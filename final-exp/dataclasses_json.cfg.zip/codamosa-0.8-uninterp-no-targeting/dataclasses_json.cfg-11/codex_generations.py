

# Generated at 2022-06-21 11:04:35.961501
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    c.encoders = {"name": "Joker"}
    assert c.encoders["name"] == "Joker"
    c.decoders = {"name": "Joker"}
    assert c.decoders["name"] == "Joker"
    c.mm_fields = {"name": "Joker"}
    assert c.mm_fields["name"] == "Joker"

# Generated at 2022-06-21 11:04:42.577729
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    global_config.encoders = {type(''): str}
    global_config.decoders = {type(''): str}
    global_config.mm_fields = {type(''): str}
    # global_config._json_module = json
    assert global_config.encoders == {type(''): str}
    assert global_config.decoders == {type(''): str}
    assert global_config.mm_fields == {type(''): str}
    # assert global_config._json_module == json

# Generated at 2022-06-21 11:04:44.008168
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)



# Generated at 2022-06-21 11:04:46.207810
# Unit test for function config
def test_config():
    @dataclass
    @config(mm_field=MarshmallowField())  # type: ignore
    class Dummy:
        pass

# Generated at 2022-06-21 11:04:48.823261
# Unit test for constructor of class Exclude

# Generated at 2022-06-21 11:04:50.865868
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert not Exclude.ALWAYS("a")


# Generated at 2022-06-21 11:04:55.228895
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER(Exclude.NEVER) == False
    assert Exclude.NEVER(Exclude.ALWAYS) == False


# Generated at 2022-06-21 11:04:56.571259
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('x') == False

# Generated at 2022-06-21 11:04:57.704291
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({"foo": 1}) == True

# Generated at 2022-06-21 11:05:09.594790
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # assert len(global_config._GlobalConfig()) == 5
    assert global_config.encoders == dict()
    assert global_config.decoders == dict()
    assert global_config.mm_fields == dict()
    assert global_config._json_module == json



# Generated at 2022-06-21 11:05:13.895763
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("field_name") == True, "UNIT TEST FAILED test_Exclude_ALWAYS"


# Generated at 2022-06-21 11:05:14.880492
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None

# Generated at 2022-06-21 11:05:24.023987
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    # Act
    # Assert
    assert Exclude.NEVER(dict())
    assert Exclude.NEVER(object)
    assert Exclude.NEVER(int)
    assert Exclude.NEVER(int())
    assert Exclude.NEVER(list)
    assert Exclude.NEVER(list())
    assert Exclude.NEVER(set)
    assert Exclude.NEVER(set())
    assert Exclude.NEVER(tuple)
    assert Exclude.NEVER(tuple())
    assert Exclude.NEVER(str)
    assert Exclude.NEVER(str())
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(float)
    assert Exclude.NEVER(float())
    assert Exclude.NEVER

# Generated at 2022-06-21 11:05:29.758588
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(tuple())
    assert Exclude.ALWAYS(list())
    assert Exclude.ALWAYS(dict())
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('abc')
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0.)
    assert Exclude.ALWAYS(1.)


# Generated at 2022-06-21 11:05:32.518120
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER('STR') == False
    assert Exclude.NEVER(Exclude.NEVER) == False


# Generated at 2022-06-21 11:05:34.378420
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("beijing")
    assert not Exclude.NEVER("beijing")

# Generated at 2022-06-21 11:05:36.218221
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")
    assert Exclude.ALWAYS(45)


# Generated at 2022-06-21 11:05:37.538526
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('hey') == False


# Generated at 2022-06-21 11:05:47.175148
# Unit test for function config
def test_config():
    import marshmallow as ma
    test_config = config(field_name='test_name', mm_field=ma.fields.DateTime(
        format='%Y-%m-%d'), letter_case=lambda x: x, undefined=Undefined.EXCLUDE)
    assert test_config['dataclasses_json']['mm_field'].format == '%Y-%m-%d'
    assert test_config['dataclasses_json']['letter_case']('a') == 'a'
    assert test_config['dataclasses_json']['undefined'] == Undefined.EXCLUDE

# Generated at 2022-06-21 11:05:48.633856
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:06:02.175803
# Unit test for function config
def test_config():
    # Setup global config
    global_config.encoders = {}
    global_config.decoders = {}
    global_config.mm_fields = {}

    # Setup dataclass
    @dataclass
    @config()
    class Test:
        name: str

    # Test read from global config
    assert Test().json() == '{"name":null}'

    # Setup dataclass
    @dataclass
    @config(encoder=str, decoder=int)
    class Test:
        name: str

    # Test read from config
    assert Test('name').json() == '"name"'
    assert Test.parse_obj('name') == Test(name=110)

# Generated at 2022-06-21 11:06:03.557392
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-21 11:06:13.296316
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from marshmallow import fields

    import json
    import pytest
    from dataclasses_json import DataClassJsonMixin, dataclass_json
    from dataclasses_json._config import (
        encode, letter_case, mm_field, exclude, undefined
    )

    # Test simple config
    @dataclass
    @config(encoder=lambda o: o * 2,
            decoder=lambda o: o * 3,
            letter_case=lambda o: o.lower(),
            mm_field=fields.Int,
            undefined=Undefined.RAISE,
            exclude=Exclude.ALWAYS,
            field_name='value',
            )
    @dataclass_json
    class ConfigTest(DataClassJsonMixin):
        value: int

   

# Generated at 2022-06-21 11:06:21.813977
# Unit test for function config
def test_config():
    @dataclass
    class Example:
        field: int
        field2: int = field(metadata=config(exclude=Exclude.NEVER))
        field3: int = field(metadata=config(field_name="overridden_field"))
        
    assert asdict(Example(123), use_defaults=False) == {"field": 123}
    assert asdict(Example(123, 456), use_defaults=False) == {"field": 123, "field2": 456}
    assert asdict(Example(123, 456), use_defaults=False, exclude=Exclude.NEVER) == {"field": 123, "field2": 456, "field3": 123}

# Generated at 2022-06-21 11:06:23.056243
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:06:34.932821
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    global_config.encoders[int] = _GlobalConfig().encoders.get(int, lambda x: x)
    global_config.decoders[int] = _GlobalConfig().decoders.get(int, lambda x: x)
    global_config.mm_fields[int] = _GlobalConfig().mm_fields.get(int, lambda x: x)
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)
    assert 'encoders' in global_config.__dict__
    assert 'decoders' in global_config.__dict__
    assert 'mm_fields' in global_config.__dict__


# Generated at 2022-06-21 11:06:37.795457
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    ALWAYS = Exclude.ALWAYS(1)
    NEVER = Exclude.NEVER(1)
    assert ALWAYS == True
    assert NEVER == False


# Generated at 2022-06-21 11:06:39.155794
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:06:41.523426
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    x = _GlobalConfig()
    assert isinstance(x.encoders, dict)
    assert isinstance(x.decoders, dict)
    assert isinstance(x.mm_fields, dict)


# Generated at 2022-06-21 11:06:42.821462
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("")
    assert not Exclude.NEVER("")

# Generated at 2022-06-21 11:06:51.864794
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from marshmallow import fields, Schema
    import pytest
    import json
    import os

    @dataclass
    class Person:
        name: str
        age: int = field(metadata=config(mm_field=fields.Integer(validate=lambda n: n > 18)))

        def __post_init__(self):
            self.age = self.age + 1

    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer(validate=lambda n: n > 18)

    person = Person('Pete', 22)
    assert json.loads(PersonSchema().dumps(person)) == {"name": "Pete", "age": 23}

# Generated at 2022-06-21 11:06:58.128990
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import config as dcj_config
    from marshmallow import Schema, fields


    @dataclass
    class C:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

        @config(encoder=lambda x: 'a')
        def a(self):
            return self.a

        @config(decoder=lambda x: 9)
        def b(self):
            return self.b

        @config(mm_field=fields.Str)
        def c(self):
            return self.c
    
    obj = C()
    schema = Schema.from_dataclass(obj)
    obj2 = schema.load(schema.dump(obj))

# Generated at 2022-06-21 11:07:00.995942
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS('a') == True)
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.ALWAYS({}) == True)


# Generated at 2022-06-21 11:07:02.919921
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('_')


# Generated at 2022-06-21 11:07:08.731976
# Unit test for function config
def test_config():
    import json

    import marshmallow as mm
    from marshmallow.fields import Integer

    import dataclasses
    from dataclasses_json.undefined import skip_undefined

    from dataclasses_json.config import config

    @dataclasses.dataclass
    @config(encoder=json.dumps, decoder=json.loads)
    class Person:
        name: str
        age: int
        # mm_field = mm.fields.Integer(missing=None)

    p = Person('Jill', age=37)

    assert json.loads(json.dumps(p)) == {'name': 'Jill', 'age': 37}

# Generated at 2022-06-21 11:07:19.820820
# Unit test for function config
def test_config():
    # NB: We should be using Undefined.EXCLUDE here, but this would
    # (erroneously) raise an UndefinedParameterError

    # Test that Undefined[Key] works correctly
    # NB: We use s for serialization, d for deserialization
    for s, d, label in ((False, True, "Default"),
                        (Undefined.EXCLUDE, Undefined.RAISE, "Exclude"),
                        (Undefined.RAISE, Undefined.RAISE, "Raise"),
                        (Undefined.INCLUDE, Undefined.INCLUDE, "Include")):
        encoded = json.dumps(Data(1, 2), cls=ConfigEncoder[s, d])
        # Expected output depends on whether or not we are including or
        # excluding undefined fields

# Generated at 2022-06-21 11:07:28.174416
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(object)
    assert Exclude.ALWAYS(Exclude)
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(test_Exclude_ALWAYS)
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS([1, None])
    assert Exclude.ALWAYS([1, None, Exclude, Exclude.ALWAYS, test_Exclude_ALWAYS, 'a'])


# Generated at 2022-06-21 11:07:30.649628
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()
    print('Test for class _GlobalConfig suceeded!')


# Generated at 2022-06-21 11:07:35.064823
# Unit test for function config
def test_config():
    @config
    @dataclass
    class Person:
        name: str

    assert type(Person.__dataclass_json__) == dict
    assert type(Person.__dataclass_json__['dataclasses_json']) == dict

# Generated at 2022-06-21 11:07:38.553222
# Unit test for constructor of class Exclude
def test_Exclude():
    alway,never =Exclude.ALWAYS,Exclude.NEVER
    assert alway is not None, "alway is None"
    assert never is not None, "never is None"

# Generated at 2022-06-21 11:07:57.186286
# Unit test for function config
def test_config():
    from marshmallow import fields
    from .converter import Converter, Field

    class TestClass:
        pass

    @config(encoder=1, decoder=True)
    class TestClass1(TestClass):
        pass

    assert global_config.encoders[TestClass1] is 1
    assert global_config.decoders[TestClass1] is True

    @config(encoder=None, decoder=False)
    class TestClass2(TestClass):
        pass

    assert global_config.encoders[TestClass2] is None
    assert global_config.decoders[TestClass2] is False

    @config(mm_field=fields.String(load_from="N"))
    class TestClass3(TestClass):
        pass


# Generated at 2022-06-21 11:07:59.429796
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    assert e.ALWAYS(1) == True
    assert e.NEVER(1) == False

# Generated at 2022-06-21 11:08:06.825616
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1.1) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS('False') == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS({}) == True


# Generated at 2022-06-21 11:08:10.184887
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS(1))
    assert (Exclude.ALWAYS("a"))
    assert (Exclude.ALWAYS(Exclude.ALWAYS))



# Generated at 2022-06-21 11:08:12.361192
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('hi')
    assert not Exclude.NEVER('hi')


# Generated at 2022-06-21 11:08:13.689143
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	print("The test_Exclude_NEVER is not implemented.")


# Generated at 2022-06-21 11:08:19.384035
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1.0) == True


# Generated at 2022-06-21 11:08:29.945703
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses import dataclass
    from decimal import Decimal
    import pytest

    @config(exclude=lambda f, _: f.name == 'my_field')
    @dataclass
    class MyClass:
        my_field: str
        my_other_field: str

    json_data = {"my_field": "my_value", "my_other_field": "other_value"}
    expected_json_data = {"my_other_field": "other_value"}
    assert MyClass.Schema().dump(MyClass("my_value", "other_value")) == expected_json_data

    with pytest.raises(UndefinedParameterError):
        @config(undefined='ASDF')
        @dataclass
        class AnotherClass:
            my_field: str

# Generated at 2022-06-21 11:08:32.087592
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)


# Generated at 2022-06-21 11:08:35.077785
# Unit test for function config
def test_config():
    class UnexpectedUndefinedParameterAction(Enum):
        ACTION = 1
    with pytest.raises(UndefinedParameterError):
        config(undefined=UnexpectedUndefinedParameterAction.ACTION)

# Generated at 2022-06-21 11:09:00.435464
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.NEVER(1) == False)

# Generated at 2022-06-21 11:09:06.258091
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import config

    assert config() == dict(dataclasses_json=dict())

    @dataclass
    @config(encoder=lambda x: x + 1)
    class Dummy:
        a: int = field(metadata=config(encoder=lambda x: x + 2))

    assert Dummy(12).to_dict() == dict(a=14)



# Generated at 2022-06-21 11:09:14.623815
# Unit test for function config
def test_config():
    @dataclass
    @config(letter_case='upper', field_name='fizzBuzz')
    class A:
        pass

    assert 'dataclasses_json' in A.__dataclass_fields__['fizzBuzz'].metadata
    assert A.__dataclass_fields__['fizzBuzz'].metadata['dataclasses_json']['letter_case']('foobar') == 'FOOBAR'

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class B:
        pass

    assert 'dataclasses_json' in B.__dataclass_fields__['B'].metadata
    assert B.__dataclass_fields__['B'].metadata['dataclasses_json']['exclude']('B', B) is True


# Generated at 2022-06-21 11:09:26.428254
# Unit test for function config
def test_config():
    @dataclass
    class A:
        foo: str
        bar: int = 10
        baz: Optional[float] = 20.5

    assert config() == {'dataclasses_json': {}}


# Generated at 2022-06-21 11:09:28.499887
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)


# Generated at 2022-06-21 11:09:30.071352
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))



# Generated at 2022-06-21 11:09:31.358795
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3)
    assert not Exclude.NEVER(3)

# Generated at 2022-06-21 11:09:33.984306
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert type(gc.encoders) == dict
    assert type(gc.decoders) == dict
    assert type(gc.mm_fields) == dict

# Generated at 2022-06-21 11:09:34.994772
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({}) == True

# Generated at 2022-06-21 11:09:40.739202
# Unit test for function config
def test_config():
    """
    Test function config to make sure it handles
    configs.
    """

    @dataclass
    @config(encoder=lambda o: o,
            decoder=lambda o: o,
            mm_field=lambda o: o,
            letter_case=lambda o: o,
            undefined='default',
            exclude=lambda o, t: True)
    class MyClass:
        name: str
        test: str = 'test'

    assert MyClass.__dataclass_json__.encoders['MyClass'] == (lambda o: o)
    assert MyClass.__dataclass_json__.decoders['MyClass'] == (lambda o: o)
    assert MyClass.__dataclass_json__.fields[0].mm_field == (lambda o: o)
    assert MyClass.__

# Generated at 2022-06-21 11:10:18.610727
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  # Arrange
  # Act
  # Assert
  assert Exclude.NEVER(None)

# Generated at 2022-06-21 11:10:19.739116
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:10:21.092832
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-21 11:10:23.155415
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def f(x):
        y = "hello"
        return y

    assert Exclude.NEVER(f) == f(f)

test_Exclude_NEVER()

# Generated at 2022-06-21 11:10:25.303025
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(-1) == True
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(-1) == False

# Generated at 2022-06-21 11:10:27.052603
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # arrange
    test_instance = {}
    # act
    result = Exclude.NEVER(test_instance)
    # assert
    assert not result, "Expected result should be False"

# Generated at 2022-06-21 11:10:29.013167
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0


# Generated at 2022-06-21 11:10:29.889537
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:10:36.557506
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_test = _GlobalConfig()
    assert isinstance(global_config_test.encoders, dict)
    assert isinstance(global_config_test.decoders, dict)
    assert isinstance(global_config_test.mm_fields, dict)
    # assert isinstance(global_config_test.json_module, json)



# Generated at 2022-06-21 11:10:38.305055
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0

# Generated at 2022-06-21 11:11:54.417428
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # setup
    from dataclasses import dataclass

    @dataclass
    class Data:
        a: str = ""
        b: str = ""
    data = Data(a="a", b="b")

    # test
    assert Exclude.NEVER(data)

    # teardown
    del Data
    del data


# Generated at 2022-06-21 11:12:02.791905
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class Nested(DataClassJsonMixin):
        a: int = field(metadata=config(field_name='a_1'))

    @dataclass
    class User(DataClassJsonMixin):
        b: Nested = field(metadata=config(field_name='z'))

    assert User.schema()(User(b=Nested(a=1))).data == {
        'z': {
            'a_1': 1
        }
    }

# Generated at 2022-06-21 11:12:04.586698
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True



# Generated at 2022-06-21 11:12:06.875103
# Unit test for function config
def test_config():
    config(undefined="ignore")
    config(undefined=Undefined.RAISE)
    config(undefined="INVALID_ACTION")

# Generated at 2022-06-21 11:12:09.528772
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    """
    Some unit testing.
    """
    item = "hello"
    assert Exclude.ALWAYS(item) == True


# Generated at 2022-06-21 11:12:15.637570
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined

    @dataclass
    class A:
        @classmethod
        def encode(cls, vec: list) -> str:
            return ','.join(map(str, vec))

        @classmethod
        def decode(cls, vec_str: str) -> list:
            return [float(x) for x in vec_str.split(',')]

    @config(encoder=A.encode, decoder=A.decode, undefined=Undefined.RAISE)
    @dataclass
    class B:
        vec: list

# Generated at 2022-06-21 11:12:16.708695
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(1) is False

# Generated at 2022-06-21 11:12:19.069833
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:12:21.551309
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-21 11:12:24.261241
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(False)
    assert(a == False)
    a = Exclude.NEVER(True)
    assert(a == False)