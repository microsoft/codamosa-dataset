

# Generated at 2022-06-21 11:04:28.254329
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-21 11:04:30.916251
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-21 11:04:37.660263
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.config import String

    @dataclass
    class Foo:
        a: str
        b: str
        c: int = config(letter_case=String.LOWERCASE,
                        field_name='_c')

    f = Foo('a', 'b', 3)
    assert f.a == "a"
    assert f.b == "b"
    assert f._c == 3

# Generated at 2022-06-21 11:04:41.549091
# Unit test for constructor of class Exclude
def test_Exclude():
    ex = Exclude()
    assert ex.__class__.__name__ == 'Exclude'
    assert type(ex.__init__).__name__ == 'function'
    assert ex.__doc__ == '\n    Pre-defined constants for exclusion. By default, fields are configured to\n    be included.\n    '


# Generated at 2022-06-21 11:04:54.826524
# Unit test for function config
def test_config():
    import unittest
    class TestConfig(unittest.TestCase):

        def test_config(self):
            dict = config(metadata=dict(a=1, b=dict(c=2)), c=3, d=dict(e=4))

            self.assertDictEqual(dict, {'a': 1, 'b': dict(c=2),
                                        'dataclasses_json': dict(c=3, d=dict(e=4))})

        def test_config_undefined(self):
            with self.assertRaises(UndefinedParameterError):
                dict = config(undefined='UNDEF')

            dict = config(undefined=Undefined.EXCLUDE)

# Generated at 2022-06-21 11:04:55.857631
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(2) == False

# Generated at 2022-06-21 11:04:58.205035
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-21 11:05:08.454169
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    global_config.encoders = {"encoders": 1}
    global_config.decoders = {"decoders": 1}
    global_config.mm_fields = {"mm_fields": 1}

    expected_encoders = {"encoders": 1}
    expected_decoders = {"decoders": 1}
    expected_mm_fields = {"mm_fields": 1}

    assert expected_encoders == global_config.encoders
    assert expected_decoders == global_config.decoders
    assert expected_mm_fields == global_config.mm_fields


# Generated at 2022-06-21 11:05:10.237645
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()
    assert Exclude.ALWAYS(object())
    assert not Exclude.NEVER(object())



# Generated at 2022-06-21 11:05:15.725622
# Unit test for function config
def test_config():
    import dataclasses
    class A:
        pass

    @dataclasses.dataclass
    class B(A):
        value: str = dataclasses.field(metadata=config(encoder=tuple))

    assert A.__dict__ == {}
    assert B.__dict__['value']['metadata']['dataclasses_json']['encoder'] is tuple

# Generated at 2022-06-21 11:05:18.744236
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-21 11:05:27.328045
# Unit test for function config
def test_config():
    f1 = lambda x: x
    f2 = lambda x: x
    for f in [f1, f2]:
        assert f(1) == config(encoder=f)[1]['dataclasses_json']['encoder']
        assert f(1) == config(decoder=f)[1]['dataclasses_json']['decoder']
        assert f(1) == config(mm_field=f)[1]['dataclasses_json']['mm_field']
        assert f(1) == config(letter_case=f)[1]['dataclasses_json']['letter_case']
        assert f(1) == config(undefined=f)[1]['dataclasses_json']['undefined']

# Generated at 2022-06-21 11:05:30.238397
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json
    # global_config.json_module = json


# Generated at 2022-06-21 11:05:31.307434
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('value') is False


# Generated at 2022-06-21 11:05:33.010590
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:05:36.307340
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-21 11:05:37.019742
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('_') == True


# Generated at 2022-06-21 11:05:40.738208
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('1') == True
    assert Exclude.ALWAYS('2') == True


# Generated at 2022-06-21 11:05:50.775123
# Unit test for function config
def test_config():
    """Ensure that config can be called in any form"""
    assert config(mm_field=1) == {'dataclasses_json': {'mm_field': 1}}
    assert config(encoder=1) == {'dataclasses_json': {'encoder': 1}}

    assert config(metadata={'dataclasses_json': {'mm_field': 1}},
                  mm_field=1) == {'dataclasses_json': {'mm_field': 1}}

    assert config(mm_field=1, encoder=1) == {'dataclasses_json':
                                             {'mm_field': 1, 'encoder': 1}}

# Generated at 2022-06-21 11:05:52.375970
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders
    global_config.decoders
    global_config.mm_fields


# Generated at 2022-06-21 11:05:57.250231
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(4.2) == False)

# Generated at 2022-06-21 11:06:06.839672
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class C:
        x: int
        y: int

    data = {'x':2, 'y':3}
    assert json.loads(json.dumps(data)) == \
        dcj.load(C, json.dumps(data))

    @dcj.dataclass_json
    @dataclasses.dataclass
    class D:
        x: int

        def to_json(self):
            return {'x': self.x}

    assert {'x':3} == json.loads(json.dumps(D(3)))

    data = {'x':2, 'y':3}
    assert json.loads(json.dumps(data)) == \
        dcj.load(C, json.dumps(data))


# Generated at 2022-06-21 11:06:08.783151
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dummy_function = lambda x: x
    assert Exclude.ALWAYS(dummy_function)



# Generated at 2022-06-21 11:06:18.639459
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field

    @dataclass
    class Nested:
        pass

    @dataclass
    class Example:
        simple: bool = field(metadata=config(encoder=float))
        nested: Nested = field(metadata=config(mm_field=dict))

    assert Example.__dataclass_fields__['simple'].metadata['dataclasses_json']['encoder'] == float
    assert Example.__dataclass_fields__['nested'].metadata['dataclasses_json']['mm_field'] == dict

LOWER, UPPER, CAPITALIZE, SNAKE, CAMEL, PASCAL = map(config, [
    'lower', 'UPPER', 'Capitalize', 'snake', 'camel', 'Pascal'
])


# Generated at 2022-06-21 11:06:20.111319
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)



# Generated at 2022-06-21 11:06:22.541998
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert not len(global_config.encoders)
    assert not len(global_config.decoders)
    assert not len(global_config.mm_fields)

# Generated at 2022-06-21 11:06:24.792672
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2) == True
    assert Exclude.NEVER(2) == False



# Generated at 2022-06-21 11:06:26.369556
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('example') == True


# Generated at 2022-06-21 11:06:28.355722
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)
    # assert False

# Generated at 2022-06-21 11:06:31.495497
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-21 11:06:42.026614
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-21 11:06:44.424537
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude()
    expected = False
    actual = obj.NEVER('a')
    assert actual==expected


# Generated at 2022-06-21 11:06:48.497497
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders.clear()
    global_config.decoders.clear()
    global_config.mm_fields.clear()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-21 11:06:51.486796
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    GlobalConfigObj = _GlobalConfig()
    assert (GlobalConfigObj.encoders) == {}
    assert (GlobalConfigObj.decoders) == {}
    assert (GlobalConfigObj.mm_fields) == {}


# Generated at 2022-06-21 11:06:52.589883
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-21 11:06:53.659812
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert(Exclude.NEVER(1)==False)


# Generated at 2022-06-21 11:06:55.284734
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("any") == True
    assert Exclude.NEVER("any") == False

# Generated at 2022-06-21 11:06:56.760242
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc") is False
    assert Exclude.NEVER("abc") is False


# Generated at 2022-06-21 11:06:59.103847
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("abcd") == False

# Generated at 2022-06-21 11:07:01.332567
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS() # no parameters

if __name__ == '__main__':
    test_Exclude_ALWAYS()

# Generated at 2022-06-21 11:07:26.460267
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude().ALWAYS(4) == True
    assert Exclude().NEVER(4) == False



# Generated at 2022-06-21 11:07:28.161655
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER(0) == False
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-21 11:07:29.698271
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-21 11:07:41.698704
# Unit test for function config
def test_config():
    def encoder(o):
        return {'data': o}

    def decoder(dct):
        return dct['data']

    class MyField(MarshmallowField):
        pass

    @dataclass_json
    @config(
        encoder=encoder,
        decoder=decoder,
        mm_field=MyField,
        letter_case=lambda s: s.upper(),
        undefined=Undefined.EXCLUDE,
    )
    class Person:
        name: str
        age: int

    metadata = Person.__dataclass_fields__['name'].metadata
    assert metadata['dataclasses_json']['encoder'] is encoder
    assert metadata['dataclasses_json']['decoder'] is decoder

# Generated at 2022-06-21 11:07:43.014310
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('123') == True


# Generated at 2022-06-21 11:07:44.778985
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-21 11:07:46.040498
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-21 11:07:46.545706
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()

# Generated at 2022-06-21 11:07:50.273682
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert type(gc.encoders) == dict
    assert gc.decoders == {}
    assert gc.mm_fields == {}
    # assert gc.json_module == json

# Generated at 2022-06-21 11:07:55.717721
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def is_not_true(x: float) -> bool:
        return not x == 1
    
    assert is_not_true(1) == False
    assert Exclude.NEVER(1) == False
    assert is_not_true(2) == True
    assert Exclude.NEVER(2) == True


# Generated at 2022-06-21 11:08:31.770066
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert isinstance(Exclude.ALWAYS, Callable)
    assert Exclude.ALWAYS(1.0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(Exclude) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:08:33.630222
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:08:37.346851
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(Exclude.ALWAYS)


# Generated at 2022-06-21 11:08:42.396894
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None
    #test that the callable functions actually return a bool value
    assert Exclude.ALWAYS(0) == True
    assert Exclude.NEVER(1) == False
    #print("test_Exclude: tested Exclude and its constructors")

# Generated at 2022-06-21 11:08:43.387635
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude() is None


# Generated at 2022-06-21 11:08:45.759212
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, type(lambda: -1))
    assert isinstance(Exclude.NEVER, type(lambda: -1))


# Generated at 2022-06-21 11:08:52.431287
# Unit test for function config
def test_config():
    import pytest
    from dataclasses_json.config import global_config, config

    def custom_decoder(json_data):
        return json_data.upper()

    class CustomField(object):
        pass

    class CustomField2(object):
        pass

    class CustomField3(object):
        pass

    class TestDecoder:
        @dataclass_json
        @config(encoder=custom_decoder)
        class CustomEncoder:
            data: str

        @config(decoder=custom_decoder)
        class CustomDecoder:
            data: str

        @config(mm_field=CustomField)
        class CustomMMField:
            data: str

        @config(mm_field=CustomField2)
        class CustomMMField2:
            data: str


# Generated at 2022-06-21 11:08:54.740573
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-21 11:09:05.030561
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("######################## Unit Test Start ########################")
    print("The method ALWAYS of class Exclude:")

    x = Exclude()
    print("The default valus of Exclude.ALWAYS:")
    print(Exclude.ALWAYS)

    def func(T):
        return True

    Exclude.ALWAYS = func
    print("The function for Exclude.ALWAYS:")
    print(Exclude.ALWAYS)
    try_this = Exclude.ALWAYS(2)
    print("The result of Exclude.ALWAYS(2):")
    print(try_this)
    print("The value of Exclude.ALWAYS after resetting:")
    print(Exclude.ALWAYS)

    print("######################### Unit Test End #########################")


# Generated at 2022-06-21 11:09:07.352643
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS("anything")


# Generated at 2022-06-21 11:10:20.369162
# Unit test for function config
def test_config():
    class Test:
        pass

    @config(encoder=str, decoder=Test, undefined=True)
    class TC:
        pass

    assert TC.__dataclass_fields__['__json__'].metadata['dataclasses_json']['encoder'] == str
    assert TC.__dataclass_fields__['__json__'].metadata['dataclasses_json']['decoder'] == Test
    assert TC.__dataclass_fields__['__json__'].metadata['dataclasses_json']['undefined'] == Undefined.RAISE

# Generated at 2022-06-21 11:10:27.477923
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields as mm_fields
    import json

    class CustomConfigClass:
        pass

    class CustomConfigField(mm_fields.Field):
        pass

    def to_str(value: CustomConfigClass) -> str:
        return "CustomConfigClass"

    def from_str(value: str) -> CustomConfigClass:
        return CustomConfigClass()

    @dataclass
    @config(encoder=to_str, decoder=from_str, mm_field=mm_fields.Number(),
            letter_case=lambda s: s.lower(), undefined=Undefined.EXCLUDE,
            field_name="alias")
    class TestClass:
        test_data: CustomConfigClass
        normal_field: int
        camel_case_field: int = 1
        snake

# Generated at 2022-06-21 11:10:31.644444
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    input = {
        "test_key": "test_value"
    }
    output = Exclude.ALWAYS(input)
    expected = True
    if output == expected:
        print("Test passed!")
        return True
    else:
        print("Test failed!")
        return False


# Generated at 2022-06-21 11:10:32.815436
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-21 11:10:37.587289
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config, _GlobalConfig)
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:10:39.987382
# Unit test for constructor of class Exclude
def test_Exclude():
    a = Exclude.ALWAYS
    b = Exclude.NEVER
    assert a == Exclude.ALWAYS
    assert b == Exclude.NEVER


# Generated at 2022-06-21 11:10:41.934282
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-21 11:10:44.221350
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    assert conf.encoders == {}
    assert conf.decoders == {}
    assert conf.mm_fields == {}
    # assert conf.json_module == json

# Generated at 2022-06-21 11:10:47.036496
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-21 11:10:50.408938
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class Test:
        a: int

    assert 'a' not in asdict(Test(123))



# Generated at 2022-06-21 11:13:28.903920
# Unit test for function config
def test_config():
    config(encoder=lambda x: x,
           letter_case=lambda x: x,
           field_name='test_field',
           undefined=Undefined.RAISE,
           exclude=lambda x, _: False)

    config(undefined="skip")
    config(undefined=Undefined.RAISE)


if __name__ == '__main__':
    test_config()

# Generated at 2022-06-21 11:13:30.283881
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test') is True


# Generated at 2022-06-21 11:13:32.849932
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("HAHAHAHA")
    assert Exclude.NEVER("HAHAHA")


# Generated at 2022-06-21 11:13:35.352032
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(Exclude.NEVER) == False)
    assert(Exclude.NEVER(Exclude.ALWAYS) == False)


# Generated at 2022-06-21 11:13:37.902049
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_global_config = _GlobalConfig()
    assert isinstance(test_global_config.mm_fields, dict)
    assert isinstance(test_global_config.encoders, dict)
    assert isinstance(test_global_config.decoders, dict)


# Generated at 2022-06-21 11:13:40.830134
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Uncomment to test manually.
    # _GlobalConfig()
    assert global_config.encoders == {}
    assert not global_config.decoders
    assert not global_config.mm_fields

# Generated at 2022-06-21 11:13:43.024478
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("test") is True
    assert Exclude.NEVER("test") is False

# Generated at 2022-06-21 11:13:44.983346
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:13:48.522907
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("tra") == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(0.0) == True
    assert Exclude.ALWAYS(complex(0, 0)) == True


# Generated at 2022-06-21 11:13:50.365184
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS is not None
