

# Generated at 2022-06-21 11:04:31.429364
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-21 11:04:33.569438
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class DataClass:
        field: str
    assert Exclude.NEVER(DataClass.field)


# Generated at 2022-06-21 11:04:41.364220
# Unit test for function config
def test_config():

    class SomeClass: pass

    @config(encoder=lambda x: x, decoder=lambda x: x, mm_field=None,
            letter_case=lambda x: x, field_name='some_field', exclude=None)
    class SomeOtherClass: pass

    assert 'dataclasses_json' in dataclasses.asdict(SomeClass())

    assert 'dataclasses_json' not in dataclasses.asdict(SomeClass)

    assert 'dataclasses_json' in dataclasses.asdict(SomeOtherClass())

    assert 'dataclasses_json' not in dataclasses.asdict(SomeOtherClass)

# Generated at 2022-06-21 11:04:42.943842
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

# Generated at 2022-06-21 11:04:55.330499
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    @dataclasses.dataclass
    class C:
        """
        @Exclude.NEVER
        """
        x: int = dataclasses.field(
            metadata=config(
                exclude=Exclude.NEVER
            )
        )
        y: int = dataclasses.field(
            metadata=config(
                exclude=Exclude.NEVER
            )
        )
        z: int = dataclasses.field(
            metadata=config(
                exclude=Exclude.NEVER
            )
        )

    c = C(0, 10, 1)

    dump = DataClassJsonMixin.to_json(c)
    #print(dump)
    #assert dump == {'x': 0, 'y': 10, 'z': 1}

    # DataClassJsonMixin.to_dictは

# Generated at 2022-06-21 11:04:56.964433
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-21 11:05:08.927378
# Unit test for function config
def test_config():
    class TestConfig:
        def __init__(self):
            self.field_name: str = 'TestConfig'

    def encoder(self):
        return 'TestConfig'

    # Invalid undefined parameter
    try:
        config(undefined='wrong')
        assert False, "Should not reach here"
    except UndefinedParameterError:
        pass

    # Invalid class
    try:
        config(undefined=TestConfig)
        assert False, "Should not reach here"
    except UndefinedParameterError:
        pass

    # Invalid class name
    try:
        config(undefined='TestConfig')
        assert False, "Should not reach here"
    except UndefinedParameterError:
        pass

    # Valid class name

# Generated at 2022-06-21 11:05:10.538887
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-21 11:05:11.979715
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:05:13.895736
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:05:24.478431
# Unit test for function config
def test_config():
    @dataclass
    class MyClass:
        id = int

    def encoder(value):
        return value

    def decoder(value):
        return value

    def mm_field():
        return 'test_field'

    def letter_case(name):
        return 'Capitalized'

    def exclude(name):
        return True

    # Test basic config
    assert config(MyClass, encoder=encoder) == {
        'dataclasses_json': {
            'encoder': encoder
        }
    }

    # Test if config appends metadata
    assert config(
        config(MyClass, encoder=encoder),
        decoder=decoder) == {
        'dataclasses_json': {
            'encoder': encoder,
            'decoder': decoder
        }
    }



# Generated at 2022-06-21 11:05:30.552229
# Unit test for function config

# Generated at 2022-06-21 11:05:32.011062
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True



# Generated at 2022-06-21 11:05:33.189084
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:05:37.164871
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    try:
        assert Exclude.ALWAYS(1)
    except AssertionError:
        print("test_Exclude_ALWAYS: test failed!")
    else:
        print("test_Exclude_ALWAYS: test passed!")


# Generated at 2022-06-21 11:05:40.406255
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False


# Generated at 2022-06-21 11:05:44.125224
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('') == True


# Generated at 2022-06-21 11:05:45.674692
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("_") == True


# Generated at 2022-06-21 11:05:53.661821
# Unit test for function config
def test_config():
    from marshmallow import Schema, fields
    
    @config(encoder = lambda x: x+1, decoder = lambda x: x-1, mm_field = fields.Integer())
    class X:
        def __init__(self):
            self.x = 3
    

# Generated at 2022-06-21 11:05:55.553570
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    key = 'test'
    assert Exclude.NEVER(key) == False

# Generated at 2022-06-21 11:05:58.272253
# Unit test for constructor of class Exclude
def test_Exclude():
    config_Exclude = Exclude()

# Generated at 2022-06-21 11:06:00.300307
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-21 11:06:03.290198
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:06:04.172521
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    pass


# Generated at 2022-06-21 11:06:14.022124
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class A:
        field1: int
        field: bool = True

    metadata = config(field_name="field1", exclude=Exclude.ALWAYS)
    assert metadata['dataclasses_json']['field_name'] == "field1"
    assert metadata['dataclasses_json']['exclude'] == Exclude.ALWAYS

    metadata = config(undefined=Undefined.EXCLUDE)
    assert metadata['dataclasses_json']['undefined'] == Undefined.EXCLUDE

    metadata = config(undefined='exclude')
    assert metadata['dataclasses_json']['undefined'] == Undefined.EXCLUDE

    metadata = config(undefined='FOO')

# Generated at 2022-06-21 11:06:22.173613
# Unit test for function config
def test_config():
    import pytest
    from marshmallow import fields as mm_fields

    @config(encoder=1, decoder=2, mm_field=3, letter_case=4, field_name='abc')
    class x:
        pass

    assert x.__dataclasses_json__ == {
        'dataclasses_json': {
            'encoder': 1,
            'decoder': 2,
            'mm_field': 3,
            'letter_case': 4,
            'undefined': Undefined.RAISE,
            'exclude': Exclude.NEVER,
        }
    }


# Generated at 2022-06-21 11:06:27.849036
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('True')
    assert Exclude.ALWAYS('true')
    assert Exclude.ALWAYS('False')
    assert Exclude.ALWAYS('false')
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-21 11:06:30.231240
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.mm_fields == {}
    assert global_config.decoders == {}

# Generated at 2022-06-21 11:06:31.645963
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('') == False


# Generated at 2022-06-21 11:06:33.415526
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER("")
    assert result == False


# Generated at 2022-06-21 11:06:38.803989
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER("a") == False

# Generated at 2022-06-21 11:06:45.613705
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from unittest import TestCase, main

    @dataclass
    class Config:
        exclude: Optional[Callable] = field(
            default_factory=lambda: lambda _, __: False
        )
        encoder: Optional[Callable] = field(
            default_factory=lambda: lambda _: ''
        )
        decoder: Optional[Callable] = field(
            default_factory=lambda: lambda _: ''
        )
        letter_case: Optional[Callable] = field(
            default_factory=lambda: lambda _: ''
        )
        undefined: Optional[Undefined] = field(
            default_factory=lambda: Undefined.RAISE
        )


# Generated at 2022-06-21 11:06:46.420211
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    exclude_instance = Exclude()
    assert exclude_instance.NEVER(3) == False


# Generated at 2022-06-21 11:06:47.152127
# Unit test for function config
def test_config():
    # added config.copy() and config.clear()
    pass



# Generated at 2022-06-21 11:06:48.453671
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS([]) == True


# Generated at 2022-06-21 11:06:57.643182
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json.undefined import _UndefinedType, Undefined

    from marshmallow import fields

    @dataclass
    class Simple:
        string: str = field(metadata=config(field_name='abc'))


# Generated at 2022-06-21 11:07:00.470622
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:07:03.540524
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(6) == True


# Generated at 2022-06-21 11:07:06.348616
# Unit test for function config
def test_config():
    import pytest

    with pytest.raises(UndefinedParameterError):
        config(undefined='NONEXISTENT_ACTION')

    config(undefined='RAISE')
    config(undefined=Undefined.RAISE)

# Generated at 2022-06-21 11:07:08.745071
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)


# Generated at 2022-06-21 11:07:16.211149
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-21 11:07:23.929157
# Unit test for function config
def test_config():
    # type: () -> None
    from marshmallow import fields
    from unittest.mock import Mock
    import json

    def func():
        # type: () -> None
        pass

    func = config(encoder=func, metadata={})(func)
    assert func.__metadata__['dataclasses_json']['encoder'] is func

    func = config(decoder=func, metadata={})(func)
    assert func.__metadata__['dataclasses_json']['decoder'] is func

    func = config(mm_field=fields.String)(func)
    assert isinstance(func.__metadata__['dataclasses_json']['mm_field'],
                      fields.String)

    func = config(letter_case=lambda x: x)(func)

# Generated at 2022-06-21 11:07:27.676650
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)
    assert isinstance(global_config.mm_fields, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.encoders, dict)


# Generated at 2022-06-21 11:07:29.290813
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("any value")


# Generated at 2022-06-21 11:07:31.229950
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)==False


# Generated at 2022-06-21 11:07:39.277635
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {int: lambda x: 1}
    global_config.decoders = {int: lambda x: 1}
    global_config.mm_fields = {int: lambda x: 1}
    assert global_config.encoders == {int: lambda x: 1}
    assert global_config.decoders == {int: lambda x: 1}
    assert global_config.mm_fields == {int: lambda x: 1}

test__GlobalConfig()


# Generated at 2022-06-21 11:07:41.097975
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_bool = Exclude.ALWAYS(1)
    assert test_bool == True


# Generated at 2022-06-21 11:07:47.104992
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert 'encoders' in global_config.__dict__, 'encoders not in global_config'
    assert 'decoders' in global_config.__dict__, 'decoders not in global_config'
    assert 'mm_fields' in global_config.__dict__, 'mm_fields not in global_config'
    #assert '_json_module' in global_config.__dict__, '_json_module not in global_config'


# Generated at 2022-06-21 11:07:48.947586
# Unit test for function config
def test_config():
    assert config(encoder='a')['dataclasses_json'] == {'encoder': 'a'}



# Generated at 2022-06-21 11:08:01.032480
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # TODO: add more tests for _GlobalConfig
    global_config = _GlobalConfig()

    test_encoder = lambda x: x
    test_decoder = lambda x: x
    test_mm_field = MarshmallowField()
    # test_json_module = json

    global_config.encoders[type] = test_encoder
    global_config.decoders[type] = test_decoder
    global_config.mm_fields[type] = test_mm_field
    # global_config.json_module = test_json_module

    assert global_config.encoders[type] == test_encoder
    assert global_config.decoders[type] == test_decoder
    assert global_config.mm_fields[type] == test_mm_field
    # assert global_config.json_

# Generated at 2022-06-21 11:08:12.573408
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_value = 'value'

    assert Exclude.ALWAYS(test_value) is True
    assert not Exclude.ALWAYS(test_value) is False


# Generated at 2022-06-21 11:08:15.336603
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Test:
        def test(self):
            return True
    t = Test()
    assert(Exclude.NEVER(t) == False)


# Generated at 2022-06-21 11:08:18.110763
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(1) is False
    assert Exclude.ALWAYS(True) is True
    assert Exclude.NEVER(False) is False
    assert Exclude.ALWAYS(0) is True
    assert Exclude.NEVER(2) is False
    assert Exclude.ALWAYS(0) is True
    assert Exclude.NEVER(2) is False


# Generated at 2022-06-21 11:08:19.691860
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)

# Generated at 2022-06-21 11:08:21.467064
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:08:23.180118
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("test")
    assert not Exclude.NEVER("test")

test_Exclude()

# Generated at 2022-06-21 11:08:26.184066
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    assert config._json_module == json

# Generated at 2022-06-21 11:08:37.599844
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(1.0) == False
    assert Exclude.NEVER("1") == False
    assert Exclude.NEVER("0") == False
    assert Exclude.NEVER("f") == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER(" ") == False
    assert Exclude.NEVER("   ") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
   

# Generated at 2022-06-21 11:08:39.474347
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    glob = Exclude.NEVER("")
    assert glob is False

# Generated at 2022-06-21 11:08:42.936084
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(Exclude.ALWAYS)


# Generated at 2022-06-21 11:09:03.014229
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    output = Exclude.NEVER(1)
    expected_output = False
    assert output == expected_output


# Generated at 2022-06-21 11:09:04.329432
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1))


# Generated at 2022-06-21 11:09:05.922809
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:09:08.708675
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    field = config(exclude=Exclude.ALWAYS)
    assert field == {"dataclasses_json": {"exclude": Exclude.ALWAYS}}


# Generated at 2022-06-21 11:09:10.932222
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}

    assert global_config.decoders == {}

    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:09:14.504793
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert(gc.encoders == {})
    assert(gc.decoders == {})
    assert(gc.mm_fields == {})
    # assert(gc.json_module == json)
    # gc.json_module = simplejson
    # assert(gc.json_module == simplejson)


# Generated at 2022-06-21 11:09:21.264493
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class ABaseClass:
        pass

    class AClass(ABaseClass):
        pass

    class BClass:
        pass

    exclude_always = Exclude.NEVER(AClass)
    assert exclude_always is False

    exclude_always_parent = Exclude.NEVER(ABaseClass)
    assert exclude_always_parent is False

    exclude_never = Exclude.NEVER(BClass)
    assert exclude_never is False


# Generated at 2022-06-21 11:09:32.220010
# Unit test for function config
def test_config():
    import pytest
    from marshmallow import fields

    @config(encoder=str)
    @dataclass
    class MyDataClass:
        a: int 

    @dataclass
    class MyDataClass2:
        b: str = config(field_name='c', letter_case=lambda x: x.upper())[field('b')]

    @dataclass
    class MyDataClass3:
        b: str = config(undefined=Undefined.RAISE)[field('b')]

    @config(exclude=lambda field_name, field_type: field_name == 'a')
    @dataclass
    class MyDataClass4:
        a: float
        b: int

    assert MyDataClass.__annotations__['a'] == int

# Generated at 2022-06-21 11:09:39.070944
# Unit test for function config
def test_config():
    def expected_case(original_name: str) -> str:
        return original_name

    assert {
        'dataclasses_json': {
            'mm_field': 'mm_field',
            'encoder': 'encoder',
            'letter_case': expected_case,
            'undefined': Undefined.EXCLUDE,
            'exclude': 'exclude',
        }
    } == config(mm_field='mm_field',
                encoder='encoder',
                decoder='decoder',
                letter_case='snake',
                undefined='exclude',
                exclude='exclude')

    class FakeField(MarshmallowField):
        pass


# Generated at 2022-06-21 11:09:50.075870
# Unit test for function config
def test_config():
    from marshmallow import fields, Schema
    from marshmallow_fields import List

    field_name = "test_config"

    @dataclass_json
    @config(encoder=lambda x: x + 1,
            decoder=lambda x: x + 2,
            mm_field=(fields.Str if field_name == "test_config" else fields.Int)(),
            field_name="test_config",
            undefined=Undefined.EXCLUDE,
            letter_case=lambda x: x.lower(),
            exclude=lambda _, test_config: test_config == 5)
    class TestClass:
        test_config: int

    assert TestClass.schema().fields['test_config'] == fields.Str()
    assert TestClass.encoder(TestClass(1)) == 2

# Generated at 2022-06-21 11:10:35.648570
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    @dataclass
    class Student:
        name: str
        age: int
        score: int = config(field_name='marks')
        rank: int = config(field_name='ranking')

    student = Student('Ravi', 23, 80, 1)

    assert json.dumps(student.__dict__) == '{"name": "Ravi", "age": 23, "marks": 80, "ranking": 1}'


# Generated at 2022-06-21 11:10:44.555740
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str

    assert config() == {'dataclasses_json': {}}
    assert config(encoder=1) == {'dataclasses_json': {'encoder': 1}}
    assert config(mm_field='field') == {'dataclasses_json': {'mm_field': 'field'}}
    assert config(field_name='name-of-field') == \
        {'dataclasses_json': {'letter_case': lambda _: 'name-of-field'}}
    assert config(undefined='ignore') == \
        {'dataclasses_json': {'undefined': Undefined.IGNORE}}

# Generated at 2022-06-21 11:10:45.735163
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("")
    assert not Exclude.NEVER("")

# Generated at 2022-06-21 11:10:55.817425
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config, DataClassJsonMixin, mm_field, mm_schema

    test_enum = Enum('test_enum', 'a b c')

    @dataclass
    class Test:
        to_exclude: str = 'to_exclude'
        to_include: int = 1
        enum: test_enum = test_enum.a

    # basic
    @dataclass
    class DataA(DataClassJsonMixin):
        exclude: int = config(exclude=Exclude.ALWAYS)(10)
        include: int = config(exclude=Exclude.NEVER)(20)

    # stringify

# Generated at 2022-06-21 11:10:56.936822
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:10:57.689988
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)

# Generated at 2022-06-21 11:10:59.055632
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("ABC") == True


# Generated at 2022-06-21 11:11:00.432997
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("A") == True


# Generated at 2022-06-21 11:11:03.660545
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:11:06.083890
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude_obj = Exclude()
    assert exclude_obj.ALWAYS(3) == True
    assert exclude_obj.NEVER(3) == False

# Generated at 2022-06-21 11:12:29.624487
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-21 11:12:35.430121
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import config

    @dataclass
    class User:
        login: str
        name: str
        password: str = field(metadata=config(exclude=lambda f, _: f == 'password'))

    assert 'password' not in User.__dataclass_fields__
    assert 'password' not in User('joe', 'Joe Shmoe', 'abc123').__dict__
    assert User('joe', 'Joe Shmoe', 'abc123').password == 'abc123'


# Generated at 2022-06-21 11:12:37.020332
# Unit test for function config
def test_config():
    assert config(encoder=lambda x: x) == {
        'dataclasses_json': {
            'encoder': lambda x: x,
        },
    }



# Generated at 2022-06-21 11:12:44.456994
# Unit test for function config
def test_config():
    gold = {
        'dataclasses_json': {
            'encoder': str,
            'decoder': int,
            'mm_field': 'foo',
            'letter_case': lambda x: x,
            'undefined': Undefined.EXCLUDE,
            'exclude': 'bar',
        }
    }
    actual = config(
        encoder=str,
        decoder=int,
        mm_field='foo',
        letter_case=lambda x: x,
        undefined='EXCLUDE',
        exclude='bar',
    )
    assert actual == gold

# Generated at 2022-06-21 11:12:52.812794
# Unit test for function config
def test_config():
    global_config.encoders = {}
    global_config.decoders = {}
    global_config.mm_fields = {}

    def f1(obj):
        """
        :type obj: Test
        """
        return obj.value

    def f2(value):
        return Test(value)

    def f3():
        return type(Test)

    def f4(value):
        return Test(value)

    @config(encoder=f1, decoder=f2, mm_field=f3())
    class Test:

        def __init__(self, value):
            self.value = value

    assert global_config.encoders == {Test: f1}
    assert global_config.decoders == {Test: f2}

# Generated at 2022-06-21 11:12:54.156921
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert(isinstance(global_config, _GlobalConfig))


# TODO: add tests

# Generated at 2022-06-21 11:12:55.418905
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    expected = True
    assert result == expected


# Generated at 2022-06-21 11:12:56.426087
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Hi") == True

# Generated at 2022-06-21 11:13:00.158650
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-21 11:13:09.908166
# Unit test for function config
def test_config():
    class A:
        def __init__(self):
            self.value = 0
        def __eq__(self, other):
            return self.value == other.value

    def encoder(a: A):
        return f"encoded{a.value}"
    def decoder(s: str):
        if not s.startswith("encoded"):
            raise ValueError(f"invalid encoded string: {s}")
        value = int(s[len("encoded"):])
        return A()
    class MField(MarshmallowField):
        def _serialize(self, value: A, attr, obj) -> str:
            return f"marshmallow{value.value}"