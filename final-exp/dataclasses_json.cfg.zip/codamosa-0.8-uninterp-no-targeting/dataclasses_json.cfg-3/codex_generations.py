

# Generated at 2022-06-21 11:04:33.573784
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print('Unit test for method NEVER of class Exclude')
    result = Exclude.NEVER(True)
    expected = False
    print('Actual result:', result)
    print('Expected result:', expected)
    assert result == expected
    print('Success')


# Generated at 2022-06-21 11:04:36.374019
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-21 11:04:37.825954
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('func') is True


# Generated at 2022-06-21 11:04:40.758846
# Unit test for function config
def test_config():
    """
    >>> @dataclass
    ... @config(field_name='snake')
    ... class Test:
    ...     field_name: str
    >>> Test('something').json()
    {'field_name': 'something'}
    """

# Generated at 2022-06-21 11:04:43.222984
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert Exclude.NEVER(2)



# Generated at 2022-06-21 11:04:44.212701
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-21 11:04:45.602455
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS(): 
    assert Exclude.ALWAYS(4)
    

# Generated at 2022-06-21 11:04:51.806204
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @config(encoder=str)
    @dataclass
    class A:
        x: int

    assert A.__dataclass_metadata__.get('dataclasses_json').get('encoder') == str


if __name__ == '__main__':
    test_config()

# Generated at 2022-06-21 11:04:57.181544
# Unit test for function config
def test_config():
    from dataclasses_json.undefined import INCLUDE_BY_DEFAULT

    assert config(mm_field=0, undefined=INCLUDE_BY_DEFAULT) == {
        'dataclasses_json': {
            'mm_field': 0,
            'undefined': INCLUDE_BY_DEFAULT,
        }
    }

# Generated at 2022-06-21 11:04:58.437074
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True



# Generated at 2022-06-21 11:05:01.709987
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(Exclude)

# Generated at 2022-06-21 11:05:04.104969
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("x")
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-21 11:05:06.326685
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:05:10.084430
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert(isinstance(global_config.encoders, dict))
    assert(isinstance(global_config.decoders, dict))
    assert(isinstance(global_config.mm_fields, dict))
    # assert(isinstance(global_config.json_module, json))


# Generated at 2022-06-21 11:05:11.494078
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:05:21.441816
# Unit test for function config
def test_config():
    import json
    
    @dataclass
    @config(
        encoder=lambda obj: {'foo': obj.foo},
        decoder=lambda dct: Test(foo=dct['foo']))
    class Test:
        foo: str
    
    assert Test.__dataclass_json__['encoder'] is not None
    assert Test.__dataclass_json__['decoder'] is not None
    
    obj = Test(foo = "bar")
    assert json.dumps(obj) == '{"foo": "bar"}'
    assert json.dumps(Test.from_dict({"foo":"bar"})) == '{"foo": "bar"}'
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-21 11:05:24.825509
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS('Hello World!')

    assert not Exclude.NEVER(1)
    assert not Exclude.NEVER(1.0)
    assert not Exclude.NEVER('Hello World!')

# Generated at 2022-06-21 11:05:32.789743
# Unit test for function config
def test_config():
    class MyField(MarshmallowField):
        pass

    assert config(
        encoder=lambda x: x,
        decoder=lambda x: x,
        mm_field=MyField(),
        letter_case=lambda x: x.lower(),
        undefined=Undefined.EXCLUDE,
        field_name='some_name',
        exclude=Exclude.ALWAYS) == {'dataclasses_json': {
            'encoder': lambda x: x,
            'decoder': lambda x: x,
            'mm_field': MyField(),
            'letter_case': lambda x: x.lower(),
            'undefined': Undefined.EXCLUDE,
            'exclude': Exclude.ALWAYS
        }}


# Generated at 2022-06-21 11:05:34.215586
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude()
    assert obj.NEVER(1)


# Generated at 2022-06-21 11:05:35.256944
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:05:41.352866
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)==False
    

# Generated at 2022-06-21 11:05:45.235907
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_case = {"texto": "valor", "x": "1"}
    NEVER = Exclude.NEVER
    result = NEVER(test_case)
    expected = False
    assert(result == expected)


# Generated at 2022-06-21 11:05:48.421936
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    # set up
    res = Exclude.NEVER("test")
    
    # Act
    # execute test
    pass
    
    # Assert
    # verify results
    assert res == False


# Generated at 2022-06-21 11:05:55.042133
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test1:
        name: str

    @dataclass
    class Test2(Test1):
        age: int

    @dataclass
    class Test3(Test2):
        height: Optional[float] = None

    assert Test1.__dataclass_json__ == {
        'dataclasses_json': {}
    }


# Generated at 2022-06-21 11:06:04.977061
# Unit test for function config
def test_config():
    from marshmallow import Schema, fields

    @dataclass
    @config(field_name="data")
    class A:
        a: int
        b: int

        @config(encoder=lambda x: x * 2, decoder=lambda x: x // 2)
        @property
        def c(self):
            return self.a + self.b

    assert json.loads(A(1, 2).to_json()) == {'data': 3}
    assert A.from_json(A(1, 2).to_json()) == A(1, 2)
    assert A.from_json(A(1, 2).to_json()).c == 3

    @dataclass
    class B:
        a: str


# Generated at 2022-06-21 11:06:06.178565
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-21 11:06:09.996321
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0
    # assert global_config._json_module == json

# Generated at 2022-06-21 11:06:18.361380
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class A:
        @dataclass_json(mm_field=fields.Int, exclude=Exclude.ALWAYS)
        class B:
            x: int

        @config(exclude=Exclude.ALWAYS)
        @dataclass_json()
        class C:
            y: int

    a = A.B(0)
    assert {"x": 0} == a.to_json()
    assert a == A.B.from_json("{}")

    a1 = A.C(0)
    assert {"y": 0} == a1.to_json()
    assert a1 == A.C.from_json("{}")

# Generated at 2022-06-21 11:06:20.644517
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert Exclude.NEVER(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-21 11:06:22.320348
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER('') == False
    assert Exclude.ALWAYS('') == True

# Generated at 2022-06-21 11:06:37.936139
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(1) == True
	assert Exclude.ALWAYS(-1) == True
	assert Exclude.ALWAYS(0) == True
	assert Exclude.ALWAYS(0.0) == True
	assert Exclude.ALWAYS(False) == True
	assert Exclude.ALWAYS(True) == True
	assert Exclude.ALWAYS(None) == True
	assert Exclude.ALWAYS('hello') == True
	assert Exclude.ALWAYS(' ') == True
	assert Exclude.ALWAYS([1]) == True
	assert Exclude.ALWAYS(['hello']) == True


# Generated at 2022-06-21 11:06:39.239052
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('_') == True


# Generated at 2022-06-21 11:06:40.825400
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('example') is False


# Generated at 2022-06-21 11:06:42.531145
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude().ALWAYS(1) == True
    assert Exclude().NEVER(1) == False

# Generated at 2022-06-21 11:06:46.165565
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("Hello World!") == False
    assert Exclude.NEVER("1234") == False


# Generated at 2022-06-21 11:06:46.888778
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('anything')
    assert not Exclude.NEVER('anything')

# Generated at 2022-06-21 11:06:50.410625
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('_') == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-21 11:06:53.493729
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude = functools.partial(Exclude.ALWAYS, 'test')
    try:
        assert(exclude() == True)
    except:
        raise Exception("Exclude was not initialized correctly")

# Generated at 2022-06-21 11:06:54.799032
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("abc") == True


# Generated at 2022-06-21 11:06:56.319753
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def myfunc(_):
        return False
    assert Exclude.NEVER(myfunc) == myfunc


# Generated at 2022-06-21 11:07:14.654101
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Unit tests for function config

# Generated at 2022-06-21 11:07:16.016520
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)

    

# Generated at 2022-06-21 11:07:16.976224
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-21 11:07:18.250065
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:07:25.136421
# Unit test for function config
def test_config():
    class MyEnum(Enum):
        FOO = 1
        BAR = 2
        BAZ = 3

    @dataclass
    class MyClass:
        X: int = 0

        @config(mm_field=MarshmallowField())
        def Y(self):
            pass

        @config(encoder=int)
        def Z(self):
            pass

        def drop(self):
            pass

        @config(field_name='other_X',
                letter_case=lambda x: x.lower())
        def X(self):
            return self.X

        @config(undefined=Undefined.RAISE)
        def foo(self):
            pass

        @config(undefined=Undefined.EXCLUDE)
        def bar(self):
            pass


# Generated at 2022-06-21 11:07:26.559220
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:07:31.589135
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(0.001) == True
    assert Exclude.ALWAYS("Hello World!") == True


# Generated at 2022-06-21 11:07:33.274908
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-21 11:07:39.236448
# Unit test for function config
def test_config():
    # Test invalid undefined parameters
    with pytest.raises(UndefinedParameterError):
        config(undefined="bad")

    # Test valid undefined parameters
    for permitted_undefined in Undefined:
        permitted_undefined_string = permitted_undefined.name

        config(undefined=permitted_undefined)
        config(undefined=permitted_undefined_string)

# Generated at 2022-06-21 11:07:41.062951
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-21 11:08:17.245909
# Unit test for function config
def test_config():
    assert config(encoder=lambda x:x)
    assert config(decoder=lambda x:x)
    assert config(mm_field=MarshmallowField())
    assert config(letter_case=lambda x:x)
    assert config(undefined=Undefined.RAISE)
    assert config(undefined='raise')
    assert config(exclude=lambda x: x)
    assert config(field_name='a')
    try:
        assert config(undefined='a')
    except Exception as e:
        assert type(e) is UndefinedParameterError


# Generated at 2022-06-21 11:08:20.946775
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:08:23.390330
# Unit test for constructor of class Exclude
def test_Exclude():
    # case 1: ALWAYS
    assert Exclude.ALWAYS(10) == True
    # case 2: NEVER
    assert Exclude.NEVER(10) == False

# Generated at 2022-06-21 11:08:34.517212
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field

    @dataclass
    class S:
        i: int = field(metadata=config(encoder=lambda a: a+1,
                                        decoder=lambda a: a-1,
                                        exclude=lambda a, b: True,
                                        mm_field=1,
                                        field_name="j",
                                        undefined=Undefined.EXCLUDE))

    @dataclass
    class C:
        k: str = field(metadata=config(letter_case=lambda a: a+"_"))

    @dataclass
    class D:
        s: S
        c: C


# Generated at 2022-06-21 11:08:40.288846
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    f = Exclude.NEVER
    assert f(()) is False
    assert f({"a": 1}) is False
    assert f({"a": "b"}) is False
    assert f(["a"]) is False
    assert f("123") is False
    assert f(123) is False
    assert f(1.23) is False



# Generated at 2022-06-21 11:08:48.613925
# Unit test for function config
def test_config():
    cls_exclude_all = config(exclude=Exclude.ALWAYS)
    assert cls_exclude_all
    assert cls_exclude_all['dataclasses_json']['exclude'] == Exclude.ALWAYS

    cls_undef_fail = config(undefined=Undefined.EXCLUDE)
    assert cls_undef_fail
    assert cls_undef_fail['dataclasses_json']['undefined'] == Undefined.EXCLUDE

# TODO: #180
# def disable_warnings():
#     global_config.disable_warnings = True
#
#
# def default_json_module():
#     global_config.json_module = json

# Generated at 2022-06-21 11:08:54.410456
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    _str = "test_str"
    _list = ["test_str_1", "test_str_2"]
    _dict = {"key1": "test_str_1", "key2": "test_str_2"}

    assert Exclude.NEVER(_str) == False
    assert Exclude.NEVER(_list) == False
    assert Exclude.NEVER(_dict) == False


# Generated at 2022-06-21 11:08:56.045616
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-21 11:08:57.251196
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:09:03.746677
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("\n###### Test NEVER of class Exclude : ######\n")

    fct = Exclude.NEVER

    print("fct('hello') = ", fct('hello'))
    print("fct(1) = ", fct(1))
    print("fct([]) = ", fct([]))
    print("fct(None) = ", fct(None))



# Generated at 2022-06-21 11:10:05.532744
# Unit test for constructor of class Exclude
def test_Exclude():
    assert not Exclude.ALWAYS(object())
    assert not Exclude.NEVER(object())



# Generated at 2022-06-21 11:10:14.828094
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class Blah:
        def __init__(self):
            self.toto = None

    class BlahEncoder:
        def default(self, obj):
            return {"toto": obj.toto}

    class BlahDecoder:
        def __call__(self, value):
            b = Blah()
            b.toto = value["toto"]
            return b

    class BlahField(MarshmallowField):
        pass

    @dataclasses.dataclass
    class Foo:
        blah: Blah
        bar: int

    expected_foo_dict = {"bar": 1, "blah": {"toto": 2}}


# Generated at 2022-06-21 11:10:16.618177
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_object = Exclude()
    res = test_object.NEVER("You can't see me!")
    assert res == False

# Generated at 2022-06-21 11:10:17.795390
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config
    global_config.mm_fields["test"] = MarshmallowField()

# Generated at 2022-06-21 11:10:19.432541
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, Callable)
    assert isinstance(Exclude.NEVER, Callable)

# Generated at 2022-06-21 11:10:20.670120
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-21 11:10:24.660188
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Global variables
    assert isinstance(global_config, _GlobalConfig)
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)
    # assert isinstance(global_config._json_module, json)

if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-21 11:10:31.336708
# Unit test for function config
def test_config():
    @dataclass
    @config(
        encoder=lambda obj: 'encoded',
        decoder=lambda obj: 'decoded',
        mm_field='mm_field',
        field_name='field_name',
        letter_case=lambda name: "modified_" + name,
        undefined=Undefined.EXCLUDE,
        exclude=Exclude.NEVER
    )
    class MyDataClass:
        pass


# Generated at 2022-06-21 11:10:35.136534
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert type(config.encoders) == dict
    assert type(config.decoders) == dict
    assert type(config.mm_fields) == dict


# Generated at 2022-06-21 11:10:41.284181
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders[int] = None
    global_config.decoders[int] = None
    global_config.mm_fields[int] = None
    if global_config.encoders[int] is not None:
        assert 0
    if global_config.decoders[int] is not None:
        assert 0
    if global_config.mm_fields[int] is not None:
        assert 0
#


# Generated at 2022-06-21 11:13:00.155809
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True



# Generated at 2022-06-21 11:13:02.832016
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g1 = _GlobalConfig()
    assert g1.encoders == {}
    assert g1.decoders == {}


# Generated at 2022-06-21 11:13:05.625607
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}


# Generated at 2022-06-21 11:13:07.380078
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Testing method NEVER of class Exclude")
    assert Exclude.NEVER("Some") == False


# Generated at 2022-06-21 11:13:09.010087
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(1) is False



# Generated at 2022-06-21 11:13:20.541927
# Unit test for function config
def test_config():
    #No configuration
    assert config() == {'dataclasses_json': {}}

    #Only the metadata is set
    assert config(metadata={'key1': 'value1'}) == {'key1': 'value1', 'dataclasses_json': {}}

    #encoder and metadata are set

# Generated at 2022-06-21 11:13:26.025608
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    fN = Exclude.NEVER

    assert fN(1) == False, "for input: 1, method NEVER should return:" + str(fN(1))
    assert fN(2) == False, "for input: 2, method NEVER should return:" + str(fN(2))
    assert fN(3) == False, "for input: 3, method NEVER should return:" + str(fN(3))

    assert fN("a") == False, "for input: a, method NEVER should return:" + str(fN("a"))
    assert fN("b") == False, "for input: b, method NEVER should return:" + str(fN("b"))
    assert fN("c") == False, "for input: c, method NEVER should return:" + str(fN("c"))

    assert fN(None) == False

# Generated at 2022-06-21 11:13:29.370118
# Unit test for constructor of class Exclude
def test_Exclude():
    ex = Exclude()
    assert ex.ALWAYS(True) == True
    assert ex.ALWAYS(False) == True
    assert ex.NEVER(True) == False
    assert ex.NEVER(False) == False

# Generated at 2022-06-21 11:13:35.906320
# Unit test for constructor of class Exclude
def test_Exclude():
	assert(Exclude.ALWAYS(1) == True)
	assert(Exclude.ALWAYS(False) == True)
	assert(Exclude.ALWAYS(True) == True)
	assert(Exclude.ALWAYS(None) == True)
	assert(Exclude.NEVER(1) == False)
	assert(Exclude.NEVER(False) == False)
	assert(Exclude.NEVER(True) == False)
	assert(Exclude.NEVER(None) == False)

# Generated at 2022-06-21 11:13:36.527172
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(5))
