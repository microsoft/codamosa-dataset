

# Generated at 2022-06-21 11:04:32.350791
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def func(a):
        return a

    system_under_test = Exclude.ALWAYS
    assert system_under_test(func) == True

# Generated at 2022-06-21 11:04:35.662655
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(3.5) == False

# Generated at 2022-06-21 11:04:42.364214
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined

    @dataclass()
    class P:
        x: int
        y: int

    @dataclass()
    class C(P):
        pass

    C.__init__.__annotations__['z'] = int


    assert not config()
    assert config() == {}
    assert config(exclude=lambda f: f == 'x') == \
           {'dataclasses_json': {'exclude': lambda f: f == 'x'}}

# Generated at 2022-06-21 11:04:45.859032
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:04:47.916837
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:04:50.259122
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-21 11:04:54.620975
# Unit test for constructor of class Exclude
def test_Exclude():
    assert id(Exclude.NEVER) == id(lambda _: False)
    assert id(Exclude.ALWAYS) == id(lambda _: True)
    assert Exclude.NEVER("anything") is False
    assert Exclude.ALWAYS("anything") is True


# Generated at 2022-06-21 11:04:56.329231
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude.ALWAYS(None)
    Exclude.NEVER(None)

# Generated at 2022-06-21 11:04:58.689556
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (Exclude.ALWAYS.__name__ == "<lambda>")
    assert (Exclude.NEVER.__name__ == "<lambda>")
    assert (Exclude.__name__ == "Exclude")

# Generated at 2022-06-21 11:05:06.282591
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([0])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({'a':'b'})

# Generated at 2022-06-21 11:05:09.947266
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-21 11:05:10.851842
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(_GlobalConfig().encoders)

# Generated at 2022-06-21 11:05:16.024164
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (Exclude.ALWAYS(Exclude.ALWAYS) == True)
    assert (Exclude.NEVER(Exclude.NEVER) == True)
    assert (Exclude.ALWAYS(Exclude.NEVER) == True)
    assert (Exclude.NEVER(Exclude.ALWAYS) == False)


# Generated at 2022-06-21 11:05:20.465344
# Unit test for function config
def test_config():
    import pytest
    from dataclasses_json.undefined import Undefined


# Generated at 2022-06-21 11:05:23.201829
# Unit test for constructor of class Exclude
def test_Exclude():
    # Confirm valid Exclude initial conditions
    assert Exclude.ALWAYS == (lambda _: True)
    assert Exclude.NEVER == (lambda _: False)
    print("#passed test_Exclude")


# Generated at 2022-06-21 11:05:23.730007
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig(): 
    global _GlobalConfig

# Generated at 2022-06-21 11:05:31.120285
# Unit test for function config
def test_config():
    import pytest
    from dataclasses import dataclass
    from typing import Union

    @dataclass
    class Base:
        a: Union[str, int]

    @config(field_name='x', encoder=lambda x: float(x))
    @dataclass
    class Child(Base):
        b: int = 2

    assert Child.__dataclass_fields__['a'].metadata == {
        'dataclasses_json': {
            'encoder': lambda x: float(x),
            'field_name': 'x',
            'undefined': Undefined.EXCLUDE,
            'letter_case': 'x'
        }
    }

# Generated at 2022-06-21 11:05:33.312319
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS.__qualname__ == '<lambda>'
    assert Exclude.NEVER.__qualname__ == '<lambda>'


# Generated at 2022-06-21 11:05:35.154228
# Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-21 11:05:36.870120
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    class TestConfig:
        pass

    TestConfig = config(TestConfig)
    assert isinstance(TestConfig['dataclasses_json'], dict)

# Generated at 2022-06-21 11:05:44.302784
# Unit test for function config
def test_config():
    @dataclass
    @config(field_name="field1")
    class TestConfig:
        field: str = "field"

    assert TestConfig.__dataclass_json__["field_name"]("field") == "field1"

# Generated at 2022-06-21 11:05:46.697808
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-21 11:05:48.500329
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert isinstance(Exclude.NEVER, Callable)
    assert Exclude.NEVER('test')

# Generated at 2022-06-21 11:05:49.418342
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()

# Generated at 2022-06-21 11:05:51.475459
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('A') == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:05:52.084768
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert isinstance(gc, _GlobalConfig)

# Generated at 2022-06-21 11:05:55.495070
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-21 11:05:57.198449
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(4) == True
    assert Exclude.NEVER(4) == False


# Generated at 2022-06-21 11:05:59.166115
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)


# Generated at 2022-06-21 11:06:01.243876
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("field")
    assert Exclude.ALWAYS("field")


# Generated at 2022-06-21 11:06:10.043566
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:06:10.995662
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    pass


# Generated at 2022-06-21 11:06:12.818231
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Test:
        a: int

    assert Exclude.NEVER(Test)



# Generated at 2022-06-21 11:06:21.519137
# Unit test for function config
def test_config():
    from dataclasses_json.undefined import EXCLUDE, EXCEPTION, IGNORE, USE_DEFAULT
    T = TypeVar('T')
    def f(x:T) -> T:
        return x

    # check that all the values in _GlobalConfig get set
    assert config(encoder=f, decoder=f, mm_field=f, letter_case=f, undefined=EXCLUDE) == {'dataclasses_json': {'encoder': f, 'decoder': f, 'mm_field': f, 'letter_case': f, 'undefined': EXCLUDE}}

# Generated at 2022-06-21 11:06:32.939429
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses import dataclass
    @config(mm_field=fields.String(), field_name='foo')
    @dataclass
    class Test:
        bar = 'bar'

    assert Test.__dataclass_json__["mm_field"] == fields.String()
    assert Test.__dataclass_json__["field_name"] == 'foo'
    # TODO: there is no getter for letter_case, so we can't predict the result of this
    # assert Test.letter_case == 'foo'
    assert Test.__dataclass_json__["undefined"] == Undefined.EXCLUDE


# Generated at 2022-06-21 11:06:37.602721
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields, Schema
    from marshmallow.validate import OneOf


# Generated at 2022-06-21 11:06:42.044011
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print('Test for method NEVER of class Exclude: ')
    @dataclass
    @config(exclude=Exclude.NEVER)
    class Class1:
        field1: int
        field2: float

    c1=Class1(2,4)
    print(c1.json())

    c1.field2=5
    print(c1.json())


# Generated at 2022-06-21 11:06:49.408767
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS("a random string")
    assert Exclude.ALWAYS("another random string")
    assert Exclude.ALWAYS("a" or "b")
    assert Exclude.ALWAYS("b" or "c")
    assert Exclude.ALWAYS("c" or "d")


# Generated at 2022-06-21 11:06:54.661783
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders[type] = str
    global_config.decoders[type] = str
    global_config.mm_fields[dict] = MarshmallowField
    assert global_config.encoders.keys() == {type}
    assert global_config.decoders.keys() == {type}
    assert global_config.mm_fields.keys() == {dict}


# Generated at 2022-06-21 11:07:04.714890
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config as _config

    @dataclass_json
    @dataclass
    class Person:
        name: str
    
    assert _config(metadata=Person.__dict__) == {}
    assert _config(Person.__dict__, encoder = 1) == {
        'dataclasses_json': {'encoder': 1}
    }
    assert _config(Person.__dict__, field_name = '', letter_case = str.capitalize) == {
        'dataclasses_json': {
            'letter_case': str.capitalize
        }
    }

# Generated at 2022-06-21 11:07:21.749588
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:07:24.549323
# Unit test for constructor of class Exclude
def test_Exclude():
    assert repr(Exclude.NEVER) == '<function Exclude.NEVER at 0x105e8f7b8>'


# Generated at 2022-06-21 11:07:36.769192
# Unit test for function config
def test_config():
    import marshmallow_dataclass

    # Case no config, return default dataclasses_json config
    @dataclass
    class Config0:
        f0: str
        f1: int = 1


# Generated at 2022-06-21 11:07:37.737951
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))

# Generated at 2022-06-21 11:07:39.548855
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-21 11:07:40.965938
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False



# Generated at 2022-06-21 11:07:42.694825
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("") is True
    assert Exclude.NEVER("") is False


# Generated at 2022-06-21 11:07:49.381377
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('string')
    assert Exclude.ALWAYS([1,2,3,4])
    assert Exclude.ALWAYS(('a','b','c','d'))
    assert Exclude.ALWAYS({'key1':1, 'key2':2})
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS({})


# Generated at 2022-06-21 11:07:51.306519
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-21 11:07:55.161832
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    type(config.encoders) == dict
    type(config.decoders) == dict
    type(config.mm_fields) == dict


# Generated at 2022-06-21 11:08:26.427946
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:08:28.272632
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True

# Generated at 2022-06-21 11:08:30.214805
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(2) == False



# Generated at 2022-06-21 11:08:32.774604
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert not global_config.encoders
    assert not global_config.decoders
    assert not global_config.mm_fields

# Generated at 2022-06-21 11:08:34.174845
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False



# Generated at 2022-06-21 11:08:37.504130
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    assert config._json_module == json

# Generated at 2022-06-21 11:08:39.762608
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude()
    assert x.NEVER("test") == False


# Generated at 2022-06-21 11:08:42.792913
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

if __name__ == "__main__":
    test_Exclude()
    print("Success!")

# Generated at 2022-06-21 11:08:43.859390
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)

# Generated at 2022-06-21 11:08:46.273934
# Unit test for constructor of class Exclude
def test_Exclude():
    assert type(Exclude.ALWAYS) == type(lambda x: x)
    assert type(Exclude.NEVER) == type(lambda x: x)

# Generated at 2022-06-21 11:09:48.756664
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)

# Generated at 2022-06-21 11:09:55.083955
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # create new instance of _GlobalConfig
    config = _GlobalConfig()
    # test if encoders is a Dict
    assert isinstance(config.encoders, Dict)
    # test if decoders is a Dict
    assert isinstance(config.decoders, Dict)
    # test if mm_fields is a Dict
    assert isinstance(config.mm_fields, Dict)



# Generated at 2022-06-21 11:09:57.481923
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER('a') is False
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER([1,2,3]) is False
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-21 11:09:59.625318
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:10:03.761847
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({'age':12}) == True
    assert Exclude.ALWAYS({'age':12, 'name':"Pedro"}) == True


# Generated at 2022-06-21 11:10:13.097598
# Unit test for function config
def test_config():
    from marshmallow import fields as ma_fields
    from typing import NamedTuple
    class EncoderTester(NamedTuple):
        before: int
        after: str

    class DecoderTester(NamedTuple):
        before: str
        after: int

    class MMFieldTester(NamedTuple):
        before: int
        after: ma_fields.Integer

    class LetterCaseTester(NamedTuple):
        before: int
        after: str

    class UndefinedTester(NamedTuple):
        before: Undefined
        after: Undefined

    class ExcludeTester(NamedTuple):
        before: Callable
        after: Callable


# Generated at 2022-06-21 11:10:14.867337
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-21 11:10:17.832706
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    """Test GlobalConfig"""

    global_conf = _GlobalConfig()
    assert global_conf is not None
    assert global_conf.encoders is not None
    assert global_conf.decoders is not None
    assert global_conf.mm_fields is not None



# Generated at 2022-06-21 11:10:22.315912
# Unit test for function config
def test_config():
    # type: () -> None
    """Test for `config` function"""

    from dataclasses_json import DataClassJsonMixin, config

    @config(mm_field=True)
    class Klass(DataClassJsonMixin):
        field_1: str

    assert Klass.__dataclass_fields__['field_1'].metadata['dataclasses_json']['mm_field']

# Generated at 2022-06-21 11:10:23.202997
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-21 11:12:43.666746
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-21 11:12:52.011961
# Unit test for function config
def test_config():
    # Test undefined options
    class Test:
        def __init__(self):
            self.x = None
            self.y = None
            self.z = None

    try:
        dataclasses.dataclass(frozen=True)(Test,
                                           metadata={'dataclasses_json': {
                                               'undefined': "Not an option"}})
        assert False
    except UndefinedParameterError:
        pass

    try:
        dataclasses.dataclass(frozen=True)(Test,
                                           metadata={'dataclasses_json': {
                                               'undefined': Undefined.RAISE}})
    except Exception:
        assert False

    # Test exclusion

# Generated at 2022-06-21 11:12:53.987022
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is True
    assert Exclude.NEVER is False
    assert Exclude.NEVER(True) is False
    assert Exclude.ALWAYS(True) is True

# Generated at 2022-06-21 11:12:55.116593
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-21 11:12:56.351441
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-21 11:13:08.646176
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('f') == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER((1,2,3)) == False
    assert Exclude.NEVER((1,2,3,4)) == False
    assert Exclude.NEVER((1,2,3,4,5)) == False
    assert Exclude.NEVER((1,2,3,4,5,6)) == False
    assert Exclude.NEVER((1,2,3,4,5,6,7)) == False
    assert Exclude.NEVER([1,2]) == False
    assert Ex

# Generated at 2022-06-21 11:13:13.760394
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == dict()
    assert global_config.decoders == dict()
    assert global_config.mm_fields == dict()
    assert global_config.json_module == json


# Generated at 2022-06-21 11:13:19.065796
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c1 = _GlobalConfig()
    assert type(c1.encoders) == dict
    c2 = _GlobalConfig()
    assert type(c2.encoders) == dict
    assert c1.encoders == c2.encoders
    assert c1.decoders == c2.decoders
    assert c1.mm_fields == c2.mm_fields


# Generated at 2022-06-21 11:13:25.311097
# Unit test for constructor of class Exclude
def test_Exclude():
    def is_red(color):
        return color == "red"
    def is_pink(color):
        return color == "pink"
    def is_raspberry(color):
        return color == "raspberry"
    #Test Always
    assert Exclude.ALWAYS("red") == True
    assert Exclude.ALWAYS("pink") == True
    #Test NEVER
    assert Exclude.NEVER("red") == False
    assert Exclude.NEVER("pink") == False
    #Test is_pink and is_red
    assert (is_pink("pink") and is_red("pink")) == False
    assert (is_pink("red") and is_red("red")) == True
    #Test is_raspberry or is_pink and is_red

# Generated at 2022-06-21 11:13:34.574971
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class Data:
        a: int
        b: int

    # Define metadata to check if it is passed
    @config(field_name='f', exclude=Exclude.ALWAYS)
    class ExcludedData(Data):
        c: int

    # Define metadata to check if it is passed
    @config(field_name='f', exclude=Exclude.NEVER)
    class IncludedData(Data):
        c: int

    # Check if metadata is merged properly
    assert excluded.config.field_name == 'f' and excluded.config.exclude == Exclude.ALWAYS
    assert included.config.field_name == 'f' and included.config.exclude == Exclude.NEVER