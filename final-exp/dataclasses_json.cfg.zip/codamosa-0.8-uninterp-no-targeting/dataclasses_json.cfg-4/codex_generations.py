

# Generated at 2022-06-21 11:04:32.696647
# Unit test for constructor of class Exclude
def test_Exclude():
	assert(Exclude.ALWAYS(1) == True)
	assert(Exclude.NEVER(2) == False)
#test_Exclude()


# Generated at 2022-06-21 11:04:37.227346
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert global_config_.encoders == dict()
    assert global_config_.decoders == dict()
    assert global_config_.mm_fields == dict()
    # assert global_config_.json_module == json



# Generated at 2022-06-21 11:04:40.268440
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS('test') == True
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER('test') == False


# Generated at 2022-06-21 11:04:52.616524
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field, asdict
    from dataclasses_json import config
    from marshmallow import Schema, fields

    schema = Schema()

    def eq(x, y, *, msg=None):
        if x != y:
            raise AssertionError(msg)

    @dataclass
    class A:
        x: int = field(metadata=config(mm_field=fields.Int()))
        y: int = field(metadata=config(mm_field=fields.Int()))
        z: int = field(metadata=config(field_name='Z'))

    a = A(x=1, y=2)
    result = schema.dump(A(1, 2))
    eq(result, {'x': 1, 'y': 2}, msg="Marshmallow config should work")



# Generated at 2022-06-21 11:04:56.830708
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert type(global_config.encoders) == dict
    assert type(global_config.decoders) == dict
    assert type(global_config.mm_fields) == dict
    # assert global_config._json_module == json


# Generated at 2022-06-21 11:04:58.034799
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-21 11:05:07.941719
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(()) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS({}) is True
    assert Exclude.ALWAYS({'a': 1, 'b': 2}) is True
    assert Exclude.ALWAYS({'a': [1, 2, 3]}) is True
    assert Exclude.ALWAYS('') is True
    assert Exclude.ALWAYS('a') is True
    assert Exclude.ALWAYS(None) is True



# Generated at 2022-06-21 11:05:17.776078
# Unit test for function config
def test_config():
    from typing import get_type_hints

    from marshmallow.fields import String as MarshmallowString

    @config(encoder=str,
            letter_case=str.lower,
            undefined=Undefined.EXCLUDE,
            field_name='a',
            exclude=Exclude.ALWAYS)
    class A:
        x: int

    assert get_type_hints(A.__init__)['x'] == int

    hints = get_type_hints(A, locals())
    assert hints['x'] == str

    assert A.__annotations__['x'] == int

    assert isinstance(A.__dict__['x'], MarshmallowString)

    assert A.__dict__['x'].attribute == 'a'

    assert A.__dict__['x'].exclude is Exclude.ALWAYS


# Generated at 2022-06-21 11:05:19.239631
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}

# Generated at 2022-06-21 11:05:27.863526
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.mm_config import MmConfig
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Example(DataClassJsonMixin):
        x: int = 0
        y: float = 0

    d = {
        '@type': 'Example',
        'x': 1,
        'y': 2
    }

    # using global config
    # json string at first
    global_config.encoders[Example] = lambda x: {
        '@type': type(x).__name__,
        'x': x.x,
        'y': x.y,
    }
    global_config.decoders[Example] = lambda d: Example(**d)
    assert Example

# Generated at 2022-06-21 11:05:32.257814
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (Exclude.ALWAYS(0) == True), "Error, the function returned an invalid result"
    assert (Exclude.NEVER(0) == False), "Error, the function returned an invalid result"

# Generated at 2022-06-21 11:05:37.785971
# Unit test for function config
def test_config():
    from marshmallow import fields as mm_fields

    assert config(exclude=Exclude.ALWAYS) == {
        'dataclasses_json': {
            'exclude': Exclude.ALWAYS
        }
    }

    class C:
        @config(encoder=float, decoder=int, mm_field=mm_fields.Str(),
                field_name='c', exclude=Exclude.NEVER)
        def __init__(self, c):
            self.c = c

    assert C(1.1).c == 1.1


# Generated at 2022-06-21 11:05:40.690621
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert not Exclude.NEVER

# Generated at 2022-06-21 11:05:43.611744
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c=_GlobalConfig()

    assert(c.encoders == {})
    assert(c.decoders == {})
    assert(c.mm_fields == {})

# Generated at 2022-06-21 11:05:50.224921
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    x1 = _GlobalConfig()
    x2 = _GlobalConfig()
    x3 = _GlobalConfig()

    assert x1.encoders == {}
    assert x1.decoders == {}
    assert x1.mm_fields == {}

    assert x2.encoders == {}
    assert x2.decoders == {}
    assert x2.mm_fields == {}

    assert x3.encoders == {}
    assert x3.decoders == {}
    assert x3.mm_fields == {}


# Generated at 2022-06-21 11:05:51.661511
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("abc")


# Generated at 2022-06-21 11:05:58.366176
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    f = Exclude.ALWAYS
    assert f(0)
    assert f(1)
    assert f(2)
    assert f(3)
    assert f(4)
    assert f(999)
    assert f(100_000)
    assert f(-1)
    assert f(-2)
    assert f(-999)
    assert f(-100_000)


# Generated at 2022-06-21 11:06:01.086687
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('asda') == False


# Generated at 2022-06-21 11:06:03.933227
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) is True
    assert not Exclude.ALWAYS(False)
    assert not Exclude.NEVER(True)
    assert Exclude.NEVER(False) is False

# Generated at 2022-06-21 11:06:05.273545
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS(1) == True)


# Generated at 2022-06-21 11:06:11.038090
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert not Exclude.NEVER(True)
    assert not Exclude.NEVER(False)

# Generated at 2022-06-21 11:06:13.706414
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(None)
    assert not Exclude.NEVER(True)
    assert not Exclude.NEVER(False)


# Generated at 2022-06-21 11:06:15.046228
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") is True


# Generated at 2022-06-21 11:06:16.584944
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('toto') == False


# Generated at 2022-06-21 11:06:17.920710
# Unit test for function config
def test_config():
    exists = 'dataclasses_json' in config()
    assert exists


# Generated at 2022-06-21 11:06:20.262920
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER("hello")
    expected = False
    assert result == expected, "Expected False, but result was True."



# Generated at 2022-06-21 11:06:21.576469
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)



# Generated at 2022-06-21 11:06:23.235386
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS({}) is True
    assert Exclude.NEVER({}) is False


# Generated at 2022-06-21 11:06:34.978199
# Unit test for function config
def test_config():
    @dataclass
    class Foo:
        a: int = field(metadata=config(encoder=lambda x: x * 2))
        b: int = field(metadata=config(decoder=lambda x: x * 3))
        c: int = field(metadata=config(mm_field=MarshmallowField()))
        d: int = field(metadata=config(field_name="D"))
        e: int = field(metadata=config(letter_case=lambda x: x.upper()))
        f: int = field(metadata=config(undefined=Undefined.RAISE))
        g: int = field(metadata=config(undefined="RAISE"))
        h: int = field(metadata=config(exclude=Exclude.NEVER))

# Generated at 2022-06-21 11:06:39.620531
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # If not setting the value of class attribute, it will get a default value
    # So here encoders, decoders, mm_fields are all empty
    assert global_config.encoders=={}
    assert global_config.decoders=={}
    assert global_config.mm_fields=={}


# Generated at 2022-06-21 11:06:52.122397
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert global_config.mm_fields is not None
    assert global_config.mm_fields is not None
    assert isinstance(global_config.mm_fields, dict)
    assert global_config.encoders is not None
    assert global_config.mm_fields is not None
    assert isinstance(global_config.mm_fields, dict)
    assert global_config.decoders is not None
    assert global_config.mm_fields is not None
    assert isinstance(global_config.mm_fields, dict)
    assert not global_config.NEVER(False)
    assert not global_config.ALWAYS(False)
    assert global_config.NEVER('toto')
    assert global_config.ALWAYS('toto')
test_Exclude_NEVER()

# Generated at 2022-06-21 11:06:54.575726
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)

# Generated at 2022-06-21 11:07:00.147639
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    with ExtValue(Exclude.NEVER, True):
        assert Exclude.NEVER(10) == True
    with ExtValue(Exclude.NEVER, False):
        assert Exclude.NEVER(20) == False
    with ExtValue(Exclude.NEVER, 1):
        assert Exclude.NEVER(30) == 1
    with ExtValue(Exclude.NEVER, 0):
        assert Exclude.NEVER(40) == 0


# Generated at 2022-06-21 11:07:04.431247
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert(isinstance(global_config.encoders, dict))
    assert(isinstance(global_config.decoders, dict))
    assert(isinstance(global_config.mm_fields, dict))


# Generated at 2022-06-21 11:07:16.604790
# Unit test for function config
def test_config():
    import marshmallow
    from marshmallow import Schema, fields

    class Example(fields.Field):
        def _serialize(self, value, attr, obj):
            return 42

        def _deserialize(self, value, attr, data):
            return 'not 42'

    # Test config

    @dataclass
    @config(encoder=lambda obj: 42)
    @config(decoder=lambda obj: 'not 42')
    class UndefinedConfig:
        pass

    @dataclass
    @config(undefined=Undefined.RAISE)
    class UndefinedConfigRaise:
        pass

    @dataclass
    @config(undefined=Undefined.EXCLUDE)
    class UndefinedConfigExclude:
        pass


# Generated at 2022-06-21 11:07:23.733074
# Unit test for function config
def test_config():

    # Testing for letter_case parameter
    @dataclass
    class WithLetterCase:
        a: str

    assert config(field_name="A", letter_case=str.lower).get('dataclasses_json').get('letter_case') == str.lower
    assert config(field_name="A", letter_case=str.lower)(WithLetterCase) == "a"

    # Testing for undefined parameter
    @dataclass
    class WithUndefined:
        a: str

    assert config(field_name="A", undefined=Undefined.RAISE).get('dataclasses_json').get('undefined') == Undefined.RAISE

# I did not wrote a unit test for the exclude parameter because I could not figure
# how to test it efficiently

# Generated at 2022-06-21 11:07:25.555756
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) is True
    assert Exclude.NEVER(3) is False

# Generated at 2022-06-21 11:07:37.831379
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    @dataclass
    class Config:
        field1: int = 0
        field2: int = 0
        field3: int = 0
        field4: int = 0
    default = Config()
    field_name_case = config(field_name='ABC')
    custom_case = config(letter_case=lambda s: s.lower())
    assert default.field1 == 0
    assert default.field2 == 0
    assert default.field3 == 0
    assert default.field4 == 0
    assert field_name_case['dataclasses_json'] == {'field_name': 'ABC'}
    assert custom_case['dataclasses_json'] == {'letter_case': custom_case['dataclasses_json']['letter_case']}

# Generated at 2022-06-21 11:07:38.463807
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") is True


# Generated at 2022-06-21 11:07:39.871224
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:07:57.184814
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-21 11:08:00.174536
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    e = Exclude.NEVER
    assert e(1) == False
    assert e(2) == False
    assert e(None) == False



# Generated at 2022-06-21 11:08:03.667090
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, Callable), 'Exclude.ALWAYS is not callable'
    assert isinstance(Exclude.NEVER, Callable), 'Exclude.NEVER is not callable'

# Generated at 2022-06-21 11:08:07.153264
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert 'encoders' in vars(_GlobalConfig())
    assert 'decoders' in vars(_GlobalConfig())
    assert 'mm_fields' in vars(_GlobalConfig())
    # assert '_json_module' in vars(_GlobalConfig())
    # TODO: add json_module in test__GlobalConfig()


# Generated at 2022-06-21 11:08:08.201426
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-21 11:08:14.716604
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0.0)
    assert Exclude.ALWAYS(float('nan'))
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-21 11:08:19.440212
# Unit test for function config
def test_config():
    # Test that an error is thrown when an invalid action is specified
    try:
        config(undefined="test")
    except UndefinedParameterError as e:
        pass
    else:
        assert False

    # Test that a valid action is found
    assert config(undefined="ignore")

# Generated at 2022-06-21 11:08:20.854058
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('this-is-a-test') == True

# Generated at 2022-06-21 11:08:27.642782
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(4)
    assert Exclude.ALWAYS((4,5))
    assert Exclude.ALWAYS([4,5])
    assert Exclude.ALWAYS({4,5})
    assert Exclude.ALWAYS({4:5})
    assert Exclude.ALWAYS('''4''')
    assert Exclude.ALWAYS('')


# Generated at 2022-06-21 11:08:31.925114
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # expected result: True
    result = Exclude.ALWAYS(0)
    assert result == True, "Error in method ALWAYS"

    # expected result: True
    result = Exclude.ALWAYS(2)
    assert result == True, "Error in method ALWAYS"


# Generated at 2022-06-21 11:08:49.578982
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER



# Generated at 2022-06-21 11:09:00.291341
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined


    @dataclass
    class TestClass:
        integer: int = 0
        string: str = 'test'

    tc = TestClass(1)

    # TestClass
    assert Exclude.ALWAYS(TestClass) == True
    assert Exclude.ALWAYS(tc) == True
    # TestClass.string
    assert Exclude.ALWAYS(TestClass.string) == True
    assert Exclude.ALWAYS(tc.string) == True
    # TestClass.undefined
    assert Exclude.ALWAYS(TestClass.undefined) == True
    assert Exclude.ALWAYS(tc.undefined) == True
    # TestClass.Undefined.EXCLUDE

# Generated at 2022-06-21 11:09:10.406158
# Unit test for function config
def test_config():
    import pytest
    from dataclasses_json.undefined import UndefinedAction

    from dataclasses import dataclass

    @dataclass
    class MyClass:
        a: str
        b: int

    # test letter_case, undefined and field_name
    @dataclass
    class ConfigClass:
        dct: Dict = config(
            letter_case=lambda x : x.lower(),
            undefined=UndefinedAction.RAISE,
            field_name='dct'
        )

    config_class = ConfigClass()
    assert config_class.dct['letter_case'](None, 'dct') == 'dct'
    with pytest.raises(UndefinedParameterError):
        config_class.dct['undefined'](None, 'dct')()
    assert config_class.d

# Generated at 2022-06-21 11:09:11.835040
# Unit test for constructor of class Exclude
def test_Exclude():

    assert Exclude.ALWAYS(True) == True

# Generated at 2022-06-21 11:09:14.356133
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}



# Generated at 2022-06-21 11:09:22.253174
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    import pytest
    global_config = _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)

    with pytest.raises(AttributeError):
        global_config.encoders = {}
    with pytest.raises(AttributeError):
        global_config.decoders = {}
    with pytest.raises(AttributeError):
        global_config.mm_fields = {}

# Generated at 2022-06-21 11:09:23.392057
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-21 11:09:30.117122
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1234) == True
    assert Exclude.ALWAYS(1.234) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(object) == True
    assert Exclude.ALWAYS({1:1, 2:2}) == True
    assert Exclude.ALWAYS([1,2,3]) == True


# Generated at 2022-06-21 11:09:36.265162
# Unit test for function config
def test_config():
    """
    Checks that config for class metadata is correct
    """
    from dataclasses import dataclass, fields
    from dataclasses_json import config

    @config()
    @dataclass
    class C:
        x: int = 2
        y: int = 3

    for field in fields(C):
        metadata = field.metadata["dataclasses_json"]
        # By default, 'undefined' is excluded
        assert not metadata["undefined"]
        # By default, fields are included
        assert not metadata["exclude"](field.name, field)

# Generated at 2022-06-21 11:09:40.225511
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()
    assert type(obj.encoders) == dict
    assert type(obj.decoders) == dict
    assert type(obj.mm_fields) == dict
    # assert type(obj.json_module) == bool

# Generated at 2022-06-21 11:10:17.678253
# Unit test for constructor of class Exclude
def test_Exclude():
    # Test whether the constant object is correctly defined

    # When input is ALWAYS
    assert Exclude.ALWAYS
    # When input is NEVER
    assert not Exclude.NEVER
    print("test_Exclude passed")

test_Exclude()

# Generated at 2022-06-21 11:10:25.728439
# Unit test for function config
def test_config():
    from marshmallow.fields import Str
    from dataclasses import dataclass

    @dataclass
    class Car:
        make: str
        model: str = field(metadata=config(
            metadata={'test': {'foo': 'bar'}},
            encoder=str,
            decoder=str,
            mm_field=Str(validate=lambda _: True),
            letter_case=str.lower,
            undefined=Undefined.RAISE,
            field_name='new_field_name',
            exclude=Exclude.ALWAYS,
        ))


# Generated at 2022-06-21 11:10:28.027326
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.decoders == {}
    assert g.encoders == {}
    assert g.mm_fields == {}

# Generated at 2022-06-21 11:10:29.199992
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER
    print(type(x))



# Generated at 2022-06-21 11:10:30.848317
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-21 11:10:34.257192
# Unit test for constructor of class Exclude
def test_Exclude():
    exo = Exclude()

# Generated at 2022-06-21 11:10:38.003743
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert global_config_.encoders == {}
    assert global_config_.decoders == {}
    assert global_config_.mm_fields == {}
    #assert global_config_.json_module is json

# Generated at 2022-06-21 11:10:38.581882
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-21 11:10:41.283344
# Unit test for constructor of class Exclude

# Generated at 2022-06-21 11:10:42.465579
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    res = Exclude.NEVER(42)
    assert res == False



# Generated at 2022-06-21 11:11:57.757570
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-21 11:12:01.643224
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def test_func(x: int) -> bool:
        if x == 1:
            return Exclude.ALWAYS(x)
        else:
            return Exclude.NEVER(x)
    assert test_func(1)
    assert not test_func(2)

# Generated at 2022-06-21 11:12:02.831588
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-21 11:12:04.629462
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(123)==True



# Generated at 2022-06-21 11:12:14.263906
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field, InitVar
    from dataclasses_json import dataclass_json, config, letter_case, Undefined

    @dataclass_json
    @dataclass
    class A:
        a: str = config(field_name="b", letter_case=letter_case.camel_case, undefined=Undefined.RAISE)
        b: str = config(field_name="c", letter_case=letter_case.lisp_case, undefined=Undefined.EXCLUDE)
        c: str = config(field_name="d", letter_case=letter_case.camel_case, undefined=Undefined.INCLUDE, metadata={"key": "value"})

# Generated at 2022-06-21 11:12:15.180659
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-21 11:12:19.992800
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # We didn't use pytest.mark.parametrize for this testcase for clarity
    # This testcase is to ensure that callable function ALWAYS will return
    # (True, True, True, True) if input is (None, 1, 'a', [1,2,3])
    result = list(map(Exclude.ALWAYS, [None, 1, 'a', [1, 2, 3]]))
    expected_result = [True, True, True, True]
    assert result == expected_result


# Generated at 2022-06-21 11:12:21.228439
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Unit tests for function config()

# Generated at 2022-06-21 11:12:22.048007
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    pass


# Generated at 2022-06-21 11:12:30.280894
# Unit test for function config
def test_config():
    from marshmallow import fields
    import dataclasses

    @dataclasses.dataclass
    @config(mm_field=fields.Field())
    class Klass:
        pass
    klass = Klass()
    assert klass.__dataclass_json__() == {'mm_field': None}

    @dataclasses.dataclass
    @config(mm_field=fields.Field(default='abc'))
    class Klass:
        pass
    klass = Klass()
    assert klass.__dataclass_json__() == {'mm_field': 'abc'}