

# Generated at 2022-06-21 11:04:31.922999
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Nothing") == True


# Generated at 2022-06-21 11:04:32.478704
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()

# Generated at 2022-06-21 11:04:35.069106
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)


# Generated at 2022-06-21 11:04:38.535994
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("hello") == False
    assert Exclude.NEVER(10.9) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-21 11:04:40.024358
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    some_value = "some value"
    assert(Exclude.ALWAYS(some_value))


# Generated at 2022-06-21 11:04:42.675393
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert hasattr(Exclude.NEVER,'__call__')
    assert Exclude.NEVER(Exclude.NEVER)


# Generated at 2022-06-21 11:04:44.519878
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:04:45.506203
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(Exclude)

# Generated at 2022-06-21 11:04:48.417432
# Unit test for constructor of class Exclude
def test_Exclude():
    import pytest
    exclude = Exclude
    assert exclude.ALWAYS(None)
    assert not exclude.NEVER(None)


# Generated at 2022-06-21 11:04:50.718754
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:04:52.866417
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-21 11:04:54.723092
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    never = Exclude.NEVER
    assert never(1) == False

# Generated at 2022-06-21 11:04:58.444813
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config._json_module == json


# Generated at 2022-06-21 11:05:04.010289
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import unittest
    from tests.test_config import Exclude_NEVER_TestCase
    unittest.TextTestRunner().run(
        unittest.TestLoader().loadTestsFromTestCase(Exclude_NEVER_TestCase))


# Generated at 2022-06-21 11:05:06.999038
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-21 11:05:08.412653
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    assert result == True


# Generated at 2022-06-21 11:05:10.190080
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    assert (e.ALWAYS(None))
    assert (e.NEVER(None) is False)
    return e

# Generated at 2022-06-21 11:05:12.463181
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-21 11:05:22.230412
# Unit test for function config
def test_config():
    import marshmallow
    class MyField(marshmallow.fields.Field):
        pass

    @config(encoder=lambda v: "encoded")
    @config(decoder=lambda v: "decoded")
    @config(mm_field=MyField())
    @config(letter_case=lambda s: s.upper())
    @config(field_name="field_name")
    @config(undefined="ERROR")
    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class MyClass:
        field: int


# Generated at 2022-06-21 11:05:24.631439
# Unit test for constructor of class Exclude
def test_Exclude():
    # Call function 'ALWAYS'
    assert Exclude.ALWAYS(3) == True
    
    # Call function 'NEVER'
    assert Exclude.NEVER(3) == False
    

# Generated at 2022-06-21 11:05:27.368609
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    e = Exclude()
    assert e.ALWAYS('arg')



# Generated at 2022-06-21 11:05:28.527692
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False;


# Generated at 2022-06-21 11:05:31.005842
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    # test done


# Generated at 2022-06-21 11:05:37.422239
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from marshmallow import fields as mm_fields

    @dataclasses.dataclass
    class Dummy:
        a: int

    config(encoder=int)
    assert issubclass(global_config.encoders[Dummy], int)

    config(decoder=int)
    assert issubclass(global_config.decoders[Dummy], int)

    config(mm_field=mm_fields.Integer())
    assert isinstance(global_config.mm_fields[Dummy], mm_fields.Integer)

# Generated at 2022-06-21 11:05:38.873783
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)

# Generated at 2022-06-21 11:05:48.065358
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('some string')
    assert Exclude.ALWAYS('some string with spaces')
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('\t')
    assert Exclude.ALWAYS(float('-inf'))
    assert Exclude.ALWAYS(float('inf'))
    assert Exclude.ALWAYS(float('NaN'))
    assert Exclude.ALWAYS(float('nan'))
    assert Exclude.ALWAYS(keep_going=True)


# Generated at 2022-06-21 11:05:52.109070
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    encoders_expected = {}
    decoders_expected = {}
    mm_fields_expected = {}
    assert global_config1.encoders == encoders_expected
    assert global_config1.decoders == decoders_expected
    assert global_config1.mm_fields == mm_fields_expected


# Generated at 2022-06-21 11:05:55.036495
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(_)
    assert not Exclude.NEVER(_)

# Generated at 2022-06-21 11:05:56.125335
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-21 11:05:57.800777
# Unit test for function config
def test_config():
    assert config(mm_field=True) == {'dataclasses_json': {'mm_field': True}}

# Generated at 2022-06-21 11:06:03.557251
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config, _GlobalConfig)

# Generated at 2022-06-21 11:06:13.296850
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field

    def upper(value):
        return value.upper()

    @dataclass
    class Example:
        f1: str = field(metadata=config(letter_case=upper))
        f2: int = field(metadata=config(field_name='field_2'))
        f3: object = field(metadata=config(exclude=Exclude.ALWAYS))
        f4: object = field(metadata=config(encoder=upper))
        f5: object = field(metadata=config(undefined='RAISE'))

    assert Example().__dataclass_fields__["f1"].metadata['dataclasses_json']['letter_case'] == upper

# Generated at 2022-06-21 11:06:17.214006
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('1') == True
    assert Exclude.ALWAYS((1,2,3)) == True
    assert Exclude.ALWAYS([1,2,3]) == True


# Generated at 2022-06-21 11:06:28.004434
# Unit test for function config
def test_config():
    """Testing the configuration of instanced types."""
    @dataclass
    class Person:
        name: str
        age: int
        children: Tuple["Person", ...]

    person = Person("Jane Doe", age=14, children=[Person("John Doe", age=5)])

    # TODO: should this be printed?
    # json_str = person.to_json(indent=2)
    # assert json_str == '{'
    #                 '"name": "Jane Doe", '
    #                 '"age": 14, '
    #                 '"children": [{'
    #                     '"name": "John Doe", '
    #                     '"age": 5, '
    #                     '"children": []'
    #                 '}]'
    #             '}'
    # print(json_str

# Generated at 2022-06-21 11:06:30.387552
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(312)


# Generated at 2022-06-21 11:06:33.880929
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    assert config._json_module == json



# Generated at 2022-06-21 11:06:42.986915
# Unit test for function config
def test_config():
    dp = dataclasses.dataclass()
    # letter_case
    assert dp.letter_case('field') == 'field'
    assert dp.letter_case('field', metadata=config(letter_case=lambda x: x.upper())) == 'FIELD'
    assert dp.letter_case('field', metadata=config(letter_case=lambda x: x.lower())) == 'field'
    assert dp.letter_case('field', metadata=config(letter_case=lambda x: 'elif')) == 'elif'
    # encoder
    assert dp.encoder(None) is None
    assert dp.encoder(None, metadata=config(encoder=lambda x: x + 1)) == 1

# Generated at 2022-06-21 11:06:45.019385
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-21 11:06:54.494342
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    import json
    import pytest
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin, config, Exclude, LetterCase

    @dataclass
    class Employee(DataClassJsonMixin):
        id: int = field(metadata=config(exclude=Exclude.ALWAYS))
        name: str
        title: str = field(metadata=config(exclude=Exclude.ALWAYS))
        is_full_time: bool = True

    obj = Employee(id=101, name='John Doe', title='Software Engineer')
    expected = '{"name": "John Doe", "is_full_time": true}'
    assert json.loads(obj.to_json()) == json.loads(expected)


# Generated at 2022-06-21 11:06:57.251552
# Unit test for function config
def test_config():
    """
    Test the config function
    """
    import pytest
    from dataclasses_json.config import Undefined, config

    with pytest.raises(UndefinedParameterError):
        config(undefined="NotValidAction")



# Generated at 2022-06-21 11:07:07.958067
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("toto") == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(["P", "a", "c", "k", "m", "a", "n"]) == False
    assert Exclude.NEVER({"a": 1, "b": 2}) == False
    assert Exclude.NEVER((1, 2, 3)) == False


# Generated at 2022-06-21 11:07:12.137058
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_lambda = Exclude.NEVER
    assert test_lambda(None) == False
    assert test_lambda(1) == False
    assert test_lambda("a") == False


# Generated at 2022-06-21 11:07:13.380697
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig



# Generated at 2022-06-21 11:07:15.443907
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, Callable)
    assert isinstance(Exclude.NEVER, Callable)

# Generated at 2022-06-21 11:07:23.500219
# Unit test for function config
def test_config():
    assert config(metadata={'a': 1}) == {'a': 1, 'dataclasses_json': {}}
    assert config(metadata={'dataclasses_json': {'a': 1}}, b=2) == {'dataclasses_json': {'a': 1}, 'b': 2}
    assert config(field_name='a') == {'dataclasses_json': {'field_name': 'a'}}
    assert config(metadata={'a': 1}, field_name='b') == {'a': 1, 'dataclasses_json': {'field_name': 'b'}}
    assert config(undefined='omit') == {'dataclasses_json': {'undefined': Undefined.OMIT}}

# Generated at 2022-06-21 11:07:26.068674
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('anything') == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-21 11:07:29.560772
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(Undefined.EXCLUDE)

    assert not Exclude.NEVER(Undefined.RAISE)
    assert not Exclude.NEVER(Undefined.INCLUDE)



# Generated at 2022-06-21 11:07:31.763287
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(_) for _ in range(100))


# Generated at 2022-06-21 11:07:36.409501
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(1.0) == True


# Generated at 2022-06-21 11:07:40.954399
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config, _GlobalConfig)
    assert isinstance(config.encoders, dict)
    assert isinstance(config.decoders, dict)
    assert isinstance(config.mm_fields, dict)
    # assert isinstance(config._json_module, json)



# Generated at 2022-06-21 11:07:57.597882
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    print("test__GlobalConfig completed")


# Generated at 2022-06-21 11:07:59.429580
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('whatever') == False


# Generated at 2022-06-21 11:08:00.875340
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test = Exclude.NEVER("test")
    assert not test

# Generated at 2022-06-21 11:08:06.946877
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c1 = _GlobalConfig()
    c2 = _GlobalConfig()
    assert c1 is not c2
    assert c1.encoders is not c2.encoders
    assert c1.encoders == c2.encoders
    assert c1.decoders is not c2.decoders
    assert c1.decoders == c2.decoders
    assert c1.mm_fields is not c2.mm_fields
    assert c1.mm_fields == c2.mm_fields

# Generated at 2022-06-21 11:08:15.631711
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a')
    assert Exclude.NEVER('b')
    assert Exclude.NEVER('c')
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(2)
    assert Exclude.NEVER(3)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER([1, 2, 3])
    assert Exclude.NEVER([])
    assert Exclude.NEVER([[1], [1, 2]])


# Generated at 2022-06-21 11:08:17.525191
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude()
    assert obj.NEVER(0)
    assert obj.NEVER('')
    assert obj.NEVER(())
    assert obj.NEVER([])
    assert obj.NEVER({})
    assert obj.NEVER(None)


# Generated at 2022-06-21 11:08:20.373880
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-21 11:08:21.811481
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(True)

# Generated at 2022-06-21 11:08:23.180334
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('toto')


# Generated at 2022-06-21 11:08:24.073848
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER is not None

# Generated at 2022-06-21 11:08:54.074699
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0
    #assert global_config.json_module == json.


# Generated at 2022-06-21 11:08:55.364128
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-21 11:08:57.574355
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}


# Generated at 2022-06-21 11:09:00.086974
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(Exclude.NEVER)

test_Exclude_NEVER()



# Generated at 2022-06-21 11:09:01.114173
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("1") == Fals

# Generated at 2022-06-21 11:09:03.968741
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("")
    assert Exclude.NEVER("")
    assert not (Exclude.ALWAYS("") and Exclude.NEVER(""))


# Generated at 2022-06-21 11:09:12.948648
# Unit test for function config
def test_config():
    import sys
    # these are passed in by the decorator
    assert config.__code__.co_varnames == (
        'metadata', 'encoder', 'decoder', 'mm_field', 'letter_case',
        'undefined', 'field_name', 'exclude', 'self', 'kwargs')
    assert config.__code__.co_argcount == 8
    assert config.__defaults__ is None
    assert config.__kwdefaults__ == {
        'metadata': None,
        'encoder': None,
        'decoder': None,
        'mm_field': None,
        'letter_case': None,
        'undefined': None,
        'field_name': None,
        'exclude': None,
    }

# Generated at 2022-06-21 11:09:14.826203
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    expected = True
    actual = Exclude.ALWAYS(None)
    assert actual == expected


# Generated at 2022-06-21 11:09:16.484069
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-21 11:09:18.169326
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(False)


# Generated at 2022-06-21 11:10:17.166245
# Unit test for function config
def test_config():
    import marshmallow
    from dataclasses import dataclass

    @dataclass
    class User:
        name: str

    class UserSchema(marshmallow.Schema):
        class Meta:
            additional = ('password',)

    schema = UserSchema()
    schema.load({'name': 'user_name', 'password': 'password'})

    @dataclass
    class User:
        name: str
        __config__ = config(exclude=Exclude.ALWAYS)

    schema = UserSchema()
    result = schema.load({'name': 'user_name', 'password': 'password'})
    assert result == {'password': 'password'}

    @dataclass
    class User:
        name: str
        __config__ = config(mm_field=marshmallow.fields.String())

# Generated at 2022-06-21 11:10:17.981869
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS


# Generated at 2022-06-21 11:10:20.618678
# Unit test for function config
def test_config():
    # seq = ('encoder', 'decoder', 'mm_field', 'letter_case')
    seq = ('encoder', 'decoder', 'mm_field')
    for name in seq:
        f = getattr(global_config, name)
        assert f == {}

# Generated at 2022-06-21 11:10:22.182524
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER(1)
    assert x == False
    # assert False


# Generated at 2022-06-21 11:10:23.248362
# Unit test for constructor of class Exclude
def test_Exclude():
    EXPECTED = Exclude.ALWAYS("")
    assert EXPECTED is True

# Generated at 2022-06-21 11:10:23.721848
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
  pass

# Generated at 2022-06-21 11:10:27.813345
# Unit test for function config
def test_config():
    from marshmallow import fields as ma_fields
    from dataclasses import dataclass

    @dataclass
    class A:
        name: str
        age: int = config(mm_field=ma_fields.Integer())

    assert A.__dict__['age'].metadata['dataclasses_json']['mm_field'] == ma_fields.Integer()

# Generated at 2022-06-21 11:10:31.502476
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Input
    c = 1
    # Expected output
    expected_output = True

    # Actual output
    actual_output = Exclude.ALWAYS(c)

    # Test
    assert actual_output == expected_output



# Generated at 2022-06-21 11:10:33.054516
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from _GlobalConfig import _GlobalConfig
    obj = _GlobalConfig()


# Generated at 2022-06-21 11:10:35.648858
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_function = Exclude.NEVER
    assert (test_function(1) == False)


# Generated at 2022-06-21 11:12:36.829835
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(4)
    assert not Exclude.NEVER(4)


# Generated at 2022-06-21 11:12:45.563206
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        a: int

    assert config() == {}
    assert config(mm_field='a') == {'dataclasses_json': {'mm_field': 'a'}}
    assert config({'a': 1}, mm_field='a') == {'a': 1, 'dataclasses_json': {'mm_field': 'a'}}
    assert config(mm_field='a')(MyClass) == {'dataclasses_json': {'mm_field': 'a'}}
    assert config(mm_field='a', letter_case='b')(MyClass) == {
        'dataclasses_json': {'mm_field': 'a', 'letter_case': 'b'}}

# Generated at 2022-06-21 11:12:47.098257
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    ng_flag = Exclude.NEVER("test")
    assert not ng_flag

# Generated at 2022-06-21 11:12:48.134193
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(_GlobalConfig(), _GlobalConfig)


# Generated at 2022-06-21 11:12:51.810999
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert callable(global_config_.encoders)
    assert callable(global_config_.decoders)
    assert callable(global_config_.mm_fields)
    # assert callable(global_config_.json_module)



# Generated at 2022-06-21 11:12:58.506305
# Unit test for function config
def test_config():
    import pytest
    from dataclasses import dataclass, field
    from dataclasses_json.config import global_config
    import marshmallow

    @dataclass
    class ClassA:
        fieldA: int
        fieldB: str

    @dataclass
    class ClassB:
        fieldA: int
        fieldB: str

    def encoder(obj, metadata):
        return metadata['json']['encoder'](obj)

    def decoder(obj, metadata):
        return metadata['json']['decoder'](obj)

    class MMFieldA(marshmallow.fields.Int):
        pass
    class MMFieldB(marshmallow.fields.Str):
        pass

    def letter_case(field_name, metadata):
        return metadata['json']['letter_case']


# Generated at 2022-06-21 11:13:07.968822
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_t = _GlobalConfig()
    # test the initial value of global_config_t
    assert isinstance(global_config_t.encoders, dict)
    assert isinstance(global_config_t.decoders, dict)
    assert isinstance(global_config_t.mm_fields, dict)
    # assert global_config_t._json_module == json
    # test the new value of global_config_t
    # global_config_t.json_module = pickle
    # assert global_config_t._json_module == pickle

if __name__ == "__main__":
    test__GlobalConfig()

# Generated at 2022-06-21 11:13:12.971948
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('str')
    assert Exclude.ALWAYS(123)
    assert Exclude.ALWAYS([1,2,3])
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS({})


# Generated at 2022-06-21 11:13:15.834556
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}

# Generated at 2022-06-21 11:13:19.187571
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert global_config_._encoders == {}
    assert global_config_._decoders == {}
    assert global_config_._mm_fields == {}
    assert global_config_._json_module == json
