

# Generated at 2022-06-21 11:04:33.615750
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test = _GlobalConfig()
    assert(test.encoders == {})
    assert(test.decoders == {})
    assert(test.mm_fields == {})
    # test_json_module(test)


# Generated at 2022-06-21 11:04:35.336174
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS({})
    assert not Exclude.NEVER({})


# Generated at 2022-06-21 11:04:38.274540
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:04:50.270672
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    
    @dataclasses.dataclass
    @config(field_name='laser')
    class LaserBeam:
        power: int
        
        def __add__(self, other):
            return LaserBeam(self.power + other.power)
        
    laser_beam_with_config = LaserBeam(1)
    
    assert laser_beam_with_config.laser == 1
    
    # TODO: Add test for encoder, decoder, mm_field, letter_case, undefined
    import pytest
    with pytest.raises(UndefinedParameterError) as exception_info:
        @dataclasses.dataclass
        @config(undefined='not_undefined')
        class NotUndefinedBeam:
            power: int
    


# Generated at 2022-06-21 11:04:56.178277
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config.encoders, dict)
    assert isinstance(config.decoders, dict)
    assert isinstance(config.mm_fields, dict)

    import json
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}


# Generated at 2022-06-21 11:05:07.942129
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(Undefined) == True
    assert Exclude.ALWAYS(Exclude) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(0xFFFFFFFFFF) == True
    assert Exclude.ALWAYS(-0xFFFFFFFFFF) == True
    assert Exclude.ALWAYS([x for x in range(20)]) == True
    assert Exclude.ALWAYS([False]) == True
    assert Exclude.ALWAYS([True]) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([None]) == True
   

# Generated at 2022-06-21 11:05:08.844954
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(T))

# Generated at 2022-06-21 11:05:19.060575
# Unit test for function config
def test_config():
    from marshmallow import validate, validates

    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Foo(DataClassJsonMixin):
        foo: int = 3.2

    assert Foo().to_dict() == {'foo': 3.2}

    @dataclass
    @config(encoder=int)
    class Foo(DataClassJsonMixin):
        foo: int = 3.2

    assert Foo().to_dict() == {'foo': int(3.2)}

    @dataclass
    @config(decoder=int)
    class Foo(DataClassJsonMixin):
        foo: int = 3.2

    assert Foo().to_dict() == {'foo': 3.2}


# Generated at 2022-06-21 11:05:27.744706
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class TypeWithMethods:
        def __init__(self):
            pass

    @dataclasses.dataclass
    class TypeWithFunctions:
        pass

    # Encoder
    @config(encoder=lambda o: o)
    @dataclasses.dataclass
    class EncoderDc:
        field: str

    assert global_config.encoders[EncoderDc] == \
        EncoderDc.__dataclass_json__['encoder']

    @config(encoder=lambda o: o)
    class EncoderType:
        pass

    assert global_config.encoders[EncoderType] == \
        EncoderType.__dataclass_json__['encoder']

    # Decoder

# Generated at 2022-06-21 11:05:29.045703
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:05:33.651505
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:05:36.305305
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-21 11:05:38.718488
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:05:41.974967
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert Exclude.NEVER(0)


# Generated at 2022-06-21 11:05:44.871555
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()

    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}

# Generated at 2022-06-21 11:05:47.218581
# Unit test for constructor of class Exclude
def test_Exclude():
    k = Exclude()
    var = True
    assert k.NEVER(var) is False
    var = False
    assert k.ALWAYS(var) is True

# Generated at 2022-06-21 11:05:50.349285
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Unit tests for config function

# Generated at 2022-06-21 11:05:52.307853
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders is not None
    assert g.decoders is not None
    assert g.mm_fields is not None

# Generated at 2022-06-21 11:05:55.153037
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True


# Generated at 2022-06-21 11:05:57.666828
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    _exclude_ALWAYS = Exclude.ALWAYS
    assert _exclude_ALWAYS('test') == True
    assert _exclude_ALWAYS(1) == True


# Generated at 2022-06-21 11:06:04.757395
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    v1 = _GlobalConfig()
    assert v1.encoders == {}
    assert v1.decoders == {}
    assert v1.mm_fields == {}


# Generated at 2022-06-21 11:06:14.622534
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import pytest

    @dataclass
    class Example:
        field: int = config(exclude='always')

    with pytest.raises(TypeError):
        Example(field=1)

    with pytest.raises(TypeError):
        Example()

    @dataclass
    class Example:
        field: int = config(exclude=lambda : True)

    with pytest.raises(TypeError):
        Example(field=1)

    with pytest.raises(TypeError):
        Example()

    @dataclass
    class Example:
        field: int = config(exclude=Exclude.ALWAYS)

    with pytest.raises(TypeError):
        Example(field=1)

    with pytest.raises(TypeError):
        Example

# Generated at 2022-06-21 11:06:18.864306
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class A:
        @classmethod
        def func1(cls, _):
            return 1
        func2 = classmethod(lambda _: 2)
    a = A()

    assert Exclude.NEVER(a.func1) == False
    assert Exclude.NEVER(a.func2) == False


# Generated at 2022-06-21 11:06:20.693564
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Exclude.NEVER:", Exclude.NEVER('data'))


test_Exclude_NEVER()

# Generated at 2022-06-21 11:06:22.051661
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('field') is False


# Generated at 2022-06-21 11:06:23.672417
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('anything')


# Generated at 2022-06-21 11:06:26.518602
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()
    assert obj.encoders
    assert obj.decoders
    assert obj.mm_fields
    assert not obj.json_module

# Generated at 2022-06-21 11:06:37.882473
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined
    import dataclasses_json
    import unittest.mock
    from typing import Dict, Any
    
    class DummyField(fields.Field):
        def _serialize(self, value, attr, obj, **kwargs):
            pass

        def _deserialize(self, value, attr, data, **kwargs):
            pass

    @config(encoder=lambda x: x,
            decoder=lambda x: x,
            mm_field=DummyField(),
            letter_case=lambda x: x,
            undefined=Undefined.EXCLUDE,
            field_name = 'mock_name',
            exclude = lambda x, y: False)
    class MockClass:
        pass


# Generated at 2022-06-21 11:06:38.848435
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig() is not None


# Generated at 2022-06-21 11:06:41.227590
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}



# Generated at 2022-06-21 11:06:51.449237
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = Exclude()
    assert x.ALWAYS == (lambda _: True)


# Generated at 2022-06-21 11:06:53.580901
# Unit test for constructor of class Exclude
def test_Exclude():
    print(Exclude.ALWAYS)
    print(Exclude.NEVER)

test_Exclude()

# Generated at 2022-06-21 11:06:59.190399
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class A:
        foo: str = "hello"

    assert A().foo == "hello"

    @dataclass
    class B:
        foo: str = "hello"

        @config(exclude=Exclude.ALWAYS)
        def foo(self) -> str:
            return "world"

    assert B().foo == "world"



# Generated at 2022-06-21 11:07:03.068840
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Testing method NEVER of class Exclude")
    assert Exclude.NEVER(12) is False
    assert Exclude.NEVER("Hello") is False
    print("Done testing method NEVER of class Exclude")


# Generated at 2022-06-21 11:07:04.081948
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(None)

# Generated at 2022-06-21 11:07:05.159389
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))


# Generated at 2022-06-21 11:07:10.497704
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("hi") == True
    assert Exclude.ALWAYS([1, 2]) == True
    assert Exclude.ALWAYS({1:"one", 2:"two"}) == True


# Generated at 2022-06-21 11:07:14.984116
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-21 11:07:17.675944
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("_dataclasses_json_obj")
    assert Exclude.ALWAYS("_dataclasses_json_init")

# Generated at 2022-06-21 11:07:18.788148
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:07:41.142302
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') is True


# Generated at 2022-06-21 11:07:44.051734
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    assert isinstance(c.encoders, dict)
    assert isinstance(c.decoders, dict)
    assert isinstance(c.mm_fields, dict)


# Generated at 2022-06-21 11:07:44.605965
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    pass


# Generated at 2022-06-21 11:07:45.858469
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-21 11:07:50.575606
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # global_config = _GlobalConfig():
    # assert global_config.default_exclusion_keys == [id, type]
    # assert global_config.encoders == {}
    # assert global_config.decoders == {}
    # assert global_config.mm_fields == {}
    # assert global_config._json_module == json
    pass


# Generated at 2022-06-21 11:07:52.253219
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-21 11:07:53.581437
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True

# Generated at 2022-06-21 11:07:56.925532
# Unit test for function config
def test_config():
    assert config(field_name='foo') == {'dataclasses_json': {'field_name': 'foo'}}
    # TODO: add test for config with all parameters

# Generated at 2022-06-21 11:07:59.101208
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-21 11:08:00.136085
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-21 11:08:40.999636
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    assert result == True

    result = Exclude.ALWAYS("string")
    assert result == True

    result = Exclude.ALWAYS(['list'])
    assert result == True

    result = Exclude.ALWAYS({'dict'})
    assert result == True



# Generated at 2022-06-21 11:08:44.065672
# Unit test for constructor of class Exclude
def test_Exclude():
    assert issubclass(Exclude.ALWAYS, Callable)
    assert issubclass(Exclude.NEVER, Callable)
    assert Exclude.ALWAYS(False)
    assert not Exclude.NEVER(False)

# Generated at 2022-06-21 11:08:49.309576
# Unit test for function config
def test_config():
    from marshmallow import fields
    import dataclasses

    @dataclasses.dataclass
    @config(encoder=lambda x: x + 1,
            decoder=lambda x: x - 1,
            mm_field=fields.Integer(),
            letter_case=lambda x: 'schwa' if x == 'alpha' else x,
            undefined=Undefined.EXCLUDE,
            field_name='alpha',
            )
    class TestClass:
        alpha: str
        beta: str

# Generated at 2022-06-21 11:08:53.955224
# Unit test for function config
def test_config():
    from marshmallow import fields

    @config(mm_field=fields.String(default='foo'))
    @dataclass
    class Test:
        """
        Test class for config
        """
        field: str

    assert Test.__dataclass_json__.mm_field.default == 'foo'

# Generated at 2022-06-21 11:08:55.240008
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS(Callable)) == True


# Generated at 2022-06-21 11:08:57.846161
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    #assert global_config.json_module == json



# Generated at 2022-06-21 11:08:59.809953
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(42)


# Generated at 2022-06-21 11:09:01.863743
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)



# Generated at 2022-06-21 11:09:05.922541
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    class Person:
        friend: str

    testPerson = Person("Steve")
    c = config(exclude=Exclude.NEVER)
    encoded = as_json(testPerson, **c)
    expected = {"friend": "Steve"}
    assert encoded == expected


# Generated at 2022-06-21 11:09:11.371776
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class SomeClass:
        x: int = config(undefined=Undefined.EXCLUDE)

    SomeClass(1, 2)

    try:
        SomeClass(1, 2, undefined="INCLUDE")
        assert False, "Didn't raise UndefinedParameterError"
    except UndefinedParameterError as e:
        assert "Invalid undefined parameter action" in str(e)

# Generated at 2022-06-21 11:10:38.972858
# Unit test for function config
def test_config():
    @dataclass
    class Foo:
        x: int
        y: int


# Generated at 2022-06-21 11:10:42.304746
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    # assert config.encoders == json
    # TODO: assert config._json_module == json


# Generated at 2022-06-21 11:10:42.928567
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert(Exclude.NEVER({}) == False)

# Generated at 2022-06-21 11:10:45.696246
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-21 11:10:47.092540
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-21 11:10:56.490188
# Unit test for function config
def test_config():

    # Exclude constants
    config(exclude=Exclude.ALWAYS)
    config(exclude=Exclude.NEVER)

    # Exclude functions
    config(exclude=lambda *_: True)
    config(exclude=lambda *_: False)

    # letter_case functions
    config(letter_case=lambda x: x.upper())
    config(letter_case=lambda x: x.lower())
    config(letter_case=lambda x: x.capitalize())

    # undefined constants
    config(undefined=Undefined.EXCLUDE)
    config(undefined=Undefined.INCLUDE)
    config(undefined=Undefined.RAISE)
    config(undefined=Undefined.USE_DEFAULT)

    # undefined dictionary keys
    config(undefined='EXCLUDE')
   

# Generated at 2022-06-21 11:10:57.557257
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None) == True)


# Generated at 2022-06-21 11:10:58.030347
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude()

# Generated at 2022-06-21 11:10:59.667152
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER("Name") == False


# Generated at 2022-06-21 11:11:00.556148
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)

# Generated at 2022-06-21 11:13:56.190575
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-21 11:14:04.671892
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin
    import unittest
    @config(encoder=lambda d: d['haha'],
            decoder=lambda d: {'haha': d},
            field_name='test',
            letter_case=lambda d: 'test',
            undefined=Undefined.EXCLUDE,
            exclude=lambda _, value: True)
    @dataclass
    class Test(DataClassJsonMixin):
        test: str = field(metadata={
            'dataclasses_json': {
                'encoder': lambda d: d.lower(),
                'decoder': lambda d: d.upper()
            }})

# Generated at 2022-06-21 11:14:06.950315
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-21 11:14:11.166304
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module is json


# Generated at 2022-06-21 11:14:14.253730
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc_only = _GlobalConfig().encoders
    gc_only[_GlobalConfig] = Exception
    test_1 = _GlobalConfig().encoders
    assert gc_only == test_1

if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-21 11:14:24.222874
# Unit test for function config
def test_config():
    import pytest

    @pytest.mark.parametrize("undefined, error", [
        (Undefined.EXCLUDE, False),
        ('exclude', False),
        ('fails', True),
    ])
    def test_undefined_actions(undefined, error):
        if error:
            with pytest.raises(UndefinedParameterError):
                config(undefined=undefined)
        else:
            assert config(undefined=undefined) == {
                'dataclasses_json': {'undefined': undefined}
            }
