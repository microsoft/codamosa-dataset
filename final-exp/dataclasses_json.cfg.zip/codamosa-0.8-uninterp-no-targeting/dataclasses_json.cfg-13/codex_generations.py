

# Generated at 2022-06-21 11:04:33.846492
# Unit test for function config
def test_config():
    from unittest.mock import Mock
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(encoder=Mock(), decoder=Mock(), mm_field=fields.String)
    class Fake:
        pass

    assert global_config.encoders[Fake] == Mock()
    assert global_config.decoders[Fake] == Mock()
    assert global_config.mm_fields[Fake] == fields.String

# Generated at 2022-06-21 11:04:37.561671
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print('test_Exclude_NEVER:')
    print(Exclude.NEVER('field'))
    assert Exclude.NEVER('field') == False, 'test_Exclude_NEVER: Test failed!'


# Generated at 2022-06-21 11:04:38.857153
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:04:40.346390
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(None)


# Generated at 2022-06-21 11:04:52.310130
# Unit test for function config
def test_config():
    from marshmallow import fields as mm_fields, Schema
    import dataclasses as dc

    @dc.dataclass
    @config(encoder=dict, decoder=dict, letter_case=str.upper, mm_field=mm_fields.Str())
    class Data:
        val: str

    class TestConfigSchema(Schema):
        class Meta:
            fields = ('val', )

    data = Data('val')
    schema = TestConfigSchema()

    # Test encoder
    obj = schema.dump(data)
    assert obj == {'val': 'val'}

    # Test decoder
    data = schema.load({'val': 'val'})
    assert data == Data('val')

    # Test letter case override
    schem

# Generated at 2022-06-21 11:04:56.920597
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is Exclude.ALWAYS
    assert Exclude.NEVER is Exclude.NEVER
    assert id(Exclude.ALWAYS) != id(Exclude.NEVER)

if __name__ == '__main__':
    test_Exclude()

# Generated at 2022-06-21 11:05:08.886187
# Unit test for function config
def test_config():
    import pytest

    from dataclasses import dataclass, Field
    from dataclasses_json import DataClassJsonMixin, config

    from dataclasses_json.config import global_config, _GlobalConfig

    @dataclass
    class MyTestClass(DataClassJsonMixin):
        a: str = Field(
            metadata=config(
                letter_case=lambda s: s.upper(),
                field_name='_a',
                exclude=lambda field, val: val == 0,
            )
        )

        b: str = 'b'
        c: int = 0

    test_class = MyTestClass()

    assert test_class.a == 'a'
    assert test_class.b == 'b'
    assert test_class.c == 0


# Generated at 2022-06-21 11:05:10.156462
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config= _GlobalConfig()
    assert global_config != None


# Generated at 2022-06-21 11:05:16.417841
# Unit test for function config
def test_config():
    @dataclass
    class A:
        field: int = config(field_name="test_field")

    dclass = A()
    dclass.field = 2
    assert dclass.field == 2

    assert dclass.to_dict() == {"test_field": 2}

    A.field.type.metadata['dataclasses_json']['exclude'] = Exclude.ALWAYS

    assert dclass.to_dict() == {}

# Generated at 2022-06-21 11:05:18.798069
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-21 11:05:23.120058
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-21 11:05:28.005200
# Unit test for constructor of class Exclude
def test_Exclude():
    # Result of function call of function 'lambda _: True'
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS('abc') == True

    # Result of function call of function 'lambda _: False'
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('abc') == False


# Generated at 2022-06-21 11:05:29.702581
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    obj= Exclude()
    assert obj.ALWAYS(1) == True
    assert obj.ALWAYS(0) == True


# Generated at 2022-06-21 11:05:30.726995
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:05:36.778284
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass
    class A:
        a: str
        b: int
        c: bool

    def do_convert(val):
        ea = A('a', 1, True)
        d = asdict(ea, dict_factory=OrderedDict)
        if val == '1':
            d['a'] = val
        if val == '2':
            d['b'] = val
        if val == '3':
            d['c'] = val
        return ea, d

    def do_test(exclude_func, val):
        ea, d = do_convert(val)
        ca = convert(ea, d, dict_factory=OrderedDict,
                     dict_hook=lambda d: A(**d), exclude=exclude_func)
        assert ea == ca



# Generated at 2022-06-21 11:05:42.363885
# Unit test for function config
def test_config():
    from dataclasses_json import DataclassJSON
    @DataclassJSON
    @config(encoder={'a': 1})
    class Foo:
        pass
    assert Foo.__dataclass_json__['encoder'] == {'a': 1}

    @DataclassJSON
    @config(metadata=Foo.__dataclass_json__)
    class Bar:
        pass
    # Should be the same as Foo
    assert Bar.__dataclass_json__ == Foo.__dataclass_json__

    @DataclassJSON
    @config(mm_field=str, encoder='a')
    class Bar:
        pass

# Generated at 2022-06-21 11:05:51.691108
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class Combine:
        field: str

    @dataclasses.dataclass
    @config(exclude=Exclude.ALWAYS)
    class Excluded:
        excluded: bool

    @dataclasses.dataclass
    @config(field_name='field')
    class Renamed:
        field: bool

    @dataclasses.dataclass
    @config(field_name='field', letter_case=str.title)
    class Capitalized:
        field: bool

    @dataclasses.dataclass
    @config(undefined=Undefined.EXCLUDE)
    class ExcludedUndefined:
        undefined: bool


# Generated at 2022-06-21 11:06:02.445079
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    global_config.encoders = {int: lambda x: x*3}
    global_config.decoders = {int: lambda x: x/3}
    global_config.mm_fields = {int: lambda x: x/3}
    assert global_config.encoders == {int: lambda x: x*3}
    assert global_config.decoders == {int: lambda x: x/3}
    assert global_config.mm_fields == {int: lambda x: x/3}


# Generated at 2022-06-21 11:06:03.382496
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)

# Generated at 2022-06-21 11:06:05.065434
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Exclude is the class on which the method was defined
    assert Exclude.NEVER(Exclude.NEVER)

# Generated at 2022-06-21 11:06:08.590626
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("teja") == True


# Generated at 2022-06-21 11:06:09.996539
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-21 11:06:11.311936
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("ABC")


# Generated at 2022-06-21 11:06:13.972875
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-21 11:06:16.631186
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}


# Generated at 2022-06-21 11:06:18.391109
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-21 11:06:19.854088
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") == True


# Generated at 2022-06-21 11:06:21.575103
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-21 11:06:25.832790
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)

test__GlobalConfig()

# Generated at 2022-06-21 11:06:27.429676
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:06:34.278887
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Unit test for method NEVER of class Exclude")
    assert Exclude.NEVER("a") == False
    print("Passed!")


# Generated at 2022-06-21 11:06:34.934339
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-21 11:06:35.649155
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-21 11:06:37.046661
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-21 11:06:44.562722
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    class TestClass:
        b: bool = False
        i: int = False
        f: float = False
        s: str = False
        d: dict = False
        a: list = False
        t: tuple = False

    def bool_decoder(x):
        return bool(x)

    def bool_encoder(x):
        return bool(x)

    assert TestClass(b=True).json() == '{"b": true}'
    assert TestClass().json(by_alias=True) == '{"b": false}'

    assert TestClass(i=1).json() == '{"i": 1}'
    assert TestClass().json(by_alias=True) == '{"i": false}'


# Generated at 2022-06-21 11:06:50.815002
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("hello")
    assert Exclude.NEVER("123123123")
    assert Exclude.NEVER(123)
    assert Exclude.NEVER(123.123)
    assert Exclude.NEVER(Undefined)
    assert Exclude.NEVER((1, 2, 3))
    assert Exclude.NEVER([1, 2, 3])
    assert Exclude.NEVER({"hello": "world"})



# Generated at 2022-06-21 11:06:51.236975
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-21 11:06:53.515892
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS(1) == True and Exclude.ALWAYS(None) == True and Exclude.ALWAYS('a') == True and Exclude.ALWAYS([1,2]) == True)


# Generated at 2022-06-21 11:06:59.105165
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    class Foo:
        foo: str = config(metadata={'foo': 'bar'}).field(metadata={'baz': 'qux'})
    assert Foo.__dataclasses_metadata__ == {'dataclasses_json': {},
                                            'foo': 'bar'}
    assert Foo.__dataclasses_fields__['foo'].metadata == {'baz': 'qux'}

# Generated at 2022-06-21 11:07:03.362154
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class AlwaysExclude:
        value: str

    assert dataclasses_json.encode_dataclass(AlwaysExclude('abc')) == '{}'



# Generated at 2022-06-21 11:07:12.665003
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-21 11:07:15.546404
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:07:22.561580
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(None) == False)
    assert(Exclude.NEVER(1) == False)
    assert(Exclude.NEVER(0) == False)
    assert(Exclude.NEVER(True) == False)
    assert(Exclude.NEVER(False) == False)
    assert(Exclude.NEVER(False) == False)
    assert(Exclude.NEVER('') == False)
    assert(Exclude.NEVER('text') == False)


# Generated at 2022-06-21 11:07:24.448781
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('_') is True


# Generated at 2022-06-21 11:07:29.097219
# Unit test for constructor of class Exclude
def test_Exclude():

    @dataclass
    class A:
        x: int = field(metadata=config(exclude=Exclude.ALWAYS))
        y: int = field(metadata=config(exclude=Exclude.NEVER))

    a = A(x = 1, y = 2)

    assert a.x == 1
    assert a.y == 2

# Generated at 2022-06-21 11:07:31.652382
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER('a') == False
    assert Exclude.ALWAYS('b') == True

# Generated at 2022-06-21 11:07:35.422789
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("a")
    assert Exclude.NEVER(2)
    assert Exclude.NEVER(None)


# Generated at 2022-06-21 11:07:37.276552
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:07:40.331893
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    from hypothesis import given
    from hypothesis.strategies import integers

    @given(val=integers())
    def test(val):
        assert Exclude.ALWAYS(val)

    test()

# Generated at 2022-06-21 11:07:49.074656
# Unit test for constructor of class _GlobalConfig

# Generated at 2022-06-21 11:08:06.616096
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-21 11:08:09.169820
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS([2, 3]) == True
    assert Exclude.NEVER('a') == False

# Generated at 2022-06-21 11:08:12.559371
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()
    assert obj.encoders == {}
    assert obj.decoders == {}
    assert obj.mm_fields == {}
    # assert obj._json_module == json


# Generated at 2022-06-21 11:08:23.565359
# Unit test for function config
def test_config():
    import pytest
    from dataclasses import dataclass

    @dataclass
    class Test:
        x: int
        y: str

    @dataclass
    class Test2:
        a: float
        b: Test

    @dataclass
    class Test3:
        a: float
        b: Test

    @dataclass
    class Test4:
        a: float
        b: Test2

    @dataclass
    class Test5:
        a: float
        b: Test

    @dataclass
    class Test6:
        a: float
        b: Test2

    @dataclass
    class Test7:
        a: float
        b: Test

    @dataclass
    class Test8:
        a: float
        b: Test


# Generated at 2022-06-21 11:08:26.232116
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_inst = _GlobalConfig()

    assert global_config_inst.encoders == {}
    assert global_config_inst.mm_fields == {}


# Generated at 2022-06-21 11:08:28.826819
# Unit test for function config
def test_config():
    class MyType:
        pass

    @config(encoder=lambda x: x)
    class MyClass:
        a: MyType



# Generated at 2022-06-21 11:08:33.154642
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-21 11:08:35.697114
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-21 11:08:37.153713
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-21 11:08:41.852879
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_global_config = _GlobalConfig()
    assert test_global_config.encoders == dict()
    assert test_global_config.decoders == dict()
    assert test_global_config.mm_fields == dict()
    # test_global_config = json


# Generated at 2022-06-21 11:09:38.995471
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(object) is False

# Generated at 2022-06-21 11:09:42.206913
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("test") == False
    assert Exclude.NEVER("tester") == False


# Generated at 2022-06-21 11:09:48.422757
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    from dataclasses import dataclass

    @dataclass
    class Basic:
        a: int
        b: list

    a = Basic(1, [1, 2])
    b = Basic(1, [])
    c = Basic(2, [1, 2])

    assert Exclude.ALWAYS(a)
    assert Exclude.ALWAYS(b)
    assert Exclude.ALWAYS(c)


# Generated at 2022-06-21 11:09:50.365364
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("a")


# Generated at 2022-06-21 11:09:52.373503
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True


# Generated at 2022-06-21 11:09:55.502204
# Unit test for constructor of class Exclude
def test_Exclude():
    assert id(Exclude.ALWAYS) == id(Exclude.NEVER)
    # print(id(Exclude.ALWAYS))
    # print(id(Exclude.NEVER))


# Generated at 2022-06-21 11:09:57.313629
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_config=_GlobalConfig()
    assert test_config.encoders == {}
    assert test_config.decoders == {}
    assert test_config.mm_fields == {}


# Generated at 2022-06-21 11:10:06.126711
# Unit test for function config
def test_config():
    assert config(exclude=Exclude.ALWAYS) == {
        'dataclasses_json': {'exclude': Exclude.ALWAYS}}

    assert config(undefined='ignore') == {
        'dataclasses_json': {'undefined': Undefined.IGNORE}}

    assert config(undefined=Undefined.RAISE) == {
        'dataclasses_json': {'undefined': Undefined.RAISE}}

    with pytest.raises(UndefinedParameterError):
        config(undefined='INVALID')



# Generated at 2022-06-21 11:10:07.503497
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-21 11:10:09.610427
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:11:26.853978
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)==True
    assert Exclude.NEVER(False)==False

# Generated at 2022-06-21 11:11:28.784316
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-21 11:11:29.328425
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-21 11:11:31.474183
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:11:33.778612
# Unit test for function config
def test_config():
    @dataclass
    @config(encoder=1)
    class Example:
        pass

    assert Example.__dataclass_metadata__['dataclasses_json']['encoder'] == 1

# Generated at 2022-06-21 11:11:36.857621
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    
test__GlobalConfig()


# Generated at 2022-06-21 11:11:38.630146
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)


test_Exclude()

# Generated at 2022-06-21 11:11:40.026798
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("1") == False


# Generated at 2022-06-21 11:11:44.097392
# Unit test for constructor of class Exclude
def test_Exclude():
    if isinstance(Exclude.ALWAYS, Callable):
        assert callable(Exclude.ALWAYS)
    if isinstance(Exclude.KWARGS, Callable):
        assert callable(Exclude.NEVER)


# Generated at 2022-06-21 11:11:51.267601
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    class User:
        """
        user class
        """
        id: int
        name: str = dataclasses.field(metadata={'marshmallow_field': MarshmallowField()})

    assert config(encoder=1, decoder="apple", mm_field=MarshmallowField(),
                  letter_case=1, undefined=1, exclude=1) == {'dataclasses_json': {
        'encoder': 1, 'decoder': 'apple',
        'mm_field': MarshmallowField(), 'letter_case': 1, 'undefined': 1,
        'exclude': 1
    }}