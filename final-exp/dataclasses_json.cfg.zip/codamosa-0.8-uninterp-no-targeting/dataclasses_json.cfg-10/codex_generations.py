

# Generated at 2022-06-21 11:04:31.796556
# Unit test for constructor of class Exclude
def test_Exclude():

    # Testing the first constructor which ALWAYS return True
    test_class_Exclude_ALWAYS = Exclude()

    assert test_class_Exclude_ALWAYS.ALWAYS(2) == True

    # Testing the second constructor which NEVER return False
    test_class_Exclude_NEVER = Exclude()

    assert test_class_Exclude_NEVER.NEVER(2) == False



# Generated at 2022-06-21 11:04:32.701340
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None) == True)

# Generated at 2022-06-21 11:04:34.522665
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.decoders == {}


# Generated at 2022-06-21 11:04:37.841099
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == Exclude.NEVER(None) == False
    assert Exclude.NEVER('5') == False
    assert Exclude.NEVER({5:5}) == False


# Generated at 2022-06-21 11:04:39.269942
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)


# Generated at 2022-06-21 11:04:50.971213
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from typing import Any

    md = config()
    assert md['dataclasses_json']['undefined'] == Undefined.RAISE

    @dataclass
    class Obj:
        a: int
        b: Any
        c: str

    @config({'dataclasses_json': {'undefined': Undefined.EXCLUDE}}, mm_field=int)
    class Obj:
        a: int
        b: Any
        c: str

    @config(mm_field=int)
    class Obj:
        a: int
        b: Any
        c: str

    @config(undefined=Undefined.EXCLUDE)
    class Obj:
        a: int
        b: Any
        c: str

# Generated at 2022-06-21 11:04:57.798868
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    global_config.encoders = {float: str}
    assert global_config.encoders[float] == str
    global_config.decoders = {int: float}
    assert global_config.decoders[int] == float
    global_config.mm_fields = {float: float}
    assert global_config.mm_fields[float] == float

test__GlobalConfig()



# Generated at 2022-06-21 11:05:01.074845
# Unit test for constructor of class Exclude

# Generated at 2022-06-21 11:05:04.852506
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    import pytest
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-21 11:05:08.718359
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    assert Exclude.NEVER is not None
    assert Exclude.NEVER({})
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER('')

# Generated at 2022-06-21 11:05:17.777075
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass
    class Data:
        name: str
        number: int
        car_type: str = field(metadata=config(exclude=Exclude.ALWAYS))
    data = Data('Paul', 234)
    #print(data.name)
    #print(data.number)
    #print(data.car_type)
    assert dataclasses_json.dumps({
        'name': 'Paul',
        'number': 234
    }) == dataclasses_json.dumps(data)

test_Exclude_ALWAYS()

# Generated at 2022-06-21 11:05:19.099515
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-21 11:05:27.784339
# Unit test for function config
def test_config():
    # ref:
    # https://docs.python.org/3/library/functools.html#functools.wraps
    # https://www.geeksforgeeks.org/private-variables-and-methods-in-python/
    import inspect

    @config(field_name='hello')
    def hello(s):
        return s

    assert inspect.signature(hello).parameters['s'].name == 'hello'

    @config(letter_case=str.lower)
    def hello2(s):
        return s

    assert hello2('HeLlO') == 'hello'


# TODO: #180
# def _disable_msg():
#     return ("Passing the json module directly to `dump`/`dumps` and "
#             "`load`/`loads`/`patch`

# Generated at 2022-06-21 11:05:30.907158
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('1') == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-21 11:05:32.768320
# Unit test for constructor of class Exclude
def test_Exclude():
    # unit test for config
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:05:34.215559
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-21 11:05:35.830183
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:05:37.792955
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert isinstance(Exclude.ALWAYS, callable)
    assert Exclude.ALWAYS('0') is True


# Generated at 2022-06-21 11:05:41.059285
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2)
    assert not Exclude.NEVER(2)


# Generated at 2022-06-21 11:05:43.989779
# Unit test for constructor of class Exclude
def test_Exclude():
  # Create an empty instance of Exclude
  e = Exclude()

  # Verify constants

# Generated at 2022-06-21 11:05:46.458632
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-21 11:05:47.399290
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()


# Generated at 2022-06-21 11:05:49.209984
# Unit test for constructor of class Exclude
def test_Exclude():
    a = Exclude
    assert a.ALWAYS("s") == True
    assert a.NEVER("s") == False

# Generated at 2022-06-21 11:05:52.878972
# Unit test for function config
def test_config():
    from marshmallow import fields

    # noinspection PyTypeChecker
    config(mm_field=fields.Integer())  # type: ignore
    config(letter_case='snake')
    config(encoder=str)
    config(decoder=str)
    config(undefined=Undefined.RAISE)
    config(exclude=Exclude.NEVER)

# Generated at 2022-06-21 11:05:55.324251
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-21 11:05:56.676700
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') is False


# Generated at 2022-06-21 11:06:06.057397
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders.update({int: lambda x: str(x)})

# Generated at 2022-06-21 11:06:16.403751
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import json
    import marshmallow

    @dataclass
    @config(encoder=json.dumps,
            decoder=json.loads,
            mm_field=marshmallow.fields.String(),
            letter_case=lambda s: s.upper(),
            undefined=Undefined.EXCLUDE,
            field_name='test',
            exclude=lambda n, d: n == 'test')
    class TestConfig:
        test: int

    assert TestConfig.__dataclass_fields__['test'].metadata["dataclasses_json"]["encoder"] == json.dumps
    assert TestConfig.__dataclasses_json__["encoder"] == json.dumps

# Generated at 2022-06-21 11:06:19.828731
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert(global_config.encoders == {})
    assert(global_config.decoders == {})
    assert(global_config.mm_fields == {})
    # assert(global_config._json_module == json)


# Generated at 2022-06-21 11:06:22.326023
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    func = Exclude.NEVER
    # Act
    result = func(0)
    # Assert
    assert not result


# Generated at 2022-06-21 11:06:35.418024
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import LetterCase, DataClassJsonMixin

    def _test_config(config_dict, expect_field_name=False, expect_letter_case=False,
                     expect_undefined=False, expect_exclude=False):
        @dataclass
        class C(DataClassJsonMixin):
            @config(**config_dict)
            def _field1(self):
                pass

        assert hasattr(C, '_field1_config')
        assert isinstance(C._field1_config, dict)

        if expect_field_name:
            assert 'field_name' in C._field1_config
        else:
            assert 'field_name' not in C._field1_config


# Generated at 2022-06-21 11:06:36.847898
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False



# Generated at 2022-06-21 11:06:41.028047
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS('True') == True
    assert Exclude.ALWAYS('str') == True
    try:
        Exclude.ALWAYS()
    except TypeError as e:
        assert type(e) == TypeError


# Generated at 2022-06-21 11:06:48.130404
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True

    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-21 11:06:57.380163
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    try:
        Config = _GlobalConfig()
        if (Config.encoders != {}):
            raise AssertionError("Constructor not setting encoders attribute to empty dictionary")
        if (Config.decoders != {}):
            raise AssertionError("Constructor not setting decoders attribute to empty dictionary")
        if (Config.mm_fields != {}):
            raise AssertionError("Constructor not setting mm_fields attribute to empty dictionary")
        if (Config._json_module != json):
            raise AssertionError("Constructor not setting _json_module class attribute to json library")
    except NameError:
        raise AssertionError("Error in constructor of _GlobalConfig class")
    except AttributeError:
        raise AssertionError("Error in constructor of _GlobalConfig class")
    except TypeError:
        raise Assert

# Generated at 2022-06-21 11:06:59.426840
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = Exclude.ALWAYS
    T = TypeVar("T")
    assert x(2)

# Generated at 2022-06-21 11:07:01.234662
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:07:03.844962
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('test')


# Generated at 2022-06-21 11:07:15.882998
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from dataclasses_json.mm_field import MMList, MMField
    from marshmallow import fields

    # TODO: add tests for the encoder and decoder functions

    # Test that mm_fields have been initialized
    assert isinstance(global_config.mm_fields[list], MMList)
    assert global_config.mm_fields[list].container == list
    assert isinstance(global_config.mm_fields[dict], MMField)
    assert global_config.mm_fields[dict].field_class == fields.Dict
    assert isinstance(global_config.mm_fields[set], MMList)
    assert global_config.mm_fields[set].container == set
    assert isinstance(global_config.mm_fields[tuple], MMList)

# Generated at 2022-06-21 11:07:23.733782
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import marshmallow

    class Field(marshmallow.fields.Field):
        pass

    @dataclass
    @config(encoder = int, decoder = str, field_name = "Override1", mm_field = Field(),
            letter_case = lambda s: s.upper(),
            undefined = 'raise',
            exclude = Exclude.NEVER)
    class A:
        i: int

    assert A.__dataclass_json__.encoder == int
    assert A.__dataclass_json__.decoder == str
    assert A.__dataclass_json__.mm_field is Field
    assert A.__dataclass_json__.field_name('i') == 'Override1'

# Generated at 2022-06-21 11:07:28.998449
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-21 11:07:33.017555
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert len(a.encoders) == 0
    assert len(a.decoders) == 0
    assert len(a.mm_fields) == 0


# Generated at 2022-06-21 11:07:34.899107
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    excluded = Exclude.NEVER
    assert excluded({}) == False


# Generated at 2022-06-21 11:07:38.405005
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER(True)
    assert not Exclude.NEVER(False)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-21 11:07:41.389825
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Test:
        def __init__(self, msg):
            self.msg = msg

    test = Test('This is a test')
    assert Exclude.NEVER(test)



# Generated at 2022-06-21 11:07:49.683432
# Unit test for function config
def test_config():
    import dataclasses_json
    import marshmallow
    @dataclasses_json.config(encoder=dataclasses_json.dumps,
                             decoder=dataclasses_json.loads,
                             mm_field=marshmallow.fields.Field(),
                             letter_case=dataclasses_json.letter_case.CamelCase,
                             undefined=Undefined.RAISE,
                             field_name="test_field_name",
                             exclude=Exclude.NEVER)
    @dataclasses.dataclass
    class TestConfig:
        field: str


# Generated at 2022-06-21 11:07:56.466156
# Unit test for function config
def test_config():
    # Test exclude:
    @dataclass
    class MyClass:
        a: str
        b: str = field(metadata=config(exclude=lambda f, _: f == 'a'))
        c: str = field(metadata=config(exclude=lambda f, _: f == 'c'))
        d: str = field(metadata=config(exclude=lambda f, _: f == 'd'))

# Generated at 2022-06-21 11:07:58.278202
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-21 11:08:07.572262
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin
    from marshmallow_dataclass import dataclass as mm_dataclass

    @dataclass
    class Example(DataClassJsonMixin):
        a: str = 'Hey there'

    # from dataclasses import dataclass, field
    assert Example().to_dict() == {'a': 'Hey there'}

    @dataclass
    class ConfigExample(DataClassJsonMixin):
        a: str = 'Hey there'

    assert ConfigExample().to_dict() == {'a': 'Hey there'}

    @config()
    @dataclass
    class JsonConfigExample(DataClassJsonMixin):
        a: str = 'Hey there'

    assert JsonConfigExample().to

# Generated at 2022-06-21 11:08:11.495719
# Unit test for function config
def test_config():
    config()
    config(metadata=None, encoder=None, decoder=None, mm_field=None, letter_case=None, undefined=None, field_name=None, exclude=None)

# Generated at 2022-06-21 11:08:17.775977
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER('hello') is False
    assert Exclude.NEVER(Exclude) is False



# Generated at 2022-06-21 11:08:20.555798
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config_ = _GlobalConfig()
    assert config_.decoders == {}
    assert config_.encoders == {}
    assert config_.mm_fields == {}

# Generated at 2022-06-21 11:08:21.906740
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER is not None
test_Exclude_NEVER()

# Generated at 2022-06-21 11:08:28.426604
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('b') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS((1,2)) == True
    assert Exclude.ALWAYS({'k1':'v1'}) == True
    assert Exclude.ALWAYS({'k2':'v2', 'k1':'v1'}) == True


# Generated at 2022-06-21 11:08:29.487005
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("") == True
    assert Exclude.NEVER("") == False

#test for function config

# Generated at 2022-06-21 11:08:32.568375
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_config = _GlobalConfig()
    assert test_config.encoders == {}
    assert test_config.decoders == {}
    assert test_config.mm_fields == {}

# Generated at 2022-06-21 11:08:39.909365
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from marshmallow import fields

    assert set(['encoders', 'decoders', 'mm_fields']) == set(global_config.__dict__.keys())

    global_config.encoders[type(1)] = lambda x: 'test_int'
    global_config.decoders[type('test')] = lambda x: 1
    global_config.mm_fields[type(1)] = fields.Integer()
    # TODO: fix this test
    # assert global_config.json_module is json

# Generated at 2022-06-21 11:08:48.913883
# Unit test for function config
def test_config():
    import marshmallow
    class User:
        pass
    @config(encoder=lambda u: u.__name__, decoder=User, mm_field=marshmallow.fields.Str(),
            letter_case=lambda value: value.lower(),
            undefined=Undefined.EXCLUDE,
            field_name='name',
            exclude=Exclude.NEVER
            )
    class User2:
        name: str
    assert global_config.encoders[User2] == global_config.encoders[User]
    assert global_config.decoders[User2] == global_config.decoders[User]
    assert global_config.mm_fields[User2] == global_config.mm_fields[User]
    assert global_config.mm_fields[User2] is marshmallow.fields.Str()

# Generated at 2022-06-21 11:08:50.980601
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-21 11:08:53.504548
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = dict()
    global_config.decoders = dict()
    global_config.mm_fields = dict()

# Generated at 2022-06-21 11:09:03.455550
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS(4) == True)


# Generated at 2022-06-21 11:09:08.667287
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    my_global_config = _GlobalConfig()

    assert my_global_config.encoders == {}
    assert my_global_config.decoders == {}
    assert my_global_config.mm_fields == {}

    # It is not possible to change the json module
    # my_global_config.json_module = json
    # assert my_global_config.json_module == json


# Generated at 2022-06-21 11:09:09.902372
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Anything") is True


# Generated at 2022-06-21 11:09:11.101109
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(None)
    assert result == False


# Generated at 2022-06-21 11:09:11.895473
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(_) == False

# Generated at 2022-06-21 11:09:22.958425
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # setter json_module
    # TODO: ascii decode errors?
    try:
        global_config.json_module = json
        global_config.json_module = rapidjson
    except Exception:
        pass
    # getter json_module
    assert global_config.json_module.dumps == json.dumps
    # getter json_module
    assert global_config.json_module.dumps == rapidjson.dumps
    # setter json_module
    try:
        global_config.json_module = simplejson
    except Exception:
        pass
    # getter json_module
    assert global_config.json_module.dumps == simplejson.dumps
    return True

if __name__ == "__main__":
    print(test__GlobalConfig())

# Generated at 2022-06-21 11:09:28.358728
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("S") == True
    assert Exclude.ALWAYS([1,2,3]) == True
    assert Exclude.ALWAYS({"a": 1, "b": 2}) == True


# Generated at 2022-06-21 11:09:36.699083
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import dataclasses
    @dataclasses.dataclass
    class TestDataClass:
        test_field: str
    
    
    json_obj = {'test_field':'test_value'}
    data_cls = TestDataClass('test_value')
    
    
    
    # Test includes ALL fields
    json_str = dataclasses_json.dump(data_cls,include=Exclude.NEVER)
    assert not json_str
    
    # Test excludes ALL fields
    data_cls = dataclasses_json.load(json_obj,TestDataClass,exclude=Exclude.NEVER)
    
    assert isinstance(data_cls,TestDataClass)
    assert not data_cls.test_field

# Generated at 2022-06-21 11:09:45.173200
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class MyClass:
        _some_uuid: str
        _some_other_uuid: str
    config(exclude=lambda field: field.name.startswith('_'))(MyClass)
    assert MyClass._dc_metadata['dataclasses_json']['exclude'](MyClass, '_some_uuid')
    assert MyClass._dc_metadata['dataclasses_json']['exclude'](MyClass, '_some_other_uuid')



# Generated at 2022-06-21 11:09:47.087497
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS("hello") == True)
    assert(Exclude.ALWAYS(1) == True)


# Generated at 2022-06-21 11:10:08.619320
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from typing import Optional


# Generated at 2022-06-21 11:10:09.868813
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:10:12.488158
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Dummy field")
    assert Exclude.ALWAYS(123)
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS([1, 2, 3])


# Generated at 2022-06-21 11:10:17.510874
# Unit test for function config
def test_config():
    import marshmallow
    @config(
        encoder='json.dumps',
        decoder='json.loads',
        mm_field=marshmallow.fields.Integer(),
        letter_case='snake',
        undefined='EXCLUDE',
        exclude=lambda fn, _: fn != 'x',
    )
    @dataclass
    class Test:
        x: int = 1
        y: int = 2
        z: int = 3
    assert Test.schema().fields['x'].__class__.__name__ == 'Integer'
    assert Test.schema().fields['y'] is None
    assert Test.schema().fields['z'] is None
    assert Test.schema().__class__.__name__ == 'SchemaMeta'

# Generated at 2022-06-21 11:10:18.609526
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-21 11:10:19.354319
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-21 11:10:20.706349
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2)
    assert not Exclude.NEVER(2)

# Generated at 2022-06-21 11:10:27.863842
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses import dataclass
    from dataclasses_json.api import (
        config,
        DataClassJsonMixin,
        DataclassJsonMixin,
    )
    from dataclasses_json.undefined import Undefined


    @config(letter_case=config.CAMELCASE,  # type: ignore
            decoder=lambda s: s.upper(),
            encoder=lambda s: s.lower(),
            field_name='test',
            undefined=Undefined.RAISE,
            exclude=lambda n, f: n.startswith('_'),
            mm_field=fields.Str(attribute='test'),
            )
    class TestClass(DataClassJsonMixin):
        _test: str

    assert TestClass.__dataclass_json__

# Generated at 2022-06-21 11:10:32.422692
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # json is imported in dataclasses_json/__init__.py
    # assert global_config.json_module == json

# Generated at 2022-06-21 11:10:36.857864
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER = lambda _: False

    assert Exclude.NEVER(1)
    assert Exclude.NEVER(2)
    assert Exclude.NEVER(3)
    assert Exclude.NEVER(4)

# Generated at 2022-06-21 11:11:17.821532
# Unit test for constructor of class Exclude

# Generated at 2022-06-21 11:11:19.258416
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-21 11:11:23.450340
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(0))  # True
    print(Exclude.ALWAYS(1))  # True
    print(Exclude.ALWAYS(''))  # True
    print(Exclude.ALWAYS(' '))  # True


# Generated at 2022-06-21 11:11:24.706902
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  assert Exclude.ALWAYS("a") == True
  

# Generated at 2022-06-21 11:11:26.340408
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-21 11:11:28.956794
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == dict()
    assert global_config.decoders == dict()
    assert global_config.mm_fields == dict()


# Generated at 2022-06-21 11:11:29.477632
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    pass

# Generated at 2022-06-21 11:11:30.989981
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS("") is True)
    assert(Exclude.NEVER("") is False)

# Generated at 2022-06-21 11:11:32.350290
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    kevin = Exclude()
    assert kevin.ALWAYS(True)


# Generated at 2022-06-21 11:11:34.204572
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(3)


# Generated at 2022-06-21 11:13:06.194216
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    # test if init values are initialized
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}
    # test if getter of private property works
    assert gc.__dict__["_GlobalConfig__encoders"] == {}

# Generated at 2022-06-21 11:13:07.377588
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(2))     # Result: True


# Generated at 2022-06-21 11:13:09.043532
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  str="hello"
  assert(Exclude.NEVER(str) == False)


# Generated at 2022-06-21 11:13:11.883285
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-21 11:13:14.051116
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) is True


# Generated at 2022-06-21 11:13:16.217828
# Unit test for constructor of class Exclude
def test_Exclude():
    from pytest import raises
    with raises(Exception):
        Exclude.NOT_EXISTS



# Generated at 2022-06-21 11:13:18.736523
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = None # define object obj
    ex = Exclude()
    #assert(ex.NEVER(obj) == True)
    assert(ex.NEVER(obj) == False)

test_Exclude_NEVER()

# Generated at 2022-06-21 11:13:20.747860
# Unit test for constructor of class Exclude
def test_Exclude():
    testA = Exclude()
    assert testA.ALWAYS
    assert testA.NEVER

# Generated at 2022-06-21 11:13:21.494318
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-21 11:13:33.117796
# Unit test for function config
def test_config():
    def case(x, *, encoder=None, decoder=None, mm_field=None,
             letter_case=None, really_letter_case=None,
             undefined=None, really_undefined=None,
             field_name='field_name', exclude=None):
        return config(
            encoder=encoder,
            decoder=decoder,
            mm_field=mm_field,
            letter_case=letter_case,
            undefined=undefined,
            field_name=field_name,
            exclude=exclude,
        )

    assert case(1) == {'dataclasses_json': {}}
    assert case(2, encoder=int) == {'dataclasses_json': {'encoder': int}}