

# Generated at 2022-06-21 11:04:31.753078
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-21 11:04:41.729225
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import numpy as np
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

    # Test 1: exclude always false
    @dataclass
    class Test1(DataClassJsonMixin):
        value: int

        @classmethod
        def __json_exclude__(cls, name: str, value: np.ndarray) -> bool:
            return Exclude.NEVER(value)


    t = Test1(10)
    # Test1 should output {'value': 10}
    print(t.to_json())

    # Test2: exclude always true
    @dataclass
    class Test2(DataClassJsonMixin):
        value: int


# Generated at 2022-06-21 11:04:47.126493
# Unit test for function config
def test_config():
    @dataclass
    @config(undefined=Undefined.RAISE, exclude=Exclude.ALWAYS)
    class Config:
        a: int
        b: dict

    assert Config._config.undefined == Undefined.RAISE
    assert Config._config.exclude == Exclude.ALWAYS


# Generated at 2022-06-21 11:04:58.829235
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Bugfix:
    #   gc = _GlobalConfig()
    #   gc.encoders = {int: {int: int}}
    #   gc.decoders = {int: {int: int}}
    #   gc.mm_fields = {int: {int: int}}
    #   print(gc.encoders)
    #   print(gc.decoders)
    #   print(gc.mm_fields)
    # Results:
    #   # but the output is all {int: int}, instead of {int: {int: int}}.
    #
    # Solution:
    #   The member variables should be initialized with {}
    gc = _GlobalConfig()
    gc.encoders = {int: {int: int}}

# Generated at 2022-06-21 11:05:10.443362
# Unit test for function config
def test_config():
    import marshmallow as ma
    from marshmallow.fields import Field as MMField

    # TODO: These should be the same kind of functions
    @config(encoder=int)
    class MyInt: pass

    @config(encoder=float)
    class MyFloat: pass

    @config(encoder=str)
    class MyStr: pass

    @config()
    class MyDefault: pass

    assert global_config.encoders[MyInt] == int
    assert global_config.encoders[MyFloat] == float
    assert global_config.encoders[MyStr] == str
    assert global_config.encoders[MyDefault] == None

    @config(mm_field=ma.fields.Int)
    class MyIntField: pass


# Generated at 2022-06-21 11:05:13.091523
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(exclude=True) == {
        'dataclasses_json': {'exclude': True}
    }

# Generated at 2022-06-21 11:05:22.986695
# Unit test for function config
def test_config():
    from unittest.mock import Mock, call
    import dataclasses

    letter_case = Mock()
    decoder = Mock()
    encoder = Mock()
    mm_field = Mock()
    exclude = Mock()
    undefined = Mock()

    @dataclasses.dataclass
    class MyClass:
        a: str
        b: bool

        decoder = decoder
        encoder = encoder
        mm_field = mm_field
        field_name = "stuff"
        letter_case = letter_case
        undefined = undefined
        exclude = exclude


# Generated at 2022-06-21 11:05:30.125873
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    class MyClass:
        field: str = 'field'
        my_field: str = 'my_field'
        _field: str = '_field'
    assert config(field_name='field')(MyClass) == {'dataclasses_json' : {'field_name' : 'field'}}
    assert config(letter_case=config.camelcase)(MyClass)['dataclasses_json']['letter_case']('test') == 'test'
    assert config(encoder=str)(MyClass) == {'dataclasses_json': {'encoder': str}}
    assert config(decoder=str)(MyClass) == {'dataclasses_json': {'decoder': str}}

# Generated at 2022-06-21 11:05:31.803354
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-21 11:05:32.346252
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude = Exclude()

# Generated at 2022-06-21 11:05:36.439923
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # arrange
    a = Exclude.NEVER
    b = []
    # act
    # assert
    assert a(b) == False

# Generated at 2022-06-21 11:05:37.421737
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-21 11:05:40.406506
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)


# Generated at 2022-06-21 11:05:42.608609
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER(Exclude.NEVER)
    assert not Exclude.ALWAYS(Exclude.ALWAYS)

# Generated at 2022-06-21 11:05:45.010808
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)
test_Exclude()

# Generated at 2022-06-21 11:05:52.041964
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1)==True)
    assert(Exclude.ALWAYS(True)==True)
    assert(Exclude.ALWAYS(False)==True)
    assert(Exclude.ALWAYS(3.14)==True)
    assert(Exclude.ALWAYS('a')==True)
    assert(Exclude.ALWAYS((1, 2, 3))==True)
    assert(Exclude.ALWAYS({'one': 1, 'two': 2, 'three': 3})==True)
    assert(Exclude.ALWAYS([1, 2, 3, 4, 5])==True)


# Generated at 2022-06-21 11:05:56.259833
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("b") == False



# Generated at 2022-06-21 11:05:57.577304
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-21 11:06:03.027083
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude_default = config()
    assert exclude_default["dataclasses_json"]["exclude"] == Exclude.NEVER

    def is_odd_number(number):
        return number % 2 == 1

    exclude_odd_number = config(exclude=is_odd_number)
    assert exclude_odd_number["dataclasses_json"]["exclude"] == is_odd_number



# Generated at 2022-06-21 11:06:03.929576
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER)

# Generated at 2022-06-21 11:06:17.515040
# Unit test for function config
def test_config():
    import dataclasses
    import json
    import marshmallow

    @dataclasses.dataclass
    class A:
        @classmethod
        def encoder(cls, o):
            return o.name

        @classmethod
        def decoder(cls, s):
            return A(s)

        name: str = dataclasses.field(default="world",
                                      metadata=config(
                                          encoder=encoder,
                                          decoder=decoder,
                                      ))
    assert '{"name":"world"}' == json.dumps(A(), default=A.encoder)
    assert A("Tom") == json.loads('{"name":"Tom"}', object_hook=A.decoder)

    class B(marshmallow.Schema):
        name = marshmallow.fields.String()


# Generated at 2022-06-21 11:06:20.596963
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	dataclass = {'a': 1, 'b': 2, 'c': 3}

	Exclude.NEVER = lambda _: False
	assert Exclude.NEVER(dataclass)
	

# Generated at 2022-06-21 11:06:31.599151
# Unit test for function config
def test_config():
    class cls:
        pass
    c = cls()
    c.__annotations__ = {}
    c.__annotations__['a'] = str
    config(encoder=1, metadata=c.__annotations__)
    assert c.__annotations__['dataclasses_json']['encoder'] == 1
    config(exclude=Exclude.ALWAYS, metadata=c.__annotations__)
    assert c.__annotations__['dataclasses_json']['exclude'] == Exclude.ALWAYS
    config(undefined='exception', metadata=c.__annotations__)
    assert c.__annotations__['dataclasses_json']['undefined'] == Undefined.EXCEPTION
    config(undefined=Undefined.RAISE, metadata=c.__annotations__)
   

# Generated at 2022-06-21 11:06:34.782164
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:06:43.466679
# Unit test for function config
def test_config():
    """Tests that config returns a dict and that it accepts a param named
    undefined.
    """
    import dataclasses

    @dataclasses.dataclass
    class Person:
        name : str
        age : int

    @config(metadata=dict(exclude=Exclude.NEVER), undefined=Undefined.EXCLUDE)
    class Person:
        name : str
        age : int

    assert isinstance(Person.__annotations__['name'], dict)

    @config(undefined=Undefined.RAISE)
    class Person:
        name: str
        age: int


# TODO: add test with two classes with the same field name
# TODO: when setting default, remove all metadata, including other libs

# TODO: add ability to set encoder/decoder globally (e.g. dat

# Generated at 2022-06-21 11:06:44.605626
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-21 11:06:54.453541
# Unit test for function config
def test_config():
    from marshmallow import fields
    from typing import List
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    global_config.encoders[Person] = lambda x: "some string"
    global_config.decoders[Person] = lambda x: 3
    global_config.mm_fields[Person] = fields.String("not used")


# Generated at 2022-06-21 11:06:56.594773
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: int

    assert Exclude.NEVER(Foo) == False


# Generated at 2022-06-21 11:06:58.440091
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
     test_item = 1
     assert(Exclude.NEVER(test_item) == False)

# Generated at 2022-06-21 11:06:59.762271
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-21 11:07:15.535210
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS("test")

    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(1.0) == False
    assert Exclude.NEVER("test") == False

# Generated at 2022-06-21 11:07:18.421297
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def never(value:T):
        return Exclude.NEVER(value)
    assert never(1) == False
    assert never(0) == False


# Generated at 2022-06-21 11:07:24.847192
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class Foo():
        field_1: str = config(metadata=config(
            metadata=config(letter_case=lambda s: s.upper())))
        field_2: int = config(metadata=config(field_name="This Is Field 2"))

    assert Foo().field_1 == ''
    assert Foo().field_2 == 0
    assert dataclasses.asdict(Foo()) == {
        'FIELD_1': '',
        'This Is Field 2': 0,
    }
    assert dataclasses.asdict(Foo('a', -1)) == {
        'FIELD_1': 'a',
        'This Is Field 2': -1,
    }

# Generated at 2022-06-21 11:07:26.977150
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

test_Exclude()

# Generated at 2022-06-21 11:07:27.948275
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:07:40.331772
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class C:
        a: str
        b: str

    assert config(mm_field=str)['dataclasses_json']['mm_field'] == str
    assert config(field_name='n')['dataclasses_json']['letter_case']('_') == 'n'
    assert config(undefined='EXCLUDE')['dataclasses_json']['undefined'] == Undefined.EXCLUDE
    assert config(field_name='n', undefined='EXCLUDE')['dataclasses_json'] == {
        'letter_case': 'n',
        'undefined': Undefined.EXCLUDE
    }

    try:
        config(undefined='invalid')
    except UndefinedParameterError:
        assert True

# Generated at 2022-06-21 11:07:41.709451
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert Exclude.NEVER(1)

# Generated at 2022-06-21 11:07:44.256556
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  assert(Exclude.ALWAYS(1))
  assert(Exclude.ALWAYS('a'))
  assert(Exclude.ALWAYS(object()))


# Generated at 2022-06-21 11:07:47.183282
# Unit test for function config
def test_config():
    assert config(metadata={'x': 1}, encoder=int, decoder=float) == {
        'x': 1,
        'dataclasses_json': {'encoder': int, 'decoder': float}
    }

# Generated at 2022-06-21 11:07:48.515873
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:08:09.331535
# Unit test for function config
def test_config():
    """
    When config is called with a parameter, the value should be stored in the
    dict returned.
    """

    import pytest

    with pytest.raises(UndefinedParameterError):
        _ = config(undefined='wrong')
    with pytest.raises(UndefinedParameterError):
        _ = config(undefined='Wrong')
    with pytest.raises(UndefinedParameterError):
        _ = config(undefined='WrO')

    md = config(undefined='error')
    assert md['dataclasses_json']['undefined'] is Undefined.ERROR

    md = config(undefined='exclude')
    assert md['dataclasses_json']['undefined'] is Undefined.EXCLUDE

    md = config(undefined='include')

# Generated at 2022-06-21 11:08:10.691064
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(5))


# Generated at 2022-06-21 11:08:13.911759
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS) == True
    assert callable(Exclude.NEVER) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.NEVER("") == False

# Generated at 2022-06-21 11:08:17.030062
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude().NEVER()


global_config.encoders[Undefined] = Undefined.encode
global_config.decoders[Undefined] = Undefined.decode

# Generated at 2022-06-21 11:08:18.580456
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:08:20.456310
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-21 11:08:21.517031
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert Exclude.ALWAYS(4)==True

# Generated at 2022-06-21 11:08:22.550344
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    pass


# Generated at 2022-06-21 11:08:33.543261
# Unit test for function config

# Generated at 2022-06-21 11:08:38.073504
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config, _GlobalConfig)
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)

# Generated at 2022-06-21 11:09:10.810400
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    global_config2 = _GlobalConfig()
    assert global_config1.encoders != global_config2.encoders
    assert global_config1.decoders != global_config2.decoders
    assert global_config1.mm_fields != global_config2.mm_fields


# Generated at 2022-06-21 11:09:13.090269
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}
    # assert _GlobalConfig().json_module == json



# Generated at 2022-06-21 11:09:18.401607
# Unit test for function config
def test_config():
    from marshmallow import fields
    import datetime
    import enum
    @config(
        encoder=str,
        decoder=int,
        mm_field=fields.Integer,
        letter_case=lambda x: x.upper(),
        undefined=Undefined.EXCLUDE,
        field_name='override_name',
        exclude=lambda k, v: False,
    )
    class User:
        name: str

    from dataclasses_json.undefined import Undefined

# Generated at 2022-06-21 11:09:20.670230
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	print(Exclude.ALWAYS(20))


# Generated at 2022-06-21 11:09:31.646631
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    class LetterCase:
        @classmethod
        def upper_case(cls, s: str) -> str:
            return s.upper()

    @dataclass
    class User:
        username: str = config(letter_case=LetterCase.upper_case)

    @dataclass
    class User2:
        username: str
        password: str = config(exclude=Exclude.ALWAYS)

    @dataclass
    class User3:
        username: str
        password: str = config(undefined=Undefined.EXCLUDE)

    @dataclass
    class User4:
        username: str

# Generated at 2022-06-21 11:09:34.561788
# Unit test for constructor of class Exclude
def test_Exclude():
    if Exclude.ALWAYS(2) != True:
        raise RuntimeError("Exclude ALWAYS is not correct!")
    if Exclude.NEVER(3) != False:
        raise RuntimeError("Exclude NEVER is not correct!")

# Generated at 2022-06-21 11:09:35.737170
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(5) == True
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-21 11:09:37.313156
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    d = _GlobalConfig()
    assert d.encoders == {}
    assert d.decoders == {}
    assert d.mm_fields == {}

# Generated at 2022-06-21 11:09:49.021831
# Unit test for function config
def test_config():
    @dataclass
    @config(field_name='foo')
    class Foo:
        pass

    assert Foo.__dataclass_fields__['foo'].metadata == \
        {'dataclasses_json': {'field_name': 'foo'}}

    @dataclass
    @config(mm_field=fields.String)
    class Bar:
        pass

    assert Bar.__dataclass_fields__['bar'].metadata == \
        {'dataclasses_json': {'mm_field': fields.String()}}

    @dataclass
    @config(undefined=Undefined.RAISE)
    class Baz:
        pass

    assert Baz.__dataclass_fields__['baz'].metadata == \
        {'dataclasses_json': {'undefined': Undefined.RAISE}}

# Generated at 2022-06-21 11:09:50.033518
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is True

# Generated at 2022-06-21 11:10:57.009899
# Unit test for function config
def test_config():
    @dataclass
    class Config:
        data: str = field(metadata=config(undefined=Undefined.EXCLUDE))
        password: str = field(metadata=config(exclude=Exclude.ALWAYS))

    parsed = Config.schema().load({"data": "data"})
    assert parsed.data == "data"
    assert parsed.password is None

    parsed = Config.schema().load({"password": "password"})
    assert parsed.data == ""
    assert parsed.password is None


# Test for function config through class Config

# Generated at 2022-06-21 11:10:59.613799
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert not global_config.encoders
    assert not global_config.decoders
    assert not global_config.mm_fields


# Generated at 2022-06-21 11:11:01.343402
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a')
    assert not Exclude.NEVER('a')


# Generated at 2022-06-21 11:11:03.750506
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-21 11:11:05.372145
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:11:08.522065
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:11:12.231158
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(3.14)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS({"x": 42})


# Generated at 2022-06-21 11:11:13.189008
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-21 11:11:23.529206
# Unit test for function config
def test_config():
    from dataclasses import Field
    from marshmallow import fields
    from dataclasses_json.api import MmField, encode

    @config(encoder=str, decoder=int, letter_case=str.lower,
            mm_field=MmField)
    class Sample:
        data: int

        def __str__(self):
            return '{}'.format(self.data)

    sample = Sample(5)
    assert (encode(sample, type_hints=fields.Integer) == '5')
    # TODO: should the encoder be invoked here? Not sure.
    assert (encode(sample, type_hints=fields.Field) == '5')

    json = '{"data": 5}'
    expected = Sample(5)
    assert (encode(expected) == json)
    # TOD

# Generated at 2022-06-21 11:11:25.530759
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    #Arrange
    a = Exclude().ALWAYS
    b = lambda: True
    #Assert
    assert a == b


# Generated at 2022-06-21 11:13:44.830706
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config
    assert global_config.encoders
    assert global_config.decoders
    assert global_config.mm_fields


# Generated at 2022-06-21 11:13:48.439981
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-21 11:13:49.905425
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)

# Generated at 2022-06-21 11:13:51.583729
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('obj') == True


# Generated at 2022-06-21 11:13:55.936010
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}


# Generated at 2022-06-21 11:14:01.952506
# Unit test for function config
def test_config():
    cls = type('Cls', (), {})
    cls.__annotations__ = {}

    assert config(cls.__annotations__) == {}

    cls.__annotations__ = config(cls.__annotations__, field_name='test_name')
    assert config(cls.__annotations__) == {'dataclasses_json': {'field_name': 'test_name'}}



# Generated at 2022-06-21 11:14:04.949456
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(4))


# Generated at 2022-06-21 11:14:07.798592
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    assert c.encoders == {}
    assert c.decoders == {}
    assert c.mm_fields == {}



# Generated at 2022-06-21 11:14:11.356767
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(-1)


# Generated at 2022-06-21 11:14:12.454796
# Unit test for constructor of class Exclude
def test_Exclude():
  assert Exclude.ALWAYS("hello")
  assert Exclude.NEVER("hello")