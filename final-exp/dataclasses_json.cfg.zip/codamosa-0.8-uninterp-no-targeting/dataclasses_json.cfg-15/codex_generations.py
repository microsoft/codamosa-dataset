

# Generated at 2022-06-21 11:04:31.962261
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config is not None


# Generated at 2022-06-21 11:04:33.378163
# Unit test for constructor of class Exclude
def test_Exclude():
  exclude = Exclude()
  assert exclude is not None

# Generated at 2022-06-21 11:04:34.702930
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a') is True


# Generated at 2022-06-21 11:04:37.661077
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    assert conf.encoders == {}
    assert conf.decoders == {}
    assert conf.mm_fields == {}


# Generated at 2022-06-21 11:04:38.943679
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-21 11:04:39.786632
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:04:52.008923
# Unit test for function config
def test_config():
    metadata = config()
    assert metadata['dataclasses_json'] == {}

    enc = lambda *args: None
    metadata = config(encoder=enc)
    assert metadata['dataclasses_json']['encoder'] == enc

    dec = lambda *args: None
    metadata = config(decoder=dec)
    assert metadata['dataclasses_json']['decoder'] == dec

    enc = lambda *args: None
    dec = lambda *args: None
    metadata = config(encoder=enc, decoder=dec)
    assert metadata['dataclasses_json']['encoder'] == enc
    assert metadata['dataclasses_json']['decoder'] == dec

    mm = lambda *args: None
    metadata = config(mm_field=mm)

# Generated at 2022-06-21 11:04:56.277154
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude().NEVER(1) == False
    assert Exclude().NEVER(None) == False
    assert Exclude().NEVER('') == False
    assert Exclude().NEVER(True) == False


# Generated at 2022-06-21 11:05:01.900662
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("A") == False
    assert Exclude.NEVER("B") == False
    assert Exclude.NEVER("C") == False
    assert Exclude.NEVER("D") == False
    assert Exclude.NEVER("E") == False
    assert Exclude.NEVER("F") == False


# Generated at 2022-06-21 11:05:03.508984
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2)
    assert not Exclude.NEVER(2)

# Generated at 2022-06-21 11:05:10.277896
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    for i in range(50):
        assert Exclude.ALWAYS(i)


# Generated at 2022-06-21 11:05:14.957238
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

    assert(global_config.encoders == {})
    assert(global_config.decoders == {})
    assert(global_config.mm_fields == {})
    # assert(global_config._json_module == json)


# Generated at 2022-06-21 11:05:23.137198
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        foo: str
        bar: int

    assert config(Foo) == {}

    # Invalid parameters
    # TODO

    # TODO: test the rest
    # Valid parameters
    assert config(Foo, encoder=lambda x: x, decoder=lambda x: x) is not None
    assert config(Foo, mm_field=int) is not None
    assert config(Foo, letter_case=lambda x: x.upper()) is not None
    assert config(Foo, undefined=Undefined.RAISE) is not None
    assert config(Foo, exclude=lambda x, _: x == "bar") is not None

# Generated at 2022-06-21 11:05:30.983247
# Unit test for function config
def test_config():
    import marshmallow as mm
    from marshmallow.fields import Str
    from dataclasses import dataclass, field

    @dataclass
    class TestConfig(object):

        string: str = field(metadata=config(
            encoder=str.upper,
            decoder=str.lower,
            mm_field=Str(missing="", allow_none=True),
            letter_case=lambda s: s.replace("_", "-"),
            undefined=Undefined.RAISE,
            exclude=Exclude.ALWAYS
        ))

        # TODO: test field_name

    assert global_config.encoders[TestConfig.string.type] == str.upper
    assert global_config.decoders[TestConfig.string.type] == str.lower
    assert global_config.mm_fields[TestConfig.string.type]

# Generated at 2022-06-21 11:05:35.569919
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json
    #
    # global_config.json_module = ujson
    # assert global_config.json_module == ujson


# Generated at 2022-06-21 11:05:41.002130
# Unit test for function config
def test_config():
    import dataclasses
    import pytest

    @dataclasses.dataclass
    class Sample(object):
        name: str = config(field_name='name')
        value: str = config(encoder=int, decoder=str)

    s = Sample()
    assert dataclasses.asdict(s) == {'name': 'name'}
    assert dataclasses.asdict(s) == {'value': 'value'}

    with pytest.raises(UndefinedParameterError):
        @dataclasses.dataclass
        class Sample(object):
            name: str = config(undefined='error')

# Generated at 2022-06-21 11:05:43.211748
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    assert Exclude.NEVER is not None
    assert Exclude.NEVER(True) is False

# Generated at 2022-06-21 11:05:44.211789
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER

# Generated at 2022-06-21 11:05:45.760001
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    flag = Exclude.ALWAYS(42)
    assert flag == True


# Generated at 2022-06-21 11:05:48.243774
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-21 11:05:54.721254
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)


# Generated at 2022-06-21 11:05:56.587109
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False, "never return false"



# Generated at 2022-06-21 11:05:58.319658
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude = Exclude()
    assert exclude.ALWAYS(1)
    assert not exclude.NEVER(1)

# Generated at 2022-06-21 11:05:59.966027
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-21 11:06:03.290281
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_object = _GlobalConfig()
    assert len(test_object.encoders) == 0
    assert len(test_object.decoders) == 0
    assert len(test_object.mm_fields) == 0


# Generated at 2022-06-21 11:06:05.972001
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert a != None
    assert a.encoders == {}
    assert a.decoders == {}
    assert a.mm_fields == {}



# Generated at 2022-06-21 11:06:10.333940
# Unit test for constructor of class Exclude
def test_Exclude():
    # Test for Exclude.ALWAYS
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True

    # Test for Exclude.NEVER
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-21 11:06:12.448945
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.NEVER(None) is False
    

# Generated at 2022-06-21 11:06:14.340254
# Unit test for constructor of class Exclude
def test_Exclude():
	this = Exclude()
	assert this == 0
	assert this is not None
	assert this is not False

# Generated at 2022-06-21 11:06:17.385977
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_config = _GlobalConfig()
    # Test
    assert test_config.encoders == {}
    assert test_config.decoders == {}
    assert test_config.mm_fields == {}

# Generated at 2022-06-21 11:06:25.736622
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-21 11:06:27.790279
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('Max')
    assert Exclude.NEVER(1)


# Generated at 2022-06-21 11:06:31.395750
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.decoders = {int: int}
    global_config.encoders = {int: int}
    assert global_config.decoders == {int: int}
    assert global_config.encoders == {int: int}

# Generated at 2022-06-21 11:06:34.563207
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:06:37.297685
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert(config.encoders == {})
    assert(config.decoders == {})
    assert(config.mm_fields == {})


# Generated at 2022-06-21 11:06:43.218283
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    if Exclude.ALWAYS(1) != True:
        print("test_Exclude_ALWAYS: Error")
    elif Exclude.ALWAYS("test") != True:
        print("test_Exclude_ALWAYS: Error")
    elif Exclude.ALWAYS(True) != True:
        print("test_Exclude_ALWAYS: Error")
    elif Exclude.ALWAYS(0) != True:
        print("test_Exclude_ALWAYS: Error")
    else:
        print("test_Exclude_ALWAYS: OK")


# Generated at 2022-06-21 11:06:45.481823
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest
    test_value = 5
    assert Exclude.NEVER(test_value) == False 
    

# Generated at 2022-06-21 11:06:46.911877
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a')


# Generated at 2022-06-21 11:06:48.464957
# Unit test for constructor of class Exclude
def test_Exclude():
    # Test pre-defined constant ALWAYS
    decoded = Exclude.ALWAYS("_")
    assert decoded
    # Test pre-defined constant NEVER
    decoded = Exclude.NEVER("_")
    assert not decoded


# Generated at 2022-06-21 11:06:55.456763
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class A:
        @config()
        def default_encode(obj):
            print("default encode")
        @config()
        def default_decode(obj):
            print("default decode")

    @dataclass
    class B:
        @config(encoder = None)
        def encode_None(obj):
            print("encode None")
        @config(decoder = None)
        def decode_None(obj):
            print("decode None")

    @dataclass
    class C:
        @config(encoder = Exclude.ALWAYS)
        def encode_ALWAYS(obj):
            print("encode ALWAYS")
        @config(decoder = Exclude.ALWAYS)
        def decode_ALWAYS(obj):
            print

# Generated at 2022-06-21 11:07:11.842061
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    a = Exclude.NEVER(5)
    assert a == False, "Exclude.NEVER fail"


# Generated at 2022-06-21 11:07:13.531525
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    obj = {}
    assert Exclude.ALWAYS(obj)


# Generated at 2022-06-21 11:07:14.103764
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("hello") is False


# Generated at 2022-06-21 11:07:16.964261
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    my_config = _GlobalConfig()
    assert my_config.encoders == {}
    assert my_config.decoders == {}
    assert my_config.mm_fields == {}

# Test for function config

# Generated at 2022-06-21 11:07:27.500846
# Unit test for function config
def test_config():

    import dataclasses

    import marshmallow

    # Test always exclude
    @dataclasses.dataclass
    class TestDcAlways:
        a: int = dataclasses.field(metadata=config(exclude=Exclude.ALWAYS))
        b: int = dataclasses.field(metadata=config(exclude=lambda field: True))

    # Test never exclude
    @dataclasses.dataclass
    class TestDcNever:
        c: int = dataclasses.field(metadata=config(exclude=Exclude.NEVER))
        d: int = dataclasses.field(metadata=config(exclude=lambda field: False))

    # Test custom exclude

# Generated at 2022-06-21 11:07:39.808085
# Unit test for function config
def test_config():
    @dataclass
    class Test:
        name: str

        def test_mm_field(self, mm_field):
            assert mm_field == Test.mm_field

        @classmethod
        def test_encoder(self, encoder):
            assert encoder == Test.encoder

        @classmethod
        def test_decoder(self, decoder):
            assert decoder == Test.decoder

        @classmethod
        def test_letter_case(self, letter_case):
            assert letter_case == Test.letter_case

        @classmethod
        def test_undefined(self, undefined):
            assert undefined == Test.undefined

        @classmethod
        def test_exclude(self, exclude):
            assert exclude == Test.exclude


    mm_field = MarshmallowField()

# Generated at 2022-06-21 11:07:41.943272
# Unit test for constructor of class Exclude
def test_Exclude():
    ALWAYS = Exclude.ALWAYS
    NEVER = Exclude.NEVER
    assert ALWAYS(1)
    assert NEVER(1)

# Generated at 2022-06-21 11:07:44.115757
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    if Exclude.ALWAYS("str"):
        print("True")
    else:
        print("False")
    return


# Generated at 2022-06-21 11:07:47.064502
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(1000) == False
    assert Exclude.NEVER(10.1) == False


# Generated at 2022-06-21 11:07:50.232109
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    ALWAYS = Exclude.ALWAYS
    assert ALWAYS(None) is True
    assert ALWAYS(1) is True
    assert ALWAYS("a") is True
    assert ALWAYS(Exclude) is True


# Generated at 2022-06-21 11:08:27.891469
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(mm_field=None) == {
        'dataclasses_json': {'mm_field': None}}
    assert config(mm_field=None, decoder=None) == {
        'dataclasses_json': {'mm_field': None, 'decoder': None}}
    assert config(mm_field=None, decoder=None, letter_case=None) == {
        'dataclasses_json': {'mm_field': None, 'decoder': None,
                             'letter_case': None}}

# Generated at 2022-06-21 11:08:28.925607
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-21 11:08:31.976810
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def testa(m):
        assert Exclude.NEVER(m) == False
    testa('')
    testa('123')
    testa('123hello')

# Generated at 2022-06-21 11:08:36.130012
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    # assert config._json_module == json
    # config.json_module = simplejson
    # assert config._json_module == simplejson

# Generated at 2022-06-21 11:08:38.537812
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS({}) == True
    assert Exclude.NEVER({}) == False

# Generated at 2022-06-21 11:08:48.044307
# Unit test for function config
def test_config():
    def my_decoder(x):
        return int(x)

    def my_encoder(x):
        return str(x)

    class MyField(MarshmallowField):
        pass

    c = config(encoder=my_encoder, decoder=my_decoder,
               mm_field=MyField, letter_case=str.upper, undefined=Undefined.EXCLUDE,
               include=lambda x, y: False)
    

# Generated at 2022-06-21 11:08:53.661281
# Unit test for constructor of class Exclude
def test_Exclude():
    # Test the class name
    assert Exclude.__name__ == "Exclude"

    # Test the first constant
    ALWAYS = Exclude.ALWAYS
    assert ALWAYS.__name__ == "ALWAYS"
    assert ALWAYS(None) == True
    assert ALWAYS(1) == True
    assert ALWAYS(False) == True
    assert ALWAYS([1, 2, 3, 4]) == True
    assert ALWAYS({'a': 1, 'b': 2}) == True
    assert ALWAYS({"x": "hello", 'y': "world"}) == True
    assert ALWAYS(set()) == True
    assert ALWAYS(set([1, 2, 3, 4])) == True
    assert ALWAYS(set(["a", "b", "c", "d"])) == True
    assert ALWAYS(range(5)) == True
    assert ALWAYS(range(10, 15))

# Generated at 2022-06-21 11:08:56.957665
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest

    @config(exclude=Exclude.NEVER)
    @dataclass
    class Example:
        a: str

    ex = Example('hello')
    assert ex.to_dict() == {'a' : 'hello'}



# Generated at 2022-06-21 11:08:59.734274
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-21 11:09:04.686660
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS(object()) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(1.0) == True


# Generated at 2022-06-21 11:10:01.760310
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Thing") == True


# Generated at 2022-06-21 11:10:11.809012
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config
    import marshmallow as ma

    @dataclass
    @config(field_name="f_name")
    class Foo:
        f_name: str

    assert Foo.__dataclass_metadata__['dataclasses_json']['field_name']() == "f_name"

    @dataclass
    @config(encoder=lambda _: 1)
    class Foo:
        f_name: str

    assert Foo.__dataclass_metadata__['dataclasses_json']['encoder'](0) == 1

    @dataclass
    @config(decoder=lambda _: 1)
    class Foo:
        f_name: str

    assert Foo.__dataclasses_json__['decoder'](None)

# Generated at 2022-06-21 11:10:17.320202
# Unit test for function config
def test_config():
    assert config(undefined=Undefined.EXCLUDE) == {
        'dataclasses_json': {
            'undefined': Undefined.EXCLUDE,
        }
    }
    assert config(undefined="Raise") == {
        'dataclasses_json': {
            'undefined': Undefined.RAISE,
        }
    }
    assert config(undefined="Untouched") == {
        'dataclasses_json': {
            'undefined': Undefined.UNTOUCHED,
        }
    }
    assert config(undefined="Ignore") == {
        'dataclasses_json': {
            'undefined': Undefined.IGNORE,
        }
    }

# Generated at 2022-06-21 11:10:19.935987
# Unit test for function config
def test_config():
    assert config() == {
        'dataclasses_json': {},
    }

    assert config(encoder=int) == {
        'dataclasses_json': {
            'encoder': int,
        },
    }

# Generated at 2022-06-21 11:10:21.010619
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('_') == True


# Generated at 2022-06-21 11:10:25.875366
# Unit test for function config
def test_config():
    import unittest

    @dataclass
    class Test:
        a: int = field(metadata=config(encoder=float))

    class TestConfig(unittest.TestCase):
        def test_config(self):
            self.assertEqual(float, Test.a.metadata['dataclasses_json']['encoder'])

    unittest.main()


# Unit test
if __name__ == '__main__':
    test_config()

# Generated at 2022-06-21 11:10:36.302566
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined

    @dataclass
    class User:
        user_id: int
        name: str

    config(exclude=Exclude.ALWAYS)(User)

    assert User.__dataclass_json__['exclude'] == Exclude.ALWAYS
    assert User.__dataclass_json__['undefined'] == Undefined.RAISE

    config(exclude=Exclude.NEVER, undefined=Undefined.EXCLUDE)(User)

    assert User.__dataclass_json__['exclude'] == Exclude.NEVER
    assert User.__dataclass_json__['undefined'] == Undefined.EXCLUDE



# Generated at 2022-06-21 11:10:37.254895
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-21 11:10:45.356136
# Unit test for function config

# Generated at 2022-06-21 11:10:51.841207
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # type: () -> None
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('not empty') == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS(0.0) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(0.0) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-21 11:13:02.578335
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert(global_config != None)

# Generated at 2022-06-21 11:13:03.921876
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("")
    assert Exclude.NEVER("")


# Generated at 2022-06-21 11:13:11.418510
# Unit test for function config
def test_config():
    import pytest
    from marshmallow import ValidationError
    from marshmallow.fields import String, Integer
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        a: str = config().field_name('b')
        b: int = config().mm_field(String(required=True))
        c: int = config(undefined=Undefined.EXCLUDE)
        d: str = config(undefined=Undefined.REQUIRE)
        e: str = config().exclude(Exclude.ALWAYS)

        @property
        def f(self):
            return self.a

    with pytest.raises(ValidationError):
        A().to_json()


# Generated at 2022-06-21 11:13:21.226960
# Unit test for function config
def test_config():
    assert config() == { 'dataclasses_json': {} }
    assert config(encoder=1) == { 'dataclasses_json': { 'encoder': 1 } }
    assert config(decoder=2) == { 'dataclasses_json': { 'decoder': 2 } }
    assert config(mm_field=3) == { 'dataclasses_json': { 'mm_field': 3 } }
    assert config(letter_case=4) == { 'dataclasses_json': { 'letter_case': 4 } }
    assert config(undefined=5) == { 'dataclasses_json': { 'undefined': 5 } }
    assert config(exclude=6) == { 'dataclasses_json': { 'exclude': 6 } }

# Generated at 2022-06-21 11:13:21.903804
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("Test")

# Generated at 2022-06-21 11:13:23.327333
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude()
    assert(isinstance(obj, Exclude))
    assert(obj.NEVER("abc") == False)

# Generated at 2022-06-21 11:13:29.374389
# Unit test for function config
def test_config():
    @dataclass
    class Test:
        value: int = 6
        value2: int = 7

    assert Test().value2 == Test().value2

# Generated at 2022-06-21 11:13:38.139496
# Unit test for function config
def test_config():
    @dataclass
    class TestClass:
        field: str

    assert config() == {'dataclasses_json': {}}
    assert config(encoder={}) == {'dataclasses_json': {'encoder': {}}}

# Generated at 2022-06-21 11:13:40.758775
# Unit test for constructor of class Exclude
def test_Exclude():
    '''
    This test will create the Exclude class without errors because 
    the constructor of Exclude class is empty.
    '''
    e = Exclude()

# Generated at 2022-06-21 11:13:42.406990
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False
