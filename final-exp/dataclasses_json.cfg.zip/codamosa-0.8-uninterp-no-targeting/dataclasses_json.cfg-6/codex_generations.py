

# Generated at 2022-06-21 11:04:27.771031
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestClass:
        def __init__(self, x):
            self.x = x

    Exclude.NEVER = Exclude.NEVER(TestClass(1))
    assert Exclude.NEVER == False


# Generated at 2022-06-21 11:04:30.666958
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-21 11:04:31.674769
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Test Constructor
    _GlobalConfig()

# Generated at 2022-06-21 11:04:33.793754
# Unit test for constructor of class Exclude

# Generated at 2022-06-21 11:04:35.157064
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert not Exclude.NEVER(True)

# Generated at 2022-06-21 11:04:36.099501
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(_GlobalConfig().encoders) == 0

# Generated at 2022-06-21 11:04:37.230675
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-21 11:04:44.502879
# Unit test for function config
def test_config():
    from dataclasses_json.undefined import Undefined
    from enum import Enum
    class LetterCase(Enum):
        Lower = str.lower
        Upper = str.upper
        Capitalize = str.capitalize
    class Meta:
        pass
    class Test:
        pass
    a = Test()
    # assert a.__class__.__dict__["_metadata"]["dataclasses_json"]["letter_case"](
    #     "first_name") == "first_name"
    config(Meta, letter_case=LetterCase.Upper.value)
    # assert a.__class__.__dict__["_metadata"]["dataclasses_json"]["letter_case"](
    #     "first_name") == "FIRST_NAME"

# Generated at 2022-06-21 11:04:57.101169
# Unit test for function config
def test_config():
    from marshmallow import fields as mm_fields
    import uuid

    # Simple fields
    @dataclass_json
    @dataclass
    class MyClass:
        uuid_object: uuid.UUID = dataclass_json.config(
            undefined=Undefined.EXCLUDE,
            mm_field=mm_fields.UUID(attribute='uuid_object')
        )
        int_object: int = dataclass_json.config(
            mm_field=mm_fields.Integer(attribute='int_object')
        )

        def __post_init__(self):
            self.uuid = self.uuid_object
            self.int = self.int_object

    u = uuid.uuid4()
    m = MyClass(uuid_object=u, int_object=1)

# Generated at 2022-06-21 11:04:58.357619
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:05:02.869300
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    C = config(exclude=Exclude.NEVER)
    assert type(C['dataclasses_json']['exclude']) == types.FunctionType

# Generated at 2022-06-21 11:05:04.201582
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-21 11:05:04.875896
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS()
    assert not Exclude.NEVER()

# Generated at 2022-06-21 11:05:10.842816
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import hypothesis.strategies as st
    import hypothesis.extra.pytestplugin as pt
    from hypothesis.stateful import RuleBasedStateMachine, rule, invariant

    class MyStateMachine(RuleBasedStateMachine):
        @rule()
        def my_rule(self):
            ret = Exclude.NEVER(None)
            assert ret == False

    state_machine = MyStateMachine.TestCase

    state_machine.run_test(st.integers(), n=pt.max_examples(10))


# Generated at 2022-06-21 11:05:15.211297
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-21 11:05:19.814410
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    f = Exclude.ALWAYS
    assert f(1) == True
    assert f(None) == True
    assert f((1, 2, 3)) == True
    assert f(1.0) == True
    assert f('EX') == True
    assert f('ABC') == True
    assert f(['A', 'B', 'C']) == True


# Generated at 2022-06-21 11:05:21.032153
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("arg") == False


# Generated at 2022-06-21 11:05:22.835122
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestClass:
        pass
    test_obj = TestClass()
    assert Exclude.NEVER(test_obj) is False

# Generated at 2022-06-21 11:05:26.488993
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    assert isinstance(conf.encoders, dict)
    assert isinstance(conf.decoders, dict)
    assert isinstance(conf.mm_fields, dict)
    # assert isinstance(conf._json_module, json)

# Tests for global_config

# Generated at 2022-06-21 11:05:31.212170
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({'a':1})
    assert Exclude.ALWAYS({'a':2})
    assert Exclude.ALWAYS({'b':1})
    assert Exclude.ALWAYS({'b':2, 'c':3})
    assert Exclude.ALWAYS({'b':2, 'd':4})
    assert Exclude.ALWAYS({'b':2, 'd':4})
    assert Exclude('a')

# Generated at 2022-06-21 11:05:34.893020
# Unit test for constructor of class Exclude
def test_Exclude():
    E = Exclude()
    assert E.ALWAYS is not None
    assert E.NEVER is not None

# Generated at 2022-06-21 11:05:38.753135
# Unit test for function config
def test_config():
    # Check that a valid action is accepted
    assert config(undefined='exclude')['dataclasses_json']['undefined'] == Undefined.EXCLUDE

    # Check that an invalid action raises an error
    with pytest.raises(UndefinedParameterError):
        config(undefined='wrongAction')

test_config()

# Generated at 2022-06-21 11:05:45.407536
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from dataclasses_json import config
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # TODO: add #180 to the above test
    # assert is_callable(global_config.json_module)


# Generated at 2022-06-21 11:05:47.756886
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert not Exclude.NEVER(True)
    assert not Exclude.NEVER(False)

# Generated at 2022-06-21 11:05:49.208791
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-21 11:05:50.451782
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert_equal(global_config.encoders, {})
    assert_equal(global_config.decoders, {})
    assert_equal(global_config.mm_fields, {})


# Generated at 2022-06-21 11:05:51.844582
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS(1))
    assert(not Exclude.NEVER(1))

# Generated at 2022-06-21 11:05:54.859133
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-21 11:05:57.801608
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    # assert config.json_module == json

# Generated at 2022-06-21 11:05:59.419449
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-21 11:06:04.172575
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert type(g.encoders) == dict
    assert type(g.decoders) == dict
    assert type(g.mm_fields) == dict
    # assert type(g.json_module) == dict

# Generated at 2022-06-21 11:06:14.022544
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class A:
        a: str = dataclasses.field(metadata=config(exclude=Exclude.ALWAYS))

    assert 'dataclasses_json' in A.__annotations__['a'].keys()
    assert 'exclude' in A.__annotations__['a']['dataclasses_json'].keys()
    assert A.__annotations__['a']['dataclasses_json']['exclude'] is Exclude.ALWAYS

    @dataclasses.dataclass
    class B:
        b: str = dataclasses.field(metadata=config(exclude=Exclude.NEVER))

    assert 'dataclasses_json' in B.__annotations__['b'].keys()

# Generated at 2022-06-21 11:06:20.463297
# Unit test for function config
def test_config():
    from .dataclass import dataclass

    @dataclass
    @config(letter_case=lambda s: s.upper())
    class Foo:
        x: str

    assert Foo.__dataclass_fields__['x'].metadata['dataclasses_json']['letter_case']('x') == 'X'

    @dataclass
    @config(undefined='raise')
    class Foo:
        x: str

    assert Foo.__dataclass_fields__['x'].metadata['dataclasses_json']['undefined'] == Undefined.RAISE

# Generated at 2022-06-21 11:06:22.885755
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-21 11:06:26.034955
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("field") == False
    assert Exclude.NEVER("field") == False
    assert Exclude.NEVER("field") == False


# Generated at 2022-06-21 11:06:27.140510
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-21 11:06:28.682681
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") == True


# Generated at 2022-06-21 11:06:30.183818
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(object) is True


# Generated at 2022-06-21 11:06:32.156260
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(5) == True
    assert Exclude.NEVER(6) == False

# Generated at 2022-06-21 11:06:35.212102
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}


# Generated at 2022-06-21 11:06:37.538167
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    f = lambda _: True
    assert Exclude.NEVER(f) == False



# Generated at 2022-06-21 11:06:38.632640
# Unit test for method NEVER of class Exclude

# Generated at 2022-06-21 11:06:42.759061
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    global_config.encoders = {str: str}
    assert global_config.encoders == {str: str}
    global_config.decoders = {str: str}
    assert global_config.decoders == {str: str}
    global_config.mm_fields = {str: str}
    assert global_config.mm_fields == {str: str}

# Generated at 2022-06-21 11:06:44.381842
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('Never')


# Generated at 2022-06-21 11:06:46.568387
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclasses.dataclass()
    class DataClass:
        a: str

    assert Exclude.NEVER(DataClass)

# Generated at 2022-06-21 11:06:54.039665
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(mm_field=fields.Integer, exclude=Exclude.ALWAYS)
    class SomeClass:
        a: int

    assert SomeClass.__dataclass_fields__['a'].metadata['dataclasses_json'] == {
        'mm_field': fields.Integer,
        'exclude': Exclude.ALWAYS
    }

    with pytest.raises(UndefinedParameterError):
        @dataclass
        @config(undefined='lol')
        class SomeClass:
            a: int

# Generated at 2022-06-21 11:06:55.595009
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, object)
    assert isinstance(Exclude.NEVER, object)

# Generated at 2022-06-21 11:06:58.397032
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    # assert config._json_module == json



# Generated at 2022-06-21 11:07:07.638467
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import unittest

    @dataclass
    class Example:
        a: int = 1

    class Test(unittest.TestCase):

        def test(self):
            self.assertEqual(
                dict(dataclasses_json=dict(
                    encoder=1,
                    decoder=2,
                    mm_field=3,
                    letter_case=lambda a: a,
                    undefined=Undefined.RAISE,
                    exclude=lambda a: a,
                )),
                config(
                    encoder=1,
                    decoder=2,
                    mm_field=3,
                    letter_case=lambda a: a,
                    undefined=Undefined.RAISE,
                    exclude=lambda a: a,
                ))

# Generated at 2022-06-21 11:07:08.867957
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config._GlobalConfig()

# Generated at 2022-06-21 11:07:11.535108
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-21 11:07:13.243164
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-21 11:07:14.984588
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:07:16.374677
# Unit test for constructor of class Exclude
def test_Exclude():
    f = Exclude.NEVER(1)
    assert f == False


# Generated at 2022-06-21 11:07:19.282515
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert isinstance(gc.encoders, dict)
    assert isinstance(gc.decoders, dict)
    assert isinstance(gc.mm_fields, dict)


# Generated at 2022-06-21 11:07:20.443021
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("any")



# Generated at 2022-06-21 11:07:31.180066
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Unit test for method NEVER of class Exclude")
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json import DataClassJsonMixin
    @dataclass
    class DcExample(DataClassJsonMixin):
        x: int
        y: str = None
        z: bool = False
        @config(exclude=Exclude.NEVER)
        def w(self):
            return self.x

    example = DcExample(10)
    assert example.x == 10
    assert example.to_json() == '{}'
    assert example.to_dict() == {}
    assert example.w is None


# Generated at 2022-06-21 11:07:31.833834
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-21 11:07:33.120938
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc") == False

# Generated at 2022-06-21 11:07:37.127209
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    class Class:
        field: str = exclude(PreDefine.NEVER, "field1")
    obj = Class(field="test")
    assert obj.field == "test"


# Generated at 2022-06-21 11:07:40.285693
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-21 11:07:41.606091
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:07:42.927669
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    ex = Exclude.ALWAYS(1)
    assert ex == True


# Generated at 2022-06-21 11:07:50.488898
# Unit test for function config
def test_config():
    # Use the same @config decorated function multiple times
    @config(letter_case=str.upper, exclude=Exclude.NEVER)
    @config(mm_field=MarshmallowField)
    @config(undefined=Undefined.RAISE, exclude=Exclude.ALWAYS)
    def function():
        pass

    assert function.__dataclass_json__["dataclasses_json"]["letter_case"] == str.upper
    assert function.__dataclass_json__["dataclasses_json"]["exclude"] == Exclude.ALWAYS
    assert function.__dataclass_json__["dataclasses_json"]["mm_field"] == MarshmallowField
    assert function.__dataclass_json__["dataclasses_json"]["undefined"] == Undefined.RAISE



# Generated at 2022-06-21 11:08:00.874797
# Unit test for function config
def test_config():
    # Mocking
    class _MockType(type):
        def __getattr__(self, item):
            return None

    class _MockClass(metaclass=_MockType):
        pass

    encoder = _MockClass()
    decoder = _MockClass()
    mm_field = _MockClass()

    # Testing
    assert config({},
                  encoder=encoder,
                  decoder=decoder,
                  mm_field=mm_field) == {
        'dataclasses_json': {
            'encoder': encoder,
            'decoder': decoder,
            'mm_field': mm_field
        }
    }

# Generated at 2022-06-21 11:08:04.630223
# Unit test for constructor of class Exclude
def test_Exclude():
    # test if the ALWAYS equals to a callable that takes one argument and returns
    # True
    assert callable(Exclude.ALWAYS)
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:08:14.627035
# Unit test for function config
def test_config():
    @dataclass
    class TestConfig:
        a: int
        b: int
        c: int
        _d: int

    assert config(field_name='_d') == {'dataclasses_json': {'field_name': '_d'}}
    assert config(letter_case='upper') == {'dataclasses_json': {'letter_case': 'upper'}}
    assert config(undefined='EXCLUDE') == {'dataclasses_json': {'undefined': Undefined.EXCLUDE}}
    assert config(exclude=Exclude.ALWAYS) == {'dataclasses_json': {'exclude': Exclude.ALWAYS}}

# Generated at 2022-06-21 11:08:17.073105
# Unit test for function config
def test_config():
    import pytest

    with pytest.raises(UndefinedParameterError):
        config(undefined='not valid')



# Generated at 2022-06-21 11:08:18.630947
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert not Exclude.NEVER
    assert Exclude()

# Generated at 2022-06-21 11:08:21.326526
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    try:
        _GlobalConfig()
    except NameError:
        assert False
    else:
        assert True


# Generated at 2022-06-21 11:08:34.701890
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import config
    import json
    import marshmallow as mm
    def _json_encoder(obj):
        if isinstance(obj, MyClass):
            return {"_type": "MyClass", "value": obj.value}
        return json.JSONEncoder.default(obj)
    def _json_decoder(obj):
        if "_type" in obj and obj["_type"] == "MyClass":
            return MyClass(obj["value"])
        return obj
    @dataclass
    class MyClass:
        value: str
        def __init__(self, value):
            self.value  = value

# Generated at 2022-06-21 11:08:36.226169
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('Hello') == True


# Generated at 2022-06-21 11:08:38.595939
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:08:40.599690
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from marshmallow.fields import Str
    config(encoder=str, decoder=eval, mm_field=Str())

# Generated at 2022-06-21 11:08:46.383983
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    _encoders: Dict[type, Callable] = {}
    _decoders: Dict[type, Callable] = {}
    _mm_fields: Dict[type, MarshmallowField] = {}
    assert global_config.encoders == _encoders
    assert global_config.decoders == _decoders
    assert global_config.mm_fields == _mm_fields


# Generated at 2022-06-21 11:08:49.833109
# Unit test for function config
def test_config():
    def always(_):
        return True

    # use a local value
    config(config(exclude=always)['dataclasses_json']['exclude'])

    # Configure globally for EVERYTHING
    config(exclude=always)
    test = config()['dataclasses_json']['exclude']
    assert callable(test)

# Generated at 2022-06-21 11:08:52.232498
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("") == True
    assert Exclude.NEVER("") == False


# Generated at 2022-06-21 11:08:53.191911
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-21 11:08:54.612943
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-21 11:08:56.917609
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1), "ALWAYS is a function that always return true"
    assert not Exclude.NEVER(1), "NEVER is a function that always return false"

# Generated at 2022-06-21 11:09:02.322213
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('string') is False

# Generated at 2022-06-21 11:09:05.155668
# Unit test for constructor of class Exclude
def test_Exclude():
    always = Exclude.ALWAYS
    never = Exclude.NEVER
    assert always(1) is True
    assert always(2) is True
    assert never(1) is False
    assert never(2) is False

# Generated at 2022-06-21 11:09:06.789649
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-21 11:09:08.851794
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # _GlobalConfig()
    # assert _GlobalConfig() == {}
    # TODO: is the below line working?
    assert global_config == {}

# Generated at 2022-06-21 11:09:15.994283
# Unit test for function config
def test_config():
    import pytest
    from dataclasses_json.metadata import _validate_metadata_config
    # noinspection PyPep8Naming
    class Test:
        def __init__(self, metadata: dict) -> None:
            self.metadata = metadata

        def __repr__(self) -> str:
            return str(self.metadata)

    @config(
        metadata=dict(bool_map={True: 1, False: 2}),
        exclude=Exclude.NEVER,
        field_name="abc",
        letter_case=lambda x: x.upper(),
        undefined=Undefined.EXCLUDE,
    )
    class TestClass(Test):
        pass


# Generated at 2022-06-21 11:09:17.266856
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)


# Generated at 2022-06-21 11:09:21.606104
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_conf = _GlobalConfig()

    assert global_conf.encoders == {}
    assert global_conf.decoders == {}
    assert global_conf.mm_fields == {}
    # assert global_conf._json_module == json

# Generated at 2022-06-21 11:09:23.441389
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert not Exclude.NEVER(True)



# Generated at 2022-06-21 11:09:26.277459
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-21 11:09:27.401264
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config


# Generated at 2022-06-21 11:09:42.121517
# Unit test for function config
def test_config():
    meta = {"dataclasses_json": {"letter_case": str.lower}}
    config(meta, letter_case=str.upper)
    assert meta == {"dataclasses_json": {"letter_case": str.upper}}

    meta = {"dataclasses_json": {"exclude": Exclude.ALWAYS}}
    config(meta, exclude=Exclude.NEVER)
    assert meta == {"dataclasses_json": {"exclude": Exclude.NEVER}}

# Generated at 2022-06-21 11:09:44.523728
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # GIVEN
    result1 = Exclude.ALWAYS('anything')
    # THEN
    assert result1 == True


# Generated at 2022-06-21 11:09:48.205980
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    from dataclasses import dataclass, field

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class SomeClass:
        a: str

    assert not hasattr(SomeClass, 'a')



# Generated at 2022-06-21 11:09:53.032380
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    
    @dataclass
    class Foo:
        x: int

# Generated at 2022-06-21 11:09:54.837208
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    a = Exclude()
    assert a.ALWAYS(1)

# Generated at 2022-06-21 11:09:56.490793
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)


# test that the constants ALWAYS and NEVER are different

# Generated at 2022-06-21 11:10:01.134495
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}


# Generated at 2022-06-21 11:10:11.033288
# Unit test for function config
def test_config():
    import pytest
    @dataclass
    @config(exclude=[])
    class A:
        a: int

    # Wrong exclude type
    with pytest.raises(UndefinedParameterError):
        @dataclass
        @config(exclude=(1,2,3))
        class A:
            a: int

    # Wrong undefine type
    with pytest.raises(UndefinedParameterError):
        @dataclass
        @config(undefined=1)
        class A:
            a: int

    # Undefined error
    @dataclass
    @config()
    class A:
        a: int
    with pytest.raises(UndefinedParameterError):
        A({})

    # Undefined error

# Generated at 2022-06-21 11:10:16.731728
# Unit test for function config
def test_config():
    assert config().get('dataclasses_json') is not None
    assert config(field_name='').get('dataclasses_json') is not None
    assert config(
        field_name='', letter_case='hello').get('dataclasses_json') is not None
    assert config(field_name='', letter_case='hello',
                  undefined='raise').get('dataclasses_json') is not None
    assert config(field_name='', letter_case='hello',
                  undefined='RAISE').get('dataclasses_json') is not None
    assert config(field_name='', letter_case='hello',
                  undefined=Undefined.RAISE).get('dataclasses_json') is not None

# Generated at 2022-06-21 11:10:18.714914
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    e = Exclude.NEVER
    assert e(1) == False
    assert e('') == False
    assert e(False) == False


# Generated at 2022-06-21 11:10:38.260297
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def cb(v):
        return v
    assert Exclude.NEVER(cb) == False

# Generated at 2022-06-21 11:10:38.848657
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-21 11:10:41.526229
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(3.14)
    assert Exclude.ALWAYS("str")


# Generated at 2022-06-21 11:10:46.908541
# Unit test for function config
def test_config():
    @dataclass
    class Test:
        a: int
        b: str
        c: str = field(metadata={'dataclasses_json': {'letter_case': lambda field_name: field_name.upper()}})

    t = Test(a=1, b="b", c="c")
    assert t.__dict__.keys() == {'a', 'b', 'c'}
    assert t.__dict__["c"] == "c"
    assert "c" not in t.to_dict().keys()
    assert "C" in t.to_dict().keys()
    assert t.to_dict()['C'] == "c"

# Generated at 2022-06-21 11:10:47.962752
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    raise Exception("Call from test before the program is running")

# Generated at 2022-06-21 11:10:50.148071
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    assert e.ALWAYS(1) == True
    assert e.NEVER(1) == False

# Generated at 2022-06-21 11:10:52.805813
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    print(global_config.encoders)
    print(global_config.decoders)
    print(global_config.mm_fields)

if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-21 11:10:53.761480
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(42) is False


# Generated at 2022-06-21 11:10:56.230016
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == dict()
    assert gc.decoders == dict()
    assert gc.mm_fields == dict()
    # For some reason, this does not work
    # assert gc.json_module == json


# Generated at 2022-06-21 11:10:58.089831
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3)
    assert not Exclude.NEVER(3)

if __name__ == '__main__':
    test_Exclude()

# Generated at 2022-06-21 11:11:36.128549
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a')
    assert not Exclude.NEVER('a')



# Generated at 2022-06-21 11:11:38.066131
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert(isinstance(global_config, _GlobalConfig))


# Generated at 2022-06-21 11:11:43.990489
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class User:
        id: int
        location: str
        name: str

        class Config:
            arbitrary_types_allowed = True
            encoder = int
            decoder = int
            field_name = "location"
            letter_case = None
    # TODO: alternatively, can generate JSONSchema and assert that it is a
    # dictionary

# Generated at 2022-06-21 11:11:45.646135
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config, _GlobalConfig)


# Generated at 2022-06-21 11:11:47.409087
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}

# Generated at 2022-06-21 11:11:48.785287
# Unit test for function config
def test_config():
    metadata = config(field_name="test")

    config(metadata=metadata, encoder=int)


test_config()

# Generated at 2022-06-21 11:11:57.843805
# Unit test for function config
def test_config():
    # Test basic config with no parameters
    @dataclass
    class Foo:
        foo: str
        bar: str = config()

    assert Foo.__annotations__['bar'] == {'dataclasses_json': {}}

    # Test config with encoder
    def encoder():
        pass

    @dataclass
    class Bar:
        foo: str
        bar: str = config(encoder=encoder)

    assert Bar.__annotations__['bar'] == {'dataclasses_json': {"encoder": encoder}}

    # Test config with decoder
    def decoder():
        pass

    @dataclass
    class Baz:
        foo: str
        bar: str = config(decoder=decoder)


# Generated at 2022-06-21 11:12:09.123940
# Unit test for function config
def test_config():
    class A:
        pass
    @dataclass
    class B(A):
        class Meta:
            pass
    assert config(metadata = A.__dict__)['dataclasses_json'] == {}
    assert config(metadata = B.__dict__)['dataclasses_json'] == {}

# Generated at 2022-06-21 11:12:12.601468
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(-2) == False
    assert Exclude.NEVER(12) == False


# Generated at 2022-06-21 11:12:13.497449
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("foo") == False


# Generated at 2022-06-21 11:13:34.169505
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS.__name__ == '<lambda>'


# Generated at 2022-06-21 11:13:35.633553
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():

    # Test simple encoding of a number
    assert global_config
    return


# Generated at 2022-06-21 11:13:36.713129
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) is False


# Generated at 2022-06-21 11:13:38.343314
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    my_obj = object()
    assert Exclude.NEVER(my_obj) == False


# Generated at 2022-06-21 11:13:41.750348
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-21 11:13:45.210345
# Unit test for function config
def test_config():
    assert config(encoder=int, exclude=Exclude.NEVER, undefined='strict') == \
        {'dataclasses_json': {'encoder': int, 'exclude': Exclude.NEVER, 'undefined': Undefined.STRICT}}

# Generated at 2022-06-21 11:13:53.213010
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class DC:
        val: int

    # Check an error is thrown if undefined parameter is invalid
    try:
        @dataclass
        class _:
            val: int = config(undefined='not a valid action')

        raise AssertionError(
            f"Invalid undefined parameter action should have raised error")
    except UndefinedParameterError:
        # This is the expected behavior
        pass

    # Check the undefined parameter is set
    @dataclass
    class _:
        val: int = config(undefined=Undefined.EXCLUDE)

    assert _.__dataclass_json__['undefined'] == Undefined.EXCLUDE

# Generated at 2022-06-21 11:13:59.733709
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1
    assert global_config1.encoders is not None
    assert global_config1.decoders is not None
    assert global_config1.mm_fields is not None
    # assert global_config1._json_module is not None


# Generated at 2022-06-21 11:14:01.768459
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS(3))
    assert callable(Exclude.NEVER(3))



# Generated at 2022-06-21 11:14:13.420450
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    from marshmallow_dataclass import class_schema

    @dataclass
    @config(mm_field=class_schema(
        metadata={'dataclasses_json': {'encoder': lambda x: x.as_dict}}))
    class SampleClass:
        # Notice the following line needed for the metaclass
        __dataclass_fields__ = None

        var1: int
        var2: str

    expected = {
        '__dataclass_fields__': None,
        'var1': 1,
        'var2': 'abc',
    }

    # Notice mm_field is set by default to be as_dict
    assert SampleClass(var1=1, var2='abc').as_dict() == expected


# Unit test: mixin with a @dat