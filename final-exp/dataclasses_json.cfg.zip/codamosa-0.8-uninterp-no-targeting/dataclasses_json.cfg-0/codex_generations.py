

# Generated at 2022-06-21 11:04:39.919979
# Unit test for function config
def test_config():
    """
    Test function config

    :return: None, assert if failed
    """
    # test all valid config
    meta = config(encoder=str, decoder=str, mm_field=str, letter_case=str,
                  undefined=Undefined.EXCLUDE, exclude=Exclude.ALWAYS)
    assert meta == {'dataclasses_json': {'encoder': str, 'decoder': str, 'mm_field': str,
                                         'letter_case': str, 'undefined': Undefined.EXCLUDE,
                                         'exclude': Exclude.ALWAYS}}

    # test undefined is an invalid value

# Generated at 2022-06-21 11:04:41.253972
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:04:52.813375
# Unit test for constructor of class Exclude
def test_Exclude():
    from dataclasses import dataclass

    @dataclass
    class Simple:
        a: int = 1
        b: int = 2
        c: int = 3
        x: float = 0.0
        y: float = 99.0
        z: float = 99.9

    a = Simple(1, 2, 3, 0.0, 99.0, 99.9)

    assert a.a == 1
    assert a.b == 2
    assert a.c == 3
    assert a.x == 0.0
    assert a.y == 99.0
    assert a.z == 99.9

    assert Exclude.ALWAYS(a) == True
    assert Exclude.NEVER(a) == False


# Generated at 2022-06-21 11:04:56.964879
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0.1)
    assert Exclude.ALWAYS(-1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("hello")


# Generated at 2022-06-21 11:04:58.512179
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-21 11:05:09.437810
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from marshmallow import fields

    @dataclass
    @config(exclude=Exclude.NEVER)
    class MyClass():
        a: str = field(metadata=config(exclude=Exclude.ALWAYS))
        b: int = field(metadata=config(exclude=Exclude.NEVER))

        class Meta:
            json_module = dict

    assert MyClass.__dataclasses_json__['exclude'] == Exclude.NEVER
    assert MyClass.a.__dataclasses_json__['exclude'] == Exclude.ALWAYS
    assert MyClass.b.__dataclasses_json__['exclude'] == Exclude.NEVER

# Generated at 2022-06-21 11:05:14.445934
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("11") == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("3") == True
    assert Exclude.ALWAYS("8") == True


# Generated at 2022-06-21 11:05:23.726622
# Unit test for function config
def test_config():
    import dataclasses
    import json

    @dataclasses.dataclass
    class Simple:
        a: str
        b: int

        class Config:
            encoder = lambda obj, encoders={} : f"Encode {obj.a} {obj.b}"
            decoder = lambda obj, decoders={} : "Decode"
            mm_field = object()
            undefined = Undefined.RAISE
            exclude = Exclude.ALWAYS

    data = Simple("a", 1)
    assert json.loads(json.dumps(data, cls=dataclasses_json.Encoder),
                     object_hook=dataclasses_json.decoder(cls=dataclasses_json.Decoder)) == "Decode"


if __name__ == "__main__":
    test_config()

# Generated at 2022-06-21 11:05:31.888036
# Unit test for function config
def test_config():
    import marshmallow
    @dataclasses.dataclass
    class Person:
        age: int
        name: str = dataclasses.field(
            metadata=config(
                mm_field=marshmallow.fields.Str()
            )
        )
        nickname: str = dataclasses.field(
            metadata=config(
                mm_field=marshmallow.fields.Str()
            )
        )
        happy: str = dataclasses.field(
            metadata=config(
                mm_field=marshmallow.fields.Str()
            )
        )

    schema = dataclasses_json.config.schema(marshmallow.Schema, person_schema=Person)

    person = Person(
        age=24,
        name='John Doe',
        nickname='Jack',
    )

# Generated at 2022-06-21 11:05:34.378630
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude_always = Exclude.ALWAYS(True)
    assert(exclude_always)
    exclude_never = Exclude.NEVER(True)
    assert not(exclude_never)

# Generated at 2022-06-21 11:05:40.925892
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("A") == True
    assert Exclude.NEVER("A") == False

# Generated at 2022-06-21 11:05:43.110864
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config, _GlobalConfig)


# Generated at 2022-06-21 11:05:50.147907
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from marshmallow import fields

    @dataclass
    class Foo:

        @classmethod
        def json_encoder(cls, obj: 'Bar'):
            pass

        @classmethod
        def json_decoder(cls, obj: 'Bar'):
            pass

        bar: 'Bar' = field(metadata=config(
            encoder=json_encoder,
            decoder=json_decoder,
            mm_field=fields.Field()
        ))


# Unit tests for class Exclude

# Generated at 2022-06-21 11:05:53.361445
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2.0)
    assert Exclude.ALWAYS('this should be included')

    assert not Exclude.NEVER(1)
    assert not Exclude.NEVER(2.0)
    assert not Exclude.NEVER('this should not be included')

# Generated at 2022-06-21 11:05:55.381999
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-21 11:06:05.234288
# Unit test for function config
def test_config():
    class TestClass:
        def __init__(self, message):
            self.message = message

        def __eq__(self, other):
            if isinstance(other, TestClass):
                return self.message == other.message
            return False

    class TestMessage:
        message: TestClass

    @dataclass_json()
    class TestEncoderDecoder(TestMessage):
        @staticmethod
        def dataclasses_json_encoder(obj):
            return obj

        @staticmethod
        def dataclasses_json_decoder(obj):
            return obj

    @dataclass_json()
    class TestLetterCase:
        @staticmethod
        def dataclasses_json_letter_case(some_var: str):
            return some_var


# Generated at 2022-06-21 11:06:06.757122
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) is True
    assert Exclude.NEVER(0) is False


# Generated at 2022-06-21 11:06:08.684987
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) is True
    assert Exclude.NEVER(3) is False


# Generated at 2022-06-21 11:06:12.818219
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    correc_input = Exclude.ALWAYS(42)
    incorrect_input = Exclude.ALWAYS('42')
    # assert correc_input == True
    assert correc_input
    assert correc_input == True
    # assert incorrect_input == False
    assert incorrect_input == False


# Generated at 2022-06-21 11:06:15.953314
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Check initial conditions
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

test__GlobalConfig()

# Generated at 2022-06-21 11:06:19.906617
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    print("test__GlobalConfig has been called")
    assert True

if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-21 11:06:30.840530
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    import json

    # Setting metadata
    @dataclass
    class ClassWithMeta:
        some_field: str = field(metadata=config(
            encoder=json.dumps,
            decoder=json.loads,
            mm_field=MarshmallowField(),
            undefined=Undefined.EXCLUDE,
            field_name="fish",
            letter_case=None,
            exclude=Exclude.ALWAYS
        ))

    # Settings in metadata

# Generated at 2022-06-21 11:06:34.830353
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0


# Generated at 2022-06-21 11:06:36.419552
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == dict()
    assert config.decoders == dict()
    assert config.mm_fields == dict()

# Generated at 2022-06-21 11:06:40.420466
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("Unit test for method ALWAYS of class Exclude")

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class C:
        a: int

    assert C.__dataclass_json__['exclude'] == Exclude.ALWAYS

    print("Passed")



# Generated at 2022-06-21 11:06:44.347473
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert isinstance(global_config_.encoders, dict)
    assert isinstance(global_config_.decoders, dict)
    assert isinstance(global_config_.mm_fields, dict)


# Generated at 2022-06-21 11:06:47.298458
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")
    assert Exclude.ALWAYS(1.1)
    assert Exclude.ALWAYS(exclude)
    assert Exclude.ALWAYS(Exclude)

# Generated at 2022-06-21 11:06:49.001183
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}


# Generated at 2022-06-21 11:06:50.319591
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-21 11:06:52.341033
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.NEVER(0) == False

test_Exclude()

# Generated at 2022-06-21 11:06:56.489154
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")


# Generated at 2022-06-21 11:06:58.644155
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("Hello World") == True 


# Generated at 2022-06-21 11:07:05.401430
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(-1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(0.0)
    assert Exclude.ALWAYS(float("inf"))
    assert Exclude.ALWAYS(float("-inf"))
    assert Exclude.ALWAYS("abc")
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS({1: 2, 3: 4})


# Generated at 2022-06-21 11:07:07.060869
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # call function Exclude.NEVER
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-21 11:07:08.509390
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config != None


# Generated at 2022-06-21 11:07:10.830036
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(12))


# Generated at 2022-06-21 11:07:20.751912
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    import marshmallow_enum

    @config(encoder=1, field_name="field_name", undefined="ignore")
    @dataclasses.dataclass
    class D:
        pass

    assert D.__dataclass_metadata__['dataclasses_json']['encoder'] == 1
    assert D.__dataclasses_json__.field_by_name["field_name"].name == "field_name"

    class E(marshmallow.Schema):
        class Meta:
            unknown = marshmallow.EXCLUDE

    @config(mm_field=marshmallow_enum.EnumField(E))
    @dataclasses.dataclass
    class F:
        pass

    assert F.__dataclasses_json__.field_by_type

# Generated at 2022-06-21 11:07:26.705357
# Unit test for function config
def test_config():
    metadata = config(
        metadata=None,
        encoder=None,
        decoder=None,
        mm_field=None,
        letter_case=None,
        undefined='RAISE',
        field_name=None,
        exclude=None
    )
    assert metadata == {'dataclasses_json': {'undefined': Undefined.RAISE}}

# Generated at 2022-06-21 11:07:28.035871
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("asdf") == True


# Generated at 2022-06-21 11:07:33.017298
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Confirm that the method NEVER always gives a false result
    assert Exclude.NEVER(0) is False
    assert Exclude.NEVER(100) is False
    assert Exclude.NEVER("") is False
    assert Exclude.NEVER("A string") is False


# Generated at 2022-06-21 11:07:44.150948
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def f(a):
        if type(a) is int:
            return False
        else:
            return True
    e = Exclude()
    assert(e.ALWAYS(f) == True)
    assert(e.ALWAYS(2) == True)
    assert(e.ALWAYS(True) == True)


# Generated at 2022-06-21 11:07:47.410555
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g_conf = _GlobalConfig()
    assert len(g_conf.encoders) == 0
    assert len(g_conf.decoders) == 0
    assert len(g_conf.mm_fields) == 0
    print('test__GlobalConfig passed!')


# Generated at 2022-06-21 11:07:49.542371
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders
    global_config.decoders
    global_config.mm_fields

test__GlobalConfig()

# Generated at 2022-06-21 11:07:54.735448
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("some string") is True
    assert Exclude.ALWAYS(5) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS((1, 2, 3)) is True
    assert Exclude.ALWAYS({}) is True


# Generated at 2022-06-21 11:08:03.162322
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1), "Exclude.NEVER should return True"
    assert Exclude.NEVER("hello"), "Exclude.NEVER should return True"
    assert Exclude.NEVER(False), "Exclude.NEVER should return True"
    assert Exclude.NEVER(True), "Exclude.NEVER should return True"
    assert Exclude.NEVER([]), "Exclude.NEVER should return True"
    assert Exclude.NEVER({}), "Exclude.NEVER should return True"


# Generated at 2022-06-21 11:08:06.606905
# Unit test for function config
def test_config():
    @config(letter_case='camel')
    class A:
        x: int

    assert A.__dataclasses_json__ == {
        'dataclasses_json': {
            'letter_case': 'camel'
        }
    }

# TODO: deprecate

# Generated at 2022-06-21 11:08:13.790470
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    field1_value = 12.3
    field2_value = True
    field3_value = "test"

    test_result1 = Exclude.ALWAYS(field1_value)
    test_result2 = Exclude.ALWAYS(field2_value)
    test_result3 = Exclude.ALWAYS(field3_value)

    assert test_result1 is True
    assert test_result2 is True
    assert test_result3 is True


# Generated at 2022-06-21 11:08:16.535452
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class A: pass
    a = A()
    if Exclude.NEVER(a):
        assert False, "Exclude.NEVER failed"

# Generated at 2022-06-21 11:08:27.550095
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class TestClass:
        a: str = dataclasses.field(metadata=config(
            field_name='foo',
            letter_case=lambda x: x.lower()
        ))
        b: int = dataclasses.field(metadata=config(
            field_name='bar',
            letter_case=lambda x: x.upper()
        ))
        c: float = dataclasses.field(metadata=config(
            field_name='baz',
            letter_case=lambda x: x.title()
        ))

    assert TestClass.__dataclass_json__.metadata(TestClass.a, 'a') == {
        'field_name' : 'foo',
        'letter_case': lambda x: x.lower()
    }

# Generated at 2022-06-21 11:08:29.373365
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-21 11:08:43.984208
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-21 11:08:46.191895
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-21 11:08:52.680080
# Unit test for function config
def test_config():
    # TODO: support for exclude
    md = config(field_name='Test')
    lib_md = md['dataclasses_json']

    assert lib_md['letter_case']('test') == 'Test'
    assert lib_md['undefined'] == Undefined.RAISE


# # TODO: make this private
# @singledispatch
# def encode(o: Any, *,
#            json_module=global_config.json_module,
#            **kwargs) -> Any:
#     """
#     Default encoder, passes everything through to the standard library.
#     """
#     return json_module.dumps(o, **kwargs)
#
#
# @encode.register  # type: ignore
# @singledispatch
# def encode_str(o: str, *,
#

# Generated at 2022-06-21 11:08:53.991573
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(42)
    assert not Exclude.NEVER(42)

# Generated at 2022-06-21 11:08:55.623029
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = object()
    assert Exclude.NEVER(obj) == False


# Generated at 2022-06-21 11:08:56.499875
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-21 11:08:58.481229
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-21 11:09:06.962358
# Unit test for function config
def test_config():
    class A:
        def __init__(self):
            self.A = 'a'
        @config(undefined='EXCLUDE')
        def func(self, dict_a):
            return dict_a['A']
    assert hasattr(A().func({}), '__str__')
    with pytest.raises(UndefinedParameterError):
        class A:
            def __init__(self):
                self.A = 'a'
            @config(undefined='EXCLUDE1')
            def func(self, dict_a):
                return dict_a['A']


# Generated at 2022-06-21 11:09:10.026872
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
  global_config = _GlobalConfig()
  assert isinstance(global_config.encoders, dict)
  assert isinstance(global_config.decoders, dict)
  assert isinstance(global_config.mm_fields, dict)



# Generated at 2022-06-21 11:09:11.523545
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-21 11:09:41.613618
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert False == Exclude.NEVER(True)
    assert False == Exclude.NEVER(False)

# Generated at 2022-06-21 11:09:44.050309
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, Callable)
    assert isinstance(Exclude.NEVER, Callable)



# Generated at 2022-06-21 11:09:54.962996
# Unit test for function config
def test_config():
    import dataclasses
    import jsonpickle

    # Test that we can pass a string option name to the Undefined parameter
    @dataclasses.dataclass
    class X:
        a: int = config(undefined='ignore')
        b: int = config(undefined='raise')

    x = X(a=1)

    # When we pass a string option name to Undefined, we should get the
    # actual Undefined member back when we call `get_schema`
    x_schema = jsonpickle.encode(x)
    assert x_schema == '{"a": 1, "b": null}'

    try:
        jsonpickle.decode(x_schema)
        assert False, "Expected decode of X to fail"
    except TypeError:
        pass

    # Test that passing an Und

# Generated at 2022-06-21 11:09:56.694284
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    Test case for Exclude.NEVER method
    """
    # Test if the method return False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-21 11:09:59.574578
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-21 11:10:01.680464
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-21 11:10:11.809876
# Unit test for function config
def test_config():
    from marshmallow import fields
    # shd be {"dataclasses_json": {}}
    print(config({}))
    # shd be {"dataclasses_json": {"encoder": "a"}}
    print(config({}, encoder="a"))
    # shd be {"dataclasses_json": {"encoder": "a"}}
    print(config({'dataclasses_json': {}}, encoder="a"))
    # shd be {"dataclasses_json": {"encoder": "a", "decoder": "b"}}
    print(config({'dataclasses_json': {}}, encoder="a", decoder="b"))
    # shd be {"dataclasses_json": {"encoder": "a", "decoder": "b"}, "user": "c"}

# Generated at 2022-06-21 11:10:14.213552
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global global_config
    global_config = _GlobalConfig()
    assert isinstance(global_config, _GlobalConfig)
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0

test__GlobalConfig()


# Generated at 2022-06-21 11:10:15.786695
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)


# Generated at 2022-06-21 11:10:22.369392
# Unit test for function config
def test_config():
    @dataclass
    class A:
        a: int = field(metadata={'example': '1'})
    print(A)
    a = A(a=1)
    print(a)
    print(asdict(a))
    print(a.a)
    print(type(a.a))
    print(a.__annotations__)
    print(getattr(A, 'a'))

    # if hasattr(A, 'a'):
    #     print('has')
    #     attr = getattr(A, 'a')
    #     print(dir(attr))
    #     print(attr.__annotations__)
    #     print(attr.metadata)



# Generated at 2022-06-21 11:11:24.445524
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses import dataclass

    @dataclass
    class Example:
        name: str

        @classmethod
        def __str__(self):
            return 'Example'

    dc_json.config(Example, mm_field=fields.String())
    assert global_config.mm_fields[Example] == fields.String()

# Generated at 2022-06-21 11:11:27.811418
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-21 11:11:29.052322
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest

    assert Exclude.NEVER("TEST") == False

# Generated at 2022-06-21 11:11:30.408207
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-21 11:11:31.987423
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    new_config=_GlobalConfig()
    assert(isinstance(new_config, _GlobalConfig))


# Generated at 2022-06-21 11:11:33.075182
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-21 11:11:33.920240
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()


# Generated at 2022-06-21 11:11:44.524116
# Unit test for function config
def test_config():
    config()
    config(encoder=str)
    config(decoder=str)
    config(mm_field=MarshmallowField)
    config(letter_case=lambda s: s)
    config(undefined='RAISE')
    config(exclude=lambda x: True)
    # try to set an invalid undefine parameter
    try:
        config(undefined='abc')
    except UndefinedParameterError as e:
        assert str(e) == "Invalid undefined parameter action, must be one of ['RAISE', 'STRICT', 'INCLUDE']"


# TODO: #179
# def use_json(json_module):
#     """
#     Use the specified `json` library to decode and encode JSON.
#
#     :param json_module: the `json` module to use.
#     """


# Generated at 2022-06-21 11:11:47.443604
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.ALWAYS(1) == False


# Generated at 2022-06-21 11:11:50.989077
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert len(global_config.encoders) == 2
    assert len(global_config.decoders) == 2
    assert len(global_config.mm_fields) == 0
    assert global_config.encoders.get(str) == str
    assert global_config.decoders.get(str) == str
    # assert global_config.json_module == json

# Generated at 2022-06-21 11:14:07.413991
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-21 11:14:09.772391
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-21 11:14:12.118232
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS("a string") is True

    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER("a string") is False

# Generated at 2022-06-21 11:14:14.310502
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('qwerty')


# Generated at 2022-06-21 11:14:17.282330
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    always = Exclude.NEVER(0)
    assert always is False, "The method NEVER of class Exclude failed!"
    print("The methode NEVER of class Exclude works!")


# Generated at 2022-06-21 11:14:18.849149
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}



# Generated at 2022-06-21 11:14:28.026534
# Unit test for function config
def test_config():
    import pytest

    from dataclasses_json.config import Undefined

    @config(undefined='strict')
    class Test_strict():
        def __init__(self, n: int):
            pass

    @config(undefined='exclude')
    class Test_exclude():
        def __init__(self, n: int):
            pass

    @config(undefined=Undefined.STRICT)
    class Test_strict_dict():
        def __init__(self, n: int):
            pass

    @config(undefined=Undefined.EXCLUDE)
    class Test_exclude_dict():
        def __init__(self, n: int):
            pass
