

# Generated at 2022-06-23 16:34:23.549279
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:34:28.630469
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(4)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER("")
    assert Exclude.NEVER("abc")


# Generated at 2022-06-23 16:34:29.451733
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('') == False

# Generated at 2022-06-23 16:34:32.276044
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("one") == True
    assert Exclude.ALWAYS(3.43) == True


# Generated at 2022-06-23 16:34:34.405020
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True



# Generated at 2022-06-23 16:34:35.728199
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    


# Generated at 2022-06-23 16:34:36.981311
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-23 16:34:39.339800
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:34:42.229363
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")


# Generated at 2022-06-23 16:34:45.076267
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:34:47.707821
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}
    # assert _GlobalConfig().json_module == json


# Generated at 2022-06-23 16:34:49.922803
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert a.encoders == {}
    assert a.decoders == {}
    assert a.mm_fields == {}

# Generated at 2022-06-23 16:35:00.887179
# Unit test for function config
def test_config():
    from marshmallow import fields, post_load, Schema
    from dataclasses_json.mm import MM
    import pytest
    from enum import Enum

    class MyEnum(Enum):
        bar = 'bar'
        baz = 'baz'


# Generated at 2022-06-23 16:35:05.322023
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert type(global_config.encoders) == dict
    assert type(global_config.decoders) == dict
    assert type(global_config.mm_fields) == dict


# Generated at 2022-06-23 16:35:06.909368
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hello") == True


# Generated at 2022-06-23 16:35:09.778093
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-23 16:35:11.420031
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert Exclude.NEVER(4) == False


# Generated at 2022-06-23 16:35:12.591159
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER('anything')


# Generated at 2022-06-23 16:35:14.710396
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert NEVER(10) == True
    assert NEVER('hello') == True
    assert NEVER(1.3) == True

# Generated at 2022-06-23 16:35:16.467085
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Unit test to check the config function

# Generated at 2022-06-23 16:35:18.648100
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert functools.reduce(lambda x,y: x and y, [ Exclude.NEVER(i+j) for i in range(5) for j in range(5)]) == True

# Generated at 2022-06-23 16:35:21.153630
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:35:27.566749
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class Point:
        x: int

    metadata = config(exclude=Exclude.ALWAYS)
    assert "dataclasses_json" in metadata
    assert metadata["dataclasses_json"]["exclude"] is Exclude.ALWAYS
    assert dataclasses_json.config(Point, metadata=metadata) == \
            {'exclude': Exclude.ALWAYS}

# Generated at 2022-06-23 16:35:32.263513
# Unit test for function config
def test_config():

    @config(field_name='A')
    @config(field_name='B')
    class C:
        pass

    assert C.__dataclasses_json__['field_name'] == 'B'

    @config(field_name='A')
    @config(field_name='B', override=True)
    class C:
        pass

    assert C.__dataclasses_json__['field_name'] == 'A'



# Generated at 2022-06-23 16:35:36.664716
# Unit test for function config
def test_config():
    assert config(field_name='test') == {
        'dataclasses_json': {'field_name': 'test'}
    }

    from marshmallow import fields
    assert config(mm_field=fields.String) == {
        'dataclasses_json': {'mm_field': fields.String}
    }

    assert config(exclude=lambda n, f: n in ('x', 'y', 'z')) == {
        'dataclasses_json': {'exclude': lambda n, f: n in ('x', 'y', 'z')}
    }

# Generated at 2022-06-23 16:35:39.313055
# Unit test for constructor of class Exclude
def test_Exclude():
    print(Exclude.ALWAYS('a'))
    print(Exclude.NEVER('a'))
    print(Exclude.ALWAYS)
    print(Exclude.NEVER)

# Generated at 2022-06-23 16:35:46.641010
# Unit test for function config
def test_config():
    from marshmallow import fields

    @dataclass
    @config(
        mm_field=fields.Str(required=False),
        encoder=str,
        decoder=int,
        undefined=Undefined.RAISE,
        exclude=Exclude.ALWAYS)
    class Person:
        name: str
        age: int

    assert isinstance(Person.__dataclass_fields__['name'].metadata['dataclasses_json']['mm_field'],
                      fields.Str)
    assert Person.__dataclass_fields__['name'].metadata['dataclasses_json']['encoder'] == str
    assert Person.__dataclass_fields__['name'].metadata['dataclasses_json']['decoder'] == int

# Generated at 2022-06-23 16:35:57.670784
# Unit test for function config
def test_config():
    def foo():
        pass

    # good
    assert config(encoder=foo) == {'dataclasses_json': {'encoder': foo}}
    assert config(decoder=foo) == {'dataclasses_json': {'decoder': foo}}
    assert config(mm_field=foo) == {'dataclasses_json': {'mm_field': foo}}
    assert config(letter_case=foo) == {'dataclasses_json': {'letter_case': foo}}
    assert config(undefined='raise') == {'dataclasses_json': {'undefined': Undefined.RAISE}}
    assert config(field_name='foo') == {'dataclasses_json': {'letter_case': 'foo'}}

# Generated at 2022-06-23 16:35:59.021773
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS('input') == True)
    assert(Exclude.NEVER('input') == False)

# Generated at 2022-06-23 16:36:08.772671
# Unit test for function config
def test_config():
    metadata = dict()
    metadata = config(metadata=metadata,
                      encoder=lambda x: 1,
                      decoder=lambda x: 100,
                      mm_field=1,
                      letter_case=lambda x: 'test_name',
                      undefined=Undefined.RAISE,
                      exclude=Exclude.ALWAYS,
                      )

    assert 'dataclasses_json' in metadata

    lib_metadata = metadata['dataclasses_json']

    assert 'encoder' in lib_metadata
    assert lib_metadata['encoder'](1) == 1

    assert 'decoder' in lib_metadata
    assert lib_metadata['decoder'](1) == 100

    assert 'mm_field' in lib_metadata
    assert lib_metadata['mm_field'] == 1

    assert 'letter_case' in lib_metadata
    assert lib

# Generated at 2022-06-23 16:36:10.759783
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)


# Generated at 2022-06-23 16:36:13.596803
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class Temp:
        def __init__(self, name, age):
            self.name =  name
            self.age = age

    temp_object = Temp('John', 24)
    result = Exclude.ALWAYS(temp_object)
    assert result


# Generated at 2022-06-23 16:36:17.433962
# Unit test for function config
def test_config():
    import pytest
    from dataclasses_json.undefined import Undefined
    @config(undefined=Undefined.EXCLUDE)
    class A:
        pass
    with pytest.raises(UndefinedParameterError):
        @config(undefined="foo")
        class A:
            pass
    lambda x, y: x == y('foo')


# Generated at 2022-06-23 16:36:21.642539
# Unit test for constructor of class Exclude
def test_Exclude():

    # Testing the ALWAYS constant
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(null)
    assert Exclude.ALWAYS('hello')

    # Testing the NEVER constant
    assert not Exclude.NEVER(2)
    assert not Exclude.NEVER(null)
    assert not Exclude.NEVER('hello')

# Generated at 2022-06-23 16:36:22.965786
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False


# Generated at 2022-06-23 16:36:26.875313
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("abc")
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER([])
    assert Exclude.NEVER([1,2])


# Generated at 2022-06-23 16:36:28.290145
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(True)


# Generated at 2022-06-23 16:36:39.795110
# Unit test for function config
def test_config():
    assert config(encoder=str) == {
        'dataclasses_json': {'encoder': str}}
    assert config(exclude=lambda obj, field: True) == {
        'dataclasses_json': {'exclude': lambda obj, field: True}}
    assert config(undefined='ignore', exclude=lambda obj, field: True) == {
        'dataclasses_json': {'undefined': Undefined.IGNORE,
                             'exclude': lambda obj, field: True}}

    assert config(undefined=Undefined.RAISE) == {
        'dataclasses_json': {'undefined': Undefined.RAISE}}
    assert config(undefined=Undefined.IGNORE) == {
        'dataclasses_json': {'undefined': Undefined.IGNORE}}

# Generated at 2022-06-23 16:36:50.040351
# Unit test for function config
def test_config():
    # Define a test dataclass
    @dataclass
    class _TestDataClass:
        a: int = field(metadata={'test_metadata': True})
        b: int = field(metadata={'test_metadata': True})

    # Create a test config for the dataclass
    test_config = config(metadata={'test_metadata': True},
                         letter_case=str.upper,
                         exclude=lambda name, val: True,
                         undefined=Undefined.RAISE)

    # Create the dataclass
    test = _TestDataClass(a=1, b=2)

    # Check that the config is applied
    config = dict(dataclasses.asdict(test, dict_factory=dict))
    assert config == {'a': 1, 'b': 2}

    # Check that the config is applied


# Generated at 2022-06-23 16:36:52.988403
# Unit test for constructor of class Exclude
def test_Exclude():
    assert not Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(3)

    assert not Exclude.NEVER(3)
    assert Exclude.NEVER(0)


# Generated at 2022-06-23 16:37:01.312303
# Unit test for function config
def test_config():
    assert config({}, encoder=str)['dataclasses_json'] == {'encoder': str}
    assert config(encoder=str)['dataclasses_json'] == {'encoder': str}

    assert config({}, decoder=str)['dataclasses_json'] == {'decoder': str}
    assert config(decoder=str)['dataclasses_json'] == {'decoder': str}

    assert config({}, mm_field=str)['dataclasses_json'] == {'mm_field': str}
    assert config(mm_field=str)['dataclasses_json'] == {'mm_field': str}

    assert config({}, field_name='foo')['dataclasses_json'] == {'letter_case': 'foo'}

# Generated at 2022-06-23 16:37:03.549124
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-23 16:37:05.351907
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a')
    assert not Exclude.NEVER('b')

# Generated at 2022-06-23 16:37:11.264951
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    global_config.encoders = {object: lambda x: x}
    global_config.decoders = {}
    global_config.mm_fields = {}

# Generated at 2022-06-23 16:37:18.486105
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    names = ['Alice','Bob','Sun','Jack','Anna','Yuki','Keven','Messi','Ronaldo','Jesus','Kylian']

    def always_include(inp: str) -> bool:
        return True

    def filter_even_num(inp: str) -> bool:
        if len(inp) % 2 == 0:
            return True
        else:
            return False
    def filter_odd_num(inp: str) -> bool:
        if len(inp) % 2 == 0:
            return False
        else:
            return True
    x = filter(always_include, names)
    y = filter(Exclude.NEVER, names)
    assert list(x) == list(y)

    x = filter(filter_odd_num, names)

# Generated at 2022-06-23 16:37:24.753717
# Unit test for function config
def test_config():
    metadata = config(encoder=str,
                      decoder=int,
                      mm_field=int,
                      letter_case=str,
                      undefined=Undefined.EXCLUDE,
                      field_name='tmp'
                      )

    assert metadata['dataclasses_json'] == {
        'encoder': str,
        'decoder': int,
        'mm_field': int,
        'letter_case': 'tmp',
        'undefined': Undefined.EXCLUDE
    }



# Generated at 2022-06-23 16:37:27.801121
# Unit test for function config
def test_config():
    metadata = config(undefined='RAISE')
    dataclasses_json = metadata['dataclasses_json']
    assert dataclasses_json['undefined'] == Undefined.RAISE

# Generated at 2022-06-23 16:37:31.541871
# Unit test for constructor of class Exclude
def test_Exclude():
    assert type(Exclude.ALWAYS) == types.FunctionType
    assert type(Exclude.NEVER) == types.FunctionType
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(0) is False

# Generated at 2022-06-23 16:37:36.907983
# Unit test for function config
def test_config():
    def config_assert(fn, *args, **kwargs):
        assert callable(fn)
        test_config = fn(*args, **kwargs)
        assert test_config['dataclasses_json'] == kwargs
        return test_config

    test_config_1 = config_assert(config)
    test_config_2 = config_assert(config, letter_case=str.lower, exclude=Exclude.ALWAYS)

# Generated at 2022-06-23 16:37:41.582146
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    assert global_config.encoders == {}
    assert global_config.mm_fields == {}
    assert global_config.encoders == {}

# Generated at 2022-06-23 16:37:51.556573
# Unit test for function config
def test_config():
    @config(metadata={"name":"test"}, letter_case="snake", undefined="ignore", exclude=Exclude.NEVER)
    class Test:
        def __init__(self, test_field: int):
            self.test_defined_field = test_field

        def __str__(self):
            return "str(TestObject)"

        def txt(self):
            return "TestObject.txt()"

        @property
        def upper_name(self):
            return "TestObject.upper_name"


    test = Test(1)
    assert test.__dataclass_json__() == {'test_defined_field': 1, 'test_field': 1}

# Generated at 2022-06-23 16:37:52.771319
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:37:54.137541
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-23 16:37:56.775871
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS(4) == True)
    assert(Exclude.NEVER(4) == False)

# Generated at 2022-06-23 16:38:07.009558
# Unit test for function config
def test_config():
    assert config().get('dataclasses_json') is None
    assert config(metadata={'foo': 'bar'}) == {'foo': 'bar'}
    assert config(encoder=None) == {'dataclasses_json': {'encoder': None}}
    assert config(decoder=None) == {'dataclasses_json': {'decoder': None}}
    assert config(mm_field=None) == {'dataclasses_json': {'mm_field': None}}
    assert config(field_name='new_field') == {'dataclasses_json': {
        'letter_case': 'new_field'}}
    assert config(undefined='EXCLUDE') == {'dataclasses_json': {
        'undefined': Undefined.EXCLUDE}}

# Generated at 2022-06-23 16:38:08.742697
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-23 16:38:10.238403
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-23 16:38:11.532399
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)

# Generated at 2022-06-23 16:38:14.519192
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert (global_config.encoders == {})
    assert (global_config.decoders == {})
    assert (global_config.mm_fields == {})


# Generated at 2022-06-23 16:38:18.704918
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(7) == False

# # Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-23 16:38:19.838417
# Unit test for method NEVER of class Exclude

# Generated at 2022-06-23 16:38:26.276865
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert callable(Exclude.ALWAYS)
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS('abc') == True
    assert Exclude.ALWAYS(0.0) == True
    assert Exclude.ALWAYS((2,1)) == True
    assert Exclude.ALWAYS({'a':1, 'b':2}) == True
    assert Exclude.ALWAYS([1,[1,False,3],3]) == True


# Generated at 2022-06-23 16:38:30.700142
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    @dataclasses.dataclass
    @config(exclude=Exclude.ALWAYS)
    class Config1:
        a: int = 3

    @dataclasses.dataclass
    @config(letter_case=lambda x: x.upper())
    class Config2:
        a: str = 'a'

    @dataclasses.dataclass
    @config(undefined=Undefined.RAISE)
    class Config3:
        a: str = dataclasses.field(metadata={'dataclasses_json': {'load_only': True}}, default='b')


# Generated at 2022-06-23 16:38:32.745120
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config is not None


# Generated at 2022-06-23 16:38:35.299319
# Unit test for constructor of class Exclude
def test_Exclude():
    with pytest.raises(TypeError, match=".*positional arguments.*"):
        Exclude()
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)


# Generated at 2022-06-23 16:38:46.356185
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class A:
        a: str

    # Deserialization
    @config(decoder=int)
    @dataclasses.dataclass
    class A1:
        a: int

    assert dataclasses_json.load("{'a': '42'}", A1) == A1(a=42)

    # Serialization
    @config(encoder=str)
    @dataclasses.dataclass
    class A2:
        a: int

    assert dataclasses_json.dump(A2(a=42)) == '{"a": "42"}'

    # Marshmallow integration
    @config(mm_field=f.Int(required=False))
    @dataclasses.dataclass
    class A3:
        a: int

    assert datac

# Generated at 2022-06-23 16:38:47.228398
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("_") is True

# Generated at 2022-06-23 16:38:57.906419
# Unit test for function config
def test_config():
    global_config.encoders = {}
    global_config.decoders = {}
    global_config.mm_fields = {}

    def encoder_lambda(obj):
        return repr(obj)

    def encoder_callable(o, typ, **kwargs):
        return f"<{typ.__qualname__} object at {hex(id(o))}>"

    def decoder_callable(dct):
        return dct

    def mm_field_callable():
        mm_field = None
        return mm_field

    def letter_case_lambda(s):
        return s.lower()

    field_name = "name"

    exclude_always = Exclude.ALWAYS


# Generated at 2022-06-23 16:39:02.731264
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

    # TODO: Fix this test
    # assert global_config.json_module == json
    # global_config.json_module = ujson
    # assert global_config.json_module == ujson

# Generated at 2022-06-23 16:39:04.908311
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:39:07.946332
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
	testObj = _GlobalConfig()
	assert testObj.encoders == {}
	assert testObj.decoders == {}
	assert testObj.mm_fields == {}

# Generated at 2022-06-23 16:39:09.533677
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("hello")
    assert not Exclude.NEVER("hello")


# Generated at 2022-06-23 16:39:10.217886
# Unit test for function config
def test_config():
  pass

# Generated at 2022-06-23 16:39:12.585845
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(5) == True)
    assert(Exclude.ALWAYS(None) == True)


# Generated at 2022-06-23 16:39:14.531159
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("anything")

if __name__ == "__main__":
    test_Exclude_NEVER()

# Generated at 2022-06-23 16:39:17.468915
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:39:18.582795
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True



# Generated at 2022-06-23 16:39:19.703827
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("s") is True


# Generated at 2022-06-23 16:39:20.819812
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-23 16:39:22.894513
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    global_config.exclude = Exclude.NEVER
    assert global_config.exclude(None)==False



# Generated at 2022-06-23 16:39:24.021515
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(_GlobalConfig(), object)


# Generated at 2022-06-23 16:39:31.772326
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class ConfigModel:
        a: str = "a"

    @dataclass
    class DecoderModel:
        a: str = "a"

    def decoder(s: str) -> str:
        return s

    @dataclass
    class EncoderModel:
        a: str = "a"

    def encoder(s: str) -> str:
        return s

    @dataclass
    class LetterCaseModel:
        a: str = "a"

    def letter_case(s: str) -> str:
        return s

    @dataclass
    class FieldNameModel:
        a: str = "a"

    @dataclass
    class ExcludeModel:
        a: str = "a"



# Generated at 2022-06-23 16:39:42.450536
# Unit test for function config
def test_config():
    # Check if the config function is working as expected
    # Initialize the metadata dictionary
    metadata = {}
    # Specify different values for different config options
    metadata = config(metadata, decoder=True, letter_case=lambda x:x)
    # Check if the values specified are present
    assert metadata['dataclasses_json']['decoder'] is True
    assert metadata['dataclasses_json']['letter_case'].__name__ == '<lambda>'
    # Check if the default values have been inserted for other config options
    assert metadata['dataclasses_json']['encoder'] is None
    assert metadata['dataclasses_json']['mm_field'] is None
    assert metadata['dataclasses_json']['undefined'] is Undefined.EXCLUDE

# Generated at 2022-06-23 16:39:46.651144
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Testing method NEVER() of class Exclude")
    assert Exclude.NEVER("ABC") == False
    print("Passed !", end="\n\n")


# Generated at 2022-06-23 16:39:49.465966
# Unit test for constructor of class Exclude
def test_Exclude():
    # test case 1
    assert Exclude.ALWAYS(5) == True
    # test case 2
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-23 16:39:53.948515
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER("")
    assert not Exclude.ALWAYS("")

# TODO: test config

# Generated at 2022-06-23 16:39:57.493397
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("TestExcludeALWAYS start")
    assert Exclude.ALWAYS(1) == True
    print("TestExcludeALWAYS end")


# Generated at 2022-06-23 16:39:59.486532
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(1)
    assert result == False


# Generated at 2022-06-23 16:40:01.017497
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:40:02.520663
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS("Hello") == True)
    assert(Exclude.NEVER("Hello") == False)

# Generated at 2022-06-23 16:40:08.398971
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined
    from dataclasses_json.core import encode
    from dataclasses import dataclass

    @dataclass
    class Foo:
        @config(
            encoder=lambda o: "encoding",
            decoder=lambda s: s.upper(),
            mm_field=fields.String,
            undefined=Undefined.SKIP,
        )
        def value(self) -> str:
            pass

        @config(exclude=Exclude.ALWAYS)
        def never_shown(self):
            return "I'm hidden"

    instance = Foo()
    assert encode(instance.value) == "encoding"
    assert encode(instance.never_shown) == Undefined



# Generated at 2022-06-23 16:40:11.520359
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-23 16:40:12.303679
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    pass

# Generated at 2022-06-23 16:40:15.152236
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:40:19.443618
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:40:20.650846
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(object)



# Generated at 2022-06-23 16:40:33.575461
# Unit test for function config
def test_config():
    import datetime
    import json

    class Foo:
        pass
    @dataclass
    class Bar:
        foo: Foo
    @dataclass
    class Baz:
        foo: str = field(metadata=config(encoder=lambda x: x))
        bar: Bar
        # This should not be affected by global config
        baz: datetime.date = datetime.date(2000, 1, 1)

    obj = Baz("foo", Bar(Foo()))

    # Encoder should not affect default parameter
    output = json.dumps(obj.__dict__, cls=Encoder)
    assert output == '{"foo": "foo", "bar": {"foo": {}}, "baz": "2000-01-01"}'

    # Decoders should not be applied

# Generated at 2022-06-23 16:40:36.569196
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS == Exclude.ALWAYS(None)
    assert Exclude.NEVER == Exclude.NEVER(None)


# Generated at 2022-06-23 16:40:39.307680
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_ = _GlobalConfig()
    assert global_.encoders == {}
    assert global_.decoders == {}
    assert global_.mm_fields == {}



# Generated at 2022-06-23 16:40:42.084018
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER(1)
    assert not Exclude.NEVER(0)
    assert not Exclude.NEVER(2)
    assert not Exclude.NEVER(3)
    assert not Exclude.NEVER("")


# Generated at 2022-06-23 16:40:44.216867
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER(2)
    assert not Exclude.ALWAYS(2)

# Generated at 2022-06-23 16:40:47.768254
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def f(a):
        return False
    assert f(1) == Exclude.NEVER(1)


# Generated at 2022-06-23 16:40:49.740607
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global global_config
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:40:52.981095
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('')
    assert not Exclude.NEVER(0)
    assert not Exclude.NEVER(None)
    assert not Exclude.NEVER('')

# Generated at 2022-06-23 16:40:55.058905
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("1")
    assert not Exclude.NEVER("2")

if __name__ == '__main__':
    test_Exclude()

# Generated at 2022-06-23 16:40:55.862305
# Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-23 16:41:03.626568
# Unit test for function config
def test_config():
    from marshmallow.schema import Schema
    from marshmallow.fields import String

    @config()
    class C:
        pass
    assert C.__metadata__.get('dataclasses_json', {}).get('encoder') is None
    assert C.__metadata__.get('dataclasses_json', {}).get('decoder') is None
    assert C.__metadata__.get('dataclasses_json', {}).get('mm_field') is None

    @config(encoder='a', decoder='b', mm_field='c')
    class C:
        pass
    assert C.__metadata__.get('dataclasses_json', {}).get('encoder') == 'a'
    assert C.__metadata__.get('dataclasses_json', {}).get('decoder') == 'b'

# Generated at 2022-06-23 16:41:12.565967
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    t = _GlobalConfig()
    assert len(t.encoders) == 0
    assert len(t.decoders) == 0
    assert len(t.mm_fields) == 0

# Unit test subclass of dataclasses.make_dataclass not working
# class Test_GlobalConfig_json_module():
#     def test_getter(self):
#         t = _GlobalConfig()
#         assert t.json_module == json
#     def test_setter(self):
#         t = _GlobalConfig()
#         t.json_module = json
#         assert t.json_module == json


# Generated at 2022-06-23 16:41:16.456795
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") is False
    assert Exclude.NEVER(0) is False
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-23 16:41:22.906633
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Simple:
        a: bool = True
        b: int = 1
        c: str = "str"

    cls = Simple
    cls = config(cls, exclude=Exclude.NEVER)
    cls = config(cls, exclude=Exclude.ALWAYS)
    cls = config(cls, exclude=lambda f, _: f.name.startswith("a"))
    cls = config(cls, field_name="new_field_name")
    cls = config(cls, letter_case=str.upper)
    cls = config(cls, undefined=Undefined.REPLACE)

# Generated at 2022-06-23 16:41:24.978356
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(object()) == True
    assert Exclude.NEVER(object()) == False


# Generated at 2022-06-23 16:41:28.475075
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER('str') == False

test_Exclude_NEVER()

# Generated at 2022-06-23 16:41:29.898509
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:41:31.701877
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(4))
    

# Generated at 2022-06-23 16:41:42.721774
# Unit test for function config
def test_config():
    import marshmallow
    import pytest

    @config(exclude=False)
    @dataclass
    class TestConfig1:
        a: str

    assert TestConfig1._config['exclude'] == False

    @config(exclude=True)
    @dataclass
    class TestConfig2:
        a: str

    assert TestConfig2._config['exclude'] == True

    @config(encoder=True)
    @dataclass
    class TestConfig3:
        a: str

    assert TestConfig3._config['encoder'] == True

    @config(decoder=True)
    @dataclass
    class TestConfig4:
        a: str

    assert TestConfig4._config['decoder'] == True


# Generated at 2022-06-23 16:41:44.985121
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert(isinstance(gc, _GlobalConfig))

if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-23 16:41:46.216298
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:41:47.966291
# Unit test for constructor of class Exclude
def test_Exclude():
    a = Exclude()
    assert a.ALWAYS()
    assert not a.NEVER()

# Generated at 2022-06-23 16:41:50.487341
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Given
    sut = Exclude.NEVER

    # When
    result = sut("a string")

    # Then
    assert result is False


# Generated at 2022-06-23 16:41:53.538443
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:41:55.562823
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER('hoge')
    assert not Exclude.NEVER(12345)


# Generated at 2022-06-23 16:42:00.886193
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert(global_config.encoders == {})
    assert(global_config.decoders == {})
    assert(global_config.mm_fields == {})
    # assert(global_config.json_module == json)
    print("Test for constructor of class _GlobalConfig: PASS")


# Generated at 2022-06-23 16:42:04.226872
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False

# Generated at 2022-06-23 16:42:07.253544
# Unit test for constructor of class Exclude
def test_Exclude():
    print(Exclude.ALWAYS)
    assert True == Exclude.ALWAYS(1)
    assert False == Exclude.NEVER(1)



# Generated at 2022-06-23 16:42:09.656116
# Unit test for constructor of class Exclude
def test_Exclude():
    print(Exclude.ALWAYS(1))
    print(Exclude.NEVER(1))
    print(Exclude.NEVER(0))



# Generated at 2022-06-23 16:42:11.884593
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    instance = _GlobalConfig()
    assert instance.encoders=={}
    assert instance.decoders=={}
    assert instance.mm_fields=={}

test__GlobalConfig()

# Generated at 2022-06-23 16:42:13.729916
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)


# Generated at 2022-06-23 16:42:21.753511
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class A:
        a: int

    dataclasses.field(metadata=config(encoder='a', decoder='b', exclude=None))
    dataclasses.field(metadata=config(encoder='a', decoder='b', exclude=lambda _: True))
    dataclasses.field(metadata=config(encoder='a', decoder='b', exclude=lambda _: False))



# Generated at 2022-06-23 16:42:28.081654
# Unit test for function config
def test_config():
    @dataclass
    @config()
    class TestConfig:
        pass

    assert TestConfig.__config__ == {'dataclasses_json': {}}

    @dataclass
    @config(letter_case=lambda s: s.upper())
    class TestConfig:
        pass


# Generated at 2022-06-23 16:42:32.682899
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config._json_module, types.ModuleType)
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-23 16:42:35.592254
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("hello") == True
    assert Exclude.ALWAYS([1, 2, 3]) == True


# Generated at 2022-06-23 16:42:36.832746
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:42:38.617992
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:42:40.792837
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:42:43.506117
# Unit test for constructor of class Exclude
def test_Exclude():
    testClass = Exclude()
    assert testClass.ALWAYS(2)
    assert testClass.NEVER(2)


# Generated at 2022-06-23 16:42:51.205808
# Unit test for function config
def test_config():
    class TestClass:
        pass
    test_obj = TestClass()
    global_config.mm_fields[type(test_obj)] = test_obj
    test_metadata = config(encoder=test_obj, decoder=test_obj, mm_field=test_obj, letter_case=test_obj.__name__,
               undefined='raise', exclude=Exclude.ALWAYS)
    assert test_metadata['dataclasses_json']['encoder'] == test_obj
    assert test_metadata['dataclasses_json']['decoder'] == test_obj
    assert test_metadata['dataclasses_json']['mm_field'] == test_obj
    assert test_metadata['dataclasses_json']['letter_case'] == TestClass.__name__

# Generated at 2022-06-23 16:42:55.009599
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS((1, 2, 3))
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(3.14)
    assert Exclude.ALWAYS('')


# Generated at 2022-06-23 16:43:03.260722
# Unit test for function config
def test_config():
    metadata = {}
    config(metadata=metadata, field_name='test_field')
    decoder = lambda a,b: a + b
    config(metadata=metadata, decoder=decoder)
    encoder = lambda a: a
    config(metadata=metadata, encoder=encoder, undefined=Undefined.EXCLUDE)

    assert metadata['dataclasses_json'] == {
        'encoder': encoder,
        'decoder': decoder,
        'undefined': Undefined.EXCLUDE,
        'letter_case': 'test_field'
        }

# Generated at 2022-06-23 16:43:05.607749
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-23 16:43:08.346658
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    ALWAYS = Exclude.ALWAYS
    assert ALWAYS(1)
    assert ALWAYS('abc')
    assert ALWAYS([1, 2, 3])
    assert ALWAYS(None)
    assert ALWAYS(Exclude)


# Generated at 2022-06-23 16:43:12.393101
# Unit test for function config
def test_config():
    # Test for UndefinedParameterError
    def test_undefined_parameter_error():
        # Test for raising UndefinedParameterError when the parameter action is not found
        with pytest.raises(UndefinedParameterError, match='Invalid undefined parameter action'):
            config(undefined='INVALID_ACTION')
        

    test_undefined_parameter_error()



# Generated at 2022-06-23 16:43:18.402952
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    config_encoders = {'type': callable}
    config_decoders = {'type': callable}
    config_mm_fields = {'type': MarshmallowField}
    assert global_config_.encoders == config_encoders
    assert global_config_.decoders == config_decoders
    assert global_config_.mm_fields == config_mm_fields

# Module test for the module-level config() function

# Generated at 2022-06-23 16:43:20.709060
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('_')



# Generated at 2022-06-23 16:43:28.201077
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    test_encoder = "test_encoder"
    test_decoder = "test_decoder"
    test_mm_field = "test_mm_field"
    test_json_module = "test_json_module"
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json
    global_config.encoders = test_encoder
    global_config.decoders = test_decoder
    global_config.mm_fields = test_mm_field
    # global_config.json_module = test_json_module
    assert global_config.encoders == test_encoder

# Generated at 2022-06-23 16:43:37.401261
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from typing import List
    from dataclasses_json import config, DataClassJsonMixin

    @dataclass
    class Person(DataClassJsonMixin):
        @classmethod
        def from_json(cls, json: dict) -> 'Person':
            return cls(json['lastName'], json['firstName'])
        last_name: str
        first_name: str
        middle_name: str = ''
        nicknames: List[str] = []

    @dataclass
    class World(DataClassJsonMixin):
        @classmethod
        def from_json(cls, json: dict) -> 'World':
            return cls(json['name'], json['people_attributes'])
        name: str

# Generated at 2022-06-23 16:43:38.897166
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-23 16:43:41.921348
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.ALWAYS('hello') == True)
    assert(Exclude.ALWAYS(Exclude) == True)
    return

# Generated at 2022-06-23 16:43:46.228333
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) ==  True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("abc") == True


# Generated at 2022-06-23 16:43:50.600953
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(10)
    assert Exclude.ALWAYS('test')
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:44:01.943408
# Unit test for function config
def test_config():
    _Test = TypeVar('_Test')

    class Test:
        def __init__(self,
                     a: str = None,
                     b: int = 0,
                     c: _Test = None,
                     d: Dict = None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    @config(metadata={'a': 'b', 'c': {'d': 'e'}},
            encoder=lambda x: 1, decoder=lambda x: 2,
            mm_field=lambda x, y: 3,
            letter_case=lambda x: 4,
            field_name=lambda x: 5,
            exclude=lambda x, y: 6,
            undefined=7,
            )
    class TestConfig(Test):
        pass


# Generated at 2022-06-23 16:44:10.434327
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_encoders = {dict: dict.__getitem__}
    test_decoders = {list: list.__contains__}
    test_mm_fields = {"json.decoder.JSONDecoder": json.decoder.JSONDecoder}
    test_global_config = _GlobalConfig()
    test_global_config.encoders = test_encoders
    test_global_config.decoders = test_decoders
    test_global_config.mm_fields = test_mm_fields
    assert isinstance(test_global_config.encoders, dict)
    assert isinstance(test_global_config.decoders, dict)
    assert isinstance(test_global_config.mm_fields, dict)
    #assert test_global_config.json_module == json

# Generated at 2022-06-23 16:44:20.113159
# Unit test for function config
def test_config():
    from pytest import raises
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json import dataclass_json

    @dataclass
    @config(encoder=lambda x: str(x),
            field_name='name',
            decoder=lambda x: int(x),
            undefined=Undefined.EXCLUDE)
    class MyClass:
        id: int

    assert MyClass.__dataclass_json__.encoder(2) == '2'
    assert MyClass.__dataclass_json__.decoder('2') == 2

    # @config(undefined=Undefined.EXCLUDE,
    #         field_name='_id')
    # class MyClass:
    #     id: int


# Generated at 2022-06-23 16:44:26.070040
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from dataclasses_json.config import config as configlib
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class H(DataClassJsonMixin):
        i: str

    assert H.schema() == {'i': {'type': 'string'}}
    assert H('a').to_json() == '{"i":"a"}'
    assert H.from_json('{"i":"b"}') == H('b')


if __name__ == '__main__':
    test__GlobalConfig()