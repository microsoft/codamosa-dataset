

# Generated at 2022-06-23 16:34:25.033163
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(2) is False
    assert Exclude.NEVER('hello') is False
    assert Exclude.NEVER('') is False


# Generated at 2022-06-23 16:34:28.479958
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(object()) == True


# Generated at 2022-06-23 16:34:29.633572
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:34:32.984961
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-23 16:34:34.750804
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test') is True


# Generated at 2022-06-23 16:34:36.773570
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()
    assert obj.encoders == {}
    assert obj.decoders == {}
    assert obj.mm_fields == {}

# Generated at 2022-06-23 16:34:38.782548
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:34:41.109095
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("") is True
    assert Exclude.NEVER("") is False

# Generated at 2022-06-23 16:34:45.395492
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER(123) is False
    assert Exclude.NEVER(0) is False
    assert Exclude.NEVER('hello') is False
    assert Exclude.ALWAYS(234) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS('') is True



# Generated at 2022-06-23 16:34:49.868521
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Set up test case
    test_case = "Test for method ALWAYS of class Exclude"
    # Define the expected result
    expected_result = True
    # Actual result
    actual_result = Exclude.ALWAYS(3)
    assert actual_result == expected_result, "{}: Failure".format(test_case)
    print("{}: Success".format(test_case))


# Generated at 2022-06-23 16:35:00.849943
# Unit test for function config
def test_config():
    import dataclasses
    import pytest

    @dataclasses.dataclass
    class Test:
        name: str = config(field_name='full_name')
        reg: float = config(exclude=Exclude.ALWAYS)

    obj = Test('John Doe', 2.34)

    # Make sure that we can only set the undefined value in config once

# Generated at 2022-06-23 16:35:11.991260
# Unit test for function config
def test_config():
    import marshmallow as ma
    from dataclasses import dataclass
    from typing import List

    @dataclass
    @config(encoder=str)
    class Foo:
        foo: int

    @dataclass
    @config(decoder=int)
    class Bar:
        bar: str

    @dataclass
    @config(mm_field=ma.fields.Integer())
    class Baz:
        baz: int

    @dataclass
    @config(letter_case=lambda _: "value")
    class Quux:
        quux: int

    @dataclass
    @config(undefined=Undefined.RAISE)
    class Toto:
        toto: int

    @dataclass
    @config(field_name="foobar")
    class Wibble:
        wibble

# Generated at 2022-06-23 16:35:13.666785
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    options = Exclude.NEVER
    actual = options(1)
    assert actual == False


# Generated at 2022-06-23 16:35:22.455256
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config
    from dataclasses_json.undefined import Undefined

    @dataclass
    class User:
        name: str
        age: int
        uid: int

    user = User("John", "20", 1)
    assert user.age == "20"

    @dataclass
    @config(encoder=int)
    class User:
        name: str
        age: int
        uid: int

    user = User("John", "20", 1)
    assert user.age == 20
    user.age = "20"
    assert user.age == 20

    @dataclass
    @config(encoder=int, decoder=str)
    class User:
        name: str
        age: int

# Generated at 2022-06-23 16:35:25.807084
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:35:27.099833
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('somestring') is False


# Generated at 2022-06-23 16:35:31.476479
# Unit test for function config
def test_config():
    from marshmallow_dataclass import class_schema
    from dataclasses import dataclass

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class A:
        x: int
        y: int

    assert class_schema(A)() == {'x': None, 'y': None}
    assert class_schema(A).dump({'x': 10, 'y': 20}) == {'x': None, 'y': None}

# Generated at 2022-06-23 16:35:33.281333
# Unit test for function config
def test_config():
    assert config(undefined='ignore') == {'dataclasses_json': {'undefined': Undefined.IGNORE}}

# Generated at 2022-06-23 16:35:34.304271
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    return True


# Generated at 2022-06-23 16:35:35.748277
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:35:37.647473
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS(1))
    assert(not(Exclude.NEVER(None)))

# Generated at 2022-06-23 16:35:39.120307
# Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-23 16:35:44.196908
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {3:3}
    global_config.decoders = {2:2}
    global_config.mm_fields = {1:1}

    assert global_config.encoders == {3: 3}
    assert global_config.decoders == {2: 2}
    assert global_config.mm_fields == {1: 1}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:35:46.377707
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5), "Exclude.ALWAYS(5) should be True"
    return


# Generated at 2022-06-23 16:35:48.691702
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("True") == False
    assert Exclude.NEVER("False") == False


# Generated at 2022-06-23 16:35:50.809540
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('value')



# Generated at 2022-06-23 16:35:52.359947
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Always") == True


# Generated at 2022-06-23 16:35:54.290331
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False

# Generated at 2022-06-23 16:36:01.731832
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class CustomFields:
        name: str
        value: int

        class Config:
            @staticmethod
            def encoder(obj) -> Optional[dict]:
                if obj.value:
                    return {obj.name: str(obj.value)}

            @staticmethod
            def decoder(dct) -> Optional[dict]:
                if dct:
                    return {k: int(v) for k, v in dct.items()}

        class Meta:
            dataclasses_json = {
                "encoder": CustomFields.Config.encoder,
                "decoder": CustomFields.Config.decoder,
            }

    import dataclasses_json

    custom_encoder = {CustomFields: CustomFields.Config.encoder}


# Generated at 2022-06-23 16:36:02.553527
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-23 16:36:03.625735
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = Exclude.ALWAYS
    assert x != None
    assert x(1) == 1
    assert x(2) == 2



# Generated at 2022-06-23 16:36:07.431555
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:36:17.335335
# Unit test for function config
def test_config():
    class MyClass:
        pass
    assert config(MyClass) == {'dataclasses_json': {}}
    assert config(MyClass, encoder=str) == {'dataclasses_json': {'encoder': str}}
    assert config(MyClass, mm_field=str) == {'dataclasses_json': {'mm_field': str}}
    assert config(MyClass, decoder=str) == {'dataclasses_json': {'decoder': str}}

# Generated at 2022-06-23 16:36:19.022848
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

test_Exclude()

# Generated at 2022-06-23 16:36:26.137532
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("word") == False
    assert Exclude.NEVER(["word"]) == False
    assert Exclude.NEVER([1, 2]) == False
    assert Exclude.NEVER({'a': 'b'}) == False


# Generated at 2022-06-23 16:36:27.347176
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:36:39.260639
# Unit test for function config
def test_config():
    import marshmallow as ma

    class _TestField(ma.fields.Field):
        pass

    class _TestField2(ma.fields.Field):
        pass

    @config(encoder=dict,
            decoder=list,
            mm_field=_TestField(),
            letter_case=lambda x: x.upper(),
            undefined=Undefined.EXCLUDE,
            exclude=Exclude.ALWAYS,
            field_name="custom_name")
    class TestSimple:
        pass

    assert global_config.encoders == {
        TestSimple: dict,
    }
    assert global_config.decoders == {
        TestSimple: list,
    }
    assert global_config.mm_fields == {
        TestSimple: _TestField(),
    }
    assert TestSimple.__dataclass_

# Generated at 2022-06-23 16:36:49.691020
# Unit test for function config
def test_config():
#    import typing
    import inspect
    from dataclasses import dataclass, replace
    from dataclasses_json.undefined import Undefined
    from marshmallow.fields import Integer, String
    from marshmallow.validate import OneOf
    # Test with metadata=dict
    @dataclass
    class UserDataDict:
        name: str
        culture: str = None
        id: int = None

    assert inspect.getclosurevars(UserDataDict) == ClosureVars(
        nonlocals={},
        globals={},
        builtins={
            'dataclass': dataclass,
            '__name__': '__main__',
            '__package__': None,
            '__doc__': None
        },
        unbound={})


# Generated at 2022-06-23 16:36:51.222114
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-23 16:36:53.906024
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(1)
    assert not Exclude.NEVER('a')
    assert not Exclude.NEVER(None)
    assert not Exclude.NEVER(Exclude)


# Generated at 2022-06-23 16:36:57.782801
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    assert conf.encoders == {}
    assert conf.decoders == {}
    assert conf.mm_fields == {}
    # ref: https://github.com/Yashvendra/dataclasses-json/issues/175
    # assert conf.json_module == json



# Generated at 2022-06-23 16:36:59.985075
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude.ALWAYS("any")
    assert not Exclude.NEVER("any")

# Generated at 2022-06-23 16:37:04.109550
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    exs = Exclude()
    class TestClass:
        def __init__(self,value):
            self.value = value
    tc = TestClass(0)
    print(exs.NEVER(tc))
    # True


# Generated at 2022-06-23 16:37:14.612906
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import config, Exclude

    @dataclass
    class Example:
        foo: int
        bar: int = field(metadata=config(exclude=Exclude.ALWAYS))
        baz: int = field(metadata=config(exclude=Exclude.NEVER))

    @dataclass
    class Another:
        foo: int = field(metadata=config(exclude=lambda field_name, d:
                                          field_name.startswith("ba")))

    obj = Example(10, 20, 30)
    assert obj.bar == 20
    assert obj.baz == 30

    assert config(obj).dict() == {'foo': 10, 'baz': 30}

    obj = Another(10, 20, 30)

# Generated at 2022-06-23 16:37:24.827336
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(13)
    assert Exclude.NEVER(-1)
    assert Exclude.NEVER(-0)
    assert Exclude.NEVER(1.3)
    assert Exclude.NEVER(-1.3)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER([])
    assert Exclude.NEVER(["234"])
    assert Exclude.NEVER(["2334", 1.2])
    assert Exclude.NEVER({})
    assert Exclude.NEVER({"toto": 1.2})
    assert Exclude.NEVER({"toto": ["234"]})

# Generated at 2022-06-23 16:37:26.198682
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('any string') == False



# Generated at 2022-06-23 16:37:28.033777
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-23 16:37:33.039685
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("str") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({1}) == False
    assert Exclude.NEVER({"str": "str"}) == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:37:34.883759
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER(10) == False
    assert Exclude.ALWAYS(10) == True

# Generated at 2022-06-23 16:37:41.288937
# Unit test for function config
def test_config():
    import marshmallow as mm

    class Example:
        pass

    # Decorator
    @config(exclude=Exclude.NEVER)
    class ExcludeNever:
        pass

    @config(letter_case=lambda s: s[1:])
    class LetterCase:
        pass

    @config(undefined=Undefined.EXCLUDE)
    class UndefinedExclude:
        pass

    @config(undefined='exclude')
    class UndefinedExclude2:
        pass

    @config(undefined=Undefined.RAISE)
    class UndefinedRaise:
        pass

    @config(undefined='raise')
    class UndefinedRaise2:
        pass

    @config(undefined=Undefined.INCLUDE)
    class UndefinedInclude:
        pass


# Generated at 2022-06-23 16:37:44.569047
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("1")
    assert not Exclude.NEVER("1")

    assert not Exclude.ALWAYS("")
    assert Exclude.NEVER("")

# Generated at 2022-06-23 16:37:46.032068
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    t = Exclude.NEVER('apple')
    assert t == False


# Generated at 2022-06-23 16:37:55.919636
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class A(DataClassJsonMixin):
        pass

    @dataclass
    class B(DataClassJsonMixin):
        pass

    @dataclass
    class C(DataClassJsonMixin):
        pass

    @dataclass
    class D(DataClassJsonMixin):
        pass

    @dataclass
    class E(DataClassJsonMixin):
        pass

    @config(encoder=int)
    @dataclass
    class Foo:
        i: int


# Generated at 2022-06-23 16:37:58.278196
# Unit test for constructor of class Exclude
def test_Exclude():
    assert hasattr(Exclude, '__call__')
    assert Exclude.ALWAYS(True)
    assert not Exclude.NEVER(True)

# Generated at 2022-06-23 16:38:01.626868
# Unit test for constructor of class Exclude
def test_Exclude():
    ex_obj = Exclude()

    class Foo:
        pass
    f = Foo()

    assert ex_obj.ALWAYS(f) is True
    assert ex_obj.NEVER(f) is False



# Generated at 2022-06-23 16:38:08.905502
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {int: lambda x: -x}
    assert global_config.encoders[int](1) == -1
    assert global_config.encoders[int](-1) == 1

    global_config.decoders = {str: lambda x: 'hello world'}
    assert global_config.decoders[str]('') == 'hello world'

    field = MarshmallowField()
    global_config.mm_fields = {int: field}

    assert global_config.mm_fields[int] == field


# Generated at 2022-06-23 16:38:10.384262
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:38:14.034960
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    func = Exclude.ALWAYS
    assert callable(func)
    assert func(None) == True
    assert func(123) == True
    assert func('abc') == True


# Generated at 2022-06-23 16:38:19.877961
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)
    assert Exclude.NEVER("")
    assert Exclude.NEVER("some string")
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(Undefined)


# Generated at 2022-06-23 16:38:23.197641
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}
    # assert g.json_module == json  # TODO: #180



# Generated at 2022-06-23 16:38:24.631353
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("a")


# Generated at 2022-06-23 16:38:30.788612
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    def assert_NEVER(obj):
        from nose.tools import assert_true
        assert_true(obj == Exclude.NEVER(obj))

    with patch('dataclasses.is_dataclass', return_value=True):
        assert_NEVER(42)
        assert_NEVER('str')
        assert_NEVER(Exclude)
        assert_NEVER(config)
        assert_NEVER(test_Exclude_NEVER)
        assert_NEVER(Exception)

# Generated at 2022-06-23 16:38:33.395121
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(5)==True
    assert Exclude.NEVER(5)==False

# Generated at 2022-06-23 16:38:35.886267
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude.ALWAYS = lambda _: True
    Exclude.NEVER = lambda _: False
    assert Exclude.ALWAYS("test") == True
    assert Exclude.NEVER("test") == False


# Generated at 2022-06-23 16:38:38.903328
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) and \
           Exclude.ALWAYS(True) and \
           Exclude.ALWAYS("A")


# Generated at 2022-06-23 16:38:42.911516
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-23 16:38:44.231917
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:38:52.443029
# Unit test for function config
def test_config():
    # Test for encoder
    class TestClass0:
        x = 0
        y = 0
    @dataclass_json
    @config(encoder=lambda o: {"x": o.x + 1, "y": o.y + 1})
    class TestClass1(TestClass0):
        pass
    assert TestClass1(1, 2).to_json() == '{"x":2,"y":3}'

    # Test for decoder
    @dataclass_json
    @config(decoder=lambda d: TestClass0(d["x"] - 1, d["y"] - 1))
    class TestClass2(TestClass0):
        pass
    assert TestClass2.from_json('{"x":2,"y":3}') == TestClass0(1, 2)

    # Test for mm_field
   

# Generated at 2022-06-23 16:39:01.721460
# Unit test for function config
def test_config():
    metadata = config(undefined='ignore')
    assert metadata['dataclasses_json']['undefined'] == Undefined.IGNORE
    assert config(undefined=Undefined.RAISE).get('dataclasses_json').get('undefined') == Undefined.RAISE
    assert config(field_name='field_name', letter_case='snake').\
        get('dataclasses_json').get('letter_case')
    assert config(field_name='field_name').\
        get('dataclasses_json').get('letter_case')

# Generated at 2022-06-23 16:39:04.416456
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    inp = 1
    # Checking for true
    assert(Exclude.ALWAYS(inp)), "Exclude.ALWAYS should return true"


# Generated at 2022-06-23 16:39:06.328985
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') is False


# Generated at 2022-06-23 16:39:07.820813
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:39:11.714772
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2)
    assert not Exclude.NEVER(2)


if __name__ == '__main__':
    # Test to see if the main function runs correctly
    test_Exclude()

# Generated at 2022-06-23 16:39:16.276811
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('abc') == True
    assert Exclude.ALWAYS([1,2,3]) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS({'a':1}) == True


# Generated at 2022-06-23 16:39:17.068284
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('1') == False

# Generated at 2022-06-23 16:39:19.079235
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:39:23.872227
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(0) is False
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(False) is False
    assert Exclude.NEVER([]) is False
    assert Exclude.NEVER(()) is False
    assert Exclude.NEVER({}) is False
    assert Exclude.NEVER('') is False
    assert Exclude.NEVER('d') is False
    assert Exclude.NEVER(b'd') is False


# Generated at 2022-06-23 16:39:25.642772
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   a = Exclude()
   assert a.ALWAYS('_') == True


# Generated at 2022-06-23 16:39:26.646310
# Unit test for constructor of class Exclude
def test_Exclude():
	a=Exclude()
	assert a.ALWAYS(4)==True
	assert a.NEVER(4)==False

# Generated at 2022-06-23 16:39:31.584741
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = Exclude.ALWAYS
    assert x(1)
    assert x(True)
    assert x("True")
    assert x("true")
    assert x("tRue")
    assert x(False)
    assert x("false")
    assert x("False")
    assert x("fAlse")


# Generated at 2022-06-23 16:39:32.871852
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True

# Generated at 2022-06-23 16:39:35.795325
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}



# Generated at 2022-06-23 16:39:37.862307
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('test') == True
    assert Exclude.NEVER('test') == False


# Generated at 2022-06-23 16:39:45.685003
# Unit test for function config
def test_config():
    class Foo:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return isinstance(other, Foo) and self.value == other.value

    class Bar:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return isinstance(other, Bar) and self.value == other.value

    @config(encoder=lambda o: o.value,
            decoder=lambda o: Foo(o),
            mm_field=lambda: marshmallow.fields.Str(),
            letter_case=str.upper,
            undefined=Undefined.RAISE,
            exclude=Exclude.ALWAYS)
    class X:
        y: Foo


# Generated at 2022-06-23 16:39:54.690807
# Unit test for function config
def test_config():
    from marshmallow_dataclass import class_schema, Schema
    from marshmallow import fields
    import json

    @config(metadata=dict(dataclasses_json={"encoder": json.dumps}))
    @dataclass
    class test:
        n: int

    assert test.n.metadata['dataclasses_json']['encoder'] == json.dumps

    @config(encoder=json.dumps, mm_field=fields.Integer())
    @dataclass
    class test:
        n: int

    schema = class_schema(test)
    assert schema.fields['n'].metadata['dataclasses_json']['encoder'] == json.dumps
    assert type(schema.fields['n']) == fields.Integer



# Generated at 2022-06-23 16:39:57.415525
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(0)==False)
    assert(Exclude.NEVER('')==False)


# Generated at 2022-06-23 16:39:59.414523
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:40:02.599262
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()
    assert type(obj.encoders) == dict
    assert type(obj.decoders) == dict
    assert type(obj.mm_fields) == dict
    # assert type(obj.json_module) == json


# Generated at 2022-06-23 16:40:04.106624
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test string") == True


# Generated at 2022-06-23 16:40:07.542628
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(object())

# Generated at 2022-06-23 16:40:14.494434
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(42) == True
    assert Exclude.ALWAYS(3.14) == True
    assert Exclude.ALWAYS(-3) == True
    assert Exclude.ALWAYS([1,2]) == True
    assert Exclude.ALWAYS(['red', 'blue']) == True
    assert Exclude.ALWAYS('spam') == True
    assert Exclude.ALWAYS({'name': 'John', 'age': 42}) == True



# Generated at 2022-06-23 16:40:17.283290
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(True)



# Generated at 2022-06-23 16:40:18.580889
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-23 16:40:24.779928
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(True)
    assert Exclude.ALWAYS("False")
    assert Exclude.ALWAYS("True")
    assert Exclude.NEVER("False")
    assert Exclude.NEVER("True")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("1")
    assert Exclude.NEVER(1)
    assert Exclude.NEVER("1")
    assert Exclude.ALWAYS("")
    assert Exclude.NEVER("")
    assert Exclude.ALWAYS("something")
    assert Exclude.NEVER("something")
    assert Exclude.ALWAYS(None)
    assert Exclude.NEVER(None)

# Generated at 2022-06-23 16:40:34.326520
# Unit test for function config
def test_config():
    from marshmallow import fields

    # Using a nested dict to represent a typing.Dict[str, dict]
    data_type_a = {"data": {"type": "number"}}
    data_type_b = {"data": {"type": "string"}}

    # Should work with no parameters
    assert config() == {}

    # Should work with metadata, even if dataclasses_json is not present
    assert config(metadata=data_type_a) == data_type_a

    # Should add encoder
    data_type_a.setdefault('dataclasses_json', {})['encoder'] = str
    assert config(metadata=data_type_a, encoder=str) == data_type_a

    # Should add decoder
    data_type_b.setdefault('dataclasses_json', {})['decoder']

# Generated at 2022-06-23 16:40:44.468420
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class Foo:
        bar: str = field(metadata=config(exclude=Exclude.NEVER))
        baz: str = field(metadata=config(exclude=lambda x, y: True))

    assert isinstance(Foo.__dataclass_fields__["bar"].metadata, dict)
    assert Foo.__dataclass_fields__["bar"].metadata["dataclasses_json"]["exclude"] == Exclude.NEVER
    assert Foo.__dataclass_fields__["baz"].metadata["dataclasses_json"]["exclude"](None, None)

config.__test__ = False

# Generated at 2022-06-23 16:40:45.229492
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-23 16:40:50.587632
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)
    assert Exclude.NEVER("hello!")
    assert Exclude.NEVER("")
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(42)


# Generated at 2022-06-23 16:40:59.814119
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert(isinstance(global_config.encoders, dict))
    assert(isinstance(global_config.decoders, dict))
    assert(isinstance(global_config.mm_fields, dict))
    assert(global_config.encoders == {})
    assert(global_config.decoders == {})
    assert(global_config.mm_fields == {})


# Generated at 2022-06-23 16:41:00.639409
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:41:06.756462
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def _Exclude_ALWAYS(T):
        return True

    def _Exclude_ALWAYS_T(T):
        return True

    assert Exclude.ALWAYS(T=_Exclude_ALWAYS_T) == True


# Generated at 2022-06-23 16:41:07.988029
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global global_config
    _GlobalConfig() == global_config


# Generated at 2022-06-23 16:41:09.439424
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(int) is True

# Generated at 2022-06-23 16:41:10.669623
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) is False


# Generated at 2022-06-23 16:41:18.818368
# Unit test for function config
def test_config():
    encoder = int
    decoder = int
    mm_field = "mm_field"
    letter_case = str.capitalize
    undefined = str
    field_name = "field_name"
    exclude = "exclude"

    metadata = config(
        encoder=encoder,
        decoder=decoder,
        mm_field=mm_field,
        letter_case=letter_case,
        undefined=undefined,
        field_name=field_name,
        exclude=exclude
    )


# Generated at 2022-06-23 16:41:19.990697
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)



# Generated at 2022-06-23 16:41:25.186392
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(3.14129) == False
    assert Exclude.NEVER("none") == False
    assert Exclude.NEVER(['a','b','c']) == False
    assert Exclude.NEVER((2,3,(5,6,7))) == False
    assert Exclude.NEVER({'hello': 'world'}) == False
    assert Exclude.NEVER({'hello': 'world', 'name': 'khang'}) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER({}) == False


# Generated at 2022-06-23 16:41:26.844138
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.__init__ != None


# Generated at 2022-06-23 16:41:30.267250
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(-23) == True


# Generated at 2022-06-23 16:41:32.923702
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    assert c.encoders == {}
    assert c.decoders == {}
    assert c.mm_fields == {}


# Generated at 2022-06-23 16:41:39.118687
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(()) is False
    assert Exclude.NEVER(10) is False
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(Exclude) is False
    assert Exclude.NEVER('abc') is False
    assert Exclude.NEVER(Exclude.NEVER) is False
    assert Exclude.NEVER(test_Exclude_NEVER) is False

# Generated at 2022-06-23 16:41:48.579281
# Unit test for function config
def test_config():
    from marshmallow import fields, Schema

    class Example:
        def __init__(self, a):
            self.a = a

    class ExampleSchema(Schema):
        class Meta:
            fields = ('a', 'b')

    class ExampleSchemaB(Schema):
        class Meta:
            fields = ('c', 'd')

    # unit tests on fields

    @dataclasses.dataclass()
    @config(encoder=ExampleSchema, decoder=Example)
    class FooA:
        a: int
        b: int

    assert isinstance(dataclasses_json._get_encoder(FooA), ExampleSchema)

    # unit tests on nested fields


# Generated at 2022-06-23 16:41:56.344902
# Unit test for function config
def test_config():
    def assert_config(config, **kwargs):
        for key, value in kwargs.items():
            assert config[key] == value

    @dataclasses.dataclass
    class TestConfig:
        @dataclasses.dataclass
        class SubConfig:
            pass

    class TestMetaConfig:
        @dataclasses.dataclass
        class SubConfig:
            @config(undefined=Undefined.EXCLUDE)
            def method(self):
                pass

    @config(encoder=1)
    def encoder_function():
        pass

    @config(decoder=2)
    def decoder_function():
        pass

    @config(mm_field=3)
    def mm_field_function():
        pass


# Generated at 2022-06-23 16:42:01.873938
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('foo')
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(0.0)


# Generated at 2022-06-23 16:42:08.984372
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    @config(encoder=dict, decoder=dict)
    class TestConf:
        pass

    assert TestConf.__dataclass_json__['encoder'] == dict
    assert TestConf.__dataclass_json__['decoder'] == dict

    @dataclasses.dataclass
    @config(field_name='fff')
    class TestConf:
        pass

    assert TestConf.__dataclass_json__['mm_field'].attribute == 'fff'

test_config()

# Generated at 2022-06-23 16:42:11.416637
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0


# Generated at 2022-06-23 16:42:13.633836
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False


# Generated at 2022-06-23 16:42:15.430317
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()



# Generated at 2022-06-23 16:42:18.794128
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("A") == True
    assert Exclude.ALWAYS("B") == True
    assert Exclude.ALWAYS("C") == True


# Generated at 2022-06-23 16:42:21.566529
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()

    assert len(config.encoders) == 0
    assert len(config.decoders) == 0
    assert not config.mm_fields

# Generated at 2022-06-23 16:42:24.282358
# Unit test for function config
def test_config():
    try:
        config(undefined="fail")
        assert False, "Should not be possible to construct a config with " \
                      "undefined='fail'"
    except UndefinedParameterError:
        pass

# Generated at 2022-06-23 16:42:28.924394
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(0)
    assert Exclude.NEVER("test")
    assert Exclude.NEVER(" ")



# Generated at 2022-06-23 16:42:32.135726
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field_name = "test"
    field_value = "value"
    assert Exclude.NEVER(field_name)
    assert not Exclude.NEVER(field_value)


# Generated at 2022-06-23 16:42:32.783617
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:42:37.035029
# Unit test for constructor of class Exclude
def test_Exclude():
    x = Exclude()
    assert callable(x.NEVER)
    assert callable(x.ALWAYS)
    assert x.NEVER.__name__ == '<lambda>'
    assert x.ALWAYS.__name__ == '<lambda>'
    assert not x.NEVER(1)
    assert x.ALWAYS(1)

# Generated at 2022-06-23 16:42:37.849100
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(object) is True

# Generated at 2022-06-23 16:42:40.413023
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:42:44.424686
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config._json_module == json

# Generated at 2022-06-23 16:42:45.676518
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-23 16:42:51.464788
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	import dataclasses
	@dataclasses.dataclass
	class testClass:
		a:int
	tc = testClass(1)
	assert(Exclude.NEVER(tc) == False)

# Generated at 2022-06-23 16:42:53.037318
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-23 16:42:55.596334
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert type(global_config.encoders) == dict
    assert type(global_config.decoders) == dict
    assert type(global_config.mm_fields) == dict


# Generated at 2022-06-23 16:42:59.792433
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    assert global_config._json_module == json

# Generated at 2022-06-23 16:43:01.411975
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False



# Generated at 2022-06-23 16:43:05.371494
# Unit test for constructor of class Exclude
def test_Exclude():
    func = lambda _: True
    assert Exclude.ALWAYS == func
    assert Exclude.NEVER == func
    assert not Exclude.ALWAYS == Exclude.NEVER
    assert Exclude.ALWAYS is not Exclude.NEVER

# Generated at 2022-06-23 16:43:09.956203
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @config(exclude=Exclude.NEVER)
    class Person:
        name: str

    assert Person.__dataclass_fields__["name"].metadata["dataclasses_json"]["exclude"](Person(name="Mark")) == False


# Generated at 2022-06-23 16:43:12.090351
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:43:13.206772
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:43:14.257496
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)



# Generated at 2022-06-23 16:43:15.204380
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-23 16:43:16.141115
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:43:16.931514
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert not Exclude.ALWAYS("Hello")

# Generated at 2022-06-23 16:43:20.535458
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-23 16:43:21.479696
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test = _GlobalConfig()

# Generated at 2022-06-23 16:43:24.717094
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclasses.dataclass
    class DummyClass:
        field1: int
        field2: float
        
    dc = DummyClass(1, 2.0)
    assert Exclude.NEVER(dc.field1) == False


# Generated at 2022-06-23 16:43:35.466387
# Unit test for function config
def test_config():
    def assert_key_equals(obj, key, value):
        assert obj.get(key) == value

    assert_key_equals(config(), 'dataclasses_json', {})
    assert_key_equals(config(), 'dataclasses_json', {})
    assert_key_equals(config(), 'dataclasses_json', {})
    assert_key_equals(config(), 'dataclasses_json', {})
    assert_key_equals(config(), 'dataclasses_json', {})
    assert_key_equals(config(), 'dataclasses_json', {})
    assert_key_equals(config(), 'dataclasses_json', {})
    assert_key_equals(config(), 'dataclasses_json', {})

# Generated at 2022-06-23 16:43:36.578262
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-23 16:43:38.453028
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('any value')
    assert not Exclude.NEVER('any value')


# Generated at 2022-06-23 16:43:41.228540
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0
    # assert global_config.json_module == json


# Generated at 2022-06-23 16:43:43.142806
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_field=3
    assert Exclude.ALWAYS(test_field)
    return;


# Generated at 2022-06-23 16:43:45.844708
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # setup
    expected = True

    # given
    Exclude.ALWAYS()

    # when
    actual = Exclude.ALWAYS()

    # then
    assert(actual == expected)



# Generated at 2022-06-23 16:43:47.213703
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:43:49.422457
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(2) is False

# Generated at 2022-06-23 16:43:52.248365
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert a.encoders == {}
    assert a.decoders == {}
    assert a.mm_fields == {}


# Generated at 2022-06-23 16:43:53.011987
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-23 16:43:54.782926
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS('anything') is True)
    assert(Exclude.NEVER('anything') is False)

# Generated at 2022-06-23 16:44:05.811081
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config
    from marshmallow import fields
    import marshmallow

    @config()
    @dataclass
    class A:
        x: int = marshmallow.INCLUDE

    assert 'dataclasses_json' in A.__annotations__['x']
    assert A.__annotations__['x']['dataclasses_json']['exclude'] == Exclude.NEVER
    assert A.__annotations__['x']['dataclasses_json']['undefined'] == Undefined.ERROR
    assert A.__annotations__['x']['dataclasses_json']['mm_field'] is fields.Integer

    @config()
    @dataclass
    class A:
        x: int = marshmallow.EXCLU

# Generated at 2022-06-23 16:44:08.631093
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS('hello')
    assert Exclude.ALWAYS('')


# Generated at 2022-06-23 16:44:10.978468
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS([]) is True)
    assert(Exclude.NEVER([]) is False)

# Generated at 2022-06-23 16:44:14.300733
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS._func == Exclude.ALWAYS(1)
    assert Exclude.NEVER._func == Exclude.NEVER(1)


# Generated at 2022-06-23 16:44:16.058450
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("foo")
    assert not Exclude.NEVER("foo")

# Generated at 2022-06-23 16:44:25.454007
# Unit test for function config
def test_config():
    # TODO: more extensive testing
    from dataclasses import dataclass
    from dataclasses_json.mm_field import MMField

    @dataclass
    class A:
        field_a: int = config(encoder=int)

    class B:
        mm_field_b: str = config(mm_field=MMField())

    assert A.__dataclass_metadata__['field_a'] == {
        'dataclasses_json': {
            'encoder': int
        }
    }

    assert B.mm_field_b.__dataclass_metadata__ == {
        'dataclasses_json': {
            'mm_field': MMField()
        }
    }
