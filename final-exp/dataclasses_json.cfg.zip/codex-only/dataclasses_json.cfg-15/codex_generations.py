

# Generated at 2022-06-23 16:34:21.654075
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(0) == True
	assert Exclude.ALWAYS(1) == True
	assert Exclude.ALWAYS(False) == True
	assert Exclude.ALWAYS(True) == True
	assert Exclude.ALWAYS(None) == True
	assert Exclude.ALWAYS('string') == True

# Generated at 2022-06-23 16:34:32.089537
# Unit test for function config
def test_config():
    """
    Test for config function
    """
    from typing import Set
    from marshmallow import fields
    fake_encoder = lambda x: x
    fake_decoder = lambda x: x
    fake_mm_field = fields.UUID

    test_cases = [
        {'encoder': fake_encoder},
        {'decoder': fake_decoder},
        {'mm_field': fake_mm_field},
        {'letter_case': lambda x: x},
        {'undefined': Undefined.RAISE},
        {'field_name': ''},
        {'exclude': lambda x, y: True}
    ]

    for test_case in test_cases:
        assert config(**test_case) == {'dataclasses_json': test_case}


# Generated at 2022-06-23 16:34:34.701214
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert isinstance(Exclude.ALWAYS, Callable), "Exclude.ALWAYS must be a function"

# Generated at 2022-06-23 16:34:38.300397
# Unit test for constructor of class Exclude
def test_Exclude():
    try:
        assert Exclude.ALWAYS(True) is True
        assert Exclude.ALWAYS(False) is True
        assert Exclude.NEVER(True) is False
        assert Exclude.NEVER(False) is False
    except AssertionError:
        print("Exclude failed")
        assert False

# Generated at 2022-06-23 16:34:40.008246
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True


# Generated at 2022-06-23 16:34:41.672962
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    func = Exclude.NEVER
    assert func(0) == False
    assert func(1) == False

# Generated at 2022-06-23 16:34:43.029283
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    v = Exclude.ALWAYS(3)
    assert v == True



# Generated at 2022-06-23 16:34:44.673069
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)


# Generated at 2022-06-23 16:34:47.023933
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}



# Generated at 2022-06-23 16:34:49.174902
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(-2829) == False
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-23 16:34:51.839384
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    instance = _GlobalConfig()
    assert type(instance) == _GlobalConfig
    assert instance.encoders == {}
    assert instance.decoders == {}
    assert instance.mm_fields == {}


# Generated at 2022-06-23 16:34:53.468432
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert isinstance(global_config1, _GlobalConfig)


# Generated at 2022-06-23 16:34:54.521600
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-23 16:34:57.088911
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('foo') == False


# Generated at 2022-06-23 16:35:00.577566
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:35:11.990950
# Unit test for function config
def test_config():
    class A:
        pass
    a = A()
    assert config(a) is a
    assert config(A) is A
    assert config() == {'dataclasses_json': {}}
    assert config(decoder=a) == config(decoder=A) == {'dataclasses_json': {'decoder': a}}
    assert config(encoder=a) == config(encoder=A) == {'dataclasses_json': {'encoder': a}}
    assert config(mm_field=a) == config(mm_field=A) == {'dataclasses_json': {'mm_field': a}}
    assert config(letter_case=a) == config(letter_case=A) == {'dataclasses_json': {'letter_case': a}}
    assert config(undefined=a)

# Generated at 2022-06-23 16:35:20.979738
# Unit test for function config
def test_config():
    metadata = config()
    assert metadata == {
        'dataclasses_json': {}
    }

    metadata = config(encoder=object, decoder=object, mm_field=object, field_name='field_name')
    assert metadata == {
        'dataclasses_json': {
            'encoder': object,
            'decoder': object,
            'mm_field': object,
            'undefined': Undefined.EXCLUDE,
            'letter_case': 'field_name',
            'exclude': Exclude.NEVER
        }
    }

    metadata = config(
        encoder=object,
        decoder=object,
        mm_field=object,
        field_name='name',
        undefined='RAISE',
        exclude=Exclude.ALWAYS,
    )

# Generated at 2022-06-23 16:35:23.667010
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    exc = Exclude.NEVER(Bunch.SomeClass(1))
    assert exc is False


# Generated at 2022-06-23 16:35:26.568756
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    expected_encoders = {}
    expected_decoders = {}
    expected_mm_fields = {}
    config = _GlobalConfig()

    assert config.encoders == expected_encoders
    assert config.decoders == expected_decoders
    assert config.mm_fields == expected_mm_fields
    # TODO: #180
    # assert config.json_module == json


# Generated at 2022-06-23 16:35:34.400270
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined
    from dataclasses_json._config import Config, GlobalConfig
    from typing import NewType
    import datetime
    import json
    import marshmallow as ma
    import datetime
    import dateutil.parser
    import pytz
    import sys

    UUID = NewType('UUID', str)


# Generated at 2022-06-23 16:35:39.805709
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS(1))
    assert(Exclude.ALWAYS("c"))
    assert(Exclude.ALWAYS(Exclude.NEVER))
    assert(not Exclude.NEVER(1))
    assert(not Exclude.NEVER("c"))
    assert(not Exclude.NEVER(Exclude.ALWAYS))



# Generated at 2022-06-23 16:35:41.139785
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER({"test": "yes"})




# Generated at 2022-06-23 16:35:43.642869
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-23 16:35:45.688573
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:35:48.742743
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:35:50.438953
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()

# Generated at 2022-06-23 16:35:53.401859
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
   a = Exclude.NEVER("a")
   b = Exclude.NEVER("b")
   c = Exclude.NEVER("c")
   assert a == b and b == c

# Generated at 2022-06-23 16:35:55.680962
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a=Exclude.NEVER({"test":"test"})
    if a!=False:
        raise ValueError("NEVER method of Exclude return the wrong value")

# Generated at 2022-06-23 16:35:59.140080
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    # Check defaults
    assert(global_config.encoders == {})
    assert(global_config.decoders == {})
    assert(global_config.mm_fields == {})
    # TODO: #180
    # assert(global_config.json_module == json)


# Generated at 2022-06-23 16:36:01.626304
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hello") == True


# Generated at 2022-06-23 16:36:03.302417
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert Exclude.NEVER(1)


# Generated at 2022-06-23 16:36:06.219041
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config, _GlobalConfig)
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    # assert config._json_module == json

# Generated at 2022-06-23 16:36:08.164467
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-23 16:36:09.534190
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test_true")


# Generated at 2022-06-23 16:36:12.141374
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER.__name__ == 'NEVER'
    assert Exclude.NEVER('ss') is False


# Generated at 2022-06-23 16:36:20.520899
# Unit test for function config
def test_config():
    # Check if config works properly
    assert 'dataclasses_json' not in config()
    assert 'encoder' not in config()
    assert 'decoder' not in config()
    assert 'mm_field' not in config()
    assert 'letter_case' not in config()
    assert 'undefined' not in config()
    assert 'exclude' not in config()

    encoder = lambda _: None
    decoder = lambda _: None
    mm_field = None
    letter_case = lambda _: 'default'
    undef = 'raise'
    exclude = Exclude.ALWAYS
    assert 'dataclasses_json' in config(encoder=encoder)
    assert 'encoder' in config(encoder=encoder)
    assert 'dataclasses_json' in config(decoder=decoder)
   

# Generated at 2022-06-23 16:36:21.818814
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(_GlobalConfig(), _GlobalConfig)


# Generated at 2022-06-23 16:36:24.668665
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    ex = Exclude.NEVER
    fake_field = 'fake_field'

    # Act
    result = ex(fake_field)

    # Assert
    assert result==False

# Generated at 2022-06-23 16:36:26.428677
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_func = Exclude.ALWAYS
    assert test_func(1) == True


# Generated at 2022-06-23 16:36:27.914524
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('123') == True
    assert Exclude.NEVER('123') == False

# Generated at 2022-06-23 16:36:30.054546
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a') == True
    assert Exclude.NEVER('a') == False

# Generated at 2022-06-23 16:36:31.977094
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:36:33.882487
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:36:36.718253
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(Exclude())
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(Exclude.NEVER)


# Generated at 2022-06-23 16:36:39.584511
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-23 16:36:46.104730
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from marshmallow import fields

    global_config.encoders[str] = str
    assert global_config.encoders[str] == str

    global_config.decoders[str] = str
    assert global_config.decoders[str] == str

    global_config.mm_fields[str] = fields.String()
    assert global_config.mm_fields[str] == fields.String()



# Generated at 2022-06-23 16:36:52.001953
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert type(global_config) == _GlobalConfig
    assert type(global_config.encoders) == dict
    assert type(global_config.decoders) == dict
    assert type(global_config.mm_fields) == dict
    # assert type(global_config._json_module == dict)

test__GlobalConfig()

# Generated at 2022-06-23 16:36:53.395550
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(16) is True


# Generated at 2022-06-23 16:36:55.147456
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-23 16:36:56.811993
# Unit test for constructor of class Exclude
def test_Exclude():
    assert "" == Exclude.ALWAYS("")
    assert None == Exclude.NEVER(None)

# Generated at 2022-06-23 16:37:03.249686
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    class TestField:
        field: str

    import marshmallow
    field = marshmallow.fields.String(required=False)
    @config(mm_field=field)
    class Test:
        x: TestField

    assert Test.x.field_type.required is False


# Generated at 2022-06-23 16:37:13.193063
# Unit test for function config
def test_config():
    # Test when everything is None
    test_dict = config()
    assert 'dataclasses_json' in test_dict.keys()

    # Test when we pass an argument
    test_dict = config(encoder=lambda x: str(x))
    assert 'dataclasses_json' in test_dict.keys()
    assert 'encoder' in test_dict['dataclasses_json'].keys()

    # Test when we pass a metadata dict
    test_dict = config({'x': 2}, encoder=lambda x: str(x))
    assert 'x' in test_dict.keys()
    assert 'dataclasses_json' in test_dict.keys()
    assert 'encoder' in test_dict['dataclasses_json'].keys()

# Generated at 2022-06-23 16:37:15.757026
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(None)==False)


# Generated at 2022-06-23 16:37:25.678786
# Unit test for function config
def test_config():
    from marshmallow import fields as mmf
    import marshmallow as mm

    @dataclass
    class A:
        x: int

    @dataclass
    class B:
        y: int

    assert 'dataclasses_json' not in fields(A)
    assert 'dataclasses_json' not in fields(B)

    # TODO: it's important to test field names as well

    # TODO: we don't need to test the rest of this
    @config(encoder=lambda x: x + 1, decoder=lambda x: x - 1)
    @dataclass
    class C:
        z: int

    assert 'encoder' in fields(C)['z']['dataclasses_json']
    assert 'decoder' in fields(C)['z']['dataclasses_json']



# Generated at 2022-06-23 16:37:29.494256
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert type(global_config.encoders) == dict
    assert type(global_config.decoders) == dict
    assert type(global_config.mm_fields) == dict

# Generated at 2022-06-23 16:37:32.405249
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    x = _GlobalConfig()
    assert x.encoders == dict() and x.decoders == dict() and x.mm_fields == dict()

test__GlobalConfig()

# Generated at 2022-06-23 16:37:37.167873
# Unit test for function config
def test_config():
    from marshmallow_dataclass import class_schema
    from dataclasses import dataclass

    @dataclass
    class Foo:
        i: int

    @config(exclude=Exclude.ALWAYS)
    class Foo:
        pass

    assert "exclude" in class_schema(Foo)._config["dataclasses_json"]

# Generated at 2022-06-23 16:37:39.953674
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    assert Exclude.ALWAYS('always')


# Generated at 2022-06-23 16:37:43.418273
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("a") == True
    assert Exclude.NEVER("a") == False

# Generated at 2022-06-23 16:37:45.888091
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(False)



# Generated at 2022-06-23 16:37:48.456123
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER(5)
    assert type(x) is bool


# Generated at 2022-06-23 16:37:50.447801
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:37:52.042578
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:37:53.396917
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER(1) is False
    assert Exclude.ALWAYS(1) is True


# Generated at 2022-06-23 16:38:02.571488
# Unit test for function config
def test_config():
    import marshmallow as ma
    from dataclasses import dataclass, field
    from dataclasses_json import config, DataClassJsonMixin, LetterCase, Undefined

    @dataclass
    class Test(DataClassJsonMixin):
        name: str
        name2: str
        name3: str
        name4: str
        name5: str
        name6: str
        name7: str
        name8: str
        name9: str
        name10: str
        name11: str
        name12: str

    def letter_case(name: str):
        return name + "_123"


# Generated at 2022-06-23 16:38:05.558340
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    @config(encoder={'bar': 'test'})
    class Dataclass:
        foo = 0
        bar = 1

    assert Dataclass.__dataclasses_json__['encoder']['bar'] == 'test'

# Generated at 2022-06-23 16:38:06.981777
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:38:08.712055
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('anything') == True
    assert Exclude.NEVER('anything') == False

# Generated at 2022-06-23 16:38:10.582507
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(10) == True
    assert Exclude.NEVER(10) == False

# Generated at 2022-06-23 16:38:12.297474
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-23 16:38:14.030191
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-23 16:38:17.847155
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(1))
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:38:18.786942
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config._GlobalConfig()



# Generated at 2022-06-23 16:38:21.398067
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    assert conf.encoders == {}
    assert conf.decoders == {}
    assert conf.mm_fields == {}


# Generated at 2022-06-23 16:38:22.709102
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-23 16:38:25.368524
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Test if default constructor value is {T,T}
    config = _GlobalConfig()
    assert isinstance(config.encoders, dict)
    assert isinstance(config.decoders, dict)


# Generated at 2022-06-23 16:38:27.920359
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-23 16:38:31.288319
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("1") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS([1, 2]) == True
    assert Exclude.ALWAYS({"a": 1}) == True


# Generated at 2022-06-23 16:38:32.785724
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(12) == False

# Generated at 2022-06-23 16:38:36.201827
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([0, 1]) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("abc") == False

# Generated at 2022-06-23 16:38:38.426948
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-23 16:38:41.151082
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  result = Exclude.NEVER("anything")
  expected = False
  assert result == expected, "NEVER method of class Exclude do not work"


# Generated at 2022-06-23 16:38:43.005781
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)


# Generated at 2022-06-23 16:38:47.014409
# Unit test for function config
def test_config():
    metadata = dict()
    config(metadata, encoder="encoder", decoder="decoder",
           mm_field="field", letter_case="lower", undefined="ignore",
           field_name="Field", exclude=lambda f, _: f != "Field")

# Generated at 2022-06-23 16:38:51.051352
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert(config.encoders == dict())
    assert(config.decoders == dict())
    assert(config.mm_fields == dict())
    # assert(config.json_module == json)


# Generated at 2022-06-23 16:38:52.539070
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(2)
    assert result == False


# Generated at 2022-06-23 16:38:55.947934
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("field") == True


# Generated at 2022-06-23 16:38:57.505813
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude = Exclude()
    assert exclude.ALWAYS(1)
    assert not exclude.NEVER(1)

# Generated at 2022-06-23 16:38:59.150736
# Unit test for constructor of class Exclude
def test_Exclude():
    print("Creating an instance of Exclude class")


# Generated at 2022-06-23 16:39:02.569421
# Unit test for constructor of class Exclude
def test_Exclude():
   if Exclude.ALWAYS is not None:
       print("True")
   else:
       print("False")

   if Exclude.NEVER is not None:
       print("True")
   else:
       print("False")

test_Exclude()

# Generated at 2022-06-23 16:39:04.680960
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('abc')
    assert not Exclude.NEVER('abc')



# Generated at 2022-06-23 16:39:06.688927
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:39:08.034215
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(12)
    assert not Exclude.NEVER(12)

# Generated at 2022-06-23 16:39:09.434133
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('abc')

# Generated at 2022-06-23 16:39:15.747735
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_1 = _GlobalConfig()
    assert (type(global_config_1) == _GlobalConfig), "global_config_1 type is correct"
    assert (type(global_config_1.encoders) == dict), "global_config_1.encoder type is correct"
    assert (type(global_config_1.decoders) == dict), "global_config_1.decoder type is correct"
    assert (type(global_config_1.mm_fields) == dict), "global_config_1.mm_field type is correct"
    print("_GlobalConfig constructor unit test successful")


# Generated at 2022-06-23 16:39:18.280350
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False

# Generated at 2022-06-23 16:39:19.714501
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('test')
    assert not Exclude.NEVER('test')


# Generated at 2022-06-23 16:39:21.179213
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-23 16:39:22.233325
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == dict()

# Generated at 2022-06-23 16:39:24.019105
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)


# Generated at 2022-06-23 16:39:28.288825
# Unit test for function config
def test_config():
    import sys
    if sys.version_info < (3, 8):
        return

    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

        @config(encoder=lambda obj: f"{obj.name} is {obj.age} years old")
        def __str__(self):
            pass

# Generated at 2022-06-23 16:39:29.098504
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('text')

# Generated at 2022-06-23 16:39:31.746028
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test = _GlobalConfig()
    assert test.encoders == {}
    assert test.decoders == {}
    assert test.mm_fields == {}

# Generated at 2022-06-23 16:39:34.276663
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:39:36.410084
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(4) is True
    assert Exclude.NEVER(4) is False



# Generated at 2022-06-23 16:39:38.072194
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("f")


# Generated at 2022-06-23 16:39:39.511217
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER.__name__ == "NEVER"
    

# Generated at 2022-06-23 16:39:40.672807
# Unit test for function config
def test_config():
    ...

# Generated at 2022-06-23 16:39:42.684132
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('name') == False


# Generated at 2022-06-23 16:39:50.193887
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config
    assert isinstance(config,_GlobalConfig)
    assert config.encoders
    assert isinstance(config.encoders, dict)
    assert config.decoders
    assert isinstance(config.decoders, dict)
    assert config.mm_fields
    assert isinstance(config.mm_fields, dict)

test__GlobalConfig()

# Generated at 2022-06-23 16:39:53.807412
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("Exclude.ALWAYS returns True")
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:40:04.391498
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from datetime import datetime
    from typing import List

    from dataclasses import dataclass

    from dataclasses_json import config
    from dataclasses_json.undefined import Undefined
    from .utils import assert_encode_decode

    @dataclass
    @config(undefined=Undefined.EXCLUDE)
    class D:
        a: Optional[str] = None

    @dataclass
    @config(undefined=Undefined.EXCLUDE)
    class E:
        a: str = "Hello"

    @dataclass
    @config(undefined=Undefined.EXCLUDE)
    class G:
        d: Optional[D] = None


# Generated at 2022-06-23 16:40:07.484983
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude_NEVER = Exclude.NEVER
    assert Exclude_NEVER(1) == False



# Generated at 2022-06-23 16:40:09.208724
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:40:14.476531
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	#arrange
	e = Exclude.NEVER
	#act
	b = e("DataClassesJson")
	#assert
	assert b, "Expected b to be True"
	

# Generated at 2022-06-23 16:40:18.926654
# Unit test for constructor of class Exclude
def test_Exclude():
    #call the constructor 
    x = Exclude()
    #return the key always
    assert(x.ALWAYS is not None)
    #return the key never 
    assert(x.NEVER is not None)

# Generated at 2022-06-23 16:40:20.540054
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-23 16:40:23.478012
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)



# Generated at 2022-06-23 16:40:27.560324
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:40:32.691956
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders[int] = int.__bool__
    global_config.decoders[str] = str.__bool__
    global_config.mm_fields[bool] = bool.__eq__

    print(f"encoders: {global_config.encoders}\n"
          f"decoders: {global_config.decoders}\n"
          f"mm_fields: {global_config.mm_fields}")

if __name__ == "__main__":
    test__GlobalConfig()

# Generated at 2022-06-23 16:40:33.404086
# Unit test for constructor of class Exclude
def test_Exclude():
    print(Exclude.ALWAYS(1))

# Generated at 2022-06-23 16:40:38.703047
# Unit test for function config
def test_config():
    assert config(undefined='ignore')['dataclasses_json']['undefined'] == Undefined.IGNORE
    assert config(field_name='hello_world')['dataclasses_json'] == {
        'letter_case': lambda field_name: 'hello_world'
    }

# Generated at 2022-06-23 16:40:41.355634
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    Test the method NEVER of class Exclude
    :return:
    """
    f = Exclude.NEVER
    assert f("this will always return False") is False


# Generated at 2022-06-23 16:40:44.358840
# Unit test for constructor of class Exclude
def test_Exclude():
    assert not Exclude.ALWAYS(None)
    assert Exclude.NEVER(None)



# Generated at 2022-06-23 16:40:54.720159
# Unit test for function config
def test_config():
    @config(metadata=dict(), encoder=Base64Encoder, exclude=Exclude.ALWAYS)
    class MyDataClass:
        foo: int
        bar: int

    MyDataClass.Config.encoder == Base64Encoder
    MyDataClass.Config.exclude == Exclude.ALWAYS

    config(MyDataClass, undefined="raises")

    assert(MyDataClass.Config.undefined == Undefined.RAISES)

    config(MyDataClass, undefined=Undefined.USE_DEFAULTS)
    assert(MyDataClass.Config.undefined == Undefined.USE_DEFAULTS)
    try:
        config(MyDataClass, undefined="invalid")
        assert(False)
    except:
        pass


# Generated at 2022-06-23 16:40:56.887543
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS)
    return Exclude.ALWAYS


# Generated at 2022-06-23 16:40:58.448229
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS()
    assert not Exclude.NEVER()

# Generated at 2022-06-23 16:41:01.615409
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert isinstance(g.encoders, dict)
    assert isinstance(g.decoders, dict)
    assert isinstance(g.mm_fields, dict)

# Generated at 2022-06-23 16:41:04.796452
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(Exclude.ALWAYS))


# Generated at 2022-06-23 16:41:06.220985
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    r = Exclude.NEVER(1)
    assert r == False

# Generated at 2022-06-23 16:41:07.907023
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-23 16:41:09.735571
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    assert e.ALWAYS(1) == True

# Generated at 2022-06-23 16:41:10.961050
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    res = Exclude.NEVER(0)
    assert res == False


# Generated at 2022-06-23 16:41:14.167816
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    assert Exclude.NEVER({'a': 1}) == False

# Generated at 2022-06-23 16:41:21.098102
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    _encoders = global_config.encoders
    _decoders = global_config.decoders
    _mm_fields = global_config.mm_fields
    assert isinstance(_encoders, dict)
    assert isinstance(_decoders, dict)
    assert isinstance(_mm_fields, dict)

# Generated at 2022-06-23 16:41:22.528951
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:41:27.065820
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-23 16:41:28.355461
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-23 16:41:31.485219
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(2.0)
    assert Exclude.NEVER('test')


# Generated at 2022-06-23 16:41:33.046907
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config_ = _GlobalConfig()
    assert config_.encoders == {}
    assert config_.decoders == {}
    assert config_.mm_fields == {}

# Generated at 2022-06-23 16:41:35.522338
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:41:37.720207
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-23 16:41:39.167392
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    t = Exclude.NEVER
    assert t('a') is False

# Generated at 2022-06-23 16:41:40.549855
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:41:41.861826
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False


# Generated at 2022-06-23 16:41:51.444957
# Unit test for function config
def test_config():
    from marshmallow import fields, Schema
    from marshmallow.validate import Regexp

    class MySchema(Schema):
        regex_field = fields.String(validate=Regexp(r'^\w+$'))

        @property
        def is_valid(self):
            return self.is_valid

    @config(encoder=lambda x: x.upper(),
            decoder=lambda x: x.lower(),
            mm_field=fields.Integer(),
            letter_case=lambda x: x.replace('_', ''),
            undefined=Undefined.EXCLUDE,
            field_name='field_name',
            exclude=Exclude.ALWAYS)
    class MyClass:
        field_name: str
        prop: str


# Generated at 2022-06-23 16:41:55.216945
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:42:01.909294
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    config.encoders[1] = 3
    config.decoders[2] = 4
    config.mm_fields[3] = 5
    assert config.encoders == {1: 3}
    assert config.decoders == {2: 4}
    assert config.mm_fields == {3: 5}

# Generated at 2022-06-23 16:42:08.983953
# Unit test for function config
def test_config():

    from marshmallow import fields as mm_fields

    from dataclasses_json.undefined import Undefined

    class TestConfig:

        class Meta:
            dataclasses_json = {
                'encoder': int,
                'decoder': float,
                'mm_field': mm_fields.Integer(),
                'letter_case': lambda _: 'snake_case',
                'undefined': Undefined.EXCLUDE,
                'exclude': Exclude.NEVER
            }

    test = TestConfig()



# Generated at 2022-06-23 16:42:15.329373
# Unit test for function config
def test_config():
    import marshmallow as mm
    assert config() == {'dataclasses_json': {}}
    assert config(encoder=int) == {'dataclasses_json': {'encoder': int}}
    assert config(decoder=float) == {'dataclasses_json': {'decoder': float}}
    assert config(mm_field=mm.fields.Integer()) == {'dataclasses_json': {'mm_field': mm.fields.Integer()}}
    assert config(letter_case=config.CAMELCASE) == {'dataclasses_json': {'letter_case': config.CAMELCASE}}
    assert config(undefined=Undefined.EXCLUDE) == {'dataclasses_json': {'undefined': Undefined.EXCLUDE}}

# Generated at 2022-06-23 16:42:17.393993
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('This') == True


# Generated at 2022-06-23 16:42:19.168753
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2)
    assert not Exclude.NEVER(2)

# Generated at 2022-06-23 16:42:27.392855
# Unit test for function config
def test_config():
    import pytest
    from marshmallow import fields
    from marshmallow.exceptions import ValidationError
    from marshmallow.validate import Range

    @public
    @dataclass
    @config(mm_field=fields.Integer(validate=Range(0, 120)),
            letter_case=lambda s: s[:2])
    class Person:
        age: int
        full_name: str

    assert Person.Config.mm_field == fields.Integer(validate=Range(0, 120))
    assert Person.Config.letter_case('full_name') == 'fu'
    obj = Person(age=50, full_name='John Doe')
    assert Person.Schema().dump(obj) == {'fu': 'John Doe', 'ag': 50}


# Generated at 2022-06-23 16:42:29.043924
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10)

# Generated at 2022-06-23 16:42:31.486847
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:42:40.111737
# Unit test for function config
def test_config():
    assert config(metadata={'a': 1}, field_name='field') == {
        'a': 1,
        'dataclasses_json': {'field_name': 'field'}}
    assert config(metadata={'a': 1}, encoder=1) == {
        'a': 1,
        'dataclasses_json': {'encoder': 1}}
    assert config(metadata={'a': 1}, decoder=1) == {
        'a': 1,
        'dataclasses_json': {'decoder': 1}}
    assert config(metadata={'a': 1}, mm_field=1) == {
        'a': 1,
        'dataclasses_json': {'mm_field': 1}}

# Generated at 2022-06-23 16:42:44.589199
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()

    assert(g.encoders == {})
    assert(g.decoders == {})
    assert(g.mm_fields == {})
    # assert(g.json_module == json)

# Generated at 2022-06-23 16:42:48.066188
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(23) == False


# Generated at 2022-06-23 16:42:52.997731
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    assert isinstance(c.encoders, dict)
    assert isinstance(c.decoders, dict)
    assert isinstance(c.mm_fields, dict)
    # assert isinstance(c.json_module, type)

# Generated at 2022-06-23 16:42:54.387235
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:42:55.645514
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    global Exclude

    assert Exclude.ALWAYS(42) # Always True

# Generated at 2022-06-23 16:43:07.243741
# Unit test for function config
def test_config():
    from dataclasses import dataclass, replace

    from marshmallow import fields

    from dataclasses_json.config import (
        Exclude,
        global_config,
        mm_fields,
    )

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class Dummy:
        pass

    # Test exclude
    lotr = Dummy()
    assert 'exclude' in lotr.__dataclass_fields__['dataclasses_json'].metadata
    assert lotr.__dataclass_fields__['dataclasses_json'].metadata['exclude'] \
        == Exclude.ALWAYS

    @config(mm_field=fields.UUID)
    @dataclass
    class Dummy:
        id: str

    # Test mm_field
    lotr = Dummy

# Generated at 2022-06-23 16:43:08.849256
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (Exclude.ALWAYS(0) == True)
    assert (Exclude.NEVER(0) == False)

# Generated at 2022-06-23 16:43:10.976320
# Unit test for constructor of class Exclude
def test_Exclude():
    """Test case to verify correctness of the Exclude class"""
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:43:14.255621
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:43:15.509113
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:43:16.211006
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()



# Generated at 2022-06-23 16:43:17.269889
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER("")
    assert not Exclude.ALWAYS("")

# Generated at 2022-06-23 16:43:21.964985
# Unit test for function config
def test_config():
    assert config(encoder=int, field_name="Unit Test") == {
        "dataclasses_json": {
            "encoder": int,
            "letter_case": "Unit Test"
        }
    }

# Generated at 2022-06-23 16:43:23.541531
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-23 16:43:26.969060
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    actual_result = Exclude.ALWAYS
    expected_result = lambda _: True
    assert (actual_result == expected_result)


# Generated at 2022-06-23 16:43:28.319956
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(T) is True


# Generated at 2022-06-23 16:43:31.194528
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-23 16:43:31.839617
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:43:32.953100
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-23 16:43:36.199877
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    first_name = 'Bob'
    Exclude.NEVER = lambda x: False
    if Exclude.NEVER(first_name):
        print("Included")
    else:
        print("Excluded")

# Generated at 2022-06-23 16:43:46.191347
# Unit test for function config
def test_config():
    import marshmallow
    class Meta:
        pass

    # default config
    assert config() == {'dataclasses_json': {}}

    # config itself
    assert config(
        metadata=config())['dataclasses_json'] == {}

    # encoder
    assert config(encoder=str)['dataclasses_json']['encoder'] == str
    assert config(encoder=lambda: None)['dataclasses_json']['encoder'] is not None

    # decoder
    assert config(decoder=int)['dataclasses_json']['decoder'] == int
    assert config(decoder=lambda: None)['dataclasses_json']['decoder'] is not None

    # mm_field

# Generated at 2022-06-23 16:43:57.017956
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Test for basic function
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}
    #assert gc._json_module == json

    # Test for add/remove encoder
    gc.encoders[int] = False
    assert gc.encoders == {int: False}
    del gc.encoders[int]
    assert gc.encoders == {}

    # Test for add/remove decoder
    gc.decoders[int] = False
    assert gc.decoders == {int: False}
    del gc.decoders[int]
    assert gc.decoders == {}

    # Test for add/remove mm_field
    gc.mm

# Generated at 2022-06-23 16:43:57.589489
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:44:07.705378
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    import json

    @dataclass
    @config(encoder=lambda o: json.dumps(o.__dict__),
            decoder=lambda d: json.loads(d),
            mm_field=fields.Field,
            letter_case=lambda s: s + '_modified',
            undefined=Undefined.EXCLUDE,
            exclude=lambda f: f == 'is_exclude')
    class Data:
        is_exclude: bool

    assert Data.__dataclass_json__.encoder is not None
    assert Data.__dataclass_json__.decoder is not None
    assert Data.__dataclass_json__.mm_field is not None

# Generated at 2022-06-23 16:44:18.824966
# Unit test for function config
def test_config():
    @dataclass
    class T:
        a: str = "foo"
        b: int = 1

    @config(encoder=1, decoder=2, mm_field=3, field_name="a",
            letter_case=4, undefined=5, exclude=6)
    class T:
        a: str = "foo"
        b: int = 1

    assert T.__dataclass_json__["encoder"] == 1
    assert T.__dataclass_json__["decoder"] == 2
    assert T.__dataclass_json__["mm_field"] == 3
    assert T.__dataclass_json__["field_name"] == 4
    assert T.__dataclass_json__["undefined"] == 5