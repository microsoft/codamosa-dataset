

# Generated at 2022-06-23 16:34:28.381339
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config
    import marshmallow as ma
    from marshmallow import fields

    global_config.mm_fields[int] = ma.fields.Integer()
    global_config.mm_fields[str] = ma.fields.Str()

    @config(encoder='decoders.MyEncoder',
            decoder='decoders.MyDecoder',
            mm_field=fields.Number(as_string=True),
            letter_case='snake_case',
            undefined='REMOVE',
            field_name='my_field_name',
            exclude=Exclude.ALWAYS)
    @dataclass
    class MyClass:
        i: int
        s: str
        my_field_name: int

    assert MyClass.__dataclass_

# Generated at 2022-06-23 16:34:30.326941
# Unit test for constructor of class Exclude
def test_Exclude():
    from Exclude import Exclude
    assert Exclude.ALWAYS(10) == True
    assert Exclude.NEVER(20) == False

# Generated at 2022-06-23 16:34:36.609254
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow.fields import String
    @dataclass
    class Example:
        a: str = config(encoder=str)
        b: str = config(decoder=str)
        c: str = config(mm_field=String)
        d: str = config(field_name="ABC")
        e: str = config(letter_case="lower")

    assert Example.a.__dataclass_json__['encoder'] == str
    assert Example.b.__dataclass_json__['decoder'] == str
    assert Example.c.__dataclass_json__['mm_field'] == String
    assert Example.d.__dataclass_json__['letter_case'](None) == "ABC"

# Generated at 2022-06-23 16:34:43.076717
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS((1,2)) == True
    assert Exclude.ALWAYS(range(0,6)) == True


# Generated at 2022-06-23 16:34:45.432270
# Unit test for function config
def test_config():
    metadata = config(letter_case='snake', undefined='ignore', exclude='')
    assert metadata['dataclasses_json']['letter_case'] == ''
    assert metadata['dataclasses_json']['undefined'] == Undefined.IGNORE
    assert metadata['dataclasses_json']['exclude'] == ''

# Generated at 2022-06-23 16:34:46.669122
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:34:48.558923
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS([1,2,3]) == True


# Generated at 2022-06-23 16:34:50.108509
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER
    assert(Exclude.NEVER(1) == False)


# Generated at 2022-06-23 16:34:52.339393
# Unit test for constructor of class Exclude
def test_Exclude():
    # Make sure the constants are defined
    assert(Exclude.ALWAYS is not None)
    assert(Exclude.NEVER is not None)

# Generated at 2022-06-23 16:34:54.002487
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()
    assert Exclude.ALWAYS(2)
    assert not Exclude.NEVER(2)

# Generated at 2022-06-23 16:34:54.874656
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

# Generated at 2022-06-23 16:34:57.090545
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") is False

# Generated at 2022-06-23 16:35:04.987630
# Unit test for function config
def test_config():
    global_config.encoders.clear()
    global_config.decoders.clear()
    global_config.mm_fields.clear()
    from dataclasses import dataclass
    from decimal import Decimal

    @dataclass
    class Test:
        test: Decimal

    assert Decimal not in global_config.encoders
    config(encoder=str)(Test)
    assert Decimal in global_config.encoders

    assert Decimal not in global_config.decoders
    config(decoder=float)(Test)
    assert Decimal in global_config.decoders

    from marshmallow import fields
    assert Decimal not in global_config.mm_fields
    mm_field = fields.Decimal()
    config(mm_field=mm_field)(Test)
    assert Decimal in global_

# Generated at 2022-06-23 16:35:08.305645
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == Exclude.ALWAYS("foo") == True
    assert Exclude.NEVER(1) == Exclude.NEVER("foo") == False


# Generated at 2022-06-23 16:35:11.096281
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()

    assert(gc.encoders == {})
    assert(gc.decoders == {})
    assert(gc.mm_fields == {})



# Generated at 2022-06-23 16:35:13.176974
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:35:15.484238
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(False) == True
    assert Exclude.NEVER(False) == False

test_Exclude()

# Generated at 2022-06-23 16:35:19.404777
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert callable(Exclude.ALWAYS)
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True
    

# Generated at 2022-06-23 16:35:20.234314
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False

# Generated at 2022-06-23 16:35:25.435915
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # The result of NEVER for a given value should always be true
    assert Exclude.NEVER(1) == True
    assert Exclude.NEVER(None) == True
    assert Exclude.NEVER("") == True



# Generated at 2022-06-23 16:35:26.644865
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER



# Generated at 2022-06-23 16:35:33.973515
# Unit test for function config

# Generated at 2022-06-23 16:35:36.392909
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    dummy = 'dummy'
    assert Exclude.NEVER(dummy) == False


# Generated at 2022-06-23 16:35:38.433020
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:35:39.805466
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("None") == False


# Generated at 2022-06-23 16:35:45.123830
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined
    from dataclasses_json import config
    from dataclasses import asdict
    from dataclasses_json import DataClassJsonMixin


    @dataclass
    class MyClass(DataClassJsonMixin):
        a: str
        b: int

        @config(exclude=Exclude.NEVER)
        def get_a(self) -> str:
            return self.a


# Generated at 2022-06-23 16:35:46.379072
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:35:50.592459
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_list = [{"a": 1, "b": 2, "c": 3}, {"a": 1, "d": 2}]
    assert Exclude.NEVER(test_list) == False


# Generated at 2022-06-23 16:35:52.563898
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  i = "a string"
  assert Exclude.NEVER(i) == False


# Generated at 2022-06-23 16:36:00.793199
# Unit test for function config
def test_config():
    @dataclass
    @config(undefined=Undefined.RAISE,
            field_name='first_name',
            exclude=Exclude.ALWAYS,
            )
    class Test:
        last_name: str = field(metadata=config(field_name='last'))
        test: str = field(metadata=config(undefined=Undefined.RAISE))

    assert get_field_meta(Test, 'last_name')['field_name'] == 'last'
    assert get_field_meta(Test, 'last_name')['undefined'] == Undefined.EXCLUDE
    assert get_field_meta(Test, 'last_name')['exclude'] is Undefined.EXCLUDE

    assert get_field_meta(Test, 'test')['field_name'] == 'test'
    assert get_field

# Generated at 2022-06-23 16:36:03.037777
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('hello')


# Generated at 2022-06-23 16:36:06.957918
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c=_GlobalConfig()
    assert c.encoders == {}
    assert c.decoders == {}
    assert c.mm_fields == {}


# Generated at 2022-06-23 16:36:17.029843
# Unit test for function config
def test_config():
    import dataclasses
    import unittest

    @dataclasses.dataclass
    class Data:
        arg: str = dataclasses.field(metadata=config())

    @dataclasses.dataclass
    class Data2:
        arg: str = dataclasses.field(metadata=config(letter_case=dataclasses_json.config.letter_case.camel_case))

    @dataclasses.dataclass
    class Data3:
        arg: str = dataclasses.field(metadata=config(undefined=dataclasses_json.Undefined.EXCLUDE))

    @dataclasses.dataclass
    class Data4:
        arg: str = dataclasses.field(metadata=config(field_name='arg'))


# Generated at 2022-06-23 16:36:19.157278
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.NEVER(0) == False
    

# Generated at 2022-06-23 16:36:22.920694
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS.__name__=="<lambda>"
    assert Exclude.NEVER.__name__=="<lambda>"
    assert(Exclude.NEVER(1)==False)
    assert(Exclude.ALWAYS(1)==True)

# Generated at 2022-06-23 16:36:26.547231
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # set up
    _GlobalConfig()
    # check
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # tear down
    pass

# Generated at 2022-06-23 16:36:29.033557
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global global_config
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-23 16:36:39.385170
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class MyClass:
        my_field: int

        @config(letter_case=lambda x: x.lower())
        def _my_field(self):
            return self.my_field

    assert MyClass._my_field.__dataclasses_json__['dataclasses_json']['letter_case']("Hi") == "hi"
    assert MyClass._my_field.__dataclasses_json__['dataclasses_json']['undefined'] ==  Undefined.RAISE

    try:
        @config(undefined=None)
        def test_config_raises(): pass
    except UndefinedParameterError:
        pass
    else:
        assert False

# Generated at 2022-06-23 16:36:43.686328
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False


# Generated at 2022-06-23 16:36:44.804164
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude()


# Generated at 2022-06-23 16:36:46.190268
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == True



# Generated at 2022-06-23 16:36:48.349946
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:36:49.870665
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3.14)


# Generated at 2022-06-23 16:36:51.377439
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:36:53.039740
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:36:55.147428
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    #arrange
    field = Exclude.ALWAYS
    #act
    #assert
    assert field('test')


# Generated at 2022-06-23 16:36:57.859505
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(_GlobalConfig(), _GlobalConfig)
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}


# Generated at 2022-06-23 16:37:00.441902
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_var = "abc"
    assert Exclude.NEVER(test_var)


# Generated at 2022-06-23 16:37:03.245224
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS('') == True)
    assert(Exclude.ALWAYS(1) == True)


# Generated at 2022-06-23 16:37:05.503824
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("") is True
    assert Exclude.NEVER("") is False



# Generated at 2022-06-23 16:37:07.744397
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:37:12.361660
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    cnf = _GlobalConfig()
    assert(cnf.encoders == {})
    assert(cnf.decoders == {})
    assert(cnf.mm_fields == {})

# Unit test of config()

# Generated at 2022-06-23 16:37:13.089403
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(object())

# Generated at 2022-06-23 16:37:16.056122
# Unit test for constructor of class Exclude
def test_Exclude():
    class A:
        a = 1
        b = 2

    ex = Exclude()




# Generated at 2022-06-23 16:37:19.029812
# Unit test for function config
def test_config():
    @dataclass
    class Example:
        exclude: str
        undefined: str
    test = Example('ALWAYS', 'skip')


# Generated at 2022-06-23 16:37:23.699780
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class User:
        name: str
        age: int = config(mm_field={"required": False})

    assert "mm_field" in User()._config["dataclasses_json"]
    assert User()._config["dataclasses_json"]["mm_field"]["required"] is False

# Generated at 2022-06-23 16:37:35.202697
# Unit test for function config
def test_config():
    @dataclass
    @config(exclude=Exclude.NEVER)
    class Test:
        def __init__(self, should_be_excluded):
            self.should_be_excluded = should_be_excluded

    data = {"should_be_excluded": "test"}
    test = Test.from_dict(data)
    assert test.to_dict() == data

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class Test:
        def __init__(self, should_not_be_excluded):
            self.should_not_be_excluded = should_not_be_excluded

    data = {"should_not_be_excluded": "test"}
    test = Test.from_dict(data)
    assert test.to_dict() == {}

# Generated at 2022-06-23 16:37:36.331322
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    never_func=Exclude.NEVER
    assert never_func(0)==False

# Generated at 2022-06-23 16:37:44.006617
# Unit test for constructor of class Exclude
def test_Exclude():
    assert repr(Exclude.ALWAYS) == '<function Exclude.ALWAYS at 0x7f373a17d950>'
    assert repr(Exclude.NEVER) == '<function Exclude.NEVER at 0x7f373a17da60>'
    assert Exclude.ALWAYS(True)
    assert not Exclude.ALWAYS(False)
    assert not Exclude.NEVER(False)
    assert not Exclude.NEVER(True)


# Generated at 2022-06-23 16:37:47.294330
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:37:50.835569
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config_list = [
        {'encoders': {}, 'decoders': {}, 'mm_fields': {}},
        _GlobalConfig(),
    ]
    assert config_list[0] == config_list[1]

# Generated at 2022-06-23 16:37:51.725318
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False

# Generated at 2022-06-23 16:37:53.600199
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude = Exclude()
    assert (exclude.ALWAYS("test") == True)
    assert (exclude.NEVER("test") == False)

# Generated at 2022-06-23 16:38:02.716784
# Unit test for function config
def test_config():
    def new_letter_case(field_name, letter_case):
        return letter_case(field_name)

    def exclude_always(field_name, _):
        return True

    @dataclass
    @config(letter_case=new_letter_case, mm_field=fields.Int)
    class A:
        id: int
        age: int = 0
        user: Optional[str] = None

    assert A.__metadata__['dataclasses_json']['letter_case'] == new_letter_case
    assert A.__metadata__['dataclasses_json']['mm_field'] is fields.Int

    # values in config are overrides
    @config(letter_case=None)
    class B(A):
        pass


# Generated at 2022-06-23 16:38:04.758190
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('Unit test string!') == False
    assert Exclude.NEVER(12345) == False


# Generated at 2022-06-23 16:38:09.951917
# Unit test for function config
def test_config():
    class C: pass
    dc = config()
    assert 'dataclasses_json' in dc
    dc = config(encoder=C)
    assert 'encoder' in dc['dataclasses_json']
    dc = config(decoder=C)
    assert 'decoder' in dc['dataclasses_json']
    dc = config(mm_field=C)
    assert 'mm_field' in dc['dataclasses_json']
    dc = config(field_name='a')
    assert 'letter_case' in dc['dataclasses_json']
    dc = config(undefined='ignore')
    assert 'undefined' in dc['dataclasses_json']
    valid_actions = list('ignore', 'raise', 'use_none')
    dc = config(undefined='invalid')
    assert 'undefined'

# Generated at 2022-06-23 16:38:12.041446
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:38:13.757984
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert global_config_


# Generated at 2022-06-23 16:38:17.039273
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS('string') == True


# Generated at 2022-06-23 16:38:21.037562
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

test__GlobalConfig()


# Generated at 2022-06-23 16:38:22.536350
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:38:31.906531
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses_json.decoder import json_decode
    from dataclasses_json.encoder import json_encode

    @config(encoder=json_encode,
            decoder=json_decode,
            mm_field=fields.Str,
            letter_case='upper',
            undefined='raise',
            field_name='test_field',
            exclude=Exclude.NEVER,
            )
    @dataclass
    class Test:
        test_field: str = "test"

    assert Test.schema().fields['test_field'].__class__ == fields.Str
    assert Test.json_decode(Test.json_encode(Test())) == Test(test_field="test")

# Generated at 2022-06-23 16:38:33.521008
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hola")


# Generated at 2022-06-23 16:38:36.632434
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("x")
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(["x"])
    assert Exclude.NEVER(("x",))
    assert Exclude.NEVER({"a": 1})
    assert Exclude.NEVER(range(3))
    assert Exclude.NEVER(range(0))
    assert Exclude.NEVER(range(1))
    assert Exclude.NEVER(range(2))
    assert Exclude.NEVER(range(10))


# Generated at 2022-06-23 16:38:46.943031
# Unit test for function config
def test_config():
    import marshmallow as mm

    @config(exclude=Exclude.ALWAYS) # type: ignore
    class _:
        pass

    @config(exclude=Exclude.NEVER) # type: ignore
    class __:
        pass

    @config(field_name="_")
    class ___:
        pass

    @config(letter_case=lambda s: s.upper()) # type: ignore
    class ____:
        pass

    @config(mm_field=mm.fields.Integer()) # type: ignore
    class _____:
        pass

    # TODO: test encoder and decoder

    @config(undefined=Undefined.RAISE) # type: ignore
    class ______:
        pass


if __name__ == "__main__":
    test_config()

# Generated at 2022-06-23 16:38:49.371683
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    print(global_config.encoders)
    print(global_config.decoders)
    print(global_config.mm_fields)


# Generated at 2022-06-23 16:38:51.629438
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-23 16:38:53.071809
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-23 16:38:55.498125
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config_org = _GlobalConfig()

    config_new = _GlobalConfig()
    assert config_org == config_new

test__GlobalConfig()

# Generated at 2022-06-23 16:39:02.464448
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    @config(field_name='bar')
    class Foo:
        bar: str

    foo = Foo('Foo')
    assert foo.to_dict() == {'bar': 'Foo'}

    @dataclass
    @config(field_name=lambda _: 'bar')
    class Foo:
        bar: str

    foo = Foo('Foo')
    assert foo.to_dict() == {'bar': 'Foo'}



# Generated at 2022-06-23 16:39:12.463362
# Unit test for function config
def test_config():
    from marshmallow import fields, Schema
    class C(Schema):
        pass

    class D:
        pass

    assert config(encoder=C, decoder=D,
                  mm_field=fields.Integer,
                  letter_case=str.lower,
                  field_name='test',
                  undefined='RAISE') == {
        'dataclasses_json': {
            'encoder': C,
            'decoder': D,
            'mm_field': fields.Integer,
            'letter_case': str.lower,
            'field_name': 'test',
            'undefined': Undefined.RAISE,
        }
    }

    # Test with upper case

# Generated at 2022-06-23 16:39:14.283695
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global global_config
    global_config = _GlobalConfig()

# Generated at 2022-06-23 16:39:15.541778
# Unit test for function config
def test_config():
    config(exclude=Exclude.ALWAYS)

# Generated at 2022-06-23 16:39:19.846437
# Unit test for function config
def test_config():
    import marshmallow as ma

    @config(exclude=Exclude.ALWAYS, mm_field=ma.fields.Integer())
    class C:
        pass

# Generated at 2022-06-23 16:39:21.308855
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("hello")
    assert not Exclude.NEVER("hello")

# Generated at 2022-06-23 16:39:22.686179
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert (Exclude.NEVER(5)) is False


# Generated at 2022-06-23 16:39:26.012950
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config_ = _GlobalConfig()
    assert config_ == global_config
    assert config_.encoders == {}
    assert config_.decoders == {}
    assert config_.mm_fields == {}
test__GlobalConfig()


# Generated at 2022-06-23 16:39:30.194020
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert(global_config.encoders == {})
    assert (global_config.decoders == {})
    assert (global_config.mm_fields == {})
    # assert (global_config.json_module.__name__ == "json")


# Generated at 2022-06-23 16:39:33.052505
# Unit test for function config
def test_config():
    from marshmallow_dataclass import dataclass

    @dataclass
    class Test:
        name: str

    assert 'dataclasses_json' in config()



# Generated at 2022-06-23 16:39:34.083399
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()



# Generated at 2022-06-23 16:39:36.195167
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-23 16:39:38.283212
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (Exclude.ALWAYS('hey') == True)
    assert (Exclude.NEVER('hey') == False)

# Generated at 2022-06-23 16:39:42.678220
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_example = Exclude()
    assert test_example.NEVER(1), "test failed. Exclude.NEVER returned False when it should return True"


# Generated at 2022-06-23 16:39:53.828752
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class DummyClass:
        a: int
        b: int
        c: int


    @dataclass
    class DummyClass1:
        a: int
        b: int
        c: int

        class Config:
            exclude = Exclude.ALWAYS

    @dataclass
    class DummyClass2:
        a: int
        b: int
        c: int

        class Config:
            exclude = Exclude.NEVER

    @dataclass
    class DummyClass3:
        a: int
        b: int
        c: int

        class Config:
            exclude = lambda _, _attr: _attr.name == 'b'

    assert DummyClass.__dict__['__annotations__'] == DummyClass1.__

# Generated at 2022-06-23 16:39:57.119145
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:40:00.045335
# Unit test for function config
def test_config():
    assert 'dataclasses_json' in config()
    assert config(encoder=float)['dataclasses_json']['encoder'] is float

# Generated at 2022-06-23 16:40:05.298320
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_data = [
        ('abc', False),
        ('bcd', False),
        ('cde', False),
        ('def', False),
    ]

    for data in test_data:
        assert data[1] == Exclude.NEVER(data[0])


# Generated at 2022-06-23 16:40:12.608838
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders
    assert global_config.decoders
    assert global_config.mm_fields
    assert global_config.encoders
    assert global_config.decoders
    assert global_config.mm_fields
    assert global_config.undefined
    assert global_config.letter_case
    assert global_config.field_name
    assert global_config.exclude
    assert global_config.json_module


# Generated at 2022-06-23 16:40:16.775141
# Unit test for constructor of class Exclude
def test_Exclude():
    always = Exclude.ALWAYS
    never = Exclude.NEVER
    assert isinstance(always, Callable)
    assert isinstance(never, Callable)


# Generated at 2022-06-23 16:40:17.665847
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-23 16:40:19.317622
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hello") == True


# Generated at 2022-06-23 16:40:25.136117
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) is False
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(2) is False
    assert Exclude.NEVER(3) is False
    assert Exclude.NEVER(4) is False
    assert Exclude.NEVER(5) is False
    assert Exclude.NEVER(6) is False
    assert Exclude.NEVER(7) is False
    assert Exclude.NEVER(8) is False
    assert Exclude.NEVER(9) is False
    assert Exclude.NEVER(-1) is False
    assert Exclude.NEVER(-2) is False
    assert Exclude.NEVER(-3) is False
    assert Exclude.NEVER(-4) is False
    assert Exclude.NEVER(-5) is False
    assert Exclude

# Generated at 2022-06-23 16:40:27.207630
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False 


# Generated at 2022-06-23 16:40:29.467972
# Unit test for constructor of class Exclude
def test_Exclude():
    # Always excluded
    assert(Exclude.NEVER(True) == False)
    # Never excluded
    assert(Exclude.ALWAYS(True) == True)

test_Exclude()

# Generated at 2022-06-23 16:40:30.809711
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:40:39.902649
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    print("Testing a constructor of class _GlobalConfig")
    # Create instance
    inst_GlobalConfig = _GlobalConfig()
    assert inst_GlobalConfig
    # Add encoders
    def encoder1(data):
        return data + 1
    def encoder2(data):
        return data - 1
    inst_GlobalConfig.encoders[bool] = encoder1
    inst_GlobalConfig.encoders[str] = encoder2
    assert inst_GlobalConfig.encoders[bool] != inst_GlobalConfig.encoders[str]
    assert inst_GlobalConfig.encoders[bool](1) == 2
    assert inst_GlobalConfig.encoders[str]("ABC") == "ABC"
    # Add decoders
    def decoder1(data):
        return data + 1

# Generated at 2022-06-23 16:40:40.790379
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()

# Generated at 2022-06-23 16:40:43.208982
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER([]) == False


# Generated at 2022-06-23 16:40:45.692695
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    _: bool = Exclude.NEVER(5)
    # not _ == True
    assert not _

# Generated at 2022-06-23 16:40:46.750460
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class A:
        pass
    a = A()
    assert Exclude.NEVER(a)

# Generated at 2022-06-23 16:40:48.751587
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('') == False


# Generated at 2022-06-23 16:40:57.644445
# Unit test for function config
def test_config():
    # Basic use case
    assert config(letter_case='snake') == {'dataclasses_json': {'letter_case': 'snake'}}
    assert config(letter_case='camel') == {'dataclasses_json': {'letter_case': 'camel'}}
    assert config(letter_case='kebab') == {'dataclasses_json': {'letter_case': 'kebab'}}
    assert config(letter_case='pascal') == {'dataclasses_json': {'letter_case': 'pascal'}}
    assert config(letter_case='lower') == {'dataclasses_json': {'letter_case': 'lower'}}
    assert config(letter_case='upper') == {'dataclasses_json': {'letter_case': 'upper'}}
    assert config

# Generated at 2022-06-23 16:40:59.422755
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    cfg = _GlobalConfig()
    assert cfg.encoders == {}
    assert cfg.decoders == {}
    assert cfg.mm_fields == {}



# Generated at 2022-06-23 16:41:01.899010
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) 
    assert Exclude.ALWAYS("Hello")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(1.0)


# Generated at 2022-06-23 16:41:04.796452
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(3)
    assert not result

# Generated at 2022-06-23 16:41:06.216689
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS 


# Generated at 2022-06-23 16:41:09.860836
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('dawid') == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:41:10.752213
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") is False

# Generated at 2022-06-23 16:41:14.200392
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}
    # assert g.json_module == json
    # g.json_module = json
    # assert g.json_module == json


# Generated at 2022-06-23 16:41:17.772748
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:41:19.701933
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('') == True


# Generated at 2022-06-23 16:41:22.429492
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:41:30.173090
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # test that Exclude.NEVER returns a function
    assert callable(Exclude.NEVER)

    # test that Exclude.NEVER returns false for any parameter
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(2.78) == False
    assert Exclude.NEVER([0, 1]) == False
    assert Exclude.NEVER({1 : "a"}) == False


# Generated at 2022-06-23 16:41:32.267755
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:41:33.284231
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:41:35.082747
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS(2) == True)
    assert (Exclude.ALWAYS(0) == True)

# Generated at 2022-06-23 16:41:39.070037
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(Exclude)  # ok
    assert Exclude.ALWAYS("hello")  # ok
    assert Exclude.ALWAYS(1)  # ok


# Generated at 2022-06-23 16:41:40.253776
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-23 16:41:42.496818
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # print(Exclude.NEVER(4))
    assert Exclude.NEVER(4) == False


# Generated at 2022-06-23 16:41:44.174858
# Unit test for constructor of class Exclude

# Generated at 2022-06-23 16:41:48.417121
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Test if the callable lambda works
    test_str = "test"
    assert Exclude.NEVER(test_str) == False
    test_str = ""
    assert Exclude.NEVER(test_str) == False

# Generated at 2022-06-23 16:41:56.273709
# Unit test for function config
def test_config():
    from marshmallow import fields as mm_fields
    from dataclasses_json.config import Undefined

    def to_camel_case(_, __):
        import re
        s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', _)
        return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()

    @config(encoder=float,
            decoder=float,
            mm_field=mm_fields.Int(),
            letter_case=to_camel_case,
            undefined=Undefined.EXCLUDE,
            exclude=Exclude.ALWAYS,
            )
    class ConfigTest:
        a: int
        b: int
        c: int

    assert Config

# Generated at 2022-06-23 16:41:58.370728
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("a") == True


# Generated at 2022-06-23 16:41:59.737829
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-23 16:42:07.988749
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    global_config.encoders = {datetime: "datetime encoder"}
    global_config.decoders = {datetime: "datetime decoder"}
    global_config.mm_fields = {datetime: "marshmallow field for datetime"}
    assert global_config.encoders[datetime] == "datetime encoder"
    assert global_config.decoders[datetime] == "datetime decoder"
    assert global_config.mm_fields[datetime] == "marshmallow field for datetime"


# Generated at 2022-06-23 16:42:09.534352
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field_name = 'name'
    assert Exclude.NEVER(field_name)



# Generated at 2022-06-23 16:42:15.598564
# Unit test for function config
def test_config():
    @dataclass
    class Type:
        i: int

    mm_field = Optional[int]
    func = lambda x: x

    # Test all valid inputs
    assert (config(encoder=func) ==
            {'dataclasses_json': {'encoder': func}})

    assert (config(decoder=func) ==
            {'dataclasses_json': {'decoder': func}})

    assert (config(mm_field=mm_field) ==
            {'dataclasses_json': {'mm_field': mm_field}})

    assert (config(letter_case=func) ==
            {'dataclasses_json': {'letter_case': func}})


# Generated at 2022-06-23 16:42:24.105546
# Unit test for function config
def test_config():
    # Create a class to generate a type hint
    @dataclass
    class _TestClass:
        pass

    # Test all config functions
    _TestClass = config(_TestClass, encoder=_TestClass)
    _TestClass = config(_TestClass, decoder=_TestClass)
    _TestClass = config(_TestClass, mm_field=_TestClass)
    _TestClass = config(_TestClass, letter_case=lambda x: x)
    _TestClass = config(_TestClass, field_name='name')
    _TestClass = config(_TestClass, exclude=lambda _, __: True)

# Generated at 2022-06-23 16:42:33.762025
# Unit test for function config
def test_config():
    # not changing state
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # #260
    if False:
        # TODO: update this
        # Test that we can disable JSON serialization
        assert global_config.json_module == json.JSONEncoder
        config(json_module=yaml.YAML)
        assert global_config.json_module == yaml.YAML
        # Test that we can re-enable JSON serialization
        config(json_module=json.JSONEncoder)
        assert global_config.json_module == json.JSONEncoder

# Generated at 2022-06-23 16:42:39.220283
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a_string')
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(.1)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS((1, 2, 3))
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({'a': 1, 'b': 2})


# Generated at 2022-06-23 16:42:41.285468
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:42:44.638893
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == dict()
    assert _GlobalConfig().decoders == dict()
    assert _GlobalConfig().mm_fields == dict()


# Generated at 2022-06-23 16:42:48.518450
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:42:58.165969
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    import warnings

    warnings.filterwarnings("error")

    # Test global config
    def encoder(o, *args, **kwargs):
        pass
    def decoder(o, *args, **kwargs):
        pass
    mm_field = marshmallow.fields.Str()
    letter_case = lambda x: x.lower()
    undefined = Undefined.RAISE

    @dataclasses.dataclass
    @config(encoder=encoder, decoder=decoder, mm_field=mm_field, letter_case=letter_case, undefined=undefined)
    class Test:
        x: int
        y: str = "hello"
        z: float = dataclasses.field()

    data = Test(1, "hello", 10.0)
    assert data

# Generated at 2022-06-23 16:43:02.875311
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config._json_module == json



# Generated at 2022-06-23 16:43:05.186738
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = 1
    assert False == Exclude.NEVER(x)
    assert True == Exclude.ALWAYS(x)

# Generated at 2022-06-23 16:43:06.546590
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:43:07.839469
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a string') == True


# Generated at 2022-06-23 16:43:09.058291
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(1)
    assert not result


# Generated at 2022-06-23 16:43:10.233184
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.NEVER(2)


# Generated at 2022-06-23 16:43:11.976275
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-23 16:43:13.095184
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-23 16:43:14.300047
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:43:20.899180
# Unit test for function config
def test_config():
    # Ensure that the Undefined string values set Undefined values properly
    assert config(undefined="ERROR")['dataclasses_json']['undefined'] == Undefined.ERROR
    assert config(undefined="EXCLUDE")['dataclasses_json']['undefined'] == Undefined.EXCLUDE
    assert config(undefined="INCLUDE")['dataclasses_json']['undefined'] == Undefined.INCLUDE
    # Ensure that the Undefined member values set properly
    assert config(undefined=Undefined.ERROR)['dataclasses_json']['undefined'] == Undefined.ERROR
    assert config(undefined=Undefined.EXCLUDE)['dataclasses_json']['undefined'] == Undefined.EXCLUDE

# Generated at 2022-06-23 16:43:26.198393
# Unit test for function config
def test_config():
    assert config(metadata={},
                  encoder='mock encoder',
                  decoder='mock decoder',
                  mm_field='mock mm_field',
                  field_name='mock field_name',
                  exclude='mock exclude',
                  undefined='EXCLUDE',
                  letter_case='mock letter_case') == {'dataclasses_json': {
        'encoder': 'mock encoder',
        'decoder': 'mock decoder',
        'mm_field': 'mock mm_field',
        'field_name': 'mock field_name',
        'letter_case': 'mock letter_case',
        'undefined': Undefined.EXCLUDE,
        'exclude': 'mock exclude'}}



# Generated at 2022-06-23 16:43:36.239809
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    class A:
        @dataclasses.dataclass
        class B:
            x: int

    @dataclasses.dataclass
    class C:
        b: A.B

    assert config(A.B, encoder="encoder") == {"dataclasses_json": {"encoder": "encoder"}}
    assert config(A.B, decoder="decoder") == {"dataclasses_json": {"decoder": "decoder"}}
    assert config(A.B, mm_field="mm_field") == {"dataclasses_json": {"mm_field": "mm_field"}}
    assert config(A.B, letter_case="letter_case") == {"dataclasses_json": {"letter_case": "letter_case"}}


# Generated at 2022-06-23 16:43:37.645985
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:43:39.542689
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) is False
    assert Exclude.NEVER("a") is False


# Generated at 2022-06-23 16:43:41.066159
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-23 16:43:42.378961
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:43:46.403599
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:43:47.981204
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)


# Generated at 2022-06-23 16:43:50.894385
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    The method NEVER() should always return False
    """
    assert not Exclude.NEVER("Any string")



# Generated at 2022-06-23 16:43:53.527270
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('')
    assert not Exclude.NEVER('')
    # Test for default
    assert not Exclude.__init__('')


# Generated at 2022-06-23 16:43:55.870843
# Unit test for constructor of class Exclude
def test_Exclude():
    TestExclude = Exclude()
    assert TestExclude.ALWAYS(4) == True
    assert TestExclude.NEVER(4) == False

# Generated at 2022-06-23 16:43:57.585318
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('') is False
    assert Exclude.NEVER('abc') is False


# Generated at 2022-06-23 16:44:07.704843
# Unit test for function config
def test_config():
    # Correct usage
    metadata = config(encoder=lambda _: _)

# Generated at 2022-06-23 16:44:09.532452
# Unit test for constructor of class Exclude
def test_Exclude():
    # Test case 1
    assert Exclude.ALWAYS(2) == True

    # Test case 2
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-23 16:44:12.046490
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(1))
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:44:12.784355
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('Hello')


# Generated at 2022-06-23 16:44:17.137406
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS("bla") is True
