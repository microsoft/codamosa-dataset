

# Generated at 2022-06-23 16:34:23.102328
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(1) == False)


# Generated at 2022-06-23 16:34:25.769843
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    any_value = [1,'b',"c"]  
    assert Exclude.ALWAYS(any_value) == True

# Generated at 2022-06-23 16:34:29.836746
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-23 16:34:30.791940
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-23 16:34:35.231218
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER != Exclude.ALWAYS
    assert Exclude.ALWAYS(True)
    assert not Exclude.ALWAYS(False)
    assert not Exclude.NEVER(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-23 16:34:37.182598
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:34:39.768173
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    #conf = _GlobalConfig()
    assert_true(True)

# Generated at 2022-06-23 16:34:46.187190
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    # assert isinstance(global_config_.encoders, dict)
    # assert isinstance(global_config_.decoders, dict)
    # assert isinstance(global_config_.mm_fields, dict)
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-23 16:34:51.524378
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("hey") == True
    assert Exclude.ALWAYS(Exclude.ALWAYS) == True


# Generated at 2022-06-23 16:34:53.603436
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def is_true(_):
        return True

    assert Exclude.ALWAYS(1) == is_true(1)



# Generated at 2022-06-23 16:34:57.248563
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert not global_config.encoders
    assert not global_config.decoders
    assert not global_config.mm_fields
    # assert global_config.json_module

# Generated at 2022-06-23 16:34:58.706619
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global global_config
    global_config = _GlobalConfig()


# Generated at 2022-06-23 16:35:00.537832
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    NeverExclude = Exclude()
    assert NeverExclude.NEVER('a') == False


# Generated at 2022-06-23 16:35:03.853978
# Unit test for constructor of class Exclude
def test_Exclude():
    # Test value of attribute
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None


# Generated at 2022-06-23 16:35:06.170382
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:35:07.672786
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-23 16:35:15.028968
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(field_name='blah') == {
        'dataclasses_json': {'letter_case': 'blah'}}
    assert config(undefined='RAISE') == {
        'dataclasses_json': {'undefined': Undefined.RAISE}}
    assert config(undefined=Undefined.RAISE) == {
        'dataclasses_json': {'undefined': Undefined.RAISE}}

# Generated at 2022-06-23 16:35:16.098459
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is True

# Generated at 2022-06-23 16:35:23.705870
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc1 = _GlobalConfig()
    # check encoders is empty dict
    assert isinstance(gc1.encoders,dict)
    assert len(gc1.encoders) == 0
    # check decoders is empty dict
    assert isinstance(gc1.decoders, dict)
    assert len(gc1.decoders) == 0
    # check mm_fields is empty dict
    assert isinstance(gc1.mm_fields, dict)
    assert len(gc1.mm_fields) == 0
    # check _json_module is json
    # TODO: add when #180 is closed
    # assert gc1._json_module == json
    # verify encoders updated
    gc1.encoders[int] = lambda x: str(x)
    assert gc1.encoders

# Generated at 2022-06-23 16:35:25.496362
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    if (e.ALWAYS is not None and e.NEVER is not None):
        print("e.ALWAYS and e.NEVER are not None")


# Generated at 2022-06-23 16:35:28.348096
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders.clear()
    global_config.decoders.clear()
    global_config.mm_fields.clear()

# Generated at 2022-06-23 16:35:31.629127
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER(True) == False

# Generated at 2022-06-23 16:35:32.743970
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert Exclude.NEVER(0)

# Generated at 2022-06-23 16:35:34.271322
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}

# Generated at 2022-06-23 16:35:37.691861
# Unit test for constructor of class Exclude
def test_Exclude():
    testOffset = Exclude()
    testOffset.ALWAYS = True
    testOffset.NEVER = False
    assert testOffset.ALWAYS
    assert not testOffset.NEVER


# Generated at 2022-06-23 16:35:38.413014
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:35:46.256634
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.mm import MM

    @dataclass
    class DataClass:
        field: str = config(field_name="override")

    assert MM(config={'fields': {
        'field': {'metadata': {
            'dataclasses_json': {
                'field_name': 'override'
            }
        }}}}).dump(DataClass()) == \
        {'override': 'field'}

    @dataclass
    class DataClass:
        field: float = config(
            encoder=lambda o: float(o) * 10,
            decoder=lambda o: float(o) / 10)


# Generated at 2022-06-23 16:35:47.216282
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 16:35:54.554724
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Create a sample test object
    class TestObject:
        name = "test"
        age = 10
        def __init__(self,name,age):
            self.name = name
            self.age = age

    # Create an instance using the sample test object
    sample_obj = TestObject("test",10)
    # Test the method NEVER of the class Exclude
    assert Exclude.NEVER(sample_obj) == False


# Generated at 2022-06-23 16:35:57.232712
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:36:03.303239
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class User():
        name: str
        password: str

    user = User(name="name", password="password")
    user_dict = user.to_dict()

    print(user_dict)
    print(f"user_dict['name'] = {user_dict['name']}")

    assert 'name' not in user_dict



# Generated at 2022-06-23 16:36:05.642299
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    res=Exclude.ALWAYS(0)
    expected=True
    assert res==expected


# Generated at 2022-06-23 16:36:06.500549
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config._GlobalConfig()


# Generated at 2022-06-23 16:36:16.888527
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses_json.config import DataClassJsonMixin, Undefined

    @dataclasses.dataclass
    @config(encoder=lambda x: f"encoder{x}",
            decoder=lambda x: f"decoder{x}",
            mm_field=fields.String,
            letter_case=lambda x: x[0].upper(),
            undefined=Undefined.RAISE,
            exclude=Exclude.NEVER,
            field_name="name")
    class FooJson(DataClassJsonMixin):
        name: str

    assert FooJson.__encoder__ == config()["dataclasses_json"]["encoder"]
    assert FooJson.__decoder__ == config()["dataclasses_json"]["decoder"]
    assert Foo

# Generated at 2022-06-23 16:36:18.818826
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("hello") == False

# Generated at 2022-06-23 16:36:24.868950
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    gc.encoders = {'dict': 'abc'}
    gc.decoders = {'dict': 'abc'}
    gc.mm_fields = {'dict': 'abc'}
    assert gc.encoders == {'dict': 'abc'}
    assert gc.decoders == {'dict': 'abc'}
    assert gc.mm_fields == {'dict': 'abc'}


# Generated at 2022-06-23 16:36:27.621937
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()

    assert gc != None
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}



# Generated at 2022-06-23 16:36:29.077847
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('any_value')


# Generated at 2022-06-23 16:36:40.322418
# Unit test for function config
def test_config():
    from parameterized import parameterized
    from marshmallow import fields as mm_fields
    from dataclasses import fields as dc_fields
    from dataclasses import dataclass
    import collections.abc

    @dataclass
    class Foo:
        a: str = 'A'
        b: str = 'B'
        c: str = 'C'
        d: str = 'D'
        e: str = 'E'
        f: List[str] = ['D', 'E', 'F']

        @config(mm_field=mm_fields.Integer(),
                field_name='_b',
                letter_case=lambda s: s.lower())
        @property
        def b(self):
            return self._b

        @b.setter
        def b(self, value):
            self._b = value

       

# Generated at 2022-06-23 16:36:46.779996
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS.__name__ == '<lambda>')
    assert(Exclude.NEVER.__name__ == '<lambda>')
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.ALWAYS(0) == True)
    assert(Exclude.NEVER(1) == False)
    assert(Exclude.NEVER(0) == False)

# Generated at 2022-06-23 16:36:47.944779
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:36:49.188627
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)

# Generated at 2022-06-23 16:36:53.648251
# Unit test for function config
def test_config():
    @dataclass
    @config(exclude=Exclude.NEVER)
    class A:
        field: str

    assert A('').to_dict() == {'field': ''}

    @dataclass
    @config(undefined=Undefined.RAISE)
    class B:
        field: str

    B('')

# Generated at 2022-06-23 16:36:59.720557
# Unit test for function config
def test_config():
    import dataclasses
    import json

    @dataclasses.dataclass
    @config(encoder=lambda i: i.__str__() * 3,
            decoder=lambda s: s[0:len(s) // 3])
    class Foo:
        bar: str

    assert json.loads(json.dumps(Foo('a'))) == {'bar': 'aaa'}

    try:
        @config(undefined='blah')
        class Bar:
            pass
    except UndefinedParameterError:
        pass
    else:
        raise AssertionError("Should not be able to set irrelevant undefined parameter")

# Generated at 2022-06-23 16:37:02.570159
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}

# Generated at 2022-06-23 16:37:03.276078
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()

# Generated at 2022-06-23 16:37:04.364253
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('abc') is False, 'Expected False from Exclude.NEVER'


# Generated at 2022-06-23 16:37:06.177891
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:37:09.269254
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:37:11.069307
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) or Exclude.ALWAYS("s") or Exclude.ALWAYS(True)

# Generated at 2022-06-23 16:37:18.368077
# Unit test for function config
def test_config():
    from typing import Any, Dict
    import pytest
    config_dict: Dict[str, Any] = {}
    config(metadata=config_dict, encoder="ENCODER")
    config(metadata=config_dict, decoder="DECODER")
    config(metadata=config_dict, mm_field="MM_FIELD")
    config(metadata=config_dict, letter_case="LETTER_CASE")
    config(metadata=config_dict, undefined="EXCLUDE")
    config(metadata=config_dict, field_name="FIELD_NAME")
    config(metadata=config_dict, exclude="EXCLUDE")

# Generated at 2022-06-23 16:37:25.312361
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    @config(mm_field=True, encoder=True, decoder=True, undefined=True,
            field_name=True, exclude=True)
    class Test:
        x: str = ""

    assert Test.__dataclasses_json__.config == {
        'mm_field': True,
        'encoder': True,
        'decoder': True,
        'undefined': True,
        'field_name': True,
        'exclude': True
    }



# Generated at 2022-06-23 16:37:34.602738
# Unit test for function config
def test_config():
    @config()
    class Test:
        pass
    test = Test()
    assert test.__metadata__ == {'dataclasses_json': {}}

    @config(encoder=float)
    class Test:
        pass
    test = Test()
    assert test.__metadata__ == {
        'dataclasses_json': {'encoder': float}
    }

    @config(undefined="ignore")
    class Test:
        pass
    test = Test()
    assert test.__metadata__ == {
        'dataclasses_json': {'undefined': Undefined.IGNORE}
    }

test_config()

# Generated at 2022-06-23 16:37:36.369030
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig(): # pragma: no cover
    from dataclasses import dataclass, field

    from marshmallow import Schema, fields

    from dataclasses_json import confi

# Generated at 2022-06-23 16:37:43.418406
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test = _GlobalConfig()

    test.encoders = {bool: str,}
    assert test.encoders == {bool: str,}

    test.decoders = {bool: str,}
    assert test.decoders == {bool: str,}

    test.mm_fields = {bool: "str",}
    assert test.mm_fields == {bool: "str",}


# Generated at 2022-06-23 16:37:48.209966
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:37:51.937703
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config
    assert global_config.encoders
    assert global_config.decoders
    assert global_config.mm_fields
    assert global_config.mm_fields

if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-23 16:37:52.816674
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == True

# Generated at 2022-06-23 16:37:53.857386
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-23 16:37:57.406093
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # WHEN:
    # We call method NEVER
    # THEN:
    # We should get a function always returning False
    assert Exclude.NEVER("") == False

# Generated at 2022-06-23 16:37:59.220934
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # assert Exclude.ALWAYS("abc") == True
    assert Exclude.ALWAYS("abc") != False


# Generated at 2022-06-23 16:38:01.180113
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-23 16:38:10.634338
# Unit test for function config
def test_config():
    import inspect
    import json
    from marshmallow import fields as mm_fields
    from dataclasses import dataclass
    from dataclasses import make_dataclass
    from typing import Optional

    @dataclass
    class Foo(object):
        a: str
        b: int = 1
        c: Optional[str] = None

    @dataclass
    class Bar(object):
        a: str
        b: int = 1
        c: Optional[str] = None

    Foo = make_dataclass("Foo", [
        ('a', str),
        ('b', int, 1),
        ('c', Optional[str], None)
    ])


# Generated at 2022-06-23 16:38:14.668661
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:38:20.863362
# Unit test for constructor of class Exclude
def test_Exclude():
    value = {}
    exclude = (
        functools.partial(config, metadata=value)
        (exclude=Exclude.ALWAYS)
        .get('dataclasses_json')
        .get('exclude')
    )
    assert callable(exclude)
    assert exclude(field_name='test', typ=int)
    assert value.get('dataclasses_json') == {'exclude': exclude}


# Generated at 2022-06-23 16:38:21.995366
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("x") == False

# Generated at 2022-06-23 16:38:31.504120
# Unit test for function config
def test_config():
    import unittest
    class TestConfig(unittest.TestCase):
        def test_undefined(self):
            # No value error
            config(undefined=Undefined.RAISE)
            config(undefined=Undefined.NULL)
            config(undefined=Undefined.EXCLUDE)
            config(undefined=Undefined.INCLUDE)

            # It works
            self.assertEqual(
                config(undefined="raise")['dataclasses_json']['undefined'],
                Undefined.RAISE
            )
            self.assertEqual(
                config(undefined="null")['dataclasses_json']['undefined'],
                Undefined.NULL
            )

# Generated at 2022-06-23 16:38:39.578764
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow.fields import Field
    
    encoder = lambda _: _
    decoder = lambda _: _
    mm_field = Field()
    letter_case = lambda _: _.lower()
    undefined = Undefined.RAISE
    field_name = 'abc'
    exclude = lambda _1, _2: False

    @dataclass
    class Person:
        abc: str

        class Config:
            encoder = encoder
            decoder = decoder
            mm_field = mm_field
            letter_case = letter_case
            undefined = undefined
            field_name = field_name
            exclude = exclude


# Generated at 2022-06-23 16:38:40.499578
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()

# Generated at 2022-06-23 16:38:46.561726
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert type(global_config.encoders) is dict
    assert type(global_config.decoders) is dict
    assert type(global_config.mm_fields) is dict
    assert type(global_config.json_module) is json
    assert global_config.json_module.dumps is json.dumps
    assert global_config.json_module.loads is json.loads


# Generated at 2022-06-23 16:38:48.480672
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config is not None

test__GlobalConfig()

# Generated at 2022-06-23 16:38:51.321064
# Unit test for constructor of class Exclude
def test_Exclude():
    print("Tests for Exclude class")

    def func1(a):
        return True

    def func2(b):
        return False

    assert Exclude.ALWAYS == func1
    assert Exclude.NEVER == func2

test_Exclude()



# Generated at 2022-06-23 16:38:52.372378
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # TODO
    assert True

# Generated at 2022-06-23 16:39:03.843935
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class DataClass:
        a: str

    class Meta:
        dataclasses_json = config(decoder=int)

    assert DataClass.__dataclasses_json__['decoder'] == int
    assert DataClass.__dataclasses_json__['encoder'] is None
    assert DataClass.__dataclasses_json__['mm_field'] is None

    @dataclasses.dataclass(metadata={'dataclasses_json': {
        'decoder': int
    }})
    class DataClass:
        a: str

    assert DataClass.__dataclasses_json__['decoder'] == int
    assert DataClass.__dataclasses_json__['encoder'] is None
    assert DataClass.__dataclasses_json__['mm_field'] is None

# Generated at 2022-06-23 16:39:05.995371
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = Exclude.ALWAYS(3)
    assert x == True


# Generated at 2022-06-23 16:39:07.809866
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") == True, "Excluding something that should not be excluded!"


# Generated at 2022-06-23 16:39:15.804057
# Unit test for function config
def test_config():
    @dataclass
    class Example:
        field1: str = field(metadata=config(field_name="field_1",
                                            letter_case=lambda x: x.upper()))

        field2: str = field(metadata=config(letter_case=lambda x: x.upper()))

    expected_letter_case = lambda x: x.upper()
    assert Example._field_metadata[1]["dataclasses_json"]["letter_case"] == expected_letter_case
    assert Example._field_metadata[2]["dataclasses_json"]["letter_case"] == expected_letter_case

    assert Example._field_metadata[1]["dataclasses_json"]["field_name"] == "field_1"

# Generated at 2022-06-23 16:39:17.663856
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.mm_fields == {}
    assert global_config.encoders == {}
    assert global_config.decoders == {}

# Generated at 2022-06-23 16:39:19.861000
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	new_class = Exclude()
	new_class.NEVER = 1
	assert(new_class.NEVER == 1)

# Generated at 2022-06-23 16:39:21.355061
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    flag = True
    assert Exclude.ALWAYS(flag)


# Generated at 2022-06-23 16:39:25.028940
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1.encoders == {}
    assert global_config1.decoders == {}
    assert global_config1.mm_fields == {}
    # assert global_config1._json_module == json



# Generated at 2022-06-23 16:39:29.886252
# Unit test for constructor of class Exclude
def test_Exclude():
    # Test that Exclude.ALWAYS is a function that takes any argument and
    # returns True
    def func(arg):
        return True
    assert Exclude.ALWAYS(func) is True

    # Test that Exclude.NEVER is a function that takes any argument and
    # returns False
    def func(arg):
        return False
    assert Exclude.NEVER(func) is False

# Generated at 2022-06-23 16:39:40.628301
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(1) == False) # 1 is a number
    assert(Exclude.NEVER(0) == False) # 0 is a number
    assert(Exclude.NEVER(True) == False) # True is a boolean
    assert(Exclude.NEVER(False) == False) # False is a boolean
    assert(Exclude.NEVER("") == False) # "" is a string
    assert(Exclude.NEVER("string") == False) # "string" is a string
    assert(Exclude.NEVER(()) == False) # () is a tuple
    assert(Exclude.NEVER((1, )) == False) # (1, ) is a tuple
    assert(Exclude.NEVER([]) == False) # [] is a list
    assert(Exclude.NEVER([1]) == False) # [

# Generated at 2022-06-23 16:39:52.879149
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    import pytest

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class DummyData:
        pass

    @dataclass
    @config(undefined=Undefined.EXCLUDE)
    class DummyData2:
        a: int

    with pytest.raises(UndefinedParameterError):
        @dataclass
        @config(undefined="invalid_undef_param")
        class CannotDeclare:
            pass

    # Declaring a encode/decode function and override existing one
    def _encode(data, _encode=global_config.encoders[DummyData]):
        """
        A sample encoder
        """
        return _encode(data)


# Generated at 2022-06-23 16:39:58.976447
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('a string')
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:40:00.454699
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('foo') == False


# Generated at 2022-06-23 16:40:01.309082
# Unit test for constructor of class Exclude
def test_Exclude():
    assert '_GlobalConfig' in __dict__

# Generated at 2022-06-23 16:40:05.295240
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("banana")
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS(set())
    assert Exclude.ALWAYS(dict())
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(Exclude.ALWAYS)


# Generated at 2022-06-23 16:40:09.577296
# Unit test for constructor of class Exclude
def test_Exclude():
    assert type(Exclude.ALWAYS) == Exclude.ALWAYS.__class__ == Callable
    assert type(Exclude.NEVER) == Exclude.NEVER.__class__ == Callable


# Generated at 2022-06-23 16:40:21.713393
# Unit test for function config
def test_config():
    def check(type_, name, value):
        assert config()['dataclasses_json'][name] == value
        assert config() == metadata.dataclasses_json
        assert metadata[type_.__name__] == {}
        assert metadata['dataclasses_json'][name] == value

    class Foo:
        pass

    assert config() == {}
    assert config()['dataclasses_json'] == {}

    # TODO: #180
    # assert config(json_module=True)['dataclasses_json']['json_module'] == json

    metadata = config(encoder=Foo, decoder=Foo, mm_field=Foo, letter_case=Foo, exclude=Foo, undefined=Foo)
    check(Foo, 'encoder', Foo)

# Generated at 2022-06-23 16:40:24.771222
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("hello")
    assert not Exclude.NEVER("hello")

# Generated at 2022-06-23 16:40:29.242636
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1.encoders == {}
    assert global_config1.decoders == {}
    assert global_config1.mm_fields == {}


# Generated at 2022-06-23 16:40:31.689107
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    return

test__GlobalConfig()

# Generated at 2022-06-23 16:40:32.437177
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-23 16:40:32.921131
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:40:34.182843
# Unit test for function config
def test_config():
    metadata = config()
    assert metadata == {'dataclasses_json': {}}



# Generated at 2022-06-23 16:40:35.623158
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test = Exclude.ALWAYS(None)
    assert test == True


# Generated at 2022-06-23 16:40:40.225054
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.mm_fields
    global_config.encoders
    global_config.decoders
    global_config.encoders = {}
    global_config.decoders = {}
    global_config.mm_fields = {}
if __name__ == "__main__":
    test__GlobalConfig()

# Generated at 2022-06-23 16:40:52.157419
# Unit test for function config
def test_config():
    # If a value is undefined, it is not included in the dict.
    assert 'encoder' not in config()['dataclasses_json']

    # Providing an encoder adds an `encoder` key.
    assert 'encoder' in config(encoder=json.dumps)['dataclasses_json']

    # If a value is passed in, it will be stored.
    assert config(encoder=json.dumps)['dataclasses_json']['encoder'] == json.dumps

    # But the key does not appear if no value is passed in.
    assert 'encoder' not in config(encoder=None)['dataclasses_json']

# Generated at 2022-06-23 16:40:53.662811
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    pass


# Generated at 2022-06-23 16:40:59.262389
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():

    from marshmallow import fields

    global_config.encoders[int] = lambda x: x
    global_config.decoders[int] = lambda x: x
    global_config.mm_fields[int] = fields.Integer()

    # TODO: add test for json_module here

# Generated at 2022-06-23 16:41:00.405074
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:41:02.424279
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0


# Generated at 2022-06-23 16:41:04.938181
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-23 16:41:08.186992
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS == Exclude.ALWAYS
    assert Exclude.ALWAYS != Exclude.NEVER
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)


# Generated at 2022-06-23 16:41:11.492823
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == Exclude.NEVER(2) == Exclude.NEVER('a') == Exclude.NEVER('b') == False

test_Exclude_NEVER()

# Generated at 2022-06-23 16:41:14.236197
# Unit test for function config
def test_config():
    config(undefined='ignore')

# Generated at 2022-06-23 16:41:16.736932
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)


# Generated at 2022-06-23 16:41:25.145309
# Unit test for function config
def test_config():
    import inspect
    import dataclasses
    import json

    @dataclasses.dataclass
    class Test:
        name: str = dataclasses.field(metadata=config(
            field_name='NAME',
            letter_case=lambda x: x.upper(),
            decoder=lambda value: value.upper(),
            undefined=Undefined.RAISE,
            exclude=Exclude.NEVER,
        ))

    assert inspect.signature(Test).parameters['name'].default == dataclasses.MISSING
    assert str(inspect.signature(Test)) == '(name: str = <dataclasses._MISSING>)'

    assert Test().name == dataclasses.MISSING
    assert Test.schema().load({"name": "name"}).data.name == "name"
    assert Test.schema

# Generated at 2022-06-23 16:41:34.622278
# Unit test for function config
def test_config():
    from marshmallow.fields import String
    from marshmallow.validate import OneOf
    from dataclasses_json.undefined import Undefined

    @config(
        encoder=str,
        decoder=str,
        mm_field=String(validate=OneOf(["foo", "bar"])),
        letter_case=lambda s: s.upper(),
        exclude=lambda _, __: True,
        undefined=Undefined.RAISE,
    )
    class Foo:
        pass

    assert Foo.__dataclasses_json__['encoder'] == str
    assert Foo.__dataclasses_json__['decoder'] == str
    assert isinstance(Foo.__dataclasses_json__['mm_field'], String)

# Generated at 2022-06-23 16:41:36.539455
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("something")


# Generated at 2022-06-23 16:41:40.003458
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert not Exclude.ALWAYS(False)
    assert not Exclude.NEVER(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-23 16:41:47.581415
# Unit test for function config
def test_config():
    from marshmallow import fields
    @config(
        encoder=lambda x: x.lower(),
        decoder=lambda x: x.upper(),
        mm_field=fields.Email
    )
    class Test:
        pass
    assert Test().__metadata__.pop('dataclasses_json').pop('mm_field')[fields.Email]

    @config(
        encoder=lambda x: x.lower(),
        decoder=lambda x: x.upper()
    )
    class Test:
        pass
    assert Test().__metadata__.pop('dataclasses_json').pop('encoder')[lambda x: x.lower()]


# Generated at 2022-06-23 16:41:50.166890
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert Exclude.NEVER(1)
    assert not Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:41:54.034728
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    t = _GlobalConfig()
    assert t.encoders == {}
    assert t.decoders == {}
    assert t.mm_fields == {}


# Generated at 2022-06-23 16:41:56.085731
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("a") == True
    assert Exclude.NEVER("b") == False

# Generated at 2022-06-23 16:41:58.266701
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(1)
    assert(result==False)


# Generated at 2022-06-23 16:42:01.581458
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config_test = _GlobalConfig()
    assert config_test.encoders == {}
    assert config_test.decoders == {}
    assert config_test.mm_fields == {}


# Generated at 2022-06-23 16:42:03.525578
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:42:08.254421
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert isinstance(a.encoders, dict)
    assert isinstance(a.decoders, dict)
    assert isinstance(a.mm_fields, dict)
    assert a.encoders == {}
    assert a.decoders == {}
    assert a.mm_fields == {}


# Generated at 2022-06-23 16:42:09.450087
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

test__GlobalConfig()

# Generated at 2022-06-23 16:42:14.668926
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from dataclasses import dataclass
    @dataclass
    class Example:
        a: int
        b: int
    # todo: test
    # global_config.encoders[Example] = lambda data: data
    # global_config.decoders[Example] = lambda data: data
    # global_config.mm_fields[Example] = lambda data: data
    # assert global_config.encoders[Example] is not None
    # assert global_config.decoders[Example] is not None
    # assert global_config.mm_fields[Example] is not None
    return True


# Generated at 2022-06-23 16:42:20.228836
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from .converter_base import get_converter
    from .main import ConverterMapping

    # TODO: figure out a better way to test this.
    # Since this is a relatively complicated test, we want to assert that all
    # the parameters of the configuration work as expected. It would be best
    # to try to do this within the same function, but we also don't want to
    # assert that the configuration was applied to the dataclass.
    #
    # This is the best solution I can think of, but let's see if there is a
    # better way...

    def assert_field_name_match(obj, expected_field_names):
        expected_field_names = set(expected_field_names)

# Generated at 2022-06-23 16:42:22.373946
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:42:25.510779
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)
    assert Exclude.ALWAYS("string")
    assert not Exclude.NEVER("string")


# Generated at 2022-06-23 16:42:27.262910
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Unit tests for function config

# Generated at 2022-06-23 16:42:29.298355
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False



# Generated at 2022-06-23 16:42:31.331540
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)



# Generated at 2022-06-23 16:42:32.781104
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("hello")
    assert not Exclude.NEVER("hello")

# Generated at 2022-06-23 16:42:40.796012
# Unit test for function config
def test_config():
    from marshmallow import fields
    import dataclasses

    @dataclasses.dataclass
    class A:
        a = fields.Str()

        class Config:
            mm_field = fields.Str()

    assert A.Config.mm_field is fields.Str

    @dataclasses.dataclass
    class B:
        b = fields.Str()

        class Config:
            mm_field = fields.Str()

    assert B.Config.mm_field is fields.Str

    default = config(mm_field = fields.Str(required = True))

    @dataclasses.dataclass
    class C:
        c = fields.Str()

        class Config:
            encode_always = True

    assert C.Config.mm_field is fields.Str

    # Confirm this is the case

# Generated at 2022-06-23 16:42:45.421831
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_GlobalConfig = _GlobalConfig()
    assert len(test_GlobalConfig.encoders) == 0
    assert len(test_GlobalConfig.decoders) == 0
    assert len(test_GlobalConfig.mm_fields) == 0


# Generated at 2022-06-23 16:42:48.839916
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gC = _GlobalConfig()
    assert isinstance(gC, _GlobalConfig)

# Generated at 2022-06-23 16:42:50.754569
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("abc")



# Generated at 2022-06-23 16:42:58.498691
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int

    assert Person.from_json('{"name":"John"}') == Person('John', Undefined.RAISE)
    assert Person.from_json('{"name":"John"}', exclude=config(exclude=Exclude.ALWAYS)) == Person('John', Undefined.EXCLUDE)
    assert Person.from_json('{"name":"John"}', exclude=config(exclude=Exclude.ALWAYS, undefined=Undefined.EXCLUDE)) == Person('John', Undefined.EXCLUDE)

if __name__ == '__main__':
    test_Exclude_ALWAYS()

# Generated at 2022-06-23 16:43:00.383496
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    a=Exclude()
    assert a.ALWAYS(1)

# Generated at 2022-06-23 16:43:01.464368
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.__init__()

# Generated at 2022-06-23 16:43:02.926587
# Unit test for method NEVER of class Exclude

# Generated at 2022-06-23 16:43:10.072679
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    f = Exclude.ALWAYS
    assert f("") == True
    assert f("a") == True
    assert f(1) == True
    assert f(True) == True
    assert f(False) == True
    assert f([1,2]) == True
    assert f((1,2)) == True
    assert f({"a":1}) == True
    assert f(None) == True
    return True

test_Exclude_ALWAYS()


# Generated at 2022-06-23 16:43:11.525039
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-23 16:43:12.659495
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-23 16:43:17.529110
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(True)==False)
    assert(Exclude.NEVER(False)==False)
    assert(Exclude.NEVER(1)==False)
    assert(Exclude.NEVER(-1)==False)
    assert(Exclude.NEVER('foo')==False)
    assert(Exclude.NEVER('')==False)



# Generated at 2022-06-23 16:43:20.579023
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER("")
    assert Exclude.ALWAYS("")

# Generated at 2022-06-23 16:43:22.570593
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert [], global_config.encoders
    assert [], global_config.decoders
    assert [], global_config.mm_fields

# Generated at 2022-06-23 16:43:24.754165
# Unit test for constructor of class Exclude
def test_Exclude():
    """
    This function is for unit test
    """
    assert Exclude.ALWAYS('') == True
    assert Exclude.NEVER('') == False

# Generated at 2022-06-23 16:43:26.509998
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-23 16:43:28.222135
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:43:30.687519
# Unit test for function config
def test_config():
    config(exclude=lambda parameter: parameter.name in ['name'])

# Generated at 2022-06-23 16:43:38.126288
# Unit test for function config
def test_config():
    # all defaults
    assert config() == {'dataclasses_json': {}}

    # all valid options
    assert config(encoder=1, decoder=2, mm_field=3, field_name=4, letter_case=5, undefined=6, exclude=7) == \
        {'dataclasses_json': {'encoder': 1, 'decoder': 2, 'mm_field': 3, 'field_name': 4, 'letter_case': 5,
                              'undefined': 6, 'exclude': 7}}

    # invalid undefined, should crash
    with pytest.raises(UndefinedParameterError):
        config(undefined='invalid')

    # valid undefined, override letter_case

# Generated at 2022-06-23 16:43:38.994023
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(12) == True
    assert Exclude.NEVER(12) == False


# Generated at 2022-06-23 16:43:41.778446
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(2)

# Generated at 2022-06-23 16:43:48.448516
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields, validate

    @dataclass
    @config(mm_field=fields.List(fields.Int(), validate=validate.Length(1)))
    class Test:
        a: int = 0
        b: int = 1

    assert Test.__dataclass_fields__['a'].metadata['dataclasses_json']['mm_field'].validate == validate.Length(1)
    assert Test.__dataclass_fields__['b'].metadata['dataclasses_json']['mm_field'].validate == validate.Length(1)

# Generated at 2022-06-23 16:43:50.993614
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class ExampleClass:
        """A dummy class that needs to be treated in the same way as a field"""

    assert Exclude.NEVER(ExampleClass)

# Generated at 2022-06-23 16:43:59.056142
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config._json_module == json

# # Unit test for property 'json_module' of class _GlobalConfig
# def test__json_module():
#     global_config = _GlobalConfig()
#     assert global_config.json_module == json
#     global_config.json_module = ujson
#     assert global_config.json_module == ujson



# Generated at 2022-06-23 16:44:00.028275
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2)
    assert not Exclude.NEVER(2)

# Generated at 2022-06-23 16:44:01.994816
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-23 16:44:09.532136
# Unit test for function config
def test_config():
    from marshmallow import fields
    @dataclass
    @config(field_name="fname")
    class Test:
        fname: str
    assert Test.__dataclass_fields__["fname"].metadata['fname'] == "fname"

    @config(mm_field=fields.Integer())
    @dataclass
    class Test:
        i: int
    assert Test.__dataclass_fields__["i"].metadata['mm_field'].__class__.__name__ == "Integer"

    @config(letter_case=lambda x: x.upper())
    @dataclass
    class Test:
        letter_case: str
    assert Test.__dataclass_fields__["letter_case"].metadata['letter_case'](x="x") == "X"


# Generated at 2022-06-23 16:44:14.694865
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)
    assert Exclude.ALWAYS('')
    assert not Exclude.NEVER('')

if __name__ == "__main__":
    test_Exclude()

    print('Passed!')

# Generated at 2022-06-23 16:44:17.024861
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test = Exclude.NEVER(3)
    assert test == False

# Generated at 2022-06-23 16:44:18.289017
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1), "Excluded fields should always return False"



# Generated at 2022-06-23 16:44:26.422750
# Unit test for function config
def test_config():
    # Test that it creates the metadata correctly
    assert config() == {'dataclasses_json': {}}

    # Test that it adds the encoder and decoder correctly
    def encoder(obj):
        return "{0}".format(obj)
    def decoder(s):
        return 0
    assert config(
        encoder=encoder, decoder=decoder) == {
            'dataclasses_json': {
                'encoder': encoder,
                'decoder': decoder,
            }
        }

    class MyField(MarshmallowField):
        pass
    assert config(mm_field=MyField) == {'dataclasses_json': {'mm_field': MyField}}
