

# Generated at 2022-06-23 16:34:20.383522
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:34:21.653522
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:34:29.446402
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)
    assert Exclude.NEVER("")
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(int(3))
    assert Exclude.NEVER(float(4.4))
    checkList = [1, 2, 3]
    assert Exclude.NEVER(checkList)
    checkTuple = (1, 2, 3)
    assert Exclude.NEVER(checkTuple)


# Generated at 2022-06-23 16:34:33.123891
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():

    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:34:34.501135
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(100)

# Generated at 2022-06-23 16:34:36.089516
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('')


# Generated at 2022-06-23 16:34:38.765165
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    func = lambda _: 5
    
    if Exclude.NEVER(func) == False:
        print("Test Exclude.NEVER successfully")
    else:
        print("Test Exclude.NEVER failed")
        quit(1)


# Generated at 2022-06-23 16:34:40.743959
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:34:42.846806
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    t = _GlobalConfig()
    assert t.encoders == {}
    assert t.mm_fields == {}
    assert t.decoders == {}

# Generated at 2022-06-23 16:34:44.506666
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:34:46.146959
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    exclude = Exclude()
    assert exclude.NEVER(42) == False


# Generated at 2022-06-23 16:34:47.448749
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(True))


# Generated at 2022-06-23 16:34:48.960277
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:34:50.149072
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config


# Generated at 2022-06-23 16:34:52.050513
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("") == True
    assert Exclude.NEVER("") == False

# Generated at 2022-06-23 16:34:54.797224
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:34:58.706704
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER('hi') == False

# Generated at 2022-06-23 16:35:02.266622
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER('test') == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(5.4) == False

# Generated at 2022-06-23 16:35:08.152567
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_dict = {
        'encoders': {},
        'decoders': {},
        'mm_fields': {}
    }
    assert global_config.encoders == test_dict['encoders']
    assert global_config.decoders == test_dict['decoders']
    assert global_config.mm_fields == test_dict['mm_fields']

# Generated at 2022-06-23 16:35:10.410989
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('foo') == True


# Generated at 2022-06-23 16:35:14.710919
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def test_NEVER(x: Exclude):
        assert x.NEVER(True) == False
        assert x.NEVER(False) == False
        assert x.NEVER(None) == False
        assert x.NEVER(44) == False

    test_NEVER(Exclude())


# Generated at 2022-06-23 16:35:15.582179
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("any")
    assert not Exclude.NEVER("any")

# Generated at 2022-06-23 16:35:23.387020
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Pet(DataClassJsonMixin):
        name: str = None
        age: int = config(exclude=Exclude.ALWAYS)

    p = Pet(name='name', age=1)
    assert p.to_json() == '{"name": "name"}'
    assert p.to_dict() == {'name': 'name'}
    assert Pet.from_dict({'name': 'name'}) == Pet(name='name')
    p = Pet(name='name', age=1)
    assert p.to_json() == '{"name": "name"}'
    assert p.to_dict() == {'name': 'name'}

# Generated at 2022-06-23 16:35:25.228386
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:35:29.251113
# Unit test for function config
def test_config():
    import pytest  # noqa

    with pytest.raises(UndefinedParameterError):
        config(undefined='not a real parameter')

    with pytest.raises(UndefinedParameterError):
        config(undefined=Undefined.ERROR)



# Generated at 2022-06-23 16:35:33.785280
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, type(lambda _: True))
    assert isinstance(Exclude.NEVER, type(lambda _: False))

# Unit tests for constructor of class _GlobalConfig

# Generated at 2022-06-23 16:35:36.230346
# Unit test for constructor of class Exclude
def test_Exclude():
    assert not Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:35:37.690958
# Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-23 16:35:38.726787
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-23 16:35:46.412578
# Unit test for function config
def test_config():
    import datetime
    from marshmallow import fields
    from dataclasses import dataclass
    from typing import NewType
    import pytest

    ID = NewType("ID", int)

    @dataclass
    class User:
        id: ID = config(mm_field=fields.Integer())
        name: str
        email: str
        when_created: datetime.datetime = config(decoder=datetime.datetime.fromisoformat)

    user = User(id=ID(1), name="test", email="test@test.com", when_created=datetime.datetime.now())

    assert user.id == 1
    assert user.name == "test"
    assert user.email == "test@test.com"
    assert isinstance(user.when_created, datetime.datetime)


# Generated at 2022-06-23 16:35:48.333608
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False



# Generated at 2022-06-23 16:35:58.533628
# Unit test for function config
def test_config():
    class Config:
        RENAME_BY_CAMEL_CASE = 1
        RENAME_BY_PASCAL_CASE = 2
        RENAME_BY_SNAKE_CASE = 3
        RENAME_BY_CAPS_SNAKE_CASE = 4
        REMOVE = 5
        EXCLUDE = 6
        RAISE = 10
        EMPTY = 11
        DEFAULT = 12
        OMIT = 13

    @config(metadata={'rename_fields_by': Config.RENAME_BY_SNAKE_CASE},)
    class Foo:
        BAR = 1
        BAZ = 2

    class Exclude:
        def exclude(_, string, _int):
            return (string == "FOO" and _int == 1)


# Generated at 2022-06-23 16:35:59.290473
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('')

# Generated at 2022-06-23 16:36:03.084888
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(-1)
    assert Exclude.ALWAYS(1.1)



# Generated at 2022-06-23 16:36:08.317362
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    class Example:
        __metadata__ = config(field_name="test")
        a: int

    assert Example.__metadata__["dataclasses_json"]["field_name"](None) == "test"

# Generated at 2022-06-23 16:36:09.620525
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a')


# Generated at 2022-06-23 16:36:11.465449
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a')
    assert not Exclude.NEVER('a')

# Generated at 2022-06-23 16:36:12.665986
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config is not None

test__GlobalConfig()


# Generated at 2022-06-23 16:36:14.308081
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    is_true = Exclude.ALWAYS(True)
    assert  is_true == True


# Generated at 2022-06-23 16:36:16.587320
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Test:
        pass
    # Test.NEVER = Exclude.NEVER
    result = Test.NEVER(Test())
    assert result == False

# Generated at 2022-06-23 16:36:20.431774
# Unit test for function config
def test_config():
    @dataclass
    class TestClass:
        field_name: str

    assert TestClass.__dict__['field_name'].metadata == config(field_name='field_name')


# TODO: this could be abstracted further

# Generated at 2022-06-23 16:36:25.037868
# Unit test for function config
def test_config():
    '''
    >>> @dataclass
    ... @config(exclude=Exclude.NEVER)
    ... class test_config_class:
    ...     pass
    >>> config(test_config_class)
    {'dataclasses_json': {'exclude': <function Exclude.NEVER at 0x7f8a8d31a510>}}
    '''

# Generated at 2022-06-23 16:36:26.466919
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-23 16:36:28.220408
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)



# Generated at 2022-06-23 16:36:30.388181
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    Test method NEVER of class Exclude
    """
    assert Exclude.NEVER(None)

# Generated at 2022-06-23 16:36:33.530154
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER == functools.partial(lambda _: False)


# Generated at 2022-06-23 16:36:38.098958
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Entity:
        foo: str = config(field_name="name")
        bar: int = config(undefined=Undefined.EXCLUDE)

    @dataclass
    class Entity2:
        foo: str = config(field_name="name")
        bar: int = config(undefined=Undefined.RAISE)

# Generated at 2022-06-23 16:36:40.170641
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER("a") == False
    assert Exclude.ALWAYS("a") == True


# Test the config() function

# Generated at 2022-06-23 16:36:43.305767
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def test_func(value) -> bool:
        return True

    assert Exclude.NEVER(test_func) == False



# Generated at 2022-06-23 16:36:45.077691
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    res = Exclude.ALWAYS(None)
    assert True == res

# Generated at 2022-06-23 16:36:47.026925
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
	test_config = _GlobalConfig()
	assert test_config


# Generated at 2022-06-23 16:36:48.821768
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")


# Generated at 2022-06-23 16:36:57.752475
# Unit test for function config
def test_config():
    import pytest
    from .main import Config

    config_dict = {}

    assert config(config_dict) == {'dataclasses_json': {}}

    @config(config_dict, encoder='encoder', decoder='decoder',
            mm_field='mm_field', undefined='RAISE', field_name='field_name',
            exclude=Exclude.NEVER)
    class Data:
        a: int = 1

    config = Config.infer(Data)
    assert config.encoder == 'encoder'
    assert config.decoder == 'decoder'
    assert config.mm_field == 'mm_field'
    assert config.undefined == Undefined.RAISE
    assert config.field_name == 'field_name'

# Generated at 2022-06-23 16:36:59.986014
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-23 16:37:04.109378
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders[float] = float
    global_config.decoders[float] = float
    assert global_config.encoders[float] == float
    assert global_config.decoders[float] == float


# Generated at 2022-06-23 16:37:11.602315
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER('a')
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(5.5)
    assert Exclude.NEVER((1, 2))
    assert Exclude.NEVER(["a", "b"])
    assert Exclude.NEVER({})
    assert Exclude.NEVER({"a": "b"})

# Generated at 2022-06-23 16:37:13.347344
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("some string")
    assert Exclude.ALWAYS(1234)


# Generated at 2022-06-23 16:37:15.647201
# Unit test for function config
def test_config():
    @config(exclude=Exclude.ALWAYS)
    class cls:
        pass

    assert cls.__dataclass_json__.get('exclude') == Exclude.ALWAYS

# Generated at 2022-06-23 16:37:21.201210
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    assert conf.encoders == {}
    assert conf.decoders == {}
    assert conf.mm_fields == {}
    # assert conf.json_module == json
    #
    # conf.json_module = simplejson
    # assert conf.json_module == simplejson



# Generated at 2022-06-23 16:37:25.736958
# Unit test for function config
def test_config():
    class TestClass:
        @classmethod
        def test_function():
            pass
    @config()
    class TestClass2:
        pass
    @config(encoder=TestClass.test_function)
    class TestClass3:
        pass
    assert 'encoder' in TestClass3.__dataclasses_json__
    assert TestClass3.__dataclasses_json__['encoder'] == TestClass.test_function

# Generated at 2022-06-23 16:37:29.173170
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}


# Generated at 2022-06-23 16:37:38.242916
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    from dataclasses_json import config

    assert not hasattr(config, "json")
    assert isinstance(config.encoders, dict)
    assert isinstance(config.decoders, dict)
    assert isinstance(config.mm_fields, dict)

    @config(encoder=lambda o: f"<<{o}>>")
    @dataclasses.dataclass
    class Example:
        s: str

    assert Example.__dataclass_fields__["s"].metadata["dataclasses_json"]["encoder"](
        "Hello") == "<<Hello>>"

    @config(decoder=lambda s: s[2:-2])
    @dataclasses.dataclass
    class Example:
        s: str

    assert Example.__datac

# Generated at 2022-06-23 16:37:46.063513
# Unit test for function config
def test_config():
    from marshmallow import fields as mm_fields
    from dataclasses import dataclass

    @dataclass
    class Data:
        field: int = config(encoder=str,
                            mm_field=mm_fields.String(),
                            exclude=Exclude.NEVER)

    assert Data._config['dataclasses_json']['encoder'] == str
    assert Data._config['dataclasses_json']['mm_field'] == mm_fields.String()
    assert Data._config['dataclasses_json']['exclude'] == Exclude.NEVER

# Generated at 2022-06-23 16:37:47.669229
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test")

# Generated at 2022-06-23 16:37:52.194184
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}
    assert _GlobalConfig()._disable_msg == ("Please use a JSON library other "
                                            "than json or simplejson.")
    assert _GlobalConfig()._json_module == json


# Generated at 2022-06-23 16:37:55.986143
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS([])


# Generated at 2022-06-23 16:38:04.712408
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("Exclude::ALWAYS returns True for any input")
    if Exclude.ALWAYS(-1) == True:
        print("ALWAYS(-1) == True")
    if Exclude.ALWAYS(0) == True:
        print("ALWAYS(0) == True")
    if Exclude.ALWAYS(1) == True:
        print("ALWAYS(1) == True")
    if Exclude.ALWAYS('Test') == True:
        print("ALWAYS('Test') == True")
    if Exclude.ALWAYS([]) == True:
        print("ALWAYS([]) == True")
    if Exclude.ALWAYS({}) == True:
        print("ALWAYS({}) == True")
    if Exclude.ALWAYS(True) == True:
        print("ALWAYS(True) == True")

# Generated at 2022-06-23 16:38:05.979697
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-23 16:38:09.138636
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(1.1) == False
    assert Exclude.NEVER('test') == False
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:38:12.093819
# Unit test for function config
def test_config():
    assert config(field_name="Foo", letter_case=None) == {
        'dataclasses_json': {
            'letter_case': 'foo'
        }
    }

# Generated at 2022-06-23 16:38:16.057175
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    """
    This method should return bool True no matter what the input is.
    """
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0.5)


# Generated at 2022-06-23 16:38:25.529658
# Unit test for function config
def test_config():
    import json
    import marshmallow
    from dataclasses_json.config import config

    class JSONEncoder(json.JSONEncoder): pass
    class JSONDecoder(json.JSONDecoder): pass
    class Field(marshmallow.fields.Field): pass

    class CustomUndefined(Undefined):
        def __call__(self, _):
            assert self == Undefined.RAISE


# Generated at 2022-06-23 16:38:28.052475
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig
    assert global_config
    print('Success: test__GlobalConfig')


# Generated at 2022-06-23 16:38:28.599818
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-23 16:38:30.718557
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class Foo:
        foo: str = dataclasses.field(metadata=config(exclude=Exclude.ALWAYS))

# Generated at 2022-06-23 16:38:39.504152
# Unit test for function config
def test_config():
    assert config() == {
        'dataclasses_json': {
            'encoder': None,
            'decoder': None,
            'mm_field': None,
            'letter_case': None,
            'undefined': None,
            'exclude': None
        }
    }
    assert config(decoder=lambda x: str(x)) == {
        'dataclasses_json': {
            'encoder': None,
            'decoder': lambda x: str(x),
            'mm_field': None,
            'letter_case': None,
            'undefined': None,
            'exclude': None
        }
    }

# Generated at 2022-06-23 16:38:44.104430
# Unit test for constructor of class Exclude
def test_Exclude():
    if Exclude.ALWAYS(1):
        print("alway works")
    else:
        raise Exception("Exception occurred in Exclude.ALWAYS")

    if not Exclude.NEVER(1):
        print("never works")
    else:
        raise Exception("Exception occurred in Exclude.NEVER")

test_Exclude()

# Generated at 2022-06-23 16:38:49.589033
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field

    @dataclass
    @config(field_name='new_name', exclude=lambda f, _: f.name == 'never')
    class ConfigClass:
        always: int = field(metadata=config(letter_case=lambda _: 'ALWAYS'))
        never: int = field(metadata=config(exclude=Exclude.ALWAYS))
        def __init__(self):
            pass
    return ConfigClass

# Generated at 2022-06-23 16:38:53.174113
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('123')
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS((1, 2))


# Generated at 2022-06-23 16:38:54.799066
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-23 16:38:57.545770
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dc = config(exclude=Exclude.ALWAYS)

# Generated at 2022-06-23 16:39:05.227131
# Unit test for function config
def test_config():
    import pytest
    from marshmallow.fields import Raw
    from dataclasses_json.undefined import Undefined
    from dataclasses import dataclass
    from typing import cast
    from ._compat import IS_PY36

    @dataclass
    class Test:
        x: int = 2
        y: int = 3
        z: int = 4

    func = lambda x: x + 2
    encoder = lambda x: x + 1
    decoder = lambda x: x - 1
    mm_field = Raw()
    letter_case = lambda x: x.upper()
    undefined = Undefined.STRICT
    field_name = "test_field"
    exclude = Exclude.ALWAYS


# Generated at 2022-06-23 16:39:07.581182
# Unit test for function config
def test_config():
    @config(field_name='b_field')
    class _:
        a_field: int
        b_field: int

# Generated at 2022-06-23 16:39:15.663125
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    @config(mm_field=True, encoder=True, letter_case=1, field_name="Field",
            undefined=Undefined.EXCLUDE, exclude=lambda _1, _2: True)
    class A:
        pass

    assert A.__dataclass_metadata__ == {
        'dataclasses_json': {
            'encoder': True,
            'mm_field': True,
            'letter_case': 1,
            'undefined': Undefined.EXCLUDE,
            'exclude': (lambda _1, _2: True)
        }
    }

    # Invalid undefined

# Generated at 2022-06-23 16:39:17.856003
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:39:18.946072
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(1)==False)


# Generated at 2022-06-23 16:39:20.325896
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def f(x):
        return x

    assert Exclude.NEVER(f) == False


# Generated at 2022-06-23 16:39:29.557423
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    @dataclass()
    class TestDc:
        a: str = "a"
        b: str = "b"
        _c: str = "c"

        @config()
        def _get_metadata(metadata):
            metadata['a'] = 'a'
            metadata['b'] = 'b'
            return metadata

        @config(exclude=Exclude.ALWAYS)
        def _get_metadata_exclude_always(metadata):
            return metadata

        @config(exclude=Exclude.NEVER)
        def _get_metadata_exclude_never(metadata):
            return metadata


# Generated at 2022-06-23 16:39:35.438348
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {1:1}
    global_config.decoders = {2:2}
    global_config.mm_fields = {3:3}

    assert global_config.encoders == {1:1}
    assert global_config.decoders == {2:2}
    assert global_config.mm_fields == {3:3}
    


# Generated at 2022-06-23 16:39:39.146654
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS('aa') == True
    assert Exclude.ALWAYS('aaaaaaaaa') == True
    assert Exclude.ALWAYS('') == True


# Generated at 2022-06-23 16:39:52.339446
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from dataclasses_json.utils import class_to_dict
    from marshmallow import fields as mm_fields
    test_class = _GlobalConfig()
    test_encoders = {}
    test_decoders = {}
    test_mm_fields = {}

    test_encoders[1] = type
    test_class.encoders = test_encoders
    test_decoders[1] = type
    test_class.decoders = test_decoders
    test_mm_fields[1] = mm_fields.Integer()
    test_class.mm_fields = test_mm_fields

    # test_class.json_module = test_encoders
    # assert test_class.json_module == test_encoders


# Generated at 2022-06-23 16:40:01.639113
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestClass():
        def __init__(self,a,b):
            assert a == 1
            assert b == 2
            self.a = a
            self.b = b
    NEVER = Exclude.NEVER
    test_class = TestClass(1,1)
    assert NEVER(test_class)==False
    test_class = TestClass(1,2)
    assert NEVER(test_class)==False

if __name__ == "__main__":
    print("Start to test Exclude")
    test_Exclude_NEVER()
    print("Exclude test pass")

# Generated at 2022-06-23 16:40:02.430313
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-23 16:40:06.224053
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_data = _GlobalConfig()
    assert test_data.encoders == {}
    assert test_data.decoders == {}
    assert test_data.mm_fields == {}


# Generated at 2022-06-23 16:40:08.729606
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('anything')


# Generated at 2022-06-23 16:40:12.733207
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {}
    global_config.decoders = {}
    global_config.mm_fields = {}

# Generated at 2022-06-23 16:40:15.738565
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, Callable)
    assert isinstance(Exclude.NEVER, Callable)

# Generated at 2022-06-23 16:40:19.443988
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('1') == False
    assert Exclude.NEVER('') == False


# Generated at 2022-06-23 16:40:20.650421
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:40:25.570417
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def my_function() -> None:
        print("Hello from my_function")
    assert Exclude.ALWAYS(my_function) == True


# Generated at 2022-06-23 16:40:34.471988
# Unit test for function config
def test_config():
    @dataclass
    class Foo:
        bar: int

        class Meta:
            encoder = int
            decoder = str
            mm_field = MarshmallowField()
            letter_case = lambda s: s
            undefined = Undefined.RAISE
            field_name = "foo"
            exclude = Exclude.ALWAYS

        class Config:
            dataclasses_json = {
                'encoder': int,
                'decoder': str,
                'mm_field': MarshmallowField(),
                'letter_case': lambda s: s,
                'undefined': Undefined.RAISE,
                'field_name': 'foo',
                'exclude': Exclude.ALWAYS,
            }

    # If a field is specified in both @config and in the Config object, @config is preferred
    assert Foo.Config.dat

# Generated at 2022-06-23 16:40:40.137366
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    fn_Exclude_ALWAYS = Exclude.ALWAYS
    print(fn_Exclude_ALWAYS(1))
    assert fn_Exclude_ALWAYS(1)
    #
    print(fn_Exclude_ALWAYS(0))
    assert fn_Exclude_ALWAYS(1)



# Generated at 2022-06-23 16:40:42.562213
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('arg') == True


# Generated at 2022-06-23 16:40:49.793788
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    assert isinstance(c.encoders, dict)
    assert isinstance(c.decoders, dict)
    assert isinstance(c.mm_fields, dict)
    assert c.mm_fields == {}
    assert c.decoders == {}
    assert c.encoders == {}


# Generated at 2022-06-23 16:40:51.107582
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3)
    assert Exclude.NEVER(3)

# Generated at 2022-06-23 16:40:58.140390
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Arrange
    # Act
    global_config = _GlobalConfig()

    # Assert
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)

# Generated at 2022-06-23 16:40:59.540708
# Unit test for function config
def test_config():
    config(letter_case=1)

# Generated at 2022-06-23 16:41:01.518120
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:41:13.217837
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    import pytest
    from dataclasses_json.undefined import Undefined

    @dataclass
    @config(letter_case='snake')
    class User:
        name: str
        identifier: int

    # field_name

    assert User.__dataclass_fields__['name'].metadata == {}

    assert User.__dataclass_fields__['identifier'].metadata['dataclasses_json']['letter_case']('') == 'identifier'

    # undefined

    assert User.__dataclass_fields__['name'].metadata == {}

    assert User.__dataclass_fields__['identifier'].metadata['dataclasses_json']['undefined'] == Undefined.EXCLUDE


# Generated at 2022-06-23 16:41:14.046571
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(_GlobalConfig, object)

# Generated at 2022-06-23 16:41:17.081672
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert not Exclude.ALWAYS(Exclude.NEVER)


# Generated at 2022-06-23 16:41:18.269316
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-23 16:41:20.529024
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:41:31.117567
# Unit test for function config
def test_config():
    @config(encoder=lambda obj: None)
    @dataclass
    class TestClass:
        a: int

    tc = TestClass(1)
    assert tc.__dataclass_fields__['a'].metadata['dataclasses_json']['encoder'] \
        == (lambda obj: None)

    @config(letter_case=lambda s: s.upper())
    @dataclass
    class TestClass2:
        a: int

    tc2 = TestClass2(1)
    assert tc2.__dataclass_fields__['a'].metadata['dataclasses_json']['letter_case'] \
        == (lambda s: s.upper())

# Generated at 2022-06-23 16:41:33.120189
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class ReferenceClass:
        def __init__(self, name):
            self.name = name

    name = ReferenceClass('test')
    assert Exclude.NEVER(name) == False
test_Exclude_NEVER()

# Generated at 2022-06-23 16:41:34.248915
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-23 16:41:35.401318
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False

# Generated at 2022-06-23 16:41:38.213426
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    assert e.ALWAYS(1)
    assert not e.NEVER(1)

# Generated at 2022-06-23 16:41:39.719709
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:41:42.126231
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:41:43.833240
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False

# Generated at 2022-06-23 16:41:46.260483
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:41:54.853212
# Unit test for function config
def test_config():
    @dataclass
    class Person:
        name: str
        age: int

    assert Field(type(None), ()).metadata == {}
    assert Field(Person, 'name').metadata == {'dataclasses_json': {}}
    assert Field(Person, 'age').metadata == {'dataclasses_json': {}}
    assert Field(Person, 'name', default='Bob').metadata == {'dataclasses_json': {}}

    @config(encoder=str)
    @dataclass
    class Person:
        name: str
        age: int

    assert Field(Person, 'name').metadata == {'dataclasses_json': {'encoder': str}}
    assert Field(Person, 'age').metadata == {'dataclasses_json': {'encoder': str}}

# Generated at 2022-06-23 16:41:55.784514
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('abc')

# Generated at 2022-06-23 16:41:57.499881
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:41:58.574796
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-23 16:42:00.331858
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('x')


# Generated at 2022-06-23 16:42:01.282351
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) is False

# Generated at 2022-06-23 16:42:02.881930
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-23 16:42:13.086643
# Unit test for function config
def test_config():
    """
    Test config function
    """
    assert config(metadata={}) == {'dataclasses_json': {}}

    assert config(metadata={}, encoder='myencoder') == {
        'dataclasses_json': {'encoder': 'myencoder'}
    }

    assert config(metadata={'foo': 'bar'}, decoder='mydecoder') == {
        'foo': 'bar', 'dataclasses_json': {'decoder': 'mydecoder'}
    }

    assert config(metadata={'dataclasses_json': {'baz': 'qaz'}},
                  mm_field='mymmfield') == {
                      'dataclasses_json': {'baz': 'qaz',
                                           'mm_field': 'mymmfield'}
                  }


# Generated at 2022-06-23 16:42:14.406034
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER
    return True

# Generated at 2022-06-23 16:42:17.577353
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("test_Exclude")
    assert not Exclude.NEVER("test_Exclude")

# Generated at 2022-06-23 16:42:19.080925
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}


# Generated at 2022-06-23 16:42:22.508270
# Unit test for function config
def test_config():
    metadata: dict = {"dataclasses_json": {"encoder": "fakes"}}
    metadata = config(metadata, encoder=lambda x: x)
    assert metadata.get("dataclasses_json").get("encoder")(12345) == 12345

# Generated at 2022-06-23 16:42:34.106862
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json import DataClassJsonMixin

    # This should not raise an error
    @dataclass(config=config(undefined='RAISE'))
    class Dummy(DataClassJsonMixin):
        pass

    # This should raise an error
    try:
        @dataclass(config=config(undefined=1234))
        class Dummy(DataClassJsonMixin):
            pass
    except UndefinedParameterError as err:
        assert str(err.args[0]) == "Invalid undefined parameter action, " \
                                   "must be one of ['RAISE', 'EXCLUDE', " \
                                   "'INCLUDE']"

# Generated at 2022-06-23 16:42:34.974343
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-23 16:42:36.252113
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("abc")


# Generated at 2022-06-23 16:42:47.686127
# Unit test for function config
def test_config():
    from marshmallow import fields
    import pytest
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined

    @dataclass
    class Example:
        name: str
        movies: list
        dob: str = '11-11-2018'
        gender: str = 'Male'
        is_married: bool = None
        children: int = 0
        age: int = None
        income: float = 0.0

        class Config:
            mm_field = fields.Date("%Y-%m-%d")
            field_name = "dob"
            exclude = {'is_married', 'children'}
            letter_case = str.lower

    example_object = Example("John", ["Movie1", "Movie2"])

# Generated at 2022-06-23 16:42:51.651562
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders
    assert global_config.decoders
    assert global_config.mm_fields
    assert global_config._json_module == json



# Generated at 2022-06-23 16:42:55.052602
# Unit test for function config
def test_config():
    import pytest
    
    with pytest.raises(UndefinedParameterError):
        config(undefined="invalid_name")
    with pytest.raises(TypeError):
        config(undefined=lambda x: x)

# Generated at 2022-06-23 16:43:00.385543
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_field_name: str = "Test Field Name"
    class TestClass:
        testfield: str = test_field_name
    testClass: TestClass = TestClass()
    assert Exclude.NEVER(testClass.testfield) == False
    assert Exclude.NEVER(TestClass.testfield) == True
    

# Generated at 2022-06-23 16:43:02.647274
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = 'a'
    b = 'b'
    assert Exclude.NEVER(a) == False
    assert Exclude.NEVER(b) == False


# Generated at 2022-06-23 16:43:04.481770
# Unit test for constructor of class Exclude
def test_Exclude():
    eq_(Exclude.ALWAYS(1), True)
    eq_(Exclude.NEVER(1), False)

# Generated at 2022-06-23 16:43:07.094103
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) and Exclude.NEVER(False)


# Generated at 2022-06-23 16:43:08.346659
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert not Exclude.NEVER(True)

# Generated at 2022-06-23 16:43:18.368008
# Unit test for function config
def test_config():
    from .encoders import SimpleStr
    from .decoders import SimpleStr
    def date_str():
        pass
    @dataclasses.dataclass
    class A:
        str: SimpleStr
        e: int
        f: int
        g: int

    assert A.__dataclass_metadata__['dataclasses_json']['exclude'] is None
    assert A.__dataclass_metadata__['dataclasses_json']['undefined'] is None
    assert A.__dataclass_metadata__['dataclasses_json']['letter_case'] is None
    assert A.__dataclass_metadata__['dataclasses_json']['decoder'] is None
    assert A.__dataclass_metadata__['dataclasses_json']['encoder'] is None

# Generated at 2022-06-23 16:43:21.308994
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    fieldA = "FieldA"
    fieldB = "FieldB"
    fieldC = "FieldC"

    assert Exclude.ALWAYS(fieldA)
    assert Exclude.ALWAYS(fieldB)
    assert Exclude.ALWAYS(fieldC)


# Generated at 2022-06-23 16:43:32.918019
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field

    @dataclass
    class MyClass:
        foo: Optional[int] = field(metadata=config(
            encoder=lambda x: -x
        ))

        # Testing whether a field can be named whatever you want
        @classmethod
        def from_json(cls, json):
            return cls(foo=json['bar'])

        def __hash__(self):
            return hash(self.foo)

    assert MyClass(foo=42).as_json() == {'foo': -42}
    assert MyClass.schema().load({'foo': -42}) == MyClass(foo=42)
    assert MyClass.schema().dump(MyClass(foo=42)) == {'foo': -42}

# Generated at 2022-06-23 16:43:33.850701
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:43:44.909923
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(-2) == False
    assert Exclude.NEVER(-3) == False
    assert Exclude.NEVER(-4) == False
    assert Exclude.NEVER(-5) == False

    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude

# Generated at 2022-06-23 16:43:49.216446
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders[type] = str
    global_config.decoders[str] = type

    assert global_config.encoders[type] == str
    assert global_config.decoders[str] == type


# Generated at 2022-06-23 16:43:50.847131
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3)
    assert not Exclude.NEVER(42)

# Generated at 2022-06-23 16:43:52.247609
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-23 16:43:55.771035
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config_ = _GlobalConfig()
    assert isinstance(config_.encoders, dict)
    assert isinstance(config_.decoders, dict)
    assert isinstance(config_.mm_fields, dict)



# Generated at 2022-06-23 16:43:58.914899
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    tester= _GlobalConfig()
    assert tester.encoders == {}
    assert tester.decoders == {}
    assert tester.mm_fields == {}


# Generated at 2022-06-23 16:44:07.386270
# Unit test for constructor of class Exclude
def test_Exclude():
    # Exclude.ALWAYS
    assert Exclude.ALWAYS
    assert Exclude.ALWAYS(1), "Exclude.ALWAYS must return True"
    assert Exclude.ALWAYS(None), "Exclude.ALWAYS must return True"
    assert Exclude.ALWAYS([1, 2]), "Exclude.ALWAYS must return True"

    # Exclude.NEVER
    assert Exclude.NEVER
    assert not Exclude.NEVER(1), "Exclude.NEVER must return False"
    assert not Exclude.NEVER(None), "Exclude.NEVER must return False"
    assert not Exclude.NEVER([1, 2]), "Exclude.NEVER must return False"


# Generated at 2022-06-23 16:44:09.264327
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  assert Exclude.ALWAYS(1) == True
  # test with one parameter
  # test with more than one parameter


# Generated at 2022-06-23 16:44:15.565537
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Testing with integer input and expecting a boolean True
    value = Exclude.ALWAYS(10)
    assert value == True
    # Testing with string input and expecting a boolean True
    value = Exclude.ALWAYS("Test String")
    assert value == True
    # Testing with float input and expecting a boolean True
    value = Exclude.ALWAYS(10.5)
    assert value == True


# Generated at 2022-06-23 16:44:25.352246
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

    assert config() == {'dataclasses_json': {}}
    encoder = lambda _ : 'encoder'
    assert config(encoder=encoder) == {'dataclasses_json': {'encoder': encoder}}
    decoder = lambda _ : 'decoder'
    assert config(decoder=decoder) == {'dataclasses_json': {'decoder': decoder}}
    mm_field = MarshmallowField()
    assert config(mm_field=mm_field) == {'dataclasses_json': {'mm_field': mm_field}}
    letter_case = lambda s: s