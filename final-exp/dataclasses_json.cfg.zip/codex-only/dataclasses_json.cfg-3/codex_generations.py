

# Generated at 2022-06-23 16:34:15.891162
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS is not None


# Generated at 2022-06-23 16:34:16.935578
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders
    global_config.decoders
    global_config.mm_fields
    # global_config.json_module

# Generated at 2022-06-23 16:34:19.050671
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:34:20.093897
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")


# Generated at 2022-06-23 16:34:27.865849
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # test for method NEVER in class Exclude
    # create a test class
    class TestClass:
        def __init__(self, state: bool):
            self.state = state

    # create an example object, whose state is False
    test_object = TestClass(False)
    test_object_2 = TestClass(True)

    result = Exclude.NEVER(test_object)

    result_2 = Exclude.NEVER(test_object_2)

    assert result == False # True
    assert result_2 == False # True


# Generated at 2022-06-23 16:34:33.702026
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(3.14) == False
    assert Exclude.NEVER('5') == False
    assert Exclude.NEVER([1,2,3]) == False
    assert Exclude.NEVER({'k':'v'}) == False
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-23 16:34:36.816267
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(123) is False
    assert Exclude.NEVER('string') is False
    assert Exclude.NEVER([1, 2, 3, 4]) is False


# Generated at 2022-06-23 16:34:40.556819
# Unit test for function config
def test_config():
    metadata = config(exclude=True)
    assert metadata
    lib_metadata = metadata['dataclasses_json']
    assert lib_metadata['exclude']
    

test_config()

# Generated at 2022-06-23 16:34:49.544819
# Unit test for function config
def test_config():
    # TODO: more unit tests
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json import config

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class A:
        x: str
        y: int

    @dataclass
    class B:
        x: str
        y: int
    B = config(exclude=Exclude.ALWAYS)(B)

    @dataclass
    @config(encoder=dict)
    class C:
        x: str
        y: int

    @dataclass
    @config(encoder=dict, decoder=dict)
    class D:
        x: str
        y: int


# Generated at 2022-06-23 16:34:52.387710
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}
    # assert _GlobalConfig().json_module == json

# Generated at 2022-06-23 16:34:58.061177
# Unit test for function config
def test_config():
    def check(result: dict,
              exp_encoder: Callable,
              exp_decoder: Callable,
              exp_mm_field: MarshmallowField,
              exp_letter_case: str,
              exp_undefined: Undefined,
              exp_exclude: bool):
        assert result['encoder'] == exp_encoder
        assert result['decoder'] == exp_decoder
        assert result['mm_field'] == exp_mm_field
        assert result['letter_case'] == exp_letter_case
        assert result['undefined'] == exp_undefined
        assert result['exclude'] == exp_exclude

    orig = {'some': 'orig', 'not': 'overwritten'}

    def encoder(obj): pass
    def decoder(dct): pass

# Generated at 2022-06-23 16:35:05.459326
# Unit test for function config
def test_config():
    def assert_config(result, metadata, **expected):
        assert metadata.get('dataclasses_json', {}).get('letter_case') == expected.pop('letter_case', None)
        assert result == expected

    assert_config(
        config(letter_case=lambda s: s.upper()),
        {},
        letter_case=lambda s: s.upper()
    )

    assert_config(
        config({}, letter_case=lambda s: s.upper()),
        {},
        letter_case=lambda s: s.upper(),
    )


# Generated at 2022-06-23 16:35:07.959054
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-23 16:35:12.182616
# Unit test for function config
def test_config():
    @config(mm_field = 'test')
    def func():
        pass

    assert func.__dataclass_fields__['return_value'].metadata['dataclasses_json']['mm_field'] == 'test'



# Generated at 2022-06-23 16:35:14.936330
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module is json


# Generated at 2022-06-23 16:35:16.343458
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER
    assert x(1) == False


# Generated at 2022-06-23 16:35:18.224933
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not Exclude.NEVER
    assert Exclude.ALWAYS('a')
    assert not Exclude.NEVER('b')

# Generated at 2022-06-23 16:35:19.501659
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER


# Generated at 2022-06-23 16:35:21.603296
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert type(global_config_.encoders) == dict
    assert type(global_config_.decoders) == dict
    assert type(global_config_.mm_fields) == dict

# Generated at 2022-06-23 16:35:30.936605
# Unit test for function config
def test_config():
    import pytest
    @config(field_name="my_field")
    class TestConfig:
        def __init__(self, my_field):
            self.my_field = my_field

    assert TestConfig("value").my_field == "value"

    @config(field_name="my_field", letter_case=str.upper)
    class TestConfig2:
        def __init__(self, my_field):
            self.my_field = my_field

    assert TestConfig2("value").my_field == "value"

    with pytest.raises(UndefinedParameterError):
        @config(undefined='nosuch')
        class TestConfig3:
            def __init__(self, my_field):
                self.my_field = my_field

# Generated at 2022-06-23 16:35:32.000434
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

# Generated at 2022-06-23 16:35:33.436113
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True), "Exclude.ALWAYS method fails"

# Generated at 2022-06-23 16:35:35.397781
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert Exclude.ALWAYS(1)==True


# Generated at 2022-06-23 16:35:36.376247
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2) == True
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-23 16:35:37.840188
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("anything")


# Generated at 2022-06-23 16:35:39.378840
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:35:40.249038
# Unit test for constructor of class Exclude
def test_Exclude():
  assert Exclude.ALWAYS('a')
  assert not Exclude.NEVER('a')


# Generated at 2022-06-23 16:35:42.609324
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert len(config.encoders) == 0
    assert len(config.decoders) == 0
    assert len(config.mm_fields) == 0

# Generated at 2022-06-23 16:35:45.896757
# Unit test for function config
def test_config():
    import pytest

    @config(metadata={'foo': 'bar'})
    class C:
        name = 'C'

    assert C.__dict__ == {'metadata': {'foo': 'bar',
                                       'dataclasses_json': {}}}



# Generated at 2022-06-23 16:35:52.819205
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS("") is True
    assert Exclude.ALWAYS("foo") is True


# Generated at 2022-06-23 16:35:54.379740
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:35:56.245132
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    for field in ["field1", "field2", "field3"]:
        assert Exclude.ALWAYS(field) == True


# Generated at 2022-06-23 16:35:57.749934
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)


# Generated at 2022-06-23 16:36:02.861121
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    
    # Instantiate an instance of _GlobalConfig
    gc = _GlobalConfig()
    
    # Ensure the values in the dictionaries are empty, as expected
    assert gc.mm_fields == {}
    assert gc.encoders == {}
    assert gc.decoders == {}
    
    return
# Test for function config

# Generated at 2022-06-23 16:36:06.138934
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class Simple:
        a: Simple = dataclasses.field(metadata=config(
            undefined=Undefined.EXCLUDE))

        @classmethod
        def from_json(cls, data: dict):
            pass

# Generated at 2022-06-23 16:36:08.514632
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:36:12.529555
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-23 16:36:13.245667
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER

# Generated at 2022-06-23 16:36:14.204688
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("")
    assert not Exclude.NEVER("")

# Generated at 2022-06-23 16:36:17.095410
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:36:18.819006
# Unit test for constructor of class Exclude
def test_Exclude():
    s = Exclude.ALWAYS
    assert callable(s)
    assert s(True)

# Generated at 2022-06-23 16:36:20.839501
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(-1) == True


# Generated at 2022-06-23 16:36:22.521409
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

test_Exclude_ALWAYS()


# Generated at 2022-06-23 16:36:24.548372
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:36:25.700631
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('hello') is True


# Generated at 2022-06-23 16:36:27.202142
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER.__call__("_")
    assert result == False


# Generated at 2022-06-23 16:36:33.699674
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class User:
        name: str
        age: int

        @classmethod
        def from_str(cls, data: str):
            return cls(*data.split())

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class OtherUser:
        name: str
        age: int

    global_config.encoders[User] = lambda user: user.name
    global_config.decoders[User] = User.from_str
    global_config.mm_fields[User] = fields.String()

    global_config.encoders[OtherUser] = lambda user: user.name
    global_config.decoders[OtherUser] = User.from_str
    global_

# Generated at 2022-06-23 16:36:35.686312
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:36:37.797975
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
  assert global_config
  assert isinstance(global_config.encoders, dict)
  assert isinstance(global_config.decoders, dict)
  assert isinstance(global_config.mm_fields, dict)

# Generated at 2022-06-23 16:36:38.515095
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)

# Generated at 2022-06-23 16:36:39.428756
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()

# Generated at 2022-06-23 16:36:41.554028
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-23 16:36:45.840643
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_obj = _GlobalConfig()
    assert global_config_obj.encoders == {}
    assert global_config_obj.decoders == {}
    assert global_config_obj.mm_fields == {}


# Generated at 2022-06-23 16:36:49.288728
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-23 16:36:53.384461
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {}
    global_config.decoders = {}
    global_config.mm_fields = {}
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:36:56.670010
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass(init=True, repr=True, eq=True)
    @config(exclude=Exclude.ALWAYS)
    class Test1:
        field_a: str



# Generated at 2022-06-23 16:36:59.430405
# Unit test for constructor of class Exclude
def test_Exclude():
    instances = []
    for value in Exclude.__dict__.values():
        if isinstance(value, Callable):
            instances.append(value)
    assert len(instances) == 2
    assert Exclude.ALWAYS('whatever')
    assert not Exclude.NEVER('whatever')

# Generated at 2022-06-23 16:37:00.893503
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('')
    assert not Exclude.NEVER('')

# Generated at 2022-06-23 16:37:04.160456
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER(1)
    try:
        Exclude.NEVER(1)
    except Exception as e:
        print(e)
        assert type(e) == TypeError

# Generated at 2022-06-23 16:37:05.554501
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-23 16:37:10.668282
# Unit test for function config
def test_config():
    # Test that config works
    config()

    # Test that config with args works and overrides default
    name = 'foo'
    cfg = config(mm_field=MarshmallowField(), field_name=name)
    assert cfg['dataclasses_json']['mm_field'] is not None
    assert cfg['dataclasses_json']['field_name'] == name

# Generated at 2022-06-23 16:37:15.187266
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert a.encoders == {}

    b = _GlobalConfig()
    b.decoders = {1: 1}
    assert b.decoders == {1: 1}

    c = _GlobalConfig()
    c.mm_fields = {2: 2}
    assert c.mm_fields == {2: 2}



# Generated at 2022-06-23 16:37:16.728895
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(T) == True


# Generated at 2022-06-23 16:37:20.956769
# Unit test for constructor of class Exclude
def test_Exclude():
    # Ensure that the values are set correctly
    assert Exclude.ALWAYS == global_config.encoders
    assert Exclude.NEVER == global_config.decoders
    assert Exclude.ALWAYS == global_config.mm_fields

# Generated at 2022-06-23 16:37:23.893025
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-23 16:37:25.509008
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('item')
    assert not Exclude.NEVER('item')

# Generated at 2022-06-23 16:37:26.726702
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig() is not None



# Generated at 2022-06-23 16:37:36.803029
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    import pdb; pdb.set_trace()
    cfg = _GlobalConfig()
    cfg.encoders['test_case'] = str
    assert cfg.encoders['test_case'] == str
    cfg.decoders['test_case'] = int
    assert cfg.decoders['test_case'] == int
    cfg.mm_fields['test_case'] = 'test_mm_field'
    assert cfg.mm_fields['test_case'] == 'test_mm_field'
    # pdb.set_trace()
    assert type(cfg.encoders['test_case']) == type(str)
    assert type(cfg.decoders['test_case']) == type(int)

# Generated at 2022-06-23 16:37:38.278054
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('Test')


# Generated at 2022-06-23 16:37:39.470808
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:37:46.274823
# Unit test for function config
def test_config():
    from datetime import datetime
    from dataclasses import dataclass

    @dataclass
    class Event:
        name: str
        now: datetime
        guests: Optional[int] = None

        @config(encoder=lambda dt: dt.isoformat(),
                decoder=lambda s: datetime.fromisoformat(s))
        def now(self):
            return datetime.now()

if __name__ == '__main__':
    test_config()

# Generated at 2022-06-23 16:37:55.919426
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    from marshmallow import fields
    from marshmallow_oneofschema import OneOfSchema

    from dataclasses_json import DataClassJsonMixin

    @dataclasses.dataclass
    class _D(DataClassJsonMixin):
        class Meta:
            exclude = None

        @config()
        class ExcludeField: pass

        @config(exclude=Exclude.ALWAYS)
        class ExcludeField2: pass

        @config()
        class ExcludeField3: pass

        @config(undefined=Undefined.USE_DEFAULTS)
        class UndefinedField: pass

    assert _D()._dc_meta.exclude == None
    assert _D.ExcludeField._dc_meta.exclude == None
    assert _D.ExcludeField2._

# Generated at 2022-06-23 16:38:02.084908
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    # Don't change the test value
    gc.encoders = {"int":12}
    gc.decoders = {"int":12}
    gc.mm_fields = {"int":12}
    assert gc.encoders == {"int":12}
    assert gc.decoders == {"int":12}
    assert gc.mm_fields == {"int":12}
    
test__GlobalConfig()

# Generated at 2022-06-23 16:38:09.582011
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    c.encoders[int] = lambda v : float(v)
    c.decoders[float] = lambda v : int(v)
    c.mm_fields[list] = []
    assert isinstance(c.encoders, dict)
    assert isinstance(c.decoders, dict)
    assert isinstance(c.mm_fields, dict)
    assert c.encoders[int](7) == 7.0
    assert c.decoders[float](7.0) == 7
    assert c.mm_fields[list] == []


# Generated at 2022-06-23 16:38:10.289586
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-23 16:38:12.765758
# Unit test for function config
def test_config():
    @dataclass
    @config(undefined=Undefined.EXCLUDE)
    class Employee:
        name: str



# Generated at 2022-06-23 16:38:14.730640
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:38:24.770785
# Unit test for function config
def test_config():
    from marshmallow import Schema
    from marshmallow.fields import Integer, String

    # We need a real class because type hints do not preserve annotations
    class User:
        def __init__(self, id_: int = None, name: str = None):
            self.id_ = id_
            self.name = name

    @dataclass
    class Data:
        user: User
        unfilled_user: User

    schema = Schema.from_dict(
        config(
            {'user': {
                'mm_field': Integer()}},  # type: ignore
            mm_field=String(),
            field_name='unfilled',
            undefined=Undefined.RAISE,
        )
    )


# Generated at 2022-06-23 16:38:26.071073
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("whatever") == False


# Generated at 2022-06-23 16:38:31.667497
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders['a'] = '1'
    assert global_config.encoders['a'] == '1'
    global_config.decoders['a'] = '2'
    assert global_config.decoders['a'] == '2'
    global_config.mm_fields['a'] = '3'
    assert global_config.mm_fields['a'] == '3'


# Generated at 2022-06-23 16:38:34.170164
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("some_string") == True


# Generated at 2022-06-23 16:38:35.399860
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")


# Generated at 2022-06-23 16:38:41.528634
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2.2)
    assert Exclude.ALWAYS('hello')
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(set())



# Generated at 2022-06-23 16:38:43.050764
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:38:44.695748
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-23 16:38:46.388155
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-23 16:38:47.924858
# Unit test for constructor of class Exclude
def test_Exclude():
    t = Exclude()
    assert t.ALWAYS
    assert t.NEVER

# Generated at 2022-06-23 16:38:51.657998
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders[type] = dict
    global_config.decoders[dict] = type
    global_config.mm_fields[str] = 'Field'
    assert type in global_config.encoders 
    assert dict in global_config.decoders
    assert str in global_config.mm_fields

test__GlobalConfig()


# Generated at 2022-06-23 16:38:57.164059
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    assert config.json_module == json

test__GlobalConfig()

# Generated at 2022-06-23 16:39:01.479700
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(1) is False
    assert isinstance(Exclude.ALWAYS, Callable) is True
    assert isinstance(Exclude.NEVER, Callable) is True

test_Exclude()

# Generated at 2022-06-23 16:39:01.983475
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()

# Generated at 2022-06-23 16:39:03.105393
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(4)
    assert a == False



# Generated at 2022-06-23 16:39:06.329117
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    if Exclude.NEVER("a") != False:
        raise AssertionError("Failure in test_Exclude_NEVER")


# Generated at 2022-06-23 16:39:12.071397
# Unit test for function config
def test_config():
    # Test correct config
    @dataclasses.dataclass
    class C:
        a: str
    c = C('hi')
    assert dataclasses_json.dump(c) == dataclasses_json.dumps(c) == '{"a": "hi"}'
    assert dataclasses_json.load(c, "{\"a\": \"new\"}") == C('new')


# Generated at 2022-06-23 16:39:13.880722
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    never = Exclude.NEVER(1)
    assert never == False


# Generated at 2022-06-23 16:39:15.458275
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")



# Generated at 2022-06-23 16:39:16.722005
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:39:18.166578
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a') == True
    assert Exclude.NEVER('a') == False

# Generated at 2022-06-23 16:39:18.934894
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	pass


# Generated at 2022-06-23 16:39:26.179497
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined

    import sys
    if sys.version_info < (3, 8):
        import dataclasses
    else:
        from dataclasses import dataclass

    def test_decoder(encoded_value):
        return encoded_value

    def test_encoder(decoded_value):
        return decoded_value

    def test_letter_case(value):
        return value.casefold()

    @dataclass
    @config(encoder=test_encoder, decoder=test_decoder,
            mm_field=fields.Int,
            letter_case=test_letter_case,
            field_name='foo',
            exclude=lambda _, __: True,
            )
    class A:
        value: str

   

# Generated at 2022-06-23 16:39:27.308270
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:39:30.250163
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_instance = _GlobalConfig()
    assert isinstance(global_config_instance.encoders, dict)
    assert isinstance(global_config_instance.decoders, dict)
    assert isinstance(global_config_instance.mm_fields, dict)


# Generated at 2022-06-23 16:39:31.643284
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:39:33.380851
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:39:43.460888
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow_dataclass import class_schema
    from marshmallow import fields

    @dataclass
    class Dummy:
        foo: str
        bar: int = 10

    assert Dummy.__dataclass_json__ == {'exclude': None,
                                        'undefined': Undefined.RAISE}

    def to_upper(_field_name):
        return _field_name.upper()

    @dataclass
    @config(
        field_name=to_upper,
        mm_field=fields.Str(attribute='now_foo', allow_none=True),
        exclude=Exclude.NEVER,
        letter_case=to_upper
    )
    class NewDummy:
        now_foo: str
        bar: int = 10

    assert New

# Generated at 2022-06-23 16:39:45.046652
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('_') is False

# Generated at 2022-06-23 16:39:50.648212
# Unit test for function config
def test_config():
    from marshmallow import fields

    import dataclasses
    @dataclasses.dataclass
    @config(mm_field=fields.Float)
    class A(object):
        age: str
    assert A.__dataclass_fields__['age'].type.metadata['dataclasses_json']['mm_field'] is fields.Float

# Generated at 2022-06-23 16:39:53.880949
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-23 16:39:57.425452
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
  gc = _GlobalConfig()
  assert gc.encoders == {}
  assert gc.decoders == {}
  assert gc.mm_fields == {}


# Generated at 2022-06-23 16:40:00.209776
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)
if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-23 16:40:02.472572
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("anything") == True
    assert Exclude.NEVER("anything") == False

# Generated at 2022-06-23 16:40:10.675569
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert Exclude.NEVER(1)

# Unit tests on function config()

# Generated at 2022-06-23 16:40:21.925201
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # TODO: add json module testing
    assert not global_config.encoders, "global_config.encoders should be empty"
    assert not global_config.decoders, "global_config.decoders should be empty"
    assert not global_config.mm_fields, "global_config.mm_fields should be empty"
    
    # TODO: add json module testing

    test_type = type(None)
    global_config.encoders[test_type] = lambda _: None
    assert test_type in global_config.encoders, "global_config.encoders should contain test_type"
    del global_config.encoders[test_type]
    assert test_type not in global_config.encoders, "global_config.encoders should not contain test_type"

   

# Generated at 2022-06-23 16:40:24.026993
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # TODO: unit tests for construction
    global_config_test = _GlobalConfig()
    assert(isinstance(global_config_test, _GlobalConfig))
    return


# Generated at 2022-06-23 16:40:26.119693
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test')


# Generated at 2022-06-23 16:40:27.246679
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:40:28.593232
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True

# Generated at 2022-06-23 16:40:29.735669
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER('')


# Generated at 2022-06-23 16:40:30.776106
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)



# Generated at 2022-06-23 16:40:34.550676
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(Undefined.RAISE) == False
    assert Exclude.NEVER(global_config) == False


# Generated at 2022-06-23 16:40:37.353852
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("s")
    assert not Exclude.NEVER("s")

# Test for constructor of class _GlobalConfig

# Generated at 2022-06-23 16:40:40.275983
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)
    try:
        Exclude.ANYTHING
        assert False
    except AttributeError:
        assert True


# Generated at 2022-06-23 16:40:51.845685
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Test True
    assert Exclude.NEVER("a")
    assert Exclude.NEVER("abc")
    assert Exclude.NEVER("")
    assert Exclude.NEVER("100")
    assert Exclude.NEVER(100)
    assert Exclude.NEVER(100.0)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    # Test False
    assert not Exclude.NEVER(0)
    assert not Exclude.NEVER(0.0)
    assert not Exclude.NEVER("0")
    assert not Exclude.NEVER(None)


# Generated at 2022-06-23 16:41:02.769293
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({'1' : 1})
    assert Exclude.ALWAYS({'1.0' : 1.0})
    assert Exclude.ALWAYS({'0' : 0})
    assert Exclude.ALWAYS({0.0 : 0.0})
    assert Exclude.ALWAYS({'e' : 4})
    assert Exclude.ALWAYS(['e', 2, 3, 'j'])
    assert Exclude.ALWAYS([3, 'j', 'e', 4])
    assert Exclude.ALWAYS([{'e' : 4}])
    assert Exclude.ALWAYS(['e', 2, 3, 'j', {'e' : 4}])


# Generated at 2022-06-23 16:41:13.343417
# Unit test for function config
def test_config():
    import json
    import marshmallow
    import pytest
    from marshmallow import fields
    from marshmallow.exceptions import ValidationError

    @dataclasses.dataclass
    @config(
        encoder=lambda obj: json.dumps(obj, use_decimal=True),
        decoder=json.loads,
        mm_field=fields.Float,
        undefined=Undefined.EXCLUDE,
        exclude=Exclude.ALWAYS,
    )
    class Data:
        pass

    data = Data()
    assert json.dumps(data, use_decimal=True) == '{}'
    assert json.loads('{"a": 1}') == {'a': 1}
    assert isinstance(Data.__fields__['type'].metadata['mm_field'], fields.Float)
    assert Data

# Generated at 2022-06-23 16:41:16.099909
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class Test:pass
    assert Exclude.ALWAYS(Test) is True


# Generated at 2022-06-23 16:41:18.595757
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) is True
    assert Exclude.NEVER(0) is False

# Generated at 2022-06-23 16:41:20.454904
# Unit test for function config
def test_config():
    config(undefined='ignore')
    config(undefined=Undefined.EXCLUDE)
    with pytest.raises(UndefinedParameterError):
        config(undefined='bad')

# Generated at 2022-06-23 16:41:24.064861
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    ret = Exclude.ALWAYS("hello")
    if ret :
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-23 16:41:33.869044
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class TestData:
        a: int = 1
        b: str = 'a'
        c: str = 'b'

    @config(decoder=lambda x: x.upper())
    class TestData2:
        field: str

    @config(encoder=lambda x: x.upper())
    class TestData3:
        field: str

    @config(field_name=lambda x: x.upper())
    class TestData4:
        field: str

    @config(undefined=Undefined.RAISE)
    class TestData5:
        field: str

    assert TestData.__dataclass_json__() is None

# Generated at 2022-06-23 16:41:37.964537
# Unit test for constructor of class Exclude
def test_Exclude():
    print(Exclude.ALWAYS(1))
    print(Exclude.NEVER(2))
    assert Exclude.ALWAYS(1)
    assert Exclude.NEVER(2)
    return



# Generated at 2022-06-23 16:41:41.447860
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude())
    assert(Exclude.ALWAYS(5))
    assert(not Exclude.NEVER(5))
    print("Passed the test of constructor of class Exclude.")


# Generated at 2022-06-23 16:41:43.049158
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:41:52.125173
# Unit test for function config
def test_config():
    '''Unit test for function config'''
    # Sub-functions to just check the config function
    # The actual JSON serialization is tested by the test for
    # the to_mapping function
    @dataclasses.dataclass
    class MyClass:
        field1: str
        field2: str
        field3: str

    # Check the decoder and encoder
    decoder = lambda x: x
    encoder = lambda x: x
    mm_field = None
    letter_case = lambda x: x
    undefined = Undefined.RAISE
    field_name = 'Test Name'
    exclude = lambda field_name, _: field_name == 'field1'

    @dataclasses.dataclass
    class TestClass:
        # Test that it can be passed in
        field1: str = dataclasses

# Generated at 2022-06-23 16:41:59.941640
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin, config
    from marshmallow_dataclass import class_schema

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class Person(DataClassJsonMixin):
        name: str = 'John Doe'
        age: int = None

    s = class_schema(Person)()
    assert s.dump(Person()) == {}



# Generated at 2022-06-23 16:42:07.107512
# Unit test for function config
def test_config():
    # type: () -> None
    letter_case = lambda x: 'ayy lmao'
    assert config(letter_case=letter_case) == {
        'dataclasses_json': {
            'letter_case': letter_case
        }
    }
    assert config(undefined='ignore') == {
        'dataclasses_json': {
            'undefined': Undefined.IGNORE
        }
    }


# Generated at 2022-06-23 16:42:12.199303
# Unit test for function config
def test_config():
    assert config(undefined='ignore') == {'dataclasses_json': {'undefined': Undefined.IGNORE}}
    assert config(undefined='raise') == {'dataclasses_json': {'undefined': Undefined.RAISE}}
    assert config(undefined='use_none') == {'dataclasses_json': {'undefined': Undefined.USE_NONE}}

    # Check that metadata is empty if no keyword arguments are passed
    assert config() == {}

# Generated at 2022-06-23 16:42:24.357539
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from marshmallow import fields
    from marshmallow.validate import Length
    @dataclass
    class MyDataClass:
        a: int
        b: str = field(metadata=config(mm_field=fields.Int(required=True)))
        c: str = field(metadata=config(mm_field=fields.Str(validate=Length(min=5))))
        d: str = field(metadata=config(mm_field=fields.Str(validate=Length(min=8))))

    class MySchema(Schema):
        class Meta:
            unknown = EXCLUDE
            dataclass_module = __name__
            dataclass_name = 'MyDataClass'

    serializer = MySchema()

# Generated at 2022-06-23 16:42:35.592175
# Unit test for function config
def test_config():
    assert config(metadata=None,encoder=str,decoder=str,mm_field=str,field_name=str,undefined=str,letter_case=str,exclude=str) == \
           {'dataclasses_json': {'encoder': str, 'decoder': str, 'mm_field': str, 'field_name': str, 'undefined': str, 'letter_case': str, 'exclude': str}}

# Generated at 2022-06-23 16:42:37.416887
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    assert c.encoders == {}
    assert c.decoders == {}
    assert c.mm_fields == {}
    # assert c._json_module == json


# Generated at 2022-06-23 16:42:48.689724
# Unit test for function config
def test_config():
    import marshmallow
    from marshmallow import fields
    import datetime
    from dataclasses_json.config import config, Undefined

    from dataclasses import dataclass, field

    @config(
        mm_field=fields.Str(
            validate=lambda s: s.startswith('x')),
        letter_case=lambda s: s.upper(),
        undefined=Undefined.EXCLUDE,
        exclude=lambda _, f: f.name == 's')
    @dataclass
    class X:
        d: datetime.date
        s: str

    @config(encoder=lambda s: s + '!')
    @dataclass
    class Y:
        s: str

    # @config(field_name='y')
    # @dataclass
    # class Y1:
   

# Generated at 2022-06-23 16:42:50.580627
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(10)
    assert result == True

# Generated at 2022-06-23 16:42:51.701811
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a=_GlobalConfig()


# Generated at 2022-06-23 16:42:59.515365
# Unit test for function config
def test_config():
    class TestType:
        pass

    def encoder(o: TestType) -> str:
        return 'encoded'

    def decoder(s: str) -> TestType:
        return TestType()

    def mm_field():
        return "MarshmallowField"

    dec_config = config(encoder=encoder, decoder=decoder, mm_field=mm_field,
                        letter_case='lower', undefined='EXCLUDE',
                        field_name='overriding_field_name')

    assert 'encoder' in dec_config['dataclasses_json']
    assert 'decoder' in dec_config['dataclasses_json']
    assert 'mm_field' in dec_config['dataclasses_json']
    assert 'letter_case' in dec_config['dataclasses_json']

# Generated at 2022-06-23 16:43:05.698897
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("-") == False
    assert Exclude.NEVER("--") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("123") == False
    assert Exclude.NEVER("---") == False
    assert Exclude.NEVER("a-b") == False


# Generated at 2022-06-23 16:43:07.034531
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(True)
    assert a == False


# Generated at 2022-06-23 16:43:12.149242
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def my_function(a):
        # Check the loop to make sure that the expected result is reached
        for _ in range(20):
            print(a)
            if (a == 0):
                assert (a == 0)
                return True
            else:
                a -=1
        return False

    test = Exclude.NEVER
    ans = test(0)

    assert (ans == True)
    assert my_function(0) == True


# Generated at 2022-06-23 16:43:14.088507
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)



# Generated at 2022-06-23 16:43:18.912885
# Unit test for constructor of class Exclude
def test_Exclude():
    exp = Exclude()

    assert exp.ALWAYS('test')
    assert not exp.NEVER('test')


global_config = _GlobalConfig()
test_config = config()
test_metadata = {'dataclasses_json':{'encoder':None,
                                     'decoder':None,
                                     'letter_case': None,
                                     'undefined': Undefined.RAISE,
                                     'exclude': Exclude.NEVER}}


# Generated at 2022-06-23 16:43:21.478918
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    assert e.NEVER(1) == False
    assert e.ALWAYS(1) == True


# Generated at 2022-06-23 16:43:22.602628
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True

test_Exclude_ALWAYS()

# Generated at 2022-06-23 16:43:24.152344
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)



# Generated at 2022-06-23 16:43:25.254050
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:43:28.795625
# Unit test for constructor of class Exclude
def test_Exclude():
    try:
        input = {
            "field1": "value1",
            "field2": "value2",
        }
        ret = Exclude()
        ret.get_dict(input)
    except Exception as err:
        print(err)
    finally:
        assert True

# Generated at 2022-06-23 16:43:32.427686
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == dict()
    assert global_config.decoders == dict()
    assert global_config.mm_fields == dict()


# Generated at 2022-06-23 16:43:34.245822
# Unit test for function config
def test_config():
    class A:
        pass
    A.__dataclass_fields__['foo'] = 'bar'
    assert A.__dataclass_fields__['foo'] == 'bar'

# Generated at 2022-06-23 16:43:45.401451
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(0))
    assert(Exclude.ALWAYS(False))
    assert(Exclude.ALWAYS(True))
    assert(Exclude.ALWAYS(1))
    assert(Exclude.ALWAYS(-1))
    assert(Exclude.ALWAYS(''))
    assert(Exclude.ALWAYS('1'))
    assert(Exclude.ALWAYS('0'))
    assert(Exclude.ALWAYS('-1'))
    assert(Exclude.ALWAYS(' '))
    assert(Exclude.ALWAYS('12345'))
    assert(Exclude.ALWAYS('ece'))
    assert(Exclude.ALWAYS(Exclude.ALWAYS))
    assert(Exclude.ALWAYS(Exclude.NEVER))
    assert(Exclude.ALWAYS((0, 1)))
   

# Generated at 2022-06-23 16:43:47.336224
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-23 16:43:58.817725
# Unit test for function config
def test_config():
    import pytest

    from dataclasses import dataclass

    from dataclasses_json.config import config as dcfg

    @dataclass
    class C:
        a: int = dcfg()

    # Test defaults
    assert {'dataclasses_json'} == set(C.a.metadata)

    # Test adding new keys
    @dataclass
    class C:
        a: int = dcfg(encoder=str)

    # Test defaults
    assert {'dataclasses_json', 'encoder'} == set(C.a.metadata)

    # Test adding existing key
    with pytest.raises(ValueError) as e:
        @dataclass
        class C:
            a: int = dcfg(encoder=str, encoder=str)


# Generated at 2022-06-23 16:44:00.231691
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-23 16:44:03.437158
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("x") == True
    assert Exclude.ALWAYS([3.14]) == True


# Generated at 2022-06-23 16:44:05.060485
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2) == True
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:44:06.308853
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == 0


# Generated at 2022-06-23 16:44:09.720001
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('String')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(())


# Generated at 2022-06-23 16:44:15.117490
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert isinstance(global_config_.encoders, dict)
    assert isinstance(global_config_.decoders, dict)
    assert isinstance(global_config_.mm_fields, dict)
    # assert isinstance(global_config_.json_module, json.JSONDecoder)
