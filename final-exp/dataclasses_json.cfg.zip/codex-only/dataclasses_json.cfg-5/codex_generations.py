

# Generated at 2022-06-23 16:34:32.478344
# Unit test for function config
def test_config():
    from marshmallow import Schema, fields
    from dataclasses_json.undefined import Undefined

    # test default metadata
    metadata = config()
    assert len(metadata['dataclasses_json']) == 0

    # test setting undefined parameter
    metadata = config(undefined="exception")
    assert metadata['dataclasses_json']['undefined'] == Undefined.EXCEPTION

    # test setting a custom field
    class EmptyField(fields.Field):
        pass

    metadata = config(mm_field=EmptyField())
    assert isinstance(metadata['dataclasses_json']['mm_field'], EmptyField)

    # test setting an undefined parameter and custom field
    metadata = config(undefined="exception", mm_field=EmptyField())
    assert metadata['dataclasses_json']['undefined'] == Und

# Generated at 2022-06-23 16:34:34.610805
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    # test if encoders/decoders is initialized as a dictionary
    assert isinstance(c.encoders, dict)
    assert isinstance(c.decoders, dict)

# Generated at 2022-06-23 16:34:35.030849
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    pass

# Generated at 2022-06-23 16:34:39.745546
# Unit test for function config
def test_config():
    if not hasattr(test_config, "ncalls"):
        test_config.ncalls = 0
    test_config.ncalls += 1

    @config(decoder=test_config, exclude=lambda f, _: f.name == 'bar')
    @dataclass_json
    @dataclass
    class Foo:
        foo: str
        bar: int

    assert test_config.ncalls > 1
    assert Foo("a", 2) == Foo("a", 2)

# Generated at 2022-06-23 16:34:41.062307
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:34:44.258006
# Unit test for function config
def test_config():
    lib_metadata = config(field_name="test")['dataclasses_json']
    assert lib_metadata['letter_case'].__name__ == 'override'
    assert lib_metadata['field_name'] == 'test'

test_config()

# Generated at 2022-06-23 16:34:53.043053
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(encoder='foo') == {'dataclasses_json': {'encoder': 'foo'}}
    assert config(decoder='foo') == {'dataclasses_json': {'decoder': 'foo'}}
    assert config(mm_field='foo') == {'dataclasses_json': {'mm_field': 'foo'}}
    assert config(field_name='foo') == {'dataclasses_json': {'field_name': 'foo'}}
    assert config(letter_case='foo') == {'dataclasses_json': {'letter_case': 'foo'}}
    valid_actions = list(action.name for action in Undefined)

# Generated at 2022-06-23 16:34:54.719498
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(1) is False

# Generated at 2022-06-23 16:34:59.021420
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # No arguments
    assert Exclude.ALWAYS()

    # With arguments
    assert Exclude.ALWAYS({'dataclasses_json': {'exclude': Exclude.ALWAYS}})



# Generated at 2022-06-23 16:35:10.140391
# Unit test for function config
def test_config():
    # Set default values
    assert config()['dataclasses_json']['encoder'] == None
    assert config()['dataclasses_json']['decoder'] == None
    assert config()['dataclasses_json']['mm_field'] == None
    assert config()['dataclasses_json']['letter_case'] == None
    assert config()['dataclasses_json']['undefined'] == None
    assert config()['dataclasses_json']['exclude'] == None
    # test_config setter
    encoder = lambda x: x
    decoder = lambda x: x
    mm_field = lambda x: x
    letter_case = lambda x: x
    undefined = lambda x: x
    exclude = lambda x: x
    # Set values
    assert config(encoder=encoder)

# Generated at 2022-06-23 16:35:17.503979
# Unit test for function config
def test_config():
    def letter_case(s: str) -> str:
        return s


# Generated at 2022-06-23 16:35:20.458628
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("hello") == True
    assert Exclude.ALWAYS("hello", "world") == True
    assert Exclude.ALWAYS("hello", "world", "!") == True


# Generated at 2022-06-23 16:35:23.222738
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")


# Generated at 2022-06-23 16:35:31.543522
# Unit test for function config
def test_config():
    import inspect
    metadata = {}
    assert inspect.signature(config).return_annotation == dict

    # Get the key but no value
    assert config(metadata=metadata, exclude=Exclude.ALWAYS)['dataclasses_json']['exclude'] == Exclude.ALWAYS

    # Get the key but no value
    assert config(metadata=metadata, undefined=Undefined.REMOVE)['dataclasses_json']['undefined'] == Undefined.REMOVE

    # Get the key but no value
    assert config(metadata=metadata, undefined='remove')['dataclasses_json']['undefined'] == Undefined.REMOVE

    with pytest.raises(UndefinedParameterError):
        config(metadata=metadata, undefined='invalid')

# Generated at 2022-06-23 16:35:42.324026
# Unit test for function config
def test_config():
    from marshmallow.fields import Int
    from marshmallow import Schema
    d = config(mm_field=Int)
    assert 'dataclasses_json' in d

    @dataclass
    class NormalSerializable:
        val: int

    assert 'val' in Schema().dump(NormalSerializable(999)).data

    @dataclass
    class ConfiguredSerializable:
        val: int

        class Config:
            mm_field = Int

    assert 'val' in Schema().dump(ConfiguredSerializable(999)).data

    @dataclass
    class ConfiguredSerializable:
        val: int

        class Config:
            mm_field = Int

    assert 'val' in Schema().dump(ConfiguredSerializable(999)).data

    # test that we can skip the Config class

# Generated at 2022-06-23 16:35:43.713389
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")


# Generated at 2022-06-23 16:35:44.880054
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:35:51.542453
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:35:52.950147
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    d = _GlobalConfig()
    assert(d is not None)


# Generated at 2022-06-23 16:35:55.843812
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestExcludeClass:
        a = 1

    test_Exclude_NEVER_obj = TestExcludeClass()
    assert Exclude.NEVER(test_Exclude_NEVER_obj) == False

# Generated at 2022-06-23 16:36:01.911323
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from inspect import signature

    @dataclass
    class DataClass:
        field: str = field(metadata=config(letter_case=str.upper))
        field2: str = "string"

    assert signature(DataClass).parameters['field'].metadata['dataclasses_json']['letter_case'] == str.upper
    assert signature(DataClass).parameters['field2'].metadata['dataclasses_json'] == {}

# Generated at 2022-06-23 16:36:03.922217
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(Hi(1,2)) is True
    assert Exclude.ALWAYS(Hi(3,4)) is True


# Generated at 2022-06-23 16:36:12.069439
# Unit test for function config
def test_config():
    import dataclasses
    from marshmallow import fields

    @dataclasses.dataclass()
    @config(encoder=lambda x: 'encoded', decoder=lambda x: 'decoded',
            mm_field=fields.Integer(), letter_case=lambda x: 'LOWER',
            undefined=Undefined.RAISE, field_name='A',
            exclude=lambda field_name, val: field_name == 'A' and val == 1)
    class Foo:
        A: int
        B: str

    assert hasattr(Foo, '__dataclasses_json__')
    assert 'encoder' in Foo.__dataclasses_json__
    assert 'decoder' in Foo.__dataclasses_json__
    assert 'mm_field' in Foo.__dataclasses_json__

# Generated at 2022-06-23 16:36:13.988046
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:36:16.922438
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert {} == global_config1.encoders
    assert {} == global_config1.decoders
    assert {} == global_config1.mm_fields

# Generated at 2022-06-23 16:36:19.168479
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_obj = Exclude.ALWAYS(2)
    expected_obj = True
    assert test_obj == expected_obj


# Generated at 2022-06-23 16:36:22.233922
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    input_set = [1,2,3,4,5]
    expected_output = True
    output = Exclude.ALWAYS(input_set)
    assert(output == expected_output)


# Generated at 2022-06-23 16:36:24.708075
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('1') is False
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(1.1) is False


# Generated at 2022-06-23 16:36:26.117712
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(8) == False


# Generated at 2022-06-23 16:36:27.308461
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-23 16:36:32.207631
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    @dataclass
    class ConfigData:
        foo: str = config(metadata=config(field_name='bar'))

    assert ConfigData.__dataclasses_json__.field_name('foo') == 'bar'

# Generated at 2022-06-23 16:36:34.516686
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:36:41.198489
# Unit test for function config
def test_config():
    class A:
        pass

    a = A()
    a.__annotations__ = {'b': str}
    a.b = 'c'

    cnt = 0
    def encoder(obj):
        nonlocal cnt
        cnt += 1
        return {'c': 'd'}

    metadata = config(encoder=encoder)
    metadata = config(metadata=metadata, letter_case=lambda s: s.upper())
    assert str(Field(a, 'b', metadata=metadata, use_dict=True).serialize()) == \
           '{\n    "C": "c"\n}'
    assert cnt == 0

    cnt = 0
    obj = Field(a, 'b', metadata=metadata, use_dict=True).deserialize({'c': 'd'})
    assert c

# Generated at 2022-06-23 16:36:43.096654
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:36:45.299441
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-23 16:36:51.257875
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from typing import Optional
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class User(DataClassJsonMixin):
        name: str
        age: Optional[int] = field(metadata=config(exclude=Exclude.ALWAYS))

    expected = '''{
    "name": "Codi",
    "age": 20
}'''.replace('\n', '')

    u1 = User(name='Codi', age=20)

    assert u1.to_json() == expected

# Generated at 2022-06-23 16:36:54.828125
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field_to_exclude = "description"
    assert Exclude.NEVER(field_to_exclude) == True
    field_to_include = "name"
    assert Exclude.NEVER(field_to_include) == True
    

# Generated at 2022-06-23 16:36:56.056528
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS()
    assert not Exclude.NEVER()

# Generated at 2022-06-23 16:37:03.286485
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json.conversion_utils import type_creator
    from dataclasses_json.undefined import Undefined, UndefinedTypeError

    @dataclass
    class Simple:
        value: str = field(metadata=config(field_name="new_name"))

        def __post_init__(self):
            assert self.value == "test"

    @dataclass
    class LetterCase:
        value: str = field(metadata=config(letter_case=lambda word: word.upper()))

        def __post_init__(self):
            assert self.value == "TEST"

    @dataclass
    class UndefinedException:
        value: str = field(metadata=config(undefined=Undefined.EXCEPTION))


# Generated at 2022-06-23 16:37:04.364286
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("test")


# Generated at 2022-06-23 16:37:06.624087
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    T = TypeVar("T")
    assert Exclude.NEVER(T) == False


# Generated at 2022-06-23 16:37:07.977152
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("anything") is True


# Generated at 2022-06-23 16:37:09.913676
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-23 16:37:10.919224
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config._GlobalConfig()

# Generated at 2022-06-23 16:37:15.092797
# Unit test for function config
def test_config():
    import inspect

    @config()
    class TestClass:
        pass

    assert inspect.signature(TestClass) == inspect.signature(config())

    @config(encoder=list, mm_field=list)
    class TestClass2:
        pass

    assert inspect.signature(TestClass2) == inspect.signature(config())

# Generated at 2022-06-23 16:37:25.244606
# Unit test for function config
def test_config():
    from marshmallow import fields as mm_fields

    # This is not an ideal way to test config(), but it does the job.
    import dataclasses

    @config(letter_case=lambda _: _.upper())
    @dataclasses.dataclass
    class MyClass:
        int_field: int

    assert dataclasses.fields(MyClass)[0].metadata == {'dataclasses_json': {
        'letter_case': lambda _: _.upper()}}

    @config(encoder=int)
    @dataclasses.dataclass
    class MyClass:
        int_field: int

    assert dataclasses.fields(MyClass)[0].metadata == {'dataclasses_json': {
        'encoder': int}}


# Generated at 2022-06-23 16:37:27.608704
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(dataclasses.make_dataclass('A', ['x'])(1))

# Generated at 2022-06-23 16:37:29.625757
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("1") == False
# Test the method Exclude.ALWAYS

# Generated at 2022-06-23 16:37:31.131052
# Unit test for constructor of class Exclude
def test_Exclude():
    a = Exclude.ALWAYS(None)
    assert a == True


# Generated at 2022-06-23 16:37:38.414409
# Unit test for function config
def test_config():
    """
    >>> metadata = {'dataclasses_json': {'exclude': 'you'}}
    >>> print(config(metadata, exclude=lambda x: True))
    {'dataclasses_json': {'exclude': <function test_config.<locals>.<lambda> at 0x11304b950>}}
    >>> print(config(metadata, field_name='you'))
    {'dataclasses_json': {'exclude': <function dataclasses_json.utils.config.<locals>.override at 0x11304b8c0>, 'field_name': 'you'}}
    """

# Generated at 2022-06-23 16:37:48.234903
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    class ExampleSchema(Schema):
        val = fields.Integer(attribute='v')

    @config(
        encoder=lambda x: f'encoded_{x}',
        decoder=lambda x: f'decoded_{x}',
        mm_field=ExampleSchema,
        letter_case=lambda x: x.lower(),
        undefined=Undefined.EXCLUDE,
        field_name='v',
        exclude=Exclude.ALWAYS,
    )
    @dataclass
    class ExampleClass:
        val: int

    class ExampleClass2:
        pass


# Generated at 2022-06-23 16:37:54.806574
# Unit test for constructor of class Exclude
def test_Exclude():
    my_input = "ALWAYS"
    assert Exclude.ALWAYS("foo") == True, "test_Exclude did not work"
    assert Exclude.NEVER("foo") == False, "test_Exclude did not work"
    if my_input == "ALWAYS":
        assert Exclude.ALWAYS("foo") == True, "test_Exclude did not work"
    elif my_input == "NEVER":
        assert Exclude.NEVER("foo") == True, "test_Exclude did not work"


# Generated at 2022-06-23 16:38:05.835635
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class A:
        i: int
        j: str

    v = A(i=1, j="j")

    from dataclasses_json import DataClassJsonMixin

    class DataA(A, DataClassJsonMixin):
        pass

    # test undefined parameter
    DataA.from_dict({"i": "1", "undefined": Undefined.RAISE}, init=False)
    DataA.from_dict({"i": "1", "undefined": Undefined.SKIP}, init=False)
    DataA.from_dict({"i": "1", "undefined": Undefined.INCLUDE}, init=False)


# Generated at 2022-06-23 16:38:07.510585
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude = Exclude()
    assert exclude.NEVER(100) == False
    assert exclude.ALWAYS(200) == True

# Generated at 2022-06-23 16:38:14.612675
# Unit test for function config
def test_config():
    @dataclass
    @config(letter_case=lambda s: s.upper())
    class Letter:
        all_caps: str

    @dataclass
    @config(undefined=Undefined.EXCLUDE)
    class Undef:
        class Meta:
            unknown = Undefined.RAISE

        missing: str

    # @dataclass
    # @config(json_module=ujson)
    # class Mod:
    #     module: str

    assert Letter('hi').all_caps == 'HI'
    assert Letter.Schema().load({'all_caps': 'hi'}).data == Letter('HI')

    assert Undef.Schema().load({'missing': 'default'}).data == Undef('default')

    # assert Mod('ujson').module == 'ujson'
    # assert Mod

# Generated at 2022-06-23 16:38:24.736430
# Unit test for function config
def test_config():
    from dataclasses import make_dataclass
    from marshmallow import fields

    def encoder(obj):
        return "hello"

    def decoder(value, cls):
        return cls(value)

    def letter_case(value):
        return value.lower()

    mm_field = fields.String()

    @config(encoder=encoder,
            decoder=decoder,
            mm_field=mm_field,
            letter_case=letter_case)
    @dataclass
    class Person:
        name: str


# Generated at 2022-06-23 16:38:26.030369
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    x = _GlobalConfig()
    assert x is not None


# Generated at 2022-06-23 16:38:29.206826
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}



# Generated at 2022-06-23 16:38:34.327999
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(3)
    assert not a
    b = Exclude.NEVER(5)
    assert not b
    c = Exclude.NEVER(0)
    assert not c


# Generated at 2022-06-23 16:38:35.353125
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:38:39.523299
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    config = {'dataclasses_json': {'exclude': Exclude.ALWAYS}}
    assert isinstance(config['dataclasses_json']['exclude'], Exclude.ALWAYS.__class__)


# Generated at 2022-06-23 16:38:40.757773
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:38:44.653153
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("any_string_here")
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS({"name": "John", "surname": "Doe"})



# Generated at 2022-06-23 16:38:47.350340
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-23 16:38:48.535978
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-23 16:38:49.920249
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS == 'Always'
    assert Exclude.NEVER == 'Never'


# Generated at 2022-06-23 16:38:52.372490
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	flag = Exclude.NEVER('abc')
	assert flag is False
	

# Generated at 2022-06-23 16:38:59.405236
# Unit test for constructor of class Exclude
def test_Exclude():
    a=Exclude.ALWAYS
    assert a(1)
    assert a(1.0)
    assert a([1,2,3])
    assert a({1,2,3})
    assert a((1,2,3))
    assert a({1:"a", 2:"b", 3:"c"})
    assert a("123")
    assert a(Exception)


# Generated at 2022-06-23 16:39:02.211410
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a=_GlobalConfig()
    assert a.encoders == {}
    assert a.decoders == {}
    assert a.mm_fields == {}


# Generated at 2022-06-23 16:39:03.041363
# Unit test for method NEVER of class Exclude

# Generated at 2022-06-23 16:39:04.544299
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()



# Generated at 2022-06-23 16:39:08.077960
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Check that the value is correct
    assert Exclude.ALWAYS(1) == True

    # Check that the type is correct
    assert type(Exclude.ALWAYS) == types.FunctionType


# Generated at 2022-06-23 16:39:15.748645
# Unit test for function config
def test_config():
    result = config(metadata={"program": "unit test"},
                    encoder="encoder1",
                    decoder="decoder1",
                    mm_field="mm_field1",
                    letter_case="letter_case1",
                    field_name="field_name1",
                    exclude="exclude1",
                    )
    expected = {"program": "unit test",
                "dataclasses_json": {
                    "encoder": "encoder1",
                    "decoder": "decoder1",
                    "mm_field": "mm_field1",
                    "letter_case": "letter_case1",
                    "field_name": "field_name1",
                    "exclude": "exclude1",
                }
                }
    assert result == expected



# Generated at 2022-06-23 16:39:25.601180
# Unit test for function config
def test_config():
    from marshmallow.fields import Integer
    class Test: pass
    class Test2: pass
    assert config(encoder=int, decoder=int, mm_field=Integer()) == \
           {'dataclasses_json':
            {
                'encoder': int,
                'decoder': int,
                'mm_field': Integer()
            }
           }

# Generated at 2022-06-23 16:39:27.380526
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Test method NEVER of class Exclude
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-23 16:39:31.918663
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {int: lambda v: '$' + str(v)}
    assert(global_config.encoders[int](10) == '$10')
    global_config.decoders = {str: lambda v: v[1:]}
    assert(global_config.decoders[str]('$10') == '10')
    global_config.mm_fields = {int: None}
    assert(global_config.mm_fields[int] == None)


# Generated at 2022-06-23 16:39:33.624977
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:39:35.297088
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('Test') == False


# Generated at 2022-06-23 16:39:44.574260
# Unit test for function config
def test_config():
    from marshmallow.fields import Int, String
    from marshmallow.exceptions import ValidationError

    import uuid

    class UUID(MarshmallowField):
        def _validate(self, value):
            try:
                uuid.UUID(value)
            except (TypeError, ValueError) as e:
                raise ValidationError(e)

    @dataclass
    @config(mm_field=UUID(), encoder=lambda v: str(v),
            decoder=lambda v: uuid.UUID(v),
            field_name='uuid',
            exclude=Exclude.ALWAYS
            )
    class Entity:
        uuid: uuid.UUID = field(metadata=config(mm_field=Int()))

# Generated at 2022-06-23 16:39:46.041520
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER("_foo"))

# Generated at 2022-06-23 16:39:53.566812
# Unit test for function config
def test_config():
    """
    Test that calling config with undefined=undefined.EXCLUDE is the same as
    explicitly passing in the `Undefined.EXCLUDE` enum.
    """
    @dataclass_json
    @config(undefined=Undefined.EXCLUDE)
    class Foo:
        x: str
        y: int

    @dataclass_json
    @config(undefined=str(Undefined.EXCLUDE))
    class Foo2:
        x: str
        y: int

    assert Foo.json_schema() == Foo2.json_schema()



# Generated at 2022-06-23 16:39:55.457311
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS
    return "OK"


# Generated at 2022-06-23 16:39:57.962695
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude().ALWAYS == Exclude.ALWAYS
    assert Exclude().NEVER == Exclude.NEVER

# Generated at 2022-06-23 16:40:01.181108
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config, _GlobalConfig)
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}

# Generated at 2022-06-23 16:40:04.957752
# Unit test for function config
def test_config():
    import pytest
    with pytest.raises(UndefinedParameterError):
        config(undefined="something")

    with pytest.raises(UndefinedParameterError):
        config(undefined="")

    assert config(undefined="ignore") == {
        "dataclasses_json": {
            "undefined": Undefined.IGNORE
        }
    }

# Generated at 2022-06-23 16:40:10.893835
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    gc.encoders = {}
    assert gc.encoders == {}
    gc.decoders = {}
    assert gc.decoders == {}
    gc.mm_fields = {}
    assert gc.mm_fields == {}

test__GlobalConfig()


# Generated at 2022-06-23 16:40:12.390503
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:40:14.703562
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS is not None


# Generated at 2022-06-23 16:40:19.767561
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module is json
    # assert global_config.json_module is json


# Generated at 2022-06-23 16:40:20.469496
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    pass

# Generated at 2022-06-23 16:40:25.930005
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    testGlobalConfig = _GlobalConfig()
    assert testGlobalConfig.encoders == {}
    assert testGlobalConfig.decoders == {}
    assert testGlobalConfig.mm_fields == {}


# Generated at 2022-06-23 16:40:30.478721
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER("Hello world!") == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:40:38.444305
# Unit test for constructor of class Exclude
def test_Exclude():
    print("Test - Exclude")
    exclude = Exclude()
    print(exclude)
    print("Exclude.ALWAYS: ", exclude.ALWAYS)
    print("Exclude.NEVER: ", exclude.NEVER)
    assert(exclude.ALWAYS("whatever") == True)
    assert(exclude.NEVER("whatever") == False)


# Generated at 2022-06-23 16:40:39.851663
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1);
    assert not Exclude.NEVER(1);

# Generated at 2022-06-23 16:40:40.751371
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
  global_config = _GlobalConfig()
  pass

# Generated at 2022-06-23 16:40:43.209986
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False



# Generated at 2022-06-23 16:40:45.198318
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert callable(Exclude.ALWAYS)


# Generated at 2022-06-23 16:40:47.677945
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	if not Exclude.ALWAYS("test"):
		raise AssertionError("Exclude.ALWAYS ate something that it wasn't supposed to!")

	if Exclude.ALWAYS(None):
		raise AssertionError("Exclude.ALWAYS gave a non-existent thing!")


# Generated at 2022-06-23 16:40:48.462062
# Unit test for constructor of class Exclude
def test_Exclude():
  assert Exclude().ALWAYS('')
  assert not Exclude().NEVER('')

# Generated at 2022-06-23 16:40:50.497167
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert Exclude.NEVER('x')
	pass


# Generated at 2022-06-23 16:40:53.226595
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)


# Generated at 2022-06-23 16:40:57.100719
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    #Check for when field is excluded
    assert Exclude.NEVER(True) == False
    #Check for when field is not excluded
    assert Exclude.NEVER(False) == False

# Generated at 2022-06-23 16:41:00.667514
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # preparing
    res_true = Exclude.ALWAYS(None)
    expect_true = True

    # actual result
    assert res_true == expect_true


# Generated at 2022-06-23 16:41:09.085083
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    f=Exclude.NEVER
    assert f(True)==False
    assert f(False)==False
    assert f(3)==False
    assert f('aa')==False
    assert f(2.3)==False
    assert f(Exclude)==False
    assert f([1,2,3])==False
test_Exclude_NEVER()


# Generated at 2022-06-23 16:41:09.656558
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:41:10.877649
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True


# Generated at 2022-06-23 16:41:15.736270
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_dict = dict(a=1, b=2, c=3)
    # test result is true or false
    test_result = Exclude.NEVER(test_dict)

    if test_result:
        # print('Method NEVER of class Exclude works correctly')
        test_result = True
    else:
        test_result = False
    # assert test_result == True
    return test_result


# Generated at 2022-06-23 16:41:16.800616
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:41:21.688630
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        i: int
        s: str

        class Meta:
            exclude = Exclude.NEVER

        @classmethod
        def from_dict(cls, d):
            return cls(**d)

    assert 'dataclasses_json' in Foo.__dataclass_metadata__
    assert Foo.__dataclass_metadata__['dataclasses_json']['exclude'] == Exclude.NEVER

# Generated at 2022-06-23 16:41:23.269066
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-23 16:41:26.800523
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    #assert global_config.json_module == json

# Generated at 2022-06-23 16:41:35.328875
# Unit test for function config
def test_config():

    from marshmallow import fields

    @config(exclude=lambda field, obj: True)
    class A:
        def __init__(self):
            self.a = 1
        pass

    assert A.__dataclass_json__['exclude'] == '<lambda>'
    assert A.__dataclass_json__['exclude'](None, None) == True

    @config(mm_field=fields.Integer())
    class B:
        def __init__(self):
            self.a = 1
        pass

    assert B.__dataclass_json__['mm_field'] == 'marshmallow.fields.Integer'
    assert B.__dataclass_json__['mm_field'].__class__.__name__ == 'Integer'


# Generated at 2022-06-23 16:41:42.812714
# Unit test for function config
def test_config():
    import pytest

    from dataclasses import dataclass

    @dataclass
    class Test:
        t1: int = config(mm_field=10)

    with pytest.raises(TypeError) as e:
        Test()

    assert '10' in str(e)

    assert Test.__dataclass_fields__['t1'].metadata['dataclasses_json']['mm_field'] == 10

# Generated at 2022-06-23 16:41:44.455988
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:41:47.351558
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS({}) == True
    assert Exclude.NEVER({}) == False


# Generated at 2022-06-23 16:41:49.204933
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:41:50.790825
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result  = Exclude.NEVER("a")
    assert result == False


# Generated at 2022-06-23 16:41:54.271909
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def func():
        return False
    
    if func == Exclude.NEVER:
        print("pass")
    else:
        print("fail")


# Generated at 2022-06-23 16:41:57.784836
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert not Exclude.ALWAYS(None)
    assert not Exclude.ALWAYS(NotImplemented)


# Generated at 2022-06-23 16:42:06.524458
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()

    c.encoders['a'] = 'aa'
    assert callable(c.encoders.get('a'))

    c.decoders['b'] = 'bb'
    assert callable(c.decoders.get('b'))

    c.mm_fields['c'] = 'cc'
    assert callable(c.mm_fields.get('c'))

    assert not c.encoders.get('d')
    assert not c.decoders.get('d')
    assert not c.mm_fields.get('d')



# Generated at 2022-06-23 16:42:08.290771
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-23 16:42:14.950199
# Unit test for function config
def test_config():

    @config(encoder=lambda x: x + 1)
    @dataclasses.dataclass
    class Foo:
        bar: int

    assert Foo(5).json() == {"bar": 6}

    @config(decoder=lambda value: value + 1)
    @dataclasses.dataclass
    class Bar:
        bar: int

    assert dataclasses.asdict(Bar.schema().load({"bar": 5})) == {"bar": 6}

    @config(mm_field=functools.partial(
        marshmallow.fields.Integer,
        missing=None,
    ))
    @dataclasses.dataclass
    class Baz:
        bar: Optional[int]

    assert Baz.schema().dump(Baz(None)) == {"bar": None}
    assert Baz.schema().load

# Generated at 2022-06-23 16:42:16.759580
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(float('nan'))


# Generated at 2022-06-23 16:42:18.736919
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json



# Generated at 2022-06-23 16:42:21.566639
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    import dataclasses

    @dataclasses.dataclass
    class TestMetadata:
        test: int

    assert Exclude.ALWAYS(TestMetadata)


# Generated at 2022-06-23 16:42:24.913989
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def fact(x):
        if x == 0:
            return 1
        return x * fact(x - 1)
    try:
        fact = Exclude.ALWAYS(fact)
    except:
        assert False
    assert fact(5) == 1



# Generated at 2022-06-23 16:42:29.387027
# Unit test for constructor of class Exclude
def test_Exclude():
    # Test the constant ALWAYS return True
    assert Exclude.ALWAYS(0) == True
    # Test the constant NEVER return False
    assert Exclude.NEVER(0) == False

if __name__ == "__main__":
    test_Exclude()

# Generated at 2022-06-23 16:42:30.981861
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("string") == True


# Generated at 2022-06-23 16:42:39.813959
# Unit test for function config
def test_config():
    class MyClass:
        @classmethod
        def __init_subclass__(cls) -> None:
            cls.a = None

        @staticmethod
        def encoder(value):
            pass

        @staticmethod
        def decoder(value):
            pass

    @dataclass
    class DummySchema(Schema):
        @classmethod
        def _declared_fields(cls):
            return {
                'x': fields.Field()
            }


# Generated at 2022-06-23 16:42:45.379396
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("True")
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(tuple())
    assert Exclude.ALWAYS(list())
    assert Exclude.ALWAYS(dict())


# Generated at 2022-06-23 16:42:46.873024
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("hello") == True
    assert Exclude.NEVER("hello") == False

# Generated at 2022-06-23 16:42:50.668108
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

    assert Exclude.ALWAYS('test')
    assert not Exclude.NEVER('test')


# Generated at 2022-06-23 16:42:52.314713
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("anything")
    assert not Exclude.NEVER("anything")

# Generated at 2022-06-23 16:42:58.350929
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class DummyClass:
        pass
    @dataclass
    class DummyClass2:
        pass

    @config(encoder=DummyClass)
    @dataclass
    class ConfigClass:
        pass

    @config(encoder=DummyClass2)
    @dataclass
    class ConfigClass2:
        pass

    assert global_config.encoders[ConfigClass] == DummyClass
    assert global_config.encoders[ConfigClass2] == DummyClass2

# Generated at 2022-06-23 16:43:09.307853
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow_dataclass
    from marshmallow import fields, validate

    @dataclasses.dataclass
    # Default JSON
    @config(
        encoder = str,
        decoder = int,
        mm_field = fields.Str(),
        letter_case=str.upper,
        undefined=Undefined.RAISE,
        field_name='my_name',
        exclude=Exclude.ALWAYS,
    )
    class Test:
        my_name: int


# Generated at 2022-06-23 16:43:14.428988
# Unit test for function config
def test_config():
    from . import test_utils
    import pytest

    @test_utils.assert_no_logs
    def test_func():
        @dataclass
        @config(exclude=Exclude.ALWAYS)
        class TestClass:
            a: int
            b: str

    with pytest.raises(TypeError):
        test_func()

# Generated at 2022-06-23 16:43:20.953645
# Unit test for function config
def test_config():
    @dataclass
    class Foo:
        x: str
        y: str

    @dataclass
    class Bar:
        x: str
        y: str

    # Test `encoder`
    @attr.s
    class ClassWithEncoder:
        x: str

    def encoder(obj: ClassWithEncoder) -> str:
        return f"ENCODED_{obj.x}"

    json = encoder(ClassWithEncoder(x='hello'))
    # TODO: add test for encoders being added to global config
    assert json == 'ENCODED_hello'

    # Test `decoder`
    @attr.s
    class ClassWithDecoder:
        x: str

    def decoder(obj: str) -> ClassWithDecoder:
        return ClassWithDecoder(x=obj)



# Generated at 2022-06-23 16:43:25.153426
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}
    # assert gc.json_module == json
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-23 16:43:28.411191
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('A')
    assert Exclude.ALWAYS('1')


# Generated at 2022-06-23 16:43:30.891879
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-23 16:43:33.684515
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS("test") == True)
    assert(Exclude.ALWAYS("") == True)
    assert(Exclude.ALWAYS("12") == True)


# Generated at 2022-06-23 16:43:44.687139
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.decoder import gen_decode
    from dataclasses_json.encoder import gen_encode

    @dataclass
    class C:
        x: int

    def f():
        pass

    cdict = config(encoder=f, decoder=f, mm_field=f,
                   letter_case='lower',
                   undefined='raise',
                   field_name='lower',
                   exclude=Exclude.ALWAYS)
    assert cdict['dataclasses_json']['encoder'] == f
    assert cdict['dataclasses_json']['decoder'] == f
    assert cdict['dataclasses_json']['mm_field'] == f

# Generated at 2022-06-23 16:43:47.009068
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:43:52.546850
# Unit test for function config
def test_config():
    from marshmallow import Schema, fields

    class EmptySchema(Schema):
        pass

    assert config(mm_field=fields.Str()) == {
        'dataclasses_json': {'mm_field': fields.Str()}
    }

    assert config(mm_field=EmptySchema()) == {
        'dataclasses_json': {'mm_field': EmptySchema()}
    }

    assert config(exclude=Exclude.NEVER) == {
        'dataclasses_json': {'exclude': Exclude.NEVER}
    }

    assert config(exclude=lambda _: False) == {
        'dataclasses_json': {'exclude': lambda _: False}
    }

# Generated at 2022-06-23 16:43:55.102966
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == dict()
    assert config.decoders == dict()
    assert config.mm_fields == dict()

# Generated at 2022-06-23 16:44:05.991873
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    @dataclasses.dataclass
    class Foo:
        bar: int = dataclasses.field(metadata=config(encoder=int, decoder=float,
                                                     mm_field=marshmallow.fields.Integer(),
                                                     letter_case='lower',
                                                     undefined=Undefined.EXCLUDE,
                                                     field_name='baz',
                                                     exclude=lambda *_: True))


# Generated at 2022-06-23 16:44:09.418837
# Unit test for function config
def test_config():
    assert config(metadata={}) == {'dataclasses_json': {}}
    assert config(metadata={'extra_metadata': 'foo'},
                  encoder=True) == {
        'dataclasses_json': {'encoder': True},
        'extra_metadata': 'foo'}

# Generated at 2022-06-23 16:44:11.169922
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:44:14.433942
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}


test__GlobalConfig()

# Generated at 2022-06-23 16:44:22.777097
# Unit test for function config
def test_config():
    # test for invalid values of undefined
    with pytest.raises(UndefinedParameterError):
        config(undefined="random")

    # test for valid values of undefined
    assert config(undefined='ignore') == {'dataclasses_json': {'undefined': Undefined.IGNORE}}
    assert config(undefined='raises') == {'dataclasses_json': {'undefined': Undefined.RAISES}}
    assert config(undefined='use_none') == {'dataclasses_json': {'undefined': Undefined.USE_NONE}}


# TODO: add tests, maybe?