

# Generated at 2022-06-23 16:34:24.213577
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("toto")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})


# Generated at 2022-06-23 16:34:27.380586
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():

    test = Exclude.ALWAYS(3)
    assert test == True
    print("Pass test_Exclude_ALWAYS")



# Generated at 2022-06-23 16:34:28.630595
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-23 16:34:29.879727
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-23 16:34:33.264598
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS(['test'])


# Generated at 2022-06-23 16:34:38.076734
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(object())
    assert Exclude.NEVER(Exclude.NEVER)
    assert Exclude.NEVER(Exclude.ALWAYS)


# Generated at 2022-06-23 16:34:44.044032
# Unit test for function config
def test_config():
    @config(encoder=lambda o: o.__name__)
    @dataclass
    class Foo:
        bar: int
        baz: str = None

    assert json.dumps(Foo('foo')) == '{"bar": "Foo"}'
    assert json.dumps(Foo('foo', 'baz')) == '{"bar": "Foo", "baz": "baz"}'

# Generated at 2022-06-23 16:34:47.450061
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    @config(exclude=Exclude.NEVER)
    class Data:
        a: str
        b: int

    j = json.dumps(Data("a", 1))
    assert j == '{"a":"a","b":1}'


# Generated at 2022-06-23 16:34:48.638351
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-23 16:34:50.190455
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    assert (result == True)
    

# Generated at 2022-06-23 16:34:51.918569
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()
    Exclude.ALWAYS
    Exclude.NEVER



# Generated at 2022-06-23 16:34:55.326903
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Config :
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
    x = Config()
    assert Exclude.NEVER(x)
    

# Generated at 2022-06-23 16:34:58.510937
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_value_true = True
    result = Exclude.ALWAYS(test_value_true)
    assert result == True


# Generated at 2022-06-23 16:35:00.374935
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS)
    assert Exclude.ALWAYS(10)


# Generated at 2022-06-23 16:35:11.948207
# Unit test for function config
def test_config():
    import pytest
    from inspect import Argument

    config_kwargs = [Argument(arg_name, inspect.Parameter.POSITIONAL_ONLY)
                     for arg_name in ['metadata', 'encoder', 'decoder',
                                      'mm_field', 'letter_case', 'undefined',
                                      'field_name', 'exclude']]

    from dataclasses import dataclass


    @dataclass
    class Person:
        name: str

    @dataclass
    class PersonWithMetadata:
        name: str = config(field_name='foo',
                           letter_case='lower',
                           undefined='EXCLUDE',
                           exclude=lambda *_: False)

    @dataclass
    class PersonWithInvalidUndefined:
        name: str = config(undefined='foo')

   

# Generated at 2022-06-23 16:35:13.314377
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(32) == True
    assert Exclude.NEVER(32) == False

# Generated at 2022-06-23 16:35:17.822942
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(4) == True

    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(4) == False



# Generated at 2022-06-23 16:35:21.252280
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {int : 'int'}
    assert global_config.encoders[int] == 'int'
    # TODO:
    # assert global_config.json_module == json
    # _GlobalConfig.json_module = 'json'
    # assert global_config.json_module == 'json'


# Generated at 2022-06-23 16:35:23.753967
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(5) is True
    assert Exclude.NEVER(5) is False



# Generated at 2022-06-23 16:35:26.991413
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # make sure the initial dataclasses_json is empty
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0

    assert Exclude.ALWAYS is global_config.encoders
    assert Exclude.ALWAYS is global_config.decoders
    assert Exclude.ALWAYS is global_config.mm_fields


# Generated at 2022-06-23 16:35:31.011144
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(-2) == False
    assert Exclude.NEVER(-3) == False
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:35:34.351212
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(1000)
    assert Exclude.NEVER(-1)


# Generated at 2022-06-23 16:35:44.200888
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from marshmallow import Schema
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class ClassToTest(DataClassJsonMixin):
        a: int
        b: str = field(metadata=config(exclude=Exclude.NEVER))
        c: str = field(metadata=config(exclude=Exclude.NEVER))
        d: str = field(metadata=config(exclude=Exclude.NEVER))
        e: str = field(metadata=config(exclude=Exclude.NEVER))
        f: str = field(metadata=config(exclude=Exclude.NEVER))

    x = ClassToTest(a=1, b='a', c='b', d='c', e='d', f='e')
    print

# Generated at 2022-06-23 16:35:45.693770
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("A") == False


# Generated at 2022-06-23 16:35:54.156559
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow.fields import Field as MarshmallowField


    @dataclass
    @config(encoder=list, decoder=list, mm_field=fields.Nested(fields.Str()))
    class MyDc:
        pass

    assert global_config.encoders[MyDc] == list
    assert global_config.decoders[MyDc] == list
    assert isinstance(global_config.mm_fields[MyDc], MarshmallowField)



# Generated at 2022-06-23 16:35:56.705504
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("test_Exclude_NEVER")
    val = Exclude.NEVER('test')
    assert(val == False)

if __name__ == "__main__":
    test_Exclude_NEVER()

# Generated at 2022-06-23 16:35:58.464950
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)
    assert not callable(Exclude())

# Generated at 2022-06-23 16:36:03.039110
# Unit test for constructor of class Exclude
def test_Exclude():
    try:
        Exclude.ALWAYS(1)
    except TypeError:
        raise TypeError("Constructor: Exclude-ALWAYS")

    try:
        Exclude.NEVER(1)
    except TypeError:
        raise TypeError("Constructor: Exclude-NEVER")

# Generated at 2022-06-23 16:36:08.452040
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER(1) == False 
    assert Exclude.ALWAYS(1) == True 
    # Check if undefined is handled properly
    assert Exclude.NEVER(Undefined) == False 
    assert Exclude.ALWAYS(Undefined) == True 
    # Check if custom classes are handled properly
    class CustomClass:
        def __init__(self):
            pass
    assert Exclude.NEVER(CustomClass()) == False 
    assert Exclude.ALWAYS(CustomClass()) == True

# Generated at 2022-06-23 16:36:10.418569
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('mock_data') == False
test_Exclude_NEVER()


# Generated at 2022-06-23 16:36:13.734296
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import marshmallow
    m = marshmallow.Schema
    @dataclass
    class Foo:
        @config(letter_case=lambda x: x)
        def bar(self):
            pass
    return Foo

# Generated at 2022-06-23 16:36:19.309512
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    from dataclasses_json import config
    @dataclass
    class Point:
        x: float
        y: float
        z: float = config(exclude=Exclude.NEVER)

    p = Point(1, 2)
    assert p.z is None
    assert Point.__dataclass_fields__['z'].default_factory() is None
    assert Point.__dataclass_fields__['z'].default_factory() == p.z


# Generated at 2022-06-23 16:36:23.729088
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    '''
    Test method of Exclude class
    :param None
    :return:
    '''
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER("-1") == False
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-23 16:36:30.153225
# Unit test for function config
def test_config():
    config(None, encoder=str)
    config(None, decoder=str)
    config(None, mm_field=str)
    config(None, letter_case=str)
    config(None, undefined='RAISE')
    config(None, exclude=Exclude.NEVER)
    try:
        config(None, undefined='not_a_valid_undefined_parameter')
        assert False, "expected an exception"
    except UndefinedParameterError as e:
        assert str(e) == (
            "Invalid undefined parameter action, "
            "must be one of ['RAISE', 'USE_DEFAULTS', 'EXCLUDE']"
        )

# Generated at 2022-06-23 16:36:32.073040
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:36:41.673273
# Unit test for function config
def test_config():
    # Set up requirements.
    TestConverter = Callable[[T],T]
    TestExcluder = Callable[[T], bool]

    # Test default values
    assert config() == dict(dataclasses_json=dict())

    # Test all available parameters and the dict output.

# Generated at 2022-06-23 16:36:48.128198
# Unit test for function config
def test_config():
    import dataclasses

    @config(encoder=lambda x: x+1, decoder=lambda x: x-1)
    @dataclasses.dataclass
    class Data:
        value: int

    data = Data(0)

    assert dataclasses_json.dumps(data, default=global_config.encoders) == '1'
    assert dataclasses_json.loads('2', object_hook=global_config.decoders) == Data(1)

# Generated at 2022-06-23 16:36:57.369908
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(field_name=None) == {'dataclasses_json': {'field_name': None}}
    assert config(undefined='Raise') == {'dataclasses_json': {'undefined': Undefined.RAISE}}
    assert config(undefined='Raise', field_name=None, exclude=None) == {'dataclasses_json': {'undefined': Undefined.RAISE, 'field_name': None, 'exclude': None}}
    assert config(undefined='Raise', field_name=None, exclude=Exclude.ALWAYS) == {'dataclasses_json': {'undefined': Undefined.RAISE, 'field_name': None, 'exclude': Exclude.ALWAYS}}

# Generated at 2022-06-23 16:37:01.543590
# Unit test for function config
def test_config():
    assert config(metadata={'a': 1},
                  encoder=str,
                  field_name='Test_Name',
                  undefined=Undefined.EXCLUDE,
                  exclude=Exclude.ALWAYS) == {
        'a': 1,
        'dataclasses_json': {
            'encoder': str,
            'field_name': 'Test_Name',
            'undefined': Undefined.EXCLUDE,
            'exclude': Exclude.ALWAYS,
        }
    }

# Generated at 2022-06-23 16:37:03.344496
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') is True


# Generated at 2022-06-23 16:37:05.149496
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(True)
    assert result == True



# Generated at 2022-06-23 16:37:06.626559
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(42) == False


# Generated at 2022-06-23 16:37:12.225375
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
	global_config = _GlobalConfig()
	assert global_config.encoders == {}
	assert global_config.decoders == {}
	assert global_config.mm_fields == {}

if __name__ == "__main__":
    test__GlobalConfig()

# Generated at 2022-06-23 16:37:13.256446
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)


# Generated at 2022-06-23 16:37:24.679766
# Unit test for function config
def test_config():
    user = NewType('user', str)
    e1 = lambda user: {"name": user.name, "email": user.email}
    d1 = lambda data: User(**data)
    e2 = lambda user: (user.name, user.email)
    d2 = lambda data: User(*data)

    @dataclass
    @config(
        encoder=e1,
        decoder=d1,
    )
    class User1:
        name: str
        email: str

    assert User1.__dataclass_json__['encoder'] == e1
    assert User1.__dataclass_json__['decoder'] == d1

    @dataclass
    @config(
        encoder=e2,
        decoder=d2,
    )
    class User2:
        name

# Generated at 2022-06-23 16:37:27.710536
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    f = Exclude.ALWAYS
    assert f(1)
    assert f('Ivo')
    assert f(True)
    assert f(False)


# Generated at 2022-06-23 16:37:29.713591
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2) == True
    assert Exclude.NEVER(2) == False



# Generated at 2022-06-23 16:37:32.650757
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}

# Generated at 2022-06-23 16:37:40.175699
# Unit test for function config
def test_config():
    import pytest
    from dataclasses_json import dataclass

    @dataclass
    class A:
        v: int = config(mm_field=MarshmallowField())
        _v: int = config(mm_field=MarshmallowField())  # noqa: WPS125

    assert A.v.metadata['dataclasses_json']['mm_field'].__class__ is MarshmallowField

    @dataclass
    class A:
        v: int = config(mm_field=MarshmallowField())
        _v: int = config(mm_field=MarshmallowField())  # noqa: WPS125
        # Field name clash
        v_: int = config(field_name='v')

    assert A.v.metadata['dataclasses_json']['mm_field'].__class__ is MarshmallowField

# Generated at 2022-06-23 16:37:49.372256
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        code: str
        name: str = config(field_name='full_name') # type: ignore

    assert MyClass.__dataclass_fields__['name'].metadata == {
        'dataclasses_json': {'field_name': 'full_name'}
    }

    # Test for str constant for undefined
    @dataclass
    class MyClass2:
        code: str
        name: str = config(undefined='RAISE') # type: ignore

    # Test for Undefined constant for undefined
    @dataclass
    class MyClass3:
        code: str
        name: str = config(undefined=Undefined.RAISE) # type: ignore

    # Test for invalid undefined value

# Generated at 2022-06-23 16:37:52.963390
# Unit test for function config
def test_config():
    metadata = config(encoder='a', decoder='b', mm_field='c')
    assert metadata['dataclasses_json']['encoder'] == 'a'
    assert metadata['dataclasses_json']['decoder'] == 'b'
    assert metadata['dataclasses_json']['mm_field'] == 'c'

# Generated at 2022-06-23 16:37:53.848327
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config


# Generated at 2022-06-23 16:37:57.406007
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj=_GlobalConfig()
    assert obj.encoders =={}
    assert obj.decoders =={}
    assert obj.mm_fields =={}
    

# Generated at 2022-06-23 16:37:58.864886
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('foo') == False


# Generated at 2022-06-23 16:38:00.631172
# Unit test for constructor of class Exclude
def test_Exclude():
    obj = Exclude()
    assert obj.ALWAYS
    assert not obj.NEVER

# Generated at 2022-06-23 16:38:04.315547
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1.encoders == {}
    assert global_config1.decoders == {}
    assert global_config1.mm_fields == {}
    # assert global_config1.json_module == json


# Generated at 2022-06-23 16:38:05.932627
# Unit test for constructor of class Exclude
def test_Exclude():
    x = Exclude()
    assert isinstance(x, Exclude)

# Generated at 2022-06-23 16:38:16.836058
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class TestClass1:
        field1: int

    @dataclass
    class TestClass2:
        field1: int

        class Config:
            encoder = int
            decoder = int
            mm_field = int
            letter_case = lambda self: self
            undefined = Undefined.RAISE
            exclude = Exclude.NEVER

    test_obj1 = TestClass1(1)
    test_obj2 = TestClass2(1)

    assert config(test_obj1.__dataclass_fields__['field1']['metadata']) is test_obj1.__dataclass_fields__['field1']['metadata']

# Generated at 2022-06-23 16:38:17.970161
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-23 16:38:20.712890
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(2)
    assert result == True
    print("Test PASSED: Exclude.ALWAYS(2) == True")

# Generated at 2022-06-23 16:38:23.942550
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)

# Generated at 2022-06-23 16:38:25.199614
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:38:27.265422
# Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-23 16:38:29.841149
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS("hello")
    assert Exclude.ALWAYS({'key': 1})


# Generated at 2022-06-23 16:38:33.038631
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-23 16:38:35.125251
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert not global_config.encoders
    assert not global_config.decoders
    assert not global_config.mm_fields

# Generated at 2022-06-23 16:38:46.074186
# Unit test for function config
def test_config():
    @dataclass
    class Test:
        a: str
        b: int = field(metadata=config(encoder=lambda o: o.encode('utf-8')))
        # Test to make sure default value is used
        c: int = 2
        d: int = field(metadata=config(letter_case=lambda s: s.upper()))
        e: int = field(metadata=config(exclude=lambda s, _: True))
        # Test to make sure the higher config takes priority
        f: int = field(metadata=config(exclude=lambda s, _: False))
        g: int = field(metadata=config(field_name='g_override'))


# Generated at 2022-06-23 16:38:47.310853
# Unit test for function config
def test_config():
    # This should not raise an UndefinedParameterError
    config(undefined="ignore")

# Generated at 2022-06-23 16:38:48.494276
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1), False


# Generated at 2022-06-23 16:38:58.708811
# Unit test for function config
def test_config():
    from datetime import date
    from marshmallow import fields, Schema

    from dataclasses import dataclass, field

    from dataclasses_json import DataClassJsonMixin, config
    from dataclasses_json.api import load, dump, load_schema, Schema

    @dataclass
    class Person(DataClassJsonMixin):
        name: str
        age: int = field(
            metadata = config(
                mm_field = fields.Integer(validate=lambda n: 18 <= n <= 99),
                encoder = lambda v: v.year,
                decoder = date.fromisoformat,
                undefined = 'EXCLUDE',
                exclude = Exclude.ALWAYS
            )
        )

# Generated at 2022-06-23 16:39:08.218781
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import marshmallow
    from nose.tools import assert_raises

    @dataclass
    class MyClass:
        @classmethod
        def encoder(cls, obj):
            return {'foo': 'bar'}

        @classmethod
        def decoder(cls, dct):
            return MyClass()

        foo: str

    # Check encoder
    @dataclass
    class NormalCase:
        foo: str = config(encoder=MyClass.encoder)

    assert 'dataclasses_json' in NormalCase.foo.metadata
    assert 'encoder' in NormalCase.foo.metadata['dataclasses_json']
    assert NormalCase.foo.metadata['dataclasses_json']['encoder'] == MyClass.encoder

    # Check decoder


# Generated at 2022-06-23 16:39:13.283694
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    # NOTE: the metadata is stored in the class object
    @dataclass
    @config(metadata={'exclude': True})
    class User:
        id: str
        email: str
        password: str
    
    print(User.__dataclass_fields__)
    print(User.__dataclass_params__['metadata'])

if __name__ == "__main__":
    test_config()

# Generated at 2022-06-23 16:39:20.963314
# Unit test for function config
def test_config():
    assert config().get('dataclasses_json') is None

    assert config(mm_field=None) == {
        'dataclasses_json': {'mm_field': None},
    }

    assert config(field_name='a') == {
        'dataclasses_json': {'letter_case': lambda _: 'a'},
    }


# Generated at 2022-06-23 16:39:29.833482
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow.fields

    @dataclasses.dataclass
    class Foo:
        bar: int

        class Meta:
            unknown = marshmallow.EXCLUDE
            included = marshmallow.INCLUDE

        # dataclasses_json configuration
        dataclasses_json = config(
            field_name='class_name',
            exclude=lambda f, _: f == 'class_name',
            mm_field=marshmallow.fields.Str(),
        )

    assert Foo.bar.metadata == {'dataclasses_json': {'field_name': 'bar'}}
    assert Foo.bar.name == 'bar'

# Generated at 2022-06-23 16:39:30.405821
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()

# Generated at 2022-06-23 16:39:35.600152
# Unit test for constructor of class _GlobalConfig

# Generated at 2022-06-23 16:39:37.004622
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)



# Generated at 2022-06-23 16:39:39.468338
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(Exclude.NEVER))
    assert(not Exclude.NEVER(Exclude.ALWAYS))


# Generated at 2022-06-23 16:39:49.857316
# Unit test for constructor of class Exclude
def test_Exclude():
    # test always
    assert(Exclude.ALWAYS('whatever') == True)
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.ALWAYS(0) == True)
    assert(Exclude.ALWAYS(None) == True)

    # test never
    assert(Exclude.NEVER('whatever') == False)
    assert(Exclude.NEVER(1) == False)
    assert(Exclude.NEVER(0) == False)
    assert(Exclude.NEVER(None) == False)



# Generated at 2022-06-23 16:39:54.292227
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_init = _GlobalConfig()
    assert isinstance(global_init,_GlobalConfig)

# test for config function

# Generated at 2022-06-23 16:40:04.075505
# Unit test for function config
def test_config():
    import marshmallow as mm
    @config(encoder='encode_some_way', decoder='decode_some_way',
            mm_field=mm.fields.String(), letter_case='snake_case',
            undefined='RAISE', exclude=Exclude.ALWAYS)
    class TestClass:
        pass

    assert TestClass.__dataclass_fields__['dataclasses_json'] == {
        'encoder': 'encode_some_way',
        'decoder': 'decode_some_way',
        'mm_field': mm.fields.String(),
        'letter_case': 'snake_case',
        'undefined': Undefined.RAISE,
        'exclude': Exclude.ALWAYS
    }

# Generated at 2022-06-23 16:40:08.674528
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:40:11.593559
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS()
    assert not Exclude.NEVER()

# Generated at 2022-06-23 16:40:13.871406
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)



# Generated at 2022-06-23 16:40:17.805076
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-23 16:40:19.353834
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-23 16:40:24.496097
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import pytest

    @dataclass
    class Container:
        """Demonstrate `config` function"""
        name: str

# Generated at 2022-06-23 16:40:31.281081
# Unit test for function config
def test_config():
    from marshmallow import fields
    import dataclasses
    import datetime
    from dataclasses_json.codec import DatetimeCodec

    @config(encoder=DatetimeCodec.encode)
    @dataclasses.dataclass
    class TestConfig(object):
        timestamp: datetime.datetime

    assert TestConfig.Schema().fields['timestamp'] == fields.DateTime()

# Generated at 2022-06-23 16:40:34.277226
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test = _GlobalConfig()

    assert isinstance(test.encoders, dict)
    assert isinstance(test.decoders, dict)
    assert isinstance(test.mm_fields, dict)
    # assert isinstance(test.json_module, object)



# Generated at 2022-06-23 16:40:35.741796
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("")
    assert not Exclude.NEVER("")

# Generated at 2022-06-23 16:40:41.576494
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS), "Exclude.ALWAYS is a function"
    assert callable(Exclude.NEVER), "Exclude.NEVER is a function"
    assert Exclude.ALWAYS(1), "Exclude.ALWAYS(1) is true"
    assert not Exclude.NEVER(1), "Exclude.NEVER(1) is false"
    print("Exclude constructor OK")


# Generated at 2022-06-23 16:40:44.569574
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def func():
        return False
    assert Exclude.NEVER == func
    

# Generated at 2022-06-23 16:40:45.784630
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-23 16:40:46.709499
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("abc")



# Generated at 2022-06-23 16:40:55.767582
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(encoder=1) == {'dataclasses_json': {
                                 'encoder': 1}}
    assert config(decoder=1) == {'dataclasses_json': {
                                 'decoder': 1}}
    assert config(mm_field=1) == {'dataclasses_json': {
                                  'mm_field': 1}}
    assert config(letter_case=1) == {'dataclasses_json': {
                                     'letter_case': 1}}
    assert isinstance(
        config(undefined='ignore')['dataclasses_json']['undefined'], Undefined)

# Generated at 2022-06-23 16:41:00.663561
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config1 = _GlobalConfig()
    config1.encoders = "encoders"
    config1.decoders = "decoders"
    config1.mm_fields = "mm_fields"
    assert config1.encoders == "encoders"
    assert config1.decoders == "decoders"
    assert config1.mm_fields == "mm_fields"


# Generated at 2022-06-23 16:41:12.976479
# Unit test for function config
def test_config():
    from marshmallow.fields import Field as MarshmallowField
    from marshmallow.fields import List as MarshmallowList
    from typing import List

    @dataclass
    @config(field_name='test')
    class A:
        test: List

    assert A.__dataclass_fields__['test'].metadata['dataclasses_json']['field_name'] == 'test'
    assert A.__dataclass_fields__['test'].metadata['dataclasses_json']['mm_field'] == MarshmallowList

    @dataclass
    @config(encoder=str)
    class B:
        test: List

    assert A.__dataclass_fields__['test'].metadata['dataclasses_json']['encoder'] == str


# Generated at 2022-06-23 16:41:17.011160
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert all(k in global_config1.__dict__ for k in ['encoders', 'decoders', 'mm_fields'])

# Generated at 2022-06-23 16:41:25.231741
# Unit test for function config
def test_config():
    from dataclasses import field
    from functools import partial

    # Test letter case config
    @config(letter_case=str.lower)
    @dataclass
    class Test:
        A_Field: str = field()
        b_Field: str = field()
        c_Field: str = field()

    assert Test.__json_metadata__['dataclasses_json']['letter_case'] == str.lower
    assert Test.__annotations__['A_Field'] == 'a_field'
    assert Test.__annotations__['b_Field'] == 'b_field'
    assert Test.__annotations__['c_Field'] == 'c_field'

    # Test letter case config with field override

# Generated at 2022-06-23 16:41:26.890442
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-23 16:41:28.138469
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:41:32.673988
# Unit test for function config
def test_config():
    config(encoder=1)
    config(decoder=1)
    config(mm_field=1)
    config(letter_case=1)
    config(undefined=1)
    config(letter_case=lambda _: _, field_name="foo")
    config(exclude=Exclude.ALWAYS)

# Generated at 2022-06-23 16:41:36.836123
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    names = ['Ben', 'Dan', 'Tom']
    assert Exclude.NEVER('Ben')
    assert Exclude.NEVER('Dan')
    assert Exclude.NEVER('Tom')
    assert Exclude.NEVER('Abdulai')


# Generated at 2022-06-23 16:41:39.908817
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Foo:
        pass
    f = Foo()
    assert Exclude.NEVER(f)
    assert not Exclude.ALWAYS(f)


# Generated at 2022-06-23 16:41:43.462487
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    case_one = Exclude.ALWAYS(1)
    assert case_one == True
    case_two = Exclude.ALWAYS('hoge')
    assert case_two == True


# Generated at 2022-06-23 16:41:44.688983
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:41:48.421037
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config,_GlobalConfig), "global_config is not an instance of _GlobalConfig"

if __name__ == '__main__':
    test__GlobalConfig()
    print('Testing Completed!')

# Generated at 2022-06-23 16:41:58.060373
# Unit test for function config
def test_config():
    from datetime import datetime
    from marshmallow import fields
    from dataclasses import dataclass, field

    @dataclass
    @config(mm_field=fields.DateTime())
    class TestDate:
        now: datetime = field(metadata={'dataclasses_json': {
            'mm_field': fields.DateTime()
        }})

    assert TestDate._field_type_info[0].metadata['dataclasses_json']['mm_field']

    @dataclass
    @config(mm_field=fields.DateTime())
    class TestDate:
        now: datetime


# Generated at 2022-06-23 16:42:00.283333
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('hello') == True
    assert Exclude.NEVER('hello') == False

# Generated at 2022-06-23 16:42:10.575335
# Unit test for constructor of class Exclude
def test_Exclude():
    from marshmallow.fields import Field
    from marshmallow.utils import is_collection
    from tests.test_dict import TestDict
    from tests.test_optional import TestOptional
    from tests.test_list import TestList

    @config(mm_field=Field())
    class TestEx:
        x: int
    s = TestEx(x=1)
    assert getattr(s, "x") == 1
    assert getattr(Exclude, "ALWAYS")(TestEx(x=1)) is True
    assert getattr(Exclude, "NEVER")(TestEx(x=1)) is False

    @config(mm_field=Field())
    class TestEx1:
        a: int
        b: int
    s = TestEx1(a=1, b=2)

# Generated at 2022-06-23 16:42:12.146647
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    try:
        config()
    except UndefinedParameterError:
        assert False

# Generated at 2022-06-23 16:42:17.460074
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER([])
    assert Exclude.NEVER('')
    assert Exclude.NEVER(())
    assert Exclude.NEVER({})


# Generated at 2022-06-23 16:42:20.489404
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-23 16:42:28.033851
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from unittest import TestCase

    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.undefined import Undefined

    class Schema(DataClassJsonMixin):
        __metadata__ = config(
            letter_case=lambda value: value.upper(),
            field_name=lambda field_name: f"_{field_name}"
        )
        __encoders__ = config(encoder=lambda value: int(value))
        __decoders__ = config(decoder=lambda value: float(value))
        __mm_fields__ = config(mm_field=fields.Int(required=True))
        __undefined__ = config(undefined=Undefined.RAISE)

# Generated at 2022-06-23 16:42:30.013508
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class A:
        pass
    assert Exclude.NEVER(A()) != True


# Generated at 2022-06-23 16:42:31.588253
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(42) is True


# Generated at 2022-06-23 16:42:33.861964
# Unit test for function config
def test_config():
    # Check that undefined parameter raises error when it is invalid
    with raises(UndefinedParameterError):
        assert config(undefined='not_valid')

# Generated at 2022-06-23 16:42:35.187837
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a')
    assert not Exclude.NEVER('a')

# Generated at 2022-06-23 16:42:42.025393
# Unit test for function config
def test_config():
    from marshmallow import fields as mm_fields
    from dataclasses_json.api import config
    from dataclasses_json.undefined import Undefined

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class ExcludeAlways:
        a_int: int = 1
        b_int: int = 2

    @config(
        encoder=lambda obj, metadata: obj.__dict__,
        decoder=lambda dct, metadata: ExcludeAlways(**dct),
        exclude=Exclude.NEVER,
    )
    @dataclass
    class ExcludeNever:
        a_int: int = 1
        b_int: int = 2


# Generated at 2022-06-23 16:42:44.424781
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def test1(t):
        return False
    assert Exclude.NEVER == test1


# Generated at 2022-06-23 16:42:56.832850
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import marshmallow as mm

    # https://github.com/agronholm/dataclasses-json/issues/175

    @dataclass
    @config(exclude=lambda _, m: m == '_')
    class User:
        username: str
        password: str


# Generated at 2022-06-23 16:42:58.887296
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(True)
    assert result == True


# Generated at 2022-06-23 16:43:09.471263
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass(config=config(encoder=int, decoder=float, mm_field=fields.Bool,
                             letter_case=str.lower, undefined=Undefined.RAISE,
                             exclude=Exclude.ALWAYS))
    class A:
        pass

    class B:
        pass

    assert global_config.encoders[A] is int
    assert global_config.decoders[A] is float
    assert global_config.mm_fields[A] is fields.Bool
    assert B.__dataclasses_json__.letter_case('a') == 'a'
    assert B.__dataclasses_json__.undefined == Undefined.RAISE
    assert B.__dataclasses_json__.exclude

# Generated at 2022-06-23 16:43:11.874989
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:43:20.021647
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(-1) == True
    assert Exclude.ALWAYS(-2) == True
    assert Exclude.ALWAYS(1.5) == True
    assert Exclude.ALWAYS(0.5) == True
    assert Exclude.ALWAYS(-1.5) == True
    assert Exclude.ALWAYS(-0.5) == True
    assert Exclude.ALWAYS(-0) == True
    assert Exclude.ALWAYS(Undefined) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS('a') == True

# Generated at 2022-06-23 16:43:23.110841
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders={}
    global_config.decoders={}
    global_config.mm_fields={}
    assert global_config.encoders=={}
    assert global_config.decoders=={}
    assert global_config.mm_fields=={}
    return



# Generated at 2022-06-23 16:43:25.740432
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True

# Generated at 2022-06-23 16:43:34.019611
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    @dataclass
    class Test:
        x: int
        y: int
        z: int
        xy: int = 22
        yz: int = 33
    t=Test(1,2,3)
    t.z=4
    d={'z':4}
    assert t.x==1
    assert t.y==2
    assert t.z==4
    assert t.xy==22
    assert t.yz==33
    assert d['z']==4
    assert t==d
    assert Exclude.NEVER(t)

# Generated at 2022-06-23 16:43:37.554514
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(None)

# Generated at 2022-06-23 16:43:39.492090
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (Exclude.ALWAYS(1) == True)
    assert (Exclude.NEVER(1) == False)

# Generated at 2022-06-23 16:43:42.104742
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}


# Generated at 2022-06-23 16:43:45.457869
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(0.2) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:43:56.458829
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        a: int = 42
        b: str = 'test'

    class TestDecoder:
        pass

    class TestEncoder:
        pass

    class TestMmField(MarshmallowField):
        pass

    assert TestClass.__dataclass_fields__['a'].metadata == {}
    assert TestClass.__dataclass_fields__['b'].metadata == {}

    @config(encoder=TestEncoder, decoder=TestDecoder, mm_field=TestMmField)
    @dataclass
    class TestClass2:
        a: int = 42
        b: str = 'test'


# Generated at 2022-06-23 16:43:58.817248
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a')
    assert not Exclude.NEVER(123)



# Generated at 2022-06-23 16:44:02.809291
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}
    # assert g._json_module == json


test__GlobalConfig()

# Generated at 2022-06-23 16:44:04.171973
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("test")
    assert not Exclude.NEVER("test")

# Generated at 2022-06-23 16:44:05.389330
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:44:06.911347
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, Callable)
    assert isinstance(Exclude.NEVER, Callable)

# Generated at 2022-06-23 16:44:08.708923
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("Test Exclude_ALWAYS")
    assert True == Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:44:15.198774
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # GIVEN
    # an _GlobalConfig and an example object
    example = dataclasses.dataclass({"field_name": "example"})
    obj = example("example")
    # WHEN
    # the method NEVER of class Exclude is executed
    result = Exclude.NEVER(obj)
    # THEN
    # the method NEVER of class Exclude must return False
    assert result == False

# Generated at 2022-06-23 16:44:18.209802
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    dataclasses_json_config=_GlobalConfig()
    assert isinstance(dataclasses_json_config,_GlobalConfig)


# Generated at 2022-06-23 16:44:19.882121
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-23 16:44:22.077953
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json
