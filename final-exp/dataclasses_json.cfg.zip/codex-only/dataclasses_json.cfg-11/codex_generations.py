

# Generated at 2022-06-23 16:34:30.339283
# Unit test for function config
def test_config():
    from marshmallow import fields
    import dataclasses
    from datetime import date
    from dataclasses_json import DataClassJsonMixin

    class Date(DataClassJsonMixin):
        def __init__(self, the_date: date):
            self.the_date = the_date

        def __repr__(self):
            return f"Date({self.the_date})"

        @classmethod
        def from_json(cls, json_str):
            if "the_date" not in json_str:
                raise ValueError("Expected json_str to have key 'the_date'")

            return cls(date.fromisoformat(json_str["the_date"]))


# Generated at 2022-06-23 16:34:34.443240
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert not Exclude.ALWAYS(False)
    assert not Exclude.NEVER(True)
    assert Exclude.NEVER(False)


# Generated at 2022-06-23 16:34:35.772049
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:34:42.099530
# Unit test for function config
def test_config():

    from marshmallow import fields as mm_fields
    import pytest

    class TestClass(object):
        def encode_test(self, x: int) -> str:
            return str(x)

        def decode_test(self, x: str) -> int:
            return int(x)

        def exclude_test(self, letter_case: str) -> bool:
            return letter_case == 'camelCase'

    test_object = TestClass()


# Generated at 2022-06-23 16:34:43.453173
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(None) == False)


# Generated at 2022-06-23 16:34:44.715992
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-23 16:34:48.207228
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # print(f"{Exclude.NEVER.__name__}={Exclude.NEVER.__qualname__}: {Exclude.NEVER(0)}")
    assert Exclude.NEVER(0)

# Generated at 2022-06-23 16:34:49.685417
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == True


# Generated at 2022-06-23 16:34:52.797485
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_config = _GlobalConfig()
    assert(test_config.encoders == {})
    assert(test_config.decoders == {})
    assert(test_config.mm_fields == {})

# Unit tests for function config

# Generated at 2022-06-23 16:34:54.796880
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('str') == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-23 16:34:57.455740
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test')


# Generated at 2022-06-23 16:34:58.895818
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER("whatever")
    assert not Exclude.ALWAYS("whatever")

# Generated at 2022-06-23 16:35:01.291006
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-23 16:35:02.362998
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert NOT(Exclude.NEVER)(None) == True

# Generated at 2022-06-23 16:35:05.576070
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    EXPECTED_RESULT = False

    # Act
    result = Exclude.NEVER(None)

    # Assert
    assert result == EXPECTED_RESULT

# Generated at 2022-06-23 16:35:08.784671
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:35:10.473887
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config is not None


# Generated at 2022-06-23 16:35:13.553232
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    assert global_config._json_module == json
    assert global_config.json_module == json


# Generated at 2022-06-23 16:35:14.478876
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-23 16:35:18.532853
# Unit test for constructor of class Exclude
def test_Exclude():
    '''
    This unit test checks whether the constructor of class Exclude works well.

    :return: True if the constructor of class Exclude works well, False if not.
    '''
    if (Exclude.ALWAYS('a') == True and Exclude.NEVER('a') == False):
        return True
    else:
        return False



# Generated at 2022-06-23 16:35:20.274323
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:35:30.033382
# Unit test for function config
def test_config():
    from datetime import date
    from marshmallow import fields as ma_fields
    assert config(encoder=date.isoformat,
                  decoder=date.fromisoformat,
                  mm_field=ma_fields.Date(),
                  letter_case=lambda s: s.upper(),
                  field_name="field",
                  undefined=Undefined.REMOVE) == {
        'dataclasses_json': {
            'encoder': date.isoformat,
            'decoder': date.fromisoformat,
            'mm_field': ma_fields.Date(),
            'letter_case': lambda s: s.upper(),
            'undefined': Undefined.REMOVE,
            'exclude': None,
        }
    }

# Generated at 2022-06-23 16:35:31.788137
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.__init__()

# Generated at 2022-06-23 16:35:39.167832
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS([1, 2]) == True
    assert Exclude.ALWAYS({'a': 'b'}) == True
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER([1, 2]) == False
    assert Exclude.NEVER({'a': 'b'}) == False


# Generated at 2022-06-23 16:35:40.938765
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_value = 3
    assert Exclude.ALWAYS(test_value) == True


# Generated at 2022-06-23 16:35:45.856040
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert type(config.encoders) is dict and config.encoders == {}
    assert type(config.decoders) is dict and config.decoders == {}
    assert type(config.mm_fields) is dict and config.mm_fields == {}
    # TODO: check that we can't set this anymore
    # assert config._json_module is json

# Generated at 2022-06-23 16:35:47.170782
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert (Exclude.NEVER(None) is False)


# Generated at 2022-06-23 16:35:50.697010
# Unit test for constructor of class Exclude
def test_Exclude():
    always = Exclude.ALWAYS(4)
    assert always == True
    never = Exclude.NEVER(4)
    assert never == False

# Generated at 2022-06-23 16:35:53.668701
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}


# Generated at 2022-06-23 16:35:56.546813
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    with open("test_Exclude_ALWAYS.json", "r") as f:
        data = json.load(f)
    assert Exclude.ALWAYS(data) == True


# Generated at 2022-06-23 16:35:57.580120
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
   assert Exclude.NEVER("a") is False


# Generated at 2022-06-23 16:36:02.315344
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int

    a = A(a='a', b=2)
    print(a)

# Generated at 2022-06-23 16:36:03.405193
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    #assert Exclude.NEVER
    assert Exclude.NEVER(None)  # returns True for any object

test_Exclude_NEVER()

# Generated at 2022-06-23 16:36:08.156437
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert callable(Exclude.ALWAYS)
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS({}) == True


# Generated at 2022-06-23 16:36:09.834209
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(100) is False
    assert Exclude.NEVER('100') is False


# Generated at 2022-06-23 16:36:13.478606
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Check input type
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-23 16:36:14.375426
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config is not None

# Generated at 2022-06-23 16:36:14.946555
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert Exclude.ALWAYS("test_str")


# Generated at 2022-06-23 16:36:15.978949
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(0)
    assert result == True

# Generated at 2022-06-23 16:36:17.596528
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('lala') == False


# Generated at 2022-06-23 16:36:18.859995
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    t = ""
    assert Exclude.NEVER(t) == False


# Generated at 2022-06-23 16:36:20.886808
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    an_int = 18
    assert Exclude.NEVER(an_int) is False


# Generated at 2022-06-23 16:36:22.188200
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('abc') == True


# Generated at 2022-06-23 16:36:23.481418
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-23 16:36:25.190349
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude
    assert e.ALWAYS('foo')
    assert not e.NEVER('bar')

# Generated at 2022-06-23 16:36:27.622155
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:36:30.231094
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    try:
        global_config_test = _GlobalConfig()
    except:
        assert False
    assert True


# Generated at 2022-06-23 16:36:34.613812
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()

    assert(config.encoders == {})
    assert(config.decoders == {})
    assert(config.mm_fields == {})
    assert(config._json_module == json)

# Generated at 2022-06-23 16:36:35.423276
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:36:36.746421
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    input = 5
    answer = Exclude.NEVER(input)
    assert answer == False


# Generated at 2022-06-23 16:36:38.705967
# Unit test for constructor of class Exclude
def test_Exclude():
    assert hasattr(Exclude, 'ALWAYS')
    assert hasattr(Exclude, 'NEVER')
    assert Exclude.ALWAYS(False)
    assert not Exclude.NEVER(True)


# Generated at 2022-06-23 16:36:43.686162
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test:
        __metadata__ = config(exclude=Exclude.ALWAYS)
        field: int

    t = Test(field=42)
    from dataclasses_json import dump
    dump(t)

# Generated at 2022-06-23 16:36:54.214360
# Unit test for function config
def test_config():
    @dataclass
    class Point:
        x: int
        y: int

    class TestConfig:
        # pylint: disable=no-self-use
        def test_default(self):
            data = globals()['config']()
            assert data == {'dataclasses_json': {}}

        def test_encoder(self):
            def encoder(value):
                return 0

            data = globals()['config']({}, encoder=encoder)
            assert data == {'dataclasses_json': {'encoder': encoder}}

        def test_decoder(self):
            def decoder(value):
                return 0

            data = globals()['config']({}, decoder=decoder)
            assert data == {'dataclasses_json': {'decoder': decoder}}

       

# Generated at 2022-06-23 16:36:55.956438
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # test constructor of class _GlobalConfig
    _GlobalConfig()


# Generated at 2022-06-23 16:37:01.815713
# Unit test for function config
def test_config():
    @dataclass
    class TestConfig:
        attr: str
        attr1: str = config(
            field_name="attr2",
            encoder=lambda x: x.upper(),
            decoder=lambda x: x.lower(),
            mm_field=fields.Str(required=True, validate=validate.Length(min=4)))

    t = TestConfig("attr", "attr1")
    t_str = t.to_json(indent=2)
    decoded_t = TestConfig.Schema().loads(t_str)
    assert decoded_t == {"attr": "attr", "attr2": "ATTR1"}

# Generated at 2022-06-23 16:37:03.900587
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER(1) == False and Exclude.NEVER(0) == False

# Generated at 2022-06-23 16:37:14.232265
# Unit test for function config
def test_config():
    import marshmallow.fields as mf
    import marshmallow as mm
    import json

    class MyEncoder(json.JSONEncoder):
        pass

    class MyDecoder(json.JSONDecoder):
        pass

    class MyMMField(mf.Field):
        pass

    @config(metadata=dict())
    class MyClass:
        pass

    @config(encoder=MyEncoder,
            decoder=MyDecoder,
            mm_field=MyMMField,
            letter_case=mf.UpperCamelCase,
            undefined=Undefined.EXCLUDE,
            field_name='myfield',
            exclude=Exclude.ALWAYS,
            metadata=dict())
    class MyClass:
        pass


# Generated at 2022-06-23 16:37:15.908602
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert True == Exclude.ALWAYS(' ')


# Generated at 2022-06-23 16:37:17.460274
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:37:22.996379
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

    # assert global_config.json_module is json
    #
    # import dataclasses_json.jsonlib as jsonlib
    # global_config.json_module = jsonlib
    # assert global_config.json_module is jsonlib

# Generated at 2022-06-23 16:37:28.984326
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True), "Exclude.ALWAYS must return true"
    assert Exclude.ALWAYS(False), "Exclude.ALWAYS must return true"
    assert Exclude.ALWAYS(1), "Exclude.ALWAYS must return true"
    assert Exclude.ALWAYS("str"), "Exclude.ALWAYS must return true"



# Generated at 2022-06-23 16:37:33.860335
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class C:
        field: str

    config(encoder=str, decoder=str, field_name='MyField', letter_case=str.lower)

    dataclasses_json.config(decoder=str)
    dataclasses_json.config(mm_field=MarshmallowField)

# Generated at 2022-06-23 16:37:36.482547
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class A:
        b: int = dataclasses.field(metadata=config(exclude=Exclude.ALWAYS))



# Generated at 2022-06-23 16:37:46.989580
# Unit test for function config
def test_config():
    import marshmallow
    import dataclasses as dc
    import marshmallow as mm

    class MySchema(mm.Schema):
        name = mm.fields.String()

    my_schema = MySchema()

    @dc.dataclass
    class MyClass:
        i: int = dc.field(metadata=config(encoder=lambda o: o + 1,
                                          decoder=lambda o: o - 1,
                                          mm_field=marshmallow.fields.Integer(),
                                          letter_case=lambda s: s.upper(),
                                          undefined=Undefined.RAISE,
                                          exclude=Exclude.NEVER,
                                          ))
        name: str

    assert hasattr(MyClass.i, "__dataclasses_json__")
    assert MyClass.i.__dat

# Generated at 2022-06-23 16:37:48.455885
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER("test") is False)



# Generated at 2022-06-23 16:37:51.814566
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0
    # assert global_config.json_module == json


# Generated at 2022-06-23 16:38:01.296366
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import marshmallow.fields

    @dataclass
    @config(encoder='encoder_func', decoder='decoder_func', mm_field=marshmallow.Str(), letter_case='upper', undefined='raise', field_name='config_field_name', exclude=Exclude.ALWAYS)
    class _ConfigTest:
        config_test_field: str

    config = _ConfigTest.__dataclasses_json__

    assert config['encoder'] == 'encoder_func'
    assert config['decoder'] == 'decoder_func'
    assert config['mm_field'] == marshmallow.fields.Str()
    assert config['letter_case'](config['field_name']) == config['field_name'].upper()
    assert config['undefined'] == Undefined.RA

# Generated at 2022-06-23 16:38:03.108609
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = {"name": "ssss"}
    assert Exclude.NEVER(a) == False


# Generated at 2022-06-23 16:38:04.404463
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    assert result == True


# Generated at 2022-06-23 16:38:13.192490
# Unit test for function config
def test_config():
    from .api import Field
    from .utils import Rename

    @config( encoder='encoder', decoder='decoder', mm_field='mm_field')
    @dataclass
    class MyClass:
        a: int
        b: str

        @property  # type: ignore
        @Field(Rename('c'))
        def p(self):
            return 'p'

    assert MyClass.__dataclass_fields__['a'].metadata['dataclasses_json']['encoder'] == 'encoder'
    assert MyClass.__dataclass_fields__['a'].metadata['dataclasses_json']['decoder'] == 'decoder'

# Generated at 2022-06-23 16:38:15.140620
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-23 16:38:25.039063
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("1") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER("abcdef") == False
    assert (Exclude.NEVER("abcdef") == False and Exclude.NEVER("abcdef123") == False)
    assert (Exclude.NEVER("abcdef") == False and Exclude.NEVER("abcdef123") == False and Exclude.NEVER([1]) == False)

# Generated at 2022-06-23 16:38:26.275221
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:38:31.533625
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class A:
        b: int = config(encoder=float)
    a = A(2)
    assert a.__dict__['b'] == 2
    from dataclasses_json.config import EncoderConfig
    assert EncoderConfig(A).encoder(A(2).b) == 2.0



# Generated at 2022-06-23 16:38:33.835042
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config.encoders, dict)
    assert isinstance(config.decoders, dict)
    assert isinstance(config.mm_fields, dict)
    # assert config.json_module is not None


# Generated at 2022-06-23 16:38:35.409110
# Unit test for constructor of class Exclude
def test_Exclude():
    print(Exclude.ALWAYS)
    print(Exclude.NEVER)

test_Exclude()

# Generated at 2022-06-23 16:38:46.482721
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # new instance should have the correct types
    gc = _GlobalConfig()
    assert type(gc.encoders) == dict
    assert type(gc.decoders) == dict
    assert type(gc.mm_fields) == dict

    # make sure the types are correct after munging
    gc.encoders = {}
    gc.decoders = gc.encoders
    assert type(gc.decoders) == dict

    gc = _GlobalConfig()
    assert type(gc.encoders) == dict
    assert type(gc.decoders) == dict
    assert type(gc.mm_fields) == dict

    # make sure the types are correct after munging
    gc.mm_fields = {}
    gc.encoders = gc.mm_fields


# Generated at 2022-06-23 16:38:49.554147
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-23 16:38:51.906711
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("some string") == True


# Generated at 2022-06-23 16:38:53.758842
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(123) is True
    assert Exclude.NEVER(123) is False

# Generated at 2022-06-23 16:38:57.043389
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    if Exclude.ALWAYS(1):
        print("PASS")
        return True
    else:
        print("FAIL")
        return False


# Generated at 2022-06-23 16:39:02.291849
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.ALWAYS(0) == True)
    assert(Exclude.ALWAYS('1') == True)
    assert(Exclude.ALWAYS('0') == True)
    assert(Exclude.ALWAYS(True) == True)
    assert(Exclude.ALWAYS(False) == True)


# Generated at 2022-06-23 16:39:06.042640
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    print(global_config.encoders)
    print(global_config.decoders)
    print(global_config.mm_fields)


# Generated at 2022-06-23 16:39:07.156962
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-23 16:39:08.118355
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)


# Generated at 2022-06-23 16:39:09.357899
# Unit test for constructor of class Exclude
def test_Exclude():
    ex = Exclude.ALWAYS
    assert ex("string")

# Generated at 2022-06-23 16:39:11.196227
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('asd')



# Generated at 2022-06-23 16:39:14.670855
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    """Test for constructor of class _GlobalConfig"""
    global_config = _GlobalConfig()

    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-23 16:39:24.797719
# Unit test for function config
def test_config():
    from marshmallow import fields, Schema
    class FooSchema(Schema):
        id = fields.Int(required=True)
    @dataclass
    class Address:
        street: str

# Generated at 2022-06-23 16:39:25.908150
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-23 16:39:29.223010
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config.encoders, dict)
    assert isinstance(config.decoders, dict)
    assert isinstance(config.mm_fields, dict)
    # assert type(config.json_module) is json.__class__


# Generated at 2022-06-23 16:39:32.192800
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_config = _GlobalConfig()
    assert test_config.encoders is not None
    assert test_config.decoders is not None
    assert test_config.mm_fields is not None

# Generated at 2022-06-23 16:39:36.557688
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Person:
        def __init__(self):
            self.name = None
            self.age = None

    p = Person()
    p.name = "John"
    p.age = 25
    print(Exclude.NEVER(p))


# Generated at 2022-06-23 16:39:45.156081
# Unit test for function config
def test_config():
    import pytest
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: int
        baz: str

    @config(exclude=Exclude.NEVER)
    class Bar:
        foo: Foo

    @config(encoder=list, decoder=tuple, mm_field=tuple,
            letter_case=lambda s: s.upper(),
            undefined=Undefined.EXCLUDE,
            exclude=Exclude.NEVER)
    class Baz:
        bar: Bar

    with pytest.raises(UndefinedParameterError) as excinfo:
        @config(undefined="INVALID")
        class Qux:
            pass
    assert "Invalid undefined parameter action" in str(excinfo.value)

    # TODO: test letter_case override


# Generated at 2022-06-23 16:39:47.905557
# Unit test for constructor of class Exclude
def test_Exclude():
    # check class Exclude
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:39:49.510280
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:39:53.453929
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

    assert isinstance(global_config, _GlobalConfig)


# Generated at 2022-06-23 16:39:54.454360
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS("")
    assert result == True
    

# Generated at 2022-06-23 16:39:58.031451
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    for val in [True, False, 0, 1, 10, -1, '1', '', None, {}, []]:
        assert Exclude.NEVER(val) == False

# Generated at 2022-06-23 16:40:06.219253
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class Data:
        a: str

    cfg = config(encoder=lambda x: x + ' encoder',
                 decoder=lambda x: x + ' decoder',
                 mm_field=MarshmallowField(attribute='b'),
                 letter_case=str.upper,
                 undefined=Undefined.EXCLUDE,
                 field_name='c',
                 exclude=Exclude.NEVER)

    assert cfg.get('dataclasses_json').get('encoder') == Data.a.__annotations__['a'].__annotations__['encoder']
    assert cfg.get('dataclasses_json').get('decoder') == Data.a.__annotations__['a'].__annotations__['decoder']

# Generated at 2022-06-23 16:40:10.186952
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    NEVER = Exclude.NEVER
    # Returns False, since the value passed in is not None
    assert NEVER(1) == False
    # Also returns False, since the value passed in is not None
    assert NEVER("test_string") == False

# Generated at 2022-06-23 16:40:12.659954
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude = Exclude()
    assert(exclude is None)


# Generated at 2022-06-23 16:40:22.458741
# Unit test for function config
def test_config():
    import marshmallow as ma
    import datetime as dt

    @config('dataclasses_json', encoder=str, cache=False,
            mm_field=ma.fields.Str())
    @dataclass
    class Test:
        name: str

    @config('dataclasses_json', decoder=dt.datetime.fromisoformat,
            cache=False, mm_field=ma.fields.Str())
    @dataclass
    class Test2:
        dt: dt.datetime

    # check encoder
    test = Test('test')
    assert (test.name == 'test')
    dumped = to_json(test)
    assert (dumped == '"test"')
    # check decoder
    test = from_json(dumped, Test)

# Generated at 2022-06-23 16:40:24.913262
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(2)

# Generated at 2022-06-23 16:40:27.433493
# Unit test for constructor of class Exclude
def test_Exclude():
    def test_func(x):
        return True

    x = Exclude.ALWAYS
    y = Exclude.NEVER

    x == test_func

    assert (x == test_func) and (y == test_func)


# Generated at 2022-06-23 16:40:30.428781
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    assert global_config.json_module == json
    global_config.json_module == json


# Generated at 2022-06-23 16:40:33.865208
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('foo')
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:40:40.042884
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert global_config.encoders == {}
    assert isinstance(global_config.decoders, dict)
    assert global_config.decoders == {}
    assert isinstance(global_config.mm_fields, dict)
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json



# Generated at 2022-06-23 16:40:43.732827
# Unit test for constructor of class Exclude
def test_Exclude():
    # TEST: start
    ex = Exclude()
    assert(ex is not None)
# TEST: end


# Generated at 2022-06-23 16:40:53.388411
# Unit test for function config
def test_config():
    assert config(field_name='test') == {'dataclasses_json': {'field_name': 'test'}}
    assert config(letter_case=str.lower) == {
        'dataclasses_json': {
            'letter_case': str.lower
        }
    }
    assert config(undefined='ignore') == {
        'dataclasses_json': {
            'undefined': Undefined.IGNORE
        }
    }
    assert config(exclude=Exclude.ALWAYS) == {
        'dataclasses_json': {
            'exclude': Exclude.ALWAYS
        }
    }

# Generated at 2022-06-23 16:40:54.807624
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER(10)


# Generated at 2022-06-23 16:40:56.960544
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:41:01.019170
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.config import config
    @dataclass
    class MyClass:
        a: int
        b: int
        @config(exclude=lambda fn, val: fn == 'b')
        def meth(self):
            return
    assert not MyClass(a=1, b=2).meth()
    return

# Generated at 2022-06-23 16:41:13.121461
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("a")
    assert Exclude.NEVER("b")
    assert Exclude.NEVER("c")
    assert Exclude.NEVER("d")
    assert Exclude.NEVER("e")
    assert Exclude.NEVER("f")
    assert Exclude.NEVER("g")
    assert Exclude.NEVER("h")
    assert Exclude.NEVER("i")
    assert Exclude.NEVER("j")
    assert Exclude.NEVER("k")
    assert Exclude.NEVER("l")
    assert Exclude.NEVER("m")
    assert Exclude.NEVER("n")
    assert Exclude.NEVER("o")
    assert Exclude.NEVER("p")
    assert Exclude.NEVER("q")

# Generated at 2022-06-23 16:41:16.597403
# Unit test for constructor of class Exclude
def test_Exclude():
	print(Exclude.ALWAYS)
	print(Exclude.NEVER)

if __name__ == "__main__":
	test_Exclude()

# Generated at 2022-06-23 16:41:17.518984
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-23 16:41:25.363195
# Unit test for function config
def test_config():
    @dataclass
    class Foo:
        x: int

    a = Foo(1)

    assert fields(a) == ['x']
    assert json.loads(dumps(a, include=None)) == {'x': 1}

    assert fields(config(a, exclude=lambda field, _: field.name == 'x')) == []
    assert json.loads(dumps(a, include=None)) == {}
    assert json.loads(dumps(a, exclude=None)) == {'x': 1}

    assert fields(config(a, field_name=lambda field, _: field.name + "1")) == ['x1']
    assert json.loads(dumps(a, include=None)) == {'x1': 1}


# Generated at 2022-06-23 16:41:27.421905
# Unit test for constructor of class Exclude
def test_Exclude():
    assert id(Exclude.ALWAYS) != id(Exclude.NEVER)

test_Exclude()

# Generated at 2022-06-23 16:41:32.030256
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Conf:
        name: str = config(
            field_name='FullName', letter_case=lambda s: s.lower()
        )

    c = Conf('Jonathan')
    assert c.name == 'jonathan'



# Generated at 2022-06-23 16:41:34.248964
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert not Exclude.ALWAYS(False)
    assert not Exclude.NEVER(True)
    assert Exclude.NEVER(False)


# Generated at 2022-06-23 16:41:36.393303
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is True
    assert Exclude.NEVER is False

# Generated at 2022-06-23 16:41:37.564125
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:41:39.069791
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(dict()) == True


# Generated at 2022-06-23 16:41:39.928286
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert False

# Generated at 2022-06-23 16:41:42.721634
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestClass:
        pass

    obj = TestClass()

    assert Exclude.NEVER(obj) == False


# Generated at 2022-06-23 16:41:45.553916
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)
    try:
        Exclude.Raise(1)
    except AttributeError:
        print("AttributeError raises well")


# Generated at 2022-06-23 16:41:47.490008
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test = Exclude.NEVER(12)
    assert test == False

# Unit Test method ALWAYS of class Exclude

# Generated at 2022-06-23 16:41:49.389308
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(5)
    assert not Exclude.NEVER(5)


# Generated at 2022-06-23 16:41:52.067515
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(2.2) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS("hello") == True


# Generated at 2022-06-23 16:41:55.216472
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert True == Exclude.ALWAYS(1)
    assert True == Exclude.ALWAYS(None)
    assert True == Exclude.ALWAYS('string')


# Generated at 2022-06-23 16:42:02.323389
# Unit test for function config
def test_config():

    from marshmallow import Schema, fields
    from marshmallow_oneofschema import OneOfSchema, fields as one_of_fields

    class Hero:
        name: str
        type: str

    class HeroSchema(Schema):
        class Meta:
            strict = True

        name = fields.String()
        type = one_of_fields.String(
            validate=one_of_fields.OneOf(["tough", "smart", "agile"])
        )

    class HeroEncoder(OneOfSchema):
        type_field = "type"
        type_field_remove = False

# Generated at 2022-06-23 16:42:03.530381
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude()



# Generated at 2022-06-23 16:42:09.946993
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Some") is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(12) is True
    assert Exclude.ALWAYS(1.234) is True
    assert Exclude.ALWAYS(["Some", "array"]) is True
    assert Exclude.ALWAYS({1: "One", 2: "Two"}) is True


# Generated at 2022-06-23 16:42:12.961525
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:42:14.143385
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('')


# Generated at 2022-06-23 16:42:18.197231
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test = _GlobalConfig()
    assert test.encoders == {}
    assert test.decoders == {}
    assert test.mm_fields == {}


# Generated at 2022-06-23 16:42:19.465701
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-23 16:42:22.105405
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:42:26.794625
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_test = _GlobalConfig()
    assert global_config_test.encoders == {}
    assert global_config_test.decoders == {}
    assert global_config_test.mm_fields == {}
    # assert global_config_test.json_module == json

# Generated at 2022-06-23 16:42:28.761347
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Hello") == True



# Generated at 2022-06-23 16:42:30.615111
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(2) == True
    assert Exclude.NEVER(2) == False

# Generated at 2022-06-23 16:42:36.426990
# Unit test for constructor of class Exclude
def test_Exclude():
    # Pre-condition: Exclude.NEVER returns False
    assert Exclude.NEVER(None) is False
    # Pre-condition: Exclude.ALWAYS returns True
    assert Exclude.ALWAYS(None) is True
    # Post-condition: Exclude.NEVER returns False
    assert Exclude.NEVER(None) is False
    # Post-condition: Exclude.ALWAYS returns True
    assert Exclude.ALWAYS(None) is True

# Generated at 2022-06-23 16:42:38.484599
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print('test_Exclude_NEVER')
    _NEVER = Exclude.NEVER
    assert(_NEVER(1) == False)
    print('pass')


# Generated at 2022-06-23 16:42:41.056230
# Unit test for constructor of class Exclude
def test_Exclude():
    param_test=Exclude
    param_test.ALWAYS
    param_test.NEVER

# Generated at 2022-06-23 16:42:44.871362
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(Undefined)
    assert Exclude.NEVER("Some value")
    assert Exclude.NEVER(42)


# Generated at 2022-06-23 16:42:48.266326
# Unit test for constructor of class Exclude
def test_Exclude():
    result = Exclude.ALWAYS("test")
    assert result == True

# Generated at 2022-06-23 16:42:50.536665
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert not Exclude.NEVER(True)



# Generated at 2022-06-23 16:42:52.987423
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("hello")
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-23 16:42:58.260419
# Unit test for function config
def test_config():
    import pytest

    with pytest.raises(UndefinedParameterError):
        config(undefined='foo')
    with pytest.raises(UndefinedParameterError):
        config(undefined=object())
    with pytest.raises(UndefinedParameterError):
        config(undefined=Undefined.EXCLUDE)
    assert config(undefined=undefined)
    assert config(undefined='exclude')
    assert config(undefined=Undefined.RAISE)
    assert config(undefined='raise')

# Generated at 2022-06-23 16:43:00.383517
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a')
    assert not Exclude.NEVER('a')

# Generated at 2022-06-23 16:43:02.155437
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)


# Generated at 2022-06-23 16:43:05.326136
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:43:13.734243
# Unit test for function config
def test_config():
    from .annotations_for_tests import test_config_encoder, test_config_decoder
    from .annotations_for_tests import test_config_mm_field
    from dataclasses import dataclass
    # Test for encoder
    @dataclass
    @config(encoder=test_config_encoder)
    class TestConfigEncoder:
        pass
    assert TestConfigEncoder.schema()['encoder'] == test_config_encoder

    # Test for decoder
    @dataclass
    @config(decoder=test_config_decoder)
    class TestConfigDecoder:
        pass
    assert TestConfigDecoder.schema()['decoder'] == test_config_decoder

    # Test for mm_field

# Generated at 2022-06-23 16:43:16.330847
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class Example:
        defaults = config(exclude=Exclude.ALWAYS)
        def __init__(self, arg1 : int, arg2 : str = 'default', arg3 = False):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3

    example = Example(42)
    assert example.arg1 is None
    assert example.arg2 is None
    assert example.arg3 is None


# Generated at 2022-06-23 16:43:18.135053
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Create a function for testing
    def test_func():
        assert Exclude.ALWAYS(None)
    # Run the test
    test_func()


# Generated at 2022-06-23 16:43:22.441594
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(1.1) == True
    assert Exclude.ALWAYS('str') == True
    assert Exclude.ALWAYS((1,2,3)) == True


# Generated at 2022-06-23 16:43:24.311744
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude.ALWAYS("test")
    Exclude.NEVER("test")


# USAGE:
# @config.encoder('~')

# Generated at 2022-06-23 16:43:27.252895
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Setup
    global_config1 = _GlobalConfig()

    # Exercise and Verify
    assert global_config1.encoders == {}
    assert global_config1.decoders == {}
    assert global_config1.mm_fields == {}
    # assert global_config1.json_module == json

# Generated at 2022-06-23 16:43:31.643369
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _global_config = _GlobalConfig()
    assert _global_config.encoders == {}
    assert _global_config.decoders == {}
    assert _global_config.mm_fields == {}


# Unit test of function _config

# Generated at 2022-06-23 16:43:34.913496
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-23 16:43:37.693488
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS.__name__ == '<lambda>'
    assert Exclude.NEVER.__name__ == '<lambda>'

# Generated at 2022-06-23 16:43:41.310797
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-23 16:43:43.545187
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
  assert global_config.encoders == {}
  assert global_config.decoders == {}
  assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:43:46.858571
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    instance = _GlobalConfig()
    if isinstance(instance.encoders, dict):
        print(True)
    else:
        print(False)


# Generated at 2022-06-23 16:43:49.024919
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(-1)
    assert Exclude.ALWAYS(0)


# Generated at 2022-06-23 16:43:53.431447
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('hello')
    assert Exclude.ALWAYS(42)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS({1: 2})


# Generated at 2022-06-23 16:43:56.970179
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    @dataclass
    class A:
        # default value is invalid
        b: int = config(undefined=Undefined.RAISE)

    from dataclasses_json import confi

# Generated at 2022-06-23 16:43:59.349922
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS == Exclude.ALWAYS
    assert Exclude.ALWAYS != Exclude.NEVER

# Generated at 2022-06-23 16:44:00.960045
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-23 16:44:05.219248
# Unit test for function config
def test_config():
    # smoke test for configuration.

    @dataclass
    class A:
        x: str = config(field_name='y')

    d = dataclasses.asdict(A())
    assert d == {'y': None}


if __name__ == '__main__':
    test_config()

# Generated at 2022-06-23 16:44:06.060128
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    assert conf is not None

# Generated at 2022-06-23 16:44:09.186954
# Unit test for function config
def test_config():
    def dummy_letter_case(field_name):
        return f"{field_name}-dummy"

    assert config(field_name="field-name") == {
        "dataclasses_json": {"letter_case": dummy_letter_case}}

# Generated at 2022-06-23 16:44:13.039587
# Unit test for constructor of class Exclude
def test_Exclude():
    """
    >>> e = Exclude()
    >>> e.ALWAYS('anything')
    True
    >>> e.NEVER('anything')
    False
    """

# Generated at 2022-06-23 16:44:14.344747
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:44:17.818606
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Given
    test_input = 'test'

    # When
    result = Exclude.NEVER(test_input)

    # Then
    assert result == False


# Generated at 2022-06-23 16:44:26.213109
# Unit test for function config
def test_config():
    # Ensure the config function works as expected before changing class
    # definition
    class Foo:
        pass

    d = config(Foo)
    assert d['dataclasses_json'] == {}

    d = config(Foo, encoder=str)
    assert d['dataclasses_json'] == {'encoder': str}

    d = config(Foo, decoder=int)
    assert d['dataclasses_json'] == {'decoder': int}

    d = config(Foo, mm_field=int)
    assert d['dataclasses_json'] == {'mm_field': int}

    d = config(Foo, letter_case=int)
    assert d['dataclasses_json'] == {'letter_case': int}

    d = config(Foo, undefined='ignore')
    assert d