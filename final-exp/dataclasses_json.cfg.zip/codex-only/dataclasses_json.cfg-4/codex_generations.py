

# Generated at 2022-06-23 16:34:27.966353
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # this test is used to test the behavior of a function function in a class
    # as we know the NEVER function is just a function created to return a boolean
    # we just call it and assert the result is False
    assert Exclude.NEVER('hahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahaha') == False
    print('test_Exclude_NEVER is passed')
    return None


# Generated at 2022-06-23 16:34:29.522688
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert True == Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:34:32.741878
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
        conf = _GlobalConfig()
        conf.encoders={}
        conf.decoders={}
        conf.mm_fields={}
        return conf


# Generated at 2022-06-23 16:34:34.892781
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:34:36.516454
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.NEVER(1) == False)
    assert(Exclude.ALWAYS(1) == True)

# Generated at 2022-06-23 16:34:40.375726
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    jason = _GlobalConfig()
    assert jason.encoders == {}
    assert jason.decoders == {}
    assert jason.mm_fields == {}


# Generated at 2022-06-23 16:34:44.632194
# Unit test for function config
def test_config():
    metadata = config(
        encoder=lambda _: None,
        decoder=lambda _: None,
        mm_field=MarshmallowField(),
        letter_case=lambda _: None,
        undefined=Undefined.EXCLUDE,
        field_name="name",
        exclude=Exclude.NEVER,
    )
    print(metadata)

# Generated at 2022-06-23 16:34:47.660810
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert(a.encoders == {})
    assert(a.decoders == {})
    assert(a.mm_fields == {})
    # assert(a._json_module == json)
test__GlobalConfig()

# Generated at 2022-06-23 16:34:58.608332
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined
    from marshmallow.fields import String

    @dataclass
    class Person:
        id: int
        name: str

    Person.__dict__.update(config(Person,
                                  encoder=lambda o: o.id,
                                  decoder=lambda o: o.id,
                                  mm_field=String(),
                                  undefined=Undefined.EXCLUDE))

    assert global_config.encoders[Person] == Person.__dict__["dataclasses_json"]['encoder']
    assert global_config.decoders[Person] == Person.__dict__["dataclasses_json"]['decoder']

# Generated at 2022-06-23 16:34:59.817944
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)


# Generated at 2022-06-23 16:35:04.616770
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Point:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    p = Point(x=2.0, y=3.0)
    assert Exclude.NEVER(p) == True

# Generated at 2022-06-23 16:35:05.630184
# Unit test for constructor of class Exclude
def test_Exclude():
    return None

# Generated at 2022-06-23 16:35:09.783241
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(5)
    assert not Exclude.NEVER(5)



# Generated at 2022-06-23 16:35:13.887414
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_1 = _GlobalConfig()
    assert global_config_1.encoders == {}
    assert global_config_1.decoders == {}
    assert global_config_1.mm_fields == {}
    # assert global_config_1._json_module == json


# Generated at 2022-06-23 16:35:16.627385
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}


# Generated at 2022-06-23 16:35:20.921248
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class Test1:
        field1: str
        field2: str
    test1 = Test1()

    test1.field1 = "field1_value"
    test1.field2 = "field2_value"
    assert Exclude.ALWAYS(test1) == True


# Generated at 2022-06-23 16:35:23.667037
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:35:27.212663
# Unit test for function config
def test_config():
    """ Test fields with config data
    """
    import marshmallow as ma
    import dataclasses as dc

    @dc.dataclass
    class Test:
        id: int
        name: str

        class Config:
            encoder: Callable = None
            decoder: Callable = None
            mm_field: Union[MarshmallowField, dict] = None
            letter_case: Callable[[str], str] = None
            undefined: Optional[Union[str, Undefined]] = None
            field_name: str = None
            exclude: Optional[Callable[[str, T], bool]] = None
            # json_module: json = json

            def _set_field(self, key, value, instance):
                name = '_' + key

# Generated at 2022-06-23 16:35:29.911234
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders[type] = Callable
    global_config.decoders[type] = Callable
    global_config.mm_fields[type] = MarshmallowField

    return True

# Generated at 2022-06-23 16:35:33.785393
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1.encoders == {}
    assert global_config1.decoders == {}
    assert global_config1.mm_fields == {}


# Generated at 2022-06-23 16:35:35.796764
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test')



# Generated at 2022-06-23 16:35:36.936361
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1), "Return True"
    assert not Exclude.NEVER(1), "Return False"

    return 0

# Generated at 2022-06-23 16:35:43.449990
# Unit test for function config
def test_config():
    metadata = config(dict(), encoder=1, decoder=2, mm_field=3, letter_case=4, undefined=5)

    assert metadata['dataclasses_json']['encoder'] == 1
    assert metadata['dataclasses_json']['decoder'] == 2
    assert metadata['dataclasses_json']['mm_field'] == 3
    assert metadata['dataclasses_json']['letter_case'] == 4
    assert metadata['dataclasses_json']['undefined'] == 5

# Generated at 2022-06-23 16:35:54.729484
# Unit test for function config
def test_config():
    # Test new API
    assert config() == {
        'dataclasses_json': {},
    }
    assert config(encoder=int) == {
        'dataclasses_json': {
            'encoder': int,
        },
    }
    assert config(decoder=float) == {
        'dataclasses_json': {
            'decoder': float,
        },
    }
    assert config(mm_field=MarshmallowField) == {
        'dataclasses_json': {
            'mm_field': MarshmallowField,
        },
    }
    assert config(field_name='foo_bar') == {
        'dataclasses_json': {
            'letter_case': 'foo_bar',
        },
    }

# Generated at 2022-06-23 16:35:56.121109
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    pass


# Generated at 2022-06-23 16:35:57.631014
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)


# Generated at 2022-06-23 16:35:58.709595
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False



# Generated at 2022-06-23 16:36:00.756601
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(_GlobalConfig(), _GlobalConfig)



# Generated at 2022-06-23 16:36:01.941854
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)

# Generated at 2022-06-23 16:36:02.905613
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('ab') == False

# Generated at 2022-06-23 16:36:14.200078
# Unit test for function config
def test_config():
    from marshmallow_dataclass import class_schema
    from marshmallow import fields
    from dataclasses import dataclass, replace
    from decimal import Decimal
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    @config(encoder=lambda x: x.real + x.imag,
            decoder=lambda x: complex(x, 0),
            mm_field=fields.Constant('mm'),
            letter_case=lambda x: x.replace('d', 'f'),
            undefined=Undefined.EXCLUDE,
            exclude=lambda _, __: True)
    class _TestConfig(DataClassJsonMixin):

        d: complex

    config_ = _TestConfig.schema.class_config
    assert config_['encoder'](_TestConfig(2 + 3j))

# Generated at 2022-06-23 16:36:17.612692
# Unit test for function config
def test_config():
    try:
        config(undefined="this_is_not_a_valid_undefined_parameter_action")
    except UndefinedParameterError:
        pass
    else:
        # if an error is not raised, the test will fail
        assert False

# -----------------------------------------------------------------------------



# Generated at 2022-06-23 16:36:20.412616
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders is not None
    assert global_config.decoders is not None
    assert global_config.mm_fields is not None
    assert global_config._json_module is not None

# Generated at 2022-06-23 16:36:22.208927
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Unit test for method ALWAYS of class Exclude
    assert Exclude.ALWAYS('') == True

# Generated at 2022-06-23 16:36:29.234947
# Unit test for function config
def test_config():
    data = config(
        field_name='test_field',
        letter_case='snake_case',
        undefined='default',
        exclude=Exclude.ALWAYS)
    data = config(
        data, field_name='other_field',
        letter_case=lambda s: s.replace('_', ''))
    assert data['dataclasses_json'] == {
        'undefined': Undefined.DEFAULT,
        'exclude': Exclude.ALWAYS,
        'letter_case': lambda s: s.replace('_', ''),
    }

# Generated at 2022-06-23 16:36:38.061026
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import pytest
    from dataclasses_json import dataclass_json, config

    @dataclass
    @dataclass_json
    @config(undefined=Undefined.RAISE)
    class Test:
        pass

    @dataclass
    @dataclass_json
    @config(undefined='Raise')
    class Test1:
        pass

    with pytest.raises(UndefinedParameterError):
        @dataclass
        @dataclass_json
        @config(undefined='US')
        class Test2:
            pass

# Generated at 2022-06-23 16:36:39.860808
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)  == True
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-23 16:36:41.610503
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER('x'))


# Generated at 2022-06-23 16:36:44.020770
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(object)


# Generated at 2022-06-23 16:36:45.650085
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-23 16:36:47.122354
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test_Exclude_ALWAYS")



# Generated at 2022-06-23 16:36:51.868738
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    test_obj = _GlobalConfig()
    assert test_obj.encoders == {}
    assert test_obj.decoders == {}
    assert test_obj.mm_fields == {}


if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-23 16:36:53.524817
# Unit test for function config
def test_config():
    assert config.__name__ == 'config'
    assert config.__module__ == 'dataclasses_json.config'

# Generated at 2022-06-23 16:36:56.162405
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        my_string: str
        my_int: int

        class Meta:
            pass

    pass

# Generated at 2022-06-23 16:36:56.673404
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-23 16:36:57.389409
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()


# Generated at 2022-06-23 16:36:59.885205
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a')


# Generated at 2022-06-23 16:37:05.559973
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print (Exclude.NEVER(1))
    print (Exclude.NEVER('a'))
    print (Exclude.NEVER(None))
    print (Exclude.NEVER(object()))
    print (Exclude.NEVER(Exception()))
    print (Exclude.NEVER(1.1))



# Generated at 2022-06-23 16:37:15.264798
# Unit test for function config
def test_config():

    def letter_case(s):
        return s.upper()

    def exclude(field_name, declared_field):
        return field_name == 'exclude'

    @config(
        metadata={'foo': 'bar'},
        encoder=lambda v: v,
        decoder=lambda v: v,
        mm_field=MarshmallowField(),
        letter_case=letter_case,
        undefined='ignore',
        exclude=exclude,
    )
    class MyClass:
        pass

    assert MyClass.__dataclasses_json__.metadata == {'foo': 'bar'}
    assert MyClass.__dataclasses_json__.encoder == letter_case
    assert MyClass.__dataclasses_json__.decoder == letter_case
    assert MyClass.__dataclasses_json__.mm

# Generated at 2022-06-23 16:37:20.821143
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    class Test:
        a: int = field(metadata=config(exclude=Exclude.NEVER))
    test = Test(a=5)
    assert to_dict(test) == {'a': 5}
    assert from_dict(test, {}) == Test(a=5)


# Generated at 2022-06-23 16:37:23.777567
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    conf.encoders = {"encoders": ""}
    conf.decoders = {"decoders": ""}
    conf.mm_fields = {"mm_fields": ""}


# Generated at 2022-06-23 16:37:25.843672
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:37:30.384814
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (Exclude.ALWAYS(1) == True)
    assert (Exclude.ALWAYS("Hello") == True)
    assert (Exclude.NEVER(1) == False)
    assert (Exclude.NEVER("Hello") == False)


# Generated at 2022-06-23 16:37:32.504713
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

test_Exclude_NEVER()


# Generated at 2022-06-23 16:37:33.901211
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:37:35.904756
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:37:37.514488
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    NEVER_CONST = Exclude.NEVER
    results = "Test"
    assert NEVER_CONST(results) == False


# Generated at 2022-06-23 16:37:47.315401
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config({'foo': 'bar'}) == {'dataclasses_json': {}, 'foo': 'bar'}
    assert config(encoder='encode') == \
        {'dataclasses_json': {'encoder': 'encode'}}
    assert config(decoder='decode') == \
        {'dataclasses_json': {'decoder': 'decode'}}
    assert config(mm_field='field') == \
        {'dataclasses_json': {'mm_field': 'field'}}
    assert config(field_name='name') == \
        {'dataclasses_json': {'letter_case': 'name'}}

# Generated at 2022-06-23 16:37:48.356571
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config._GlobalConfig()


# Generated at 2022-06-23 16:37:50.050911
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude()
    assert x.NEVER != 5

# Generated at 2022-06-23 16:37:59.202274
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from typing import Callable, Optional
    from marshmallow import Schema, fields

    s = Schema()

    @s.pre_load()
    def load_person(data, **kwargs):
        if "first" in data:
            data["first"] = data.get("first").upper()
        if "last" in data:
            data["last"] = data.get("last").upper()
        return data

    @s.post_dump()
    def dump_person(data, many, **kwargs):
        data["first"] = data["first"].lower()
        data["last"] = data["last"].lower()
        return data

    @s.validates_schema()
    def validate_person(data, **kwargs):
        if "first" in data and not data["first"]:
            raise ValueError

# Generated at 2022-06-23 16:38:02.323593
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-23 16:38:03.730345
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)



# Generated at 2022-06-23 16:38:06.850442
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0


# Generated at 2022-06-23 16:38:08.078552
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc


# Generated at 2022-06-23 16:38:09.739264
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Unit test for method NEVER of class Exclude")
    assert not Exclude.NEVER("")


# Generated at 2022-06-23 16:38:14.251804
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1.encoders == {}
    assert global_config1.decoders == {}
    assert global_config1.mm_fields == {}
    # assert global_config1.json_module == json


# Generated at 2022-06-23 16:38:17.480275
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    assert global_config._json_module == json

# Generated at 2022-06-23 16:38:20.756141
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    # assert config.json_module == json



# Generated at 2022-06-23 16:38:23.704645
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    if Exclude.NEVER(1):
        print("test_Exclude_NEVER: Error")
    else:
        print("test_Exclude_NEVER: OK")

test_Exclude_NEVER()

# Generated at 2022-06-23 16:38:24.912124
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude.ALWAYS(10)
    Exclude.NEVER(20)

# Generated at 2022-06-23 16:38:33.524048
# Unit test for function config
def test_config():
    from marshmallow import fields

    from .undefined import Undefined, UndefinedParameterError

    @dataclass
    @config(encoder=lambda x: x + 1)
    class Item:
        value: int

    assert Item.json_dumps(Item(3)) == '{"value": 4}'

    @dataclass
    @config(decoder=int)
    class Item:
        value: int

    assert Item.json_loads('{"value": "4"}').value == 4

    @dataclass
    @config(mm_field=fields.Integer)
    class Item:
        value: int

    assert Item.schema().dump(Item(value=3)) == {'value': 3}


# Generated at 2022-06-23 16:38:34.537836
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('yes') == True


# Generated at 2022-06-23 16:38:39.268373
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    dc_js_config = _GlobalConfig()
    assert dc_js_config.encoders == {}
    assert dc_js_config.decoders == {}
    assert dc_js_config.mm_fields == {}
    # assert dc_js_config._json_module == json

# Generated at 2022-06-23 16:38:42.172509
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(None))
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-23 16:38:43.697527
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(4) == True


# Generated at 2022-06-23 16:38:46.434674
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_test = _GlobalConfig()
    assert global_config_test.encoders == {}
    assert global_config_test.decoders == {}

# Generated at 2022-06-23 16:38:57.352031
# Unit test for function config
def test_config():
    class X:
        pass

    metadata = config(
        encoder=str,
        decoder=int,
        mm_field=object(),
        letter_case=lambda s: s.upper(),
        undefined=Undefined.EXCLUDE,
        field_name='x',
        exclude=lambda name, field: name == 'x')

    assert metadata['dataclasses_json']['encoder'] == str
    assert metadata['dataclasses_json']['decoder'] == int
    assert metadata['dataclasses_json']['mm_field'] == object()
    assert metadata['dataclasses_json']['undefined'] == Undefined.EXCLUDE
    assert metadata['dataclasses_json']['letter_case']('') == 'X'

# Generated at 2022-06-23 16:38:58.547467
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('abc') == False


# Generated at 2022-06-23 16:38:59.852845
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('some_value')
    assert not Exclude.NEVER('some_value')

# Generated at 2022-06-23 16:39:03.844308
# Unit test for function config
def test_config():
    # testing
    @config(encoder=lambda x: x)
    @dataclass
    class Foo:
        some_value: str

    assert Foo._config.encoder(1) == 1


# TODO: #180
# def use_json(json_module):
#     global_config.json_module = json_module

# Generated at 2022-06-23 16:39:09.356112
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields, Schema

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class MyClass:
        var: str

    assert hasattr(MyClass, '__dataclasses_json__')
    assert 'exclude' in MyClass.__dataclasses_json__



# Generated at 2022-06-23 16:39:11.537524
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()
    assert obj.encoders == {}
    assert obj.decoders == {}
    assert obj.mm_fields == {}


# Generated at 2022-06-23 16:39:12.619512
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Hello World")


# Generated at 2022-06-23 16:39:14.531428
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is Exclude.ALWAYS()
    assert Exclude.NEVER is Exclude.NEVER()


# Generated at 2022-06-23 16:39:16.488267
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) is True
    assert Exclude.NEVER(0) is False

# Generated at 2022-06-23 16:39:17.505480
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:39:18.320238
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-23 16:39:20.292568
# Unit test for constructor of class Exclude
def test_Exclude():
    assert id(Exclude.ALWAYS) == id(Exclude.ALWAYS)
    assert id(Exclude.NEVER) == id(Exclude.NEVER)


# Generated at 2022-06-23 16:39:21.424558
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    f = Exclude.ALWAYS(0)
    assert f == True


# Generated at 2022-06-23 16:39:30.159691
# Unit test for constructor of class Exclude
def test_Exclude():
    assert len(Exclude.__dict__) == 2
    assert Exclude.ALWAYS.__name__ == "ALWAYS"
    assert Exclude.NEVER.__name__ == "NEVER"

# Unit tests for class _GlobalConfig
# def test___init__():
#     assert len(_GlobalConfig.__dict__) == 2
#     assert "json" in _GlobalConfig.__name__
#     assert "json_module" in _GlobalConfig.__name__
#
# def test___init__():
#     # Good:
#     gc__ = _GlobalConfig()
#     assert gc__.json_module == json
#
#     # Bad:
#     gc__ = _GlobalConfig()
#     gc__.json_module = None
#     try:
#         gc__.json_module =

# Generated at 2022-06-23 16:39:31.498739
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("true")
    assert not Exclude.NEVER("false")

# Generated at 2022-06-23 16:39:35.539700
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.json_module.__name__ == 'json'
    assert global_config.encoders == dict()
    assert global_config.decoders == dict()
    assert global_config.mm_fields == dict()

# Generated at 2022-06-23 16:39:39.598109
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})


# Generated at 2022-06-23 16:39:48.790988
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    global_config.encoders = {str:float}
    global_config.decoders = {str:float}
    global_config.mm_fields = {str:float}

    assert global_config.encoders == {str:float}
    assert global_config.decoders == {str:float}
    assert global_config.mm_fields == {str:float}



# Generated at 2022-06-23 16:39:55.500963
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    import dataclasses_json
    import marshmallow

    @dataclass
    class A:
        i: int
        s: str
        b: bool
        nested: 'A'

        @dataclasses_json.config(exclude=Exclude.ALWAYS)
        def __post_init__(self):
            pass

    @dataclasses_json.config(exclude=Exclude.ALWAYS)
    def always():
        pass

    @dataclasses_json.config(exclude=Exclude.NEVER)
    def never():
        pass

    # Verify the always/never functions

    assert always._config['dataclasses_json']['exclude'] is Exclude.ALWAYS
    assert never._config['dataclasses_json']['exclude'] is Exclude

# Generated at 2022-06-23 16:39:57.523248
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:40:02.238161
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(0.0) == True


# Generated at 2022-06-23 16:40:06.719043
# Unit test for constructor of class Exclude
def test_Exclude():
    excludes=Exclude()
    assert includes.ALWAYS==True
    assert includes.NEVER==False
    # assert includes.None==False
    # assert includes.NULL==False
    # assert includes.MISSING==False
    # assert includes.DEFAULT==False


# Generated at 2022-06-23 16:40:08.299308
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test")

# Generated at 2022-06-23 16:40:12.122435
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():

    with pytest.raises(TypeError):
        global_config = _GlobalConfig()
        assert global_config.encoders == {}
        assert global_config.decoders == {}
        assert global_config.mm_fields == {}
        # assert global_config.json_module == json


# Generated at 2022-06-23 16:40:16.847093
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1.encoders == dict()
    assert global_config1.decoders == dict()
    assert global_config1.mm_fields == dict()

# Generated at 2022-06-23 16:40:18.773286
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
  global _GlobalConfig
  global _GlobalConfig_instance
  global_config = _GlobalConfig()
  _GlobalConfig_instance = global_config

test__GlobalConfig()

# Generated at 2022-06-23 16:40:20.428131
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config is not None


# Generated at 2022-06-23 16:40:21.838352
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(9))

# Generated at 2022-06-23 16:40:30.498646
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(encoder=1) == {'dataclasses_json': {'encoder': 1}}
    assert config(encoder=1, decoder=2) == {
        'dataclasses_json': {
            'encoder': 1,
            'decoder': 2,
        },
    }
    assert config(mm_field=1) == {'dataclasses_json': {'mm_field': 1}}
    assert config(mm_field=1, field_name='name') == {
        'dataclasses_json': {
            'mm_field': 1,
            'letter_case': lambda x: 'name',
        },
    }

# Generated at 2022-06-23 16:40:34.476246
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:40:35.578993
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False

# Generated at 2022-06-23 16:40:37.844980
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('string') == False


# Generated at 2022-06-23 16:40:46.655173
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    """
    Test the constructor of '_GlobalConfig'.
    :return:
    """
    # output: {'dataclasses_json': {'encoder': <function test at 0x7f8b9289bb70>, 'decoder': <function test at 0x7f8b9289bc80>}}
    config(encoder=test, decoder=test)
    # output: {'dataclasses_json': {'exclude': <function test at 0x7f8b9289bc80>}}
    config(exclude=test)

    # output: {'dataclasses_json': {'encoder': <function test at 0x7f8b9289bb70>}}
    config(encoder=test)
    # output: {'dataclasses_json': {'encoder': <function test at 0x7

# Generated at 2022-06-23 16:40:49.197734
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:40:51.177638
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)


# Generated at 2022-06-23 16:40:57.031236
# Unit test for function config
def test_config():
    @dataclass
    @config(mm_field=int)
    class Test:
        attr: int

    assert Test(attr=5).attr == 5
    assert Test(attr=5)._config['mm_field'] == int



# Generated at 2022-06-23 16:41:02.301529
# Unit test for function config
def test_config():
    @config(field_name="a")
    class A:
        pass
    assert A.__dataclasses_json__["field_name"]("a") == "a"

    @config(letter_case=lambda s: s.upper())
    class A:
        pass

    assert A.__dataclasses_json__["letter_case"]("a") == "A"

    @config(undefined=Undefined.EXCLUDE)
    class A:
        pass

    assert not A.__dataclasses_json__["undefined"]

# Generated at 2022-06-23 16:41:04.938466
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:41:07.096346
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == True
    assert Exclude.NEVER(1) == True
    assert Exclude.NEVER(2) == True

# Generated at 2022-06-23 16:41:09.274203
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class A:
        pass
    assert Exclude.NEVER(A())


# Generated at 2022-06-23 16:41:12.810405
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    import dataclasses_json
    @dataclasses.dataclass
    @dataclasses_json.config(exclude=Exclude.ALWAYS)
    class Point:
        x: int
        y: int
    p = Point(1,2)
    assert dataclasses_json.dump(p) == "{}"

# Generated at 2022-06-23 16:41:18.115346
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(None) is True

    assert Exclude.NEVER(0) is False
    assert Exclude.NEVER(None) is False



# Generated at 2022-06-23 16:41:20.051730
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER('')


# Generated at 2022-06-23 16:41:21.603198
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(Undefined)


# Generated at 2022-06-23 16:41:31.355022
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(-1) == True
    assert Exclude.ALWAYS(100) == True
    assert Exclude.ALWAYS(-1000) == True
    assert Exclude.ALWAYS(0.0001) == True

    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(100) == False
    assert Exclude.NEVER(-1000) == False
    assert Exclude.NEVER(0.0001) == False

test_Exclude()

# Generated at 2022-06-23 16:41:33.149454
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert global_config_.encoders == {}
    assert global_config_.decoders == {}
    assert global_config_.mm_fields == {}

# Generated at 2022-06-23 16:41:44.612875
# Unit test for function config
def test_config():
    metadata = {}
    assert metadata == {
        'name1': {
            'encoder': 'encoder',
            'decoder': 'decoder',
            'mm_field': 'mm_field',
            'letter_case': 'letter_case',
            'undefined': 'undefined',
            'exclude': 'exclude',
        },
        'dataclasses_json': {
            'encoder': 'encoder',
            'decoder': 'decoder',
            'mm_field': 'mm_field',
            'letter_case': 'letter_case',
            'undefined': 'undefined',
            'exclude': 'exclude',
        }
    }


# Generated at 2022-06-23 16:41:51.011522
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS('0') == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS({}) == True


# Generated at 2022-06-23 16:41:53.244340
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True



# Generated at 2022-06-23 16:41:56.001764
# Unit test for function config
def test_config():
    @dataclass
    class MyDataClass:
        my_field: int

        class Meta:
            unknown = config(exclude=Exclude.ALWAYS)


# Generated at 2022-06-23 16:41:59.040397
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    data = _GlobalConfig()
    assert data.encoders=={}
    assert data.decoders=={}
    assert data.mm_fields=={}


# Generated at 2022-06-23 16:42:01.151444
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Callable
    assert Exclude.ALWAYS
    assert Exclude.NEVER


# Generated at 2022-06-23 16:42:06.592557
# Unit test for constructor of class Exclude
def test_Exclude():
    tExclude=Exclude()
    if (tExclude.ALWAYS("0") ==tExclude.NEVER("0")):
        print("Unit test for Exclude failed")
    else:
        print("Unit test for Exclude suceeded")

# Main function that runs unit test for constructor of class Exclude
if __name__== "__main__":
    test_Exclude()

# Generated at 2022-06-23 16:42:13.877563
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(False) is False
    assert Exclude.NEVER(1.0) is False
    assert Exclude.NEVER(1.0j) is False
    assert Exclude.NEVER(1e100) is False
    assert Exclude.NEVER('a') is False
    assert Exclude.NEVER(['a']) is False
    assert Exclude.NEVER(('a',)) is False
    assert Exclude.NEVER({'a': 1}) is False
    assert Exclude.NEVER(object()) is False
    assert Exclude.NEVER(object) is False


# Generated at 2022-06-23 16:42:16.281489
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('anything') == True


# Generated at 2022-06-23 16:42:26.282396
# Unit test for function config
def test_config():
    from dataclasses import dataclass, fields, is_dataclass
    from typing import Any, Dict
    from marshmallow import fields as mm_fields
    from unittest import TestCase

    @dataclass
    class SomeDataClass:
        to_remove: str = 'remove'
        to_keep: str = 'keep'

    class SomeTestConfig(TestCase):
        def setUp(self):
            self.dc = SomeDataClass()

        def test_in_model(self):
            self.assertTrue(is_dataclass(self.dc))
            self.assertEqual({f.name for f in fields(self.dc)},
                             {'to_remove', 'to_keep'})

            # Test that the 'to_remove' field is removed

# Generated at 2022-06-23 16:42:28.570430
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-23 16:42:30.658099
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude()
    assert (obj.NEVER(0) == False)


# Generated at 2022-06-23 16:42:36.073307
# Unit test for function config
def test_config():
    assert config(
        encoder=str.upper,
        decoder=str.lower,
        mm_field=MarshmallowField(),
        letter_case=str.swapcase,
        undefined=Undefined.EXCLUDE,
        exclude=Exclude.NEVER
    ) == {
        'dataclasses_json': {
            'encoder': str.upper,
            'decoder': str.lower,
            'mm_field': MarshmallowField(),
            'letter_case': str.swapcase,
            'undefined': Undefined.EXCLUDE,
            'exclude': Exclude.NEVER
        }
    }

# Generated at 2022-06-23 16:42:40.258608
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert(len(gc.encoders.keys()) == 0)
    assert(len(gc.decoders.keys()) == 0)
    assert(len(gc.mm_fields.keys()) == 0)

# Generated at 2022-06-23 16:42:43.289819
# Unit test for constructor of class Exclude
def test_Exclude():
    obj1 = Exclude()
    assert obj1.ALWAYS is not None
    obj2 = Exclude()
    assert obj2.NEVER is not None
    assert obj1 == obj2

# Generated at 2022-06-23 16:42:48.885537
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config, _GlobalConfig)
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)

# Generated at 2022-06-23 16:42:50.804049
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:42:52.416517
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    testobject = Exclude()
    testobject.NEVER(5)

# Generated at 2022-06-23 16:42:54.206140
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("a") == True
    assert Exclude.NEVER("b") == False

# Generated at 2022-06-23 16:42:55.141298
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not(Exclude.NEVER(1))

# Generated at 2022-06-23 16:43:01.817123
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0
    # assert global_config.json_module.__name__ == json.__name__
    # global_config.json_module = simplejson
    # assert global_config.json_module.__name__ == simplejson.__name__


# Generated at 2022-06-23 16:43:03.309421
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)



# Generated at 2022-06-23 16:43:08.018042
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:43:12.599399
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config1 = _GlobalConfig()
    encoders = config1.encoders
    decoders = config1.decoders
    mm_fields = config1.mm_fields
    assert encoders == {}
    assert decoders == {}
    assert mm_fields == {}


# Generated at 2022-06-23 16:43:13.939868
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()

# Generated at 2022-06-23 16:43:17.972986
# Unit test for function config
def test_config():
    import pytest

    def assert_config_results(input_data, expected_results):
        # assert expected_results.items() <= config(input_data).items()

        for attr, value in expected_results.items():
            # assert value == config(input_data).get(attr, None), \
            #     f"Config value {attr} did not match expected, got {value} instead of {config(input_data).get(attr, None)}"
            assert config(input_data).get(attr, None) == value

        assert len(expected_results) == len(config(input_data)), \
            f"Config value length did not match expected, got {len(expected_results)} instead of {len(config(input_data))}"

    assert_config_results(metadata={}, expected_results={})
    assert_config_

# Generated at 2022-06-23 16:43:20.666916
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("r") == True


# Generated at 2022-06-23 16:43:28.173365
# Unit test for function config
def test_config():
    metadata = config(encoder="dataclasses_json.encoder.Encoder",
                     decoder="dataclasses_json.decoder.Decoder",
                     mm_field="dataclasses_json.mm.MarshmallowField",
                     field_name="field_name",
                     letter_case="letter_case",
                     undefined="EXCLUDE",
                     exclude=Exclude.ALWAYS
                     )
    assert metadata['dataclasses_json']['encoder'] == "dataclasses_json.encoder.Encoder"
    assert metadata['dataclasses_json']['decoder'] == "dataclasses_json.decoder.Decoder"
    assert metadata['dataclasses_json']['mm_field'] == "dataclasses_json.mm.MarshmallowField"

# Generated at 2022-06-23 16:43:37.401721
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    import pytest

    @dataclass
    class Cfg:
        test: str = 'test'

    @config(field_name='test')
    @dataclass
    class FieldName:
        test: str = 'test'

    @config(field_name=config(field_name='test'))
    @dataclass
    class FieldNameFunc:
        test: str = 'test'

    @config(field_name=lambda fld: fld)
    @dataclass
    class FieldNameLambda:
        test: str = 'test'

    @config(field_name='test', letter_case='title')
    @dataclass
    class LetterCase:
        test: str = 'test'


# Generated at 2022-06-23 16:43:38.884192
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert bool(g.encoders) == False
    assert bool(g.decoders) == False
    assert bool(g.mm_fields) == False


# Generated at 2022-06-23 16:43:43.944846
# Unit test for function config
def test_config():
    @config(encoder=encode, decoder=decode)
    @dataclass
    class A:
        att: int = 1

    a = A()
    assert dataclasses_json.encode_instance(a) == '{"att": 1}'
    assert dataclasses_json.decode_instance(A, '{"att": 1}') == a



# Generated at 2022-06-23 16:43:44.857714
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)

# Generated at 2022-06-23 16:43:46.075200
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("foo") is True


# Generated at 2022-06-23 16:43:49.422327
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)



# Generated at 2022-06-23 16:43:51.822011
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    c.encoders
    c.decoders
    c.mm_fields
    # c._json_module

# Generated at 2022-06-23 16:43:52.295050
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is callable

# Generated at 2022-06-23 16:44:03.682379
# Unit test for function config
def test_config():
    class Model:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    class Encoder:
        @staticmethod
        def encode(value):
            return value

    class Decoder:
        @staticmethod
        def decode(value):
            return value.upper()

    class MMField(MarshmallowField):
        def _serialize(self, value, attr, obj, **kwargs):
            return value

        def _deserialize(self, value, attr, data, **kwargs):
            return value

    assert config() == {}

    encoder = Encoder()
    decoder = Decoder()
    mm_field = MMField()
    assert config(encoder=encoder) == {'dataclasses_json': {'encoder': encoder}}

# Generated at 2022-06-23 16:44:05.715556
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    excluded = False
    def test(x):
        return x

    excluded = Exclude.NEVER(test)

    return excluded

# Generated at 2022-06-23 16:44:09.148695
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config._json_module == json



# Generated at 2022-06-23 16:44:19.536394
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    import dataclasses_json

    # Test for config with some key but one value for each key
    @dataclass
    @dataclasses_json.config(
        encoder={'name': 'encoder'},
        decoder={'name': 'decoder'},
        mm_field={'name': fields.String()},
        letter_case={'name': 'snake_case'},
        undefined={'name': 'RAISE'},
        field_name={'name': 'name'},
        exclude={'name': dataclasses_json.Exclude.ALWAYS},
        )
    class TestConfig:
        name: str

    assert TestConfig.__dataclass_json__.encoder == {'name': 'encoder'}

# Generated at 2022-06-23 16:44:20.962198
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
