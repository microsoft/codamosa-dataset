

# Generated at 2022-06-23 16:34:23.693285
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude1 = Exclude()

# Generated at 2022-06-23 16:34:25.132295
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()


# Generated at 2022-06-23 16:34:33.973311
# Unit test for function config
def test_config():
    """
    Unit test for function config
    """
    # the parameters we will pass to the function config
    # with 'encoder' set to a dummy encoder
    # and 'decoder' set to a dummy decoder
    test_metadata = {
        'dataclasses_json': {
            'encoder': 'dummy_encoder',
            'decoder': 'dummy_decoder'
        }
    }
    config(metadata = test_metadata, encoder = None, decoder = None, letter_case = None, undefined = None, exclude = None, field_name = None)
    # check that config worked as expected

# Generated at 2022-06-23 16:34:37.182763
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER("qwerty") == False
    print("[test_Exclude_NEVER] OK")



# Generated at 2022-06-23 16:34:41.250142
# Unit test for function config
def test_config():
    @dataclass
    @config(letter_case=lambda s: s.upper())
    class A:
        foo: str

    assert A("aa").json() == '{"FOO": "aa"}'

# Generated at 2022-06-23 16:34:43.358616
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders
    assert global_config.decoders
    assert global_config.mm_fields


# Generated at 2022-06-23 16:34:46.025509
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    exclude = Exclude.NEVER
    assert exclude("")
    assert exclude("true")
    assert exclude("false")
    assert exclude("NULL")
    assert exclude("None")
    assert exclude("none")

# Generated at 2022-06-23 16:34:47.659124
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a') == True
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:34:48.833775
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    a = []
    assert Exclude.ALWAYS(a) == True


# Generated at 2022-06-23 16:34:50.559545
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-23 16:34:51.143610
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    pass

# Generated at 2022-06-23 16:34:53.038080
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('any') == True
    # assert Exclude.ALWAYS(6) == True


# Generated at 2022-06-23 16:34:54.719458
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) is True
    assert Exclude.ALWAYS('test') is True



# Generated at 2022-06-23 16:34:57.351862
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-23 16:34:59.779512
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    l=Exclude()
    assert l.ALWAYS(True)==True
    assert l.ALWAYS(False)==True


# Generated at 2022-06-23 16:35:00.418707
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:35:07.629703
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    @config(encoder=repr, decoder=int, mm_field=int)
    class Number:
        value: int

    assert Number.__dataclass_json__['encoder'] is repr
    assert Number.__dataclass_json__['decoder'] is int
    assert Number.__dataclass_json__['mm_field'] is int

# Generated at 2022-06-23 16:35:16.178503
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('1')
    assert Exclude.ALWAYS(None)

    test_dict = {
        'a': 1,
        'b': 2,
        'c': 42,
        'd': None,
        'e': '100'
    }

    assert Exclude.ALWAYS(test_dict)


# Generated at 2022-06-23 16:35:17.090481
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-23 16:35:18.263365
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:35:27.329520
# Unit test for function config
def test_config():
    assert {
        'dataclasses_json': {
            'encoder': encoder,
            'decoder': decoder,
            'mm_field': mm_field,
            'letter_case': letter_case,
            'undefined': undefined,
            'exclude': exclude,
    }} == config(
        encoder=encoder,
        decoder=decoder,
        mm_field=mm_field,
        letter_case=letter_case,
        undefined=undefined,
        exclude=exclude,
    )


# Generated at 2022-06-23 16:35:30.197401
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)
# test__GlobalConfig()


# Generated at 2022-06-23 16:35:34.585128
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-23 16:35:44.343028
# Unit test for function config
def test_config():
    from marshmallow import fields

    @config(metadata={}, encoder=bytes)
    @dataclass
    class D:
        i: int

    @config(metadata={}, decoder=int)
    @dataclass
    class D:
        i: str

    @config(metadata={}, mm_field=fields.String)
    @dataclass
    class D:
        i: str

    @config(metadata={}, mm_field=fields.String)
    @dataclass
    class D:
        i: int

    @config(metadata={}, field_name="i")
    @dataclass
    class D:
        i: int

    @config(metadata={}, letter_case=lambda x: x.lower())
    @dataclass
    class D:
        i: int


# Generated at 2022-06-23 16:35:45.814122
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("I don't care")



# Generated at 2022-06-23 16:35:47.782970
# Unit test for constructor of class Exclude
def test_Exclude():
    assert ((Exclude.ALWAYS(2), Exclude.NEVER(2)) == (True, False))


# Generated at 2022-06-23 16:35:49.419979
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True
    

# Generated at 2022-06-23 16:35:51.660413
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    value = Exclude.ALWAYS('anything')
    assert value == True



# Generated at 2022-06-23 16:35:53.660720
# Unit test for constructor of class Exclude
def test_Exclude():
  assert Exclude.ALWAYS(None) == True
  assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:35:58.469416
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude_1 = Exclude()
    exclude_2 = Exclude()
    assert type(exclude_1) == type(exclude_2)
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER == False
    assert Exclude.ALWAYS == True

# Generated at 2022-06-23 16:36:00.148897
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-23 16:36:03.259433
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:36:04.524633
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = 1
    assert Exclude.NEVER(a)


# Generated at 2022-06-23 16:36:16.637643
# Unit test for function config
def test_config():
    from .api import config
    from .undefined import Undefined

    # Define a callback function to test
    def _callback(self):
        return self
    # Self-reference for the callback
    callback = _callback

    # Test for the default metadata
    metadata = config()
    assert dataclasses_json.is_config(metadata) is True

    # Test for metadata changes
    metadata = config(metadata, encoder=callback, decoder=callback,
                      mm_field=callback, letter_case=callback,
                      undefined=Undefined.RAISE, exclude=callback,
                      field_name="field_name")
    assert dataclasses_json.is_config(metadata) is True

    # TODO: add a test for internal re-wrapping

    # Test for a bad undefined parameter

# Generated at 2022-06-23 16:36:26.940483
# Unit test for function config
def test_config():
    config_key = 'dataclasses_json'
    encoder = lambda: 2
    decoder = lambda: 2
    mm_field = lambda: 2
    letter_case = lambda: 2
    undefined = Undefined.RAISE
    field_name = "field_name"
    exclude = Exclude.NEVER
    metadata = config(encoder=encoder, decoder=decoder,
                      mm_field=mm_field, letter_case=letter_case,
                      undefined=undefined, field_name=field_name,
                      exclude=exclude)
    assert isinstance(metadata, dict)
    assert config_key in metadata
    assert metadata[config_key]['encoder'] == encoder
    assert metadata[config_key]['decoder'] == decoder
    assert metadata[config_key]['mm_field'] == mm

# Generated at 2022-06-23 16:36:27.803198
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-23 16:36:29.486156
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-23 16:36:40.460437
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined, UndefinedParameterError
    import pytest
    valid_actions = list(action.name for action in Undefined)

    valid_config = config(exclude=False, encoder="encode", decoder="decode", mm_field="mm_field")
    assert 'dataclasses_json' in valid_config
    lib_valid_config = valid_config['dataclasses_json']
    assert 'exclude' in lib_valid_config
    assert lib_valid_config['exclude'] is False
    assert 'encoder' in lib_valid_config
    assert lib_valid_config['encoder'] == "encode"
    assert 'decoder' in lib_valid_config
    assert lib_valid_

# Generated at 2022-06-23 16:36:41.292891
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-23 16:36:42.787205
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    pass


# Generated at 2022-06-23 16:36:50.145202
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass

    @dataclass
    class ExcludeDC:
        e1: int
        e2: float = None
        e3: str = 'NEVER'
        e4: bool = True

    data = {'e1': 10, 'e2': 3.14159265359}

    # If function NEVER is used, it must exclude all fields, not only
    # the last.
    json = dataclass_json.dumps(ExcludeDC(**data),
                                config=dataclass_json.config(
                                    exclude=Exclude.NEVER))
    assert json == '{}'


# Generated at 2022-06-23 16:36:52.360853
# Unit test for constructor of class Exclude
def test_Exclude():
    x = Exclude.ALWAYS('Test')
    assert x is True
    y = Exclude.NEVER('Test')
    assert y is False

# Generated at 2022-06-23 16:36:53.648171
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:36:57.515991
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert (global_config.encoders,global_config.decoders,global_config.mm_fields) == ({},{},{})
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:37:00.343759
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") is True
    assert Exclude.NEVER(1) is True


# Generated at 2022-06-23 16:37:06.424066
# Unit test for function config
def test_config():
    metadata = config(
        field_name='TEST',
        letter_case=lambda x: x.title(),
        undefined=Undefined.STRICT
    )
    assert metadata["dataclasses_json"] == {
        "field_name": "TEST",
        "letter_case": lambda x: x.title(),
        "undefined": Undefined.STRICT
    }

# Generated at 2022-06-23 16:37:09.866834
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert(global_config1.encoders == {})
    assert(global_config1.decoders == {})
    assert(global_config1.mm_fields == {})


# Generated at 2022-06-23 16:37:11.669796
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class MyClass:
        pass
    my_class = MyClass()
    assert Exclude.NEVER(my_class)

# Generated at 2022-06-23 16:37:15.057996
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(bool) == True
    assert Exclude.ALWAYS('string') == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2.2) == True


# Generated at 2022-06-23 16:37:25.217455
# Unit test for function config
def test_config():
    from marshmallow import fields
    import datetime

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class ExcludeAlways:
        param: str

    assert ExcludeAlways.__config__()['exclude'] == Exclude.ALWAYS

    @config(field_name='this_name')
    @dataclass
    class FieldName:
        param: str

    assert FieldName.__config__()['field_name'] == 'this_name'

    @config(field_name='this_name', letter_case=str.upper)
    @dataclass
    class FieldNameUpper:
        param: str

    assert FieldNameUpper.__config__()['field_name'] == 'this_name'


# Generated at 2022-06-23 16:37:27.560385
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(10))
    print(Exclude.NEVER('100'))


# Generated at 2022-06-23 16:37:29.172882
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('Whatever') is True


# Generated at 2022-06-23 16:37:33.603556
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS(...)

test_Exclude_ALWAYS()


# Generated at 2022-06-23 16:37:34.940920
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:37:41.347591
# Unit test for function config
def test_config():
    import pytest
    from dataclasses import dataclass

    @dataclass
    class TestData:

        field: str = "default value"

    @dataclass
    class TestData2:

        field: str = "default value"

    @dataclass
    class TestData3:

        field: str = "default value"

    with pytest.raises(UndefinedParameterError):
        config(undefined='non_existing')

    with pytest.raises(UndefinedParameterError):
        config(undefined=Undefined.RAISE)

    TestData = config(undefined=Undefined.EXCLUDE)(TestData)
    assert TestData.__dataclass_json__.undefined == Undefined.EXCLUDE
    TestData2 = config(undefined='exclude')(TestData2)


# Generated at 2022-06-23 16:37:43.632548
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:37:45.533707
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) is True


# Generated at 2022-06-23 16:37:47.657149
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a string") == False


# Generated at 2022-06-23 16:37:53.809171
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {"a":1}
    global_config.decoders = {"b":1}
    global_config.mm_fields = {"c":1}
    # global_config.json_module = None
    assert global_config.encoders == {"a":1}
    assert global_config.decoders == {"b":1}
    assert global_config.mm_fields == {"c":1}
    # assert global_config.json_module == None


# Generated at 2022-06-23 16:37:55.113921
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(_GlobalConfig(), _GlobalConfig)


# Generated at 2022-06-23 16:37:58.685501
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    assert global_config._json_module == json


# Generated at 2022-06-23 16:38:00.106045
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS(None) == True)
    assert (Exclude.NEVER(None) == False)

# Generated at 2022-06-23 16:38:02.369778
# Unit test for constructor of class Exclude
def test_Exclude():
    assert type(Exclude.ALWAYS) is type(lambda x: True)
    assert type(Exclude.NEVER) is type(lambda x: False)

# Generated at 2022-06-23 16:38:11.866630
# Unit test for function config
def test_config():
    from marshmallow import Schema, fields
    from dataclasses import dataclass, field

    class UpperLowerSchema(Schema):
        upper = fields.Str()
        lower = fields.Str()

    test_schema = UpperLowerSchema()


# Generated at 2022-06-23 16:38:13.154937
# Unit test for constructor of class Exclude
def test_Exclude():
    return None

# Generated at 2022-06-23 16:38:19.541878
# Unit test for function config
def test_config():
    import pytest

    with pytest.raises(UndefinedParameterError):
        @dataclass
        @config(undefined="foo")
        class Foo:
            x: Optional[str] = None

    @dataclass
    @config(undefined="ignore")
    class Foo:
        x: Optional[str] = None

    assert Foo.schema().declared_fields["x"].missing == Undefined.IGNORE

# Generated at 2022-06-23 16:38:21.379810
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-23 16:38:26.730926
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    global_config.encoders = {int: lambda x: "int"}
    global_config.decoders = {int: lambda x: "int"}
    global_config.mm_fields = {int: lambda x: "int"}
    assert global_config.encoders == {int: lambda x: "int"}
    assert global_config.decoders == {int: lambda x: "int"}
    assert global_config.mm_fields == {int: lambda x: "int"}

# Generated at 2022-06-23 16:38:34.291038
# Unit test for function config
def test_config():
    metadata = config(
        field_name='bob',
        undefined='error',
        letter_case=lambda x: x.upper(),
        exclude=lambda field: field.name == 'foo'
    )
    assert metadata['dataclasses_json']['encoder'] is None
    assert metadata['dataclasses_json']['decoder'] is None
    assert metadata['dataclasses_json']['mm_field'] is None
    assert metadata['dataclasses_json']['undefined'] == Undefined.ERROR
    assert metadata['dataclasses_json']['letter_case']("test") == "test".upper()


# Generated at 2022-06-23 16:38:35.588242
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:38:38.520131
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:38:40.665490
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}
    # assert config.json_module == json

test__GlobalConfig()


# Generated at 2022-06-23 16:38:50.178171
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    metadata = {'dataclasses_json': {'encoder': 0, 'decoder': 0,
                                     'mm_field': 0, 'letter_case': 0,
                                     'undefined': 0, 'exclude': 0}}

# Generated at 2022-06-23 16:38:59.792451
# Unit test for function config
def test_config():
    import dataclasses
    from marshmallow import fields as mm_fields

    @config()
    @dataclasses.dataclass
    class Test:
        a: int

    assert Test.__metadata__ == {
        'dataclasses_json': {},
    }

    @config(ensure_ascii=False,
            encoder=lambda x: "encoded",
            decoder=lambda y: "decoded",
            mm_field=mm_fields.Integer(),
            letter_case=lambda x: x.upper(),
            undefined=Undefined.EXCLUDE,
            field_name="a",
            exclude=Exclude.ALWAYS,
            )
    @dataclasses.dataclass
    class Test:
        a: int


# Generated at 2022-06-23 16:39:01.643975
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('abc') == True


# Generated at 2022-06-23 16:39:11.645563
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses import dataclass

    @config(encoder=lambda x: x)
    @dataclass
    class Example:
        x: int

    assert global_config.encoders[Example] == Example.__dataclass_json__.encoder

    @config(decoder=lambda x: x)
    @dataclass
    class Example:
        x: int

    assert global_config.decoders[Example] == Example.__dataclass_json__.decoder

    @config(mm_field=fields.Int)
    @dataclass
    class Example:
        x: int

    assert global_config.mm_fields[Example] == Example.__dataclass_json__.mm_field


# Generated at 2022-06-23 16:39:12.473299
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS(1))

# Generated at 2022-06-23 16:39:14.295403
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config, _GlobalConfig)

# Generated at 2022-06-23 16:39:15.582136
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("foo")==True

# Generated at 2022-06-23 16:39:16.479924
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("ABC") == False

# Generated at 2022-06-23 16:39:17.769519
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(1) is False

# Generated at 2022-06-23 16:39:19.783191
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    e = Exclude()
    assert e.NEVER('a') == False


# Generated at 2022-06-23 16:39:29.023589
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Data:
        a: str

    assert config() == {'dataclasses_json': {}}
    assert config(metadata={}, mm_field=int) == {
        'dataclasses_json': {'mm_field': int}
    }
    with pytest.raises(UndefinedParameterError):
        config(undefined='invalid')

    ctrl = config(undefined=Undefined.RAISE)
    _ = Data(a='b')
    assert Data.__annotations__ == {'a': str}
    Data = dataclass(frozen=True, metadata=ctrl)(Data)
    with pytest.raises(UndefinedParameterError):
        Data(a='b')
    config(undefined=Undefined.EXCLUDE)

# Generated at 2022-06-23 16:39:31.357146
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS.__name__ == '<lambda>'
    assert Exclude.NEVER.__name__ == '<lambda>'



# Generated at 2022-06-23 16:39:37.644450
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {}
    global_config.decoders = {}
    global_config.mm_fields = {}
    # global_config._json_module = json

    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config._json_module == json


# Generated at 2022-06-23 16:39:39.097609
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:39:42.191579
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(False) is False



# Generated at 2022-06-23 16:39:45.189586
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.json_module = json


if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-23 16:39:46.973857
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("String") == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-23 16:39:51.358702
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from collections import namedtuple
    import marshmallow

    # for module-level tests, we need to reset the encoders
    global_config.encoders.clear()

    @dataclass
    class M:
        i: int = config()
        s: str = config(encoder=lambda x: x)

    def test_encoder(value, key, config, **kwargs):
        return value

    @dataclass
    class N:
        i: int = config(encoder=test_encoder)
        s: str = config(encoder=lambda x: x, field_name='s',
                        letter_case="lower")


# Generated at 2022-06-23 16:39:53.598771
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") is False


# Generated at 2022-06-23 16:39:55.525979
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER("test") == True)


# Generated at 2022-06-23 16:39:57.425391
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(None)

# Generated at 2022-06-23 16:39:58.827030
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)


# Generated at 2022-06-23 16:40:01.360772
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:40:07.940555
# Unit test for function config
def test_config():
    import dataclasses
    from marshmallow import fields

    @dataclasses.dataclass
    @config(field_name='MyInt',
            encoder=int,
            decoder=float,
            mm_field=fields.Int(),
            letter_case='pascal',
            undefined=Undefined.EXCLUDE,
            exclude=Exclude.ALWAYS,
            )
    class _Test:
        my_int: int

    assert _Test.__json_metadata__['dataclasses_json']['field_name'] == 'MyInt'
    assert _Test.__json_metadata__['dataclasses_json']['encoder'] == int
    assert _Test.__json_metadata__['dataclasses_json']['decoder'] == float

# Generated at 2022-06-23 16:40:09.397780
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-23 16:40:14.119608
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(123)
    assert Exclude.ALWAYS('test')

# Generated at 2022-06-23 16:40:17.512765
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Unit test for method NEVER of class Exclude")
    NEVER = Exclude.NEVER
    assert NEVER('s') == False


# Generated at 2022-06-23 16:40:19.013708
# Unit test for constructor of class Exclude
def test_Exclude():
    print(Exclude)


# Generated at 2022-06-23 16:40:20.613955
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER('abcd') is False
    assert Exclude.ALWAYS('abcd') is True

# Generated at 2022-06-23 16:40:24.346611
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:40:30.921030
# Unit test for function config
def test_config():
    @dataclass_json
    @dataclass
    class TestClass:
        int_field: int = config(encoder=lambda x: x + 1)

    tc = TestClass(1)
    assert tc.to_json() == '2'
    assert TestClass.from_json('1') == tc
    assert TestClass.from_json('2') == TestClass(2)

# Generated at 2022-06-23 16:40:33.016818
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-23 16:40:34.009554
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:40:43.109125
# Unit test for function config
def test_config():
    config(undefined='error')
    assert config(undefined='strict') == {'dataclasses_json': {'undefined': Undefined.STRICT}}
    assert config(undefined='silent') == {'dataclasses_json': {'undefined': Undefined.SILENT}}
    assert config(undefined='ignore') == {'dataclasses_json': {'undefined': Undefined.IGNORE}}
    assert config(undefined='raise') == {'dataclasses_json': {'undefined': Undefined.RAISE}}
    assert config(undefined='exception') == {'dataclasses_json': {'undefined': Undefined.EXCEPTION}}

# Generated at 2022-06-23 16:40:46.188109
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:40:52.080399
# Unit test for function config
def test_config():
    @dataclass
    @config(undefined=lambda obj: "foo")
    class Foo:
        a: int
        b: str
    # TODO: this should work
    # assert Foo.__dataclass_json__['undefined'] == "foo"
    assert Foo.__dataclass_json__['undefined']() == "foo"

# Generated at 2022-06-23 16:40:53.115513
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:40:55.097534
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-23 16:40:58.912679
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-23 16:41:01.304594
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def test_func(t: Exclude.ALWAYS):
        assert Exclude.ALWAYS == True
    test_func


# Generated at 2022-06-23 16:41:06.424507
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:41:07.750954
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)


# Generated at 2022-06-23 16:41:09.900873
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-23 16:41:14.357477
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        field_1: str = config(letter_case=lambda s: s.upper())

    assert Foo.__dataclass_fields__['field_1'].metadata == {
        'dataclasses_json': {
            'letter_case': lambda s: s.upper(),
        }
    }



# Generated at 2022-06-23 16:41:15.661129
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:41:17.560631
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:41:21.162775
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class A:
        pass
    a = A()
    actual = Exclude.NEVER(a)
    expected = False
    assert actual == expected


# Generated at 2022-06-23 16:41:25.097547
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.decoders is not None
    assert global_config.encoders is not None
    assert global_config.mm_fields is not None


# Generated at 2022-06-23 16:41:34.595044
# Unit test for function config
def test_config():
    md = config(field_name='foo_bar')
    assert md == {'dataclasses_json': {}}

    md = config(field_name='fooBar')
    assert md == {'dataclasses_json': {'letter_case': 'camel', 'field_name': 'fooBar'}}

    md = config(metadata=md, letter_case=lambda s: s + '_')
    assert md == {'dataclasses_json': {'letter_case': 'camel_', 'field_name': 'fooBar'}}

    md = config(metadata=md, exclude=True)
    assert md == {'dataclasses_json': {'letter_case': 'camel_', 'field_name': 'fooBar', 'exclude': True}}

    md = config(metadata=md, undefined='ignore')
   

# Generated at 2022-06-23 16:41:45.411028
# Unit test for function config
def test_config():
    from marshmallow import fields

    class CustomField(fields.Field):
        pass

    class Class:
        field_name = "field_name"

    @dataclass
    class Config:
        def __init__(self, encoder: Callable,
                     decoder: Callable,
                     mm_field: CustomField,
                     field_name: int,
                     exclude: Callable,
                     undefined: str,
                     letter_case: int,
                     cls: Optional[Type[Class]] = None):
            pass

    _ = config(Config,
               encoder=lambda: None,
               decoder=lambda: None,
               mm_field=CustomField,
               field_name=1,
               exclude=lambda: None,
               undefined="default",
               letter_case=1)

# Generated at 2022-06-23 16:41:50.166765
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1.encoders == {}
    assert global_config1.decoders == {}
    assert global_config1.mm_fields == {}
    # assert global_config1._json_module == json

    # global_config1.json_module = json


# Generated at 2022-06-23 16:41:54.578210
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders is not None
    assert global_config.decoders is not None
    assert global_config.mm_fields is not None

# Generated at 2022-06-23 16:41:56.302908
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:41:57.550339
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False

# Generated at 2022-06-23 16:42:01.368146
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("non-empty string") == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:42:02.972150
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-23 16:42:04.304732
# Unit test for constructor of class Exclude
def test_Exclude():
    exc = Exclude()

# Generated at 2022-06-23 16:42:06.510805
# Unit test for constructor of class Exclude

# Generated at 2022-06-23 16:42:07.717822
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("abcde")


# Generated at 2022-06-23 16:42:09.049360
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:42:14.422599
# Unit test for function config
def test_config():
    """
    Test that config is as expected
    """
    metadata = config(
        encoder='encoder',
        decoder='decoder',
        mm_field='mm_field',
        letter_case='letter_case',
        undefined='undefined',
        exclude='exclude',
    )
    assert metadata == {
        'dataclasses_json': {
            'encoder': 'encoder',
            'decoder': 'decoder',
            'mm_field': 'mm_field',
            'letter_case': 'letter_case',
            'undefined': 'undefined',
            'exclude': 'exclude'
        }
    }

# Generated at 2022-06-23 16:42:15.574229
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:42:25.937476
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields, Schema

    @dataclass
    class MyDataclass:
        field: str = "abc"
        field2: int = 123

    @dataclass
    class MyDataclass2:
        field: str = "def"
        field2: int = 456

        class Meta:
            dataclass_json = config(field_name="field2", encoder=lambda x: x * x)

    # Testing metadata depending on decorator
    assert MyDataclass.__dataclass_json__() == {
        'field': 'abc',
        'field2': 123
    }

    assert MyDataclass2.__dataclass_json__() == {
        'field': 'def',
        'field2': 456
    }



# Generated at 2022-06-23 16:42:27.592644
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True


# Generated at 2022-06-23 16:42:29.544566
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:42:31.136044
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:42:34.245591
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    c = _GlobalConfig()
    assert c.encoders == {}
    assert c.decoders == {}
    assert c.mm_fields == {}
    assert c._json_module == json


# Generated at 2022-06-23 16:42:41.565798
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test(object):
        field_name: str

    global_config.encoders[Test] = str
    global_config.decoders[Test] = str
    global_config.mm_fields[Test] = str
    test_config = config(encoder=Test, decoder=Test, mm_field=Test)
    assert test_config == {'dataclasses_json': {'encoder': Test, 'decoder': Test,
                                                'mm_field': Test, 'undefined': Undefined.RAISE}}

    test_config = config(encoder=str)
    assert test_config['dataclasses_json']['encoder'] == str

    test_config = config(decoder=str)

# Generated at 2022-06-23 16:42:43.564806
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(10) == True
    assert Exclude.NEVER(10) == False

# Generated at 2022-06-23 16:42:47.830989
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class Example:
        x: int = config(undefined='exclude')
        y: int = config(undefined='raise')

    allow_none = (Example().x is None)
    with pytest.raises(UndefinedParameterError):
        Example().y

    assert allow_none


# Generated at 2022-06-23 16:42:49.807437
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert not Exclude.NEVER

# Generated at 2022-06-23 16:42:53.387806
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    import marshmallow
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json


# Generated at 2022-06-23 16:42:55.053138
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(1))
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:42:56.538645
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.NEVER(False) == False

# Generated at 2022-06-23 16:43:08.178927
# Unit test for function config
def test_config():
    from unittest import TestCase
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined

    class Test(TestCase):
        def test_defaults(self):
            @dataclass
            class MyClass:
                pass
            self.assertEqual(MyClass.__dataclass_fields__['config'], {})
            self.assertEqual(MyClass.__dataclass_fields__['config'].get('letter_case'), None)
            self.assertEqual(MyClass.__dataclass_fields__['config'].get('undefined'), Undefined.RAISE)


# Generated at 2022-06-23 16:43:12.736266
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config, _GlobalConfig)
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0


# Generated at 2022-06-23 16:43:16.013360
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module is json


# Generated at 2022-06-23 16:43:18.640704
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_ = _GlobalConfig()
    assert isinstance(global_config_.encoders, dict)
    assert isinstance(global_config_.decoders, dict)
    assert isinstance(global_config_.mm_fields, dict)


# Generated at 2022-06-23 16:43:19.879320
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert not Exclude.ALWAYS("TEST")


# Generated at 2022-06-23 16:43:21.970191
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    try:
        Exclude.NEVER(None)
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-23 16:43:33.089786
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Initialize an instance of _GlobalConfig
    global_config.__init__()

    # Check of attributes
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

    flag = False
    try:
        global_config.encoders = '123'
    except TypeError:
        flag = True
    assert flag
    flag = False
    try:
        global_config.decoders = '123'
    except TypeError:
        flag = True
    assert flag

    flag = False
    try:
        global_config.mm_fields = '123'
    except TypeError:
        flag = True
    assert flag


# Generated at 2022-06-23 16:43:41.460982
# Unit test for function config
def test_config():
    assert config(metadata={}, field_name='hello') == {
        'dataclasses_json': {'field_name': 'hello'}}
    class MyField(MarshmallowField):
        pass

    assert config(metadata={}, mm_field=MyField()) == {
        'dataclasses_json': {'mm_field': MyField()}}

# TODO: figure out how to make this work with dataclasses
# @config(field_name='hello')
# class Test:
#     pass
#
# assert Test.__dataclass_fields__['hello'].metadata == {'field_name': 'hello'}

# Generated at 2022-06-23 16:43:42.327150
# Unit test for function config
def test_config():
    assert config(encoder=str) == {'dataclasses_json': {'encoder': str}}

# Generated at 2022-06-23 16:43:43.989045
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
  global_config = _GlobalConfig()
  print(global_config.encoders)

# Generated at 2022-06-23 16:43:47.091072
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:43:48.961082
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert Exclude.NEVER(1) == False
	assert Exclude.NEVER('1') == False
	assert Exclude.NEVER([1,2]) == False


# Generated at 2022-06-23 16:43:50.994782
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    res = Exclude.NEVER(1)
    assert res == False
    print(res)



# Generated at 2022-06-23 16:43:54.788859
# Unit test for function config
def test_config():
    class Student:
        def __init__(self, id, name):
            self.id = id
            self.name = name
    # Student=config(Student)
    # print(Student)


if __name__ == '__main__':
    test_config()

# Generated at 2022-06-23 16:43:56.411091
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:43:59.929438
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    global_config2 = _GlobalConfig()
    assert global_config1.encoders == {}
    assert global_config2.decoders == {}

# Generated at 2022-06-23 16:44:03.140960
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER({})
    assert Exclude.NEVER({'hello': 'world'})
    assert Exclude.NEVER(['hello', 'world'])

# Generated at 2022-06-23 16:44:11.974277
# Unit test for function config
def test_config():
    from . example import User
    from marshmallow import Schema, fields

    class UserSchema(Schema):
        name = fields.Str()
        age = fields.Int()

    assert User.__metadata__ == {
        'dataclasses_json': {
            'encoder': None,
            'decoder': None,
            'mm_field': None,
            'letter_case': None,
            'undefined': Undefined.RAISE,
            'exclude': None,
        }
    }


# Generated at 2022-06-23 16:44:14.478253
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Exclude.NEVER(object) should return False
    assert(Exclude.NEVER(object) is False)



# Generated at 2022-06-23 16:44:20.124960
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert callable(Exclude.ALWAYS)
    assert Exclude.ALWAYS("var")
    assert Exclude.ALWAYS(100)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:44:23.834726
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(())
