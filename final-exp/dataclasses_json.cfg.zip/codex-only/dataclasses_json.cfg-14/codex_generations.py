

# Generated at 2022-06-23 16:34:30.151218
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    import pytest
    from marshmallow.fields import Int

    gc = _GlobalConfig()

    with pytest.raises(TypeError):
        gc.encoders = "test"
    with pytest.raises(TypeError):
        gc.encoders = 1

    gc.encoders = {}
    assert gc.encoders == {}

    with pytest.raises(TypeError):
        gc.decoders = "test"
    with pytest.raises(TypeError):
        gc.decoders = 1

    gc.decoders = {}
    assert gc.decoders == {}

    with pytest.raises(TypeError):
        gc.mm_fields = "test"
    with pytest.raises(TypeError):
        gc.mm_

# Generated at 2022-06-23 16:34:34.223791
# Unit test for constructor of class Exclude
def test_Exclude():
    ex_alw = Exclude.ALWAYS(10)
    assert ex_alw == True
    ex_nev = Exclude.NEVER(10)
    assert ex_nev == False

# Generated at 2022-06-23 16:34:40.203987
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(-0) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(0.1) == False
    assert Exclude.NEVER(-0.1) == False
    assert Exclude.NEVER("False") == False
    assert Exclude.NEVER(Exclude.NEVER) == False
    assert Exclude.NEVER(Exclude.ALWAYS) == False


# Generated at 2022-06-23 16:34:42.286840
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    f = Exclude.NEVER
    result = f(1)
    assert result is False
    assert isinstance(result, bool)


# Generated at 2022-06-23 16:34:51.190776
# Unit test for constructor of class Exclude
def test_Exclude():
    # This is used to test the class Exclude
    assert id(Exclude.ALWAYS) != id(Exclude.NEVER)
    assert callable(Exclude.ALWAYS) == True
    assert callable(Exclude.NEVER) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS('abc') == True
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER('abc') == False
    assert Exclude.ALWAYS.__name__ == '<lambda>'
    assert Exclude.NEVER.__name__ == '<lambda>'


if __name__ == "__main__":
    test_Exclude()

# Generated at 2022-06-23 16:34:57.412855
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class ConfigExample:
        simple: int
        exclude: str

    x = ConfigExample(
        simple=1,
        exclude=2,
    )

    y = dataclasses_json.config(exclude=Exclude.ALWAYS)(ConfigExample)(1, 2)
    assert x == y

# Generated at 2022-06-23 16:35:00.164797
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('Test')
    assert not Exclude.ALWAYS('Test') == True


# Generated at 2022-06-23 16:35:02.315974
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:35:12.739724
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from typing import Optional

    import pytest

    @dataclass
    class Person:
        name: str
        age: Optional[int] = None

    @dataclass
    class User:
        name: str
        age: Optional[int] = None

    # test: set global config
    global_config.encoders[Person] = lambda x: x.name
    global_config.decoders[Person] = lambda x: Person(name=x)
    global_config.mm_fields[Person] = lambda : None

    assert Person(name='Alice').to_json() == '"Alice"'
    assert Person.from_json('"Alice"') == Person(name='Alice')

    # test: override global config

# Generated at 2022-06-23 16:35:13.666497
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")


# Generated at 2022-06-23 16:35:17.217854
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    x = "chua"
    y = "bien"
    assert Exclude.NEVER(x) == False, "Test NEVER false"
    assert Exclude.NEVER(y) == False, "Test NEVER false"


# Generated at 2022-06-23 16:35:24.470100
# Unit test for function config
def test_config():
  import unittest

  class TestConfig(unittest.TestCase):
      def test_config_metadata(self):
          @dataclass_json
          @config(metadata={"foo": "bar"},)
          @dataclass
          class Test:
              pass

          assert Test._json_metadata == {"dataclasses_json": {}, "foo": "bar"}

      def test_config_undefined(self):
          for undefined in (
                  "RAISE",
                  "EXCLUDE",
                  "INCLUDE",
                  Undefined.RAISE,
                  Undefined.EXCLUDE,
                  Undefined.INCLUDE):

              @dataclass_json
              @config(undefined=undefined)
              @dataclass
              class Test:
                  pass


# Generated at 2022-06-23 16:35:32.196599
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass()
    class ValidMetadata:
        simple: int = config()

        encoder: int = config(encoder=lambda x: x + 1)

        decoder: int = config(decoder=lambda x: x + 1)

        mm_field: int = config(mm_field=MarshmallowField())

        letter_case: int = config(letter_case=lambda x: x.upper())

        undefined: int = config(undefined=Undefined.SKIP)

        exclude: int = config(exclude=Exclude.ALWAYS)

    @dataclasses.dataclass()
    class InvalidMetadata:
        invalid_undefined: int = config(undefined="unknown")

# Generated at 2022-06-23 16:35:32.996007
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS


# Generated at 2022-06-23 16:35:35.800386
# Unit test for function config
def test_config():
    import _pytest.doctest
    _pytest.doctest.testmod(None, name='config')



# Generated at 2022-06-23 16:35:44.949796
# Unit test for constructor of class Exclude
def test_Exclude():
    from dataclasses import dataclass
    import marshmallow
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Person:
        first_name: str
        last_name: str
        height: int

    assert not Person.config(exclude=Exclude.NEVER)().exclude_field('height')
    assert Person.config(exclude=Exclude.NEVER)().exclude_field('first_name')
    assert Person.config(exclude=Exclude.NEVER)().exclude_field('last_name')

    assert Person.config(exclude=Exclude.ALWAYS)().exclude_field('height')
    assert Person.config(exclude=Exclude.ALWAYS)().exclude_field('first_name')
    assert Person.config

# Generated at 2022-06-23 16:35:45.896272
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:35:49.420851
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:35:52.947726
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    from dataclasses import dataclass

    @dataclass
    class Point:
        x: float
        y: float
    a = Point(1, 2)
    assert Exclude.ALWAYS(a) == True


# Generated at 2022-06-23 16:35:55.147958
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER("")

    print("Test case for method NEVER of class Exclude passed!")


# Generated at 2022-06-23 16:35:57.545244
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(1))
    assert(Exclude.NEVER(None))
    assert(Exclude.NEVER(object))


# Generated at 2022-06-23 16:36:00.108504
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    assert conf.encoders == {}
    assert conf.decoders == {}
    assert conf.mm_fields == {}


# Generated at 2022-06-23 16:36:02.117545
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:36:03.439568
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a')


# Generated at 2022-06-23 16:36:05.026003
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('A')
    assert not Exclude.NEVER('B')


# Generated at 2022-06-23 16:36:07.540605
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance (_GlobalConfig(), _GlobalConfig)

# Generated at 2022-06-23 16:36:09.318990
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-23 16:36:10.958588
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:36:12.602950
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (Exclude.ALWAYS('hello') == True)
    assert (Exclude.NEVER('hello') == False)
    return True


# Generated at 2022-06-23 16:36:15.904927
# Unit test for function config
def test_config():
    # Valid usage
    config(undefined="RAISE")
    config(undefined="EXCLUDE")
    config(undefined="INCLUDE")
    config(undefined=Undefined.EXCLUDE)

    # Invalid usage
    try:
        config(undefined="LOL")
    except UndefinedParameterError:
        pass
    else:
        assert False



# Generated at 2022-06-23 16:36:22.876925
# Unit test for function config
def test_config():
    @config(letter_case='camel')
    @dataclass
    class Point:
        x: int
        y: int

    obj = Point(1, 2)

    assert obj.x == 1
    assert obj.y == 2

    obj_json = Point.Schema().dumps(obj)

    assert isinstance(obj_json, str)
    assert obj.x == 1
    assert obj.y == 2

    assert json.loads(obj_json) == {'x': 1, 'y': 2}



# Generated at 2022-06-23 16:36:25.271532
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude = Exclude.NEVER
    assert exclude('abc') is False

    exclude = Exclude.ALWAYS
    assert exclude('abc') is True

# Generated at 2022-06-23 16:36:28.799767
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS == Exclude.ALWAYS

# Generated at 2022-06-23 16:36:33.475605
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    try:
        global_config._GlobalConfig()
    except Exception as e:
        assert(False), "Could not create object _GlobalConfig: " + str(e)
    else:
        assert(True)

test__GlobalConfig()


# Generated at 2022-06-23 16:36:35.651959
# Unit test for constructor of class Exclude
def test_Exclude():
    excl = Exclude()
    assert excl.ALWAYS(1)
    assert not excl.NEVER(2)

# Generated at 2022-06-23 16:36:36.711267
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(None))


# Generated at 2022-06-23 16:36:38.198909
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

test__GlobalConfig()

# Generated at 2022-06-23 16:36:42.272710
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = 'a'
    b = 'b'
    assert Exclude.NEVER(a) == False
    assert Exclude.NEVER(b) == False


# Generated at 2022-06-23 16:36:51.401235
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined

    @config(
        encoder=lambda obj: "encoded",
        decoder=lambda obj: "decoded",
        mm_field=fields.String(attribute="mm_field"),
        field_name='field_name',
        letter_case=lambda obj: obj.upper(),
        undefined=Undefined.EXCLUDE,
        exclude=lambda field, obj: obj is not None
    )
    class Class:
        field = None


# Generated at 2022-06-23 16:36:52.688526
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("123") == False


# Generated at 2022-06-23 16:36:53.967272
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-23 16:36:56.242617
# Unit test for constructor of class Exclude
def test_Exclude():
    E = Exclude()
    assert E.ALWAYS(0) == True
    assert E.NEVER(0) == False


# Generated at 2022-06-23 16:36:59.984194
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER('a') == False

# Generated at 2022-06-23 16:37:01.700351
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) is True


# Generated at 2022-06-23 16:37:05.403276
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config_ = _GlobalConfig()
    assert config_.encoders == {}
    assert config_.decoders == {}
    assert config_.mm_fields == {}
    assert isinstance(config_, _GlobalConfig)

# Generated at 2022-06-23 16:37:08.879806
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert(global_config.encoders == {})
    assert(global_config.decoders == {})
    assert(global_config.mm_fields == {})
    # assert(global_config._json_module == json)


# Generated at 2022-06-23 16:37:10.316772
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  assert (Exclude.ALWAYS('foo')) == True


# Generated at 2022-06-23 16:37:12.587955
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # TODO: Add tests for `encoders` and `decoders`
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:37:13.754069
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('Hello') is False


# Generated at 2022-06-23 16:37:16.228039
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3)
    assert not Exclude.NEVER(5)


# Generated at 2022-06-23 16:37:19.571957
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') is False
    assert Exclude.NEVER('b') is False
    assert Exclude.NEVER('c') is False


# Generated at 2022-06-23 16:37:23.854702
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS((1,2)) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(0.0) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(print) == True


# Generated at 2022-06-23 16:37:27.658187
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2) is False
    assert Exclude.NEVER('a string') is False
    assert Exclude.NEVER([1, 'a string', 5]) is False



# Generated at 2022-06-23 16:37:37.272435
# Unit test for function config

# Generated at 2022-06-23 16:37:40.697005
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER.__name__ == "<lambda>", "The Exclude.NEVER method doesn't return a lambda"
    assert Exclude.NEVER("") == False, "Exclude.NEVER doesn't return False for any input"


# Generated at 2022-06-23 16:37:44.331051
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude.ALWAYS, Callable[[T], bool])
    assert isinstance(Exclude.NEVER, Callable[[T], bool])



# Generated at 2022-06-23 16:37:47.345129
# Unit test for function config
def test_config():
    assert len(config().items()) == 1
    assert len(config(decoder=True).items()) == 1
    assert len(config().items()) == 1

# Generated at 2022-06-23 16:37:48.486763
# Unit test for constructor of class Exclude
def test_Exclude():
    assert isinstance(Exclude, object)



# Generated at 2022-06-23 16:37:49.715476
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config

# Generated at 2022-06-23 16:37:58.958347
# Unit test for function config
def test_config():
    from typing import set

    def override_decoder(_):
        pass

    def override_encoder(_):
        pass

    def override_letter_case(_):
        pass

    def override_exclude(_, T):
        pass

    from marshmallow.fields import Integer
    from marshmallow import Schema

    class CustomField(Integer):
        pass

    class SampleSchema(Schema):
        mm_field = CustomField()

    @config(encoder=override_encoder,
            decoder=override_decoder,
            letter_case=override_letter_case,
            mm_field=CustomField(),
            field_name='override_field_name',
            undefined=Undefined.RAISE,
            exclude=override_exclude,
            )
    class Sample:
        a: str
        b

# Generated at 2022-06-23 16:38:02.418007
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("test_Exclude_NEVER")
    a = Exclude.NEVER(False)
    b = Exclude.NEVER(True)
    assert (a==b==False)


# Generated at 2022-06-23 16:38:04.741026
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    conf = _GlobalConfig()
    assert conf.encoders == {}
    assert conf.decoders == {}
    assert conf.mm_fields == {}
    # print(conf._json_module)
    # assert conf._json_module == json

# Generated at 2022-06-23 16:38:06.346919
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:38:10.525498
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("abc")
    assert Exclude.ALWAYS(-0.5)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS([])


# Generated at 2022-06-23 16:38:12.204293
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False


# Generated at 2022-06-23 16:38:13.922116
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:38:16.381521
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS([1, 2, 3])
    assert not Exclude.NEVER([1, 2, 3])


# Generated at 2022-06-23 16:38:26.151225
# Unit test for function config
def test_config():
    def func():
        pass
    metadata = {}
    metadata = config(metadata, encoder=func, decoder=func, mm_field=func,
                      field_name="name", letter_case=func, undefined=Undefined.RAISE, exclude=func)
    assert 'dataclasses_json' in metadata
    assert 'encoder' in metadata['dataclasses_json']
    assert 'decoder' in metadata['dataclasses_json']
    assert 'mm_field' in metadata['dataclasses_json']
    assert 'field_name' in metadata['dataclasses_json']
    assert 'letter_case' in metadata['dataclasses_json']
    assert 'undefined' in metadata['dataclasses_json']
    assert 'exclude' in metadata['dataclasses_json']

# Generated at 2022-06-23 16:38:29.329063
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()

    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}


# Generated at 2022-06-23 16:38:33.520967
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS)
    assert Exclude.ALWAYS is Exclude.ALWAYS



# Generated at 2022-06-23 16:38:36.271876
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert(global_config.encoders == {})
    assert(global_config.decoders == {})
    assert(global_config.mm_fields == {})


# Generated at 2022-06-23 16:38:41.709589
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders[T] = T
    global_config.decoders[T] = T
    global_config.mm_fields[T] = T

    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-23 16:38:42.866352
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False)

# Generated at 2022-06-23 16:38:44.189836
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert not Exclude.NEVER(True)

# Generated at 2022-06-23 16:38:52.910867
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS(0))
    assert(Exclude.ALWAYS(1))
    assert(Exclude.ALWAYS(2))
    assert(Exclude.ALWAYS(3))
    assert(Exclude.ALWAYS(4))
    assert(Exclude.ALWAYS(5))
    assert(Exclude.ALWAYS(6))
    assert(Exclude.ALWAYS(7))
    assert(Exclude.ALWAYS(8))
    assert(Exclude.ALWAYS(9))
    assert(not Exclude.NEVER(0))
    assert(not Exclude.NEVER(1))
    assert(not Exclude.NEVER(2))
    assert(not Exclude.NEVER(3))
    assert(not Exclude.NEVER(4))
    assert(not Exclude.NEVER(5))
   

# Generated at 2022-06-23 16:38:56.659899
# Unit test for function config
def test_config():
    return config(mm_field="a", encoder="b", decoder="c", letter_case="d", undefined="ignore")


# Generated at 2022-06-23 16:38:58.206481
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:39:01.526630
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    tt = Exclude.NEVER

    # Act
    result = tt("some arg")

    # Assert
    expected = False
    assert result == expected

# Generated at 2022-06-23 16:39:02.312431
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:39:03.449948
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("123") == True


# Generated at 2022-06-23 16:39:06.339951
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:39:11.121034
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('s')
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(Exclude)
    assert Exclude.ALWAYS(Exclude.ALWAYS)


# Generated at 2022-06-23 16:39:13.206019
# Unit test for constructor of class Exclude
def test_Exclude():
    testbool = Exclude.ALWAYS('_')
    assert testbool == True
    testbool = Exclude.NEVER('_')
    assert testbool == False

# Generated at 2022-06-23 16:39:20.045752
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS('abc') == True
    assert Exclude.ALWAYS(123) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS(set()) == True
    assert Exclude.ALWAYS(Undefined) == True



# Generated at 2022-06-23 16:39:22.060327
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class sample:
        pass

    assert Exclude.ALWAYS(sample()) == True


# Generated at 2022-06-23 16:39:25.726941
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config._json_module == json


# Generated at 2022-06-23 16:39:26.853583
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(7), "Error in method ALWAYS of class Exclude"



# Generated at 2022-06-23 16:39:27.508841
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-23 16:39:28.326769
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False

# Generated at 2022-06-23 16:39:33.780964
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Initialize new object of type Exclude
    exclude_obj = Exclude()

    # The actual result
    actual_result = exclude_obj.ALWAYS(1)

    # Expected result
    expected_result = True
    
    # Assert if the results not equal
    assert expected_result == actual_result


# Generated at 2022-06-23 16:39:35.439487
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:39:36.523550
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config._GlobalConfig()


# Generated at 2022-06-23 16:39:45.156041
# Unit test for function config
def test_config():
    decoder = lambda value: value
    encoder = lambda value: value
    mm_field = 1
    letter_case = lambda value: value
    undefined = "ignore"
    import json

    cfg_meta = config(decoder=decoder, encoder=encoder, mm_field=mm_field, letter_case=letter_case, undefined=undefined)
    assert cfg_meta['dataclasses_json']['encoder'] == encoder
    assert cfg_meta['dataclasses_json']['decoder'] == decoder
    assert cfg_meta['dataclasses_json']['mm_field'] == 1
    assert cfg_meta['dataclasses_json']['letter_case'] == letter_case
    assert cfg_meta['dataclasses_json']['undefined'] == Undefined

# Generated at 2022-06-23 16:39:54.531451
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields as mm_fields

    @dataclass
    class A:
        x: int

        class Config(object):
            encoder = staticmethod(lambda x: 'ENCODED: {0}'.format(x))
            decoder = staticmethod(lambda x: 'DECODED: {0}'.format(x))
            mm_field = mm_fields.Int(required=False, missing=None)
            letter_case = staticmethod(lambda x: x.upper())
            undefined = Undefined.EXCLUDE
            exclude = Exclude.NEVER

    assert A.Config.encoder(42) == 'ENCODED: 42'
    assert A.Config.decoder(42) == 'DECODED: 42'
    assert A.Config.mm_field.__

# Generated at 2022-06-23 16:39:56.963759
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    a = Exclude()
    assert a.ALWAYS(1) == True


# Generated at 2022-06-23 16:40:02.238082
# Unit test for function config
def test_config():
    assert config(undefined="ignore").get('dataclasses_json').get('undefined') == Undefined.IGNORE


# Add config function to the module's namespace
# to prevent text editor from linting it.
# See https://github.com/agronholm/pydantic/issues/1217
config.__module__ = "dataclasses"  # type: ignore

# Generated at 2022-06-23 16:40:06.602878
# Unit test for function config
def test_config():
    import dataclasses
    from marshmallow.fields import Boolean
    from dataclasses_json.mm import MmConfig
    from dataclasses_json.undefined import EXCLUDE

    class ConfigOverridden(MmConfig):
        pass


# Generated at 2022-06-23 16:40:08.675018
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    expected = False
    result = Exclude.NEVER(None)
    assert result == expected

# Generated at 2022-06-23 16:40:14.777453
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from marshmallow import fields
    c = _GlobalConfig()
    c.mm_fields[int] = fields.Int
    assert(c.mm_fields[int] == fields.Int)
    assert(c.mm_fields[float] == None)

# Generated at 2022-06-23 16:40:16.922954
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("hello") is False


# Generated at 2022-06-23 16:40:18.652293
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("False") == False

# Generated at 2022-06-23 16:40:21.584320
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert len(global_config.encoders) == 0 and len(global_config.decoders) == 0 and len(global_config.mm_fields) == 0 and global_config._json_module == json


# Generated at 2022-06-23 16:40:33.652422
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Config:
        class Config:
            dataclasses_json = config(
                encoder = lambda x: x,
                decoder = lambda x: x,
                mm_field = "mm field",
                letter_case = lambda x: x,
                undefined = Undefined.EXCLUDE,
                field_name = "field_name"
            )
        i: int
        j: int = config(exclude=Exclude.ALWAYS)


# Generated at 2022-06-23 16:40:35.148376
# Unit test for constructor of class Exclude
def test_Exclude():
    exclude = Exclude()
    assert exclude.ALWAYS(1)
    assert not exclude.NEVER(1)

# Generated at 2022-06-23 16:40:38.243783
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS([])


# Generated at 2022-06-23 16:40:46.900803
# Unit test for function config
def test_config():
    @dataclass
    class Example:
        # TODO: define a type alias?
        encoder: Callable
        decoder: Callable
        mm_field: MarshmallowField
        letter_case: Callable[[str], str]
        field_name: str
        exclude: Optional[Callable[[str, T], bool]]

        encoder = config(encoder=int)
        decoder = config(decoder=int)
        mm_field = config(mm_field=int)
        field_name = config(field_name="my_field_name")
        exclude = config(exclude=Exclude.ALWAYS)
        letter_case = config(letter_case=str.upper)

    assert Example.encoder(0) == 0
    assert Example.decoder(0) == 0

# Generated at 2022-06-23 16:40:55.598683
# Unit test for function config
def test_config():
    import pytest
    from dataclasses import dataclass

    @dataclass
    class DataObj:
        name: str = 'test'

    data_obj = DataObj()

    # Test for undefined config with valid actions
    for action in Undefined:
        with pytest.warns(None) as record:
            config(undefined=action.name)(data_obj)
        assert len(record) == 0

    # Test for undefined config with invalid action
    with pytest.raises(UndefinedParameterError) as err:
        config(undefined='make_a_sandwich')(data_obj)
    assert str(err.value) == 'Invalid undefined parameter action, ' \
                             'must be one of [RAISE, INCLUDE, EXCLUDE]'

# Generated at 2022-06-23 16:40:56.520929
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)


# Generated at 2022-06-23 16:41:04.413863
# Unit test for function config
def test_config():
    # TODO: this will be removed in version 0.3.0
    try:
        from marshmallow import fields as mm_fields
    except ImportError:
        return

    @config(encoder=my_encoder, decoder=my_decoder,
            mm_field=mm_fields.String(), letter_case=str.lower,
            undefined=Undefined.IGNORE, field_name='Foo',
            exclude=Exclude.NEVER)
    @dataclass
    class Foo:
        foo: int = 1

    assert Foo.__dataclasses_json__['encoder'] is my_encoder
    assert Foo.__dataclasses_json__['decoder'] is my_decoder
    assert isinstance(
        Foo.__dataclasses_json__['mm_field'], mm_fields.String)
   

# Generated at 2022-06-23 16:41:05.768978
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a")


# Generated at 2022-06-23 16:41:13.729661
# Unit test for function config
def test_config():
    class C: pass
    assert config(encoder=dict, decoder=dict, mm_field=C, letter_case=dict,
                  undefined=dict, field_name=dict, exclude=dict,
                  metadata={'a': 'b'}) == {'a': "b",
                                           'dataclasses_json':
                                           {
                                               'encoder': dict,
                                               'decoder': dict,
                                               'mm_field': C,
                                               'letter_case': dict,
                                               'undefined': dict,
                                               'exclude': dict
                                           }}

# Unit tests for the global config object

# Generated at 2022-06-23 16:41:17.978503
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(0) is False

# Generated at 2022-06-23 16:41:27.711184
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int
        email: str = "unknown"

    assert config(Person)['dataclasses_json'] == {}

    @dataclass
    class Person:
        name: str
        age: int
        email: str = "unknown"

        class Config:
            expire = 'never'

    assert config(Person)['dataclasses_json'] == {}
    assert config(Person.Config)['dataclasses_json']['expire'] == 'never'

    @dataclass
    class Person:
        name: str
        age: int
        email: str = "unknown"

        class Config:
            pass

    @dataclass
    class Student(Person):
        std_id: int


# Generated at 2022-06-23 16:41:31.663230
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global global_config
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:41:33.706655
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}


# Generated at 2022-06-23 16:41:45.126641
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields as ma_fields
    from dataclasses_json import mm_config
    # Define a marshmallow schema and json encoder/decoder
    class MySchema(mm_config, ma_fields.Schema):
        id = ma_fields.Integer()
        name = ma_fields.String()

    json_encode = MySchema().dump
    json_decode = MySchema().load

    @config(letter_case=str.upper, encoder=json_encode, decoder=json_decode,
            mm_field=ma_fields.Integer(as_string=True),
            undefined=Undefined.EXCLUDE, exclude=Exclude.ALWAYS)
    @dataclass(frozen=True)
    class Dataclass:
        id

# Generated at 2022-06-23 16:41:46.133515
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(True) == False)


# Generated at 2022-06-23 16:41:47.430428
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-23 16:41:50.367892
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    Given: An instance of the class Exclude
    When: method NEVER is called with a parameter
    Then: the parameter is not included
    """
    assert Exclude.NEVER(0)

# Generated at 2022-06-23 16:41:54.184385
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    if Exclude.ALWAYS(1) and Exclude.ALWAYS(None) and Exclude.ALWAYS({}):
        return True
    else:
        return False


# Generated at 2022-06-23 16:41:56.735810
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from mock import Mock
    a = _GlobalConfig()
    assert a.encoders == {}
    assert a.decoders == {}
    assert a.mm_fields == {}
    assert a._json_module == json

# Generated at 2022-06-23 16:41:58.463589
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-23 16:42:01.368344
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS("")
    expected = True
    assert result == expected, f"Expected: {expected} != Actual: {result}"


# Generated at 2022-06-23 16:42:03.317306
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)


# Generated at 2022-06-23 16:42:06.303181
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}


# Generated at 2022-06-23 16:42:07.525715
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:42:09.909230
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (Exclude.ALWAYS("my_string") is True)
    assert (Exclude.NEVER("my_string") is False)

# Generated at 2022-06-23 16:42:10.786948
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config

# Generated at 2022-06-23 16:42:12.525153
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:42:15.374827
# Unit test for constructor of class Exclude
def test_Exclude():
    obj = Exclude()
    assert obj.ALWAYS(5) == True
    assert obj.NEVER(5) == False

# Generated at 2022-06-23 16:42:16.541984
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config._GlobalConfig()


# Generated at 2022-06-23 16:42:18.085122
# Unit test for function config
def test_config():
    c = config(undefined="Raise")

# Generated at 2022-06-23 16:42:19.832851
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS is not None
    assert Exclude.NEVER is not None

# Generated at 2022-06-23 16:42:21.615498
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == Exclude.NEVER(2)


# Generated at 2022-06-23 16:42:28.533879
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(-1.0) == False
    assert Exclude.NEVER(1.0) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('abcde') == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER((1, 2)) == False

# Generated at 2022-06-23 16:42:36.122469
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)
    # print(global_config.encoders)
    assert global_config.encoders == dict()
    # print(global_config.decoders)
    assert global_config.decoders == dict()
    # print(global_config.mm_fields)
    assert global_config.mm_fields == dict()
    # print(global_config._json_module)
    assert global_config._json_module == dict()
#
# if __name__ == "__main__":
#     test__GlobalConfig()

# Generated at 2022-06-23 16:42:37.316562
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:42:43.035960
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        # This warning is not raised by pylint
        # pylint: disable=unsubscriptable-object
        a: str = field(metadata=config())

    @dataclass
    class B(DataClassJsonMixin):
        # This warning is not raised by pylint
        # pylint: disable=unsubscriptable-object
        a: str = field(metadata=config(letter_case="snake"))

    @dataclass
    class C(DataClassJsonMixin):
        # This warning is not raised by pylint
        # pylint: disable=unsubscriptable-object
        a: str = field

# Generated at 2022-06-23 16:42:48.172609
# Unit test for constructor of class Exclude
def test_Exclude():
    # Test Exclude.ALWAYS works properly
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS("abc")
    # Test Exclude.NEVER works properly
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER("abc") == False


# Generated at 2022-06-23 16:42:55.647080
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    print("Testing test__GlobalConfig()...")
    global_config.encoders["int"] = lambda i: i

# Generated at 2022-06-23 16:42:57.088097
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)



# Generated at 2022-06-23 16:43:00.148851
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS == Exclude.ALWAYS
    assert Exclude.NEVER == Exclude.NEVER


# Generated at 2022-06-23 16:43:02.531965
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}

# Generated at 2022-06-23 16:43:04.482012
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    with pytest.raises(UndefinedParameterError):
        config(undefined=Undefined.EXCEPTION)


# Generated at 2022-06-23 16:43:16.220671
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class TestA:
        a: int = config()

    @dataclasses.dataclass
    class TestB:
        a: int = config(letter_case=lambda x: x.lower())

    @dataclasses.dataclass
    class TestC:
        a: int = config(undefined=Undefined.RAISE)

    @dataclasses.dataclass
    class TestD:
        a: int = config(encoder=int)

    @dataclasses.dataclass
    class TestE:
        a: int = config(decoder=int)

    @dataclasses.dataclass
    class TestF:
        a: int = config(mm_field=int)


# Generated at 2022-06-23 16:43:18.039687
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(lambda x:x) == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-23 16:43:21.039370
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)


# Generated at 2022-06-23 16:43:22.462704
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-23 16:43:34.470622
# Unit test for function config
def test_config():
    import pytest
    TEST_CLASS_NAME = 'test_class'
    TEST_LETTER_CASE_NAME = 'test_letter_case'
    TEST_FIELD_NAME = 'test_field'
    TEST_ENCODER_NAME = 'test_encoder'
    TEST_DECODER_NAME = 'test_decoder'
    TEST_MM_FIELD_NAME = 'test_mm_field'
    TEST_EXCLUDE_NAME = 'test_exclude'

    class TestClass:
        pass
    class TestLetterCase:
        def __init__(self, value):
            self.value = value
        def __call__(self, input):
            return self.value
    class TestField:
        pass
    class TestEncoder:
        pass
    class TestDecoder:
        pass

# Generated at 2022-06-23 16:43:45.403212
# Unit test for function config
def test_config():
    from marshmallow.fields import Integer, String

    _fields = {
        'a': 'A',
        'b': 'B',
        'c': 'C',
        'd': 'D',
        'e': 'E',
        'f': 'F',
        'g': 'G',
        'h': 'H',
        'i': 'I',
        'j': 'J',
    }


# Generated at 2022-06-23 16:43:52.212542
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses import dataclass, field

    @dataclass
    class ConfigTest:
        int_val: int
        str_val: str
        float_val: float
        bool_val: bool
        list_val: list
        dict_val: dict

    @dataclass
    class ConfigTest2:
        int_val: int
        str_val: str
        float_val: float
        bool_val: bool
        list_val: list
        dict_val: dict

    config_test: ConfigTest = ConfigTest(
        10,
        'test',
        10.1,
        True,
        [1, 2, 3],
        {'a': 1, 'b': 2},
    )

# Generated at 2022-06-23 16:43:54.023529
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(2) is False


# Generated at 2022-06-23 16:44:05.138680
# Unit test for function config
def test_config():
    # test encoder
    class Foo:
        pass
    def encoder(o):
        return o.__class__.__name__
    config(encoder=encoder)
    assert(global_config.encoders[Foo] == encoder)
    # reconfigure
    config(encoder=None)
    assert(Foo not in global_config.encoders)
    # test decoder
    class Bar:
        pass
    def decoder(s):
        return Bar()
    config(decoder=decoder)
    assert(global_config.decoders[Bar] == decoder)
    # reconfigure
    config(decoder=None)
    assert(Bar not in global_config.decoders)
    # test field
    class Baz:
        pass

# Generated at 2022-06-23 16:44:06.748958
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False



# Generated at 2022-06-23 16:44:12.772545
# Unit test for function config
def test_config():
    @config(
            field_name='postcode',
            letter_case='lower',
            undefined='EXCLUDE',
            exclude=Exclude.ALWAYS,
            )
    class Config:
        def __init__(self, postcode):
            self.postcode = postcode

    config_case = Config('L4L8B4')
    assert config_case.postcode == 'L4L8B4'


# TODO: #180
# def set_json_module(json_module):
#     """
#     Set the module to use for JSON support.
#     """
#     global_config.json_module = json_module

# Generated at 2022-06-23 16:44:13.719569
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    return True

# Generated at 2022-06-23 16:44:15.962772
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders
    assert global_config.decoders
    assert global_config.mm_fields


# Generated at 2022-06-23 16:44:25.454823
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS([1, 2, 4])
    assert Exclude.ALWAYS((1, 2, 3))
    assert Exclude.ALWAYS((1, 2, 3))
    assert Exclude.ALWAYS({"v": 1})
    assert Exclude.ALWAYS({"v1": 1, "v2": 2})
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(-100)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("This is a test")
    assert Exclude.ALWAYS(b"This is a test")