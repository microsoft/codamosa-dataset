

# Generated at 2022-06-23 16:34:23.790055
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def __init__(self):
        self.error = 0

    if Exclude.NEVER(1):
        __init__.error = 0
    else:
        __init__.error = __init__.error + 1

    if Exclude.NEVER(None):
        __init__.error = __init__.error + 1
    else:
        __init__.error = __init__.error + 1

    if Exclude.NEVER('abc'):
        __init__.error = __init__.error + 1
    else:
        __init__.error = __init__.error + 1
    assert __init__.error == 4


# Generated at 2022-06-23 16:34:28.917272
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('1')

# Generated at 2022-06-23 16:34:30.149891
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(1)
    assert a == False


# Generated at 2022-06-23 16:34:39.863741
# Unit test for function config
def test_config():
    def test_encoder(obj):
        return "encoder"

    def test_decoder(obj):
        return "decoder"

    mm_field = MarshmallowField()

    @functools.wraps(config)
    def test_fn():
        return config(
            encoder=test_encoder,
            decoder=test_decoder,
            mm_field=mm_field,
            undefined=Undefined.RAISE,
            field_name='test',
            exclude=Exclude.ALWAYS,
        )

    tmp_dict = test_fn()
    result = tmp_dict.get("dataclasses_json")

    assert result.get("encoder") == test_encoder
    assert result.get("decoder") == test_decoder
    assert result.get("mm_field") == mm_field

# Generated at 2022-06-23 16:34:43.078117
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc")
    assert Exclude.NEVER("aBc")
    assert Exclude.NEVER("ABC")
    assert Exclude.NEVER("aaa")
    assert Exclude.NEVER("aaa")


# Generated at 2022-06-23 16:34:51.990033
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from marshmallow import Schema, fields

    @dataclass
    class Dummy(DataClassJsonMixin):
        x: int = None  # noqa
        y: int = config(mm_field=fields.Int(validate=lambda x: x % 2 == 0))

    assert isinstance(Dummy.__dataclass_fields__['x'].metadata['dataclasses_json']['mm_field'], fields.Integer)
    assert isinstance(Dummy.__dataclass_fields__['y'].metadata['dataclasses_json']['mm_field'], fields.Integer)

    class DummySchema(Schema):
        class Meta:
            ordered = True


# Generated at 2022-06-23 16:34:53.277361
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('foo') is False


# Generated at 2022-06-23 16:34:57.404984
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig().encoders == {}
    assert _GlobalConfig().decoders == {}
    assert _GlobalConfig().mm_fields == {}
    # assert _GlobalConfig().json_module == json


# Generated at 2022-06-23 16:35:00.497704
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("")
    assert not Exclude.NEVER("")


if __name__ == "__main__":
    # Unit test for constructor of class Exclude
    test_Exclude()

# Generated at 2022-06-23 16:35:03.008957
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("test")
    assert not Exclude.NEVER("test")

# Generated at 2022-06-23 16:35:04.030585
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('_') == False

# Generated at 2022-06-23 16:35:06.221865
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)



# Generated at 2022-06-23 16:35:11.054628
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    new_global_config = _GlobalConfig()
    assert isinstance(new_global_config.encoders, dict)
    assert isinstance(new_global_config.decoders, dict)
    assert isinstance(new_global_config.mm_fields, dict)
    # assert isinstance(new_global_config._json_module, json._json)


# Generated at 2022-06-23 16:35:12.260300
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False



# Generated at 2022-06-23 16:35:21.220231
# Unit test for function config
def test_config():
    import dataclasses
    from marshmallow import fields
    # TODO: add test for field_name
    class T(dataclasses.dataclass):
        a: int
        b: dict
        c: str
        d: list
        e: float

        class Config:
            encoder = str
            decoder = int
            mm_field = fields.String
            letter_case = str.upper
            undefined = Undefined.RAISE
            exclude = Exclude.NEVER

    assert T.Config.encoder == str
    assert T.Config.decoder == int
    assert T.Config.mm_field == fields.String
    assert T.Config.letter_case == str.upper
    assert T.Config.undefined == Undefined.RAISE
    assert T.Config.exclude == Exclude.NEVER



# Generated at 2022-06-23 16:35:23.372357
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)


# Generated at 2022-06-23 16:35:25.142858
# Unit test for function config
def test_config():
    """docstring for test_config"""
    pass



# Generated at 2022-06-23 16:35:26.796292
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)


# Generated at 2022-06-23 16:35:29.156562
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:35:34.532013
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-23 16:35:37.084350
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    assert e.ALWAYS(1)
    assert not e.NEVER(1)


# Generated at 2022-06-23 16:35:40.837123
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():

    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS(set())
    assert Exclude.ALWAYS(dict())



# Generated at 2022-06-23 16:35:42.445118
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('x') == True
    assert Exclude.NEVER('x') == False

# Generated at 2022-06-23 16:35:43.995102
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)



# Generated at 2022-06-23 16:35:45.430113
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER("")


# Generated at 2022-06-23 16:35:47.731912
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.NEVER(1) == False)


# Generated at 2022-06-23 16:35:50.486498
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    expected = True
    actual = Exclude.ALWAYS(None)
    assert actual == expected


# Generated at 2022-06-23 16:35:53.838734
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS("string"))
    assert(Exclude.ALWAYS(42))
    assert(Exclude.ALWAYS(("tuple", "of", "strings")))


# Generated at 2022-06-23 16:36:01.461054
# Unit test for function config
def test_config():
    class MyClass:
        @config(encoder=str)
        def _(self) -> None:
            pass

    assert get_config(MyClass._)['encoder'] is str
    # Test case-insensitivity.
    assert get_config(MyClass._)['ENCODER'] is str

    @config(exclude=Exclude.ALWAYS)
    class AlwaysExclude:
        pass

    assert get_config(AlwaysExclude)['exclude'] is Exclude.ALWAYS

    @config(field_name="a_long_field_name", letter_case=lambda x: x.lower())
    class MyClass:
        pass

    assert get_config(MyClass)['letter_case'](None) == "a_long_field_name"

    # Reset the global config, to ensure there are no side-effects


# Generated at 2022-06-23 16:36:09.692416
# Unit test for function config
def test_config():
    # default
    assert config() == {'dataclasses_json': {}}

    # every possible field
    assert config(
        encoder='ENCODER',
        decoder='DECODER',
        mm_field='MM_FIELD',
        field_name='FIELD_NAME',
        letter_case='LETTER_CASE',
        undefined='UNDEFINED',
        exclude='EXCLUDE') == {'dataclasses_json': {
            'encoder': 'ENCODER',
            'decoder': 'DECODER',
            'mm_field': 'MM_FIELD',
            'field_name': 'FIELD_NAME',
            'letter_case': 'LETTER_CASE',
            'undefined': 'UNDEFINED',
            'exclude': 'EXCLUDE'
        }}

    # every

# Generated at 2022-06-23 16:36:13.014365
# Unit test for function config
def test_config():
    dct = config(exclude=Exclude.NEVER)
    assert dct['dataclasses_json']['exclude'] == Exclude.NEVER
    assert dct is not config(dct)

# Generated at 2022-06-23 16:36:15.344478
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    assert Exclude.NEVER("a")
    assert Exclude.NEVER(None)

# Generated at 2022-06-23 16:36:16.080937
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-23 16:36:18.734090
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)

    assert not Exclude.NEVER(True)
    assert not Exclude.NEVER(False)

# Generated at 2022-06-23 16:36:28.144163
# Unit test for function config
def test_config():
    import marshmallow

    assert config(foo="bar") == {'dataclasses_json': {'foo': 'bar'}}

    @config(encoder=str)
    class TestClass:
        pass

    assert TestClass.__dataclasses_json__['encoder'] == str

    @config(exclude=Exclude.ALWAYS)
    class TestClass:
        pass

    assert TestClass.__dataclasses_json__['exclude'] == Exclude.ALWAYS

    @config(undefined=Undefined.EXCLUDE)
    class TestClass:
        pass

    assert TestClass.__dataclasses_json__['undefined'] == Undefined.EXCLUDE

    @config(mm_field=marshmallow.fields.Str())
    class TestClass:
        pass

    assert TestClass.__datac

# Generated at 2022-06-23 16:36:29.849994
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER
    assert Exclude.ALWAYS

# Generated at 2022-06-23 16:36:37.856589
# Unit test for function config
def test_config():
    @dataclass
    @config(metadata=dict(
        dataclasses_json=dict(mm_field=None)
    ))
    class A:
        field: str

    @dataclass
    @config(
        encoder=str,
        decoder=str,
        mm_field=None,
        letter_case=str.lower,
        undefined=None,
        field_name='field',
        exclude=Exclude.ALWAYS,
    )
    class B:
        field: str



# Generated at 2022-06-23 16:36:42.317898
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([0])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({'a':0})


# Generated at 2022-06-23 16:36:45.750340
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0

# Generated at 2022-06-23 16:36:48.350874
# Unit test for constructor of class Exclude
def test_Exclude():
	assert Exclude.ALWAYS(1) == True
	assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:36:50.789597
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert Exclude.NEVER(1)
	assert Exclude.NEVER(2)
	assert Exclude.NEVER(3)
	assert Exclude.NEVER(4)


# Generated at 2022-06-23 16:36:52.340820
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    try:
        Exclude.NEVER(1)
    except:
        assert False


# Generated at 2022-06-23 16:36:53.259805
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("anything") == False

# Generated at 2022-06-23 16:36:54.621360
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:36:57.018079
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}
    assert g.mm_fields == {}


# Generated at 2022-06-23 16:37:00.029492
# Unit test for function config
def test_config():
    import pytest

    with pytest.raises(UndefinedParameterError):
        config(undefined='asdf')



# Generated at 2022-06-23 16:37:00.996498
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-23 16:37:12.457666
# Unit test for function config
def test_config():
    dataclass_type = type('DummyClass', (), {})
    dic= {'a': 1, 'b': 2}
    config(dic)
    assert dic['dataclasses_json'] == {}, "test_config() dic 1 failed"
    config(dic, encoder=lambda _: dic)
    assert dic['dataclasses_json'] == {'encoder': lambda _: dic}, "test_config() dic 2 failed"
    config(dic, decoder=lambda _: dic)
    assert dic['dataclasses_json'] == {'encoder': lambda _: dic, 'decoder': lambda _: dic}, "test_config() dic 3 failed"
    config(dic, mm_field=lambda _: _)

# Generated at 2022-06-23 16:37:13.644231
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(None))
    return 1


# Generated at 2022-06-23 16:37:17.110126
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config1 = _GlobalConfig()
    assert config1.encoders == {}
    assert config1.decoders == {}
    assert config1.mm_fields == {}



# Generated at 2022-06-23 16:37:19.185915
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True



# Generated at 2022-06-23 16:37:22.261761
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude
    assert e.ALWAYS(1)
    assert e.NEVER(1)
    assert not e.ALWAYS("")
    assert not e.NEVER("")


# Generated at 2022-06-23 16:37:24.802567
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders is not None
    assert global_config.decoders is not None
    assert global_config.mm_fields is not None

# Generated at 2022-06-23 16:37:26.684968
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_val = Exclude.NEVER("test_val")
    assert not test_val


# Generated at 2022-06-23 16:37:29.448870
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()

    assert e.ALWAYS == Exclude.ALWAYS
    assert e.NEVER == Exclude.NEVER

# Generated at 2022-06-23 16:37:30.386555
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1) == True)

# Generated at 2022-06-23 16:37:32.895568
# Unit test for constructor of class Exclude
def test_Exclude():
    # unit test for constant ALWAYS and NEVER
    assert Exclude.ALWAYS(1) is True
    assert Exclude.NEVER(2) is False

# Generated at 2022-06-23 16:37:33.902366
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert type(global_config) == _GlobalConfig

# Generated at 2022-06-23 16:37:40.489311
# Unit test for function config
def test_config():
    import pytest
    from marshmallow import fields

    class A:
        class Config:
            dataclasses_json = {
                "undefined": "raise",
            }

    class B:
        pass

    @dataclasses.dataclass
    class C:
        x: Optional[int]

        class Config:
            dataclasses_json = {
                "undefined": Undefined.OVERRIDE,
            }

    class D:
        class Config:
            dataclasses_json = {
                "exclude": Exclude.ALWAYS,
            }

    class E:
        class Config:
            dataclasses_json = {
                "encoder": lambda x: 42
            }


# Generated at 2022-06-23 16:37:43.276910
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("field") == False



# Generated at 2022-06-23 16:37:46.567711
# Unit test for constructor of class Exclude
def test_Exclude():
    print(Exclude.ALWAYS)
    print(Exclude.NEVER)

if __name__ == "__main__":
    test_Exclude()

# Generated at 2022-06-23 16:37:48.603265
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(tuple())
    assert Exclude.ALWAYS(123)


# Generated at 2022-06-23 16:37:49.844593
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()


# Generated at 2022-06-23 16:37:54.923590
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    
    encoder = config(encoder = lambda x: str(x))
    decoder = config(decoder = lambda x: x)
    assert encoder['dataclasses_json']['encoder'] == global_config.encoders[type('')]
    assert decoder['dataclasses_json']['decoder'] == global_config.decoders[type('')]

# Generated at 2022-06-23 16:37:58.516140
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("Alice")
    assert Exclude.NEVER("Bob")
    assert Exclude.NEVER("Charlie")
    assert Exclude.NEVER("Dan")


# Generated at 2022-06-23 16:38:05.343014
# Unit test for function config
def test_config():
    # Does a basic check that the metadata is set correctly
    metadata = config()
    assert metadata == {'dataclasses_json': {}}

    metadata = config(metadata)
    assert metadata == {'dataclasses_json': {}}

    metadata = config(metadata={'other': 'metadata'})
    assert metadata == {'dataclasses_json': {}, 'other': 'metadata'}

    for undefined in ['INCLUDE', 'EXCLUDE', 'RAISE', 'INCLUDE_BY_DEFAULT']:
        metadata = config(undefined=undefined)
        assert metadata == {'dataclasses_json': {'undefined': Undefined.INCLUDE}}

# Generated at 2022-06-23 16:38:07.053849
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)



# Generated at 2022-06-23 16:38:08.300582
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") is False


# Generated at 2022-06-23 16:38:19.988473
# Unit test for function config
def test_config():
    # Test excluding unmapped attributes
    assert config(undefined=Undefined.EXCLUDE) == {
        'dataclasses_json': {
            'undefined': Undefined.EXCLUDE
        }
    }

    # Test excluding unmapped attributes
    assert config(undefined='EXCLUDE') == {
        'dataclasses_json': {
            'undefined': Undefined.EXCLUDE
        }
    }

    # Test excluding unmapped attributes
    assert config(undefined='exclude') == {
        'dataclasses_json': {
            'undefined': Undefined.EXCLUDE
        }
    }

    # Test for invalid undefined parameter

# Generated at 2022-06-23 16:38:22.579437
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == {}
    assert config.decoders == {}
    assert config.mm_fields == {}


# Generated at 2022-06-23 16:38:31.940811
# Unit test for function config
def test_config():
    class MyType(object):
        pass

    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

    encoder = lambda x: 42
    decoder = lambda x: x + 1
    mm_field = str

    my_type = MyType()
    config(
        my_type,
        encoder=encoder,
        decoder=decoder,
        mm_field=mm_field,
    )
    assert "dataclasses_json" in my_type.__dataclasses_json__
    my_dataclasses_json = my_type.__dataclasses_json__["dataclasses_json"]
    assert my_dataclasses_json["encoder"] == encoder

# Generated at 2022-06-23 16:38:36.789451
# Unit test for function config
def test_config():
    @dataclass
    class User:
        name: str
        user_id: int
        is_admin: bool

        @property
        def id(self):
            return self.user_id

    def test_exclude(field: str, value: User) -> bool:
        if field == 'is_admin':
            return not value.is_admin
        return False

    res = (User('Bob', user_id=42, is_admin=True),
           config(field_name='user_id', exclude=test_exclude))
    assert res == ({'name': 'Bob',
                    'user_id': 42,
                    'is_admin': True},
                   {'dataclasses_json': {
                       'field_name': 'user_id',
                       'exclude': test_exclude}
                   })
   

# Generated at 2022-06-23 16:38:40.585057
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    @dataclass
    class DataClass:
        a: int = 1
        b: str = 'hello'

    data = DataClass()
    assert Exclude.NEVER(data) == False

# Generated at 2022-06-23 16:38:46.298802
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER(1.0/3) == False
    assert Exclude.NEVER([]) == False
    # assert Exclude.NEVER({}) == False
    assert Exclude.NEVER((0,)) == False
    # assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:38:51.691841
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("A")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS((1, 2))
    assert Exclude.ALWAYS([1, 2])
    assert Exclude.ALWAYS({"a": 1})
    assert Exclude.ALWAYS(Exclude)
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(Exclude.NEVER)


# Generated at 2022-06-23 16:38:55.747263
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc") == False


# Generated at 2022-06-23 16:38:57.002508
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)



# Generated at 2022-06-23 16:38:58.547082
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(False) == True

# Generated at 2022-06-23 16:39:00.809791
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    A = config(Exclude.ALWAYS)
    B = config(Exclude.ALWAYS)
    C = config(Exclude.ALWAYS)
    assert A == B == C



# Generated at 2022-06-23 16:39:02.385643
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS == Exclude().ALWAYS
    assert Exclude.NEVER == Exclude().NEVER



# Generated at 2022-06-23 16:39:12.077544
# Unit test for function config
def test_config():
    # Samples
    @config(metadata={"b": "c"}, encoder=True, decoder=True, mm_field=True,
              letter_case=True, exclude=True)
    @config(metadata={"a": "b"}, encoder=False, decoder=False, mm_field=False,
              letter_case=False, exclude=False)
    class Sample: pass

    assert Sample.__dataclasses_json__ == {
        'encoder': False,
        'decoder': False,
        'mm_field': False,
        'letter_case': False,
        'exclude': False,
    }

    assert Sample().__dataclasses_json__['metadata'] == {
        'a': 'b',
        'b': 'c'
    }

# Generated at 2022-06-23 16:39:15.917490
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-23 16:39:25.434966
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    @dataclasses.dataclass
    @config(
        mm_field=marshmallow.fields.Integer(),
        encoder=lambda i: i + 1,
        decoder=lambda i: i - 1,
    )
    class A:
        a: int
    assert A.__dataclasses_json__.encoder(1) == 2
    assert A.__dataclasses_json__.decoder(2) == 1
    assert isinstance(A.__dataclasses_json__.mm_field, marshmallow.fields.Integer)
    assert A.__dataclasses_json__.undefined is Undefined.EXCLUDE
    assert A.__dataclasses_json__.letter_case is str.lower

# Generated at 2022-06-23 16:39:26.620355
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field = 'a'
    assert Exclude.NEVER(field)

# Generated at 2022-06-23 16:39:28.095153
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	class K:
		pass
	k=K()
	assert Exclude.ALWAYS(k)


# Generated at 2022-06-23 16:39:31.794268
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    @dataclass
    class MyClass:
        number: int = config(encoder=int)

    #     obj = MyClass()
    #     assert obj.number == 0

# Generated at 2022-06-23 16:39:35.389001
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_ = _GlobalConfig()
    assert(global_.encoders == {})
    assert(global_.decoders == {})
    assert(global_.mm_fields == {})


# Generated at 2022-06-23 16:39:36.810853
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:39:39.290850
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def correct_NEVER_test():
        return NEVER.__qualname__ == 'Exclude.NEVER'

    assert correct_NEVER_test()

# Generated at 2022-06-23 16:39:41.762419
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('') == True


# Generated at 2022-06-23 16:39:44.728315
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-23 16:39:49.421562
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:39:56.689397
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Foo:
        def __init__(self):
            self.foo_field = 3
    # create instance of class Foo
    foo_var = Foo()
    # method NEVER of class Exclude returns False if field is excluded
    assert not Exclude.NEVER(foo_var)


# Generated at 2022-06-23 16:40:00.456067
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)
    assert not Exclude.ALWAYS("Hello")
    assert Exclude.NEVER("Hello")

test_Exclude()

# Generated at 2022-06-23 16:40:10.093142
# Unit test for function config
def test_config():
    from marshmallow.fields import Decimal
    from dataclasses import dataclass, fields
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class ConfigMixin(DataClassJsonMixin):
        config_name: str = config(field_name='config_name1')
        config_letter: str = config(letter_case=str.lower, field_name='config_letter1')
        config_encoder: str = config(encoder=str)
        config_decoder: str = config(decoder=str)
        config_mm_field: str = config(mm_field=Decimal)
        config_undefined: str = config(undefined='raise')
        config_exclude: str = config(exclude=config.EXCLUDE.ALWAYS)


# Generated at 2022-06-23 16:40:21.048071
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(mm_field=fields.Int(), field_name="renamed_field", exclude=Exclude.NEVER, letter_case=lambda x: x.upper())
    class Configured:
        field: int

    assert Configured.__dataclass_fields__['field'].metadata == {
        'dataclasses_json': {
            'mm_field': fields.Int(),
            'field_name': 'renamed_field',
            'exclude': Exclude.NEVER,
            'letter_case': lambda x: x.upper()
        }
    }

# Generated at 2022-06-23 16:40:24.274090
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-23 16:40:30.285883
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # We assume that the method NEVER returns false for all objects
    assert Exclude.NEVER("test")==False
    assert Exclude.NEVER([1,2,3])==False
    assert Exclude.NEVER(4)==False
    assert Exclude.NEVER((5,5))==False

# Generated at 2022-06-23 16:40:40.384369
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(1.0) == True
    assert Exclude.ALWAYS(2.0) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(['a']) == True


# Generated at 2022-06-23 16:40:43.940377
# Unit test for constructor of class Exclude
def test_Exclude():
    x = Exclude()

    assert x.ALWAYS('a') == True
    assert x.NEVER('a') == False


# Generated at 2022-06-23 16:40:45.673416
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global global_config
    global_config = _GlobalConfig()
    assert global_config.mm_fields == {}
    assert global_config.encoders == {}
    assert global_config.decoders == {}


# Generated at 2022-06-23 16:40:46.555059
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:40:53.874202
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(1.234) == True
    assert Exclude.ALWAYS("Hello") == True
    assert Exclude.ALWAYS([1,2,3]) == True
    assert Exclude.ALWAYS((1,2,3)) == True
    assert Exclude.ALWAYS({1,2,3}) == True
    assert Exclude.ALWAYS({1:"a", 2:"b", 3:"c"}) == True

# Generated at 2022-06-23 16:41:04.119967
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.undefined import EXCLUDE, SKIP
    from marshmallow import Schema, fields

    @config(encoder=list, decoder=dict)
    @dataclass
    class Point:
        x: int
        y: int

    # Function config @decorator
    assert Point.__dataclass_json__.encoder is list
    assert Point.__dataclass_json__.decoder is dict

    # Function config @decorator
    assert Point.__dataclass_json__.undefined is SKIP

    # Function config @decorator
    assert Point.__dataclass_json__.exclude is None

    # Function config @decorator
    assert Point.__dataclass_json__.mm_field is None

   

# Generated at 2022-06-23 16:41:05.392280
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("anything")
    assert not Exclude.NEVER("anything")

# Generated at 2022-06-23 16:41:06.809512
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-23 16:41:08.027903
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-23 16:41:10.160380
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert not Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-23 16:41:18.406585
# Unit test for function config
def test_config():
    class Test:
        def __init__(self, name: str) -> None:
            self.name = name


# Generated at 2022-06-23 16:41:24.010171
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Assuming that the global variable is initialized
    # global_config = GlobalConfig()
    # print(global_config.encoders)

    # Create a dict
    dict_to_encode = {'a': 1, 'b': 2, 'c': 3}

    # The method NEVER always returns False
    assert Exclude.NEVER(dict_to_encode) == False


# Generated at 2022-06-23 16:41:26.670158
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('A')
    assert Exclude.ALWAYS(Exclude.NEVER)


# Generated at 2022-06-23 16:41:28.928416
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  if (Exclude.ALWAYS(True) != True 
      and Exclude.ALWAYS(False) != True):
    exit()


# Generated at 2022-06-23 16:41:30.318000
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-23 16:41:33.667240
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(1.2) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS({"a":1}) == True


# Generated at 2022-06-23 16:41:34.821100
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig



# Generated at 2022-06-23 16:41:45.853264
# Unit test for function config
def test_config():

    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

    @dataclass
    class MyIntClass:
        value: int

    @config(encoder=lambda o: 'encoded_' + str(o))
    @dataclass
    class MyIntClassEncoded:
        value: int

    @config(decoder=lambda o: int('decoded_'+ o))
    @dataclass
    class MyIntClassEncodedDecoded:
        value: int

    @config(mm_field=Int)
    @dataclass
    class MyIntClassEncodedDecodedField:
        value: int


# Generated at 2022-06-23 16:41:54.376432
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str = 'John Doe'
        age: int = 0

    assert config() == {
        'dataclasses_json': {
            'undefined': Undefined.EXCLUDE,
        }
    }


# Generated at 2022-06-23 16:41:55.525215
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("hallo") == False


# Generated at 2022-06-23 16:41:56.935777
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-23 16:41:57.818586
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:41:59.688876
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(123)



# Generated at 2022-06-23 16:42:01.747874
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {}
    global_config.decoders = {}
    global_config.mm_fields = {}


# Generated at 2022-06-23 16:42:03.355928
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-23 16:42:06.673960
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("a") == False

# Generated at 2022-06-23 16:42:08.121497
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:42:10.709792
# Unit test for function config
def test_config():
    @dataclass
    @config(metadata=dict(field_name='a'))
    class A:
        a: int
    assert get_field_metadata(A, "a")['field_name'] == 'a'

# Generated at 2022-06-23 16:42:11.982750
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True), "Exclude.ALWAYS failed"


# Generated at 2022-06-23 16:42:12.882047
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert _GlobalConfig()

# Generated at 2022-06-23 16:42:15.758694
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == (lambda _: False)(1)


# Generated at 2022-06-23 16:42:25.189341
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # 1
    @dataclass
    class Dummy:
        pass

    assert Exclude.NEVER(Dummy()) == False

    # 2
    @dataclass
    class Dummy:
        pass
    assert Exclude.NEVER(Dummy()) == False

    # 3
    @dataclass
    class Dummy:
        pass
    assert Exclude.NEVER(Dummy()) == False

    # 4
    @dataclass
    class Dummy:
        pass
    assert Exclude.NEVER(Dummy()) == False

    # 5
    @dataclass
    class Dummy:
        pass
    assert Exclude.NEVER(Dummy()) == False


# Generated at 2022-06-23 16:42:26.794668
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-23 16:42:37.389857
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}

    assert ('dataclasses_json' in config(encoder=str)
            and 'encoder' in config(encoder=str)['dataclasses_json'])

    assert ('dataclasses_json' in config(decoder=lambda x: x)
            and 'decoder' in config(decoder=lambda x: x)['dataclasses_json'])

    assert ('dataclasses_json' in config(mm_field='test')
            and 'mm_field' in config(mm_field='test')['dataclasses_json'])

    assert ('dataclasses_json' in config(letter_case=lambda x: x)
            and 'letter_case' in config(letter_case=lambda x: x)['dataclasses_json'])

   

# Generated at 2022-06-23 16:42:39.954524
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(Exclude.ALWAYS) == True


# Generated at 2022-06-23 16:42:41.803130
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test') == True


# Generated at 2022-06-23 16:42:44.593280
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj1 = Exclude.NEVER("abc")
    assert type(obj1) == bool
    assert obj1 == False


# Generated at 2022-06-23 16:42:48.901559
# Unit test for constructor of class Exclude
def test_Exclude():
    ex = Exclude()
    assert ex.ALWAYS == (lambda _: True)
    assert ex.NEVER == (lambda _: False)

# Generated at 2022-06-23 16:42:49.876699
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False




# Generated at 2022-06-23 16:42:58.638996
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow

    @dataclasses.dataclass
    @config(encoder=int,
            field_name=lambda f: f.name.upper(),
            letter_case=lambda f: f.lower(),
            exclude=lambda f, v: f.name == v,
            undefined=Undefined.RAISE)
    class Foo:
        d: str = dataclasses.field(repr=False)
        a: int = dataclasses.field(metadata={'example': 1})
        # Undefined will overwrite the class level setting
        # For this field, raise an error
        b: int = dataclasses.field(metadata={'undefined': Undefined.RAISE})
        # For this field, silently replace with None

# Generated at 2022-06-23 16:43:00.898755
# Unit test for constructor of class Exclude
def test_Exclude():
    t=Exclude()
    assert type.__module__=='dataclasses_json.config'



# Generated at 2022-06-23 16:43:02.332463
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:43:06.738860
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(False) is False
    assert Exclude.NEVER(None) is False
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(0) is False



# Generated at 2022-06-23 16:43:08.349584
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-23 16:43:10.628384
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:43:15.209806
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert(isinstance(global_config.encoders, dict))
    assert(isinstance(global_config.decoders, dict))
    assert(isinstance(global_config.mm_fields, dict))
    #assert(global_config.json_module is json)


# Generated at 2022-06-23 16:43:17.033015
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-23 16:43:21.265270
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    globalConfig = _GlobalConfig()
    globalConfig.encoders
    globalConfig.decoders
    globalConfig.mm_fields

# Generated at 2022-06-23 16:43:28.478221
# Unit test for function config
def test_config():
    from dataclasses import dataclass, fields, asdict
    from dataclasses_json import config


    @dataclass
    class C:
        a: int = 0
        b: int = 1
        c: int = 2

    C.__annotations__

    @config(exclude=Exclude.NEVER)
    @dataclass
    class D:
        a: int = 0
        b: int = 1
        c: int = 2
    assert len(fields(D)) == 3

    @config(exclude=lambda f, v: f.name in ["a", "b"])
    @dataclass
    class E:
        a: int = 0
        b: int = 1
        c: int = 2

    # TODO: test on dumping?
    assert len(fields(E)) == 1

# Generated at 2022-06-23 16:43:36.012182
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Check Global Config
    assert isinstance(global_config, _GlobalConfig)
    assert not global_config.encoders
    assert not global_config.decoders
    assert not global_config.mm_fields

    # Check config
    from marshmallow import fields
    from dataclasses import dataclass

    @dataclass
    @config(mm_field=fields.Integer(dump_to="int_field"))
    class Test:
        test: int

    assert global_config.mm_fields[Test] == fields.Integer(dump_to="int_field")


# Generated at 2022-06-23 16:43:40.864774
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert('encoders' in global_config.encoders)
    assert('decoders' in global_config.decoders)
    assert('mm_fields' in global_config.mm_fields)
    assert(Exclude.ALWAYS(T=None))
    assert(not Exclude.NEVER(T=None))


# Generated at 2022-06-23 16:43:41.464422
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()

# Generated at 2022-06-23 16:43:44.075343
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(True)
    assert Exclude.ALWAYS(True)
    assert Exclude.NEVER(True)

# Generated at 2022-06-23 16:43:46.304151
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config1 = _GlobalConfig()
    assert config1 is not None
    pass

# Generated at 2022-06-23 16:43:50.120653
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_conf = _GlobalConfig()
    assert isinstance(global_conf.encoders, dict)
    assert isinstance(global_conf.decoders, dict)
    assert isinstance(global_conf.mm_fields, dict)


# Generated at 2022-06-23 16:43:54.023778
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass_json(decode=True)
    @config(exclude=Exclude.NEVER)
    @dataclass
    class Dog:
        name: str
    Dog(name="Hachi").to_json() == '{"name":"Hachi"}'


# Generated at 2022-06-23 16:43:55.034492
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-23 16:43:59.160322
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dic = {1: 2, 6: 7}
    keys = [1, 5]
    ret = dict(filter(lambda ele: Exclude.ALWAYS(ele[0]), dic.items()))
    assert ret == dic


# Generated at 2022-06-23 16:44:00.081655
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(99)


# Generated at 2022-06-23 16:44:02.467543
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    obj = 'aaa'
    res = Exclude.ALWAYS(obj)
    assert res == True


# Generated at 2022-06-23 16:44:03.821147
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:44:09.685217
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('hello')
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS('abc')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({'int': 1, 'float': 1.1, 'arr': [1, 2, 3]})


# Generated at 2022-06-23 16:44:19.772029
# Unit test for function config
def test_config():
    # Testing the functionality
    from dataclasses import dataclass
    from marshmallow import fields

    from dataclasses_json.config import config

    @config(encoder=lambda x: "encoded",
            decoder=lambda _: "decoded",
            mm_field=fields.String(),
            letter_case=lambda x: "upper_case",
            field_name="field_name",
            undefined=Undefined.EXCLUDE,
            exclude=Exclude.NEVER,
            )
    @dataclass
    class Person:
        name: str
        age: int

    # Testing that `metadata` is always returned
    metadata = config(encoder=lambda x: "encoded")
    assert "dataclasses_json" in metadata
    assert "encoder" in metadata["dataclasses_json"]

    #