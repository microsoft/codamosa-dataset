

# Generated at 2022-06-23 16:34:20.422622
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(int)

# Generated at 2022-06-23 16:34:24.169613
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS((1,)) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS({}) == True


# Generated at 2022-06-23 16:34:33.519262
# Unit test for function config
def test_config():
    import unittest
    import dataclasses

    @dataclasses.dataclass
    class ConfigData:
        test: str

    class ConfigTest(unittest.TestCase):
        def test_1(self):
            @dataclasses.dataclass
            class ExampleData:
                test: str = dataclasses.field(metadata={
                    'dataclasses_json': {
                        'encoder': 'test_encoder',
                        'decoder': 'test_decoder',
                        'mm_field': 'test_field',
                    }
                })

            # config(metadata=ExampleData, encoder='test_config_function')
            # assert hasattr(ExampleData, 'test')
            # assert getattr(ExampleData, 'test').metadata['encoder'] == 'test_config_function'


# Generated at 2022-06-23 16:34:36.729811
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(False) is False

# Generated at 2022-06-23 16:34:39.769489
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True, "Exclude.ALWAYS should return True."


# Generated at 2022-06-23 16:34:42.571364
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    func = Exclude.NEVER
    res1 = func("a")
    res2 = func("b")
    res3 = func("c")
    assert not (res1 and res2 and res3)



# Generated at 2022-06-23 16:34:44.258377
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("abc") == True
    assert Exclude.NEVER("abc") == False

# Generated at 2022-06-23 16:34:46.078040
# Unit test for function config
def test_config():
    try:
        config(undefined="a")
        assert False
    except UndefinedParameterError:
        pass

    metadata = config(exclude=Exclude.ALWAYS)
    assert metadata['dataclasses_json']['exclude'] == Exclude.ALWAYS

# Generated at 2022-06-23 16:34:47.705710
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    testField = Exclude.NEVER
    assert testField('abcd') == False


# Generated at 2022-06-23 16:34:49.922775
# Unit test for constructor of class Exclude
def test_Exclude():
    assert str(Exclude.ALWAYS(True)) == 'True'
    assert str(Exclude.NEVER(True)) == 'False'


# Generated at 2022-06-23 16:34:50.981389
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True

# Generated at 2022-06-23 16:34:53.498516
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:34:54.836075
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    e = Exclude()
    assert e.NEVER('test')

# Generated at 2022-06-23 16:34:57.508146
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-23 16:35:05.218690
# Unit test for function config
def test_config():
    from dataclasses import field
    from marshmallow import Schema, fields
    from marshmallow_enum import EnumField

    from dataclasses import dataclass

    @dataclass
    class Config:
        name: str = field(metadata=config(field_name='NAME',
                                          letter_case=str.lower))
        type: str = field(metadata=config(field_name='TYPE',
                                          letter_case=lambda x: x.upper()))
        kind: str = field(metadata=config(exclude=Exclude.ALWAYS))

    result = Config()
    assert result.name == 'NAME'
    assert result.type == 'TYPE'
    assert result.kind is None


    class MyEnum:
        FOO = 'Foo'
        BAR = 'Bar'


# Generated at 2022-06-23 16:35:14.422799
# Unit test for function config
def test_config():
    """
    Test if config function is working fine.
    """
    from dataclasses import dataclass

    @dataclass
    class TestDataClass:
        """
        Test by creating fake dataclass.
        """
        var_1: int = 3
        var_2: int = 5

    def my_encoder(obj: TestDataClass) -> dict:
        """
        Fake encoder.
        """
        return {"var1": obj.var_1, "var2": obj.var_2}

    def my_decoder(obj: dict) -> TestDataClass:
        """
        Fake decoder.
        """
        return TestDataClass(
            var_1=obj["var1"],
            var_2=obj["var2"]
        )


# Generated at 2022-06-23 16:35:22.934320
# Unit test for function config
def test_config():

    # Test for default metadata
    metadata = config()
    assert metadata == {'dataclasses_json': {}}

    # Test for config with defined metadata
    metadata = config(metadata={'test_metadata': 'test'})
    assert metadata == {'test_metadata': 'test', 'dataclasses_json': {}}

    # Test for valid encoder
    def test_encoder():
        pass

    metadata = config(encoder=test_encoder)
    assert metadata == {'dataclasses_json': {'encoder': test_encoder}}

    # Test for valid decoder
    def test_decoder():
        pass

    metadata = config(decoder=test_decoder)
    assert metadata == {'dataclasses_json': {'decoder': test_decoder}}

    # Test for valid mm_field
   

# Generated at 2022-06-23 16:35:25.143291
# Unit test for constructor of class Exclude
def test_Exclude():
    e = Exclude()
    assert e.ALWAYS == True
    assert e.NEVER == False

# Generated at 2022-06-23 16:35:27.141468
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:35:29.830781
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert 'encoders' in global_config.__dict__
    assert 'decoders' in global_config.__dict__
    assert 'mm_fields' in global_config.__dict__

# Generated at 2022-06-23 16:35:33.389215
# Unit test for function config
def test_config():
    metadata = config(encoder=lambda foo: foo)
    assert metadata['dataclasses_json']['encoder'] == '<lambda>'

# Test for function config

# Generated at 2022-06-23 16:35:35.323016
# Unit test for constructor of class Exclude
def test_Exclude():
    def test1():
        return Exclude.ALWAYS
    assert test1()() == True
    def test2():
        return Exclude.NEVER
    assert test2()() == False


# Generated at 2022-06-23 16:35:39.314163
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Metadata = {'dataclasses_json': {'exclude': Exclude.NEVER}}
    result = config(Metadata)
    expected = {'dataclasses_json': {'exclude': Exclude.NEVER}}
    assert(expected == result)


# Generated at 2022-06-23 16:35:41.774867
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    f = Exclude.ALWAYS
    assert f(1) == True
    assert f(None) == True
    assert f(True) == True


# Generated at 2022-06-23 16:35:43.182198
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('ANYTHING') is True


# Generated at 2022-06-23 16:35:45.429670
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Set example value
    _value = True
    # Method ALWAYS of class Exclude returns always same value _value
    assert Exclude.ALWAYS(_value) == _value


# Generated at 2022-06-23 16:35:48.847510
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-23 16:35:52.819841
# Unit test for constructor of class Exclude
def test_Exclude():
    try:
        obj1 = Exclude.ALWAYS
        obj2 = Exclude.NEVER
    except:
        return False
    return True


# Generated at 2022-06-23 16:35:54.379106
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:35:58.641414
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert set(global_config.encoders.keys()) == set()
    assert set(global_config.decoders.keys()) == set()
    assert set(global_config.mm_fields.keys()) == set()

if __name__ == "__main__":
    test__GlobalConfig()

# Generated at 2022-06-23 16:36:02.546316
# Unit test for constructor of class Exclude
def test_Exclude():
    assert (callable(Exclude.ALWAYS))
    assert (callable(Exclude.NEVER))

    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:36:03.835711
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(7)


# Generated at 2022-06-23 16:36:10.522874
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS('abc') == True
    assert Exclude.ALWAYS(1.23) == True
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER('abc') == False
    assert Exclude.NEVER(1.23) == False

# Generated at 2022-06-23 16:36:17.434859
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == True
    assert Exclude.NEVER(1) == True
    assert Exclude.NEVER(False) == True
    assert Exclude.NEVER(True) == True
    assert Exclude.NEVER('') == True
    assert Exclude.NEVER('foo') == True
    assert Exclude.NEVER(dict()) == True
    assert Exclude.NEVER(dict(foo=[])) == True
    assert Exclude.NEVER([]) == True
    assert Exclude.NEVER([1, 2, 3]) == True

# Generated at 2022-06-23 16:36:24.991232
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)
    global_config.encoders = "Hello"
    global_config.decoders = "World"
    global_config.mm_fields = "!"
    assert global_config.encoders == "Hello"
    assert global_config.decoders == "World"
    assert global_config.mm_fields == "!"

# Generated at 2022-06-23 16:36:26.757079
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    o = Exclude()
    t = o.ALWAYS("whatever")
    assert t is True


# Generated at 2022-06-23 16:36:28.507245
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:36:36.982222
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    This method is used to test the method NEVER of class Exclude
    """
    case_1 = True
    case_2 = False
    case_input = [case_1, case_2]
    case_output = [False, False]
    for i, _ in enumerate(case_input):

        if Exclude.NEVER(case_input[i]) == case_output[i]:
            print("Test case {} passed".format(i))
        else:
            print("Test case {} failed".format(i))



# Generated at 2022-06-23 16:36:37.703218
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)

# Generated at 2022-06-23 16:36:39.680757
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()
    assert obj.encoders == {}
    assert obj.decoders == {}
    assert obj.mm_fields == {}
    # assert obj.json_module == json


# Generated at 2022-06-23 16:36:41.374943
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(2)

# Generated at 2022-06-23 16:36:43.863589
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-23 16:36:50.474092
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields as mm_fields

    @dataclass
    class MyClass:
        a: int
        b: int = 1

    assert MyClass.__dict__ == config(MyClass.__dict__)
    assert MyClass.__dict__ == config(encoder=int)
    assert MyClass.__dict__ != config(encoder=int, mm_field=mm_fields.Integer())
    assert MyClass.__dict__ == config(metadata=MyClass.__dict__,
                                      encoder=int, mm_field=mm_fields.Integer())

# Generated at 2022-06-23 16:36:51.911966
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:36:53.905719
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER.__name__ == '<lambda>'
    assert Exclude.NEVER('KeyForTestNever') == False



# Generated at 2022-06-23 16:36:55.424078
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('mike')
    assert not Exclude.NEVER('mike')

# Generated at 2022-06-23 16:36:56.534776
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None))


# Generated at 2022-06-23 16:36:57.370094
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_test = _GlobalConfig()

# Generated at 2022-06-23 16:36:58.184611
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False

# Generated at 2022-06-23 16:37:00.248648
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:37:02.051323
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('anything') == True


# Generated at 2022-06-23 16:37:03.701085
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) is True


# Generated at 2022-06-23 16:37:07.173119
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders is not None
    assert global_config.decoders is not None
    assert global_config.mm_fields is not None

test__GlobalConfig()

# Generated at 2022-06-23 16:37:11.453914
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(100) == True
    assert Exclude.ALWAYS(3.14) == True
    assert Exclude.ALWAYS("Hello World!") == True


# Generated at 2022-06-23 16:37:12.948676
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("any") == True


# Generated at 2022-06-23 16:37:24.643536
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class TestDataClass:
        some_class_variable: str
        some_other_variable: str

    assert TestDataClass.__annotations__.keys() == {'some_class_variable', 'some_other_variable'}

    @config(metadata=config(field_name='some_other_variable'))
    class TestDataClass:
        some_class_variable: str
        some_other_variable: str

    assert TestDataClass.__annotations__.keys() == {'some_class_variable', 'some_other_variable'}
    assert TestDataClass.__dataclass_fields__['some_other_variable'].metadata['dataclasses_json']['field_name'] == 'some_other_variable'


# Generated at 2022-06-23 16:37:31.083930
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    @config(undefined='silent', field_name='f')
    class TestClass:
        f: int

    assert TestClass._field_metadata['f']['dataclasses_json']['undefined'] == Undefined.SILENT
    assert TestClass._field_metadata['f']['dataclasses_json']['field_name'] == 'f'



# Generated at 2022-06-23 16:37:39.249109
# Unit test for function config
def test_config():
    assert config() == {}

# Generated at 2022-06-23 16:37:44.681877
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER({})
    assert Exclude.NEVER([])
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(38.3)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-23 16:37:47.658168
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)

# Generated at 2022-06-23 16:37:50.448643
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert (global_config.decoders == {})
    assert (global_config.encoders == {})

test__GlobalConfig()

# Generated at 2022-06-23 16:37:51.350389
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(100) == True

# Generated at 2022-06-23 16:37:52.566449
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:37:54.287325
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Replace this for custom test
    assert Exclude.NEVER(Exclude.NEVER)



# Generated at 2022-06-23 16:37:55.830187
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)



# Generated at 2022-06-23 16:38:02.966597
# Unit test for function config
def test_config():
    @dataclass_json
    @config(undefined=Undefined.EXCLUDE)
    class Test:
        a: int

    assert Test.__dataclass_metadata__['dataclasses_json']['undefined'] == Undefined.EXCLUDE

    # Unit test for invalid undefined parameter
    try:
        @dataclass_json
        @config(undefined=Undefined.RAISE)
        class InvalidTest:
            a: int
    except UndefinedParameterError:
        pass



# Generated at 2022-06-23 16:38:05.692216
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER('a')
    assert not Exclude.NEVER('b')
    assert not Exclude.NEVER('c')


# Generated at 2022-06-23 16:38:06.880374
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()


# Generated at 2022-06-23 16:38:09.581555
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(dict())
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(())



# Generated at 2022-06-23 16:38:11.325335
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('anything')



# Generated at 2022-06-23 16:38:15.140536
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER('a')
    assert Exclude.NEVER([])
    assert Exclude.NEVER({})
    assert Exclude.NEVER(())


# Generated at 2022-06-23 16:38:18.509381
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert len(global_config.encoders) == 0
    assert len(global_config.decoders) == 0
    assert len(global_config.mm_fields) == 0

# Generated at 2022-06-23 16:38:23.546967
# Unit test for function config
def test_config():
    expected = {'exclude': Exclude.ALWAYS}
    actual = config(metadata={}, exclude=Exclude.ALWAYS)
    assert actual == {'dataclasses_json': expected}

    config(metadata={'a': 1}, exclude=Exclude.NEVER)
    assert actual == {'dataclasses_json': expected,
                      'a': 1}

# Generated at 2022-06-23 16:38:24.780810
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-23 16:38:33.434478
# Unit test for function config
def test_config():
    import marshmallow as mm
    class Test:
        @classmethod
        def __init_subclass__(cls, *args, **kwargs):
            cls.__annotations__ = dict(cls.__annotations__, **kwargs)
            return super().__init_subclass__(*args, **kwargs)
    class TestField(mm.fields.Field):
        pass


# Generated at 2022-06-23 16:38:35.630722
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert(global_config.mm_fields == {})
    assert(global_config.encoders == {})
    assert(global_config.decoders == {})

# Generated at 2022-06-23 16:38:38.519146
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS((1, 2)) is True
    assert Exclude.NEVER((2, 3)) is False


# Generated at 2022-06-23 16:38:40.288459
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-23 16:38:43.464527
# Unit test for constructor of class Exclude
def test_Exclude():
    class Test:
        def __init__(self):
            pass
    t = Test()
    assert(Exclude.ALWAYS(t))
    assert(not Exclude.NEVER(t))

# Generated at 2022-06-23 16:38:53.561846
# Unit test for function config
def test_config():
    from collections import UserDict
    from marshmallow import fields as mm_fields

    @dataclass_json
    @config(encoder=list, decoder=dict)
    class A:
        lst: list
        dct: UserDict

    @dataclass_json
    @config(mm_field=mm_fields.List)
    class B:
        lst: list

    @dataclass_json
    @config(letter_case=lambda s: s.upper())
    class C:
        hello: str

    @dataclass_json
    @config(undefined='EXCLUDE')
    class D:
        hello: str

    @dataclass_json
    @config(field_name='world')
    class E:
        hello: str


# Generated at 2022-06-23 16:39:01.872127
# Unit test for function config
def test_config():
    import unittest
    import datetime
    from marshmallow import fields
    from dataclasses import dataclass

    @dataclass
    class SomeData:
        date: datetime.date = config(decoder=lambda d: datetime.date(int(d['y']), int(d['m']), int(d['d'])))

    data = SomeData.schema().load({'date':{'y': 2018,'m': 1,'d': 15}})
    assert data.date == datetime.date(2018,1,15)
    data = SomeData(datetime.datetime(2018, 1, 15))
    result = SomeData.schema().dump(data)
    assert result['date'] == {'y': 2018,'m': 1,'d': 15}

# Util for tests

# Generated at 2022-06-23 16:39:05.901525
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def _is_a(a):
        return a == "a"
    assert Exclude.NEVER(_is_a("b")) == False
    assert Exclude.NEVER(_is_a("a")) == False


# Generated at 2022-06-23 16:39:14.705175
# Unit test for function config
def test_config():
    import pytest
    from marshmallow import ValidationError
    from marshmallow_dataclass import class_schema

    from dataclasses_json.undefined import Undefined, UndefinedError

    dummy_class = class_schema({
        "test": str,
    })(object)

    def test_encoder(obj):
        return str(obj) + "!"

    def test_decoder(json: str):
        return json[:-1]

    def test_field(name: str):
        return name + "_field"

    def test_letter_case(name: str):
        return name.capitalize()

    def test_exclude(name: str, obj: dummy_class):
        return name == obj.test


# Generated at 2022-06-23 16:39:16.316781
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest
    assert Exclude.NEVER('Field') is False


# Generated at 2022-06-23 16:39:22.364911
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    class Person:
        name: str
        age: int = field(metadata={'dataclasses_json': {'exclude': Exclude.NEVER}})

    p = Person('Eric', 35)
    json = p.to_json()
    assert json == '{"name": "Eric", "age": 35}'

    p = p.from_json(json)
    assert p.name == 'Eric'
    assert p.age == 35


# Generated at 2022-06-23 16:39:24.171934
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-23 16:39:25.106316
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("foobar")

# Generated at 2022-06-23 16:39:32.421496
# Unit test for constructor of class _GlobalConfig

# Generated at 2022-06-23 16:39:36.014488
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:39:36.675249
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-23 16:39:40.548461
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Test:
        my_val: str
        def __init__(self, my_val) -> None:
            self.my_val = my_val

    test_obj = Test('test')
    assert Exclude.NEVER(test_obj) is True



# Generated at 2022-06-23 16:39:52.844715
# Unit test for function config
def test_config():
    cls = dataclasses.make_dataclass('TestDataClass', [
        ('a', int, config()),
        ('b', int, config(exclude=Exclude.ALWAYS)),
        ('c', int, config(exclude=Exclude.NEVER)),
        ('d', int, config(undefined=Undefined.EXCLUDE)),
        ('e', int, config(undefined=Undefined.RAISE)),
        ('f', int, config(undefined=Undefined.INCLUDE)),
    ])


# Generated at 2022-06-23 16:39:54.525860
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()
    assert not obj.encoders
    assert not obj.decoders
    assert not obj.mm_fields

# Generated at 2022-06-23 16:39:57.495061
# Unit test for constructor of class Exclude
def test_Exclude():
    x = Exclude()
    assert(x.ALWAYS("") == True)
    assert(x.NEVER("") == False)


# Generated at 2022-06-23 16:40:00.896309
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(2)


# Generated at 2022-06-23 16:40:07.670024
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int = config()
        b: str = config(field_name='test')
        c: int = config(field_name='test', letter_case=lambda x: x.upper())
        d: int = config(letter_case=lambda x: x)
        e: int = config(undefined=Undefined.ERROR)
        f: int = config(undefined=Undefined.STRICT)
        g: int = config(undefined=Undefined.RAISE)
        h: int = config(undefined=Undefined.USE_KWARGS)
        i: int = config(undefined=Undefined.SKIP)
        j: int = config(undefined=Undefined.PASS)

# Generated at 2022-06-23 16:40:11.718694
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass
    class User:
        id: int = 1
        name: str = 'user1'
        phone: str = None

    user = User()
    assert user.id == 1
    assert user.name == 'user1'
    assert user.phone is None


# Generated at 2022-06-23 16:40:13.958280
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(1)

# Generated at 2022-06-23 16:40:17.365989
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(object)
    assert Exclude.ALWAYS(1234)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:40:19.269781
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-23 16:40:20.629584
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('abc')
    assert not Exclude.NEVER('abc')

# Generated at 2022-06-23 16:40:23.615402
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:40:25.132521
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER("a")

# Generated at 2022-06-23 16:40:33.885200
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass

    @dataclass
    class MyClass:
        a: str
        b: str

    MyClass_json = MyClass.__json__()
    MyClass_json.update({"exclude": Exclude.NEVER, "mm_field": str})

    assert MyClass_json == {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "a": {
                "type": "string"
            },
            "b": {
                "type": "string"
            }
        },
        "exclude": Exclude.NEVER,
        "mm_field": str
    }


# Generated at 2022-06-23 16:40:41.937909
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from flask.json import jsonify
    from flask import Flask
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        lastname: str
        age: int

    app = Flask(__name__)

    # Use exclude with function NEVER of the class Exclude
    @app.route('/testExclude_NEVER')
    def testExclude_NEVER():
        person1 = Person('John','Lennon',40)
        return jsonify(person1)

    if __name__ == '__main__':
        app.run(debug=True)

# Test for method ALWAYS of class Exclude

# Generated at 2022-06-23 16:40:51.415564
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = dict()
    if global_config.encoders != dict():
        raise Exception('Test #1 has failed!')
    if global_config.decoders != dict():
        raise Exception('Test #2 has failed!')
    if global_config.mm_fields != dict():
        raise Exception('Test #3 has failed!')
    #global_config.json_module = ""
    #if global_config.json_module != "":
    #    raise Exception('Test #4 has failed!')

# Generated at 2022-06-23 16:40:57.101077
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER
    assert result(8) == False
    assert result(1) == False
    assert result([1,2,3]) == False
    assert result(None) == False
    assert result([]) == False
    

# Generated at 2022-06-23 16:40:58.490989
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:40:59.701243
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders=={}
    assert global_config.decoders=={}

# Generated at 2022-06-23 16:41:01.680162
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	if Exclude.ALWAYS(5) == True:
		print("Method ALWAYS works properly.")
	else:
		print("Method ALWAYS does not work properly.")


# Generated at 2022-06-23 16:41:09.288512
# Unit test for function config
def test_config():
    from dataclasses import dataclass

# Generated at 2022-06-23 16:41:12.164963
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:41:23.864242
# Unit test for function config
def test_config():
    import marshmallow.fields
    from typing import NamedTuple
    from marshmallow import fields

    def my_encoder(obj: NamedTuple):
        pass

    def my_decoder(obj: NamedTuple):
        pass

    class MyField(fields.Field):
        pass

    class MyTuple(NamedTuple):
        pass

    assert config(MyTuple, encoder=my_encoder) == {'dataclasses_json': {'encoder': my_encoder}}
    assert config(MyTuple, decoder=my_decoder) == {'dataclasses_json': {'decoder': my_decoder}}
    assert config(MyTuple, mm_field=MyField) == {'dataclasses_json': {'mm_field': MyField}}

# Generated at 2022-06-23 16:41:25.787724
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS != Exclude.NEVER
    assert callable(Exclude.ALWAYS)
    assert callable(Exclude.NEVER)

# Generated at 2022-06-23 16:41:27.792878
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(False) is False



# Generated at 2022-06-23 16:41:29.802167
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Unit test for method ALWAYS of class Exclude
    assert Exclude.ALWAYS("test value")


# Generated at 2022-06-23 16:41:31.949608
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-23 16:41:38.408251
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config as dcj_config

    @dataclass
    class Sample:
        field: str = dcj_config(field_name='different_name')

    assert Sample().field == 'different_name'
    assert Sample.__annotations__['field'] == 'different_name'
    assert Sample.__dict__['field'].metadata['dataclasses_json']['field_name'] == 'different_name'

# Generated at 2022-06-23 16:41:40.625497
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from marshmallow import fields

    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}



# Generated at 2022-06-23 16:41:41.221546
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _GlobalConfig()

# Generated at 2022-06-23 16:41:49.629614
# Unit test for function config
def test_config():
    # Configure the dunder
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        field_one: int

    assert config() == {'dataclasses_json': {}}

# Generated at 2022-06-23 16:41:51.121496
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('a') == True
    assert Exclude.NEVER('b') == False

# Generated at 2022-06-23 16:42:02.971631
# Unit test for function config
def test_config():
    from marshmallow import Schema, fields

    @config(exclude=Exclude.ALWAYS)
    class Model:
        foo: str
    assert Model.__dataclasses_json__['exclude'] is Exclude.ALWAYS

    @config(encoder=type)
    class Model:
        foo: str
    assert Model.__dataclasses_json__['encoder'] is type

    @config(decoder=type)
    class Model:
        foo: str
    assert Model.__dataclasses_json__['decoder'] is type

    @config(mm_field=fields.Str)
    class Model:
        foo: str
    assert Model.__dataclasses_json__['mm_field'] is fields.Str

    @config(undefined=Undefined.EXCLUDE)
    class Model:
        foo

# Generated at 2022-06-23 16:42:08.079477
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)
    # assert isinstance(global_config._json_module, json)


# Generated at 2022-06-23 16:42:10.676865
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER('a')
    assert Exclude.NEVER('b')


# Generated at 2022-06-23 16:42:14.273924
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    ex = Exclude()
    assert not ex.NEVER(1)
    assert not ex.NEVER(2)
    assert not ex.NEVER(3)
    assert not ex.NEVER(4)
    assert not ex.NEVER(5)
    assert not ex.NEVER(6)


# Generated at 2022-06-23 16:42:16.643783
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:42:19.219175
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:42:21.469187
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert g.encoders == {}
    assert g.decoders == {}

# Generated at 2022-06-23 16:42:23.050470
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:42:24.756758
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)


# Generated at 2022-06-23 16:42:25.971070
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")

# Generated at 2022-06-23 16:42:29.027334
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    funclist=Exclude.NEVER(["Asdf","bsdf"])
    assert funclist == True


# Generated at 2022-06-23 16:42:32.682792
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert(len(a.encoders) == 0)
    assert(len(a.decoders) == 0)
    assert(len(a.mm_fields) == 0)


# Generated at 2022-06-23 16:42:34.487048
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-23 16:42:37.114550
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert_equal(global_config.encoders, {})
    assert_equal(global_config.decoders, {})
    assert_equal(global_config.mm_fields, {})


# Generated at 2022-06-23 16:42:38.918909
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:42:43.620573
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test_string") is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(3.14) is True


# Generated at 2022-06-23 16:42:46.951026
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-23 16:42:49.937667
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-23 16:42:50.857269
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("hello") == False

# Generated at 2022-06-23 16:42:52.466527
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-23 16:42:59.077144
# Unit test for function config
def test_config():

    Func = Callable[..., T]

    @dataclass
    @config(encoder=Func,
            decoder=Func,
            mm_field=MarshmallowField,
            letter_case=Func,
            undefined=Undefined.EXCLUDE,
            field_name='some_field',
            exclude=Exclude.ALWAYS)
    class DummyClass:
        pass

    try:
        @dataclass
        @config(undefined='just_some_string')
        class InvalidClass:
            pass
    except UndefinedParameterError:
        pass
    else:
        raise AssertionError("Invalid undefined param action should raise")

# Generated at 2022-06-23 16:43:09.669688
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow_jsonapi import Schema

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class A():
        x: str

    @config(mm_field=fields.Integer(), encoder=int)
    @dataclass
    class B():
        x: int

    @config(field_name='Y')
    @dataclass
    class C():
        x: int

    @config(mm_field=fields.Integer(), encoder=int)
    @config(field_name='Y')
    @dataclass
    class CMM():
        x: int

    @config(letter_case=lambda s: s.lower())
    @dataclass
    class D():
        x: int


# Generated at 2022-06-23 16:43:12.071208
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config2 = _GlobalConfig()
    assert global_config2.encoders == {}
    assert global_config2.decoders == {}
    assert global_config2.mm_fields == {}


# Generated at 2022-06-23 16:43:14.291936
# Unit test for constructor of class Exclude
def test_Exclude():
    testExclude1 = Exclude.ALWAYS
    testExclude2 = Exclude.NEVER
    a = 5
    assert testExclude1(a) == True
    assert testExclude2(a) == False

# Generated at 2022-06-23 16:43:18.247887
# Unit test for function config
def test_config():
    pass
    # assert config(metadata={}, encoder=int) == {'dataclasses_json': {'encoder': int}}
    # assert config(metadata={'dataclasses_json': {'encoder': float}}, exclude=True) == {'dataclasses_json': {'encoder': float, 'exclude': True}}
    # assert config(metadata={'dataclasses_json': {'encoder': float}}, exclude=True, undefined='EXCLUDE') == {'dataclasses_json': {'encoder': float, 'exclude': True, 'undefined': Undefined.EXCLUDE}}
    # assert config(metadata={'dataclasses_json': {'encoder': float}}, exclude=True, undefined=Undefined.EXCLUDE) == {'dataclasses_json': {'encoder

# Generated at 2022-06-23 16:43:23.786385
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    with pytest.raises(TypeError):
        _GlobalConfig(1)
    with pytest.raises(TypeError):
        _GlobalConfig('str')
    with pytest.raises(TypeError):
        _GlobalConfig(True)
    with pytest.raises(TypeError):
        _GlobalConfig(1.0)
    _GlobalConfig()

# Generated at 2022-06-23 16:43:26.333356
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    assert global_config._json_module == json

# Generated at 2022-06-23 16:43:27.659669
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False



# Generated at 2022-06-23 16:43:29.046696
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("")
    assert not Exclude.NEVER("")

# Generated at 2022-06-23 16:43:31.539795
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("value") is True


# Generated at 2022-06-23 16:43:32.825063
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:43:43.457968
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import config, DataClassJsonMixin, DataclassJsonMixin
    from enum import Enum
    from typing import Optional
    from marshmallow import Schema

    @dataclass
    class MyEnum(Enum):
        foo: str
        bar: str

    @dataclass
    class DataClass(DataClassJsonMixin):
        foo: Optional[str] = None
        bar: Optional[MyEnum] = None

    class Dataclass(DataclassJsonMixin):
        foo: Optional[str] = None
        bar: Optional[MyEnum] = None


# Generated at 2022-06-23 16:43:45.097938
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(object) == True
    assert Exclude.NEVER(object) == False

# Generated at 2022-06-23 16:43:49.622540
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # Some way to test the initial values of the attributes in __init__?
    assert global_config.encoders # has to be a dictionary
    assert global_config.decoders # has to be a dictionary
    assert global_config.mm_fields # has to be a dictionary

# Generated at 2022-06-23 16:43:51.230957
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('Hello') == True



# Generated at 2022-06-23 16:44:02.672350
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from marshmallow.fields import String

    @dataclass
    class Foo:
        id: int = field(metadata=config(field_name='bar'))
        s: str = field(metadata=config(mm_field=String(allow_none=True)))

    assert Foo.__dataclasses_json__.field_map['id'].metadata['dataclasses_json'].get('field_name') == 'bar'
    assert Foo.__dataclasses_json__.field_map['s'].metadata['dataclasses_json'].get('mm_field') == String(allow_none=True)


# Generated at 2022-06-23 16:44:10.001672
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    # test for encoders
    assert global_config.encoders == {}
    global_config.encoders = dict()
    assert global_config.encoders == {}
    # test for decoders
    assert global_config.decoders == {}
    global_config.decoders = dict()
    assert global_config.decoders == {}
    # test for mm_fields
    assert global_config.mm_fields == {}
    global_config.mm_fields = dict()
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:44:13.820320
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.api import _get_field_config

    @dataclass
    class Data:
        number: int

    data_with_config = config(field_name='some_field_name')(Data)

    field_config = _get_field_config(data_with_config.__dataclass_fields__['number'])

    assert 'some_field_name' == field_config['name']
    assert Undefined.RAISE == field_config['undefined']

# Generated at 2022-06-23 16:44:15.618722
# Unit test for constructor of class Exclude
def test_Exclude():
    assert not Exclude.NEVER(True)


# Generated at 2022-06-23 16:44:25.385520
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test:
        field: int = 10

    assert config(Test.__annotations__['field']) == {'dataclasses_json': {}}

    assert config(Test.__annotations__['field'], letter_case='camelCase') == {
        'dataclasses_json': {
            'letter_case': 'camelCase'
        }
    }

    assert config(Test.__annotations__['field'], letter_case=lambda x: x) == {
        'dataclasses_json': {
            'letter_case': lambda x: x
        }
    }
