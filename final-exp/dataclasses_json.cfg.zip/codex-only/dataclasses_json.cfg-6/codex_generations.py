

# Generated at 2022-06-23 16:34:20.695976
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('string')
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)



# Generated at 2022-06-23 16:34:23.549656
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False

# Generated at 2022-06-23 16:34:30.034550
# Unit test for constructor of class Exclude
def test_Exclude():
    global Exclude
    Exclude = config()
    assert callable(Exclude.NEVER)
    assert callable(Exclude.ALWAYS)
    assert Exclude.NEVER(4) == False
    assert Exclude.ALWAYS('some') == True
    assert Exclude.NEVER(Exclude.ALWAYS) == False

if __name__ == '__main__':
    test_Exclude()

# Generated at 2022-06-23 16:34:31.731155
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    # TODO: check values?
    _GlobalConfig()


# Generated at 2022-06-23 16:34:35.464204
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders == {}
    assert gc.decoders == {}
    assert gc.mm_fields == {}
    assert gc.json_module == json

# Generated at 2022-06-23 16:34:46.275376
# Unit test for function config
def test_config():
    class Test:
        def __init__(self):
            self.m = {}

        @config()
        def test_default(self):
            self.m = {'dataclasses_json': {}}

        @config(mm_field=True)
        def test_mm_field(self):
            self.m = {'dataclasses_json': {
                'mm_field': True
            }}

        @config(field_name='name')
        def test_field_name(self):
            self.m = {'dataclasses_json': {
                'field_name': 'name'
            }}


    assert Test().m == {'dataclasses_json': {}}
    assert Test().test_default().m == {'dataclasses_json': {}}
    assert Test().test_mm_field().m

# Generated at 2022-06-23 16:34:47.916494
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    _ = config()

if __name__ == '__main__':
    test__GlobalConfig()

# Generated at 2022-06-23 16:34:51.469036
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    g = _GlobalConfig()
    assert isinstance(g, _GlobalConfig)
    assert isinstance(g.encoders, dict)
    assert isinstance(g.decoders, dict)
    assert isinstance(g.mm_fields, dict)


# Generated at 2022-06-23 16:35:02.372341
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from marshmallow import fields
    from marshmallow_dataclass import class_schema

    @dataclass
    class Foo:
        f1: int = field(metadata=config())
        f2: int = field(metadata=config(letter_case='snake_case'))
        f4: int = field(metadata=config(letter_case=lambda s: s.upper()))

        def __init__(self):
            self.f1 = 1
            self.f2 = 2
            self.f3 = 3
            self.f4 = 4

    expected_json = {'f1': 1, 'f2': 2, 'f4': 4}

    foo = Foo()
    schema = class_schema(Foo)
    assert schema.dump(foo) == expected

# Generated at 2022-06-23 16:35:04.350146
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-23 16:35:05.370508
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()



# Generated at 2022-06-23 16:35:09.372144
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert type(config.encoders) == dict
    assert type(config.decoders) == dict
    assert type(config.mm_fields) == dict
    # assert type(config.json_module) == json


# Generated at 2022-06-23 16:35:16.740451
# Unit test for function config
def test_config():
    class MyClass:
        pass

    @dataclass_json
    @dataclass_json.config(encoder=lambda a: 1,
                           decoder=lambda b: 2,
                           mm_field=MarshmallowField,
                           letter_case=lambda c: c.upper(),
                           undefined=Undefined.RAISE,
                           exclude=lambda d, e: True,
                           field_name="my_field")
    @dataclass_json.config(encoder=lambda f: 3)
    class MyDataClass(MyClass):
        field: str

    assert MyDataClass.__annotations__ == {'field': str}

# Generated at 2022-06-23 16:35:17.981748
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert not Exclude.NEVER

# Generated at 2022-06-23 16:35:25.042033
# Unit test for function config
def test_config():
    @dataclass
    class ConfigurationTest:
        test: str
        test2: str
        test3: str

    json_data = {'test': 'a',
                 'test2': 'b',
                 'test3': 'c'}

    # Check that we can get a new instance of Configuration with the given
    # configuration.
    assert dataclasses.asdict(dataclasses.replace(ConfigurationTest,
                                                  **json_data)) == json_data

    # Configure it to be camel case and not accept undefined parameters
    dataclasses.replace(ConfigurationTest,
                        **json_data,
                        **config(undefined=Undefined.RAISE,
                                 letter_case=LetterCase.CAMEL))

    # Check that we get an error when a parameter is not in the JSON data

# Generated at 2022-06-23 16:35:26.249258
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER("")
    assert result == False


# Generated at 2022-06-23 16:35:27.442659
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER(4) == False


# Generated at 2022-06-23 16:35:32.151846
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    gc = _GlobalConfig()
    assert gc.encoders.__class__.__name__ == 'dict', "encoders should be a dictionary"
    assert gc.decoders.__class__.__name__ == 'dict', "decoders should be a dictionary"
    assert gc.mm_fields.__class__.__name__ == 'dict', "mm_fields should be a dictionary"
    return True


# Generated at 2022-06-23 16:35:35.808989
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Test None
    assert (Exclude.ALWAYS(None) == True)
    # Test string
    assert (Exclude.ALWAYS("test") == True)
    # Test int
    assert (Exclude.ALWAYS(1) == True)
    # Test float
    assert (Exclude.ALWAYS(1.1) == True)
    # Test bool
    assert (Exclude.ALWAYS(True) == True)


# Generated at 2022-06-23 16:35:38.549783
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(3.4)
    assert Exclude.ALWAYS("hello")
    # Even function can be the argument
    assert Exclude.ALWAYS(Exclude.NEVER)
    return


# Generated at 2022-06-23 16:35:46.324463
# Unit test for function config
def test_config():
    class Example:
        @dataclass_json
        @dataclass
        class Example:
            field1: str

    assert Example.Example.__dataclass_fields__._fielddict['field1'].metadata\
                ['dataclasses_json']['exclude'] == Exclude.NEVER


# Generated at 2022-06-23 16:35:47.261235
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(10) == True

# Generated at 2022-06-23 16:35:49.263394
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("some_arg") == True


# Generated at 2022-06-23 16:35:53.750004
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert isinstance(global_config1.encoders, dict)
    assert isinstance(global_config1.decoders, dict)
    assert isinstance(global_config1.mm_fields, dict)

# Generated at 2022-06-23 16:35:55.354294
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:35:57.064449
# Unit test for constructor of class Exclude
def test_Exclude():
    E = Exclude
    assert E.NEVER(1) == False
    assert E.ALWAYS(1) == True

# Generated at 2022-06-23 16:35:57.547404
# Unit test for constructor of class Exclude
def test_Exclude():
    Exclude()

# Generated at 2022-06-23 16:35:58.622202
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('hello')


# Generated at 2022-06-23 16:36:04.608472
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    a = _GlobalConfig()
    assert a.encoders == {}
    assert a.decoders == {}
    assert a.mm_fields == {}
    assert a._json_module == json

    json_module = json
    a._json_module = json_module
    #assert a.json_module == json_module
    #a.json_module = json_module

# test for function config

# Generated at 2022-06-23 16:36:05.803577
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS
    assert Exclude.NEVER

# Generated at 2022-06-23 16:36:06.992814
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") is False


# Generated at 2022-06-23 16:36:08.466511
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test = Exclude.ALWAYS('test')
    assert test == True


# Generated at 2022-06-23 16:36:10.418003
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    expected = True
    actual = Exclude.ALWAYS(1)
    assert expected == actual


# Generated at 2022-06-23 16:36:12.009308
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-23 16:36:13.213879
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("abc") == True


# Generated at 2022-06-23 16:36:22.005745
# Unit test for function config
def test_config():
    """Unit test for function config"""
    test_config = config()
    assert test_config == {'dataclasses_json': {}}

    test_config1 = config(metadata={}, encoder='test_encoder')
    assert test_config1 == {
        'dataclasses_json': {
            'encoder': 'test_encoder'
        }
    }

    test_config2 = config(metadata={'dataclasses_json': {'exclude': 'test_exclude'}}, decoder='test_decoder',
                          mm_field='test_mm_field', letter_case='test_letter_case',
                          undefined='test_undefined', field_name='test_field_name')

# Generated at 2022-06-23 16:36:22.966675
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({}) == True

# Generated at 2022-06-23 16:36:25.626578
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestClass:
        pass
    obj = TestClass()
    assert Exclude.NEVER(obj)

test_Exclude_NEVER()


# Generated at 2022-06-23 16:36:28.464068
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config1 = _GlobalConfig()
    assert config1.encoders == {}
    assert config1.decoders == {}
    assert config1.mm_fields == {}
    # assert config1.json_module == json

test__GlobalConfig()


# Generated at 2022-06-23 16:36:35.780272
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config.encoders = {bool: str}
    assert global_config.encoders[bool] == str
    global_config.decoders = {str: bool}
    assert global_config.decoders[str] == bool
    from marshmallow.fields import Integer
    global_config.mm_fields = {int: Integer()}
    assert global_config.mm_fields[int] == Integer()


# Generated at 2022-06-23 16:36:37.638240
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    cfg = _GlobalConfig()
    assert cfg.encoders == {}
    assert cfg.decoders == {}
    assert cfg.mm_fields == {}


# Generated at 2022-06-23 16:36:38.610681
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('x')
    assert not Exclude.NEVER('x')

# Generated at 2022-06-23 16:36:39.804554
# Unit test for constructor of class Exclude
def test_Exclude():
    assert callable(Exclude.ALWAYS) == True
    assert callable(Exclude.NEVER) == True

# Generated at 2022-06-23 16:36:48.277873
# Unit test for constructor of class Exclude
def test_Exclude():
    assert_equals(str(Exclude()), "<class 'dataclasses_json.config._GlobalConfig'>")
    assert_equals(str(Exclude.ALWAYS), '<function Exclude.ALWAYS at 0x000001DF5AE731F8>')
    assert_equals(str(Exclude.NEVER), '<function Exclude.NEVER at 0x000001DF4C03D378>')
    assert_equals(Exclude.ALWAYS.__code__.co_argcount, 1)
    assert_equals(Exclude.NEVER.__code__.co_argcount, 1)

# Generated at 2022-06-23 16:36:49.819585
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None)
    assert not Exclude.NEVER(None)

# Generated at 2022-06-23 16:36:51.076698
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-23 16:36:52.715399
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config is not None


# Generated at 2022-06-23 16:37:00.300165
# Unit test for function config
def test_config():
    import types
    dct = config(None)
    dcj = dct['dataclasses_json']
    assert len(dcj) == 0
    dct = config(None, field_name='Test', exclude=Exclude.ALWAYS)
    dcj = dct['dataclasses_json']
    assert len(dcj) == 2
    assert dcj['field_name'] == 'Test'
    assert dcj['exclude'] == Exclude.ALWAYS
    dct = config(None, undefined='default')
    dcj = dct['dataclasses_json']
    assert len(dcj) == 1
    assert dcj['undefined'] == Undefined.DEFAULT
    dct = config(None, undefined=Undefined.EXCLUDE)
    dcj = dct['dataclasses_json']
   

# Generated at 2022-06-23 16:37:02.724540
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(2) == False

# Generated at 2022-06-23 16:37:06.176782
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config._json_module == json

# Generated at 2022-06-23 16:37:10.203116
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:37:12.033727
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def f(i):
        return i

    assert Exclude.NEVER(f) == False


# Generated at 2022-06-23 16:37:13.306665
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:37:17.110580
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert not global_config1.encoders
    assert not global_config1.decoders
    assert not global_config1.mm_fields

# Generated at 2022-06-23 16:37:18.277604
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()


# Generated at 2022-06-23 16:37:20.125544
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("foo") == False


# Generated at 2022-06-23 16:37:22.772380
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)

if __name__ == '__main__':
    test_Exclude()

# Generated at 2022-06-23 16:37:24.438550
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-23 16:37:24.962656
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude()

# Generated at 2022-06-23 16:37:27.071113
# Unit test for constructor of class Exclude

# Generated at 2022-06-23 16:37:28.837972
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(1))


# Generated at 2022-06-23 16:37:35.552153
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

    config(encoder=lambda x: str(x),
           decoder=lambda x: str(x),
           mm_field=MarshmallowField(),
           field_name="test_field",
           exclude=lambda x, y: True)

    assert global_config.encoders["test_field"] == str
    assert global_config.decoders["test_field"] == str
    assert global_config.mm_fields["test_field"] == MarshmallowField


test__GlobalConfig()

# Generated at 2022-06-23 16:37:37.212831
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert not Exclude.NEVER(Exclude.NEVER)

test_Exclude()

# Generated at 2022-06-23 16:37:46.563862
# Unit test for function config
def test_config():
    @dataclass
    class DM:
        a: int = 0

    dm = DM(1)
    assert dumps(dm, use_decimal=True,
                 sort_keys=False,
                 ) == '{"a": 1}'

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class DM:
        a: int = 1

    dm = DM(2)
    assert dumps(dm, use_decimal=True,
                 sort_keys=False,
                 ) == '{}'

    # Test for func config return value
    g = config(field_name='a')
    assert g['dataclasses_json']['field_name'] == 'a'

# Generated at 2022-06-23 16:37:54.925660
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    res1 = Exclude.ALWAYS(1)
    res2 = Exclude.ALWAYS(0)
    res3 = Exclude.ALWAYS(0.0)
    res4 = Exclude.ALWAYS(['foo', 'bar'])
    res5 = Exclude.ALWAYS({'foo': 'bar'})

    assert res1, "has failed to exclude 1"
    assert res2, "has failed to exclude 0"
    assert res3, "has failed to exclude 0.0"
    assert res4, "has failed to exclude ['foo', 'bar']"
    assert res5, "has failed to exclude {'foo': 'bar'}"



# Generated at 2022-06-23 16:37:57.094951
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    f = lambda x: False

    assert Exclude.NEVER == f


# Generated at 2022-06-23 16:38:07.274584
# Unit test for function config
def test_config():
    @dataclass
    class Test:
        a: int
        b: int

    assert Test(1, 2).__dict__ == Test(1, 2).to_dict()

    @config(mm_field=fields.String)
    @dataclass
    class Test:
        a: int
        b: int

    assert Test(1, 2).__dict__ != Test(1, 2).to_dict()
    assert Test(1, 2).to_dict() == {'a': '1', 'b': '2'}
    assert Test.schema().load({'a': '1', 'b': '2'}).dict() == \
        Test(1, 2).__dict__

    @config(encoder=lambda o: o + 10)
    @dataclass
    class Test:
        a: int


# Generated at 2022-06-23 16:38:10.469338
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config =  _GlobalConfig()
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)



# Generated at 2022-06-23 16:38:16.741813
# Unit test for function config
def test_config():
    assert config(field_name="some_name") == {
        'dataclasses_json': {'field_name': 'some_name'}}
    assert config(letter_case=lambda x: x + " for real") == {
        'dataclasses_json': {'letter_case': (
            lambda _, _letter_case=lambda x: x+" for real": _letter_case)}}

# Generated at 2022-06-23 16:38:19.988097
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:38:21.489532
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('anything') == True


# Generated at 2022-06-23 16:38:22.971631
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(3)
    assert result is False


# Generated at 2022-06-23 16:38:32.236621
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Callable[Callable[T], bool] (this is our predicate for Exclude.NEVER)
    # Let's type it as:
    # Callable[Callable[TypeVar("T"), Any], bool]
    # Still, this type is wrong, since this will accept all callables not just
    # those that represent a predicate to be applied to an object of type T.
    # But, this is the best we can do with the mypy type system.
    @config(exclude=Exclude.NEVER)
    @dataclass
    class TestExcludeNEVER:
        i: int

    TestExcludeNEVER()

    try:
        TestExcludeNEVER(4)
        assert False, "Expected exception"
    except TypeError:
        pass


# Generated at 2022-06-23 16:38:33.967364
# Unit test for function config
def test_config():
    config(undefined="RAISE")

    config(undefined=Undefined.RAISE)

    try:
        config(undefined="invalid")
        assert False
    except UndefinedParameterError:
        pass

# Generated at 2022-06-23 16:38:36.884332
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config_object = _GlobalConfig()
    assert config_object.encoders == {}
    assert config_object.decoders == {}
    assert config_object.mm_fields == {}


# Generated at 2022-06-23 16:38:42.368707
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    import os
    import sys
    sys.path.append('../')
    from dataclasses_json import dataclass_json
    # Get current working directory
    CWD = os.getcwd()
    # add the folder of your desired module to sys.path
    sys.path.append(CWD)
    # import your desired module
    from lib.models.config import global_config

# Generated at 2022-06-23 16:38:44.105193
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("string") == True


# Generated at 2022-06-23 16:38:45.659197
# Unit test for constructor of class Exclude
def test_Exclude():
    assert hasattr(Exclude, 'ALWAYS')
    assert hasattr(Exclude, 'NEVER')


# Generated at 2022-06-23 16:38:47.229183
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('foo') == False


# Generated at 2022-06-23 16:38:48.413873
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("foo") == True


# Generated at 2022-06-23 16:38:52.900888
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    A = Exclude.ALWAYS
    assert A(1) == True
    assert A(2) == True
    assert A(3) == True
    assert A(4) == True
    assert A(5) == True
    assert A(6) == True
    assert A(7) == True
    assert A(8) == True
    assert A(9) == True
    assert A(10) == True


# Generated at 2022-06-23 16:38:54.346150
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER('')
    assert not Exclude.ALWAYS('')

# Generated at 2022-06-23 16:38:56.056199
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-23 16:38:59.740298
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    @dataclass
    class Test:
        name: str
        value: int

# Generated at 2022-06-23 16:39:01.603903
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-23 16:39:03.332550
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

# Generated at 2022-06-23 16:39:09.525967
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert type(Exclude.NEVER) is type(lambda x:x)
    assert len(inspect.getfullargspec(Exclude.NEVER).args) == 1
    assert Exclude.NEVER("1") == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER("1234") == False
    assert Exclude.NEVER("12345") == False


# Generated at 2022-06-23 16:39:10.715943
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:39:20.931133
# Unit test for function config
def test_config():
    # Test config with no arguments
    assert config() == {'dataclasses_json': {}}

    # Test config with empty arguments
    assert config(encoder=None,
                  decoder=None,
                  mm_field=None,
                  letter_case=None,
                  undefined=None,
                  field_name=None,
                  metadata={}) == {'dataclasses_json': {}}

    # Test config with non-empty arguments with metadata

# Generated at 2022-06-23 16:39:23.007877
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    exclude = Exclude.NEVER

    # Act
    result = exclude('test')

    # Assert
    assert result is False

# Generated at 2022-06-23 16:39:24.889722
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    curr_field = "field"
    assert Exclude.NEVER(curr_field)


# Generated at 2022-06-23 16:39:26.540828
# Unit test for constructor of class Exclude

# Generated at 2022-06-23 16:39:31.355958
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    class Test1:
        x: int
        y: int = config(exclude=Exclude.ALWAYS)

    t1 = Test1(1, 2)
    assert t1.y == 2
    assert dataclasses.asdict(t1) == {'x': 1}

    @dataclasses.dataclass
    class Test2:
        x: int
        y: int = config(exclude=Exclude.NEVER)

    t2 = Test2(1, 2)
    assert t2.y == 2
    assert dataclasses.asdict(t2) == {'x': 1, 'y': 2}

    @dataclasses.dataclass
    class Test3:
        x: int

# Generated at 2022-06-23 16:39:36.195248
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config_test = _GlobalConfig()
    print("encoders: ", global_config_test.encoders)
    print("decoders: ", global_config_test.decoders)
    print("mm_fields: ", global_config_test.mm_fields)


# Generated at 2022-06-23 16:39:38.283080
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:39:40.869631
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER(123) == False


# Generated at 2022-06-23 16:39:45.583077
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(1)
    b = Exclude.NEVER(2)
    assert a == False
    assert b == False

test_Exclude_NEVER()


# Generated at 2022-06-23 16:39:49.904775
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config1 = _GlobalConfig()
    assert global_config1.encoders == {} and global_config1.decoders == {}
    assert global_config1.mm_fields == {}
    # assert global_config1._json_module == json

# Generated at 2022-06-23 16:39:52.915660
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:39:53.766661
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('random_str')

# Generated at 2022-06-23 16:39:58.138927
# Unit test for function config
def test_config():
    dct = config(field_name='a', exclude=Exclude.ALWAYS)
    assert dct['dataclasses_json']['exclude'] is Exclude.ALWAYS

    dct = config(undefined='RAISE')
    assert dct['dataclasses_json']['undefined'] is Undefined.RAISE

# Generated at 2022-06-23 16:40:01.920229
# Unit test for function config
def test_config():
    @dataclass
    @config(
        undefine=Undefined.SKIP,
    )
    class Foo:
        f: int
        f2: str
        f3: bool

    assert Foo._config['undefined'] == Undefined.SKIP

# Generated at 2022-06-23 16:40:12.540581
# Unit test for function config
def test_config():
    import dataclasses
    assert config(exclude=Exclude.ALWAYS) == {'dataclasses_json': {'exclude': Exclude.ALWAYS}}
    assert config(letter_case=str.title) == {'dataclasses_json': {'letter_case': str.title}}
    assert config(undefined=Undefined.EXCLUDE) == {'dataclasses_json': {'undefined': Undefined.EXCLUDE}}
    assert config(undefined=Undefined.EXCLUDE) == {'dataclasses_json': {'undefined': Undefined.EXCLUDE}}
    assert config(undefined='exclude') == {'dataclasses_json': {'undefined': Undefined.EXCLUDE}}

# Generated at 2022-06-23 16:40:20.882077
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from marshmallow import fields
    assert len(global_config.encoders) == 0
    config(encoder = lambda x: x + 1)
    assert len(global_config.encoders) == 1
    config(decoder = lambda x: x - 1)
    assert len(global_config.decoders) == 1
    config(mm_field = fields.Integer)
    assert len(global_config.mm_fields) == 1
    # config(json_module=json)
    # assert hasattr(json, 'dump')



# Generated at 2022-06-23 16:40:27.706298
# Unit test for constructor of class Exclude
def test_Exclude():
    excl = Exclude()
    assert excl.ALWAYS(1)
    assert not excl.NEVER(1)
    excl = Exclude()
    assert excl.ALWAYS(1)
    assert not excl.NEVER(1)


# Generated at 2022-06-23 16:40:35.187916
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses import dataclass

    from .converter import register_converters
    from .encoder import register_encoders
    from .decoder import register_decoders

    @dataclass
    class Foo:
        x: int = 3
        y: int = 4

    @dataclass
    class Bar:
        foo: Foo = config(encoder=lambda foo: foo.x + foo.y,
                          decoder=lambda a: Foo(x=a))

    try:
        config(exclude=Exclude.ALWAYS)
    except TypeError:
        # config called without dataclass
        pass
    else:
        raise AssertionError

    assert Bar.foo.encoder(Bar(Foo())) == 7

    bar = Bar()
    bar

# Generated at 2022-06-23 16:40:45.194508
# Unit test for function config
def test_config():
    from dataclasses import is_dataclass, asdict, fields

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class Test:
        a: int
        b: int

    assert is_dataclass(Test)
    assert asdict(Test(1, 1)) == {}

    assert all(f.metadata.get('dataclasses_json', {}).get('exclude')
               for f in fields(Test))

    Test = config(exclude=Exclude.ALWAYS)(Test)
    assert is_dataclass(Test)
    assert asdict(Test(1, 1)) == {}

    assert all(f.metadata.get('dataclasses_json', {}).get('exclude')
               for f in fields(Test))

# Generated at 2022-06-23 16:40:48.298863
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(object()) is True
    assert Exclude.NEVER(object()) is False

# Generated at 2022-06-23 16:40:50.701562
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-23 16:41:02.464315
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import Schema
    from marshmallow_dataclass import class_schema
    from dataclasses_json import DataClassJsonMixin, config

    class Encoder(data.JSONEncoder):
        pass

    def Decoder(obj):
        return obj

    @class_schema
    class Schema(Schema):
        pass

    @config(encoder=Encoder, mm_field=Schema.as_marshmallow_field)
    @dataclass
    class Config(DataClassJsonMixin):
        pass

    assert Config.json_module.encoder is Encoder
    assert isinstance(Config.schema, Schema)



# Generated at 2022-06-23 16:41:04.941020
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True

# Generated at 2022-06-23 16:41:07.934803
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("2")
    assert Exclude.ALWAYS(True)
    

# Generated at 2022-06-23 16:41:10.752522
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('test')
    assert Exclude.ALWAYS(['test_list'])


# Generated at 2022-06-23 16:41:12.291832
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-23 16:41:17.424839
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config._json_module == json

# Generated at 2022-06-23 16:41:21.025989
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    obj = _GlobalConfig()
    assert obj.encoders == {}
    assert obj.decoders == {}
    assert obj.mm_fields == {}


# Generated at 2022-06-23 16:41:32.456026
# Unit test for function config
def test_config():
    from marshmallow import fields, Schema
    from marshmallow.validate import Range

    import pytest

    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from dataclasses_json.undefined import Undefined

    with pytest.raises(UndefinedParameterError):
        config(undefined="NONEXISTENT")

    @dataclass
    class ConfigTest(DataClassJsonMixin):
        a: int = 1
        b: int = 2

    @dataclass
    class CustomEncoderTest(DataClassJsonMixin):
        a: int = 1

        @classmethod
        def encoder(cls, obj: CustomEncoderTest) -> dict:
            return {'custom_a': obj.a + 1}


# Generated at 2022-06-23 16:41:33.817050
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-23 16:41:35.308639
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.NEVER is not None
    assert Exclude.ALWAYS is not None

# Generated at 2022-06-23 16:41:37.564160
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)



# Generated at 2022-06-23 16:41:39.069639
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("TEST") is False


# Generated at 2022-06-23 16:41:40.974703
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('abc') is True


# Generated at 2022-06-23 16:41:43.697793
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER(True) == False
  assert Exclude.NEVER(False) == False
  assert Exclude.NEVER(None) == False


# Generated at 2022-06-23 16:41:44.871491
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-23 16:41:52.757242
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()

    encoders = {(int,): lambda x: x+1}
    decoders = {(str,): lambda x: str(x)}
    mm_fields = {(str,): str(1)}
    json_module = 'json'
    global_config.encoders = encoders
    global_config.decoders = decoders
    global_config.mm_fields = mm_fields

    assert global_config.encoders == encoders
    assert global_config.decoders == decoders
    assert global_config.mm_fields == mm_fields


# Generated at 2022-06-23 16:41:54.997719
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-23 16:41:56.265508
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("asdf") == True


# Generated at 2022-06-23 16:42:07.488485
# Unit test for function config
def test_config():
    def encoder(obj): return obj
    def decoder(obj): return obj
    def mm_field(obj): return obj
    def letter_case(word): return word.lower()
    def undefined(word): return word
    def exclude(field, cls): return field

    assert config(encoder=encoder, decoder=decoder, mm_field=mm_field,
                  letter_case=letter_case, undefined=undefined,
                  field_name='Positional Only', exclude=exclude) == \
           {'dataclasses_json': {'encoder': encoder, 'decoder': decoder,
                                 'mm_field': mm_field, 'letter_case': letter_case,
                                 'undefined': undefined, 'field_name': 'Positional Only',
                                 'exclude': exclude}}

# Generated at 2022-06-23 16:42:10.915381
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    assert isinstance(global_config, _GlobalConfig)
    assert isinstance(global_config.encoders, dict)
    assert isinstance(global_config.decoders, dict)
    assert isinstance(global_config.mm_fields, dict)


# Generated at 2022-06-23 16:42:17.941313
# Unit test for function config
def test_config():
    from marshmallow import fields as mm_fields

    from dataclasses_json.config import Exclude, config, global_config

    @config()
    @dataclass
    class A:
        a: int

    assert A.__dataclass_json__.default_encoder == global_config.encoders[str]
    assert A.__dataclass_json__.default_decoder == global_config.decoders[str]

    @config(encoder=str, decoder=int, mm_field=mm_fields.Str)
    @dataclass
    class B:
        a: int

    assert B.__dataclass_json__.default_encoder == global_config.encoders[str]
    assert B.__dataclass_json__.default_decoder == global_config.decod

# Generated at 2022-06-23 16:42:20.133724
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('test') is True
    assert Exclude.NEVER('test') is False


# Generated at 2022-06-23 16:42:23.335249
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    global_config = _GlobalConfig()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}
    # assert global_config.json_module == json

# Generated at 2022-06-23 16:42:25.514097
# Unit test for constructor of class Exclude
def test_Exclude():
    assert(Exclude.ALWAYS == functools.partial(lambda x: True, True))
    assert(Exclude.NEVER == functools.partial(lambda x: False, True))

# Generated at 2022-06-23 16:42:31.641039
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert isinstance(config.encoders,dict)
    assert len(config.encoders) == 0
    assert isinstance(config.decoders,dict)
    assert len(config.decoders) == 0
    assert isinstance(config.mm_fields,dict)
    assert len(config.mm_fields) == 0


# Generated at 2022-06-23 16:42:40.199527
# Unit test for function config
def test_config():
    class Foo:
        def __init__(self, attributes: dict):
            self.__dict__.update(attributes)

    @dataclass
    class Bar(object):
        foo: Foo

    b = Bar(Foo({'a': 1}))
    
    # Unit test for function config

# Generated at 2022-06-23 16:42:43.238861
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('somestring')
    assert Exclude.ALWAYS({})


# Generated at 2022-06-23 16:42:44.055607
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-23 16:42:49.432423
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    config = _GlobalConfig()
    assert config.encoders == dict()
    assert config.decoders == dict()
    assert config.mm_fields == dict()


# Generated at 2022-06-23 16:42:51.366967
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS('something') is True
    assert Exclude.NEVER('something') is False

# Generated at 2022-06-23 16:42:56.137989
# Unit test for constructor of class _GlobalConfig
def test__GlobalConfig():
    from dataclasses_json.config import Exclude, _GlobalConfig
    global_config = _GlobalConfig()
    assert(global_config.encoders == {})
    assert(global_config.decoders == {})
    assert(global_config.mm_fields == {})
    # assert(global_config._json_module == json)


# Generated at 2022-06-23 16:42:57.512336
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-23 16:43:06.905593
# Unit test for function config
def test_config():
    # Valid cases
    assert config(undefined='EXCLUDE') == {
        'dataclasses_json': {'undefined': Undefined.EXCLUDE}}

    assert config(undefined=Undefined.EXCLUDE) == {
        'dataclasses_json': {'undefined': Undefined.EXCLUDE}}

    assert config(undefined='FAIL') == {
        'dataclasses_json': {'undefined': Undefined.FAIL}}

    # Invalid case
    try:
        config(undefined='INVALID')
    except UndefinedParameterError:
        return
    assert False

# Generated at 2022-06-23 16:43:08.487094
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  assert Exclude.ALWAYS("") == True


# Generated at 2022-06-23 16:43:10.033073
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test') == True


# Generated at 2022-06-23 16:43:19.273350
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class Example:
        field_1: str
        datetime: str
        field_3: str

    # TODO: some of the tests for this function are in util.py
    assert config(metadata={}) == {'dataclasses_json': {}}
    assert config(dict(dataclasses_json=dict(exclude=lambda _, use_dict: use_dict))) == \
           {'dataclasses_json': {'exclude': lambda _, use_dict: use_dict}}

# Generated at 2022-06-23 16:43:24.866334
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("1")
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER({})
    assert Exclude.NEVER([])
    assert Exclude.NEVER("")
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(1.23)



# Generated at 2022-06-23 16:43:35.506416
# Unit test for function config
def test_config():
    source = {
        'dataclasses_json': {
            'encoder': None,
            'decoder': None,
            'mm_field': None,
            'letter_case': None,
            'undefined': 'ignore',
            'exclude': None,
        }
    }
    assert config(source) == source
    assert config(metadata=source) == source

    with pytest.raises(UndefinedParameterError) as excinfo:
        config(metadata=source, undefined='invalid_action')
    assert excinfo.value.args[0] == \
        "Invalid undefined parameter action, must be one of ['RAISE', 'EXCLUDE', 'INCLUDE', 'IGNORE']"


# Generated at 2022-06-23 16:43:37.351251
# Unit test for constructor of class Exclude
def test_Exclude():
	assert Exclude.ALWAYS(True) == True
	assert Exclude.NEVER(False) == False

# Generated at 2022-06-23 16:43:39.701552
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS("dummy") is True
    assert Exclude.NEVER("dummy") is False


# Unit tests for function config

# Generated at 2022-06-23 16:43:41.211543
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("foo") == False


# Generated at 2022-06-23 16:43:42.743390
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-23 16:43:44.383882
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("testing Exclude.ALWAYS")
    assert Exclude.ALWAYS(12)



# Generated at 2022-06-23 16:43:47.178594
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True


# Generated at 2022-06-23 16:43:48.245552
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER() == False


# Generated at 2022-06-23 16:43:51.277826
# Unit test for constructor of class Exclude
def test_Exclude():
    assert Exclude.ALWAYS(True)
    assert not Exclude.ALWAYS(False)
    assert not Exclude.NEVER(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-23 16:43:53.085949
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-23 16:43:57.328088
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    misc = Exclude()
    if misc.NEVER(1) == True:
        print("test_Exclude_NEVER() successful!\n")
    else:
        print("test_Exclude_NEVER() failed!\n")

#Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-23 16:44:07.523212
# Unit test for function config
def test_config():
    import marshmallow as mm
    from dataclasses import dataclass
    @dataclass
    class Obj:
        foo: str
        bar: str = mm.fields.Str()

    assert config(encoder=str, decoder=str, mm_field=mm.fields.Str()) == {
        'dataclasses_json': {'encoder': str, 'decoder': str,
                             'mm_field': mm.fields.Str()
                             }
    }
    assert config(letter_case=lambda x: x) == {
        'dataclasses_json': {'letter_case': lambda x: x}
    }
    assert config(undefined="RAISE") == {
        'dataclasses_json': {'undefined': Undefined.RAISE}
    }

# Generated at 2022-06-23 16:44:10.008567
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test value")


# Generated at 2022-06-23 16:44:19.873922
# Unit test for function config
def test_config():
    # TODO: define a proper class
    class MockMeta:
        def __init__(self, data):
            self.data = data

    class MockClass:
        def __init__(self, name):
            self.name = name

        def __str__(self):
            return f"{type(self).__name__}{{{self.name}}}"

    class MockField:
        def __init__(self, name):
            self.name = name

    class MockEncoder:
        pass

    class MockDecoder:
        pass

    class MockCamelCase:
        def __init__(self, name):
            self.name = name

        def __call__(self, s: str) -> str:
            return ''.join(x.title() for x in s.split('_'))
