

# Generated at 2022-06-11 20:54:21.211900
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    p = Exclude.ALWAYS
    assert p(True)
    assert p(False)
    # TODO: add more test cases for Exclude.ALWAYS


# Generated at 2022-06-11 20:54:32.761438
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses import dataclass, field
    from dataclasses_json.api import mschema
    import pytest

    @dataclass
    class C:
        a: int = 1
        # exclude b
        b: int = field(metadata=config(exclude=Exclude.ALWAYS))
        c: int = 2

    class MSchema(mschema.Schema):
        class Meta:
            unknown = mschema.EXCLUDE

    schema = MSchema()

    obj = C()

    serialized = schema.dump(obj)
    assert serialized == {"a": 1, "c": 2}

    # Test setting field_name
    @dataclass
    class D:
        a: int = 1

# Generated at 2022-06-11 20:54:34.216603
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_string = "test"
    assert Exclude.NEVER(test_string) == False


# Generated at 2022-06-11 20:54:38.073516
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) and Exclude.ALWAYS(1) and Exclude.ALWAYS(1.1) and Exclude.ALWAYS('') and Exclude.ALWAYS(b'') and Exclude.ALWAYS(()) and Exclude.ALWAYS([])


# Generated at 2022-06-11 20:54:39.172988
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER


# Generated at 2022-06-11 20:54:44.471310
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER('') is False
    assert Exclude.NEVER(0) is False
    assert Exclude.NEVER(-1) is False
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(False) is False
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-11 20:54:45.720037
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
     assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:54:48.120335
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:54:50.291023
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == True


# Generated at 2022-06-11 20:54:54.497635
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    instance = Exclude.ALWAYS
    assert instance(1)
    assert instance(1.5)
    assert instance(True)
    assert instance('string')
    assert instance([1, 2, 3])
    assert instance({'key': 'value'})


# Generated at 2022-06-11 20:54:58.684946
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_Exclude_NEVER.result = Exclude.NEVER('foo')
    return test_Exclude_NEVER.result


# Generated at 2022-06-11 20:54:59.256882
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(object())


# Generated at 2022-06-11 20:55:01.065567
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:55:03.459227
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Given
    test_string = 'ABC'

    # When
    result = Exclude.NEVER(test_string)

    # Then
    assert result == False

# Generated at 2022-06-11 20:55:06.212166
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    func = Exclude.NEVER
    assert func(0) == False
    assert func(1) == False
    assert func(-1) == False
    assert func(2) == False


# Generated at 2022-06-11 20:55:13.548457
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS(set()) == True


# Generated at 2022-06-11 20:55:15.009927
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)

test_Exclude_ALWAYS()


# Generated at 2022-06-11 20:55:19.547467
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(set())
    assert Exclude.ALWAYS(frozenset())


# Generated at 2022-06-11 20:55:21.134843
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 20:55:31.878972
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class MyConfig:
        param1: str = "a"
        param2: str = config(field_name="my_param2")
        param3: str = config(field_name="my_param3", letter_case=None)
        param4: str = config(field_name="my_param4", letter_case="snake")

    class MyCamel:

        @staticmethod
        def to_camel(s):
            return "".join(x.capitalize() or "_" for x in s.split("_"))


# Generated at 2022-06-11 20:55:43.056633
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude()
    x.ALWAYS = lambda x : True
    x.NEVER = lambda x : False
    print("Value =" + str(x.NEVER(False)))
    assert x.NEVER(False) == False

# Generated at 2022-06-11 20:55:44.003973
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)

# Generated at 2022-06-11 20:55:45.205194
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test")

# Generated at 2022-06-11 20:55:47.501206
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) is False and Exclude.NEVER(1) is False

# Generated at 2022-06-11 20:55:48.994558
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():    
    instance = Exclude()
    assert instance.ALWAYS("") == True


# Generated at 2022-06-11 20:55:53.938234
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3.14)
    assert Exclude.ALWAYS("Hello world")
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})


# Generated at 2022-06-11 20:55:55.004987
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER({}) == False


# Generated at 2022-06-11 20:55:56.594217
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('string') == False

# Generated at 2022-06-11 20:56:01.720177
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def f(x):
        assert x == 1
        return False
    def g(x):
        assert x == 2
        return True
    assert Exclude.NEVER(1) == f(1)
    assert Exclude.NEVER(2) == f(2)


# Generated at 2022-06-11 20:56:03.639990
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    f = Exclude.NEVER
    assert f(1) == False
    assert f(0) == False
    assert f(object()) == False


# Generated at 2022-06-11 20:56:12.860274
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc") is False


# Generated at 2022-06-11 20:56:15.634664
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    NEVER = Exclude.NEVER
    assert(Exclude.NEVER(0) == False)
    assert(Exclude.NEVER(1) == False)


# Generated at 2022-06-11 20:56:17.728891
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-11 20:56:20.130156
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER('') == False


# Generated at 2022-06-11 20:56:22.097625
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = int
    type(x).__name__ = "Exclude"
    assert Exclude.NEVER(x)

# Generated at 2022-06-11 20:56:23.356305
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = True
    Exclude.NEVER(x) == False

# Generated at 2022-06-11 20:56:24.730261
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS
    assert result(1) == True


# Generated at 2022-06-11 20:56:26.033963
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False

# Generated at 2022-06-11 20:56:27.544701
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(Exclude.NEVER) == False


# Generated at 2022-06-11 20:56:30.784036
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))
    print(Exclude.NEVER('a'))
    print(Exclude.NEVER(()))

# Generated at 2022-06-11 20:56:48.810946
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER([]) is False


# Generated at 2022-06-11 20:56:53.118035
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(123)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER('')
    assert Exclude.NEVER([])
    assert Exclude.NEVER({})
    assert Exclude.NEVER(0.0)



# Generated at 2022-06-11 20:56:55.078268
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-11 20:56:56.401795
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:56:58.111494
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    EXCLUDE_NEVER = Exclude.NEVER
    assert EXCLUDE_NEVER(None) == False

# Generated at 2022-06-11 20:57:07.597237
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    from typing import List
    from dataclasses_json import config

    @dataclass
    @config(exclude=Exclude.NEVER)
    class Test:
        id: int
        name: str
        description: Optional[str]
        tags: List[str]

    test_instance = Test(1, 'test', 'test description', ['tag1', 'tag2'])
    test_json = '{"id": 1, "name": "test", "description": "test description", "tags": ["tag1", "tag2"]}'
    assert test_instance.to_json() == test_json


# Generated at 2022-06-11 20:57:09.714991
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-11 20:57:10.804717
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-11 20:57:12.610164
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") is False

# Generated at 2022-06-11 20:57:14.611495
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test = Exclude.ALWAYS((1, 2)) == True
    assert test


# Generated at 2022-06-11 20:57:50.245097
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-11 20:57:51.857971
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:57:57.392128
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("1234") == True
    assert Exclude.ALWAYS(1234) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS([1,2,3]) == True
    assert Exclude.ALWAYS({"a":1}) == True

# Generated at 2022-06-11 20:57:58.617492
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:59.793308
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test') == True


# Generated at 2022-06-11 20:58:02.149917
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    data = []
    assert Exclude.ALWAYS(data)
    data = [1, 2, 3]
    assert Exclude.ALWAYS(data)


# Generated at 2022-06-11 20:58:12.157955
# Unit test for function config
def test_config():
    metadata = config(field_name='foo', letter_case=str.lower)
    assert metadata['dataclasses_json']['letter_case']('foo') == 'foo'
    metadata = config(field_name='foo', letter_case=str.upper)
    assert metadata['dataclasses_json']['letter_case']('foo') == 'FOO'
    config(undefined=Undefined.RAISE)
    config(undefined=Undefined.NULL)
    config(undefined=Undefined.EXCLUDE)
    config(undefined=Undefined.RAISE.name)
    config(undefined=Undefined.NULL.name)
    config(undefined=Undefined.EXCLUDE.name)
    with pytest.raises(UndefinedParameterError):
        config(undefined='foo')
   

# Generated at 2022-06-11 20:58:13.325028
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("foo") is True


# Generated at 2022-06-11 20:58:15.244422
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:58:17.525735
# Unit test for method NEVER of class Exclude

# Generated at 2022-06-11 20:59:36.899247
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("hello world") == False
    assert Exclude.NEVER("goodbye world") == False
    assert Exclude.NEVER("0") == False
    assert Exclude.NEVER("1") == False
    assert Exclude.NEVER("42") == False
    assert Exclude.NEVER("431213") == False
    assert Exclude.NEVER("-1") == False
    assert Exclude.NEVER("-2") == False
    assert Exclude.NEVER("-1000") == False
    assert Exclude.NEVER("-3232") == False
    assert Exclude.NEVER("0.0001") == False
    assert Exclude.NEVER("0.01") == False
    assert Exclude

# Generated at 2022-06-11 20:59:41.256055
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # First test that Exclude.ALWAYS is true for any parameter
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(-1) == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 20:59:43.640211
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    _ = 'test_for_Exclude_ALWAYS'
    assert Exclude.ALWAYS(_) == True


# Generated at 2022-06-11 20:59:44.812528
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 20:59:46.800403
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-11 20:59:49.010852
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(True)
	assert Exclude.ALWAYS(False)


# Generated at 2022-06-11 20:59:50.639041
# Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-11 20:59:52.822104
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(1234) == False



# Generated at 2022-06-11 20:59:53.973006
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("TEST")


# Generated at 2022-06-11 21:00:00.869938
# Unit test for function config
def test_config():
    # Testing the `valid_actions` message
    try:
        config(undefined='not_exists')
    except UndefinedParameterError as e:
        assert e.message == 'Invalid undefined parameter action, ' \
                            'must be one of ' \
                            '[\'EXCLUDE\', \'INCLUDE\', \'RAISE\', \'STRICT\']'
    else:
        assert False, 'Should raise exception'


test_config()

# Generated at 2022-06-11 21:02:54.145690
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({}) == True


# Generated at 2022-06-11 21:03:00.465915
# Unit test for function config
def test_config():
    import dataclasses
    
    class A:
        __annotations__ = {'x': int}

        def __init__(self, x: int):
            self.x = x

    @dataclasses.dataclass
    class B:
        x: int = 0
        y: str = "y"


# Generated at 2022-06-11 21:03:02.134793
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  instance = Exclude()

# Generated at 2022-06-11 21:03:05.030385
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("str")


# Generated at 2022-06-11 21:03:09.034406
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS(1.2)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS("123")


# Generated at 2022-06-11 21:03:18.619563
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.letter_case import LetterCase
    from marshmallow import fields

    @dataclass
    class A:
        @classmethod
        def metaclass_config(mcs, metadata):
            return config(metadata)

    assert A.metaclass_config({}) == {'dataclasses_json': {}}

    @dataclass
    class B:
        @classmethod
        def metaclass_config(mcs, metadata):
            return config(metadata, encoder=float)

    assert B.metaclass_config({}) == {'dataclasses_json': {
        'encoder': float}}


# Generated at 2022-06-11 21:03:26.883509
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(True))
    print(Exclude.NEVER(False))
    print(Exclude.NEVER(None))
    Exclude.NEVER(1)
    print(Exclude.NEVER(0))
    print(Exclude.NEVER(0.0))
    print(Exclude.NEVER(0.00))
    print(Exclude.NEVER(0.0000))
    print(Exclude.NEVER(0.00000))
    print(Exclude.NEVER(0.000000))
    print(Exclude.NEVER(0.0000000))
    print(Exclude.NEVER(0.00000000))
    print(Exclude.NEVER(0.000000000))
    print(Exclude.NEVER(0.0000000000))

# Generated at 2022-06-11 21:03:28.950964
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")


# Generated at 2022-06-11 21:03:30.083534
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-11 21:03:31.580407
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(' ') == False
