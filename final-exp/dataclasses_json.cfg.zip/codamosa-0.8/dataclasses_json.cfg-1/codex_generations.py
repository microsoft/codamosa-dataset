

# Generated at 2022-06-11 20:54:20.259424
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-11 20:54:24.328192
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert (Exclude.NEVER(1) == Exclude.NEVER(2))
    assert (Exclude.NEVER(1) == True)
    assert (Exclude.NEVER('1') == True)


# Generated at 2022-06-11 20:54:26.389380
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:54:27.666394
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER('adb')


# Generated at 2022-06-11 20:54:30.892535
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result_true=Exclude.NEVER(1)
    result_false=Exclude.NEVER(0)
    assert result_true==False
    assert result_false==False


# Generated at 2022-06-11 20:54:39.685571
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    import numpy as np
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.config import config
    from dataclasses_json.undefined import Undefined

    @dataclass()
    class RectangleInfo(DataClassJsonMixin):
        width: float = field(
            default=Undefined.RAISE, metadata=config(undefined=Undefined.RAISE)
        )
        height: float = field(
            default=Undefined.RAISE, metadata=config(undefined=Undefined.RAISE)
        )
        depth: float = field(
            default=Undefined.RAISE, metadata=config(undefined=Undefined.RAISE)
        )


# Generated at 2022-06-11 20:54:49.704351
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(1.0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('1') == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS([1,2,3]) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS({'a':'a'}) == True
    assert Exclude.ALWAYS({'a':1}) == True
    assert Exclude.ALWAYS({'a':1,'b':True}) == True
    assert Exclude.ALWAYS({'a':1,'b':False}) == True
    assert Ex

# Generated at 2022-06-11 20:54:51.097228
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('123') == False


# Generated at 2022-06-11 20:54:52.591984
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER("ok")
    assert x == False

# Generated at 2022-06-11 20:54:54.381592
# Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-11 20:54:56.318099
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    pass

# Generated at 2022-06-11 20:54:59.670687
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:55:01.278720
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    my_class = Exclude()
    assert my_class.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:02.686359
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:55:03.538453
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-11 20:55:08.810743
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('') == False


# Generated at 2022-06-11 20:55:16.863730
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class C1:
        def __init__(self, x: int):
            self.x = x
    class C2:
        def __init__(self, x: int, y: int):
            self.x = x
            self.y = y
    c1 = C1(1)
    c2 = C2(1,2)
    configs = [Exclude.ALWAYS, Exclude.ALWAYS, Exclude.ALWAYS]
    assert configs[0](c1)
    assert configs[1](c2)
    assert configs[2](c1) and configs[2](c2)



# Generated at 2022-06-11 20:55:27.406122
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from marshmallow.fields import Field
    from dataclasses_json.api import Config

    assert Config().encoder() is None
    assert Config().decoder() is None
    assert Config().mm_field() is None
    assert Config().letter_case() is None
    assert Config().undefined() is Undefined.EXCLUDE
    assert Config().exclude() is None

    @dataclass
    class TestClass:
        class_attr: str = field(metadata=config(letter_case=str.upper))
        value: int = field(metadata=config(exclude=Exclude.ALWAYS))
        field_name: str = field(metadata=config(field_name='fieldName'))

# Generated at 2022-06-11 20:55:34.038122
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0.0) == True
    assert Exclude.ALWAYS(1.0) == True
    assert Exclude.ALWAYS(1e-06) == True


# Generated at 2022-06-11 20:55:41.362365
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("1")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([0])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({"a": 123})
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:55:48.163165
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0.98) == True
    assert Exclude.ALWAYS('gustavo') == True
    assert Exclude.ALWAYS(Exclude) == True


# Generated at 2022-06-11 20:55:52.545659
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS([1,2,3])
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-11 20:56:02.527173
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER('A') == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(1.0) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([0]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({0:0}) == False
    assert Exclude.NEVER((0,0)) == False

# Generated at 2022-06-11 20:56:06.300077
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS({}) == True


# Generated at 2022-06-11 20:56:08.647737
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    test = Exclude.NEVER('test')
    # Act
    a = test
    # Assert
    assert a == False


# Generated at 2022-06-11 20:56:09.922948
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER()
    assert x == False


# Generated at 2022-06-11 20:56:11.077882
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    value = 1234
    assert Exclude.ALWAYS(value)


# Generated at 2022-06-11 20:56:15.097543
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert callable(Exclude.ALWAYS)
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(Exclude.ALWAYS) == True
    assert Exclude.ALWAYS(False) == True



# Generated at 2022-06-11 20:56:20.084691
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    exclude = Exclude.ALWAYS
    assert exclude('1') is True
    assert exclude(1) is True
    assert exclude(True) is True
    assert exclude(None) is True
    assert exclude([1, 2, 3]) is True
    assert exclude({1, 2, 3}) is True
    assert exclude({'a': 1, 'b': 2}) is True

# Generated at 2022-06-11 20:56:26.170220
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False


# Generated at 2022-06-11 20:56:32.790745
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) is True


# Generated at 2022-06-11 20:56:34.505879
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False



# Generated at 2022-06-11 20:56:35.484234
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")


# Generated at 2022-06-11 20:56:36.516831
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") is True


# Generated at 2022-06-11 20:56:38.035330
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) is False

# Generated at 2022-06-11 20:56:39.319376
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('ABC') is False


# Generated at 2022-06-11 20:56:43.408905
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_data = dict()
    test_data["test0"] = {"param": "test0"}
    test_data["test1"] = {"param": "test1"}
    test_data["test2"] = {"param": "test2"}
    test_data["test3"] = {"param": "test3"}

    assert len(test_data) == 4
    assert Exclude.ALWAYS(test_data) == True


# Generated at 2022-06-11 20:56:45.274762
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("Random string") is False


# Generated at 2022-06-11 20:56:52.040317
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    input = {
        'name': 'Jo',
        'age': 28,
        'gender': 'male',
        'address': 'NY, USA'
    }
    expected_output = {}
    output = {}

    for key, value in input.items():
        if Exclude.NEVER(key):
            output[key] = value

    assert Exclude.NEVER(key) == True
    assert expected_output == output



# Generated at 2022-06-11 20:57:00.344966
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass
    class Example:
        value1: str = field(metadata = config(exclude=Exclude.ALWAYS))
        value2: str = field(metadata = config(exclude=Exclude.ALWAYS))

    example = Example("test1", "test2")

    assert {"value1": "test1", "value2": "test2"} == example.to_dict()
    assert dict() == example.to_dict(exclude_none=True)
    assert dict() == example.to_json(exclude_none=True)


# Generated at 2022-06-11 20:57:15.068471
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # ALWAYS check true
    assert Exclude.ALWAYS(3) == True, "Test Exclude ALWAYS false"
    # ALWAYS check false
    assert Exclude.ALWAYS(4) == True, "Test Exclude ALWAYS true"


# Generated at 2022-06-11 20:57:16.233187
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('exclude')


# Generated at 2022-06-11 20:57:18.795109
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hello") == True


# Generated at 2022-06-11 20:57:20.297366
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:57:22.175683
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2)


# Generated at 2022-06-11 20:57:26.784713
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Let's assume we have a field 'name'
    exclude_result = Exclude.NEVER("name")
    # If we do not want to include the field 'name',
    # we should get the output of function NEVER as True
    assert_equal(exclude_result, True)


# Generated at 2022-06-11 20:57:29.833505
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @config(exclude=Exclude.ALWAYS)
    @dataclass()
    class A:
        field: int

    serialized = A(5)

    assert serialized.serialize() == {}



# Generated at 2022-06-11 20:57:31.701396
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 20:57:33.028082
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(''))


# Generated at 2022-06-11 20:57:35.390021
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a: int = 1
    b: int = 2
    assert Exclude.NEVER(a) == False
    assert Exclude.NEVER(b) == False

# Generated at 2022-06-11 20:58:01.090003
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:58:02.184467
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("foo") == True


# Generated at 2022-06-11 20:58:08.535142
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(99) == False
    assert Exclude.NEVER("test") == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:58:09.357029
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-11 20:58:11.744674
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    exclude = Exclude.ALWAYS
    assert exclude(7)
    assert exclude(None)
    assert exclude("some string")
    assert exclude([])
    assert exclude({})


# Generated at 2022-06-11 20:58:14.633769
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER(3)
    if not x:
        print("test_Exclude_NEVER: test is Passed")
    else:
        print("test_Exclude_NEVER: test is Failed")

# Generated at 2022-06-11 20:58:17.483415
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) is True
    assert Exclude.NEVER("hello") is True
    assert Exclude.NEVER(None) is True
    assert Exclude.NEVER(lambda x: 2) is True

# Generated at 2022-06-11 20:58:19.417161
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def method(x,y):
        return False
    a = Exclude.NEVER(method)
    assert a == False

# Generated at 2022-06-11 20:58:21.949854
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field_name = "field_name"
    x = Exclude.NEVER(field_name)
    y = None
    assert x == y


# Generated at 2022-06-11 20:58:30.871899
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    f1 = Exclude.NEVER
    assert f1(True) == False
    assert f1(False) == False
    assert f1('') == False
    assert f1('None') == False
    assert f1(None) == False
    assert f1(0) == False
    assert f1(1) == False
    assert f1(12.0) == False
    assert f1([1, 2, 3]) == False
    assert f1({'x': 1, 'y': 2}) == False
    assert f1(Undefined) == False
    assert f1(Exception) == False


# Generated at 2022-06-11 20:59:21.455563
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("A")
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:59:28.398395
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)==False
    assert Exclude.NEVER('a')==False
    assert Exclude.NEVER('100')==False
    assert Exclude.NEVER(1.01)==False
    assert Exclude.NEVER([1,2,3])==False
    assert Exclude.NEVER((1,2,3))==False
    assert Exclude.NEVER({1:'a',2:'b',3:'c'})==False
    assert Exclude.NEVER({'a':1,'b':2,'c':3})==False


# Generated at 2022-06-11 20:59:29.878094
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:59:33.945792
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("qwert") == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("12345") == False
    assert Exclude.NEVER(" ") == False
    assert Exclude.NEVER("123a") == False
    assert Exclude.NEVER("123A") == False


# Generated at 2022-06-11 20:59:35.513569
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(Undefined) == True

# Generated at 2022-06-11 20:59:38.583318
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_val = "NEVER"
    # ALWAYS returns true, so the value will be excluded from json
    test = Exclude.NEVER(test_val)
    assert test == True


# Generated at 2022-06-11 20:59:42.040993
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test:
        foo: int = config()

    assert Test._json_metadata["dataclasses_json"] == {}



# Generated at 2022-06-11 20:59:43.581214
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('A string that could be anything')

# Generated at 2022-06-11 20:59:45.048456
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    excluded = Exclude.NEVER("test_field")
    assert excluded is True
    

# Generated at 2022-06-11 20:59:48.919634
# Unit test for function config
def test_config():
    config(metadata={}, encoder=str)


# TODO: #180
# def set_json(module):
#     global_config.json_module = module
#     return module



# Generated at 2022-06-11 21:01:40.332430
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER("12") == False


# Generated at 2022-06-11 21:01:41.917422
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(None)
    assert result == True
    print('test_Exclude_ALWAYS passed')


# Generated at 2022-06-11 21:01:47.234391
# Unit test for function config
def test_config():
    import dataclasses

    @dataclasses.dataclass
    @config(letter_case=lambda s: s.upper(), undefined='EXCLUDE')
    class MyClass:
        my_param: int

    assert MyClass.letter_case('not_used') == 'MY_PARAM'
    assert MyClass.undefined == Undefined.EXCLUDE

# Generated at 2022-06-11 21:01:48.680294
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("1")
    assert Exclude.NEVER("123")



# Generated at 2022-06-11 21:01:50.941836
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('abcd') == False

# Generated at 2022-06-11 21:01:52.273208
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(123) is False


# Generated at 2022-06-11 21:01:53.425953
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") is True


# Generated at 2022-06-11 21:01:55.858390
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-11 21:01:57.373300
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER("")
    expected = False
    assert result == expected


# Generated at 2022-06-11 21:01:58.210120
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
