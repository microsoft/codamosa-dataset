

# Generated at 2022-06-11 20:54:28.296050
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS({'True': True})
    assert Exclude.ALWAYS(('x', 'y', 'z'))


# Generated at 2022-06-11 20:54:31.220680
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-11 20:54:32.439684
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  assert Exclude.ALWAYS(1)



# Generated at 2022-06-11 20:54:33.586915
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") is False


# Generated at 2022-06-11 20:54:34.874799
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('x')


# Generated at 2022-06-11 20:54:38.260218
# Unit test for function config
def test_config():
    class A:
        pass

    @config(encoder=A)
    class C:
        pass

    assert C.__dict__['__dataclass_metadata__']['dataclasses_json']['encoder'] == A


# Generated at 2022-06-11 20:54:39.564549
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:54:42.058827
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None) == True)
    assert(Exclude.ALWAYS(False) == True)
    assert(Exclude.ALWAYS(True) == True)


# Generated at 2022-06-11 20:54:44.045656
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:54:45.642062
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    temp = Exclude()
    assert temp.NEVER('Hello World') == False


# Generated at 2022-06-11 20:54:49.892210
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("ok") == True

# Generated at 2022-06-11 20:54:52.122461
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    model = 'model'

    # Act
    result = Exclude.NEVER(model)

    # Assert
    assert result == False

# Generated at 2022-06-11 20:54:53.904065
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:54:58.217856
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("Testing method ALWAYS of class Exclude")
    if not Exclude.ALWAYS("anything"):
        print("FAILED : Unexpected False returned by Exclude.ALWAYS")
    else:
        print("PASSED : Expected True returned by Exclude.ALWAYS")


# Generated at 2022-06-11 20:55:04.225742
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Foo(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    f = Foo(1, 2, 3)
    if Exclude.NEVER(f.a) and Exclude.NEVER(f.b) and Exclude.NEVER(f.c):
        print("The functions NEVER is correct")
    else:
        print("The function NEVER is not correct")


# Generated at 2022-06-11 20:55:09.380790
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS('String') == True


# Generated at 2022-06-11 20:55:10.464788
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(T) == False


# Generated at 2022-06-11 20:55:14.407127
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    exclude = Exclude.ALWAYS
    assert exclude(None)
    assert exclude(1)
    assert exclude(1.1)
    assert exclude(False)
    assert exclude(True)
    assert exclude(["a", "b" ,"c"])
    assert exclude({"a": 1, "b":2, "c": 3})
    assert exclude({"c": [1, 2, 3], "a": False, "b" :True})
    
    

# Generated at 2022-06-11 20:55:15.691677
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:55:26.753099
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        field: str

    dct = TestClass(field='test')

    # Test for encoder
    # Test for decoder
    # Test for mm_field

    # Test for letter_case
    @functools.wraps(lambda x: x, assigned=[])
    def letter_case(x):
        return x.upper()

    @dataclass
    class TestClass1:
        field: str

        class Config:
            dataclasses_json = {
                'letter_case': letter_case,
            }

    # Test for field_name
    @dataclass
    class TestClass2:
        field: str


# Generated at 2022-06-11 20:55:31.948131
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS('') is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True


# Generated at 2022-06-11 20:55:37.670552
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(0.1) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('aaa') == False
    assert Exclude.NEVER('bbb') == False
    assert Exclude.NEVER('a0') == False
    assert Exclude.NEVER('0.0') == False
    assert Exclude.NEVER('0.1') == False


# Generated at 2022-06-11 20:55:41.805241
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('')== True
    assert Exclude.ALWAYS([])== True
    assert Exclude.ALWAYS(())== True
    assert Exclude.ALWAYS(Undefined)== True


# Generated at 2022-06-11 20:55:45.166218
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("abc") == True


# Generated at 2022-06-11 20:55:47.512071
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert True == Exclude.NEVER(1)
    assert False == Exclude.NEVER(0)


# Generated at 2022-06-11 20:55:48.437608
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:55:49.700561
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    exclude = Exclude.NEVER
    assert exclude('test') is False

# Generated at 2022-06-11 20:55:51.597841
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    f = Exclude.NEVER([])
    assert f == False


# Generated at 2022-06-11 20:55:53.218079
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def func(x: int) -> bool:
        return False
    assert(Exclude.NEVER(1) == func(1))



# Generated at 2022-06-11 20:55:54.462684
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('value') == False


# Generated at 2022-06-11 20:56:03.595435
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from typing import Any
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("1") == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 20:56:06.029172
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    object = object()
    assert Exclude.ALWAYS(object) == True

test_Exclude_ALWAYS()


# Generated at 2022-06-11 20:56:08.300688
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # When calling Exclude.NEVER()
    # Then the result should be False
    assert Exclude.NEVER() == False


# Generated at 2022-06-11 20:56:09.581061
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS('')
    assert result == True


# Generated at 2022-06-11 20:56:10.760595
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(2)
    assert a == False

# Generated at 2022-06-11 20:56:12.860287
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('Hello World') == True


# Generated at 2022-06-11 20:56:17.394140
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    # We can also directly use config without the decorator
    mmf = config(A, mm_field=A.a)
    assert mmf['dataclasses_json']['mm_field'] == A.a

# Generated at 2022-06-11 20:56:18.778885
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:20.083985
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False


# Generated at 2022-06-11 20:56:21.064367
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:56:34.236962
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert NEVER(3) is False

# Generated at 2022-06-11 20:56:35.631543
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS('dummy') == True)


# Generated at 2022-06-11 20:56:36.720090
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:39.958279
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:56:41.349986
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-11 20:56:46.999008
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    EXAMPLE_NEVER_TRUE = Exclude.NEVER({})
    EXAMPLE_NEVER_FALSE = Exclude.NEVER(None)

    if EXAMPLE_NEVER_TRUE or EXAMPLE_NEVER_FALSE:
        assert False
    else:
        assert True


# Generated at 2022-06-11 20:56:55.235240
# Unit test for function config
def test_config():
    assert 'dataclasses_json' in config(field_name="foo")
    assert config(field_name="foo")['dataclasses_json']['letter_case']("abc") == "foo"

    assert 'dataclasses_json' in config(field_name="foo", letter_case=str.upper)
    assert config(field_name="foo", letter_case=str.upper)['dataclasses_json']['letter_case']("abc") == "FOO"

    assert 'dataclasses_json' in config(letter_case=lambda s: s[::-1])
    assert config(letter_case=lambda s: s[::-1])['dataclasses_json']['letter_case']("abc") == "cba"



# Generated at 2022-06-11 20:56:59.909446
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER({})
    assert Exclude.NEVER([])
    assert Exclude.NEVER(())
    assert Exclude.NEVER(object)


# Generated at 2022-06-11 20:57:01.351244
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    res = Exclude.ALWAYS(1)
    assert res == True


# Generated at 2022-06-11 20:57:02.927664
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:57:29.337030
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:57:31.557725
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("DMITRIIIIIIIIIIIIIIII")


# Generated at 2022-06-11 20:57:32.621544
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER() == False

# Generated at 2022-06-11 20:57:33.891248
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS('something') is True)


# Generated at 2022-06-11 20:57:38.364626
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('s')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(Exclude.ALWAYS)


# Generated at 2022-06-11 20:57:40.003440
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:57:41.877496
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("Some text") == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:57:43.864536
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:57:45.411058
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True


# Generated at 2022-06-11 20:57:48.895155
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(9) == False


# Generated at 2022-06-11 20:58:40.678866
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-11 20:58:43.427541
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('python') == True
    assert Exclude.ALWAYS('js') == True


# Generated at 2022-06-11 20:58:45.315808
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dummy_object = None
    assert Exclude.ALWAYS(dummy_object)


# Generated at 2022-06-11 20:58:47.386348
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('s') == False


# Generated at 2022-06-11 20:58:49.606859
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("hello") == False
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-11 20:58:52.013617
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # No arguments passed
    condition = Exclude.ALWAYS(None)
    if condition:
        print("ALWAYS test completed")
    elif not condition:
        raise Exception("ALWAYS test failed")


# Generated at 2022-06-11 20:58:58.515453
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(Undefined) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(0.0) == True
    assert Exclude.ALWAYS(0.0+0.0j) == True


# Generated at 2022-06-11 20:59:08.424602
# Unit test for function config
def test_config():

    # Check the @config decorator
    from datetime import datetime, timezone
    from dataclasses import dataclass

    @dataclass
    class User:
        id: int
        name: str
        created_at: datetime = None

    def my_encoder(o):
        if isinstance(o, datetime):
            return o.replace(tzinfo=timezone.utc).isoformat()

    def my_decoder(o):
        if isinstance(o, str):
            return datetime.strptime(o, "%Y-%m-%dT%H:%M:%S.%f%z")


# Generated at 2022-06-11 20:59:10.047411
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("toto") == True



# Generated at 2022-06-11 20:59:11.397299
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude_NEVER = Exclude.NEVER
    assert Exclude_NEVER('abc') == False


# Generated at 2022-06-11 21:01:13.899131
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2)
    assert not Exclude.NEVER(0)


# Generated at 2022-06-11 21:01:15.304684
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Test the condition where the field is set to NEVER
    assert Exclude.NEVER is True


# Generated at 2022-06-11 21:01:16.753589
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 21:01:23.963082
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER('test') == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER(lambda x: x == 0) == False



# Generated at 2022-06-11 21:01:25.838137
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER('dog') == False


# Generated at 2022-06-11 21:01:29.513631
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER('')
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(())
    assert Exclude.NEVER({})


# Generated at 2022-06-11 21:01:31.096502
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 21:01:33.098420
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER("") is False)
    assert(Exclude.NEVER(None) is False)

# Unit tests for method ALWAYS of class Exclude

# Generated at 2022-06-11 21:01:34.360095
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True



# Generated at 2022-06-11 21:01:42.217760
# Unit test for function config
def test_config():
    # Directs the function config to generate metadata with the appropriate
    # parameters and check if they match the arguments passed
    # pylint: disable=unused-variable
    @config(metadata={}, letter_case='invalid', decoder=lambda x: x + 1,
            mm_field=None)
    class TestClass:
        pass

    assert TestClass.__dataclass_metadata__['dataclasses_json']['letter_case']() == 'testclass'
    assert TestClass.__dataclass_metadata__['dataclasses_json']['decoder'](1) == 2
    assert TestClass.__dataclass_metadata__['dataclasses_json']['mm_field'] is None
    # pylint: enable=unused-variable

