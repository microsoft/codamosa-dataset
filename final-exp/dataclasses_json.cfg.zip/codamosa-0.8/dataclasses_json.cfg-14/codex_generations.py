

# Generated at 2022-06-11 20:54:33.195057
# Unit test for function config
def test_config():
    from marshmallow import fields
    from marshmallow_oneofschema import OneOfSchema
    from dataclasses import dataclass, fields as dataclasses_fields
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class Foo(DataClassJsonMixin, letter_case='camel'):
        id: int = config(field_name='_id')

    @dataclass
    class Bar(Foo):
        pass

    @dataclass
    class Baz(Foo):
        pass

    @dataclass
    class Qux(DataClassJsonMixin):
        foo: Foo
        bar: Bar

    @dataclass
    class Norf(DataClassJsonMixin):
        bar: Bar = Bar(id=42)


# Generated at 2022-06-11 20:54:39.683829
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Checks that the method ALWAYS of class Exclude return True
    assert Exclude.ALWAYS(1) == True

    # Checks that the method ALWAYS of class Exclude return True
    assert Exclude.ALWAYS(0) == True

    # Checks that the method ALWAYS of class Exclude return True
    assert Exclude.ALWAYS(2) == True

    # Checks that the method ALWAYS of class Exclude return True
    assert Exclude.ALWAYS(10) == True

    # Checks that the method ALWAYS of class Exclude return True
    assert Exclude.ALWAYS(-1) == True


# Generated at 2022-06-11 20:54:49.703742
# Unit test for function config
def test_config():
    import pytest
    from dataclasses import dataclass
    from dataclasses_json import config

    @config(decoder=int,
            letter_case='underscore',
            undefined='ignore',
            exclude=Exclude.ALWAYS)
    @dataclass
    class Foo:
        foo: str
        bar: int

    assert Foo.__dataclass_json__.decoder == int
    assert Foo.__dataclass_json__.letter_case('') == '_'
    assert Foo.__dataclass_json__.undefined == Undefined.IGNORE
    assert Foo.__dataclass_json__.exclude(None, None)


# Generated at 2022-06-11 20:54:51.093608
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('aa')


# Generated at 2022-06-11 20:54:54.196697
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    obj = Exclude.NEVER
    # Act
    result = obj(None)
    # Assert
    assert result == False


# Generated at 2022-06-11 20:55:00.205339
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Test: test_Exclude_NEVER")
    a = Exclude.NEVER
    print(type(a))
    print(a(True))
    print(a(1))
    print(a(1.0))
    print(a(Exclude))
    print(a(Exclude.NEVER))
    print(a(Exclude.ALWAYS))


test_Exclude_NEVER()

# Generated at 2022-06-11 20:55:01.874471
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    e = Exclude()
    assert e.NEVER(1) == False


# Generated at 2022-06-11 20:55:04.525728
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Test NEVER on three not None value
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER('true') is False


# Generated at 2022-06-11 20:55:05.796419
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Testing class Exclude method NEVER")


# Generated at 2022-06-11 20:55:10.198625
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	l = [1,2,3]
	for x in l:
		try:
			assert(Exclude.ALWAYS(x))
		except:
			raise Exception("Exclude.ALWAYS test failed!")
	

# Generated at 2022-06-11 20:55:13.871386
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:55:15.027890
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test_field') == False


# Generated at 2022-06-11 20:55:17.456841
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER("adsf") == False
    return True
    

# Generated at 2022-06-11 20:55:19.022310
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude()

    assert True is obj.NEVER(False)



# Generated at 2022-06-11 20:55:22.012206
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("string") == False
    assert Exclude.NEVER({"key": "value"}) == False

# Generated at 2022-06-11 20:55:24.355390
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    e = Exclude()
    for i in range(1, 100):
        assert e.NEVER(i)


# Generated at 2022-06-11 20:55:27.130417
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_func = Exclude.ALWAYS
    input_value = [0, 1, 2]
    assert(test_func(input_value))


# Generated at 2022-06-11 20:55:28.085197
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:55:30.927911
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    dec = Decimal("3.4")
    assert Exclude.NEVER(dec) == False
    assert type(Exclude.NEVER(dec)) == bool


# Generated at 2022-06-11 20:55:32.205600
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False
    

# Generated at 2022-06-11 20:55:44.867658
# Unit test for function config
def test_config():
    class A:
        pass

    class B:
        pass

    @config(encoder=A, decoder=B, letter_case=lambda _: _)
    @dataclasses.dataclass
    class C:
        class Meta:
            unknown = 'raise'

    assert C.Meta.json_module == dataclasses_json.config.json

    encoder = C.Meta.encoders[C]
    assert isinstance(encoder, A)

    decoder = C.Meta.decoders[C]
    assert isinstance(decoder, B)

    assert C.Meta.letter_case(None) == None

    with pytest.raises(UndefinedParameterError):
        @config(undefined='unacceptable')
        @dataclasses.dataclass
        class D:
            pass


# Generated at 2022-06-11 20:55:47.239074
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a')


# Generated at 2022-06-11 20:55:48.626531
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False


# Generated at 2022-06-11 20:55:49.515158
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER(1)

# Generated at 2022-06-11 20:55:51.422117
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    exclude = Exclude.NEVER(True)
    assert exclude is True

# Generated at 2022-06-11 20:55:52.600000
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2)


# Generated at 2022-06-11 20:55:53.588898
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:55:55.101166
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True

test_Exclude_ALWAYS()


# Generated at 2022-06-11 20:55:58.710210
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.ALWAYS("lion") == True)
    assert(Exclude.ALWAYS(True) == True)
    assert(Exclude.ALWAYS(False) == True)
    assert(Exclude.ALWAYS(None) == True)


# Generated at 2022-06-11 20:56:02.594208
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(42)
    assert not Exclude.NEVER(None)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)


# Generated at 2022-06-11 20:56:13.667121
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    c=Exclude.NEVER
    assert(c(True)==False)
    assert(c(False)==False)
    assert(c('')==False)
    assert(c('x')==False)
    assert(c(0)==False)
    assert(c(1)==False)
    assert(c(None)==False)
    assert(c('twenty')==False)
    assert(c('seventeen')==False)

# Generated at 2022-06-11 20:56:17.817213
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    if Exclude.NEVER(1) == True:
        return 'Exclude.NEVER(<parameter>) returns True, it should return False'
    else:
        return 'Exclude.NEVER(<parameter>) returns False, it works fine'


# Generated at 2022-06-11 20:56:19.089160
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS('hello') == True


# Generated at 2022-06-11 20:56:21.486579
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # arrange
    test_data = 'test_data'
    # act
    result = Exclude.NEVER(test_data)
    # assert
    assert result == False

# Generated at 2022-06-11 20:56:22.871825
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-11 20:56:24.351754
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:56:26.395121
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('something')


# Generated at 2022-06-11 20:56:27.806850
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-11 20:56:30.022171
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True)==False


# Generated at 2022-06-11 20:56:31.275490
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS([1,2,3]) == True


# Generated at 2022-06-11 20:56:53.154542
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:59.453890
# Unit test for function config

# Generated at 2022-06-11 20:57:03.752232
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS('str') is True
    assert Exclude.ALWAYS((1, 2)) is True
    assert Exclude.ALWAYS([1, 2]) is True
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-11 20:57:05.975864
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:57:08.477196
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False

# Generated at 2022-06-11 20:57:09.945025
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('some_value')
    assert Exclude.ALWAYS(10)


# Generated at 2022-06-11 20:57:11.518362
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Execute statement under test
    res = Exclude.NEVER("")
    #  Verify result
    assert res == False


# Generated at 2022-06-11 20:57:14.354531
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # arrange
    sut = Exclude.ALWAYS

    # act
    actual = sut(1)

    # assert
    assert actual

# Generated at 2022-06-11 20:57:17.238895
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('a')


# Generated at 2022-06-11 20:57:20.343432
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = Exclude.ALWAYS(4)
    # x should be the same as the actual value
    assert x == True


# Generated at 2022-06-11 20:58:01.008834
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test = Exclude.ALWAYS
    assert test('a'), "test_Exclude_ALWAYS"


# Generated at 2022-06-11 20:58:03.161134
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER
    assert a(2) == False
    assert a("hello") == False
    assert a(Exclude()) == False
    assert a(Undefined) == False


# Generated at 2022-06-11 20:58:07.153406
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("string")
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-11 20:58:08.569556
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:58:09.381289
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("A") is True


# Generated at 2022-06-11 20:58:12.344467
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER('') == False


# Generated at 2022-06-11 20:58:15.205037
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert Exclude.ALWAYS(1) == True
   assert Exclude.ALWAYS(0) == True
   assert Exclude.ALWAYS('') == True


# Generated at 2022-06-11 20:58:16.465283
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(34) == True


# Generated at 2022-06-11 20:58:17.697730
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:58:18.974685
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-11 20:59:47.611224
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from marshmallow import fields
    from dataclasses_json import Config, LetterCase, dataclass_json

    @dataclass
    class Foo:
        id: int
        name: str = field(metadata=config(field_name='name'))
        excluded_field: int = field(metadata=config(exclude=Exclude.ALWAYS))
        email: str = field(metadata=config(
            letter_case=LetterCase.CAMEL,
            undefined=Undefined.EXCLUDE,
            mm_field=fields.Email,
        ))

        def __post_init__(self) -> None:
            self.id = str(self.id)

        def __str__(self) -> str:
            return f"{self.id}-{self.name}"

# Generated at 2022-06-11 20:59:49.056684
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    e = Exclude
    assert e.NEVER('a') == False


# Generated at 2022-06-11 20:59:56.769481
# Unit test for function config
def test_config():
    @dataclass
    class TestData:
        a: int = 1
        b: str = "a"
        c: str = Field(init=False, default="c")

    assert TestData.__dataclass_fields__["c"].metadata['dataclasses_json']['exclude'] == Exclude.NEVER
    assert TestData.__dataclass_fields__["b"].metadata['dataclasses_json']['undefined'] == Undefined.EXCLUDE

    assert TestData.__dataclass_fields__["a"].metadata['dataclasses_json']['exclude'] == Exclude.NEVER
    assert TestData.__dataclass_fields__["a"].metadata['dataclasses_json']['undefined'] == Undefined.RAISE


test_config()

# Generated at 2022-06-11 20:59:57.872816
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test')



# Generated at 2022-06-11 21:00:02.151201
# Unit test for function config
def test_config():
    @dataclass
    @config(letter_case=lambda x: x)
    class Foo:
        pass

    assert Foo.__config__ == {
        'letter_case': lambda x: x,
    }
    assert Foo.__metadata__ == {
        'dataclasses_json': {
            'letter_case': lambda x: x
        }
    }



# Generated at 2022-06-11 21:00:04.033689
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER("test") == False)
    

# Generated at 2022-06-11 21:00:07.709216
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(3.14) == True


# Generated at 2022-06-11 21:00:12.015896
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS('test') == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS([]) == True


# Generated at 2022-06-11 21:00:16.145575
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(False)

# Generated at 2022-06-11 21:00:18.376441
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-11 21:03:19.799549
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 21:03:27.047466
# Unit test for function config
def test_config():
    metadata = {}
    lib_metadata = {
        'encoder': object(),
        'decoder': object(),
        'mm_field': object(),
        'undefined': Undefined.EXCLUDE,
        'letter_case': lambda _: 'abc',
        'exclude': lambda _, __: True
    }
    assert config(metadata) == {'dataclasses_json': {}}
    assert config(metadata, encoder=object(), decoder=object(),
                  mm_field=object(), undefined=Undefined.EXCLUDE,
                  letter_case=lambda _: 'abc',
                  exclude=lambda _, __: True) == {'dataclasses_json': lib_metadata}

# Generated at 2022-06-11 21:03:29.335690
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    obst = Exclude.ALWAYS(10)
    assert obst == True



# Generated at 2022-06-11 21:03:30.160074
# Unit test for method NEVER of class Exclude

# Generated at 2022-06-11 21:03:31.619299
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	a = Exclude.NEVER(13)
	assert a == False


# Generated at 2022-06-11 21:03:35.945424
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER("")
    assert Exclude.NEVER("test string")
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(Exclude.ALWAYS)


# Generated at 2022-06-11 21:03:38.619456
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Test Exclude.NEVER(): ", end="")
    assert Exclude.NEVER('_')
    print("Passed")


# Generated at 2022-06-11 21:03:42.061310
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("ciao")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS([1,2,3])

# Generated at 2022-06-11 21:03:49.950249
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class TestDataclass:
        field: str


    class TestMarshmallowField(MarshmallowField):
        pass

    assert TestDataclass.__dataclass_fields__['field'].metadata == {}

    @config(mm_field = TestMarshmallowField,
            encoder = lambda s, *args: "encoded string",
            decoder = lambda s, *args, **kwargs: "decoded string",
            letter_case = lambda s, *args, **kwargs: "letter_case",
            undefined = Undefined.PASSTHROUGH,
            exclude = Exclude.ALWAYS
            )
    @dataclass
    class TestDataclass:
        field: str


# Generated at 2022-06-11 21:03:52.362130
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
