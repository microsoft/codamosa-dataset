

# Generated at 2022-06-11 20:54:20.600549
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") is True


# Generated at 2022-06-11 20:54:21.901516
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-11 20:54:24.011574
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) is True


# Generated at 2022-06-11 20:54:26.150838
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None) == True)


# Generated at 2022-06-11 20:54:27.430287
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-11 20:54:32.285690
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(-1)
    assert Exclude.ALWAYS(-2.3)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("hello")


# Generated at 2022-06-11 20:54:33.433691
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 20:54:35.020358
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def test_func():
        return True
    assert not Exclude.NEVER(test_func)


# Generated at 2022-06-11 20:54:36.524469
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-11 20:54:39.852839
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(.5)
    assert Exclude.ALWAYS(1.5)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-11 20:54:42.594329
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(5)


# Generated at 2022-06-11 20:54:45.009068
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    param = "irrelevant"
    assert(Exclude.NEVER(param) == False)


# Generated at 2022-06-11 20:54:46.118520
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('foobar') is True


# Generated at 2022-06-11 20:54:57.146883
# Unit test for function config
def test_config():
    # Test undefined should be in Undefined, otherwise raise Exception
    with pytest.raises(UndefinedParameterError):
        config(undefined='test')
    # Test undefined is case insensitive
    assert config(undefined='ignore') == config(undefined='IGNORE')
    # Test undefined is Undefined if metadata is defined
    assert config(undefined=Undefined.EXCLUDE) == \
        config(undefined='exclude')
    # Test undefined is Undefined if metadata is defined
    assert config(undefined=Undefined.RAISE) == \
        config(undefined='raise')
    # Test undefined is Undefined if metadata is defined
    assert config(undefined=Undefined.WARN) == \
        config(undefined='warn')

    # Test exclude is a Callable
    def exclude(*args, **kwargs):
        pass

# Generated at 2022-06-11 20:54:58.999990
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)

# Generated at 2022-06-11 20:54:59.933866
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('abc') == False

# Generated at 2022-06-11 20:55:01.595072
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(1)
    assert result == False, "Should be False"


# Generated at 2022-06-11 20:55:04.652198
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("str")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(())


# Generated at 2022-06-11 20:55:05.874873
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    f = Exclude.ALWAYS
    assert f(0)


# Generated at 2022-06-11 20:55:08.174924
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("trojan") is False


# Generated at 2022-06-11 20:55:12.401382
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class Foo:
        a: str
        b: str

    f = Foo("a", "b")
    data = dataclasses_json.dump(f)

    assert data == {}



# Generated at 2022-06-11 20:55:17.942264
# Unit test for function config
def test_config():
    # type: () -> None

    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(encoder=lambda x: x.upper(), mm_field=fields.Str)
    class Foo:
        bar: str
        baz: str

    assert Foo.schema().fields['bar'] == fields.Str()
    assert Foo.schema().loads(dict(bar='a', baz='b')).bar == 'A'

# Generated at 2022-06-11 20:55:19.482830
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    input = Exclude.ALWAYS(1)
    expected = True
    assert input == expected

# Generated at 2022-06-11 20:55:20.994422
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER("_") == False)

# Generated at 2022-06-11 20:55:31.839085
# Unit test for function config
def test_config():
    from dataclasses import fields
    from marshmallow import fields as mm_fields
    from dataclasses_json.api import BLACKLIST, DEFAULT, MODE

    @config(
        encoder=str,
        decoder=None,
        mm_field=mm_fields.Boolean(missing=False),
        field_name='my_new_field_name',
        letter_case=str.lower,
        undefined=DEFAULT,
        exclude=Exclude.ALWAYS
    )
    class MyClass:
        my_field: int
        my_new_field_name: bool

    opts = global_config.__dict__

    field_names = ('my_field', 'my_new_field_name')

    assert opts['encoders'][int] is str

# Generated at 2022-06-11 20:55:33.653447
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)

#Unit test for method NEVER of class Exclude

# Generated at 2022-06-11 20:55:35.081584
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:39.063170
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER
    assert x('x') == False
    assert x('y') == False
    assert x('z') == False
    assert x(1) == False
    assert x(3.14) == False
    assert x(True) == False
    assert x(False) == False

# Generated at 2022-06-11 20:55:40.052207
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER('test')

# Generated at 2022-06-11 20:55:41.719383
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("name") == True


# Generated at 2022-06-11 20:55:48.446948
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS("some string") == True
    assert Exclude.ALWAYS([2,3,4,5]) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS([]) == True


# Generated at 2022-06-11 20:55:51.422676
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER(5)
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER('5') == False
    


# Generated at 2022-06-11 20:55:52.677653
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    t = Exclude.ALWAYS(1)
    assert t == True


# Generated at 2022-06-11 20:55:53.690038
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('anything') == False


# Generated at 2022-06-11 20:55:54.907368
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    value = "test_value"
    assert Exclude.NEVER(value) is False

# Generated at 2022-06-11 20:55:57.703449
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  assert Exclude.ALWAYS(0) == True
  assert Exclude.ALWAYS(1) == True
  assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:56:00.593847
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False


# Generated at 2022-06-11 20:56:01.989238
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('x') == False


# Generated at 2022-06-11 20:56:02.883926
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("hello") is False

# Generated at 2022-06-11 20:56:04.007637
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-11 20:56:06.680358
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    ret = Exclude.NEVER(1)
    assert ret == False



# Generated at 2022-06-11 20:56:08.439967
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(100) is False
    assert Exclude.NEVER("abc") is False


# Generated at 2022-06-11 20:56:10.066255
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    config(exclude = Exclude.NEVER)
    assert Exclude.NEVER(T) == False


# Generated at 2022-06-11 20:56:11.181556
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('foo')


# Generated at 2022-06-11 20:56:21.109167
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    class U: pass
    u = U()
    @dataclass
    class Cls:
        a: str = field(metadata=config(encoder=lambda*_,**__: "a",
                                       decoder=lambda*_,**__: "b",
                                       mm_field=lambda*_,**__: "c",
                                       letter_case="d",
                                       undefined="drop",
                                       exclude=lambda*_,**__: "e",
                                       ))
        b: list = field(metadata=config(encoder=u,
                                        decoder=u,
                                        mm_field=u,
                                        letter_case=u,
                                        undefined=u,
                                        exclude=u
                                        ))

    cls = Cls()

# Generated at 2022-06-11 20:56:24.113995
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1), "Something wrong"
    assert Exclude.ALWAYS(2), "Something wrong"
    assert Exclude.ALWAYS(3), "Something wrong"


# Generated at 2022-06-11 20:56:24.957738
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False) == False

# Generated at 2022-06-11 20:56:27.392439
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # When
    is_included = Exclude.ALWAYS(1)

    # Then
    assert is_included


# Generated at 2022-06-11 20:56:31.393000
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER("field1")

    if result != False:
        raise AssertionError("Result is not False")
    else:
        print("test_Exclude_NEVER OK")


# Generated at 2022-06-11 20:56:32.350729
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(true) == false

# Generated at 2022-06-11 20:56:36.030453
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    field_name = "this is a name"
    assert Exclude.ALWAYS(field_name) == True


# Generated at 2022-06-11 20:56:43.887877
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(encoder=1) == {'dataclasses_json': {'encoder': 1}}
    assert config(decoder=1) == {'dataclasses_json': {'decoder': 1}}
    assert config(mm_field=1) == {'dataclasses_json': {'mm_field': 1}}
    assert config(letter_case=1) == {'dataclasses_json': {'letter_case': 1}}
    assert config(undefined=1) == {'dataclasses_json': {'undefined': Undefined.RAISE}}
    assert config(undefined='raise') == {'dataclasses_json': {'undefined': Undefined.RAISE}}

# Generated at 2022-06-11 20:56:46.208841
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS.__name__ == '<lambda>'


# Generated at 2022-06-11 20:56:48.578593
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("hello") is False


# Generated at 2022-06-11 20:56:49.862517
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(T) == True


# Generated at 2022-06-11 20:56:54.848790
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass

    @dataclass
    class MyDataClass:
        name: str
        email: str

    @dataclass_json(exclude=Exclude.NEVER)
    class MyDataClass:
        name: str
        email: str

    instance: MyDataClass = MyDataClass('John Dow', 'example@email.com')

    assert dataclass_json(instance) == """{"name": "John Dow", "email": "example@email.com"}"""

# Generated at 2022-06-11 20:56:56.964479
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS(True) == Exclude.ALWAYS(False) == True)


# Generated at 2022-06-11 20:56:58.293422
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False



# Generated at 2022-06-11 20:56:59.453089
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:57:01.028818
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:57:09.195082
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test = Exclude.ALWAYS(10)
    expected = True
    assert test == expected, "Error calling Exclude.ALWAYS(10), got {}, expected {}".format(test, expected)

    test = Exclude.ALWAYS(20)
    expected = True
    assert test == expected, "Error calling Exclude.ALWAYS(20), got {}, expected {}".format(test, expected)


# Generated at 2022-06-11 20:57:11.160456
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS("hello")
    assert Exclude.ALWAYS([1, 2, 3])



# Generated at 2022-06-11 20:57:14.276830
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    if(Exclude.ALWAYS(1) != True):
        return False
    else:
        return True


# Generated at 2022-06-11 20:57:15.361382
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:57:19.005331
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    @config()
    class TestClass:
        field: int
        field2: str

    assert TestClass(1, 'field2') is not None

# Generated at 2022-06-11 20:57:20.482894
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('hello')



# Generated at 2022-06-11 20:57:22.585519
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:57:28.198631
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # ALWAYS predicate of exclusion accepts all
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(2.0) == True
    assert Exclude.ALWAYS(100) == True
    assert Exclude.ALWAYS(-100.0) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:30.650276
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:57:31.871290
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:57:38.777145
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-11 20:57:45.304371
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS('') is True
    assert Exclude.ALWAYS([]) is True
    assert Exclude.ALWAYS(()) is True
    assert Exclude.ALWAYS({}) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(0.0) is True
    assert Exclude.ALWAYS(False) is True



# Generated at 2022-06-11 20:57:49.830326
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(object())
    assert Exclude.NEVER(serializable())



# Generated at 2022-06-11 20:57:51.072974
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)


# Generated at 2022-06-11 20:57:52.502237
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:57:53.790534
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	return Exclude.NEVER(1)



# Generated at 2022-06-11 20:57:55.669315
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1))


# Generated at 2022-06-11 20:57:59.306874
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    return True


# Generated at 2022-06-11 20:58:04.221332
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(())


# Generated at 2022-06-11 20:58:05.931201
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER("a")



# Generated at 2022-06-11 20:58:22.857877
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field, asdict
    from marshmallow import Schema, fields
    class MySchema(Schema):
        a = fields.Int()
    def encoder(obj, *args, **kwargs):
        return str(obj)
    def decoder(obj, *args, **kwargs):
        return int(obj)
    @dataclass
    class MyDataClass:
        b: int
        a: str = field(metadata=config(encoder=encoder, decoder=decoder, mm_field=MySchema.a))
    assert asdict(MyDataClass(1)) == {"b": 1, "a": None}

# Generated at 2022-06-11 20:58:24.914865
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:58:26.209061
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("0")


# Generated at 2022-06-11 20:58:27.640648
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a')


# Generated at 2022-06-11 20:58:30.040338
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 20:58:35.207865
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('1') == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS((1,2)) == True
    assert Exclude.ALWAYS({1,2}) == True
    assert Exclude.ALWAYS({1:1}) == True


# Generated at 2022-06-11 20:58:39.378968
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("abc") == True
    assert Exclude.ALWAYS(0x0a) == True
    assert Exclude.ALWAYS(0.0) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS({'a': 1, 'b': 2}) == True


# Generated at 2022-06-11 20:58:41.037603
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # given
    value = 10
    # when
    result = Exclude.ALWAYS(value)
    # then
    assert result



# Generated at 2022-06-11 20:58:47.335963
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER.__name__ == "NEVER"
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(Exception) == False
    assert Exclude.NEVER(value=True) == False
    return None


# Generated at 2022-06-11 20:58:48.852955
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-11 20:59:18.044414
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Put the Undefined key undefined at the dictionary
    cfg = config(undefined=Undefined.EXCLUDE)

# Generated at 2022-06-11 20:59:18.845844
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_tuple = (1,2,"a")
    assert Exclude.NEVER(test_tuple) == False

# Generated at 2022-06-11 20:59:21.658557
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_input = Exclude.NEVER(1)
    if test_input != False:
        raise AssertionError("Expected False, got: {}".format(test_input))

# Generated at 2022-06-11 20:59:26.229234
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from unittest import TestCase
    class MyTest(TestCase):
        def test_Exclude_NEVER(self):
            self.assertTrue(Exclude.NEVER(None))
            self.assertTrue(Exclude.NEVER(1))
            self.assertTrue(Exclude.NEVER("any"))
    return MyTest


# Generated at 2022-06-11 20:59:27.460974
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:59:28.399171
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:59:29.925935
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:59:32.186423
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("foo") == False, "Exclude.NEVER returned True when it should be False"


# Generated at 2022-06-11 20:59:38.049957
# Unit test for function config
def test_config():
    config_meta = config()
    assert config_meta['dataclasses_json'] == {}

    config_meta = config(encoder=lambda x: x)
    assert config_meta['dataclasses_json']['encoder'] == (lambda x: x)

    config_meta = config(decoder=lambda x: x)
    assert config_meta['dataclasses_json']['decoder'] == (lambda x: x)

    config_meta = config(mm_field=None)
    assert config_meta['dataclasses_json']['mm_field'] == None

    config_meta = config(field_name='MyName')
    assert config_meta['dataclasses_json']['letter_case']('test') == 'MyName'

    config_meta = config(letter_case=str.upper)
   

# Generated at 2022-06-11 20:59:41.950520
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    """
    Exclude.ALWAYS is a function that always returns True
    """
    func = Exclude.ALWAYS
    assert isinstance(func, Callable[[T], bool])
    assert func('hello world')


# Generated at 2022-06-11 21:00:29.342850
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("true") == True


# Generated at 2022-06-11 21:00:31.495062
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Unit test for method NEVER of class Exclude")
    never = Exclude.NEVER
    result = never(dict())
    assert result

# Generated at 2022-06-11 21:00:36.588564
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("string") == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(1.0) == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-11 21:00:38.103631
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 21:00:42.691369
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('any string')
    assert Exclude.ALWAYS(8)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS()
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(0.5)
    assert Exclude.ALWAYS([1, 2, 3, 4])
    assert Exclude.ALWAYS({'a': 2, 'b': 3})
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 21:00:45.307932
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2.2)
    assert Exclude.ALWAYS('string')
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-11 21:00:51.781892
# Unit test for function config
def test_config():
    assert config() == {'dataclasses_json': {}}
    assert config(field_name='custom_field_name') == \
        {'dataclasses_json': {'letter_case': 'custom_field_name'}}
    assert config(undefined='ignore') == \
        {'dataclasses_json': {'undefined': Undefined.IGNORE}}
    assert config(exclude=Exclude.NEVER) == \
        {'dataclasses_json': {'exclude': Exclude.NEVER}}

# Generated at 2022-06-11 21:00:52.963310
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS('data')

# Generated at 2022-06-11 21:00:55.256969
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS(object()) is True



# Generated at 2022-06-11 21:00:57.956682
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 21:02:48.237677
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(None) == False
    

# Generated at 2022-06-11 21:02:50.098954
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    Test to assert that method NEVER of class Exclude is defined
    """
    boolean = lambda _: False
    assert Exclude.NEVER == boolean

# Generated at 2022-06-11 21:02:51.222076
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("something") == False


# Generated at 2022-06-11 21:02:52.366855
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class test:
        val = 2
    assert not Exclude.NEVER(test)


# Generated at 2022-06-11 21:02:54.422196
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(None)
    assert not Exclude.NEVER(1)
    assert not Exclude.NEVER('any')


# Generated at 2022-06-11 21:02:55.409306
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 21:02:56.297941
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS is not None


# Generated at 2022-06-11 21:02:57.620795
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test = Exclude()
    temp=test.ALWAYS(True)
    assert temp == True


# Generated at 2022-06-11 21:02:59.777251
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 21:03:02.372324
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    input_ = [1, 2, 3]
    expected_output = True
    output = Exclude.ALWAYS(input_)
    assert output == expected_output
