

# Generated at 2022-06-11 20:54:25.205246
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('something') == True


# Generated at 2022-06-11 20:54:27.093162
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("EXPECTED RESULT: False. ACTUAL RESULT: ", Exclude.NEVER(""))


# Generated at 2022-06-11 20:54:29.047211
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    u = False
    res = Exclude.NEVER(u)
    exp = False
    assert res == exp


# Generated at 2022-06-11 20:54:33.439055
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") is False
    assert Exclude.NEVER("no") is False
    assert Exclude.NEVER("yes") is False
    assert Exclude.NEVER("non") is False
    assert Exclude.NEVER("none") is False
    assert Exclude.NEVER("xxx") is False


# Generated at 2022-06-11 20:54:34.759691
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 20:54:36.972403
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:54:38.343411
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False



# Generated at 2022-06-11 20:54:47.657213
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    import pytest
    # Unit tests for the config function
    # Also tests for configuring for classes
    @dataclass
    @config(mm_field=fields.Integer())
    class IntField:
        i: int

    @dataclass
    @config(mm_field=fields.Integer())
    class FloatField:
        i: float

    @dataclass
    @config(undefined=Undefined.IGNORE)
    class IgnoredField:
        i: str

    @dataclass
    @config(field_name='new-field')
    class FieldName:
        i: str


# Generated at 2022-06-11 20:54:51.052765
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)

if __name__ == "__main__":
    test_Exclude_ALWAYS()

# Generated at 2022-06-11 20:54:56.805869
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(Undefined) is True
    assert Exclude.NEVER(None) is True
    assert Exclude.NEVER(True) is True
    assert Exclude.NEVER(False) is True
    assert Exclude.NEVER(0) is True
    assert Exclude.NEVER(0.0) is True
    assert Exclude.NEVER('0.0') is True


# Generated at 2022-06-11 20:55:00.104920
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') is False


# Generated at 2022-06-11 20:55:01.371036
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:03.062062
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = 'abc'
    assert Exclude.NEVER(a) == False


# Generated at 2022-06-11 20:55:04.156466
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:55:14.240695
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    from dataclasses_json import config
    import json

    @dataclass
    class Test:
        name: str
        last_name: str
        age: int

        @config(exclude=Exclude.NEVER)
        def last_name(self):
            return self.last_name

        @config(exclude=Exclude.NEVER)
        def age(self):
            return self.age

    test_instance = Test("John", "Doe", 56)
    test_instance_json = json.loads(test_instance.to_json())
    assert "last_name" in test_instance_json and "age" in test_instance_json


# Generated at 2022-06-11 20:55:15.528803
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    '''
    Test Exclude.NEVER
    '''
    assert Exclude.NEVER(2)

# Generated at 2022-06-11 20:55:17.808752
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert Exclude.ALWAYS(1)
   assert Exclude.ALWAYS('string')


# Generated at 2022-06-11 20:55:21.781812
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER("")


# Generated at 2022-06-11 20:55:22.763966
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER()


# Generated at 2022-06-11 20:55:25.111902
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS("hello")
    assert result == True, "Something went wrong with the method ALWAYS from class Exclude"


# Generated at 2022-06-11 20:55:27.430687
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:28.598670
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS("hello"))


# Generated at 2022-06-11 20:55:31.147464
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(None)
    assert result == True, f"Expected: True; Actual: {result}"


# Generated at 2022-06-11 20:55:33.377565
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER('a')
    assert not Exclude.NEVER(1)
    assert not Exclude.NEVER(object)


# Generated at 2022-06-11 20:55:35.414311
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-11 20:55:37.750433
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-11 20:55:44.798374
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Test function with integer argument
    assert Exclude.ALWAYS(1) is True
    # Test function with string argument
    assert Exclude.ALWAYS('string') is True
    # Test function with object argument
    class A:
        a = 1
        def __init__(self, a):
            self.a = a
    obj = A(2)
    assert Exclude.ALWAYS(obj) is True
    # Test function with multiple argument
    assert Exclude.ALWAYS(1, 'string', obj) is True



# Generated at 2022-06-11 20:55:49.222191
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # help of lambda :
    # https://www.geeksforgeeks.org/lambda-in-python/
    # source code of class Exclude :
    # file : dataclasses_json/config.py
    # line : 56
    Exclude.NEVER(None)
    print(Exclude.NEVER(None))

# Generated at 2022-06-11 20:55:51.092194
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)


# Generated at 2022-06-11 20:55:52.743804
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert (Exclude.NEVER(1) == False)
    return True


# Generated at 2022-06-11 20:56:07.360175
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(True)
    assert result == True
    result = Exclude.ALWAYS(False)
    assert result == True
    result = Exclude.ALWAYS(0)
    assert result == True
    result = Exclude.ALWAYS(3)
    assert result == True
    result = Exclude.ALWAYS('a')
    assert result == True
    result = Exclude.ALWAYS('abc')
    assert result == True
    result = Exclude.ALWAYS('')
    assert result == True
    result = Exclude.ALWAYS([])
    assert result == True
    result = Exclude.ALWAYS(['a'])
    assert result == True
    result = Exclude.ALWAYS(['a', 'b'])
    assert result == True
    result = Exclude.ALWAYS({})

# Generated at 2022-06-11 20:56:08.571597
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    some_object = object
    assert Exclude.NEVER(some_object) == False

# Generated at 2022-06-11 20:56:09.853047
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():

    assert Exclude.ALWAYS("test")



# Generated at 2022-06-11 20:56:13.554705
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    dummy = "dummy"
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(dummy) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({}) == False


# Generated at 2022-06-11 20:56:16.846196
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True  # type: ignore
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-11 20:56:21.939467
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1.2)
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})


# Generated at 2022-06-11 20:56:23.317024
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:56:24.692160
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a")==False


# Generated at 2022-06-11 20:56:29.769876
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('abc'*10) == True
    assert Exclude.ALWAYS(Exclude.NEVER) == True


# Generated at 2022-06-11 20:56:31.244484
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:56:41.205968
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    func = Exclude.ALWAYS
    assert func("") == True
    assert func(1) == True
    assert func("a") == True


# Generated at 2022-06-11 20:56:44.202979
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # object that is passed to the method
    obj = object()
    bool_value = Exclude.ALWAYS(obj)
    assert bool_value



# Generated at 2022-06-11 20:56:46.609670
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:55.318375
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(123) == False
    assert Exclude.NEVER(-123) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(123.456) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("0") == False
    assert Exclude.NEVER("HelloWorld_123456") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([0]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({'':None})

# Generated at 2022-06-11 20:56:58.524296
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    class X:
        i: int
        y: bool = field(metadata=config(exclude=Exclude.NEVER))

    assert X(1).y is None


# Generated at 2022-06-11 20:57:04.645353
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass, asdict
    from typing import Dict
    from dataclasses_json import config, Exclude

    @dataclass
    class MyData:
        a: int
        b: int = config(exclude=Exclude.NEVER)

    data = MyData(a=40, b=50)
    assert asdict(data) == {'a': 40, 'b': 50}


# Generated at 2022-06-11 20:57:06.804985
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:07.831329
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:08.998826
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:57:09.830312
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("something") is True

# Generated at 2022-06-11 20:57:27.145673
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:28.932056
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    flag = False
    if Exclude.ALWAYS(flag):
        flag = True
    assert flag

# Generated at 2022-06-11 20:57:30.427323
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('field')


# Generated at 2022-06-11 20:57:32.118787
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(Exclude.NEVER) == True

# Generated at 2022-06-11 20:57:33.419765
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False


# Generated at 2022-06-11 20:57:38.579906
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.2)
    assert Exclude.ALWAYS(1 + 2j)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1})


# Generated at 2022-06-11 20:57:40.438581
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)


# Generated at 2022-06-11 20:57:42.012447
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    print("Test Exclude.NEVER PASSED")


# Generated at 2022-06-11 20:57:43.953780
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:45.194788
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("Anything") == False


# Generated at 2022-06-11 20:58:32.045562
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(0) == True)
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.ALWAYS(-1) == True)
    assert(Exclude.ALWAYS(True) == True)
    assert(Exclude.ALWAYS(False) == True)
    assert(Exclude.ALWAYS({}) == True)
    assert(Exclude.ALWAYS([]) == True)
    assert(Exclude.ALWAYS('a') == True)
    assert(Exclude.ALWAYS('') == True)
    assert(Exclude.ALWAYS(()) == True)


# Generated at 2022-06-11 20:58:33.207537
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("_") == True


# Generated at 2022-06-11 20:58:34.326024
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:58:35.383009
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:58:36.155511
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:58:42.118721
# Unit test for function config
def test_config():
    import json
    import marshmallow
    from marshmallow.fields import String as StringField
    from marshmallow.schema import Schema as MarshmallowSchema
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json, config

    from typing import Dict

    from collections.abc import Mapping

    @dataclass_json
    @dataclass
    class DataConfig:
        name: str
        config: Dict = field(metadata=config(mm_field=StringField()))

    class DataConfigSchema(MarshmallowSchema):
        name = StringField()

    data = DataConfig(
        name='name',
        config=dict(config=dict(shared=True)))


# Generated at 2022-06-11 20:58:45.002961
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    #Arrange
    obj = Exclude()
    #Act
    res = obj.ALWAYS("Hi")
    #Assert
    assert res == True


# Generated at 2022-06-11 20:58:46.365053
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    value = 5
    assert Exclude.NEVER(value) == False


# Generated at 2022-06-11 20:58:48.112706
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)

# Generated at 2022-06-11 20:58:53.819116
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(-5) is True
    assert Exclude.ALWAYS("test") is True
    assert Exclude.ALWAYS("") is True
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS(1.2) is True
    assert Exclude.ALWAYS(0.0) is True
    assert Exclude.ALWAYS(-1.2) is True



# Generated at 2022-06-11 21:00:20.572870
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 21:00:22.401144
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    o = object()
    assert Exclude.NEVER(o) == False


# Generated at 2022-06-11 21:00:23.377134
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    pass


# Generated at 2022-06-11 21:00:24.655114
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-11 21:00:26.159704
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():

    assert(Exclude.ALWAYS("_") == True)


# Generated at 2022-06-11 21:00:27.239277
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('fake') == True


# Generated at 2022-06-11 21:00:30.687405
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3)
    assert not Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(list())
    assert Exclude.ALWAYS(dict())


# Generated at 2022-06-11 21:00:36.329534
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(float('inf')) == True



# Generated at 2022-06-11 21:00:37.482293
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-11 21:00:40.215695
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    func = Exclude.ALWAYS
    assert func(1) == True
    assert func(2) == True
    assert func(3) == True


# Generated at 2022-06-11 21:03:41.302192
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class A:
        b = "b"
    assert Exclude.ALWAYS(A) == True
    assert Exclude.ALWAYS("b") == True


# Generated at 2022-06-11 21:03:45.349719
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(-1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(3)



# Generated at 2022-06-11 21:03:48.559150
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS('string')
    assert Exclude.ALWAYS(Exclude.ALWAYS)



# Generated at 2022-06-11 21:03:50.284173
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-11 21:03:52.628833
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-11 21:03:53.876476
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('foo') is True


# Generated at 2022-06-11 21:03:55.461905
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 21:03:56.447321
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER)



# Generated at 2022-06-11 21:04:07.577586
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    cls = Exclude.NEVER
    if cls(0):
        assert False
    try:
        if cls(1):
            assert False
    except:
        assert False
    try:
        if cls(True):
            assert False
    except:
        assert False
    try:
        if cls('1'):
            assert False
    except:
        assert False
    try:
        if cls(dict()):
            assert False
    except:
        assert False
    try:
        if cls([]):
            assert False
    except:
        assert False
    try:
        if cls(tuple()):
            assert False
    except:
        assert False
    try:
        if cls(None):
            assert False
    except:
        assert False
    assert True



# Generated at 2022-06-11 21:04:08.707725
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('abc') is False
