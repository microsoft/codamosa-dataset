

# Generated at 2022-06-11 20:54:20.343934
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:54:22.010540
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude()
    assert obj.NEVER(True) == False


# Generated at 2022-06-11 20:54:33.039512
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses_json import Undefined
    import json
    import decimal

    def encoder(obj):
        pass

    def decoder(obj):
        pass

    class MMField(fields.Field):
        pass

    def letter_case(letter: str):
        pass

    def exclude(_name, _cls):
        pass

    metadata = config(encoder=encoder,
                      decoder=decoder,
                      mm_field=MMField,
                      letter_case=letter_case,
                      undefined=Undefined.EXCLUDE,
                      field_name='field_name',
                      exclude=exclude)
    assert 'dataclasses_json' in metadata
    lib_metadata = metadata['dataclasses_json']
    assert 'encoder' in lib_metadata
    assert lib_metadata

# Generated at 2022-06-11 20:54:34.646032
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("example string") is False

# Unit Test for method ALWAYS of class Exclude

# Generated at 2022-06-11 20:54:41.880985
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False, "Exclusion Failed"
    assert Exclude.NEVER("b") == False, "Exclusion Failed"
    assert Exclude.NEVER(1) == False, "Exclusion Failed"
    assert Exclude.NEVER(0) == False, "Exclusion Failed"
    assert Exclude.NEVER(None) == False, "Exclusion Failed"
    assert Exclude.NEVER([]) == False, "Exclusion Failed"
    assert Exclude.NEVER({}) == False, "Exclusion Failed"
    assert Exclude.NEVER([1,2]) == False, "Exclusion Failed"
    assert Exclude.NEVER({'a':1, 'b':2}) == False, "Exclusion Failed"

# Generated at 2022-06-11 20:54:44.236691
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    #print (Exclude.ALWAYS(1))
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:54:45.478969
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-11 20:54:46.501784
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)


# Generated at 2022-06-11 20:54:47.885904
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS() == True


# Generated at 2022-06-11 20:54:59.806994
# Unit test for function config
def test_config():

    from dataclasses import dataclass

    @dataclass
    class Test:
        pass

    metadata = config(
        encoder=lambda x: x,
        decoder=lambda x: x,
        mm_field=MarshmallowField(),
        letter_case=lambda x: x.upper(),
        undefined=Undefined.EXCLUDE,
        field_name='field',
        exclude=lambda x, y: True,
    )
    assert metadata['dataclasses_json'] == dict(
        encoder=lambda x: x,
        decoder=lambda x: x,
        mm_field=MarshmallowField(),
        letter_case=lambda x: x.upper(),
        undefined=Undefined.EXCLUDE,
        field_name='field',
        exclude=lambda x, y: True,
    )
   

# Generated at 2022-06-11 20:55:02.853559
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:55:04.127872
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True


# Generated at 2022-06-11 20:55:05.756831
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    EXAMPLE = "example"
    assert Exclude.ALWAYS(EXAMPLE)


# Generated at 2022-06-11 20:55:16.712277
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER(" ") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(1.0) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(3 + 5j) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER([1,2,3]) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER((1,)) == False
    assert Exclude.NEVER((1,2,3)) == False
    assert Exclude

# Generated at 2022-06-11 20:55:18.428591
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:55:26.799999
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(10)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(12.3)
    assert Exclude.ALWAYS(1.2e-3)
    assert Exclude.ALWAYS('abc')
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS((1, 2, 3))
    assert Exclude.ALWAYS({1: 'a', 2: 'b', 3: 'c'})


# Generated at 2022-06-11 20:55:28.802600
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(42) == True)
    assert(Exclude.ALWAYS(Undefined) == True)


# Generated at 2022-06-11 20:55:30.616570
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:55:31.959461
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert True == Exclude.ALWAYS(True)


# Generated at 2022-06-11 20:55:33.081916
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert Exclude.NEVER(1)==False

# Generated at 2022-06-11 20:55:36.016814
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS("field") == True)


# Generated at 2022-06-11 20:55:36.872661
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER(3)

# Generated at 2022-06-11 20:55:38.693928
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def test(x):
        return False

    assert test == Exclude.NEVER


# Generated at 2022-06-11 20:55:40.456420
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert not Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:55:41.760372
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False)

# Generated at 2022-06-11 20:55:43.593461
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False, "Exclude.NEVER does not work"


# Generated at 2022-06-11 20:55:45.318315
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    A = Exclude.NEVER
    assert not A(1)


# Generated at 2022-06-11 20:55:48.362497
# Unit test for function config
def test_config():
    class A:
        pass
    x = config(encoder=A)
    assert isinstance(x['dataclasses_json']['encoder'], type(A))



# Generated at 2022-06-11 20:55:50.727109
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert(Exclude.ALWAYS("a") == True)
   assert(Exclude.ALWAYS("ab") == True)


# Generated at 2022-06-11 20:55:53.100539
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    expected_result = False

    # Act
    result = Exclude.NEVER("a")

    # Assert
    assert result == expected_result

# Generated at 2022-06-11 20:56:01.195530
# Unit test for function config
def test_config():
    @dataclass
    class Person:
        first_name: str
        id: int
        # TODO: if we ever add the ability to rename the field in the
        # _GlobalConfig metadata, we will have to update this test
        name: str = config(field_name='first_name')
        email_address: str = config(field_name='email',letter_case=None)
        age: int = config(undefined=Undefined.RAISE)

    json_str = '{"first_name": "John", "email": "john@example.com"}'

    person = Person.schema().loads(json_str) 
    assert person.name=='John'
    assert person.email_address == "john@example.com"

# Generated at 2022-06-11 20:56:02.475334
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:56:03.353863
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER)



# Generated at 2022-06-11 20:56:05.100870
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)

# Generated at 2022-06-11 20:56:11.443960
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(10.0)
    assert Exclude.NEVER(-1)
    assert Exclude.NEVER(-10.0)
    assert Exclude.NEVER(0.1)
    assert Exclude.NEVER(-0.1)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(None)
    # assert Exclude.NEVER([])
    # assert Exclude.NEVER({})
    assert Exclude.NEVER('abcd')
    assert Exclude.NEVER('')


# Generated at 2022-06-11 20:56:12.973180
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

test_Exclude_NEVER()


# Generated at 2022-06-11 20:56:15.456746
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)



# Generated at 2022-06-11 20:56:19.347277
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():

    # Test case 1
    class TestCase1:
        x = True

    assert Exclude.ALWAYS(TestCase1)

    # Test case 2
    class TestCase2:
        x = False

    assert Exclude.ALWAYS(TestCase2)



# Generated at 2022-06-11 20:56:20.302150
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-11 20:56:22.451526
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    from dataclasses_json.config import Exclude

    def func():
        pass
    assert Exclude.ALWAYS(func) == True


# Generated at 2022-06-11 20:56:31.798700
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Exclude.NEVER function has not just 1 constant value, it has 2 constant
    # values, 1 is True and another is False. However, we only need to test
    # 1 value to prove that it is a constant value.
    assert Exclude.NEVER("test") == False
    assert Exclude.NEVER("test") == False


# Generated at 2022-06-11 20:56:33.323072
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test = Exclude()
    resp = test.NEVER('a')
    assert resp == False


# Generated at 2022-06-11 20:56:42.218965
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined
    # Define an encoder
    def encoder(obj):
        return [str(obj)]

    # Define a decoder
    def decoder(obj):
        return obj

    # Define a Marshmallow Field
    class MyField(fields.Field):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    # Define a custom letter case
    def letter_case(field_name):
        return field_name.lower()

    # Define a custom exclude
    def exclude(field_name, field_value):
        return field_name.startswith("_")

    # Define a class that is decorated with config

# Generated at 2022-06-11 20:56:48.476123
# Unit test for function config
def test_config():
    from enum import Enum
    class Undef(Enum):
        STRICT = 1
        EMPTY = 2

    # Test Undefined
    config(undefined=Undef.EMPTY.name)
    config(undefined=Undef.EMPTY)

    config(undefined="Strict")

# Generated at 2022-06-11 20:56:50.131925
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    name = Exclude.ALWAYS.__name__

    assert name == "ALWAYS"


# Generated at 2022-06-11 20:56:51.093527
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(_)


# Generated at 2022-06-11 20:56:52.470080
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:54.701847
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  a = Exclude()
  assert(a.NEVER("hello") == False)


# Generated at 2022-06-11 20:56:57.208383
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("good input") is True
    assert Exclude.ALWAYS("bad input") is True


# Generated at 2022-06-11 20:56:58.523444
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('something') == False


# Generated at 2022-06-11 20:57:13.286872
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:57:15.531946
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(1.1) == True
    assert Exclude.ALWAYS("a") == True


# Generated at 2022-06-11 20:57:19.742023
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("Untitled")
    assert Exclude.NEVER(42)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER([])


# Generated at 2022-06-11 20:57:21.738343
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:57:24.490770
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def _is_included(name):
        return False
    assert(Exclude.NEVER('Test') == _is_included('Test'))
    assert(Exclude.NEVER('None') == _is_included('None'))


# Generated at 2022-06-11 20:57:28.501356
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") is True
    assert Exclude.ALWAYS("test") is True
    assert Exclude.ALWAYS(123) is True
    assert Exclude.ALWAYS(-456) is True
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-11 20:57:29.832242
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER('name'))


# Generated at 2022-06-11 20:57:31.699985
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS() == True



# Generated at 2022-06-11 20:57:41.071827
# Unit test for function config
def test_config():
    import marshmallow
    import marshmallow_dataclass
    from dataclasses import dataclass

    @config()
    @dataclass
    class A:
        ident: int
        name: str

    assert A.__dataclass_metadata__['dataclasses_json']['mm_field'] == marshmallow.fields.Field

    @config(mm_field=marshmallow.fields.Integer)
    @dataclass
    class B:
        ident: int
        name: str
    assert B.__dataclass_metadata__['dataclasses_json']['mm_field'] == marshmallow.fields.Integer

    @config()
    @dataclass
    class C:
        ident: int
        name: str
    m = marshmallow_dataclass.class_schema(C)
    assert m

# Generated at 2022-06-11 20:57:42.347821
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:58:12.091147
# Unit test for function config
def test_config():
    simple_class = dataclasses.make_dataclass('simple_class',
                                              [('f0', int),
                                               ('f1', int)])
    simple_dict = {'f0': 1, 'f1': 2}
    simple_json = '{"f0": 1, "f1": 2}'

    undef_class = dataclasses.make_dataclass('undef_class',
                                             [('f0', int, config(undefined=Undefined.SKIP)),
                                              ('f1', int, config(undefined=Undefined.RAISE))])
    undef_dict = {'f1': 2}
    undef_json = '{"f1": 2}'

    class complex_class:
        def __init__(self, f0):
            self.obj

# Generated at 2022-06-11 20:58:21.427376
# Unit test for function config
def test_config():
    from dataclasses import dataclass

# Generated at 2022-06-11 20:58:22.201166
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:58:25.605411
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Create a constant field
    CONSTANT = Exclude.NEVER
    assert CONSTANT(1) == False
    assert CONSTANT(0) == False
    assert CONSTANT(1000000) == False

# Generated at 2022-06-11 20:58:27.302179
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest

    assert Exclude.NEVER("a") == False, "Exclude.NEVER failed"

# Generated at 2022-06-11 20:58:30.139523
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    a = Exclude.ALWAYS(None)
    assert(a== True)
    

# Generated at 2022-06-11 20:58:31.549799
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a')


# Generated at 2022-06-11 20:58:32.729886
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)  # 1 is not None


# Generated at 2022-06-11 20:58:34.774708
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def foo():
        print('foo')
    if Exclude.NEVER(foo):
        print('True')
    else:
        print('False')

# Generated at 2022-06-11 20:58:37.163461
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("abc")
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS({1,2,3})


# Generated at 2022-06-11 20:59:18.598459
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('my_var')


# Generated at 2022-06-11 20:59:21.569753
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.ALWAYS(1)
    assert not Exclude.NEVER(2)
    assert not (Exclude.NEVER(2) and Exclude.ALWAYS(1))

# Generated at 2022-06-11 20:59:22.553549
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS is not None)


# Generated at 2022-06-11 20:59:25.670674
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS(False) is not False


# Generated at 2022-06-11 20:59:26.891610
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("anything") == True


# Generated at 2022-06-11 20:59:28.202556
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") is False

# Generated at 2022-06-11 20:59:29.311208
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 20:59:31.531893
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-11 20:59:37.724257
# Unit test for function config
def test_config():
    from marshmallow import fields as mm_fields
    from marshmallow_dataclass import class_schema

    @config(exclude=Exclude.NEVER)
    @dataclass
    class C1:
        x: int

    assert C1(1).json() == '{"x": 1}'

    @config(letter_case=str.upper)
    @dataclass
    class C2:
        x: int

    assert C2(1).json() == '{"X": 1}'

    @config(mm_field=mm_fields.Email())
    @dataclass
    class C3:
        e: str

    assert C3("test@test.com").json() == '{"e": "test@test.com"}'


# Generated at 2022-06-11 20:59:39.272588
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-11 21:01:07.839838
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    return


# Generated at 2022-06-11 21:01:09.031918
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert True == Exclude.ALWAYS("")


# Generated at 2022-06-11 21:01:13.575872
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('owo') == True
    assert Exclude.ALWAYS('uwu') == True
    assert Exclude.ALWAYS('owo') != False
    assert Exclude.ALWAYS('uwu') != False

# Generated at 2022-06-11 21:01:14.953109
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(object), "Exclude.NEVER(object) is True"


# Generated at 2022-06-11 21:01:17.767948
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("dataclass") == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-11 21:01:29.267870
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(float("nan"))
    assert Exclude.ALWAYS(float("inf"))
    assert Exclude.ALWAYS(float("-inf"))
    assert Exclude.ALWAYS(float("infinity"))
    assert Exclude.ALWAYS(float("-infinity"))
    assert Exclude.ALWAYS(complex(1, 1))
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS((1, 2, 3))
   

# Generated at 2022-06-11 21:01:31.604752
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS('Hello')
    assert Exclude.ALWAYS(Exclude)


# Generated at 2022-06-11 21:01:32.994399
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("test_Exclude_NEVER has been called")
    assert Exclude.NEVER("test")

# Generated at 2022-06-11 21:01:35.704552
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test = Exclude()
    assert test.NEVER(3) == False
    assert test.NEVER("Never") == False
    assert test.NEVER("always") == False


# Generated at 2022-06-11 21:01:37.016554
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
