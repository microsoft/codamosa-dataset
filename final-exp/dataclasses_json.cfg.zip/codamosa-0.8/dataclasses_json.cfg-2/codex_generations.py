

# Generated at 2022-06-11 20:54:21.411264
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_1 = statement("test")
    test_2 = statement("test2")
    assert Exclude.ALWAYS(test_1)
    assert Exclude.ALWAYS(test_2)


# Generated at 2022-06-11 20:54:23.747443
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    value = Exclude.ALWAYS(1)
    assert value



# Generated at 2022-06-11 20:54:27.747525
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    @config(exclude = Exclude.NEVER)
    class A:
        a: int
    
    a = A(10)
    print(dict(a.__dict__))


# Generated at 2022-06-11 20:54:32.921859
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Test by feeding Exclude.NEVER with some parameters and verifying its outputs
    result = Exclude.NEVER(0)
    assert(result==False)
    result = Exclude.NEVER(1)
    assert(result==False)
    result = Exclude.NEVER("")
    assert(result==False)
    result = Exclude.NEVER("False")
    assert(result==False)


# Generated at 2022-06-11 20:54:35.183477
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():

    assert Exclude.ALWAYS("string") == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(3) == True



# Generated at 2022-06-11 20:54:36.698322
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_value = False
    assert test_value == Exclude.NEVER(_)

# Generated at 2022-06-11 20:54:38.108006
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert Exclude.NEVER(2) == False


# Generated at 2022-06-11 20:54:39.214443
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:54:40.666482
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:54:43.997971
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER
    assert a(1) == False
    assert a(True) == False
    assert a("apple") == False
    assert a([]) == False


# Generated at 2022-06-11 20:54:46.232016
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("A") is False

# Generated at 2022-06-11 20:54:55.488601
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(-1)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.5)
    assert Exclude.ALWAYS(-1.5)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS("Hello world")
    assert Exclude.ALWAYS("!@#$%^&*()")
    assert Exclude.ALWAYS("1")


# Generated at 2022-06-11 20:54:56.811230
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('anything') is True


# Generated at 2022-06-11 20:54:58.453978
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True

# Generated at 2022-06-11 20:55:01.829261
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestData:
        x = 1
        y = 2

    assert(Exclude.NEVER(TestData.x) == False)
    assert(Exclude.NEVER(TestData.y) == False)


# Generated at 2022-06-11 20:55:04.128644
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") is True
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-11 20:55:05.427416
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('anything') is False


# Generated at 2022-06-11 20:55:09.516232
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS(object) is True


# Generated at 2022-06-11 20:55:12.207930
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @config(exclude=Exclude.NEVER)
    @dataclass
    class MyClass:
        a: int
        b: int
    myclass = MyClass(1, 2)
    assert myclass == MyClass(1, 2)


# Generated at 2022-06-11 20:55:15.311426
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(f"Exclude.ALWAYS(True) is {Exclude.ALWAYS(True)}")
    print(f"Exclude.ALWAYS(False) is {Exclude.ALWAYS(False)}")


# Generated at 2022-06-11 20:55:19.166871
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Test: Pass anything to ALWAYS method
    assert Exclude.ALWAYS('23')
    # Test: Pass None to ALWAYS method
    assert Exclude.ALWAYS(None)

# Generated at 2022-06-11 20:55:20.697278
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-11 20:55:25.289227
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Check if method NEVER return False for any input
    assert Exclude.NEVER(1), "NEVER should return False for any input"
    assert Exclude.NEVER("foo"), "NEVER should return False for any input"
    assert not Exclude.NEVER(None), "NEVER should return False for any input"


# Generated at 2022-06-11 20:55:26.988863
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)



# Generated at 2022-06-11 20:55:28.329548
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test')


# Generated at 2022-06-11 20:55:30.088047
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:55:31.422637
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) is True


# Generated at 2022-06-11 20:55:32.649130
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(True)


# Generated at 2022-06-11 20:55:34.949625
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(Undefined) is True


# Generated at 2022-06-11 20:55:36.016531
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER("a"))


# Generated at 2022-06-11 20:55:38.983720
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-11 20:55:40.679202
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_dict={'a':1,'b':2}
    assert Exclude.ALWAYS(test_dict)==True

# Generated at 2022-06-11 20:55:42.265441
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Hello") == True


# Generated at 2022-06-11 20:55:43.635172
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    value = 1
    assert Exclude.NEVER(value) == False


# Generated at 2022-06-11 20:55:45.436969
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	data = Exclude.NEVER(1)
	assert data == False



# Generated at 2022-06-11 20:55:48.028772
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(12)
    assert result == True, "Expected result was not true"



# Generated at 2022-06-11 20:55:49.138317
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True



# Generated at 2022-06-11 20:55:50.966866
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) 
    

# Generated at 2022-06-11 20:55:53.912452
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    @dataclass
    class A:
        a: int

    a = A(0)
    assert Exclude.NEVER(a)
    assert not Exclude.NEVER(A(1))


# Generated at 2022-06-11 20:55:55.256623
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-11 20:56:05.439510
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(-1)
    assert Exclude.NEVER(0.0)
    assert Exclude.NEVER(1.0)
    assert Exclude.NEVER(-1.0)
    assert Exclude.NEVER(())
    assert Exclude.NEVER(('a',))
    assert Exclude.NEVER(('a', 'b'))

# Generated at 2022-06-11 20:56:06.607474
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:56:08.142976
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:09.204575
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc")



# Generated at 2022-06-11 20:56:10.580398
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") is True


# Generated at 2022-06-11 20:56:11.962973
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    NOTPASS = Exclude.NEVER("Test")
    assert(NOTPASS == False)


# Generated at 2022-06-11 20:56:21.978385
# Unit test for function config
def test_config():
    pass


# TODO: #180
# def get_json_module():
#     return global_config.json_module


# def _set_json_module(json_module):
#     global_config.json_module = json_module


# TODO: #180
# JSONModule = TypeVar('JSONModule', bound=ModuleType)
#
#
# @functools.lru_cache(maxsize=1)
# def get_import_path(json_module: JSONModule) -> str:
#     return json_module.__name__
#
#
# def get_import_name(json_module: JSONModule) -> str:
#     return json_module.__name__.split('.')[-1]
#
#
# def try_import_module(name: str) -> Optional[JSONModule]:

# Generated at 2022-06-11 20:56:23.032647
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(1)

# Generated at 2022-06-11 20:56:24.849480
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = int()
    y = Exclude.ALWAYS(x)
    assert y


# Generated at 2022-06-11 20:56:29.818342
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude()

    assert a.NEVER(0)
    assert a.NEVER(0.0)
    assert a.NEVER(True)
    assert a.NEVER(False)
    assert a.NEVER("")
    assert a.NEVER(" ")

# Generated at 2022-06-11 20:56:32.604042
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field = Exclude.NEVER("field")
    assert field == False


# Generated at 2022-06-11 20:56:34.501422
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    t = "test"
    assert Exclude.ALWAYS(t)


# Generated at 2022-06-11 20:56:36.223030
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3)
    assert not Exclude.NEVER(None)


# Generated at 2022-06-11 20:56:37.352652
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:40.877877
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    @config()
    class Data:
        foo: str
        bar: int

    assert Data.__dataclass_metadata__['dataclasses_json']['exclude'] == Exclude.NEVER



# Generated at 2022-06-11 20:56:46.949085
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(1.0) == False


# Generated at 2022-06-11 20:56:52.503778
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('text')
    assert Exclude.ALWAYS({'name': 'rishi'})


# Generated at 2022-06-11 20:56:53.642557
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(4) == False


# Generated at 2022-06-11 20:57:00.937307
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # True
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(())
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    # False
    assert not Exclude.NEVER(0)
    assert not Exclude.NEVER(1.2)
    assert not Exclude.NEVER(3j)
    assert not Exclude.NEVER("not none")


# Generated at 2022-06-11 20:57:02.518178
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:57:06.001953
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:57:08.212561
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert(True==Exclude.ALWAYS(True))
   assert(True==Exclude.ALWAYS(False))
   assert(True==Exclude.ALWAYS("One"))


# Generated at 2022-06-11 20:57:09.081407
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS


# Generated at 2022-06-11 20:57:10.536576
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class A:
        pass
    
    assert Exclude.ALWAYS(A())


# Generated at 2022-06-11 20:57:12.924847
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("x")


# Generated at 2022-06-11 20:57:14.791105
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 20:57:15.958180
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS(1)
    return True


# Generated at 2022-06-11 20:57:21.980537
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1), "test_Exclude_ALWAYS: Check ALWAYS method of Exclude class"
    assert Exclude.ALWAYS(12), "test_Exclude_ALWAYS: Check ALWAYS method of Exclude class"
    print('Exclude ALWAYS method: PASSED')


# Generated at 2022-06-11 20:57:22.675995
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:57:33.481314
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest
    
    # Test 1
    assert Exclude.NEVER(1) == False
    
    # Test 2
    assert Exclude.NEVER('some string') == False
    
    # Test 3
    assert Exclude.NEVER((1, 2)) == False
    
    # Test 4
    assert Exclude.NEVER([1, 2]) == False
    
    # Test 5
    assert Exclude.NEVER({'a': 1}) == False
    
    # Test 6
    assert Exclude.NEVER(True) == False
    
    # Test 7
    assert Exclude.NEVER(None) == False
    
    # Test 8
    assert Exclude.NEVER(1.0) == False
    
    # Test 9

# Generated at 2022-06-11 20:57:41.652000
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(_GlobalConfig.Exclude.ALWAYS("abc"))


# Generated at 2022-06-11 20:57:43.602168
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(1)


# Generated at 2022-06-11 20:57:44.893108
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:45.673483
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("123") == False

# Generated at 2022-06-11 20:57:48.061074
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class_ = Exclude
    obj = EXCLUDE_TEST_OBJ
    assert class_.ALWAYS(obj)



# Generated at 2022-06-11 20:57:50.020771
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class theClass():
        pass
    c = theClass()
    assert Exclude.NEVER(c) == False


# Generated at 2022-06-11 20:57:51.708129
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:57:53.063853
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('dataclasses_json')


# Generated at 2022-06-11 20:58:01.008889
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(0) == False)
    assert(Exclude.NEVER(1) == False)
    assert(Exclude.NEVER([]) == False)
    assert(Exclude.NEVER([0]) == False)
    assert(Exclude.NEVER("") == False)
    assert(Exclude.NEVER(" ") == False)
    assert(Exclude.NEVER(None) == False)
    assert(Exclude.NEVER(True) == False)
    assert(Exclude.NEVER(False) == False)


# Generated at 2022-06-11 20:58:02.115174
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test')


# Generated at 2022-06-11 20:58:22.921790
# Unit test for function config
def test_config():
    from enum import Enum
    from dataclasses import dataclass
    from marshmallow.fields import Str
    from dataclasses_json.undefined import Undefined

    @dataclass
    class Color(Enum):
        RED = "red"
        BLUE = "blue"
        GREEN = "green"

    @dataclass
    class Data:
        a: str

    @dataclass
    class Config:
        color: Color
        data: Data

    def encoder(v: Data):
        return v.a

    def decoder(v: str):
        return Data(a=v)

    # regression test for marshmallow field
    # regression test for underscore

# Generated at 2022-06-11 20:58:24.551675
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-11 20:58:25.891741
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    a = Exclude.ALWAYS(1)
    assert a == True

# Generated at 2022-06-11 20:58:35.777683
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.api import config
    import pytest


# Generated at 2022-06-11 20:58:36.705434
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("Some string") == False


# Generated at 2022-06-11 20:58:37.865236
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:58:39.053284
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:58:40.141644
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test')


# Generated at 2022-06-11 20:58:41.216978
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-11 20:58:49.653569
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(123) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1, 2, 3]) == False
    assert Exclude.NEVER({"a":1, "b":2, "c":3}) == False
    assert Exclude.NEVER({}) == False


# Generated at 2022-06-11 20:59:20.704743
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert _GlobalConfig.NEVER(None) == False


# Generated at 2022-06-11 20:59:21.750677
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-11 20:59:23.074142
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-11 20:59:24.161740
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-11 20:59:28.592548
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class Animal(object):
        name: str
        age: int

    a = Animal("Peter", 5)
    assert a.name is None
    assert a.age is None


# Generated at 2022-06-11 20:59:31.493415
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(20)
    assert not Exclude.ALWAYS(False)
    assert not Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:59:32.604367
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('abc')


# Generated at 2022-06-11 20:59:35.063697
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('asd')


# Generated at 2022-06-11 20:59:37.861559
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:59:41.096607
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    if Exclude.NEVER(3) == False:
        print("Unit test for method NEVER of class Exclude: Pass")
    else:
        print("Unit test for method NEVER of class Exclude: Fail")

# Generated at 2022-06-11 21:00:41.060669
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    always_result = Exclude.ALWAYS(Field("a", str, metadata={}))
    assert always_result is True, "Function Exclude.ALWAYS failed"

test_Exclude_ALWAYS()


# Generated at 2022-06-11 21:00:42.078626
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-11 21:00:43.348056
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_value = Exclude.ALWAYS(1)
    assert test_value == True


# Generated at 2022-06-11 21:00:45.202172
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a=False
    if Exclude.NEVER(1) == True:
        a=True
    assert a==False


# Generated at 2022-06-11 21:00:46.610571
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 21:00:50.726408
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is True
    assert Exclude.NEVER("string") is True
    assert Exclude.NEVER(1) is True
    assert Exclude.NEVER(0.1) is True
    assert Exclude.NEVER(True) is True


# Generated at 2022-06-11 21:00:52.128098
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    assert(Exclude.NEVER(True) == False)


# Generated at 2022-06-11 21:00:54.254013
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("coucou") == False


# Generated at 2022-06-11 21:00:55.810177
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 21:00:59.037352
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # arrange
    Ex = Exclude.NEVER
    a = ""
    # act
    b = Ex(a)
    # assert
    assert b == False
    print("Exclude.NEVER(" + a + ") is " + str(b))


# Generated at 2022-06-11 21:03:26.420947
# Unit test for function config
def test_config():
    from marshmallow.fields import Boolean

    def letter_case(name):
        return name.lower()

    def exclude(name, value):
        return name.endswith('_')

    @config(encoder=bool, decoder=float, mm_field=Boolean(missing=False),
            letter_case=letter_case, undefined='EXCLUDE',
            exclude=exclude)
    @dataclasses.dataclass
    class _:
        pass

    assert _._config()['dataclasses_json']['encoder'] == bool
    assert _._config()['dataclasses_json']['decoder'] == float
    assert _._config()['dataclasses_json']['mm_field'] == Boolean(missing=False)

# Generated at 2022-06-11 21:03:28.319612
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(4) == False

# Generated at 2022-06-11 21:03:30.615472
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    ALWAYS = Exclude.ALWAYS
    NEVER = Exclude.NEVER
    assert ALWAYS('a')
    assert NEVER('')
    assert NEVER(1)
    assert NEVER(None)
    assert NEVER([])
    assert NEVER(tuple())
    assert NEVER(set())
    assert NEVER({})
    assert NEVER(Exclude)
    assert NEVER(Exclude.ALWAYS)
    assert NEVER(Exclude.NEVER)

# Generated at 2022-06-11 21:03:31.850609
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('abc') == True


# Generated at 2022-06-11 21:03:33.820244
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("123")


# Generated at 2022-06-11 21:03:35.649561
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)  # 1 doesn't change the result
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(2)


# Generated at 2022-06-11 21:03:39.925670
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestClass:
        def __init__(self):
            self.name = "Alex"
    testObject = TestClass()
    result = Exclude.NEVER(testObject)
    assert result == False


# Generated at 2022-06-11 21:03:40.801629
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    pass


# Generated at 2022-06-11 21:03:48.038210
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Function to test
    test_func = Exclude.NEVER
    # Test cases
    test_cases = [1, 'str', [1,2], {'a': 1}]
    # Test result: only if it is False for all test cases
    test_result = True
    for test_case in test_cases:
        if test_func(test_case) == True:
            test_result = False
            print(f"Test failed for test_func = {test_func} and test_case = {test_case}")
    # Return test result 
    return test_result


# Generated at 2022-06-11 21:03:50.186334
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
