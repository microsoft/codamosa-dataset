

# Generated at 2022-06-11 20:54:27.469261
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(0) == False



# Generated at 2022-06-11 20:54:29.970529
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    und = Exclude()
    assert und.NEVER(1) is True
    assert und.NEVER(2) is True
    assert und.NEVER(3) is True

# Generated at 2022-06-11 20:54:32.200346
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:54:33.355954
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    ret = Exclude.ALWAYS("test")
    assert ret == True

# Generated at 2022-06-11 20:54:41.232492
# Unit test for function config
def test_config():
    from marshmallow import fields, Schema
    from dataclasses import dataclass
    from typing import Type

    @config(letter_case=lambda s: s.upper())
    @dataclass
    class Data:
        x: int

    assert Data.__dataclass_json__.letter_case('foo') == 'FOO'

    @config(encoder=lambda o, _: str(o.x),
            decoder=lambda s, _: int(s))
    @dataclass
    class Data:
        x: int

    assert Data.__dataclass_json__.decoder('42') == 42
    assert Data.__dataclass_json__.encoder(Data(42)) == '42'


# Generated at 2022-06-11 20:54:46.264243
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Check it's always True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS({'a': 1, 'b': 2}) == True
    assert Exclude.ALWAYS(Exclude.ALWAYS) == True


# Generated at 2022-06-11 20:54:48.082800
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:54:50.963018
# Unit test for function config
def test_config():
    try:
        config(undefined='unknown')
    except UndefinedParameterError:
        pass
    else:
        assert False

# Generated at 2022-06-11 20:54:52.074222
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) is False

# Generated at 2022-06-11 20:54:54.240993
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))
    return Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:54:59.577541
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("anything") == True

# Generated at 2022-06-11 20:55:04.569007
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass(order=True)
    class Person:
        name: str
        age: int = field(metadata=config(exclude=Exclude.ALWAYS))

    p = Person("mikey", 32)
    assert json.dumps(p.__dict__, indent=2) == '{\n  "name": "mikey"\n}'


# Generated at 2022-06-11 20:55:05.835169
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-11 20:55:07.311732
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:55:09.336359
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class Class:
        pass

    assert Exclude.ALWAYS(Class)



# Generated at 2022-06-11 20:55:10.361990
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert True == Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:55:15.119290
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    immu = True
    len_1 = Exclude.NEVER([1])
    len_2 = Exclude.NEVER([1,2])
    len_3 = Exclude.NEVER([1,2,3])
    len_4 = Exclude.NEVER([1,2,3,4])
    len_5 = Exclude.NEVER([1,2,3,4,5])

    assert len_1 is False and len_2 is False and len_3 is False and len_4 is False and len_5 is False
    return immu


# Generated at 2022-06-11 20:55:16.325424
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('') == False


# Generated at 2022-06-11 20:55:19.482712
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER(123) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False



# Generated at 2022-06-11 20:55:30.572714
# Unit test for function config
def test_config():
    import dataclasses
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined

    @dataclasses.dataclass
    @config(encoder=lambda o: o.value)
    class Foo:
        value: int
        other_value: int

    assert global_config.encoders[Foo] is Foo.__dataclasses_json__.encoder

    @dataclasses.dataclass
    @config(encoder=lambda o: o.value, field_name="this_name")
    class Foo:
        value: int
        this_name: int

    assert global_config.encoders[Foo] is Foo.__dataclasses_json__.encoder


# Generated at 2022-06-11 20:55:36.580171
# Unit test for function config
def test_config():
    from dataclasses import dataclass, asdict

    @dataclass
    class Test:
        field: str = config(field_name="field")

    assert asdict(Test()) == {"field": None}

    assert Test("str").__dict__ == {"field": "str"}

    t = Test()
    t.field = "str"
    assert asdict(t) == {"field": "str"}

# Generated at 2022-06-11 20:55:47.088219
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS('A')
    assert Exclude.ALWAYS('hello world!')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS([False])
    assert Exclude.ALWAYS([True])
    assert Exclude.ALWAYS(['a'])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({'a': 'b'})

# Generated at 2022-06-11 20:55:50.726964
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER("foo") == False
    assert Exclude.NEVER([1,2,3]) == False
    print("Test method NEVER of class Exclude passed!")


# Generated at 2022-06-11 20:55:52.298958
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("ANYTHING")

# Generated at 2022-06-11 20:55:53.350335
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:02.074496
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Test when value is None
    assert Exclude.ALWAYS(None)
    # Test when value is boolean
    assert Exclude.ALWAYS(True)
    # Test when value is integer
    assert Exclude.ALWAYS(0)
    # Test when value is float
    assert Exclude.ALWAYS(0.0)
    # Test when value is string
    assert Exclude.ALWAYS("")
    # Test when value is a list
    assert Exclude.ALWAYS([])
    # Test when value is a dictionary
    assert Exclude.ALWAYS({})
    # Test when value is an object
    assert Exclude.ALWAYS(object())

# Test when value is None

# Generated at 2022-06-11 20:56:02.963457
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True

# Generated at 2022-06-11 20:56:04.408244
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:56:05.874518
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:07.330395
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-11 20:56:11.745980
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS


# Generated at 2022-06-11 20:56:21.732831
# Unit test for function config
def test_config():
    class TestClass:
        def __init__(self,
                     json_encoder=None,
                     json_decoder=None,
                     marshmallow_field=None,
                     letter_case=None):
            self.json_encoder = json_encoder
            self.json_decoder = json_decoder
            self.marshmallow_field = marshmallow_field
            self.letter_case = letter_case

    def encoder(config, value):
        return config.json_encoder(value)

    def decoder(config, value):
        return config.json_decoder(value)

    def mm_field(_, value):
        return "marshmallow_field_value"

    def letter_case(_, value):
        return value.upper()


# Generated at 2022-06-11 20:56:22.789724
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False

# Generated at 2022-06-11 20:56:25.448990
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude.NEVER
    assert obj('') == False
    assert obj('a') == False
    assert obj(1) == False
    assert obj(None) == False


# Generated at 2022-06-11 20:56:26.864658
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc") is False

# Generated at 2022-06-11 20:56:28.586930
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_data = 'string'
    assert Exclude.NEVER(test_data) == False

# Generated at 2022-06-11 20:56:31.930064
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    with pytest.raises(UndefinedParameterError):
        @dataclass
        @config(undefined="FOO")
        class Example:
            x: int

# Generated at 2022-06-11 20:56:33.395989
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    res = Exclude.ALWAYS("_a")
    assert res == True



# Generated at 2022-06-11 20:56:36.308027
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    data = {
        "a": 14,
        "b": 5,
        "c": True,
        "d": -2
    }
    assert data == Exclude.NEVER(data)


# Generated at 2022-06-11 20:56:37.824995
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    action = Exclude.NEVER(3)
    assert action


# Generated at 2022-06-11 20:56:48.013201
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:56:49.727341
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1))
    assert(Exclude.ALWAYS('Yolo'))


# Generated at 2022-06-11 20:56:51.414659
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = Exclude.ALWAYS(_=5)
    assert x == True


# Generated at 2022-06-11 20:56:54.991532
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == True
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(object) == False

# Generated at 2022-06-11 20:57:01.752086
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    """Tests the method ALWAYS of the class Exclude"""
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS(object()) is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS(2) is True
    assert Exclude.ALWAYS(1.0) is True
    assert Exclude.ALWAYS('foo') is True


# Generated at 2022-06-11 20:57:03.218904
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    n = Exclude.NEVER(1)
    assert n == False

# Generated at 2022-06-11 20:57:05.438545
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)


# Generated at 2022-06-11 20:57:07.047887
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None) == True)


# Generated at 2022-06-11 20:57:08.176080
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3)


# Generated at 2022-06-11 20:57:09.355551
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:26.089312
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():

    assert Exclude.ALWAYS('a') == True

# Generated at 2022-06-11 20:57:28.236681
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('str')
    assert Exclude.ALWAYS([1, 2, 3])


# Generated at 2022-06-11 20:57:29.247532
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-11 20:57:32.303746
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(Undefined) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:36.477906
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(None) != False


# Generated at 2022-06-11 20:57:37.750221
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('anything') == True


# Generated at 2022-06-11 20:57:39.727265
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def test_fun(x):
        return True
    assert Exclude.NEVER(test_fun) == False

# Generated at 2022-06-11 20:57:40.876228
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:57:42.144888
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") is False


# Generated at 2022-06-11 20:57:44.084831
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(0)
    assert a == False


# Generated at 2022-06-11 20:58:17.020197
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    with suppress(Exception):
        Exclude.NEVER(None)

# Generated at 2022-06-11 20:58:18.975583
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS("a") is True



# Generated at 2022-06-11 20:58:21.662640
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    #Unit test
    example = {'a':5,'b':4,'c':19}
    for k, v in example.items():
        print(k,v)


# Generated at 2022-06-11 20:58:23.383356
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:58:32.203867
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    from dataclasses_json.config import config
    from dataclasses_json.undefined import EXCLUDE

    @dataclass
    @config(exclude=Exclude.NEVER)
    class DataClass:
        a: str
        b: str = EXCLUDE

    dc = DataClass(a="Test a", b="Test b")
    assert dc.a == "Test a"
    assert dc.b == "Test b"

    json = dc.to_json()
    assert json == '{"a": "Test a", "b": "Test b"}'


# Generated at 2022-06-11 20:58:39.410768
# Unit test for function config
def test_config():
    from marshmallow import fields
    from dataclasses_json.config import config, Exclude
    import datetime
    import uuid

    @dataclass
    @config(encoder=uuid.uuid4,
            decoder=uuid.UUID,
            mm_field=fields.UUID(),
            letter_case=lambda s: s.upper(),
            undefined=Undefined.EXCLUDE,
            exclude=Exclude.ALWAYS,
            )
    class Example:
        name: str
        uuid: str

    assert Example.__config__["encoder"] == uuid.uuid4
    assert Example.__config__["decoder"] == uuid.UUID
    assert type(Example.__config__["mm_field"]) == fields.UUID
    assert Example.__config__["letter_case"]

# Generated at 2022-06-11 20:58:40.176308
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)

# Generated at 2022-06-11 20:58:41.217371
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    config()
    assert Exclude.ALWAYS("") == True


# Generated at 2022-06-11 20:58:42.683923
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")

# Generated at 2022-06-11 20:58:44.189863
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5)


# Generated at 2022-06-11 21:00:00.303360
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)



# Generated at 2022-06-11 21:00:04.033935
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    if Exclude.NEVER:
        print("FAILED")
    else:
        print("PASSED")


test_Exclude_NEVER()

# Generated at 2022-06-11 21:00:05.162834
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False


# Generated at 2022-06-11 21:00:07.568359
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_str = "Test String"
    assert Exclude.NEVER(test_str) is False


# Generated at 2022-06-11 21:00:12.831183
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('NON')
    assert not Exclude.NEVER('OUI')
    assert Exclude.NEVER(1)
    assert not Exclude.NEVER(None)
    assert Exclude.NEVER(())
    assert Exclude.NEVER([])



# Generated at 2022-06-11 21:00:17.295027
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS(Undefined) == True

#Unit test for method NEVER of class Exclude

# Generated at 2022-06-11 21:00:22.750427
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10)
    assert Exclude.NEVER(3)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(0.0)
    assert Exclude.NEVER([])
    assert Exclude.NEVER(['a'])
    assert Exclude.NEVER(('a', 'b'))
    assert Exclude.NEVER(('a', 'b', 'c'))
    assert Exclude.NEVER({})
    assert Exclude.NEVER({'a': 'a'})
    assert Exclude.NEVER({'a': 'b'})


# Generated at 2022-06-11 21:00:26.379344
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(True) == False
    # assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 21:00:28.578823
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(True)
    assert Exclude.NEVER(False)


# Generated at 2022-06-11 21:00:29.462010
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-11 21:03:18.038457
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) is True


# Generated at 2022-06-11 21:03:26.466436
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined

    @dataclass
    class TestClass:
        a: int
        b: str


    tc = TestClass(a=3, b='hello')

    '''
    ACTUAL OUTPUT:
    {'a': 3, 'b': 'hello'}

    EXPECTED OUTPUT:
    {'b': 'hello'}

    '''

    print(tc.b)
    print(tc.a)

    print(TestClass.__dict__['a'])
    print(TestClass.__dict__['b'])

    tc_dict = asdict(tc, undefined=Undefined.EXCLUDE, exclude=Exclude.NEVER)
    print(tc_dict)

# Generated at 2022-06-11 21:03:28.321396
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-11 21:03:29.298330
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-11 21:03:32.039144
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({'left': 0}) == True
    assert Exclude.ALWAYS({'left': 0}, right=1) == True



# Generated at 2022-06-11 21:03:35.968384
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER("not empty")
    assert Exclude.NEVER([])
    assert Exclude.NEVER({})
    assert Exclude.NEVER([1])
    assert Exclude.NEVER({1})


# Generated at 2022-06-11 21:03:38.183502
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-11 21:03:44.332129
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    instance = Exclude()
    assert instance.ALWAYS(True) == True
    assert instance.ALWAYS(False) == True
    assert instance.ALWAYS(None) == True
    assert instance.ALWAYS(0) == True
    assert instance.ALWAYS(10.3) == True
    assert instance.ALWAYS([1,2,3]) == True
    assert instance.ALWAYS({"name":"hugo","age":23}) == True


# Generated at 2022-06-11 21:03:45.058567
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)


# Generated at 2022-06-11 21:03:47.825025
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(False) is False
    assert Exclude.NEVER(None) is False
    assert Exclude.NEVER('true') is False
    assert Exclude.NEVER('false') is False
