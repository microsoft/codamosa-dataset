

# Generated at 2022-06-11 20:54:23.947013
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(2) == True)

# Generated at 2022-06-11 20:54:27.261430
# Unit test for function config
def test_config():
    @dataclass
    @config()
    class CDummyClass:
        a: int
        b: int

    CDummyClass.__dataclass_metadata__



# Generated at 2022-06-11 20:54:29.231419
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_str = 'test'
    expected = True
    actual = Exclude.ALWAYS(test_str)
    assert expected == actual


# Generated at 2022-06-11 20:54:32.002373
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('foo')
    assert Exclude.NEVER(42)
    assert Exclude.NEVER({'a': 'b'})

# Generated at 2022-06-11 20:54:33.154912
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False


# Generated at 2022-06-11 20:54:37.951100
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(0.5) is True
    assert Exclude.ALWAYS(0.0000005) is True
    assert Exclude.ALWAYS(object) is True
    assert Exclude.ALWAYS(Exclude.ALWAYS) is True



# Generated at 2022-06-11 20:54:40.751816
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(100) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('hello') == False

# Generated at 2022-06-11 20:54:41.977570
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER = lambda _: False


# Generated at 2022-06-11 20:54:46.049150
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test")
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1.5)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:54:47.092850
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:54:50.516240
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-11 20:54:52.390286
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(None)
    expected = True
    assert result == expected


# Generated at 2022-06-11 20:54:54.590392
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False and Exclude.NEVER(None) == False

# Generated at 2022-06-11 20:54:55.942186
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:54:57.241777
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:54:59.763309
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    my_field = Exclude.NEVER
    assert not my_field(False)
    

# Generated at 2022-06-11 20:55:01.374659
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert False == Exclude.NEVER(5)
    assert False == Exclude.NEVER(None)


# Generated at 2022-06-11 20:55:03.983659
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class A:
        a = 0
    # test 1
    assert Exclude.NEVER(A())
    a = A()
    a.a = 1
    # test 2
    assert Exclude.NEVER(a)

# Generated at 2022-06-11 20:55:08.427427
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import unittest
    class MyTest(unittest.TestCase):
        def test(self):
            f = Exclude.NEVER
            self.assertFalse(f("abc"))
    t = MyTest()
    t.test()


# Generated at 2022-06-11 20:55:10.007233
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("foo")
    assert Exclude.ALWAYS("bar")


# Generated at 2022-06-11 20:55:14.973159
# Unit test for function config
def test_config():
    assert config(field_name="name", letter_case=str.upper) == {
        'dataclasses_json': {
            'letter_case': lambda _: "name".upper()
        }
    }

# Generated at 2022-06-11 20:55:16.557802
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:55:27.176939
# Unit test for function config
def test_config():
    from marshmallow import fields
    from copy import copy

    dict_metadata = {}

    dict_metadata = config(dict_metadata, mm_field=fields.Decimal())
    assert dict_metadata == {'dataclasses_json': {'mm_field': fields.Decimal()}}

    dict_metadata = config(dict_metadata, encoder='test_encoder')
    assert dict_metadata == {'dataclasses_json': {'mm_field': fields.Decimal(),
                                                  'encoder': 'test_encoder'}}

    dict_metadata = config(dict_metadata, decoder='test_decoder')

# Generated at 2022-06-11 20:55:28.802348
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(2) is False


# Generated at 2022-06-11 20:55:30.617665
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:32.471151
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(42)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("test")
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-11 20:55:34.011044
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    
    T = TypeVar("T")

    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 20:55:35.644832
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-11 20:55:40.188277
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass

    @dataclass
    class A:
        x: int

    @config(exclude=Exclude.NEVER)
    @dataclass
    class B:
        x: int

    assert Exclude.NEVER(A) is False
    assert Exclude.NEVER(B) is False


# Generated at 2022-06-11 20:55:45.541296
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    from datetime import datetime
    @dataclass
    class A:
        a: int
        b: str

    assert Exclude.ALWAYS(int)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)

    a = A(a = 1, b = 'hello')
    assert Exclude.ALWAYS(a)
    assert Exclude.ALWAYS(A)


# Generated at 2022-06-11 20:55:48.362942
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:55:50.727601
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    d = {"a": 1, "b": 2}
    res = Exclude.NEVER(d)
    assert res == False



# Generated at 2022-06-11 20:55:53.579630
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})


# Generated at 2022-06-11 20:55:54.842028
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") == True



# Generated at 2022-06-11 20:55:56.428127
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-11 20:55:58.206039
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("x") == False

test_Exclude_NEVER()


# Generated at 2022-06-11 20:56:02.845563
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    @dataclass
    class Example:
        exclude: Exclude = Exclude.NEVER
    e = Example()
    assert not e.exclude(None)

# test_Exclude_NEVER()

# Generated at 2022-06-11 20:56:07.147888
# Unit test for function config
def test_config():
    import marshmallow as mm
    @dataclasses.dataclass
    class TestClass:
        x: str = dataclasses.field(metadata=config(exclude=Exclude.ALWAYS))
        y: str = dataclasses.field(metadata=config(mm_field=mm.fields.Integer()))


# Generated at 2022-06-11 20:56:08.467762
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER({})

test_Exclude_NEVER()

# Generated at 2022-06-11 20:56:11.283819
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10)
    assert Exclude.NEVER(20)
    assert Exclude.NEVER(30)
    assert Exclude.NEVER(40)
    assert Exclude.NEVER(50)


# Generated at 2022-06-11 20:56:14.021347
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:56:18.412171
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    error_msg = "Unit test for method ALWAYS of class Exclude failed"
    assert Exclude.ALWAYS(0), error_msg
    assert Exclude.ALWAYS(False), error_msg
    assert Exclude.ALWAYS([]), error_msg
    assert Exclude.ALWAYS({}), error_msg



# Generated at 2022-06-11 20:56:23.356684
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0.1)
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(None)

#Unit test for method NEVER of class Exclude

# Generated at 2022-06-11 20:56:26.564509
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS((1,2,3))
    assert Exclude.ALWAYS({})
    assert not Exclude.ALWAYS(0)


# Generated at 2022-06-11 20:56:32.014352
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(3.2) == True


# Generated at 2022-06-11 20:56:33.174561
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")


# Generated at 2022-06-11 20:56:38.341232
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Nothing gets excluded
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS("name")
    assert Exclude.ALWAYS([1,2,3])
    assert Exclude.ALWAYS({'key': 'value'})
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-11 20:56:39.606055
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:56:41.898033
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    expected = False
    value = "value"
    # Act
    actual = Exclude.NEVER(value)
    # Assert
    assert actual == expected



# Generated at 2022-06-11 20:56:43.914231
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert bool(Exclude.ALWAYS(True))
    assert not bool(Exclude.ALWAYS(False))

# Generated at 2022-06-11 20:56:48.767880
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("some_text")



# Generated at 2022-06-11 20:56:51.549810
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False)
    assert Exclude.NEVER('abc')
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(2)

# Generated at 2022-06-11 20:56:52.824983
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('anything')
    return True

# Generated at 2022-06-11 20:56:58.065248
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    @config(exclude=Exclude.NEVER)
    class Data:
        name: str
        value: int

    data = Data("myname", 12)
    assert DataclassJSONMixin.to_json(data) == '{"name":"myname","value":12}'



# Generated at 2022-06-11 20:57:00.132456
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True


# Generated at 2022-06-11 20:57:04.386645
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    foo = Exclude.ALWAYS(1)
    assert foo == True
    foo = Exclude.ALWAYS(0)
    assert foo == True
    foo = Exclude.ALWAYS(0.0)
    assert foo == True
    foo = Exclude.ALWAYS(True)
    assert foo == True



# Generated at 2022-06-11 20:57:10.320938
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0.234) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS([1,2,3]) == True
    assert Exclude.ALWAYS((1,2,3)) == True


# Generated at 2022-06-11 20:57:11.318346
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)


# Generated at 2022-06-11 20:57:14.575990
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("testing") == False


# Generated at 2022-06-11 20:57:20.109626
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(3.1415)
    assert Exclude.NEVER([1,2,3])
    assert Exclude.NEVER((1,2,3))
    assert Exclude.NEVER({1,2})


# Generated at 2022-06-11 20:57:27.907770
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # zero param should be ignored
    assert Exclude.ALWAYS(0) is True
    # one param should be ignored
    assert Exclude.ALWAYS(1) is True



# Generated at 2022-06-11 20:57:29.394440
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

test_Exclude_NEVER()

# Generated at 2022-06-11 20:57:31.033151
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 20:57:34.814722
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    NEVER = Exclude.NEVER
    assert NEVER('foo') is False
    assert NEVER(None) is False
    assert NEVER(type) is False
    assert NEVER(Exclude.ALWAYS) is False
    assert NEVER(Exclude.NEVER) is False


# Generated at 2022-06-11 20:57:36.183763
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    

# Generated at 2022-06-11 20:57:37.828250
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(1) == True

#Unit test for method NEVER of class Exclude

# Generated at 2022-06-11 20:57:41.032421
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class myValue:
        value = 1
    obj = myValue()
    assert(Exclude.NEVER(obj) == False)
    obj.value = 2
    assert(Exclude.NEVER(obj) == False)


# Generated at 2022-06-11 20:57:50.843898
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(3.14)
    assert Exclude.ALWAYS(['mango', 'banana', 'grapes'])
    assert Exclude.ALWAYS([4, 7, 10])
    assert Exclude.ALWAYS(range(10))
    assert Exclude.ALWAYS({'a', 'b', 'c'})
    assert Exclude.ALWAYS({'age': 20, 'name': 'jack'})
    assert Exclude.ALWAYS({4, 5, 6})
    assert Exclude.ALWAYS({1: 'a', 2: 'b'})
    assert Exclude.ALWAYS('fruit')
    assert Exclude.ALWAYS('')

# Generated at 2022-06-11 20:57:52.704536
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:57:53.956250
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))



# Generated at 2022-06-11 20:58:18.851243
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    dct = dict([[1, 2], [3, 4]])
    f_NEVER = Exclude.NEVER

    assert f_NEVER(dct) == False
    assert f_NEVER(dct[1]) == False
    assert f_NEVER(dct[1][1]) == False
    

# Generated at 2022-06-11 20:58:20.709206
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('anything')



# Generated at 2022-06-11 20:58:21.767200
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('always') == True


# Generated at 2022-06-11 20:58:25.006888
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(None) == False
    return True
    

# Generated at 2022-06-11 20:58:27.513090
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("_") == False
    assert Exclude.NEVER("5") == False
    assert Exclude.NEVER("abcd") == False


# Generated at 2022-06-11 20:58:30.661584
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-11 20:58:32.045091
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:58:32.890499
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("string") == False

# Generated at 2022-06-11 20:58:34.021876
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:58:35.098917
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('whatever')


# Generated at 2022-06-11 20:58:56.594694
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:58:57.691521
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    pass


# Generated at 2022-06-11 20:59:02.466742
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # When called on an instance of class Exclude
    # the result is a function that returns False regardless the input
    assert Exclude.NEVER("Some string") is False
    assert Exclude.NEVER(lambda x: x) is False
    assert Exclude.NEVER(Exclude) is False


# Generated at 2022-06-11 20:59:06.207183
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Create a class C
    class C:
        pass
    
    # Create an object c of class C
    c = C()
    # Verify that the output of method NEVER is False
    assert Exclude.NEVER(c) == False


# Generated at 2022-06-11 20:59:07.526724
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:59:09.710794
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    name = 'Hello World'
    # Check that that Exclude.NEVER returns false
    assert Exclude.NEVER(name) == False


# Generated at 2022-06-11 20:59:10.628950
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:59:11.622864
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:59:13.427885
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def NEVER(a):
        return False

    assert Exclude.NEVER(3) == NEVER(3)


# Generated at 2022-06-11 20:59:15.875709
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("test")
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 21:00:09.953572
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    global Exclude
    assert Exclude.NEVER(2)


# Generated at 2022-06-11 21:00:11.855601
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True


# Generated at 2022-06-11 21:00:13.006579
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-11 21:00:13.666624
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 21:00:15.585642
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("value") == False

# Generated at 2022-06-11 21:00:19.292517
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS([]) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS(3.14) is True
    assert Exclude.ALWAYS('test') is True


# Generated at 2022-06-11 21:00:21.242871
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("abc") == True


# Generated at 2022-06-11 21:00:23.422038
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def test(x: str) -> bool:
        return x == 's'
    assert Exclude.ALWAYS(test)


# Generated at 2022-06-11 21:00:24.355559
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER("trung")

# Generated at 2022-06-11 21:00:25.652427
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    _ = Exclude()
    assert _.ALWAYS("Hello")

# Generated at 2022-06-11 21:02:22.303450
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0.0)
    assert Exclude.ALWAYS(0.1)


# Generated at 2022-06-11 21:02:23.933817
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class MyClass:
        pass
    obj = MyClass()
    assert Exclude.NEVER(obj)

# Generated at 2022-06-11 21:02:26.771153
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1.1) == True
    assert Exclude.ALWAYS('test') == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-11 21:02:28.895635
# Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-11 21:02:32.730764
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    input_data = 'a string'
    output_data = Exclude.NEVER(input_data)
    assert output_data == False


# Generated at 2022-06-11 21:02:35.142834
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("test") == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False

# Generated at 2022-06-11 21:02:37.236592
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
   t = Exclude.NEVER(1)
   assert t == False


# Generated at 2022-06-11 21:02:38.725050
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-11 21:02:40.639672
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)


# Generated at 2022-06-11 21:02:42.742771
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field_name = 'field'
    obj = Exclude.NEVER(field_name)
    assert obj == False

