

# Generated at 2022-06-11 20:54:24.559085
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER(2)
    assert x == False
    return x


# Generated at 2022-06-11 20:54:29.318395
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.1)
    assert Exclude.ALWAYS('abc')
    assert Exclude.ALWAYS((1, 2, 3))
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS({'a': 1, 2: 'b'})

# Generated at 2022-06-11 20:54:32.722260
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False



# Generated at 2022-06-11 20:54:39.513440
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(test_Exclude_ALWAYS)
    assert Exclude.ALWAYS(global_config.encoders)
    assert Exclude.ALWAYS(global_config.mm_fields)
    assert Exclude.ALWAYS(global_config.decoders)
    assert Exclude.ALWAYS(Exclude.ALWAYS)


# Generated at 2022-06-11 20:54:44.515815
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert callable(Exclude.NEVER)
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER([1, 2, 3]) == False
    assert Exclude.NEVER({'A': 1, 'B': 2}) == False



# Generated at 2022-06-11 20:54:46.069991
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class Foo:
        bar = Exclude.ALWAYS
    assert bar(Foo)==True


# Generated at 2022-06-11 20:54:46.845449
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(Exclude()) == True

# Generated at 2022-06-11 20:54:47.909290
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(True))


# Generated at 2022-06-11 20:54:53.206737
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS('abc') == True


# Generated at 2022-06-11 20:54:57.196741
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("123") == False
    assert Exclude.NEVER([1, 2, 3]) == False
    assert Exclude.NEVER({"key": "value"}) == False



# Generated at 2022-06-11 20:55:01.330505
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS('Test') == True
    assert Exclude.ALWAYS(False) == True



# Generated at 2022-06-11 20:55:08.153805
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.undefined import Undefined
    from dataclasses_json.decoder import JSONDecoder
    from dataclasses_json.encoder import JSONEncoder

    @dataclass
    @config(encoder=JSONEncoder)
    class ConfigEncoder:
        a: int = 5

    @dataclass
    @config(decoder=JSONDecoder)
    class ConfigDecoder:
        a: int = 5

    @dataclass
    @config(mm_field=fields.String)
    class ConfigMmField:
        a: Optional[int] = 5

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class ConfigExclude:
        a: Optional[int] = 5



# Generated at 2022-06-11 20:55:09.809428
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') is False
    assert Exclude.NEVER('a') is False


# Generated at 2022-06-11 20:55:10.838586
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('A') == True



# Generated at 2022-06-11 20:55:11.846693
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(0)
    assert a == False


# Generated at 2022-06-11 20:55:12.682710
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 20:55:13.724882
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  print(Exclude.ALWAYS('hello'))


# Generated at 2022-06-11 20:55:14.628407
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(100) == True
    return


# Generated at 2022-06-11 20:55:15.893412
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:55:18.068545
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class F:
        f = 1

    assert Exclude.NEVER(F())



# Generated at 2022-06-11 20:55:23.162143
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    if Exclude.NEVER(0) == True:
        print('test_Exclude_NEVER() passed')
    else:
        print('test_Exclude_NEVER() failed')


# Generated at 2022-06-11 20:55:24.800843
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:34.637377
# Unit test for function config
def test_config():

    from marshmallow.fields import Email, Field
    class MyMmField(Field):
        def _serialize(self, value, attr, obj, **kwargs):
            # type: (str, str, Any, **Any) -> Dict[str, Any]
            return {attr: value}

        def _deserialize(self, value, attr, data, **kwargs):
            # type: (str, str, Dict[str, Any], **Any) -> Dict[str, Any]
            return {attr: value}

    def some_callback(x):
        return x

    # Test metadata

# Generated at 2022-06-11 20:55:35.748917
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("foo")


# Generated at 2022-06-11 20:55:38.163337
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-11 20:55:39.364715
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('string') == True

# Generated at 2022-06-11 20:55:40.365798
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-11 20:55:42.456462
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # When:
    output = Exclude.ALWAYS('test')

    # Then:
    assert output



# Generated at 2022-06-11 20:55:43.835334
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('str') == False


# Generated at 2022-06-11 20:55:44.975987
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10) == False

# Generated at 2022-06-11 20:55:49.351654
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True

# Generated at 2022-06-11 20:55:50.727206
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:55:53.100779
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('abc')
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(['a', 'b', 'c'])


# Generated at 2022-06-11 20:55:56.185731
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(object())
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS(Exclude.ALWAYS)

# Generated at 2022-06-11 20:56:05.602164
# Unit test for function config
def test_config():
    import pytest

    @dataclasses.dataclass
    class HasConfig:
        a: str = dataclasses.field(metadata=config(mm_field='a'))

        @classmethod
        def get_json_meta(cls):
            return dataclasses.fields(cls)['a'].metadata['dataclasses_json']

    t = HasConfig()
    assert t.get_json_meta()['mm_field'] == 'a'


    with pytest.raises(UndefinedParameterError):
        dataclasses.dataclass(
            metadata=config(undefined='bad')
        )(str)

# Generated at 2022-06-11 20:56:06.716408
# Unit test for function config
def test_config():
    config(encoder=lambda obj: obj.__str__(), mm_field="bla")

# Generated at 2022-06-11 20:56:08.206750
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True


# Generated at 2022-06-11 20:56:10.109458
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(123) == False

# Generated at 2022-06-11 20:56:11.251764
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-11 20:56:12.508980
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
   assert Exclude.ALWAYS("a") == True


# Generated at 2022-06-11 20:56:19.389125
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("some string") == True
    assert Exclude.ALWAYS(Exclude) == True


# Generated at 2022-06-11 20:56:20.688735
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:56:23.156719
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({"foo": "bar"})
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:56:24.920361
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True

# Generated at 2022-06-11 20:56:31.475833
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("twas brillig, and the slithy toves")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({"": "jaba"})


# Generated at 2022-06-11 20:56:32.752855
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-11 20:56:34.513270
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:56:42.820585
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(4)
    assert Exclude.ALWAYS("this_is_a_string")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(9.5)
    assert Exclude.ALWAYS([1,2,3,4])
    assert Exclude.ALWAYS((1,2,3,4))
    assert Exclude.ALWAYS([[1,2],[3,4]])
    assert Exclude.ALWAYS(([1,2],[3,4]))
    assert Exclude.ALWAYS({"a":1})
    assert Exclude.ALWAYS({"a":1, "b":2})
    assert Exclude.ALWAYS({"a":1, "b":"hello"})

# Generated at 2022-06-11 20:56:44.241891
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:49.822067
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS("hi")
    assert Exclude.ALWAYS("")


# Generated at 2022-06-11 20:57:00.525230
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS('a'))


# Generated at 2022-06-11 20:57:03.510177
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	if NEVER("hello") != False:
		raise ValueError("Exclude.NEVER(_) incorrectly returns true")


# Generated at 2022-06-11 20:57:06.929900
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(1) == False)
    assert(Exclude.NEVER(0) == False)
    assert(Exclude.NEVER("asdf") == False)

# Generated at 2022-06-11 20:57:09.355257
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Test a symbolic value
    result = Exclude.NEVER(True)
    assert result == False
    # Test a real value
    result = Exclude.NEVER(None)
    assert result == False

# Generated at 2022-06-11 20:57:10.152661
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER('a')==False

# Generated at 2022-06-11 20:57:12.696898
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(3.14) == False
    assert Exclude.NEVER('abc') == False
    assert Exclude.NEVER([1, 2, 3]) == False


# Generated at 2022-06-11 20:57:14.043625
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) is True

# Generated at 2022-06-11 20:57:15.361717
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("hello")


# Generated at 2022-06-11 20:57:23.192463
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS is Exclude.ALWAYS
    assert Exclude.ALWAYS is not None
    assert Exclude.ALWAYS is not 1
    assert Exclude.ALWAYS is not True
    assert Exclude.ALWAYS is Exclude.ALWAYS(1)
    assert Exclude.ALWAYS is Exclude.ALWAYS("2")
    assert Exclude.ALWAYS is Exclude.ALWAYS([1,2])
    assert Exclude.ALWAYS is Exclude.ALWAYS({"a":"b"})


# Generated at 2022-06-11 20:57:26.370911
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER("")
    Exclude.NEVER("a")
    Exclude.NEVER("a" * 200)


# Generated at 2022-06-11 20:57:46.619179
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert (Exclude.NEVER("yes") == False)
    assert (Exclude.NEVER("no") == False)
    assert (Exclude.NEVER("") == False)
    assert (Exclude.NEVER(" ") == False)


# Generated at 2022-06-11 20:57:48.312318
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:57:50.773529
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude()
    assert x.NEVER(1) == False
    assert x.NEVER(2) == False
    assert x.NEVER(3) == False


# Generated at 2022-06-11 20:57:54.945998
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    if (Exclude.NEVER(False)):
        raise AssertionError
    if (Exclude.NEVER(True)):
        raise AssertionError
    if (Exclude.NEVER(None)):
        raise AssertionError


# Generated at 2022-06-11 20:57:56.794214
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('hello')

# Generated at 2022-06-11 20:57:58.574750
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    res = Exclude.NEVER(0)
    assert res == False, f"Expected False, got {res}"

# Generated at 2022-06-11 20:57:59.753900
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(9) == False


# Generated at 2022-06-11 20:58:01.210241
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:58:06.260992
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(1e-5)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('hello')
    assert Exclude.ALWAYS([1,2,3])
    assert Exclude.ALWAYS((1,2,3))
    assert Exclude.ALWAYS({'hello': 'world'})
    assert Exclude.ALWAYS({1,2,3})
    assert Exclude.ALWAYS(set())
    assert Exclude.ALWAYS(dict())


# Generated at 2022-06-11 20:58:07.792374
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    rc = Exclude.NEVER(1)
    assert rc == False


# Generated at 2022-06-11 20:58:43.427425
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(bool)
    assert Exclude.NEVER(int)
    assert Exclude.NEVER('abc')
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(Exclude.NEVER)


# Generated at 2022-06-11 20:58:44.957215
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False



# Generated at 2022-06-11 20:58:47.386376
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-11 20:58:47.977024
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")


# Generated at 2022-06-11 20:58:49.394512
# Unit test for method NEVER of class Exclude

# Generated at 2022-06-11 20:58:52.085072
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("0") == True
    assert Exclude.ALWAYS("1") == True


# Generated at 2022-06-11 20:58:53.421314
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False

# Generated at 2022-06-11 20:58:55.063681
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") is True


# Generated at 2022-06-11 20:58:57.733035
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("string") == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-11 20:59:01.061348
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    
    class Foo(object):
        def __init__(self):
            self.a = False

    a = Foo()
    assert Exclude.NEVER(a)


# Generated at 2022-06-11 21:00:23.422569
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("A") is False


# Generated at 2022-06-11 21:00:24.702594
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True


# Generated at 2022-06-11 21:00:26.204614
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 21:00:28.791432
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert callable(Exclude.ALWAYS)
    for arg in [True, False, 0, 1, "", "hey!", "hi\n", b"", b"hey!", b"hi\n"]:
        assert Exclude.ALWAYS(arg)


# Generated at 2022-06-11 21:00:30.146415
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert True == Exclude.NEVER(1)


# Generated at 2022-06-11 21:00:31.497135
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(None)
    assert result == True

# Generated at 2022-06-11 21:00:33.037573
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 21:00:35.860693
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(False) == True
	assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-11 21:00:37.615830
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER(): 
    exclude_tester = Exclude.NEVER
    print(exclude_tester)
    assert exclude_tester(True) == False

# Generated at 2022-06-11 21:00:39.730150
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("test_Exclude_ALWAYS: ", Exclude.ALWAYS(5))


# Generated at 2022-06-11 21:03:42.060856
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(-5) == False
    assert Exclude.NEVER([1,2]) == False


# Generated at 2022-06-11 21:03:43.895190
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER("something") is False)

test_Exclude_NEVER()

# Generated at 2022-06-11 21:03:44.893438
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("qwerty") is False


# Generated at 2022-06-11 21:03:45.975134
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
   assert Exclude.NEVER(4) == False


# Generated at 2022-06-11 21:03:51.592281
# Unit test for function config
def test_config():
    # Test to check that undefined parameter errors are raised with
    # undefined names that are not valid.
    with pytest.raises(UndefinedParameterError) as exc_info:
        @config(undefined="invalid")
        class MyClass:
            pass

    # Test to check that the undefined parameter error message works.
    with pytest.raises(UndefinedParameterError) as exc_info:
        @config(undefined="invalid")
        class MyClass:
            pass

    assert exc_info.value.args[0].startswith(
        "Invalid undefined parameter action, ") is True
    assert 'must be one of' in exc_info.value.args[0] is True
    assert 'RAISE' in exc_info.value.args[0] is True
    assert 'DISCARD' in exc_info.value

# Generated at 2022-06-11 21:03:54.662303
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('b') == False


# Generated at 2022-06-11 21:03:55.571818
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 21:04:00.086136
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(42)
    assert Exclude.ALWAYS('str')
    assert Exclude.ALWAYS(2.2)


# Generated at 2022-06-11 21:04:10.637854
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False, "Test for method NEVER was a fail"
    assert Exclude.NEVER(" ") == False, "Test for method NEVER was a fail"
    assert Exclude.NEVER("  ") == False, "Test for method NEVER was a fail"
    assert Exclude.NEVER("   ") == False, "Test for method NEVER was a fail"
    assert Exclude.NEVER("a") == False, "Test for method NEVER was a fail"
    assert Exclude.NEVER("ab") == False, "Test for method NEVER was a fail"
    assert Exclude.NEVER("abc") == False, "Test for method NEVER was a fail"
    assert Exclude.NEVER("abcd") == False, "Test for method NEVER was a fail"

# Generated at 2022-06-11 21:04:12.167822
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field = Exclude.NEVER
    value = field('value')
    assert value == Exclude.NEVER('value')
