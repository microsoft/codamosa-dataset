

# Generated at 2022-06-11 20:54:20.796097
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS("foo") == True


# Generated at 2022-06-11 20:54:32.246518
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow as mm
    import pytest
    
    @config(field_name='name',
            letter_case=lambda s: s.title(),
            undefined=Undefined.EXCLUDE,
            exclude=Exclude.ALWAYS)
    @dataclasses.dataclass
    class Test:
        name: str
        age: int
        
    assert Test(name='John', age=15)._dc_asdict() == {'name': 'John'}
    
    mm_field = mm.fields.String(attribute='name')
    @config(letter_case=lambda s: s.title(),
            mm_field=mm_field)
    @dataclasses.dataclass
    class Test:
        name: str
        age: int
        

# Generated at 2022-06-11 20:54:33.433599
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(4)


# Generated at 2022-06-11 20:54:36.702776
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    if not Exclude.ALWAYS(None):
        return False
    if not Exclude.ALWAYS(None, None):
        return False
    if not Exclude.ALWAYS(1, 2, 3):
        return False
    return True


# Generated at 2022-06-11 20:54:42.757326
# Unit test for function config
def test_config():

    @dataclass
    class Test:
        name: str
        age: int = field(default=None, metadata=config(undefined=Undefined.EXCLUDE))

    @dataclass
    class Test2:
        name: str
        age: int = field(default=None, metadata=config(undefined=0))

    @dataclass
    class Test3:
        name: str
        age: int = field(default=None, metadata=config(undefined="raise"))

    @dataclass
    class Test4:
        name: str
        age: int = field(default=None, metadata=config(undefined="Return"))

    @dataclass
    class Test5:
        name: str
        age: int = field(default=None, metadata=config(undefined="default"))


# Generated at 2022-06-11 20:54:44.823327
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude().ALWAYS == Exclude.ALWAYS


# Generated at 2022-06-11 20:54:45.921368
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(True))   # prints False



# Generated at 2022-06-11 20:54:47.910541
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # METHOD UNDER TEST IS NEVER
    # By design, method NEVER always returns False.
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:54:51.643049
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert callable(Exclude.NEVER)
    assert not Exclude.NEVER(None)
    assert not Exclude.NEVER(123)
    assert not Exclude.NEVER("abc")


# Generated at 2022-06-11 20:54:53.804112
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.ALWAYS(2)
    assert Exclude.NEVER(2) == False

# Generated at 2022-06-11 20:54:56.626237
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    return Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:05.949159
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    import marshmallow as ma
    from marshmallow.fields import Field as MMField

    from dataclasses_json.config import config

    @config(encoder=lambda x: f'E{x}', decoder=lambda x: x.strip('E'),
            mm_field=MMField(missing='default'),
            field_name=lambda default, letter_case: '_'.join(letter_case(word)
                                                             for word in default.split('_')),
            letter_case=lambda s: s[::-1],
            undefined=lambda d, tp: tp.type(d),
            exclude=lambda d, tp: d == 'exclude',
            )
    @dataclass
    class MyDataClass:
        foo: float

# Generated at 2022-06-11 20:55:08.988369
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(2)
    assert not Exclude.NEVER(0)

# Generated at 2022-06-11 20:55:09.713380
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('ANYTHING') is False

# Generated at 2022-06-11 20:55:10.773759
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 20:55:12.093327
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    global_config.encoders = {int:str}
    assert Exclude.NEVER(int) == False

# Generated at 2022-06-11 20:55:15.220373
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS('foo') == True)
    assert(Exclude.ALWAYS(None) == True)
    assert(Exclude.ALWAYS(0) == True)


# Generated at 2022-06-11 20:55:19.641601
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") is True
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS(0) is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True
    # Object is not None
    class Obj:
        pass
    obj = Obj()
    assert Exclude.ALWAYS(obj) is True


# Generated at 2022-06-11 20:55:21.390324
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:55:22.814314
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(2)


# Generated at 2022-06-11 20:55:28.947819
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Data for the test
    test_case = Exclude()
    field_name = 'name'
    field_type = str

    # Method
    result = test_case.NEVER(field_type)

    # Test
    assert result == False

# Generated at 2022-06-11 20:55:29.821182
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True



# Generated at 2022-06-11 20:55:30.691298
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1))


# Generated at 2022-06-11 20:55:32.362632
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
# Creating dataclass object
 obj = Exclude()
 result = obj.NEVER("sushant")
 assert result == False

# Generated at 2022-06-11 20:55:33.571880
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-11 20:55:35.086943
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test') is True


# Generated at 2022-06-11 20:55:36.170022
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('any value') == False


# Generated at 2022-06-11 20:55:37.577405
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False



# Generated at 2022-06-11 20:55:38.543950
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def a():
        return False


# Generated at 2022-06-11 20:55:40.051882
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 20:55:47.809035
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("dummy") is True


# Generated at 2022-06-11 20:55:57.264568
# Unit test for function config
def test_config():
    # Basic test
    metadata = config(encoder=str)
    assert metadata['dataclasses_json']['encoder'] == str

    # Test that the encoder is not stored when it's the same as the default
    metadata = config()
    assert 'encoder' not in metadata['dataclasses_json']

    # Test that letter_case is transformed if it's a string
    metadata = config(letter_case='snake')
    assert metadata['dataclasses_json']['letter_case'] == 'snake_case'

    # Test that it raises an error for an invalid letter_case
    with pytest.raises(UndefinedParameterError):
        metadata = config(letter_case='invalid')

    # Test that a field name is transformed with reCAPTCHA
    metadata = config(field_name='my_field')


# Generated at 2022-06-11 20:55:59.251562
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-11 20:56:01.058274
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:56:09.855194
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(0) == True
	assert Exclude.ALWAYS(1) == True
	assert Exclude.ALWAYS(100) == True
	assert Exclude.ALWAYS(None) == True
	assert Exclude.ALWAYS("") == True
	assert Exclude.ALWAYS("Tuple") == True
	assert Exclude.ALWAYS("Set") == True
	assert Exclude.ALWAYS("List") == True
	assert Exclude.ALWAYS("Dict") == True
	assert Exclude.ALWAYS("String") == True
	assert Exclude.ALWAYS("Boolean") == True
	assert Exclude.ALWAYS("Integer") == True
	assert Exclude.ALWAYS("Float") == True
	assert Exclude.ALWAYS("Complex") == True
	assert Exclude.ALWAYS("Class") == True
	

# Generated at 2022-06-11 20:56:12.718822
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_Exclude_NEVER_result = Exclude.NEVER(1)
    if test_Exclude_NEVER_result == False:
        print('Exclude.NEVER(1) passed')
    else:
        print('Exclude.NEVER(1) failed')


# Generated at 2022-06-11 20:56:14.312816
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(42) is True


# Generated at 2022-06-11 20:56:24.273263
# Unit test for function config
def test_config():
    import pytest

    @dataclass
    class TestClass:
        var: str
        var2: str

    tc = TestClass(var="testvar", var2="testvar2")  # type: ignore

    test_config = config(metadata = None,
                         encoder = None,
                         decoder = None,
                         mm_field = None,
                         letter_case = None,
                         undefined = None,
                         field_name = "test_fieldname",
                         exclude = Exclude.ALWAYS)


# Generated at 2022-06-11 20:56:26.397548
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-11 20:56:27.429467
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS([])



# Generated at 2022-06-11 20:56:46.392821
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude
    assert(x.NEVER(3) == False)


# Generated at 2022-06-11 20:56:50.553827
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    T1 = TypeVar("T1")
    def ALWAYS(T1: TypeVar("T1"), p: T1):
        return True
    assert Exclude.ALWAYS('AAAA')
    assert ALWAYS('AAAA')
    
    

# Generated at 2022-06-11 20:56:51.504054
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS is True


# Generated at 2022-06-11 20:56:56.204993
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass
    class Example:
        field: int

    config = {
        'exclude': Exclude.ALWAYS
    }
    encoded_data = Example(field=3).to_json()

    assert(encoded_data == '{}')


# Generated at 2022-06-11 20:56:57.539945
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-11 20:57:08.354669
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER([1, 2]) == False
    assert Exclude.NEVER((1, 2)) == False
    assert Exclude.NEVER({1, 2}) == False
    assert Exclude.NEVER({1: 1, 2: 2}) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER(('a', 'b')) == False
    assert Exclude.NEVER({'a', 'b'}) == False
    assert Exclude.NEVER({'a': 'a', 'b': 'b'})

# Generated at 2022-06-11 20:57:09.542864
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True



# Generated at 2022-06-11 20:57:11.435205
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True


# Generated at 2022-06-11 20:57:15.921048
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined

    @dataclass
    class TestConfig:
        a: str = config(undefined=Undefined.RAISE)
        b: str

    assert TestConfig(b='b').a == 'a'

# test_config()

# Generated at 2022-06-11 20:57:18.044020
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:57:46.213680
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('abc')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({1: 'a'})


# Generated at 2022-06-11 20:57:49.028240
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

    assert Exclude.NEVER("a") == False

    assert Exclude.NEVER([]) == False


# Generated at 2022-06-11 20:57:50.170623
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)


# Generated at 2022-06-11 20:57:52.666320
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:57:53.586081
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER(20)

# Generated at 2022-06-11 20:57:55.038151
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hello") == True

# Generated at 2022-06-11 20:57:57.457918
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('should be ignored value') == True


# Generated at 2022-06-11 20:57:58.973722
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS('test')
    expected = True
    assert result == expected


# Generated at 2022-06-11 20:58:00.164470
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-11 20:58:01.209588
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False

# Generated at 2022-06-11 20:58:51.169842
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('h') == True


# Generated at 2022-06-11 20:59:02.356637
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    import json
    from marshmallow import Schema, fields

    class Field(fields.Field):
        pass

    @dataclass
    class Config:
        name: str
        a_field: str = field(metadata=config(mm_field=Field()))
        b_field: str = field(metadata=config(encoder=str.upper,
                                             decoder=str.lower))
        z_field: int = field(metadata=config(undefined=Undefined.EXCLUDE))

    schema = Schema()
    assert isinstance(schema.fields["name"], Field)
    assert isinstance(schema.fields["a_field"], Field)
    assert isinstance(schema.fields["b_field"], Field)

# Generated at 2022-06-11 20:59:06.108372
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS([1, 2, 3]) is True
    assert Exclude.ALWAYS('') is True
    assert Exclude.ALWAYS(()) is True
    assert Exclude.ALWAYS([]) is True



# Generated at 2022-06-11 20:59:08.979723
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('hello') == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(Exclude.NEVER) == False


# Generated at 2022-06-11 20:59:09.636388
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)


# Generated at 2022-06-11 20:59:13.283054
# Unit test for function config
def test_config():
    @dataclasses.dataclass
    class SomeClass:
        a: int = 42
        b: int = dataclasses.field(metadata=config(exclude=Exclude.ALWAYS))

    sc = SomeClass()
    assert sc.b == 42
    dc = dataclasses.asdict(sc)
    assert 'b' not in dc

# Generated at 2022-06-11 20:59:14.365031
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    assert result



# Generated at 2022-06-11 20:59:15.875522
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("Test")


# Generated at 2022-06-11 20:59:21.870507
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS('0') == True
    assert Exclude.ALWAYS(' ') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([0, 1, 3]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({'A': 1}) == True
    assert Exclude.ALWAYS(set()) == True
    assert Exclude.ALWAYS(set([0, 1, 3])) == True
    assert Exclude.ALWAYS(tuple()) == True
    assert Exclude

# Generated at 2022-06-11 20:59:23.206613
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Class:
        pass

    assert Exclude.NEVER(Class()) == False



# Generated at 2022-06-11 21:01:27.937496
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None), "Never is used to always return False"


# Generated at 2022-06-11 21:01:28.732725
# Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-11 21:01:30.545656
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("1")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(["a", 1])


# Generated at 2022-06-11 21:01:32.674083
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Setup
    item = 1

    # Exercise
    is_excluded = Exclude.NEVER(item)

    # Verify
    assert not is_excluded



# Generated at 2022-06-11 21:01:34.000895
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)



# Generated at 2022-06-11 21:01:35.175074
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    global dataclass
    assert Exclude.NEVER("X")

# Generated at 2022-06-11 21:01:37.754605
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True)  == Exclude.ALWAYS(False) == True


# Generated at 2022-06-11 21:01:39.216003
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc") == False


# Generated at 2022-06-11 21:01:40.810526
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest

    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False



# Generated at 2022-06-11 21:01:41.859758
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    a = Exclude.ALWAYS
    print(a('test'))