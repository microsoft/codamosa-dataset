

# Generated at 2022-06-11 20:54:25.453693
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(42)


# Generated at 2022-06-11 20:54:32.246208
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(10)
    assert Exclude.ALWAYS(10.)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS(set())
    assert Exclude.ALWAYS(exclude)

# Generated at 2022-06-11 20:54:35.842361
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(True)

# Generated at 2022-06-11 20:54:38.108902
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Testing method NEVER of class Exclude, expecting False")
    assert (Exclude.NEVER(True) == False)


# Generated at 2022-06-11 20:54:41.168630
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(None)
    assert Exclude.NEVER("Hello")
    assert Exclude.NEVER("Hi")


# Generated at 2022-06-11 20:54:49.572870
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER(3)
    b = Exclude.NEVER(3.0)
    c = Exclude.NEVER("test")
    d = Exclude.NEVER([3,2,1])
    e = Exclude.NEVER((3,2,1))
    f = Exclude.NEVER(set([1,2,3]))
    g = Exclude.NEVER({"a":1})

    assert(not a)
    assert(not b)
    assert(not c)
    assert(not d)
    assert(not e)
    assert(not f)
    assert(not g)


# Generated at 2022-06-11 20:54:50.961634
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    assert result == True


# Generated at 2022-06-11 20:54:54.846216
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('str') == False
    assert Exclude.NEVER(1.0) == False
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 20:54:57.685901
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(-1) == True


# Generated at 2022-06-11 20:55:00.289344
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    t = Exclude.NEVER(obj=1)
    if t != False:
        raise(Exception())



# Generated at 2022-06-11 20:55:03.180481
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:55:04.568668
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(object) == True


# Generated at 2022-06-11 20:55:05.516963
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:55:07.310985
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:55:08.987932
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('_x')


# Generated at 2022-06-11 20:55:10.838749
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(object())
    assert Exclude.ALWAYS(123)
    assert Exclude.ALWAYS('qwerty')


# Generated at 2022-06-11 20:55:18.635355
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test:
        arg: int

        def _json_encode(self) -> str:
            return 'foo'

        def _json_decode(cls, s: str) -> 'Test':
            return Test(int(s))

    assert config() == {'dataclasses_json': {}}

    assert config(encoder=Test._json_encode) == {
            'dataclasses_json': {
                'encoder': Test._json_encode
            }
        }

    assert config(decoder=Test._json_decode) == {
            'dataclasses_json': {
                'decoder': Test._json_decode
            }
        }

    import marshmallow

# Generated at 2022-06-11 20:55:19.855746
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:25.069185
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('abc')


# Generated at 2022-06-11 20:55:32.284384
# Unit test for function config
def test_config():
    # GIVEN
    class Foo:
        pass

    @config(exclude=Exclude.NEVER)
    class Bar:
        pass

    # WHEN
    foo_metadata = dataclasses.fields(Foo)[0].metadata['dataclasses_json']
    bar_metadata = dataclasses.fields(Bar)[0].metadata['dataclasses_json']

    # THEN
    assert foo_metadata['exclude'](None, None)
    assert not bar_metadata['exclude'](None, None)


# Generated at 2022-06-11 20:55:35.368340
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test') == True



# Generated at 2022-06-11 20:55:36.446076
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER(1)
    assert x == False


# Generated at 2022-06-11 20:55:47.245132
# Unit test for function config
def test_config():
    # Config without metadata
    assert config() == {'dataclasses_json': {}}

    # Config with metadata
    assert config(metadata={"name": "foo"}) == {
        'dataclasses_json': {},
        "name": "foo",
    }

    # Config with encoder
    def encoder(o):
        """This is an encoder"""
        pass
    assert config(encoder=encoder) == {
        'dataclasses_json': {
            "encoder": encoder,
        },
    }

    # Config with decoder
    def decoder(o):
        """This is a decoder"""
        pass
    assert config(decoder=decoder) == {
        'dataclasses_json': {
            "decoder": decoder,
        },
    }

    # Config

# Generated at 2022-06-11 20:55:52.510936
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(Exclude.NEVER) == False
    assert Exclude.NEVER(Exclude.ALWAYS) == False
    assert Exclude.NEVER(Exclude) == False



# Generated at 2022-06-11 20:55:53.251037
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('test') == False

# Generated at 2022-06-11 20:55:55.282436
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS(1)

    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('a') == True


# Generated at 2022-06-11 20:55:57.572549
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Test:
        pass
    test = Test()
    assert Exclude.NEVER(test) is False


# Generated at 2022-06-11 20:55:59.164535
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-11 20:56:03.475588
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) is False
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER('testing') is False
    assert Exclude.NEVER(None) is False
    assert Exclude.NEVER({}) is False

# Generated at 2022-06-11 20:56:11.381477
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(1.1) == False
    assert Exclude.NEVER(2.2) == False
    assert Exclude.NEVER('string') == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER('\n') == False
    assert Exclude.NEVER('\t') == False
    assert Exclude.NEVER('\b') == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(' ') == False


# Generated at 2022-06-11 20:56:15.319718
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    o = "test"
    assert Exclude.ALWAYS(o) == True


# Generated at 2022-06-11 20:56:25.107973
# Unit test for function config
def test_config():
    assert config(mm_field="my_mm_field") == {"dataclasses_json": {
        "mm_field": "my_mm_field"
    }}
    assert config(encoder="my_encoder") == {"dataclasses_json": {
        "encoder": "my_encoder"
    }}
    assert config(decoder="my_decoder") == {"dataclasses_json": {
        "decoder": "my_decoder"
    }}
    assert config(field_name="my_field_name") == {"dataclasses_json": {
        "letter_case": "my_field_name"
    }}
    assert config(undefined="error") == {"dataclasses_json": {
        "undefined": 0
    }}
    assert config(exclude=lambda f, v: True)

# Generated at 2022-06-11 20:56:26.821533
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') is True


# Generated at 2022-06-11 20:56:28.586524
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:56:31.201353
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:56:32.831331
# Unit test for function config
def test_config():
    # Assert that this function is parsed correctly
    assert config() == {'dataclasses_json': {}}

# Generated at 2022-06-11 20:56:36.864908
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None))
    assert(Exclude.ALWAYS(0))
    assert(Exclude.ALWAYS(""))
    assert(Exclude.ALWAYS(0.0))
    assert(Exclude.ALWAYS([]))
    assert(Exclude.ALWAYS({}))



# Generated at 2022-06-11 20:56:38.430344
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    

# Generated at 2022-06-11 20:56:39.686566
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-11 20:56:41.277241
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert isinstance(Exclude.ALWAYS, Callable)
    assert Exclude.ALWAYS(5)


# Generated at 2022-06-11 20:56:49.170551
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("abc") == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(-1) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:56:50.868210
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)



# Generated at 2022-06-11 20:56:52.122496
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("dummy_value")


# Generated at 2022-06-11 20:56:53.044175
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER("") == False

# Generated at 2022-06-11 20:56:58.340610
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)



# Generated at 2022-06-11 20:57:03.629906
# Unit test for function config
def test_config():
    @dataclass_json
    @config(field_name='my_field', exclude=Exclude.ALWAYS)
    class MyClass:
        my_field: str

    assert get_field_config(MyClass, 'my_field').name == 'my_field'
    assert get_field_config(MyClass, 'my_field').exclude(MyClass())

# Generated at 2022-06-11 20:57:05.909557
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None))


# Generated at 2022-06-11 20:57:07.205107
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
                                

# Generated at 2022-06-11 20:57:08.783598
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class Dummy:
        pass

    a = Dummy()

    assert Exclude.ALWAYS(a)


# Generated at 2022-06-11 20:57:09.945779
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:57:14.722020
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Given
    never = Exclude.NEVER
    a = 1
    # When
    result = never(a)
    # Then
    assert result is False


# Generated at 2022-06-11 20:57:18.165729
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER("")
    assert not Exclude.NEVER(0)
    assert not Exclude.NEVER(False)
    assert not Exclude.NEVER(None)


# Generated at 2022-06-11 20:57:20.061834
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hello") == True


# Generated at 2022-06-11 20:57:27.549569
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class TestExclude_ALWAYS:
        att1: int

    # Test for the exclude property
    assert TestExclude_ALWAYS.__dataclass_fields__['att1']._field.metadata['exclude'] == Exclude.ALWAYS

    # Test for the method 'property' of the field
    assert TestExclude_ALWAYS.__dataclass_fields__['att1']._field.property(1) == True
    assert TestExclude_ALWAYS.__dataclass_fields__['att1']._field.property("a") == True
    assert TestExclude_ALWAYS.__dataclass_fields__['att1']._field.property(TestExclude_ALWAYS) == True



# Generated at 2022-06-11 20:57:28.657842
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:57:29.973634
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    obj = Exclude.ALWAYS("")
    assert obj == True


# Generated at 2022-06-11 20:57:31.738203
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    always = Exclude.ALWAYS(1)
    assert always



# Generated at 2022-06-11 20:57:34.854347
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER("Test") == False
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 20:57:39.424957
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  # Test1:
  assert Exclude.NEVER('A') == False
  # Test2:
  assert Exclude.NEVER(54) == False
  # Test3:
  assert Exclude.NEVER([]) == False
  # Test4:
  assert Exclude.NEVER(True) == False



# Generated at 2022-06-11 20:57:40.594441
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(37)


# Generated at 2022-06-11 20:57:45.481152
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) is False
    assert Exclude.NEVER(False) is False
    assert Exclude.NEVER(object()) is False


# Generated at 2022-06-11 20:57:48.986533
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") is True
    assert Exclude.ALWAYS("") is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS(1234) is True


# Generated at 2022-06-11 20:57:50.737489
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("Unit test for method ALWAYS of class Exclude:", Exclude.ALWAYS("name"))
    # Output: True


# Generated at 2022-06-11 20:57:57.619286
# Unit test for function config
def test_config():
    config(undefined=Undefined.EXCLUDE)
    config(undefined='EXCLUDE')

    try:
        config(undefined='Unknown')
    except UndefinedParameterError as error:
        assert error.args[0] == "Invalid undefined parameter action, " \
                                "must be one of ['RAISE', 'STRICT', 'EXCLUDE', 'INCLUDE']"

# Generated at 2022-06-11 20:57:58.816208
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5)


# Generated at 2022-06-11 20:58:02.418269
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  print('test_Exclude_NEVER')
  assert Exclude.NEVER('a')
  assert Exclude.NEVER(10)
  assert Exclude.NEVER(None)
  assert Exclude.NEVER([])
  assert Exclude.NEVER({'a': 'b'})


# Generated at 2022-06-11 20:58:05.972860
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert callable(Exclude.NEVER), "NEVER is not callable"
    assert Exclude.NEVER(1), "NEVER must return a True value"


# Generated at 2022-06-11 20:58:06.976565
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    a = False
    assert not a


# Generated at 2022-06-11 20:58:10.659003
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude()
    assert x.NEVER(1) == False
    assert x.NEVER(0) == False
    assert x.NEVER(2) == False
    assert x.NEVER(27) == False
    assert x.NEVER(-1) == False
#

# Generated at 2022-06-11 20:58:11.775614
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:58:15.538779
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(42) == False


# Generated at 2022-06-11 20:58:16.757603
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('') is True


# Generated at 2022-06-11 20:58:17.652997
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:58:24.636273
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    class MySchema(Schema):
        a = fields.String()

    @dataclass
    class A:
        a: int
        b: str

    @config(encoder=lambda x: None,
            decoder=lambda x: None,
            mm_field=fields.String,
            field_name='c',
            letter_case=lambda x: x,
            undefined=Undefined.EXCLUDE,
            exclude=lambda x: True)
    class B(A):
        a: int
        b: str


# Generated at 2022-06-11 20:58:27.512821
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("whatever") == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True


# Generated at 2022-06-11 20:58:30.661209
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @dataclass
    class MyClass:
        a: int

    assert Exclude.ALWAYS(MyClass.a) is True



# Generated at 2022-06-11 20:58:31.935598
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("hello") == True
    assert Exclude.ALWAYS(3.14) == True



# Generated at 2022-06-11 20:58:33.090198
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a")


# Generated at 2022-06-11 20:58:34.210958
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == True


# Generated at 2022-06-11 20:58:35.947206
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER({})
    assert Exclude.NEVER('')
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(float(1))

# Generated at 2022-06-11 20:58:43.111737
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert Exclude.NEVER(1) == False
	assert Exclude.NEVER(0) == False
	assert Exclude.NEVER(1.1) == False
	assert Exclude.NEVER(0.0) == False
	assert Exclude.NEVER('abc') == False
	assert Exclude.NEVER([]) == False
	assert Exclude.NEVER({}) == False
	assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:58:44.287358
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER('my_data')

# Generated at 2022-06-11 20:58:53.570051
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test:
        x: int

    @dataclass
    class Subclass(Test):
        y: str

    class SubclassWithConfig(Test):
        y: str

        class Config:
            exclude = Exclude.ALWAYS

        def __init__(self, x, y):
            super().__init__(x)
            self.y = y

    def exclude_false(_: str, obj):
        return False

    assert Test.__dataclass_fields__['x'].metadata \
        == Subclass.__dataclass_fields__['x'].metadata
    assert Test.__dataclass_fields__['x'].metadata \
        == SubclassWithConfig.__dataclass_fields__['x'].metadata


# Generated at 2022-06-11 20:58:56.064793
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("some_string")
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(None)

# Generated at 2022-06-11 20:58:57.507996
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("hello") == False


# Generated at 2022-06-11 20:58:58.659836
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(0))

# Generated at 2022-06-11 20:59:00.595186
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("str") == False


# Generated at 2022-06-11 20:59:07.470659
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("Start test_Exclude_ALWAYS")
    class A():
        def __init__(self, a):
            self.a = a
    a_1 = A("Class A")
    print("exclude.ALWAYS of A: ", Exclude.ALWAYS(a_1)) # true
    class B:
        def __init__(self, a):
            self.a = a
    b_1 = B("Class B")
    print("exclude.ALWAYS of B: ", Exclude.ALWAYS(b_1)) # true


# Generated at 2022-06-11 20:59:08.686594
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:59:10.263556
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS('test') == True
	

# Generated at 2022-06-11 20:59:13.673458
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(4) == False

# Generated at 2022-06-11 20:59:14.982565
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:59:15.775039
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER('abc')


# Generated at 2022-06-11 20:59:16.817177
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 20:59:21.778893
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(123) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-123) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER([1, 2, 3]) == False
    assert Exclude.NEVER((1, 2, 3)) == False
    assert Exclude.NEVER({'a': 1, 'b': 2, 'c': 3}) == False
    assert Exclude.NEVER(Exclude.NEVER) == False
    assert Exclude.NEVER(Exclude.ALWAYS) == False



# Generated at 2022-06-11 20:59:23.420520
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)

# Generated at 2022-06-11 20:59:25.670370
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') is True


# Generated at 2022-06-11 20:59:27.499066
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    expected_return = True
    actual_return = Exclude.ALWAYS("")
    assert expected_return == actual_return


# Generated at 2022-06-11 20:59:27.947311
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-11 20:59:29.514842
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS('TEST')
    assert result == True


# Generated at 2022-06-11 20:59:35.431851
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("\nBegin testing method ALWAYS of class Exclude")
    import os
    from dataclasses import dataclass

    @dataclass
    class User:
        name: str
        age: int = 18

    user = User("John Doe", 19)

    assert(Exclude.ALWAYS(user))


# Generated at 2022-06-11 20:59:37.547003
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(Undefined)


# Generated at 2022-06-11 20:59:39.510253
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True


# Generated at 2022-06-11 20:59:41.057946
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True


# Generated at 2022-06-11 20:59:46.388535
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    res = Exclude.ALWAYS(1)
    assert res == True
    res = Exclude.ALWAYS(-1)
    assert res == True
    res = Exclude.ALWAYS(0.1)
    assert res == True
    res = Exclude.ALWAYS(0)
    assert res == True
    res = Exclude.ALWAYS(None)
    assert res == True
    res = Exclude.ALWAYS()
    assert res == True


# Generated at 2022-06-11 20:59:48.314116
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)



# Generated at 2022-06-11 20:59:52.709689
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True

if __name__ == '__main__':
    test_Exclude_ALWAYS()

# Generated at 2022-06-11 20:59:53.444986
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")


# Generated at 2022-06-11 20:59:57.076494
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-11 21:00:01.251353
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    @dataclass
    class TestClass:
        name: str = config(field_name='test_name')
    assert TestClass.__dataclass_fields__['name'].metadata == {
            'dataclasses_json': {'field_name': 'test_name'}}


# Generated at 2022-06-11 21:00:04.934550
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc") is False



# Generated at 2022-06-11 21:00:06.099079
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(9) == False

# Generated at 2022-06-11 21:00:10.322609
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(object())


# Generated at 2022-06-11 21:00:11.701301
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("abc")

# Generated at 2022-06-11 21:00:12.830637
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('Nothing') == False


# Generated at 2022-06-11 21:00:15.713840
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude()
    result = obj.NEVER("test")
    assert result == False


# Generated at 2022-06-11 21:00:17.949663
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-11 21:00:19.014686
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS( object() )


# Generated at 2022-06-11 21:00:20.783503
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    ret = Exclude.ALWAYS(1)
    assert ret == True


# Generated at 2022-06-11 21:00:29.026114
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(100)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(' ')
    assert Exclude.ALWAYS('s')
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS(())
    class A:
        def __init__(self, value: int):
            self.value = value
    assert Exclude.ALWAYS(A(0))
    assert Exclude.ALWAYS(A(1))


# Generated at 2022-06-11 21:00:36.330931
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    return


# Generated at 2022-06-11 21:00:37.201426
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False

# Generated at 2022-06-11 21:00:39.617980
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    if Exclude.NEVER(1):
        print('fail')
    else:
        print('pass')


# Generated at 2022-06-11 21:00:45.348759
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest
    from dataclasses import make_dataclass
    from dataclasses_json import config, dataclass_json

    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int

    @dataclass_json
    @dataclass
    class Student(Person):
        number: int

    @dataclass_json
    @dataclass
    class Student2(Person):
        number: int

        @config(exclude=Exclude.NEVER)
        def number(self):
            return self.number * 2

    jane = Student('Jane', 17, 10)
    assert dataclass_json.dumps(jane) == '{"name": "Jane", "age": 17}'


# Generated at 2022-06-11 21:00:55.212003
# Unit test for function config
def test_config():
    # Just to make sure the function doesn't raise
    assert config() == {'dataclasses_json': {}}
    assert config(encoder='my_encoder') == {'dataclasses_json': {'encoder': 'my_encoder'}}
    assert config(decoder='my_decoder') == {'dataclasses_json': {'decoder': 'my_decoder'}}
    assert config(mm_field='my_mm_field') == {'dataclasses_json': {'mm_field': 'my_mm_field'}}
    assert config(letter_case='my_letter_case') == {'dataclasses_json': {'letter_case': 'my_letter_case'}}

# Generated at 2022-06-11 21:00:57.916861
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER("good") == False
  assert Exclude.NEVER("bad") == False
  assert Exclude.NEVER("ugly") == False
  

# Generated at 2022-06-11 21:00:59.393357
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    class TestClass:
        test_field: str

    t = TestClass("")
    result = Exclude.NEVER(t)
    assert result is False

# Generated at 2022-06-11 21:01:01.819853
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    data = {'a': 'A', 'b': 'B'}
    Exclude.NEVER(data)
    if data is not None:
        return data



# Generated at 2022-06-11 21:01:07.720643
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    dc = dataclasses.dataclass()
    @dc
    class A:
        x:int=5
        @config(exclude=Exclude.NEVER)
        def y(self):
            return A.x+100
    assert A().y() == 105
    assert json.dumps(A()) == '{"y":105}'


# Generated at 2022-06-11 21:01:08.955282
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('hello') == False
    

# Generated at 2022-06-11 21:01:30.146544
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # python code in file Exclude.py
    if __name__ == '__main__':
        print("class Exclude:")
        print("    # TODO: add Warnings?")
        print("    ALWAYS: Callable[[T], bool] = lambda _: True")
        print("    NEVER: Callable[[T], bool] = lambda _: False")

        print("\n")

        def f1(value):
            return not value


        def f2(value):
            return value



# Generated at 2022-06-11 21:01:33.918558
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Test that Exclude.NEVER returns false no matter what is passed inside
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 21:01:35.090854
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True



# Generated at 2022-06-11 21:01:39.813721
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS(None) == True
    # success


# Generated at 2022-06-11 21:01:40.839755
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result=Exclude.NEVER("a")
    assert result==False


# Generated at 2022-06-11 21:01:42.114001
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    expected = True
    assert(result == expected)



# Generated at 2022-06-11 21:01:45.077160
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('toto') == True
    assert Exclude.ALWAYS('tata') == True
    assert Exclude.ALWAYS(42) == True


# Generated at 2022-06-11 21:01:46.282000
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.ALWAYS(1) == False
    pass


# Generated at 2022-06-11 21:01:47.850635
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 21:01:49.735993
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1))


# Generated at 2022-06-11 21:02:14.792946
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('string') == True


# Generated at 2022-06-11 21:02:18.745349
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hello") == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    return True


# Generated at 2022-06-11 21:02:22.996843
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("blabla")
    assert Exclude.ALWAYS(3.14)
    assert Exclude.ALWAYS(object)
    assert Exclude.ALWAYS(Exclude)



# Generated at 2022-06-11 21:02:24.211004
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True



# Generated at 2022-06-11 21:02:26.539136
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def f(x):
        return 5
    if Exclude.NEVER(f) == False:
        print("test_Exclude_NEVER passed")
    else:
        print("test_Exclude_NEVER failed")


# Generated at 2022-06-11 21:02:29.429647
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False



# Generated at 2022-06-11 21:02:32.821007
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Arrange
    _instance = Exclude.ALWAYS

    # Act

    # Assert
    assert _instance(4) == True


# Generated at 2022-06-11 21:02:33.841643
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(object) == True


# Generated at 2022-06-11 21:02:36.898656
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("abcd") == True


# Generated at 2022-06-11 21:02:38.053695
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 21:03:21.354687
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 21:03:23.671551
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	# Test data
	obj1 = 5
	obj2 = "hello"
	obj3 = []
	
	# Tests
	assert Exclude.ALWAYS(obj1)
	assert Exclude.ALWAYS(obj2)
	assert Exclude.ALWAYS(obj3)


# Generated at 2022-06-11 21:03:25.413870
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 21:03:29.856724
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS((1,2)) == True
    assert Exclude.ALWAYS([1,2]) == True


# Generated at 2022-06-11 21:03:31.348844
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-11 21:03:39.588215
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Создаем объект класса Exclude
    ex = Exclude()
    # Вызываем его метод NEVER
    answer = ex.NEVER(ex)
    # Сверяем возвращаемое значение при обращении к данному методу с ожидаемым значением
    assert answer == False


# Generated at 2022-06-11 21:03:41.189214
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 21:03:41.764681
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 21:03:43.983815
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('blah')
    assert Exclude.ALWAYS(True)


# Generated at 2022-06-11 21:03:46.109298
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(123) is True
    assert Exclude.ALWAYS('abc') is True
    assert Exclude.ALWAYS(('abc', 'def')) is True
    assert Exclude.ALWAYS([]) is True
    assert Exclude.ALWAYS({}) is True
