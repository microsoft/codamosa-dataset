

# Generated at 2022-06-11 20:54:31.175391
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(2)
    assert Exclude.NEVER(3)
    assert Exclude.NEVER(4)
    assert Exclude.NEVER(5)
    assert Exclude.NEVER(6)
    assert Exclude.NEVER(7)
    assert Exclude.NEVER(8)
    assert Exclude.NEVER(9)
    assert Exclude.NEVER(10)
    assert Exclude.NEVER("")
    assert Exclude.NEVER("A")


# Generated at 2022-06-11 20:54:33.038327
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class TestClass:
        pass
    tc = TestClass()
    assert Exclude.ALWAYS(tc) is True


# Generated at 2022-06-11 20:54:35.673282
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class Class1:
        def __init__(self):
            self.value = 1
    instance1 = Class1()
    assert Exclude.NEVER(instance1) == True



# Generated at 2022-06-11 20:54:38.336684
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:54:41.208461
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:54:45.269885
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(0)
    assert Exclude.NEVER("")
    assert Exclude.NEVER([])
    assert Exclude.NEVER(())
    assert Exclude.NEVER({})


# Generated at 2022-06-11 20:54:49.746388
# Unit test for function config
def test_config():
    @config(field_name="abc", mm_field=str)
    class A:
        pass

    assert A.__annotations__['abc'] == str
    assert A.__dict__['_field_metadata']['abc']['dataclasses_json']['mm_field'] == str

# Generated at 2022-06-11 20:54:51.094438
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("some_value")


# Generated at 2022-06-11 20:55:02.185260
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(letter_case=lambda s: s.upper())
    class Example1:
        a: int

    @dataclass
    @config(encoder=str)
    @config(decoder=int)
    @config(mm_field=fields.DateTime())
    class Example2:
        b: str

    @dataclass
    @config(undefined='EXCLUDE')
    class Example3:
        c: str

    @dataclass
    @config(exclude=lambda f, t: f.startswith('_'))
    class Example4:
        _d: str
        e: int
        f: str


# Generated at 2022-06-11 20:55:03.123170
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_value = 2
    assert Exclude.ALWAYS(test_value) == True

# Generated at 2022-06-11 20:55:15.450884
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestClass:
        def __init__(self):
            self.test = "test"

    t = TestClass()

    # Test with required parameter
    if not Exclude.NEVER(t):
        raise Exception("NEVER No parameter should return true")

    # Test with optional parameter
    if not Exclude.NEVER(t, test="test"):
        raise Exception("NEVER Optional parameter should return true")

    # Test without optional parameter
    if not Exclude.NEVER(t, test_2="test_2"):
        raise Exception("NEVER Missing optional parameter should return true")

    # Test with required parameter
    if Exclude.NEVER(t, test_3="test_3"):
        raise Exception("NEVER Extra optional parameter should return false")


# Generated at 2022-06-11 20:55:17.415842
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-11 20:55:20.952289
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS(object)
    assert Exclude.ALWAYS(list)


# Generated at 2022-06-11 20:55:23.745714
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("abc")
    assert Exclude.NEVER("abc")
    assert Exclude.NEVER("")


# Generated at 2022-06-11 20:55:32.040335
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("string")
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS((1, 2, 3))
    assert Exclude.ALWAYS({"key": "value"})
    assert Exclude.ALWAYS({"key1": 1, "key2": 2, "key3": 3})


# Generated at 2022-06-11 20:55:34.983222
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS('1')
    assert Exclude.ALWAYS(2j)


# Generated at 2022-06-11 20:55:38.284343
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("random")
    assert Exclude.NEVER({})
    assert Exclude.NEVER(None)
    assert Exclude.NEVER([])
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(False)

# Generated at 2022-06-11 20:55:40.279804
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS("abc")


# Generated at 2022-06-11 20:55:44.796703
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS("Hello") == True
    assert Exclude.ALWAYS(['apple', 'orange']) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS({'A': 'apple'}) == True


# Generated at 2022-06-11 20:55:47.537934
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class A:
        pass
    a = A()
    assert Exclude.NEVER(a) == False


# Generated at 2022-06-11 20:55:52.333887
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:55:54.428157
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:55:56.372379
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True



# Generated at 2022-06-11 20:56:07.328519
# Unit test for function config
def test_config():
    from dataclasses import asdict
    from marshmallow import fields as mm_fields

    @config(exclude=lambda f: False)
    @dataclass
    class Dummy:
        a: str

    assert not Dummy.__dict__['a'].metadata['dataclasses_json']['exclude']

    @config(letter_case=lambda s: s)
    @dataclass
    class Dummy:
        a: str

    assert Dummy.__dict__['a'].metadata['dataclasses_json']['letter_case'] is None

    @config(letter_case=lambda s: s)
    @dataclass
    class Dummy:
        a: str = field(metadata=config(letter_case=lambda s: s.upper()))


# Generated at 2022-06-11 20:56:08.330061
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("anything")

# Generated at 2022-06-11 20:56:10.252003
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is True

if __name__ == "__main__":
    test_Exclude_NEVER()

# Generated at 2022-06-11 20:56:12.300052
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS("") == True)
    assert(Exclude.ALWAYS(1) == True)
    assert(Exclude.ALWAYS(True) == True)


# Generated at 2022-06-11 20:56:14.087216
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field = "This field"
    assert Exclude.NEVER(field) == False


# Generated at 2022-06-11 20:56:19.179018
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    d1 = dataclasses.dataclass(metadata=config(exclude=Exclude.NEVER))
    @dataclass_json
    @d1
    class TestNever:
        a: int = 1
        b: int = 2
        c: int = 3
    test_never = TestNever()
    assert test_never.__json__() == {}


# Generated at 2022-06-11 20:56:20.837050
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True
    assert Exclude.ALWAYS("") == True


# Generated at 2022-06-11 20:56:30.354774
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude()
    assert a.NEVER(1) == True
    assert a.NEVER(0) == True


# Generated at 2022-06-11 20:56:32.011785
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(4) == False

#Unit test for method ALWAYS of class Exclude

# Generated at 2022-06-11 20:56:33.174741
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:56:36.095911
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """ Test method NEVER of class Exclude
    Returning False in this method means that the field is not included, else the field is included
    """
    assert Exclude.NEVER('x') == False


# Generated at 2022-06-11 20:56:37.231617
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:56:38.803030
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("T")


# Generated at 2022-06-11 20:56:39.693379
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")


# Generated at 2022-06-11 20:56:40.842270
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(ValueError()) == True


# Generated at 2022-06-11 20:56:42.272891
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:43.909525
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    ex = Exclude()
    assert ex.ALWAYS(1) == True

# Generated at 2022-06-11 20:56:58.571976
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER('any')
    assert (result == False), "expect Exclude.NEVER returns False"

# Generated at 2022-06-11 20:57:00.130175
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(5)
    assert result == True


# Generated at 2022-06-11 20:57:01.583266
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-11 20:57:02.700439
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS


# Generated at 2022-06-11 20:57:06.027434
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-11 20:57:09.194183
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER('False')
    assert Exclude.NEVER(False)
    assert Exclude.NEVER({})
    assert Exclude.NEVER([])


# Generated at 2022-06-11 20:57:10.904066
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def test_func(a):
        return Exclude.NEVER(a)

    assert test_func(False) == False


# Generated at 2022-06-11 20:57:13.167737
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:57:14.931657
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS('hi') == True


# Generated at 2022-06-11 20:57:21.942230
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_value = 1
    config_dict = config(exclude=Exclude.ALWAYS)
    assert str(config_dict) == "{'dataclasses_json': {'exclude': <function Exclude.ALWAYS at 0x7f6b37d6b620>}}"
    assert config_dict['dataclasses_json']['exclude'](1) == True
    return True


# Generated at 2022-06-11 20:58:23.033630
# Unit test for function config
def test_config():
    _cls = type('Cls', (object,), {})
    _cls.__getattr__ = lambda self, name: 'NM'
    _cls.__delattr__ = lambda self, name: UndefinedParameterError
    _cls._repr = lambda self: 'N'
    metadata = config(
        encoder=lambda cls, _: cls,
        decoder=lambda cls, _: cls,
        mm_field=lambda cls, _: cls,
        letter_case=lambda cls, _: cls,
        undefined=lambda cls, _: cls,
        exclude=_cls,
        field_name=_cls,
    )
    assert 'N' == str(metadata)
    assert 'N' == repr(metadata)

# Generated at 2022-06-11 20:58:25.287865
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER('T'))

if __name__ == '__main__':
    test_Exclude_NEVER()

# Generated at 2022-06-11 20:58:27.007070
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS('test'))
    assert Exclude.ALWAYS('test')


# Generated at 2022-06-11 20:58:30.616867
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(10)
    assert Exclude.ALWAYS("S")


# Generated at 2022-06-11 20:58:32.004892
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:58:34.097850
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") is True
    assert Exclude.ALWAYS([]) is True
    assert Exclude.ALWAYS({"": ""}) is True


# Generated at 2022-06-11 20:58:35.171638
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") is True


# Generated at 2022-06-11 20:58:36.225431
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS(True) == True


# Generated at 2022-06-11 20:58:37.261269
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
     assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:58:38.524964
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:59:40.243239
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    d = 5

    # Act
    r = Exclude.NEVER(d)

    # Assert
    assert r == False


# Generated at 2022-06-11 20:59:42.030020
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(False)
    assert result == False

# Generated at 2022-06-11 20:59:48.563339
# Unit test for function config
def test_config():
    from marshmallow import fields

    from dataclasses_json import config
    from dataclasses_json import DataClassJsonMixin, config

    @config(undefined=Undefined.RAISE, exclude= Exclude.ALWAYS)
    @dataclass
    class Test(DataClassJsonMixin):
        a: int = field(default=7, metadata={'name': 'noname'})

    assert Test().config_fields().get('undefined') is Undefined.RAISE
    assert Test().config_fields().get('exclude') is Exclude.ALWAYS

    @config(undefined=Undefined.RAISE)
    @dataclass
    class Test2(DataClassJsonMixin):
        a: int = field(default=7, metadata={'name': 'noname'})

    assert Test2().config_fields

# Generated at 2022-06-11 20:59:53.166842
# Unit test for function config
def test_config():
    @config(encoder=1, decoder=2, field_name=3)
    class Example:
        pass

    assert Example.__dataclasses_json__['encoder'] == 1
    assert Example.__dataclasses_json__['decoder'] == 2
    assert Example.__dataclasses_json__['letter_case'](3) == 3

# Generated at 2022-06-11 20:59:56.215747
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:59:57.566191
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS('test'))
    pass


# Generated at 2022-06-11 21:00:00.588225
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None) == True)
    assert(Exclude.ALWAYS(10) == True)
    assert(Exclude.ALWAYS('a') == True)


# Generated at 2022-06-11 21:00:02.689566
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('test')



# Generated at 2022-06-11 21:00:04.407169
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 21:00:05.199932
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-11 21:02:18.325341
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(True))


# Generated at 2022-06-11 21:02:19.631632
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)


# Generated at 2022-06-11 21:02:21.864145
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == Exclude.NEVER(2) == False


# Generated at 2022-06-11 21:02:23.326414
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 21:02:24.979123
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER('a')
    expected = False
    assert result == expected


# Generated at 2022-06-11 21:02:26.290804
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-11 21:02:32.569682
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1), "The value should be true"
    assert Exclude.ALWAYS(2.2), "The value should be true"
    assert Exclude.ALWAYS('abc'), "The value should be true"



# Generated at 2022-06-11 21:02:33.711204
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 21:02:37.379184
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True,"Exclude.ALWAYS(5) does not return True"


# Generated at 2022-06-11 21:02:38.542366
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert not Exclude.ALWAYS(None)
