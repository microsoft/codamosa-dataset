

# Generated at 2022-06-11 20:54:26.534116
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    if Exclude.ALWAYS(1) == True:
        print("Exclude.ALWAYS(1) pass")
    else:
        print("Exclude.ALWAYS(1) fail")


# Generated at 2022-06-11 20:54:28.065899
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:54:37.830818
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from json import loads
    from unittest import TestCase, main

    from dataclasses import dataclass
    from marshmallow import Schema
    from dataclasses_json import config

    @config(encoder=lambda d: 'encoded', decoder=lambda s: 'decoded')
    @dataclass
    class Foo:
        a: str
        b: int

    class FooSchema(Schema):
        f1 = config(encoder=lambda d: 'f1encoded', decoder=lambda s: 'f1decoded')(lambda: 5)

        class Meta:
            fields = ('a', 'f1')

    foo = Foo('test', 9001)

    schema = FooSchema()
    schema.loads('{"a": "test", "b": 9001}')

# Generated at 2022-06-11 20:54:39.406937
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:54:40.546109
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:54:44.603652
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-11 20:54:45.857803
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:54:47.231015
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    context: int = 1
    assert Exclude.ALWAYS(context)
    assert not Exclude.NEVER(context)

# Generated at 2022-06-11 20:54:50.396774
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Setup
    expected = False
    actual = Exclude.NEVER(None)

    # Exercise
    actual = Exclude.NEVER(None)

    # Verify
    assert expected == actual


# Generated at 2022-06-11 20:54:51.834990
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-11 20:54:59.671410
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(0.5) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("string") == False


# Generated at 2022-06-11 20:55:03.140750
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import unittest

    class ExcludeUnitTest(unittest.TestCase):
        def test_Exclude_NEVER(self):
            flag = Exclude.NEVER(1)
            self.assertFalse(flag)

    unittest.main()
    
    

# Generated at 2022-06-11 20:55:04.522947
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.NEVER is not None


# Generated at 2022-06-11 20:55:10.898574
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    @config(exclude=Exclude.NEVER)
    class ToExclude:
        a: int
        b: str
        c: Optional[str] = None
    tt = ToExclude(1, "hello", None)
    assert json.dumps(tt.__dict__, indent=2) == \
        '{\n  "a": 1,\n  "b": "hello",\n  "c": null\n}'


# Generated at 2022-06-11 20:55:12.782428
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # True for every input
    assert Exclude.ALWAYS(Undefined) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-11 20:55:14.200019
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:55:15.468694
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:55:17.765229
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert not Exclude.NEVER("test")
    assert Exclude.ALWAYS("test")



# Generated at 2022-06-11 20:55:18.629744
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
	assert Exclude.NEVER(50) == False

# Generated at 2022-06-11 20:55:20.472654
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = Exclude.ALWAYS(2)
    expected = True
    assert x == expected


# Generated at 2022-06-11 20:55:23.346305
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True



# Generated at 2022-06-11 20:55:31.286785
# Unit test for function config
def test_config():
    import dataclasses
    @dataclasses.dataclass
    class test:
        val: int

    d = test(1)
    config = d.__dataclass_metadata__['dataclasses_json']
    assert config['exclude'] is None
    assert config['undefined'] is Undefined.EXCLUDE
    assert config['letter_case'] is None
    assert config['encoder'] is None
    assert config['decoder'] is None
    assert config['mm_field'] is None
    config = d.__dataclass_metadata__['dataclasses_json']

# Generated at 2022-06-11 20:55:38.251356
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert type(Exclude.NEVER) == type(lambda x: x)
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(3.4) == False
    assert Exclude.NEVER(3+4j) == False
    assert Exclude.NEVER((1,2)) == False
    assert Exclude.NEVER((1,)) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER([1,2]) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({1,2}) == False
    assert Exclude.NEVER({}) == False

# Generated at 2022-06-11 20:55:42.967421
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(False)
    assert not Exclude.NEVER(True)
    assert Exclude.NEVER(None)
    assert not Exclude.NEVER([])
    assert not Exclude.NEVER({})
    assert not Exclude.NEVER(())


# Generated at 2022-06-11 20:55:44.226236
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("whatever") == True


# Generated at 2022-06-11 20:55:46.116892
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:47.883618
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(T) == True

# Generated at 2022-06-11 20:55:57.328481
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(-1)
    assert Exclude.ALWAYS(-2)
    assert not Exclude.ALWAYS(1)
    assert not Exclude.ALWAYS(2)
    assert Exclude.ALWAYS('0')
    assert Exclude.ALWAYS('1')
    assert Exclude.ALWAYS('2')
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('aaa')
    assert not Exclude.ALWAYS(None)
    assert Exclude.ALWAYS([0])
    assert Exclude.ALWAYS([''])
    assert Exclude.ALWAYS([])
    assert not Exclude.ALWAYS([])
    assert Exclude.ALWAYS({'0': 0})
    assert Exclude.ALWAYS({'': ''})

# Generated at 2022-06-11 20:55:59.395556
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:56:02.559482
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(dict(exclude=True))
    assert Exclude.ALWAYS(dict(exclude=False))



# Generated at 2022-06-11 20:56:05.744347
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)



# Generated at 2022-06-11 20:56:12.685054
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import config
    @dataclass
    class Tester:
        name: str = 'Mickael'
        age: int = 0
        is_student: bool = field(metadata={
            'dataclasses_json': config(mm_field=int)
        })
    assert Tester().__dataclass_fields__['is_student'].metadata['dataclasses_json']['mm_field'] == int

    @dataclass
    class Tester1:
        name: str = field(metadata={
            'dataclasses_json': config(field_name='firstName')
        })
    assert Tester1().__dataclass_fields__['name'].metadata['dataclasses_json']['field_name'] == 'firstName'

# Generated at 2022-06-11 20:56:14.211067
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:56:15.589132
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude.NEVER(True)
    assert obj == False

# Generated at 2022-06-11 20:56:17.686250
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.ALWAYS("")
    assert not Exclude.NEVER("")



# Generated at 2022-06-11 20:56:19.716991
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:56:22.057519
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x1 = Exclude.NEVER('abc')
    x2 = Exclude.NEVER(abc=1)

    assert x1 == False
    assert x2 == False



# Generated at 2022-06-11 20:56:23.355400
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:56:24.426049
# Unit test for method NEVER of class Exclude

# Generated at 2022-06-11 20:56:26.394036
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER is not None

# Generated at 2022-06-11 20:56:32.472360
# Unit test for function config
def test_config():
    assert config(encoder=lambda _: "encoder") == {
        'dataclasses_json': {
            'encoder': lambda _: "encoder"
        }
    }

# Generated at 2022-06-11 20:56:34.465566
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") == False


# Generated at 2022-06-11 20:56:36.650765
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 20:56:40.544330
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("test")
    assert Exclude.ALWAYS(10.5)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-11 20:56:41.957374
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('whatever') is False


# Generated at 2022-06-11 20:56:43.177045
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-11 20:56:44.203233
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(field="field") == False

# Generated at 2022-06-11 20:56:51.277096
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert callable(Exclude.ALWAYS)
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS(None) == True
    # __doc__ (as of 2020-09-07) for dataclasses_json.config.Exclude.ALWAYS:



# Generated at 2022-06-11 20:56:57.061338
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))
    print(Exclude.NEVER(0))
    print(Exclude.NEVER(-1))
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False

# Test for field_name of method config

# Generated at 2022-06-11 20:56:58.387083
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('hello')


# Generated at 2022-06-11 20:57:08.283685
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    exp_result = True
    result = Exclude.ALWAYS("some_str")
    assert result == exp_result, "Expected result of Exclude.ALWAYS()"


# Generated at 2022-06-11 20:57:09.325843
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:57:10.118375
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False

# Generated at 2022-06-11 20:57:11.189733
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:57:14.282369
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test")
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:57:15.725465
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-11 20:57:19.070532
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS("Hello")


# Generated at 2022-06-11 20:57:20.526663
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('abc') == False


# Generated at 2022-06-11 20:57:22.289717
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(42) == False


# Generated at 2022-06-11 20:57:27.862417
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # SEE: https://stackoverflow.com/questions/3061/calling-a-function-of-a-module-by-using-its-name-a-string
    # SEE: https://stackoverflow.com/questions/4546272/python-getting-a-method-from-an-object
    a = Exclude.NEVER("hello")
    assert a == False


# Generated at 2022-06-11 20:58:01.662322
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER is not None


# Generated at 2022-06-11 20:58:05.402824
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(True) == True)
    assert(Exclude.ALWAYS(False) == True)


# Generated at 2022-06-11 20:58:07.110600
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(True))
    assert(Exclude.ALWAYS(False))


# Generated at 2022-06-11 20:58:08.243416
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('1') == False

# Generated at 2022-06-11 20:58:09.091032
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False


# Generated at 2022-06-11 20:58:10.365669
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)
    

# Generated at 2022-06-11 20:58:11.474707
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:58:12.263095
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:58:13.396928
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert True == Exclude.ALWAYS("a")


# Generated at 2022-06-11 20:58:15.328279
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-11 20:58:48.946816
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3)



# Generated at 2022-06-11 20:58:49.853970
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1)

# Generated at 2022-06-11 20:58:54.218887
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS(' ') == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(['a']) == True
    assert Exclude.ALWAYS({'a':1}) == True

# Generated at 2022-06-11 20:58:55.872842
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('any parameter')


# Generated at 2022-06-11 20:58:59.475219
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(None)
    assert not Exclude.NEVER(True)
    assert not Exclude.NEVER(False)
    assert not Exclude.NEVER("")


# Generated at 2022-06-11 20:59:05.295226
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(2) is False
    assert Exclude.NEVER(3) is False
    assert Exclude.NEVER(4) is False
    assert Exclude.NEVER(5) is False
    assert Exclude.NEVER(6) is False
    assert Exclude.NEVER(7) is False


# Generated at 2022-06-11 20:59:06.174128
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(1)

# Generated at 2022-06-11 20:59:07.747621
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("Hello") == False
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-11 20:59:11.815295
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Assume
    predicate = Exclude.NEVER

    # Arrange
    obj1 = 'test'
    obj2 = 123

    # Act
    result1 = predicate(obj1)
    result2 = predicate(obj2)

    # Assert
    assert result1 == False
    assert result2 == False


# Generated at 2022-06-11 20:59:19.287517
# Unit test for function config
def test_config():
    # type: ignore
    @dataclass
    class TestClass:
        a: int

    c = config(field_name='new_value')
    assert c == {
        'dataclasses_json': {
            'letter_case': 'new_value'
        }
    }

    c = config(encoder=int)
    assert c == {
        'dataclasses_json': {
            'encoder': int
        }
    }

    c = config(undefined=Undefined.RAISE)
    assert c == {
        'dataclasses_json': {
            'undefined': Undefined.RAISE
        }
    }

    c = config(undefined='skip')

# Generated at 2022-06-11 21:00:41.826247
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('foo') == True


# Generated at 2022-06-11 21:00:43.349471
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    _Exclude_NEVER = Exclude.NEVER(1) == False
    assert(_Exclude_NEVER == True)


# Generated at 2022-06-11 21:00:45.482092
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-11 21:00:46.958803
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-11 21:00:49.826801
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    # assert Exclude.NEVER("string") == False

if __name__ == '__main__':
    test_Exclude_NEVER()

# Generated at 2022-06-11 21:00:51.251433
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert True == Exclude.ALWAYS(None)


# Generated at 2022-06-11 21:01:00.464649
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS("b") == True
    assert Exclude.ALWAYS("c") == True
    assert Exclude.ALWAYS("d") == True
    assert Exclude.ALWAYS("e") == True
    assert Exclude.ALWAYS("f") == True
    assert Exclude.ALWAYS("g") == True
    assert Exclude.ALWAYS("h") == True
    assert Exclude.ALWAYS("i") == True
    assert Exclude.ALWAYS("j") == True
    assert Exclude.ALWAYS("k") == True
    assert Exclude.ALWAYS("l") == True
    assert Exclude.ALWAYS("m") == True
    assert Exclude.ALWAYS("n") == True
    assert Exclude.ALWAYS("o") == True
    assert Exclude

# Generated at 2022-06-11 21:01:02.352151
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(Exclude.NEVER)



# Generated at 2022-06-11 21:01:03.356959
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True

# Generated at 2022-06-11 21:01:04.503347
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 21:04:08.118442
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("sd")
    assert not Exclude.NEVER("sd")

# Generated at 2022-06-11 21:04:10.638636
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_dict = {
        "key1": "value1",
        "key2": "value2",
    }
    for key, value in test_dict.items():
        assert Exclude.NEVER(key) is False


# Generated at 2022-06-11 21:04:14.772843
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER
    assert a(None)
    assert a(0)
    assert a('')
    assert a(1.3)
    assert a(False)
    assert a(True)
    assert a(complex(-1,1))
    assert a(5-6j)
    assert a('asdf')
    assert a([0,1])
    assert a((0,1))
    assert a({0:1})
    assert a(b'a')
    assert a(bytearray(b'a'))
    assert a(memoryview(b'a'))
    assert a(range(3))
    assert a(set([0,1]))
    assert a(slice(1,2))
    assert a(frozenset([0,1]))
    assert a(Exception())

# Generated at 2022-06-11 21:04:16.108020
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS("fish") is True



# Generated at 2022-06-11 21:04:17.137107
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test") is False  


# Generated at 2022-06-11 21:04:20.565770
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class TestClass:
        int_field : int

    my_object = TestClass()
    my_object.int_field = 1
    assert Exclude.NEVER(my_object) == True
