

# Generated at 2022-06-11 20:54:31.250644
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    f = Exclude.ALWAYS
    assert(f(True) == True)
    assert(f(False) == True)
    assert(f(Undefined) == True)
    assert(f(None) == True)
    assert(f(1) == True)
    assert(f(0) == True)
    assert(f('') == True)
    assert(f('None') == True)
    assert(f([]) == True)
    assert(f([True, False, None, Undefined]) == True)
    assert(f([1, 0, [], [True, False, None, Undefined]]) == True)


# Generated at 2022-06-11 20:54:39.910766
# Unit test for function config
def test_config():
    import datetime
    import dataclasses
    import marshmallow

    @dataclasses.dataclass
    class C(object):

        @dataclasses.dataclass
        class Nested(object):
            name: str = dataclasses.field(metadata=config(encoder=str, decoder=str.upper))

        name: str = dataclasses.field(default="test")
        nested: Nested = dataclasses.field(metadata=config(field_name="NESTED"))

    c = C()

    assert c.name == "test"
    assert c.nested.name == ""

    module_config.encoders[str] = str.upper
    module_config.decoders[str] = str.lower
    module_config.mm_fields[str] = marshmallow.fields.String()



# Generated at 2022-06-11 20:54:42.762062
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def test1(obj):
        return True
    def test2(obj):
        return False
    assert test1 == Exclude.ALWAYS(obj=5)
    assert test2 != Exclude.ALWAYS(obj=5)

# Generated at 2022-06-11 20:54:44.821744
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('Hello, World!')


# Generated at 2022-06-11 20:54:45.921376
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hello") == True



# Generated at 2022-06-11 20:54:49.892146
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(0)
    assert not Exclude.NEVER(1)
    assert not Exclude.NEVER(3.14)
    assert not Exclude.NEVER(1000000)


# Generated at 2022-06-11 20:54:52.874331
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS.__call__(3)
    assert Exclude.ALWAYS.__call__(None)
    assert Exclude.ALWAYS.__call__('test_string')


# Generated at 2022-06-11 20:54:55.157784
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    def f():
        pass
    res = Exclude.NEVER(f)
    assert res == False


# Generated at 2022-06-11 20:55:03.219585
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import pytest
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass
    import functools
    import marshmallow

    @config(exclude=Exclude.NEVER)
    @dataclass
    class TestClass:
        attr1: int

    schema = marshmallow.Schema.from_dataclass(TestClass)
    obj = TestClass(attr1=4)
    res = schema.dump(obj)
    assert res['attr1'] == 4
    res2 = schema.load({'attr1': 6})
    assert res2 == TestClass(attr1=6)

# Generated at 2022-06-11 20:55:04.568906
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False


# Generated at 2022-06-11 20:55:08.760339
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude()
    assert a.NEVER([]) == False


# Generated at 2022-06-11 20:55:09.690452
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS(5) == True

# Generated at 2022-06-11 20:55:11.077240
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False, "Exclude.NEVER is not working"


# Generated at 2022-06-11 20:55:13.236872
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(1) == False)

# Generated at 2022-06-11 20:55:14.433338
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("some string")


# Generated at 2022-06-11 20:55:15.438982
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("Anything") is True


# Generated at 2022-06-11 20:55:16.953465
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(None)

# Generated at 2022-06-11 20:55:19.285764
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    # Exclude.NEVER = lambda _: False
    # Act
    # Assert
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-11 20:55:23.033881
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class t_struct:
        def __init__(self, t_str:str):
            self.t_str = t_str
    assert Exclude.NEVER(t_struct('t_str')) == False 



# Generated at 2022-06-11 20:55:26.423310
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # GIVEN
    # data
    mydata = "arbitrary object"

    # WHEN
    result = Exclude.NEVER(mydata)

    # THEN
    assert result is False


# Generated at 2022-06-11 20:55:32.040853
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS("Hello")
    assert Exclude.ALWAYS(["a", "b", "c"])
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:55:36.449922
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS({"a": 1, "b": 2, "c": 3})
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-11 20:55:37.878468
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))


# Generated at 2022-06-11 20:55:41.632564
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('abc')
    assert Exclude.ALWAYS(0.5)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:55:44.765363
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(1.1) == True
    assert Exclude.ALWAYS('string') == True
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-11 20:55:54.325535
# Unit test for function config
def test_config():
    class Foo:
        pass

    encoder_callable = lambda x: x
    decoder_callable = lambda x: x
    mm_field = MarshmallowField
    letter_case = str.upper
    undefined = Undefined.RAISE
    exclude = Exclude.ALWAYS

    # Make sure function decorator works as expected
    @config(encoder=encoder_callable, decoder=decoder_callable, mm_field=mm_field,
            letter_case=letter_case, undefined=undefined, field_name="foo",
            exclude=exclude)
    class Foo(Foo):
        pass

    assert getattr(Foo, '__dataclass_json__').get('encoder') == encoder_callable

# Generated at 2022-06-11 20:55:55.756386
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False

# Generated at 2022-06-11 20:55:56.918331
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:55:57.802157
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('key') == True


# Generated at 2022-06-11 20:56:00.618400
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("a")


# Generated at 2022-06-11 20:56:03.633648
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('field') is False


# Generated at 2022-06-11 20:56:05.358384
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude.NEVER(None)
    assert obj is False


# Generated at 2022-06-11 20:56:06.532075
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) is False


# Generated at 2022-06-11 20:56:08.112543
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("hello")


# Generated at 2022-06-11 20:56:13.690152
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class Foo:
        a: int = 1
        b: int = 2
        c: int = 3
        d: int = 4

    foo = Foo()
    data = json.dumps(foo)
    assert(data == '{}')

    @config(exclude=Exclude.ALWAYS)
    @dataclass
    class Bar:
        a: str = "abcde"
        b: str = "bcdef"

    bar = Bar()
    data = json.dumps(bar)
    assert(data == '{}')



# Generated at 2022-06-11 20:56:15.234628
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:56:25.032874
# Unit test for function config
def test_config():
    import pytest

    @dataclass
    @config(field_name="my_field")
    class A:
        i: int

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class B:
        i: int

    @dataclass
    @config(undefined=Undefined.IGNORE)
    class C:
        i: int

    a: A = A(123)
    assert a.__dataclass_json__['my_field'] == 'i'

    b: B = B(100)
    assert b.__dataclass_json__['exclude'] == Exclude.ALWAYS

    c: C = C(1)
    assert c.__dataclass_json__['undefined'] == Undefined.IGNORE

    # Test invalid undefined action

# Generated at 2022-06-11 20:56:26.699599
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1) == True)


# Generated at 2022-06-11 20:56:27.677868
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

# Generated at 2022-06-11 20:56:32.986836
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    class Item:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    item = Item(1, 2)
    assert Exclude.ALWAYS(item)
    assert Exclude.ALWAYS(item.a)
    assert Exclude.ALWAYS(item.b)


# Generated at 2022-06-11 20:56:36.684942
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("1")
    assert Exclude.NEVER("2")
    assert Exclude.NEVER("3")

# Generated at 2022-06-11 20:56:41.732625
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # GIVEN
    # WHEN
    # THEN
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:56:43.262168
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(10)



# Generated at 2022-06-11 20:56:46.444955
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # arrange
    test_data = 1
    # act
    result = Exclude.NEVER(test_data)
    # assert
    assert result == False

# Generated at 2022-06-11 20:56:48.767397
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True



# Generated at 2022-06-11 20:56:54.179477
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("Hello World")
    assert Exclude.ALWAYS(" ")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS("b")
    assert Exclude.ALWAYS("c")


# Generated at 2022-06-11 20:56:56.107728
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS(None) == True)


# Generated at 2022-06-11 20:56:57.445453
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('dummy') == False


# Generated at 2022-06-11 20:56:58.883894
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(object())


# Generated at 2022-06-11 20:57:01.751320
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(1))
    assert(Exclude.ALWAYS(True))
    assert(Exclude.ALWAYS('test'))


# Generated at 2022-06-11 20:57:05.975572
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:57:08.175524
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # if is the same python file
    if (__file__[-8:] == 'path.py'):
        assert Exclude.ALWAYS("anything") == True


# Generated at 2022-06-11 20:57:09.357132
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    field = Exclude.ALWAYS(True)

    assert field is True


# Generated at 2022-06-11 20:57:11.226475
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @dataclass
    class Dummy:
        a: str

    return Dummy("hello")



# Generated at 2022-06-11 20:57:13.286881
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 20:57:14.429107
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-11 20:57:15.537876
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-11 20:57:17.169438
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') is True


# Generated at 2022-06-11 20:57:19.003897
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("")


# Generated at 2022-06-11 20:57:23.051304
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER('Hello') == False
    assert Exclude.NEVER('Hello', 'World') == False
    assert Exclude.NEVER('Hello', 'World', '!') == False


# Generated at 2022-06-11 20:57:27.817237
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS(0) is True


# Generated at 2022-06-11 20:57:30.649680
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = {'test': True}
    cls = Exclude.NEVER(a)
    if cls == True:
        return True


# Generated at 2022-06-11 20:57:32.621135
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 20:57:33.892214
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test = Exclude.ALWAYS
    assert test('Test') is True


# Generated at 2022-06-11 20:57:35.505964
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("_")
    assert Exclude.ALWAYS(3)


# Generated at 2022-06-11 20:57:45.374970
# Unit test for function config
def test_config():
    from dataclasses import Field

    from marshmallow.fields import Int

    from dataclasses_json import DataClassJsonMixin, config


    @config(encoder=lambda x: x)
    class C(DataClassJsonMixin):
        a = Field(metadata={'encoder': lambda x: x})


# Generated at 2022-06-11 20:57:53.210519
# Unit test for function config
def test_config():
    import dataclasses
    # Create a test dataclass, apply config, and check that the metadata is stored correctly
    @dataclasses.dataclass
    @config(encoder=str, decoder=float, mm_field=str, letter_case=lambda x: x.upper(),
            undefined=str(Undefined.EXCLUDE), exclude=Exclude.NEVER)
    class TestConfig:
        field: int

    assert(TestConfig.__dataclasses_json__.encoder==str)
    assert(TestConfig.__dataclasses_json__.decoder==float)
    assert(TestConfig.__dataclasses_json__.mm_field==str)
    assert(TestConfig.__dataclasses_json__.letter_case('')=='')

# Generated at 2022-06-11 20:57:54.453506
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 20:57:56.864004
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("test") == True


# Generated at 2022-06-11 20:57:57.932986
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False

# Generated at 2022-06-11 20:58:06.326042
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.config import config
    from dataclasses_json.undefined import Undefined

    @dataclass
    @config()
    class Person:
        name: str

    @dataclass
    @config(exclude=Exclude.ALWAYS)
    class Person2:
        name: str

    @dataclass
    @config(undefined=Undefined.EXCLUDE)
    class Person3:
        name: str

    @dataclass
    @config(undefined="raise")
    class Person4:
        name: str

    @dataclass
    @config(undefined="RETURN_NULL")
    class Person5:
        name: str


# Generated at 2022-06-11 20:58:07.837294
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-11 20:58:08.641034
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 20:58:09.430037
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
	assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-11 20:58:11.293409
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS("shreyas") == True


# Generated at 2022-06-11 20:58:12.123965
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("any") == False 


# Generated at 2022-06-11 20:58:13.284359
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():

    assert Exclude.ALWAYS(1) is True


# Generated at 2022-06-11 20:58:17.277838
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    @config(exclude=Exclude.NEVER)
    @dataclass
    class C:
        a: str
        b: int

    assert asdict(C("a", 1)) == {"a": "a", "b": 1}



# Generated at 2022-06-11 20:58:20.424816
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_value_1 = True
    test_value_2 = False

    assert Exclude.ALWAYS(test_value_1) == True
    assert Exclude.ALWAYS(test_value_2) == True


# Generated at 2022-06-11 20:58:21.877015
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    obj = Exclude()
    assert obj.ALWAYS('string') == True
    return


# Generated at 2022-06-11 20:58:27.128522
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(-2) == True
    assert Exclude.ALWAYS(100) == True


# Generated at 2022-06-11 20:58:30.749046
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Arrange
    x = 42

    # Act
    res = Exclude.NEVER(x)

    # Assert
    assert res == False


# Generated at 2022-06-11 20:58:32.127808
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = lambda _: False
    assert Exclude.NEVER == x

# Generated at 2022-06-11 20:58:33.910045
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
  ret_val = Exclude.ALWAYS("foo")
  assert ret_val == True, "expected value to be True"
  return



# Generated at 2022-06-11 20:58:35.516252
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x = Exclude.NEVER(3)
    assert x == False
    y = Exclude.NEVER("test")
    assert y == False


# Generated at 2022-06-11 20:58:37.281410
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False, "Always False"
    assert Exclude.NEVER(567) == False, "Always False"

# Generated at 2022-06-11 20:58:44.242739
# Unit test for function config
def test_config():
    # Test for valid value for undefined
    config(undefined='ignore')

    # Test for invalid value for undefined
    with pytest.raises(UndefinedParameterError):
        config(undefined='INVALID')

    # Test for valid value for undefined
    config(undefined=Undefined.RAISE)

    # Test for valid value for exclude
    config(exclude=Exclude.NEVER)

    # Test for invalid value for exclude
    with pytest.raises(TypeError):
        config(exclude=1)

    # Test for valid value for exclude
    config(exclude=Exclude.NEVER)



# Generated at 2022-06-11 20:58:45.540111
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('never')


# Generated at 2022-06-11 20:58:46.543378
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0) == False

# Generated at 2022-06-11 20:58:49.693765
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    try:
        Exclude.NEVER(None)
        assert False
    except TypeError:
        assert True
    except Exception:
        assert False
    else:
        assert False

# Generated at 2022-06-11 20:58:56.669982
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False
    assert Exclude.NEVER(2) is False



# Generated at 2022-06-11 20:58:58.165323
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-11 20:59:01.855203
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER("ANY")
    assert Exclude.NEVER("INPUT")
    assert Exclude.NEVER("ANYTHING")


# Generated at 2022-06-11 20:59:06.726068
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # type: () -> None
    assert Exclude.NEVER(1)
    assert Exclude.NEVER("")
    assert Exclude.NEVER(True)
    assert Exclude.NEVER([])
    assert Exclude.NEVER({})
    assert Exclude.NEVER({"a":1, "b":2})
    assert Exclude.NEVER(object())


# Generated at 2022-06-11 20:59:09.263890
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("s") == True
    assert Exclude.ALWAYS(('s', 'a')) == True


# Generated at 2022-06-11 20:59:16.650806
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("hi") == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1, 2, 3]) == False
    assert Exclude.NEVER(('a', 'b')) == False
    assert Exclude.NEVER((1, 2)) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({"proper": True}) == False
    assert Exclude.NEVER(lambda x: x) == False


# Generated at 2022-06-11 20:59:17.743032
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)



# Generated at 2022-06-11 20:59:18.717799
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) is True


# Generated at 2022-06-11 20:59:20.775710
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("str") is False


# Generated at 2022-06-11 20:59:22.357900
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True, "Erro ao testar Exclude.ALWAYS"


# Generated at 2022-06-11 20:59:35.515184
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True



# Generated at 2022-06-11 20:59:38.128912
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Arrange
    ex = Exclude()
    # Act
    result = ex.ALWAYS(5)
    # Assert
    assert result == True


# Generated at 2022-06-11 20:59:38.832930
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    pass

# Generated at 2022-06-11 20:59:41.910744
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("FieldA")
    assert Exclude.ALWAYS("FieldB")
    assert Exclude.ALWAYS("FieldC")


# Generated at 2022-06-11 20:59:44.167823
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('foo')
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-11 20:59:46.118929
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1234) == False


# Generated at 2022-06-11 20:59:48.123986
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("foo") is True


# Generated at 2022-06-11 20:59:51.844199
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(123) is True
    assert Exclude.ALWAYS(False) is True
    assert Exclude.ALWAYS(None) is True
    assert Exclude.ALWAYS(Undefined) is True


# Generated at 2022-06-11 20:59:52.961125
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    e = Exclude()
    assert e.ALWAYS


# Generated at 2022-06-11 20:59:55.286521
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(7) is False


# Generated at 2022-06-11 21:00:18.554050
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    The purpose of this method is to check that
    the method NEVER of class Exclude returns True
    """
    # GIVEN
    variable = 'My variable'

    # WHEN
    answer = Exclude.NEVER(variable)

    # THEN
    assert answer



# Generated at 2022-06-11 21:00:24.902357
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER([])
    assert Exclude.NEVER(())
    assert Exclude.NEVER({})
    assert Exclude.NEVER('')
    assert Exclude.NEVER(0)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(1.23)
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(False)
    assert Exclude.NEVER(None)


# Generated at 2022-06-11 21:00:31.152742
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(None))
    assert(Exclude.NEVER(False))
    assert(Exclude.NEVER(-1))
    assert(Exclude.NEVER(True))
    assert(Exclude.NEVER(True))
    assert(Exclude.NEVER(""))
    assert(Exclude.NEVER("anything"  ))
    assert(Exclude.NEVER(0) )
    assert(Exclude.NEVER(1) )
    assert(Exclude.NEVER(int) )
    assert(Exclude.NEVER(type(None)) )
    assert(Exclude.NEVER(type("")) )
    assert(Exclude.NEVER(type(1)) )
    assert(Exclude.NEVER([]) )
    assert(Exclude.NEVER([1, 2, 3]) )

# Generated at 2022-06-11 21:00:39.806171
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    never = Exclude.NEVER
    always = Exclude.ALWAYS
    assert(never(10) == False)
    assert(never(20) == False)
    assert(never(30) == False)
    assert(never(False) == False)
    assert(never(True) == False)
    assert(never(never) == False)
    assert(never(always) == False)
    assert(never('Hello') == False)
    assert(never(['1', '2', '3']) == False)
    assert(never({'name': 'Marc', 'age': 32}) == False)


# Generated at 2022-06-11 21:00:41.295080
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS('1')


# Generated at 2022-06-11 21:00:50.029689
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER(" ") == False
    assert Exclude.NEVER("str") == False
    assert Exclude.NEVER("str str") == False
    assert Exclude.NEVER(3.14) == False
    assert Exclude.NEVER("3.14") == False
    assert Exclude.NEVER("3.14 str") == False
    assert Exclude.NEVER("abc 3.14 str") == False

test_Exclude_NEVER()


# Generated at 2022-06-11 21:00:57.097436
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True
    assert Exclude.ALWAYS("hello") is True
    assert Exclude.ALWAYS([]) is True
    assert Exclude.ALWAYS(()) is True
    assert Exclude.ALWAYS("") is True
    assert Exclude.ALWAYS(0.0) is True
    assert Exclude.ALWAYS("1") is True
    assert Exclude.ALWAYS("True") is True
    assert Exclude.ALWAYS("False") is True
    assert Exclude.ALWAYS("None") is True



# Generated at 2022-06-11 21:00:58.815608
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert not Exclude.ALWAYS(1), 'Test ALWAYS of class Exclude failed! The constant always should return False'


# Generated at 2022-06-11 21:00:59.955748
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER(None)
    assert result == False


# Generated at 2022-06-11 21:01:07.284038
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(100)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('abc')
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS((1,))
    assert Exclude.ALWAYS((1, 2, 3))
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS([1, 2, 3])


# Generated at 2022-06-11 21:01:54.748331
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(None)


# Generated at 2022-06-11 21:01:56.571044
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)


# Generated at 2022-06-11 21:01:57.579440
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-11 21:01:58.378937
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-11 21:02:00.879121
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a")
    assert Exclude.NEVER("b")
    assert Exclude.NEVER("c")
    assert Exclude.NEVER("d")
    assert Exclude.NEVER("e")
    return "OK"


# Generated at 2022-06-11 21:02:03.160108
# Unit test for function config
def test_config():
    assert config(undefined="ignore") == {'dataclasses_json': {'undefined': Undefined.IGNORE}}
    assert config(undefined=Undefined.IGNORE) == {'dataclasses_json': {'undefined': Undefined.IGNORE}}

# Generated at 2022-06-11 21:02:04.819874
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    obj = Exclude()
    assert obj.ALWAYS("a value")



# Generated at 2022-06-11 21:02:06.386488
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-11 21:02:08.705620
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(5)
    assert Exclude.NEVER('Hello')
    assert Exclude.NEVER({'Hola'})


# Generated at 2022-06-11 21:02:09.752560
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    f = Exclude.NEVER
    assert f("")


# Generated at 2022-06-11 21:03:44.414126
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)


# Generated at 2022-06-11 21:03:45.546053
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS


# Generated at 2022-06-11 21:03:47.004702
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-11 21:03:49.940648
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    print(result)
    assert result is True


# Generated at 2022-06-11 21:03:52.361937
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-11 21:03:58.303156
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(T(),T()) == True
    assert Exclude.ALWAYS(1,2) == True
    assert Exclude.ALWAYS(True,False) == True
    assert Exclude.ALWAYS(['a','b'],['c','d']) == True
    assert Exclude.ALWAYS(['a','b'],'c') == True
    assert Exclude.ALWAYS(['a','b'],True) == True
    assert Exclude.ALWAYS(['a','b'],1) == True
    assert Exclude.ALWAYS('a',1) == True
    assert Exclude.ALWAYS('a',True) == True
    assert Exclude.ALWAYS(1,'a') == True
    assert Exclude.ALWAYS(True,'a') == True
    assert Exclude.ALWAYS(1,2,3)

# Generated at 2022-06-11 21:04:01.882647
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    Verify that class Exclude.NEVER is a function that always returns False
    """
    assert False == Exclude.NEVER(0)
    assert False == Exclude.NEVER(1)
    assert False == Exclude.NEVER(2.0)
    assert False == Exclude.NEVER(-1)

# Generated at 2022-06-11 21:04:03.207930
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = object()
    assert Exclude.NEVER(obj) == False


# Generated at 2022-06-11 21:04:04.227335
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS)



# Generated at 2022-06-11 21:04:07.937869
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    z = Exclude()
    A = z.NEVER(True)
    assert A == False