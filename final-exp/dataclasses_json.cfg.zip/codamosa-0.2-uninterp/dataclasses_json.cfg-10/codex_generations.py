

# Generated at 2022-06-17 17:45:26.422536
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:27.483575
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:45:28.522241
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:29.518663
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:30.817081
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:45:37.563555
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:45:43.572277
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(encoder=str, decoder=int, mm_field=fields.Int())
    class A:
        a: int

    assert A.__dataclass_json__.encoder == str
    assert A.__dataclass_json__.decoder == int
    assert A.__dataclass_json__.mm_field == fields.Int()

    @dataclass
    @config(letter_case=lambda s: s.upper())
    class B:
        b: int

    assert B.__dataclass_json__.letter_case('b') == 'B'

    @dataclass
    @config(undefined=Undefined.RAISE)
    class C:
        c: int

    assert C

# Generated at 2022-06-17 17:45:44.710554
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:45:47.303006
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:45:53.696639
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:45:57.362993
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:02.430628
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:46:10.712774
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({'a': 1, 'b': 2}) == True


# Generated at 2022-06-17 17:46:13.132124
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:14.381059
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:21.653351
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:46:29.318976
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(0.1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER((1,)) == False
    assert Exclude.NEVER((1,2)) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER([1,2]) == False
    assert Exclude.NEVER({}) == False

# Generated at 2022-06-17 17:46:36.980269
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Test(DataClassJsonMixin):
        a: int = config(mm_field=fields.Integer())
        b: str = config(mm_field=fields.String())

    assert Test.schema().fields['a'].__class__ == fields.Integer
    assert Test.schema().fields['b'].__class__ == fields.String

# Generated at 2022-06-17 17:46:44.915564
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(encoder=lambda o: o.__dict__,
            decoder=lambda d: TestConfig(**d),
            mm_field=fields.Dict(),
            letter_case=lambda s: s.upper(),
            undefined=Undefined.EXCLUDE,
            field_name='test_config',
            exclude=Exclude.ALWAYS)
    class TestConfig:
        test_config: str

    assert TestConfig.__dataclass_json__.encoder(TestConfig('test')) == {'test_config': 'test'}
    assert TestConfig.__dataclass_json__.decoder({'test_config': 'test'}) == TestConfig('test')
    assert TestConfig.__dataclass_

# Generated at 2022-06-17 17:46:50.405512
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("abc")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(Exclude.NEVER)


# Generated at 2022-06-17 17:46:57.059200
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:47:07.477338
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER([1, 2]) == False
    assert Exclude.NEVER([1, 2, 3]) == False
    assert Exclude.NEVER({}) == False

# Generated at 2022-06-17 17:47:14.973121
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(0.0)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("test")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({'a': 1, 'b': 2})


# Generated at 2022-06-17 17:47:18.994062
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:47:20.718184
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:30.097436
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:47:36.468231
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-17 17:47:38.089662
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:45.741825
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({1:1}) == True


# Generated at 2022-06-17 17:47:52.576349
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:47:58.087533
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:09.374359
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:48:18.094515
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow.validate import OneOf
    from dataclasses_json.api import load, dump

    @dataclass
    @config(encoder=lambda o: o.value, decoder=lambda v: MyEnum(v))
    class MyEnum:
        value: str

        def __init__(self, value: str):
            if value not in ('a', 'b'):
                raise ValueError('Invalid value')
            self.value = value

    @dataclass
    @config(mm_field=fields.String(validate=OneOf(['a', 'b'])))
    class MyEnum2:
        value: str


# Generated at 2022-06-17 17:48:19.479799
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:48:23.414846
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-17 17:48:24.826612
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:31.686325
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:48:39.335013
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-17 17:48:41.245263
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:48:43.829537
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:52.107002
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:49:04.095900
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:49:05.313945
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:06.337230
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:10.141044
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:18.792548
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:49:19.984421
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:22.758593
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:49:23.985624
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:28.244326
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-17 17:49:52.443222
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.api import load, dump

    @dataclass
    class Test:
        a: int = config(encoder=lambda x: x + 1,
                        decoder=lambda x: x - 1)
        b: str = config(mm_field=fields.String)
        c: str = config(field_name='C')
        d: str = config(letter_case=lambda x: x.lower())
        e: str = config(undefined=Undefined.EXCLUDE)
        f: str = config(undefined=Undefined.RAISE)
        g: str = config(undefined=Undefined.INCLUDE)
        h: str = config(undefined='exclude')

# Generated at 2022-06-17 17:49:58.367425
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER("1") == False
    assert Exclude.NEVER("0") == False
    assert Exclude.NEVER("None") == False
    assert Exclude.NEVER("True") == False
    assert Exclude.NEVER("False") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NE

# Generated at 2022-06-17 17:49:59.699024
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:50:05.763184
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS({}) == True


# Generated at 2022-06-17 17:50:09.506939
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-17 17:50:10.894752
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:12.357069
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:50:14.120381
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:23.773522
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS('abc') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS((1, 2, 3)) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({'a': 1, 'b': 2}) == True


# Generated at 2022-06-17 17:50:30.841576
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({1: 1}) == True


# Generated at 2022-06-17 17:50:50.406137
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:54.686853
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({"a": 1})


# Generated at 2022-06-17 17:51:01.946577
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS(4)
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(6)
    assert Exclude.ALWAYS(7)
    assert Exclude.ALWAYS(8)
    assert Exclude.ALWAYS(9)
    assert Exclude.ALWAYS(10)


# Generated at 2022-06-17 17:51:03.173983
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:51:08.559129
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:51:11.795000
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False


# Generated at 2022-06-17 17:51:12.605333
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:51:14.184749
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:51:21.786266
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:51:23.090996
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:52:14.664639
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({1:1}) == True


# Generated at 2022-06-17 17:52:15.895950
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:52:18.648174
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:52:19.874314
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:21.145244
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:28.820771
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json.config import Undefined

    @dataclass
    class TestConfig:
        a: int = field(metadata=config(undefined=Undefined.RAISE))
        b: int = field(metadata=config(undefined=Undefined.EXCLUDE))
        c: int = field(metadata=config(undefined=Undefined.INCLUDE))
        d: int = field(metadata=config(undefined=Undefined.USE_DEFAULT))
        e: int = field(metadata=config(undefined=Undefined.SKIP))
        f: int = field(metadata=config(undefined=Undefined.TOLERATE))


# Generated at 2022-06-17 17:52:30.064719
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:36.979426
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("abc") == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS((1, 2)) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1, 2]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({1: 2}) == True


# Generated at 2022-06-17 17:52:42.015348
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:52:53.714683
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int
        b: str

    assert config(Test) == {'dataclasses_json': {}}
    assert config(Test, encoder=int) == {'dataclasses_json': {'encoder': int}}
    assert config(Test, decoder=int) == {'dataclasses_json': {'decoder': int}}
    assert config(Test, mm_field=int) == {'dataclasses_json': {'mm_field': int}}
    assert config(Test, letter_case=int) == {'dataclasses_json': {'letter_case': int}}

# Generated at 2022-06-17 17:54:28.606520
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:54:30.988314
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-17 17:54:39.099631
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class TestConfig(DataClassJsonMixin):
        a: int = config(encoder=lambda x: x + 1,
                        decoder=lambda x: x - 1,
                        mm_field=fields.Integer(),
                        letter_case=lambda x: x.upper(),
                        undefined=Undefined.EXCLUDE,
                        exclude=Exclude.NEVER)

    assert TestConfig.schema().fields['A'].__class__ == fields.Integer
    assert TestConfig(1).to_json() == '{"A": 2}'
    assert TestConfig.from_json('{"A": 2}') == TestConfig(1)

# Generated at 2022-06-17 17:54:41.574720
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:54:43.777018
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:54:52.034704
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:54:58.691398
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:55:02.809905
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({'a': 1}) == False


# Generated at 2022-06-17 17:55:03.806068
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:55:04.526815
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
