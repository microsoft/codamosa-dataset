

# Generated at 2022-06-17 17:45:25.680498
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:45:26.808578
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:31.695057
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class A:
        a: int = config(exclude=Exclude.ALWAYS)

    assert A().a == 0

    @dataclass
    class B:
        b: int = config(exclude=Exclude.NEVER)

    assert B().b == 0

    @dataclass
    class C:
        c: int = config(exclude=lambda f, v: v == 0)

    assert C().c == 0
    assert C(c=1).c == 1

# Generated at 2022-06-17 17:45:33.086476
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:40.156300
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({1:1}) == True


# Generated at 2022-06-17 17:45:46.497707
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})


# Generated at 2022-06-17 17:45:53.735571
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({'a': 1}) == False


# Generated at 2022-06-17 17:45:54.870392
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:45:59.958512
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-17 17:46:04.018628
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-17 17:46:07.695851
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:14.827979
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({'a': 1}) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS((1,)) == True
    assert Exclude.ALWAYS(set()) == True
    assert Exclude.ALWAYS({1}) == True
    assert Ex

# Generated at 2022-06-17 17:46:22.242274
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-17 17:46:29.835137
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:46:30.835532
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-17 17:46:33.510291
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-17 17:46:36.754390
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:46:39.942609
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(-1) == False


# Generated at 2022-06-17 17:46:42.676456
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:44.610541
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:56.398950
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(Exclude.ALWAYS) == True
    assert Exclude.ALWAYS(Exclude.NEVER) == True
    assert Exclude.ALWAYS(Exclude) == True
    assert Exclude.ALWAYS(config) == True
    assert Exclude.ALWAYS(global_config) == True
    assert Exclude.ALWAYS(Undefined.RAISE) == True
    assert Exclude.ALWAYS(Undefined.EXCLUDE) == True
    assert Exclude.ALWAYS(Undefined.INCLUDE) == True
    assert Ex

# Generated at 2022-06-17 17:46:58.936934
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True


# Generated at 2022-06-17 17:47:00.408697
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:03.789184
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-17 17:47:05.325265
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:07.001095
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:08.530624
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:09.638423
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:15.791713
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({1:1}) == False


# Generated at 2022-06-17 17:47:17.127531
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:35.234706
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:47:38.445594
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-17 17:47:52.242219
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:47:54.073338
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-17 17:47:55.471718
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:02.325539
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS({}) == True


# Generated at 2022-06-17 17:48:08.019693
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:48:13.247872
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:48:20.057585
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(1.0) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER(set()) == False
    assert Exclude.NEVER(frozenset()) == False
    assert Exclude.NEVER(Exclude.NEVER) == False
    assert Exclude.NEVER(Exclude.ALWAYS) == False

# Generated at 2022-06-17 17:48:21.975278
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:48:37.456292
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-17 17:48:44.353863
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(0.1) == False
    assert Exclude.NEVER(-0.1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("ab") == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER("abcd") == False
    assert Exclude.NEVER("abcde")

# Generated at 2022-06-17 17:48:46.515795
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:48.779714
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:55.526166
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS(4)
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(6)
    assert Exclude.ALWAYS(7)
    assert Exclude.ALWAYS(8)
    assert Exclude.ALWAYS(9)
    assert Exclude.ALWAYS(10)
    assert Exclude.ALWAYS(11)
    assert Exclude.ALWAYS(12)
    assert Exclude.ALWAYS(13)
    assert Exclude.ALWAYS(14)
    assert Exclude.ALWAYS(15)
    assert Exclude.ALWAYS(16)
    assert Exclude.ALWAYS(17)
    assert Exclude.ALWAYS(18)
   

# Generated at 2022-06-17 17:48:56.867426
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:59.601670
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:49:01.033857
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:07.111232
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:49:11.485893
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True


# Generated at 2022-06-17 17:49:28.518966
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:34.479369
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('abc') == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER([1, 2]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({'a': 1}) == False
    assert Exclude.NEVER({'a': 1, 'b': 2}) == False


# Generated at 2022-06-17 17:49:37.153765
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:38.801112
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:43.403873
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-17 17:49:45.595142
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:52.417920
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:49:56.263958
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({'a': 1})


# Generated at 2022-06-17 17:50:06.006405
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:50:07.227512
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:38.042687
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:50:46.593614
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.api import load, dump

    @dataclass
    class Test:
        a: int = config(encoder=lambda x: x + 1,
                        decoder=lambda x: x - 1,
                        mm_field=fields.Integer(),
                        letter_case=lambda x: x.upper(),
                        undefined=Undefined.EXCLUDE,
                        field_name='b',
                        exclude=Exclude.ALWAYS)

    assert dump(Test(1)) == '{"b": 2}'
    assert load(Test, '{"b": 2}') == Test(0)

    @dataclass
    class Test:
        a: int = config(undefined=Undefined.RAISE)


# Generated at 2022-06-17 17:50:54.539902
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:50:56.520539
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:57.822265
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:51:05.272455
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("1") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(object) == True
    assert Exclude.ALWAYS(Exclude) == True
    assert Exclude.ALWAYS(Exclude.ALWAYS) == True
    assert Exclude.ALWAYS(Exclude.NEVER) == True


# Generated at 2022-06-17 17:51:07.240601
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:51:12.649841
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:51:14.184874
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:51:16.524922
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:52:34.029845
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:35.219841
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:36.738114
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:38.860493
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-17 17:52:48.928438
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:52:50.994611
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:52:56.706167
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:52:58.151167
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:53:00.376871
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-17 17:53:01.483264
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
