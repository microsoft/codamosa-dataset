

# Generated at 2022-06-17 17:45:31.342125
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:45:32.675984
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:34.033947
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:37.735226
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-17 17:45:43.651809
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:45:51.064451
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json import config, DataClassJsonMixin

    @dataclass
    class Test(DataClassJsonMixin):
        a: int = config(mm_field=fields.Integer())
        b: str = config(mm_field=fields.String())

    assert Test.schema().fields['a'].__class__ == fields.Integer
    assert Test.schema().fields['b'].__class__ == fields.String

# Generated at 2022-06-17 17:45:56.920878
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:45:58.114067
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-17 17:45:59.187574
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:00.284988
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:04.017709
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:12.950994
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:46:14.222094
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:15.823341
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:46:17.410833
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:23.168410
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:46:24.195106
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:25.280661
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:32.628548
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({'a': 1}) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS((1,)) == True
    assert Exclude.ALWAYS(set()) == True
    assert Exclude.ALWAYS(set([1])) == True


# Generated at 2022-06-17 17:46:33.776727
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:39.409159
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True


# Generated at 2022-06-17 17:46:45.283259
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True


# Generated at 2022-06-17 17:46:51.897130
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(encoder=lambda x: x, decoder=lambda x: x, mm_field=fields.Integer())
    class A:
        pass


# Generated at 2022-06-17 17:46:55.803555
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:46:57.395675
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:58.761056
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:06.278570
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True


# Generated at 2022-06-17 17:47:07.515898
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:09.037261
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:13.572096
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(Exclude.ALWAYS) == True
    assert Exclude.ALWAYS(Exclude.NEVER) == True


# Generated at 2022-06-17 17:47:17.048927
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:26.675933
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER("123") == False
    assert Exclude.NEVER("abc123") == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER((1,)) == False
    assert Exclude.NEVER((1, 2)) == False
    assert Exclude.NEVER((1, 2, 3)) == False
    assert Exclude.NEVER([]) == False

# Generated at 2022-06-17 17:47:28.132902
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:37.685625
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:47:39.109451
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:41.708666
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:46.086040
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True


# Generated at 2022-06-17 17:47:56.263168
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    import marshmallow.fields

    @dataclasses.dataclass
    @config(encoder=lambda x: x, decoder=lambda x: x,
            mm_field=marshmallow.fields.Int(),
            letter_case=lambda x: x.upper(),
            undefined=Undefined.EXCLUDE,
            exclude=Exclude.ALWAYS)
    class Test:
        a: int


# Generated at 2022-06-17 17:48:02.670933
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:48:04.516651
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:14.802999
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:48:21.535951
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:48:24.189658
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-17 17:48:25.445225
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:48:27.574898
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-17 17:48:39.370558
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("1") == False
    assert Exclude.NEVER("0") == False
    assert Exclude.NEVER("None") == False
    assert Exclude.NEVER("True") == False
    assert Exclude.NEVER("False") == False
    assert Exclude.NEVER(" ") == False
    assert Exclude.NEVER("  ") == False
    assert Exclude.NEVER("   ") == False
    assert Ex

# Generated at 2022-06-17 17:48:41.311344
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:53.872592
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int
        b: int

    assert config(A) == {'dataclasses_json': {}}
    assert config(A, encoder=int) == {'dataclasses_json': {'encoder': int}}
    assert config(A, decoder=int) == {'dataclasses_json': {'decoder': int}}
    assert config(A, mm_field=int) == {'dataclasses_json': {'mm_field': int}}
    assert config(A, letter_case=int) == {'dataclasses_json': {'letter_case': int}}
    assert config(A, undefined=Undefined.RAISE) == {'dataclasses_json': {'undefined': Undefined.RAISE}}

# Generated at 2022-06-17 17:49:05.238208
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int
        b: str

    assert config(A) == {'dataclasses_json': {}}
    assert config(A, encoder=1) == {'dataclasses_json': {'encoder': 1}}
    assert config(A, decoder=1) == {'dataclasses_json': {'decoder': 1}}
    assert config(A, mm_field=1) == {'dataclasses_json': {'mm_field': 1}}
    assert config(A, letter_case=1) == {'dataclasses_json': {'letter_case': 1}}
    assert config(A, undefined=1) == {'dataclasses_json': {'undefined': 1}}

# Generated at 2022-06-17 17:49:10.526035
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:49:20.479177
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER(set()) == False
    assert Exclude.NEVER(frozenset()) == False
    assert Exclude.NEVER(object()) == False
    assert Exclude.NEVER(object) == False
    assert Exclude.NEVER(Exclude) == False
    assert Exclude.NEVER(Exclude.NEVER) == False

# Generated at 2022-06-17 17:49:23.379930
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False


# Generated at 2022-06-17 17:49:24.535931
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:26.146944
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:30.725313
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:49:32.369417
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:33.334081
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:49:35.249886
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:37.227307
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:39.762423
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True


# Generated at 2022-06-17 17:49:50.478874
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-17 17:49:51.412748
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:52.940355
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:54.428657
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:00.808579
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:50:09.470197
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int
        b: int

    assert Test.__dataclass_fields__['a'].metadata == {}
    assert Test.__dataclass_fields__['b'].metadata == {}

    @dataclass
    class Test:
        a: int
        b: int = config(field_name='b_field')

    assert Test.__dataclass_fields__['a'].metadata == {}
    assert Test.__dataclass_fields__['b'].metadata == {
        'dataclasses_json': {'field_name': 'b_field'}
    }

    @dataclass
    class Test:
        a: int

# Generated at 2022-06-17 17:50:10.830617
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:50:17.713055
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(set())
    assert Exclude.ALWAYS(frozenset())
    assert Exclude.ALWAYS(object())


# Generated at 2022-06-17 17:50:19.058873
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:24.669045
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int = config(exclude=Exclude.ALWAYS)

    assert A.__dataclass_fields__['a'].metadata == {
        'dataclasses_json': {'exclude': Exclude.ALWAYS}
    }

# Generated at 2022-06-17 17:50:54.288122
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:50:56.402352
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:50:57.706802
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:51:00.928429
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-17 17:51:07.501503
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:51:09.058208
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-17 17:51:12.457849
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:51:22.857913
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER(set()) == False
    assert Exclude.NEVER(frozenset()) == False
    assert Exclude.NEVER(Exclude.NEVER) == False
    assert Exclude.NEVER(Exclude.ALWAYS) == False


# Generated at 2022-06-17 17:51:24.042719
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:51:31.410035
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS(4)
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(6)
    assert Exclude.ALWAYS(7)
    assert Exclude.ALWAYS(8)
    assert Exclude.ALWAYS(9)
    assert Exclude.ALWAYS(10)
    assert Exclude.ALWAYS(11)
    assert Exclude.ALWAYS(12)
    assert Exclude.ALWAYS(13)
    assert Exclude.ALWAYS(14)
    assert Exclude.ALWAYS(15)
    assert Exclude.ALWAYS(16)
    assert Exclude.ALWAYS(17)
   

# Generated at 2022-06-17 17:52:15.969703
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:23.813523
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import config, DataClassJsonMixin, dataclass_json

    @dataclass
    class Test(DataClassJsonMixin):
        a: int = field(metadata=config(exclude=Exclude.ALWAYS))
        b: int = field(metadata=config(exclude=Exclude.NEVER))
        c: int = field(metadata=config(exclude=lambda f: f.name == 'c'))

    assert dataclass_json(Test(1, 2, 3)) == '{"b": 2}'

# Generated at 2022-06-17 17:52:30.307572
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS('a')
    assert Exclude.ALWAYS('1')
    assert Exclude.ALWAYS('')
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(set())
    assert Exclude.ALWAYS(frozenset())
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(Exclude.NEVER)
    assert Exclude.ALWAYS(Exclude)
    assert Exclude.ALWAYS(config)

# Generated at 2022-06-17 17:52:31.560676
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:52:33.146528
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:34.686688
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:39.755933
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-17 17:52:44.560269
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-17 17:52:46.638877
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:48.710590
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:54:16.018821
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:54:23.458581
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS(4)
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(6)
    assert Exclude.ALWAYS(7)
    assert Exclude.ALWAYS(8)
    assert Exclude.ALWAYS(9)
    assert Exclude.ALWAYS(10)
    assert Exclude.ALWAYS(11)
    assert Exclude.ALWAYS(12)
    assert Exclude.ALWAYS(13)
    assert Exclude.ALWAYS(14)
    assert Exclude.ALWAYS(15)
    assert Exclude.ALWAYS(16)
    assert Exclude.ALWAYS(17)
    assert Exclude.ALWAYS(18)
   

# Generated at 2022-06-17 17:54:32.047580
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:54:33.215847
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:54:35.145245
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False


# Generated at 2022-06-17 17:54:36.334343
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:54:42.661423
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(1.0) == False
    assert Exclude.NEVER(0.0) == False
    assert Exclude.NEVER(-1.0) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(object) == False


# Generated at 2022-06-17 17:54:44.869573
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:54:47.427065
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import config
    from dataclasses_json.undefined import Undefined

    @dataclass
    class Data:
        a: int = field(metadata=config(undefined=Undefined.EXCLUDE))

    assert Data(a=1).to_dict() == {'a': 1}
    assert Data().to_dict() == {}

# Generated at 2022-06-17 17:54:49.384039
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
