

# Generated at 2022-06-17 17:45:26.823967
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:27.913092
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:33.702192
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER([1, 2]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({1: 1}) == False
    assert Exclude.NEVER({1: 1, 2: 2})

# Generated at 2022-06-17 17:45:35.897419
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:37.050629
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-17 17:45:38.158407
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:45:41.381035
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:45:43.365419
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:51.724998
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({1: 1}) == False


# Generated at 2022-06-17 17:45:53.216715
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:01.640111
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS("abc") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS((1,)) == True
    assert Exclude.ALWAYS((1, 2)) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS([1, 2]) == True
    assert Exclude.ALWAYS({}) == True
    assert Ex

# Generated at 2022-06-17 17:46:03.973225
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:05.314209
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:06.665501
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:08.425538
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:46:15.227801
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:46:25.185884
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER((1,)) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({1: 1}) == False
    assert Exclude.NEVER(set()) == False
    assert Exclude.NEVER(set([1])) == False

# Generated at 2022-06-17 17:46:32.576206
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:46:33.736473
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:43.006706
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:46:47.143667
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:53.059055
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:46:54.197282
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:58.183817
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True


# Generated at 2022-06-17 17:46:59.639746
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:06.280533
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:47:15.090061
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:47:17.048847
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:19.354549
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:20.947720
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:25.840453
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:26.966225
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:37.116572
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:47:38.991378
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:41.639145
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:47.183414
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True


# Generated at 2022-06-17 17:47:53.128820
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:47:54.550333
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-17 17:47:55.278509
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:59.869197
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS("abc") == True


# Generated at 2022-06-17 17:48:04.753258
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:08.747364
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True


# Generated at 2022-06-17 17:48:09.914027
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:12.135608
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:48:13.324180
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:14.439671
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:15.529478
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:21.420358
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS('abc') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS([1, 2]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({'a': 1}) == True
    assert Exclude.ALWAYS({'a': 1, 'b': 2}) == True


# Generated at 2022-06-17 17:48:23.048634
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:24.514439
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:39.376313
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("abc") == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS((1, 2, 3)) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({1: 2, 3: 4}) == True


# Generated at 2022-06-17 17:48:44.827464
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})


# Generated at 2022-06-17 17:48:50.579719
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:48:51.339092
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:52.449531
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:01.226694
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:49:09.035467
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    import pytest

    @dataclasses.dataclass
    class A:
        x: int = dataclasses.field(metadata=config(encoder=str))
        y: int = dataclasses.field(metadata=config(decoder=int))
        z: int = dataclasses.field(metadata=config(mm_field=marshmallow.fields.Int()))
        a: int = dataclasses.field(metadata=config(letter_case=lambda s: s.upper()))
        b: int = dataclasses.field(metadata=config(undefined=Undefined.RAISE))
        c: int = dataclasses.field(metadata=config(field_name='c'))

# Generated at 2022-06-17 17:49:18.350951
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config
    @dataclass
    class A:
        a: int = config(undefined=Undefined.RAISE)
        b: int = config(undefined=Undefined.EXCLUDE)
        c: int = config(undefined=Undefined.INCLUDE)
        d: int = config(undefined=Undefined.USE_DEFAULTS)
        e: int = config(undefined=Undefined.SKIP)
        f: int = config(undefined=Undefined.TOLERATE)
        g: int = config(undefined=Undefined.WARN)
        h: int = config(undefined=Undefined.ERROR)
        i: int = config(undefined=Undefined.PASS)

# Generated at 2022-06-17 17:49:27.036213
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config, DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        a: int = config(field_name='b')
        b: int = config(field_name='a')

    assert A.schema() == {
        'type': 'object',
        'properties': {
            'a': {'type': 'integer'},
            'b': {'type': 'integer'},
        },
        'required': ['a', 'b'],
    }

# Generated at 2022-06-17 17:49:28.311158
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:34.401659
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:49:37.152897
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:49:44.302013
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json.undefined import Undefined

    @dataclass
    class Test:
        a: int = config(undefined=Undefined.EXCLUDE)
        b: int = config(undefined=Undefined.RAISE)
        c: int = config(undefined=Undefined.INCLUDE)
        d: int = config(undefined=Undefined.USE_DEFAULT)
        e: int = config(undefined=Undefined.PASS_THROUGH)

    assert Test.__dataclass_fields__['a'].metadata['dataclasses_json']['undefined'] == Undefined.EXCLUDE
    assert Test.__dataclass_fields__['b'].metadata['dataclasses_json']['undefined'] == Undefined.RA

# Generated at 2022-06-17 17:49:48.286242
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({'a': 1}) == False


# Generated at 2022-06-17 17:49:49.142146
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:49:50.008080
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:49:50.868186
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:49:51.725127
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:49:52.742566
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:53.724425
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:50:11.971782
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config
    @dataclass
    class A:
        a: int = 1
        b: int = 2
        c: int = 3
        d: int = 4
        e: int = 5
        f: int = 6
        g: int = 7
        h: int = 8
        i: int = 9
        j: int = 10
        k: int = 11
        l: int = 12
        m: int = 13
        n: int = 14
        o: int = 15
        p: int = 16
        q: int = 17
        r: int = 18
        s: int = 19
        t: int = 20
        u: int = 21
        v: int = 22
        w: int = 23
        x: int = 24


# Generated at 2022-06-17 17:50:13.222343
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:50:14.824189
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:22.149436
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("abc")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1, 2, 3])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 2, 3: 4})


# Generated at 2022-06-17 17:50:31.507064
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER(' ') == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('abc') == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER([1, 2]) == False
    assert Exclude.NEVER([1, 2, 3]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({'a': 1})

# Generated at 2022-06-17 17:50:33.803812
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:35.294178
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:50:44.684150
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:50:46.783074
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:50:50.769060
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")


# Generated at 2022-06-17 17:51:08.558191
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:51:15.588258
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude

# Generated at 2022-06-17 17:51:19.874644
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS({})


# Generated at 2022-06-17 17:51:21.588662
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:51:26.863621
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(-1) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(object()) == False


# Generated at 2022-06-17 17:51:28.203290
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:51:39.491791
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS(()) == True
    assert Exclude.ALWAYS((1,)) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({1: 1}) == True


# Generated at 2022-06-17 17:51:47.954722
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:51:49.947047
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:52:01.541337
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(Exclude.NEVER)
    assert Exclude.ALWAYS(test_Exclude_ALWAYS)
    assert Exclude.ALWAYS(test_Exclude_NEVER)
    assert Exclude.ALWAYS(test_config)
    assert Exclude.ALWAYS(test_config_encoder)
    assert Exclude.ALWAYS(test_config_decoder)

# Generated at 2022-06-17 17:52:52.920466
# Unit test for function config
def test_config():
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class Test(DataClassJsonMixin):
        a: int = field(metadata=config(exclude=Exclude.ALWAYS))
        b: int = field(metadata=config(exclude=Exclude.NEVER))

    assert Test.schema().dump(Test(1, 2)) == {'b': 2}

# Generated at 2022-06-17 17:52:54.218699
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:53:03.119117
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER((1,)) == False
    assert Exclude.NEVER((1, 2)) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER([1, 2]) == False
    assert Exclude.NEVER({}) == False

# Generated at 2022-06-17 17:53:04.049634
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:53:05.045755
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:53:05.931580
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:53:07.559221
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:53:08.704005
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:53:10.017697
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:53:12.048760
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:54:44.590568
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:54:46.861806
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-17 17:54:48.885325
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:54:50.210564
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:54:51.248460
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:54:56.565691
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(object())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS((1,))
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:54:57.517210
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:55:01.617103
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:55:03.420447
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True


# Generated at 2022-06-17 17:55:07.224161
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(encoder=lambda x: x, decoder=lambda x: x, mm_field=fields.Str())
    class Test:
        pass
