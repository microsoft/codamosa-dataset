

# Generated at 2022-06-17 17:45:30.500668
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow
    from marshmallow.fields import String

    @dataclasses.dataclass
    @config(encoder=lambda x: x, decoder=lambda x: x, mm_field=String())
    class Test:
        pass


# Generated at 2022-06-17 17:45:31.488554
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:45:32.827733
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:45:34.247346
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:45:35.006438
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:35.708464
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('a') == False


# Generated at 2022-06-17 17:45:42.472988
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config, DataClassJsonMixin, Undefined

    @dataclass
    class MyData(DataClassJsonMixin):
        a: int = config(undefined=Undefined.RAISE)
        b: int = config(undefined=Undefined.EXCLUDE)
        c: int = config(undefined=Undefined.INCLUDE)
        d: int = config(undefined=Undefined.USE_DEFAULT)
        e: int = config(undefined=Undefined.USE_NONE)

    assert MyData.schema()['a'].required is True
    assert MyData.schema()['b'].required is False
    assert MyData.schema()['c'].required is True

# Generated at 2022-06-17 17:45:53.094389
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:45:54.253915
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:45:58.211458
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config, DataClassJsonMixin, dataclass_json

    @dataclass
    class Test(DataClassJsonMixin):
        a: int = 1
        b: int = 2

    assert Test().to_json() == '{"a": 1, "b": 2}'

    @dataclass_json
    @dataclass
    class Test(DataClassJsonMixin):
        a: int = 1
        b: int = 2

    assert Test().to_json() == '{"a": 1, "b": 2}'

    @dataclass_json
    @dataclass
    class Test(DataClassJsonMixin):
        a: int = 1
        b: int = 2


# Generated at 2022-06-17 17:46:08.084877
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER({1:1}) == False


# Generated at 2022-06-17 17:46:15.048379
# Unit test for function config
def test_config():
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int
        b: int

    assert Test.__dataclass_fields__['a'].metadata == {}
    assert Test.__dataclass_fields__['b'].metadata == {}

    @config(field_name='a')
    @dataclass
    class Test:
        a: int
        b: int

    assert Test.__dataclass_fields__['a'].metadata == {'dataclasses_json': {'field_name': 'a'}}
    assert Test.__dataclass_fields__['b'].metadata == {}

    @config(field_name='a', exclude=Exclude.ALWAYS)
    @dataclass
    class Test:
        a: int
        b: int

    assert Test

# Generated at 2022-06-17 17:46:21.056897
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(1.0)
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})


# Generated at 2022-06-17 17:46:22.302233
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-17 17:46:23.333356
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:24.357943
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:29.243846
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(2)
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS(4)
    assert Exclude.ALWAYS(5)
    assert Exclude.ALWAYS(6)
    assert Exclude.ALWAYS(7)
    assert Exclude.ALWAYS(8)
    assert Exclude.ALWAYS(9)
    assert Exclude.ALWAYS(10)


# Generated at 2022-06-17 17:46:30.021676
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:46:32.315497
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:33.661226
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-17 17:46:38.588719
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:41.181860
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:46:52.841345
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(" ")
    assert Exclude.ALWAYS("test")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([0])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS([True])
    assert Exclude.ALWAYS([False])
    assert Exclude.ALWAYS([""])
    assert Exclude.ALWAYS([" "])
    assert Exclude.ALWAYS(["test"])
    assert Exclude.ALWAYS({})

# Generated at 2022-06-17 17:46:59.215038
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:47:00.627825
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:02.136513
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:02.807458
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:11.320526
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({"a": 1, "b": 2}) == True


# Generated at 2022-06-17 17:47:12.524716
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:18.188258
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:47:31.644553
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:32.894896
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:35.222333
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(object())


# Generated at 2022-06-17 17:47:36.046086
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:38.170986
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-17 17:47:39.477695
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:49.043571
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from dataclasses_json import config, DataClassJsonMixin

    @dataclass
    class MyDataClass(DataClassJsonMixin):
        a: int = config(field_name='A')
        b: int = config(field_name='B')

    assert MyDataClass.schema() == {
        'A': {'type': 'integer'},
        'B': {'type': 'integer'},
    }

# Generated at 2022-06-17 17:47:50.161591
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:47:51.680249
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:47:58.587711
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:48:16.803906
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:24.344470
# Unit test for function config
def test_config():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    @config(encoder=lambda x: x, decoder=lambda x: x, mm_field=fields.Int(),
            letter_case=lambda x: x, undefined=Undefined.RAISE, field_name='test',
            exclude=Exclude.ALWAYS)
    class Test:
        pass


# Generated at 2022-06-17 17:48:30.788547
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS(())
    assert Exclude.ALWAYS(set())
    assert Exclude.ALWAYS(frozenset())
    assert Exclude.ALWAYS(range(0))
    assert Exclude.ALWAYS(range(1))
    assert Exclude.ALWAYS(range(2))
    assert Exclude.ALWAYS(range(3))
    assert Exclude.ALWAYS(range(4))
    assert Exclude.ALWAYS(range(5))
    assert Exclude.ALWAYS(range(6))

# Generated at 2022-06-17 17:48:32.630937
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:48:34.245982
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:48:41.245039
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:48:53.847326
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:49:05.237164
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:49:11.022578
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(3) == True
    assert Exclude.ALWAYS(4) == True
    assert Exclude.ALWAYS(5) == True
    assert Exclude.ALWAYS(6) == True
    assert Exclude.ALWAYS(7) == True
    assert Exclude.ALWAYS(8) == True
    assert Exclude.ALWAYS(9) == True
    assert Exclude.ALWAYS(10) == True
    assert Exclude.ALWAYS(11) == True
    assert Exclude.ALWAYS(12) == True
    assert Exclude.ALWAYS(13) == True
    assert Exclude.ALWAYS(14) == True
    assert Exclude.ALWAYS(15) == True
    assert Exclude

# Generated at 2022-06-17 17:49:12.471158
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:49:52.653577
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:54.159312
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:49:57.074738
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:49:57.919163
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:49:59.616339
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:00.777801
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:01.494490
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:50:04.169593
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS("a")
    assert Exclude.ALWAYS([])
    assert Exclude.ALWAYS([1])
    assert Exclude.ALWAYS({})
    assert Exclude.ALWAYS({1: 1})


# Generated at 2022-06-17 17:50:10.780678
# Unit test for function config
def test_config():
    import dataclasses
    from marshmallow import fields

    @dataclasses.dataclass
    @config(encoder=lambda x: x, decoder=lambda x: x, mm_field=fields.Int())
    class Test:
        pass


# Generated at 2022-06-17 17:50:12.209952
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-17 17:51:28.337633
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False
    assert Exclude.NEVER(11) == False
    assert Exclude.NEVER(12) == False
    assert Exclude.NEVER(13) == False
    assert Exclude.NEVER(14) == False
    assert Exclude.NEVER(15) == False
    assert Exclude

# Generated at 2022-06-17 17:51:35.116310
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True


# Generated at 2022-06-17 17:51:37.007131
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:51:43.351069
# Unit test for function config
def test_config():
    import dataclasses
    import marshmallow

    @dataclasses.dataclass
    class Test:
        a: str = dataclasses.field(metadata=config(field_name='b'))
        b: str = dataclasses.field(metadata=config(encoder=lambda x: x.upper()))
        c: str = dataclasses.field(metadata=config(decoder=lambda x: x.lower()))
        d: str = dataclasses.field(metadata=config(mm_field=marshmallow.fields.String()))
        e: str = dataclasses.field(metadata=config(letter_case=lambda x: x.lower()))
        f: str = dataclasses.field(metadata=config(undefined=Undefined.RAISE))

# Generated at 2022-06-17 17:51:45.436322
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:51:53.109891
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("a") == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1]) == True
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({1:1}) == True


# Generated at 2022-06-17 17:51:54.501490
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:51:57.630049
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-17 17:51:59.056558
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-17 17:52:00.362160
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:55:06.314504
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS("")
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(object)
    assert Exclude.ALWAYS(Exclude)
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(Exclude.NEVER)
    assert Exclude.ALWAYS(test_Exclude_ALWAYS)
    assert Exclude.ALWAYS(test_Exclude_NEVER)


# Generated at 2022-06-17 17:55:07.119690
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:55:08.071426
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-17 17:55:11.715115
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-17 17:55:16.581996
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(2) == False
    assert Exclude.NEVER(3) == False
    assert Exclude.NEVER(4) == False
    assert Exclude.NEVER(5) == False
    assert Exclude.NEVER(6) == False
    assert Exclude.NEVER(7) == False
    assert Exclude.NEVER(8) == False
    assert Exclude.NEVER(9) == False
    assert Exclude.NEVER(10) == False


# Generated at 2022-06-17 17:55:24.208264
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER("") == False
    assert Exclude.NEVER("a") == False
    assert Exclude.NEVER("abc") == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER([1]) == False
    assert Exclude.NEVER([1, 2]) == False
    assert Exclude.NEVER([1, 2, 3]) == False
    assert Exclude.NEVER({"a": 1}) == False
    assert Exclude.NEVER({"a": 1, "b": 2}) == False
    assert Exclude.NEVER({"a": 1, "b": 2, "c": 3}) == False