

# Generated at 2022-06-25 15:44:46.008320
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(3) == True



# Generated at 2022-06-25 15:44:55.111377
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    import pytest
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS([False]) == True
    assert Exclude.ALWAYS([True]) == True
    assert Exclude.ALWAYS(['']) == True
    assert Exclude.ALWAYS(['a', 'b', 'c']) == True

    # Test case when the parameter name is not consistent with the function name

# Generated at 2022-06-25 15:44:59.002412
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1.1)
    assert Exclude.ALWAYS(3)
    assert Exclude.ALWAYS(1)

# Generated at 2022-06-25 15:45:00.291693
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-25 15:45:03.367877
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(42) == False


# Generated at 2022-06-25 15:45:03.878286
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    a = Exclude()

# Generated at 2022-06-25 15:45:04.935241
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)


# Generated at 2022-06-25 15:45:10.498752
# Unit test for function config
def test_config():
    global_config_0 = _GlobalConfig()
    # test case 0
    global_config_0.encoders = {}
    config(encoder=lambda x : x)
    assert global_config == global_config_0
    # test case 1
    global_config_0.encoders = {}
    config(metadata={}, encoder=lambda x : x)
    assert global_config == global_config_0


# Generated at 2022-06-25 15:45:11.500535
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5) == True


# Generated at 2022-06-25 15:45:13.755997
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS('') == True
    assert Exclude.ALWAYS('abc') == True


# Generated at 2022-06-25 15:45:16.345384
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("a") == False


# Generated at 2022-06-25 15:45:17.997175
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    exclude = Exclude.ALWAYS
    x = 1
    assert exclude(x)
    assert exclude(None)


# Generated at 2022-06-25 15:45:19.221500
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False

test_case_0()

# Generated at 2022-06-25 15:45:20.612652
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print("Unit test for method NEVER of class Exclude")
    assert Exclude.NEVER('foo') is False


# Generated at 2022-06-25 15:45:22.333836
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('test')


# Generated at 2022-06-25 15:45:23.301327
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS


# Generated at 2022-06-25 15:45:25.610354
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    Test function for the Exclude.NEVER method
    """
    assert Exclude.NEVER("Lorem ipsum") == False


# Generated at 2022-06-25 15:45:28.092190
# Unit test for function config
def test_config():
    # Access global config
    global_config.encoders
    global_config.decoders
    global_config.mm_fields

# Generated at 2022-06-25 15:45:29.676007
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    if Exclude.ALWAYS(1):
        assert True


# Generated at 2022-06-25 15:45:36.937861
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    ignore_0 = Exclude.NEVER
    ignore_1 = Exclude.NEVER
    assert ignore_0 == ignore_1
    ignore_2 = Exclude.NEVER
    ignore_3 = Exclude.NEVER
    assert ignore_2 == ignore_3


# Generated at 2022-06-25 15:45:41.632220
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    val = Exclude.ALWAYS(3)
    assert val == True


# Generated at 2022-06-25 15:45:42.446221
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(';D')


# Generated at 2022-06-25 15:45:43.626702
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('_') == True


# Generated at 2022-06-25 15:45:46.561858
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    param_0 = Exclude
    param_1 = Exclude.NEVER
    res_0 = param_0.NEVER(param_1)
    assert res_0 is None


# Generated at 2022-06-25 15:45:47.506951
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS


# Generated at 2022-06-25 15:45:49.828221
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    str_0 = ';D'
    dict_0 = config(undefined=str_0)


# Generated at 2022-06-25 15:45:50.695014
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS(1)


# Generated at 2022-06-25 15:45:51.732901
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    cExclude = Exclude()
    assert cExclude.NEVER("abc")


# Generated at 2022-06-25 15:46:01.127070
# Unit test for function config
def test_config():
    # test undefined
    str_0 = ';D'
    str_1 = 'D;'
    dict_0 = config(undefined=str_0)
    dict_1 = config(undefined=str_1)
    assert dict_0['dataclasses_json']['undefined'] == Undefined.RAISE
    assert dict_1['dataclasses_json']['undefined'] == Undefined.RAISE
    # test field_name
    str_2 = ';D'
    str_3 = 'D;'
    dict_2 = config(field_name=str_2)
    dict_3 = config(field_name=str_3)
    dct_func_2 = dict_2['dataclasses_json']['letter_case']

# Generated at 2022-06-25 15:46:02.537836
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-25 15:46:06.949396
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    dict = {1: 'D'}
    for key in dict:
        assert Exclude.NEVER(dict[key]) == False


# Generated at 2022-06-25 15:46:08.165664
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result_0 = Exclude.ALWAYS(2)
    assert result_0 == True


# Generated at 2022-06-25 15:46:10.154170
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    str_0 = ';D'
    def Exclude_ALWAYS(p0):
        return not ';D'
    dict_0 = config(undefined=str_0)



# Generated at 2022-06-25 15:46:11.363399
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Test case 1
    value = Exclude.NEVER(None)
    assert value == False


# Generated at 2022-06-25 15:46:14.127113
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    obj_0 = Exclude()
    class_0 = Exclude
    method_0 = class_0.ALWAYS
    assert(method_0(obj_0))


# Generated at 2022-06-25 15:46:17.479696
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(Exclude.NEVER(1))


# Generated at 2022-06-25 15:46:22.506746
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    _Exclude = Exclude
    _NEVER = _Exclude.NEVER
    def test_NEVER(val):
        return _NEVER(val)
    assert test_NEVER(False)
    assert test_NEVER(True)


# Generated at 2022-06-25 15:46:24.238191
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('lala') == False
    assert Exclude.NEVER('lili') == False


# Generated at 2022-06-25 15:46:24.959185
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  pass


# Generated at 2022-06-25 15:46:25.548918
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    test_case_0()


# Generated at 2022-06-25 15:46:34.075510
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = Exclude.NEVER
    assert a(None) == False



# Generated at 2022-06-25 15:46:39.965652
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(';)') == True
    assert Exclude.ALWAYS(':(') == True
    assert Exclude.ALWAYS(':)') == True
    assert Exclude.ALWAYS(':]') == True
    assert Exclude.ALWAYS(';(') == True
    assert Exclude.ALWAYS(';)') == True
    assert Exclude.ALWAYS(';]') == True
    assert Exclude.ALWAYS(';D') == True


# Generated at 2022-06-25 15:46:41.047306
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-25 15:46:42.363941
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    obj = Exclude()
    assert(obj.NEVER(0)) == False


# Generated at 2022-06-25 15:46:45.733901
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    str_0 = ';D'
    dict_0 = config(undefined=str_0)
    dict_1 = config(undefined=Exclude.ALWAYS, undefined=Undefined.RAISE)
    dict_3 = config(undefined=Exclude.NEVER, undefined=Undefined.RAISE)


# Generated at 2022-06-25 15:46:46.906550
# Unit test for function config
def test_config():
    str_0 = ';D'
    dict_0 = config(undefined=str_0)
    print(dict_0)

# Generated at 2022-06-25 15:46:57.703165
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    #import dataclasses_json.config as dcj_config
    #global_config = dcj_config._GlobalConfig()
    #ex = dcj_config.Exclude
    str_0 = global_config.mm_fields.items()
    bool_0 = Exclude.NEVER(str_0)
    str_1 = global_config.mm_fields
    bool_1 = Exclude.NEVER(str_1)
    int_0 = global_config.mm_fields.popitem()
    bool_2 = Exclude.NEVER(int_0)
    str_2 = global_config.mm_fields.keys()
    bool_3 = Exclude.NEVER(str_2)
    str_3 = global_config.mm_fields.values()

# Generated at 2022-06-25 15:47:01.423483
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    exclude_0 = Exclude.ALWAYS
    assert (exclude_0('F') == True)


# Generated at 2022-06-25 15:47:03.684605
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-25 15:47:05.525356
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('_')


# Generated at 2022-06-25 15:47:23.370765
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class_0 = Exclude
    str_0 = 'NEVER'
    expect = class_0.__dict__[str_0]
    expect()

# Generated at 2022-06-25 15:47:29.941829
# Unit test for function config
def test_config():
    import inspect
    # Retrieve function object
    func = config
    func_object = inspect.getfullargspec(func)

    # Assert parameter names
    parameters = func_object.args
    assert parameters[0] == 'metadata'
    assert parameters[1] == 'encoder'
    assert parameters[2] == 'decoder'
    assert parameters[3] == 'mm_field'
    assert parameters[4] == 'letter_case'
    assert parameters[5] == 'undefined'
    assert parameters[6] == 'field_name'
    assert parameters[7] == 'exclude'
    assert len(parameters) == 8

    # Assert defaults
    defaults = func_object.defaults
    assert defaults[0] is None
    assert defaults[1] is None
    assert defaults[2] is None
   

# Generated at 2022-06-25 15:47:30.971210
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS)


# Generated at 2022-06-25 15:47:31.788802
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER(1))


# Generated at 2022-06-25 15:47:32.626116
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS is not None


# Generated at 2022-06-25 15:47:35.392711
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """Method _Exclude_NEVER of class _Exclude."""
    def _Exclude_NEVER():
        assert Exclude.NEVER('string') is False


# Generated at 2022-06-25 15:47:45.240150
# Unit test for function config
def test_config():
    _test_config(
        {'encoder': 1, 'decoder': 2, 'mm_field': 3, 'letter_case': 4, 'undefined': 5, 'field_name': 6, 'exclude': 7},
        {})
    _test_config(
        {'encoder': 11, 'decoder': 12, 'mm_field': 13, 'letter_case': 14, 'undefined': 15, 'field_name': 16, 'exclude': 17},
        {'encoder': 1, 'decoder': 2, 'mm_field': 3, 'letter_case': 4, 'undefined': 5, 'field_name': 6, 'exclude': 7})


# Unit test helper method

# Generated at 2022-06-25 15:47:48.520554
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('x') == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-25 15:47:51.764633
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('a') == True
    assert Exclude.ALWAYS('b') == True
    assert Exclude.ALWAYS('c') == True
    assert Exclude.ALWAYS('d') == True


# Generated at 2022-06-25 15:47:52.804319
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) is True


# Generated at 2022-06-25 15:48:56.580903
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass, field
    from dataclasses_json import config
    from dataclasses_json.undefined import Undefined

    @dataclass
    class Test1:
        num: int = field(metadata=config(undefined=Undefined.RAISE))

    t1 = Test1(1)

    try:
        t1.num
    except UndefinedParameterError:
        return 0
    else:
        return 1

# Generated at 2022-06-25 15:48:58.088785
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER('dummy')


# Generated at 2022-06-25 15:49:00.379291
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    string_0 = '*'
    Exclude_0 = Exclude()
    Exclude_0.NEVER(string_0)

# Generated at 2022-06-25 15:49:02.119407
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    str_0 = 'exclude'
    dict_0 = config(undefined=str_0)

# Generated at 2022-06-25 15:49:03.879429
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS('abcde')


# Generated at 2022-06-25 15:49:05.478763
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    x_0 = Exclude.NEVER
    y_0 = Exclude.NEVER(1)



# Generated at 2022-06-25 15:49:09.160459
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Define a_Exclude_NEVER_0 with literal value Exclude.NEVER
    a_Exclude_NEVER_0 = Exclude.NEVER
    # Call method NEVER of class Exclude
    a_bool_1 = Exclude.NEVER(a_Exclude_NEVER_0)
    assert a_bool_1 == False

test_case_0()

# Generated at 2022-06-25 15:49:12.852676
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # TEST CASE: 0
    # Currently just assert to not have errors
    str_0 = 'exclude'
    dict_0 = config(undefined=str_0)

# Generated at 2022-06-25 15:49:14.129197
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    str_0 = 'exclude'
    dict_0 = config(undefined=str_0)



# Generated at 2022-06-25 15:49:16.015471
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # String 'abc'
    str_0 = 'abc'
    # Assert
    assert Exclude.NEVER(str_0) == False


# Generated at 2022-06-25 15:50:27.448254
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Define a mock object
    class Mock:
        def __init__(self, value):
            self.value = value
    mock = Mock(True)
    # Test
    to_test = Exclude.ALWAYS(mock)
    assert to_test

# Generated at 2022-06-25 15:50:34.428466
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # Setting up x to be of type type
    x = type
    global_config.encoders[int] = lambda _: 'x'
    def _mm_field_0(_name_0, _t_0):
        return global_config.mm_fields[_t_0](_name_0)
    # Setting up a to be of type int
    a = 4
    # Calling function Exclude.ALWAYS with parameters (x,)
    result_Exclude_ALWAYS_0 = Exclude.ALWAYS(x)
    assert result_Exclude_ALWAYS_0 == True
    # Calling function config with parameters (undefined='rai', exclude=Exclude.ALWAYS, mm_field=_mm_field_0, encoder=lambda x: 'x')

# Generated at 2022-06-25 15:50:35.273056
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
  # TODO: finish test
  print("NEVER")


# Generated at 2022-06-25 15:50:36.445113
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    visitor = Exclude.NEVER
    assert visitor(10) == False


# Generated at 2022-06-25 15:50:37.417339
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    Exclude.ALWAYS

test_Exclude_ALWAYS()

# Generated at 2022-06-25 15:50:41.710631
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER # should be a constant
    assert(callable(Exclude.NEVER))
    assert(Exclude.NEVER(1) == False)
    assert(Exclude.NEVER(True) == False)
    assert(Exclude.NEVER('1') == False)


# Generated at 2022-06-25 15:50:45.770143
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    boolean = Exclude.ALWAYS(None)
    assert boolean



# Generated at 2022-06-25 15:50:47.346119
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    res = Exclude.ALWAYS
    assert res is not None


# Generated at 2022-06-25 15:50:48.205123
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0) is True


# Generated at 2022-06-25 15:50:49.025853
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    is_NEVER = Exclude.NEVER()


# Generated at 2022-06-25 15:53:09.315921
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS('exclude'))


# Generated at 2022-06-25 15:53:10.643973
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    p = 's'
    assert True == Exclude.ALWAYS(p)


# Generated at 2022-06-25 15:53:11.821823
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('testing') == True


# Generated at 2022-06-25 15:53:13.177746
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    a = 'exclude'
    Exclude.NEVER(a)


# Generated at 2022-06-25 15:53:14.198537
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('foo') == True



# Generated at 2022-06-25 15:53:15.568697
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    bool_0 = Exclude.NEVER(False)


# Generated at 2022-06-25 15:53:18.226464
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    val_0 = Exclude.NEVER('str_0')
    print(val_0)
    print(isinstance(val_0, bool))



# Generated at 2022-06-25 15:53:20.444728
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    lst_0 = [1, 2, 3]
    value_0 = Exclude.ALWAYS(lst_0)
    assert value_0 == True


# Generated at 2022-06-25 15:53:21.403684
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    object_0 = Exclude.NEVER


# Generated at 2022-06-25 15:53:22.661534
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    never = Exclude.NEVER(None)
    assert never == False
