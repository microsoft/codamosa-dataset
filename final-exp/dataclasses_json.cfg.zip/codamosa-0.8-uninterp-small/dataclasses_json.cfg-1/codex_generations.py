

# Generated at 2022-06-25 15:44:48.827127
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    result = Exclude.NEVER

# Generated at 2022-06-25 15:44:53.307410
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    ret = Exclude.ALWAYS(0)
    assert ret == True


# Generated at 2022-06-25 15:44:58.368214
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    config.Exclude.NEVER
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER('True') == False
    assert Exclude.NEVER({True:False}) == False
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-25 15:44:59.365266
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print(Exclude.ALWAYS(0))


# Generated at 2022-06-25 15:45:01.671783
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS("example")


# Generated at 2022-06-25 15:45:03.514052
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-25 15:45:04.607985
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("rabbit")



# Generated at 2022-06-25 15:45:06.642193
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    True if Exclude.NEVER(False) else False

# Generated at 2022-06-25 15:45:14.300199
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("NotNull")
    assert Exclude.NEVER("")
    assert Exclude.NEVER(True)
    assert Exclude.NEVER(1)
    assert Exclude.NEVER(0.5)
    assert Exclude.NEVER([1,2,3])


# Generated at 2022-06-25 15:45:15.536418
# Unit test for function config
def test_config():
    config()

# Generated at 2022-06-25 15:45:18.456851
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False


# Generated at 2022-06-25 15:45:22.958639
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class A:
        def __init__(self, value):
            self.value = value

    a = A(1)
    assert Exclude.NEVER(a) == False
    a.value = 2
    assert Exclude.NEVER(a) == False


# Generated at 2022-06-25 15:45:32.737901
# Unit test for function config
def test_config():
    metadata = {
        'a': 1
    }
    config(metadata=metadata)
    assert metadata == {
        'a': 1,
        'dataclasses_json': {}
    }

    encoder = object()
    config(metadata=metadata, encoder=encoder)
    assert metadata == {
        'a': 1,
        'dataclasses_json': {
            'encoder': encoder
        }
    }

    decoder = object()
    config(metadata=metadata, decoder=decoder)
    assert metadata == {
        'a': 1,
        'dataclasses_json': {
            'encoder': encoder,
            'decoder': decoder
        }
    }

    mm_field = object()
    config(metadata=metadata, mm_field=mm_field)

# Generated at 2022-06-25 15:45:33.716969
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-25 15:45:35.406377
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER('somestring') == False)


# Generated at 2022-06-25 15:45:36.213946
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(8)

# Generated at 2022-06-25 15:45:40.838200
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS('s')


# Generated at 2022-06-25 15:45:45.663732
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(0)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS(Exclude.ALWAYS)
    assert Exclude.ALWAYS(Exclude.NEVER)
    assert Exclude.ALWAYS(test_case_0)


# Generated at 2022-06-25 15:45:54.945423
# Unit test for function config
def test_config():
    global_config_0 = _GlobalConfig()
    assert global_config_0.encoders == {}
    assert global_config_0.decoders == {}
    assert global_config_0.mm_fields == {}
    # assert global_config_0.json_module is json

    config(encoder=float, decoder=int, mm_field=int)
    assert global_config.encoders[float] == float
    assert global_config.decoders[int] == int
    assert global_config.mm_fields[int] == int

    config(metadata={'dataclasses_json': {'encoder': float, 'decoder': int,
                                          'mm_field': int}})
    assert global_config.encoders[float] == float
    assert global_config.decoders[int]

# Generated at 2022-06-25 15:45:56.312217
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True



# Generated at 2022-06-25 15:46:06.542403
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # assert Exclude.NEVER(object) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER('hello') == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER(1.0) == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER({'a':1}) == False
    assert Exclude.NEVER([1,2,3]) == False
    assert Exclude.NEVER(('a','b')) == False
    assert Exclude.NEVER(('a','b','c')) == False


# Generated at 2022-06-25 15:46:07.399159
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('')


# Generated at 2022-06-25 15:46:08.868398
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    if Exclude.NEVER(1) != False:
        print("Error: Exclude.NEVER returns wrong answer")
        

# Generated at 2022-06-25 15:46:10.092122
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True, "The result is not correct."
    

# Generated at 2022-06-25 15:46:11.136837
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(None))
    assert(Exclude.ALWAYS(1))


# Generated at 2022-06-25 15:46:11.740838
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")


# Generated at 2022-06-25 15:46:13.626748
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-25 15:46:14.549325
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-25 15:46:23.744925
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def test_ALWAYS_true(is_bound: bool, *args: str, **kwargs: str) -> bool:
        assert Exclude.ALWAYS(is_bound)
        return True

    assert test_ALWAYS_true(True, "arg1", "arg2")
    assert test_ALWAYS_true(True, arg1="val1", arg2="val2")


# Generated at 2022-06-25 15:46:26.388975
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    print("Testing Exclude.ALWAYS")
    if(Exclude.ALWAYS(0)):
        print("Test passed")
    else:
        print("Test failed")
    if(Exclude.ALWAYS(1)):
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-25 15:46:29.092372
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS('foo') == True)


# Generated at 2022-06-25 15:46:29.937811
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) is False


# Generated at 2022-06-25 15:46:31.576194
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-25 15:46:33.575193
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    field_type = str
    assert Exclude.NEVER(field_type) is False


# Generated at 2022-06-25 15:46:36.078619
# Unit test for function config
def test_config():
    assert ('dataclasses_json' in config()) == True

# unit test for function _GlobalConfig

# Generated at 2022-06-25 15:46:43.651669
# Unit test for function config
def test_config():
    from marshmallow import fields
    from typing import cast, Callable
    # if you want to use mypy, this must be `_GlobalConfig` instead
    # of `globals()["_GlobalConfig"]`
    global_config = cast(Callable[..., _GlobalConfig], globals()["_GlobalConfig"])()

    # https://stackoverflow.com/questions/319279/how-to-validate-ip-address-in-python/32001260
    def is_valid_ipv4_address(address):
        try:
            socket.inet_pton(socket.AF_INET, address)
        except AttributeError:  # no inet_pton here, sorry
            try:
                socket.inet_aton(address)
            except socket.error:
                return False

# Generated at 2022-06-25 15:46:46.065316
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert type(Exclude.NEVER) == Callable

# Generated at 2022-06-25 15:46:56.926892
# Unit test for function config
def test_config():
    # Test 0
    test_case_0()

    # Test 1
    metadata_1 = config(encoder = 'test1')
    assert metadata_1['dataclasses_json']['encoder'] == 'test1'

    # Test 2
    metadata_2 = config(decoder = 'test2')
    assert metadata_2['dataclasses_json']['decoder'] == 'test2'

    # Test 3
    metadata_3 = config(mm_field = 'test3')
    assert metadata_3['dataclasses_json']['mm_field'] == 'test3'

    # Test 4
    metadata_4 = config(letter_case = 'test4')
    assert metadata_4['dataclasses_json']['letter_case'] == 'test4'

    # Test 5

# Generated at 2022-06-25 15:47:05.269359
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
    assert Exclude.ALWAYS(False) == True
    assert Exclude.ALWAYS(None) == True
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(0) == True
    assert Exclude.ALWAYS(0.0) == True
    assert Exclude.ALWAYS(0.6) == True
    assert Exclude.ALWAYS("") == True
    assert Exclude.ALWAYS("0") == True
    assert Exclude.ALWAYS("A") == True
    assert Exclude.ALWAYS([]) == True
    assert Exclude.ALWAYS([0]) == True
    assert Exclude.ALWAYS([0, 1]) == True
    assert Exclude.ALWAYS([1, 2, 3]) == True
    assert Exclude.ALWAYS({})

# Generated at 2022-06-25 15:47:07.412574
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    res = Exclude.NEVER('bob')
    return res


# Generated at 2022-06-25 15:47:11.331722
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True
    assert Exclude.ALWAYS(500) == True
    assert Exclude.ALWAYS(-1) == True
    assert Exclude.ALWAYS(0) == True


# Generated at 2022-06-25 15:47:14.337268
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER is not None


# Generated at 2022-06-25 15:47:16.839471
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert (Exclude.ALWAYS(1)) == True


# Generated at 2022-06-25 15:47:17.714836
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(1)
    assert result == True


# Generated at 2022-06-25 15:47:22.300314
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Example(DataClassJsonMixin):
        val: int
        @classmethod
        def _config(cls):
            return config(exclude=Exclude.NEVER)

    assert Example(3).to_json() == '{"val": 3}'


# Generated at 2022-06-25 15:47:23.571751
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    t = Exclude.NEVER(123)
    assert t == False


# Generated at 2022-06-25 15:47:25.375062
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == Exclude.NEVER(1.1) == Exclude.NEVER(2) == Exclude.NEVER(2**31)

# Generated at 2022-06-25 15:47:26.347095
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None) == True


# Generated at 2022-06-25 15:47:31.159620
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    from dataclasses import dataclass
    from typing import cast
    @dataclass
    class Node:
        value: int
        def __init__(self, value:int) -> None:
            self.value = value
    def test(node_value:int) -> bool:
        node = Node(node_value)
        return cast(bool, (Exclude.ALWAYS)(node))
    assert test(node_value=1)

# Generated at 2022-06-25 15:47:36.594576
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(None)
    assert Exclude.ALWAYS([1,2,3])
    assert Exclude.ALWAYS(['a','b','c'])
    assert Exclude.ALWAYS(('a','b','c'))
    assert Exclude.ALWAYS({'a':1, 'b':2, 'c':3})
    assert Exclude.ALWAYS({"a":1, "b":2, "c":3})
    assert Exclude.ALWAYS(0.5)
    assert Exclude.ALWAYS(1.5)
    assert Exclude.ALWAYS(0.0)
    assert Exclude.ALWAYS(-0.5)


# Generated at 2022-06-25 15:47:39.932945
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    data = 0
    Exclude.NEVER(data)

# Generated at 2022-06-25 15:47:44.816610
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    class DummyClass:
        pass

    obj = DummyClass()
    ret = lambda obj: Exclude.NEVER(obj)

    assert ret(obj) == False

# Generated at 2022-06-25 15:47:45.985226
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(5)


# Generated at 2022-06-25 15:47:47.066546
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS({}) == True
    assert Exclude.ALWAYS({'a': 1}) == True


# Generated at 2022-06-25 15:47:48.300603
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    global Exclude
    test_param = 10
    assert Exclude.NEVER(test_param) == False


# Generated at 2022-06-25 15:47:49.457123
# Unit test for function config
def test_config():
    pass

# Generated at 2022-06-25 15:47:51.801692
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("")
    assert Exclude.NEVER(1)
    assert Exclude.NEVER({})
    assert Exclude.NEVER({1:1})


# Generated at 2022-06-25 15:47:52.838055
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(0)


# Generated at 2022-06-25 15:47:57.360661
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert(Exclude.NEVER("a") == False)
    assert(Exclude.NEVER("b") == False)
    assert(Exclude.NEVER("c") == False)


# Generated at 2022-06-25 15:48:04.534190
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    def test_case_1():
        assert Exclude.ALWAYS(True)

    def test_case_2():
        assert Exclude.ALWAYS(False)

    test_case_1()
    test_case_2()


# Generated at 2022-06-25 15:48:09.872888
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert func_to_test.Exclude.ALWAYS(00) == True


# Generated at 2022-06-25 15:48:10.952694
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True


# Generated at 2022-06-25 15:48:11.632847
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    Exclude.NEVER(0)

# Generated at 2022-06-25 15:48:13.844755
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():

    def _configure(x):
        return config(exclude=Exclude.NEVER)

    dict = _configure(1)
    dict = _configure(2)
    dict = _configure(3)
    dict = _configure(4)

# Generated at 2022-06-25 15:48:14.959485
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(None)


# Generated at 2022-06-25 15:48:19.250007
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER("test")
    assert Exclude.NEVER("")
    assert Exclude.NEVER(1234)
    assert Exclude.NEVER(1j)
    assert Exclude.NEVER([1, 2, 3])
    assert Exclude.NEVER(("a", "b", ))
    assert Exclude.NEVER({1, 2, 3})
    assert Exclude.NEVER({"a": "b", })
    assert Exclude.NEVER(object)
    assert Exclude.NEVER(None)


# Generated at 2022-06-25 15:48:20.229241
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dict_1 = config(exclude=Exclude.ALWAYS)


# Generated at 2022-06-25 15:48:21.156676
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dict_1 = config(exclude=Exclude.ALWAYS)


# Generated at 2022-06-25 15:48:29.898766
# Unit test for function config
def test_config():
    with pytest.raises(UndefinedParameterError):
        config(undefined="invalid")

    config()
    assert global_config.encoders == {}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

    config(encoder=int)
    assert global_config.encoders == {int: int}
    assert global_config.decoders == {}
    assert global_config.mm_fields == {}

    config(decoder=int)
    assert global_config.encoders == {int: int}
    assert global_config.decoders == {int: int}
    assert global_config.mm_fields == {}

    config(mm_field=int)
    assert global_config.encoders == {int: int}
    assert global_config.dec

# Generated at 2022-06-25 15:48:35.642996
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)
    assert Exclude.ALWAYS(['a', 'b', 'c'])
    assert Exclude.ALWAYS((1, 2, 3))
    assert Exclude.ALWAYS({'a': 1, 'b': 2})
    # TODO: This test case is for marshmallow fields to test
    # assert Exclude.ALWAYS(<marshmallow fields>) <marshmallow fields> can be any type of marshmallow field
    return True


# Generated at 2022-06-25 15:48:40.273669
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) is False


# Generated at 2022-06-25 15:48:41.994075
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    exclude = Exclude.NEVER
    assert exclude("") == False
    assert exclude(0) == False
    assert exclude(None) == False
    assert exclude(1.0) == False


# Generated at 2022-06-25 15:48:43.621668
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    Test if this function returns false
    """
    assert Exclude.NEVER(True) == False
    

# Generated at 2022-06-25 15:48:51.941295
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Item:
        name: str
        quantities: List[float]

    @dataclass
    class Item_1:
        name: str
        quantities: List[float]

    @dataclass
    class Item_2:
        name: str
        quantities: List[float]

    @dataclass
    class Item_3:
        name: str
        quantities: List[float]

    @dataclass
    class Item_4:
        name: str
        quantities: List[float]

    @dataclass
    class Item_5:
        name: str
        quantities: List[float]

    @dataclass
    class Item_6:
        name: str
        quantities: List[float]


# Generated at 2022-06-25 15:49:00.955618
# Unit test for function config
def test_config():
    dict_0 = config()
    dict_1 = config()
    assert dict_0 != dict_1

    dict_2 = config(exclude=Exclude.ALWAYS)
    dict_3 = config(undefined="RAISE")
    dict_4 = config(encoder=int)
    dict_5 = config(decoder=int)
    dict_6 = config(mm_field=int)
    dict_7 = config(letter_case=int)

    assert dict_0 != dict_1 != dict_2 != dict_3 != dict_4 != dict_5 != dict_6 != dict_7


if __name__ == '__main__':
    test_config()

# Generated at 2022-06-25 15:49:02.948957
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)



# Generated at 2022-06-25 15:49:04.302264
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('anything') == True


# Generated at 2022-06-25 15:49:11.666282
# Unit test for function config
def test_config():
    # Set letter_case
    letter_case_input = "snake_case"
    letter_case_output = "snake_case"
    assert config(letter_case=letter_case_input)['dataclasses_json']['letter_case'] == letter_case_output

    # Set undefined
    undefined_input = "RAISE"
    undefined_output = Undefined.RAISE
    assert config(undefined=undefined_input)['dataclasses_json']['undefined'] == undefined_output

    # Set encoder/decoder
    encoder_input = "some_encoder"
    encoder_output = "some_encoder"
    assert config(encoder=encoder_input)['dataclasses_json']['encoder'] == encoder_output


# Generated at 2022-06-25 15:49:12.987609
# Unit test for function config
def test_config():
    cls_name = config()
    assert cls_name == {}



# Generated at 2022-06-25 15:49:15.709397
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dict_0 = config()
    dict_1 = config(exclude=Exclude.ALWAYS)
    assert dict_0 == dict_1


# Generated at 2022-06-25 15:49:21.206611
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # TODO: write your own unit test
    assert True


# Generated at 2022-06-25 15:49:22.222845
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    # TODO: add test
    pass


# Generated at 2022-06-25 15:49:23.700959
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    """
    Test for method ALWAYS of class Exclude.
    """
    obj = Exclude()
    assert obj.ALWAYS() == True


# Generated at 2022-06-25 15:49:33.363837
# Unit test for function config
def test_config():
    dict_0 = config()
    dict_1 = {'dataclasses_json': {}}
    assert dict_0 == dict_1

    dict_2 = config(encoder={})
    dict_3 = {'dataclasses_json': {'encoder': {}}}
    assert dict_2 == dict_3

    dict_4 = config(decoder={})
    dict_5 = {'dataclasses_json': {'decoder': {}}}
    assert dict_4 == dict_5

    dict_6 = config(mm_field={})
    dict_7 = {'dataclasses_json': {'mm_field': {}}}
    assert dict_6 == dict_7

    dict_8 = config(letter_case=lambda x: str)

# Generated at 2022-06-25 15:49:35.528638
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    E = Exclude()
    E.ALWAYS(1)
    E.ALWAYS(True)
    E.ALWAYS(None)


# Generated at 2022-06-25 15:49:39.190979
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER('str') == False


# Generated at 2022-06-25 15:49:40.388111
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    EXCLUDE = Exclude.ALWAYS
    assert EXCLUDE("")

# Generated at 2022-06-25 15:49:42.510937
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_Exclude_NEVER_0()
    test_Exclude_NEVER_1()
    test_Exclude_NEVER_2()


# Generated at 2022-06-25 15:49:43.587409
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dict_0 = config(exclude = Exclude.ALWAYS)


# Generated at 2022-06-25 15:49:44.388945
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    print(_GlobalConfig.NEVER())

# Generated at 2022-06-25 15:49:53.539742
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS('abc') == True


# Generated at 2022-06-25 15:49:54.560754
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(True) == False


# Generated at 2022-06-25 15:49:55.932087
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(1)


# Generated at 2022-06-25 15:49:57.015893
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    ret_value = Exclude.NEVER(0)
    assert ret_value == False


# Generated at 2022-06-25 15:49:57.891565
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-25 15:49:58.700367
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-25 15:50:04.151805
# Unit test for function config
def test_config():
    
    # Test 0: test if the config function returns a dictionary
    # Expected behavior:
    # The config function returns an empty dictionary if no arguments are passed in
    config_result_0 = test_case_0()
    assert isinstance(config_result_0, dict)
    
    
    
    
    


    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    

# Generated at 2022-06-25 15:50:06.193633
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)



# Generated at 2022-06-25 15:50:07.411666
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    variable_0 = Exclude.NEVER()


# Generated at 2022-06-25 15:50:10.713145
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    import json
    import marshmallow as mm
    from dataclasses_json import config, DataClassJsonMixin, typed_encoder

    @config(mm_field=mm.fields.Integer(dump_only=True))
    @dataclasses.dataclass
    class A(DataClassJsonMixin):
        a: int = 0

    assert typed_encoder(A(a=1)) == {'a': 1}
    assert typed_encoder(A(a=1), exclude=Exclude.NEVER) == {'a': 1}



# Generated at 2022-06-25 15:50:28.635231
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    """
    Unit test for method NEVER of class Exclude
    """
    assert (Exclude.NEVER("hello") == False)


# Generated at 2022-06-25 15:50:30.214113
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(2) == True
    assert Exclude.ALWAYS(0.5) == True


# Generated at 2022-06-25 15:50:31.389774
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-25 15:50:32.965125
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    instance = Exclude.NEVER
    truth = instance(0)
    assert truth is False


# Generated at 2022-06-25 15:50:33.619805
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(None) == False

# Generated at 2022-06-25 15:50:41.270016
# Unit test for function config
def test_config():
    dict_0 = config()
    dict_1 = config(metadata={'a': 1, 'b': 2})
    dict_2 = config(encoder=Encoders.encode_default)
    dict_3 = config(metadata={'a': 1, 'b': 2}, encoder=Encoders.encode_default)
    dict_4 = config(metadata={'a': 1, 'b': 2}, encoder=Encoders.encode_default, mm_field=Integer())
    dict_5 = config(metadata={'a': 1, 'b': 2}, encoder=Encoders.encode_default, mm_field=Integer(), undefined=Undefined.EXCLUDE)

# Generated at 2022-06-25 15:50:46.232933
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    test_obj = Exclude
    assert test_obj.NEVER("test") == False


# Generated at 2022-06-25 15:50:48.409814
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1)
    assert Exclude.ALWAYS(7.2)
    assert Exclude.ALWAYS(True)
    assert Exclude.ALWAYS(False)


# Generated at 2022-06-25 15:50:51.273541
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    dict_0 = config()
    dict_1 = config(exclude=Exclude.NEVER)
    # Expected: True
    bool_0 = dict_0 == dict_1


# Generated at 2022-06-25 15:50:52.081945
# Unit test for function config
def test_config():
    assert test_case_0() == {'dataclasses_json': {}}

# Generated at 2022-06-25 15:51:25.689139
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    list_variable_0 = list()
    assert True == Exclude.ALWAYS(list_variable_0)


# Generated at 2022-06-25 15:51:26.783684
# Unit test for function config
def test_config():
    assert not config().items()



# Generated at 2022-06-25 15:51:27.741792
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert not Exclude.NEVER(1)


# Generated at 2022-06-25 15:51:28.880724
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    # Returns True if the field is always excluded
    assert Exclude.NEVER('field') == True


# Generated at 2022-06-25 15:51:29.928746
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(1) == True


# Generated at 2022-06-25 15:51:33.074645
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    dict_0 = {0: 0, 1: 1, 2: 2}
    list_0 = [Exclude.NEVER(dict_0), True, True, True]

    for value in dict_0.values():
        list_0.append(Exclude.NEVER(value))

    assert list_0 == [False, True, True, True, False, False, False]


# Generated at 2022-06-25 15:51:41.355766
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False
    assert Exclude.NEVER(0) == False
    assert Exclude.NEVER('a') == False
    assert Exclude.NEVER('') == False
    assert Exclude.NEVER([]) == False
    assert Exclude.NEVER(()) == False
    assert Exclude.NEVER({}) == False
    assert Exclude.NEVER(None) == False
    assert Exclude.NEVER(object) == False
    assert Exclude.NEVER(True) == False
    assert Exclude.NEVER(False) == False


# Generated at 2022-06-25 15:51:42.763386
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert(Exclude.ALWAYS(0) == True)
    assert(Exclude.ALWAYS("test") == True)


# Generated at 2022-06-25 15:51:43.725189
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) is True
    assert Exclude.ALWAYS(False) is True


# Generated at 2022-06-25 15:51:48.456400
# Unit test for function config
def test_config():
    dict_1 = config()
    assert(len(dict_1)==1)
    assert(len(dict_1['dataclasses_json'])==0)
    dict_2 = config(field_name = 'hello')
    assert(len(dict_2)==1)
    assert(len(dict_2['dataclasses_json'])==1)
    assert(dict_2['dataclasses_json']['letter_case']('field_name')=='hello')
    dict_3 = config(undefined = 'RAISE')
    assert(len(dict_3)==1)
    assert(len(dict_3['dataclasses_json'])==1)
    assert(dict_3['dataclasses_json']['undefined']==Undefined.RAISE)

# Generated at 2022-06-25 15:52:53.800251
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    result = Exclude.ALWAYS(0)
    assert result



# Generated at 2022-06-25 15:52:58.856191
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(Undefined.RAISE) == False
    assert Exclude.NEVER(Undefined.EXCLUDE) == False
    assert Exclude.NEVER(Undefined.INCLUDE) == False
    assert Exclude.NEVER(Undefined.TOLERATE) == False
    assert Exclude.NEVER(Undefined.BYPASS) == False


# Generated at 2022-06-25 15:53:00.152388
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    x = Exclude.ALWAYS
    assert(Exclude.ALWAYS(5) == True)


# Generated at 2022-06-25 15:53:02.633689
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dict_0 = dict(age=10, name='Alice')
    assert Exclude.ALWAYS(dict_0) is True


# Generated at 2022-06-25 15:53:03.567589
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert True == Exclude.NEVER("")


# Generated at 2022-06-25 15:53:05.413749
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert config() == {}
    assert config() == {"dataclasses_json": {}}
    assert Exclude.NEVER("") == False
    assert Exclude.ALWAYS("") == True
    assert Exclude.NEVER("hello") == False
    assert Exclude.ALWAYS("hello") == True


# Generated at 2022-06-25 15:53:06.258360
# Unit test for method NEVER of class Exclude
def test_Exclude_NEVER():
    assert Exclude.NEVER(1) == False


# Generated at 2022-06-25 15:53:07.612569
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(0)


# Generated at 2022-06-25 15:53:13.274461
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    dict_0 = Exclude.ALWAYS
    dict_1 = dict_0(1)
    assert dict_1 is True


# Generated at 2022-06-25 15:53:14.299501
# Unit test for method ALWAYS of class Exclude
def test_Exclude_ALWAYS():
    assert Exclude.ALWAYS(True) == True
