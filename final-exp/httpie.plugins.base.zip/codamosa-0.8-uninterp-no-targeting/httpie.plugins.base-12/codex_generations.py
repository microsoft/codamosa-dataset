

# Generated at 2022-06-21 14:34:25.473119
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPluginTester1(TransportPlugin):
        def get_adapter(self):
            pass

    class TransportPluginTester2(TransportPlugin):
        pass

    t1 = TransportPluginTester1()
    t2 = TransportPluginTester2()

    try:
        t1.get_adapter()
    except NotImplementedError:
        pass
    else:
        raise AssertionError

    try:
        t2.get_adapter()
    except NotImplementedError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-21 14:34:29.456367
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class MyTransportPlugin(TransportPlugin):
        prefix = 'https+unix'

        def get_adapter(self):
            pass

    assert MyTransportPlugin().get_adapter()



# Generated at 2022-06-21 14:34:31.351482
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converterPlugin = ConverterPlugin('hello')
    assert converterPlugin.mime == 'hello'


# Generated at 2022-06-21 14:34:34.040989
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    text=""
    assert (kwargs['format_options'])
    assert (FormatterPlugin.format_headers(headers))
    assert (FormatterPlugin.format_body(content , mime))

# Generated at 2022-06-21 14:34:38.154379
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter = FormatterPlugin(**{'format_options': 'test'})
    assert formatter.enabled == True
    assert formatter.kwargs == {'format_options' : 'test'}
    assert formatter.format_options == 'test'

# Generated at 2022-06-21 14:34:41.624787
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPluginAuth(AuthPlugin):
        auth_type = 'auth'

        def get_auth(self, username=None, password=None):
            print(username)
            print(password)

    up = AuthPluginAuth()
    up.get_auth(username='liuyu', password='123456')


# Generated at 2022-06-21 14:34:42.540522
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    assert BasePlugin().name is None

# Generated at 2022-06-21 14:34:45.465357
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    output = FormatterPlugin.format_headers('Test\nHeader: Value\nConnection: close\n\n')
    assert output == 'Test\nHeader: Value\nConnection: close\n'



# Generated at 2022-06-21 14:34:52.947731
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    # Test 1
    env = Environment()
    headers = 'HTTP/1.1 200 OK'
    content = 'Hello World!'
    mime = 'application/json'
    # as the formatter is a dummy, it should return the same value
    formatter = Formatter()
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK'
    assert formatter.format_body(content, mime) == 'Hello World!'

# Generated at 2022-06-21 14:34:57.027553
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    try:
        BasePlugin()
    except NotImplementedError as e:
        raise AssertionError("BasePlugin() raised NotImplementedError")
    except Exception as e:
        raise AssertionError("BasePlugin() raised exception " + str(e))



# Generated at 2022-06-21 14:35:06.391541
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TheConverter(ConverterPlugin):
        def __init__(self, mime):
            super(TheConverter, self).__init__(mime)

        def convert(self, content_bytes):
            return str(content_bytes, encoding='utf-8')

        @classmethod
        def supports(cls, mime):
            return mime in ["application/json", "application/xml"]

    plugin = TheConverter("application/json")
    content_bytes = b"this is the content"
    assert plugin.convert(content_bytes) == "this is the content"



# Generated at 2022-06-21 14:35:11.026659
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.compat import is_windows

# Generated at 2022-06-21 14:35:15.912861
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    with pytest.raises(NotImplementedError):
        class TestTransportPlugin(TransportPlugin):
            pass

        tp = TestTransportPlugin()
        print(tp.get_adapter())



# Generated at 2022-06-21 14:35:25.528791
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPluginEx(AuthPlugin):
        def get_auth(self, username=None, password=None):
            if self.raw_auth:
                return tuple(self.raw_auth.split(':'))

    # If username:password are parsed,
    # then get_auth receives them as `username, password` arguments.
    http_auth = AuthPluginEx()
    assert http_auth.get_auth('some-username', 'some-password') == \
        ('some-username', 'some-password')

    # If credentials are not parsed and instead `raw_auth`
    # contains the raw value of `-a` (as a string), then...
    http_auth.raw_auth = 'some-username:some-password'
    assert http_auth.get_auth() == ('some-username', 'some-password')

   

# Generated at 2022-06-21 14:35:29.617184
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    """
    Test constructor of class FormatterPlugin
    """
    env = Environment()
    format_options = []
    formatterPlugin = FormatterPlugin(env, format_options=format_options)
    assert formatterPlugin is not None, "Constructor of FormatterPlugin returned None."

# Generated at 2022-06-21 14:35:33.139828
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    a: AuthPlugin = AuthPlugin()
    try:
        a.get_auth()
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-21 14:35:36.384975
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(AuthPlugin):
        auth_type = 'abc'
    plugin = AuthPlugin()
    assert plugin.auth_type == 'abc'


# Generated at 2022-06-21 14:35:43.469159
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class MyAuth(AuthPlugin):

        def get_auth(self, username=None, password=None):
            pass

    class MyFormatter(FormatterPlugin):

        def format_headers(self, headers: str) -> str:
            pass

        def format_body(self, content: str, mime: str) -> str:
            pass

    class MyTransport(TransportPlugin):

        def get_adapter(self):
            pass

    bp = BasePlugin()
    with pytest.raises(NotImplementedError):
        MyFormatter({}, env=None)
    with pytest.raises(NotImplementedError):
        MyAuth()
    with pytest.raises(NotImplementedError):
        MyTransport()

# Generated at 2022-06-21 14:35:54.021865
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    """
    Test the method format_headers of class FormatterPlugin
    """
    test_headers_1 = "HTTP/1.1 200 OK\r\n\
    Date: Mon, 27 Jul 2009 12:28:53 GMT\r\n\
    Server: Apache\r\n\
    Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\n\
    ETag: \"34aa387-d-1568eb00\"\r\n\
    Accept-Ranges: bytes\r\n\
    Content-Type: text/plain\r\n\
    Content-Length: 51\r\n\r\n"

# Generated at 2022-06-21 14:35:55.623904
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    AuthPlugin()


# Generated at 2022-06-21 14:36:01.837604
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test-auth'

        def get_auth(self, username=None, password=None):
            return 'test_auth'

    plugin = TestAuthPlugin()
    assert plugin.auth_type == 'test-auth'
    
    assert plugin.get_auth() == 'test_auth'

# Generated at 2022-06-21 14:36:05.046097
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class ExampleTransport(TransportPlugin):

        prefix = 'foo'

        def get_adapter(self):
            return 'foo'

    assert isinstance(ExampleTransport().get_adapter(), str)

# Generated at 2022-06-21 14:36:06.034583
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    pass
    

# Generated at 2022-06-21 14:36:07.356066
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    test_c = ConverterPlugin(".bat")


# Generated at 2022-06-21 14:36:09.478685
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    obj = AuthPlugin()
    assert obj


# Generated at 2022-06-21 14:36:14.433107
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():

    test_ConverterPlugin = ConverterPlugin('application/json')
    assert test_ConverterPlugin.convert('<html><body>Hello world!</body></html>') == False
    test_ConverterPlugin.mime = 'text/html'
    assert test_ConverterPlugin.convert('<html><body>Hello world!</body></html>')  == True

# Generated at 2022-06-21 14:36:18.306011
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    import httpie.output

    f = httpie.output.get_formatter('Custom Formatter')({}, format_options=None, is_tty=True)
    assert f.group_name == 'format'
    assert f.enabled
    assert f.kwargs
    assert f.format_options is None



# Generated at 2022-06-21 14:36:20.378032
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    assert FormatterPlugin().enabled is True
    assert FormatterPlugin().kwargs == {}
    assert FormatterPlugin().format_options == {}



# Generated at 2022-06-21 14:36:27.872892
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    print("Checking method format_body of class FormatterPlugin...")
    fp = FormatterPlugin(env={"a": "b"}, format_options={"format": "json"})
    return_value = fp.format_body(content=b"{'a': 1}".decode(), mime="application/json")
    if return_value != "{'a': 1}":
        raise AssertionError("Returned value does not match expected value")
    print('Passed!')

# Generated at 2022-06-21 14:36:29.400094
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    f = FormatterPlugin()
    assert f.enabled is True
    assert f.kwargs is None
    assert f.format_options is None

# Generated at 2022-06-21 14:36:36.227979
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    a = AuthPlugin()
    assert a.auth_type is None and a.auth_require is True and a.auth_parse is True and a.netrc_parse is False and a.prompt_password is True and a.raw_auth is None


# Generated at 2022-06-21 14:36:37.514991
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    pass


# Generated at 2022-06-21 14:36:42.865682
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    import httpie.plugins
    class TestAuthPlugin(AuthPlugin):
        name = 'TestAuthPlugin'
        auth_type = 'test-auth'

        def get_auth(self, username=None, password=None):
            return None
    httpie.plugins.auth_basic = TestAuthPlugin
    tt = httpie.plugins.auth_basic
    assert tt.name=='TestAuthPlugin'
    assert tt.auth_type=='test-auth'


# Generated at 2022-06-21 14:36:43.644790
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
	pass


# Generated at 2022-06-21 14:36:47.309359
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        
        def convert(self, content_bytes):
            return content_bytes.decode()
        
        @classmethod
        def supports(cls, mime):
            if mime == 'test':
                return True
            else:
                return False
    
    res = TestConverterPlugin('test')
    assert res.mime == 'test'

# Generated at 2022-06-21 14:36:48.571323
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter = FormatterPlugin()
    assert formatter != None


# Generated at 2022-06-21 14:36:54.253060
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter = FormatterPlugin()
    try:
        formatter.format_body('some content', '')
    except NotImplementedError:
        print ("You need to implement the 'format_body' method")

    print ("Method format_body of class FormatterPlugin is implemented")


test_FormatterPlugin_format_body()

# Generated at 2022-06-21 14:37:01.249686
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    from httpie.plugins import ConverterPlugin
    from httpie.output.streams import get_binary_stream


    class ExampleConverter(ConverterPlugin):
        @classmethod
        def supports(mime):
            return False

        def convert(content_bytes):
            return content_bytes

    example_converter = ExampleConverter(mime='text/plain')
    # not supported
    assert example_converter.convert(b'/r/') == b'/r/'



# Generated at 2022-06-21 14:37:04.002121
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    """
    Test function for method get_auth of class AuthPlugin
    """
    pass


# Generated at 2022-06-21 14:37:08.520422
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class DummyConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return '<converted>'

        @classmethod
        def supports(cls, mime):
            return True

    p = DummyConverterPlugin(mime='*/*')
    assert p.convert('<content>') == '<converted>'


# Generated at 2022-06-21 14:37:23.713061
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class Dummy(ConverterPlugin):
        def convert(self, content_bytes):
            data = content_bytes
            assert isinstance(data, bytes)
            return data
        @classmethod
        def supports(cls, mime):
            return True
    class Environment:
        def __init__(self):
            self.stdout = sys.stdout
    e = Environment()
    a = {'headers': {'Content-Type': 'application/json'}, 'content': b'{"key": "value"}'}
    r = Dummy.supports(a['headers']['Content-Type'])
    r = Dummy(a['headers']['Content-Type']).convert(a['content'])

# Generated at 2022-06-21 14:37:26.221633
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    t = TransportPlugin()
    assert t.prefix is None
    r = t.get_adapter()


# Generated at 2022-06-21 14:37:31.114342
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    from httpie.plugins import builtin


    class TestTransportPlugin(TransportPlugin):
        prefix = 'tst+'

        def get_adapter(self):
            return httpie.plugins.builtin.HTTPAdapter()

    test_plugin = TestTransportPlugin()
    assert test_plugin.get_adapter() == builtin.HTTPAdapter()

# Generated at 2022-06-21 14:37:34.053731
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class BasePlugin_instance(BasePlugin):
        pass

    BasePlugin_instance()


if __name__ == '__main__':
    test_BasePlugin()

# Generated at 2022-06-21 14:37:35.113274
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    return


# Generated at 2022-06-21 14:37:45.628635
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin(httpie.plugins.base.TransportPlugin):
        prefix = 'test'
        def get_adapter(self):
            return None
    transport = TransportPlugin()
    assert transport.prefix == 'test'

    class BaseAdapter(object):
        def __init__(self, *args, **kwargs):
            pass

    class TestAdapter(BaseAdapter):
        def __init__(self, *args, **kwargs):
            BaseAdapter.__init__(self, *args, **kwargs)

    class TestAdapterPlugin(httpie.plugins.base.TransportPlugin):
        prefix = 'test'
        def get_adapter(self):
            return TestAdapter()

    transport = TestAdapterPlugin()
    assert transport.prefix == 'test'
    assert transport.get_adapter().__class__ is TestAdapter

# Generated at 2022-06-21 14:37:55.280079
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class MyAuthPlugin(AuthPlugin):
        auth_type = "my-auth"
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None
        name = "My auth"
        description = "A my-auth plugin for python"
        package_name = 'httpie-my-auth'
        def get_auth(self, username=None, password=None):
            pass

    plugin = MyAuthPlugin()

    assert plugin.auth_type == "my-auth"
    assert plugin.auth_require
    assert plugin.auth_parse
    assert not plugin.netrc_parse
    assert plugin.prompt_password
    assert plugin.raw_auth == None
    assert plugin.name == "My auth"

# Generated at 2022-06-21 14:38:01.596868
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class _AuthPlugin(AuthPlugin):
        auth_type = ''

        def get_auth(self, username=None, password=None):
            return username, password

    plugin = _AuthPlugin()
    assert plugin.get_auth('user', 'pass') == ('user', 'pass')

if __name__=="__main__":
    test_AuthPlugin_get_auth()

# Generated at 2022-06-21 14:38:05.359384
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class ConverterTest(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return 'application/json' in mime
    return ConverterTest('application/json')

# Generated at 2022-06-21 14:38:13.384767
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class ConverterPluginSub(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            pass

        @classmethod
        def supports(cls, mime):
            pass

    converterPlugin = ConverterPluginSub("text/plain")
    assert converterPlugin.mime == "text/plain"
    assert isinstance(converterPlugin, ConverterPlugin)
    assert isinstance(converterPlugin, BasePlugin)


# Generated at 2022-06-21 14:38:33.415557
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    env = Environment()
    plugin = FormatterPlugin(env=env, format_options=None)
    assert plugin.enabled == True
    assert plugin.kwargs == {'format_options': None}
    assert plugin.format_options is None
    # Test that an exception is thrown when missing format_options.
    exception_raised = False
    try:
        plugin = FormatterPlugin(env=env)
    except KeyError:
        exception_raised = True
    assert exception_raised



# Generated at 2022-06-21 14:38:35.647503
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    t = TransportPlugin()
    print('TransportPlugin', t.prefix, t.package_name, t.name, t.description)


# Generated at 2022-06-21 14:38:39.820128
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class test_ConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

    test_ConverterPlugin('test')

    assert test_ConverterPlugin != 'test'


# Generated at 2022-06-21 14:38:41.924452
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    # Arrange
    adapter = TransportPlugin()
    # Act
    # Assert
    assert adapter.get_adapter() == NotImplementedError


# Generated at 2022-06-21 14:38:47.139184
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    """
    test AuthPlugin.get_auth

    """
    class ClassPluginAuth(AuthPlugin):
        """
        This is a subclass of AuthPlugin, but it doesn't implement get_auth
        """
        def get_auth(self, username=None, password=None):
            pass

    class PluginAuth(AuthPlugin):
        def get_auth(self, username=None, password=None):
            pass

    instance = ClassPluginAuth()
    s = str(instance)
    instance = PluginAuth()
    s = str(instance)


# Generated at 2022-06-21 14:38:49.347621
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():

    assert issubclass(TransportPlugin, BasePlugin)



# Generated at 2022-06-21 14:38:56.011747
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    # auth_type,auth_require,auth_parse,netrc_parse,prompt_password,raw_auth
    b = AuthPlugin()
    assert b.auth_type is None
    assert b.auth_require == True
    assert b.auth_parse == True
    assert b.netrc_parse == False
    assert b.prompt_password == True
    assert b.raw_auth is None
    assert b.package_name is None


# Generated at 2022-06-21 14:38:57.389362
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    """
    This test for testing the method get_adapter of class TransportPlugin
    """
    Adapter = TransportPlugin()
    assert Adapter.get_adapter()



# Generated at 2022-06-21 14:38:59.563381
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        def get_adapter(self):
            pass
    TestTransportPlugin()


# Generated at 2022-06-21 14:39:07.277456
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class MyConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.upper()

        @classmethod
        def supports(cls, mime):
            return mime == 'convert/me'

    class MyFormatterPlugin:
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = MyConverterPlugin('convert/me')
    formatter = MyFormatterPlugin()
    assert plugin.convert(b'foo') == b'FOO'
    assert plugin.convert(b'foo').decode() == 'FOO'
    assert formatter.format_body(plugin.convert(b'foo').decode(), 'foo') == 'FOO'

# Generated at 2022-06-21 14:39:38.537792
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class myFormatter(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    env = Environment(
        stdin=io.BytesIO(),
        stdout=io.BytesIO()
    )
    myFormatter(env=env,
                format_options={'A': 1, 'B': 2, 'C': 3})
    # If the code runs to here, it means the constructor is fine.



# Generated at 2022-06-21 14:39:45.525328
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin(BasePlugin):
        prefix = None

        def get_adapter(self):
            raise NotImplementedError()

    class AdapterTest(RequestsUnixSocketAdapter):
        def send(self, request, **kwargs):
            return request

    class TransportPluginTest(TransportPlugin):
        prefix = "unix://"

        def get_adapter(self):
            return AdapterTest()

    assert TransportPluginTest().get_adapter() is not None



# Generated at 2022-06-21 14:39:50.530027
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    mime = 'text/msgpack'
    converter = ConverterPlugin(mime)
    content_bytes = msgpack.packb({'text': 'foo'})
    expected = [{b'text': b'foo'}]
    assert converter.convert(content_bytes) == expected


# Generated at 2022-06-21 14:39:55.832740
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

        def format_body(self, content, mime):
            return content

    tfp = TestFormatterPlugin(format_options=None)
    assert tfp.format_body("test", mime="text/plain") == "test"



# Generated at 2022-06-21 14:39:58.279290
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():

    class MyTransport(TransportPlugin):
        prefix = 'https+unix'

    assert MyTransport.prefix == 'https+unix'


# Generated at 2022-06-21 14:40:03.782424
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class ConverterPlugin(BasePlugin):

        def __init__(self, mime):
            self.mime = mime

        def convert(self, content_bytes):
            # Some dummy conversion
            return content_bytes.decode() + ' converted'

        @classmethod
        def supports(cls, mime):
            return mime == 'foo/bar'

    converter = ConverterPlugin('foo/bar')
    assert converter.convert(b'content') == 'content converted'



# Generated at 2022-06-21 14:40:08.900703
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    import requests
    import requests_ntlm

    class AuthPluginTest(AuthPlugin):
        def get_auth(self, username=None, password=None):
            return requests_ntlm.HttpNtlmAuth(username, password)

    plugin = AuthPluginTest()
    assert isinstance(plugin, Plugin)
    assert isinstance(plugin, AuthPlugin)
    assert isinstance(plugin.get_auth(), requests.auth.AuthBase)



# Generated at 2022-06-21 14:40:09.901628
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    assert 0



# Generated at 2022-06-21 14:40:13.934242
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(TransportPlugin):
        prefix = 'unix'

        def get_adapter(self):
            return None

    assert TransportPlugin.prefix == 'unix'
    assert TransportPlugin.get_adapter(TransportPlugin) is None

# Generated at 2022-06-21 14:40:16.912694
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class UnixSocketTransportPlugin(TransportPlugin):
        prefix = 'unix'

        def get_adapter(self):
            from httpie.unixsocket import UnixAdapter
            return UnixAdapter
    plugin.load_transport_plugin(UnixSocketTransportPlugin)


# Generated at 2022-06-21 14:41:24.548485
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Test FormatterPlugin.format_body()
    fp = FormatterPlugin()
    assert fp.format_body("foo", "text/plain") == "foo"

# Generated at 2022-06-21 14:41:27.984959
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    try:
        # This should fail
        cp = ConverterPlugin('text/html')

    except NotImplementedError:
        print("Test passed")
    else:
        print("Test failed")



# Generated at 2022-06-21 14:41:29.125823
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()


# Generated at 2022-06-21 14:41:37.216825
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    print('Testing AuthPlugin.get_auth()')

    class AuthPlugin_get_auth(AuthPlugin):
        """
        Dummy AuthPlugin class for testing AuthPlugin.get_auth()
        """
        def get_auth(self, username=None, password=None):
            return 'AuthPlugin.get_auth() was called'

    auth = AuthPlugin_get_auth()
    res = auth.get_auth()

    if res == 'AuthPlugin.get_auth() was called':
        print('OK\n')
    else:
        print('Error: expected response to be "AuthPlugin.get_auth() was called" but got "' + res + '"\n')



# Generated at 2022-06-21 14:41:41.254947
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin = AuthPlugin()
    print("\n Testing get_auth() method of class AuthPlugin :")
    print("\n The Auth Plugin is :", auth_plugin.name)
    try:
        auth_plugin.get_auth("abc", "abc")
    except Exception as e:
        print("\n Error in AuthPlugin_get_auth():", e)


# Generated at 2022-06-21 14:41:45.294645
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import builtin
    f = builtin.JSONCompactFormatter()
    import json
    assert f.format_body(json.dumps(['das']), 'application/json') == '["das"]'

# Generated at 2022-06-21 14:41:48.514943
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    assert base_plugin.name == None
    assert base_plugin.description == None
    assert base_plugin.package_name == None


# Generated at 2022-06-21 14:41:52.265211
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(httpie.plugins.AuthPlugin):
        name = 'my auth'
        auth_type = 'my-auth'

        def get_auth(self, username=None, password=None):
            return requests.auth.HTTPBasicAuth(username, password)
    print(AuthPlugin)

# Generated at 2022-06-21 14:41:54.076347
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class cp(ConverterPlugin):
         pass
    cp('test_class')

# Generated at 2022-06-21 14:41:54.615516
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    b = BasePlugin()