

# Generated at 2022-06-17 20:56:15.313003
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test_test'


# Generated at 2022-06-17 20:56:20.726992
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('abc', 'text/plain') == 'ABC'


# Generated at 2022-06-17 20:56:29.414196
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyURLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import PrettyXMLFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawURLEncodedFormatter
    from httpie.plugins.builtin import RawXMLFormatter
    from httpie.plugins.builtin import PrettyRawJSONFormatter
    from httpie.plugins.builtin import PrettyRawURLEncodedFormatter
    from httpie.plugins.builtin import PrettyRawXMLFormatter

# Generated at 2022-06-17 20:56:33.282971
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 20:56:37.979912
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('a', 'text/plain') == 'b'

# Generated at 2022-06-17 20:56:47.743045
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import ColorsFormatter
    from httpie.output.formatters.format import Formatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.html import HTMLFormatter
    from httpie.output.formatters.raw import RawFormatter
    from httpie.output.formatters.terminal import TerminalFormatter
    from httpie.output.formatters.xml import XMLFormatter
    from httpie.output.formatters.pretty import PrettyFormatter
    from httpie.output.formatters.ugly import UglyFormatter
    from httpie.output.formatters.verbose import VerboseFormatter

# Generated at 2022-06-17 20:57:00.590510
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers + '\n'

    class MyFormatterPlugin2(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers + '\n'

    class MyFormatterPlugin3(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers + '\n'

    class MyFormatterPlugin4(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers + '\n'

    class MyFormatterPlugin5(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers + '\n'


# Generated at 2022-06-17 20:57:06.693260
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: 1\nb: 2') == 'a: 1\n\tb: 2'



# Generated at 2022-06-17 20:57:14.307787
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import PrettyHTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import PrettyImageFormatterPlugin

# Generated at 2022-06-17 20:57:21.472306
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPluginTest(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    formatter = FormatterPluginTest(format_options={})
    assert formatter.format_headers('Content-Type: text/html\r\n') == 'Content-Type: text/html\n'


# Generated at 2022-06-17 20:57:26.668631
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')
    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:57:29.105226
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test_content', 'test_mime') == 'test_content'



# Generated at 2022-06-17 20:57:33.730805
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:57:37.597969
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:57:42.654466
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "") == "test"


# Generated at 2022-06-17 20:57:48.431572
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin().format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''



# Generated at 2022-06-17 20:57:56.001427
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 20:58:00.801265
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    env = Environment()
    env.config['format'] = 'TestFormatterPlugin'
    env.config['format_options'] = {}
    formatter = env.get_formatter()

# Generated at 2022-06-17 20:58:05.784906
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "test") == "test"


# Generated at 2022-06-17 20:58:13.608626
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')


# Generated at 2022-06-17 20:58:18.190332
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 20:58:21.231907
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_body("test", "test") == "test"


# Generated at 2022-06-17 20:58:25.104114
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    assert TestFormatterPlugin(format_options={}).format_headers('test') == 'test'


# Generated at 2022-06-17 20:58:31.829808
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    env = Environment()
    formatter = TestFormatterPlugin(env=env, format_options=None)
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == headers


# Generated at 2022-06-17 20:58:36.120393
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_body('\n', '') == '\n\t'


# Generated at 2022-06-17 20:58:38.978438
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 20:58:41.568533
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('test', 'TEST')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'TEST'


# Generated at 2022-06-17 20:58:45.614090
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 20:58:47.324615
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_headers("test") == "test"


# Generated at 2022-06-17 20:58:53.707966
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body("test", "text/html") == "test"



# Generated at 2022-06-17 20:59:10.971337
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super(TestFormatterPlugin, self).__init__(**kwargs)

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.enabled == True
    assert test_formatter_plugin.kwargs == {'format_options': {}}
    assert test_formatter_plugin.format_options == {}


# Generated at 2022-06-17 20:59:18.185271
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = None
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            raise NotImplementedError()

    auth = AuthPlugin()
    assert auth.auth_type == None
    assert auth.auth_require == True
    assert auth.auth_parse == True
    assert auth.netrc_parse == False
    assert auth.prompt_password == True
    assert auth.raw_auth == None


# Generated at 2022-06-17 20:59:23.523846
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 20:59:28.893842
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        auth_type = 'test'
        auth_parse = True

        def get_auth(self, username=None, password=None):
            return username, password

    plugin = AuthPlugin()
    assert plugin.get_auth('foo', 'bar') == ('foo', 'bar')
    assert plugin.get_auth() == (None, None)



# Generated at 2022-06-17 20:59:33.753517
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    test_formatter_plugin = TestFormatterPlugin(format_options=None)
    assert test_formatter_plugin.enabled is True
    assert test_formatter_plugin.kwargs == {'format_options': None}
    assert test_formatter_plugin.format_options is None



# Generated at 2022-06-17 20:59:36.690309
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    assert TestTransportPlugin().prefix == 'test'
    assert TestTransportPlugin().get_adapter() == 'test'


# Generated at 2022-06-17 20:59:38.363897
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin(BasePlugin):
        def get_adapter(self):
            return "adapter"

    assert TransportPlugin().get_adapter() == "adapter"


# Generated at 2022-06-17 20:59:45.566404
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'hello') == 'hello'


# Generated at 2022-06-17 20:59:58.383173
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    import httpie.plugins
    import httpie.output.formatters
    import httpie.output.streams
    import httpie.core
    import httpie.cli
    import httpie.config
    import httpie.plugins.builtin

    # Create an instance of class Environment

# Generated at 2022-06-17 21:00:00.613419
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:00:12.542717
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        pass

    plugin = TestPlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None


# Generated at 2022-06-17 21:00:15.706592
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class MyTransportPlugin(TransportPlugin):
        prefix = 'my'

        def get_adapter(self):
            return 'my_adapter'

    plugin = MyTransportPlugin()
    assert plugin.get_adapter() == 'my_adapter'



# Generated at 2022-06-17 21:00:26.680421
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})

# Generated at 2022-06-17 21:00:30.342787
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(BasePlugin):
        prefix = None

        def get_adapter(self):
            raise NotImplementedError()

    tp = TransportPlugin()
    assert tp.prefix is None


# Generated at 2022-06-17 21:00:36.695408
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('application/json')
    assert plugin.mime == 'application/json'


# Generated at 2022-06-17 21:00:40.348850
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "text/plain") == "test"

# Generated at 2022-06-17 21:00:44.095064
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        pass

    plugin = TestPlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None


# Generated at 2022-06-17 21:00:48.400294
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    assert TestFormatterPlugin(format_options={}).format_headers('\r\n') == '\n'


# Generated at 2022-06-17 21:00:57.231620
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class ConverterPluginTest(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            raise NotImplementedError

        @classmethod
        def supports(cls, mime):
            raise NotImplementedError

    c = ConverterPluginTest('mime')
    assert c.mime == 'mime'


# Generated at 2022-06-17 21:01:00.596205
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin_test(TransportPlugin):
        def get_adapter(self):
            return None
    assert TransportPlugin_test().get_adapter() is None


# Generated at 2022-06-17 21:01:25.869035
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    t = TestConverterPlugin('test')
    assert t.mime == 'test'



# Generated at 2022-06-17 21:01:28.499886
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test_adapter'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test_adapter'

# Generated at 2022-06-17 21:01:34.597963
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'Hello') == 'Hello'


# Generated at 2022-06-17 21:01:37.566591
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    f = FormatterPlugin(format_options={})
    assert f.enabled == True
    assert f.kwargs == {'format_options': {}}
    assert f.format_options == {}


# Generated at 2022-06-17 21:01:42.217660
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'application/atom+xml') == 'testtest'

# Generated at 2022-06-17 21:01:43.735009
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    assert FormatterPlugin(format_options={})


# Generated at 2022-06-17 21:01:49.039494
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''HTTP/1.1 200 OK
    Content-Type: application/json
    Content-Length: 2
    '''
    assert TestFormatterPlugin().format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json Content-Length: 2 '


# Generated at 2022-06-17 21:01:56.895145
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test plugin'
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None
        prefix = None

    plugin = TestPlugin()
    assert plugin.name == 'test'
    assert plugin.description == 'test plugin'
    assert plugin.auth_type == 'test'
    assert plugin.auth_require == True
    assert plugin.auth_parse == True
    assert plugin.netrc_parse == False
    assert plugin.prompt_password == True
    assert plugin.raw_auth == None
    assert plugin.prefix == None


# Generated at 2022-06-17 21:02:00.428010
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        def get_auth(self, username=None, password=None):
            return username, password

    auth = AuthPlugin()
    assert auth.get_auth(username='user', password='pass') == ('user', 'pass')

# Generated at 2022-06-17 21:02:05.349530
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '-test'

    test_plugin = TestFormatterPlugin(**{'format_options': {}})
    assert test_plugin.format_body('test', 'application/json') == 'test-test'

# Generated at 2022-06-17 21:02:50.024933
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class ConverterPlugin_test(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    test_plugin = ConverterPlugin_test('application/json')
    assert test_plugin.convert(b'{"test": "test"}') == '{"test": "test"}'


# Generated at 2022-06-17 21:03:00.912385
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test plugin'
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None
        prefix = 'test'
        group_name = 'test'

    p = TestPlugin()
    assert p.name == 'test'
    assert p.description == 'test plugin'
    assert p.auth_type == 'test'
    assert p.auth_require == True
    assert p.auth_parse == True
    assert p.netrc_parse == False
    assert p.prompt_password == True
    assert p.raw_auth == None
    assert p.prefix == 'test'
    assert p.group_name == 'test'


# Generated at 2022-06-17 21:03:05.555954
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth'
        auth_parse = False
        auth_require = False
        netrc_parse = False
        prompt_password = False

        def get_auth(self, username=None, password=None):
            return 'my-auth'

    plugin = MyAuthPlugin()
    assert plugin.get_auth() == 'my-auth'



# Generated at 2022-06-17 21:03:09.100017
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return None

    assert TestTransportPlugin().get_adapter() is None


# Generated at 2022-06-17 21:03:13.804934
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    converter = TestConverterPlugin('text/plain')
    assert converter.convert(b'foo') == 'foo'



# Generated at 2022-06-17 21:03:16.861551
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    fp = TestFormatterPlugin(format_options=None)
    assert fp.format_headers("test") == "test"


# Generated at 2022-06-17 21:03:22.726223
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options=None)
    assert plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:03:25.599938
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_formatter('json')

# Generated at 2022-06-17 21:03:32.337759
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = "Test Plugin"
        description = "This is a test plugin."
        auth_type = "test-auth"
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        prefix = "test"

    plugin = TestPlugin()
    assert plugin.name == "Test Plugin"
    assert plugin.description == "This is a test plugin."
    assert plugin.auth_type == "test-auth"
    assert plugin.auth_require == True
    assert plugin.auth_parse == True
    assert plugin.netrc_parse == False
    assert plugin.prompt_password == True
    assert plugin.prefix == "test"


# Generated at 2022-06-17 21:03:37.370819
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode()

        @classmethod
        def supports(cls, mime):
            return True

    assert TestConverterPlugin('text/plain').convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:05:04.898469
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        name = 'test'
        description = 'test'
        group_name = 'test'

    env = Environment(colors=256)
    fp = TestFormatterPlugin(env=env, format_options=None)
    assert fp.enabled is True
    assert fp.kwargs['env'] is env
    assert fp.kwargs['format_options'] is None
    assert fp.format_options is None
    assert fp.name == 'test'
    assert fp.description == 'test'
    assert fp.group_name == 'test'


# Generated at 2022-06-17 21:05:09.199541
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return None

    plugin = TestAuthPlugin()
    assert plugin.auth_type == 'test-auth'
    assert plugin.auth_require == True
    assert plugin.auth_parse == True
    assert plugin.netrc_parse == False
    assert plugin.prompt_password == True
    assert plugin.raw_auth == None


# Generated at 2022-06-17 21:05:20.301504
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import plugin_manager
    from httpie.plugins import builtin
    from httpie.plugins import builtin_plugins
    from httpie.plugins import get_plugin_manager
    from httpie.plugins import get_plugin_config
    from httpie.plugins import get_plugin_config_value
    from httpie.plugins import get_plugin_config_values
    from httpie.plugins import get_plugin_config_values_as_dict
    from httpie.plugins import get_plugin_config_value_as_bool
    from httpie.plugins import get_plugin_config_value_as_list
    from httpie.plugins import get_plugin_config_value_as_int
    from httpie.plugins import get_plugin_config_value

# Generated at 2022-06-17 21:05:24.270108
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/plain') == 'test'

# Generated at 2022-06-17 21:05:30.624369
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            return None

    auth = AuthPlugin()
    assert auth.auth_type == 'test'
    assert auth.auth_require == True
    assert auth.auth_parse == True
    assert auth.netrc_parse == False
    assert auth.prompt_password == True
    assert auth.raw_auth == None


# Generated at 2022-06-17 21:05:33.960480
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:05:39.317513
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '


# Generated at 2022-06-17 21:05:42.264376
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body("test", "text/html") == "test"



# Generated at 2022-06-17 21:05:46.003483
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:05:49.968393
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class ConverterPluginTest(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    c = ConverterPluginTest('application/json')
    assert c.mime == 'application/json'
