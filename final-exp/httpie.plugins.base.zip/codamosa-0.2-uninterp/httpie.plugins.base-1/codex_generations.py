

# Generated at 2022-06-17 20:56:11.615856
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d\n') == 'a: b\n\tc: d\n'



# Generated at 2022-06-17 20:56:16.604788
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 20:56:27.081808
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    HTTP/1.1 200 OK
    Date: Mon, 27 Jul 2009 12:28:53 GMT
    Server: Apache/2.2.14 (Win32)
    Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
    Content-Length: 88
    Content-Type: text/html
    Connection: Closed
    '''

    formatter = TestFormatterPlugin(format_options={})

# Generated at 2022-06-17 20:56:31.708007
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test'

# Generated at 2022-06-17 20:56:35.496778
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    p = TestFormatterPlugin(format_options={})
    assert p.format_body('foo', 'text/plain') == 'foo\n'



# Generated at 2022-06-17 20:56:41.310804
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == headers


# Generated at 2022-06-17 20:56:47.635214
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json

'''



# Generated at 2022-06-17 20:56:50.083970
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 20:56:57.174211
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    assert MyFormatterPlugin(format_options={}).format_headers('a: b\nc: d\n') == 'a: b c: d '


# Generated at 2022-06-17 20:57:08.679174
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPluginTest(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    HTTP/1.1 200 OK
    Server: nginx/1.10.3 (Ubuntu)
    Date: Thu, 16 May 2019 14:07:03 GMT
    Content-Type: application/json
    Content-Length: 2
    Connection: keep-alive
    Access-Control-Allow-Origin: *
    Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
    Access-Control-Allow-Headers: Content-Type, Authorization
    Access-Control-Max-Age: 1728000
    '''

# Generated at 2022-06-17 20:57:15.636440
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test\n'


# Generated at 2022-06-17 20:57:20.376079
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 20:57:24.927923
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('aaa', 'text/plain') == 'bbb'


# Generated at 2022-06-17 20:57:29.868801
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    # Test case 1
    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "application/json") == "test"

    # Test case 2
    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "application/xml") == "test"

    # Test case 3
    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "application/atom+xml") == "test"

    # Test case 4
    test_form

# Generated at 2022-06-17 20:57:33.355114
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter = FormatterPlugin()
    headers = 'Content-Type: application/json\nContent-Length: 2\n'
    assert formatter.format_headers(headers) == headers


# Generated at 2022-06-17 20:57:36.348546
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatter(FormatterPlugin):
        def format_headers(self, headers):
            return headers

    formatter = TestFormatter(format_options={})
    assert formatter.format_headers('headers') == 'headers'


# Generated at 2022-06-17 20:57:46.544705
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\t')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

# Generated at 2022-06-17 20:57:49.233876
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 20:57:55.929768
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('hello', 'mime') == 'HELLO'


# Generated at 2022-06-17 20:57:59.913448
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'test') == 'test'

# Generated at 2022-06-17 20:58:07.455283
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "") == "test"

# Generated at 2022-06-17 20:58:10.758588
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options=None).format_body("test", "test") == "test"


# Generated at 2022-06-17 20:58:21.654183
# Unit test for method format_headers of class FormatterPlugin

# Generated at 2022-06-17 20:58:26.067404
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPluginTest(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = FormatterPluginTest(format_options={})
    assert formatter.format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 20:58:32.593181
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a\nb\nc') == 'a\n\tb\n\tc'


# Generated at 2022-06-17 20:58:36.991393
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_headers("a: b\nc: d") == "a: b c: d"


# Generated at 2022-06-17 20:58:40.004865
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 20:58:42.071992
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'test') == 'test'


# Generated at 2022-06-17 20:58:45.890436
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', ' ')

    assert TestFormatterPlugin(format_options={}).format_headers('a\nb') == 'a b'



# Generated at 2022-06-17 20:58:50.642148
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'application/json') == 'test\n'



# Generated at 2022-06-17 20:59:00.175874
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('aaa', 'text/plain') == 'bbb'

# Generated at 2022-06-17 20:59:06.030333
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\n')

    assert TestFormatterPlugin(format_options={}).format_body('hello\nworld', 'text/plain') == 'hello\n\nworld'


# Generated at 2022-06-17 20:59:10.933756
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'application/atom+xml') == 'testtest'

# Generated at 2022-06-17 20:59:13.866862
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:59:17.431439
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    fp = FormatterPlugin_test(format_options=None)
    assert fp.format_headers('test') == 'test'



# Generated at 2022-06-17 20:59:22.362451
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'


# Generated at 2022-06-17 20:59:27.665685
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('foo\nbar\n', 'text/plain') == '\tfoo\n\tbar\n'



# Generated at 2022-06-17 20:59:32.569884
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('Content-Type: application/json\r\n') == 'Content-Type: application/json\n'



# Generated at 2022-06-17 20:59:35.949844
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'test') == 'testtest'

# Generated at 2022-06-17 20:59:38.688581
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:03.782007
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:00:07.267572
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPluginTest(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert FormatterPluginTest(format_options={}).format_headers(headers) == headers


# Generated at 2022-06-17 21:00:12.236179
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '


# Generated at 2022-06-17 21:00:17.932488
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 21:00:29.726619
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import ColorsFormatter
    from httpie.output.formatters.default import DefaultFormatter
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.pretty import PrettyFormatter
    from httpie.output.formatters.raw import RawFormatter
    from httpie.output.formatters.table import TableFormatter
    from httpie.output.formatters.terminal_formatter import TerminalFormatter
    from httpie.output.formatters.html import HTMLFormatter
    from httpie.output.formatters.xml import XMLFormatter
    from httpie.output.formatters.yaml import YAMLFormatter
    from httpie.output.formatters.csv import CSVFormatter

# Generated at 2022-06-17 21:00:36.881184
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\t')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK\tContent-Type: application/json\t
'''



# Generated at 2022-06-17 21:00:42.651966
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    headers_formatted = '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''
    assert FormatterPlugin_test(format_options={}).format_headers(headers) == headers_formatted


# Generated at 2022-06-17 21:00:48.400215
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('a: b\nc: d') == 'a: b\n\nc: d'



# Generated at 2022-06-17 21:00:58.956794
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatter(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    # Test with a single header
    headers = 'Content-Type: application/json'
    assert TestFormatter(format_options={}).format_headers(headers) == headers.upper()

    # Test with multiple headers
    headers = 'Content-Type: application/json\nContent-Length: 42'
    assert TestFormatter(format_options={}).format_headers(headers) == headers.upper()


# Generated at 2022-06-17 21:01:00.555995
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers("test") == "test"


# Generated at 2022-06-17 21:01:26.271736
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(BasePlugin):
        """
        Requests transport adapter docs:

            <https://requests.readthedocs.io/en/latest/user/advanced/#transport-adapters>

        See httpie-unixsocket for an example transport plugin:

            <https://github.com/httpie/httpie-unixsocket>

        """

        # The URL prefix the adapter should be mount to.
        prefix = None

        def get_adapter(self):
            """
            Return a ``requests.adapters.BaseAdapter`` subclass instance to be
            mounted to ``self.prefix``.

            """
            raise NotImplementedError()

    # Test that the constructor of class TransportPlugin is callable
    try:
        TransportPlugin()
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-17 21:01:32.213595
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test-auth'

        def get_auth(self, username=None, password=None):
            return 'test-auth'

    plugin = TestAuthPlugin()
    assert plugin.get_auth() == 'test-auth'



# Generated at 2022-06-17 21:01:37.522234
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    converter = TestConverterPlugin('text/plain')
    assert converter.convert(b'Hello') == 'Hello'


# Generated at 2022-06-17 21:01:43.444416
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    converter = TestConverterPlugin('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 21:01:48.223988
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:01:51.426652
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    fp = TestFormatterPlugin(format_options=None)
    assert fp.format_body('aaa', 'text/plain') == 'bbb'


# Generated at 2022-06-17 21:01:57.065513
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:02:01.890893
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return username, password

    auth = AuthPlugin()
    assert auth.get_auth('user', 'pass') == ('user', 'pass')


# Generated at 2022-06-17 21:02:06.744490
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes
        @classmethod
        def supports(cls, mime):
            return True
    converter_plugin = TestConverterPlugin('mime')
    assert converter_plugin.mime == 'mime'


# Generated at 2022-06-17 21:02:10.708655
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    assert TestConverterPlugin('text/plain').convert(b'foo') == 'foo'



# Generated at 2022-06-17 21:02:35.486425
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        pass
    plugin = TestPlugin()
    assert plugin.name == 'TestPlugin'
    assert plugin.description is None
    assert plugin.package_name == 'httpie.plugins.test_plugin'


# Generated at 2022-06-17 21:02:40.937899
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            pass

        @classmethod
        def supports(cls, mime):
            pass

    TestConverterPlugin('application/json')


# Generated at 2022-06-17 21:02:47.029169
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    assert TestConverterPlugin(mime='text/plain').convert(b'foo') == 'foo'



# Generated at 2022-06-17 21:02:55.671385
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class BasePluginTest(BasePlugin):
        name = "BasePluginTest"
        description = "BasePluginTest"
    bpt = BasePluginTest()
    assert bpt.name == "BasePluginTest"
    assert bpt.description == "BasePluginTest"
    assert bpt.package_name == "httpie.plugins.builtin.BasePluginTest"


# Generated at 2022-06-17 21:02:59.615557
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return None

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.package_name is None


# Generated at 2022-06-17 21:03:05.861753
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 21:03:09.833527
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:03:14.735447
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class MyConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    plugin = MyConverterPlugin('application/json')
    assert plugin.mime == 'application/json'


# Generated at 2022-06-17 21:03:20.281633
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            return username, password

    auth = AuthPlugin()
    assert auth.auth_type == 'test'
    assert auth.auth_require == True
    assert auth.auth_parse == True
    assert auth.netrc_parse == False
    assert auth.prompt_password == True
    assert auth.raw_auth == None
    assert auth.get_auth('user', 'pass') == ('user', 'pass')


# Generated at 2022-06-17 21:03:26.297869
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'



# Generated at 2022-06-17 21:04:13.175656
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverter(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)
        def convert(self, content_bytes):
            return content_bytes
        @classmethod
        def supports(cls, mime):
            return True
    t = TestConverter('test')
    assert t.mime == 'test'


# Generated at 2022-06-17 21:04:16.674545
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_formatted'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('content', 'mime') == 'content_formatted'

# Generated at 2022-06-17 21:04:19.472716
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    bp = BasePlugin()
    assert bp.name == None
    assert bp.description == None
    assert bp.package_name == None


# Generated at 2022-06-17 21:04:23.950934
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:04:28.235166
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    assert TestConverterPlugin('text/plain').convert(b'abc') == 'abc'


# Generated at 2022-06-17 21:04:30.130612
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    FormatterPlugin(format_options={})


# Generated at 2022-06-17 21:04:37.112565
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    converter = TestConverterPlugin('text/plain')
    assert converter.mime == 'text/plain'


# Generated at 2022-06-17 21:04:45.415682
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    env = Environment()
    format_options = FormatOptions()
    format_options.colors = True
    format_options.style = 'solarized'
    format_options.format = 'json'
    format_options.prettify = True
    format_options.headers = 'none'
    format_options.body = 'none'
    format_options.output_options = OutputOptions()
    format_options.output_options.output_file = None
    format_options.output_options.output_options_specified = False
    format_options.output_options.output_options_overridden = False
    format_options.output_options.output_options_overridden_by

# Generated at 2022-06-17 21:04:54.172197
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class MyPlugin(BasePlugin):
        name = 'MyPlugin'
        description = 'MyPlugin description'
        auth_type = 'my-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None
        prefix = None

    plugin = MyPlugin()
    assert plugin.name == 'MyPlugin'
    assert plugin.description == 'MyPlugin description'
    assert plugin.auth_type == 'my-auth'
    assert plugin.auth_require == True
    assert plugin.auth_parse == True
    assert plugin.netrc_parse == False
    assert plugin.prompt_password == True
    assert plugin.raw_auth == None
    assert plugin.prefix == None


# Generated at 2022-06-17 21:04:58.083812
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        pass
    plugin = TestPlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None
