

# Generated at 2022-06-17 20:56:14.531225
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "test") == "test"

# Generated at 2022-06-17 20:56:22.874944
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert plugin.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''



# Generated at 2022-06-17 20:56:28.450303
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('header: value') == 'HEADER: VALUE'


# Generated at 2022-06-17 20:56:33.359944
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_format_body(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = FormatterPlugin_format_body(**{'format_options': {}})
    assert fp.format_body("content", "mime") == "content"


# Generated at 2022-06-17 20:56:37.670660
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'test') == 'test'



# Generated at 2022-06-17 20:56:42.212886
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content.upper()

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'TEST'


# Generated at 2022-06-17 20:56:50.222422
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Test 1
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('HTTP/1.1 200 OK\r\n') == 'HTTP/1.1 200 OK\n'

    # Test 2
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    test_formatter = TestFormatterPlugin(format_options={})

# Generated at 2022-06-17 20:56:52.404218
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:56:58.837811
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "test") == "test"



# Generated at 2022-06-17 20:57:04.478407
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:57:11.972513
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace("\n", "")

    assert TestFormatterPlugin(format_options={}).format_headers("\n") == ""


# Generated at 2022-06-17 20:57:18.574958
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'text/plain') == 'test_test'

# Generated at 2022-06-17 20:57:27.628973
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 1270
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Thu, 25 Jul 2019 15:58:23 GMT

'''

# Generated at 2022-06-17 20:57:36.002244
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert MyFormatterPlugin(format_options={}).format_headers('\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        '',
        '',
    ])) == '\n'.join([
        'HTTP/1.1 200 OK',
        '\tContent-Type: application/json',
        '',
        '',
    ])



# Generated at 2022-06-17 20:57:39.198081
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 20:57:42.047185
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', '') == 'b'


# Generated at 2022-06-17 20:57:46.138120
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')
    assert TestFormatterPlugin().format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:57:48.617580
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "text/plain") == "test"

# Generated at 2022-06-17 20:57:52.215819
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers(
        'Content-Type: application/json\n'
        'Content-Length: 2\n'
        '\n'
    ) == '\tContent-Type: application/json\n' \
        '\tContent-Length: 2\n' \
        '\t\n'



# Generated at 2022-06-17 20:57:54.166750
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin().format_body('content', 'mime') == 'content'



# Generated at 2022-06-17 20:58:00.723605
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 20:58:08.209767
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace("\n", "")

    class TestEnvironment:
        def __init__(self):
            self.colors = False
            self.format = 'json'

    env = TestEnvironment()
    formatter = TestFormatterPlugin(env=env, format_options={})
    assert formatter.format_body("{\"test\": \"test\"}\n", "application/json") == "{\"test\": \"test\"}"



# Generated at 2022-06-17 20:58:11.588451
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers("test") == "test"


# Generated at 2022-06-17 20:58:16.756748
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'testtest'

# Generated at 2022-06-17 20:58:21.894699
# Unit test for method format_headers of class FormatterPlugin

# Generated at 2022-06-17 20:58:26.788945
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('hello', 'text/plain') == 'HELLO'



# Generated at 2022-06-17 20:58:34.605774
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

'''



# Generated at 2022-06-17 20:58:37.205657
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin()
    assert test_formatter.format_headers("test") == "test"


# Generated at 2022-06-17 20:58:40.766896
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('\n', 'text/plain') == '\n\t'



# Generated at 2022-06-17 20:58:45.941589
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('<', '&lt;')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('<html>', 'text/html') == '&lt;html>'



# Generated at 2022-06-17 20:59:01.044112
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments.token import Token
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments.token import Token
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments.token import Token
    from httpie.plugins import FormatterPlugin

# Generated at 2022-06-17 20:59:08.418309
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    # Test for method format_body of class FormatterPlugin
    # Test for the case when content is empty
    assert TestFormatterPlugin().format_body("", "") == ""
    # Test for the case when content is not empty
    assert TestFormatterPlugin().format_body("test", "") == "test"


# Generated at 2022-06-17 20:59:13.160408
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter_plugin = TestFormatterPlugin()
    assert test_formatter_plugin.format_headers('a\nb\nc') == 'a\n\tb\n\tc'


# Generated at 2022-06-17 20:59:15.881237
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_body("test", "test") == "test"

# Generated at 2022-06-17 20:59:18.410784
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('aaa', 'text/plain') == 'bbb'

# Generated at 2022-06-17 20:59:26.697134
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''



# Generated at 2022-06-17 20:59:30.647150
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + "test"

    assert TestFormatterPlugin(format_options={}).format_body("test", "") == "testtest"


# Generated at 2022-06-17 20:59:34.911103
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')
    tfp = TestFormatterPlugin(**{'format_options': {}})
    assert tfp.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:59:43.740182
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == headers.replace('\r\n', '\n')


# Generated at 2022-06-17 20:59:48.304503
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:02.185999
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    test_headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

# Generated at 2022-06-17 21:00:04.949749
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 21:00:11.173625
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''



# Generated at 2022-06-17 21:00:22.888547
# Unit test for method format_headers of class FormatterPlugin

# Generated at 2022-06-17 21:00:27.299796
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test\n'


# Generated at 2022-06-17 21:00:34.765041
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin().format_headers(headers) == '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
\r
'''

# Generated at 2022-06-17 21:00:41.197993
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: text/html; charset=utf-8
    Content-Length: 12
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: text/html; charset=utf-8 Content-Length: 12 '


# Generated at 2022-06-17 21:00:47.156385
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:00:54.032873
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 21:00:59.874441
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'text/plain') == 'test\n'


# Generated at 2022-06-17 21:01:12.159701
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 21:01:15.321532
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('foo', 'bar') == 'FOO'



# Generated at 2022-06-17 21:01:26.271344
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    # Test 1

# Generated at 2022-06-17 21:01:30.633196
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''



# Generated at 2022-06-17 21:01:35.954020
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_formatted'
    tfp = TestFormatterPlugin(**{'format_options': {}})
    assert tfp.format_body('content', 'mime') == 'content_formatted'


# Generated at 2022-06-17 21:01:46.910380
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''


# Generated at 2022-06-17 21:01:53.399226
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body("test", "application/json") == "test"


# Generated at 2022-06-17 21:01:59.175916
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 21:02:02.321850
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert MyFormatterPlugin(format_options={}).format_body('a', 'text/plain') == 'b'


# Generated at 2022-06-17 21:02:06.776268
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'testtest'

# Generated at 2022-06-17 21:02:24.551539
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 1270
Connection: keep-alive
Date: Sun, 14 Jul 2019 11:56:25 GMT
Server: nginx/1.14.0 (Ubuntu)

'''

# Generated at 2022-06-17 21:02:30.890076
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.upper()

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'A: B\nC: D'


# Generated at 2022-06-17 21:02:35.318914
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 21:02:46.981139
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    test_headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

'''

# Generated at 2022-06-17 21:02:55.011255
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\tb\n\tc'



# Generated at 2022-06-17 21:02:59.252924
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 21:03:05.600954
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
Content-Length: 2\r
\r
'''



# Generated at 2022-06-17 21:03:15.258073
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

# Generated at 2022-06-17 21:03:21.613415
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\r\nc: d'


# Generated at 2022-06-17 21:03:26.015229
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace("\n", "")

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test\n", "") == "test"



# Generated at 2022-06-17 21:03:53.709504
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    assert TestConverterPlugin('text/plain').convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:04:03.747615
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    import requests
    from httpie.plugins.auth import AuthPlugin

    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth'
        auth_parse = True
        auth_require = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return requests.auth.HTTPBasicAuth(username, password)

    plugin = MyAuthPlugin()
    plugin.raw_auth = 'user:pass'
    assert plugin.get_auth('user', 'pass')
    assert plugin.get_auth() == requests.auth.HTTPBasicAuth('user', 'pass')


# Generated at 2022-06-17 21:04:08.536431
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class MyTransportPlugin(TransportPlugin):
        prefix = 'my'

        def get_adapter(self):
            return 'adapter'

    plugin = MyTransportPlugin()
    assert plugin.get_adapter() == 'adapter'


# Generated at 2022-06-17 21:04:14.217933
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.plugins import FormatterPlugin
    from httpie.environment import Environment
    env = Environment()
    formatter = FormatterPlugin(env=env, format_options={})
    assert formatter.enabled
    assert formatter.kwargs == {'env': env, 'format_options': {}}
    assert formatter.format_options == {}

# Generated at 2022-06-17 21:04:18.572908
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPluginTest(AuthPlugin):
        auth_type = 'test'

        def get_auth(self, username=None, password=None):
            return 'test'

    assert AuthPluginTest().get_auth() == 'test'

# Generated at 2022-06-17 21:04:24.580438
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:04:29.042286
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    converter = TestConverterPlugin('text/plain')
    assert converter.convert(b'hello world') == 'hello world'


# Generated at 2022-06-17 21:04:36.973381
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super(TestConverterPlugin, self).__init__(mime)
        def convert(self, content_bytes):
            return content_bytes
        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('application/json')
    assert plugin.mime == 'application/json'


# Generated at 2022-06-17 21:04:45.368276
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    test_headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

    test_headers_formatted = '''HTTP/1.1 200 OK Date: Mon, 27 Jul 2009 12:28:53 GMT Server: Apache/2.2.14 (Win32) Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT Content-Length: 88 Content-Type: text/html Connection: Closed'''

   

# Generated at 2022-06-17 21:04:48.311018
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin_test(TransportPlugin):
        prefix = 'test'
        def get_adapter(self):
            return 'test'
    assert TransportPlugin_test().get_adapter() == 'test'


# Generated at 2022-06-17 21:05:38.407844
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    tfp = TestFormatterPlugin(format_options=None)
    assert tfp.enabled
    assert tfp.kwargs == {'format_options': None}
    assert tfp.format_options is None



# Generated at 2022-06-17 21:05:42.047859
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class ConverterPlugin_test(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode()

        @classmethod
        def supports(cls, mime):
            return True

    converter = ConverterPlugin_test('text/plain')
    assert converter.convert(b'hello') == 'hello'



# Generated at 2022-06-17 21:05:46.559500
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            return None

    auth_plugin = AuthPlugin()
    assert auth_plugin.auth_type == 'test'
    assert auth_plugin.auth_require == True
    assert auth_plugin.auth_parse == True
    assert auth_plugin.netrc_parse == False
    assert auth_plugin.prompt_password == True
    assert auth_plugin.raw_auth == None


# Generated at 2022-06-17 21:05:49.684192
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class Test(BasePlugin):
        name = 'test'
        description = 'test plugin'
    assert Test().name == 'test'
    assert Test().description == 'test plugin'
    assert Test().package_name == 'httpie.plugins.test'


# Generated at 2022-06-17 21:05:56.388166
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 21:06:02.133108
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import plugin_manager

    plugin_manager.load_installed_plugins()
    env = Environment()
    env.config.default_options['format'] = 'json'
    env.config.default_options['format_options'] = {}
    formatter = plugin_manager.get_formatter(env)
    assert isinstance(formatter, FormatterPlugin)



# Generated at 2022-06-17 21:06:06.642001
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers + '\n'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'test\n'


# Generated at 2022-06-17 21:06:10.682404
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'
