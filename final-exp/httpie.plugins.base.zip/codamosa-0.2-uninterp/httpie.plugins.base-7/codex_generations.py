

# Generated at 2022-06-17 20:56:08.723885
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('aaa', 'text/plain') == 'bbb'



# Generated at 2022-06-17 20:56:18.191875
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert test_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:56:23.360836
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options=None)
    assert plugin.format_body('test', 'application/atom+xml') == 'test'



# Generated at 2022-06-17 20:56:30.925093
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return "test"

    # Test with a valid mime type
    assert TestFormatterPlugin(format_options={}).format_body("", "application/json") == "test"

    # Test with an invalid mime type
    assert TestFormatterPlugin(format_options={}).format_body("", "application/invalid") == ""



# Generated at 2022-06-17 20:56:34.845023
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\r\n') == 'a: b\n'


# Generated at 2022-06-17 20:56:40.895159
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('HTTP/1.1 200 OK\r\n') == 'HTTP/1.1 200 OK\n'


# Generated at 2022-06-17 20:56:45.732530
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\r\n') == 'a: b\n'


# Generated at 2022-06-17 20:56:51.780225
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "test") == "test"

# Generated at 2022-06-17 20:56:59.405590
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '


# Generated at 2022-06-17 20:57:04.379871
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'TEST'

# Generated at 2022-06-17 20:57:10.360683
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b\r\nc: d'


# Generated at 2022-06-17 20:57:16.466913
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('foo', 'text/plain') == 'foo\n'



# Generated at 2022-06-17 20:57:21.217036
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:57:25.299667
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace("<", "&lt;")

    assert TestFormatterPlugin(format_options={}).format_body("<html>", "text/html") == "&lt;html>"



# Generated at 2022-06-17 20:57:27.804378
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('test') == 'test'



# Generated at 2022-06-17 20:57:32.850149
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:57:36.851760
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:57:41.532893
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatter(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatter(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json

'''


# Generated at 2022-06-17 20:57:47.315110
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    class TestEnvironment:
        def __init__(self):
            self.colors = False
            self.prettify = False
            self.stream = False

    env = TestEnvironment()
    formatter = TestFormatterPlugin(env=env, format_options={})
    assert formatter.format_body('\n', 'text/plain') == '\n\t'



# Generated at 2022-06-17 20:57:54.126454
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers

    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:58:00.569470
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('test') == 'test'


# Generated at 2022-06-17 20:58:10.329364
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import BodyFormatterPlugin
    from httpie.plugins.builtin import LineFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin

# Generated at 2022-06-17 20:58:14.851299
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    f = FormatterPlugin_test(format_options={})
    assert f.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:58:25.634123
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')
    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Tue, 27 Aug 2019 12:23:56 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Mon, 26 Aug 2019 13:14:00 GMT
ETag: "2d-59a6b7c5f5180"
Accept-Ranges: bytes
Content-Length: 45
Content-Type: text/html

'''

# Generated at 2022-06-17 20:58:30.444311
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    assert TestFormatterPlugin(format_options={}).format_headers('test') == 'TEST'


# Generated at 2022-06-17 20:58:34.936293
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options=None)
    assert test_formatter_plugin.format_body("test", "test") == "test"



# Generated at 2022-06-17 20:58:39.653883
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert plugin.format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json'


# Generated at 2022-06-17 20:58:41.924710
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers("test") == "test"



# Generated at 2022-06-17 20:58:51.744854
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins.builtin import HTTPieJSONFormatter
    from httpie.plugins.builtin import HTTPiePrettyFormatter
    from httpie.plugins.builtin import HTTPieTableFormatter
    from httpie.plugins.builtin import HTTPieTerminalFormatter
    from httpie.plugins.builtin import HTTPieUnixFormatter
    from httpie.plugins.builtin import HTTPieVerticalFormatter
    from httpie.plugins.builtin import HTTPieZeroFormatter
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import TableFormatter
    from httpie.plugins.builtin import TerminalFormatter
    from httpie.plugins.builtin import UnixFormatter
    from httpie.plugins.builtin import VerticalFormatter
   

# Generated at 2022-06-17 20:58:58.580876
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')
    assert TestFormatterPlugin(format_options={}).format_headers('a: b\r\nc: d\r\n') == 'a: b\nc: d\n'


# Generated at 2022-06-17 20:59:04.133897
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:59:14.515029
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Wed, 11 Oct 2017 10:34:36 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK

Server: nginx/1.10.3 (Ubuntu)

Date: Wed, 11 Oct 2017 10:34:36 GMT

Content-Type: application/json

Content-Length: 2

Connection: keep-alive

'''

# Generated at 2022-06-17 20:59:19.480729
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == 'Content-Type: application/json Content-Length: 2 '


# Generated at 2022-06-17 20:59:24.957759
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_body('\n', 'application/json') == '\n\t'

# Generated at 2022-06-17 20:59:29.036245
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')
    assert TestFormatterPlugin(format_options={}).format_body('a', 'text/plain') == 'b'

# Generated at 2022-06-17 20:59:32.679543
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body("test", "") == "test"


# Generated at 2022-06-17 20:59:36.174209
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:59:39.022553
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:59:44.726778
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 20:59:46.996900
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:00:01.079411
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''



# Generated at 2022-06-17 21:00:04.398883
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test_test'

# Generated at 2022-06-17 21:00:07.324930
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:10.997650
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('abc', 'text/plain') == 'ABC'


# Generated at 2022-06-17 21:00:13.640239
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options=None)
    assert plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:00:19.992459
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 21:00:24.346780
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:30.343366
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('foo: bar\nbar: baz') == 'foo: bar\n\tbar: baz'


# Generated at 2022-06-17 21:00:35.112967
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test\n'


# Generated at 2022-06-17 21:00:43.173154
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Wed, 08 Nov 2017 16:49:25 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

'''

# Generated at 2022-06-17 21:01:14.474798
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return None

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() is None


# Generated at 2022-06-17 21:01:21.951466
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    t = TestConverterPlugin('mime')
    assert t.mime == 'mime'


# Generated at 2022-06-17 21:01:26.037910
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes
        @classmethod
        def supports(cls, mime):
            return True
    t = TestConverterPlugin('mime')
    assert t.mime == 'mime'


# Generated at 2022-06-17 21:01:29.068033
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '-test'
    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test-test'


# Generated at 2022-06-17 21:01:33.823485
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth'

        def get_auth(self, username=None, password=None):
            return 'get_auth'

    plugin = MyAuthPlugin()
    assert plugin.get_auth() == 'get_auth'


# Generated at 2022-06-17 21:01:38.587527
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode()

        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'



# Generated at 2022-06-17 21:01:43.046622
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:01:46.979849
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:01:50.518651
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    plugin = BasePlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None


# Generated at 2022-06-17 21:01:56.085290
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        def get_auth(self, username=None, password=None):
            return username, password
    auth = AuthPlugin()
    assert auth.get_auth('user', 'pass') == ('user', 'pass')


# Generated at 2022-06-17 21:02:21.615836
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_plugin = TestFormatterPlugin(format_options={})
    assert test_plugin.format_body("test", "application/json") == "test"



# Generated at 2022-06-17 21:02:24.255599
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'test') == 'test'

# Generated at 2022-06-17 21:02:30.348676
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin(BasePlugin):
        prefix = 'http+unix://'

        def get_adapter(self):
            return 'http+unix://'

    assert TransportPlugin().get_adapter() == 'http+unix://'



# Generated at 2022-06-17 21:02:33.488878
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'



# Generated at 2022-06-17 21:02:36.924253
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin(BasePlugin):
        prefix = 'http+unix://'

        def get_adapter(self):
            return 'adapter'

    plugin = TransportPlugin()
    assert plugin.get_adapter() == 'adapter'


# Generated at 2022-06-17 21:02:40.528553
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:02:44.610589
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(TransportPlugin):
        prefix = 'unix'

        def get_adapter(self):
            return None

    assert TransportPlugin.prefix == 'unix'



# Generated at 2022-06-17 21:02:49.984832
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert MyFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
\r
'''


# Generated at 2022-06-17 21:02:56.040642
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test plugin'

    plugin = TestPlugin()
    assert plugin.name == 'test'
    assert plugin.description == 'test plugin'
    assert plugin.package_name == 'httpie_test'


# Generated at 2022-06-17 21:03:00.833245
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('application/json')
    assert plugin.mime == 'application/json'


# Generated at 2022-06-17 21:03:49.043824
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers("test") == "test"


# Generated at 2022-06-17 21:03:55.216517
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)
            self.mime = mime

        def convert(self, content_bytes):
            raise NotImplementedError

        @classmethod
        def supports(cls, mime):
            raise NotImplementedError

    test_plugin = TestConverterPlugin('test')
    assert test_plugin.mime == 'test'


# Generated at 2022-06-17 21:03:59.112655
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    bp = BasePlugin()
    assert bp.name is None
    assert bp.description is None
    assert bp.package_name is None


# Generated at 2022-06-17 21:04:03.085921
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:04:05.965850
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 21:04:12.398195
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 21:04:16.821556
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class ConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            self.mime = mime

        def convert(self, content_bytes):
            raise NotImplementedError

        @classmethod
        def supports(cls, mime):
            raise NotImplementedError

    c = ConverterPlugin('application/json')
    assert c.mime == 'application/json'


# Generated at 2022-06-17 21:04:22.431181
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverter(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode()

        @classmethod
        def supports(cls, mime):
            return True

    assert TestConverter('text/plain').convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:04:27.175589
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class ConverterPlugin_test(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    assert ConverterPlugin_test('text/plain').convert(b'abc') == 'abc'


# Generated at 2022-06-17 21:04:39.579065
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    # Create a dummy class
    class DummyFormatter(FormatterPlugin):
        pass

    # Create a dummy environment
    class DummyEnv:
        def __init__(self):
            self.colors = False
            self.prettify = True
            self.style = 'solarized'

    # Create a dummy format_options
    class DummyFormatOptions:
        def __init__(self):
            self.headers = 'pretty'
            self.body = 'pretty'

    # Create a dummy formatter
    dummy_formatter = DummyFormatter(env=DummyEnv(), format_options=DummyFormatOptions())

    # Check if the dummy formatter is enabled
    assert dummy_formatter.enabled == True

    # Check if the dummy formatter has the right format_options
    assert dummy_formatter.format