

# Generated at 2022-06-17 20:56:08.797714
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "text/html") == "test"


# Generated at 2022-06-17 20:56:15.685157
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    formatter = FormatterPlugin(format_options={})
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert formatter.format_headers(headers) == headers


# Generated at 2022-06-17 20:56:20.936137
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('hello', 'text/plain') == 'HELLO'

# Generated at 2022-06-17 20:56:29.599375
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

# Generated at 2022-06-17 20:56:39.859406
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

# Generated at 2022-06-17 20:56:49.046329
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(**{'format_options': {}})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Date: Mon, 03 Aug 2020 08:51:52 GMT
Server: Apache/2.4.18 (Ubuntu)
Vary: Accept-Encoding
X-Powered-By: PHP/7.2.24-0ubuntu0.18.04.6
Content-Length: 2
Connection: close

'''

# Generated at 2022-06-17 20:56:55.567561
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 20:57:06.310248
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

# Generated at 2022-06-17 20:57:10.902110
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('foo: bar\nbar: baz') == 'foo: bar\n\tbar: baz'



# Generated at 2022-06-17 20:57:17.040491
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('a', 'text/plain') == 'b'



# Generated at 2022-06-17 20:57:24.175412
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = MyFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d\n') == 'a: b\n\tc: d\n'


# Generated at 2022-06-17 20:57:29.119299
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert plugin.format_headers(headers) == '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
\r
'''



# Generated at 2022-06-17 20:57:33.731063
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('\n') == '\n\t'


# Generated at 2022-06-17 20:57:37.005020
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers

    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:57:40.915910
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 20:57:45.126423
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\r\nc: d\r\n') == 'a: b\nc: d\n'


# Generated at 2022-06-17 20:57:48.464727
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'TEST'


# Generated at 2022-06-17 20:57:59.324976
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    Content-Length: 2
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''
    HTTP/1.1 200 OK
    \tContent-Type: application/json
    \tContent-Length: 2
    '''



# Generated at 2022-06-17 20:58:02.275451
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content + '_formatted'

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('content', 'mime') == 'content_formatted'



# Generated at 2022-06-17 20:58:07.212950
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test\n'



# Generated at 2022-06-17 20:58:14.748349
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers("test") == "test"


# Generated at 2022-06-17 20:58:20.109390
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = MyFormatterPlugin(format_options={})
    assert plugin.format_headers('foo: bar\n') == 'foo: bar\n\t'



# Generated at 2022-06-17 20:58:24.419341
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:58:32.356788
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert plugin.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''



# Generated at 2022-06-17 20:58:36.209996
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return 'test'

    fp = TestFormatterPlugin(env=None, format_options=None)
    assert fp.format_headers('test') == 'test'


# Generated at 2022-06-17 20:58:39.416856
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:58:42.245344
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:58:46.608168
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatter(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatter(format_options={})
    assert test_formatter.format_body("test", "text/html") == "test"



# Generated at 2022-06-17 20:58:52.880458
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    fp = FormatterPlugin_test(format_options={})
    assert fp.format_headers("test") == "test"


# Generated at 2022-06-17 20:58:55.623860
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:59:08.419454
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('abc\ndef', 'text/plain') == 'abc\n\tdef'



# Generated at 2022-06-17 20:59:12.075774
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'test'

# Generated at 2022-06-17 20:59:15.417473
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:59:19.154978
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a\nb') == 'a\r\nb'


# Generated at 2022-06-17 20:59:24.002302
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin().format_headers('foo: bar\n') == 'foo: bar\n\t'



# Generated at 2022-06-17 20:59:30.016386
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert test_formatter.format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '


# Generated at 2022-06-17 20:59:33.779594
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    my_formatter_plugin = MyFormatterPlugin(format_options={})
    assert my_formatter_plugin.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 20:59:36.758385
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:59:40.275228
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\n')
    assert FormatterPlugin_test(format_options={}).format_body('a\nb\nc', 'text/plain') == 'a\n\nb\n\nc'


# Generated at 2022-06-17 20:59:46.499752
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('foo: bar\nbaz: qux') == 'foo: bar\n\tbaz: qux'


# Generated at 2022-06-17 20:59:57.918595
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('\n', 'text/plain') == '\n\n'


# Generated at 2022-06-17 21:00:01.863031
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "") == "test"

# Generated at 2022-06-17 21:00:08.306169
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test_content', 'test_mime') == 'test_content'

# Generated at 2022-06-17 21:00:16.347716
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.plugins.builtin.formatter
    import httpie.plugins.builtin.formatters.colors
    import httpie.plugins.builtin.formatters.colors.Solarized
    import httpie.plugins.builtin.formatters.colors.Solarized.Solarized
    import httpie.plugins.builtin.formatters.colors.Solarized.Solarized256
    import httpie.plugins.builtin.formatters.colors.Solarized.Solarized8
    import httpie.plugins.builtin.formatters.colors.Solarized.Solarized8.Solarized8
    import httpie.plugins.builtin.formatters.colors.Solarized.Solarized8.Solarized8256

# Generated at 2022-06-17 21:00:22.734536
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    content = '{"a": 1, "b": 2}'
    mime = 'application/json'
    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body(content, mime) == content



# Generated at 2022-06-17 21:00:26.350948
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    fp = FormatterPlugin_test(format_options=None)
    assert fp.format_headers("test") == "test"



# Generated at 2022-06-17 21:00:31.274202
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 21:00:36.436777
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'text/plain') == 'test'

# Generated at 2022-06-17 21:00:43.949083
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''
        HTTP/1.1 200 OK
        Content-Type: application/json
        Content-Length: 2
        Date: Wed, 22 May 2019 10:29:43 GMT
        Server: Python/3.7 aiohttp/3.5.4
    '''

# Generated at 2022-06-17 21:00:53.217520
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import json
    from httpie.plugins import plugin_manager

    plugin_manager.load_installed_plugins()
    formatter = plugin_manager.get_formatter('json')
    headers = '''HTTP/1.1 200 OK
Date: Tue, 12 May 2020 16:03:01 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Tue, 12 May 2020 15:59:59 GMT
ETag: "1d3-5a9e9b4f9b6c0"
Accept-Ranges: bytes
Content-Length: 467
Vary: Accept-Encoding
Content-Type: text/html

'''
    headers_json = formatter.format_headers(headers)

# Generated at 2022-06-17 21:01:03.473753
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:01:08.632768
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body("test", "text/plain") == "test"

# Generated at 2022-06-17 21:01:13.762713
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatter(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    assert TestFormatter(format_options={}).format_headers('a\nb\nc') == 'a b c'


# Generated at 2022-06-17 21:01:18.815838
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('hello', 'text/plain') == 'HELLO'


# Generated at 2022-06-17 21:01:23.578476
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('a', 'text/plain') == 'b'


# Generated at 2022-06-17 21:01:30.449301
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    import httpie.plugins.builtin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import JSONLinesPrettyFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import PrettyXMLFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import PrettyHTMLFormatter
    from httpie.plugins.builtin import CSVFormatter
    from httpie.plugins.builtin import TSVFormatter
    from httpie.plugins.builtin import TableFormatter
    from httpie.plugins.builtin import Raw

# Generated at 2022-06-17 21:01:39.815885
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import httpie.plugins
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import builtin
    from httpie.plugins import manager
    from httpie.plugins import registry
    from httpie.plugins import test_FormatterPlugin
    from httpie.plugins import test_FormatterPlugin_format_headers
    from httpie.plugins import test_FormatterPlugin_format_headers_1
    from httpie.plugins import test_FormatterPlugin_format_headers_2
    from httpie.plugins import test_FormatterPlugin_format_headers_3
    from httpie.plugins import test_FormatterPlugin_format_headers_4
    from httpie.plugins import test_FormatterPlugin_format_headers_5
    from httpie.plugins import test_FormatterPlugin_format_headers_6
    from httpie.plugins import test_

# Generated at 2022-06-17 21:01:46.261369
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.lexers import get_lexer_by_name
    from pygments.token import Token
    from pygments.util import ClassNotFound
    from pygments.lexers.special import TextLexer
    from pygments.lexers.agile import PythonLexer
    from pygments.lexers.web import PhpLexer
    from pygments.lexers.compiled import CppLexer
    from pygments.lexers.markup import HtmlLexer
    from pygments.lexers.data import JsonLexer
    from pygments.lexers.data import YamlLexer
    from pygments.lexers.data import XmlLexer
    from pygments.lexers.data import Ini

# Generated at 2022-06-17 21:01:49.817939
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    f = MyFormatterPlugin(**{'format_options': {}})
    assert f.format_body('abc', 'application/atom+xml') == 'bbc'

# Generated at 2022-06-17 21:01:57.835569
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:02:17.703418
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    fp = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert fp.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json

'''


# Generated at 2022-06-17 21:02:21.142615
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'text/html') == 'b'


# Generated at 2022-06-17 21:02:23.434192
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 21:02:30.936917
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test_content", "test_mime") == "test_content"

# Generated at 2022-06-17 21:02:32.797475
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 21:02:36.605546
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'



# Generated at 2022-06-17 21:02:41.686611
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    fp = FormatterPlugin_test(format_options={})
    assert fp.format_body('test', 'application/atom+xml') == 'test_test'


# Generated at 2022-06-17 21:02:48.795800
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert MyFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''


# Generated at 2022-06-17 21:02:55.160017
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 21:02:59.893141
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')
    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b c: d'


# Generated at 2022-06-17 21:03:28.792536
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_plugin = TestFormatterPlugin(format_options=None)
    assert test_plugin.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 21:03:34.099340
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'text/plain') == 'test\n'


# Generated at 2022-06-17 21:03:39.709967
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('a', 'mime') == 'b'



# Generated at 2022-06-17 21:03:44.693440
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\r\n\r\nc: d') == 'a: b\n\nc: d'



# Generated at 2022-06-17 21:03:50.915721
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPluginTest(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = FormatterPluginTest(format_options={})
    assert formatter.format_body("test", "application/json") == "test"



# Generated at 2022-06-17 21:03:52.674254
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "text/plain") == "test"


# Generated at 2022-06-17 21:03:59.262502
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test_test'

# Generated at 2022-06-17 21:04:03.654885
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')
    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK\r
Content-Type: application/json\r
\r
'''


# Generated at 2022-06-17 21:04:12.310099
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''
    HTTP/1.1 200 OK
    \tContent-Type: application/json
    '''



# Generated at 2022-06-17 21:04:16.125201
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'TEST'

# Generated at 2022-06-17 21:05:17.405260
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

'''



# Generated at 2022-06-17 21:05:22.033591
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    assert TestFormatterPlugin().format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:05:27.489558
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('<', '&lt;').replace('>', '&gt;')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('<html>', 'text/html') == '&lt;html&gt;'



# Generated at 2022-06-17 21:05:32.038929
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return 'test'

    assert TestFormatterPlugin(format_options={}).format_body('', '') == 'test'



# Generated at 2022-06-17 21:05:36.068060
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "text/html") == "test"

# Generated at 2022-06-17 21:05:40.073978
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content + '\n'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('foo', 'text/plain') == 'foo\n'



# Generated at 2022-06-17 21:05:46.275892
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
\r
'''


# Generated at 2022-06-17 21:05:50.620380
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    Content-Type: application/json
    Content-Length: 5
    '''
    assert TestFormatterPlugin().format_headers(headers) == ' Content-Type: application/json Content-Length: 5 '


# Generated at 2022-06-17 21:06:00.584453
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert MyFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK
	Content-Type: application/json
	Content-Length: 2

'''



# Generated at 2022-06-17 21:06:02.251909
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'

