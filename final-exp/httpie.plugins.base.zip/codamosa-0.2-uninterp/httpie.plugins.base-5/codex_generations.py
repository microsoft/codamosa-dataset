

# Generated at 2022-06-17 20:56:09.956468
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'testtest'


# Generated at 2022-06-17 20:56:14.877681
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:56:19.513530
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 20:56:24.848684
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\tb\n\tc'


# Generated at 2022-06-17 20:56:27.954469
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:56:35.262113
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('\n') == '\n\t'
    assert test_formatter.format_headers('\n\n') == '\n\t\n\t'
    assert test_formatter.format_headers('\n\n\n') == '\n\t\n\t\n\t'


# Generated at 2022-06-17 20:56:45.989984
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    class TestFormatterPlugin2(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t\t')

    class TestFormatterPlugin3(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t\t\t')

    class TestFormatterPlugin4(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t\t\t\t')


# Generated at 2022-06-17 20:56:49.110729
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return 'formatted'

    assert TestFormatterPlugin(format_options={}).format_body('content', 'mime') == 'formatted'


# Generated at 2022-06-17 20:56:51.273776
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:56:54.797018
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert test_formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:57:01.283486
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b c: d'



# Generated at 2022-06-17 20:57:07.245421
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:57:14.160409
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''



# Generated at 2022-06-17 20:57:20.190433
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 20:57:24.221018
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    plugin = TestFormatterPlugin(format_options=None)
    assert plugin.format_headers('test') == 'test'


# Generated at 2022-06-17 20:57:31.317351
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''
    HTTP/1.1 200 OK
    CONTENT-TYPE: APPLICATION/JSON
    '''


# Generated at 2022-06-17 20:57:37.388507
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    expected = '''
    HTTP/1.1 200 OK
    \tContent-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == expected


# Generated at 2022-06-17 20:57:42.174346
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'TEST'


# Generated at 2022-06-17 20:57:45.988464
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 20:57:49.265375
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "text/html") == "test"



# Generated at 2022-06-17 20:57:56.510827
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n') == 'HTTP/1.1 200 OK\nContent-Type: text/html; charset=utf-8\n\n'


# Generated at 2022-06-17 20:58:00.788346
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "test") == "test"

# Generated at 2022-06-17 20:58:05.434530
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'testtest'


# Generated at 2022-06-17 20:58:09.173569
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:58:14.654863
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\nc: d'


# Generated at 2022-06-17 20:58:22.376908
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''


# Generated at 2022-06-17 20:58:27.904495
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin().format_headers(headers) == '''
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:58:33.166530
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers("test_headers") == "test_headers"


# Generated at 2022-06-17 20:58:37.479767
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:58:40.546850
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/html') == 'test_test'

# Generated at 2022-06-17 20:58:59.907085
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

'''

# Generated at 2022-06-17 20:59:02.954757
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:59:09.069878
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "") == "test"



# Generated at 2022-06-17 20:59:12.617899
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body("test", "test") == "test"

# Generated at 2022-06-17 20:59:15.416356
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test\n'


# Generated at 2022-06-17 20:59:17.871431
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'


# Generated at 2022-06-17 20:59:28.942004
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')


# Generated at 2022-06-17 20:59:32.906601
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\tb\n\tc'


# Generated at 2022-06-17 20:59:37.988407
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''


# Generated at 2022-06-17 20:59:45.168632
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:00:01.203390
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatter(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    f = TestFormatter()
    assert f.format_headers('foo\nbar') == 'foo\n\tbar'


# Generated at 2022-06-17 21:00:07.920294
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.upper()

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'A: B\nC: D'



# Generated at 2022-06-17 21:00:11.356496
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('abc', 'text/plain') == 'ABC'



# Generated at 2022-06-17 21:00:23.064396
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    env = Environment(colors=256)

# Generated at 2022-06-17 21:00:27.825965
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('a: b\nc: d') == 'a: b\r\nc: d'


# Generated at 2022-06-17 21:00:32.728666
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test\n'

# Generated at 2022-06-17 21:00:37.463203
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers("test") == "test"



# Generated at 2022-06-17 21:00:42.248545
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    plugins = plugin_manager.get_plugins()
    formatter_plugins = plugins['formatter']
    for formatter_plugin in formatter_plugins:
        if formatter_plugin.name == 'JSON':
            json_formatter_plugin = formatter_plugin
            break
    json_formatter_plugin.format_body('{"a": 1}', 'application/json')

# Generated at 2022-06-17 21:00:47.335773
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 21:00:54.343864
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('test', 'mime') == 'TEST'


# Generated at 2022-06-17 21:01:24.277597
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('foo: bar\nbar: baz') == 'foo: bar\n\tbar: baz'



# Generated at 2022-06-17 21:01:30.795591
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    # Test 1
    headers = '''HTTP/1.1 200 OK\r\nDate: Sun, 10 May 2020 10:00:00 GMT\r\nServer: Apache/2.4.18 (Ubuntu)\r\nLast-Modified: Sun, 10 May 2020 10:00:00 GMT\r\nETag: "1a2b3c4d5e6f7g8h9i0j"\r\nAccept-Ranges: bytes\r\nContent-Length: 12345\r\nVary: Accept-Encoding\r\nContent-Type: text/html\r\n\r\n'''
    assert Test

# Generated at 2022-06-17 21:01:35.684047
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:01:41.902983
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    test_formatter_plugin = TestFormatterPlugin(**{'format_options': {}})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'TEST'


# Generated at 2022-06-17 21:01:46.773901
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:01:54.629417
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('a: b\nc: d\n') == 'a: b c: d '


# Generated at 2022-06-17 21:02:00.459321
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 21:02:05.018799
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "text/plain") == "test"

# Generated at 2022-06-17 21:02:09.245015
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('test', 'TEST')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'TEST'


# Generated at 2022-06-17 21:02:15.278738
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''
    HTTP/1.1 200 OK
    \tContent-Type: application/json
    '''


# Generated at 2022-06-17 21:02:39.685967
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return None

    t = TestTransportPlugin()
    assert t.prefix == 'test'


# Generated at 2022-06-17 21:02:48.209421
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return None

    plugin = MyAuthPlugin()
    assert plugin.auth_type == 'my-auth'
    assert plugin.auth_require == True
    assert plugin.auth_parse == True
    assert plugin.netrc_parse == False
    assert plugin.prompt_password == True
    assert plugin.raw_auth == None
    assert plugin.get_auth() == None


# Generated at 2022-06-17 21:02:53.712335
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    env = Environment(colors=256, stdout_isatty=True)
    formatter = TestFormatterPlugin(env=env, format_options={})
    assert formatter.enabled
    assert formatter.kwargs['env'] == env
    assert formatter.kwargs['format_options'] == {}
    assert formatter.format_options == {}



# Generated at 2022-06-17 21:02:59.089066
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    converter = TestConverterPlugin('text/plain')
    assert converter.convert(b'abc') == 'abc'


# Generated at 2022-06-17 21:03:04.044567
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        auth_type = 'my-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return username, password

    auth = AuthPlugin()
    assert auth.get_auth('user', 'pass') == ('user', 'pass')


# Generated at 2022-06-17 21:03:08.536691
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test description'

    plugin = TestPlugin()
    assert plugin.name == 'test'
    assert plugin.description == 'test description'
    assert plugin.package_name == 'httpie_test'


# Generated at 2022-06-17 21:03:10.606576
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    plugin = BasePlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None


# Generated at 2022-06-17 21:03:13.201028
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        pass
    plugin = TestPlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None


# Generated at 2022-06-17 21:03:19.925642
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test plugin'
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None
        prefix = None
        group_name = 'format'
        enabled = True
        kwargs = {}
        format_options = {}

    plugin = TestPlugin()
    assert plugin.name == 'test'
    assert plugin.description == 'test plugin'
    assert plugin.auth_type == 'test'
    assert plugin.auth_require == True
    assert plugin.auth_parse == True
    assert plugin.netrc_parse == False
    assert plugin.prompt_password == True
    assert plugin.raw_auth == None
    assert plugin.prefix

# Generated at 2022-06-17 21:03:27.909288
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    plugin = TestFormatterPlugin(format_options=None)
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert plugin.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''



# Generated at 2022-06-17 21:04:09.535800
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test_test'


# Generated at 2022-06-17 21:04:16.821452
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''


# Generated at 2022-06-17 21:04:24.072511
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''
HTTP/1.1 200 OK
	Content-Type: application/json

'''


# Generated at 2022-06-17 21:04:27.181354
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class MyTransportPlugin(TransportPlugin):
        prefix = 'my-transport'

        def get_adapter(self):
            return None

    plugin = MyTransportPlugin()
    assert plugin.prefix == 'my-transport'


# Generated at 2022-06-17 21:04:38.120896
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = 'my-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return None

    auth = AuthPlugin()
    assert auth.auth_type == 'my-auth'
    assert auth.auth_require == True
    assert auth.auth_parse == True
    assert auth.netrc_parse == False
    assert auth.prompt_password == True
    assert auth.raw_auth == None
    assert auth.get_auth() == None


# Generated at 2022-06-17 21:04:43.660590
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    converter = TestConverterPlugin('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 21:04:47.034114
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    plugin = BasePlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None


# Generated at 2022-06-17 21:04:55.058642
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return username, password

    auth = AuthPlugin()
    assert auth.get_auth('username', 'password') == ('username', 'password')


# Generated at 2022-06-17 21:04:59.663052
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = None
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            raise NotImplementedError()

    AuthPlugin()


# Generated at 2022-06-17 21:05:05.075383
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    assert TestConverterPlugin('application/json').mime == 'application/json'
