

# Generated at 2022-06-17 20:56:14.877726
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin().format_headers(headers) == headers.replace('\n', '\n\n')


# Generated at 2022-06-17 20:56:19.513510
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body("test", "application/json") == "test"


# Generated at 2022-06-17 20:56:26.491067
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    Content-Length: 2
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json Content-Length: 2 '


# Generated at 2022-06-17 20:56:30.355317
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:56:35.951802
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
\r
'''


# Generated at 2022-06-17 20:56:42.354198
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('foo: bar\nbaz: qux\n') == 'foo: bar\n\tbaz: qux\n'



# Generated at 2022-06-17 20:56:46.236962
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:56:53.677881
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('aaa', 'text/plain') == 'bbb'



# Generated at 2022-06-17 20:56:59.122671
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin()
    assert test_formatter_plugin.format_body("test", "test") == "test"



# Generated at 2022-06-17 20:57:04.429088
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/html') == 'test'



# Generated at 2022-06-17 20:57:09.936270
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'


# Generated at 2022-06-17 20:57:15.852861
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', ' ')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

# Generated at 2022-06-17 20:57:22.108931
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 20:57:25.409536
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    fp = FormatterPlugin_test(format_options={})
    assert fp.format_headers("test") == "test"


# Generated at 2022-06-17 20:57:28.147621
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test'

# Generated at 2022-06-17 20:57:32.891205
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('content', 'mime') == 'content_test'

# Generated at 2022-06-17 20:57:35.953287
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers("test") == "test"



# Generated at 2022-06-17 20:57:39.163213
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content + '_formatted'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('content', 'mime') == 'content_formatted'

# Generated at 2022-06-17 20:57:43.764771
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json

'''



# Generated at 2022-06-17 20:57:47.199327
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 20:57:52.745245
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:57:55.851700
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', ' ')

    assert TestFormatterPlugin(format_options={}).format_headers(
        '''HTTP/1.1 200 OK
Content-Type: application/json

''') == 'HTTP/1.1 200 OK Content-Type: application/json '



# Generated at 2022-06-17 20:57:57.905446
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body("test", "") == "test"


# Generated at 2022-06-17 20:58:02.174144
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test_test'



# Generated at 2022-06-17 20:58:06.806087
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return 'test'

    tfp = TestFormatterPlugin(format_options=None)
    assert tfp.format_body('', '') == 'test'


# Generated at 2022-06-17 20:58:12.201604
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json

'''


# Generated at 2022-06-17 20:58:17.025060
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return "test"

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body("", "") == "test"



# Generated at 2022-06-17 20:58:22.521289
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d\n') == 'a: b c: d '


# Generated at 2022-06-17 20:58:26.315864
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_headers('test') == 'test'


# Generated at 2022-06-17 20:58:32.105838
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 20:58:39.827390
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + "test"

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "") == "testtest"

# Generated at 2022-06-17 20:58:42.071712
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 20:58:47.504857
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\r\n', '\n')

    formatter = FormatterPlugin_test(format_options={})
    assert formatter.format_headers('a: b\r\nc: d\r\n') == 'a: b\nc: d\n'



# Generated at 2022-06-17 20:59:00.470095
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

'''

# Generated at 2022-06-17 20:59:06.338383
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\nc: d') == 'a: b c: d'



# Generated at 2022-06-17 20:59:13.493954
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert plugin.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:59:17.046824
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body("test", "test") == "test"


# Generated at 2022-06-17 20:59:22.232070
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('foo: bar\n') == 'foo: bar\n\t'


# Generated at 2022-06-17 20:59:32.031802
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    class Environment:
        def __init__(self):
            self.stdout = io.StringIO()

    env = Environment()
    formatter = FormatterPlugin(env=env, format_options={})

# Generated at 2022-06-17 20:59:37.064288
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''Content-Type: application/json
\tContent-Length: 2

'''



# Generated at 2022-06-17 20:59:49.844542
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import httpie.plugins
    httpie.plugins.load_plugins()
    for plugin in httpie.plugins.formatter_plugins:
        if plugin.name == 'JSON':
            break
    else:
        raise RuntimeError('JSON plugin not found')
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Date: Thu, 26 Mar 2020 19:18:28 GMT
Server: Apache/2.4.18 (Ubuntu)
Vary: Accept-Encoding
Content-Length: 2
Connection: close

'''
    assert plugin.format_headers(headers) == headers


# Generated at 2022-06-17 20:59:58.419825
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''

# Generated at 2022-06-17 21:00:02.841495
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:00:07.508839
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    p = TestFormatterPlugin(format_options={})
    assert p.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:00:11.155602
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')
    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a b c'


# Generated at 2022-06-17 21:00:15.876458
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:20.499223
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin().format_body("test", "application/json") == "test"


# Generated at 2022-06-17 21:00:25.815305
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('Content-Type: application/json\r\n') == 'Content-Type: application/json\n'


# Generated at 2022-06-17 21:00:32.336614
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert MyFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '


# Generated at 2022-06-17 21:00:37.066097
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:55.908006
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(BasePlugin):
        prefix = None

        def get_adapter(self):
            raise NotImplementedError()

    tp = TransportPlugin()
    assert tp.prefix == None


# Generated at 2022-06-17 21:01:02.959024
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth'
        auth_parse = True
        auth_require = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return requests.auth.HTTPBasicAuth(username, password)

    plugin = MyAuthPlugin()
    assert plugin.get_auth('user', 'pass') == requests.auth.HTTPBasicAuth('user', 'pass')

# Generated at 2022-06-17 21:01:04.731887
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'text/plain') == 'b'


# Generated at 2022-06-17 21:01:13.812750
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    env = Environment(stdout=None, stderr=None, stdin=None)
    formatter = FormatterPlugin(env=env, format_options=None)
    assert formatter.enabled == True
    assert formatter.kwargs == {'env': env, 'format_options': None}
    assert formatter.format_options == None
    assert formatter.format_headers('headers') == 'headers'
    assert formatter.format_body('content', 'mime') == 'content'

# Generated at 2022-06-17 21:01:16.324787
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    plugin = BasePlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None


# Generated at 2022-06-17 21:01:21.997925
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    fp = TestFormatterPlugin(**{'format_options': {}})
    assert fp.format_body('test', 'application/json') == 'test\n'

# Generated at 2022-06-17 21:01:26.686840
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:01:38.277505
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test plugin'
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None
        prefix = 'test'
        group_name = 'test'
        enabled = True
        kwargs = {'format_options': 'test'}
        format_options = 'test'

    test_plugin = TestPlugin()
    assert test_plugin.name == 'test'
    assert test_plugin.description == 'test plugin'
    assert test_plugin.auth_type == 'test'
    assert test_plugin.auth_require == True
    assert test_plugin.auth_parse == True
    assert test_plugin.netrc_parse == False

# Generated at 2022-06-17 21:01:42.216736
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('test') == 'test'



# Generated at 2022-06-17 21:01:46.731878
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'Test Plugin'
        description = 'Test Plugin Description'
    plugin = TestPlugin()
    assert plugin.name == 'Test Plugin'
    assert plugin.description == 'Test Plugin Description'
    assert plugin.package_name == 'httpie_plugins.test_plugin'


# Generated at 2022-06-17 21:02:15.322882
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            pass

    auth = TestAuthPlugin()
    assert auth.auth_type == 'test-auth'
    assert auth.auth_require == True
    assert auth.auth_parse == True
    assert auth.netrc_parse == False
    assert auth.prompt_password == True
    assert auth.raw_auth == None


# Generated at 2022-06-17 21:02:18.534255
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin(BasePlugin):
        def get_adapter(self):
            return 'adapter'

    plugin = TransportPlugin()
    assert plugin.get_adapter() == 'adapter'


# Generated at 2022-06-17 21:02:23.839767
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = TestConverterPlugin('text/plain')
    assert plugin.mime == 'text/plain'
    assert plugin.convert(b'foo') == 'foo'
    assert plugin.supports('text/plain')
    assert not plugin.supports('text/html')


# Generated at 2022-06-17 21:02:31.874786
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:02:38.199176
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = None
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            pass

    auth = AuthPlugin()
    assert auth.auth_type == None
    assert auth.auth_require == True
    assert auth.auth_parse == True
    assert auth.netrc_parse == False
    assert auth.prompt_password == True
    assert auth.raw_auth == None


# Generated at 2022-06-17 21:02:41.685954
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'
        def get_adapter(self):
            return 'test'
    t = TestTransportPlugin()
    assert t.prefix == 'test'
    assert t.get_adapter() == 'test'


# Generated at 2022-06-17 21:02:45.730022
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    try:
        BasePlugin()
    except NotImplementedError:
        print("BasePlugin constructor is not implemented")
    else:
        print("BasePlugin constructor is implemented")


# Generated at 2022-06-17 21:02:53.931476
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    test_headers = '''HTTP/1.1 200 OK
Date: Wed, 22 Apr 2020 09:40:40 GMT
Server: Apache/2.4.41 (Ubuntu)
Last-Modified: Wed, 22 Apr 2020 09:40:40 GMT
ETag: "2a-5a8f7c6d7b6c0"
Accept-Ranges: bytes
Content-Length: 42
Content-Type: text/html

'''

# Generated at 2022-06-17 21:02:58.958440
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test'
    assert TestPlugin().name == 'test'
    assert TestPlugin().description == 'test'
    assert TestPlugin().package_name == 'httpie_test'


# Generated at 2022-06-17 21:03:01.524641
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return None

    assert TestTransportPlugin(None).get_adapter() is None


# Generated at 2022-06-17 21:03:44.331741
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'

# Generated at 2022-06-17 21:03:53.202154
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = None
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            raise NotImplementedError()

    auth_plugin = AuthPlugin()
    assert auth_plugin.auth_type == None
    assert auth_plugin.auth_require == True
    assert auth_plugin.auth_parse == True
    assert auth_plugin.netrc_parse == False
    assert auth_plugin.prompt_password == True
    assert auth_plugin.raw_auth == None


# Generated at 2022-06-17 21:03:59.262834
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'TEST'


# Generated at 2022-06-17 21:04:03.280069
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return None

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.package_name == 'httpie.plugins.transport.test'


# Generated at 2022-06-17 21:04:05.887568
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        def get_auth(self, username=None, password=None):
            return username, password
    auth_plugin = AuthPlugin()
    assert auth_plugin.get_auth('user', 'pass') == ('user', 'pass')


# Generated at 2022-06-17 21:04:12.394201
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class MyConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    assert MyConverterPlugin('text/plain').convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:04:17.138399
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    from httpie.plugins import FormatterPlugin
    env = Environment()
    formatter = FormatterPlugin(env=env, format_options={})
    assert formatter.enabled
    assert formatter.kwargs == {'env': env, 'format_options': {}}
    assert formatter.format_options == {}
    assert formatter.format_headers('headers') == 'headers'
    assert formatter.format_body('content', 'mime') == 'content'


# Generated at 2022-06-17 21:04:24.284221
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    env = Environment()
    formatter = FormatterPlugin(env=env, format_options=None)
    assert formatter.enabled == True
    assert formatter.kwargs == {'env': env, 'format_options': None}
    assert formatter.format_options == None
    assert formatter.format_headers('headers') == 'headers'
    assert formatter.format_body('content', 'mime') == 'content'

# Generated at 2022-06-17 21:04:31.092329
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test plugin'
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

    test_plugin = TestPlugin()
    assert test_plugin.name == 'test'
    assert test_plugin.description == 'test plugin'
    assert test_plugin.auth_type == 'test'
    assert test_plugin.auth_require == True
    assert test_plugin.auth_parse == True
    assert test_plugin.netrc_parse == False
    assert test_plugin.prompt_password == True
    assert test_plugin.raw_auth == None


# Generated at 2022-06-17 21:04:39.013020
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\n')
    tfp = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert tfp.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''
