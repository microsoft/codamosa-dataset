

# Generated at 2022-06-17 20:56:10.214904
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin().format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 20:56:15.462232
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b c: d'


# Generated at 2022-06-17 20:56:20.779553
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "") == "test"



# Generated at 2022-06-17 20:56:25.278222
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:56:28.243982
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body("test", "application/atom+xml") == "test"



# Generated at 2022-06-17 20:56:32.849676
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test_test'



# Generated at 2022-06-17 20:56:36.939007
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = FormatterPlugin_test(format_options={})
    assert fp.format_body('test', 'application/atom+xml') == 'test'


# Generated at 2022-06-17 20:56:40.833571
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(test_headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:56:45.689125
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPluginTest(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = FormatterPluginTest(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 20:56:52.401213
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "test") == "test"



# Generated at 2022-06-17 20:56:57.496432
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\r\n') == 'a: b\n'


# Generated at 2022-06-17 20:57:02.700492
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 20:57:08.154386
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 20:57:15.020267
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments.token import Token
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments.token import Token
    import pytest
    import re
    import os
    import sys
    import pytest
    import re
    import os
    import sys

    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers


# Generated at 2022-06-17 20:57:21.072781
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:57:24.887104
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_formatted'

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('content', 'mime') == 'content_formatted'

# Generated at 2022-06-17 20:57:27.943440
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:57:32.891119
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:57:36.238295
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 20:57:44.007981
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''



# Generated at 2022-06-17 20:57:54.560921
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_headers('test') == 'test'


# Generated at 2022-06-17 20:57:59.848300
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "test") == "test"


# Generated at 2022-06-17 20:58:03.336527
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:58:12.461141
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    import httpie.plugins
    httpie.plugins.__path__.append('/home/travis/build/httpie/httpie/tests/plugins')
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    formatter = FormatterPlugin()
    assert formatter.format_body('{"foo": "bar"}', 'application/json') == '{\n    "foo": "bar"\n}'
    assert formatter.format_body('{"foo": "bar"}', 'application/xml') == '<?xml version="1.0" encoding="UTF-8"?>\n<root>\n  <foo>bar</foo>\n</root>'

# Generated at 2022-06-17 20:58:17.654861
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('hello', 'text/plain') == 'HELLO'



# Generated at 2022-06-17 20:58:21.922937
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.upper()

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('test') == 'TEST'


# Generated at 2022-06-17 20:58:26.553646
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'
    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test\n'


# Generated at 2022-06-17 20:58:32.010728
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "test") == "test"

# Generated at 2022-06-17 20:58:37.180172
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    env = Environment()
    formatter = TestFormatterPlugin(env=env, format_options={})
    assert formatter.format_headers('foo: bar\nbaz: qux') == 'foo: bar\r\nbaz: qux'


# Generated at 2022-06-17 20:58:40.766429
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 20:58:54.233493
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('aaa', 'text/plain') == 'bbb'



# Generated at 2022-06-17 20:58:59.653433
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:59:02.094572
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    assert TestFormatterPlugin(format_options=None).format_headers('test') == 'TEST'


# Generated at 2022-06-17 20:59:07.373039
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:59:11.989032
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_body('\n', 'text/plain') == '\n\t'


# Generated at 2022-06-17 20:59:14.840381
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "") == "test"

# Generated at 2022-06-17 20:59:17.556328
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('foo', 'text/plain') == 'foo\n'


# Generated at 2022-06-17 20:59:22.638301
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'


# Generated at 2022-06-17 20:59:27.208779
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\nb\n\nc'


# Generated at 2022-06-17 20:59:32.187041
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d\n') == 'a: b\n\tc: d\n'


# Generated at 2022-06-17 20:59:47.871224
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 20:59:53.821168
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Test 1
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter_plugin = TestFormatterPlugin(**{'format_options': {}})
    assert test_formatter_plugin.format_headers('test') == 'test'

    # Test 2
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter_plugin = TestFormatterPlugin(**{'format_options': {}})
    assert test_formatter_plugin.format_headers('test') == 'test'



# Generated at 2022-06-17 20:59:58.460193
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 21:00:03.444663
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '


# Generated at 2022-06-17 21:00:06.720437
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter_plugin = TestFormatterPlugin(format_options=None)
    assert test_formatter_plugin.format_headers('test_headers') == 'test_headers'


# Generated at 2022-06-17 21:00:10.806511
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'
    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_body('test', 'application/json') == 'test_test'

# Generated at 2022-06-17 21:00:15.440439
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:20.857813
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    fp = FormatterPlugin_test(format_options={})
    assert fp.format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 21:00:25.789298
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\nc: d') == 'a: b c: d'


# Generated at 2022-06-17 21:00:30.296925
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return 'test'

    assert TestFormatterPlugin(format_options={}).format_body('', '') == 'test'



# Generated at 2022-06-17 21:00:59.349277
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    f = TestFormatterPlugin(format_options=None)
    assert f.format_headers("test") == "test"


# Generated at 2022-06-17 21:01:01.204973
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('foo: bar\nbar: baz') == 'foo: bar\n\tbar: baz'



# Generated at 2022-06-17 21:01:07.358294
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from pygments.lexers import HtmlLexer
    from pygments.lexers import XmlLexer
    from pygments.lexers import JavascriptLexer
    from pygments.lexers import PythonLexer
    from pygments.lexers import YamlLexer
    from pygments.lexers import TextLexer
    from pygments.lexers import get_lexer_by_name
    from pygments.lexers import get_lexer_for_mimetype
    from pygments.lexers import get_lexer_for_filename
    from pygments.lexers import get_lexer_by_name

# Generated at 2022-06-17 21:01:13.482092
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:01:18.605481
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')
    assert TestFormatterPlugin(format_options={}).format_body('\n', 'application/json') == '\n\t'


# Generated at 2022-06-17 21:01:22.996462
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test\n'

# Generated at 2022-06-17 21:01:29.744901
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')
    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 2
Date: Mon, 27 Jul 2015 01:01:01 GMT

'''
    assert plugin.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json; charset=utf-8
\tContent-Length: 2
\tDate: Mon, 27 Jul 2015 01:01:01 GMT

'''


# Generated at 2022-06-17 21:01:39.329370
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''\
HTTP/1.1 200 OK
Content-Length: 0
Content-Type: text/plain; charset=utf-8
Date: Thu, 03 Jan 2019 17:10:09 GMT
Server: TestServer
'''
    expected = '''\
HTTP/1.1 200 OK
	Content-Length: 0
	Content-Type: text/plain; charset=utf-8
	Date: Thu, 03 Jan 2019 17:10:09 GMT
	Server: TestServer
'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == expected


# Generated at 2022-06-17 21:01:43.976196
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b\r\nc: d'


# Generated at 2022-06-17 21:01:47.589652
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 21:02:44.122522
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('\n\n\n', 'application/json') == '\n\t\n\t\n\t'



# Generated at 2022-06-17 21:02:51.610213
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    headers = '''HTTP/1.1 200 OK
Date: Tue, 24 Sep 2019 05:00:00 GMT
Server: Apache/2.4.29 (Ubuntu)
Last-Modified: Mon, 23 Sep 2019 05:00:00 GMT
ETag: "10000000565a5-5b7f-5824bccc2e680"
Accept-Ranges: bytes
Content-Length: 1468
Vary: Accept-Encoding
Content-Type: text/html

'''
    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers(headers) == headers


# Generated at 2022-06-17 21:03:01.284343
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_headers = 'HTTP/1.1 200 OK\r\n' \
                   'Content-Type: text/html; charset=utf-8\r\n' \
                   'Content-Length: 13\r\n' \
                   'Connection: keep-alive\r\n' \
                   'Server: gunicorn/19.9.0\r\n' \
                   'Date: Sat, 01 Dec 2018 11:35:32 GMT\r\n' \
                   '\r\n' \
                   'Hello, World!'

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers(test_headers) == test_headers


# Generated at 2022-06-17 21:03:05.942321
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options=None)
    assert plugin.format_headers('a: b\nc: d\n') == 'a: b\n\tc: d\n'


# Generated at 2022-06-17 21:03:13.364582
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers
    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

'''
    assert formatter.format_headers(headers) == headers


# Generated at 2022-06-17 21:03:20.005111
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''


# Generated at 2022-06-17 21:03:24.985907
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'TEST'


# Generated at 2022-06-17 21:03:28.688126
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + "test"

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "") == "testtest"

# Generated at 2022-06-17 21:03:37.913902
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert test_formatter_plugin.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 21:03:47.480919
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')


# Generated at 2022-06-17 21:05:40.698229
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''



# Generated at 2022-06-17 21:05:43.357904
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatter(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\r\n')

    assert MyFormatter(format_options={}).format_headers('a\nb\nc') == 'a\r\nb\r\nc'


# Generated at 2022-06-17 21:05:48.433445
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\tb\n\tc'



# Generated at 2022-06-17 21:05:59.949454
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''



# Generated at 2022-06-17 21:06:03.531224
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_body('aaa', 'text/plain') == 'bbb'



# Generated at 2022-06-17 21:06:06.995178
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return 'test'

    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_headers('test') == 'test'
