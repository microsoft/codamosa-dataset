

# Generated at 2022-06-17 20:56:13.469427
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:56:23.068517
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('\n') == '\n\t'
    assert test_formatter.format_headers('\n\n') == '\n\t\n\t'
    assert test_formatter.format_headers('\n\n\n') == '\n\t\n\t\n\t'


# Generated at 2022-06-17 20:56:28.534354
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')
    assert TestFormatterPlugin(format_options={}).format_headers('\n') == '\n\t'


# Generated at 2022-06-17 20:56:33.091163
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('hello', 'text/plain') == 'HELLO'



# Generated at 2022-06-17 20:56:37.349220
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:56:47.300682
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

# Generated at 2022-06-17 20:56:58.471788
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    test_formatter = TestFormatterPlugin(format_options=None)
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert test_formatter.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''


# Generated at 2022-06-17 20:57:02.838736
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'

# Generated at 2022-06-17 20:57:05.218541
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json

'''


# Generated at 2022-06-17 20:57:09.646238
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 20:57:23.453326
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_

# Generated at 2022-06-17 20:57:34.423176
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_

# Generated at 2022-06-17 20:57:39.683563
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 20:57:41.555326
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('\r\n') == '\n'


# Generated at 2022-06-17 20:57:44.318534
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return 'test'

    assert TestFormatterPlugin(format_options={}).format_body('', '') == 'test'


# Generated at 2022-06-17 20:57:48.010653
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('\n\n\n', '') == '\n\t\n\t\n\t'



# Generated at 2022-06-17 20:57:55.358463
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(**{'format_options': {}})
    assert plugin.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:57:57.683771
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "") == "test"


# Generated at 2022-06-17 20:58:01.732566
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')
    fp = TestFormatterPlugin(**{'format_options': {'format': 'test'}})
    assert fp.format_body('test\ntest\ntest', 'text/plain') == '\ttest\n\ttest\n\ttest'



# Generated at 2022-06-17 20:58:06.131988
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('headers') == 'headers'


# Generated at 2022-06-17 20:58:16.245486
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert plugin.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''


# Generated at 2022-06-17 20:58:23.848334
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace("\n", " ")

    headers = """
    HTTP/1.1 200 OK
    Content-Type: application/json
    Content-Length: 2
    """
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == """
    HTTP/1.1 200 OK Content-Type: application/json Content-Length: 2
    """


# Generated at 2022-06-17 20:58:29.971623
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:58:34.551702
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\tb\n\tc'


# Generated at 2022-06-17 20:58:41.464176
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    test_plugin = TestFormatterPlugin(format_options={})
    test_headers = '''HTTP/1.1 200 OK
Date: Tue, 21 Jan 2020 18:28:05 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Tue, 21 Jan 2020 18:28:05 GMT
ETag: "2d-5a4b4d4c4b0a0"
Accept-Ranges: bytes
Content-Length: 45
Vary: Accept-Encoding
Content-Type: text/html

'''

# Generated at 2022-06-17 20:58:47.548169
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', ' ')

    fp = TestFormatterPlugin(format_options=None)
    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert fp.format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '



# Generated at 2022-06-17 20:58:55.202994
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 20:58:58.603275
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/html') == 'test_test'

# Generated at 2022-06-17 20:59:01.527291
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_plugin = TestFormatterPlugin(format_options={})
    assert test_plugin.format_body("test", "test") == "test"

# Generated at 2022-06-17 20:59:04.134389
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')
    assert TestFormatterPlugin(format_options={}).format_headers('a: b\r\nc: d') == 'a: b\nc: d'


# Generated at 2022-06-17 20:59:11.696636
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/html') == 'test'



# Generated at 2022-06-17 20:59:14.347748
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 20:59:18.815297
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\r\nc: d\r\n') == 'a: b\nc: d\n'


# Generated at 2022-06-17 20:59:26.740948
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''
HTTP/1.1 200 OK
	Content-Type: application/json
	Content-Length: 2

'''


# Generated at 2022-06-17 20:59:32.415321
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    class TestEnvironment:
        def __init__(self):
            self.formatter = TestFormatterPlugin(format_options={})

    env = TestEnvironment()
    assert env.formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:59:35.792475
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test\n'

# Generated at 2022-06-17 20:59:38.796671
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "application/json") == "test"



# Generated at 2022-06-17 20:59:44.648813
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    assert FormatterPlugin_test(format_options={}).format_body('test', 'test') == 'testtest'


# Generated at 2022-06-17 20:59:48.252861
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body("test", "application/atom+xml") == "test"



# Generated at 2022-06-17 20:59:57.557887
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''



# Generated at 2022-06-17 21:00:07.267854
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('a', 'text/plain') == 'b'


# Generated at 2022-06-17 21:00:12.740676
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK\nContent-Type: text/plain\n\n'


# Generated at 2022-06-17 21:00:22.016879
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    fp = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert fp.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''



# Generated at 2022-06-17 21:00:26.489130
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')
    assert TestFormatterPlugin(format_options=None).format_headers('a\nb\nc') == 'a\n\tb\n\tc'


# Generated at 2022-06-17 21:00:32.541267
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    plugin = TestFormatterPlugin(format_options=None)
    assert plugin.format_headers('a: b\nc: d\n') == 'a: b\n\nc: d\n\n'


# Generated at 2022-06-17 21:00:37.693524
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    formatter = FormatterPlugin_test(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test_test'


# Generated at 2022-06-17 21:00:41.609826
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(**{'format_options': {}})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 21:00:51.735610
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Test with empty headers
    headers = ''
    formatter = FormatterPlugin()
    assert formatter.format_headers(headers) == ''

    # Test with headers with no newlines
    headers = 'HTTP/1.1 200 OK'
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK'

    # Test with headers with newlines
    headers = 'HTTP/1.1 200 OK\nContent-Type: application/json'
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK\nContent-Type: application/json'

    # Test with headers with newlines and spaces
    headers = 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'

# Generated at 2022-06-17 21:00:59.157774
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(**{'format_options': {}})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 21:01:03.508517
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 21:01:22.095110
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = FormatterPlugin_test(**{'format_options': {}})
    assert fp.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:01:27.559258
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK\nContent-Type: text/html\n\n'


# Generated at 2022-06-17 21:01:33.187758
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 21:01:38.043299
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\nc: d') == 'a: b c: d'



# Generated at 2022-06-17 21:01:42.041287
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 21:01:48.745575
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert test_formatter.format_headers(headers) == '''HTTP/1.1 200 OK\r
Content-Type: application/json\r
Content-Length: 2\r
\r
'''

# Generated at 2022-06-17 21:01:51.362730
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')
    assert TestFormatterPlugin(format_options={}).format_headers('\n') == '\r\n'


# Generated at 2022-06-17 21:01:56.991207
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:02:00.726519
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    assert TestFormatterPlugin().format_headers('\n') == ' '


# Generated at 2022-06-17 21:02:08.417189
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert test_formatter_plugin.format_headers(headers) == '''
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 21:03:00.604536
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test-auth'
        auth_parse = True

        def get_auth(self, username=None, password=None):
            return username, password

    plugin = TestAuthPlugin()
    assert plugin.get_auth('user', 'pass') == ('user', 'pass')
    assert plugin.get_auth() == (None, None)
    assert plugin.get_auth(username='user') == ('user', None)
    assert plugin.get_auth(password='pass') == (None, 'pass')

    plugin = TestAuthPlugin()
    plugin.auth_parse = False
    assert plugin.get_auth('user', 'pass') == (None, None)
    assert plugin.get_auth() == (None, None)

# Generated at 2022-06-17 21:03:10.393232
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        """
        Base auth plugin class.

        See httpie-ntlm for an example auth plugin:

            <https://github.com/httpie/httpie-ntlm>

        See also `test_auth_plugins.py`

        """
        # The value that should be passed to --auth-type
        # to use this auth plugin. Eg. "my-auth"
        auth_type = None

        # Set to `False` to make it possible to invoke this auth
        # plugin without requiring the user to specify credentials
        # through `--auth, -a`.
        auth_require = True

        # By default the `-a` argument is parsed for `username:password`.
        # Set this to `False` to disable the parsing and error handling.
        auth_parse = True

        # Set to `

# Generated at 2022-06-17 21:03:12.996271
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'

    plugin = TestPlugin()
    assert plugin.name == 'test'
    assert plugin.package_name == 'test'


# Generated at 2022-06-17 21:03:17.504425
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\n')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('\n', '') == '\n\n'
    assert fp.format_body('\n\n', '') == '\n\n\n\n'



# Generated at 2022-06-17 21:03:27.638065
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = 'my-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return None

    auth_plugin = AuthPlugin()
    assert auth_plugin.auth_type == 'my-auth'
    assert auth_plugin.auth_require == True
    assert auth_plugin.auth_parse == True
    assert auth_plugin.netrc_parse == False
    assert auth_plugin.prompt_password == True
    assert auth_plugin.get_auth() == None


# Generated at 2022-06-17 21:03:30.213409
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'



# Generated at 2022-06-17 21:03:33.883572
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    assert TestTransportPlugin().get_adapter() == 'test'



# Generated at 2022-06-17 21:03:41.175433
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return username, password

    plugin = AuthPlugin()
    plugin.raw_auth = 'test:test'
    username, password = plugin.get_auth()
    assert username == 'test'
    assert password == 'test'

# Generated at 2022-06-17 21:03:42.931500
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    assert BasePlugin.name == None
    assert BasePlugin.description == None
    assert BasePlugin.package_name == None


# Generated at 2022-06-17 21:03:47.174727
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    t = TestConverterPlugin('application/json')
    assert t.mime == 'application/json'



# Generated at 2022-06-17 21:04:35.408884
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes
        @classmethod
        def supports(cls, mime):
            return True
    converter_plugin = TestConverterPlugin('test')
    assert converter_plugin.mime == 'test'


# Generated at 2022-06-17 21:04:40.064688
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    test_plugin = TestConverterPlugin('application/json')
    assert test_plugin.mime == 'application/json'


# Generated at 2022-06-17 21:04:43.939067
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    converter = TestConverterPlugin('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 21:04:49.366490
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    from httpie.plugins import FormatterPlugin
    env = Environment()
    formatter = FormatterPlugin(env=env, format_options={})
    assert formatter.enabled == True
    assert formatter.kwargs == {'env': env, 'format_options': {}}
    assert formatter.format_options == {}


# Generated at 2022-06-17 21:04:54.710302
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class MyPlugin(BasePlugin):
        name = 'My Plugin'
        description = 'My plugin description'

    plugin = MyPlugin()
    assert plugin.name == 'My Plugin'
    assert plugin.description == 'My plugin description'
    assert plugin.package_name is None


# Generated at 2022-06-17 21:04:58.618108
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.plugins import FormatterPlugin
    from httpie.environment import Environment
    env = Environment()
    formatter = FormatterPlugin(env=env, format_options={})
    assert formatter.enabled is True
    assert formatter.kwargs == {'env': env, 'format_options': {}}
    assert formatter.format_options == {}


# Generated at 2022-06-17 21:05:00.820161
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class MyTransportPlugin(TransportPlugin):
        prefix = 'my-transport'

        def get_adapter(self):
            return 'adapter'

    plugin = MyTransportPlugin()
    assert plugin.get_adapter() == 'adapter'



# Generated at 2022-06-17 21:05:06.852156
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = None
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            raise NotImplementedError()

    auth_plugin = AuthPlugin()
    assert auth_plugin.auth_type is None
    assert auth_plugin.auth_require is True
    assert auth_plugin.auth_parse is True
    assert auth_plugin.netrc_parse is False
    assert auth_plugin.prompt_password is True
    assert auth_plugin.raw_auth is None


# Generated at 2022-06-17 21:05:13.137802
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    t = TestConverterPlugin('application/json')
    assert t.mime == 'application/json'


# Generated at 2022-06-17 21:05:20.473898
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class ConverterPluginTest(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    converter_plugin = ConverterPluginTest('text/plain')
    assert converter_plugin.mime == 'text/plain'
