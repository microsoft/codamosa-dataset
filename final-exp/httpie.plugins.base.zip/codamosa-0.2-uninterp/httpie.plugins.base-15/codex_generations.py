

# Generated at 2022-06-17 20:56:11.531176
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    formatter_plugin = TestFormatterPlugin(**{'format_options': {}})
    assert formatter_plugin.format_body('test', 'application/atom+xml') == 'test'


# Generated at 2022-06-17 20:56:16.896559
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/atom+xml') == 'testtest'

# Generated at 2022-06-17 20:56:24.889488
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK
	Content-Type: application/json
	Content-Length: 2

'''


# Generated at 2022-06-17 20:56:30.663558
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:56:34.214685
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 20:56:41.454253
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert plugin.format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''



# Generated at 2022-06-17 20:56:49.776498
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    headers = '''\
HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Content-Type: text/html; charset=UTF-8
Content-Encoding: UTF-8
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
ETag: "3f80f-1b6-3e1cb03b"
Content-Length: 138
Accept-Ranges: bytes
Connection: close

'''

# Generated at 2022-06-17 20:56:56.867624
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b\n\nc: d'


# Generated at 2022-06-17 20:57:00.752940
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "text/plain") == "test"



# Generated at 2022-06-17 20:57:05.675353
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 20:57:11.026374
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 20:57:16.590567
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body("test", "text/plain") == "test"

# Generated at 2022-06-17 20:57:19.799323
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('a', 'mime') == 'b'


# Generated at 2022-06-17 20:57:24.494683
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options=None)
    assert test_formatter_plugin.format_body("test", "test") == "test"



# Generated at 2022-06-17 20:57:26.632346
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'testtest'



# Generated at 2022-06-17 20:57:29.649430
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('test', 'TEST')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'TEST'



# Generated at 2022-06-17 20:57:38.986927
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    import json
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments import highlight
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments import highlight
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments import highlight
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer

# Generated at 2022-06-17 20:57:43.074780
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body("test", "application/json") == "test"


# Generated at 2022-06-17 20:57:47.045018
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('aaa', 'text/plain') == 'bbb'


# Generated at 2022-06-17 20:57:54.982519
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'text/html') == 'test\n'


# Generated at 2022-06-17 20:58:01.138206
# Unit test for constructor of class BasePlugin

# Generated at 2022-06-17 20:58:05.114624
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return 'test'

    assert TestFormatterPlugin(format_options={}).format_headers('test') == 'test'


# Generated at 2022-06-17 20:58:05.446531
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    BasePlugin()

# Generated at 2022-06-17 20:58:15.000160
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth'

        def get_auth(self, username=None, password=None):
            return 'MyAuth(%s, %s)' % (username, password)

    plugin = MyAuthPlugin()
    assert plugin.get_auth('user', 'pass') == 'MyAuth(user, pass)'
    assert plugin.get_auth(username='user', password='pass') == 'MyAuth(user, pass)'
    assert plugin.get_auth(password='pass', username='user') == 'MyAuth(user, pass)'
    assert plugin.get_auth('user', password='pass') == 'MyAuth(user, pass)'

# Generated at 2022-06-17 20:58:18.196640
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 20:58:22.475082
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n  ')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert test_formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
  Content-Type: application/json
  Content-Length: 2

'''


# Generated at 2022-06-17 20:58:26.865491
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(**{'format_options': {}})
    assert test_formatter.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 20:58:36.038644
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = None
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            raise NotImplementedError()

    auth = AuthPlugin()
    assert auth.auth_type == None
    assert auth.auth_require == True
    assert auth.auth_parse == True
    assert auth.netrc_parse == False
    assert auth.prompt_password == True
    assert auth.raw_auth == None


# Generated at 2022-06-17 20:58:38.405544
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return None

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'


# Generated at 2022-06-17 20:58:41.464345
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    env = Environment()
    formatter = FormatterPlugin(env=env, format_options={})
    assert formatter.enabled == True
    assert formatter.kwargs == {'env': env, 'format_options': {}}
    assert formatter.format_options == {}


# Generated at 2022-06-17 20:58:48.221569
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(BasePlugin):
        prefix = None

        def get_adapter(self):
            raise NotImplementedError()

    tp = TransportPlugin()
    assert tp.name is None
    assert tp.description is None
    assert tp.package_name is None
    assert tp.prefix is None


# Generated at 2022-06-17 20:58:51.907452
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    assert TestTransportPlugin().prefix == 'test'
    assert TestTransportPlugin().get_adapter() == 'test'

# Generated at 2022-06-17 20:59:02.401629
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = True
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return requests.auth.HTTPBasicAuth(username, password)

    plugin = MyAuthPlugin()
    plugin.raw_auth = 'username:password'
    assert plugin.get_auth('username', 'password') is not None
    assert plugin.get_auth('username', 'password') is not None
    assert plugin.get_auth('username', 'password') is not None
    assert plugin.get_auth('username', 'password') is not None
    assert plugin.get_auth('username', 'password') is not None

# Generated at 2022-06-17 20:59:07.372508
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'

# Generated at 2022-06-17 20:59:11.697273
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    env = Environment()
    formatter = TestFormatterPlugin(env=env, format_options={})
    assert formatter.format_headers('headers') == 'headers'


# Generated at 2022-06-17 20:59:15.464689
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:59:19.699177
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    fp = TestFormatterPlugin(format_options={})
    assert fp.enabled
    assert fp.kwargs == {'format_options': {}}
    assert fp.format_options == {}


# Generated at 2022-06-17 20:59:26.940854
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return None

    plugin = AuthPlugin()
    assert plugin.auth_type == 'test'
    assert plugin.auth_require == True
    assert plugin.auth_parse == True
    assert plugin.netrc_parse == False
    assert plugin.prompt_password == True


# Generated at 2022-06-17 20:59:31.637970
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class ConverterPlugin(BasePlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = ConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'



# Generated at 2022-06-17 20:59:35.666090
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class MyConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    converter = MyConverterPlugin('text/plain')
    assert converter.convert(b'foo') == 'foo'



# Generated at 2022-06-17 20:59:46.581652
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'


# Generated at 2022-06-17 20:59:58.483910
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 12
Connection: keep-alive
Date: Mon, 02 Dec 2019 20:14:57 GMT

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: text/html; charset=utf-8
\tContent-Length: 12
\tConnection: keep-alive
\tDate: Mon, 02 Dec 2019 20:14:57 GMT

'''


# Generated at 2022-06-17 21:00:02.087532
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(TransportPlugin):
        prefix = 'foo'

        def get_adapter(self):
            return None

    tp = TransportPlugin()
    assert tp.prefix == 'foo'
    assert tp.get_adapter() is None


# Generated at 2022-06-17 21:00:07.497226
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        def get_auth(self, username=None, password=None):
            return username, password

    auth = AuthPlugin()
    assert auth.get_auth(username="user", password="pass") == ("user", "pass")


# Generated at 2022-06-17 21:00:11.117408
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test plugin'

    plugin = TestPlugin()
    assert plugin.name == 'test'
    assert plugin.description == 'test plugin'
    assert plugin.package_name == 'httpie.plugins.test'


# Generated at 2022-06-17 21:00:16.204554
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes
        @classmethod
        def supports(cls, mime):
            return True

    c = TestConverterPlugin('application/json')
    assert c.mime == 'application/json'


# Generated at 2022-06-17 21:00:21.303564
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()

    assert plugin.prefix == 'test'
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:00:26.114955
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    assert TestConverterPlugin('text/plain').convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:00:34.825465
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 21:00:38.110657
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin_test(TransportPlugin):
        prefix = 'test'
        def get_adapter(self):
            return 'test'

    assert TransportPlugin_test().get_adapter() == 'test'


# Generated at 2022-06-17 21:00:57.307841
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode()

        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('text/plain')
    assert plugin.mime == 'text/plain'
    assert plugin.convert(b'foo') == 'foo'
    assert plugin.supports('text/plain')


# Generated at 2022-06-17 21:01:01.990127
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_body("hello", "text/plain") == "hello"


# Generated at 2022-06-17 21:01:05.531471
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:01:09.308337
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin(BasePlugin):
        prefix = 'http+unix://'

        def get_adapter(self):
            return None

    transport_plugin = TransportPlugin()
    assert transport_plugin.get_adapter() is None

# Generated at 2022-06-17 21:01:16.909044
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            return None

    plugin = TestAuthPlugin()
    assert plugin.auth_type == 'test-auth'
    assert plugin.auth_require == True
    assert plugin.auth_parse == True
    assert plugin.netrc_parse == False
    assert plugin.prompt_password == True
    assert plugin.raw_auth == None


# Generated at 2022-06-17 21:01:23.171137
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('application/json')
    assert plugin.mime == 'application/json'


# Generated at 2022-06-17 21:01:27.818229
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            return username, password

    plugin = AuthPlugin()
    plugin.raw_auth = 'test:test'
    assert plugin.get_auth() == ('test', 'test')


# Generated at 2022-06-17 21:01:34.410230
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'application/json'

    plugin = TestConverterPlugin('application/json')
    assert plugin.convert(b'{"foo": "bar"}') == '{"foo": "bar"}'


# Generated at 2022-06-17 21:01:38.091800
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.get_adapter() == 'test'

# Generated at 2022-06-17 21:01:44.887842
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    env = Environment()
    kwargs = {'format_options': {'colors': True}}
    formatter = FormatterPlugin(**kwargs)
    assert formatter.enabled == True
    assert formatter.kwargs == kwargs
    assert formatter.format_options == {'colors': True}
    assert formatter.format_headers('headers') == 'headers'
    assert formatter.format_body('content', 'mime') == 'content'


# Generated at 2022-06-17 21:02:12.047473
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class BasePluginTest(BasePlugin):
        name = 'BasePluginTest'
        description = 'BasePluginTest description'
        auth_type = 'BasePluginTest auth_type'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None
        prefix = None

    base_plugin_test = BasePluginTest()
    assert base_plugin_test.name == 'BasePluginTest'
    assert base_plugin_test.description == 'BasePluginTest description'
    assert base_plugin_test.auth_type == 'BasePluginTest auth_type'
    assert base_plugin_test.auth_require == True
    assert base_plugin_test.auth_parse == True
    assert base_plugin_test.netrc_parse == False
    assert base_plugin_

# Generated at 2022-06-17 21:02:15.768865
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'

# Generated at 2022-06-17 21:02:19.596817
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            pass

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.package_name is None


# Generated at 2022-06-17 21:02:23.713224
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'application/json'

    converter = TestConverterPlugin('application/json')
    assert converter.convert(b'{"foo": "bar"}') == '{"foo": "bar"}'



# Generated at 2022-06-17 21:02:30.621105
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('abc', 'text/plain') == 'ABC'


# Generated at 2022-06-17 21:02:34.378487
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:02:36.532445
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    assert BasePlugin.name == None
    assert BasePlugin.description == None
    assert BasePlugin.package_name == None


# Generated at 2022-06-17 21:02:40.621148
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        def get_auth(self, username=None, password=None):
            return username, password

    auth = AuthPlugin()
    assert auth.get_auth('user', 'pass') == ('user', 'pass')



# Generated at 2022-06-17 21:02:46.042119
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "text/plain") == "test"

# Generated at 2022-06-17 21:02:50.095516
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(BasePlugin):
        """
        Requests transport adapter docs:

            <https://requests.readthedocs.io/en/latest/user/advanced/#transport-adapters>

        See httpie-unixsocket for an example transport plugin:

            <https://github.com/httpie/httpie-unixsocket>

        """

        # The URL prefix the adapter should be mount to.
        prefix = None

        def get_adapter(self):
            """
            Return a ``requests.adapters.BaseAdapter`` subclass instance to be
            mounted to ``self.prefix``.

            """
            raise NotImplementedError()

    assert TransportPlugin.prefix is None
    assert TransportPlugin.get_adapter is not None


# Generated at 2022-06-17 21:03:34.466726
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth'

        def get_auth(self, username=None, password=None):
            return 'MyAuth(%s, %s)' % (username, password)

    plugin = MyAuthPlugin()
    assert plugin.get_auth('user', 'pass') == 'MyAuth(user, pass)'



# Generated at 2022-06-17 21:03:41.526083
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    test_plugin = TestConverterPlugin('test')
    assert test_plugin.mime == 'test'


# Generated at 2022-06-17 21:03:44.946332
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'test') == 'testtest'



# Generated at 2022-06-17 21:03:52.059485
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == headers.upper()

# Generated at 2022-06-17 21:03:58.925619
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')
    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\tb\n\tc'


# Generated at 2022-06-17 21:04:05.274829
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    fp = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert fp.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''


# Generated at 2022-06-17 21:04:09.290076
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test_adapter'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test_adapter'


# Generated at 2022-06-17 21:04:15.783072
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.enabled
    assert test_formatter_plugin.kwargs['format_options'] == {}
    assert test_formatter_plugin.format_options == {}



# Generated at 2022-06-17 21:04:23.170036
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    t = TestConverterPlugin('test')
    assert t.mime == 'test'


# Generated at 2022-06-17 21:04:30.706243
# Unit test for constructor of class BasePlugin

# Generated at 2022-06-17 21:06:04.826410
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return mime == 'text/plain'

    converter = TestConverterPlugin('text/plain')
    assert converter.convert(b'abc') == 'abc'
