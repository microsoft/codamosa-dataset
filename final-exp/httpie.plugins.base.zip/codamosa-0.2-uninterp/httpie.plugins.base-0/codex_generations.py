

# Generated at 2022-06-17 20:56:15.312597
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')
    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\nb\n\nc'


# Generated at 2022-06-17 20:56:16.557117
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    assert True


# Generated at 2022-06-17 20:56:21.397117
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatter(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatter(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test'

# Generated at 2022-06-17 20:56:25.394574
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = FormatterPlugin_test(**{'format_options': {}})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:56:29.460894
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('foo: bar\nbar: baz') == 'foo: bar\n\tbar: baz'



# Generated at 2022-06-17 20:56:32.113524
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:56:38.891426
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''



# Generated at 2022-06-17 20:56:45.601962
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == headers.replace('\n', '\n\n')


# Generated at 2022-06-17 20:56:49.315060
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return 'test_FormatterPlugin_format_headers'

    test_formatter_plugin = TestFormatterPlugin(format_options=None)
    assert test_formatter_plugin.format_headers('test') == 'test_FormatterPlugin_format_headers'


# Generated at 2022-06-17 20:56:57.020022
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\nc: d') == 'a: b\n\nc: d'



# Generated at 2022-06-17 20:57:09.605419
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    f = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 16 Sep 2019 15:05:36 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 13
Connection: keep-alive
Vary: Accept-Encoding
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
X-Content-Type-Options: nosniff
X-Clacks-Overhead: GNU Terry Pratchett

'''
    assert f.format_headers

# Generated at 2022-06-17 20:57:13.633020
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', ' ')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert plugin.format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '



# Generated at 2022-06-17 20:57:19.296892
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')
    assert TestFormatterPlugin(format_options={}).format_headers('\r\n') == '\n'


# Generated at 2022-06-17 20:57:28.147046
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''


# Generated at 2022-06-17 20:57:35.354571
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = '''HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK\nContent-Type: text/html\n\n'''


# Generated at 2022-06-17 20:57:38.633281
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = FormatterPlugin(format_options={})
    assert fp.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:57:44.894446
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json

'''


# Generated at 2022-06-17 20:57:48.486353
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a\r\nb') == 'a\nb'


# Generated at 2022-06-17 20:57:57.137254
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\r\n', '\n')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('Content-Type: text/html\r\n\r\n') == 'Content-Type: text/html\n\n'


# Generated at 2022-06-17 20:58:00.466879
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_plugin = TestFormatterPlugin(format_options={})
    assert test_plugin.format_headers('test') == 'test'


# Generated at 2022-06-17 20:58:07.783779
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body("test", "application/json") == "test"



# Generated at 2022-06-17 20:58:15.884815
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPluginTest(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert FormatterPluginTest(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''



# Generated at 2022-06-17 20:58:26.418678
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''


# Generated at 2022-06-17 20:58:34.891378
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    formatter = MyFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''



# Generated at 2022-06-17 20:58:37.694157
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 20:58:43.875512
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 20 Apr 2020 14:42:21 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

'''
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK Server: nginx/1.10.3 (Ubuntu) Date: Mon, 20 Apr 2020 14:42:21 GMT Content-Type: application/json Content-Length: 2 Connection: keep-alive '


# Generated at 2022-06-17 20:58:48.966333
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n  ')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK
  Content-Type: application/json

'''


# Generated at 2022-06-17 20:58:55.910002
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_headers('test') == 'TEST'


# Generated at 2022-06-17 20:58:59.059781
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 20:59:02.799781
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '



# Generated at 2022-06-17 20:59:12.551949
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:59:15.357210
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\n')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a\nb') == 'a\n\nb'



# Generated at 2022-06-17 20:59:17.795512
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content + '\n'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test\n'



# Generated at 2022-06-17 20:59:22.955995
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('abc', 'text/plain') == 'ABC'


# Generated at 2022-06-17 20:59:27.160844
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = FormatterPlugin_test(format_options=None)
    assert formatter.format_body("test", "test") == "test"


# Generated at 2022-06-17 20:59:31.152668
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_headers("test") == "test"


# Generated at 2022-06-17 20:59:33.131812
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d\n') == 'A: B\nC: D\n'



# Generated at 2022-06-17 20:59:37.950377
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == ' HTTP/1.1 200 OK Content-Type: application/json Content-Length: 2 '


# Generated at 2022-06-17 20:59:44.432853
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:59:48.376175
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content, mime):
            return content + '_test'

    formatter = FormatterPlugin_test(**{'format_options': {}})
    assert formatter.format_body('test', 'application/atom+xml') == 'test_test'

# Generated at 2022-06-17 21:00:03.688049
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MockFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + "test"

    fp = MockFormatterPlugin(format_options=None)
    assert fp.format_body("test", "text/plain") == "testtest"

# Generated at 2022-06-17 21:00:06.949242
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 21:00:10.645680
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content

    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 21:00:16.016969
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('foo: bar\n') == 'foo: bar\r\n'


# Generated at 2022-06-17 21:00:21.554629
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 21:00:28.403469
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert test_formatter.format_headers(headers) == '''
    HTTP/1.1 200 OK
    \tContent-Type: application/json
    '''



# Generated at 2022-06-17 21:00:30.760042
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 21:00:36.684647
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('Content-Type: application/json\r\n') == 'Content-Type: application/json\n'



# Generated at 2022-06-17 21:00:40.323720
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    plugin_manager.get_enabled_plugins()
    for plugin in plugin_manager.get_enabled_plugins():
        if isinstance(plugin, FormatterPlugin):
            plugin.format_headers('headers')


# Generated at 2022-06-17 21:00:46.381815
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + "test"

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "application/atom+xml") == "testtest"



# Generated at 2022-06-17 21:01:13.380845
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options=None)
    assert test_formatter_plugin.format_body("test", "test") == "test"


# Generated at 2022-06-17 21:01:20.237814
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''

# Generated at 2022-06-17 21:01:24.610139
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'


# Generated at 2022-06-17 21:01:27.816721
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'


# Generated at 2022-06-17 21:01:33.575458
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:01:37.740641
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + "test"

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "") == "testtest"

# Generated at 2022-06-17 21:01:42.041804
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test\n'


# Generated at 2022-06-17 21:01:46.560488
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    assert TestFormatterPlugin(format_options={}).format_headers('\r\n\r\n') == '\n\n'


# Generated at 2022-06-17 21:01:53.759956
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('a', 'text/plain') == 'b'



# Generated at 2022-06-17 21:02:00.650428
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == ' HTTP/1.1 200 OK Content-Type: application/json '


# Generated at 2022-06-17 21:02:56.826092
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    import json
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import plugin_manager
    from httpie.plugins import builtin
    from httpie.plugins import builtin_plugins
    from httpie.plugins import get_plugin_manager
    from httpie.plugins import get_plugins
    from httpie.plugins import load_plugins
    from httpie.plugins import plugin_manager
    from httpie.plugins import plugin_manager
    from httpie.plugins import plugin_manager
    from httpie.plugins import plugin_manager
    from httpie.plugins import plugin_manager
    from httpie.plugins import plugin_manager
    from httpie.plugins import plugin_manager
    from httpie.plugins import plugin_manager
    from httpie.plugins import plugin_manager
    from httpie.plugins import plugin_manager

# Generated at 2022-06-17 21:03:03.663108
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPluginTest(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\n')

    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert FormatterPluginTest(format_options={}).format_headers(headers) == '''
HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''


# Generated at 2022-06-17 21:03:08.540845
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:03:14.587199
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin().format_headers(headers) == '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
Content-Length: 2\r
\r
'''


# Generated at 2022-06-17 21:03:18.777262
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('a\nb', 'text/plain') == 'a\n\nb'

# Generated at 2022-06-17 21:03:23.986314
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 21:03:33.991458
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.lexers import get_lexer_by_name
    from pygments.token import Token
    from pygments.util import ClassNotFound
    from pygments.lexers.special import TextLexer
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.lexers import get_lexer_by_name
    from pygments.token import Token
    from pygments.util import ClassNotFound
    from pygments.lexers.special import TextLexer
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.lexers import get_

# Generated at 2022-06-17 21:03:38.876551
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body(content='test', mime='application/json') == 'test'


# Generated at 2022-06-17 21:03:43.346093
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'test') == 'test_test'



# Generated at 2022-06-17 21:03:47.983395
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 21:05:42.531737
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    env = Environment()
    kwargs = {'format_options': {}}
    formatter = FormatterPlugin(**kwargs)
    assert formatter.enabled == True
    assert formatter.kwargs == kwargs
    assert formatter.format_options == kwargs['format_options']


# Generated at 2022-06-17 21:05:45.479854
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'Hello World') == 'Hello World'


# Generated at 2022-06-17 21:05:49.012432
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers("test") == "test"


# Generated at 2022-06-17 21:05:58.347308
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class TestConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)

        def convert(self, content_bytes):
            return content_bytes

        @classmethod
        def supports(cls, mime):
            return True

    t = TestConverterPlugin('test')
    assert t.mime == 'test'


# Generated at 2022-06-17 21:06:01.545440
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPluginTest(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'adapter'

    plugin = TransportPluginTest()
    assert plugin.get_adapter() == 'adapter'


# Generated at 2022-06-17 21:06:05.282611
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'


# Generated at 2022-06-17 21:06:15.741449
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import Stream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_HELP
    from httpie.output.streams import is_binary_content
    from httpie.output.streams import is_json
    from httpie.output.streams import is_xml
    from httpie.output.streams import is_html
    from httpie.output.streams import is_javascript
    from httpie.output.streams import is_form
    from httpie.output.streams import is_pretty
    from httpie.output.streams import is_ugly
    from httpie.output.streams import is_stream