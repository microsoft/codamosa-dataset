

# Generated at 2022-06-17 20:56:12.874542
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_headers('HTTP/1.1 200 OK\r\n') == 'HTTP/1.1 200 OK\n'


# Generated at 2022-06-17 20:56:18.708951
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')
    assert TestFormatterPlugin(format_options={}).format_headers('a: b\r\nc: d\r\n') == 'a: b\nc: d\n'


# Generated at 2022-06-17 20:56:27.619761
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        'Content-Length: 2',
        '',
        '{}'
    ])) == '\n'.join([
        'HTTP/1.1 200 OK',
        '\tContent-Type: application/json',
        '\tContent-Length: 2',
        '',
        '{}'
    ])



# Generated at 2022-06-17 20:56:32.071039
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'testtest'

# Generated at 2022-06-17 20:56:35.222877
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'application/json') == 'testtest'

# Generated at 2022-06-17 20:56:39.858582
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert MyFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'

# Generated at 2022-06-17 20:56:46.488822
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_headers('HTTP/1.1 200 OK\nContent-Type: application/json\n\n') == 'HTTP/1.1 200 OK\n\nContent-Type: application/json\n\n'


# Generated at 2022-06-17 20:57:00.196747
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Sat, 20 Jul 2019 13:50:36 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Sat, 20 Jul 2019 13:50:36 GMT
ETag: "2d-58f7b9c8d8c00"
Accept-Ranges: bytes
Content-Length: 45
Vary: Accept-Encoding
Content-Type: text/html

'''

# Generated at 2022-06-17 20:57:07.149821
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\n')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin().format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

'''



# Generated at 2022-06-17 20:57:10.984260
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    f = FormatterPlugin_test(format_options={})
    assert f.format_body("test", "test") == "test"


# Generated at 2022-06-17 20:57:18.332461
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'

# Generated at 2022-06-17 20:57:22.821623
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "test") == "test"

# Generated at 2022-06-17 20:57:27.060681
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = FormatterPlugin_test(**{'format_options': {}})
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\nc: d'


# Generated at 2022-06-17 20:57:33.140288
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Content-Type: text/html; charset=UTF-8
Content-Encoding: UTF-8
Content-Length: 138
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
ETag: "3f80f-1b6-3e1cb03b"
Accept-Ranges: bytes
Connection: close

'''

# Generated at 2022-06-17 20:57:36.775582
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'text/plain') == 'b'


# Generated at 2022-06-17 20:57:41.712956
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = '''HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK\nContent-Type: application/json\n\n'''


# Generated at 2022-06-17 20:57:48.361564
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    test_headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert test_formatter.format_headers(test_headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:57:55.430537
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('abc', 'text/plain') == 'ABC'


# Generated at 2022-06-17 20:58:00.200567
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:58:06.557764
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    '''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''
    HTTP/1.1 200 OK
    CONTENT-TYPE: APPLICATION/JSON
    '''


# Generated at 2022-06-17 20:58:14.653629
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPluginTest(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    formatter = FormatterPluginTest(format_options={})
    assert formatter.format_body('test', 'application/json') == 'testtest'



# Generated at 2022-06-17 20:58:19.636749
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    f = TestFormatterPlugin(format_options={})
    headers = '''
    HTTP/1.1 200 OK
    Date: Wed, 06 May 2020 15:51:13 GMT
    Server: Apache/2.4.18 (Ubuntu)
    Last-Modified: Wed, 06 May 2020 15:49:38 GMT
    ETag: "2a-5a9a8f1a2d2c0"
    Accept-Ranges: bytes
    Content-Length: 42
    Vary: Accept-Encoding
    Content-Type: text/html

    '''

# Generated at 2022-06-17 20:58:24.387594
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'b') == 'b'



# Generated at 2022-06-17 20:58:35.323702
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\t')

    test_formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''

# Generated at 2022-06-17 20:58:36.303119
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    assert FormatterPlugin.format_body('', '') == ''


# Generated at 2022-06-17 20:58:42.801821
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 11 Sep 2017 15:20:44 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

'''

# Generated at 2022-06-17 20:58:47.221435
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "text/plain") == "test"

# Generated at 2022-06-17 20:58:53.632524
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body("test", "text/html") == "test"


# Generated at 2022-06-17 20:58:59.403196
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'test\n'



# Generated at 2022-06-17 20:59:02.953229
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/atom+xml') == 'test'



# Generated at 2022-06-17 20:59:10.820208
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:59:13.764541
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'test\n'


# Generated at 2022-06-17 20:59:17.728136
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin().format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:59:23.191276
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('a', 'text/plain') == 'b'



# Generated at 2022-06-17 20:59:30.699189
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    test_headers_expected = '''
HTTP/1.1 200 OK
	Content-Type: application/json
	Content-Length: 2

'''
    assert FormatterPlugin_test(format_options=None).format_headers(test_headers) == test_headers_expected


# Generated at 2022-06-17 20:59:34.395386
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_body('\n', 'text/plain') == '\n\t'


# Generated at 2022-06-17 20:59:41.083908
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Date: Sun, 10 May 2020 19:46:29 GMT
Server: Apache
X-Powered-By: PHP/7.2.24
Content-Length: 2
Connection: close

'''

# Generated at 2022-06-17 20:59:45.567139
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:59:50.932188
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    test_formatter = FormatterPlugin()
    test_headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 13
Connection: keep-alive
Date: Wed, 18 Sep 2019 09:10:38 GMT
Server: nginx/1.14.0 (Ubuntu)

'''
    assert test_formatter.format_headers(test_headers) == test_headers


# Generated at 2022-06-17 20:59:57.298281
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('foo: bar\nbar: baz') == 'foo: bar\n\tbar: baz'



# Generated at 2022-06-17 21:00:05.373402
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:13.080634
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('HTTP/1.1 200 OK\r\n') == 'HTTP/1.1 200 OK\n'
    assert formatter.format_headers('HTTP/1.1 200 OK\r\n\r\n') == 'HTTP/1.1 200 OK\n\n'
    assert formatter.format_headers('HTTP/1.1 200 OK\r\n\r\n') == 'HTTP/1.1 200 OK\n\n'

# Generated at 2022-06-17 21:00:19.811966
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b c: d'



# Generated at 2022-06-17 21:00:24.565792
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:00:29.420164
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'TEST'


# Generated at 2022-06-17 21:00:34.972438
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 21:00:39.642409
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 21:00:47.061083
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json

'''



# Generated at 2022-06-17 21:00:59.723004
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Tue, 18 Aug 2020 17:46:22 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

'''
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK Date: Tue, 18 Aug 2020 17:46:22 GMT Content-Type: application/json Content-Length: 2 Connection: keep-alive '


# Generated at 2022-06-17 21:01:03.796575
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'TEST'



# Generated at 2022-06-17 21:01:16.837739
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatter(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatter(format_options={}).format_headers(headers) == '''
HTTP/1.1 200 OK
	Content-Type: application/json
	Content-Length: 2

'''


# Generated at 2022-06-17 21:01:22.820118
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 21:01:26.423016
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('\n') == '\n\t'


# Generated at 2022-06-17 21:01:38.287430
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments import highlight
    import os
    import sys
    import tempfile
    import unittest

    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers

    class TestFormatterPluginTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_file = tempfile.NamedTemporaryFile(delete=False)
            self.temp_file.write(b'HTTP/1.1 200 OK\r\n')

# Generated at 2022-06-17 21:01:45.461941
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 21:01:53.651659
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        'Content-Length: 2',
        '',
        '{}',
    ])) == '\n'.join([
        'HTTP/1.1 200 OK',
        '\tContent-Type: application/json',
        '\tContent-Length: 2',
        '',
        '{}',
    ])


# Generated at 2022-06-17 21:01:59.667867
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')
    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:02:05.595507
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''HTTP/1.1 200 OK
Date: Fri, 05 Jul 2019 14:00:00 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Wed, 22 Jul 2015 19:43:22 GMT
ETag: "359670651+ident"
Accept-Ranges: bytes
Content-Length: 45
Vary: Accept-Encoding
Content-Type: text/plain

'''

# Generated at 2022-06-17 21:02:08.729878
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.upper()

    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_headers('test') == 'TEST'


# Generated at 2022-06-17 21:02:13.166789
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = MyFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert plugin.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json

'''


# Generated at 2022-06-17 21:02:30.576539
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test\n'


# Generated at 2022-06-17 21:02:36.335680
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK
	Content-Type: application/json

'''



# Generated at 2022-06-17 21:02:41.187392
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.environment import Environment
    env = Environment()
    formatter = FormatterPlugin(env=env, format_options={})
    assert formatter.enabled == True
    assert formatter.kwargs == {'env': env, 'format_options': {}}
    assert formatter.format_options == {}


# Generated at 2022-06-17 21:02:51.058371
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(BasePlugin):
        """
        Requests transport adapter docs:

            <https://requests.readthedocs.io/en/latest/user/advanced/#transport-adapters>

        See httpie-unixsocket for an example transport plugin:

            <https://github.com/httpie/httpie-unixsocket>

        """

        # The URL prefix the adapter should be mount to.
        prefix = None

        def get_adapter(self):
            """
            Return a ``requests.adapters.BaseAdapter`` subclass instance to be
            mounted to ``self.prefix``.

            """
            raise NotImplementedError()

    tp = TransportPlugin()
    assert tp.prefix == None
    assert tp.get_adapter() == NotImplementedError


# Generated at 2022-06-17 21:02:55.305557
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('application/json')
    assert plugin.convert(b'{"foo": "bar"}') == '{"foo": "bar"}'


# Generated at 2022-06-17 21:03:03.126515
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = None
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            raise NotImplementedError()

    auth = AuthPlugin()
    assert auth.auth_type is None
    assert auth.auth_require is True
    assert auth.auth_parse is True
    assert auth.netrc_parse is False
    assert auth.prompt_password is True
    assert auth.raw_auth is None


# Generated at 2022-06-17 21:03:07.891494
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.core import Environment
    env = Environment()
    formatter = FormatterPlugin(env=env, format_options=None)
    assert formatter.enabled == True
    assert formatter.kwargs == {'env': env, 'format_options': None}
    assert formatter.format_options == None


# Generated at 2022-06-17 21:03:14.997859
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = 'my-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            return None

    auth = AuthPlugin()
    assert auth.auth_type == 'my-auth'
    assert auth.auth_require == True
    assert auth.auth_parse == True
    assert auth.netrc_parse == False
    assert auth.prompt_password == True
    assert auth.raw_auth == None


# Generated at 2022-06-17 21:03:22.249310
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    # Test the constructor of class FormatterPlugin
    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.enabled
    assert test_formatter_plugin.kwargs == {'format_options': {}}
    assert test_formatter_plugin.format_options == {}


# Generated at 2022-06-17 21:03:28.214417
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    env = Environment()
    format_options = {}
    kwargs = {'env': env, 'format_options': format_options}
    formatter = TestFormatterPlugin(**kwargs)
    assert formatter.enabled
    assert formatter.kwargs == kwargs
    assert formatter.format_options == format_options



# Generated at 2022-06-17 21:03:40.653050
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from httpie.environment import Environment
    env = Environment()
    FormatterPlugin(env=env, format_options={})

# Generated at 2022-06-17 21:03:49.343580
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = None
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            raise NotImplementedError()

    auth_plugin = AuthPlugin()
    assert auth_plugin.auth_type == None
    assert auth_plugin.auth_require == True
    assert auth_plugin.auth_parse == True
    assert auth_plugin.netrc_parse == False
    assert auth_plugin.prompt_password == True
    assert auth_plugin.raw_auth == None


# Generated at 2022-06-17 21:03:57.691238
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth'
        auth_parse = False
        auth_require = False
        netrc_parse = False
        prompt_password = False

        def get_auth(self, username=None, password=None):
            return 'my-auth'

    plugin = MyAuthPlugin()
    assert plugin.get_auth() == 'my-auth'


# Generated at 2022-06-17 21:03:59.505701
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin(BasePlugin):
        def format_headers(self, headers: str) -> str:
            return headers
    fp = FormatterPlugin()
    assert fp.format_headers("headers") == "headers"


# Generated at 2022-06-17 21:04:04.145923
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode('utf-8')

        @classmethod
        def supports(cls, mime):
            return True

    plugin = TestConverterPlugin('text/plain')
    assert plugin.convert(b'foo') == 'foo'


# Generated at 2022-06-17 21:04:09.576832
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('a', 'text/plain') == 'b'


# Generated at 2022-06-17 21:04:14.295537
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin(BasePlugin):
        prefix = 'http+unix://'

        def get_adapter(self):
            return 'adapter'

    plugin = TransportPlugin()
    assert plugin.get_adapter() == 'adapter'

# Generated at 2022-06-17 21:04:18.572591
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    assert TestTransportPlugin().get_adapter() == 'test'


# Generated at 2022-06-17 21:04:25.549550
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class BasePluginTest(BasePlugin):
        name = 'BasePluginTest'
        description = 'BasePluginTest description'
        package_name = 'BasePluginTest package_name'
    base_plugin_test = BasePluginTest()
    assert base_plugin_test.name == 'BasePluginTest'
    assert base_plugin_test.description == 'BasePluginTest description'
    assert base_plugin_test.package_name == 'BasePluginTest package_name'


# Generated at 2022-06-17 21:04:28.466478
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin_test(TransportPlugin):
        prefix = 'test'
        def get_adapter(self):
            return 'test'
    t = TransportPlugin_test()
    assert t.get_adapter() == 'test'


# Generated at 2022-06-17 21:04:53.377929
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter = ConverterPlugin('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 21:04:59.436507
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    # Test for constructor of class FormatterPlugin
    formatter = FormatterPlugin(format_options=None)
    assert formatter.enabled == True
    assert formatter.kwargs == {'format_options': None}
    assert formatter.format_options == None
    assert formatter.format_headers('headers') == 'headers'
    assert formatter.format_body('content', 'mime') == 'content'


# Generated at 2022-06-17 21:05:04.504576
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return None

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'test'
    assert plugin.package_name == 'httpie.plugins.transport.test'
    assert plugin.name == 'test'
    assert plugin.description is None


# Generated at 2022-06-17 21:05:10.333803
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'testtest'



# Generated at 2022-06-17 21:05:12.308545
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    plugin = BasePlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None


# Generated at 2022-06-17 21:05:22.107275
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class AuthPlugin(BasePlugin):
        auth_type = None
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None

        def get_auth(self, username=None, password=None):
            raise NotImplementedError()

    auth_plugin = AuthPlugin()
    assert auth_plugin.auth_type == None
    assert auth_plugin.auth_require == True
    assert auth_plugin.auth_parse == True
    assert auth_plugin.netrc_parse == False
    assert auth_plugin.prompt_password == True
    assert auth_plugin.raw_auth == None


# Generated at 2022-06-17 21:05:30.275324
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestPlugin(BasePlugin):
        name = 'test'
        description = 'test plugin'
        auth_type = 'test'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = True
        raw_auth = None
        prefix = None

    plugin = TestPlugin()
    assert plugin.name == 'test'
    assert plugin.description == 'test plugin'
    assert plugin.auth_type == 'test'
    assert plugin.auth_require == True
    assert plugin.auth_parse == True
    assert plugin.netrc_parse == False
    assert plugin.prompt_password == True
    assert plugin.raw_auth == None
    assert plugin.prefix == None


# Generated at 2022-06-17 21:05:39.661620
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    class MyFormatterPlugin2(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.lower()

    class MyFormatterPlugin3(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.title()

    class MyFormatterPlugin4(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.capitalize()

    assert MyFormatterPlugin().format_body('abc', 'text/plain') == 'ABC'

# Generated at 2022-06-17 21:05:42.782868
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:05:46.273418
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'test'

        def get_adapter(self):
            return 'test'

    plugin = TestTransportPlugin()
    assert plugin.get_adapter() == 'test'
