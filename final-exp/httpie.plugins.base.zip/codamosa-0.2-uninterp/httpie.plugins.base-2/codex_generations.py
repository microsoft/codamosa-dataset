

# Generated at 2022-06-17 20:56:09.563565
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "test") == "test"


# Generated at 2022-06-17 20:56:22.011778
# Unit test for method format_headers of class FormatterPlugin

# Generated at 2022-06-17 20:56:26.477048
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: 1\nb: 2') == 'a: 1\n\tb: 2'


# Generated at 2022-06-17 20:56:31.056733
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'a') == 'b'

# Generated at 2022-06-17 20:56:33.967310
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('abc', 'text/plain') == 'ABC'


# Generated at 2022-06-17 20:56:38.891389
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '-test'

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('test', 'application/atom+xml') == 'test-test'



# Generated at 2022-06-17 20:56:43.326538
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 20:56:47.074382
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options=None).format_headers('\n') == '\n\t'


# Generated at 2022-06-17 20:56:50.326462
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    f = FormatterPlugin_test(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b c: d'


# Generated at 2022-06-17 20:56:57.404088
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('aaa', 'text/plain') == 'bbb'



# Generated at 2022-06-17 20:57:11.373451
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Test case 1
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    # Test case 2
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    # Test case 3
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    # Test case 4
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

# Generated at 2022-06-17 20:57:15.968360
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return 'test'

    assert TestFormatterPlugin(format_options={}).format_body('', '') == 'test'


# Generated at 2022-06-17 20:57:22.157084
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\n')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('a\nb', 'text/plain') == 'a\n\nb'



# Generated at 2022-06-17 20:57:25.729894
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace("\n", "")

    assert TestFormatterPlugin(format_options={}).format_body("\n", "") == ""


# Generated at 2022-06-17 20:57:28.466874
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin().format_body('a', 'text/plain') == 'b'

# Generated at 2022-06-17 20:57:33.397413
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')
    assert TestFormatterPlugin().format_headers('a: b\nc: d') == 'a: b\r\nc: d'


# Generated at 2022-06-17 20:57:37.004671
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + "test"

    assert TestFormatterPlugin(format_options={}).format_body("test", "") == "testtest"


# Generated at 2022-06-17 20:57:42.772668
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\nc: d') == 'a: b c: d'


# Generated at 2022-06-17 20:57:46.235344
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('abc', 'text/plain') == 'ABC'



# Generated at 2022-06-17 20:57:48.931524
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test\n'



# Generated at 2022-06-17 20:57:54.300624
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:58:00.227744
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d\n') == 'a: b\n\tc: d\n'


# Generated at 2022-06-17 20:58:04.478296
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin().format_body('abc', 'text/plain') == 'ABC'



# Generated at 2022-06-17 20:58:08.636958
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('a', 'text/plain') == 'b'



# Generated at 2022-06-17 20:58:12.460627
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:58:16.931448
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'test') == 'test'


# Generated at 2022-06-17 20:58:22.801261
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('\n', 'application/atom+xml') == '\n\t'



# Generated at 2022-06-17 20:58:26.755889
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('foo\nbar') == 'foo\n\tbar'


# Generated at 2022-06-17 20:58:32.642776
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin()
    assert fp.format_body('{"a": "b"}', 'application/json') == '{"a": "b"}'



# Generated at 2022-06-17 20:58:36.426979
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPluginTest(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    f = FormatterPluginTest(format_options=None)
    assert f.format_body("test", "test") == "test"


# Generated at 2022-06-17 20:58:47.464723
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_plugin = TestFormatterPlugin(format_options=None)
    assert test_plugin.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:58:54.527114
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'


# Generated at 2022-06-17 20:58:58.446358
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('foo: bar\nbar: baz') == 'foo: bar\n\nbar: baz'


# Generated at 2022-06-17 20:59:02.096445
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:59:13.415709
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    tfp = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.14.0 (Ubuntu)
Date: Tue, 19 May 2020 12:03:03 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

'''

# Generated at 2022-06-17 20:59:21.223550
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''


# Generated at 2022-06-17 20:59:25.783924
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\n')

    assert TestFormatterPlugin(format_options={}).format_body('\n', 'text/plain') == '\n\n'


# Generated at 2022-06-17 20:59:32.569418
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK\r
Content-Type: application/json\r
Content-Length: 2\r
\r
'''



# Generated at 2022-06-17 20:59:37.928257
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:59:46.874877
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 21:00:03.643771
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/plain') == 'TEST'

# Generated at 2022-06-17 21:00:06.917234
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    assert TestFormatterPlugin().format_headers('a: b\r\nc: d\r\n') == 'a: b\nc: d\n'


# Generated at 2022-06-17 21:00:10.997885
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_formatted'

    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_body('content', 'mime') == 'content_formatted'



# Generated at 2022-06-17 21:00:16.445543
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\r\n') == 'a: b\n'



# Generated at 2022-06-17 21:00:21.601384
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    tfp = TestFormatterPlugin(**{'format_options': {}})
    assert tfp.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:25.685252
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:30.204999
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'test'



# Generated at 2022-06-17 21:00:35.785839
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b c: d'


# Generated at 2022-06-17 21:00:41.917516
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 21:00:48.081798
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:01:20.111429
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body("test", "") == "test"


# Generated at 2022-06-17 21:01:24.818237
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = FormatterPlugin_test(**{'format_options': {}})
    assert fp.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 21:01:27.975021
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = FormatterPlugin_test(format_options=None)
    assert formatter.format_body("test", "test") == "test"


# Generated at 2022-06-17 21:01:33.912431
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')
    assert TestFormatterPlugin(format_options={}).format_headers('a: b\r\nc: d\r\n\r\n') == 'a: b\nc: d\n\n'


# Generated at 2022-06-17 21:01:38.040232
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'
    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'testtest'



# Generated at 2022-06-17 21:01:42.903723
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter_plugin = TestFormatterPlugin(format_options={})
    assert formatter_plugin.format_body('test', 'text/html') == 'test'



# Generated at 2022-06-17 21:01:50.989887
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Test the method format_headers of class FormatterPlugin
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    # Expected output:
    #   'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    formatter = FormatterPlugin()
    assert formatter.format_headers(headers) == 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'

    # Test case 2:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent

# Generated at 2022-06-17 21:02:02.376676
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    test_plugin = TestFormatterPlugin(format_options={})
    test_headers = '''HTTP/1.1 200 OK
Date: Tue, 28 Apr 2020 16:03:02 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Tue, 28 Apr 2020 15:58:27 GMT
ETag: "2d-5a9e3c3e7e3c0"
Accept-Ranges: bytes
Content-Length: 45
Connection: close
Content-Type: text/html

'''

# Generated at 2022-06-17 21:02:06.456930
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatter(FormatterPlugin):
        def format_headers(self, headers):
            return headers.upper()

    env = Environment(colors=256)
    formatter = TestFormatter(env=env)
    assert formatter.format_headers('hello') == 'HELLO'


# Generated at 2022-06-17 21:02:10.640244
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return "test"

    plugin = MyFormatterPlugin(format_options={})
    assert plugin.format_body("test", "test") == "test"

# Generated at 2022-06-17 21:03:14.037119
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins.builtin import HTTPieJSONFormatter
    from httpie.plugins.builtin import HTTPiePrettyFormatter
    from httpie.plugins.builtin import HTTPieTableFormatter
    from httpie.plugins.builtin import HTTPieTerminalFormatter
    from httpie.plugins.builtin import HTTPieURLEncodedFormatter
    from httpie.plugins.builtin import HTTPieXMLFormatter
    from httpie.plugins.builtin import HTTPieYAMLFormatter
    from httpie.plugins.builtin import HTTPieHTMLFormatter
    from httpie.plugins.builtin import HTTPieCSVFormatter
    from httpie.plugins.builtin import HTTPieTSVFormatter
    from httpie.plugins.builtin import HTTPieMarkdownFormatter
    from httpie.plugins.builtin import HTTPieImage

# Generated at 2022-06-17 21:03:16.895274
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content.upper()

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('foo', 'text/plain') == 'FOO'



# Generated at 2022-06-17 21:03:22.419212
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body("test", "test") == "test"

# Generated at 2022-06-17 21:03:27.043710
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\nc: d') == 'a: b c: d'



# Generated at 2022-06-17 21:03:33.949368
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')


# Generated at 2022-06-17 21:03:39.154801
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'testtest'

# Generated at 2022-06-17 21:03:48.808432
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\n')

    content = '''
    <html>
    <head>
    <title>Test</title>
    </head>
    <body>
    <h1>Test</h1>
    </body>
    </html>
    '''
    expected = '''
    <html>

    <head>

    <title>Test</title>

    </head>

    <body>

    <h1>Test</h1>

    </body>

    </html>
    '''
    assert TestFormatterPlugin(format_options={}).format_body(content, 'text/html') == expected

# Unit

# Generated at 2022-06-17 21:03:54.002324
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_formatted'

    fp = TestFormatterPlugin(**{'format_options': {}})
    assert fp.format_body('test', 'mime') == 'test_formatted'


# Generated at 2022-06-17 21:04:00.315683
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == headers


# Generated at 2022-06-17 21:04:04.359523
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_formatted'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('content', 'mime') == 'content_formatted'