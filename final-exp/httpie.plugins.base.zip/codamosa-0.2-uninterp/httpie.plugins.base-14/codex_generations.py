

# Generated at 2022-06-17 20:56:16.078317
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('abc', 'text/plain') == 'bbc'



# Generated at 2022-06-17 20:56:26.735453
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    # Test with empty headers
    headers = ''
    formatter = TestFormatterPlugin(**{'format_options': {}})
    assert formatter.format_headers(headers) == headers

    # Test with headers

# Generated at 2022-06-17 20:56:30.971182
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin()
    assert test_formatter.format_headers("test") == "test"


# Generated at 2022-06-17 20:56:36.495090
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''
HTTP/1.1 200 OK
	Content-Type: application/json

'''


# Generated at 2022-06-17 20:56:45.159501
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Test with empty headers
    headers = ""
    formatter = FormatterPlugin(format_options=None)
    assert formatter.format_headers(headers) == ""

    # Test with headers
    headers = "HTTP/1.1 200 OK\r\n" \
              "Content-Type: application/json\r\n" \
              "Content-Length: 2\r\n" \
              "Connection: close\r\n" \
              "\r\n"
    formatter = FormatterPlugin(format_options=None)
    assert formatter.format_headers(headers) == headers



# Generated at 2022-06-17 20:56:59.310530
# Unit test for method format_headers of class FormatterPlugin

# Generated at 2022-06-17 20:57:05.033330
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'test') == 'testtest'

# Generated at 2022-06-17 20:57:12.978358
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('\n'.join([
        'HTTP/1.1 200 OK',
        'Content-Type: application/json',
        '',
        '{',
        '    "foo": "bar"',
        '}',
    ])) == '\n'.join([
        'HTTP/1.1 200 OK',
        '\tContent-Type: application/json',
        '',
        '{',
        '    "foo": "bar"',
        '}',
    ])


# Generated at 2022-06-17 20:57:19.010187
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = FormatterPlugin_test(format_options={})
    assert fp.format_body("test", "text/plain") == "test"


# Generated at 2022-06-17 20:57:23.448652
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', ' ')

    assert TestFormatterPlugin().format_body('\n', 'text/plain') == ' '



# Generated at 2022-06-17 20:57:30.246008
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert MyFormatterPlugin(format_options={}).format_body('abc', 'text/plain') == 'ABC'



# Generated at 2022-06-17 20:57:34.304591
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 20:57:38.422339
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_body('\n\n', 'text/plain') == '\n\t\n\t'



# Generated at 2022-06-17 20:57:43.299847
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('\n', '') == '\n\t'



# Generated at 2022-06-17 20:57:46.714837
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('a', 'text/plain') == 'b'


# Generated at 2022-06-17 20:57:54.561960
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('test', 'application/json') == 'testtest'


# Generated at 2022-06-17 20:57:58.025162
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    for plugin in plugin_manager.get_plugins(FormatterPlugin):
        if plugin.name == 'JSON':
            assert plugin.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n') == 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'


# Generated at 2022-06-17 20:58:00.524772
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert FormatterPlugin().format_headers('headers') == 'headers'


# Generated at 2022-06-17 20:58:05.478918
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return "test"
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "test") == "test"


# Generated at 2022-06-17 20:58:07.620460
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('\n') == '\n\t'


# Generated at 2022-06-17 20:58:15.884534
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    test_headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(test_headers) == 'HTTP/1.1 200 OK Content-Type: application/json '


# Generated at 2022-06-17 20:58:17.989191
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    f = TestFormatterPlugin(format_options=None)
    assert f.format_body("test", "test") == "test"



# Generated at 2022-06-17 20:58:20.227077
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test_test'

# Generated at 2022-06-17 20:58:25.181130
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('a: b\nc: d') == 'a: b c: d'



# Generated at 2022-06-17 20:58:35.960614
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_binary_stream
    from httpie.output.streams import get_

# Generated at 2022-06-17 20:58:39.652850
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d') == 'a: b c: d'



# Generated at 2022-06-17 20:58:42.262671
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatter(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    formatter = TestFormatter(format_options={})
    assert formatter.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:58:46.598809
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace("\n", "")

    assert TestFormatterPlugin(format_options={}).format_body("\n", "") == ""



# Generated at 2022-06-17 20:58:53.481444
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('\n') == '\n\t'


# Generated at 2022-06-17 20:58:56.373389
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'TEST'


# Generated at 2022-06-17 20:59:01.378612
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b\r\nc: d'


# Generated at 2022-06-17 20:59:07.654579
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 20:59:11.887289
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'application/atom+xml') == 'testtest'


# Generated at 2022-06-17 20:59:15.238038
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 20:59:18.709041
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 20:59:26.344768
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    fp = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert fp.format_headers(headers) == '''\
HTTP/1.1 200 OK
	Content-Type: application/json

'''



# Generated at 2022-06-17 20:59:30.731457
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 20:59:34.108123
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_plugin = TestFormatterPlugin(format_options={})
    assert test_plugin.format_body("test", "test") == "test"


# Generated at 2022-06-17 20:59:37.188405
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')
    assert TestFormatterPlugin(format_options={}).format_body('a', 'mime') == 'b'


# Generated at 2022-06-17 20:59:39.946103
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'TEST'


# Generated at 2022-06-17 20:59:46.427337
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert plugin.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json

'''


# Generated at 2022-06-17 20:59:49.930872
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_headers('test') == 'test'



# Generated at 2022-06-17 20:59:52.723282
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    assert TestFormatterPlugin(format_options={}).format_headers('\r\n') == '\n'


# Generated at 2022-06-17 20:59:57.608845
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content
    assert TestFormatterPlugin(format_options={}).format_body('test', 'test') == 'test'


# Generated at 2022-06-17 21:00:01.283384
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    plugin = TestFormatterPlugin(format_options=None)
    assert plugin.format_headers("test") == "test"


# Generated at 2022-06-17 21:00:07.977587
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:00:11.434661
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()
    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'TEST'


# Generated at 2022-06-17 21:00:15.912289
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

'''



# Generated at 2022-06-17 21:00:21.402687
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'application/json') == 'test_test'

# Generated at 2022-06-17 21:00:25.505122
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content + '_formatted'

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('content', 'mime') == 'content_formatted'



# Generated at 2022-06-17 21:00:36.579063
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 21:00:40.815220
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\r\nc: d'


# Generated at 2022-06-17 21:00:51.032583
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.plugins.builtin.formatter
    import httpie.plugins.builtin.formatters
    import httpie.plugins.builtin.formatters.colors
    import httpie.plugins.builtin.formatters.colors.colors
    import httpie.plugins.builtin.formatters.colors.colors_256
    import httpie.plugins.builtin.formatters.colors.colors_truecolor
    import httpie.plugins.builtin.formatters.colors.colors_truecolor_rgb
    import httpie.plugins.builtin.formatters.colors.colors_truecolor_rgb_hex
    import httpie.plugins.builtin.formatters.colors.colors_truecolor_rgb

# Generated at 2022-06-17 21:00:57.457276
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 21:00:59.679195
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class MyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    plugin = MyFormatterPlugin(format_options=None)
    assert plugin.format_headers('\r\n') == '\n'


# Generated at 2022-06-17 21:01:04.270352
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == headers


# Generated at 2022-06-17 21:01:11.280610
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('foo\nbar', 'text/plain') == 'foo\n\nbar'



# Generated at 2022-06-17 21:01:18.344521
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import Terminal256Formatter
    from pygments.lexers import HttpLexer
    from pygments import highlight
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import Terminal256Formatter
    from pygments.lexers import HttpLexer
    from pygments import highlight
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import Terminal256Formatter
    from pygments.lexers import HttpLex

# Generated at 2022-06-17 21:01:23.127572
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    fp = TestFormatterPlugin(format_options=None)
    assert fp.format_body('test', 'application/json') == 'test\n'


# Generated at 2022-06-17 21:01:27.517603
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('foo: bar\nbar: baz') == 'foo: bar\n\nbar: baz'



# Generated at 2022-06-17 21:01:42.994102
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('aaa', 'text/plain') == 'bbb'



# Generated at 2022-06-17 21:01:47.572760
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(env=None, format_options=None)
    assert formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'


# Generated at 2022-06-17 21:02:00.964850
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    class TestFormatterPlugin2(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.lower()

    class TestFormatterPlugin3(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.capitalize()

    class TestFormatterPlugin4(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.title()


# Generated at 2022-06-17 21:02:06.405451
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d\n') == 'a: b c: d'


# Generated at 2022-06-17 21:02:09.502141
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('test') == 'test'


# Generated at 2022-06-17 21:02:13.341505
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_plugin = TestFormatterPlugin(format_options={})
    assert test_plugin.format_body("test", "application/atom+xml") == "test"

# Generated at 2022-06-17 21:02:16.735201
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:02:22.641934
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert plugin.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json

'''


# Generated at 2022-06-17 21:02:27.909591
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace("\n", "")

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("\n\n\n", "") == ""
    assert test_formatter.format_body("\n\n\n\n\n", "") == ""
    assert test_formatter.format_body("\n\n\n\n\n\n\n\n\n", "") == ""
    assert test_formatter.format_body("\n\n\n\n\n\n\n\n\n\n\n\n\n", "") == ""
    assert test_formatter.format_

# Generated at 2022-06-17 21:02:32.398264
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test\n'

# Generated at 2022-06-17 21:03:02.677741
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test\n'



# Generated at 2022-06-17 21:03:08.538364
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    class TestEnvironment:
        def __init__(self):
            self.colors = False

    env = TestEnvironment()
    formatter = TestFormatterPlugin(env=env)
    assert formatter.format_body('test', 'text/plain') == 'TEST'


# Generated at 2022-06-17 21:03:10.442312
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    headers = '''
    HTTP/1.1 200 OK
    Content-Type: application/json
    Content-Length: 2
    '''
    assert TestFormatterPlugin(format_options=None).format_headers(headers) == headers.upper()


# Generated at 2022-06-17 21:03:13.998681
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    test_formatter_plugin = TestFormatterPlugin(format_options=None)
    assert test_formatter_plugin.format_headers('headers') == 'headers'


# Generated at 2022-06-17 21:03:24.686535
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments import highlight
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_formatter
    from httpie.output.formatters.colors import PygmentsHTTPFormatter
    from httpie.output.formatters.colors import Pygments256HTTPFormatter
    from httpie.output.formatters.colors import PygmentsTrueColorHTTPFormatter
    from httpie.output.formatters.colors import PygmentsHTTPFormatter
    from httpie.output.formatters.colors import Pygments256HTTPFormatter

# Generated at 2022-06-17 21:03:28.721043
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers
    test_formatter_plugin = TestFormatterPlugin(**{'format_options': None})
    assert test_formatter_plugin.format_headers('test_headers') == 'test_headers'


# Generated at 2022-06-17 21:03:31.899146
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    content = 'abc'
    mime = 'text/plain'
    assert TestFormatterPlugin(format_options={}).format_body(content, mime) == content.upper()


# Generated at 2022-06-17 21:03:37.842179
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin().format_headers(headers) == headers.replace('\n', '\r\n')



# Generated at 2022-06-17 21:03:47.405170
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Content-Type: text/html; charset=UTF-8
Content-Encoding: UTF-8
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
ETag: "3f80f-1b6-3e1cb03b"
Content-Length: 138
Accept-Ranges: bytes
Connection: close

'''

# Generated at 2022-06-17 21:04:00.571036
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''


# Generated at 2022-06-17 21:05:01.672503
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    assert TestFormatterPlugin(format_options={}).format_headers(
        'HTTP/1.1 200 OK\n'
        'Content-Type: application/json\n'
        'Content-Length: 2\n'
        '\n'
    ) == (
        'HTTP/1.1 200 OK\n\n'
        'Content-Type: application/json\n\n'
        'Content-Length: 2\n\n'
        '\n'
    )



# Generated at 2022-06-17 21:05:06.314474
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = FormatterPlugin_test(format_options=None)
    assert fp.format_body('test', 'text/plain') == 'test'

# Generated at 2022-06-17 21:05:14.326788
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert plugin.format_headers(headers) == '''HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''



# Generated at 2022-06-17 21:05:19.112626
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPluginTest(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return 'test'

    formatter = FormatterPluginTest(**{'format_options': {}})
    assert formatter.format_body('test', 'application/atom+xml') == 'test'

# Generated at 2022-06-17 21:05:23.979081
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_test(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    fp = FormatterPlugin_test(format_options={})
    assert fp.format_body('a', 'mime') == 'b'

# Generated at 2022-06-17 21:05:30.510457
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    content = '''
    {
        "name": "John Doe",
        "age": 42
    }
    '''
    assert TestFormatterPlugin(format_options={}).format_body(content, 'application/json') == '''
    \t{
    \t\t"name": "John Doe",
    \t\t"age": 42
    \t}
    '''



# Generated at 2022-06-17 21:05:34.817078
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_body('\n', 'text/plain') == '\n\t'



# Generated at 2022-06-17 21:05:42.946919
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''


# Generated at 2022-06-17 21:05:48.905389
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK Content-Type: application/json '


# Generated at 2022-06-17 21:05:55.317547
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers
    tfp = TestFormatterPlugin(format_options={})
    assert tfp.format_headers('test') == 'test'
