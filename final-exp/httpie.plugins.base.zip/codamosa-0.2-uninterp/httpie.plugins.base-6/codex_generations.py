

# Generated at 2022-06-17 20:56:08.605275
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'application/json') == 'test'

# Generated at 2022-06-17 20:56:14.877620
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')
    assert TestFormatterPlugin(format_options={}).format_headers('a: b\r\nc: d\r\n') == 'a: b\nc: d\n'


# Generated at 2022-06-17 20:56:19.513213
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPluginTest(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    f = FormatterPluginTest(format_options={})
    assert f.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 20:56:26.440467
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace("\n", " ")

    test_headers = """Content-Type: application/json
Content-Length: 2

"""
    expected_headers = """Content-Type: application/json Content-Length: 2 """
    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_headers(test_headers) == expected_headers


# Generated at 2022-06-17 20:56:31.507777
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\n')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('a: b\nc: d') == 'a: b\n\nc: d'



# Generated at 2022-06-17 20:56:34.276992
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body("test", "text/html") == "test"


# Generated at 2022-06-17 20:56:39.298816
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', ' ')

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('a: b\nc: d\n') == 'a: b c: d '


# Generated at 2022-06-17 20:56:48.672248
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Date: Tue, 12 May 2020 20:39:44 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Tue, 12 May 2020 20:39:44 GMT
ETag: "2a-5a7b5c5d8e7f0"
Accept-Ranges: bytes
Content-Length: 42
Content-Type: text/html

'''

# Generated at 2022-06-17 20:56:58.544974
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatter(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\t')

    formatter = TestFormatter(format_options={})
    headers = '''\
HTTP/1.1 200 OK
Content-Type: application/json

'''
    assert formatter.format_headers(headers) == '''\
HTTP/1.1 200 OK
\tContent-Type: application/json

'''


# Generated at 2022-06-17 20:57:06.214347
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'


# Generated at 2022-06-17 20:57:12.718139
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "application/json") == "test"


# Generated at 2022-06-17 20:57:18.768824
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace("\n", "")

    test_formatter = TestFormatterPlugin(format_options=None)
    assert test_formatter.format_headers("a\nb") == "ab"


# Generated at 2022-06-17 20:57:23.263677
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content + '_test'

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('content', 'mime') == 'content_test'



# Generated at 2022-06-17 20:57:26.848948
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('\n', '\n\n')

    assert TestFormatterPlugin(format_options={}).format_body('\n', '') == '\n\n'


# Generated at 2022-06-17 20:57:29.437993
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 20:57:33.616368
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_headers('test') == 'test'


# Generated at 2022-06-17 20:57:37.500562
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'
    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test_test'

# Generated at 2022-06-17 20:57:42.254179
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "application/json") == "test"

# Generated at 2022-06-17 20:57:46.419798
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body("test", "text/plain") == "test"

# Generated at 2022-06-17 20:57:49.617590
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "test") == "test"



# Generated at 2022-06-17 20:58:00.051537
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b c: d'


# Generated at 2022-06-17 20:58:06.644358
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK\nContent-Type: text/html\n\n'


# Generated at 2022-06-17 20:58:09.978281
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin_test(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    f = FormatterPlugin_test(format_options={})
    assert f.format_headers("test") == "test"


# Generated at 2022-06-17 20:58:12.974276
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body("test", "test") == "test"

# Generated at 2022-06-17 20:58:24.814980
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawPlugin
    from httpie.plugins.builtin import UnicodeJSONFormatterPlugin
    from httpie.plugins.builtin import UnicodePlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import URLEncodedPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin
    from httpie.plugins.builtin import XMLPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import HTMLPlugin

# Generated at 2022-06-17 20:58:35.629396
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 15 Oct 2018 13:48:33 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
X-Powered-By: PHP/7.2.10-0ubuntu0.18.04.1
Cache-Control: no-cache, private
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59

'''

# Generated at 2022-06-17 20:58:39.629507
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    headers = '''Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'Content-Type: application/json Content-Length: 2 '


# Generated at 2022-06-17 20:58:43.791511
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 20:58:47.870865
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body('test', 'application/json') == 'test'


# Generated at 2022-06-17 20:58:57.272067
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    formatter = TestFormatterPlugin(format_options=None)
    assert formatter.format_headers('\n'.join(['a: b', 'c: d'])) == '\ta: b\n\tc: d'


# Generated at 2022-06-17 20:59:09.683330
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('a', 'text/plain') == 'b'



# Generated at 2022-06-17 20:59:13.172563
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('a', 'text/plain') == 'b'

# Generated at 2022-06-17 20:59:17.060892
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    assert TestFormatterPlugin(format_options={}).format_body('hello', 'text/plain') == 'HELLO'



# Generated at 2022-06-17 20:59:22.663815
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + 'test'

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'application/json') == 'testtest'


# Generated at 2022-06-17 20:59:26.373549
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('test', 'application/json') == 'test\n'



# Generated at 2022-06-17 20:59:28.578596
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    assert MyFormatterPlugin(format_options={}).format_body('foo', 'text/plain') == 'foo\n'


# Generated at 2022-06-17 20:59:33.468251
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    assert TestFormatterPlugin(format_options={}).format_body('aaa', 'text/plain') == 'bbb'

# Generated at 2022-06-17 20:59:39.502584
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    plugin = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Content-Length: 12
Connection: keep-alive

'''
    assert plugin.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: text/plain; charset=utf-8
\tContent-Length: 12
\tConnection: keep-alive

'''


# Generated at 2022-06-17 20:59:50.036104
# Unit test for method format_headers of class FormatterPlugin

# Generated at 2022-06-17 20:59:54.689476
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content, mime):
            return content

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('foo', 'bar') == 'foo'



# Generated at 2022-06-17 21:00:12.929545
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    f = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert f.format_headers(headers) == '''HTTP/1.1 200 OK
\tContent-Type: application/json
\tContent-Length: 2

'''


# Generated at 2022-06-17 21:00:18.009978
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/html') == 'test_test'

# Generated at 2022-06-17 21:00:22.925995
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert TestFormatterPlugin(format_options={}).format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 21:00:34.237668
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    env = Environment(colors=256,
                      stdout_isatty=True,
                      stdin_isatty=True,
                      format_options={})
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Mon, 13 May 2019 11:53:44 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive

'''
    formatter = TestFormatterPlugin(env=env, format_options={})

# Generated at 2022-06-17 21:00:40.247392
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\r\n', '\n')

    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'


# Generated at 2022-06-17 21:00:45.258047
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_body("test", "text/html") == "test"


# Generated at 2022-06-17 21:00:47.293230
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert FormatterPlugin(format_options={}).format_headers('headers') == 'headers'


# Generated at 2022-06-17 21:00:54.873611
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\tb\n\tc'


# Generated at 2022-06-17 21:01:00.958171
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_body('test', 'text/plain') == 'test'


# Generated at 2022-06-17 21:01:02.916617
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('aaa', 'text/plain') == 'bbb'



# Generated at 2022-06-17 21:01:33.527688
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', ' ')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_headers('a: b\nc: d') == 'a: b c: d'


# Generated at 2022-06-17 21:01:38.050514
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    assert TestFormatterPlugin(format_options={}).format_headers('a: b\nc: d') == 'a: b\n\nc: d'


# Generated at 2022-06-17 21:01:42.393185
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = TestFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'text/plain') == 'test'



# Generated at 2022-06-17 21:01:48.718249
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\n')

    headers = '''
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert TestFormatterPlugin(format_options={}).format_headers(headers) == '''
HTTP/1.1 200 OK

Content-Type: application/json

Content-Length: 2

'''



# Generated at 2022-06-17 21:01:54.930037
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin = MyFormatterPlugin(format_options={})
    assert plugin.format_body('test', 'application/json') == 'test'



# Generated at 2022-06-17 21:01:59.991755
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatter(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.upper()

    formatter = TestFormatter(format_options={})
    assert formatter.format_body('hello', 'text/plain') == 'HELLO'

# Generated at 2022-06-17 21:02:04.661373
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content.replace('a', 'b')

    fp = TestFormatterPlugin(format_options={})
    assert fp.format_body('aaa', 'text/plain') == 'bbb'



# Generated at 2022-06-17 21:02:08.614062
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\n\n')
    assert TestFormatterPlugin(format_options={}).format_headers('a\nb\nc') == 'a\n\nb\n\nc'


# Generated at 2022-06-17 21:02:11.485893
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.upper()

    plugin = TestFormatterPlugin(format_options=None)
    assert plugin.format_headers('test') == 'TEST'



# Generated at 2022-06-17 21:02:16.308062
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    test_formatter_plugin = TestFormatterPlugin(format_options={})
    assert test_formatter_plugin.format_body('test', 'test') == 'test'



# Generated at 2022-06-17 21:03:12.883392
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\r\n')

    formatter = TestFormatterPlugin(format_options={})
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert formatter.format_headers(headers) == '''HTTP/1.1 200 OK\r
Content-Type: application/json\r
Content-Length: 2\r
\r
'''


# Generated at 2022-06-17 21:03:16.105794
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    fp = TestFormatterPlugin()
    assert fp.format_body('test', 'text/html') == 'test'


# Generated at 2022-06-17 21:03:22.122337
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '\n'

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('test', 'text/plain') == 'test\n'



# Generated at 2022-06-17 21:03:30.629025
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import pytest
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN_STR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_STR

    # Test for method format_headers of class FormatterPlugin
    # Test for method format_headers of class FormatterPlugin
    # Test for method format_headers of class FormatterPlugin
    # Test for method format_headers of class FormatterPlugin
    # Test for method format_headers of class FormatterPlugin
    # Test for method

# Generated at 2022-06-17 21:03:36.120703
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_formatted'

    f = TestFormatterPlugin(format_options={})
    assert f.format_body('content', 'mime') == 'content_formatted'



# Generated at 2022-06-17 21:03:45.635410
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.plugins.builtin.formatter
    import httpie.plugins.builtin.formatters
    import httpie.plugins.builtin.formatters.colors
    import httpie.plugins.builtin.formatters.colors.__main__
    import httpie.plugins.builtin.formatters.colors.__main__.ColorsFormatter
    import httpie.plugins.builtin.formatters.colors.__main__.ColorsFormatter.format_headers
    import httpie.plugins.builtin.formatters.colors.__main__.ColorsFormatter.format_body
    import httpie.plugins.builtin.formatters.colors.__main__.ColorsFormatter.format_headers

# Generated at 2022-06-17 21:03:49.831240
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + '_test'

    formatter = TestFormatterPlugin(**{'format_options': {}})
    assert formatter.format_body('test', 'application/json') == 'test_test'

# Generated at 2022-06-17 21:03:58.146786
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('a: b\nc: d') == 'a: b\n\tc: d'



# Generated at 2022-06-17 21:04:02.828710
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers.replace('\n', '\r\n')

    f = TestFormatterPlugin(format_options={})
    assert f.format_headers('foo: bar\nbaz: qux') == 'foo: bar\r\nbaz: qux'



# Generated at 2022-06-17 21:04:05.624152
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers

    formatter = TestFormatterPlugin(format_options={})
    assert formatter.format_headers('test') == 'test'


# Generated at 2022-06-17 21:05:58.347256
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()

    test_formatter = TestFormatterPlugin(format_options={})
    assert test_formatter.format_headers('test') == 'TEST'



# Generated at 2022-06-17 21:06:03.418270
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.replace('\n', '\n\t')

    fp = TestFormatterPlugin(**{'format_options': {}})
    assert fp.format_headers('a: b\nc: d') == 'a: b\n\tc: d'

