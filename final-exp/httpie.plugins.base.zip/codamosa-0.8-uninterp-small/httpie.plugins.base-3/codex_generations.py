

# Generated at 2022-06-25 19:10:18.704004
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin(kwargs={'format_options' : 'format_options'})
    formatter_plugin_0.format_headers('headers')


# Generated at 2022-06-25 19:10:26.154611
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin(**{})
    formatter_plugin_0.kwargs = {}
    formatter_plugin_0.kwargs['format_options'] = {'text_only': bool, 'pretty': bool}
    formatter_plugin_0.group_name = str
    formatter_plugin_0.kwargs = {}
    formatter_plugin_0.kwargs['format_options'] = {'text_only': bool, 'pretty': bool}

    # Testing body of method format_headers
    headers = 'text'
    assert formatter_plugin_0.format_headers(headers) == 'text'



# Generated at 2022-06-25 19:10:32.372000
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    hdrs = '''Connection: close
    Content-Length: 53
    Cache-Control: no-cache, no-store, must-revalidate
    Date: Sun, 29 Sep 2019 12:03:00 GMT
    Expires: 0
    Access-Control-Allow-Origin: *
    Access-Control-Allow-Methods: GET, POST
    Access-Control-Allow-Headers: Content-Type
    Access-Control-Max-Age: 86400
    Access-Control-Allow-Credentials: true
    Content-Type: application/json; charset=utf-8
    Server: Cloudflare
    '''
    fp = FormatterPlugin()
    res = fp.format_headers(hdrs)
    assert(res == hdrs)


# Generated at 2022-06-25 19:10:35.776454
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = "text"
    mime = "application/json"
    assert formatter_plugin_0.format_body(content, mime) == "text"


# Generated at 2022-06-25 19:10:38.586560
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body('', 'text/plain') == ''



# Generated at 2022-06-25 19:10:41.912041
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin(**{'format_options': {'abc': 321}, 'env': Environment()})
    headers = "abc"
    try:
        _return = formatter_plugin_0.format_headers(headers)
    except Exception as e:
        e.args += (headers, )
        raise


# Generated at 2022-06-25 19:10:49.094105
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    test_body = "YXNkZg=="
    test_mime = "text/plain"
    test_kwargs = dict(
        env=str,
        format_options=str
    )
    formatter_plugin_0 = FormatterPlugin(**test_kwargs)
    output_0 = formatter_plugin_0.format_body(test_body, test_mime)
    assert output_0 == test_body


# Generated at 2022-06-25 19:10:50.725513
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    formatter_plugin_1.format_body()


# Generated at 2022-06-25 19:10:55.663459
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    body_content = "Hello, world!"
    body_mime = "text/plain"
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers(body_content)
    formatter_plugin_0.format_body(body_content, body_mime)


# Generated at 2022-06-25 19:10:58.804424
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    print("test_FormatterPlugin_format_body")
    x = FormatterPlugin
    x.__init__(x)
    assert x.format_body("headers: foo: bar\n", "application/atom+xml") == "headers: foo: bar\n"



# Generated at 2022-06-25 19:11:10.204039
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(mime = 'application/csv')
    try:
        converter_plugin_0.convert(content_bytes = b'\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r')
    except NotImplementedError:
        pass
    converter_plugin_1 = ConverterPlugin(mime = 'application/csv')

# Generated at 2022-06-25 19:11:12.359737
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    from httpie.plugins import AuthPlugin
    auth_plugin_0 = AuthPlugin()
    assert auth_plugin_0 != None


# Generated at 2022-06-25 19:11:23.727675
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # TODO: Test params case1, case2
    # Test case setup:
    class TestFormatterPlugin(FormatterPlugin):
        def __init__(self):
            self.group_name = 'format'
            self.enabled = True
            self.kwargs = None
            self.format_options = None

        def format_headers(self, headers):
            # TODO: Implement
            return headers

        def format_body(self, content, mime):
            # TODO: Implement
            return content

    class TestFormatterPluginInstance:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.FormatterPlugin = FormatterPlugin(**kwargs)
            self.test_formatter_plugin = TestFormatterPlugin()
            self.test_case_0()
            self

# Generated at 2022-06-25 19:11:27.306855
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    class some_plugin(FormatterPlugin):

        def format_body(self, content, mime):
            return 'test'

    formatter_plugin_0 = some_plugin(format_options={})
    formatter_plugin_0.format_body('test_content', 'test_mime')



# Generated at 2022-06-25 19:11:28.695635
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:11:30.903320
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    assert FormatterPlugin.group_name == 'format'
    assert FormatterPlugin().group_name == 'format'


# Generated at 2022-06-25 19:11:35.097059
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    base_plugin_0  = AuthPlugin()
    username = ''
    passowrd = ''
    base_plugin_0.get_auth(username,passowrd)


# Generated at 2022-06-25 19:11:44.545190
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    for plugin in get_auth_plugins():
        if plugin.auth_type == 'smb':
            auth_plugin_0 = plugin()
            auth_plugin_0.get_auth()
        elif plugin.auth_type == 'basic':
            auth_plugin_1 = plugin()
            auth_plugin_1.get_auth()
        elif plugin.auth_type == 'digest':
            auth_plugin_2 = plugin()
            auth_plugin_2.get_auth()
        elif plugin.auth_type == 'aws':
            auth_plugin_3 = plugin()
            auth_plugin_3.get_auth()
        elif plugin.auth_type == 'oauth2':
            auth_plugin_4 = plugin()
            auth_plugin_4.get_auth()

# Generated at 2022-06-25 19:11:47.301385
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    auth_plugin_0.raw_auth = 'raw_auth'
    assert auth_plugin_0.get_auth() == NotImplementedError


# Generated at 2022-06-25 19:11:48.459077
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    AuthPlugin()


# Generated at 2022-06-25 19:11:51.615410
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    prefix_0 = None
    transport_plugin_0 = TransportPlugin(prefix_0)


# Generated at 2022-06-25 19:11:53.382419
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()
    auth_plugin_0.auth_parse()


# Generated at 2022-06-25 19:11:55.198105
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    str_0 = None
    dict_0 = {str_0: str_0}
    assert ConverterPlugin(dict_0) is not None


# Generated at 2022-06-25 19:12:00.294646
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    str_0 = None
    dict_0 = {str_0: str_0}
    converter_plugin_0 = ConverterPlugin(dict_0)
    # Access instance attribute mime
    try:
        print(converter_plugin_0.mime)
    except AttributeError:
        print("Caught an exception")
    # Access class attribute
    try:
        print(ConverterPlugin.supports)
    except AttributeError:
        print("Caught an exception")

# Generated at 2022-06-25 19:12:01.244523
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    TransportPlugin_test = TransportPlugin()


# Generated at 2022-06-25 19:12:02.186465
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    BasePlugin()


# Generated at 2022-06-25 19:12:05.283364
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    str_0 = None
    transport_plugin_0 = TransportPlugin(str_0)



# Generated at 2022-06-25 19:12:09.278839
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    def test_body(self, content, mime):
        return content
    FormatterPlugin.format_body = test_body
    def test_body(self, content, mime):
        return content
    FormatterPlugin.format_body = test_body



# Generated at 2022-06-25 19:12:11.647426
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin({})
    headers_0 = ""
    print (formatter_plugin_0.format_headers(headers_0))


# Generated at 2022-06-25 19:12:12.805326
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin(**{})

# Generated at 2022-06-25 19:12:18.915737
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Test Case 0
    # test_case_0:
    str_0 = None
    dict_0 = {str_0: str_0}
    converter_plugin_0 = ConverterPlugin(dict_0)
    assert converter_plugin_0.format_headers() == None


# Generated at 2022-06-25 19:12:22.142242
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    instance = AuthPlugin()


# Generated at 2022-06-25 19:12:27.170911
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    # Test for type of isinstance()
    # http://docs.python.org/3/library/functions.html#isinstance
    # Also see
    # http://stackoverflow.com/questions/1549801/difference-between-isinstance-and-type-in-python
    # and
    # http://docs.python.org/3/reference/datamodel.html#object.__class__

    # Test for empty class

    base_plugin_0 = BasePlugin()
    # assert base_plugin_0.name == None
    # assert base_plugin_0.description == None

    # assert base_plugin_0.package_name == None
    assert isinstance(base_plugin_0.package_name, str)

    # Now test for description and name

# Generated at 2022-06-25 19:12:31.255768
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():

    # Arrange
    base_plugin = BasePlugin()
    transport_plugin = TransportPlugin()

    # Act
    result = transport_plugin.get_adapter()

    # Assert
    assert result

# Generated at 2022-06-25 19:12:33.810108
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():

    converter_plugin_0 = ConverterPlugin(None)
    content_bytes = ""
    converter_plugin_0.convert(content_bytes)
    assert_equal(converter_plugin_0.mime, None)


# Generated at 2022-06-25 19:12:37.054903
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:12:45.136170
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    # Test with valid input
    prefix_0 = 'valid_prefix'

    transport_plugin_0 = TransportPlugin()
    transport_plugin_0.prefix = prefix_0
    transport_plugin_0.get_adapter()
    # Test with non valid input
    prefix_1 = 'valid_prefix::0'

    transport_plugin_1 = TransportPlugin()
    transport_plugin_1.prefix = prefix_1
    transport_plugin_1.get_adapter()



# Generated at 2022-06-25 19:12:45.982604
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    from httpie.plugins import AuthPlugin
    AuthPlugin()


# Generated at 2022-06-25 19:12:53.085563
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    str_0 = None
    dict_0 = {str_0: str_0}
    formatter_plugin_0 = FormatterPlugin(dict_0)
    str_0 = None
    dict_0 = {str_0: str_0}
    str_1 = formatter_plugin_0.format_body(dict_0, dict_0)


# Generated at 2022-06-25 19:12:56.818689
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    env = Environment()
    kwargs = {'format_options': env.formatter_options}
    formatter_plugin_0 = FormatterPlugin(kwargs)
    headers = str_0
    expect = str_0
    actual = formatter_plugin_0.format_headers(headers)
    assert expect == actual


# Generated at 2022-06-25 19:13:04.329196
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    # Normal case for "ConverterPlugin(str)"
    try:
        str_1 = None
        dict_1 = {str_1: str_1}
        converter_plugin_1 = ConverterPlugin(dict_1)
    except Exception as e:
        print(str(e))


# Generated at 2022-06-25 19:13:09.119085
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    str_0 = None
    class_0 = TransportPlugin(str_0)
    # In order to pass this test the tested method of class TransportPlugin
    # should return a NotImplementedError
    assert class_0.get_adapter() is NotImplementedError


# Generated at 2022-06-25 19:13:11.976513
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():

    formatter_plugin_1 = FormatterPlugin()
    str_0 = 'headers'
    test_result = formatter_plugin_1.format_headers(str_0)


# Generated at 2022-06-25 19:13:14.312909
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    str_0 = None
    dict_0 = {str_0: str_0}
    converter_plugin_0 = ConverterPlugin(dict_0)


# Generated at 2022-06-25 19:13:15.554894
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:13:17.522844
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin(**{str_0: str_0})
    return formatter_plugin_0


# Generated at 2022-06-25 19:13:21.442608
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    str_0 = None
    dict_0 = {str_0: str_0}
    auth_plugin_0 = AuthPlugin(dict_0)
    str_0 = None
    dict_0 = {str_0: str_0}
    auth_plugin_1 = AuthPlugin(dict_0)
    str_0 = None
    dict_0 = {str_0: str_0}
    auth_plugin_1.get_auth(str_0, dict_0)


# Generated at 2022-06-25 19:13:27.124475
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    # Make sure __init__ actually exists.
    try:
        BasePlugin.__init__
    except:
        assert False, "Unable to find __init__ method for BasePlugin"

    try:
        BasePlugin()
    except TypeError:
        pass
    else:
        assert False, "Failed to raise TypeError on BasePlugin()"


# Generated at 2022-06-25 19:13:35.467198
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    t = TransportPlugin(name="name",description="description",auth_type="auth_type",auth_require="auth_require",auth_parse="auth_parse",netrc_parse="netrc_parse",prompt_password="prompt_password",raw_auth="raw_auth",get_auth="get_auth",prefix="prefix")
if __name__ == "__main__":
    test_TransportPlugin()
    #test_case_0()

# Generated at 2022-06-25 19:13:40.022974
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    try:
        AuthPlugin()
    except Exception as e:
        pass


# Generated at 2022-06-25 19:13:53.653983
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    assert_expect(transport_plugin_0.get_adapter(), NotImplementedError)


# Generated at 2022-06-25 19:14:00.887125
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    dict_0 = {'":': '":'}
    assert_equals(ConverterPlugin(dict_0).mime, {'":': '":'})
    dict_0 = {'abcdefghijklmnopqrstuvwxyz': 'abcdefghijklmnopqrstuvwxyz'}
    assert_equals(ConverterPlugin(dict_0).mime, {'abcdefghijklmnopqrstuvwxyz': 'abcdefghijklmnopqrstuvwxyz'})
    dict_0 = {'a_': 'a_'}
    assert_equals(ConverterPlugin(dict_0).mime, {'a_': 'a_'})
    dict_0 = {'a_3': 'a_3'}

# Generated at 2022-06-25 19:14:05.179381
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    try:
        formatter_plugin_0 = FormatterPlugin()
        content = 'body_content'
        mime = 'application/json'
        formatter_plugin_0.format_body(content, mime)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:14:08.477035
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    baseplugin = BasePlugin()
    assert baseplugin.name == None
    assert baseplugin.description == None
    assert baseplugin.package_name == None


# Generated at 2022-06-25 19:14:12.633864
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    str_0 = None
    dict_0 = {str_0: str_0}
    converter_plugin_0 = ConverterPlugin(dict_0)
    str_1 = None
    str_2 = converter_plugin_0.convert(str_1)


# Generated at 2022-06-25 19:14:13.761076
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    FormatterPlugin()


# Generated at 2022-06-25 19:14:20.249861
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    str_0 = "I1yL3"
    dict_0 = {str_0: str_0}
    converter_plugin_0 = ConverterPlugin(dict_0)
    try:
        converter_plugin_0.convert(None)
    except NotImplementedError:
        pass
    except:
        raise AssertionError('Unexpected exception thrown')

    try:
        converter_plugin_0.supports(str_0)
    except NotImplementedError:
        pass
    except:
        raise AssertionError('Unexpected exception thrown')


test_case_0()
test_ConverterPlugin()
print("*** TestProgram: End ***")

# Generated at 2022-06-25 19:14:23.301328
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class_0 = TestAuthPlugin_get_auth()
    str_1 = None
    str_2 = None
    class_0.get_auth(str_1, str_2)


# Generated at 2022-06-25 19:14:34.697660
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    dict_0 = {
        "auth_parse": True,
        "auth_require": True,
        "auth_type": "auth plugins",
        "description": "auth plugins",
        "name": "auth plugins",
        "netrc_parse": True,
        "package_name": "auth plugins",
        "prompt_password": True
    }
    auth_plugin_0 = AuthPlugin(dict_0)
    assert str(auth_plugin_0) == "<BasePlugin 'auth plugins'>"
    assert auth_plugin_0.auth_parse == True
    assert auth_plugin_0.auth_require == True
    assert auth_plugin_0.auth_type == "auth plugins"
    assert auth_plugin_0.description == "auth plugins"
    assert auth_plugin_0.name == "auth plugins"

# Generated at 2022-06-25 19:14:37.738673
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Test for method format_body of class FormatterPlugin
    str_0 = None
    dict_0 = {str_0: str_0}
    formatter_plugin_0 = FormatterPlugin(dict_0)
    str_1 = None
    str_2 = '#\\#$"$#$#'
    formatter_plugin_0.format_body(str_1, str_2)


# Generated at 2022-06-25 19:15:04.069046
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    dict_0 = {'CwjxOHxA': 'RZ_6U8LUBro', 'XdUCy': 'i'}
    transport_plugin_0 = TransportPlugin()
    # AssertionError: Expected Exception
    try:
        transport_plugin_0.get_adapter()
        assert False
    except Exception:
        assert True


# Generated at 2022-06-25 19:15:08.059441
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_type = None
    auth_require = True
    auth_parse = True
    netrc_parse = False
    prompt_password = True

    auth_plugin_0 = AuthPlugin(auth_type,auth_require,auth_parse,netrc_parse,prompt_password)


# Generated at 2022-06-25 19:15:14.517238
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    str_0 = None
    dict_0 = {str_0: str_0}
    formatter_plugin_0 = FormatterPlugin(**dict_0)
    str_1 = str_0
    str_2 = formatter_plugin_0.format_headers(str_1)


# Generated at 2022-06-25 19:15:17.513015
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # fmt: off
    kwargs_0 = {'format_options': {}}
    formatter_plugin_0 = FormatterPlugin(**kwargs_0)
    assert formatter_plugin_0.format_headers('headers-0') == 'headers-0'


# Generated at 2022-06-25 19:15:20.967250
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    # test TransportPlugin
    kwargs = {'some_arg_01': 'some_arg_02'}
    transport_plugin_0 = TransportPlugin(**kwargs)


# Generated at 2022-06-25 19:15:30.840592
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    with mock.patch('httpie_plugins.AuthPlugin.raw_auth', new_callable=mock.PropertyMock) as mock_raw_auth:
        with mock.patch('httpie_plugins.BasePlugin.package_name', new_callable=mock.PropertyMock) as mock_package_name:
            with mock.patch('httpie_plugins.BasePlugin.description', new_callable=mock.PropertyMock) as mock_description:
                mock_raw_auth.return_value = None
                mock_package_name.return_value = None
                mock_description.return_value = None
                with mock.patch('httpie_plugins.BasePlugin.name', new_callable=mock.PropertyMock) as mock_name:
                    mock_name.return_value = None

# Generated at 2022-06-25 19:15:33.402695
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    # set up
    str_0 = None
    call_out = None
    # test constructor of class AuthPlugin
    test_case_0()
    # return
    return


# Generated at 2022-06-25 19:15:35.385187
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    str_0 = None
    prefix_0 = TransportPlugin(str_0)
    prefix_0.get_adapter()


# Generated at 2022-06-25 19:15:43.629438
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    # Case 1: If the mime is 'application/msgpack'
    mime_1 = 'application/msgpack'
    converter_plugin_1 = ConverterPlugin(mime_1)
    mime_1_ = converter_plugin_1.mime
    assert mime_1 == mime_1_

    # Case 2: If the mime is 'application/json'
    mime_2 = 'application/json'
    converter_plugin_2 = ConverterPlugin(mime_2)
    mime_2_ = converter_plugin_2.mime
    assert mime_2 == mime_2_


# Generated at 2022-06-25 19:15:48.110469
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    # Create a new instance of class ConverterPlugin.
    temp_variable_0 = None
    temp_variable_1 = {temp_variable_0: temp_variable_0}
    converter_plugin_0 = ConverterPlugin(temp_variable_1)
    # Call the `convert method` of the instance.
    temp_variable_2 = None
    temp_variable_0 = converter_plugin_0.convert(temp_variable_2)


# Generated at 2022-06-25 19:16:46.910755
# Unit test for constructor of class BasePlugin
def test_BasePlugin():

    # Test cases
    test_case_0()



# Generated at 2022-06-25 19:16:54.413130
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    # auth is passed with -a option
    auth_type = "basic"
    auth_parse = True
    raw_auth = "username:password"
    username = "username"
    password = "password"
    username_password = "username:password"
    auth_plugin_0 = AuthPlugin(auth_type, auth_parse, raw_auth, username_password)
    assert auth_plugin_0.get_auth(username, password) == None


# Generated at 2022-06-25 19:16:58.258250
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    str_0 = None
    dict_0 = {str_0: str_0}
    formatter_plugin_0 = FormatterPlugin(**dict_0)
    str_1 = None
    assert formatter_plugin_0.format_headers(str_1) == str_1


# Generated at 2022-06-25 19:17:01.417618
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin('data')
    formatter_plugin_0 = FormatterPlugin()
    str_0 = 'content_utf8_bytes'
    converter_plugin_0.format_body(str_0, formatter_plugin_0)


# Generated at 2022-06-25 19:17:10.744680
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    # Create an instance for test
    try:
        BasePlugin_instance_0 = BasePlugin()
    except TypeError as error:
        # If there is an error, delete the instance
        del BasePlugin_instance_0
        print("Exception when creating an instance")
        print(error)
    except Exception as exception:
        del BasePlugin_instance_0
        print("Exception when creating an instance")
        raise exception
    else:
        # If there is no error, delete the instance
        del BasePlugin_instance_0


# Generated at 2022-06-25 19:17:11.731972
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    BasePlugin()


# Generated at 2022-06-25 19:17:22.823794
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    str_0 = None

# Generated at 2022-06-25 19:17:26.751442
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_type = None
    username = None
    password = None
    auth_plugin_0 = AuthPlugin(auth_type)
    requests_auth_base_0 = auth_plugin_0.get_auth(username, password)


# Generated at 2022-06-25 19:17:29.469888
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    with pytest.raises(NotImplementedError):
        FormatterPlugin().format_headers(str())


# Generated at 2022-06-25 19:17:34.127492
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    str_0 = None
    dict_0 = {str_0: str_0}
    converter_plugin_0 = ConverterPlugin(dict_0)
    # test_case_0()
    # test_case_1()
    # test_case_2()
    # test_case_3()
    # test_case_4()


# Generated at 2022-06-25 19:19:42.286480
# Unit test for constructor of class BasePlugin
def test_BasePlugin():

    base_plugin_0 = BasePlugin()
    assert base_plugin_0.name == None, 'base_plugin_0.name != None'
    assert base_plugin_0.description == None, 'base_plugin_0.description != None'
    assert base_plugin_0.package_name == None, 'base_plugin_0.package_name != None'


# Generated at 2022-06-25 19:19:46.453379
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    from .plugins import install_plugin_manager
    install_plugin_manager()
    from .plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    for plugin in plugin_manager.get_plugins():
        if 'TransportPlugin' != type(plugin).__name__:
            continue
        for name, cls in utils.walk_modules('httpie_plugins.transport'):
            try:
                cls().get_adapter()
            except NotImplementedError:
                pass

# Generated at 2022-06-25 19:19:47.302880
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_1 = BasePlugin()


# Generated at 2022-06-25 19:19:50.850065
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    str_0 = None
    str_1 = None
    str_2 = ' '
    # AssertionError: expected <KeyError: None>, found <KeyError: ' '>
    assert str_0 == str_2, str_1
    test_case_0()

test_FormatterPlugin_format_body()

# Generated at 2022-06-25 19:19:52.295316
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    with pytest.raises(NotImplementedError):
        auth_plugin_0 = AuthPlugin()
        auth_plugin_0.get_auth()


# Generated at 2022-06-25 19:19:59.767312
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    str_1 = None
    # how to call the constructor?
    auth_plugin_0 = AuthPlugin(str_1)
    str_2 = None
    # how to call the constructor?
    auth_plugin_1 = AuthPlugin(str_2)
    str_3 = None
    auth_plugin_0.auth_type = str_3
    str_4 = None
    auth_plugin_0.raw_auth = str_4
    str_5 = None
    auth_plugin_1.raw_auth = str_5
    username_0 = None
    password_0 = None
    # how to call the method get_auth?
    res_0 = auth_plugin_0.get_auth(username_0, password_0)
    username_1 = None
    password_1 = None
    # how to call the method

# Generated at 2022-06-25 19:20:02.582728
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    prefix_0 = None
    transport_plugin_0 = TransportPlugin(prefix_0)
    try:
        transport_plugin_0.get_adapter()
    except NotImplementedError:
        assert True
    else:
        assert False



# Generated at 2022-06-25 19:20:09.398887
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    str_0 = None
    dict_0 = {str_0: str_0}
    converter_plugin_0 = ConverterPlugin(dict_0)
    converter_plugin_0.get_converter = mock.Mock()
    mime = mock.Mock()
    content_bytes = mock.Mock()
    result = converter_plugin_0.convert(mime, content_bytes)
    assert result == converter_plugin_0.get_converter.return_value.convert.return_value


# Generated at 2022-06-25 19:20:13.013178
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    # kwargs: key-word arguments
    # kwargs = {'dict_0': dict_0}
    # auth_plugin_0 = AuthPlugin(**kwargs)
    # pytest.raises(NotImplementedError, "auth_plugin_0.get_auth(username=None, password=None)")
    pass
