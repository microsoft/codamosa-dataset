

# Generated at 2022-06-25 19:10:25.992621
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    # Create instance of formatter plugin
    fmt_plugin_0 = FormatterPlugin(format_options= {'colors': True, 'indent': 2, 'sort_headers': True, 'stream': False})

    # Retrieve data from stdin
    f = open("/tmp/_httpie_test_data_0.httpie", "r")
    content = f.read()
    f.close()

    # Test method format_body
    result = fmt_plugin_0.format_body(content=content, mime="application/json")
    assert result == content



# Generated at 2022-06-25 19:10:29.696630
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    pass


"""Unit test for method format_body of class FormatterPlugin
   Ensure that the method format_body works as expected.
   Test setup:
       None

   Input:
       (str) headers = ''

   Expected result:
       headers == ''
"""



# Generated at 2022-06-25 19:10:40.754711
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    value1 = "Cookie: csrftoken=g6UYG6kgcC6EvvXmJgCZDQQHTzFdcHxv; sessionid=6c0i6d504u6rxvf6jvsldd1dg6lmmw8z" # value of format_options
    kwargs1 = {'format_options': value1}
    formatter1 = FormatterPlugin(**kwargs1)
    formatter1.format_headers = FormatterPlugin.format_headers

# Generated at 2022-06-25 19:10:41.683826
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    FormatterPlugin.format_headers()


# Generated at 2022-06-25 19:10:44.629482
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    def format_headers(headers: str) -> str:
        return headers
    assert format_headers('headers') == 'headers'


# Generated at 2022-06-25 19:10:46.682982
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()

    # Test for formatter_plugin_0 is not yet implemented
    assert False



# Generated at 2022-06-25 19:10:50.771748
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin(100)
    formatter_plugin_0.kwargs = {'foo': 'bar'}
    headers = "headers"
    assert headers == formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:10:51.723442
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('P', 'application/x-www-form-urlencoded')


# Generated at 2022-06-25 19:11:00.106022
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # This is the input class.
    # It should be loaded from file.
    class testTransportPlugin(TransportPlugin):
        prefix = "foo"
        def get_adapter(self):
            print("foo1")
            return "foo1"
        def convert(self, content_bytes):
            print("foo2")
            return "foo2"
        def supports(self, mime):
            print("foo3")
            return "foo3"
    # This is the input class.
    # It should be loaded from file.
    class testFormatterPlugin(FormatterPlugin):
        group_name = "foo"
        def __init__(self, **kwargs):
            print("foo1")
            return "foo1"
        def format_headers(self, headers):
            print("foo2")

# Generated at 2022-06-25 19:11:10.080302
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import builtin
    from pygments.lexers import HttpLexer
    formatter_plugin = builtin.FormatterPlugin()
    assert formatter_plugin.format_headers('GET / HTTP/1.1\r\nHost: localhost:5000\r\nConnection: keep-alive\r\nAccept: */*\r\nUser-Agent: HTTPie/2.0.0\r\n\r\n') == 'GET / HTTP/1.1\r\nHost: localhost:5000\r\nConnection: keep-alive\r\nAccept: */*\r\nUser-Agent: HTTPie/2.0.0\r\n\r\n'

# Generated at 2022-06-25 19:11:14.571748
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    str_0 = 'content of a body'
    str_1 = formatter_plugin_0.format_body(str_0, None)


# Generated at 2022-06-25 19:11:15.145686
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    assert False



# Generated at 2022-06-25 19:11:17.282038
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    string_0 = formatter_plugin_0.format_headers("")


# Generated at 2022-06-25 19:11:20.522083
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    var_0 = formatter_plugin_0.format_body(('', 'application/json'))
    assert '' == var_0


# Generated at 2022-06-25 19:11:23.963285
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    var_0 = formatter_plugin_0.format_headers("headers")


# Generated at 2022-06-25 19:11:26.391491
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin(**{'format_options': {}})
    assert formatter_plugin_0.format_body('Some text', 'text/plain') == 'Some text'


# Generated at 2022-06-25 19:11:28.056018
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    FormatterPlugin().format_body(
            'content', 'mime')


# Generated at 2022-06-25 19:11:31.328903
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    transport_plugin_0 = TransportPlugin()
    # TODO: should probably be the mime type of the actual content
    var_0 = transport_plugin_0.format_body("text", "text/html")


# Generated at 2022-06-25 19:11:36.031961
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin(**None)
    headers_0 = ''
    var_0 = formatter_plugin_0.format_headers(headers_0)


# Generated at 2022-06-25 19:11:39.232297
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_1 = FormatterPlugin()
    headers_0 = formatter_plugin_1.format_headers(formatter_plugin_0.format_headers(""))
    assert headers_0 == ""


# Generated at 2022-06-25 19:11:42.433748
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    var_0 = transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:11:44.631946
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    test_instance_0 = FormatterPlugin()
    str_0 = test_instance_0.format_body()


# Generated at 2022-06-25 19:11:50.705364
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    import pytest
    from httpie.plugins import _load_plugin_modules
    _load_plugin_modules('')
    test_instance = FormatterPlugin()
    # we have to mock content and mime arguments,
    # because it is not possible to import API and FormatterPlugin from same file
    # since API imports from settings
    with pytest.raises(NotImplementedError):
        test_instance.format_body(None, None)


# Generated at 2022-06-25 19:11:53.957324
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    content_bytes = 'example_bytes'
    converter_plugin_0 = ConverterPlugin(mime = 'example_mime')
    var_0 = converter_plugin_0.convert(content_bytes)


# Generated at 2022-06-25 19:11:54.922650
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    var_0 = transport_plugin_0.get_adapter()

# Generated at 2022-06-25 19:11:56.050087
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_1 = AuthPlugin()



# Generated at 2022-06-25 19:11:57.021764
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:12:02.456125
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    transport_plugin_0 = AuthPlugin()
    assert transport_plugin_0.auth_type == None
    assert transport_plugin_0.auth_require == True
    assert transport_plugin_0.auth_parse == True
    assert transport_plugin_0.netrc_parse == False
    assert transport_plugin_0.prompt_password == True
    assert transport_plugin_0.raw_auth == None
    assert transport_plugin_0.get_auth()


# Generated at 2022-06-25 19:12:05.154889
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    try:
        var_0 = transport_plugin_0.get_adapter()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:12:08.112034
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():

    # SUT
    formatter_plugin_0 = FormatterPlugin()
    headers = formatter_plugin_0.format_headers("headers_0")
    assert headers == "headers_0"

# Generated at 2022-06-25 19:12:12.123949
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body("", str())


# Generated at 2022-06-25 19:12:14.159700
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    var_0 = transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:12:21.546136
# Unit test for constructor of class AuthPlugin

# Generated at 2022-06-25 19:12:23.553937
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    mime = 'application/json'

    # Call the constructor of class ConverterPlugin
    ConverterPlugin(mime)



# Generated at 2022-06-25 19:12:26.859612
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    transport_plugin_2 = TransportPlugin()
    var_2 = transport_plugin_2.get_adapter()
    auth_plugin_3 = AuthPlugin()
    var_3 = auth_plugin_3.get_auth()
    var_3.update_headers(None)


# Generated at 2022-06-25 19:12:30.693629
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    transport_plugin_0 = TransportPlugin()
    try:
        transport_plugin_0.name
    except Exception as err:
        assert False, err


# Generated at 2022-06-25 19:12:33.107779
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    try:
        var_0 = transport_plugin_0.get_adapter()
        assert False
    except NotImplementedError:
        assert True



# Generated at 2022-06-25 19:12:34.657798
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    transport_plugin_0 = TransportPlugin()
    var_0 = transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:12:36.384597
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    from requests.auth import AuthBase
    transport_plugin_0 = AuthPlugin()
    assert isinstance(transport_plugin_0.get_auth(), AuthBase)


# Generated at 2022-06-25 19:12:38.889054
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(mime=str_0)
    try:
        var_0 = converter_plugin_0.convert(content_bytes=bytes_0)
    except Exception as e:
        pass


# Generated at 2022-06-25 19:12:45.136699
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_1 = TransportPlugin()
    assert type(transport_plugin_1) == TransportPlugin


# Generated at 2022-06-25 19:12:46.302730
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin(mime = None)


# Generated at 2022-06-25 19:12:53.640456
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    mime = 'text/xml'
    converter_plugin_0 = ConverterPlugin(mime)
    # Unit test for function .convert()
    content_bytes = 'bytes_content'
    var_0 = converter_plugin_0.convert(content_bytes)
    # Unit test for function .supports()
    var_1 = ConverterPlugin.supports(mime)


# Generated at 2022-06-25 19:12:55.798705
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    # called
    auth_plugin_0 = AuthPlugin()
    auth_plugin_0.get_auth(username="none", password="cabernet")


# Generated at 2022-06-25 19:12:56.890998
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:12:58.049425
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:13:01.539663
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    test_case_0()

if __name__ == '__main__':
    import sys

    try:
        if sys.argv[1] == 'test_BasePlugin':
            test_BasePlugin()
            print('OK')
        else:
            print('USAGE: %s test_BasePlugin')
    except IndexError:
        print('USAGE: usage: %s test_BasePlugin')

# Generated at 2022-06-25 19:13:03.832776
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    username_0 = None
    password_0 = None
    result_0 = auth_plugin_0.get_auth(username_0, password_0)


# Generated at 2022-06-25 19:13:11.939995
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():

    # Test parameters:
    #
    # mime = <test_case_0>
    #
    # If mime == <test_case_0>:
    #    
    #     message = 'Hello World'
    #    

    converter_plugin = ConverterPlugin(mime)
    assert hasattr(converter_plugin, 'mime') == True
    assert hasattr(converter_plugin, 'convert') == True
    assert hasattr(converter_plugin, 'supports') == True



# Generated at 2022-06-25 19:13:16.487040
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    var_0 = auth_plugin_0.get_auth(username="uname", password="pass")
    print(var_0)


# Generated at 2022-06-25 19:13:27.506061
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    var_0 = ConverterPlugin("application/json")


# Generated at 2022-06-25 19:13:36.368040
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():

    # Test for default value of parameter 'username'
    test_class = AuthPlugin()
    assert test_class.get_auth() == NotImplementedError

    # Test for default value of parameter 'password'
    test_class = AuthPlugin()
    assert test_class.get_auth(username=None) == NotImplementedError

    # Test using argument 'password'
    test_class = AuthPlugin()
    assert test_class.get_auth(username=None, password=None) == NotImplementedError



# Generated at 2022-06-25 19:13:40.444522
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()
    assert_true(auth_plugin_0.auth_parse)
    return


# Generated at 2022-06-25 19:13:44.010995
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatterPlugin = FormatterPlugin()
    text_value = "test_value"
    x = formatterPlugin.format_headers(text_value)


# Generated at 2022-06-25 19:13:51.414347
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    default_formatter = FormatterPlugin()
    headers = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4'
    try:
        result = default_formatter.format_headers(headers)
        assert result != None
    except:
        assert False


# Generated at 2022-06-25 19:13:53.141773
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin = AuthPlugin()
    assert isinstance(auth_plugin, AuthPlugin)


# Generated at 2022-06-25 19:13:55.189333
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    content_bytes = bytes()

    converter_plugin = ConverterPlugin('mime')
    res = converter_plugin.convert(content_bytes)


# Generated at 2022-06-25 19:13:58.363153
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    mime = 'application/atom+xml'
    content = 'content'
    actual_output = formatter_plugin.format_body(content, mime)
    expected_output = content
    assert actual_output == expected_output


# Generated at 2022-06-25 19:13:59.673114
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin(mime='application/json')


# Generated at 2022-06-25 19:14:02.429053
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    var_0 = transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:14:24.161362
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    transport_plugin_0 = TransportPlugin()
    var_0 = FormatterPlugin()
    var_1 = transport_plugin_0.get_adapter()
    var_2 = var_0.format_headers('headers' )


# Generated at 2022-06-25 19:14:27.678325
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin('mime')
    # ERROR: assert isinstance(converter_plugin_0, plugin_manager.Plugin)
    assert isinstance(converter_plugin_0, ConverterPlugin)



# Generated at 2022-06-25 19:14:31.346561
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'apple'
    formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:14:34.577387
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    mime = 'application/json'
    content = '{"foo": "bar"}'
    formatter_plugin = FormatterPlugin()
    formatter_plugin.format_body(content=content, mime=mime)

# Generated at 2022-06-25 19:14:36.821480
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    var_0 = transport_plugin_0.get_adapter()
    assert var_0 is None


# Generated at 2022-06-25 19:14:42.246661
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    assert_raises(NotImplementedError, transport_plugin_0.get_adapter)



# Generated at 2022-06-25 19:14:43.551763
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:14:47.971614
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    username_0 = None
    password_0 = None
    var_0 = auth_plugin_0.get_auth(username_0, password_0)


# Generated at 2022-06-25 19:14:52.026672
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins.builtin import HTTPieArgumentParser

    class SomePlugin(FormatterPlugin):
        def format_body(self, content, mime):
            # User implementation.
            return 'test'

    formatter_plugin_0 = SomePlugin()
    environment_0 = None
    var_0 = formatter_plugin_0.format_body('test', 'some_mime')



# Generated at 2022-06-25 19:14:55.088635
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    # Get a TransportPlugin instance
    transport_plugin_0 = TransportPlugin()
    # Get the value of attribute 'package_name'
    var_0 = transport_plugin_0.package_name


# Generated at 2022-06-25 19:15:37.887891
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    from httpie.plugins import plugin_manager
    from httpie.context import Environment

    plugin_manager.load_from_entry_point('entrypoint_converter.test_case_0:Case0', name='test_case_0')
    converter_plugin_0 = ConverterPlugin('mime')


# Generated at 2022-06-25 19:15:43.519426
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class TestAuthPlugin:
        def get_auth(self, username=None, password=None):
            assert username
            assert password
            return [username, password]
    auth_plugin = TestAuthPlugin()
    username = 'test_username'
    password = 'test_password'
    auth = auth_plugin.get_auth(username, password)
    assert auth == [username, password]


# Generated at 2022-06-25 19:15:47.815463
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    # Test that a TransportPlugin instance can be instantiated
    transport_plugin_0 = TransportPlugin()
    assert transport_plugin_0.name is None, "name should be None"
    assert transport_plugin_0.description is None, "description should be None"
    assert transport_plugin_0.package_name is None, "package_name should be None"
    assert transport_plugin_0.prefix is None, "prefix should be None"


# Generated at 2022-06-25 19:15:56.270918
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    # Create a new instance of the class under test, leaving out the
    # default kwargs
    fmt = FormatterPlugin()
    assert fmt.enabled == True
    assert fmt.kwargs == None

    # Create a new instance passing in the default kwargs
    fmt = FormatterPlugin(format_options='json')
    assert fmt.enabled == True
    assert fmt.kwargs['format_options'] == 'json'

    # Create a new instance pass in other kwargs
    fmt = FormatterPlugin(format_options='json', other='foo')
    assert fmt.kwargs['format_options'] == 'json'
    assert fmt.kwargs['other'] == 'foo'

# Generated at 2022-06-25 19:15:59.264596
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    var_0 = transport_plugin_0.get_adapter()
    assert var_0 is not None


# Generated at 2022-06-25 19:16:00.441410
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:16:04.830238
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    # Arrange
    mime = 'Content-Type: application/json'

    # Act
    formatter_plugin_0 = FormatterPlugin(
        format_options={'style': 'default'}
    )

    # Assert
    assert formatter_plugin_0.kwargs == {'format_options': {'style': 'default'}}


# Generated at 2022-06-25 19:16:07.010021
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    arguments = {'format_options': {}}
    test_class = FormatterPlugin(**arguments)
    test_class.format_body("test_content", "test_mime")


# Generated at 2022-06-25 19:16:09.324208
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Set up args
    mime = 'mime'
    content = 'content'

    # Call object method
    formatter_plugin_0 = FormatterPlugin()
    var_1 = formatter_plugin_0.format_body(mime, content)


# Generated at 2022-06-25 19:16:11.899087
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    arg_0 = FormatterPlugin()
    arg_1 = str()
    arg_2 = str()
    arg_0.format_body(arg_1, arg_2)


# Generated at 2022-06-25 19:17:56.361213
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    var_0 = formatter_plugin_0.format_body("n.ih.r", "DE:i?t\"'2t")


# Generated at 2022-06-25 19:17:59.636671
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    """Tests the format_headers method of class FormatterPlugin"""
    # Test with an instance of FormatterPlugin
    formatter_plugin_0 = FormatterPlugin()
    var_0 = formatter_plugin_0.format_headers()


# Generated at 2022-06-25 19:18:01.567478
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    try:
        auth_plugin_0 = AuthPlugin()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 19:18:02.436727
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:18:04.463937
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()
    assert transport_plugin_0.prefix == None
    assert transport_plugin_0.package_name == None


# Generated at 2022-06-25 19:18:06.940975
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # You can choose to use keyword arguments in case you want to test a different constructor
    transport_plugin_0 = FormatterPlugin()
    var_1 = transport_plugin_0.format_headers('HEADERS')
    # This should be false
    assert var_1 == 'HEADERS'


# Generated at 2022-06-25 19:18:07.988427
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    var_0 = transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:18:09.561221
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    var_0 = transport_plugin_0.get_adapter()
    print(var_0)

# Generated at 2022-06-25 19:18:11.102289
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin(mime)
    attributes_0 = converter_plugin_0.mime
    assert attributes_0 == mime
    return attributes_0


# Generated at 2022-06-25 19:18:20.931784
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    #
    # unit test for method format_body of class FormatterPlugin
    #
    formatter_plugin_0 = FormatterPlugin()
    str_0 = formatter_plugin_0.format_body("", "")
    assert str_0 == ""
    str_1 = formatter_plugin_0.format_body("", "")
    assert str_1 == ""
    str_2 = formatter_plugin_0.format_body("", "")
    assert str_2 == ""
    str_3 = formatter_plugin_0.format_body("", "")
    assert str_3 == ""
    str_4 = formatter_plugin_0.format_body("", "")
    assert str_4 == ""
    str_5 = formatter_plugin_0.format_body("", "")
    assert str_5