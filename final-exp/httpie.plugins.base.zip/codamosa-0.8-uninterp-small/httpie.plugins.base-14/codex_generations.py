

# Generated at 2022-06-25 19:10:20.550216
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers('headers')


# Generated at 2022-06-25 19:10:23.486383
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body("content", "mime") is None, 'Expected None, but got: ' + repr(None)


# Generated at 2022-06-25 19:10:25.520783
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = ""
    formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:10:27.686841
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 19:10:33.258511
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.name == 'httpie-formatter-plugin-example'
    assert formatter_plugin_0.description == None
    assert formatter_plugin_0.group_name == 'format'
    assert formatter_plugin_0.format_body('\t\n', 'text/plain') == '\t\n'
    assert formatter_plugin_0.format_body('\n', 'text/plain') == '\n'
    assert formatter_plugin_0.format_body('\n\t', 'text/plain') == '\n\t'
    assert formatter_plugin_0.format_body('\n\n\t\n', 'text/plain') == '\n\n\t\n'
    assert formatter_

# Generated at 2022-06-25 19:10:41.314008
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Arbitrary test case
    formatter_plugin = FormatterPlugin()
    content = 'hello world'
    mime = 'text/plain'
    expected = formatter_plugin.format_body(content, mime)
    assert expected == content
    # Edge case 0
    content = None
    mime = None
    expected = formatter_plugin.format_body(content, mime)
    assert expected == content
    # Utilises all the inputs
    formatter_plugin_2 = FormatterPlugin()
    content = 'hello world'
    mime = 'text/plain'
    expected = formatter_plugin_2.format_body(content, mime)
    assert expected == content

# Generated at 2022-06-25 19:10:43.499017
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    if FormatterPlugin.format_body() != None:
        raise AssertionError


# Generated at 2022-06-25 19:10:46.222985
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    test_instance_0 = FormatterPlugin()
    test_arg_0 = 'hello world'
    test_instance_0.format_headers(test_arg_0)

# Generated at 2022-06-25 19:10:48.858927
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body('', '') == ''



# Generated at 2022-06-25 19:10:51.616561
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body(content="a", mime="") == "a"


# Generated at 2022-06-25 19:10:56.309215
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'http://google.com'
    assert(formatter_plugin_0.format_headers(headers) == 'http://google.com')



# Generated at 2022-06-25 19:11:02.162622
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    headers_1 = formatter_plugin_1.format_headers(headers ='')
    assert headers_1 == ''
    formatter_plugin_2 = FormatterPlugin()
    headers_2 = formatter_plugin_2.format_headers(headers ='')
    assert headers_2 == ''
    formatter_plugin_3 = FormatterPlugin()
    headers_3 = formatter_plugin_3.format_headers(headers ='')
    assert headers_3 == ''
    formatter_plugin_4 = FormatterPlugin()
    headers_4 = formatter_plugin_4.format_headers(headers ='')
    assert headers_4 == ''
    formatter_plugin_5 = FormatterPlugin()

# Generated at 2022-06-25 19:11:05.520676
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers = FormatterPlugin.format_headers
    result = formatter_plugin_0.format_headers("headers")
    assert result == "headers"


# Generated at 2022-06-25 19:11:08.197493
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = "content"
    mime = "mime"
    result = formatter_plugin_0.format_body(content, mime)


# Generated at 2022-06-25 19:11:12.402577
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body('', 'text/html') == ''



# Generated at 2022-06-25 19:11:14.570778
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers(headers='headers_1')


# Generated at 2022-06-25 19:11:18.100700
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body("{\"code\":0}\n", "application/json")
    formatter_plugin_0.format_body("{\"code\":0}\n", "application/json")


# Generated at 2022-06-25 19:11:23.821872
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    try:
        formatter_plugin_1.format_body("foo/bar","something")
    except Exception as e:
        pass
    else:
        raise Exception("format_body method of class FormatterPlugin did not throw any exception")



# Generated at 2022-06-25 19:11:30.146670
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = '''HTTP/1.1 401 UNAUTHORIZED\r
Content-Type: text/plain\r
Date: Mon, 24 Aug 2020 17:00:54 GMT\r
Server: Apache/2\r
Set-Cookie: JSESSIONID=14D177092DC9FAB1D6E2B0D5F35B5B6B; Path=/; HttpOnly\r
\r
'''
    # Call method format_headers of FormatterPlugin instance formatter_plugin_0
    formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:11:34.680158
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'ABC'
    value = formatter_plugin_0.format_headers(headers)
    assert (value == 'ABC')


# Generated at 2022-06-25 19:11:47.110922
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin(format_options={'colors': {'hex': 'red'}, 'headers': {'cookie': {'sep': '; '}}, 'pretty': {'colors': {'header': 'blue'}}})
    formatter_plugin_0.kwargs = {'format_options': {'pretty': {'colors': {'header': 'blue'}}, 'headers': {'cookie': {'sep': '; '}}, 'colors': {'hex': 'red'}}}
    formatter_plugin_0.format_options = {'pretty': {'colors': {'header': 'blue'}}, 'headers': {'cookie': {'sep': '; '}}, 'colors': {'hex': 'red'}}
    formatter_plugin_0.enabled = True

# Generated at 2022-06-25 19:11:50.705068
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    content = "some content"
    mime = "some mime"
    formatter_plugin_0 = FormatterPlugin()
    assert content == formatter_plugin_0.format_body(content, mime)


# Generated at 2022-06-25 19:11:54.596663
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers("bNMkzxe=U6DlYI1S:S:S:S:S:S:S:S:S:S:S:S:S:S:Mg=:")


# Generated at 2022-06-25 19:11:56.050836
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    assert isinstance(formatter_plugin, FormatterPlugin)

# Generated at 2022-06-25 19:11:57.540797
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers("") == ''



# Generated at 2022-06-25 19:12:00.617270
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.kwargs = {'format_options': {'format': 'colors'}}
    assert formatter_plugin_0.format_body(None, None)


# Generated at 2022-06-25 19:12:04.449844
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin(format_options="option_1")
    formatter_plugin_1.format_body("JSON", "application/json")


# Generated at 2022-06-25 19:12:13.007689
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert isinstance(formatter_plugin_0.format_body(content='<', mime='\n'), str)
    assert isinstance(formatter_plugin_0.format_body(content='V', mime='\n'), str)
    assert isinstance(formatter_plugin_0.format_body(
        content='.', mime='\n'), str)
    assert isinstance(formatter_plugin_0.format_body(
        content='\n', mime='\n'), str)
    assert isinstance(formatter_plugin_0.format_body(
        content='\n', mime='\n'), str)


# Generated at 2022-06-25 19:12:16.260166
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()

    # No error should be raised
    try:
        formatter_plugin_0.format_body('', '')
    except:
        raise



# Generated at 2022-06-25 19:12:18.825940
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    expected = str()
    actual = formatter_plugin_0.format_headers(headers = str())
    assert actual == expected


# Generated at 2022-06-25 19:12:27.996206
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "User-Agent: HTTPie/1.0.2\nAccept-Encoding: gzip, deflate, compress\nAccept: */*\nConnection: keep-alive\n"
    output = formatter_plugin_0.format_headers(headers)
    assert type(output) is str


# Generated at 2022-06-25 19:12:36.899538
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins import FormatterPlugin
    import httpie.plugins as plugins
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:12:45.737192
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.kwargs = dict()
    formatter_plugin_0.kwargs['format_options'] = set()
    formatter_plugin_0.format_options = set()
    formatter_plugin_0.enabled = True
    mime = 'application/atom+xml'
    content = 'application/atom+xml'
    result = formatter_plugin_0.format_body(content, mime)
    assert result == 'application/atom+xml'


# Generated at 2022-06-25 19:12:47.398476
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = None
    formatter_plugin_0.format_headers(headers)

# Generated at 2022-06-25 19:12:53.276173
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Creating a FormatterPlugin object
    formatter_plugin = FormatterPlugin()

    # Ensure that the format_body method returns a string
    assert isinstance(formatter_plugin.format_body('test_content', 'test_mime'), str)



# Generated at 2022-06-25 19:12:55.126353
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers("") == ""


# Generated at 2022-06-25 19:13:00.880939
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'headers'
    headers = formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:13:08.494238
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    # Get a FormatterPlugin
    formatter_plugin = FormatterPlugin()
    formatter_plugin = FormatterPlugin(format_options = {'style':None})
    assert isinstance(formatter_plugin, FormatterPlugin)

    # Call method format_body of class FormatterPlugin
    formatter_plugin.format_body(content = 'content', mime = 'mime')



# Generated at 2022-06-25 19:13:11.390988
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    str_0 = formatter_plugin_0.format_headers(None)
    str_1 = FormatterPlugin.format_headers('headers')


# Generated at 2022-06-25 19:13:21.098119
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    env = itest.Environment([])
    space_case_0 = FormatterPlugin(env=env, format_options={})
    do_space_case_0 = space_case_0.format_headers('headers')
    assert do_space_case_0 == 'headers'
    space_case_1 = FormatterPlugin(env=env, format_options={'headers': {'indent': ' '}})
    do_space_case_1 = space_case_1.format_headers('headers')
    assert do_space_case_1 == 'headers'
    space_case_2 = FormatterPlugin(env=env, format_options={'headers': {'indent': '\t'}})
    do_space_case_2 = space_case_2.format_headers('headers')
    assert do_space_case_

# Generated at 2022-06-25 19:13:34.607520
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    pass


# Generated at 2022-06-25 19:13:39.500597
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('content_bytes', 'mime')
    # There should be a warning here

# Generated at 2022-06-25 19:13:48.195944
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'Accept-Encoding: gzip, deflate\nConnection: keep-alive\nAccept: */*\nContent-Length: 0\nUser-Agent: HTTPie/1.0.3\n'
    expected_value = 'Accept-Encoding: gzip, deflate\nConnection: keep-alive\nAccept: */*\nContent-Length: 0\nUser-Agent: HTTPie/1.0.3\n'
    assert formatter_plugin_0.format_headers(headers) == expected_value
    headers = 'Content-Length: 0\nAccept: */*\nUser-Agent: HTTPie/1.0.3\nConnection: keep-alive\nAccept-Encoding: gzip, deflate\n'

# Generated at 2022-06-25 19:13:52.958410
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    headers_1 = "hello"
    assert_equals(formatter_plugin_1.format_headers(headers_1), "hello")



# Generated at 2022-06-25 19:13:56.770153
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "test/css") == "test/css"
    return "test/css"


# Generated at 2022-06-25 19:14:02.777363
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin(
        format_options=['headers']
    )
    headers = 'HTTP/1.1 200 OK\n'\
        'Content-Encoding: gzip\n'\
        'Content-Type: application/json; charset=utf-8\n'
    headers = formatter_plugin.format_headers(headers)

    assert headers == 'HTTP/1.1 200 OK\n'\
        'Content-Encoding: gzip\n'\
        'Content-Type: application/json; charset=utf-8\n'

    formatter_plugin = FormatterPlugin(
        format_options=['headers', 'pretty']
    )

# Generated at 2022-06-25 19:14:06.614807
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Init
    formatter_plugin_0 = FormatterPlugin()
    headers = "headers.txt"

    # Invoke method
    result_headers = formatter_plugin_0.format_headers(headers)
    assert result_headers == "headers.txt"


# Generated at 2022-06-25 19:14:10.418518
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin(**{'format_options': {'foo': None}})
    assert None is not formatter_plugin_0.format_body(
        '', 'application/json')



# Generated at 2022-06-25 19:14:19.112966
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # test_FormatterPlugin_format_body
    print('test_FormatterPlugin_format_body')
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.kwargs = {
        'format_options': {
            'output_options': {'flow_style': True, 'sort_keys': True},
            'pprint_max_array_len': 1,
            'pprint_max_depth': 2,
            'pprint_max_dict_len': 1,
            'pprint_max_seq_len': 2,
            'pprint_miscellaneous_max_size': 1,
            'pprint_number_max_size': 1,
            'pprint_str_max_size': 1
        }
    }
    import re
    import json
    import yaml

# Generated at 2022-06-25 19:14:23.340458
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    test_string_1 = 'headers: str'
    expected_value_1 = 'headers: str'
    output_value_1 = formatter_plugin_1.format_headers(test_string_1)
    assert output_value_1 == expected_value_1


# Generated at 2022-06-25 19:14:34.653145
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    cp = ConverterPlugin('mime')
    cp.convert('content_bytes')
    assert True


# Generated at 2022-06-25 19:14:35.783629
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()


# Generated at 2022-06-25 19:14:36.822256
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()



# Generated at 2022-06-25 19:14:38.436847
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    try:
        converter_plugin_0 = ConverterPlugin(str())
    except Exception:
        assert False
    assert True



# Generated at 2022-06-25 19:14:39.822986
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin = TransportPlugin()
    result = transport_plugin.get_adapter()
    assert result is None



# Generated at 2022-06-25 19:14:42.937650
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    config_dir = os.path.dirname(os.path.abspath(__file__))
    plugin_dir = os.path.join(config_dir, 'plugins')
    import httpie.plugins as plugins
    plugins.load_plugins(plugin_dir)
    formatter_plugin = plugins.formatter_plugins[0]
    formatter_plugin.__init__()
    return True

# Generated at 2022-06-25 19:14:47.351982
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    # get_adapter should raise an error because it has not been implemented
    tp = TransportPlugin()
    with pytest.raises(NotImplementedError):
        tp.get_adapter()


# Generated at 2022-06-25 19:14:50.503760
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'content-type: application/atom+xml'
    assert formatter_plugin_0.format_headers(headers) == headers



# Generated at 2022-06-25 19:14:57.799431
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():

    class AuthPlugin_impl(AuthPlugin):
        def get_auth(self, username=None, password=None):
            """
            If `auth_parse` is set to `True`, then `username`
            and `password` contain the parsed credentials.

            Use `self.raw_auth` to access the raw value passed through
            `--auth, -a`.

            Return a ``requests.auth.AuthBase`` subclass instance.

            """
            return BasicAuth('user', 'pass')

    auth_plugin_0 = AuthPlugin()
    auth_plugin_0 = AuthPlugin_impl()
    basic_auth_0 = auth_plugin_0.get_auth()
    assert_equal(type(basic_auth_0), BasicAuth)
    assert_equal(basic_auth_0.username, 'user')

# Generated at 2022-06-25 19:15:03.832039
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    with mock.patch('os.path.exists', return_value=True), \
        mock.patch('os.popen'):
        formatter_plugin_1 = AuthPlugin()
        assert formatter_plugin_1.get_auth() == None


# Generated at 2022-06-25 19:15:26.657940
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    result=formatter_plugin_0.format_headers(headers)
    assert result == headers


# Generated at 2022-06-25 19:15:28.488343
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    a = TransportPlugin()
    assert isinstance(a.get_adapter(), requests.adapters.BaseAdapter)


# Generated at 2022-06-25 19:15:30.591609
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()

    assert base_plugin.name == None
    assert base_plugin.description == None
    assert base_plugin.package_name == None


# Generated at 2022-06-25 19:15:32.269049
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    formatter_plugin_1 = FormatterPlugin(prefix=None)



# Generated at 2022-06-25 19:15:33.517457
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    #@TODO: Replace with a unit test
    pass


# Generated at 2022-06-25 19:15:37.524743
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    #
    # Case 0
    #
    transport_plugin_0 = TransportPlugin()
    try:
        transport_plugin_0.get_adapter()
    except NotImplementedError:
        pass
    else:
        assert False, "Expected not to reach here"



# Generated at 2022-06-25 19:15:43.810419
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert t.check_events(formatter_plugin_0,
                          {'format_body': 'application/atom+xml',
                           'format_options': OrderedDict([])})
    assert t.check_events(formatter_plugin_0,
                          {'format_body': 'application/atom+xml',
                           'format_options': OrderedDict([])})


# Generated at 2022-06-25 19:15:45.809618
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_1 = FormatterPlugin()
    assert isinstance(formatter_plugin_1, FormatterPlugin)


# Generated at 2022-06-25 19:15:48.645575
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    assert formatter_plugin_1.format_headers("HTTP/1.1 200 OK") == "HTTP/1.1 200 OK"


# Generated at 2022-06-25 19:15:50.701416
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = ""
    assert(formatter_plugin_0.format_headers(headers) == "")


# Generated at 2022-06-25 19:16:50.276202
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    """
    AuthPlugin(self, raw_auth: str, **kwargs: Any) -> None
    """
    auth_plugin_0 = AuthPlugin()
    assert auth_plugin_0.auth_require == True
    assert auth_plugin_0.auth_parse == True
    assert auth_plugin_0.netrc_parse == False
    assert auth_plugin_0.prompt_password == True
    assert auth_plugin_0.raw_auth == None
    print("test_AuthPlugin: constructed an instance of class AuthPlugin")



# Generated at 2022-06-25 19:16:52.373061
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(None)
    assert_raises(NotImplementedError, converter_plugin_0.convert, None)


# Generated at 2022-06-25 19:16:58.649004
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "HTTP/1.1 200 OK\nDate: Fri, 23 Oct 2020 16:31:47 GMT\nContent-Type: text/html; charset=UTF-8\nServer: Jetty(9.2.z-SNAPSHOT)\nContent-Length: 0\n\n"
    output = formatter_plugin_0.format_headers(headers)
    assert output == headers


# Generated at 2022-06-25 19:17:01.297768
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers('headers') == 'headers'
    print('Success: test_FormatterPlugin_format_headers')


# Generated at 2022-06-25 19:17:05.453689
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:17:08.772561
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    # given
    mime = 'mime'

    # when
    converter_plugin = ConverterPlugin(mime)

    # then
    assert converter_plugin


# Generated at 2022-06-25 19:17:10.081390
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin = TransportPlugin()
    transport_plugin.get_adapter()


# Generated at 2022-06-25 19:17:14.482066
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    sample = AuthPlugin()
    assert(sample.auth_type == None)
    sample.auth_type = "MyAuth"
    assert(sample.auth_type == "MyAuth")
    assert(sample.auth_parse == True)
    sample.auth_parse = False
    assert(sample.auth_parse == False)
    assert(sample.auth_require == True)
    sample.auth_require = False
    assert(sample.auth_require == False)
    assert(sample.netrc_parse == False)
    sample.netrc_parse = True
    assert(sample.netrc_parse == True)
    assert(sample.prompt_password == True)
    sample.prompt_password = False
    assert(sample.prompt_password == False)
    assert(sample.raw_auth == None)
    sample.raw

# Generated at 2022-06-25 19:17:18.386269
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    print("Start unit test for constructor of class ConverterPlugin")
    converter_plugin_0 = ConverterPlugin(mime="text/plain")
    assert converter_plugin_0.mime == "text/plain"
    print("Unit test for constructor of class ConverterPlugin finished")


# Generated at 2022-06-25 19:17:21.444173
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'headers'
    headers_1 = formatter_plugin_0.format_headers(headers)
    assert headers_1 == 'headers'


# Generated at 2022-06-25 19:19:11.956957
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    try:
        auth_plugin_0 = AuthPlugin()
    except NotImplementedError as e:
        assert(str(e) == 'get_auth()')


# Generated at 2022-06-25 19:19:15.489764
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin('multipart/form-data')
    converter_plugin_1 = ConverterPlugin('multipart/form-data')
    try:
        converter_plugin_0.convert('\u007f')
    except NotImplementedError:
        pass
    try:
        converter_plugin_1.convert(123)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:19:18.544880
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin('application/vnd.sun.wadl+xml')
    converter_plugin_0.convert('\tiw\r')


# Generated at 2022-06-25 19:19:19.571887
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:19:21.467981
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('', 'application/atom+xml')


# Generated at 2022-06-25 19:19:23.296121
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    formatter_plugin.format_headers("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nOK")


# Generated at 2022-06-25 19:19:23.908483
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    TransportPlugin()


# Generated at 2022-06-25 19:19:24.710451
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:19:25.849720
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin = AuthPlugin()


# Generated at 2022-06-25 19:19:26.255289
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    BasePlugin()