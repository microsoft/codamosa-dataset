

# Generated at 2022-06-25 19:10:23.485506
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    def format_body(self, content: str, mime: str) -> str:
        """Return processed `content`.

        :param mime: E.g., 'application/atom+xml'.
        :param content: The body content as text

        """
        return content

    assert True == type(format_body(self="", content="", mime="")) == str


# Generated at 2022-06-25 19:10:25.868676
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = ''
    assert formatter_plugin_0.format_headers(headers) == headers



# Generated at 2022-06-25 19:10:28.055433
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "headers"
    assert formatter_plugin_0.format_headers(headers) == "headers"


# Generated at 2022-06-25 19:10:29.674940
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    instance_0 = FormatterPlugin()
    instance_0.format_body('', '') # Expects a TypeError


# Generated at 2022-06-25 19:10:33.956600
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "String, \"headers\""
    assert formatter_plugin_0.format_headers(headers) == "String, \"headers\""


# Generated at 2022-06-25 19:10:38.724378
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    content_1 = "content"
    mime_1 = "mime"
    try:
        formatter_plugin_1.format_body(content_1, mime_1)
    except NotImplementedError:
        print("Test successful!\n")


# Generated at 2022-06-25 19:10:40.508418
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('mime', 'content')


# Generated at 2022-06-25 19:10:43.398274
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = None
    assert formatter_plugin_0.format_headers(headers) == None


# Generated at 2022-06-25 19:10:45.133233
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()



# Generated at 2022-06-25 19:10:47.094917
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers('headers_0')
    assert True


# Generated at 2022-06-25 19:10:50.725206
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body("", "")



# Generated at 2022-06-25 19:10:54.397789
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'test_mime'
    content = 'test_content'
    assert formatter_plugin_0.format_body(content, mime) == content


# Generated at 2022-06-25 19:10:59.902012
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'HTTP/1.1 200 OK\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nServer: Apache/2.2.14 (Win32)\r\nLast-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\nContent-Length: 88\r\nContent-Type: text/html\r\nConnection: Closed\r\n\r\n'
    formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:11:06.742983
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    """
    Test case for method format_headers of class FormatterPlugin
    """
    formatter_plugin_1 = FormatterPlugin()
    headers_1 = 'Content-Type: application/json\nContent-Length: 30'
    expected_result_1 = 'Content-Type: application/json\nContent-Length: 30'
    actual_result_1 = formatter_plugin_1.format_headers(headers_1)
    assert actual_result_1 == expected_result_1


# Generated at 2022-06-25 19:11:11.506267
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'headers'
    with pytest.raises(NotImplementedError):
        formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:11:12.802868
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    content = "text"
    mime = "text"
    


# Generated at 2022-06-25 19:11:13.775617
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    pass


# Generated at 2022-06-25 19:11:21.303082
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    """Some of the formatters use C escape sequences, which if printed
    out in a terminal in a text mode, will be interpreted by the terminal
    as a command and not as a sequence of characters. Because of this
    we need to strip the formatting and make sure that the result is
    equal to the argument.
    """
    formatter_plugin_0 = FormatterPlugin()
    mime = 'text/html'
    content = '<html>...</html>'
    out = formatter_plugin_0.format_body(mime, content)
    assert out == content


# Generated at 2022-06-25 19:11:30.186429
# Unit test for method format_body of class FormatterPlugin

# Generated at 2022-06-25 19:11:34.719743
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers(headers='headers')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 19:11:38.207276
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers(headers='headers')


# Generated at 2022-06-25 19:11:41.193842
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    result = formatter_plugin_0.format_headers(headers="HTTP/1.1 200 OK\n")
    assert result == "HTTP/1.1 200 OK\n"


# Generated at 2022-06-25 19:11:44.724110
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    headers = "Content-Type :text/html; charset=utf-8\nContent-Length:34\n"
    formatter_plugin.format_headers(headers)



# Generated at 2022-06-25 19:11:47.490475
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin(format_options = u'JSON')
    formatter_plugin_0.format_body('Hello World!', 'text/html')



# Generated at 2022-06-25 19:11:52.796882
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter_plugin_0 = TestFormatterPlugin()

    # Check the return value of method format_body() of class FormatterPlugin
    assert formatter_plugin_0.format_body('content', 'mime') == 'content'

# Generated at 2022-06-25 19:12:00.283317
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content_0 = "\u0a62\u0d4c\u10f8\u1320\u1759\u19a6\u1c6b\u1fd4\u23cf\u268b\u2dab\u33a6\u38ce\u3de3\u4408\u4b26\u50dc\u5661\u5df8\u65a6\u6b94\u6f71\u7433"
    mime_0 = 'application/javascript'
    result_0 = formatter_plugin_0.format_body(content_0, mime_0)

# Generated at 2022-06-25 19:12:04.451830
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    arg_1 = ""
    res = formatter_plugin_0.format_headers(arg_1)
    assert res == ""


# Generated at 2022-06-25 19:12:06.629636
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers()


# Generated at 2022-06-25 19:12:10.946402
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    class FormatterPlugin:

        def format_body(self, content: str, mime: str) -> str:
            return content

    formatter_plugin = FormatterPlugin()
    content = '{"key": "value"}'
    assert formatter_plugin.format_body(content, 'application/json') == content



# Generated at 2022-06-25 19:12:15.930748
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    content_bytes = b''
    formatter_plugin_0 = FormatterPlugin(**{'format_options': {}}, )
    # Call format_headers() as defined by the abstract class.
    ret_format_headers = formatter_plugin_0.format_headers(content_bytes)
    # Call format_headers() as defined by the parent class.
    ret_format_headers = formatter_plugin_0.format_headers(content_bytes)


# Generated at 2022-06-25 19:12:18.470686
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()



# Generated at 2022-06-25 19:12:22.825081
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    plugin = TransportPlugin()
    assert plugin.name == None
    assert plugin.description == None
    assert plugin.package_name == None


# Generated at 2022-06-25 19:12:24.172747
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:12:27.935493
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin("application/xml")
    assert converter_plugin_0 != None
    converter_plugin_1 = ConverterPlugin("image/jpeg")
    assert converter_plugin_1 != None


# Generated at 2022-06-25 19:12:31.698694
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    username = ""
    password = ""
    assert auth_plugin_0.get_auth(username, password) is None


# Generated at 2022-06-25 19:12:33.639985
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    assert_raises(NotImplementedError, transport_plugin_0.get_adapter)


# Generated at 2022-06-25 19:12:35.416628
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    try:
        ConverterPlugin.convert()
    except (NotImplementedError):
        pass
    else:
        print("Test Case Failed.")


# Generated at 2022-06-25 19:12:36.125198
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    BasePlugin()


# Generated at 2022-06-25 19:12:37.812205
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()

    # No exception raised
    transport_plugin_0.get_adapter()



# Generated at 2022-06-25 19:12:38.854472
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin = ConverterPlugin(None)


# Generated at 2022-06-25 19:12:44.729142
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin = TransportPlugin()
    assert(transport_plugin.package_name is None)
    transport_plugin.get_adapter()
    assert (transport_plugin.prefix is None)

# Generated at 2022-06-25 19:12:46.226798
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin = TransportPlugin()
    adapter = transport_plugin.get_adapter()


# Generated at 2022-06-25 19:12:48.205884
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    auth_plugin_0.get_auth(username=None, password=None)



# Generated at 2022-06-25 19:12:58.719633
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    try:
        transport_plugin_0.get_adapter()
        assert False # TODO: should raise AssertionError, "AssertionError: ..."
    except NotImplementedError:
        pass
    # TODO: Uncomment the following lines in case you wish to test this
    #       method without inheriting from the defined class
    # FormatterPlugin.get_adapter = TransportPlugin.get_adapter
    # transport_plugin_1 = TransportPlugin()
    # try:
    #     transport_plugin_1.get_adapter()
    #     assert False # TODO: should raise AssertionError, "AssertionError: ..."
    # except NotImplementedError:
    #     pass


# Generated at 2022-06-25 19:13:00.333818
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    result = formatter_plugin_0.format_body('content', 'string')
    assert isinstance(result, str), 'Expected str got {}'.format(type(result))


# Generated at 2022-06-25 19:13:02.563006
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()


# Generated at 2022-06-25 19:13:10.158396
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Test 1
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('', 'application/atom+xml')

    # Test 2
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('test_value', 'application/atom+xml')

    # Test 3
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('', 'application/javascript')



# Generated at 2022-06-25 19:13:14.246204
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    try:
        # Instantiate object of class AuthPlugin
        auth_plugin_0 = AuthPlugin()
        # Call method get_auth on object auth_plugin_0
        auth_plugin_0.get_auth()
        assert False
    except NotImplementedError as e:
        assert True


# Generated at 2022-06-25 19:13:16.319196
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    prefix = None
    self = TransportPlugin()
    self.prefix = prefix
    self.get_adapter()


# Generated at 2022-06-25 19:13:18.867250
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin = TransportPlugin()
    try:
        transport_plugin.get_adapter()
    except NotImplementedError:
        print("NotImplementedError")


# Generated at 2022-06-25 19:13:25.098069
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:13:31.821360
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "GET /posts/ HTTP/1.1\r\n" \
              "Accept: application/json, */*\r\n" \
              "Accept-Encoding: gzip, deflate\r\n" \
              "Connection: keep-alive\r\n" \
              "Content-Length: 4\r\n" \
              "Content-Type: text/plain\r\n" \
              "Host: 127.0.0.1:5000\r\n" \
              "User-Agent: HTTPie/1.0.3\r\n" \
              "\r\n" \
              "YWJj"
    formatter_plugin_0.format_headers(headers)

# Generated at 2022-06-25 19:13:34.470161
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin = TransportPlugin()
    transport_plugin.get_adapter()


# Generated at 2022-06-25 19:13:36.762947
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_1 = FormatterPlugin()
    assert formatter_plugin_1.enabled is True
    assert formatter_plugin_1.kwargs is None
    assert formatter_plugin_1.format_options is None

# Generated at 2022-06-25 19:13:40.074501
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    formatter_plugin_0 = AuthPlugin()
    formatter_plugin_0.get_auth()



# Generated at 2022-06-25 19:13:45.924543
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin(
        format_options={
            'style': '',
            'colors': False,
            'format': 'colored',
            'plain_options': '',
            'colors_options': '',
            'colors_256': False,
            'json_options': ''
        }
    )
    formatter_plugin_0.format_body('foo', 'bar')

# Generated at 2022-06-25 19:13:47.572911
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin = ConverterPlugin('application/json')
    assert converter_plugin.mime == 'application/json'


# Generated at 2022-06-25 19:13:53.187193
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin("application/application/application")
    content_bytes = b"content_bytes"
    with pytest.raises(NotImplementedError):
        converter_plugin_0.convert(content_bytes)


# Generated at 2022-06-25 19:13:54.180969
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:13:58.040397
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    assert getattr(FormatterPlugin, 'group_name') == 'format'
    assert not getattr(FormatterPlugin, 'enabled')
    formatter_plugin_0 = FormatterPlugin()
    assert getattr(formatter_plugin_0, 'group_name') == 'format'
    assert not getattr(formatter_plugin_0, 'enabled')


# Generated at 2022-06-25 19:14:12.430505
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    username = 'username'
    password = 'password'

    # Call AuthPlugin::get_auth
    assert auth_plugin_0.get_auth(username, password) is None



# Generated at 2022-06-25 19:14:13.410085
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    pass



# Generated at 2022-06-25 19:14:14.473548
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    test_case_0()

test_BasePlugin()

# Generated at 2022-06-25 19:14:17.963177
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    prefix = 'unix://'
    test_case_0 = TransportPlugin()
    test_case_0.prefix = prefix
    test_case_0.get_adapter()
    test_case_0.prefix = 'http://'
    test_case_0.get_adapter()


# Generated at 2022-06-25 19:14:21.981062
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    assert AuthPlugin.auth_type is None
    assert AuthPlugin.auth_require is True
    assert AuthPlugin.auth_parse is True
    assert AuthPlugin.netrc_parse is False
    assert AuthPlugin.prompt_password is True
    assert AuthPlugin.netrc_parse is False
    assert AuthPlugin.raw_auth is None



# Generated at 2022-06-25 19:14:26.659978
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    headers = 'HTTP/1.1 200 OK\nConnection: keep-alive\nContent-Type: text/html; charset=utf-8\nContent-Encoding: gzip'
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers(headers)==headers


# Generated at 2022-06-25 19:14:32.859797
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    test = AuthPlugin()
    assert test != None
    assert test.auth_type == None
    assert test.auth_require == True
    assert test.auth_parse == True
    assert test.netrc_parse == False
    assert test.prompt_password == True
    assert test.raw_auth == None


# Generated at 2022-06-25 19:14:35.006962
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    with pytest.raises(NotImplementedError):
        transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:14:37.831856
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin = ConverterPlugin(mime='application/rdap+json')
    assert converter_plugin.convert(
        content_bytes=b'[{"foo": "bar"}]') == '[{"foo": "bar"}]'


# Generated at 2022-06-25 19:14:42.244782
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(None)
    assert_raises(NotImplementedError, converter_plugin_0.convert, None)


# Generated at 2022-06-25 19:15:07.285750
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(mime = 'mime')
    with pytest.raises(NotImplementedError):
        converter_plugin_0.convert(content_bytes = b'content_bytes')


# Generated at 2022-06-25 19:15:10.025324
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    assert not None==ConverterPlugin.convert(None, None)



# Generated at 2022-06-25 19:15:16.054534
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    mime = 'application/json'
    content_bytes = '{"key":123}'.encode("utf8")
    json_plugin = JSONConverterPlugin(mime)
    output = 'key -> 123\n'
    assert json_plugin.convert(content_bytes) == output


if __name__ == "__main__":
    test_case_0()
    test_ConverterPlugin_convert()

# Generated at 2022-06-25 19:15:19.100284
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    assert base_plugin.name is None
    assert base_plugin.description is None
    assert base_plugin.package_name is None


# Generated at 2022-06-25 19:15:20.926189
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    pass



# Generated at 2022-06-25 19:15:25.861804
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin = ConverterPlugin('application/json')
    with pytest.raises(NotImplementedError):
        converter_plugin.convert(None)


# Generated at 2022-06-25 19:15:33.481449
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    def test_plugin():
        pass
    test_plugin.name = 'message'
    test_plugin.mime = 'application/message'
    test_plugin.__init__ = ConverterPlugin.__init__
    test_plugin.__init__(test_plugin, 'application/message')
    assert test_plugin.name == 'message'
    assert test_plugin.mime == 'application/message'

# Unit test 1 for function supports in class ConverterPlugin

# Generated at 2022-06-25 19:15:37.524625
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()
    assert transport_plugin_0.prefix == None
    assert transport_plugin_0.name == None
    assert transport_plugin_0.description == None
    assert transport_plugin_0.package_name == None
    
# Unit Test for constructor of class AuthPlugin

# Generated at 2022-06-25 19:15:40.125607
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin = TransportPlugin()
    # Constructor of TransportPlugin
    assert transport_plugin.name is None
    assert transport_plugin.description is None
    assert transport_plugin.package_name is None


# Generated at 2022-06-25 19:15:43.081948
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    content = formatter_plugin.format_body("", "")
    assert content == ""


# Generated at 2022-06-25 19:16:42.857746
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Create an instance of FormatterPlugin with no keyword arguments
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers("") == ""
    assert isinstance(formatter_plugin_0.format_headers(""), str)
    # Create an instance of FormatterPlugin with no keyword arguments
    formatter_plugin_1 = FormatterPlugin()
    assert formatter_plugin_1.format_headers("") == ""
    assert isinstance(formatter_plugin_1.format_headers(""), str)


# Generated at 2022-06-25 19:16:43.597406
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin = TransportPlugin()


# Generated at 2022-06-25 19:16:44.538316
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    auth_plugin_0.get_auth()

# Generated at 2022-06-25 19:16:46.012220
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin = TransportPlugin()


# Generated at 2022-06-25 19:16:46.829070
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    assert BasePlugin is not None



# Generated at 2022-06-25 19:16:52.105358
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    def get_adapter():
        raise NotImplementedError
    # prefix = None
    # prefix = 'foo'
    # The following codes are catch during httpie
    # plugin registration
    # tp = TransportPlugin()
    # tp = TransportPlugin(prefix=prefix)
    # tp.get_adapter()



# Generated at 2022-06-25 19:16:56.103289
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    # Instance of class AuthPlugin
    auth_plugin_0 = AuthPlugin()
    # Type error
    try:
        auth_plugin_0.get_auth()
    except TypeError as e:
        logger.error(e)


# Generated at 2022-06-25 19:16:57.197419
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    tp = FormatterPlugin()



# Generated at 2022-06-25 19:16:59.811181
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin("application/json")
    try:
        converter_plugin_0.convert("{}")
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:17:02.383413
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers_0 = formatter_plugin_0.format_headers('Content-Type: application/json\r\n\r\n')
    assert headers_0 == 'Content-Type: application/json\r\n\r\n'


# Generated at 2022-06-25 19:18:58.560415
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    assert base_plugin
    assert base_plugin.name == None
    assert base_plugin.description == None
    assert base_plugin.package_name == None


# Generated at 2022-06-25 19:19:01.731703
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    plugin_name = "test"
    plugin_description = "this is a test plugin"

    plugin_base = BasePlugin()
    plugin_base.name = plugin_name
    plugin_base.description = plugin_description

    assert plugin_base.name == plugin_name
    assert plugin_base.description == plugin_description


# Generated at 2022-06-25 19:19:03.667966
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(mime='')
    content_bytes = ''
    assert converter_plugin_0.convert(content_bytes) is None


# Generated at 2022-06-25 19:19:06.816750
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    # ConverterPlugin(mime)
    converter_plugin_0 = ConverterPlugin(mime)
    converter_plugin_1 = ConverterPlugin(mime)
    assert converter_plugin_0.mime == converter_plugin_1.mime


# Generated at 2022-06-25 19:19:09.218093
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    assert isinstance(base_plugin, BasePlugin)
    assert isinstance(base_plugin.name, str)
    assert isinstance(base_plugin.description, str)
    assert isinstance(base_plugin.package_name, str)



# Generated at 2022-06-25 19:19:12.635384
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    #test case 1
    assert base_plugin.name == None, "BasePlugin.name should be None"
    #test case 2
    assert base_plugin.description == None, "BasePlugin.description should be None"
    #test case 3
    assert base_plugin.package_name == None, "BasePlugin.package_name should be None"


# Generated at 2022-06-25 19:19:14.298289
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Arange
    formatter_plugin_0 = FormatterPlugin()

    # Act
    headers = formatter_plugin_0.format_headers('')

    # Assert
    assert headers == ''


# Generated at 2022-06-25 19:19:16.324194
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    formatter_plugin_1 = FormatterPlugin()
    content = formatter_plugin_1.format_body("{")

    assert content is "{"


# Generated at 2022-06-25 19:19:18.962252
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin = ConverterPlugin(mime='application/x-msgpack')
    converter_plugin.convert(content_bytes="Hello")

# Generated at 2022-06-25 19:19:21.209185
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers("headers") == 'headers', "formatter_plugin.py: test_case_0 failed"
