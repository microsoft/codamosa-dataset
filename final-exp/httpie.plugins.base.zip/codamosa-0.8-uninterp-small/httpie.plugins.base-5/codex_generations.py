

# Generated at 2022-06-25 19:10:21.010148
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = str()
    result = formatter_plugin_0.format_headers(headers)
    assert isinstance(result, str)



# Generated at 2022-06-25 19:10:22.922300
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert FormatterPlugin().format_headers("abcd") == "abcd"


# Generated at 2022-06-25 19:10:25.269278
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    result = formatter_plugin_0.format_body('1', '2')
    assert type(result) == str


# Generated at 2022-06-25 19:10:27.123938
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body("", "") == ""


# Generated at 2022-06-25 19:10:29.445764
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    test_mime: str = ""
    test_content: str = ""
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body(test_mime, test_content)

# Generated at 2022-06-25 19:10:35.310672
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_init = FormatterPlugin(env=None,
        format_options=None
        )
    formatter_plugin_format_body = formatter_plugin_init.format_body(content=None,
        mime=None
        )
    assert formatter_plugin_format_body == None


# Generated at 2022-06-25 19:10:39.193436
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = 'text/plain'
    mime = 'application/atom+xml'
    assert formatter_plugin_0.format_body(content, mime) in ['text/plain', 'application/atom+xml']


# Generated at 2022-06-25 19:10:43.246118
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    # Testing another branch: keywords: (i) and (i)
    assert formatter_plugin_0.format_body('', '') == '', 'Failed Assertion'



# Generated at 2022-06-25 19:10:45.765173
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('h', 'h')


# Generated at 2022-06-25 19:10:56.475924
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()

    try:
        # Test for a possible exception
        formatter_plugin_0.format_headers(headers='headers_0')
        raise Exception("Exception not raised")
    except:
        pass

    try:
        # Test for a possible exception
        formatter_plugin_0.format_headers(headers=None)
        raise Exception("Exception not raised")
    except:
        pass

    try:
        # Test for a possible exception
        formatter_plugin_0.format_headers(headers=[])
        raise Exception("Exception not raised")
    except:
        pass


# Generated at 2022-06-25 19:11:09.618619
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    test_content = "application/atom+xml"
    test_mime = "application/atom+xml"

# Generated at 2022-06-25 19:11:11.433406
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = formatter_plugin_0.format_body("", "application/json")



# Generated at 2022-06-25 19:11:13.457741
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    try:
        formatter_plugin_0.format_body(content, mime)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:11:18.492051
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = "text/plain"
    content = b"Httpie is a HTTP client.\n"
    content_formatted = formatter_plugin_0.format_body(content, mime)
    print("Content formatted:", content_formatted)
    assert content == content_formatted


# Generated at 2022-06-25 19:11:22.630467
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    some_headers = 'Application/Json'
    rv = formatter_plugin_0.format_headers(some_headers)

    return rv


# Generated at 2022-06-25 19:11:25.804806
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    # test if `FormatterPlugin.format_headers` is callable
    assert isinstance(FormatterPlugin.format_headers(formatter_plugin_0), str)


# Generated at 2022-06-25 19:11:28.142658
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    exception = None
    try:
        formatter_plugin_0.format_headers("fctz;1t")
    except Exception as e:
        exception = e
    assert exception is not None


# Generated at 2022-06-25 19:11:39.186059
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    formatter_plugin_1 = FormatterPlugin()

    # test for function formatter.format response body
    formatter_plugin_1.format_body("test_body", "application/json") # test for return string
    formatter_plugin_1.format_body("{test_body}", "application/json")
    formatter_plugin_1.format_body("[]", "application/json")
    formatter_plugin_1.format_body("[0,1,2,3,4]", "application/json")
    formatter_plugin_1.format_body("[['this', 'is', 'a', 'test'], ['this', 'is', 'another', 'test']]", "application/json")

# Generated at 2022-06-25 19:11:41.192574
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body(None, None)



# Generated at 2022-06-25 19:11:43.551317
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    print(formatter_plugin_0.format_headers('headers'))


# Generated at 2022-06-25 19:11:53.006803
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body('text/html', 'text/html') == 'text/html'



# Generated at 2022-06-25 19:11:55.774237
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers(headers ="HTTP/1.1 200 OK\n") ==  "HTTP/1.1 200 OK\n"


# Generated at 2022-06-25 19:11:58.308117
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    format_body_result_0 = formatter_plugin_0.format_body("", "")
    assert isinstance(format_body_result_0, str)


# Generated at 2022-06-25 19:12:04.196281
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    try:
        formatter_plugin_0 = FormatterPlugin()
        mime_0 = "application/atom+xml"
        content_0 = "<test></test>"
        assert formatter_plugin_0.format_body(content_0, mime_0) == "<test></test>"
    except:
        assert True == False


# Generated at 2022-06-25 19:12:08.305169
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    test_input = 'test_string'
    test_mime = 'application/json'
    assert isinstance(formatter_plugin.format_body(test_input, test_mime), str)


# Generated at 2022-06-25 19:12:09.576209
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    t = FormatterPlugin()
    t.format_headers("")


# Generated at 2022-06-25 19:12:11.597580
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body(None,None)


# Generated at 2022-06-25 19:12:16.163271
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    test_content = "Content"
    mime = "mime"
    expect_content = "Content"
    FormatterPlugin_mock = mock.Mock(spec=FormatterPlugin)
    FormatterPlugin_mock.format_body = FormatterPlugin.format_body
    result_content = FormatterPlugin_mock.format_body(test_content, mime)
    assert result_content == expect_content


# Generated at 2022-06-25 19:12:18.501470
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    env = Environment()
    assert formatter_plugin_1.format_headers("") == ""



# Generated at 2022-06-25 19:12:23.512025
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    def func(content: str, mime: str) -> str:
        return content
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body = func


# Generated at 2022-06-25 19:12:38.981766
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin(format_options=None)
    content = 'dGVzdA=='
    mime = 'text/plain'
    print(formatter_plugin_1.format_body(content, mime))


# Generated at 2022-06-25 19:12:45.294784
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    test_headers = {"a": "a", "b": "b"}
    test_output = formatter_plugin_0.format_headers(test_headers)
    assert test_output == test_headers


# Generated at 2022-06-25 19:12:52.837577
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    try:
        f0 = FormatterPlugin()
        f0.format_body(content='This is a test', mime='test type')
        assert True
    except NotImplementedError:
        assert True
    except Exception:
        assert False
    try:
        f1 = FormatterPlugin()
        f1.format_body(content=None, mime=None)
        assert False
    except:
        assert True



# Generated at 2022-06-25 19:13:00.565997
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Get the FormatterPlugin object
    formatter_plugin_0 = FormatterPlugin()

# Generated at 2022-06-25 19:13:09.253141
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    formatter_plugin_0 = FormatterPlugin()

    # Test no 1
    content = 'The quick brown fox jumps over the lazy dog.'
    mime = 'blah blah blah'

    res = formatter_plugin_0.format_body(content, mime)

    assert content == res

    # Test no 2
    res = formatter_plugin_0.format_body(0.00, "application/json")

    assert "0.0" == res

    print('Success')
    return



# Generated at 2022-06-25 19:13:19.776254
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    format_options = {}
    format_options['pretty'] = 'all'
    format_options['colors'] = '16'
    format_options['stdout_as_tTY'] = True
    format_options['style'] = 'solarized'
    format_options['ascii'] = False

    formatter_json_plugin = FormatterJsonPlugin(format_options=format_options)
    body = '{"msg":"Hello World"}'
    mime = 'application/json'
    output = formatter_json_plugin.format_body(body, mime)

    print('\n' + '*'*50)
    print('Unit test for method format_body of class FormatterJsonPlugin:')
    print('-'*50)
    print(output)

    formatter_pretty_plugin = FormatterPrettyPlugin

# Generated at 2022-06-25 19:13:21.458240
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    content = ''
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers(content)


# Generated at 2022-06-25 19:13:30.424310
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()

    def test_case_0():
        mime = 'text/plain'
        content = '{}'
        result = formatter_plugin_0.format_body(content,mime)
        assert result == '{}'

    def test_case_1():
        mime = 'application/json'
        content = '{"a" : {"b" : {"c" : {"d" : {"e" : {"f" : "g"}}}}}}'
        result = formatter_plugin_0.format_body(content,mime)

# Generated at 2022-06-25 19:13:34.997031
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body('hi', '') == 'hi'

# assert True test_case_0() == 1

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 19:13:38.065181
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    test_content = 'abcdef'  # type: str
    test_mime = 'application/atom+xml'  # type: str
    plugin = FormatterPlugin()
    output = plugin.format_body(test_content, test_mime)
    assert output == test_content


# Generated at 2022-06-25 19:14:15.734587
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    mime = 'application/atom+xml'

# Generated at 2022-06-25 19:14:19.527762
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_2 = FormatterPlugin()
    arg_0 = '<span>\n</span>'
    arg_1 = 'text/html'
    ret = formatter_plugin_2.format_body(arg_0, arg_1)
    assert ret == '<span>\n</span>'


# Generated at 2022-06-25 19:14:23.749048
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert 'application/atom+xml' == formatter_plugin_0.format_body('application/atom+xml', 'application/atom+xml')
    assert '10.0' == formatter_plugin_0.format_body('10.0', '10.0')


# Generated at 2022-06-25 19:14:28.834322
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_format_body = FormatterPlugin(
        env=Environment(),
        format_options=()
    )
    mime = "application/atom+xml"
    content = "<a href=\"http://test/test\"/>"
    assert formatter_plugin_format_body.format_body(mime, content) == content


# Generated at 2022-06-25 19:14:31.672162
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 19:14:36.045368
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin(**{'format_options': {'iterable_such_as_list_tuple': 'iterable_such_as_list_tuple', 'indent': 'indent'}})
    formatter_plugin_0.format_body('content', 'mime')


# Generated at 2022-06-25 19:14:37.934030
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers(headers = '')


# Generated at 2022-06-25 19:14:39.596654
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin(**{"format_options": {}})
    assert formatter_plugin_0.format_body("text", "text/plain") == "text"

# Generated at 2022-06-25 19:14:44.564716
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():

    # Given a formatter_plugin
    formatter_plugin_0 = FormatterPlugin()

    header_0 = "HTTP/1.1 200 OK\r\n" + "Date: Sun, 18 Oct 2020 16:29:49 GMT\r\n" + "Content-Type: application/json\r\n" + "Content-Length: 56\r\n" + "Connection: close\r\n" + "Server: Ragel/6.10 OpenResty/1.13.6.2\r\n" + "\r\n" + "{\"employeeId\": 10, \"firstName\": \"John\", \"lastName\": \"Doe\"}"

    # When the method format_headers is invoked
    header_1 = str(formatter_plugin_0.format_headers(header_0))

# Generated at 2022-06-25 19:14:51.174162
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = """HTTP/1.1 200 OK
Content-Length: 513
Connection: Keep-Alive
Content-Type: text/html; charset=utf-8
Date: Tue, 20 Oct 2020 22:13:54 GMT
Server: Apache
X-Powered-By: PHP/7.2.2

"""

    assert formatter_plugin_0.format_headers(headers) == "HTTP/1.1 200 OK"



# Generated at 2022-06-25 19:15:15.104336
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    username = str()
    password = str()
    assert isinstance(auth_plugin_0.get_auth(username, password),
                      requests.auth.AuthBase) is True  # fails


# Generated at 2022-06-25 19:15:20.552397
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    from httpie.plugins.converters.msgpack import ConverterPlugin
    content = b'content'
    assert ConverterPlugin(content).convert() == content
    assert ConverterPlugin(content.decode()).convert() == content


# Generated at 2022-06-25 19:15:22.453789
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    assert base_plugin


# Generated at 2022-06-25 19:15:26.344628
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin('text/html')
    assert converter_plugin_0.mime == 'text/html'



# Generated at 2022-06-25 19:15:28.977555
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:15:30.399581
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    adapter = transport_plugin_0.get_adapter()



# Generated at 2022-06-25 19:15:33.242063
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    with pytest.raises(NotImplementedError):
        transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:15:36.605120
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    c = ConverterPlugin(mime=bytes('application/atom+xml', 'ascii'))
    print(c.convert(bytes('It is a test', 'utf-8')))

test_ConverterPlugin_convert()

test_case_0()

# Generated at 2022-06-25 19:15:38.869294
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    formatter_plugin.format_body("asd", "asd")


# Generated at 2022-06-25 19:15:47.787890
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()

    # Test case 1
    arg0 = '{}'
    arg1 = 'application/json'
    expected_result = '{}'
    result = formatter_plugin_0.format_body(arg0, arg1)

    assert result == expected_result

    # Test case 2
    arg0 = '{"foo":["bar","baz"]}'
    arg1 = 'application/json'
    expected_result = '{\n    "foo": [\n        "bar",\n        "baz"\n    ]\n}'
    result = formatter_plugin_0.format_body(arg0, arg1)

    assert result == expected_result

    # Test case 3
    arg0 = '{"foo":["bar","baz"]}'

# Generated at 2022-06-25 19:16:42.738391
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    dummy = AuthPlugin()
    assert dummy


# Generated at 2022-06-25 19:16:46.770692
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    # Test with no parameters
    try:
        formatter_plugin_0.format_headers()
    except NotImplementedError:
        pass
    # Test with wrong number of parameters
    try:
        formatter_plugin_0.format_headers('headers', 'headers')
    except TypeError:
        pass
    # Test with a correct case
    try:
        formatter_plugin_0.format_headers('headers')
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:16:48.211335
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:16:50.718775
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    test_auth_plugin = AuthPlugin()


# Generated at 2022-06-25 19:16:52.171782
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    test0 = ConverterPlugin('mime')
    assert test0.mime == 'mime'


# Generated at 2022-06-25 19:16:55.571553
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    # Test to ensure that the get_auth method of the class object
    # AuthPlugin can run successfully
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:16:58.711828
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    # Tests a transport plugin
    class TransportPlugin(BasePlugin):
        def get_adapter(self):
            return "adapter"
    transport_plugin = TransportPlugin()
    assert transport_plugin.get_adapter() == "adapter"


# Generated at 2022-06-25 19:17:02.778353
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    # Test for base case: should have none value for auth_type
    auth_plugin_base = AuthPlugin()
    assert auth_plugin_base.auth_type is None

    # Test for the field auth_require in the base class, should be True
    assert auth_plugin_base.auth_require is True

    # Test for the field auth_parse in the base class, should be True
    assert auth_plugin_base.auth_parse is True



# Generated at 2022-06-25 19:17:06.772508
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()
    assert transport_plugin_0.prefix is None


# Generated at 2022-06-25 19:17:07.873404
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    test_case_0()


# Generated at 2022-06-25 19:19:06.484359
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'Hello, World'
    actual = formatter_plugin_0.format_headers(headers)
    assert headers == actual


# Generated at 2022-06-25 19:19:08.375321
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers('text/HTML') == 'text/HTML'



# Generated at 2022-06-25 19:19:10.040229
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth = AuthPlugin()
    assert auth.auth_require is True
    assert auth.auth_parse is True


# Generated at 2022-06-25 19:19:11.929349
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPluginImpl(TransportPlugin):
        auth_type = 'Test'

    transport_plugin_impl = TransportPluginImpl()
    assert transport_plugin_impl.auth_type == 'Test'


# Generated at 2022-06-25 19:19:14.352647
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    x = b'12345'
    mime = 'application/atom+xml'
    expected = '12345'
    actual = formatter_plugin_0.format_body(x.decode('utf8'), mime)
    assert expected == actual



# Generated at 2022-06-25 19:19:18.783488
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin(env=Environment(), format_options={})
    assert formatter_plugin_0.enabled is True
    assert formatter_plugin_0.kwargs == {'env': Environment(),
                                         'format_options': {}}
    assert formatter_plugin_0.format_options == {}


# Generated at 2022-06-25 19:19:25.848819
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # data of test_case_0
    formatter_plugin_0 = FormatterPlugin()
    content_0 = ''
    mime_0 = 'application/json'
    expected_0 = ''
    formatter_plugin_0.format_body(content_0, mime_0)
    assert expected_0 == formatter_plugin_0.format_body(content_0, mime_0)

    # data of test_case_1
    formatter_plugin_1 = FormatterPlugin()
    content_1 = ''
    mime_1 = 'application/xml'
    expected_1 = ''
    formatter_plugin_1.format_body(content_1, mime_1)
    assert expected_1 == formatter_plugin_1.format_body(content_1, mime_1)

    # data

# Generated at 2022-06-25 19:19:26.851293
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin = AuthPlugin()
    assert auth_plugin.auth_require is not None



# Generated at 2022-06-25 19:19:32.571606
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    headers_str_1 = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nCache-Control: max-age=3600\r\n\r\n"
    resp_headers_1 = formatter_plugin_1.format_headers(headers_str_1)
    assert resp_headers_1 == "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nCache-Control: max-age=3600\r\n\r\n"


# Generated at 2022-06-25 19:19:40.849539
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.name = "FormatterPlugin"
    formatter_plugin_0.description = "FormatterPlugin"
    formatter_plugin_0.auth_type = "FormatterPlugin"
    formatter_plugin_0.auth_require = True
    formatter_plugin_0.auth_parse = True
    formatter_plugin_0.netrc_parse = True
    formatter_plugin_0.prompt_password = True

    assert formatter_plugin_0.name == "FormatterPlugin", "Expected value: 'FormatterPlugin', actual value: " + formatter_plugin_0.name