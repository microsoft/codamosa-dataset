

# Generated at 2022-06-25 19:10:17.311269
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()



# Generated at 2022-06-25 19:10:20.012090
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers('{"some": "json"}') == '{"some": "json"}'


# Generated at 2022-06-25 19:10:20.884760
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    pass



# Generated at 2022-06-25 19:10:25.993229
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = b"foo\r\nbar\r\n"
    text = formatter_plugin_0.format_headers(headers)
    if not text.startswith("foo\r\nbar\r\n"):
        raise Exception("Failed")
    print("test_FormatterPlugin_format_headers() passed")


# Generated at 2022-06-25 19:10:28.124690
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers_0 = ''
    assert formatter_plugin_0.format_headers(headers_0) == ''


# Generated at 2022-06-25 19:10:32.841049
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'header'
    output = formatter_plugin_0.format_headers(headers)
    assert output == headers

# Generated at 2022-06-25 19:10:35.109957
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    assert(formatter_plugin.format_headers == FormatterPlugin.format_headers)


# Generated at 2022-06-25 19:10:39.357718
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin({'format_options': {}})
    try:
        formatter_plugin_0.format_body('', 'application/octet-stream')
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 19:10:48.767496
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "HTTP/1.1 200 OK\r\nDate: Sat, 13 Oct 2018 02:33:03 GMT\r\nServer: Apache\r\nPowered-By: PHP/5.4.45\r\nX-Powered-By: PleskLin\r\nVary: Accept-Encoding\r\nContent-Encoding: gzip\r\nContent-Length: 173\r\nContent-Type: application/json; charset=utf-8\r\n"
    assert formatter_plugin_0.format_headers(headers) == headers


# Generated at 2022-06-25 19:10:58.517055
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Create a mocked class
    class MockFormatterPlugin(formatter_plugins.FormatterPlugin):
        @classmethod
        def supports(cls, mime):
            return mime.lower() != 'application/xml'

        def format_headers(self, headers):
            return headers

        def format_body(self, body, mime):
            return "{0}".format(mime.lower())


    # Test case 0
    formatter_plugin_0 = MockFormatterPlugin()

    formatter_plugin_0.format_body('This is a random text', 'application/json')
    # expected 'application/json'
    formatter_plugin_0.format_body('This is a random text', 'application/XML')
    # expected 'This is a random text'

# Generated at 2022-06-25 19:11:02.793720
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    # Ensure that no exception is thrown
    formatter_plugin_0.format_headers(headers="")


# Generated at 2022-06-25 19:11:07.873221
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Given
    formatter_plugin = FormatterPlugin()
    headers = "HTTP/1.1 200 OK\nContent-Type: text/plain\n\n"

    # When
    retval = formatter_plugin.format_headers(headers)

    # Then
    assert retval == "HTTP/1.1 200 OK\nContent-Type: text/plain\n\n"


# Generated at 2022-06-25 19:11:19.792501
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin({})

# Generated at 2022-06-25 19:11:29.022025
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    print("## Unit test for method format_body of class FormatterPlugin")
    # Create instance of FormatterPlugin
    formatter_plugin_0 = FormatterPlugin(**{
        'format_options': {
            'ascii': True,
            'curses-aware': True,
            'default_scheme': 'https',
            'follow': True,
            'pretty': 'all',
            'style': 'solarized'},
        'stdin': Mock(),
        'stdout_isatty': None})
    # unit test of method format_body
    formatter_plugin_0.format_body("content", "mime")


# Generated at 2022-06-25 19:11:38.961834
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.kwargs = {'format_options': DispatchingDict()}
    formatter_plugin_0.kwargs['format_options'] = DispatchingDict()
    # This is need to run the method
    formatter_plugin_0.format_options = DispatchingDict()
    formatter_plugin_0.format_options['sudf'] = False
    formatter_plugin_0.kwargs['format_options']['sudf'] = False
    obj = formatter_plugin_0.format_body("", "example")
    # Assert that the method behaves as expected
    assert isinstance(obj, str)


# Generated at 2022-06-25 19:11:44.263297
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    test_data_0 = './data/data.txt'
    with open(test_data_0, 'rb') as f:
        headers = f.read()
    assert isinstance(headers, bytes), "data read from file is not in bytes"
    result = formatter_plugin_0.format_headers(headers)
    print(result)


# Generated at 2022-06-25 19:11:46.648443
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    x = formatter_plugin_0.format_headers("")
    assert x == ""


# Generated at 2022-06-25 19:11:49.806908
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers("headers")
    # assert formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:11:56.427331
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    formatter_plugin_1 = FormatterPlugin()
    test_case_1 = formatter_plugin_1.format_body(content="unit_test", mime="application/json")
    assert(test_case_1 == "unit_test")

    # Test simple logic
    formatter_plugin_2 = FormatterPlugin()
    test_case_2 = formatter_plugin_2.format_body(content="{\"key\": \"value\"}", mime="application/json")
    assert(test_case_2 == "{\"key\": \"value\"}")


# Generated at 2022-06-25 19:11:57.883421
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = ""
    formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:12:04.653361
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body(content="This is a test.", mime="text/plain")


# Generated at 2022-06-25 19:12:05.701658
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    test_case_0()

# Generated at 2022-06-25 19:12:11.324083
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    input = """\
HTTP/1.1 200 OK
Date: Fri, 07 Sep 2018 12:03:37 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 16
Connection: keep-alive
Cache-Control: keep-alive

Hello, world!
"""
    expected = """\
HTTP/1.1 200 OK
Date: Fri, 07 Sep 2018 12:03:37 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 16
Connection: keep-alive
Cache-Control: keep-alive

Hello, world!
"""
    actual = formatter_plugin_0.format_headers(input)
    assert actual == expected



# Generated at 2022-06-25 19:12:14.310331
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    content = "Hello"
    mime = 'application/json'
    res = formatter_plugin.format_body(content, mime)
    assert res == content


# Generated at 2022-06-25 19:12:19.154917
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    FormatterPlugin_instance_0 = FormatterPlugin()
    mime = 'application/atom+xml'
    data = b''
    data_bytes_0 = data.encode('utf-8')
    content = data_bytes_0.decode('utf-8')
    FormatterPlugin_instance_0.format_body(content, mime)
    FormatterPlugin_instance_0.format_body(content, mime)


# Generated at 2022-06-25 19:12:24.045454
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    formatter_with_options = FormatterPlugin(
        format_options=dict(
            colors=True,
            indent=2,
            prefix='>',
            pretty=True
        )
    )
    # test format_body with no arguments
    formatter_with_options.format_body()
    # test format_body with 1 arguments
    formatter_with_options.format_body(mime='application/json')
    # test format_body with 2 arguments
    formatter_with_options.format_body(content='{"key": "value"}', mime='application/json')


# Generated at 2022-06-25 19:12:30.011253
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'mime v0.0'
    content = 'content v0.0'
    result = formatter_plugin_0.format_body(content=content, mime=mime)
    assert result == 'content v0.0'


# Generated at 2022-06-25 19:12:33.055492
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin(**{'format_options': {}})
    formatter_plugin_0.format_body('[\"1\", \"2\", \"3\"]', 'application/json')

# Generated at 2022-06-25 19:12:35.139122
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers_str = ''
    result = formatter_plugin_0.format_headers(headers_str)
    assert result is not None


# Generated at 2022-06-25 19:12:44.729344
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin(format_options=0, max_width=160)
    headers = '''HTTP/1.1 200 OK
Connection: close
Content-Length: 9
Content-Type: application/json
Date: Mon, 06 Jan 2020 16:55:55 GMT
Server: waitress'''
    expected = 'HTTP/1.1 200 OK\r\nConnection: close\r\nContent-Length: 9\r\nContent-Type: application/json\r\nDate: Mon, 06 Jan 2020 16:55:55 GMT\r\nServer: waitress\r\n'
    
    assert formatter_plugin.format_headers(headers=headers) == expected


# Generated at 2022-06-25 19:12:51.816883
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin = ConverterPlugin(None)
    with pytest.raises(NotImplementedError):
        converter_plugin.convert()


# Generated at 2022-06-25 19:12:53.483813
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    print()
    print('Testing test_TransportPlugin_get_adapter...')
    assert True
    print('Test completed')


# Generated at 2022-06-25 19:12:54.680479
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    adapter = test_TransportPlugin.get_adapter()


# Generated at 2022-06-25 19:12:56.744652
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    from httpie.plugins import AuthPlugin

    p = AuthPlugin()
    username = None
    password = None
    p.get_auth(username, password)



# Generated at 2022-06-25 19:12:58.272154
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()
    transport_plugin_0.name = 'name'
    transport_plugin_0.description = 'description'
    transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:12:59.023794
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    tp = TransportPlugin()


# Generated at 2022-06-25 19:13:00.032378
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:13:03.704373
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(mime=None)
    assert_raises(NotImplementedError, converter_plugin_0.convert, content_bytes=None)


# Generated at 2022-06-25 19:13:10.507416
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    try:
        # Call method get_adapter of class TransportPlugin
        # raise NotImplementedError()
        # Call method get_adapter of class TransportPlugin
        # raise NotImplementedError()
        # Call method get_adapter of class TransportPlugin
        # raise NotImplementedError()
        raise NotImplementedError()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:13:14.777317
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()


# Generated at 2022-06-25 19:13:24.460965
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()

    test_name = "base-plugin"
    exec('base_plugin.name = "{}"'.format(test_name))
    assert base_plugin.name == test_name

    test_description = "This is a base plugin"
    exec('base_plugin.description = "{}"'.format(test_description))
    assert base_plugin.description == test_description

    test_package_name = "package_name"
    exec('base_plugin.package_name = "{}"'.format(test_package_name))
    assert base_plugin.package_name == test_package_name


# Generated at 2022-06-25 19:13:25.953192
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin('message/rfc822')


# Generated at 2022-06-25 19:13:27.980553
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin('')
    converter_plugin_1 = ConverterPlugin('mime')



# Generated at 2022-06-25 19:13:30.479069
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    test_TransportPlugin_1 = TransportPlugin()


# Generated at 2022-06-25 19:13:32.262090
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()
    # No assert
    pass



# Generated at 2022-06-25 19:13:35.804220
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    # Get instance of class
    converter_plugin = ConverterPlugin(mime="text/plain")
    # Call method
    converter_plugin.convert(content_bytes="None")


# Generated at 2022-06-25 19:13:39.661199
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    assert FormatterPlugin.group_name == 'format'



# Generated at 2022-06-25 19:13:40.614995
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    AuthPlugin()


# Generated at 2022-06-25 19:13:44.317114
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    assert TransportPlugin.prefix is None
    # Unit test for get_adapter()
    assert TransportPlugin.get_adapter() is NotImplementedError


# Generated at 2022-06-25 19:13:54.961855
# Unit test for constructor of class FormatterPlugin

# Generated at 2022-06-25 19:14:09.758612
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    """
    Test constructor of class FormatterPlugin
    :return:
    """
    test_FormatterPlugin = FormatterPlugin(format_options={"group_name": "format"})
    assert test_FormatterPlugin.kwargs["format_options"] == {"group_name": "format"}
    assert test_FormatterPlugin.group_name == "format"
    assert test_FormatterPlugin.enabled is True


# Generated at 2022-06-25 19:14:11.830886
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers(' ') == ' '



# Generated at 2022-06-25 19:14:17.133102
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime_0 = 'mime_0'
    content_0 = 'content_0'

    assert formatter_plugin_0.format_body(content_0, mime_0) == content_0, 'Expected ' + content_0 + ' but got ' + formatter_plugin_0.format_body(content_0, mime_0)

test_FormatterPlugin_format_body()

# Generated at 2022-06-25 19:14:18.142797
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    print(AuthPlugin)


# Generated at 2022-06-25 19:14:20.234561
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    assert base_plugin.name is None
    assert base_plugin.description is None
    assert base_plugin.package_name is None


# Generated at 2022-06-25 19:14:24.295620
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    formatter_plugin_0 = AuthPlugin()
    username = "test_username"
    password = "test_password"
    try:
        formatter_plugin_0.get_auth(username, password)
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-25 19:14:25.612200
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:14:27.301077
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert 'application/atom+xml' == 'application/atom+xml'


# Generated at 2022-06-25 19:14:29.353834
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    _auth_plugin_0 = AuthPlugin()
    _auth_plugin_0.get_auth()


# Generated at 2022-06-25 19:14:31.589444
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    formatter_plugin_0 = FormatterPlugin()
    # TODO


# Generated at 2022-06-25 19:14:54.422483
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    username = 'username'
    password = 'password'
    assert auth_plugin_0.get_auth(username=username, password=password) is None



# Generated at 2022-06-25 19:14:57.131443
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin("application/vnd.api+json")
    content_bytes = "vnd.api+json"
    try:
        assert converter_plugin_0.convert(content_bytes) is None
    except NotImplementedError:
        raise



# Generated at 2022-06-25 19:15:06.813708
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    from httpie.plugins import AuthPlugin

    # Empty auth.
    auth_plugin = AuthPlugin()
    auth_plugin.get_auth()

    # No username.
    auth_plugin = AuthPlugin()
    auth_plugin.raw_auth = ':'
    auth_plugin.get_auth()
    # No password.
    auth_plugin = AuthPlugin()
    auth_plugin.raw_auth = 'username:'
    auth_plugin.get_auth()

    # Credentials present.
    auth_plugin = AuthPlugin()
    auth_plugin.raw_auth = 'username:password'
    auth_plugin.get_auth()


# Generated at 2022-06-25 19:15:08.394343
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()
    assert transport_plugin_0.prefix is None


# Generated at 2022-06-25 19:15:11.771891
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    assert test_case_0() == None

# Generated at 2022-06-25 19:15:13.336798
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_1 = FormatterPlugin(group_name='format')


# Generated at 2022-06-25 19:15:19.567016
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    env_0 = (Environment({'print_body_only': '', 'stream': '', 'headers': '', 'verify': '', 'output_file': '', 'timeout': '', 'history_file': '', 'auth_type': '', 'config_dir': '', 'style': '', 'config_file': '', 'debug': '', 'colors': '', 'implicit_content_type': '', 'output': '', 'session': '', 'default_options': '', 'download_dir': '', 'check_status': '', 'download': '', 'pretty': '', 'download_resume': ''}),)
    assert formatter_plugin_0.format_headers(headers='Content-Type: application/json') == 'Content-Type: application/json'



# Generated at 2022-06-25 19:15:21.982524
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()

    assert(formatter_plugin.format_body("hello world", "application/json") == "hello world")


# Generated at 2022-06-25 19:15:24.930176
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:15:28.896511
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:16:16.661954
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    plugins = [AuthPlugin(), TransportPlugin(), ConverterPlugin()]

    for plugin in plugins:
        assert plugin.name == None
        assert plugin.description == None
        assert plugin.package_name == None


# Generated at 2022-06-25 19:16:19.142100
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin = FormatterPlugin()
    assert formatter_plugin is not None
    assert formatter_plugin.enabled is True
    assert isinstance(formatter_plugin, FormatterPlugin)


# Generated at 2022-06-25 19:16:20.779084
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.group_name == 'format'


# Generated at 2022-06-25 19:16:23.260409
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_object = BasePlugin()
    assert base_plugin_object.name is None
    assert base_plugin_object.description is None
    assert base_plugin_object.package_name is None


# Generated at 2022-06-25 19:16:25.055768
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    # Unit test for method get_adapter of class TransportPlugin
    transport_plugin = TransportPlugin()
    assert transport_plugin
    assert transport_plugin.get_adapter() is None

# Generated at 2022-06-25 19:16:28.013598
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    """
    Test the response body formatter plugin.
    """
    import json

    formatter_plugin_0 = FormatterPlugin()

    json_body = {'id': 123, 'name': 'Foo Bar'}
    json_data = json.dumps(json_body)

    assert formatter_plugin_0.format_body(json_data, 'application/json') == json_data


# Generated at 2022-06-25 19:16:30.238374
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(mime="")
    # Pass
    content_bytes = bytes()
    assert converter_plugin_0.convert(content_bytes) == None


# Generated at 2022-06-25 19:16:31.388387
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    formatter_plugin_1 = FormatterPlugin()
    formatter_plugin_1.get_auth()


# Generated at 2022-06-25 19:16:34.165425
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    assert TransportPlugin.__name__ == 'TransportPlugin'
    assert TransportPlugin.get_adapter.__name__ == 'get_adapter'


# Generated at 2022-06-25 19:16:42.960793
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'application/atom+xml'
    content = '''
<service xmlns="http://www.w3.org/2007/app" xmlns:atom="http://www.w3.org/2005/Atom">
  <workspace>
    <atom:title>Main Site</atom:title>
    <collection href="http://example.org/blog/main" >
      <atom:title>My Blog Entries</atom:title>
    </collection>
  </workspace>
</service>
'''
    result = formatter_plugin_0.format_body(content, mime)
    print('result', result)


# Generated at 2022-06-25 19:18:30.804496
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    # Test that an error occurs when calling a method marked as abstract
    class TestAbstractMethod(AuthPlugin):
        auth_type = 'method_marked_as_abstract'

        def get_auth(self, username=None, password=None):
            pass
    with pytest.raises(NotImplementedError):
        TestAbstractMethod().get_auth()


# Generated at 2022-06-25 19:18:34.746988
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()
    assert base_plugin_0.package_name is None
    assert base_plugin_0.name is None
    assert base_plugin_0.description is None


# Generated at 2022-06-25 19:18:40.292401
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()
    assert base_plugin_0.name is None
    assert base_plugin_0.description is None
    assert base_plugin_0.package_name is None

    base_plugin_1 = BasePlugin()
    assert base_plugin_1.name is None
    assert base_plugin_1.description is None
    assert base_plugin_1.package_name is None
    assert base_plugin_1.name is not base_plugin_0.name
    assert base_plugin_1.description is not base_plugin_0.description
    assert base_plugin_1.package_name is not base_plugin_0.package_name


# Generated at 2022-06-25 19:18:42.410331
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "HTTP/1.1 200 OK\n" \
              "Content-Type: application/json\n" \
              "Content-Length: 116\n" \
              "\n"
    assert formatter_plugin_0.format_headers(headers) == headers



# Generated at 2022-06-25 19:18:50.461979
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    auth_plugin_0.auth_require = True
    auth_plugin_0.auth_parse = True
    auth_plugin_0.auth_type = 'auth_type'
    auth_plugin_0.description = 'description'
    auth_plugin_0.name = 'name'
    auth_plugin_0.netrc_parse = False
    auth_plugin_0.package_name = 'package_name'
    auth_plugin_0.prompt_password = True
    auth_plugin_0.raw_auth = 'raw_auth'

    output = auth_plugin_0.get_auth(username = 'username', password = 'password')
    output = auth_plugin_0.get_auth(username = 'username', password = 'password')



# Generated at 2022-06-25 19:18:53.472051
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    httpie_unixsocket = TransportPlugin()
    try:
        httpie_unixsocket.get_adapter()
        assert False
    except NotImplementedError as e:
        assert True


# Generated at 2022-06-25 19:18:56.275584
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    test_auth_plugin_0 = AuthPlugin()
    username = 'username'
    password = 'password'
    test_auth_plugin_0.get_auth(username, password)


# Generated at 2022-06-25 19:18:58.694112
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin("mime")
    return (converter_plugin_0.mime)

# Generated at 2022-06-25 19:19:02.783495
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    def get_auth(self, username=None, password=None):
        return 0
    plugin = AuthPlugin()
    plugin.get_auth = get_auth.__get__(plugin, AuthPlugin)
    # Unit test for method get_auth
    # Unit test for parameter username
    plugin.get_auth(username = "test")
    # Unit test for parameter password
    plugin.get_auth(password = "test")


# Generated at 2022-06-25 19:19:04.033257
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin = ConverterPlugin(object)
    converter_plugin.convert(object)
