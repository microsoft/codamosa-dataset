

# Generated at 2022-06-25 19:10:17.361768
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    test_case_0()

# Generated at 2022-06-25 19:10:25.952647
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Arrange
    formatter_plugin = FormatterPlugin()
    headers = "[('Date', 'Tue, 07 Jan 2020 11:21:33 GMT'), ('Server', 'WSGIServer/0.2 CPython/3.7.4'), ('X-Frame-Options', 'SAMEORIGIN')]"

    # Act
    formatted_headers = formatter_plugin.format_headers(headers)

    # Assert
    assert(formatted_headers == '[(\'Date\', \'Tue, 07 Jan 2020 11:21:33 GMT\'), (\'Server\', \'WSGIServer/0.2 CPython/3.7.4\'), (\'X-Frame-Options\', \'SAMEORIGIN\')]')


# Generated at 2022-06-25 19:10:27.766405
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('c0', 'application/atom+xml')



# Generated at 2022-06-25 19:10:29.790067
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()

# Generated at 2022-06-25 19:10:35.687526
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "Content-Type: text/html; charset=utf-8"
    expected = "Content-Type: text/html; charset=utf-8"
    result = formatter_plugin_0.format_headers(headers)
    assert result == expected



# Generated at 2022-06-25 19:10:37.073275
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    FormatterPlugin.format_headers()



# Generated at 2022-06-25 19:10:39.753627
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # default
    formatter_plugin_0 = FormatterPlugin()
    text = b'data'
    content = formatter_plugin_0.format_body(text)
    assert content == 'data'


# Generated at 2022-06-25 19:10:43.039509
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    test_obj_f = FormatterPlugin()
    # Type str parameter: some content with random characters
    test_obj_f.format_body(content="sample_content_string")


# Generated at 2022-06-25 19:10:49.413509
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    
    print("__________________________")
    print("Test for format_body method")
    print("__________________________")

    print("Test with FormatterPlugin")
    formatter_plugin_0 = FormatterPlugin()
    expected_result = "body"
    if (expected_result == formatter_plugin_0.format_body("body","mime")):
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-25 19:10:58.951819
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import io
    import unittest
    from contextlib import redirect_stdout
    from httpie.output.formatters.headers import HeadersFormatter

    class Mock(FormatterPlugin):

        def __init__(self,**kwargs):
            self.kwargs = kwargs
            self.format_options=kwargs['format_options']

        def format_headers(self, headers: str) -> str:
            return headers

    class test_0(unittest.TestCase):

        def test_0(self):
            # TODO
            # self.assertEqual(expected, test_case_0())
            pass  # implemented in formatter_plugin_0


# Generated at 2022-06-25 19:11:04.085528
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = b'content-type: text/plain\r\n\r\n'
    formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:11:07.512869
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = ''
    mime = ''

    # check if the method returns the formatted body.
    result = formatter_plugin_0.format_body(content, mime)
    assert result == content


# Generated at 2022-06-25 19:11:12.095487
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers_0 = formatter_plugin_0.format_headers('headers')
    print(headers_0)


# Generated at 2022-06-25 19:11:20.620694
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "Content-Type: application/json; charset=utf-8\r\n" \
              "Content-Length: 77\r\n" \
              "Connection: close\r\n" \
              "Access-Control-Allow-Origin: *\r\n" \
              "Date: Tue, 28 Apr 2020 05:46:03 GMT\r\n" \
              "Server: waitress\r\n" \
              "\r\n" \
              "{\"result\": [], \"status\": \"success\", \"total\": 0}"
    assert formatter_plugin_0.format_headers(headers) == headers


# Generated at 2022-06-25 19:11:27.457419
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_1 = FormatterPlugin()
    mime = 'application/json'
    content = '{"stuff":1}'

    format_body = formatter_plugin_0.format_body(content, mime)
    assert format_body == ('{"stuff":1}')

    format_body = formatter_plugin_1.format_body(content, mime)
    assert format_body == ('{"stuff":1}')

# Generated at 2022-06-25 19:11:29.158627
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert formatter_plugin_0.format_headers("headers") is not None


# Generated at 2022-06-25 19:11:40.139631
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'application/atom+xml'

# Generated at 2022-06-25 19:11:43.596307
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    expected = "hello"
    mime = ""
    content = "hello"

    actual = formatter_plugin.format_body(content, mime)
    assert expected == actual



# Generated at 2022-06-25 19:11:46.416459
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers("Accept-Language: en-US") == "Accept-Language: en-US"


# Generated at 2022-06-25 19:11:48.667816
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    if formatter_plugin_1.format_body:
        pass
    else:
        assert False

# Generated at 2022-06-25 19:11:53.633069
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers(headers='headers') == 'headers'



# Generated at 2022-06-25 19:11:55.108483
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'headers'
    result = formatter_plugin_0.format_headers(headers)
    assert result == 'headers'


# Generated at 2022-06-25 19:11:56.833530
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers(headers="")


# Generated at 2022-06-25 19:11:58.999938
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "Headers"
    assert(formatter_plugin_0.format_headers(headers) == "Headers")


# Generated at 2022-06-25 19:12:02.139819
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers(headers=str()) == str(''), 'Expected different value from assertion'


# Generated at 2022-06-25 19:12:13.386489
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    format_body = FormatterPlugin.format_body

# Generated at 2022-06-25 19:12:19.212813
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # This test should be absolutely OK.
    formatter_plugin_0 = FormatterPlugin()
    test_case_0_content = "test_case_0_content"
    test_case_0_mime = "text/html"
    # This line should be OK.
    formatted_body = formatter_plugin_0.format_body(test_case_0_content, test_case_0_mime)
    assert(formatted_body == test_case_0_content)



# Generated at 2022-06-25 19:12:24.966786
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Create an instance of class FormatterPlugin
    formatter_plugin_0 = FormatterPlugin()

    # Create a string for the test
    str0 = ''

    result = formatter_plugin_0.format_headers(str0)

    assert result == '', 'The result is not correct'


# Generated at 2022-06-25 19:12:27.105055
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "foo"
    headers = formatter_plugin_0.format_headers(headers)
    assert headers == "foo"


# Generated at 2022-06-25 19:12:30.893112
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = ''
    result = formatter_plugin_0.format_headers(headers)
    assert result is None


# Generated at 2022-06-25 19:12:46.302158
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    content: str = "{{2+2}}"
    mime: str = "application/json"
    test_case_0 = FormatterPlugin()
    actual_value = test_case_0.format_body(content, mime)
    assert actual_value == content
    content: str = "{{2+2}}"
    mime: str = "application/atom+xml"
    test_case_1 = FormatterPlugin()
    actual_value = test_case_1.format_body(content, mime)
    assert actual_value == content


# Generated at 2022-06-25 19:12:55.296215
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    headers_arg = headers;
    formatter_plugin_0 = FormatterPlugin();
    print (formatter_plugin_0.enabled);
    print (formatter_plugin_0.group_name);
    print (formatter_plugin_0.kwargs);
    print (type(formatter_plugin_0));
    print (dir(formatter_plugin_0));
    print (type(formatter_plugin_0.format_headers));
    print (formatter_plugin_0.format_headers(headers_arg));
    print (headers);



# Generated at 2022-06-25 19:13:01.036674
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = '''
    Content-Type: text/plain
    Date: Mon, 07 Jan 2019 08:06:14 GMT
    Last-Modified: Sat, 22 Dec 2018 04:07:24 GMT
    Server: nginx/1.14.0 (Ubuntu)
    Strict-Transport-Security: max-age=15724800; includeSubDomains; preload
    X-Content-Type-Options: nosniff
    Content-Length: 17
    Connection: keep-alive
'''
    headers = formatter_plugin_0.format_headers(headers)
    print(headers)



# Generated at 2022-06-25 19:13:13.049671
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    header_plugin = FormatterPlugin()

# Generated at 2022-06-25 19:13:22.724415
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Test instance creation of class FormatterPlugin
    formatter_plugin_0 = FormatterPlugin(**{'format_options': {}})
    # Assigning argument 'content' to a protected method
    # Getting the type of 'formatter_plugin_0' (line 533)
    formatter_plugin_0_type_store = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 533, 11), 'formatter_plugin_0')
    # Obtaining the member 'format_body' of a type (line 533)

# Generated at 2022-06-25 19:13:24.742414
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers('headers') == 'headers'


# Generated at 2022-06-25 19:13:25.952678
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    res = FormatterPlugin.format_body()
    assert res == None


# Generated at 2022-06-25 19:13:29.067317
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content="{\"message\": \"Not Found\"}"
    mime="application/json"
    ret =formatter_plugin_0.format_body(content, mime)
    print(ret)



# Generated at 2022-06-25 19:13:34.788922
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Header
    print(Fore.CYAN + "Test for method format_body of class FormatterPlugin" + Fore.WHITE)
    # Condition
    formatter_plugin_1 = FormatterPlugin()
    # Expectation
    #Assert
    assert formatter_plugin_1.format_body == None


# Generated at 2022-06-25 19:13:36.193236
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers("headers")

# Generated at 2022-06-25 19:13:57.962193
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Create a FormatterPlugin instance
    formatter_plugin_0 = FormatterPlugin()

    txt = 'abc'
    txt2 = 'xyz'
    assert formatter_plugin_0.format_body(txt2 + '{}', 'application/msgpack') == txt2 + '{}'

    # It is a known bug that we are not able to generate
    # complete test sample for parameter content
    # at the moment.
    # test_case_1() is used to generate complete test sample
    # for parameter content.
    # After the sample is generated, run this test again
    # to guarantee correctness.
    # test_case_1()

    # Also, it is a known bug that we do not support
    # different input for different parameters.
    # When the bug is fixed,
    # please uncomment the following

# Generated at 2022-06-25 19:14:00.722141
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    test_case_0()
    content = open("test/test.txt", 'r').read()
    content = formatter_plugin_0.format_body(content,"application/atom+xml")
    print(content)


# Generated at 2022-06-25 19:14:04.478720
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    content = "sup"
    mime = "application"
    assert formatter_plugin_1.format_body(content, mime) == content

# Tests if the test suite runs

# Generated at 2022-06-25 19:14:09.278072
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
#    formatter_plugin.env = None
    assert formatter_plugin.format_body('application/json', '{}') == '{}'
    assert formatter_plugin.format_body(None, '{}') == '{}'



# Generated at 2022-06-25 19:14:16.453624
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    """
    This is a unit test of method format_body of class FormatterPlugin
    """

    # Create the object of class FormatterPlugin
    formatter_plugin_0 = FormatterPlugin()

    # Create the variable of expected format body
    expected_str_0 = 'JSON'

    # Call method format_body of class FormatterPlugin
    format_body_return_0 = formatter_plugin_0.format_body("{}", "application/json; charset=UTF-8")

    # Check if the return value is equal to the expected output
    assert format_body_return_0 == expected_str_0, "Error! Format body is not string."



# Generated at 2022-06-25 19:14:18.272647
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    result = formatter_plugin_0.format_body('0')
    assert result == '0'

# Generated at 2022-06-25 19:14:19.180000
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert True



# Generated at 2022-06-25 19:14:20.988824
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = ''
    formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:14:24.213463
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "HTTP/1.1 200 OK\n\n"
    formatted_headers = formatter_plugin_0.format_headers(headers)
    print(formatted_headers)


# Generated at 2022-06-25 19:14:35.488742
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()

    class DummyBody(str):

        def __init__(self, body):
            self.body = body

        def __str__(self):
            return self.body

    class DummyResponse():

        def __init__(self, headers, body):
            self.headers = headers
            self.body = body

    # CASE where formatter_plugin return formatted headers and formatter plugin is enabled
    expected_output = 'HTTP/1.1 200 OK\nContent-Type: application/json'
    headers = 'HTTP/1.1 200 OK\nContent-Type: application/json'
    body = DummyBody('{"key": "value"}')
    response = DummyResponse(headers, body)
    formatter_plugin.enabled = True
    output = formatter_plugin.format_headers

# Generated at 2022-06-25 19:15:06.966677
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = format_headers(headers)
    assert 'headers' == formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:15:08.096387
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    FormatterPlugin.format_body(self, content, mime)


# Generated at 2022-06-25 19:15:14.517266
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = "EZbqty1JgC"
    mime = "a1wkm6UgJ6"
    returned = formatter_plugin_0.format_body(content, mime)
    assert returned == content


# Generated at 2022-06-25 19:15:21.047414
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    json = """{"key": "value"}"""
    content = '{"key": "value"}'
    mime = 'application/json'
    assert_equals(formatter_plugin.format_body(content, mime), json)


# Generated at 2022-06-25 19:15:26.990062
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter = FormatterPlugin()
    mime = 'text/plain'
    data = 'abcdefghijklmnopqrstuvwxyz'
    result = formatter.format_body(data,mime)
    assert result == data


# Generated at 2022-06-25 19:15:28.977545
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    


# Generated at 2022-06-25 19:15:31.899091
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = r'test_value'
    assert formatter_plugin_0.format_headers(headers) == r'test_value'


# Generated at 2022-06-25 19:15:34.186172
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "a,b,c"
    assert formatter_plugin_0.format_headers(headers) == headers


# Generated at 2022-06-25 19:15:44.202202
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    data_0 = '''HTTP/1.1 200 OK\r\nContent-Type: application/atom+xml; charset=utf-8\r\nContent-Length: 401\r\nETag: W/"1b2-1084f9e31d61"\r\nSet-Cookie: test=1; path=/;\r\n\r\n'''
    ret = formatter_plugin_0.format_headers(data_0)

# Generated at 2022-06-25 19:15:50.438933
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    headers = 'Date: Sat, 08 Aug 2020 01:59:52 GMT\n'\
              'Content-Type: application/octet-stream\n'\
              'Content-Length: 17\n'\
              'Server: Werkzeug/1.0.1 Python/3.8.1\n\n'\
              '{"status":200}\n'
    actual = formatter_plugin.format_headers(headers)
    expected = 'Date: Sat, 08 Aug 2020 01:59:52 GMT\n'\
               'Content-Type: application/octet-stream\n'\
               'Content-Length: 17\n'\
               'Server: Werkzeug/1.0.1 Python/3.8.1\n\n'
    assert actual == expected



# Generated at 2022-06-25 19:17:54.461326
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin = ConverterPlugin('text/html')
    assert converter_plugin.mime == 'text/html'

# Generated at 2022-06-25 19:18:03.524610
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    def get_adapter():
        return 'adapter'

    transport_plugin = TransportPlugin()
    transport_plugin.prefix = 'my-prefix'
    transport_plugin.get_adapter = get_adapter

    assert transport_plugin.prefix == 'my-prefix'
    assert transport_plugin.get_adapter() == 'adapter'

    class MyTransportPlugin(TransportPlugin):
        def get_adapter(self):
            return 'adapter'

    my_transport_plugin = MyTransportPlugin()
    my_transport_plugin.prefix = 'my-prefix'

    assert my_transport_plugin.prefix == 'my-prefix'
    assert my_transport_plugin.get_adapter() == 'adapter'


# Generated at 2022-06-25 19:18:04.215071
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin = TransportPlugin()


# Generated at 2022-06-25 19:18:07.360655
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = "application/json"
    content = '{"name": "httpie", "description": "HTTPie is a command line HTTP client."}'
    result = formatter_plugin_0.format_body(content, mime)
    assert result == '{"name": "httpie", "description": "HTTPie is a command line HTTP client."}'

# Generated at 2022-06-25 19:18:07.960929
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    assert FormatterPlugin() is not None

# Generated at 2022-06-25 19:18:09.064706
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:18:10.785107
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()

    test_param_0 = "test_headers"

    formatter_plugin_0.format_headers(test_param_0)


# Generated at 2022-06-25 19:18:12.213401
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    from httpie.plugins import AuthPlugin
    auth_plugin = AuthPlugin()
    auth_plugin.get_auth()


# Generated at 2022-06-25 19:18:22.853498
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():

    # Test when auth_parse sets to True
    auth_plugin_1 = AuthPlugin()
    assert auth_plugin_1.auth_parse == True
    assert auth_plugin_1.netrc_parse is False
    assert auth_plugin_1.prompt_password is True

    # Test when auth_parse sets to False
    auth_plugin_2 = AuthPlugin()
    auth_plugin_2.auth_parse = False
    assert auth_plugin_2.auth_parse is False

    # Testing get_auth() method
    auth_plugin_2.get_auth()
    assert auth_plugin_2.raw_auth is None
    assert auth_plugin_2.auth_require is True
    assert auth_plugin_2.netrc_parse is False
    assert auth_plugin_2.prompt_password is True



# Generated at 2022-06-25 19:18:28.596614
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    ret_format_body = formatter_plugin_0.format_body("""\
    {{
    \t"id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
    \t"name": "gopher"
    }}""", "applicaton/json")