

# Generated at 2022-06-25 19:10:22.889559
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    content_string = "This is response body"
    mime = "test"
    returned_value = formatter_plugin_1.format_body(content_string, mime)
    assert returned_value == content_string


# Generated at 2022-06-25 19:10:23.444396
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    pass

# Generated at 2022-06-25 19:10:26.472269
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    mime = 'application/json'
    content = 'Some content'
    result = formatter_plugin.format_body(content, mime)
    assert result == 'Some content'


# Generated at 2022-06-25 19:10:28.888730
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    str_0 = formatter_plugin_0.format_body('', 'n/a')
    assert str_0 == ''


# Generated at 2022-06-25 19:10:33.013312
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers = lambda *args: ''
    test_case_0()


# Generated at 2022-06-25 19:10:35.687833
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter = FormatterPlugin()
    formatted_body = formatter.format_body("body", "mime")
    assert formatted_body == "body"


# Generated at 2022-06-25 19:10:37.458791
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "headers"
    format_headers_value = formatter_plugin_0.format_headers(headers)
    print("test_FormatterPlugin_format_headers::format_headers_value = {}".format(format_headers_value))
    assert format_headers_value == "headers"


# Generated at 2022-06-25 19:10:40.651920
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin('spam', 'eggs')
    formatter_plugin_1.format_body("foo is a nice guy", 'ascii')
    formatter_plugin_1.format_body("bar is good", 'ascii')


# Generated at 2022-06-25 19:10:51.856370
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin(format_options=PLUGIN_MANAGER.format_options)
    formatter_plugin_instance = (type(formatter_plugin_0)).__init__(
        formatter_plugin_0, format_options=PLUGIN_MANAGER.format_options
        )

    content_str_0 = '{"search_1": {"search_0": "search_0"}}'
    mime_str_0 = 'application/json'

    # Call method
    try:
        content_0 = formatter_plugin_0.format_body(content_str_0, mime_str_0)
    except:
        content_0 = formatter_plugin_0.format_body(content_str_0, mime_str_0)



# Generated at 2022-06-25 19:10:54.023237
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    assert formatter_plugin.format_body('test', 'mime') == 'test'


# Generated at 2022-06-25 19:10:58.180861
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    headers = formatter_plugin.format_headers("Hello world")
    assert headers == "Hello world", "This is a valid test"



# Generated at 2022-06-25 19:11:06.201637
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.group_name = 'format'

# Generated at 2022-06-25 19:11:09.195030
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    headers = '''headers: <header-1>'''
    assert formatter_plugin_1.format_headers(headers) == '''headers: <header-1>'''


# Generated at 2022-06-25 19:11:14.800799
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    test_content = '<ns1:hello xmlns:ns1="http://www.foo.com/">world</ns1:hello>'
    test_mime = 'application/json'
    result = formatter_plugin_0.format_body(test_content, test_mime)
    assert result == test_content

# Generated at 2022-06-25 19:11:17.245751
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body('foo', 'foo') == 'foo'



# Generated at 2022-06-25 19:11:28.257747
# Unit test for method format_body of class FormatterPlugin

# Generated at 2022-06-25 19:11:30.819510
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert (formatter_plugin_0.format_body('', 'application/json') == '')


# Generated at 2022-06-25 19:11:31.693177
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    assert True


# Generated at 2022-06-25 19:11:35.219301
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    formatter_plugin_1.format_body()
            

# Generated at 2022-06-25 19:11:37.609043
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers_0 = ""
    formatter_plugin_0.format_headers(headers_0)


# Generated at 2022-06-25 19:11:46.242635
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.group_name = None
    formatter_plugin_0.format_options = None
    formatter_plugin_0.kwargs = {}
    formatter_plugin_0.enabled = True
    formatter_plugin_0.headers = None

    formatter_plugin_0.format_headers(formatter_plugin_0.headers)


# Generated at 2022-06-25 19:11:50.571574
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    mime = "text/html"
    content = '<h1>National Park Service</h1>'
    content_fmt = formatter_plugin.format_body(content, mime)
    assert content_fmt == content


# Generated at 2022-06-25 19:11:52.206311
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:11:59.400896
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin(
        format_options = {
            'format': 'json',
            'indent': None,
            'colors': None,
            'style': None,
            'range': None,
            'slices': None,
            'prettify': None,
        }
    )
    content = '{ "id": "1234", "name": "abc" }'
    mime = 'application/json'
    output = formatter_plugin_1.format_body(content, mime)
    expected_output = '  {\n    "id": "1234",\n    "name": "abc"\n  }'
    print(output)
    assert output == expected_output

# Generated at 2022-06-25 19:12:02.278096
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'headers'
    out_headers = formatter_plugin_0.format_headers(headers)
    assert headers == out_headers



# Generated at 2022-06-25 19:12:06.953723
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers_0 = test_FormatterPlugin_format_headers_0()

    formatter_plugin_0.format_headers(headers_0)



# Generated at 2022-06-25 19:12:10.895518
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers_0 = 'Accept-Language: en-US,en;q=0.5'
    headers_1 = formatter_plugin_0.format_headers(headers_0)
    assert headers_1 == headers_0


# Generated at 2022-06-25 19:12:14.227330
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers({'headers': 'https://ncbi.nlm.nih.gov/pubmed'}) == 'https://ncbi.nlm.nih.gov/pubmed'


# Generated at 2022-06-25 19:12:18.640876
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'Content-Type: application/json\nContent-Length: 16\n'
    if formatter_plugin_0.format_headers(headers) != headers:
        raise RuntimeError('formatter_plugin_0.format_headers() != headers')
    del formatter_plugin_0


# Generated at 2022-06-25 19:12:22.946313
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    assert formatter_plugin_0.format_body(content='{"test": true}', mime='application/json') == '{"test": true}'

# Generated at 2022-06-25 19:12:33.428442
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    arg_0 = ""
    result = formatter_plugin_0.format_headers(arg_0)
    if result != "":
        raise RuntimeError("Got unexpected result: " + result)


# Generated at 2022-06-25 19:12:36.889081
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    fp = FormatterPlugin()
    fp.format_body("", "")


# Generated at 2022-06-25 19:12:46.910222
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    def format_body(self, content, mime):
        pass

    def format_body_1(self, content, mime):
        # This method is not implemented
        raise NotImplementedError()

    # This method has no wrong arguments
    FormatterPlugin.format_body = format_body

    # This method has wrong arguments
    FormatterPlugin.format_body = format_body_1
    try:
        formatter_plugin_0 = FormatterPlugin()
    except NotImplementedError as e:
        return
    # If the above method does not raise exception, the following
    # statement will be reached and the case test will fail.
    assert False



# Generated at 2022-06-25 19:12:56.707015
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()

    # Method format_body of class FormatterPlugin
    # is called here with arguments:
    #    content: "AAA"
    #    mime: "application/atom+xml"
    #
    # The return value of method format_body of class FormatterPlugin
    # was coerced to the return type of
    # the function `test_FormatterPlugin_format_body`
    #
    # The return value of `test_FormatterPlugin_format_body` is:
    #    content_1: "AAA"
    #
    assert format_body("AAA", "application/atom+xml") == "AAA"


# Generated at 2022-06-25 19:13:02.467707
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('application/atom+xml', 'text')
    formatter_plugin_0.format_body('application/atom+xml', 'text')



# Generated at 2022-06-25 19:13:07.207742
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = b"Hello"
    mime = "text/plain"
    assert formatter_plugin_0.format_body(content, mime) == "Hello"


# Generated at 2022-06-25 19:13:12.506251
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from httpie.plugins.builtin import FormatterPlugin
    headers = "Content-Type: application/json\nDate: Mon, 19 Aug 2019 13:33:19 GMT\nServer: BaseHTTP/0.6 Python/3.7.4\nContent-Length: 13\n\n"
    formatter_plugin_1 = FormatterPlugin()
    formatter_plugin_1.format_headers(headers)


# Generated at 2022-06-25 19:13:19.126389
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    TestClass = FormatterPlugin
    TestInstance = TestClass()
    TestInstance.format_headers(headers=None)  # should be in the format <type 'NoneType'> but got <type 'str'>

    TestInstance.format_headers(headers="headers")  # should be in the format <type 'str'> but got <type 'NoneType'>

    TestInstance.format_headers(headers="headers")  # should be in the format <type 'str'> but got <type 'str'>


# Generated at 2022-06-25 19:13:21.640982
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    headers = formatter_plugin_1.format_headers("headers")
    expected = "headers"
    if expected == headers:
        return True
    else:
        return False
    

# Generated at 2022-06-25 19:13:27.505446
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    class mock_Formatter(FormatterPlugin):

        def format_body(self, content, mime):
            return content

    formatter_plugin_1 = mock_Formatter()
    content = "response body"
    mime = 'application/atom+xml'
    out = formatter_plugin_1.format_body(content, mime)
    assert out == "response body"



# Generated at 2022-06-25 19:13:44.845163
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    test_0 = formatter_plugin_0.format_headers('aGVsbG8gd29ybGQ=')
    #Testing
    assert test_0 == 'aGVsbG8gd29ybGQ='



# Generated at 2022-06-25 19:13:47.267959
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # setup
    formatter_plugin_1 = FormatterPlugin()

    # test
    formatter_plugin_1.format_body('text/html; charset=UTF-8', 'application/json')



# Generated at 2022-06-25 19:13:52.265087
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    try:
        formatter_plugin_0.format_headers("headers")
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:13:57.933797
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.kwargs = {}
    headers = 'GET /demo/index HTTP/1.1\r\nHost: httpbin.org:80\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nUser-Agent: HTTPie/0.9.9\r\n\r\n'
    headers = formatter_plugin_0.format_headers(headers)
    assert len(headers) == 255


# Generated at 2022-06-25 19:13:59.301505
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    fp = FormatterPlugin()
    assert fp.format_body('{a: 1, b: 2}', 'text/json') == '{a: 1, b: 2}'


# Generated at 2022-06-25 19:14:02.838422
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers(headers='') == ''


# Generated at 2022-06-25 19:14:05.076231
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    assert formatter_plugin_0.format_body(content="{}", mime="application/json") in ("{}", )


# Generated at 2022-06-25 19:14:09.717425
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    """
    Unit test for method format_headers of class FormatterPlugin
    """
    formatter_plugin_1 = FormatterPlugin()
    # test positive case
    # asserts that it holds true
    assert formatter_plugin_1.format_headers('headers_0') is not None


# Generated at 2022-06-25 19:14:12.862348
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    textio_list_0 = io.StringIO()
    headers_dict_0 = {}
    content_type_0 = formatter_plugin_0.format_headers(textio_list_0)

# Generated at 2022-06-25 19:14:15.481697
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    value_1 = formatter_plugin_1.format_headers("''")
    assert value_1 == ''
    

# Generated at 2022-06-25 19:14:47.230952
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'application/atom+xml'
    content = '<feed><entry><title>My Blog</title></entry></feed>'
    expected = '<feed><entry><title>My Blog</title></entry></feed>'
    actual = formatter_plugin_0.format_body(content, mime)
    assert actual == expected


# Generated at 2022-06-25 19:14:50.256975
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    FormatterPlugin_format_headers_0 = FormatterPlugin()
    string_0 = FormatterPlugin_format_headers_0.format_headers("")


# Generated at 2022-06-25 19:14:57.646481
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    headers_1 = "HTTP/1.1 200 OK\n" \
              + "Content-Type: x-www-form-urlencoded\n" \
              + "Content-Type: application/json\n" \
              + "Connection: close\n" \
              + "Server: nginx\n" \
              + "Date: Mon, 31 Aug 2020 15:03:59 GMT\n" \
              + "Content-Length: 14\n\n"
    headers_1_copy = headers_1
    headers_2 = formatter_plugin_1.format_headers(headers_1)
    # Test pre-condition:
    assert(headers_1_copy == headers_1)
    # Test post-condition:
    assert(headers_2 == headers_1)


# Generated at 2022-06-25 19:15:03.788108
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = 'this is a string'
    mime = 'text/plain'
    assert formatter_plugin_0.format_body(content, mime) == 'this is a string'


# Generated at 2022-06-25 19:15:07.050236
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    content = "content"
    mime = "mime"
    formatter_plugin = FormatterPlugin()
    assert formatter_plugin.format_body(content, mime) == "content"


# Generated at 2022-06-25 19:15:13.126226
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    dummy_headers = ""
    try:
        result = formatter_plugin_0.format_headers(dummy_headers)
    except AttributeError:
        result = "AttributeError"
    assert result == "AttributeError"


# Generated at 2022-06-25 19:15:15.909414
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert(formatter_plugin_0.format_body('text/html')=='text/html')


# Generated at 2022-06-25 19:15:17.754404
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:15:21.397373
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    # expected: 
    res = formatter_plugin_0.format_body('application/atom+xml', 'test string')


# Generated at 2022-06-25 19:15:25.691382
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    formatter_plugin.format_body()


# Generated at 2022-06-25 19:17:11.293799
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin('application/json')
    with pytest.raises(NotImplementedError):
        converter_plugin_0.convert(content_bytes=None)


# Generated at 2022-06-25 19:17:19.412058
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()
    assert auth_plugin_0.auth_type == None
    assert auth_plugin_0.auth_require == True
    assert auth_plugin_0.auth_parse == True
    assert auth_plugin_0.netrc_parse == False
    assert auth_plugin_0.prompt_password == True
    assert auth_plugin_0.raw_auth == None
    try:
        auth_plugin_0.get_auth()
        assert False
    except:
        pass



# Generated at 2022-06-25 19:17:20.847935
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    TransportPlugin()


# Generated at 2022-06-25 19:17:22.311499
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin = ConverterPlugin("application/json")
    assert converter_plugin



# Generated at 2022-06-25 19:17:25.595182
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    with pytest.raises(NotImplementedError):
        auth_plugin_0.get_auth()



# Generated at 2022-06-25 19:17:28.421965
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    assert formatter_plugin_1.format_body(content='',mime='') != None


# Generated at 2022-06-25 19:17:31.114428
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    OAuthPlugin = AuthPlugin()
    with pytest.raises(NotImplementedError):
        OAuthPlugin.get_auth("username", "password")


# Generated at 2022-06-25 19:17:40.683961
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    username = 'username'
    password = 'password'
    assert auth_plugin_0.get_auth(username, password) == auth_plugin_0.get_auth(username, password)
    assert auth_plugin_0.get_auth(username, password) == auth_plugin_0.get_auth(username, password)
    assert auth_plugin_0.get_auth(username, password) == auth_plugin_0.get_auth(username, password)
    assert auth_plugin_0.get_auth(username, password) == auth_plugin_0.get_auth(username, password)
    assert auth_plugin_0.get_auth(username, password) == auth_plugin_0.get_auth(username, password)


# Generated at 2022-06-25 19:17:42.489962
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()


# Generated at 2022-06-25 19:17:45.699858
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.kwargs == {}
    assert formatter_plugin_0.group_name == 'format'
    assert formatter_plugin_0.enabled == True
    assert formatter_plugin_0.format_options == {}


# Generated at 2022-06-25 19:19:48.138245
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    # Create an instance of TransportPlugin
    transport_plugin_0 = TransportPlugin()
    # Probably raises NotImplementedError
    transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:19:49.401710
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    # Placeholder
    assert True



# Generated at 2022-06-25 19:19:51.446831
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    # Constructor without parameters
    try:
        transport_plugin_0 = TransportPlugin()
    except:
        print("test 0 failed")



# Generated at 2022-06-25 19:19:53.890360
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(None)
    try:
        converter_plugin_0.convert(None)
    except NotImplementedError as raised_exception:
        pass
    else:
        raise Exception('Exception not raised')


# Generated at 2022-06-25 19:19:56.692790
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    # setup
    converter_plugin_0 = ConverterPlugin(mime='')
    content_bytes = b''
    # exercise
    result = converter_plugin_0.convert(content_bytes)
    # verify
    assert result is None


# Generated at 2022-06-25 19:19:58.029241
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():

    converter_plugin_0 = ConverterPlugin(mime = 'application/json')


# Generated at 2022-06-25 19:20:00.395749
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    headers = "headers"
    formatter_plugin_0 = FormatterPlugin()
    # type: ignore
    assert formatter_plugin_0.format_headers(headers) is not None



# Generated at 2022-06-25 19:20:01.386074
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    # instance = FormatterPlugin(**kwargs)
    pass


# Generated at 2022-06-25 19:20:02.579751
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin()


# Generated at 2022-06-25 19:20:09.387329
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import json
    formatter_plugin_0 = FormatterPlugin()
    headers = "Date: Tue, 26 Jul 2016 12:03:11 GMT\r\n"
    headers = headers.encode('UTF-8')
    headers = json.loads(headers)
    expected = ("{\r\n"
                 "  \"Date\": \"Tue, 26 Jul 2016 12:03:11 GMT\"\r\n"
                 "}")
    result = formatter_plugin_0.format_headers(headers)
    assert(result == expected)
