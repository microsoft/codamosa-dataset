

# Generated at 2022-06-25 19:10:23.137344
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = "QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFB"
    mime = "text/plain"
    formatter_plugin_0.format_body(content, mime)


if __name__ == "__main__":
    test_FormatterPlugin_format_body()

# Generated at 2022-06-25 19:10:25.868287
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = "Test String"
    mime = "text/html"
    formatter_plugin_0.format_body(content, mime)


# Generated at 2022-06-25 19:10:28.325331
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'headers_0'
    assert formatter_plugin_0.format_headers(headers) == 'headers_0'


# Generated at 2022-06-25 19:10:30.074822
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    test_case_0()


# Generated at 2022-06-25 19:10:33.955691
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    assert formatter_plugin_1.format_body('content', 'mime') == 'content'


# Generated at 2022-06-25 19:10:38.359757
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = formatter_plugin_0.format_options
    content = 'abc'
    result = formatter_plugin_0.format_body(content, mime)
    assert result == content or result == 'abc'


# Generated at 2022-06-25 19:10:41.995282
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin() 
    line = 'This is header'
    headers = 'headers'
    res1 = formatter_plugin_0.format_headers(line)
    res2 = formatter_plugin_0.format_headers(headers)
    assert res1 == 'This is header'
    assert res2 == 'headers'


# Generated at 2022-06-25 19:10:53.177577
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = "{\n\t'app_id': '5e8024cc', \n\t'app_key': '3b4a8a90fe3c190543e26e3a9cb827e8',\n\t'name': 'John Doe',\n\t'email': 'john.doe@example.com',\n\t'role': 'user'\n}"

# Generated at 2022-06-25 19:10:56.696397
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import FormatterPlugin
    formatter_plugin = FormatterPlugin()
    content = "Hello world!"
    mime = "text/plain"
    s = formatter_plugin.format_body(content, mime)


# Generated at 2022-06-25 19:11:01.622625
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers('text/html; charset=UTF-8') == 'text/html; charset=UTF-8'


# Generated at 2022-06-25 19:11:06.567009
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body('', 'application/json')


# Generated at 2022-06-25 19:11:14.044699
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from pyhttp.utils import pyhttp_str_to_bytes
    json_str = '{"title": "Test Json", "author": "pyhttp"}'
    mime = "application/json"
    formatter_plugin = FormatterPlugin()
    assert type(formatter_plugin) is FormatterPlugin
    result = formatter_plugin.format_body(json_str, mime)
    assert result == json_str
    assert type(result) is str
    result = formatter_plugin.format_body(pyhttp_str_to_bytes(json_str), mime)
    assert result == json_str
    assert type(result) is str
    html_str = '<html><p>pyhttp test</p></html>'
    mime = "text/html"
    result = formatter_plugin.format_body

# Generated at 2022-06-25 19:11:15.265873
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    formatter_plugin.format_options.width = 80

# Generated at 2022-06-25 19:11:18.692709
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    arg_0 = formatter_plugin_0.format_body("", "")
    if arg_0 != "":
        print("Test case 0 failed")


# Generated at 2022-06-25 19:11:29.518944
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    assert formatter_plugin_1.format_body('application/atom+xml', 'content') == 'content'
    formatter_plugin_2 = FormatterPlugin()
    assert formatter_plugin_1.format_body('application/json', 'content') == 'content'
    formatter_plugin_3 = FormatterPlugin()
    assert formatter_plugin_1.format_body('text/html', 'content') == 'content'
    formatter_plugin_4 = FormatterPlugin()
    assert formatter_plugin_1.format_body('text/plain', 'content') == 'content'
    formatter_plugin_5 = FormatterPlugin()
    assert formatter_plugin_1.format_body('application/xml', 'content') == 'content'
    formatter_plugin_6

# Generated at 2022-06-25 19:11:36.431920
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import FormatterPlugin
    formatter_plugin_0 = FormatterPlugin()
    headers = "example headers"
    mime = "example mime"
    content = "example content"
    try:
        result = formatter_plugin_0.format_body(headers, mime)
        assert type(result) == str
    except NotImplementedError:
        assert True


# Generated at 2022-06-25 19:11:40.019954
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import pytest

    # Unit test for method format_headers of class FormatterPlugin
    def f():
        assert formatter_plugin_0.format_headers(str(headers)) == str(headers)
    with pytest.raises(NotImplementedError):
        f()


# Generated at 2022-06-25 19:11:44.267271
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    # The param headers of type str
    headers = '200 OK\n{}\n\n'
    headers_returned = formatter_plugin_0.format_headers(headers)
    assert headers_returned == headers
# Case: (1)

# Generated at 2022-06-25 19:11:47.020779
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin(Environment(), format_options=None)
    assert formatter_plugin_1.format_headers('text/html') == 'text/html'


# Generated at 2022-06-25 19:11:49.405875
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers("headers")



# Generated at 2022-06-25 19:11:56.991622
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers("headers") == "headers"


# Generated at 2022-06-25 19:12:01.672849
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    import sys
    import os
    sys.path.append(os.path.abspath(__file__ + "/../../.."))
    import httpie
    plugin_class = httpie.plugins.FormatterPlugin
    test_object = plugin_class()
    mime = None
    content = None
    result = test_object.format_body(content, mime)
    assert result is None


# Generated at 2022-06-25 19:12:05.550475
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    content = " "
    mime = "text/html"
    response_content = FormatterPlugin.format_body(content, mime)


# Generated at 2022-06-25 19:12:10.036136
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    try:
        formatter_plugin_0.format_body("", "text/plain")
    except NotImplementedError:
        print("Test case 0 PASSED")
    else:
        print("Test case 0 FAILED")


# Generated at 2022-06-25 19:12:15.472327
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Create an instance of class FormatterPlugin
    formatter_plugin_0 = FormatterPlugin()
    # Invoke method format_headers on instance formatter_plugin_0
    result_format_headers_0 = formatter_plugin_0.format_headers("headers")

    # If `result_format_headers_0` equals target value "headers"
    if result_format_headers_0 == "headers":
        # Return True
        return True
    else:
        # Return False
        return False


# Generated at 2022-06-25 19:12:18.465043
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers('headers_string') == 'headers_string'
    print('Test for function format_headers() of class FormatterPlugin is successful.')


# Generated at 2022-06-25 19:12:23.981033
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'application/atom+xml'
    content = 'content'
    assert formatter_plugin_0.format_body(content, mime) == 'content'


# Generated at 2022-06-25 19:12:26.791830
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    content = "some text to test the formatter plugin with"
    mime = "text/plain"
    assert formatter_plugin_1.format_body(content, mime) == content


# Generated at 2022-06-25 19:12:30.611388
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    output = formatter_plugin_0.format_headers("headers")
    assert(output == "headers")


# Generated at 2022-06-25 19:12:32.974454
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    with pytest.raises(NotImplementedError):
        formatter_plugin_0.format_headers(headers='headers_0')


# Generated at 2022-06-25 19:12:47.529010
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert 'hello world' == formatter_plugin_0.format_body('hello world', 'application/json')


# Generated at 2022-06-25 19:12:51.766603
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers('headers')


# Generated at 2022-06-25 19:12:54.588651
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = ""
    try:
        returned_value = formatter_plugin_0.format_headers(headers)
    except Exception:
        raise


# Generated at 2022-06-25 19:12:56.374088
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert_equal(formatter_plugin_0.format_headers(""), "")


# Generated at 2022-06-25 19:12:59.467428
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Unit test for method format_headers of class FormatterPlugin
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.group_name = "format"

    # Call method format_headers
    headers = ''
    output = formatter_plugin_0.format_headers(headers)


# Generated at 2022-06-25 19:13:05.616078
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()

    # Test for method format_headers.
    # TODO: uncomment if FormatterPlugin.__init__ is implemented
    #env = Environment()
    #assert formatter_plugin_0.format_headers('plain-text') == 'plain-text'



# Generated at 2022-06-25 19:13:15.113154
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    from plugins import FormatterPlugin
    from textwrap import dedent

# Generated at 2022-06-25 19:13:18.804706
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    string_0 = formatter_plugin_0.format_headers('A')
    string_1 = formatter_plugin_0.format_headers('A')
    assert string_0 == string_1
    return string_0



# Generated at 2022-06-25 19:13:22.118467
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'Headers'
    expected_headers_0 = 'Formated headers'

    return assert_equals(
        formatter_plugin_0.format_headers(headers),
        expected_headers_0
    )


# Generated at 2022-06-25 19:13:26.933456
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = """\
HTTP/1.1 200 OK
Content-Length: 0
Content-Type: text/plain
Date: Sat, 16 May 2020 11:49:33 GMT
"""
    assert formatter_plugin_0.format_headers(headers) == headers



# Generated at 2022-06-25 19:13:45.034209
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'text/html'
    content = 'тестове'
    result = formatter_plugin_0.format_body(content,mime)
    assert result == 'тестове'

test_case_0()
test_FormatterPlugin_format_body()

# Generated at 2022-06-25 19:13:47.370326
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = '204 No Content'
    result = formatter_plugin_0.format_headers(headers)
    assert result == headers


# Generated at 2022-06-25 19:13:56.655525
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    format_options = {}
    formatter_plugin_1 = FormatterPlugin(format_options)
    content = '{"hello": "world"}'
    mime = 'application/json'
    result = formatter_plugin_1.format_body(content, mime)
    assert result == '{\n    "hello": "world"\n}'
    content = '<html><meta name="keywords" content="some keywords"></html>'
    mime = 'text/html'
    result = formatter_plugin_1.format_body(content, mime)
    assert result == '<html>\n    <meta name="keywords" content="some keywords"/>\n</html>'


# Generated at 2022-06-25 19:14:01.770678
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = "a"
    mime = "a"
    actual_result = formatter_plugin_0.format_body(content, mime)
    expected_result = "a"
    assert actual_result == expected_result, \
        "Test failed. Actual result is " + actual_result + " while expected result is " + expected_result


# Generated at 2022-06-25 19:14:06.366171
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    content = "json"
    mime = "application/json"
    assert formatter_plugin_1.format_body(content, mime) == "json"  # Test with arguments: content = "json", mime = "application/json"


# Generated at 2022-06-25 19:14:08.770054
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    # place your test here


# Generated at 2022-06-25 19:14:17.850510
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    # formatter_plugin_0.format_headers()
    headers = "Date: Wed, 02 Oct 2019 09:14:08 GMT\nServer: TornadoServer/1.1\nContent-Type: application/json; charset=utf-8\nAccess-Control-Allow-Origin: *\nAccess-Control-Allow-Credentials: true\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\nX-Clacks-Overhead: GNU Terry Pratchett\nCache-Control: max-age=0, no-cache, no-store\nVary: Accept-Encoding\nTransfer-Encoding: chunked\n"
    formatter_plugin_0.format_headers(headers=headers)
    # print(formatter_plugin_0.headers)

#

# Generated at 2022-06-25 19:14:21.084484
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'text/xml'
    content = '<a>b</a>'
    assert formatter_plugin_0.format_body(content, mime) == '<a>b</a>'


# Generated at 2022-06-25 19:14:23.937792
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    assert formatter_plugin.format_body("{\"test_key\": \"test_value\"}", "") == "{\"test_key\": \"test_value\"}"

# Generated at 2022-06-25 19:14:25.924546
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    formatter_plugin_1.format_body("Hello world")



# Generated at 2022-06-25 19:14:52.084809
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    formatter_plugin_0 = TransportPlugin()
    source_0 = formatter_plugin_0.get_adapter()



# Generated at 2022-06-25 19:14:54.216347
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    tp = TransportPlugin()
    adp = tp.get_adapter()


# Generated at 2022-06-25 19:14:57.656612
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    env, plugin_registry = get_plugin_manager()
    plugin_registry.load_directory("plugins")
    for transport_plugin in env.transport_plugins:
        if transport_plugin.prefix == 'http+unix://':
            transport_plugin.get_adapter('unixsocket')
            return
    assert False, "Could not find transport plugin for 'http+unix://'"




# Generated at 2022-06-25 19:15:04.721684
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_1 = FormatterPlugin()
    if formatter_plugin_1.enabled != True:
        raise Exception("Wrong color_mode")
    if formatter_plugin_1.kwargs != None:
        raise Exception("Wrong keyword arguments")
    if formatter_plugin_1.format_options != None:
        raise Exception("Wrong format_options")


# Generated at 2022-06-25 19:15:11.218496
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    def get_adapter():
        return

    transport_plugin = TransportPlugin()
    transport_plugin.get_adapter = get_adapter
    transport_plugin.prefix = "http+unix:///"

    assert transport_plugin.prefix == "http+unix:///"
    assert transport_plugin.get_adapter() is None


# Generated at 2022-06-25 19:15:18.798637
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()
    assert transport_plugin_0.prefix is None
    transport_plugin_1 = TransportPlugin()
    assert transport_plugin_1.prefix is None
    transport_plugin_2 = TransportPlugin()
    assert transport_plugin_2.prefix is None
    transport_plugin_3 = TransportPlugin()
    assert transport_plugin_3.prefix is None
    transport_plugin_4 = TransportPlugin()
    assert transport_plugin_4.prefix is None
    transport_plugin_5 = TransportPlugin()
    assert transport_plugin_5.prefix is None
    transport_plugin_6 = TransportPlugin()
    assert transport_plugin_6.prefix is None
    transport_plugin_7 = TransportPlugin()
    assert transport_plugin_7.prefix is None
    transport_plugin_8 = TransportPlugin()
    assert transport_

# Generated at 2022-06-25 19:15:21.498582
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.group_name == 'format'


# Generated at 2022-06-25 19:15:27.329300
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    #try:
        #formatter_plugin = FormatterPlugin()
        #print('TEST PASSED')
    #except:
        #print('TEST FAILED')
    test_case_0()
    #test_case_1()


# Generated at 2022-06-25 19:15:28.419890
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:15:29.360598
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    assert TransportPlugin()


# Generated at 2022-06-25 19:16:24.732186
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    # Calling get_adapter() raises NotImplementedError...
    with pytest.raises(NotImplementedError):
        transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:16:26.374568
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    from requests.compat import urlparse

    formatter_plugin_1 = FormatterPlugin()
    print(str(formatter_plugin_1.kwargs))



# Generated at 2022-06-25 19:16:31.589628
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Input parameter of type str
    headers = "This is a string"
    # Instance of FormatterPlugin created using the default constructor
    formatter_plugin_1 = FormatterPlugin()
    # Calling the format_headers method of formatter_plugin_1 instance
    try:
        returned__formatted_headers = formatter_plugin_1.format_headers(headers)
    except:
        returned__formatted_headers = "Exception caught"
    # Output parameter returned__formatted_headers
    assert returned__formatted_headers == "This is a string", "Test case 0 failed"


# Generated at 2022-06-25 19:16:41.140138
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    # Initialization of TransportPlugin subclass
    class transport_plugin_0(TransportPlugin):
        prefix = None
        def get_adapter(self):
            return
    # Creation of the mock object of requests.adapters.BaseAdapter
    mock_BaseAdapter_0 = Mock(spec=BaseAdapter)
    # Definition of the class return value of TransportPlugin.get_adapter
    # which returns requests.adapters.BaseAdapter type
    transport_plugin_0.get_adapter = Mock(return_value=mock_BaseAdapter_0)
    # Call to the tested method
    adapter_result = transport_plugin_0.get_adapter()
    # Evaluation of the class return value
    assert adapter_result == mock_BaseAdapter_0


# Generated at 2022-06-25 19:16:43.131267
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    assert base_plugin.name == None
    assert base_plugin.description == None


# Generated at 2022-06-25 19:16:44.085872
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:16:47.873468
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    username = 'username'
    password = 'password'
    auth = auth_plugin_0.get_auth(username=username, password=password)


# Generated at 2022-06-25 19:16:51.003512
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    assert_raises(NotImplementedError, transport_plugin_0.get_adapter)

# Generated at 2022-06-25 19:16:54.687251
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    from requests.adapters import HTTPAdapter
    transport_plugin_0 = TransportPlugin()
    with pytest.raises(NotImplementedError):
        actual = transport_plugin_0.get_adapter()


# Generated at 2022-06-25 19:16:57.381559
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    try:
        transport_plugin_0.get_adapter()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:18:58.914755
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    plugin = BasePlugin()
    assert plugin.name is None
    assert plugin.description is None



# Generated at 2022-06-25 19:19:03.014349
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    formatter_plugin = FormatterPlugin()
    assert 'name' in formatter_plugin.__dict__.keys()
    assert 'description' in formatter_plugin.__dict__.keys()
    assert 'package_name' in formatter_plugin.__dict__.keys()
    assert formatter_plugin.name is None
    assert formatter_plugin.description is None
    assert formatter_plugin.package_name is None


# Generated at 2022-06-25 19:19:06.114321
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'unixsocket'

        def __init__(self):
            pass

        def get_adapter(self):
            pass

    test_transport_plugin_0 = TestTransportPlugin()


# Generated at 2022-06-25 19:19:07.117927
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin("content-type")


# Generated at 2022-06-25 19:19:09.036455
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    mime='test_mime'
    content_bytes='test_content_bytes'
    obj = ConverterPlugin(mime)
    obj.convert(content_bytes)


# Generated at 2022-06-25 19:19:13.418407
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TransportPlugin_A(TransportPlugin):
        prefix = 'a'

        def get_adapter(self):
            return None

    class TransportPlugin_B(TransportPlugin):
        prefix = 'b'

        def get_adapter(self):
            return None

    plugin_a = TransportPlugin_A()
    plugin_b = TransportPlugin_B()
    assert len([plugin_a, plugin_b]) == 2
    assert plugin_a.prefix == 'a'
    assert plugin_b.prefix == 'b'



# Generated at 2022-06-25 19:19:14.177283
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()


# Generated at 2022-06-25 19:19:18.174590
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    # The value of variable __init__ should be an instance of class
    # ConverterPlugin, thus it should be able to pass the test.
    __init__ = ConverterPlugin('image/png')
    assert isinstance(__init__, ConverterPlugin)


# Generated at 2022-06-25 19:19:18.927731
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin = TransportPlugin()

# Generated at 2022-06-25 19:19:20.155259
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    FormatterPlugin()
    return 0

test_case_0()

test_FormatterPlugin()