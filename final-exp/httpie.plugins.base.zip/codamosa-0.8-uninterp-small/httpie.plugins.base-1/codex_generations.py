

# Generated at 2022-06-25 19:10:20.054748
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    headers = 'Content-type:application/json\r\nReferer:/foo/bar'
    formatter_plugin.format_headers(headers)


# Generated at 2022-06-25 19:10:23.988642
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    try:
        formatter_plugin_0.format_body(str(''), str(''))
    except NotImplementedError:
        assert True
    except Exception:
        assert False
    else:
        assert False
    assert True



# Generated at 2022-06-25 19:10:26.028874
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    formatter_plugin.format_body('Hello world!', 'text/plain')

# Generated at 2022-06-25 19:10:27.902545
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body(content='', mime='')


# Generated at 2022-06-25 19:10:32.626532
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class CustomFormatterPlugin(FormatterPlugin):
        def __init__(self):
            super().__init__()

        def format_body(self, content: str, mime: str) -> str:
            return content

    # Test that CustomFormatterPlugin.get_header returns the same value
    # as FormatterPlugin.get_header
    fp = CustomFormatterPlugin()
    assert fp.format_body("test_format_body", "mime") == "test_format_body"
    assert fp.format_body("test_format_body", "mime") != "default_formatter_method"



# Generated at 2022-06-25 19:10:35.639385
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    str_1 = formatter_plugin_0.format_body('content', 'mime')
    assert str_1 == 'content'


# Generated at 2022-06-25 19:10:37.736953
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    format_body_1 = FormatterPlugin()
    format_body_1.format_body(self, content, mime)

# Generated at 2022-06-25 19:10:41.374956
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin(**{'format_options': {'format': 'json', 'print_body': False}, 'output_options': {}})
    assert formatter_plugin.format_body('{"book": "Lord of the Rings"}', 'application/json') == '{"book": "Lord of the Rings"}'


# Generated at 2022-06-25 19:10:48.954024
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_instance = FormatterPlugin()
    try:
        formatter_plugin_instance.format_headers(headers)
    except NotImplementedError:
        print('Unit test for method format_headers of class FormatterPlugin failed')
        sys.exit(1)
    except Exception as inst:
        print('Unexpected Exception received: ' + type(inst).__name__)
        sys.exit(1)
    print('Unit test for method format_headers of class FormatterPlugin passed')


# Generated at 2022-06-25 19:10:51.714291
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter1 = FormatterPlugin()
    assert formatter1.format_headers("[headers]\nheader1: value1") == "[headers]\nheader1: value1"

# Generated at 2022-06-25 19:10:54.072988
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin = FormatterPlugin()
    assert formatter_plugin is not None

# Generated at 2022-06-25 19:10:59.036269
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    # Assert
    assert_raises(NotImplementedError, TransportPlugin(), get_adapter)


# Generated at 2022-06-25 19:11:00.036535
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
  tp = TransportPlugin()


# Generated at 2022-06-25 19:11:02.488155
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    plugin = FormatterPlugin()
    assert plugin.format_body(1, 1)

#Unit test for method format_header of class FormatterPlugin

# Generated at 2022-06-25 19:11:03.757638
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()

# Generated at 2022-06-25 19:11:04.715376
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    assert True


# Generated at 2022-06-25 19:11:06.066557
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:11:08.315168
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    test_plugin = BasePlugin()
    assert test_plugin.name == None
    assert test_plugin.description == None
    assert test_plugin.package_name == None


# Generated at 2022-06-25 19:11:10.355779
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    mime = "application/json"
    instance = ConverterPlugin(mime)
    assert instance.mime == "application/json"


# Generated at 2022-06-25 19:11:12.802814
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    assert base_plugin.name == None
    assert base_plugin.description == None

    assert base_plugin.package_name == None



# Generated at 2022-06-25 19:11:16.433928
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    formatter_plugin_2 = ConverterPlugin("application/json")
    formatter_plugin_3 = ConverterPlugin("text/html")
    assert formatter_plugin_2.mime == "application/json"
    assert formatter_plugin_3.mime == "text/html"


# Generated at 2022-06-25 19:11:27.548073
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = """HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Content-Length: 34
Server: Werkzeug/0.16.0 Python/3.6.9
Date: Thu, 15 Oct 2020 12:33:43 GMT

"""

    assert formatter_plugin_0.format_headers(headers) == """HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Content-Length: 34
Server: Werkzeug/0.16.0 Python/3.6.9
Date: Thu, 15 Oct 2020 12:33:43 GMT

"""

# Generated at 2022-06-25 19:11:31.888829
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    # Enter input arguments for method format_headers of class FormatterPlugin
    headers = None
    # Perform the method call
    output = formatter_plugin_0.format_headers(headers)
    # Assert the result
    assert isinstance(output, str)


# Generated at 2022-06-25 19:11:36.004897
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    def get_adapter():
        raise NotImplementedError()
    def test():
        get_adapter()
    test()


# Generated at 2022-06-25 19:11:37.886096
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin = ConverterPlugin(mime='application/json')
    assert converter_plugin.mime == 'application/json'

# Generated at 2022-06-25 19:11:45.493804
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    try:
        formatter_plugin_0 = AuthPlugin()
        try:
            formatter_plugin_0.auth_type = 'auth_type'
            formatter_plugin_0.auth_require = True
            formatter_plugin_0.auth_parse = True
            formatter_plugin_0.netrc_parse = False
            formatter_plugin_0.prompt_password = True
            formatter_plugin_0.raw_auth = str()
            ret = formatter_plugin_0.get_auth()
        except NotImplementedError:
            pass
    except BaseException:
        pass


# Generated at 2022-06-25 19:11:46.510019
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    baseplugin_0 = BasePlugin()

# Generated at 2022-06-25 19:11:50.852494
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin = AuthPlugin()
    # Test that:
    # - AuthPlugin is an instance of BasePlugin
    # - It raises a NotImplementedError when calling get_auth
    assert isinstance(auth_plugin,BasePlugin)
    call_get_auth(auth_plugin)


# Generated at 2022-06-25 19:11:53.424563
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    headers = formatter_plugin_1.format_headers(headers="text")
    assert isinstance(headers, str)


# Generated at 2022-06-25 19:12:00.690052
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():

    client = Mock()
    # Source: httpie/auth_plugin.py:17
    # 'Base auth plugin class.'
    # 
    #     See httpie-ntlm for an example auth plugin:
    # 
    #         <https://github.com/httpie/httpie-ntlm>
    # 
    #     See also `test_auth_plugins.py`
    # 
    # class AuthPlugin(BasePlugin):
    #     """
    #     Base auth plugin class.
    # 
    #     See httpie-ntlm for an example auth plugin:
    # 
    #         <https://github.com/httpie/httpie-ntlm>
    # 
    #     See also `test_auth_plugins.py`
    # 
    #     """
    #

# Generated at 2022-06-25 19:12:06.770774
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    formatter_plugin_0 = ConverterPlugin()
    content_bytes = 'content_bytes'
    formatter_plugin_0.convert(content_bytes)


# Generated at 2022-06-25 19:12:13.554143
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():

    converter_plugin = ConverterPlugin('application/json')
    
    try:
        converter_plugin.__init__(1)
    except TypeError:
        assert True
    
    try:
        converter_plugin.convert(b'\x80\x85\x93\xA2id\xA2/n\xA2et\xA3msg\xA6Hello!')
    except NotImplementedError:
        assert True
    
    try:
        converter_plugin.supports(1)
    except TypeError:
        assert True


# Generated at 2022-06-25 19:12:18.243256
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    assert AuthPlugin.auth_type is None
    assert AuthPlugin.auth_require is True
    assert AuthPlugin.auth_parse is True
    assert AuthPlugin.netrc_parse is False
    assert AuthPlugin.prompt_password is True
    assert AuthPlugin.raw_auth is None

    def get_auth():
        return
    assert get_auth() is None



# Generated at 2022-06-25 19:12:23.275197
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    # https://github.com/jakubroztocil/httpie/blob/master/tests/test_converters.py
    test_case_0()
    assert True



# Generated at 2022-06-25 19:12:24.633034
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin = ConverterPlugin('application/msgpack')


# Generated at 2022-06-25 19:12:27.704070
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    basePlugin_test = BasePlugin()
    assert basePlugin_test.name == None
    assert basePlugin_test.description == None
    assert basePlugin_test.package_name == None


# Generated at 2022-06-25 19:12:32.681704
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    f = FormatterPlugin()
    assert f.group_name == 'format'

    with pytest.raises(NotImplementedError):
        f.format_body(None, None)

    with pytest.raises(NotImplementedError):
        f.format_headers(None)

# Generated at 2022-06-25 19:12:33.742269
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    print(TransportPlugin().get_adapter())



# Generated at 2022-06-25 19:12:36.028835
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()
    assert base_plugin_0
    assert base_plugin_0.description is None
    assert base_plugin_0.name is None
    assert base_plugin_0.package_name is None


# Generated at 2022-06-25 19:12:36.483726
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    assert FormatterPlugin()

# Generated at 2022-06-25 19:12:43.778142
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    # Test instantiation of ConverterPlugin class
    converter_plugin_0 = ConverterPlugin("mime")


# Generated at 2022-06-25 19:12:48.386868
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import json
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers("""HTTP/1.1 200 OK
Date: Tue, 26 Mar 2019 15:35:04 GMT
Server: gunicorn/19.9.0
Content-Type: application/json
Content-Length: 4
Connection: keep-alive
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true

""")



# Generated at 2022-06-25 19:12:52.018520
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:12:57.267726
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():

    # Init FormatterPlugin object
    formatter_plugin_1 = FormatterPlugin()

    # Define arguement 'headers'
    arguement_1 = 'headers'

    # Call method format_headers of class FormatterPlugin
    # with arguements 'headers'
    testObject = formatter_plugin_1.format_headers(arguement_1)

    # Assert 'return_value' is  equal to 'headers'
    assert testObject == 'headers'



# Generated at 2022-06-25 19:13:02.548687
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    # default constructor
    ur = TransportPlugin()
    ur.get_adapter()
    ur.name = 'name'
    ur.description = 'description'
    ur.package_name = 'package_name'
    ur.prefix = 'prefix'

    # prefixed constructor
    ur = TransportPlugin(name='name',
            description='description',
            package_name='package_name',
            prefix='prefix')
    ur.get_adapter()
    ur.name = 'name'
    ur.description = 'description'
    ur.package_name = 'package_name'
    ur.prefix = 'prefix'


# Generated at 2022-06-25 19:13:08.822126
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()
    assert auth_plugin_0.auth_parse == True
    assert auth_plugin_0.auth_require == True
    assert auth_plugin_0.netrc_parse == False
    assert auth_plugin_0.prompt_password == True
    assert auth_plugin_0.raw_auth is None


# Generated at 2022-06-25 19:13:12.013978
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'application/json'
    content = '{"name":"abcd","age":10}'
    formatter_plugin_0.format_body(mime, content)


# Generated at 2022-06-25 19:13:14.042285
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin(None)
    converter_plugin_0.convert(None)



# Generated at 2022-06-25 19:13:16.448074
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()
    assert_raises(NotImplementedError, transport_plugin_0.get_adapter)


# Generated at 2022-06-25 19:13:18.134645
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    c = ConverterPlugin('text/html')
    c.convert('Hello')
    return

# Generated at 2022-06-25 19:13:31.355331
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin = TransportPlugin()

    with raises(NotImplementedError):
        transport_plugin.get_adapter()


# Generated at 2022-06-25 19:13:35.430020
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    try:
        auth_plugin_0.get_auth()

    except NotImplementedError as e:
        print("Expected error: %s" % e)


# Generated at 2022-06-25 19:13:40.743903
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    plugin_0 = ConverterPlugin(mime='mime')
    content_bytes = 'content_bytes'
    plugin_0.convert(content_bytes)


# Generated at 2022-06-25 19:13:43.179022
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:13:46.309276
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = str()
    content = str()
    # Call method
    result = formatter_plugin_0.format_body(content, mime)
    assert(result is None)


# Generated at 2022-06-25 19:13:52.399982
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'foo'
        auth_require = False
        auth_parse = True
        netrc_parse = False
        prompt_password = False

        def get_auth(self, username=None, password=None):
            pass

    auth_plugin_0 = MyAuthPlugin()


# Generated at 2022-06-25 19:13:53.178058
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()

# Generated at 2022-06-25 19:13:59.061879
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Arrange
    formatterPlugin = FormatterPlugin()
    headers = "date: Tue, 13 Aug 2019 08:32:51 GMT\n" \
              "server: Apache/2.4.25 (Debian)\n" \
              "vary: Accept-Encoding\n" \
              "content-length: 0\n" \
              "connection: close\n" \
              "content-type: text/html; charset=UTF-8"

    # Act
    result = formatterPlugin.format_headers(headers)

    # Assert
    assert result == headers


# Generated at 2022-06-25 19:14:05.335966
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    a = AuthPlugin()
    assert a.name is None
    assert a.description is None
    assert a.package_name is None
    assert a.auth_type == None
    assert a.auth_require == True
    assert a.auth_parse == True
    assert a.netrc_parse == False
    assert a.prompt_password == True
    assert a.raw_auth is None

# Generated at 2022-06-25 19:14:06.367316
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()

# Generated at 2022-06-25 19:14:37.247776
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin() # Subclasses need to override method 'get_auth'
    print(r"auth_plugin_0 = '{0}'".format(auth_plugin_0))
    auth_plugin_0.netrc_parse = True
    auth_plugin_0.auth_type = 'basic'
    auth_plugin_0.auth_require = True
    auth_plugin_0.auth_parse = True
    auth_plugin_0.prompt_password = True
    print(r"auth_plugin_0 = '{0}'".format(auth_plugin_0))
    auth_plugin_0.get_auth(username=None, password=None) # Subclasses need to override method 'get_auth'


# Generated at 2022-06-25 19:14:42.669207
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    str_0 = formatter_plugin_0.format_body('', 'application/atom+xml')
    assert type(str_0) == str


# Generated at 2022-06-25 19:14:47.109427
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin = TransportPlugin()
    assert(transport_plugin.package_name == None)
    assert(transport_plugin.name == None)
    assert(transport_plugin.description == None)


# Generated at 2022-06-25 19:14:50.930979
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():

    auth_plugin_0 = AuthPlugin()
    # No exception is thrown
    try:
        auth_plugin_0.get_auth(username="username_0", password="password_0")
    except Exception as exception_0:
        raise exception_0


# Generated at 2022-06-25 19:14:51.858436
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    formatter = AuthPlugin()
    formatter.get_auth()

# Generated at 2022-06-25 19:14:53.393677
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin()
    converter_plugin_0.convert()

# Generated at 2022-06-25 19:14:56.151198
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin(mime = "text/plain")
    converter_plugin_0.convert(content_bytes = b'hello')
    converter_plugin_0.supports(mime = "text/plain")



# Generated at 2022-06-25 19:15:07.219794
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import io
    import unittest
    
    class DummyFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return 'test'

    def test_FormatterPlugin_format_headers():
        with io.StringIO() as buf, redirect_stdout(buf):
            formatter_plugin_0 = DummyFormatterPlugin()
            formatter_plugin_0.format_headers('HTTP/1.1 200 OK\r\nDate: Fri, 18 Jan 2019 23:02:14 GMT\r\nConnection: keep-alive\r\nContent-Length: 9\r\nContent-Type: application/json\r\n\r\n{"name": "dummy"}')
            output = buf.getvalue()
            buf.close()
            assert output == 'test'


# Generated at 2022-06-25 19:15:11.133229
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert FormatterPlugin().format_headers(headers='Test') == 'Test'


# Generated at 2022-06-25 19:15:13.217030
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin('mime')
    assert converter_plugin_0.mime == 'mime'


# Generated at 2022-06-25 19:16:01.612688
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    plugin = TransportPlugin()
    ret = plugin.get_adapter()
    pass


# Generated at 2022-06-25 19:16:03.801586
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    assert formatter_plugin.format_headers("headers") == "headers"


# Generated at 2022-06-25 19:16:04.932968
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:16:08.871660
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    auth_plugin_0 = AuthPlugin()
    auth_plugin_0.auth_require = False
    auth_plugin_0.auth_parse = False
    auth_plugin_0.netrc_parse = True
    auth_plugin_0.prompt_password = True
    auth_plugin_0.raw_auth = 'username:password'
    user_0 = test_get_auth(auth_plugin_0, username='username', password='password')
    print(user_0)
    print('All test cases passed')




# Generated at 2022-06-25 19:16:10.974301
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    assert BasePlugin().name == None
    assert BasePlugin().description == None
    assert BasePlugin().package_name == None


# Generated at 2022-06-25 19:16:13.695000
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    test_TransportPlugin = TransportPlugin()
    try:
        # Case 0
        result = test_TransportPlugin.get_adapter()
    except NotImplementedError:
        print ("NotImplementedError")
    else:
        print ("Inside else")    


# Generated at 2022-06-25 19:16:18.694815
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_obj = FormatterPlugin()
    headers_value = "Example of headers"
    formatter_plugin_obj.format_headers(headers_value) == "Example of headers"


# Generated at 2022-06-25 19:16:19.778249
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin("mime")



# Generated at 2022-06-25 19:16:22.926163
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    plugin_0 = TransportPlugin()
    exc_0 = None
    try:
        plugin_0.get_adapter()
    except Exception as exc_0:
        pass
    assert isinstance(exc_0, NotImplementedError)


# Generated at 2022-06-25 19:16:26.690027
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    test_url = 'unix:/var/run/docker.sock:/containers/json'

    class TestTransportPlugin(TransportPlugin):
        prefix = 'unix'

        def get_adapter(self):
            return requests_unixsocket.UnixAdapter('/var/run/docker.sock')

    plugin = TestTransportPlugin()
    assert plugin.prefix == 'unix'
    assert plugin.get_adapter()


# Generated at 2022-06-25 19:18:21.191864
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    event = AuthPlugin()
    event.get_auth()


# Generated at 2022-06-25 19:18:24.904112
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():

    # Case 0
    formatter_plugin_0 = FormatterPlugin()
    headers = 'test'
    expected_0 = 'test'
    actual_0 = formatter_plugin_0.format_headers(headers)
    assert actual_0 == expected_0



# Generated at 2022-06-25 19:18:26.033675
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:18:29.478466
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin = BasePlugin()
    assert base_plugin.name == None
    assert base_plugin.description == None
    assert base_plugin.package_name == None


# Generated at 2022-06-25 19:18:35.198767
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin(mime = 'application/json')
    try:
        converter_plugin_0.convert(content_bytes = 'hello')
    except NotImplementedError:
        pass
    try:
        converter_plugin_0.supports(mime = 'application/json')
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:18:36.459412
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    test_ConverterPlugin_0 = ConverterPlugin('application/json')


# Generated at 2022-06-25 19:18:42.040979
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    class FormatterPlugin_impl():
        def __init__(self, **kwargs):
            self.env = kwargs['env']
            self.format_options = kwargs['format_options']
            if 'json' in self.format_options:
                self.enabled = 'json' in self.format_options

    FormatterPlugin.__bases__ = (FormatterPlugin_impl,)
    plugin = FormatterPlugin(env='MOCK ENV', format_options={})
    assert plugin.enabled is False
    plugin = FormatterPlugin(env='MOCK ENV', format_options={'json': True})
    assert plugin.enabled is True



# Generated at 2022-06-25 19:18:44.616606
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_1 = FormatterPlugin()
    assert formatter_plugin_1.group_name == 'format'
    assert formatter_plugin_1.enabled == True


# Generated at 2022-06-25 19:18:50.966986
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    # Creating object of class AuthPlugin without parameters
    auth_plugin_0 = AuthPlugin()
    print("\nAuthPlugin object created without parameters: ")
    print(auth_plugin_0.__dict__)
    # Creating object of class AuthPlugin with parameters
    auth_plugin_1 = AuthPlugin(name="plugin_0", description="plugin_desc", auth_type="plugin_type", auth_require="True", auth_parse="True", netrc_parse="True", prompt_password="False", raw_auth="auth_raw")
    print("\nAuthPlugin object created with parameters: ")
    print(auth_plugin_1.__dict__)


# Generated at 2022-06-25 19:18:53.524790
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():

    # Create a class instance of TransportPlugin
    # and call the get_adapter method
    # This returns a BaseAdapter subclass instance to be mounted to transport_plugin.prefix
    return

