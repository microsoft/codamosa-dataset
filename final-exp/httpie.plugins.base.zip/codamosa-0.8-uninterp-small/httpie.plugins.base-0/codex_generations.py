

# Generated at 2022-06-25 19:10:20.719146
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "headers"
    result = formatter_plugin_0.format_headers(headers)

    assert result == "headers"


# Generated at 2022-06-25 19:10:23.311973
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = ''
    assert formatter_plugin_0.format_headers(headers) == ''


# Generated at 2022-06-25 19:10:31.056269
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import builtin
    from httpie.plugins import plugin
    from httpie.plugins import manager

    class AuthPlugin2(AuthPlugin):
        auth_type = 'auth_plugin_2'
        auth_require = False
        auth_parse = True
        netrc_parse = False
        prompt_password = True

        def get_auth(self, username=None, password=None):
            pass

    class TransportPlugin2(TransportPlugin):
        prefix = 'http+unix'

        def get_adapter(self):
            pass

    class ConverterPlugin2(ConverterPlugin):
        @classmethod
        def supports(cls, mime):
            pass

        def convert(self, content_bytes):
            pass


# Generated at 2022-06-25 19:10:34.011167
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers('headers')


# Generated at 2022-06-25 19:10:37.292842
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    assert formatter_plugin.format_headers('test case') == 'test case'
    assert formatter_plugin.format_headers('') == ''


# Generated at 2022-06-25 19:10:43.921673
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    template = '''
    @pytest.mark.parametrize('content', [
        'im the content',
        'my name is',
        'hello dear',
        'one more'
    ])
    def test_x(self, content, mocker, env):
        mfs = FormatterPlugin()
        result = mfs.format_body(content, mime='application/json')
        assert result == expected
    '''

    count = 0
    for content in ['im the content', 'my name is', 'hello dear', 'one more']:
        new_template = template.replace('content', '"' + str(content) + '"')
        new_template = new_template.replace('expected', '"' + str(content) + '"')
        print(new_template)
        count += 1
        test_

# Generated at 2022-06-25 19:10:44.985489
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    pass


# Generated at 2022-06-25 19:10:48.674087
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    content = '"content"'
    mime = '"mime"'
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body(content, mime) == content


# Generated at 2022-06-25 19:10:50.678779
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    assert formatter_plugin.format_headers("r:r")



# Generated at 2022-06-25 19:10:52.042360
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    format_body()

# Generated at 2022-06-25 19:10:56.435333
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers("headers=headers") == "headers=headers"



# Generated at 2022-06-25 19:10:58.712651
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'Content-Type: application/json;charset=utf-8'
    formatter_plugin_0.format_headers(headers)



# Generated at 2022-06-25 19:11:02.609033
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    mime = "a"
    content = "b"
    result = formatter_plugin_1.format_body(content, mime)
    assert result == "b"


# Generated at 2022-06-25 19:11:07.143538
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content_0 = "test"
    mime_0 = MIME_JSON
    res_0 = formatter_plugin_0.format_body(content_0,mime_0)
    assert res_0 is not None
    assert res_0 == "test"


# Generated at 2022-06-25 19:11:11.864865
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    headers = 'test string'
    result = formatter_plugin_1.format_headers(headers)
    assert result == headers


# Generated at 2022-06-25 19:11:13.195349
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert False, "Test if a random headers is formatted correctly."


# Generated at 2022-06-25 19:11:15.325998
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers('headers')


# Generated at 2022-06-25 19:11:17.887199
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body(content="abc", mime="abc") is not None


# Generated at 2022-06-25 19:11:20.327988
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    print("Calling unit test: FormatterPlugin::format_headers")
    formatter_plugin_200 = FormatterPlugin()


# Generated at 2022-06-25 19:11:25.177782
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    # Type checking
    mime = 'application/x-yaml'
    content = 'some more text'
    assert isinstance(formatter_plugin_0.format_body(content, mime), str)


# Generated at 2022-06-25 19:11:30.820233
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers("Hello World") == "Hello World"


# Generated at 2022-06-25 19:11:41.666762
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers("%$#")
    formatter_plugin_0.format_headers("Headers:")
    formatter_plugin_0.format_headers("")
    formatter_plugin_0.format_headers("\t")
    formatter_plugin_0.format_headers("\t\t")
    formatter_plugin_0.format_headers("\t\t\t")
    formatter_plugin_0.format_headers("\t\t\t\t")
    formatter_plugin_0.format_headers("\t\t\t\t\t")
    formatter_plugin_0.format_headers("\t\t\t\t\t\t")

# Generated at 2022-06-25 19:11:51.998951
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    format_options = FormatOptions()
    format_options.color=False
    format_options.stream=False
    format_options.prettify=True
    format_options.style=''
    format_options.group_responses=False
    format_options.headers='none'
    test_arg0 = 'HTTP/1.1 200 OK\r\nDate: Fri, 15 Feb 2019 10:48:05 GMT\r\nServer: uWSGI/2.0.18 Python/3.7.2\r\nContent-Type: application/json\r\nContent-Length: 8\r\n\r\n'

# Generated at 2022-06-25 19:11:54.206268
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body('A', 'B') == 'A'


# Generated at 2022-06-25 19:11:55.305877
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers("Content-Length: 546")


# Generated at 2022-06-25 19:11:57.113229
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_1 = FormatterPlugin()
    formatter_plugin_1.format_body('test_content', 'test_mime')
    assert True


# Generated at 2022-06-25 19:12:08.204967
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = '''HTTP/1.1 200 OK
Content-Language: fr
Content-Type: text/html; charset=UTF-8
Vary: Accept-Language, Cookie
Date: Fri, 09 Mar 2018 21:05:39 GMT
Server: Apache
Last-Modified: Tue, 09 Jan 2018 15:12:11 GMT
Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Pragma: no-cache
Content-Length: 38133

<!DOCTYPE html>
<html lang="fr">
<head>
<title>Jouer dans la Foreuse!</title>'''
    result = formatter_plugin_0

# Generated at 2022-06-25 19:12:11.637703
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    data = ""
    assert_equal(data, formatter_plugin_0.format_headers(data),
                 "Method format_headers of class FormatterPlugin returned data instead of " + data)


# Generated at 2022-06-25 19:12:18.454358
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()

# Generated at 2022-06-25 19:12:27.965085
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    #
    # formatter_plugin_0 is of class FormatterPlugin
    #
    raw_content_0 = 'Hello World'
    mime_0 = 'text/plain'
    args_0 = {'mime': mime_0, 'raw_content': raw_content_0}
    formatter_plugin_0 = FormatterPlugin(**args_0)
    #
    # format_body: The content format is text/plain
    #
    expected_result_0 = 'Hello World'
    actual_result_0 = formatter_plugin_0.format_body(mime=mime_0, content=raw_content_0)
    #
    assert actual_result_0 == expected_result_0


# Generated at 2022-06-25 19:12:37.310859
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert test_case_0().formatter_plugin_0.format_headers("headers") == "headers"


# Generated at 2022-06-25 19:12:48.168327
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Create instance of FormatterPlugin class
    formatter_plugin = FormatterPlugin()
    # Provide parameters
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Server: nginx\r\n' \
              'Date: Wed, 27 May 2020 19:23:48 GMT\r\n' \
              'Content-Type: application/json\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: close\r\n' \
              '\r\n' \
              '[]'
    # Run method format_headers
    result = formatter_plugin.format_headers(headers)
    # Print method format_headers' result
    print(result)
    # Print method format_headers' parameters

# Generated at 2022-06-25 19:12:53.373339
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = 'test headers'
    result = formatter_plugin_0.format_headers(headers)
    # assert result == 'test headers'


# Generated at 2022-06-25 19:12:58.582658
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class FormatterPlugin_0(FormatterPlugin):
        def format_body(self, content, mime):
            return content
    formatter_plugin_0 = FormatterPlugin_0(**{'format_options': {}})
    content = "content"
    mime = "mime"
    content_ret = formatter_plugin_0.format_body(content, mime)
    assert content == content_ret # unit test for method format_body of class FormatterPlugin


# Generated at 2022-06-25 19:12:59.808319
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = "text"
    assert formatter_plugin_0.format_headers(headers) == "text"


# Generated at 2022-06-25 19:13:02.702365
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_body(content="content", mime="mime")

# Generated at 2022-06-25 19:13:13.665586
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()

# Generated at 2022-06-25 19:13:16.623427
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin = FormatterPlugin()
    result = formatter_plugin.format_body("content", "mime")
    expected = "content"
    assert result == expected, "Unexpected result"

# Generated at 2022-06-25 19:13:19.337822
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = "text/html"
    mime = "html"
    assert formatter_plugin_0.format_body(content, mime) == "text/html"


# Generated at 2022-06-25 19:13:25.441072
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_1 = FormatterPlugin()
    formatter_plugin_1.format_headers('headers: null')
    formatter_plugin_1.format_headers('headers: HTTP/1.1  200 OK\nDate: Sat, 18 Jan 2020 13:13:58 GMT\nServer: Apache\nX-Powered-By: PHP/5.6.40\nSet-Cookie: PHPSESSID=5b5f5cc80c9d5; path=/\nExpires: Thu, 19 Nov 1981 08:52:00 GMT\nCache-Control: no-store, no-cache, must-revalidate\nPragma: no-cache\nContent-Length: 21\nContent-Type: text/html; charset=UTF-8')

# Generated at 2022-06-25 19:13:43.548165
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    env = Environment()
    kwargs = {}
    formatter_plugin_0.__init__(env,kwargs)
    param = 'test'
    r = formatter_plugin_0.format_headers(param)
    print(r)


# Generated at 2022-06-25 19:13:46.003730
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_0.format_headers("")


# Generated at 2022-06-25 19:13:51.239196
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():

    # Construct fixture
    formatter_plugin_0 = FormatterPlugin()

    # Test
    content = 'Now is the time'
    mime = 'application/atom+xml'
    formatter_plugin_0.format_body(content, mime)


# Generated at 2022-06-25 19:13:52.647062
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    print("test_FormatterPlugin_format_body")
    pass



# Generated at 2022-06-25 19:14:00.126768
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # monkey patching
    from httpie.utils import default_environment
    from httpie.output.formatters import get_formatter
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.output.formatters.colors import (
        COLORS as _COLORS,
        STYLES as _STYLES,
    )
    _COLORS['test-colors'] = (0, 1, 2)
    _STYLES['test-style'] = 'test-style'
    http_response = Response()

# Generated at 2022-06-25 19:14:02.522734
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    test_case_0()


# Generated at 2022-06-25 19:14:06.757573
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'application/atom+xml'
    content = '<html><head><title>Hola</title></head></html>'

    assert formatter_plugin_0.format_body(content, mime) == content



# Generated at 2022-06-25 19:14:10.193522
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = 'test'
    mime = 'test'
    assert formatter_plugin_0.format_body(content, mime) == content



# Generated at 2022-06-25 19:14:12.943248
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    test_content = "Hi"
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_body(test_content) == test_content


# Generated at 2022-06-25 19:14:15.523594
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers = {}
    assert formatter_plugin_0.format_headers(headers) == {}


# Generated at 2022-06-25 19:14:48.602574
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    new_formatter_plugin = FormatterPlugin()
    test_string = "<html>\n\n<body>\n<h1>hello</h1>\n</body>\n</html>"
    test_mime = "text/html"
    new_test_string = new_formatter_plugin.format_body(test_string, test_mime)
    assert new_test_string == test_string

# Generated at 2022-06-25 19:14:52.516728
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin = FormatterPlugin()
    headers = """HTTP/1.1 200 OK
Content-Type: application/json

"""
    assert formatter_plugin.format_headers(headers) == headers


# Generated at 2022-06-25 19:14:54.704678
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    assert formatter_plugin_0.format_headers('headers') == 'headers'



# Generated at 2022-06-25 19:14:56.897820
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content_0 = 'abc'
    mime_0 = 'application/atom+xml'
    formatter_plugin_0.format_body(content_0, mime_0)



# Generated at 2022-06-25 19:15:00.660242
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    mime = 'application/json'

# Generated at 2022-06-25 19:15:05.895882
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    body = "Hello World"
    mime = "text/plain"
    assert formatter_plugin_0.format_body(body, mime) == "Hello World"


# Generated at 2022-06-25 19:15:08.017034
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter_plugin_0 = FormatterPlugin()
    headers_0 = "Header"
    # Unit test for format_headers of class object
    formatted_headers = formatter_plugin_0.format_headers(headers_0)
    assert type(formatted_headers) == str


# Generated at 2022-06-25 19:15:15.757567
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    """
    This method verifies if the body of the response is correctly formatted.
    """
    formatter_plugin_0 = FormatterPlugin()
    response = '''{ "message": "ok" }'''
    mime = 'application/json'
    expected = '''{ "message": "ok" }'''
    assert formatter_plugin_0.format_body(response, mime) == expected



# Generated at 2022-06-25 19:15:17.701598
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    instance = FormatterPlugin()
    instance.format_headers("headers")


# Generated at 2022-06-25 19:15:21.647159
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter_plugin_0 = FormatterPlugin()
    content = ""
    mime = ""

    try:
        formatter_plugin_0.format_body(content, mime)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:16:34.799095
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    print("Testing constructor of class TransportPlugin")
    transport_plugin = TransportPlugin()


# Generated at 2022-06-25 19:16:39.511153
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin = ConverterPlugin('changed MIME')
    assert converter_plugin.mime == 'changed MIME'
    assert converter_plugin.convert(b'data') == NotImplementedError
    assert converter_plugin.supports('test') == NotImplementedError



# Generated at 2022-06-25 19:16:40.763123
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin_0 = AuthPlugin()


# Generated at 2022-06-25 19:16:42.848007
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin('test_mime')
    converter_plugin_0.convert(bytes(1))



# Generated at 2022-06-25 19:16:43.828943
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    base_plugin_0 = BasePlugin()


# Generated at 2022-06-25 19:16:44.277314
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    TransportPlugin()

# Generated at 2022-06-25 19:16:50.373851
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin0(AuthPlugin):
        def get_auth(self, username=None, password=None):
            return "AuthPlugin0.get_auth()"
    auth_plugin_0 = AuthPlugin0()
    assert auth_plugin_0.get_auth() == "AuthPlugin0.get_auth()"


# Generated at 2022-06-25 19:16:51.612257
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()



# Generated at 2022-06-25 19:16:55.265926
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    # Test whether parameter can be passed to superclass
    formatter_plugin_1 = FormatterPlugin(group_name='my_format')
    assert formatter_plugin_1.group_name == 'my_format'

# Generated at 2022-06-25 19:16:56.038436
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:18:59.380741
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin_0 = TransportPlugin()


# Generated at 2022-06-25 19:19:00.437673
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    prefix = TransportPlugin.prefix
    assert prefix == None


# Generated at 2022-06-25 19:19:02.183771
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    trans_plugin = TransportPlugin()
    if trans_plugin:
        pass
    else :
        raise AssertionError()
    assert trans_plugin.prefix == None


# Generated at 2022-06-25 19:19:04.206504
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    converter_plugin_0 = ConverterPlugin("application")
    assert_raises(NotImplementedError, converter_plugin_0.convert, b"application")


# Generated at 2022-06-25 19:19:05.590704
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    formatter_plugin_0 = FormatterPlugin()


# Generated at 2022-06-25 19:19:06.606905
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    converter_plugin_0 = ConverterPlugin("a")


# Generated at 2022-06-25 19:19:08.849033
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    if __name__ == '__main__':
        unixsocket = TransportPlugin()
        unixsocket.prefix = 'http+unix://'
        unixsocket.get_adapter = 'httpunixsocket'


# Generated at 2022-06-25 19:19:11.614852
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    # Create an instance of class TransportPlugin
    transport_plugin_0 = TransportPlugin()

    # Verify that fields of the instance were initialised correctly
    assert transport_plugin_0.package_name is None
    assert transport_plugin_0.description is None
    assert transport_plugin_0.name is None


# Generated at 2022-06-25 19:19:12.345996
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    auth_plugin = AuthPlugin()


# Generated at 2022-06-25 19:19:13.637199
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    transport_plugin = TransportPlugin()
    transport_plugin.get_adapter()

# Test for abstract method get_auth of class AuthPlugin