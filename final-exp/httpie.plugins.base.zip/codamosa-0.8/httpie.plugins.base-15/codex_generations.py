

# Generated at 2022-06-12 00:09:08.624150
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    d = FormatterPlugin(**{'format_options': {'colors': True, 'style': None, 'format': None}})
    assert d.format_body('A text for testing', "mime") == 'A text for testing'


# Generated at 2022-06-12 00:09:13.037381
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    class FormatterPlugin1(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers+"abc"
    formatter_plugin=FormatterPlugin1()
    assert formatter_plugin.format_headers("123")=="123abc"


# Generated at 2022-06-12 00:09:13.900623
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    FormatterPlugin().format_body('test','test')

# Generated at 2022-06-12 00:09:19.724225
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    assert FormatterPlugin().format_headers("") == ""
    assert FormatterPlugin().format_headers("a: b") == "a: b"
    assert FormatterPlugin().format_headers("a: b\n c: d") == "a: b\n c: d"
    assert FormatterPlugin().format_headers("a: b\nC: d") == "a: b\nC: d"
    assert FormatterPlugin().format_headers("a: b\nC: d\n") == "a: b\nC: d\n"

# Generated at 2022-06-12 00:09:30.913536
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # Create an instance of FormatterPlugin
    fp = FormatterPlugin(content='Hello world')

    # Create a test string
    content = '{"id": "0001", "type": "donut", "name": "Cake", "ppu": 0.55, "batters": { "batter": [ { "id": "1001", "type": "Regular" }, { "id": "1002", "type": "Chocolate" }, { "id": "1003", "type": "Blueberry" }, { "id": "1004", "type": "Devil\'s Food" } } }'

# Generated at 2022-06-12 00:09:33.770391
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    expected = "a: b\n"
    output = FormatterPlugin().format_headers("a: b")
    assert output == expected


# Generated at 2022-06-12 00:09:44.114545
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import pytest
    from httpie import ExitStatus

    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers):
            return headers + '\nAdditional header'
    class TestFormatterPlugin_Fail(FormatterPlugin):
        def format_headers(self, headers):
            raise ValueError('Test')
    class TestFormatterPlugin_ExitStatusFail(FormatterPlugin):
        def format_headers(self, headers):
            return ''
    class TestFormatterPlugin_ExitStatusFail2(FormatterPlugin):
        def format_headers(self, headers):
            raise Exception('Test')

    assert TestFormatterPlugin().format_headers('Test') == 'Test\nAdditional header'

    with pytest.raises(ValueError):
        TestFormatterPlugin_Fail().format_headers('Test')

# Generated at 2022-06-12 00:09:44.619039
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    pass

# Generated at 2022-06-12 00:09:45.646942
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    # type: (TestCase) -> None
    pass


# Generated at 2022-06-12 00:09:53.965752
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # load the package containing the plugin
    import httpie_dummy_formatter_plugin
    # create an instance of that plugin
    plugin = httpie_dummy_formatter_plugin.DummyFormatterPlugin()
    # get headers from a request
    r = requests.get("http://httpbin.org/headers")
    # call the plugin's method format_headers
    formatted_headers = plugin.format_headers(r.text)
    # check that the returned string is not empty
    assert len(formatted_headers) > 0


# Generated at 2022-06-12 00:09:59.393251
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TransportPlugin(TransportPlugin):
        prefix = 'unix'

        def get_adapter(self):
            return UNIXSocketAdapter('/tmp/httpie.sock')
    print(TransportPlugin)



# Generated at 2022-06-12 00:10:03.722764
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    Plugin = BasePlugin()
    assert Plugin.name == None, "name is not properly initialized"
    assert Plugin.description == None, "description is not properly initialized"
    assert Plugin.package_name == None, "package_name is not properly initialized"


# Generated at 2022-06-12 00:10:10.923551
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class TestFormatter(FormatterPlugin):
        name = 'testformatter'
        enabled = True

        def format_body(self, content: str, mime: str) -> str:
            return 'test_content'

    assert TestFormatter(kwargs={'format_options': {}}).format_body('content', 'mime') == 'test_content'

# Generated at 2022-06-12 00:10:15.892835
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class AdapterSubclass(TransportPlugin):
        prefix = 'test'
        def get_adapter(self):
            return 'test_AdapterSubclass_get_adapter'
    adapter_subclass = AdapterSubclass()
    assert adapter_subclass.get_adapter() == 'test_AdapterSubclass_get_adapter'


# Generated at 2022-06-12 00:10:26.165260
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    import io
    import json
    import sys
    class JsonTest(ConverterPlugin):
        def convert(self, content_bytes):
            print("Json:",content_bytes)
            return json.dumps(json.loads(content_bytes), indent=2)
        @classmethod
        def supports(cls, mime):
            return "json" in mime
    class _Stdout(io.TextIOBase):
        def write(self, text):
            print("TextIOBase:",text)
            sys.stdout.write(text)
            return len(text)
    with open("index.json") as f:
        content = f.read()
        JsonTest("text/json")
        print("PrettifiedFormatterPlugin:",isinstance(JsonTest, PrettifiedFormatterPlugin))

# Generated at 2022-06-12 00:10:30.366924
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    import requests
    import httpie.plugins
    httpie.plugins.load_auth_plugins()
    http_auth = httpie.plugins.get_auth_plugin('http')
    http_auth.get_auth(username='Foo', password='Bar')



# Generated at 2022-06-12 00:10:33.515684
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    basePlugin = BasePlugin()
    assert basePlugin.name == None
    assert basePlugin.description == None
    assert basePlugin.package_name == None


# Generated at 2022-06-12 00:10:37.590075
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test'

        def get_auth(self, username=None, password=None):
            return username + password

    plugin = TestAuthPlugin()
    assert plugin.get_auth(username='u', password='p') == 'up'


# Generated at 2022-06-12 00:10:41.702460
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class MIME(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)
            self.mime = mime

    mime = MIME('css')
    assert mime.mime == 'css', "Constructor of ConverterPlugin is not correct"



# Generated at 2022-06-12 00:10:47.466038
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    # Test for method get_auth( self, username = None, password = None )
    # of class AuthPlugin
    username = 'admin'
    password = 'admin'
    obj = AuthPlugin()
    with pytest.raises(NotImplementedError):
        obj.get_auth()


# Generated at 2022-06-12 00:10:51.027537
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    pass


# Generated at 2022-06-12 00:10:54.969281
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPlugin(BasePlugin):
        def get_auth(self, username=None, password=None):
            return True
    userAuth = AuthPlugin()
    assert userAuth.get_auth(username="abc",password="1234") == True

# Generated at 2022-06-12 00:10:59.669162
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():

    class ConverterPlugin(BasePlugin):
        def convert(self, content_bytes):
            return content_bytes.upper()

        @classmethod
        def supports(cls, mime):
            return mime.lower() == 'text/a'

    # Instantiation
    converter = ConverterPlugin('text/a')

    # Test convert function
    assert converter.convert(b'abcdefgh') == b'ABCDEFGH'



# Generated at 2022-06-12 00:11:07.135932
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class TestConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes
        @classmethod
        def supports(cls, mime):
            return True
    conv = TestConverterPlugin('test/test')
    assert conv.convert(b'ab\ncd') == b'ab\ncd'
    assert conv.convert(u'ab\ncd') == b'ab\ncd'


# Generated at 2022-06-12 00:11:10.960420
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    data = {"format_options": ['--color','--verbose']}
    formatter_plugin = FormatterPlugin(**data)
    assert formatter_plugin.kwargs['format_options'] == ['--color','--verbose']


# Generated at 2022-06-12 00:11:14.345569
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TestTransportPlugin(TransportPlugin):
        prefix = 'http'

        def get_adapter(self):
            return 'Test'

    plugin = TestTransportPlugin()
    plugin.get_adapter()
    assert plugin.prefix == 'http'


# Generated at 2022-06-12 00:11:19.000599
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():

    import httpie.cli

    class TestFormatterPlugin(FormatterPlugin):

        def format_headers(self, headers: str) -> str:
            return headers

    plugin = TestFormatterPlugin(**{
        'env': httpie.cli.Environment(),
        'format_options': {},
    })



# Generated at 2022-06-12 00:11:21.908112
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    format_options = {}
    formatter_plugin = FormatterPlugin(format_options=format_options)
    assert formatter_plugin.format_options == format_options



# Generated at 2022-06-12 00:11:26.102593
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    # Instantiate an object of type ConverterPlugin
    converter = ConverterPlugin("application/json")
    # Check that the correct class has been called
    assert converter.__class__ is ConverterPlugin
    # Check that the __init__ function of the class has been called
    assert converter.mime == "application/json"

# Generated at 2022-06-12 00:11:29.125200
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter = FormatterPlugin()
    x = b'{"test":"test value"}'
    x = formatter.format_body(x, 'application/json')
    print(x)



# Generated at 2022-06-12 00:11:41.775673
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    import sys

# Generated at 2022-06-12 00:11:49.738645
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class MockedConverterPlugin(ConverterPlugin):
        def convert(self, content_bytes):
            return content_bytes.decode()
        @classmethod
        def supports(cls, mime):
            return False

    mimes = ["application/json", "application/xml", "text/html", "text/plain"]
    message = "This is a test conversion.\n"
    testConverterPlugin = MockedConverterPlugin('application/json')
    for mime in mimes:
        assert testConverterPlugin.convert(message.encode()).rstrip() == message



# Generated at 2022-06-12 00:11:50.733127
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    pass



# Generated at 2022-06-12 00:11:54.633707
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    class MyFormatterPlugin(FormatterPlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content + content
    formatter = MyFormatterPlugin()
    print(formatter.format_body('abc', None))



# Generated at 2022-06-12 00:11:57.254971
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    # test constructor without arguments
    with pytest.raises(TypeError):
        BasePlugin()



# Generated at 2022-06-12 00:12:03.661750
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class ConverterPluginTest(ConverterPlugin):
        @classmethod
        def supports(cls, mime):
            return True

    plugin = ConverterPluginTest("foo")
    assert plugin.convert(b"bar") == "foo"

    class ConverterPluginTest2(ConverterPlugin):
        @classmethod
        def supports(cls, mime):
            return True

    plugin2 = ConverterPluginTest2("foo")
    assert plugin2.convert(b"bar") == "foo"


# Generated at 2022-06-12 00:12:09.434375
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    class SampleAuthPlugin(AuthPlugin):
        def get_auth(self, username=None, password=None):
            pass

    p = SampleAuthPlugin()
    assert p.auth_type == None
    assert p.auth_require == True
    assert p.auth_parse == True
    assert p.netrc_parse == False
    assert p.prompt_password == True
    assert p.raw_auth == None
if __name__ == '__main__':
    test_AuthPlugin()

# Generated at 2022-06-12 00:12:15.521874
# Unit test for constructor of class AuthPlugin
def test_AuthPlugin():
    def get_auth(username=None, password=None):
        raise NotImplementedError()

    # call __init__ with argument
    # test that no error is raised
    AuthPlugin(auth_type='something', get_auth=get_auth)

    # call __init__ without argument
    # test that no error is raised
    AuthPlugin()


# Generated at 2022-06-12 00:12:19.315348
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    class MyConverterPlugin(ConverterPlugin):
        def __init__(self,mime):
            self.mime = mime
        def convert(self, content_bytes):
            return "a"
        @classmethod
        def supports(cls, mime):
            return True

    assert MyConverterPlugin("mime").convert(b"content") == "a"

# Generated at 2022-06-12 00:12:21.915677
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    def constructor():
        _ = BasePlugin()

    with pytest.raises(TypeError):
        constructor()

# Generated at 2022-06-12 00:12:40.800959
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    plugin = ConverterPlugin('mime')
    print(plugin)
    # Unit test for __init__ of class AuthPlugin
    plugin = AuthPlugin()
    print(plugin)
    # Unit test for __init__ of class TransportPlugin
    plugin = TransportPlugin()
    print(plugin)
    # Unit test for __init__ of class FormatterPlugin
    args = dict()
    plugin = FormatterPlugin(**args)
    print(plugin)
    args = dict()
    plugin = FormatterPlugin(**args)
    print(plugin)
    args = dict()
    plugin = FormatterPlugin(**args)
    print(plugin)
    args = dict()
    plugin = FormatterPlugin(**args)
    print(plugin)
    args = dict()
    plugin = FormatterPlugin(**args)
    print(plugin)



# Generated at 2022-06-12 00:12:45.435217
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class A(TransportPlugin):
        prefix = 'a'
        def get_adapter(self):
            return requests.adapters.HTTPAdapter()

    a = A()
    assert isinstance(a.get_adapter(), requests.adapters.BaseAdapter)



# Generated at 2022-06-12 00:12:56.512362
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    formatter = FormatterPlugin()
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Date: Sat, 02 Feb 2019 18:22:06 GMT\r\n' \
              'Server: Apache/2.4.29 (Ubuntu)\r\n' \
              'Last-Modified: Fri, 01 Feb 2019 13:52:52 GMT\r\n' \
              'ETag: "2b15-58844f4fcb100"\r\n' \
              'Accept-Ranges: bytes\r\n' \
              'Content-Length: 10965\r\n' \
              'Connection: close\r\n' \
              'Content-Type: text/html; charset=UTF-8\r\n'
    processed_headers = formatter.format_headers(headers)


# Generated at 2022-06-12 00:13:05.538449
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import os
    import sys
    import unittest

    # If a test fails, then print the whole output, not just the diff.
    unittest.main(buffer=False)
    class TestFormatterPlugin(unittest.TestCase):
        def test_format_headers(self):
            self.maxDiff = None  # Print the whole output, not just the diff.
            sys.path.append(os.path.dirname(__file__))
            from httpie.plugins import builtin

# Generated at 2022-06-12 00:13:11.579083
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    test = ConverterPlugin(mime = 'text/plain')
    print(test.mime)
    assert (type(test.mime) == str) == True
    assert (type(test.convert)) == types.MethodType == True
    assert (type(test.supports)) == types.MethodType == True


# Generated at 2022-06-12 00:13:20.612716
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    from httpie.plugins import plugin_manager
    from httpie.output.streams import UnsupportedMediaType

    plugin_manager.load_internal_plugins()

    formatter_plugin = plugin_manager.find_first_plugin_by_instance(FormatterPlugin)
    formatter_plugin_instance = formatter_plugin()

    #return formatter_plugin_instance.format_body('{"foo":"bar"}', 'application/json')
    return formatter_plugin_instance.format_body('<html><body><h1>hello world</h1></body></html>', 'text/html')


# Generated at 2022-06-12 00:13:25.076193
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    # case 1
    try:
        p = ConverterPlugin('mime')
        assert False
    except NotImplementedError:
        pass
    except:
        assert False


    # case 2
    try:
        p = ConverterPlugin.supports('mime')
        assert False
    except NotImplementedError:
        pass
    except:
        assert False

# Generated at 2022-06-12 00:13:30.431552
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    class TestBasePlugin(BasePlugin):
        pass
    test_plugin = TestBasePlugin()
    # should return right name
    assert test_plugin.name == "TestBasePlugin"
    # should return right name if defined
    test_plugin.name = "name_test"
    assert test_plugin.name == "name_test"
    # should return right package name
    assert test_plugin.package_name == "tests"



# Generated at 2022-06-12 00:13:37.506289
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class TestTransportPlugin(TransportPlugin):
        pass

    x = TestTransportPlugin()
    assert x.prefix is None


plugin_packages = ['httpie', 'plugins']
loaded_auth_plugins = {}
loaded_transport_plugins = {}
loaded_converter_plugins = {}
loaded_formatter_plugins = {}



# Generated at 2022-06-12 00:13:45.088020
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class SessionAuthPlugin(AuthPlugin):
        auth_type = 'session-auth'

        def get_auth(self, username=None, password=None):
            return requests.auth.HTTPBasicAuth(username, password)

    my_auth_plugin = SessionAuthPlugin()
    assert my_auth_plugin.auth_type == 'session-auth'
    assert my_auth_plugin.auth_require == True
    assert my_auth_plugin.auth_parse == True
    assert my_auth_plugin.netrc_parse == False
    assert my_auth_plugin.prompt_password == True

# Generated at 2022-06-12 00:14:13.306554
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    """
    >>> class MyAuthPlugin(AuthPlugin):
    ...     def get_auth(self, username=None, password=None):
    ...         if username and password:
    ...             return (username, password)
    ...         return '42'
    ...
    >>> auth_plugin = MyAuthPlugin()
    >>> auth_plugin.get_auth()
    '42'
    >>> auth_plugin.get_auth('foo', 'bar')
    ('foo', 'bar')
    """



# Generated at 2022-06-12 00:14:17.026119
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    #Setup
    env = Environment()
    format_options1 = True
    format_options2 = False
    
    #Test
    FormatterPlugin(env, True)
    FormatterPlugin(env, False)

    #Assert
    assert(True)


# Generated at 2022-06-12 00:14:20.369262
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class TP(TransportPlugin):
        def get_adapter(self):
            pass
    
    tp = TP()
    assert tp.get_adapter() == None


# Generated at 2022-06-12 00:14:25.564201
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    '''
    if auth_parse is true, username and password contains
    the parsed credentials.
    '''
    username = 'abc'
    password = '***'
    raw_auth = username+':'+password
    c = AuthPlugin()
    c.auth_parse = True
    c.raw_auth = raw_auth
    c.get_auth(username=username, password=password)
    # If raw_auth exists, username and password should be None
    c.raw_auth = 'abc'
    username = 'def'
    password = '***'
    c.get_auth(username=username, password=password)
    # If auth_parse is False, username and password should be None
    c.auth_parse = False
    c.get_auth(username='any', password='any')
    # If both auth_

# Generated at 2022-06-12 00:14:26.843654
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    assert 1 == 1

# Generated at 2022-06-12 00:14:33.992417
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class MyPlugin(AuthPlugin):
        auth_type = 'my-auth'
        auth_require = True
        auth_parse = True
        netrc_parse = False
        prompt_password = False

        def get_auth(self, username=None, password=None):
            assert username == 'user'
            assert password == 'pass'
            assert self.raw_auth == 'user:pass'

    MyPlugin().get_auth(username='user', password='pass')



# Generated at 2022-06-12 00:14:41.603455
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    # Given the headers of the response
    headers = """HTTP/1.1 200 OK
Content-Type: text/html
Content-Length: 612

"""
    # When the formatter is initialized
    formatter = FormatterPlugin()
    # And we format the headers
    headers_formatted = formatter.format_headers(headers)
    # Then the headers remain unchanged
    assert headers_formatted == headers


# Generated at 2022-06-12 00:14:47.706701
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    from os.path import dirname, join

    def test_name():
        init_path = join(dirname(__file__), '__init__.py')
        with open(init_path) as f:
            init_src = f.read()
        assert 'name = ' in init_src

    test_name()


# Generated at 2022-06-12 00:14:53.609442
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    from httprunner import __version__
    from httprunner.utils import get_os_environ
    from httper import __version__ as httper_version
    import requests
    import sys
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    tp_list = plugin_manager.get_transport_plugins()
    for tp in tp_list:
        if tp.name == "UnixSocket":
            tp.get_adapter()



# Generated at 2022-06-12 00:14:56.755414
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
	class Fake:
		enabled = True
		kwargs = {'format_options': 'none'}

	assert Fake.enabled is True
	assert Fake.kwargs['format_options'] == 'none'

# Generated at 2022-06-12 00:15:40.342812
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
     result = FormatterPlugin().format_body('content', 'text/html')
     assert result == 'content'

# Generated at 2022-06-12 00:15:45.103343
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():

    class MyConverter(ConverterPlugin):
        def __init__(self, mime):
            # directly call the constructor of base class
            super(MyConverter, self).__init__(mime)

    plugin = MyConverter('mime')

    assert plugin.mime == 'mime'

# Generated at 2022-06-12 00:15:46.658854
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    assert ConverterPlugin("test_mime").convert("test_content") == "test_content"


# Generated at 2022-06-12 00:15:48.546745
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    plugin = ConverterPlugin('application/json')
    assert issubclass(plugin.__class__, ConverterPlugin)


# Generated at 2022-06-12 00:15:58.891129
# Unit test for method convert of class ConverterPlugin

# Generated at 2022-06-12 00:16:03.942457
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    class checkTransportPlugin(TransportPlugin):
        prefix = 'unix:///'
        def get_adapter(self):
            return 'test adapter'
    a = checkTransportPlugin()
    assert a.prefix == 'unix:///'
    assert a.get_adapter() == 'test adapter'


# Generated at 2022-06-12 00:16:06.325533
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    p = BasePlugin()
    assert p.name == None
    assert p.description == None
    assert p.package_name == None


# Generated at 2022-06-12 00:16:11.826628
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    x = FormatterPlugin(**{'env': None, 'format_options': {"colors": "0"}})
    y = x.format_headers("HTTP/1.1 200 OK\ncontent-type: application/json")
    assert y == "HTTP/1.1 200 OK" + os.linesep + "content-type: application/json"



# Generated at 2022-06-12 00:16:20.601970
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    plugin = BasePlugin()
    assert plugin.name is None
    assert plugin.description is None
    assert plugin.package_name is None

    plugin.name = 'test_name'
    assert plugin.name == 'test_name'
    assert plugin.description is None
    assert plugin.package_name is None

    plugin.description = 'test_description'
    assert plugin.name == 'test_name'
    assert plugin.description == 'test_description'
    assert plugin.package_name is None

    plugin.package_name = 'test_package_name'
    assert plugin.name == 'test_name'
    assert plugin.description == 'test_description'
    assert plugin.package_name == 'test_package_name'



# Generated at 2022-06-12 00:16:31.378147
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.builtin import HTTPBinUploadConverter
    from httpie.plugins.builtin import UnformattedOutputConverter
    from httpie.plugins.builtin import JSONConverter
    plugin = ConverterPlugin('${mime}')
    # NotImplementedError
    try:
        plugin.convert('{}')
        assert False
    except NotImplementedError:
        assert True
    # NotImplementedError
    try:
        plugin.convert('{"a":"b"}')
        assert False
    except NotImplementedError:
        assert True
    # NotImplementedError

# Generated at 2022-06-12 00:18:06.810136
# Unit test for method format_body of class FormatterPlugin
def test_FormatterPlugin_format_body():
    formatter = FormatterPlugin(format_options=None)
    assert formatter.format_body(content="{}", mime="") == "{}"



# Generated at 2022-06-12 00:18:11.327244
# Unit test for constructor of class ConverterPlugin
def test_ConverterPlugin():
    class ConverterPlugin(ConverterPlugin):
        def __init__(self,mime):
            self.mime = mime
            self.name = None
            self.description = None
            self.package_name = None
    a = ConverterPlugin("application/mpack")
    assert(a.mime == "application/mpack")


# Generated at 2022-06-12 00:18:17.867503
# Unit test for method get_adapter of class TransportPlugin
def test_TransportPlugin_get_adapter():
    class MyTransportPlugin(TransportPlugin):
        prefix = 'mytransport'
        def get_adapter(self):
            pass

    # Can't import base class attribute
    try:
        getattr(MyTransportPlugin, 'prefix')
    except ImportError:
        pass

    # Can't import base class method
    try:
        getattr(MyTransportPlugin, 'get_adapter')
    except ImportError:
        pass

    # Can't import base class
    try:
        getattr(MyTransportPlugin, 'TransportPlugin')
    except ImportError:
        pass


# Generated at 2022-06-12 00:18:19.517028
# Unit test for constructor of class FormatterPlugin
def test_FormatterPlugin():
    assert FormatterPlugin.group_name == 'format'



# Generated at 2022-06-12 00:18:28.917959
# Unit test for method get_auth of class AuthPlugin
def test_AuthPlugin_get_auth():
    class AuthPluginImpl(AuthPlugin):
        def get_auth(self, username=None, password=None):
            return "abcd"
    
    auth1 = AuthPluginImpl()
    assert auth1.get_auth("foo", "bar") == "abcd"
    assert auth1.auth_type is None
    
    class AuthPluginImpl2(AuthPlugin):
        auth_type = "ntlm"
        def get_auth(self, username=None, password=None):
            return "1234"
    
    auth2 = AuthPluginImpl2()
    assert auth2.auth_type == "ntlm"
    assert auth2.auth_parse is True
    assert auth2.auth_require is True
    assert auth2.netrc_parse is False
    assert auth2.prompt_password is True

# Generated at 2022-06-12 00:18:37.502218
# Unit test for constructor of class BasePlugin
def test_BasePlugin():
    """Tests the constructor of BasePlugin"""
    test_string = "test_string"

    test_base = BasePlugin()

    assert(test_base.name is None)
    assert(test_base.description is None)
    assert(test_base.package_name is None)

    test_base2 = BasePlugin(name=test_string,description=test_string)

    assert(test_base2.name == test_string)
    assert(test_base2.description == test_string)
    assert(test_base2.package_name is None)

# Generated at 2022-06-12 00:18:48.974459
# Unit test for method format_headers of class FormatterPlugin
def test_FormatterPlugin_format_headers():
    import responses
    import pytest
    from httpie import ExitStatus
    from utils import TestEnvironment, http, HTTP_OK

    env = TestEnvironment()
    env.config['output']['headers_only'] = True
    format_options = env.config['output']['format_options'].get(
        'json', {})
    format_environment_options = env.config['output']['format_environment_options'].get(
        'json', {})
    format_plugin = FormatterPlugin(
        format_options=format_options,
        format_environment_options=format_environment_options
    )


# Generated at 2022-06-12 00:18:58.840175
# Unit test for method convert of class ConverterPlugin
def test_ConverterPlugin_convert():
    import json

    class MockDict(dict):
        def __init__(self, mime):
            self.mime = mime

    mime_json = MockDict('application/json')
    raw_content = b'{"foo": "bar", "nested": ["a", "b", {"c": "d"}]}'
    expected_result = json.loads(raw_content.decode())

    def convert(self, content_bytes):
        return content_bytes.decode()

    class FooJsonConverter(ConverterPlugin):
        def __init__(self, mime):
            self.mime = mime

        def convert(self, content_bytes):
            return content_bytes.decode()

        @classmethod
        def supports(cls, mime):
            return mime.mime

# Generated at 2022-06-12 00:19:05.279143
# Unit test for constructor of class TransportPlugin
def test_TransportPlugin():
    from httpie.plugins import TransportPlugin
    from httpie.plugins import BuiltinPlugins
    from httpie import __version__

    class CustomTransportPlugin(TransportPlugin):
        prefix = 'http://'
        def get_adapter(self):
            return

    def custom_init_hook(cls, filename, package_name, index=None):
        instance = cls()
        instance.package_name = package_name
        return [instance]

    import types
    import httpie.plugins.builtin
    import re
    httpie.plugins.builtin.__init__ = types.MethodType(custom_init_hook,
                                                       httpie.plugins.builtin)
    httpie.plugins.builtin.__all__.append('CustomTransportPlugin')
    httpie.plugins.builtin.CustomTransportPlugin