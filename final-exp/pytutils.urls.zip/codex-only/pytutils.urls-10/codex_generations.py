

# Generated at 2022-06-24 03:24:38.729089
# Unit test for function update_query_params
def test_update_query_params():
    urls = [
        ('http://example.com?foo=bar', {"foo": "stuff"}, 'http://example.com?foo=stuff'),
        ('http://example.com?foo=bar&foo=baz', {"foo": "stuff"}, 'http://example.com?foo=stuff'),
        ('http://example.com?foo=bar', {"foo": "stuff", "bar": "foo"}, 'http://example.com?bar=foo&foo=stuff'),
    ]

    for url, params, expected in urls:
        assert update_query_params(url, params) == expected

# Add this line to unittest.py
# import sys;sys.path.insert(0,os.path.expanduser('~/github/utilities/python'))
# import unittest_utils as test
# test.test_

# Generated at 2022-06-24 03:24:42.294556
# Unit test for function update_query_params
def test_update_query_params():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:24:45.101757
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?biz=baz&foo=stuff' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))



# Generated at 2022-06-24 03:24:49.848612
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, {'foo': 'stuff', 'baz': 'ping'}) == 'http://example.com?baz=ping&biz=baz&foo=stuff'


# Generated at 2022-06-24 03:25:00.981444
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    url = update_query_params(url, dict(foo='stuff'))
    eq_(url, 'http://example.com?biz=baz&foo=stuff')

    url = 'http://example.com?foo=bar&biz=baz'
    url = update_query_params(url, dict(foo='stuff', biz='stuff2'))
    eq_(url, 'http://example.com?biz=stuff2&foo=stuff')

    url = 'http://example.com?foo=bar&biz=baz'
    url = update_query_params(url, dict(foo='stuff', biz='stuff2', hello='world'))

# Generated at 2022-06-24 03:25:06.285992
# Unit test for function update_query_params
def test_update_query_params():
    import unittest
    class TestUpdateQueryParams(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_update_query_params(self):
            self.assertEqual(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')), 'http://example.com?biz=baz&foo=stuff')

    unittest.main()


# Generated at 2022-06-24 03:25:14.332169
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/'
    url = update_query_params(url, {'foo': 'bar'})
    assert url == 'http://example.com/?foo=bar'
    url = update_query_params(url, {'foo': 'stuff'})
    assert url == 'http://example.com/?foo=stuff'
    url = update_query_params(url, {'biz': 'baz'})
    assert url == 'http://example.com/?foo=stuff&biz=baz'
    url = update_query_params(url, {'foo': None})
    assert url == 'http://example.com/?biz=baz'


# Generated at 2022-06-24 03:25:21.006074
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/api/v1/search/'
    params = {'param1': '1', 'param2': '2'}
    new_url = update_query_params(url, params, doseq=True)
    assert new_url == 'http://example.com/api/v1/search/?param1=1&param2=2'
    new_url = update_query_params(new_url, {'param2': '3'})
    assert new_url == 'http://example.com/api/v1/search/?param1=1&param2=3'



# Generated at 2022-06-24 03:25:28.535091
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# For the curious:
# def update_query_params_wtf(url, **kwargs):
#     """
#     Update and/or insert query parameters in a URL.
#
#     >>> update_query_params_wtf('http://example.com?foo=bar&biz=baz', foo='stuff')
#     'http://example.com?...foo=stuff...'
#
#     :param url: URL
#     :type url: str
#     :param kwargs: Query parameters
#     :type kwargs: dict
#     :return: Modified URL
#     :rtype: str
#     """

# Generated at 2022-06-24 03:25:38.468368
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://www.example.com/query.html?a=1&b=2', dict(z=3)) == \
            'http://www.example.com/query.html?a=1&b=2&z=3'
    assert update_query_params('http://www.example.com/query.html?a=1&b=2', dict(a=3)) == \
            'http://www.example.com/query.html?a=3&b=2'
    assert update_query_params('http://www.example.com/query.html?a=1&b=2', dict(a=3,b=4)) == \
            'http://www.example.com/query.html?a=3&b=4'


# Generated at 2022-06-24 03:25:44.582424
# Unit test for function update_query_params
def test_update_query_params():
    query_string = 'foo=bar&foo=baz&biz=baz'
    url = 'http://example.com?' + query_string
    url2 = update_query_params(url, dict(foo='stuff'))
    assert url != url2
    assert urlparse.parse_qs(urlparse.urlsplit(url2)[3]) == {'foo': ['stuff'], 'biz': ['baz']}

# Generated at 2022-06-24 03:25:53.479211
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               dict(foo='stuff',
                                    other='value')) == 'http://example.com?other=value&foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               dict(foo='stuff',
                                    other='value')) == 'http://example.com?other=value&foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               dict(foo='stuff',
                                    other='value'),
                               doseq=False) == 'http://example.com?biz=baz&foo=stuff&other=value'
    assert update_query_

# Generated at 2022-06-24 03:25:59.779816
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    result = update_query_params(url, params)

    # Test for manipulable URL string
    assert isinstance(result, str)

    # Test for expected results
    assert result == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:26:05.937395
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff'])) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:26:13.065645
# Unit test for function update_query_params
def test_update_query_params():

    test_url = 'http://example.com?foo=bar&biz=baz'
    expected_url = 'http://example.com?biz=baz&foo=stuff'

    test_url = update_query_params(test_url, dict(foo='stuff'))

    if test_url != expected_url:
        raise AssertionError('update_query_params should have returned %s but '
                             'returned %s' % (expected_url, test_url))

    test_url = 'http://example.com?foo=bar&biz=baz'
    expected_url = 'http://example.com?biz=baz&foo=bar&biz=stuff'

    test_url = update_query_params(test_url, dict(biz='stuff'))


# Generated at 2022-06-24 03:26:18.166264
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com/path?foo=stuff&foo=stuff2&biz=baz' == update_query_params(
        'http://example.com/path?foo=bar&foo=bar2&biz=baz',
        dict(foo=['stuff', 'stuff2'])
    )

# Generated at 2022-06-24 03:26:20.382496
# Unit test for function update_query_params
def test_update_query_params():
    # TODO
    pass


#
# Strip out private data (for example, passwords) from an ElementTree.
#

# Generated at 2022-06-24 03:26:26.032962
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('/', {'biz': 'foo'}) == '/?biz=foo'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:26:36.739943
# Unit test for function update_query_params
def test_update_query_params():
    import unittest

    class UrlparseTest(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_update_query_params(self):
            url = "http://example.com?foo=bar&biz=baz"
            params = {"foo": "stuff"}
            new_url = update_query_params(url, params)
            self.assertEqual("http://example.com?foo=stuff&biz=baz", new_url)

        def test_update_query_params_doseq(self):
            url = "http://example.com?foo=bar&biz=baz"
            params = {"foo": "stuff", "biz": "stuff"}
            new_url = update_query_params(url, params)
            self

# Generated at 2022-06-24 03:26:43.991214
# Unit test for function update_query_params
def test_update_query_params():
    params = {'foo': 1, 'biz': 2, 'baz': 3}
    url = 'http://example.com/index.html'

    url = update_query_params(url, params=params)
    assert url == 'http://example.com/index.html?biz=2&baz=3&foo=1'

    url = 'http://example.com/index.html?foo=bar&biz=baz'
    url = update_query_params(url, params=params)
    assert url == 'http://example.com/index.html?biz=2&baz=3&foo=bar&biz=baz'



# Generated at 2022-06-24 03:26:54.769796
# Unit test for function update_query_params
def test_update_query_params():
    assert "http://example.com?foo=stuff&biz=baz" == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert "http://example.com?foo=bar&biz=baz" == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='bar'))
    assert "http://example.com?foo=bar&biz=baz" == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='bar&biz=baz'))

# Generated at 2022-06-24 03:26:57.470008
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:27:03.402392
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    output = update_query_params(test_url, dict(foo='stuff', biz='bong'))
    print(output)
    # The print statement above should show:
    # http://example.com?foo=stuff&biz=bong

if __name__ == '__main__':
    test_update_query_params()


# Generated at 2022-06-24 03:27:09.704755
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'


# Generated at 2022-06-24 03:27:20.905573
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz&baz=biz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz&baz=biz'
    assert update_query_params(url, dict(foo='stuff&biz=baz', biz='baz')) == 'http://example.com?foo=stuff%26biz%3Dbaz&biz=baz&baz=biz'
    assert update_query_params(url, dict(foo='stuff&biz=baz', biz='baz'), doseq=False) == 'http://example.com?foo=stuff%26biz%3Dbaz&biz=baz&baz=biz'
    

# ==============================================================================
# Fixture for http server

# Generated at 2022-06-24 03:27:26.445141
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'
    print("OK")

test_update_query_params()

# Generated at 2022-06-24 03:27:29.645287
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')

    assert update_query_params(url, params) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-24 03:27:38.775051
# Unit test for function update_query_params
def test_update_query_params():
    import pytest
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(spam='eggs')) == 'http://example.com?biz=baz&foo=bar&spam=eggs'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', spam='eggs')) == 'http://example.com?biz=baz&foo=stuff&spam=eggs'

# Generated at 2022-06-24 03:27:49.022774
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com'
    params = dict(foo='bar', biz='baz')
    new_url = update_query_params(url, params)

    assert new_url == 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(new_url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(new_url, dict(buz='stuff')) == 'http://example.com?biz=baz&foo=bar&buz=stuff'
    assert update_query_params(new_url, dict(), doseq=False) == 'http://example.com?biz=baz&foo=bar'
    

########################################################################
#                              Functions
########################################################################


# Generated at 2022-06-24 03:27:52.929738
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == "http://example.com?foo=stuff&biz=baz"


# Generated at 2022-06-24 03:27:57.369390
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    url = update_query_params(url, params, doseq=True)
    assert url == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:28:02.301592
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com/foo?test=test&test1=test1"
    url_new = update_query_params(url, {'test': 'test_new', 'test2': 'test2'})
    print(url_new)


if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:28:08.021751
# Unit test for function update_query_params
def test_update_query_params():
    url = update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff', test='case'),
    )
    assert url == 'http://example.com?foo=stuff&biz=baz&test=case',\
        'Expected {}, got {}'.format('http://example.com?foo=stuff...', url)

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:28:16.121746
# Unit test for function update_query_params
def test_update_query_params():
    url = 'https://www.googleapis.com/geolocation/v1/geolocate'
    params = {"key": "AIzaSyB6Q1U6BEK9_LsYnJ1T6NnSjKdIiRO-kSM"}
    result = update_query_params(url, params)
    print(result)
    assert result == 'https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyB6Q1U6BEK9_LsYnJ1T6NnSjKdIiRO-kSM'

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:28:22.008605
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test function update_query_params
    """
    assert(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))) == 'http://example.com?biz=baz&foo=stuff'
    assert(update_query_params('http://example.com', dict(foo='stuff'))) == 'http://example.com?foo=stuff'

if __name__ == '__main__':
    """
    Main entry point of the script
    """
    test_update_query_params()

# Generated at 2022-06-24 03:28:24.888628
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:28:36.209901
# Unit test for function update_query_params
def test_update_query_params():
    url_1 = 'http://www.test.com?test=test'
    url_2 = 'http://www.test.com?test=test&test2=test2'
    url_3 = 'http://www.test.com?test=test&test2=test2&test3=test3'

    assert update_query_params(url_1, dict(test2='test2')) == url_2
    assert update_query_params(url_2, dict(test='test')) == url_2
    assert update_query_params(url_2, dict(test='stuff')) == 'http://www.test.com?test=stuff&test2=test2'

# Generated at 2022-06-24 03:28:41.293638
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# debug purpose
if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:28:49.516067
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params("http://example.com", {'foo': 'bar'}) ==
           "http://example.com?foo=bar")
    assert(update_query_params("http://example.com?foo=bar&biz=baz",
                               {'foo': 'stuff'}) ==
           "http://example.com?biz=baz&foo=stuff")
    assert(update_query_params("http://example.com?a=b%20c&biz=baz",
                               {'foo': 'stuff'}) ==
           "http://example.com?a=b+c&biz=baz&foo=stuff")

# Generated at 2022-06-24 03:28:58.878820
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test for function update_query_params
    """
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz=['baz', 'foo'])) == 'http://example.com?biz=baz&biz=foo&foo=bar'

# Generated at 2022-06-24 03:29:03.105530
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:29:06.798082
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    
test_update_query_params()
 

# Generated at 2022-06-24 03:29:15.102015
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))

#test_update_query_params()

# Generated at 2022-06-24 03:29:24.398329
# Unit test for function update_query_params
def test_update_query_params():
    # handle url containing query parameters
    url = 'http://example.com?foo=bar&biz=baz'
    ret = update_query_params(url, {'foo': 'stuff'})
    expected = 'http://example.com?foo=stuff&biz=baz'
    assert ret == expected

    # handle url not containing query parameters
    url = 'http://example.com'
    ret = update_query_params(url, {'foo': 'stuff'})
    expected = 'http://example.com?foo=stuff'
    assert ret == expected

    # handle url containing query parameters and path
    url = 'http://example.com/foo/bar?foo=bar&biz=baz'
    ret = update_query_params(url, {'foo': 'stuff'})

# Generated at 2022-06-24 03:29:27.644128
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:29:36.588997
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    expected = 'http://example.com?biz=baz&foo=stuff'
    result = update_query_params(url, params)
    assert result == expected

    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff', 'baz': None}
    expected = 'http://example.com?biz=baz&foo=stuff&baz'
    result = update_query_params(url, params)
    assert result == expected

# Generated at 2022-06-24 03:29:46.257121
# Unit test for function update_query_params
def test_update_query_params():
    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert url == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url, dict(foo='morestuff')) == 'http://example.com?foo=morestuff&biz=baz'
    assert update_query_params(url, dict(foo='morestuff', new='spam')) == 'http://example.com?foo=morestuff&biz=baz&new=spam'


# Unit tests
if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:29:56.157600
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://www.example.com/path/to/page.html?key1=value1&key2=value2&key3=value3"
    url_modified = update_query_params(
        url=url,
        params=dict(key1="value1_modified", key2="value2_modified", key3="value3_modified")
    )
    assert url_modified == "http://www.example.com/path/to/page.html?key1=value1_modified&key2=value2_modified&key3=value3_modified"

# Run unit tests
if __name__ == "__main__":
    import unittest
    import doctest
    doctest.testmod(verbose=False)

    # Run unit tests
    unittest.main()

# Generated at 2022-06-24 03:30:05.160589
# Unit test for function update_query_params
def test_update_query_params():

    url_old = 'http://example.com?foo=bar&biz=baz'
    url_new = update_query_params(url_old, dict(foo='stuff'))
    assert_equal(url_new, 'http://example.com?foo=stuff&biz=baz')

    url_old = 'http://example.com?foo=bar&biz=baz'
    url_new = update_query_params(url_old, dict(foo='stuff', biz='bip'))
    assert_equal(url_new, 'http://example.com?foo=stuff&biz=bip')

    url_old = 'http://example.com?foo=bar&biz=baz'

# Generated at 2022-06-24 03:30:10.073054
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'

    kwargs = dict(foo='stuff')
    new_url = update_query_params(url, params=kwargs)
    assert new_url == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-24 03:30:19.109948
# Unit test for function update_query_params
def test_update_query_params():

    def assert_equal(l, r):
        assert l == r, '%s != %s' % (l, r)

    assert_equal(
        update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}),
        'http://example.com?foo=stuff&biz=baz'
    )

    assert_equal(
        update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'baz': 'quux'}),
        'http://example.com?foo=stuff&biz=baz&baz=quux'
    )


# Generated at 2022-06-24 03:30:24.958075
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected = 'http://example.com?biz=baz&foo=stuff'
    result = update_query_params(url, params)
    assert result == expected

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:30:34.150552
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {'foo': 'bar'}) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(foo='bar', biz='baz')) == 'http://example.com?biz=baz&foo=bar'



# Generated at 2022-06-24 03:30:41.280236
# Unit test for function update_query_params
def test_update_query_params():
    # Test missing query string
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'

    # Test empty query string
    assert update_query_params('http://example.com?', dict(foo='bar')) == 'http://example.com?foo=bar'

    # Test different dictionary key types

# Generated at 2022-06-24 03:30:49.574962
# Unit test for function update_query_params
def test_update_query_params():
    url_test = 'http://example.com?foo=bar&biz=baz'
    kwargs_test = dict(foo='stuff')
    uqp = update_query_params(url_test, kwargs_test)
    assert uqp == 'http://example.com?biz=baz&foo=stuff'

    url_test = 'http://example.com'
    kwargs_test = dict(foo='stuff')
    uqp = update_query_params(url_test, kwargs_test)
    assert uqp == 'http://example.com?foo=stuff'

    url_test = 'http://example.com?foo=bar&biz=baz'
    kwargs_test = dict(foo=['stuff', 'morestuff'])
    uqp = update_query_

# Generated at 2022-06-24 03:31:00.966293
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='stuff')) == 'http://example.com?biz=stuff&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='stuff'), doseq=False) == 'http://example.com?foo=stuff'

# Generated at 2022-06-24 03:31:05.289372
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    new_url = update_query_params(url, {"foo":"stuff"})
    expected = "http://example.com?foo=stuff&biz=baz"
    assert new_url == expected



# Generated at 2022-06-24 03:31:09.010443
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:31:15.670370
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/foo?key=val'
    url = update_query_params(url, {'foo': 'bar', 'key': 'new'})

    assert url == 'http://example.com/foo?foo=bar&key=new'

# Given a URL like http://example.com/foo?key=val,
# return the value of the parameter 'key'.
# Uses function update_query_params (above).

# Generated at 2022-06-24 03:31:24.244576
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://localhost?foo=bar', dict(foo='stuff')) == 'http://localhost?foo=stuff'
    assert update_query_params('http://localhost?foo=bar', dict(foo='stuff', biz='baz')) == 'http://localhost?foo=stuff&biz=baz'
    assert update_query_params('http://localhost?foo=bar', dict(foo='stuff', biz=['baz'])) == 'http://localhost?foo=stuff&biz=baz'
    assert update_query_params('http://localhost?foo=bar', dict(foo='stuff', biz=['baz', 'biz'])) == 'http://localhost?foo=stuff&biz=baz&biz=biz'

# Generated at 2022-06-24 03:31:29.945686
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected_url = 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == expected_url, 'Wrong new URL'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:31:37.520185
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='foo')) == 'http://example.com?bar=foo&biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'bar']), doseq=False) == 'http://example.com?biz=baz&foo=stuff&foo=bar'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:31:41.262137
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected_url = 'http://example.com?biz=baz&foo=stuff'

    assert update_query_params(url, params) == expected_url

# Generated at 2022-06-24 03:31:47.703070
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected_url = 'http://example.com?foo=stuff&biz=baz'
    url = update_query_params(url, params)
    assert url == expected_url, 'Expected "%s", got "%s"' % (expected_url, url)

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:31:53.116898
# Unit test for function update_query_params
def test_update_query_params():
    # Testing the results of update_query_params function
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:31:57.522082
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    
test_update_query_params()

# Generated at 2022-06-24 03:32:07.683974
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='biz')) == 'http://example.com?foo=stuff&biz=biz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(stuff='biz')) == 'http://example.com?foo=bar&biz=baz&stuff=biz'
    assert update_query_params('http://example.com', dict(foo='stuff', biz='biz')) == 'http://example.com?foo=stuff&biz=biz'

# Generated at 2022-06-24 03:32:19.039488
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz=['baz','buz','boo'])) == 'http://example.com?foo=bar&biz=baz&biz=buz&biz=boo'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), False) == 'http://example.com?foo=bar&foo=stuff&biz=baz'

# Generated at 2022-06-24 03:32:22.197375
# Unit test for function update_query_params
def test_update_query_params():
    input = ('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    result = update_query_params(*input)
    assert result == 'http://example.com?biz=baz&foo=stuff'

test_update_query_params()

# Generated at 2022-06-24 03:32:30.301989
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'


if __name__ == '__main__':
    # Unit tests
    test_update_query_params()

# Generated at 2022-06-24 03:32:34.359843
# Unit test for function update_query_params
def test_update_query_params():
    return

if __name__ == '__main__':
    import sys
    import doctest

    if len(sys.argv) == 1:
        doctest.testmod()
    else:
        for arg in sys.argv[1:]:
            doctest.run_docstring_examples(__import__(arg).__doc__, globals())

# Generated at 2022-06-24 03:32:45.741000
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz&foo=bak'
    params = dict(foo='stuff', biz='bizzzz')
    assert update_query_params(url, params) == 'http://example.com?foo=stuff&biz=bizzzz'

    # Query parameters in the URL are overwritten
    url = 'http://example.com?foo=bar&biz=baz&foo=bak'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == 'http://example.com?foo=stuff'

    # Query parameter with a list value in the URL
    url = 'http://example.com?foo=bar&biz=baz&foo=bak'
    # Lists are encoded by urlparse as "['foo', 'bar']",

# Generated at 2022-06-24 03:32:50.454127
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:32:53.739303
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'




# Example of using check_output function

# Generated at 2022-06-24 03:33:00.048785
# Unit test for function update_query_params
def test_update_query_params():
    # Test 1
    assert update_query_params('http://example.com', {'a': 1}) == 'http://example.com?a=1'
    # Test 2
    assert update_query_params('http://example.com?a=1&b=2', {'b': 3, 'c': 4}) == 'http://example.com?a=1&b=3&c=4'
    # Test 3
    assert update_query_params('http://example.com?a=1&b=2&b=3', {'b': 4, 'c': 5}) == 'http://example.com?a=1&b=4&c=5'

# Generated at 2022-06-24 03:33:03.398207
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    test_params = {'foo': 'stuff'}
    new_url = update_query_params(test_url, test_params)
    print(new_url)



# Generated at 2022-06-24 03:33:11.652420
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=bar&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='bar', biz='baz'))
    assert 'http://example.com?foo=bar&biz=baz&foo=stuff' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert 'http://example.com?foo=bar&biz=baz&stuff=1' == update_query_params('http://example.com?foo=bar&biz=baz', dict(stuff='1'))

# Generated at 2022-06-24 03:33:19.425583
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?biz=baz&foo=stuff'
    new_url = update_query_params(url, dict(foobar='stuff'))
    assert new_url == 'http://example.com?biz=baz&foo=bar&foobar=stuff'
    new_url = update_query_params(url, dict(biz='stuff'))
    assert new_url == 'http://example.com?biz=stuff&foo=bar'



# Generated at 2022-06-24 03:33:24.179226
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# TEST CODE

# Generated at 2022-06-24 03:33:34.096576
# Unit test for function update_query_params
def test_update_query_params():
    # Test with empty URL
    if update_query_params("", {"foo": "stuff"}) != "?foo=stuff":
        print("Test 1 of 3 failed")
    # Test with 1 query parameter in the URL
    if update_query_params("?foo=bar", {"foo": "stuff"}) != "?foo=stuff" \
            and update_query_params("?foo=bar", {"foo": "stuff"}) != "?foo=bar&foo=stuff":
        print("Test 2 of 3 failed")
    # Test with several query parameters in the URL, one to be replaced, the other two to be added

# Generated at 2022-06-24 03:33:42.933145
# Unit test for function update_query_params
def test_update_query_params():
    # Basic usage with existing query parameters
    assert update_query_params(
        'https://www.google.pl?foo=bar&biz=baz', dict(foo='stuff')) == \
        'https://www.google.pl?foo=stuff&biz=baz'
    # Update a parameter with multiple values
    assert update_query_params(
        'https://www.google.pl?foo=bar&foo=baz', dict(foo='stuff')) == \
        'https://www.google.pl?foo=stuff'
    # Insert a new parameter
    assert update_query_params(
        'https://www.google.pl?foo=bar', dict(biz='baz')) == \
        'https://www.google.pl?foo=bar&biz=baz'
    # Only change query parameters

# Generated at 2022-06-24 03:33:51.184783
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baz2')) == 'http://example.com?biz=baz2&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz&baz=baz2', dict(foo='stuff', biz='baz2', fare='beef')) == 'http://example.com?baz=baz2&biz=baz2&fare=beef&foo=stuff'

# Generated at 2022-06-24 03:34:01.045204
# Unit test for function update_query_params

# Generated at 2022-06-24 03:34:07.875230
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz&foo=meh', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-24 03:34:12.035537
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:34:15.116237
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:34:25.425609
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='stuff')) == 'http://example.com?biz=stuff&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(stuff='stuff')) == 'http://example.com?biz=baz&foo=bar&stuff=stuff'

# Generated at 2022-06-24 03:34:29.096450
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    expected = 'http://example.com?biz=baz&foo=stuff'
    computed = update_query_params(url, params)
    assert computed == expected