

# Generated at 2022-06-24 03:24:38.037437
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'bar': ['spam', 'eggs']}) == 'http://example.com?bar=spam&bar=eggs&biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': ['stuff', 'more']}) == 'http://example.com?biz=baz&foo=stuff&foo=more'

# Generated at 2022-06-24 03:24:43.426279
# Unit test for function update_query_params
def test_update_query_params():
        assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-24 03:24:47.402399
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test the function update_query_params using doctests.

    :return: None
    :rtype: NoneType
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:24:53.103326
# Unit test for function update_query_params
def test_update_query_params():

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?foo=stuff&biz=buzz'

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff'])) == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-24 03:25:04.692349
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=bar&biz=baz' == update_query_params('http://example.com?foo=stuff&biz=baz', {'foo':'bar'})
    assert 'http://example.com?foo=bar&biz=baz' == update_query_params('http://example.com?foo=stuff&biz=baz', {'foo':'bar'}, doseq = False)
    assert 'http://example.com?foo=bar&biz=baz&baz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', {'baz':'baz'})

# Generated at 2022-06-24 03:25:09.143118
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    

# Test run
test_update_query_params()

# Run via "python -m doctest update_query_params.py"

# Generated at 2022-06-24 03:25:19.340288
# Unit test for function update_query_params
def test_update_query_params():

    assert 'http://example.com?foo=a&biz=baz' == update_query_params(
        'http://example.com?foo=bar&biz=baz', {'foo': 'a'}
    )
    assert 'http://example.com?foo=a&foo=b&biz=baz' == update_query_params(
        'http://example.com?foo=bar&biz=baz', {'foo': ['a', 'b']}
    )
    assert 'http://example.com?foo=a&foo=b&biz=baz' == update_query_params(
        'http://example.com?foo=bar&biz=baz', {'foo': 'a', 'foo': 'b'}
    )

# Generated at 2022-06-24 03:25:25.554778
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', dict(bar='foo')) == 'http://example.com?foo=bar&bar=foo'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'

# Generated at 2022-06-24 03:25:38.123294
# Unit test for function update_query_params
def test_update_query_params():
    # sets the values of the query string to expected values
    assert update_query_params('http://example.com?a=1&b=2', dict(b=3, c=4)) == 'http://example.com?a=1&c=4&b=3'
    assert update_query_params('http://example.com?a=1&b=2', {'b': 3, 'c': 4}) == 'http://example.com?a=1&c=4&b=3'  # pass params as a list
    assert update_query_params('http://example.com?a=1&b=2', {'b': 3, 'c': 4}, doseq=False) == 'http://example.com?a=1&b=3&c=4'

    # in the case of duplicate values, the new value takes

# Generated at 2022-06-24 03:25:43.711273
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-24 03:25:48.206883
# Unit test for function update_query_params
def test_update_query_params():
    params = dict(foo='stuff')
    assert update_query_params('http://example.com?foo=bar&biz=baz', params) == 'http://example.com?biz=baz&foo=stuff'


import cStringIO


# Generated at 2022-06-24 03:25:57.077160
# Unit test for function update_query_params
def test_update_query_params():
    assert (
        update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) ==
        'http://example.com?biz=baz&foo=stuff'
    )
    assert (
        update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff'])) ==
        'http://example.com?biz=baz&foo=stuff'
    )
    assert (
        update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'bar'])) ==
        'http://example.com?biz=baz&foo=stuff&foo=bar'
    )

# Generated at 2022-06-24 03:26:03.661899
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', test='thing')) == 'http://example.com?foo=stuff&biz=baz&test=thing'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:26:07.006156
# Unit test for function update_query_params
def test_update_query_params():
    assert 'https://example.com/?foo=stuff&biz=baz' == update_query_params('https://example.com/?foo=bar&biz=baz', {'foo': 'stuff'})

# Generated at 2022-06-24 03:26:16.560977
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
test_update_query_params()
# Import requests library
import requests
try:
    from urllib import urlencode
    from urlparse import parse_qs
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qs

# Set the request parameters
#url = 'https://cambio.la/?view=currency_exchange_rates&rest_route=/'
#url = 'https://cambio.la/?rest_route=/wallets/'
url = 'https://cambio.la/wallets/?rest_route=/wallets/'

# Make sure to

# Generated at 2022-06-24 03:26:20.435231
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:26:28.064831
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/user?foo=bar&biz=baz&biz=bat'
    expected = 'http://example.com/user?foo=stuff&biz=bat'
    assert update_query_params(url, dict(foo='stuff')) == expected

    expected = 'http://example.com/user?foo=bar&biz=bat&foo=stuff'

# Generated at 2022-06-24 03:26:34.443694
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff', bar=1))
    assert new_url == 'http://example.com?bar=1&biz=baz&foo=stuff'
    return new_url

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:26:41.070293
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    """
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    result = update_query_params(url, params)
    if result == 'http://example.com?foo=stuff&biz=baz':
        pass
    else:
        print('test_update_query_params() failed')

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 03:26:46.953861
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='junk')) == 'http://example.com?foo=stuff&biz=junk'

# Generated at 2022-06-24 03:26:55.648141
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('foo=bar&biz=buz', {'foo': 'stuff', 'fire': 'ice'}) == 'biz=buz&foo=stuff&fire=ice'
    assert update_query_params('foo=bar&biz=buz', {'on': 'on'}) == 'biz=buz&foo=bar&on=on'
    assert update_query_params('foo=bar&biz=buz', {'foo': 'stuff'}) == 'biz=buz&foo=stuff'
    assert update_query_params('foo=bar&foo=buz', {'foo': 'stuff'}) == 'foo=stuff&foo=buz'


# Generated at 2022-06-24 03:27:03.508954
# Unit test for function update_query_params
def test_update_query_params():
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz')
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff&biz=bar')) == 'http://example.com?foo=stuff%26biz%3Dbar&biz=baz')
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='bar')) == 'http://example.com?foo=stuff&biz=bar')
    # Test with an empty dictionary

# Generated at 2022-06-24 03:27:14.836732
# Unit test for function update_query_params
def test_update_query_params():
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='stuff')))
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='stuff', foo='stuff')))
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='stuff', foo='stuff', new='stuff')))
    print(update_query_params('http://example.com?foo=', dict(biz='stuff', foo='stuff', new='stuff')))

# Generated at 2022-06-24 03:27:22.157290
# Unit test for function update_query_params
def test_update_query_params():
    # pycharm non-zero exit code
    import sys
    sys.exit = lambda *args, **kwargs: sys.exit(0)

    # pytest args
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', help='url to test')
    parser.add_argument('--params', help='parameters to test')
    args = parser.parse_args()

    # args
    url = args.url
    params = args.params

    # test
    print(update_query_params(url, params))

# Generated at 2022-06-24 03:27:30.307017
# Unit test for function update_query_params
def test_update_query_params():
    # test changing existing query
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz'

    # test adding query
    assert update_query_params('http://example.com?foo=bar', {'biz': 'baz'}) == 'http://example.com?foo=bar&biz=baz'

    # test overwriting query & adding new query
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'fred': 'blog'}) == 'http://example.com?foo=stuff&biz=baz&fred=blog'

    # test with lists

# Generated at 2022-06-24 03:27:36.619335
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?1=something&2=[2,2]"

# Generated at 2022-06-24 03:27:45.186761
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz&buz=buz'
    params = {'foo': 'stuff'}
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?buz=buz&foo=stuff&biz=baz'
    params = {'foo': 'evenmoar'}
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?buz=buz&foo=evenmoar&biz=baz'

# https://github.com/un33k/django-p3p/blob/master/p3p/templatetags/p3p.py


# Generated at 2022-06-24 03:27:52.329952
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test for function update_query_params
    """
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='foo')) == 'http://example.com?bar=foo&biz=baz&foo=stuff'



# Generated at 2022-06-24 03:27:55.948899
# Unit test for function update_query_params
def test_update_query_params():
    result = update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff'))
    assert result == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:28:02.976909
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz&biz=baz2'
    assert update_query_params(url, params=dict(foo='stuff')) == 'http://example.com?biz=baz&biz=baz2&foo=stuff'
    assert update_query_params(url, params=dict(foo='stuff', bar=['biz'])) == 'http://example.com?bar=biz&biz=baz&biz=baz2&foo=stuff'



# Generated at 2022-06-24 03:28:07.403062
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://www.example.com?cat=true&dog=false'
    new_url = update_query_params(test_url, dict(cat='false'))
    assert new_url == 'http://www.example.com?cat=false&dog=false'

# Generated at 2022-06-24 03:28:10.890709
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-24 03:28:18.430685
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, {'biz': 'stuff'}) == 'http://example.com?biz=stuff&foo=bar'
    assert update_query_params(url, {'foo': 'stuff', 'biz': 'stuff'}) == 'http://example.com?biz=stuff&foo=stuff'



# Generated at 2022-06-24 03:28:24.674563
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    test_params = {'foo': 'stuff'}
    expected_result = 'http://example.com?foo=stuff&biz=baz'

    result = update_query_params( test_url, test_params)
    if result != expected_result:
        raise ValueError("update_query_params failed")
    else:
        print("update_query_params passed")



# Generated at 2022-06-24 03:28:36.023626
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff', biz='buh')
    ) == 'http://example.com?biz=buh&foo=stuff'

    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff', biz='buh', new='param')
    ) == 'http://example.com?biz=buh&foo=stuff&new=param'


# Generated at 2022-06-24 03:28:47.337977
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?foo=stuff&biz=buzz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='buzz')) == 'http://example.com?foo=stuff&biz=baz&bar=buzz'

# Generated at 2022-06-24 03:28:55.924458
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    updated_url = update_query_params(url, dict(foo='stuff'))
    assert urlparse.urlparse(updated_url).query == 'foo=stuff&biz=baz'

    url = 'http://example.com?test1=1&test2=2'
    updated_url = update_query_params(url, dict(test1='1', test2='2'))
    assert urlparse.urlparse(updated_url).query == 'test1=1&test2=2'


# Generated at 2022-06-24 03:28:58.466357
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-24 03:29:05.747784
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz'), False) == 'http://example.com?biz=buzz&foo=stuff'
    return True


# Generated at 2022-06-24 03:29:08.781360
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
        'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-24 03:29:19.033774
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    result = 'http://example.com?foo=stuff&biz=baz'
    assert result == update_query_params(url, params)

    params = dict(biz='foobar')
    result = 'http://example.com?foo=stuff&biz=foobar'
    assert result == update_query_params(url, params)

    params = dict(biz='foobar', zoo='baz')
    result = 'http://example.com?foo=stuff&biz=foobar&zoo=baz'
    assert result == update_query_params(url, params)

# Generated at 2022-06-24 03:29:22.877669
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:29:26.763384
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:29:29.970115
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:29:35.490907
# Unit test for function update_query_params
def test_update_query_params():
    assert "http://example.com?foo=stuff" == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert "http://example.com?foo=stuff&biz=baz" == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), False)

# Generated at 2022-06-24 03:29:40.904159
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected = 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url, params) == expected


# Template tag to include a rendered template in a template

# Generated at 2022-06-24 03:29:45.172013
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:29:48.782657
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:29:59.803722
# Unit test for function update_query_params
def test_update_query_params():
    """
    Python unit test for function update_query_params
    """
    # Test one argument
    url_arg = 'http://example.com?foo=bar&biz=baz'
    url_kwargs = dict(foo='stuff')
    url_result = update_query_params(url_arg, url_kwargs)
    url_check = 'http://example.com?biz=baz&foo=stuff'
    assert url_result == url_check, \
        "Expected {0}, got {1}".format(url_check, url_result)

    # Test two arguments
    url_arg = 'http://example.com?foo=bar&biz=baz'
    url_kwargs = dict(foo='stuff', biz='barf')

# Generated at 2022-06-24 03:30:09.725896
# Unit test for function update_query_params
def test_update_query_params():
    # The next two lines are merely to quiet down the
    # 'ResourceWarning: unclosed <socket.socket ...>'
    # messages generated by calling urllib.request.urlopen().
    import gc
    gc.collect()

    url = "http://example.com?foo=bar&biz=baz"
    assert url == update_query_params(url, {});
    url = "http://example.com?foo=bar&biz=baz"
    assert "http://example.com?biz=baz&foo=stuff" == update_query_params(url, {'foo': 'stuff'})
    url = "http://example.com?foo=bar&biz=baz"

# Generated at 2022-06-24 03:30:14.986426
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == "http://example.com?biz=baz&foo=stuff"
    assert update_query_params("http://example.com?foo=bar&biz=baz", {"foo": "stuff"}) == "http://example.com?biz=baz&foo=stuff"

# Generated at 2022-06-24 03:30:20.642227
# Unit test for function update_query_params
def test_update_query_params():
    url='http://example.com?foo=bar&biz=baz'
    print(url)
    print(update_query_params(url,  dict(foo= 'stuff')))
    print(update_query_params(url,  dict(foo= 'stuff')))
    print(update_query_params(url,  dict(foo= 'stuff')))
    print(update_query_params(url,  dict(foo= 'stuff')))

print('----------')
test_update_query_params()
print('----------')

# Generated at 2022-06-24 03:30:27.271985
# Unit test for function update_query_params
def test_update_query_params():
  assert update_query_params('https://stackoverflow.com?foo=bar&biz=baz', dict(foo='stuff')) == 'https://stackoverflow.com?biz=baz&foo=stuff'

# Test function
test_update_query_params()

# Generated at 2022-06-24 03:30:30.078667
# Unit test for function update_query_params
def test_update_query_params():
    if not 'example.com' in update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')):
        raise Exception("test_update_query_params failed!")


# Generated at 2022-06-24 03:30:34.521648
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert 'http://example.com?foo=stuff' == update_query_params(url, dict(foo='stuff'))
    assert 'http://example.com?foo=stuff&biz=baz' == update_query_params(url, dict(foo='stuff'))


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:30:40.387289
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected = 'http://example.com?biz=baz&foo=stuff'
    result = update_query_params(url, dict(foo='stuff'))
    assert result == expected



# Generated at 2022-06-24 03:30:48.620656
# Unit test for function update_query_params
def test_update_query_params():
    url = 'https://example.com'
    assert url == update_query_params(url, {})
    url = 'https://example.com?'
    assert url == update_query_params(url, {})
    url = 'https://example.com?'
    assert url == update_query_params(url, {})
    url = 'https://example.com?foo=bar'
    assert update_query_params(url, {}) == 'https://example.com?foo=bar'
    assert update_query_params(url, {'foo': 'baz'}) == 'https://example.com?foo=baz'
    assert update_query_params(url, {'foo': 'baz'}) == 'https://example.com?foo=baz'

# Generated at 2022-06-24 03:30:53.774736
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': "stuff", 'baz': 'new'}
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?biz=baz&foo=stuff&baz=new'



# Generated at 2022-06-24 03:31:01.913127
# Unit test for function update_query_params
def test_update_query_params():
    result = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert result == 'http://example.com?biz=baz&foo=stuff'

    result = update_query_params('http://example.com?foo=abc&foo=xyz&foo=stuff&biz=baz', dict(foo='bar'))
    assert result == 'http://example.com?biz=baz&foo=bar'


if __name__ == '__main__':
    # Run unit tests if invoked directly
    test_update_query_params()

# Generated at 2022-06-24 03:31:05.510544
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:31:09.212258
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    new_url = update_query_params(url, dict(foo="stuff"))

# The actual query used in the function

# Generated at 2022-06-24 03:31:19.912808
# Unit test for function update_query_params
def test_update_query_params():
    # No params
    assert update_query_params('http://foo.com', {}) == 'http://foo.com'

    # Dict
    assert update_query_params('http://foo.com', {'a': 'b'}) == 'http://foo.com?a=b'
    assert update_query_params('http://foo.com', {'a': 'b', 'c': 'd'}) == 'http://foo.com?a=b&c=d'
    assert update_query_params('http://foo.com', {'a': ['b', 'c']}) == 'http://foo.com?a=b&a=c'

    # Nested dict

# Generated at 2022-06-24 03:31:29.797059
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    test_params = dict(foo='stuff')
    assert (update_query_params(test_url, test_params) ==
            'http://example.com?biz=baz&foo=stuff#')
    test_params = dict(foo={'stuff', 'things'})
    assert (update_query_params(test_url, test_params) ==
            'http://example.com?biz=baz&foo=stuff&foo=things#')
    test_params = dict(foo='stuff', biz=['baz', 'buzz'])
    assert (update_query_params(test_url, test_params) ==
            'http://example.com?biz=baz&biz=buzz&foo=stuff#')
   

# Generated at 2022-06-24 03:31:31.851817
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:31:35.124295
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert 'http://example.com?biz=baz&foo=stuff' == update_query_params(url, params)



# Generated at 2022-06-24 03:31:43.284469
# Unit test for function update_query_params
def test_update_query_params():
    # Simple example
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    # Merging multiple items
    assert update_query_params(
        'http://example.com?foo=bar', dict(foo='foo2', foo3='foo3')) == 'http://example.com?foo=foo2&foo3=foo3'
    # Multiple values for one argument
    assert update_query_params(
        'http://example.com?foo=bar', dict(foo=['foo2', 'foo3'])) == 'http://example.com?foo=foo2&foo=foo3'
    # Multiple values for one argument, disabling doseq

# Generated at 2022-06-24 03:31:53.606951
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff1', 'stuff2'])) == 'http://example.com?biz=baz&foo=stuff1&foo=stuff2'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff1'), doseq=False) == 'http://example.com?biz=baz&foo=stuff1'

# Generated at 2022-06-24 03:31:56.404792
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:32:00.316788
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    newurl = update_query_params(url, params)
    assert newurl == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-24 03:32:06.976942
# Unit test for function update_query_params
def test_update_query_params():
    url1 = 'https://example.com/foo?x=1&y=2'
    url2 = 'https://example.com/foo?x=1&y=2'
    assert(update_query_params(url1, dict(x=1)) == url2)
    assert(update_query_params(url1, dict(x=1, y=2)) == url2)
    assert(update_query_params(url1, dict(x=1, y=2, z=3)) != url2)

# Generated at 2022-06-24 03:32:14.256526
# Unit test for function update_query_params
def test_update_query_params():
    test_url = "http://example.com?foo=bar&biz=baz"
    assert update_query_params(test_url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

    test_url = "http://example.com?foo=bar&biz=baz"
    assert update_query_params(test_url, dict(foo='stuff', biz=['baz1', 'baz2'])) == 'http://example.com?biz=baz1&biz=baz2&foo=stuff'

    test_url = "http://example.com?foo=bar&biz=baz"

# Generated at 2022-06-24 03:32:23.794446
# Unit test for function update_query_params
def test_update_query_params():
    """
    Run a unit test for the function update_query_params.
    """
    # Case 1.
    #
    # functionality
    #
    url = 'http://www.google.com?foo=bar'
    url = update_query_params(url, dict(foo='stuff'))
    print(url)
    #
    # validate
    #
    assert url == 'http://www.google.com?foo=stuff'

    # Case 2.
    #
    # functionality
    #
    url = 'http://www.google.com?foo=bar'
    url = update_query_params(url, dict(baz='stuff'))
    print(url)
    #
    # validate
    #
    assert url == 'http://www.google.com?foo=bar&baz=stuff'


# Generated at 2022-06-24 03:32:33.592578
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz&foo=buzz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-24 03:32:38.833429
# Unit test for function update_query_params
def test_update_query_params():
    url = 'https://demo.docusign.net/restapi/v2/accounts/123/envelopes?count=1&include_metadata=true'
    params = {'count': '10'}
    new_url = update_query_params(url, params)
    print(new_url)


test_update_query_params()

# Generated at 2022-06-24 03:32:49.590747
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='bar')) ==\
        'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) ==\
        'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(zip=[])) ==\
        'http://example.com?foo=bar&zip='
    assert update_query_params('http://example.com?foo=bar&zip=', dict(zip=[])) ==\
        'http://example.com?foo=bar&zip='

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:32:57.282148
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', quux='quuux')) == 'http://example.com?biz=baz&foo=stuff&quux=quuux'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baz', quux='quuux')) == 'http://example.com?biz=baz&foo=stuff&quux=quuux'

# Generated at 2022-06-24 03:33:04.632337
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    url = update_query_params(url, params)
    assert url == 'http://example.com?foo=stuff&biz=baz', '%r != %r' % (url, 'http://example.com?foo=stuff&biz=baz')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:33:13.036414
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com'
    url2 = 'http://example.com?foo=bar&biz=baz'
    url3 = 'http://example.com?fo=bar&foo=baz'
    params = {'foo': 'stuff'}

    assert update_query_params(url, params) == 'http://example.com?foo=stuff'
    assert update_query_params(url2, params) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url3, params) == 'http://example.com?foo=stuff&fo=bar'



# Generated at 2022-06-24 03:33:24.516199
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com/foo/bar?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com/foo/bar?biz=baz&foo=stuff'
    assert update_query_params('http://example.com/foo/bar?biz=baz&foo=stuff', dict(foo='stuff2')) == 'http://example.com/foo/bar?biz=baz&foo=stuff2'
    assert update_query_params('http://example.com/foo/bar?biz=baz&foo=stuff', dict(foo2='stuff2')) == 'http://example.com/foo/bar?biz=baz&foo=stuff&foo2=stuff2'

# Generated at 2022-06-24 03:33:31.441733
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    updated_url = update_query_params(url, {"foo": "stuff"})
    expected = "http://example.com?biz=baz&foo=stuff"
    assert updated_url == expected, "Expected URL is %s, but got %s" % (expected, updated_url)



# Generated at 2022-06-24 03:33:34.048387
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-24 03:33:37.934212
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:33:42.315317
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:33:49.070335
# Unit test for function update_query_params
def test_update_query_params():
    for test_case in [
        ['http://example.com?foo=bar&biz=baz',
         {'foo': 'stuff'},
         'http://example.com?biz=baz&foo=stuff'],
        ['http://example.com',
         {'foo': 'stuff'},
         'http://example.com?foo=stuff']
        ]:
        assert update_query_params(*test_case[:-1]) == test_case[-1]

test_update_query_params()

# Generated at 2022-06-24 03:33:51.593247
# Unit test for function update_query_params
def test_update_query_params():
    """Test for function update_query_params"""
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-24 03:33:55.250659
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:33:57.045235
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-24 03:34:02.351552
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz&biz=bizbiz'
    updated_url = update_query_params(url, dict(
        foo='stuff',
        bing='baz',
        biz='junk',
    ), doseq=False)
    assert updated_url == 'http://example.com?foo=stuff&bing=baz&biz=junk', updated_url

# Generated at 2022-06-24 03:34:11.278693
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com?foo=bar&biz=baz", {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params("http://example.com?foo=bar&biz=baz", {'foo': 'stuff', 'foo2': 'stuff2'}) == 'http://example.com?biz=baz&foo=stuff&foo2=stuff2'
    assert update_query_params("http://example.com#bar", {'foo': 'stuff', 'foo2': 'stuff2'}) == 'http://example.com?foo=stuff&foo2=stuff2#bar'

# Generated at 2022-06-24 03:34:20.281612
# Unit test for function update_query_params
def test_update_query_params():
    from nose.tools import assert_equal
    assert_equal(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')), 'http://example.com?biz=baz&foo=stuff')
    assert_equal(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False), 'http://example.com?biz=baz&foo=stuff')

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:34:23.694319
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected_url = 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(foo='stuff')) == expected_url


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:34:32.583921
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&foo=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=[])) == 'http://example.com?foo=&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='whatever')) == 'http://example.com?foo=stuff&biz=baz&bar=whatever'
    assert update_query_