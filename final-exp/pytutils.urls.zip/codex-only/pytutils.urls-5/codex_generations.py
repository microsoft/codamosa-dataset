

# Generated at 2022-06-24 03:24:33.971748
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='buz')) == 'http://example.com?biz=buz&foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='buz', foo='stuff')) == 'http://example.com?biz=buz&foo=stuff'


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:24:39.731768
# Unit test for function update_query_params
def test_update_query_params():
    """Test for function update_query_params."""
    assert update_query_params("", {"foo": "bar"}) == "?foo=bar"
    assert update_query_params("", {"foo": [1, 2, 3]}) == "?foo=1&foo=2&foo=3"
    assert update_query_params("", {"foo": [1, 2, 3]}, doseq=False) == "?foo=%5B1%2C+2%2C+3%5D"

# Generated at 2022-06-24 03:24:47.352445
# Unit test for function update_query_params
def test_update_query_params():
    url = urlparse.urlparse('https://sgoings.csh.rit.edu/wiki/Special:OAuth2Client/authorize?response_type=code&client_id=foo')
    assert update_query_params(url, dict(foo='bar')) == 'https://sgoings.csh.rit.edu/wiki/Special:OAuth2Client/authorize?foo=bar&response_type=code&client_id=foo'
    url = urlparse.urlparse('https://sgoings.csh.rit.edu/wiki/Special:OAuth2Client/authorize?foo=bar&response_type=code&client_id=foo')

# Generated at 2022-06-24 03:24:52.882491
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=stuff&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert 'http://example.com?&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=None))
    assert 'http://example.com?foo=stuff&biz=baz&fiz=wiz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', fiz='wiz'))

# Generated at 2022-06-24 03:24:59.650307
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com", dict(foo='bar')) == 'http://example.com?foo=bar'
    assert update_query_params("http://example.com?foo=bar", dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-24 03:25:04.116866
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo = 'stuff')
    assert update_query_params(url, params) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:25:14.748098
# Unit test for function update_query_params
def test_update_query_params():
    # Test basic functionality:
    assert update_query_params('http://example.com', {'foo': 'bar'}) == 'http://example.com?foo=bar'

    # Test case insensitivity of query parameters:
    assert update_query_params('http://example.com?FOO=bar', {'foo': 'baz'}) == 'http://example.com?FOO=baz'

    # Test repeated parameters:
    assert update_query_params('http://example.com?foo=bar&foo=baz', {'foo': 'stuff'}) == 'http://example.com?foo=stuff'

# Generated at 2022-06-24 03:25:24.208913
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='stuff2')) == 'http://example.com?foo=stuff&biz=stuff2'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', new='stuff2')) == 'http://example.com?foo=stuff&biz=baz&new=stuff2'

# Generated at 2022-06-24 03:25:28.889499
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected = 'http://example.com?foo=stuff&biz=baz'
    actual = update_query_params(url, params)
    assert actual == expected, 'Expected {} but got {}'.format(expected, actual)

# Generated at 2022-06-24 03:25:34.534342
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    """
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url, params) == new_url



# Generated at 2022-06-24 03:25:43.655631
# Unit test for function update_query_params
def test_update_query_params():
    query_string = 'bar=old&foo=bar&biz=baz'
    new_query_string = 'bar=new&foo=stuff'
    expected_query_string = 'bar=new&foo=stuff&biz=baz'

    url = 'http://example.com'
    url_with_query_string = url + '?' + query_string
    expected_url_with_query_string = url + '?' + expected_query_string

    params = {
        'foo': 'stuff',
        'bar': 'new'
    }

    assert update_query_params(url, params) == url
    assert update_query_params(url_with_query_string, params) == expected_url_with_query_string

# Does it work with unicode / UTF-8


# Generated at 2022-06-24 03:25:49.075277
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'

# Generated at 2022-06-24 03:25:52.790083
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    print(f'URL: {new_url}')
    assert new_url == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-24 03:25:57.554501
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-24 03:26:01.624505
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-24 03:26:09.482960
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'more': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz&more=stuff'

if __name__ == "__main__":
    sys.exit(test_update_query_params())

# Generated at 2022-06-24 03:26:18.807784
# Unit test for function update_query_params
def test_update_query_params():
    assert 'https://example.com/page/1?foo=bar&thing=stuff' == update_query_params('https://example.com/page/1?foo=bar', {'thing': 'stuff'})
    assert 'https://example.com/page/1?foo=bar&thing=&thing=stuff' == update_query_params('https://example.com/page/1?foo=bar', {'thing': ''})
    assert 'https://example.com/page/1?foo=bar&thing=5' == update_query_params('https://example.com/page/1?foo=bar', {'thing': '5'})
    assert '' == update_query_params('https://example.com/page/1?foo=bar', {'thing': None})

# Generated at 2022-06-24 03:26:27.395633
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foobar='stuff')) == 'http://example.com?biz=baz&foo=bar&foobar=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'morestuff'])) == 'http://example.com?biz=baz&foo=stuff&foo=morestuff'

# Generated at 2022-06-24 03:26:38.242580
# Unit test for function update_query_params
def test_update_query_params():
    """Test update_query_params()"""

    # Test with a simple single parameter
    url = 'http://example.com?foo=bar'
    expected_result = 'http://example.com?foo=stuff'
    result = update_query_params(url, dict(foo='stuff'))
    assert result == expected_result, "update_query_params({}, {'foo': 'stuff'}) did not produce correct url".format(url)

    # Test with multiple parameters
    url = 'http://example.com?foo=bar&biz=baz'
    expected_result = 'http://example.com?foo=stuff&biz=bonk'
    result = update_query_params(url, dict(foo='stuff', biz='bonk'))

# Generated at 2022-06-24 03:26:42.812903
# Unit test for function update_query_params
def test_update_query_params():
    test = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert urlparse.parse_qs(urlparse.urlsplit(test).query)['foo'] == ['stuff']
    assert urlparse.parse_qs(urlparse.urlsplit(test).query)['biz'] == ['baz']



# Generated at 2022-06-24 03:26:52.527575
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit tests for function update_query_params
    :return:
    """
    # Test 1: Update non-existent query parameter
    url = 'https://api3.geo.admin.ch'
    params = {'foo': 'bar'}
    assert update_query_params(url, params) == 'https://api3.geo.admin.ch?foo=bar'

    # Test 2: Update existing query parameter
    url = 'https://api3.geo.admin.ch?foo=bar'
    params = {'foo': 'baz'}
    assert update_query_params(url, params) == 'https://api3.geo.admin.ch?foo=baz'

# Generated at 2022-06-24 03:26:58.899411
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/is?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    if new_url != 'http://example.com/is?biz=baz&foo=stuff':
        print("update_query_params Test failed")

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:27:04.905550
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?a=1&b=1&c=1',
                               dict(a='stuff', c='stuff2')) \
                               == 'http://example.com?a=stuff&b=1&c=stuff2'
    assert update_query_params('http://example.com',
                               dict(a='stuff', c='stuff2')) \
                               == 'http://example.com?a=stuff&c=stuff2'
    assert update_query_params('http://example.com?a=1&b=1&c=1',
                               dict(a='stuff&')) \
                               == 'http://example.com?a=stuff%26&b=1&c=1'

# Generated at 2022-06-24 03:27:15.952039
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        "http://www.example.com", {"foo": "bar", "pk": "1"}
    ) == "http://www.example.com?foo=bar&pk=1"

    assert update_query_params(
        "http://www.example.com?foo=bar&pk=1", {"foo": "bar", "pk": "1"}
    ) == "http://www.example.com?foo=bar&pk=1"

    assert update_query_params(
        "http://www.example.com?pk=1", {"nk": "bar"}
    ) == "http://www.example.com?nk=bar&pk=1"


# Generated at 2022-06-24 03:27:24.836869
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=stuff' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert 'http://example.com?foo=stuff' == update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'})
    assert 'http://example.com?foo=stuff' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff']))

    # From the docstring
    assert 'http://example.com?foo=stuff' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))

    assert 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-24 03:27:31.564590
# Unit test for function update_query_params
def test_update_query_params():

    assert update_query_params("http://example.com?foo=bar", {"bar":"baz"}) == "http://example.com?foo=bar&bar=baz"
    assert update_query_params("http://example.com?foo=bar", {"foo":"baz"}) == "http://example.com?foo=baz"
    assert update_query_params("http://example.com", {"foo":"bar"}) == "http://example.com?foo=bar"

# Generated at 2022-06-24 03:27:35.353514
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=stuff&biz=baz' == \
           update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:27:44.058720
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params('http://example.com', {}) == 'http://example.com')
    assert(update_query_params('http://example.com?foo=bar', {}) == 'http://example.com?foo=bar')
    assert(update_query_params('http://example.com?foo=bar', dict(foo='stuff'))
           == 'http://example.com?foo=stuff')
    assert(update_query_params('http://example.com?foo=bar', dict(bar='stuff'))
           == 'http://example.com?foo=bar&bar=stuff')

# Generated at 2022-06-24 03:27:48.133516
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert 'foo=stuff' in new_url
    assert '?foo=stuff' in new_url

# Generated at 2022-06-24 03:27:58.929915
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='more stuff')) == 'http://example.com?bar=more+stuff&biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(stuff=[1, 2, 3])) == 'http://example.com?biz=baz&foo=bar&stuff=1&stuff=2&stuff=3'

# Generated at 2022-06-24 03:28:00.889358
# Unit test for function update_query_params
def test_update_query_params():
    doctest.run_docstring_examples(update_query_params, globals(), False)



# Generated at 2022-06-24 03:28:10.167109
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='stuff')) == 'http://example.com?bar=stuff&biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'morestuff'])) == 'http://example.com?biz=baz&foo=stuff&foo=morestuff'

# Generated at 2022-06-24 03:28:20.199368
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test for function update_query_params.
    """
    try:
        import sys
        import os
        import re
        import unittest

        class Test_update_query_params(unittest.TestCase):

            def test_update_query_parmas(self):
                params = dict(foo='stuff')
                self.assertEqual('http://example.com?foo=stuff&biz=baz',
                                 update_query_params('http://example.com?foo=bar&biz=baz', params))

        unittest.main()
    except ImportError:  # pragma: no cover
        sys.stderr.write('[WARNING] unittest not installed, skipping\n')



# Generated at 2022-06-24 03:28:29.656431
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com/?foo=bar', dict(foo='stuff')) == 'http://example.com/?foo=stuff'
    assert update_query_params('http://example.com/?foo=bar', dict(foo='stuff', biz='baz')) == 'http://example.com/?biz=baz&foo=stuff'
    assert update_query_params('http://example.com/?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com/?biz=baz&foo=stuff'
    assert update_query_params('http://example.com/?foo=bar&biz=baz', dict(biz='bang')) == 'http://example.com/?biz=bang&foo=bar'

# Generated at 2022-06-24 03:28:38.688171
# Unit test for function update_query_params
def test_update_query_params():
    assert ('http://example.com?foo=stuff'
            ==
            update_query_params('http://example.com', dict(foo='stuff')))
    assert ('http://example.com?foo=stuff'
            ==
            update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    assert ('http://example.com?foo=stuff'
            ==
            update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    assert ('http://example.com?foo=stuff&biz=baz'
            ==
            update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))

# Generated at 2022-06-24 03:28:40.396214
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar'
    assert 'foo=baz' in update_query_params(url, dict(foo='baz'))

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:28:45.850991
# Unit test for function update_query_params
def test_update_query_params():
    original_url = 'http://example.com/path/to?foo=bar&foo=baz&biz=baz'
    expected_url = 'http://example.com/path/to?foo=stuff&biz=baz'
    actual = update_query_params(original_url, dict(foo='stuff'))
    assert actual == expected_url, actual


# Generated at 2022-06-24 03:28:53.320341
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == "http://example.com?foo=stuff&biz=baz"

# Tests for function update_query_params
if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:28:55.800751
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
           'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:29:03.980195
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, {'foo': 'stuff'})
    if new_url != 'http://example.com?biz=baz&foo=stuff':
        print('Test failed. Expected: '
              'http://example.com?biz=baz&foo=stuff. Got: ' + new_url)
        return False

    new_url = update_query_params(url, {})
    if new_url != url:
        print('Test failed. Expected: ' + url + '. Got: ' + new_url)
        return False

    new_url = update_query_params(url, {'foo': 'stuff', 'fnord': 'schamot'})

# Generated at 2022-06-24 03:29:08.927775
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='stuff')) == 'http://example.com?biz=stuff&foo=bar'

# Generated at 2022-06-24 03:29:16.113382
# Unit test for function update_query_params
def test_update_query_params():
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) ==
        'http://example.com?foo=stuff&biz=baz')
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='stuff')) == 
        'http://example.com?foo=bar&biz=stuff')


# Generated at 2022-06-24 03:29:19.924246
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test update_query_params
    """
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff')



# Generated at 2022-06-24 03:29:22.837673
# Unit test for function update_query_params
def test_update_query_params():
    result = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert result == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-24 03:29:26.284875
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-24 03:29:30.352938
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff'])) == 'http://example.com?biz=baz&foo=stuff'


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:29:39.870543
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    # These should do an update
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    # These should do an insert
    assert update_query_params(url, dict(hello='world')) == 'http://example.com?biz=baz&foo=bar&hello=world'
    # This should do an update, and an insert
    assert update_query_params(url, dict(foo='stuff', hello='world')) == 'http://example.com?biz=baz&foo=stuff&hello=world'

# Generated at 2022-06-24 03:29:48.682931
# Unit test for function update_query_params
def test_update_query_params():

    # test 1
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params, doseq=True)
    # print(new_url)
    expected_url = 'http://example.com?biz=baz&foo=stuff'
    assert new_url == expected_url

    # test 2
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params, doseq=False)
    # print(new_url)
    expected_url = 'http://example.com?biz=baz&foo=stuff'
    assert new_url == expected_url


# Generated at 2022-06-24 03:29:56.119982
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://www.foo.com?a=b&c=d'
    new_url = update_query_params(url, {'a': 'e', 'f': 'g'})
    if new_url != 'http://www.foo.com?a=e&c=d&f=g':
        raise Exception("update_query_params failed: %s" % new_url)


if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:30:05.130447
# Unit test for function update_query_params
def test_update_query_params():
    url = 'https://example.com?foo=bar&biz=baz'
    url1 = update_query_params(url, {'foo': 'stuff'})
    print(url, ':', url1)
    assert url1 == 'https://example.com?foo=stuff&biz=baz'
    url2 = update_query_params(url, {'foo': ['stuff', 'more']})
    print(url, ':', url2)
    assert url2 == 'https://example.com?foo=stuff&foo=more&biz=baz'
    url3 = update_query_params(url, {'foo': 'stuff', 'biz': ['baz', 'more']})
    print(url, ':', url3)

# Generated at 2022-06-24 03:30:11.088480
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# EOF

# Generated at 2022-06-24 03:30:14.420337
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:30:21.289157
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff', biz='bang')
    url2 = update_query_params(url, params)
    expected = 'http://example.com?biz=bang&foo=stuff'
    assert url2 == expected, '%s != %s' % (url2, expected)


# Generated at 2022-06-24 03:30:25.657382
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?...foo=stuff...' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))

# Generated at 2022-06-24 03:30:31.986098
# Unit test for function update_query_params
def test_update_query_params():
    formal_url = 'http://example.com?foo=bar&biz=baz'
    modified_url = update_query_params(formal_url, dict(foo='stuff'))
    expected_url = 'http://example.com?biz=baz&foo=stuff'
    assert modified_url == expected_url, 'Function update_query_params has some problems. Please check unit test!'
#test_update_query_params()



# Generated at 2022-06-24 03:30:41.258283
# Unit test for function update_query_params

# Generated at 2022-06-24 03:30:49.271314
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test for function update_query_params
    """

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='stuff')) == 'http://example.com?biz=stuff&foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='other_stuff')) == 'http://example.com?biz=other_stuff&foo=stuff'


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:30:55.241957
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://localhost:8000/gis/raster/raster_list_page/1/"
    params = {'order_by': '-id'}
    new_url = update_query_params(url, params)

    assert new_url == "http://localhost:8000/gis/raster/raster_list_page/1/?order_by=%2Did"

# Generated at 2022-06-24 03:31:00.540122
# Unit test for function update_query_params
def test_update_query_params():
	assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

if __name__ == '__main__':
  test_update_query_params()

# Generated at 2022-06-24 03:31:03.970030
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    url = update_query_params(url, dict(foo='stuff'))
    assert url == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-24 03:31:09.566007
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
# end

# Generated at 2022-06-24 03:31:19.231631
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com/?foo=bar', dict(baz='buz')) == 'http://example.com/?foo=bar&baz=buz'
    assert update_query_params('http://example.com', dict(foo=None)) == 'http://example.com'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:31:26.217548
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff', baz='qux')
    url = update_query_params(url, params)
    assert url == 'http://example.com?foo=stuff&biz=baz&baz=qux'

# Generated at 2022-06-24 03:31:36.193146
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(url='http://example.com?foo=bar&biz=baz', params={'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url='http://example.com?foo=bar&biz=baz', params={'foo': 'stuff', 'biz': 'stuff'}) == 'http://example.com?biz=baz&biz=stuff&foo=stuff'
    assert update_query_params(url='http://example.com?foo=bar&biz=baz', params={'foo': 'stuff', 'biz': ['stuff']}) == 'http://example.com?biz=baz&biz=stuff&foo=stuff'

# Generated at 2022-06-24 03:31:39.863441
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Function to read the API configuration file to determine the API key to use for various APIs

# Generated at 2022-06-24 03:31:49.166904
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    """

    # Using parse_qs test example in docs
    # https://docs.python.org/2/library/urlparse.html#urlparse.parse_qs
    # >>> from urlparse import parse_qs
    # >>> parse_qs('foo=bar&baz=fob')
    # {'baz': ['fob'], 'foo': ['bar']}
    url = 'http://example.com?foo=bar&baz=fob'
    params = {'foo':'stuff', 'biz':'baz'}
    result = update_query_params(url, params)
    assert result == "http://example.com?foo=stuff&baz=fob&biz=baz"

# Generated at 2022-06-24 03:31:57.616337
# Unit test for function update_query_params
def test_update_query_params():
    # Tests for multiple values for the same parameter name
    url = "http://example.com?a=b&a=c"
    new_url = update_query_params(url, {'a':['asdf', 'ghjk']})
    assert new_url == "http://example.com?a=asdf&a=ghjk", "Multiple values for the same parameter not handled correctly"

    url = "http://example.com?a=1"
    new_url = update_query_params(url, {'b':[2, 3]})
    assert new_url == "http://example.com?a=1&b=2&b=3", "Multiple values for the same parameter not handled correctly"

    # Test for single values
    url = "http://example.com?a=b"
    new_url = update

# Generated at 2022-06-24 03:32:07.756451
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com/foo', dict(foo='stuff')) == 'http://example.com/foo?foo=stuff'
    assert update_query_params('http://example.com/?foo=bar', dict(foo='stuff')) == 'http://example.com/?foo=stuff'

# Generated at 2022-06-24 03:32:12.276223
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:32:15.203375
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-24 03:32:18.369795
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected = 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(foo='stuff')) == expected


# Generated at 2022-06-24 03:32:21.499955
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    result = update_query_params(url, dict(foo='stuff'))
    assert result == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-24 03:32:26.096543
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-24 03:32:30.078195
# Unit test for function update_query_params
def test_update_query_params():
    test_url = "http://example.com?foo=bar&biz=baz"
    foo_query = {'foo': 'stuff'}
    assert(update_query_params(test_url, foo_query) == 'http://example.com?biz=baz&foo=stuff')

test_update_query_params()

# Generated at 2022-06-24 03:32:37.203203
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    """
    # Test
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'





# vim: filetype=python

# Generated at 2022-06-24 03:32:48.816628
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='')) == 'http://example.com?biz=baz&foo=stuff&bar='
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar=''), doseq=False) == 'http://example.com?biz=baz&bar=&foo=stuff'

# Generated at 2022-06-24 03:32:56.563511
# Unit test for function update_query_params
def test_update_query_params():
    url_test = "http://example.com?foo=bar&biz=baz"
    url_test_result = "http://example.com?foo=stuff&biz=baz"
    url_result = update_query_params(url_test, dict(foo='stuff'))
    assert url_result == url_test_result

# Test that function update_query_params actually works
test_update_query_params()

# Print url with updated parameters
print(update_query_params(url_query, dict(page=3)))


# URL decoding
# -------------

# Below is example decoding from the query parameters:
params = dict(page=2, per_page=100)
params_encoded = urlencode(params)
print('Encoded:', params_encoded)


# Generated at 2022-06-24 03:33:05.142503
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {'foo': 'stuff'}) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', {'foo': 'stuff'}) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', {'foo': 'stuff', 'biz': 'baz'}) == 'http://example.com?biz=baz&foo=stuff'
    print('update_query_params: unit test passed!')

# Generated at 2022-06-24 03:33:15.293510
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', one=1)) == 'http://example.com?biz=baz&foo=stuff&one=1'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com', dict()) == 'http://example.com'
    assert update_query_params('http://example.com?foo=bar', dict()) == 'http://example.com?foo=bar'
    assert update_

# Generated at 2022-06-24 03:33:25.018562
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test for function update_query_params
    """
    # Test 1 : With dic
    url = "http://example.com?foo=bar&biz=baz"
    params = {'foo': 'stuff'}
    new_url = update_query_params(url, params, doseq=True)
    assert new_url == 'http://example.com?foo=stuff&biz=baz'

    # Test 2 : With tuple
    url = "http://example.com?foo=bar&biz=baz"
    params = (('foo', 'stuff'))
    new_url = update_query_params(url, params, doseq=True)
    assert new_url == 'http://example.com?foo=stuff&biz=baz'

    # Test 3 : With tuple

# Generated at 2022-06-24 03:33:31.130383
# Unit test for function update_query_params
def test_update_query_params():
    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert url == 'http://example.com?foo=stuff&biz=baz'
    # TODO: test OrderedDict
    # TODO: test multivalue parameters
    return

# Generated at 2022-06-24 03:33:34.426648
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected = 'http://example.com?foo=stuff&biz=baz'
    actual = update_query_params(url, dict(foo='stuff'))
    assert actual == expected



# Generated at 2022-06-24 03:33:37.933687
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=stuff&biz=baz' == update_query_params(
            'http://example.com?foo=bar&biz=baz', dict(foo='stuff'))



# Generated at 2022-06-24 03:33:48.430412
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff1', 'stuff2'])) == 'http://example.com?biz=baz&foo=stuff1&foo=stuff2'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff1', 'stuff2']), doseq=False) == 'http://example.com?biz=baz&foo=stuff1,stuff2'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:33:54.791839
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'

    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?foo=stuff&biz=baz'

    new_url = update_query_params(url, dict(fiz='stuff'))
    assert new_url == 'http://example.com?foo=bar&biz=baz&fiz=stuff'

    new_url = update_query_params(url, dict(fiz='stuff', foo='bar'))
    assert new_url == 'http://example.com?foo=bar&biz=baz&fiz=stuff'

# Generated at 2022-06-24 03:34:00.265778
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com/foo/bar?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com/foo/bar?biz=baz&foo=stuff'
    assert update_query_params('http://example.com/foo/bar?biz=baz', dict(foo='stuff')) == 'http://example.com/foo/bar?biz=baz&foo=stuff'

test_update_query_params()

# Generated at 2022-06-24 03:34:06.708850
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    #print "\nurl = '{}'".format(url)
    #print "\nURL is {} bytes long when encoded as utf-8".format(len(url.encode('utf-8')))
    result = update_query_params(url, dict(foo='stuff'))
    #print "\nupdate_query_params('{}', dict(foo='stuff'))".format(url)
    #print "\nResult is {}".format(result)
    #print "\nResult is {} bytes long when encoded as utf-8".format(len(result.encode('utf-8')))
    assert result == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-24 03:34:11.374595
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?keyword=foo&page=1&search=bar'
    print(update_query_params(url, params={'page':2}))

# Run function if called from command line
if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-24 03:34:14.608104
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        {'foo': 'stuff'}
    ) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-24 03:34:19.957438
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Helpers for testing every URL in a HTML page

# Generated at 2022-06-24 03:34:23.150354
# Unit test for function update_query_params
def test_update_query_params():
    url= "http://www.example.com?foo=bar&biz=baz"
    params=dict(foo="stuff")
    assert update_query_params(url, params) == "http://www.example.com?biz=baz&foo=stuff"




# Datetime utilties

# Generated at 2022-06-24 03:34:27.308175
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    print('Test passed')

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-24 03:34:32.776992
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    params = dict(foo='stuff')
    expected = 'http://example.com?foo=stuff&biz=baz'
    result = update_query_params(url, params)
    assert result == expected