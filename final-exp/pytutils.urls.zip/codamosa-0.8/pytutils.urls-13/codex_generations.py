

# Generated at 2022-06-12 08:20:07.902603
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == "http://example.com?biz=baz&foo=stuff"
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', boo='buzz')) == "http://example.com?boo=buzz&biz=baz&foo=stuff"
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), False) == "http://example.com?biz=baz&foo=stuff"

# Generated at 2022-06-12 08:20:13.965443
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    """
    url = 'http://localhost:8000?foo=bar'
    url = update_query_params(url, dict(foo='stuff'))
    assert url == 'http://localhost:8000?foo=stuff'

    url = update_query_params(url, dict(biz='baz'))
    assert url == 'http://localhost:8000?foo=stuff&biz=baz'



# Generated at 2022-06-12 08:20:23.193889
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baz')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'bar'])) == 'http://example.com?biz=baz&foo=stuff&foo=bar'


if __name__ == '__main__':
    test_update_query_params()


# Generated at 2022-06-12 08:20:30.123255
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(baz='stuff')) == 'http://example.com?foo=bar&biz=baz&baz=stuff'



# Generated at 2022-06-12 08:20:36.564325
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(url="http://example.com", params={"foo": "bar"}) == "http://example.com?foo=bar"
    assert update_query_params(url="http://example.com?foo=baz", params={"foo": "bar"}) == "http://example.com?foo=bar"
    assert update_query_params(url="http://example.com?foo=bar", params={"biz": "baz"}) == "http://example.com?foo=bar&biz=baz"


# Generated at 2022-06-12 08:20:42.352710
# Unit test for function update_query_params
def test_update_query_params():

    url = update_query_params('https://www.google.com/search?q=taj+mahal&oq=taj+mahal&aqs=chrome..69i57.3100j0j7&sourceid=chrome&ie=UTF-8', dict(q='Taj Mahal'))
    print(url)

test_update_query_params()

# Generated at 2022-06-12 08:20:49.464306
# Unit test for function update_query_params
def test_update_query_params():
    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert 'http://example.com?biz=baz&foo=stuff' == url

    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False)
    assert 'http://example.com?biz=baz&foo=stuff' == url

    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'other']), doseq=False)
    assert 'http://example.com?biz=baz&foo=stuff&foo=other' == url


# Generated at 2022-06-12 08:20:57.513201
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected = 'http://example.com?biz=baz&foo=stuff'
    result = update_query_params(url, params)
    assert result == expected



# ---------------------------------------------------------------------
# Task 1: Run this code and see what happens
# ---------------------------------------------------------------------

print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))


# ---------------------------------------------------------------------
# Task 2: Uncomment and run this code and see what happens
# ---------------------------------------------------------------------

# def test_update_query_params():
#     url = 'http://example.com?foo=bar&biz=baz'
#     params = dict(foo='stuff')
#     expected = 'http://

# Generated at 2022-06-12 08:21:01.666015
# Unit test for function update_query_params
def test_update_query_params():
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) ==
            'http://example.com?biz=baz&foo=stuff')


# This is copied from urllib.parse.urlencode()

# Generated at 2022-06-12 08:21:12.266330
# Unit test for function update_query_params
def test_update_query_params():
    assert 'a=1&b=foo' in update_query_params('https://example.com?b=foo', {'a': '1'})
    assert 'b=foo&a=1' in update_query_params('https://example.com?a=1', {'b': 'foo'})
    assert 'b=foo&a=1' in update_query_params('https://example.com?a=1&c=2', {'b': 'foo'})
    assert 'c=2&a=1&b=foo' in update_query_params('https://example.com?a=1&c=2', {'b': 'foo'})
    assert 'https://example.com?b=foo' in update_query_params('https://example.com?b=foo', {})

# Generated at 2022-06-12 08:21:23.692163
# Unit test for function update_query_params
def test_update_query_params():
    url_params_in = {
    'url': 'http://example.com?foo=bar&biz=baz',
    'params': dict(foo='stuff')
    }
    url_params_out = ('http://example.com?foo=stuff&biz=baz',
                      'http://example.com?biz=baz&foo=stuff')
    assert update_query_params(**url_params_in) in url_params_out

    url_params_in = {
    'url': 'http://example.com?foo=bar&biz=baz',
    'params': dict(foo='stuff', u=55)
    }

# Generated at 2022-06-12 08:21:28.555046
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert 'foo=stuff' in new_url
    assert 'biz=baz' in new_url

    # Insert a new query parameter
    new_url = update_query_params(url, dict(cow='stuff'))
    assert 'cow=stuff' in new_url

# Generated at 2022-06-12 08:21:32.225031
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-12 08:21:42.298923
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff', biz='kapow')) == 'http://example.com?biz=kapow&foo=stuff'
    assert update_query_params(url, dict(foo='stuff', biz='kapow'), doseq=False) == 'http://example.com?biz=kapow&foo=stuff'
    url = 'http://example.com?foo=bar&biz=baz&biz=red'

# Generated at 2022-06-12 08:21:42.947232
# Unit test for function update_query_params
def test_update_query_params():
    assert updat

# Generated at 2022-06-12 08:21:46.972124
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/path?foo=bar&biz=baz'
    assert 'foo=stuff' in update_query_params(url, dict(foo='stuff'))



# Generated at 2022-06-12 08:21:52.227785
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', baz='qux')) == 'http://example.com?baz=qux&biz=baz&foo=stuff'

# Generated at 2022-06-12 08:22:03.375847
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    kwargs = dict(foo='stuff', hello='world')
    updated_url = update_query_params(url, kwargs)
    assert updated_url == 'http://example.com?foo=stuff&biz=baz&hello=world'

    url = "http://example.com?foo=bar&biz=baz"
    kwargs = dict(foo='stuff', hello=['world', 'to you'])
    updated_url = update_query_params(url, kwargs)
    assert updated_url == 'http://example.com?foo=stuff&biz=baz&hello=world&hello=to+you'

test_update_query_params()

# Generated at 2022-06-12 08:22:08.063401
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    res = update_query_params(url, params)
    assert res == 'http://example.com?biz=baz&foo=stuff'
    params = dict(foo='stuff', biz='baz')
    res = update_query_params(url, params)
    assert res == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-12 08:22:19.435922
# Unit test for function update_query_params
def test_update_query_params():

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?biz=buzz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(biz='buzz')) == 'http://example.com?biz=buzz&foo=bar'
    assert update_query_params('http://example.com', dict(foo='stuff', biz='buzz')) == 'http://example.com?biz=buzz&foo=stuff'


# Generated at 2022-06-12 08:22:25.979605
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'

import unittest

# Generated at 2022-06-12 08:22:30.154155
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert 'foo=stuff' in new_url
    assert 'biz=baz' in new_url

# Generated at 2022-06-12 08:22:37.823199
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='')) == 'http://example.com?biz=&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz=['newbiz'])) == 'http://example.com?biz=newbiz&foo=stuff'

# Generated at 2022-06-12 08:22:48.434429
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='stuff')) == 'http://example.com?foo=stuff&biz=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='stuff'), doseq=False) == 'http://example.com?biz=stuff&foo=stuff'

# Generated at 2022-06-12 08:22:52.393765
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com'
    params = {'foo': 'bar', 'biz': 'baz'}
    for key, value in params.items():
        url = update_query_params(url, {key: value})
    assert url == 'http://example.com?foo=bar&biz=baz', url


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:22:58.165899
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://www.example.com/index.php?user_id=123&type=abc'
    params = dict(type='xyz')
    new_url = update_query_params(url, params)
    assert new_url == 'http://www.example.com/index.php?user_id=123&type=xyz'



# Generated at 2022-06-12 08:23:08.758061
# Unit test for function update_query_params
def test_update_query_params():
    if not os.path.exists("tmpTesting"): 
        os.system("mkdir tmpTesting")
    
    f = open("tmpTesting/unit_test_update_query_params.txt","w")
    params = {'foo': 'stuff'}
    url = "http://example.com?foo=bar&biz=baz"
    
    f.write("url=%s\n"%url)
    updated_url = update_query_params(url, params, doseq=True)
    f.write("updated_url=%s\n"%updated_url)
    f.close()

    # Check the output is correct
    f2 = open("tmpTesting/unit_test_update_query_params.txt", "r")
    old_url = f2.readline()

# Generated at 2022-06-12 08:23:12.431949
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://www.example.com/?foo=bar'
    params = dict(foo = 'stuff')
    new_url = update_query_params(url, params, doseq=True)
    if new_url != 'http://www.example.com/?foo=stuff':
        print('Error in test_update_query_params')
        
test_update_query_params()

# Generated at 2022-06-12 08:23:17.552952
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', foo2='bam')) == 'http://example.com?foo=stuff&biz=baz&foo2=bam'
    assert update_query_params('http://example.com/?foo=bar&biz=baz', dict(foo='stuff', foo2='bam')) == 'http://example.com/?foo=stuff&biz=baz&foo2=bam'

# Generated at 2022-06-12 08:23:27.691454
# Unit test for function update_query_params
def test_update_query_params():
    test_dict = {
            "http://example.com?foo=bar&biz=baz":
            "http://example.com?biz=baz&foo=stuff",
            "http://example.com?foo=bar&foo=baz":
            "http://example.com?foo=bar&foo=baz",
            "http://example.com?foo=bar&foo=baz&foo=qux":
            "http://example.com?foo=bar&foo=baz&foo=qux&foo=stuff",
            "http://example.com?foo=bar":
            "http://example.com?foo=stuff",
            "http://example.com?foo=bar&bar=baz":
            "http://example.com?bar=baz&foo=stuff",
            }


# Generated at 2022-06-12 08:23:36.176808
# Unit test for function update_query_params
def test_update_query_params():
    """
    Simple unit tests for update_query_params
    """
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-12 08:23:45.177060
# Unit test for function update_query_params
def test_update_query_params():
    test = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=True)
    assert test == 'http://example.com?biz=baz&foo=stuff'
    test = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False)
    assert test == 'http://example.com?biz=baz&foo=stuff'
    test = update_query_params('http://example.com/path?foo=bar&biz=baz', dict(foo='stuff'), doseq=True)
    assert test == 'http://example.com/path?biz=baz&foo=stuff'

# Generated at 2022-06-12 08:23:50.513107
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com/?foo=bar', dict(foo='stuff')) == 'http://example.com/?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'



# Generated at 2022-06-12 08:23:56.889237
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == 'http://example.com?biz=baz&foo=stuff'
    
test_update_query_params()

# Instructor's version


# Generated at 2022-06-12 08:24:00.775010
# Unit test for function update_query_params
def test_update_query_params():
    test_url = "http://example.com"
    test_query_params = dict(foo="bar")
    result = update_query_params(test_url, test_query_params)
    assert result == "http://example.com?foo=bar"
    test_query_params = dict(biz="baz")
    result = update_query_params(result, test_query_params)
    assert result == "http://example.com?biz=baz&foo=bar"
    result = update_query_params(result, dict(foo="stuff"))
    assert result == "http://example.com?biz=baz&foo=stuff"
    # Test multiple values
    test_query_params = dict(biz="biz1")
    result = update_query_params(result, test_query_params)

# Generated at 2022-06-12 08:24:02.720562
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'

# Generated at 2022-06-12 08:24:06.465393
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:24:11.821686
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("https://google.com", {"test": "testme"}) == "https://google.com?test=testme"
    assert update_query_params("https://google.com?foo=bar&biz=baz", dict(foo='stuff')) == "https://google.com?biz=baz&foo=stuff"

# Generated at 2022-06-12 08:24:16.195903
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    'http://example.com?foo=stuff&biz=baz'
    """



# Generated at 2022-06-12 08:24:22.489846
# Unit test for function update_query_params
def test_update_query_params():
    url = 'https://example.com/search?q=query&client=ubuntu&channel=fs&ie=utf-8&oe=utf-8'
    params = {'client': 'firefox'}
    new_url = 'https://example.com/search?q=query&client=firefox&channel=fs&ie=utf-8&oe=utf-8'
    assert update_query_params(url, params) == new_url



# Generated at 2022-06-12 08:24:36.010285
# Unit test for function update_query_params
def test_update_query_params():
    inp_url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    out_url = update_query_params(inp_url, params)
    assert out_url == 'http://example.com?foo=stuff&biz=baz'

# Usage: py.test test_1.py
if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:24:47.430044
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    test_params = dict(foo='stuff', biz=['stuff','more stuff'])
    expected = 'http://example.com?biz=%28stuff%2Cmore+stuff%29&foo=stuff'


    assert update_query_params(test_url, test_params) == expected
    #print(update_query_params(test_url, test_params))

    test_url_2 = 'http://example.com?foo=bar&biz=baz'
    test_params_2 = dict(foo='stuff', biz=['stuff','more stuff'])
    expected_2 = 'http://example.com?biz=stuff&biz=more+stuff&foo=stuff'



# Generated at 2022-06-12 08:24:50.447721
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# AVAILABLE TESTS


# Generated at 2022-06-12 08:24:53.028627
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=stuff&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))

# Generated at 2022-06-12 08:25:00.854608
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'

    new_url = update_query_params(url, {'foo': 'stuff'})
    assert new_url == 'http://example.com?foo=stuff&biz=baz'

    new_url = update_query_params(url, {'foo': None})
    assert new_url == 'http://example.com?biz=baz'


# See http://stackoverflow.com/questions/3277503/how-to-read-a-file-line-by-line-into-a-list-with-python#3277516

# Generated at 2022-06-12 08:25:04.464181
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    result = update_query_params(url, params)
    assert result == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-12 08:25:15.439131
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='stuff')) == 'http://example.com?biz=stuff&foo=stuff'
    assert update_query_params('http://example.com?foo=stuff', dict(foo='bar', biz='stuff')) == 'http://example.com?biz=stuff&foo=bar'
    assert update_query_params('http://example.com', dict(biz='stuff')) == 'http://example.com?biz=stuff'

# Generated at 2022-06-12 08:25:21.897130
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test that tests the function update_query_params
    """
    # debug
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    print(update_query_params(url, params))

# Run the unit test
if __name__ == '__main__':
    # Debug
    test_update_query_params()

# Generated at 2022-06-12 08:25:24.704892
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-12 08:25:28.235859
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baz 2')) == 'http://example.com?foo=stuff&biz=baz%202'



# Generated at 2022-06-12 08:25:49.415313
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:25:59.890652
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test cases for update_query_params.
    """
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
        'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == \
        'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'more_stuff']), doseq=True) == \
        'http://example.com?biz=baz&foo=stuff&foo=more_stuff'

# Generated at 2022-06-12 08:26:03.791784
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=True) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff'], biz=['bam']), doseq=True) == 'http://example.com?biz=baz&biz=bam&foo=bar&foo=stuff'

# Generated at 2022-06-12 08:26:14.319142
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test update_query_params

    :return:
    """
    url = 'http://example.com?foo=bar&biz=baz'
    actual = update_query_params(url, dict(foo='stuff'))
    expected = 'http://example.com?biz=baz&foo=stuff'
    assert actual == expected

    url = 'http://example.com?foo=bar&biz=baz'
    actual = update_query_params(url, dict(foo='stuff', biz='bah'))
    expected = 'http://example.com?biz=bah&foo=stuff'
    assert actual == expected

    url = 'http://example.com?foo=bar&biz=baz'

# Generated at 2022-06-12 08:26:21.663391
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
           'http://example.com?biz=baz&foo=stuff'

    assert update_query_params('http://example.com', dict(foo='stuff')) == \
           'http://example.com?foo=stuff'

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == \
           'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:26:31.551075
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz', "Failed to update query parameter"
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'biz': 'buzz'}) == 'http://example.com?foo=stuff&biz=buzz', "Failed to update query parameter"
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'biz': 'buzz', 'fizz': 'pop'}) == 'http://example.com?biz=buzz&foo=stuff&fizz=pop', "Failed to update query parameter"

# Generated at 2022-06-12 08:26:37.977229
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['foo', 'bar'])) == 'http://example.com?biz=baz&foo=foo&foo=bar'


# Generated at 2022-06-12 08:26:41.844588
# Unit test for function update_query_params
def test_update_query_params():
    result = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    print(result)
    assert result == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-12 08:26:46.555285
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='baz')) == 'http://example.com?foo=stuff&biz=baz&bar=baz'



# Generated at 2022-06-12 08:26:52.478489
# Unit test for function update_query_params
def test_update_query_params():
    url = 'https://priority.example.com/endpoint'
    url_params = {
                'apikey': 'ABC123',
                'page': '4',
                'pageSize': '50',
                'type': 'SALE',
                }

    updated_url = update_query_params(url, url_params)
    assert('page=4&pageSize=50&type=SALE&apikey=ABC123' == updated_url[-48:])

test_update_query_params()

# Generated at 2022-06-12 08:27:32.488502
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert(new_url == 'http://example.com?biz=baz&foo=stuff')
    assert(get_query_params(new_url) == params)


# Generated at 2022-06-12 08:27:39.476788
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='etc')) == 'http://example.com?foo=stuff&biz=etc'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='etc', bleep='bloop')) == 'http://example.com?foo=stuff&biz=etc&bleep=bloop'

# Create a test suite to execute all tests
import unittest

# Generated at 2022-06-12 08:27:50.843917
# Unit test for function update_query_params
def test_update_query_params():
    from nose.tools import assert_equal
    assert_equal(update_query_params(
        "http://example.com/?foo=bar&biz=baz", dict(foo='stuff'), doseq=True),
        'http://example.com/?foo=stuff&biz=baz')
    assert_equal(update_query_params(
        "http://example.com/?foo=bar&biz=baz", dict(foo='stuff'), doseq=False),
        'http://example.com/?foo=stuff')
    assert_equal(update_query_params(
        "http://example.com/?foo=bar&biz=baz", dict(foo=('stuff', 'otherstuff')), doseq=False),
        'http://example.com/?foo=stuff&foo=otherstuff&biz=baz')

# Generated at 2022-06-12 08:27:58.933755
# Unit test for function update_query_params
def test_update_query_params():
    assert "http://example.com?foo=stuff&biz=baz" == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert "http://example.com?foo=stuff&biz=baz" == update_query_params('http://example.com?foo=stuff&biz=baz', dict(foo='stuff'))
    assert "http://example.com?foo=stuff&biz=baz&baz=foo" == update_query_params('http://example.com?foo=stuff&biz=baz', dict(baz='foo'))


# Generated at 2022-06-12 08:28:09.296844
# Unit test for function update_query_params
def test_update_query_params():

    # test_1:
    #   - if a param is updated, it should be updated
    #   - if a param is added, it should be added
    #   - if a param is not passed to update, it should remain unchanged
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff', cat='dog')
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?biz=baz&cat=dog&foo=stuff'

    # test_2:
    #   - if a param is updated, it should be updated
    #   - if a param is added, it should be added
    #   - if a param is not passed to update, it should remain unchanged

# Generated at 2022-06-12 08:28:16.709524
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test function update_query_params
    """
    print("")
    print("*****************************************************************")
    print("*************** test_update_query_params ************************")
    print("*****************************************************************")
    print("")
    test_url1 = 'http://example.com/?foo=bar&biz=baz'
    print("test_url1 = " + test_url1)
    print("test_url1 after update_query_params = " + update_query_params(test_url1, dict(foo='stuff')))
    test_url2 = 'http://example.com/my/url?foo=bar&biz=baz&biz=biz'
    print("test_url2 = " + test_url2)

# Generated at 2022-06-12 08:28:21.547560
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test update_query_params
    """
    test_url = 'http://example.com?foo=bar&biz=baz&biz=buzz'
    test_updated_url = 'http://example.com?biz=baz&biz=buzz&foo=stuff'
    test_params = {'foo': ['stuff']}

    assert update_query_params(test_url, test_params) == test_updated_url




# Generated at 2022-06-12 08:28:26.299081
# Unit test for function update_query_params
def test_update_query_params():
    params = {'foo': 'stuff'}
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, params)
    print(new_url)

if __name__ == "__main__":
    test_update_query_params()



# Generated at 2022-06-12 08:28:36.849179
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    return "Unit test passed in function update_query_params"

# Code to execute unit test
test_update_query_params()

# Code to call function
update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))

# END OF PROGRAM

#-------------------------------------------------------------------------------------
# TITLE: Functions_update_query_params_02.py
#
# PURPOSE: Add or modify a query parameter in a URL 
# NOTES:
#
#-------------------------------------------------------------------------------------

#-------------------------------------------------------------------------------------
# REVISION HISTORY: Functions_update_query_params_01.py
#

# Generated at 2022-06-12 08:28:40.337358
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    expected_url = 'http://example.com?biz=baz&foo=stuff'
    assert new_url == expected_url