

# Generated at 2022-06-12 08:20:07.937929
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test the update_query_params function against established cases

    :return:
    :rtype:
    """

# Generated at 2022-06-12 08:20:12.165236
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    expected = 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url, params) == expected



# Generated at 2022-06-12 08:20:14.808511
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'




# Generated at 2022-06-12 08:20:25.214963
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com/foo/bar?a=b&b=c&c=d"
    result = update_query_params(url, {'a': 'A', 'e': 'E', 'f': 'F'})
    assert result == "http://example.com/foo/bar?a=A&b=c&c=d&e=E&f=F"
    result = update_query_params(url, {'a': 'A', 'b': 'B', 'c': 'C'})
    assert result == "http://example.com/foo/bar?a=A&b=B&c=C"
    result = update_query_params(url, {'a': 'A', 'c': 'C', 'e': 'E'})

# Generated at 2022-06-12 08:20:32.451449
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('https://www.google.com', {'q':'Test'}) == 'https://www.google.com?q=Test'
    assert update_query_params('https://www.google.com?q=Current', {'q':'Test'}) == 'https://www.google.com?q=Test'
    assert update_query_params('https://www.google.com?q=Current&foo=bar', {'q':'Test'}) == 'https://www.google.com?foo=bar&q=Test'

# Generated at 2022-06-12 08:20:39.812087
# Unit test for function update_query_params
def test_update_query_params():
    # Test without query string
    url = 'https://github.com/'
    params = {'key': 'value'}
    url = update_query_params(url, params)
    assert url == 'https://github.com/?key=value'

    # Test with query string
    url = 'https://github.com/?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    url = update_query_params(url, params)
    assert url == 'https://github.com/?foo=stuff&biz=baz'

    # Test with multiple values for the same parameter
    url = 'https://github.com/?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    url = update_query_params(url, params)

# Generated at 2022-06-12 08:20:42.540114
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert 'foo=stuff' in update_query_params(url, dict(foo='stuff'))

# Generated at 2022-06-12 08:20:46.306801
# Unit test for function update_query_params
def test_update_query_params():
    # Test 1:
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    assert update_query_params(url, params) == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-12 08:20:53.462579
# Unit test for function update_query_params
def test_update_query_params():
    """
    Check that function update_query_params is working
    """
    url = 'http://example.com?foo=bar&biz=bla'
    params = {'foo': 'stuff', 'baz': ['a', 'b']}
    result = update_query_params(url, params)
    assert ('foo=stuff' in result)
    assert ('baz=a' in result)
    assert ('baz=b' in result)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:20:56.822769
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar'
    params = {'foo': 'stuff'}
    assert update_query_params(url, params) == 'http://example.com?foo=stuff'



# Generated at 2022-06-12 08:21:05.704551
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', baz='wtf')) == 'http://example.com?baz=wtf&biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', baz='wtf', hi='sup')) == 'http://example.com?baz=wtf&biz=baz&foo=stuff&hi=sup'

# Generated at 2022-06-12 08:21:08.719859
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    assert 'foo=stuff' in update_query_params(url, params)



# Generated at 2022-06-12 08:21:17.763234
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test for function update_query_params
    """

    print("Testing {}...".format(update_query_params.__name__))

    url = "http://example.com?foo=bar&biz=baz"
    params = {'foo':'stuff'}

    outputurl = update_query_params(url, params)
    expectedurl = "http://example.com?foo=stuff&biz=baz"

    if outputurl == expectedurl:
        print("Test passed.")
    else:
        print("Test failed: expected {} to equal {}".format(outputurl, expectedurl))

if __name__ == "__main__":
    # Test update_query_params
    test_update_query_params()

# Generated at 2022-06-12 08:21:25.849872
# Unit test for function update_query_params
def test_update_query_params():
    # Test simple code path
    old_url = 'http://example.com'
    params = dict(foo='bar')
    assert update_query_params(old_url, params) == 'http://example.com?foo=bar'
    # Test with existing parameters
    old_url = 'http://example.com?foo=bar'
    params = dict(biz='baz')
    assert update_query_params(old_url, params) == 'http://example.com?foo=bar&biz=baz'
    # Test with existing parameters
    old_url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff', more='shiz')

# Generated at 2022-06-12 08:21:29.871528
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'

    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?biz=baz&foo=stuff'


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:21:36.614550
# Unit test for function update_query_params
def test_update_query_params():
    # This is a simple test - but there is no updated_query_params() function to test against.
    # It was only created to test the update_query_params() function.
    assert update_query_params('http://example.com', dict(page='1')) == 'http://example.com?page=1'    

# Code for testing and running this script
if __name__ == '__main__':
    print('Running unit tests')
    from doctest import testmod
    testmod()
    print('Testing completed')

# Generated at 2022-06-12 08:21:44.761624
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}, doseq=False) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': ['stuff', 'stuff2']}, doseq=False) == 'http://example.com?biz=baz&foo=stuff&foo=stuff2'

# Generated at 2022-06-12 08:21:48.014668
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-12 08:21:52.635740
# Unit test for function update_query_params
def test_update_query_params():
    expected = 'http://example.com?foo=stuff&biz=baz&biz=baz2'
    result = update_query_params('http://example.com?foo=bar&biz=baz&biz=baz2', dict(foo='stuff'))
    assert result == expected, 'Expected %s, got %s' % (expected, result)



# Generated at 2022-06-12 08:22:00.847752
# Unit test for function update_query_params
def test_update_query_params():
    """
    Testing of update_query_params function.
    """

    test_url = 'http://example.com?foo=bar&biz=baz'
    test_params = {'foo':'stuff'}

    result = update_query_params(test_url, test_params)
    assert result == 'http://example.com?biz=baz&foo=stuff'

# Unit test section end


if __name__ == '__main__':
    """
    Run tests if script is executed as python-module.
    """
    test_update_query_params()

# Generated at 2022-06-12 08:22:07.298524
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(bing='bong')) == 'http://example.com?bing=bong&biz=baz&foo=bar'

test_update_query_params()

# Generated at 2022-06-12 08:22:13.957109
# Unit test for function update_query_params
def test_update_query_params():
    """Unit test for update_query_params
    >>> update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    'http://example.com?foo=stuff&biz=baz'
    """
    return


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True, raise_on_error=True)

# Generated at 2022-06-12 08:22:20.571130
# Unit test for function update_query_params
def test_update_query_params():
    _assert_equals(
        update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')),
        'http://example.com?biz=baz&foo=stuff')
    _assert_equals(
        update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'things'])),
        'http://example.com?biz=baz&foo=things&foo=stuff')


# Generated at 2022-06-12 08:22:25.569091
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://www.foo.com?foo=bar&biz=baz'
    params = {'foo': 'stuff', 'bar': 'something'}
    print(update_query_params(url, params))


# Generated at 2022-06-12 08:22:35.167345
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) \
        == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'things'])) \
        == 'http://example.com?biz=baz&foo=stuff&foo=things'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='things')) \
        == 'http://example.com?biz=things&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False)

# Generated at 2022-06-12 08:22:45.534382
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(a=1, b=2)) == 'http://example.com?a=1&b=2'
    assert update_query_params('http://example.com?a=1&b=2', dict(a='foo', b=3)) == 'http://example.com?a=foo&b=3'
    assert update_query_params('http://example.com/path/to/stuff', dict(a=1, b=2)) == 'http://example.com/path/to/stuff?a=1&b=2'


if __name__ == '__main__':
    import sys
    try:
        globals()['test_' + sys.argv[1]]()
    except KeyError:
        pass

# Generated at 2022-06-12 08:22:53.809504
# Unit test for function update_query_params
def test_update_query_params():
    """Unit test for function update_query_params"""
    assert 'http://example.com?foo=stuff&biz=baz&woot=0' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff',woot=0))
    assert 'http://example.com/foo?bar=stuff' == update_query_params('http://example.com/foo', dict(bar='stuff'))
    assert 'http://example.com/foo?bar=stuff' == update_query_params('http://example.com/foo?foo=bar', dict(bar='stuff'))

# Generated at 2022-06-12 08:23:05.335339
# Unit test for function update_query_params
def test_update_query_params():
    import uuid

    assert update_query_params('http://example.com',
                               {'foo': 'bar'}) == 'http://example.com?foo=bar'

    assert update_query_params('http://example.com?foo=bar',
                               {'biz': 'baz'}) == 'http://example.com?foo=bar&biz=baz'

    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz'

    url_with_path = 'http://example.com/' + uuid.uuid4()

# Generated at 2022-06-12 08:23:09.149934
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/foo?foo=bar&biz=baz'
    url = update_query_params(url, dict(foo='stuff'))
    assert url == 'http://example.com/foo?biz=baz&foo=stuff'
test_update_query_params()


# Generated at 2022-06-12 08:23:11.317491
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-12 08:23:20.335487
# Unit test for function update_query_params
def test_update_query_params():
    result = update_query_params( 'http://www.example.com/', {'foo':'bar'} )
    assert result == 'http://www.example.com/?foo=bar'
    result = update_query_params( 'http://www.example.com/', {'foo':'bar', 'biz':'baz'} )
    assert result == 'http://www.example.com/?biz=baz&foo=bar'
    result = update_query_params( 'http://www.example.com/', {'foo':'bar', 'biz':'baz'}, False )
    assert result == 'http://www.example.com/?biz=baz&foo=bar'

# Generated at 2022-06-12 08:23:29.767760
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com'
    params = dict(foo='stuff')
    kwparam_url = update_query_params(url, params)
    assert kwparam_url == 'http://example.com?foo=stuff'
    url = 'http://example.com?foo=bar'
    params = dict(foo='stuff')
    kwparam_url = update_query_params(url, params)
    assert kwparam_url == 'http://example.com?foo=stuff'
    url = 'http://example.com?foo=bar&bar=foo'
    params = dict(foo='stuff')
    kwparam_url = update_query_params(url, params)
    assert kwparam_url == 'http://example.com?foo=stuff&bar=foo'

# Generated at 2022-06-12 08:23:40.764355
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {'foo': 'bar'}) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'new': 'param'}) == 'http://example.com?foo=stuff&biz=baz&new=param'
    assert update_query_params('http://example.com', {'param': ['a', 'b']}) == 'http://example.com?param=a&param=b'

# Generated at 2022-06-12 08:23:50.907892
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com/', {}) == 'http://example.com/'
    assert update_query_params('http://example.com?foo=bar', {}) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {}) == 'http://example.com?foo=bar&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'

# Generated at 2022-06-12 08:24:01.996725
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(key='val1', foo='stuff')) == 'http://example.com?biz=baz&foo=stuff&key=val1'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(key=['val1', 'val2'])) == 'http://example.com?biz=baz&foo=bar&key=val1&key=val2'

# Generated at 2022-06-12 08:24:12.567229
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?foo=stuff&biz=buzz'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff', biz='buzz')) == 'http://example.com?biz=buzz&foo=stuff'

if __name__ == "__main__":
    import doctest
   

# Generated at 2022-06-12 08:24:23.906123
# Unit test for function update_query_params
def test_update_query_params():
    base_url = 'http://example.com/'
    query_params = {
        'p1': ['v1', 'v2'],
        'p2': ['v2', 'v3'],
    }
    # create base url
    test_url = update_query_params(base_url, query_params)
    # test multiple value params
    assert len(urlparse.parse_qs(test_url)['p1']) == 2
    assert len(urlparse.parse_qs(test_url)['p2']) == 2
    # add new param with one value
    new_query_params = {
        'p3': ['v4'],
    }
    test_url = update_query_params(test_url, new_query_params)

# Generated at 2022-06-12 08:24:27.762542
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff', biz='buzz')) == 'http://example.com?foo=stuff&biz=buzz'



# Generated at 2022-06-12 08:24:30.444421
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-12 08:24:40.616545
# Unit test for function update_query_params
def test_update_query_params():
    """Testing function update_query_params
    """

    # Test with one parameter that already exists
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, params=dict(foo='stuff'))
    assert new_url == 'http://example.com?foo=stuff&biz=baz'

    # Test with one parameter that is new
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, params=dict(parm='stuff'))
    assert new_url == 'http://example.com?foo=bar&biz=baz&parm=stuff'

    # Test with multiple parameters
    url = 'http://example.com?foo=bar&biz=baz'
   

# Generated at 2022-06-12 08:24:49.924134
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://www.example.com?foo=bar&a=b&c=d&foo=stuff'
    url_updated = update_query_params(url, {'a': '1', 'c': ['2', '3']})
    assert url_updated == 'http://www.example.com/?a=1&c=2&c=3&foo=bar&foo=stuff'



# Generated at 2022-06-12 08:24:55.150433
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    url_update = update_query_params(url, dict(foo='stuff'))
    assert url_update == 'http://example.com?biz=baz&foo=stuff', '%s != %s' % (url_update, 'http://example.com?biz=baz&foo=stuff')

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:24:58.321828
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-12 08:25:01.807194
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    result_url = update_query_params(test_url, dict(foo='stuff'))
    assert result_url == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-12 08:25:05.875444
# Unit test for function update_query_params
def test_update_query_params():
    assert_equals(
        update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}),
        'http://example.com?foo=stuff&biz=baz'
    )

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-12 08:25:09.174685
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-12 08:25:12.378322
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-12 08:25:16.632305
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'


if __name__ == '__main__':
    from pytest import main
    main(args=['--tb=short', '--verbose', __file__])

# Generated at 2022-06-12 08:25:21.979367
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz&foo=somethingelse', {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz&foo=somethingelse'


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:25:25.091665
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

test_update_query_params()




# Generated at 2022-06-12 08:25:39.858343
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    expected = 'http://example.com?foo=stuff&biz=baz'
    assert new_url == expected, new_url

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:25:43.277006
# Unit test for function update_query_params
def test_update_query_params():
    """Test function update_query_params."""
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'




# Generated at 2022-06-12 08:25:54.578754
# Unit test for function update_query_params
def test_update_query_params():
    # Test case when no parameter is replaced
    assert "http://example.com?foo=bar&biz=baz&baz=foo" == update_query_params("http://example.com?foo=bar&biz=baz&baz=foo", {})

    # Test case when one parameter is replaced
    assert "http://example.com?foo=bar&biz=baz&baz=foo&biz=newbiz" == update_query_params("http://example.com?foo=bar&biz=baz&baz=foo", {'biz': 'newbiz'})

    # Test case when one parameter is replaced (lengthy test)

# Generated at 2022-06-12 08:26:03.359935
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', wow='amaze')) == 'http://example.com?foo=stuff&biz=baz&wow=amaze'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff'])) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-12 08:26:08.838940
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-12 08:26:13.176121
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test for function update_query_params.
    :return:
    """
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-12 08:26:22.030734
# Unit test for function update_query_params
def test_update_query_params():
    # test1
    url = 'http://www.example.com'
    params = {'key1': 'val1', 'key2': 'val2'}
    x = 'http://www.example.com?key1=val1&key2=val2'
    assert update_query_params(url, params, doseq=True) == x
    assert update_query_params(url, params, doseq=False) == x

    # test2
    url = 'http://www.example.com?key1=val1&key2=val2'
    params = {'key1': 'val1', 'key2': 'val2'}
    x = 'http://www.example.com?key1=val1&key2=val2'
    assert update_query_params(url, params, doseq=True)

# Generated at 2022-06-12 08:26:31.896866
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff&biz=true')) == 'http://example.com?biz=baz&foo=stuff%26biz%3Dtrue'
    assert update_query_params('http://example.com?foo=blah', dict(foo='stuff', biz='baz')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-12 08:26:37.669457
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) ==  'http://example.com?foo=stuff&biz=baz'

if __name__ == "__main__":
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))

# Generated at 2022-06-12 08:26:44.479896
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {'foo': 'bar'}) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', {'foo': 'biz', 'biz': 'stuff'}) == \
        'http://example.com?foo=biz&biz=stuff'
    assert update_query_params('http://example.com?foo=bar', {'foo': ['biz', 'stuff']}) == \
        'http://example.com?foo=biz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar', {'biz': 'stuff'}) == \
        'http://example.com?foo=bar&biz=stuff'

# Generated at 2022-06-12 08:27:03.190034
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-12 08:27:12.555119
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?foo=stuff&biz=baz'
    new_url = update_query_params(url, dict(qux='stuff'))
    assert new_url == 'http://example.com?foo=bar&biz=baz&qux=stuff'
    new_url = update_query_params(url, dict(foo='stuff'), doseq=False)
    assert new_url == 'http://example.com?foo=bar&biz=baz&foo=stuff'
    new_url = update_query_params(url, dict(foo=('stuff', 'stuff2')))

# Generated at 2022-06-12 08:27:21.235922
# Unit test for function update_query_params

# Generated at 2022-06-12 08:27:31.942804
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff', biz='stuff'))
    assert urlparse.urlparse(new_url).query == 'biz=stuff&foo=stuff'

    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(biz='stuff'))
    assert urlparse.urlparse(new_url).query == 'biz=stuff&foo=bar'

    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(ban=['a', 'b', 'c']))

# Generated at 2022-06-12 08:27:39.153693
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == "http://example.com?foo=stuff&biz=baz")
    assert(update_query_params("http://example.com?foo=bar&biz=baz&q=x", dict(q='y')) == "http://example.com?foo=bar&biz=baz&q=y")
    assert(update_query_params("http://example.com?q=x", dict(q='y')) == "http://example.com?q=y")
    assert(update_query_params("http://example.com?q=x&q=y", dict(q='y')) == "http://example.com?q=y&q=y")

# Generated at 2022-06-12 08:27:42.645411
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)



# Generated at 2022-06-12 08:27:49.773156
# Unit test for function update_query_params
def test_update_query_params():
    # Test that the return type is a string
    assert update_query_params('www.google.com', {'foo':'bar'}) == 'www.google.com?foo=bar'
    # Test that the returned string is modified
    assert update_query_params('www.google.com?foo=bar', {'foo':'biz'}) == 'www.google.com?foo=biz'

test_update_query_params()

# Generated at 2022-06-12 08:27:53.485754
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-12 08:27:56.504861
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('https://www.google.com/', {'q': 'Googling'}) == 'https://www.google.com/?q=Googling'

# Generated at 2022-06-12 08:28:08.400536
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert('http://example.com?foo=stuff&biz=baz' == update_query_params(url, params))

    url = 'http://example.com?foo=stuff&biz=baz'
    params = dict(foo='bar')
    assert('http://example.com?foo=bar&biz=baz' == update_query_params(url, params))

if __name__ == '__main__':
    import sys
    import nose

    if len(sys.argv) > 1:
        argv = sys.argv[1:]
    else:
        argv = ['-s', '--with-doctest']

# Generated at 2022-06-12 08:28:51.903690
# Unit test for function update_query_params
def test_update_query_params():
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
            == 'http://example.com?biz=baz&foo=stuff')
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'things']))
            == 'http://example.com?biz=baz&foo=things&foo=stuff')



# Generated at 2022-06-12 08:28:57.238001
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)

    assert new_url == 'http://example.com?biz=baz&foo=stuff'


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:29:00.282743
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-12 08:29:03.729776
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?...foo=stuff...' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:29:09.481922
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=stuff&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert 'http://example.com?foo=stuff&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', baz='dah'))


# Generated at 2022-06-12 08:29:16.890515
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               {'foo': 'stuff', 'biz': 'baz2'}) == 'http://example.com?foo=stuff&biz=baz&biz=baz2'
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               {'foo': ['stuff', 'stuff2']}) == 'http://example.com?foo=stuff&foo=stuff2&biz=baz'

if __name__ == '__main__':
    test_update_query_params

# Generated at 2022-06-12 08:29:22.364909
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    test_url = update_query_params(test_url, {'foo':'stuff'})
    print(test_url)
    test_url = 'http://example.com?foo=bar&biz=baz'
    test_url = update_query_params(test_url, {'foo':'stuff','newparam':'0'})
    print(test_url)


# Generated at 2022-06-12 08:29:30.995335
# Unit test for function update_query_params
def test_update_query_params():
    # Test simple replacement
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    # Test same key twice
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff','thing'])) == 'http://example.com?foo=stuff&foo=thing&biz=baz'
    # Test new key
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(nested='things')) == 'http://example.com?foo=bar&biz=baz&nested=things'
    # Test new key

# Generated at 2022-06-12 08:29:35.297377
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

    assert update_query_params(
        'https://example.com',
        dict(foo='stuff')) == 'https://example.com?foo=stuff'

# Generated at 2022-06-12 08:29:40.135110
# Unit test for function update_query_params
def test_update_query_params():
    # Compare to: https://httpbin.org/get?foo=bar
    url = update_query_params('https://httpbin.org/get?foo=bar', dict(foo='stuff'))
    assert url == 'https://httpbin.org/get?foo=stuff'
    print('Passed: test_update_query_params')


if __name__ == "__main__":
    test_update_query_params()