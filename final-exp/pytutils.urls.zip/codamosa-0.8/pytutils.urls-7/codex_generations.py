

# Generated at 2022-06-12 08:20:02.813988
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test with a valid URL
    """
    assert(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff')

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:20:10.625438
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz=['buzz', 'fuzz'])) == 'http://example.com?biz=fuzz&biz=buzz&foo=stuff'

# Generated at 2022-06-12 08:20:15.609260
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    
    
    
if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-12 08:20:26.548011
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    """

    # default
    assert(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff')

    # not doseq
    params = [('foo', 'stuff')]
    assert(update_query_params('http://example.com?foo=bar&biz=baz', params, doseq=False) == 'http://example.com?biz=baz&foo=stuff')

    # doseq
    params = [('foo', 'stuff'), ('foo', 'stuff2')]

# Generated at 2022-06-12 08:20:29.581871
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    result = update_query_params(url, dict(foo='stuff'))
    assert result is not None
 


# Generated at 2022-06-12 08:20:36.775778
# Unit test for function update_query_params
def test_update_query_params():
    """This is a test for the function update_query_params"""
    url = "http://www.example.com/index.php?doc=some_doc&name=john+doe"
    print("\nexpect:\nhttp://www.example.com/index.php?doc=some_doc&name=john+doe&email=john%40example.com\ngot:")
    print(update_query_params(url, {'email': 'john@example.com'}))

# main function
if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-12 08:20:46.951482
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='bar')) == \
           'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
           'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='baz')) == \
           'http://example.com?foo=stuff&biz=baz&bar=baz'

# Generated at 2022-06-12 08:20:56.237612
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='blah')) == 'http://example.com?biz=blah&foo=stuff'
    assert update_query_params(
        'http://example.com', dict(foo='stuff', biz='blah')) == 'http://example.com?biz=blah&foo=stuff'

# Generated at 2022-06-12 08:21:00.434002
# Unit test for function update_query_params
def test_update_query_params():
    expected = 'http://example.com?foo=stuff&biz=baz&buz=boo'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', buz='boo')) == expected

# Generated at 2022-06-12 08:21:11.410624
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               {'foo': 'stuff', 'new': 'true'}) == 'http://example.com?foo=stuff&biz=baz&new=true'
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               {'foo': 'stuff', 'biz': 'new_baz'}) == 'http://example.com?foo=stuff&biz=new_baz'

# Generated at 2022-06-12 08:21:18.506664
# Unit test for function update_query_params
def test_update_query_params():

    # Test 1
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected = 'http://example.com?foo=stuff&biz=baz'
    result = update_query_params(url, params)
    assert result == expected

    # Test 2
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff', cat='dog')
    expected = 'http://example.com?foo=stuff&biz=baz&cat=dog'
    result = update_query_params(url, params)
    assert result == expected

    # Test 3
    url = 'http://example.com/test/unit'
    params = dict(foo='stuff', cat='dog')

# Generated at 2022-06-12 08:21:26.298520
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='baz')) == 'http://example.com?foo=stuff&biz=baz&bar=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz#123', dict(foo='stuff', bar='baz')) == 'http://example.com?foo=stuff&biz=baz&bar=baz#123'

# Generated at 2022-06-12 08:21:31.186679
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url, dict(stuff='biz')) == 'http://example.com?foo=bar&biz=baz&stuff=biz'
test_update_query_params()

# Generated at 2022-06-12 08:21:37.154541
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', baz='ok')) == 'http://example.com?baz=ok&biz=baz&foo=stuff'

# Generated at 2022-06-12 08:21:44.463873
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/favicon.ico'

    assert url == update_query_params(url, {})
    assert 'http://example.com/favicon.ico?foo=123' == update_query_params(url, dict(foo='123'))
    assert 'http://example.com/favicon.ico?foo=123' == update_query_params(url, foo='123')
    assert 'http://example.com/favicon.ico?foo=123' == update_query_params(url, dict(foo=['123']))
    assert 'http://example.com/favicon.ico?foo=123' == update_query_params(url, foo=['123'])

# Generated at 2022-06-12 08:21:53.869798
# Unit test for function update_query_params
def test_update_query_params():
    import sys

    # case 1
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')

    # Should return:
    # 'http://example.com?...foo=stuff...'
    new_url = update_query_params(url, params)

    # test case 1
    if new_url != 'http://example.com?foo=stuff&biz=baz':
        raise Exception('test case 1 failed: ' + sys._getframe().f_code.co_name)

    # case 2
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(biz='stuff')

    # Should return:
    # 'http://example.com?...foo=stuff...'

# Generated at 2022-06-12 08:22:00.939154
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test function update_query_params
    """
    test_string = 'http://example.com?foo=bar&biz=baz'
    result_string = update_query_params(test_string, dict(foo='stuff'))

    assert result_string == 'http://example.com?biz=baz&foo=stuff'

# Run unit tests
if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:22:06.713979
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'bar': 'baz'}) == 'http://example.com?bar=baz&biz=baz&foo=stuff'
test_update_query_params()

# Generated at 2022-06-12 08:22:18.063559
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {'foo': 'bar'}) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', {'foo': 'bar'}) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', {'foo': 'baz'}) == 'http://example.com?foo=baz'
    assert update_query_params('http://example.com?foo=bar', {'abc': 'xyz'}) == 'http://example.com?foo=bar&abc=xyz'

# Generated at 2022-06-12 08:22:24.777213
# Unit test for function update_query_params
def test_update_query_params():
    # Test case 1
    url = "http://example.com?foo=bar&biz=baz"
    params = {"foo": "stuff"}
    result = update_query_params(url, params)
    expected_result = "http://example.com?foo=stuff&biz=baz"
    assert result == expected_result
    
    # Test case 2
    url = "http://example.com?foo=bar&biz=baz"
    params = {"api_key": "123456"}
    result = update_query_params(url, params)
    expected_result = "http://example.com?biz=baz&foo=bar&api_key=123456"
    assert result == expected_result
    
    # Test case 3

# Generated at 2022-06-12 08:22:35.053423
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='banana')) == 'http://example.com?biz=banana&foo=stuff'


# Generated at 2022-06-12 08:22:45.481455
# Unit test for function update_query_params
def test_update_query_params():

    # Test if method adds param to empty URL
    query_params = dict(foo='stuff')
    url = 'http://example.com'
    rv = update_query_params(url, query_params)
    assert rv == 'http://example.com?foo=stuff'

    # Test if method updates existing param
    query_params = dict(foo='stuff')
    url = 'http://example.com?foo=bar'
    rv = update_query_params(url, query_params)
    assert rv == 'http://example.com?foo=stuff'

    # Test if method adds param to existing URL
    query_params = dict(new='stuff')
    url = 'http://example.com?foo=bar'
    rv = update_query_params(url, query_params)

# Generated at 2022-06-12 08:22:53.783194
# Unit test for function update_query_params
def test_update_query_params():
    def assertEquals(a, b):
        if a != b:
            raise Exception('%s != %s' % (a, b))

    assertEquals(
        update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')),
        'http://example.com?biz=baz&foo=stuff'
    )
    assertEquals(
        update_query_params('http://example.com', dict(foo='bar')),
        'http://example.com?foo=bar'
    )
    assertEquals(
        update_query_params('http://example.com?foo=bar', dict(foo='stuff')),
        'http://example.com?foo=stuff'
    )

# Generated at 2022-06-12 08:23:05.336385
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> update_query_params('http://example.com', dict(foo='stuff'))
    'http://example.com?foo=stuff'
    >>> update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    'http://example.com?biz=baz&foo=stuff'
    >>> update_query_params('http://example.com', {'foo': 'bar', 'foo': 'baz'}, doseq=True)
    'http://example.com?foo=bar&foo=baz'
    >>> update_query_params('http://example.com?foo=bar&foo=baz', {'foo': 'stuff'}, doseq=True)
    'http://example.com?foo=stuff'
    """
    pass

# Generated at 2022-06-12 08:23:08.837515
# Unit test for function update_query_params
def test_update_query_params():
    # Test cases are taken from the beginning of this function.
    url = "http://example.com?foo=bar&biz=baz"
    assert update_query_params(url, dict(foo='stuff')) == "http://example.com?biz=baz&foo=stuff"

# Generated at 2022-06-12 08:23:15.510938
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com/?foo=bar&biz=baz'
    test_params = {'foo': 'stuff'}
    assert update_query_params(test_url, test_params) == 'http://example.com/?foo=stuff&biz=baz'
    test_params = {'foo': 'stuff', 'biz': 'bang'}
    assert update_query_params(test_url, test_params) == 'http://example.com/?foo=stuff&biz=bang'
    test_params = {'boo': 'stuff'}
    assert update_query_params(test_url, test_params) == 'http://example.com/?foo=bar&biz=baz&boo=stuff'

    test_url = 'http://example.com/?a=1&a=2'
   

# Generated at 2022-06-12 08:23:18.167956
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://localhost:8089/accounts/sign-in/?next=%2F', {'next': '/stuff'}) == 'http://localhost:8089/accounts/sign-in/?next=%2Fstuff'



# Generated at 2022-06-12 08:23:28.284288
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', bar='stuff') == 'http://example.com?bar=stuff&biz=baz&foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', bar='stuff', biz='estuff') == 'http://example.com?bar=stuff&biz=estuff&foo=bar'

# Generated at 2022-06-12 08:23:38.289589
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='boo')) == 'http://example.com?biz=boo&foo=stuff'

    assert update_query_params('http://example.com?foo=bar&biz=baz&baz=zoink', dict(foo='stuff')) == 'http://example.com?baz=zoink&biz=baz&foo=stuff'


# Generated at 2022-06-12 08:23:46.320370
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
        'http://example.com?foo=stuff&biz=baz'

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', xoxo='hug')) == \
        'http://example.com?foo=stuff&biz=baz&xoxo=hug'

    # Test overwriting query params
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='1', foo='2')) == \
        'http://example.com?foo=1&foo=2&biz=baz'

# Generated at 2022-06-12 08:24:00.246959
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?biz=baz&foo=stuff'

    params = {'surname': 'slater', 'first_name': 'dave'}
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?biz=baz&foo=bar&first_name=dave&surname=slater'


# Generated at 2022-06-12 08:24:10.492464
# Unit test for function update_query_params
def test_update_query_params():
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', boz='bottle')))
    print(update_query_params('http://example.com?foo=bar&biz=baz&foo=buz', dict(foo='stuff', boz='bottle')))
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(boz='bottle', foo='stuff')))
    print(update_query_params('http://example.com?foo=bar&biz=baz&foo=buz', dict(boz='bottle', foo='stuff')))


# Generated at 2022-06-12 08:24:17.797190
# Unit test for function update_query_params
def test_update_query_params():
    from nose.tools import assert_equal, assert_regexp_matches
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    print(new_url)
    assert_regexp_matches(new_url, '...foo=stuff...')
    assert_regexp_matches(new_url, '...biz=baz...')
    assert_equal(urlparse.urlparse(url).query, 'foo=bar&biz=baz')
    assert_equal(urlparse.urlparse(new_url).query, 'foo=stuff&biz=baz')
test_update_query_params()

# Generated at 2022-06-12 08:24:28.468161
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, foo='stuff')
    assert new_url == 'http://example.com?foo=stuff&biz=baz'
    new_url = update_query_params(new_url, biz='stuff')
    assert new_url == 'http://example.com?foo=stuff&biz=stuff'
    new_url = update_query_params(new_url, bar='stuff')
    assert new_url == 'http://example.com?foo=stuff&biz=stuff&bar=stuff'
    new_url = update_query_params(new_url, bar=['stuff', 'morestuff'])

# Generated at 2022-06-12 08:24:38.286227
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'https://api.hubapi.com/foo?bar=biz&baz=stuff', {'bar': 'foo'}) == 'https://api.hubapi.com/foo?bar=foo&baz=stuff'
    assert update_query_params(
        'https://api.hubapi.com/foo?bar=biz&baz=stuff', {'bar': 'foo', 'baz':'thing'}) == 'https://api.hubapi.com/foo?bar=foo&baz=thing'
    assert update_query_params(
        'https://api.hubapi.com/foo', {'bar': 'foo', 'baz':'thing'}) == 'https://api.hubapi.com/foo?bar=foo&baz=thing'


# Generated at 2022-06-12 08:24:46.044852
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff&%$')) == 'http://example.com?foo=stuff%26%25%24'

# Generated at 2022-06-12 08:24:53.867526
# Unit test for function update_query_params
def test_update_query_params():
    from nose.tools import eq_
    assert 'foo=stuff' in update_query_params('http://example.com?foo=bar', dict(foo='stuff'))
    assert 'foo=stuff' in update_query_params('http://example.com?foo=bar', dict(foo=['stuff']))
    eq_('http://example.com?foo=stuff', update_query_params('http://example.com?foo=bar', dict(foo='stuff'), doseq=False))
    eq_('http://example.com?foo=stuff', update_query_params('http://example.com?foo=bar', dict(foo=['stuff']), doseq=False))

# Generated at 2022-06-12 08:24:59.156973
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected_output = 'http://example.com?biz=baz&foo=stuff'
    output = update_query_params(url, dict(foo='stuff'))
    assert output == expected_output

#############################
# Using class in a function
#############################
from datetime import datetime

# Generated at 2022-06-12 08:25:06.317783
# Unit test for function update_query_params
def test_update_query_params():
    # Case 1: path without query parameters, without update, without fragment
    url = 'http://example.com'
    params = {}
    assert update_query_params(url, params) == url


    # Case 2: path without query parameters, with empty update
    url = 'http://example.com'
    params = {}
    assert update_query_params(url, params) == url


    # Case 3: path with query parameters, without update
    url = 'http://example.com?foo=bar'
    params = {}
    assert update_query_params(url, params) == url


    # Case 4: path with query parameters, with update
    url = 'http://example.com?foo=bar'
    params = {'foo': 'stuff'}

# Generated at 2022-06-12 08:25:10.589801
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:25:23.269593
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-12 08:25:27.671461
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected_url = 'http://example.com?biz=baz&foo=stuff'
    output_url = update_query_params(url, params)
    if output_url != expected_url:
        raise Exception('Test failed: expected ' + expected_url + ' but got ' + output_url)


# Generated at 2022-06-12 08:25:36.646274
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'fo': 'stuff'}) == 'http://example.com?foo=bar&biz=baz&fo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'new_arg': 'stuff'}) == 'http://example.com?foo=bar&biz=baz&new_arg=stuff'

# Generated at 2022-06-12 08:25:46.347299
# Unit test for function update_query_params
def test_update_query_params():
    assert (update_query_params('http://example.com?foo=bar&biz=baz', {'foo':'stuff','biz':'stuff'})) == 'http://example.com?biz=stuff&foo=stuff'
    assert (update_query_params('http://example.com?foo=bar&biz=baz', {'foo':'stuff','biz':'stuff','blah':'stuff'})) == 'http://example.com?blah=stuff&biz=stuff&foo=stuff'

# Generated at 2022-06-12 08:25:49.361257
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-12 08:25:59.856054
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?foo=stuff&biz=buzz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'buzz'])) == 'http://example.com?foo=stuff&foo=buzz&biz=baz'

# Generated at 2022-06-12 08:26:06.419001
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://localhost/path?foo=bar&biz=baz", dict(foo='stuff')) == "http://localhost/path?biz=baz&foo=stuff"
    assert update_query_params("http://localhost/path?foo=bar&biz=baz&baz=test", dict(foo='stuff', biz='test')) == "http://localhost/path?baz=test&biz=test&foo=stuff"


if __name__ == "__main__":
    url = "http://localhost/path?foo=bar&biz=baz&baz=test"
    print(update_query_params(url, dict(foo='stuff', biz='test')))
    print(update_query_params(url, dict(foo='stuff', biz='test'), doseq=False))

# Generated at 2022-06-12 08:26:14.185915
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(xin='zhi')) == 'http://example.com?biz=baz&foo=bar&xin=zhi'
    return True

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:26:21.057001
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
            'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com/', dict()) == 'http://example.com/'
    assert update_query_params('http://example.com/', dict(foo=['bar', 'baz'])) == \
            'http://example.com/?foo=bar&foo=baz'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-12 08:26:30.877283
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff'])) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff'], biz='stuff')) == 'http://example.com?biz=stuff&foo=stuff'


# Generated at 2022-06-12 08:27:02.398555
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com/?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='bang')) == 'http://example.com?foo=stuff&biz=bang'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='bang', aler='toto')) == 'http://example.com?foo=stuff&biz=bang&aler=toto'
    print

# Generated at 2022-06-12 08:27:05.782235
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff'),
        doseq=True
    ) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()
    print('unit test OK')

# Generated at 2022-06-12 08:27:10.108517
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://www.test.test?foo=bar&baz=bam", {"foo": "biz", "other": "stuff"}) == "http://www.test.test?foo=biz&baz=bam&other=stuff"



# Generated at 2022-06-12 08:27:12.763386
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
        'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-12 08:27:20.881085
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='bar')) == 'http://example.com?biz=baz&foo=bar'
    assert update_query_params('http://example.com?foo=bar', dict(baz='biz')) == 'http://example.com?baz=biz&foo=bar'
    assert update_query_params('http://example.com?foo=bar&foo=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff'

# Generated at 2022-06-12 08:27:31.446099
# Unit test for function update_query_params
def test_update_query_params():
    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert url == 'http://example.com?biz=baz&foo=stuff'

    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff']))
    assert url == 'http://example.com?biz=baz&foo=stuff'

    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'things']))
    assert url == 'http://example.com?biz=baz&foo=stuff&foo=things'

    url = update_query_params('http://example.com?biz=baz', dict(foo=['stuff', 'things']))

# Generated at 2022-06-12 08:27:36.915134
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com/this/is/a/path?foo=bar&biz=baz&biz=boz&baz'
    # Convert params dict to query parameters
    test_params = dict(foo='stuff', biz='baaz')

    actual = update_query_params(test_url, test_params, doseq=False)
    expected = 'http://example.com/this/is/a/path?foo=stuff&biz=baaz&baz'
    assert actual == expected


# Generated at 2022-06-12 08:27:40.959162
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com'
    test_query = dict(foo='stuff')

    test_result = update_query_params(test_url, test_query)
    assert test_result == 'http://example.com/?foo=stuff'



# Generated at 2022-06-12 08:27:44.996544
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-12 08:27:53.690545
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com/foo?bar=bar&biz=baz', dict(foo='stuff')) == 'http://example.com/foo?bar=bar&biz=baz&foo=stuff'
    assert update_query_params('http://example.com/?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com/?foo=stuff&biz=baz'

# Generated at 2022-06-12 08:28:41.720617
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://www.example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, {'foo': 'stuff'})
    assert new_url == 'http://www.example.com?foo=stuff&biz=baz'



# Generated at 2022-06-12 08:28:48.522207
# Unit test for function update_query_params
def test_update_query_params():
    print("Testing method 'update_query_params' ...")
    with Timer("update_query_params"):
        url = "http://example.com?foo=bar&biz=baz"
        params = {"foo": "stuff"}
        print("url: " + url)
        print("params: " + str(params))
        print("return: " + update_query_params(url, params, doseq=True))

# Generated at 2022-06-12 08:28:55.268543
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert new_url == "http://example.com?foo=stuff&biz=baz"

    url = "http://example.com?foo=bar&biz=baz"
    params = dict(foo='stuff', biz='abcd')
    new_url = update_query_params(url, params)
    assert new_url == "http://example.com?foo=stuff&biz=abcd"

# Generated at 2022-06-12 08:29:04.952821
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test for function update_query_params
    """
    # Initialize
    url = 'http://example.com'
    res0 = 'http://example.com?'
    res1 = 'http://example.com?foo=bar'
    res2 = 'http://example.com?foo=bar&biz=baz'
    res3 = 'http://example.com?foo=stuff&biz=baz'
    # Run & compare
    assert(update_query_params(url,{}) == res0)
    assert(update_query_params(url,{'foo':'bar'}) == res1)
    assert(update_query_params(url,{'foo':'bar','biz':'baz'}) == res2)

# Generated at 2022-06-12 08:29:08.428258
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-12 08:29:13.742510
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected_result = 'http://example.com?biz=baz&foo=stuff'
    result = update_query_params(url, params)
    if result != expected_result:
        raise Exception(
            'Result: {}\nExpected: {}'.format(
                result, expected_result
            ))



# Generated at 2022-06-12 08:29:18.883443
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(baz='stuff')) == 'http://example.com?biz=baz&foo=bar&baz=stuff'

# Generated at 2022-06-12 08:29:27.748792
# Unit test for function update_query_params
def test_update_query_params():
    '''

    :return:
    '''
    url = 'http://example.com?foo=bar'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?foo=stuff'

    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?foo=stuff&biz=baz'

    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='baz'))
    assert new_url == 'http://example.com?foo=baz&biz=baz'

    url

# Generated at 2022-06-12 08:29:36.696862
# Unit test for function update_query_params
def test_update_query_params():

    # Make sure a query param is added to a URL that has no query params.
    url = 'http://example.com/'
    params = {'foo': 'bar'}
    url_new = update_query_params(url, params)
    assert url_new == 'http://example.com/?foo=bar'

    # Make sure a query param is added to the end of a URL that already has
    # query params.
    url = 'http://example.com/?biz=baz'
    params = {'foo': 'bar'}
    url_new = update_query_params(url, params)
    assert url_new == 'http://example.com/?biz=baz&foo=bar'

    # Make sure an existing query param is updated.
    url = 'http://example.com/?foo=bar'

# Generated at 2022-06-12 08:29:39.345339
# Unit test for function update_query_params
def test_update_query_params():
    test_value = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert test_value == 'http://example.com?foo=stuff&biz=baz'