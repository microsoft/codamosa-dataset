

# Generated at 2022-06-21 22:28:23.193293
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    result = update_query_params(url, params)
    assert result == 'http://example.com?biz=baz&foo=stuff'

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:28:25.420285
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:28:29.176395
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-21 22:28:36.049620
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff',wil='doe')) == 'http://example.com?biz=baz&foo=stuff&wil=doe'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff',wil='doe',doe='doe')) == 'http://example.com?biz=baz&doe=doe&foo=stuff&wil=doe'

# Generated at 2022-06-21 22:28:40.722397
# Unit test for function update_query_params
def test_update_query_params():
    url_ = 'http://example.com?foo=bar&biz=baz'
    params = { 'foo': 'stuff' }
    result = update_query_params(url_, params)
    assert result == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:28:45.409647
# Unit test for function update_query_params
def test_update_query_params():
    expected_result = 'http://example.com?foo=stuff&biz=baz&param1=value1&param2=value2'
    
    new_url = update_query_params('http://example.com?foo=bar&biz=baz', {'foo':'stuff', 'param1':'value1', 'param2':'value2'})
    
    assert new_url == expected_result

test_update_query_params()

# Generated at 2022-06-21 22:28:56.045914
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff1', 'stuff2'])) == 'http://example.com?biz=baz&foo=stuff1&foo=stuff2'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff1', 'stuff2']), doseq=False) == 'http://example.com?biz=baz&foo=stuff1,stuff2'

# Generated at 2022-06-21 22:29:01.916941
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params('http://example.com', {'foo': ['bar']}) == 'http://example.com?foo=bar')
    assert(update_query_params('http://example.com?foo=bar', {'bar': ['baz']}) == 'http://example.com?foo=bar&bar=baz')
    assert(update_query_params('http://example.com?foo=bar', {'foo': ['baz']}) == 'http://example.com?foo=baz')
    assert(update_query_params('http://example.com?foo=bar', {'foo': ['baz', 'foo']}) == 'http://example.com?foo=baz&foo=foo')

# Generated at 2022-06-21 22:29:12.702500
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?foo=stuff&biz=buzz'
    assert update_query_params('http://example.com?a=1&a=2', dict(a=1)) == 'http://example.com?a=1&a=1'
    assert update_query_params('http://example.com?a=1&a=2', dict(a=1), doseq=False) == 'http://example.com?a=1'

# Generated at 2022-06-21 22:29:20.328654
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', biz='stuff') == 'http://example.com?biz=stuff&foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', biz='baz') == 'http://example.com?biz=baz&foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', biz='baz', foo='baz') == 'http://example.com?biz=baz&foo=baz'

# Generated at 2022-06-21 22:29:24.252132
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:29:28.803613
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    expected_url = 'http://example.com?biz=baz&foo=stuff'

    assert new_url == expected_url

# Generated at 2022-06-21 22:29:37.941669
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test for function update_query_params

    :return:
    """
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz#test', dict(foo='stuff', biz='newbaz')) == 'http://example.com?biz=newbaz&foo=stuff#test'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': ['stuff'], 'biz': ['newbaz']}) == 'http://example.com?biz=newbaz&foo=stuff'

# Generated at 2022-06-21 22:29:48.410621
# Unit test for function update_query_params
def test_update_query_params():

    def test_query_params(url, params, doseq=True, expected=None):
        assert expected == update_query_params(url, params, doseq), \
                    'url: %s, params: %s, doseq: %s' % (url, params, doseq)

    test_query_params('http://example.com?foo=bar&biz=baz',
            {'foo': 'stuff'},
            expected='http://example.com?foo=stuff&biz=baz')

    test_query_params('http://example.com?foo=bar&biz=baz',
            {'buz': 'stuff', 'foo': 'overwritten'},
            expected='http://example.com?foo=overwritten&biz=baz&buz=stuff')


# Generated at 2022-06-21 22:29:54.375842
# Unit test for function update_query_params
def test_update_query_params():
    # create an example URL with a query string
    exampl_url = update_query_params("http://localhost/test.php", {'foo': 'bar'})
    assert exampl_url == "http://localhost/test.php?foo=bar"
    
    # update the query string
    updat_url = update_query_params(exampl_url, {'foo': 'baz'})
    assert updat_url == "http://localhost/test.php?foo=baz"
    
    # add to the query string
    more_url = update_query_params(exampl_url, {'baz': 'qux'})
    assert more_url == "http://localhost/test.php?foo=bar&baz=qux"
    
    # test again
    more_url = update_query

# Generated at 2022-06-21 22:30:06.401165
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&baz=biz'
    assert 'foo=stuff' in update_query_params(url, dict(foo='stuff'))
    assert 'baz=stuff' in update_query_params(url, dict(baz='stuff'))
    assert 'foo=baz' in update_query_params(url, dict(foo='baz'))
    assert 'baz=bar' in update_query_params(url, dict(baz='bar'))
    assert 'foo=baz&baz=bar' in update_query_params(url, dict(foo='baz', baz='bar'))
    assert 'foo=baz&baz=biz' in update_query_params(url, dict(foo='baz'), doseq=False)

# Generated at 2022-06-21 22:30:12.260953
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    result = 'http://example.com?foo=stuff&biz=baz'
    print(result)
    assert update_query_params(url, params) == result
    print("Test passed!")

# test_update_query_params()


# Generated at 2022-06-21 22:30:23.478374
# Unit test for function update_query_params

# Generated at 2022-06-21 22:30:33.151892
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='qux')) == 'http://example.com?biz=qux&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz=['qux'])) == 'http://example.com?biz=qux&foo=stuff'

# Generated at 2022-06-21 22:30:45.288939
# Unit test for function update_query_params
def test_update_query_params():
    """Unit test for function update_query_params"""

    def assertNewUrl(url, new_params, expected_new_url):
        """Assert that update_query_params returns the expected new url."""
        new_url = update_query_params(url, new_params)
        assert new_url == expected_new_url

    url = 'http://example.com?biz=baz&foo=bar'
    # No change, but also no error when params are not found.
    assertNewUrl(url, dict(biz='baz'), 'http://example.com?biz=baz&foo=bar')
    assertNewUrl(url, dict(baz='biz'), 'http://example.com?biz=baz&foo=bar')

    # Insert new parameter.

# Generated at 2022-06-21 22:30:55.162443
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test for function update_query_params
    """
    # Initialise key variables
    url = 'http://example.com?foo=bar&biz=baz'

    # Test
    result = update_query_params(url, dict(foo='stuff'))
    assert 'foo=stuff' in result



# Generated at 2022-06-21 22:31:01.301128
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {'foo': '42'}) ==\
        'http://example.com?foo=42'
    assert update_query_params('http://example.com?foo=bar', {'foo': '42'}) ==\
        'http://example.com?foo=42'
    assert update_query_params('http://example.com?foo=bar', {'bar': '42'}) ==\
        'http://example.com?foo=bar&bar=42'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:31:05.074393
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

####### Keys in dictionary ########


# Generated at 2022-06-21 22:31:13.390963
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz&biz=buzz'
    params = dict(foo='stuff', baz='barz')
    new_url = update_query_params(url, params)
    expected_new_url = 'http://example.com?foo=stuff&biz=baz&biz=buzz&baz=barz'
    assert new_url == expected_new_url

# Generated at 2022-06-21 22:31:24.214498
# Unit test for function update_query_params
def test_update_query_params():

    # Test 1
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    result = update_query_params(url, params)
    assert result == 'http://example.com?biz=baz&foo=stuff'


    # Test 2
    url = 'http://example.com'
    params = {'foo': 'stuff'}
    result = update_query_params(url, params)
    assert result == 'http://example.com?foo=stuff'

    # Test 3
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff', 'hello': 'world'}
    result = update_query_params(url, params)

# Generated at 2022-06-21 22:31:31.587747
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff', fiz='stuff')) == \
        'http://example.com?foo=stuff&biz=baz&fiz=stuff'
    assert update_query_params(url, dict(foo='stuff', biz='zap')) == \
        'http://example.com?foo=stuff&biz=zap'
    assert update_query_params(url, dict(foo='stuff')) == \
        'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url, dict()) == \
        'http://example.com?foo=bar&biz=baz'

# Generated at 2022-06-21 22:31:42.884525
# Unit test for function update_query_params
def test_update_query_params():
    # Test to update a parameter
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, {'foo': 'stuff'})
    assert new_url == 'http://example.com?biz=baz&foo=stuff'

    # Test to add a parameter
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, {'hello': 'world'})
    assert new_url == 'http://example.com?biz=baz&foo=bar&hello=world'

    # Test to add a parameter to an empty url
    url = 'http://example.com'
    new_url = update_query_params(url, {'foo': 'bar'})
    assert new_

# Generated at 2022-06-21 22:31:50.347543
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    'http://example.com?...foo=stuff...'
    """
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    result_url = 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, params) == result_url



# Generated at 2022-06-21 22:32:01.970828
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com/foo?bar=baz', dict(bar='stuff')) == 'http://example.com/foo?bar=stuff'
    assert update_query_params('http://example.com/?baz=buz', dict(foo='stuff')) == 'http://example.com/?baz=buz&foo=stuff'
    assert update_query_params('http://example.com/?baz=buz&bar=baz', dict(bar='stuff')) == 'http://example.com/?baz=buz&bar=stuff'
    assert update_query_params('http://example.com/?baz=buz&bar=baz', dict(baz='stuff')) == 'http://example.com/?baz=stuff&bar=baz'
    assert update_query_params

# Generated at 2022-06-21 22:32:07.503097
# Unit test for function update_query_params
def test_update_query_params():
    url = "https://www.google.com/search?q=python"
    params = dict(lang="en", q="python")
    
    result = update_query_params(url, params)
    print(result)
    assert result == "https://www.google.com/search?lang=en&q=python"


#------------------------------------------------
# Pythonic way to execute a function multiple times

# Generated at 2022-06-21 22:32:29.023724
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test the update_query_params function
    """
    # Test inserting a new key
    
    url = 'http://example.com/search?q=query'
    new_url = update_query_params(url, {'foo': 'bar'})
    assert new_url == 'http://example.com/search?foo=bar&q=query'
    
    # Test updating a key
    
    url = 'http://example.com/search?foo=bar'
    new_url = update_query_params(url, {'foo': 'baz'})
    assert new_url == 'http://example.com/search?foo=baz'

    # Test & vs. &amp;
    
    url = 'http://example.com/search?foo=bar&amp;biz=baz'
    new

# Generated at 2022-06-21 22:32:37.240376
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(biz='stuff')) == 'http://example.com?foo=bar&biz=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-21 22:32:48.500608
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(biz='stuff')) == 'http://example.com?foo=bar&biz=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff', biz='bang')) == 'http://example.com?foo=stuff&biz=bang'

    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff', biz='bang')) == 'http://example.com?foo=stuff&biz=bang'

# Generated at 2022-06-21 22:32:56.144529
# Unit test for function update_query_params
def test_update_query_params():
    url="http://example.com?foo=bar&biz=baz"
    params={'foo':'stuff'}
    print(update_query_params(url,params))

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:33:02.732488
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected_url = 'http://example.com?foo=stuff&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == expected_url

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:33:07.735844
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {}) == 'http://example.com'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-21 22:33:15.264599
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=bar&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', {})
    assert 'http://example.com?bar=foo&foo=bar&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', {'bar': 'foo'})
    assert 'http://example.com?foo=baz&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'baz'})



# Generated at 2022-06-21 22:33:24.904022
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?a=b&a=c&d=e', dict(a='f', a='g')) == 'http://example.com?a=f&a=g&d=e'
    assert update_query_params('http://example.com?a=b&a=c&d=e', dict(a='h', a='i')) == 'http://example.com?a=h&a=i&d=e'
    assert update_query_params('http://example.com?a=b&a=c&d=e', dict(a='f', a='g'), doseq=False) == 'http://example.com?a=f&d=e'

# Generated at 2022-06-21 22:33:32.334425
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
if __name__ == '__main__':
    test_update_query_params()


# Generated at 2022-06-21 22:33:38.296640
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz=['biz1', 'biz2'])) == 'http://example.com?biz=biz1&biz=biz2&foo=stuff'

# Generated at 2022-06-21 22:34:12.118630
# Unit test for function update_query_params
def test_update_query_params():
    required_query_parameters = {
        'client_id': 'example_client_id',
        'response_type': 'code',
        'redirect_uri': 'https://example.com/callback',
    }
    url = 'https://accounts.google.com/o/oauth2/v2/auth'
    url = update_query_params(url, required_query_parameters)
    print(url)
    scheme, netloc, path, query_string, fragment = urlparse.urlsplit(url)
    assert query_string == 'client_id=example_client_id&redirect_uri=https%3A%2F%2Fexample.com%2Fcallback&response_type=code'

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:34:22.473432
# Unit test for function update_query_params
def test_update_query_params():
    class Test(object):
        def __init__(self, assert_method):
            self.assert_method = assert_method

        def test_list(self):
            self.assert_method(
                "http://example.com?foo=bar&foo=stuff",
                update_query_params("http://example.com?foo=bar", {"foo": "stuff"})
            )

        def test_list_list(self):
            self.assert_method(
                "http://example.com?foo=bar&foo=stuff",
                update_query_params("http://example.com?foo=bar", {"foo": ["stuff"]})
            )


# Generated at 2022-06-21 22:34:32.236318
# Unit test for function update_query_params
def test_update_query_params():
    url = update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'})
    assert url == 'http://example.com?biz=baz&foo=stuff'
    url = update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}, doseq=False)
    assert url == 'http://example.com?biz=baz&foo=stuff'
    url = update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'biz': ['5', '6']})
    assert url == 'http://example.com?biz=5&biz=6&foo=stuff'

# Generated at 2022-06-21 22:34:35.912453
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://staging.vacationspots.net/?'
    params = {'property_id': 'L-2267'}
    new_url = update_query_params(url,params)

    assert new_url == 'http://staging.vacationspots.net/?property_id=L-2267'


# Generated at 2022-06-21 22:34:45.712354
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?biz=baz&foo=stuff', new_url
    new_url = update_query_params(new_url, dict(biz='another'))
    assert new_url == 'http://example.com?biz=another&foo=stuff', new_url
    new_url = update_query_params(new_url, dict(new='field'))
    assert new_url == 'http://example.com?biz=another&foo=stuff&new=field', new_url

# This can be used as a decorator to check that arguments in a function are
# of a certain type.  E.g.
#

# Generated at 2022-06-21 22:34:49.984182
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(bar=123, biz=3)
    expected = 'http://example.com?bar=123&biz=3&foo=bar'
    actual = update_query_params(url, params)
    assert expected == actual

# Generated at 2022-06-21 22:34:53.767068
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert 'foo=stuff' in new_url

# Generated at 2022-06-21 22:35:00.741516
# Unit test for function update_query_params
def test_update_query_params():
    """
    Tests for update_query_params function.
    """
    url = 'http://example.com'
    url_result = 'http://example.com/?foo=stuff&biz=baz'

    url = update_query_params(url, dict(foo='stuff', biz='baz'))
    assert url == url_result

    url = 'http://example.com?foo=bar&biz=baz'
    url_result = 'http://example.com?foo=stuff&biz=baz'

    url = update_query_params(url, dict(foo='stuff'))
    assert url == url_result



# Generated at 2022-06-21 22:35:07.649761
# Unit test for function update_query_params
def test_update_query_params():
    # Test normal URL
    url = 'http://example.com?foo=bar&biz=baz&empty'
    new_url = update_query_params(url, {'foo': 'stuff'})
    assert new_url == 'http://example.com?foo=stuff&biz=baz&empty'
    # Test URL with hash
    url = 'http://example.com?foo=bar&biz=baz&empty#hash'
    new_url = update_query_params(url, {'foo': 'stuff'})
    assert new_url == 'http://example.com?foo=stuff&biz=baz&empty#hash'
    # Test URL with no query params at all
    url = 'http://example.com#hash'

# Generated at 2022-06-21 22:35:12.890061
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-21 22:35:58.707865
# Unit test for function update_query_params
def test_update_query_params():
    actual = update_query_params('http://example.com?foo=bar&biz=baz',
                                 dict(foo='stuff', biz='buzz'))
    assert actual == 'http://example.com?foo=stuff&biz=buzz'

test_update_query_params()

# Generated at 2022-06-21 22:36:03.851863
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'


# Generated at 2022-06-21 22:36:06.757909
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-21 22:36:13.337856
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(foo="stuff")) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar#hash', dict(foo='stuff')) == 'http://example.com?foo=stuff#hash'

# Generated at 2022-06-21 22:36:15.807752
# Unit test for function update_query_params
def test_update_query_params():
    url = "https://example.com?foo=bar&biz=baz"
    url = update_query_params(url, dict(foo='stuff'))
    assert url == "https://example.com?biz=baz&foo=stuff"

# Generated at 2022-06-21 22:36:26.798568
# Unit test for function update_query_params

# Generated at 2022-06-21 22:36:33.148074
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    kwargs = {'foo': 'stuff', 'extra': 'bacon'}
    updated_url = update_query_params(url, kwargs)
    assert updated_url == 'http://example.com?biz=baz&foo=stuff&extra=bacon'
    print(updated_url)


if "__name__" == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:36:38.784783
# Unit test for function update_query_params
def test_update_query_params():
    params = {'a': 1,  'b': 2, 'c': 'abc'}
    url = 'http://www.google.com/search?q=aaaa'
    url_updated = update_query_params(url, params)
    print('url_updated=', url_updated)
    assert url_updated == 'http://www.google.com/search?a=1&b=2&c=abc&q=aaaa'


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:36:44.787247
# Unit test for function update_query_params
def test_update_query_params():
    # No arguments
    assert update_query_params(None, None) == ""

    # Empty arguments
    assert update_query_params("", {}) == ""

    # Empty arguments
    assert update_query_params("http://www.google.com", {}) == "http://www.google.com"

    # Adding one parameter
    assert update_query_params("http://www.google.com", {'foo': 'bar'}) == "http://www.google.com?foo=bar"

    # Adding two parameters
    assert update_query_params("http://www.google.com", {'foo': 'bar', 'biz': 'baz'}) == "http://www.google.com?foo=bar&biz=baz"

    # Adding existing parameter

# Generated at 2022-06-21 22:36:55.168898
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo':'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo':'stuff', 'foo': 'stuff2'}) == 'http://example.com?foo=stuff2&biz=baz'

# Generated at 2022-06-21 22:37:51.157133
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {}) == 'http://example.com'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?foo=stuff&biz=buzz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:37:58.134862
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'bar': 'blah'}) == 'http://example.com?bar=blah&biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'blah': []}) == 'http://example.com?biz=baz&foo=bar&blah='


if __name__ == '__main__':
    print('Running unit tests')
    test_update_query_params()

# Generated at 2022-06-21 22:38:01.291882
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:38:11.402283
# Unit test for function update_query_params
def test_update_query_params():
    test_url1 = 'http://example.com?foo=bar&biz=baz'
    test_url2 = 'http://example.com'
    test_url3 = 'http://example.com?foo=bar&biz=baz'

    expected1 = 'http://example.com?foo=stuff&biz=baz'
    expected2 = 'http://example.com?foo=bar'
    expected3 = 'http://example.com?foo=stuff&biz=baz'

    assert expected1 == update_query_params(test_url1, dict(foo='stuff'))
    assert expected2 == update_query_params(test_url2, dict(foo='bar'))
    assert expected3 == update_query_params(test_url3, dict(foo='stuff'))

# Generated at 2022-06-21 22:38:14.588296
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:38:17.204708
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == 'http://example.com?biz=baz&foo=stuff'

