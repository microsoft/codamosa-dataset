

# Generated at 2022-06-21 22:28:20.529519
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected = 'http://example.com?biz=baz&foo=stuff'
    result = update_query_params(url, dict(foo='stuff'))
    assert_equal(result, expected)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:28:25.104930
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('https://www.zalando.de/adidas-superstar-turnschuhe-low-ad111s02p-a12.html?n=2&su=true') == 'https://www.zalando.de/adidas-superstar-turnschuhe-low-ad111s02p-a12.html?n=2&su=true&sale=yes'

# Generated at 2022-06-21 22:28:34.376455
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff&biz=stuff2')) == 'http://example.com?foo=stuff%26biz%3Dstuff2&biz=baz' # Preserve '&'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff&biz=stuff2')) == 'http://example.com?foo=stuff%26biz%3Dstuff2&biz=baz' # Preserve '&'

# Generated at 2022-06-21 22:28:42.879039
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'

    expected_url = 'http://example.com?biz=baz&foo=stuff'
    actual_url = update_query_params(url, dict(foo='stuff'))

    assert expected_url == actual_url
    print('expected_url: {}'.format(expected_url))
    print('actual_url: {}'.format(actual_url))


# Start test
if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:28:54.896381
# Unit test for function update_query_params
def test_update_query_params():
    assert u'http://example.com/?foo=biz&bar=foo' == update_query_params(u'http://example.com/?bar=foo', dict(foo=u'biz'))
    assert u'http://example.com/?foo=stuff&bar=foo' == update_query_params(u'http://example.com/?foo=bar&bar=foo', dict(foo=u'stuff'))
    assert u'http://example.com/?foo=stuff&bar=foo' == update_query_params(u'http://example.com/?foo=bar&bar=foo', dict(foo=[u'stuff']))

    # Testing if we can add a new param

# Generated at 2022-06-21 22:28:59.624685
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(bar='stuff')) == 'http://example.com?bar=stuff&biz=baz&foo=bar'
test_update_query_params()



# Generated at 2022-06-21 22:29:08.456865
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) \
        == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) \
        == 'http://example.com?foo=stuff'



# Generated at 2022-06-21 22:29:11.388495
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?...biz=baz...foo=stuff' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))


# Generated at 2022-06-21 22:29:21.473543
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(foo='stuff')) == new_url
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = 'http://example.com?biz=baz'
    assert update_query_params(url, dict(foo=None)) == new_url

# Generated at 2022-06-21 22:29:30.868043
# Unit test for function update_query_params
def test_update_query_params():
    simple_url = 'http://example.com'
    params = {'foo': 'bar'}
    simple_answer = 'http://example.com?foo=bar'
    assert simple_answer == update_query_params(simple_url, params)

    complex_url = 'http://example.com?test=test&test2=test2'
    complex_answer = 'http://example.com?test=test&test2=test2&new=new'
    params = {'new': 'new'}
    assert complex_answer == update_query_params(complex_url, params)

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:29:43.700518
# Unit test for function update_query_params

# Generated at 2022-06-21 22:29:48.569577
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test function for function update_query_params
    """
    url = "http://example.com?foo=bar&biz=baz"
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert new_url == "http://example.com?biz=baz&foo=stuff"


# Generated at 2022-06-21 22:29:50.830400
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com/?foo=bar&bar=foo", dict(foo="stuff")) == "http://example.com/?foo=stuff&bar=foo"



# Generated at 2022-06-21 22:29:52.627414
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) \
        == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:29:59.302691
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
           'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='stuff')) == \
           'http://example.com?foo=bar&biz=stuff'

# Generated at 2022-06-21 22:30:01.839285
# Unit test for function update_query_params
def test_update_query_params():

    # Arrange
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo':'stuff', 'hamburger':'awesome'}
    expected_url = 'http://example.com?foo=stuff&hamburger=awesome&biz=baz'

    # Act
    actual_url = update_query_params(url, params)

    # Assert
    assert expected_url == actual_url

# Generated at 2022-06-21 22:30:07.394380
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    actual_url = update_query_params(url, dict(foo='stuff'))
    expected_url = 'http://example.com?biz=baz&foo=stuff'
    assert actual_url == expected_url



# Generated at 2022-06-21 22:30:18.445747
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(url='http://example.com?foo=bar&biz=baz', params=dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url='http://example.com?foo=bar&biz=baz', params=dict(foo='stuff', bar=1)) == 'http://example.com?foo=stuff&biz=baz&bar=1'
    assert update_query_params(url='http://example.com', params=dict(foo='stuff')) == 'http://example.com?foo=stuff'

# Generated at 2022-06-21 22:30:30.293946
# Unit test for function update_query_params
def test_update_query_params():
    # Test a url query string with no previous query params
    url = "http://example.com"
    new_url = update_query_params(url, {'biz':'baz', 'foo':'bar'})
    assert(new_url == "http://example.com?biz=baz&foo=bar")

    # Test a url query string with existing query params.
    # Assert that the new params replace the old ones.
    url = "http://example.com?foo=baz"
    new_url = update_query_params(url, {'biz':'baz', 'foo':'bar'})
    assert(new_url == "http://example.com?biz=baz&foo=bar")

    # Test a url query string with some existing query params.
    # Assert that the new params are added to the

# Generated at 2022-06-21 22:30:42.641580
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
        'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='things')) == \
        'http://example.com?biz=things&foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == \
        'http://example.com?foo=stuff'

# Generated at 2022-06-21 22:30:48.278090
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:30:55.802227
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(new_param='new_value')) == 'http://example.com?biz=baz&foo=bar&new_param=new_value'



# Generated at 2022-06-21 22:30:58.648790
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-21 22:31:01.669758
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-21 22:31:07.511665
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com/foo/bar?stuff=things&other=whatnot',
        dict(foo='bar', stuff='nonsense')
    ) == 'http://example.com/foo/bar?...foo=bar...'



# Generated at 2022-06-21 22:31:12.529033
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo' : 'stuff'}
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-21 22:31:15.821263
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:31:25.621814
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {'foo': 'stuff'}) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?', {'foo': 'stuff'}) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', {'foo': 'stuff'}) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-21 22:31:28.903945
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:31:36.069895
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='baz', foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    print('All test for update_query_params passed.')


# Generated at 2022-06-21 22:31:45.320090
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    params = {"foo": "stuff"}
    assert update_query_params(url, params) == "http://example.com?biz=baz&foo=stuff"

# Generated at 2022-06-21 22:31:54.669535
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?biz=baz&foo=stuff'

    new_url = update_query_params(url, dict(biz='baz2'))
    assert new_url == 'http://example.com?biz=baz2&foo=bar'

    new_url = update_query_params(url, dict(biz=['baz1', 'baz2']))
    assert new_url == 'http://example.com?biz=baz1&biz=baz2&foo=bar'


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:32:02.309818
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    print('Passed')

# Test with no parameters
test_update_query_params()

# Test with additional parameters
test_update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', baz='blah'))

# Generated at 2022-06-21 22:32:08.934175
# Unit test for function update_query_params
def test_update_query_params():
    sample_url = "https://example.com?foo=bar&biz=baz"
    sample_params = dict(foo='stuff')

    actual_result = update_query_params(sample_url, sample_params)
    expected_result = "https://example.com?biz=baz&foo=stuff"

    assert actual_result == expected_result, "Wrong! Expected '{}' but got '{}'".format(expected_result, actual_result)

# Run the unit test for the function update_query_params
test_update_query_params()

# Generated at 2022-06-21 22:32:17.940112
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz', dict(foo='stuff&baz=123')) == 'http://example.com?foo=stuff%26baz%3D123&biz=baz'
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz', dict(foo='stuff'), False) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-21 22:32:29.065431
# Unit test for function update_query_params
def test_update_query_params():
    
    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert url == 'http://example.com?biz=baz&foo=stuff'
    
    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['qux', 'quux']))
    assert url == 'http://example.com?biz=baz&foo=qux&foo=quux'

    url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False)
    assert url == 'http://example.com?biz=baz&foo'


# Generated at 2022-06-21 22:32:34.606740
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff', biz='batz'))
    assert new_url == 'http://example.com?biz=batz&foo=stuff'


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:32:42.201252
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expect = 'http://example.com?foo=stuff&biz=baz'
    actual = update_query_params(url, params)
    assert expect == actual


if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod()

    if len(sys.argv) > 1:
        test_update_query_params()

# Generated at 2022-06-21 22:32:46.843145
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:32:54.654008
# Unit test for function update_query_params
def test_update_query_params():
    
    print("Testing update_query_params")

    test1 = str(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    if test1 != 'http://example.com?biz=baz&foo=stuff':
        print("Error! Test 1 Failed!")
    
    test2 = str(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', new='param')))
    if test2 != 'http://example.com?biz=baz&foo=stuff&new=param':
        print("Error! Test 2 Failed!")
    else:
        print("Passed!")


# Generated at 2022-06-21 22:33:14.461115
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://test.com?foo=stuff' == update_query_params('http://test.com?foo=bar', {'foo': 'stuff'})
    assert 'http://test.com?foo=stuff' == update_query_params('http://test.com?foo=bar', {'foo': 'stuff'})
    assert 'http://test.com?foo=stuff' == update_query_params('http://test.com', {'foo': 'stuff'})
    assert 'http://test.com?foo=stuff&bar=baz' == update_query_params('http://test.com', {'foo': 'stuff', 'bar': 'baz'})

# Generated at 2022-06-21 22:33:18.597752
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo':'stuff'}) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:33:22.521008
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:33:29.894207
# Unit test for function update_query_params
def test_update_query_params():
    # Case 1: new query parameters
    url = 'http://example.com'
    params = {'foo': 'bar'}
    params_expected = {'foo': ['bar']}
    assert params_expected == urlparse.parse_qs(urlparse.urlsplit(update_query_params(url, params))[3])

    # Case 2: update existing query parameter
    url = 'http://example.com?foo=bar'
    params = {'foo': 'stuff'}
    params_expected = {'foo': ['stuff']}
    assert params_expected == urlparse.parse_qs(urlparse.urlsplit(update_query_params(url, params))[3])

    # Case 3: add query parameter
    url = 'http://example.com?foo=bar'
    params = {'stuff': 'morestuff'}

# Generated at 2022-06-21 22:33:32.040702
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    url2 = update_query_params(url, {'foo': 'stuff'})
    expected = 'http://example.com?biz=baz&foo=stuff'
    assert(url2 == expected)

print(update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}))

# Generated at 2022-06-21 22:33:35.035745
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:33:42.085187
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff')
    assert(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='things')) == 'http://example.com?biz=things&foo=stuff')
    assert(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='things', wiz='wow')) == 'http://example.com?biz=things&foo=stuff&wiz=wow')

# Generated at 2022-06-21 22:33:52.744713
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&foo=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?foo=stuff&foo=baz'

# Generated at 2022-06-21 22:33:56.118776
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://demo.example.com/index.php?foo=bar&biz=baz'
    new_url = update_query_params(url, {'foo': 'stuff'})
    print(new_url)
    assert new_url == 'http://demo.example.com/index.php?foo=stuff&biz=baz'

# Generated at 2022-06-21 22:34:03.585448
# Unit test for function update_query_params
def test_update_query_params():
    input_url = "http://example.com?foo=bar&biz=baz"
    input_params = dict(foo="stuff")
    output_url = update_query_params(input_url, input_params)

    expected_url = "http://example.com?foo=stuff&biz=baz"
    print("output: %s" % output_url)
    print("expected: %s" % expected_url)
    assert output_url == expected_url

# Generated at 2022-06-21 22:34:33.087682
# Unit test for function update_query_params
def test_update_query_params():
    assert "http://example.com?foo=stuff&biz=baz" == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert "http://example.com?foo=stuff&biz=baz" == update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'})
    assert "http://example.com" == update_query_params('http://example.com', {})

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    print("Running unit tests")
    test_update_query_params()

# Generated at 2022-06-21 22:34:39.264334
# Unit test for function update_query_params
def test_update_query_params():
    print("Testing function update_query_params()")
    test_url = "http://example.com?foo=bar&biz=baz"
    test_params = {"foo": "stuff"}
    expected_url = "http://example.com?foo=stuff&biz=baz"
    uqp_url = update_query_params(test_url, test_params)
    print("test_url: {}".format(test_url))
    print("test_params: {}".format(test_params))
    print("expected_url: {}".format(expected_url))
    print("uqp_url: {}".format(uqp_url))
    if uqp_url == expected_url:
        print("SUCCESS")
    else:
        print("FAILURE")
    print()

# Generated at 2022-06-21 22:34:43.502694
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert 'foo=stuff' in new_url


if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-21 22:34:50.998016
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?blah=foo&bluh=biz'
    new_url = update_query_params(url, {'bluh': 'test1', 'test': '123'})
    assert new_url == 'http://example.com?blah=foo&bluh=test1&test=123'
    new_url = update_query_params(new_url, {'bluh': 'test2'}, doseq=False)
    assert new_url == 'http://example.com?blah=foo&bluh=test2&test=123'



# Generated at 2022-06-21 22:34:54.826825
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    """


# Generated at 2022-06-21 22:34:58.967809
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    >>> False
    """
    correct_url = 'http://example.com/?fizz=buzz&foo=bar'
    test_url = update_query_params('http://example.com/?foo=bar', dict(fizz='buzz'))
    assert test_url == correct_url

# Generated at 2022-06-21 22:35:01.589215
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Alias function to urlencode

# Generated at 2022-06-21 22:35:06.387628
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'

# Generated at 2022-06-21 22:35:16.581488
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/'
    params = {'foo': 'bar'}
    r = update_query_params(url, params)
    assert 'foo=bar' in r, "update_query_params(url, params) failed"
    params = {'foo': 'baz'}
    r = update_query_params(url, params)
    assert 'foo=baz' in r and 'foo=bar' not in r, "update_query_params(url, params) failed"

#
# Simple multi-dimensional array implementation as in PHP
#

# Generated at 2022-06-21 22:35:19.478651
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-21 22:35:44.942455
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/path/to/resource?foo=1&foo=2&bar=3'
    expected = 'http://example.com/path/to/resource?foo=3&bar=3&baz=4'
    assert update_query_params(url, {'foo': '3', 'baz': '4'}) == expected



# Generated at 2022-06-21 22:35:46.580421
# Unit test for function update_query_params
def test_update_query_params():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:35:48.637937
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:35:52.160058
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com/?biz=baz&foo=stuff'



# Generated at 2022-06-21 22:35:54.228554
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://e?foo=foo1&bar=bar' == update_query_params('http://e?foo=foo&bar=bar', {'foo': 'foo1'})

# Generated at 2022-06-21 22:36:04.667957
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://www.example.com/?id=11111&campaignid=22222'
    res = update_query_params(url, dict(campaignid='333'))
    assert res == 'http://www.example.com/?campaignid=333&id=11111'
    res = update_query_params(url, dict(campaignid='333', id='444'))
    assert res == 'http://www.example.com/?campaignid=333&id=444'
    res = update_query_params(url, dict(campaignid='333', id='444'))
    assert res == 'http://www.example.com/?campaignid=333&id=444'
    res = update_query_params(url, dict(campaignid='333', id='444'), doseq=False)

# Generated at 2022-06-21 22:36:14.222919
# Unit test for function update_query_params
def test_update_query_params():
    # Testing the case of update_query_params, when adding or modifying parameters in an existing query string
    assert (
        update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
        == 'http://example.com?biz=baz&foo=stuff'
        )
    # Testing the case of update_query_params, when adding parameters without query string
    assert (
        update_query_params('http://example.com', dict(foo='stuff'))
        == 'http://example.com?foo=stuff'
        )
    # Testing the case of update_query_params, when adding parameters to an empty URL string
    assert (
        update_query_params('', dict(foo='stuff'))
        == '?foo=stuff'
        )



# Generated at 2022-06-21 22:36:26.670090
# Unit test for function update_query_params
def test_update_query_params():
    input_map = [
        ('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), 'http://example.com?foo=stuff&biz=baz'),
        ('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzzzz'), 'http://example.com?foo=stuff&biz=buzzzz'),
        (
            'http://example.com?foo=bar&biz=baz',
            dict(foo=['stuff'], biz=['buzzzz', 'stuff']),
            'http://example.com?foo=stuff&biz=buzzzz&biz=stuff'
        )
    ]


# Generated at 2022-06-21 22:36:32.494761
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baz')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-21 22:36:40.642015
# Unit test for function update_query_params
def test_update_query_params():
    test_dict = {
        'http://example.com?foo=bar&biz=baz':
            {'foo': 'stuff'},
        'http://example.com?foo=bar&biz=baz':
            {'foo': ['stuff', 'thing'] },
        'http://example.com': {'foo': 'bar'},
        'http://example.com/': {'foo': 'bar'},
        'http://example.com#bar': {'foo': 'bar'},
        u'http://example.com': {'foo': 'bar'},
    }
    for url, params in test_dict.items():
        result = update_query_params(url, params)
        expected = urlparse.urljoin(url, '?' + urlencode(params))

        assert result == expected

# Generated at 2022-06-21 22:37:31.858567
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff', biz='baz')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff', biz='baz'), False) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:37:36.572428
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    True
    """
    url = 'http://example.com?foo=bar&biz=baz'
    actual = update_query_params(url, dict(foo='stuff'))
    expected = 'http://example.com?foo=stuff&biz=baz'
    print(actual)
    print(expected)
    assert actual == expected
    return True

#print test_update_query_params()


# Generated at 2022-06-21 22:37:47.563767
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com/?foo=bar', {'foo': 'stuff'}) == 'http://example.com/?foo=stuff'
    assert update_query_params('http://example.com/?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com/?foo=stuff&biz=baz'
    assert update_query_params('http://example.com/?foo=bar', {'foo': 'stuff', 'biz': 'baz'}) == 'http://example.com/?foo=stuff&biz=baz'
    assert update_query_params('http://example.com/?foo=bar', {}) == 'http://example.com/?foo=bar'

# Generated at 2022-06-21 22:37:51.359757
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    result_url = update_query_params(url, dict(foo='stuff'))
    assert result_url == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-21 22:37:56.633749
# Unit test for function update_query_params
def test_update_query_params():
    print('start test_update_query_params')
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff',bar='buk')) == 'http://example.com?bar=buk&biz=baz&foo=stuff'
    return 'Okay'



# Generated at 2022-06-21 22:38:03.029546
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:38:05.872662
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    params = {
        'foo': 'stuff',
        'hello': ['world'],
    }

    new_url = update_query_params(test_url, params)
    assert isinstance(new_url, str)
    assert 'http://example.com?foo=stuff&biz=baz&hello=world' == new_url


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:38:14.325182
# Unit test for function update_query_params
def test_update_query_params():

    first_url = 'http://example.com?foo=bar&biz=baz'
    second_url = update_query_params(first_url, dict(foo='stuff'))
    assert second_url == 'http://example.com?foo=stuff&biz=baz'

    first_url = 'http://example.com?foo=bar&biz=baz'
    second_url = update_query_params(first_url, dict(foo='stuff', biz='boom'))
    assert second_url == 'http://example.com?foo=stuff&biz=boom'