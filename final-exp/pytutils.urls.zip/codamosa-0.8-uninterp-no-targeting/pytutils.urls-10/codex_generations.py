

# Generated at 2022-06-21 22:28:24.021747
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(a='b')) == 'http://example.com?a=b'
    assert update_query_params('http://example.com?c=d', dict(a='b')) == 'http://example.com?c=d&a=b'
    assert update_query_params('http://example.com?a=b', dict(c='d')) == 'http://example.com?a=b&c=d'
    assert update_query_params('http://example.com?a=b&c=d', dict(e='f')) == 'http://example.com?a=b&c=d&e=f'

# Generated at 2022-06-21 22:28:29.531150
# Unit test for function update_query_params
def test_update_query_params():
    url_1 = 'http://example.com?foo=bar&biz=baz'
    url_2 = 'http://example.com?foo=stuff&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url_1, params) == url_2

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:28:32.214144
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new = update_query_params(url, dict(foo='stuff'))
    print(new)

test_update_query_params()

# Generated at 2022-06-21 22:28:36.058182
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:28:44.867630
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com/foo?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com/foo?biz=baz&foo=stuff'
    assert update_query_params('http://example.com/foo?biz=baz', dict(foo='stuff')) == 'http://example.com/foo?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:28:48.653489
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    updated_url = update_query_params(url, params)
  

# Generated at 2022-06-21 22:28:54.279699
# Unit test for function update_query_params
def test_update_query_params():

    url = 'https://api.github.com/search/repositories?q=tetris+language:assembly&sort=stars&order=desc'
    print(url)
    params = {"page":2, "per_page" : 100}
    url = update_query_params(url, params, doseq=True)
    print(url)
    return
test_update_query_params()

# Generated at 2022-06-21 22:28:58.875576
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=bar&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert 'http://example.com?foo=bar&biz=baz&foo=stuff' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False)



# Generated at 2022-06-21 22:29:01.209923
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:29:06.108956
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    params = dict(foo='stuff')
    result = update_query_params(url, params)
    assert result == "http://example.com?biz=baz&foo=stuff"

test_update_query_params()

# Generated at 2022-06-21 22:29:12.709131
# Unit test for function update_query_params
def test_update_query_params():
    initial_url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(initial_url, dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(initial_url, dict(biz='stuff')) == 'http://example.com?foo=bar&biz=stuff'
    assert update_query_params(initial_url, dict(foo='stuff', biz='stuff')) == 'http://example.com?foo=stuff&biz=stuff'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:29:25.382084
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    url_result = 'http://example.com?foo=stuff&biz=baz'
    assert url_result == update_query_params(url, dict(foo='stuff'))

    # Test append Query item Param
    url = 'http://example.com?foo=bar&biz=baz'
    url_result = 'http://example.com?foo=bar&biz=baz&foo=stuff'
    assert url_result == update_query_params(url, dict(foo='stuff'), True)

    # Test with existing list query param, should take last one.
    url = 'http://example.com?foo=bar&biz=baz&foo=stuff'

# Generated at 2022-06-21 22:29:35.911874
# Unit test for function update_query_params
def test_update_query_params():
    import unittest
    class TestUpdateQueryParams(unittest.TestCase):
        def test_update_value(self):
            url = 'http://example.com?foo=bar&biz=baz'
            params = dict(foo='stuff')
            expected = 'http://example.com?biz=baz&foo=stuff'
            self.assertEqual(expected, update_query_params(url, params))

        def test_insert_value(self):
            url = 'http://example.com?foo=bar&biz=baz'
            params = dict(foo2='stuff2')
            expected = 'http://example.com?foo=bar&biz=baz&foo2=stuff2'
            self.assertEqual(expected, update_query_params(url, params))

    unittest.main()

# Generated at 2022-06-21 22:29:46.739966
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='newbaz')) == 'http://example.com?biz=newbaz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='newbaz&foo=stuff')) == 'http://example.com?biz=newbaz%26foo%3Dstuff&foo=bar'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:29:51.579679
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'poo':'pap'}) == 'http://example.com?biz=baz&foo=stuff&poo=pap'




# Generated at 2022-06-21 22:29:56.216998
# Unit test for function update_query_params
def test_update_query_params():
    text = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert text == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-21 22:30:02.495159
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test the update_query_params method.
    :return:
    """
    input_url = 'http://example.com?foo=bar&biz=baz'
    expected_url = 'http://example.com?foo=stuff&biz=baz'

    updated_url = update_query_params(input_url, dict(foo='stuff'))

    assert updated_url == expected_url



# Generated at 2022-06-21 22:30:08.687350
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    print('Passed test_update_query_params')

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:30:13.650712
# Unit test for function update_query_params
def test_update_query_params():
    url = "https://www.example.com/login/?next=/secure/index/"
    print("before: " + url)
    url2 = update_query_params(url, dict(foo='bar'))
    print("after: " + url2)

if __name__ == "__main__":
    # execute only if run as a script
    test_update_query_params()

# Generated at 2022-06-21 22:30:16.870577
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://localhost:8080?filter=1", filter=2, filter_type="AZ") == \
           "http://localhost:8080?filter=2&filter_type=AZ"


# Generated at 2022-06-21 22:30:28.103458
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://127.0.0.1:8080/search?start=0&limit=50'
    params = dict(limit=20)
    expected_url = 'http://127.0.0.1:8080/search?limit=20&start=0'

    new_url = update_query_params(url, params)
    assert new_url == expected_url



# Generated at 2022-06-21 22:30:33.661429
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(test_url, {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(test_url, {'foo': 'stuff', 'biz': 'stuff'}) == 'http://example.com?biz=stuff&foo=stuff'
    assert update_query_params(test_url, {'another': 'param'}) == 'http://example.com?another=param&biz=baz&foo=bar'


# Generated at 2022-06-21 22:30:41.899810
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?foo=stuff&biz=baz'

    # Test case when the query parameter doesn't exist in the URL
    new_url = update_query_params(url, dict(a='stuff'))
    assert new_url == 'http://example.com?foo=bar&biz=baz&a=stuff'

# Generated at 2022-06-21 22:30:48.698824
# Unit test for function update_query_params
def test_update_query_params():
    # 1st test: no update (should return default)
    print(update_query_params('http://example.com?foo=bar&biz=baz', {}))

    # 2nd test: one item update
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))

    # 3rd test: more than one item update
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='bang')))


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:30:59.748270
# Unit test for function update_query_params
def test_update_query_params():
    assert 'https://demo.scraperwiki.com/foo?a=1&b=2' == update_query_params('https://demo.scraperwiki.com/foo?a=1', {'b': 2})
    assert 'https://demo.scraperwiki.com/foo?a=1&b=2' == update_query_params('https://demo.scraperwiki.com/foo?b=2', {'a': 1})
    assert 'https://demo.scraperwiki.com/foo?a=1' == update_query_params('https://demo.scraperwiki.com/foo?b=2', {'a': 1}, doseq=False)

# Generated at 2022-06-21 22:31:03.910971
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:31:17.445667
# Unit test for function update_query_params
def test_update_query_params():
    url='http://example.com?foo=bar'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params(url, dict(foo='stuff', biz='baz')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url, dict(funny=['biz','baz'])) == 'http://example.com?foo=bar&funny=biz&funny=baz'
    assert update_query_params(url, dict(funny=['biz','boz'])) == 'http://example.com?foo=bar&funny=biz&funny=boz'

# Generated at 2022-06-21 22:31:26.656111
# Unit test for function update_query_params
def test_update_query_params():
    # Update existing parameter
    assert update_query_params('http://example.com?foo=bar', {'foo':'new'}) == 'http://example.com?foo=new'

    # Update existing parameter with new value
    assert update_query_params('http://example.com?foo=bar', {'foo':'new'}) == 'http://example.com?foo=new'

    # Add parameter
    assert update_query_params('http://example.com?foo=bar', {'russian':'doll'}) == 'http://example.com?foo=bar&russian=doll'

    # Test unicode characters
    assert update_query_params('http://example.com?foo=bar', {u'ünicøde': u'ünîcødé'})


# Example for usage

# Generated at 2022-06-21 22:31:32.731485
# Unit test for function update_query_params
def test_update_query_params():
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff')
    assert (update_query_params('http://example.com?biz=baz&foo=bar', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff')
    assert (update_query_params('http://example.com?biz=baz&foo=bar', dict(bar='stuff')) == 'http://example.com?bar=stuff&biz=baz&foo=bar')
    assert (update_query_params('http://example.com?biz=baz', dict(bar='stuff')) == 'http://example.com?bar=stuff&biz=baz')

# Generated at 2022-06-21 22:31:43.976302
# Unit test for function update_query_params
def test_update_query_params():
    #url1 = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    #assert(url1 == 'http://example.com?...foo=stuff...')
    url2 = update_query_params('http://example.com', dict(foo='stuff'))
    assert(url2 == 'http://example.com?foo=stuff')
    url3 = update_query_params('http://example.com?foo=bar', dict(foo='stuff', biz='baz'))
    assert(url3 == 'http://example.com?foo=stuff&biz=baz')
    url4 = update_query_params('http://example.com#anchor', dict(foo='stuff', biz='baz'))

# Generated at 2022-06-21 22:32:04.539176
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://www.google.com"
    params = {'foo':'stuff'}
    assert update_query_params(url, params) == "http://www.google.com?foo=stuff"
    params = {'foo':'stuff', 'go':'away'}
    assert update_query_params(url, params) == "http://www.google.com?foo=stuff&go=away"
    params = {'foo':'stuff', 'biz':'baz'}
    assert update_query_params(url, params) == "http://www.google.com?foo=stuff&biz=baz"

# test_update_query_params()

# Generated at 2022-06-21 22:32:08.933972
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://search.example.com/search.html?q=foo&sa=Google+Search"
    url2 = update_query_params(url, dict(q="bar", biz="baz"))
    print(url2)
    assert url2 == 'http://search.example.com/search.html?q=bar&biz=baz&sa=Google+Search'



# Generated at 2022-06-21 22:32:14.667990
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', baz="new")) == 'http://example.com?biz=baz&foo=stuff&baz=new'


# Generated at 2022-06-21 22:32:26.391658
# Unit test for function update_query_params
def test_update_query_params():
    """Unit test for function update_query_params"""
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff')
    ) == "http://example.com?biz=baz&foo=stuff"

    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo=['stuff', 'morestuff'])
    ) == "http://example.com?biz=baz&foo=stuff&foo=morestuff"


# Unit tests
#

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:32:37.006409
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='bar')) == 'http://example.com?bar=bar&biz=baz&foo=stuff'


# Table of common characters with their names and accented forms.
# From https://github.com/lepture/mistune

# Generated at 2022-06-21 22:32:48.577846
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buz')) == 'http://example.com?foo=stuff&biz=buz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='a=b')) == 'http://example.com?biz=baz&foo=a%3Db'

# Generated at 2022-06-21 22:32:56.165762
# Unit test for function update_query_params
def test_update_query_params():
    # Update existing parameters
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    # Add parameters
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'bar': 'stuff'}) == 'http://example.com?bar=stuff&biz=baz&foo=bar'
    # Remove parameters
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': ''}) == 'http://example.com?biz=baz'
    # URL-encode parameters

# Generated at 2022-06-21 22:33:00.463595
# Unit test for function update_query_params
def test_update_query_params():
    result = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert result == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:33:03.757420
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz')

# Generated at 2022-06-21 22:33:11.479892
# Unit test for function update_query_params
def test_update_query_params():
    """
    Tests for the update_query_params function
    """
    assert(update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz')
    assert(update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff', 'biz': 'buzz'}) == 'http://example.com?foo=stuff&biz=buzz')
    assert(update_query_params('http://example.com?foo=bar&biz=baz', {'foo': ['stuff', 'thing']}) == 'http://example.com?foo=stuff&foo=thing&biz=baz')

# Generated at 2022-06-21 22:33:29.372938
# Unit test for function update_query_params
def test_update_query_params():
  """
  Test function update_query_params
  """
  assert update_query_params("http://example.com", dict(foo="bar")) == "http://example.com?foo=bar"
  assert update_query_params("http://example.com?foo=bar", dict(foo="biz")) == "http://example.com?foo=biz"
  assert update_query_params("http://example.com?foo=bar", dict(biz="baz")) == "http://example.com?foo=bar&biz=baz"
  assert update_query_params("http://example.com?foo=bar&biz=baz", dict(biz="biz")) == "http://example.com?foo=bar&biz=biz"

# Generated at 2022-06-21 22:33:33.422625
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:33:36.746466
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff')
    ) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:33:41.578183
# Unit test for function update_query_params
def test_update_query_params():
  expected = 'http://example.com?foo=stuff&biz=baz'
  actual = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
  assert expected == actual
  assert "stuff" in actual


if __name__ == "__main__":
  test_update_query_params()

# Generated at 2022-06-21 22:33:50.379618
# Unit test for function update_query_params
def test_update_query_params():
    url_params = {
        'http://example.com?foo=bar&biz=baz': {'foo': 'stuff'},
        'http://example.com?foo=bar&biz=baz': {'foo': 'stuff', 'foo2': 'stuff2'},
        }
    for url, params in url_params.items():
        new_url_expect = update_query_params(url, params)
        new_url = url
        for key, value in params.items():
            new_url = update_query_params(new_url, params)
        assert new_url == new_url_expect


# Generated at 2022-06-21 22:33:57.968925
# Unit test for function update_query_params
def test_update_query_params():
    url_with_query_string = u'http://example.com?foo=bar&biz=baz'
    url_without_query_string = u'http://example.com'
    url_with_fragment = u'http://example.com#foo'

    # update the foo query param in the query string
    assert update_query_params(url_with_query_string, dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

    # insert a new query param
    assert update_query_params(url_with_query_string, dict(baz='stuff')) == 'http://example.com?foo=bar&biz=baz&baz=stuff'

    # add a query string to a URL with no query string

# Generated at 2022-06-21 22:34:08.057351
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?biz=buzz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict()) == 'http://example.com?biz=baz&foo=bar'

# Generated at 2022-06-21 22:34:12.730567
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?name=John+Smith&age=37'
    params = {'age': 38}
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?age=38&name=John+Smith'

test_update_query_params()

# Generated at 2022-06-21 22:34:23.622427
# Unit test for function update_query_params
def test_update_query_params():
    url1 = 'http://example.com?foo=bar&biz=baz'
    url2 = 'http://example.com?foo=bar&biz=baz&biz=baf'
    assert update_query_params(url1, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url1, dict(foo=['stuff', 'things'])) == 'http://example.com?biz=baz&foo=stuff&foo=things'
    assert update_query_params(url1, dict(foo='stuff', biz='things')) == 'http://example.com?biz=things&foo=stuff'

# Generated at 2022-06-21 22:34:32.932641
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=bar&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict())
    assert 'http://example.com?foo=stuff&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert 'http://example.com?foo=stuff&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff']))
    assert 'http://example.com?foo=stuff&biz=baz' == update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baz'))

# Generated at 2022-06-21 22:34:56.933693
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-21 22:34:59.187439
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-21 22:35:06.613003
# Unit test for function update_query_params
def test_update_query_params():
    test_url = "https://www.example.com/foo?bar=1&biz=2&baz=3"
    assert update_query_params(test_url, {"bar": "1", "biz": "2", "baz": "3"}) == test_url
    assert update_query_params(test_url, {"bar": "1", "biz": "2", "baz": "3", "bif": "4"}) == "https://www.example.com/foo?bar=1&biz=2&baz=3&bif=4"

# Generated at 2022-06-21 22:35:19.317480
# Unit test for function update_query_params
def test_update_query_params():
    import bs4
    import collections


# Generated at 2022-06-21 22:35:23.258489
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test function update_query_params
    """
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:35:31.800855
# Unit test for function update_query_params
def test_update_query_params():
    from urllib import urlencode

    url = 'http://example.com?foo=bar&biz=baz'
    kwargs = {'foo': 'stuff'}
    new_url = update_query_params(url, params=kwargs)
    assert new_url == 'http://example.com?foo=stuff&biz=baz'
    assert new_url == 'http://example.com?biz=baz&foo=stuff'

    url = 'http://example.com?foo=bar&biz=baz'
    kwargs = {'widget': 'stuff'}
    new_url = update_query_params(url, params=kwargs)
    assert new_url == 'http://example.com?foo=bar&biz=baz&widget=stuff'


# Generated at 2022-06-21 22:35:36.009129
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://www.example.com/blah?foo=bar&biz=baz', {'biz':'buzz'}) == 'http://www.example.com/blah?foo=bar&biz=buzz'
    assert update_query_params('http://www.example.com/blah?foo=bar&biz=baz', {'biz':['buzz','buzz2']}) == 'http://www.example.com/blah?foo=bar&biz=buzz&biz=buzz2'


# Generated at 2022-06-21 22:35:44.194200
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test for function update_query_params
    """
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', foo2='bar2')) == 'http://example.com?foo=stuff&biz=baz&foo2=bar2'
    assert update_query_params('http://example.com', dict(foo='stuff', foo2='bar2')) == 'http://example.com?foo=stuff&foo2=bar2'


# Generated at 2022-06-21 22:35:51.018271
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == 'http://example.com?foo=stuff&biz=baz'
    # TODO: Make sure 'foo=bar&foo=stuff&biz=baz' is not returned


# Use a dict mapping country codes to country names.
# Add your own country if you want to translate it.
# http://en.wikipedia.org/wiki/List_of_countries_by_two-letter_code
# http://en.wikipedia.org/wiki/ISO_3166-1

# Generated at 2022-06-21 22:35:56.643549
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baz')) == 'http://example.com?biz=baz&foo=stuff'

test_update_query_params()

# Generated at 2022-06-21 22:36:23.237474
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:36:26.141806
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:36:33.772213
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected_url = 'http://example.com?foo=stuff&biz=baz'
    params = {'foo': 'stuff'}
    result_url = update_query_params(url, params, doseq=True)
    if result_url != expected_url:
        raise Exception("result_url expected: " + expected_url + " result_url: "+ result_url)

# Generated at 2022-06-21 22:36:36.760968
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:36:44.047598
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test for function update_query_params
    """
    # Example 1
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'

    # Example 2
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

    # Example 3
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='biz')) == 'http://example.com?foo=stuff&biz=biz'

    # Example 4

# Generated at 2022-06-21 22:36:54.478156
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == "http://example.com?foo=stuff&biz=baz"
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff', wiz='toto')) == "http://example.com?foo=stuff&biz=baz&wiz=toto"
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff', biz='toto')) == "http://example.com?foo=stuff&biz=toto"

# Generated at 2022-06-21 22:37:03.377121
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='stuff')) == 'http://example.com?foo=stuff&biz=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'junk'], biz='stuff')) == 'http://example.com?foo=stuff&foo=junk&biz=stuff'

# Generated at 2022-06-21 22:37:10.318598
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='stuff')) == 'http://example.com?foo=stuff&biz=baz&bar=stuff'

# Generated at 2022-06-21 22:37:17.888853
# Unit test for function update_query_params
def test_update_query_params():
    url = 'https://www.google.com/'
    params = dict(q='b')
    assert 'q=b' in update_query_params(url, params)
    params = dict(q='a')
    assert 'q=a' in update_query_params(url, params)
    url = 'https://www.google.com/?biz=baz'
    params = dict(foo='stuff')
    assert 'foo=stuff' in update_query_params(url, params)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:37:19.693483
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

test_update_query_params()

# Generated at 2022-06-21 22:38:13.024268
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', {'foo': 'biz'}) == 'http://example.com?foo=biz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'new': 'param'}) == 'http://example.com?biz=baz&foo=bar&new=param'
    assert update_query_params('http://example.com?foo=bar', {'foo': 'stuff', 'thing': 'else'}) == 'http://example.com?foo=stuff&thing=else'

