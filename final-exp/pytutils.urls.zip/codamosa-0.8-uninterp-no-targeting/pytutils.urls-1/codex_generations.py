

# Generated at 2022-06-21 22:28:24.825807
# Unit test for function update_query_params
def test_update_query_params():

    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff', biz='bizness')) == "http://example.com?biz=bizness&foo=stuff"
    assert update_query_params("https://example.com?foo=bar&biz=baz", dict(foo='stuff')) == "https://example.com?biz=baz&foo=stuff"
    assert update_query_params("http://example.com?foo=bar", dict(foo='stuff', biz='bizness')) == "http://example.com?biz=bizness&foo=stuff"
    assert update_query_params("http://example.com?foo=bar", dict(biz='bizness')) == "http://example.com?biz=bizness&foo=bar"
    assert update_

# Generated at 2022-06-21 22:28:34.085917
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict()) == 'http://example.com?foo=bar&biz=baz'
    assert update_query_params('http://example.com?biz=baz', dict()) == 'http://example.com?biz=baz'

# Generated at 2022-06-21 22:28:39.325274
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com/foo/bar/?search=test&page=1"
    new_url = update_query_params(url, {"page": 2})
    assert new_url == "http://example.com/foo/bar/?page=2&search=test"


# Generated at 2022-06-21 22:28:46.692781
# Unit test for function update_query_params
def test_update_query_params():
    # Check for basic cases
    assert update_query_params("http://www.example.com?foo=bar", {"foo":"stuff"}) == "http://www.example.com?foo=stuff"
    assert update_query_params("http://www.example.com?foo=bar", {"foobar":"stuff"}) == "http://www.example.com?foo=bar&foobar=stuff"
    assert update_query_params("http://www.example.com?foo=bar&foo=bar2", {"foobar":"stuff"}) == "http://www.example.com?foo=bar&foo=bar2&foobar=stuff"
    assert update_query_params("http://www.example.com", {"foo":"bar"}) == "http://www.example.com?foo=bar"

# Generated at 2022-06-21 22:28:53.815245
# Unit test for function update_query_params
def test_update_query_params():
    url_string = 'http://example.com/?foo=bar&foo=bar2&biz=baz'
    url_string_actual = update_query_params(url_string, {'foo':'stuff', 'one':1}, doseq=True)
    url_string_expected = 'http://example.com/?foo=stuff&foo=bar2&biz=baz&one=1'
    assert (url_string_actual == url_string_expected)


# Generated at 2022-06-21 22:29:01.318226
# Unit test for function update_query_params
def test_update_query_params():

    # Tests from the docstring
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) ==
            'http://example.com?biz=baz&foo=stuff')

    # Test when the url does not have any query parameters
    assert (update_query_params('http://example.com', dict(foo='stuff', biz='baz')) ==
            'http://example.com?biz=baz&foo=stuff')

    # Test with empty base url
    assert (update_query_params('', dict(foo='stuff', biz='baz')) ==
            '?biz=baz&foo=stuff')

    # Test with query parameters having single value

# Generated at 2022-06-21 22:29:11.183795
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    'http://example.com?biz=baz&foo=stuff'
    """
    def _test_update_query_params(url, params, expected):
        assert update_query_params(url, params) == expected
        assert update_query_params(url + '?', params) == expected
        assert update_query_params(url + '?', params, False) == expected

    import doctest
    doctest.run_docstring_examples(_test_update_query_params, globals(), verbose=False)

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:29:17.022454
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    updated_url = update_query_params(url, {'foo': 'stuff'})
    assert updated_url == 'http://example.com?foo=stuff&biz=baz'

test_update_query_params()

# Generated at 2022-06-21 22:29:29.351888
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com'
    new_url = update_query_params(url, {'foo' : 'bar'})
    assert new_url == 'http://example.com?foo=bar' , 'Failed to update query param'
    new_url = update_query_params(url, {'foo' : 'bar', 'biz' : 'baz'})
    assert new_url == 'http://example.com?foo=bar&biz=baz' , 'Failed to update query params'
    url = 'http://example.com?foo=bar'
    new_url = update_query_params(url, {'foo' : 'stuff'})
    assert new_url == 'http://example.com?foo=stuff' , 'Failed to update query param'
    new_url = update_query_params

# Generated at 2022-06-21 22:29:38.238247
# Unit test for function update_query_params
def test_update_query_params():
    assert "http://example.com/?foo=stuff&biz=baz" == update_query_params('http://example.com?foo=bar&biz=baz', {"foo": "stuff"})
    assert "http://example.com/?foo=stuff&biz=baz" == update_query_params('http://example.com/?foo=bar&biz=baz', {"foo": "stuff"})
    assert "http://example.com/?foo=stuff&biz=baz" == update_query_params('http://example.com/?foo=bar&biz=baz&foo=more', {"foo": "stuff"})
    assert "http://example.com/?biz=baz&foo=stuff" == update_query_params('http://example.com/?foo=bar&biz=baz', {"foo": "stuff"}, False)

# Generated at 2022-06-21 22:29:44.179726
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&foo=baz&biz=baz'
    assert update_query_params(url, {'foo':'stuff'}) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:29:47.941391
# Unit test for function update_query_params
def test_update_query_params():

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == "http://example.com?foo=stuff&biz=baz"

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:30:00.266176
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', buzz='bazz')) == 'http://example.com?biz=baz&buzz=bazz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', buzz='bazz', luck='lack')) == 'http://example.com?biz=baz&buzz=bazz&foo=stuff&luck=lack'

# Generated at 2022-06-21 22:30:12.456607
# Unit test for function update_query_params
def test_update_query_params():
    print('Test for update_query_params')
    assert update_query_params('http://example.com', {'foo': 'bar'}) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', {'foo': 'stuff'}) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', {'bar': 'stuff'}) == 'http://example.com?foo=bar&bar=stuff'
    assert update_query_params('http://example.com?foo=bar', {'foo': ['bar', 'stuff']}) == 'http://example.com?foo=bar&foo=stuff'
    print('Passed')

if __name__ == '__main__':
    test_update_

# Generated at 2022-06-21 22:30:20.063305
# Unit test for function update_query_params
def test_update_query_params():
    import sys
    if sys.version_info >= (3, 0):
        test_url = 'http://www.example.com?foo=bar&biz=baz'
        assert update_query_params(test_url, dict(foo='stuff')) == 'http://www.example.com/?foo=stuff&biz=baz'
        assert update_query_params(test_url, dict(foo='stuff', bar='stuff2')) == 'http://www.example.com/?foo=stuff&bar=stuff2&biz=baz'



# Generated at 2022-06-21 22:30:31.338808
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff', biz='baz')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:30:35.927493
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-21 22:30:45.077172
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com/?foo=stuff&biz=baz'
    new_url = update_query_params(new_url, dict(foo='stuff', biz='stuff'))
    assert new_url == 'http://example.com/?foo=stuff&biz=stuff'
    new_url = update_query_params(new_url, dict(foo='stuff', biz='bam'))
    assert new_url == 'http://example.com/?foo=stuff&biz=bam'

# Generated at 2022-06-21 22:30:50.758468
# Unit test for function update_query_params
def test_update_query_params():
    """
    Unit test for the update_query_params function.

    :param url: URL
    :type url: str
    :param kwargs: Query parameters
    :type kwargs: dict
    """
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:30:57.714203
# Unit test for function update_query_params
def test_update_query_params():
    from nose.tools import assert_equals
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff', dog='puppy')
    new_url = update_query_params(url, params)
    assert_equals('http://example.com?dog=puppy&biz=baz&foo=stuff', new_url)


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:31:12.842868
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=foobar', dict(biz='baz')) == 'http://example.com?biz=baz&foo=foobar'
    assert update_query_params('http://example.com?foo=foobar', dict(biz=['baz'])) == 'http://example.com?biz=baz&foo=foobar'
    assert update_query_params('http://example.com?foo=foobar', dict(biz=['baz', 'biz'])) == 'http://example.com?biz=#1:baz,biz#&foo=foobar'
    assert update

# Generated at 2022-06-21 22:31:17.919023
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    expected_new_url = 'http://example.com?foo=stuff&biz=baz'
    assert new_url == expected_new_url



# Generated at 2022-06-21 22:31:23.742385
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(foo=['stuff', 'other'])) == 'http://example.com?foo=stuff&foo=other'
test_update_query_params()

# Generated at 2022-06-21 22:31:31.266665
# Unit test for function update_query_params
def test_update_query_params():
    '''
    Check that update_query_params is working properly
    '''
    # Commonly used in tests, so do it first
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='boz')) == 'http://example.com?biz=boz&foo=stuff'

# Generated at 2022-06-21 22:31:42.829885
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://www.example.org?a=b&c=d',
                               {'a': 'z'}) == 'http://www.example.org?a=z&c=d'
    assert update_query_params('http://www.example.org?a=b&c=d',
                               {'a': ['z', 'y']}) == 'http://www.example.org?a=z&a=y&c=d'
    assert update_query_params('http://www.example.org?a=b&c=d',
                               {'e': 'f'}) == 'http://www.example.org?a=b&c=d&e=f'

# Generated at 2022-06-21 22:31:47.783598
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')

    assert update_query_params(url, params) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:31:53.981343
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff'


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:31:56.284325
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params_dict = dict(foo='stuff')
    assert(update_query_params(url, params_dict) == 'http://example.com?biz=baz&foo=stuff')

# End of file

# Generated at 2022-06-21 22:32:00.120599
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

test_update_query_params()

# Generated at 2022-06-21 22:32:05.537244
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == 'http://example.com?foo=stuff&biz=baz'

# Run unit test for function update_query_params
if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:32:17.882573
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    """
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(foo='stuff', biz='stuff')) == 'http://example.com?biz=stuff&foo=stuff'
    assert update_query_params(url, dict(bar='stuff', biz='stuff')) == 'http://example.com?bar=stuff&biz=stuff&foo=bar'


# Generated at 2022-06-21 22:32:29.065077
# Unit test for function update_query_params
def test_update_query_params():
    pass
    # assert update_query_params('http://example.com', dict()) == 'http://example.com'
    # assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?...foo=stuff...'
    # assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baz')) == 'http://example.com?...foo=stuff...&...biz=baz...'
    # assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?...foo=stuff...'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:32:37.508596
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com"
    new_url = update_query_params(url, {'foo': 'bar'})
    assert new_url == 'http://example.com?foo=bar'

    url = "http://example.com?foo=bar"
    new_url = update_query_params(url, {'foo': 'stuff'})
    assert new_url == 'http://example.com?foo=stuff'

    url = "http://example.com?foo=bar&biz=baz"
    new_url = update_query_params(url, {'foo': 'stuff'})
    assert new_url == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:32:39.945617
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    assert new_url == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-21 22:32:51.286025
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'

    # Test case1
    params = {
        'foo': 'stuff'
    }
    assert update_query_params(url, params) == 'http://example.com?foo=stuff&biz=baz'

    # Test case2
    params = {
        'biz': 'stuff'
    }
    assert update_query_params(url, params) == 'http://example.com?foo=bar&biz=stuff'

    # Test case3
    params = {
        'foo': 'stuff',
        'biz': ['stuff', 'things']
    }
    assert update_query_params(url, params) == 'http://example.com?foo=stuff&biz=stuff&biz=things'


# Generated at 2022-06-21 22:33:03.665988
# Unit test for function update_query_params
def test_update_query_params():
    def normalize_url(url):
        url = urlparse.urlparse(url)
        url = url._replace(netloc='example.com')
        url = url.geturl()
        return url

    url = 'http://example.com?a=1&b=2'
    params = {'c': 3}
    expected_url = 'http://example.com?a=1&b=2&c=3'
    result = update_query_params(url, params)
    result = normalize_url(result)
    assert result == expected_url

    url = 'http://example.com?a=1&b=2'
    params = {'a': 3}
    expected_url = 'http://example.com?a=3&b=2'

# Generated at 2022-06-21 22:33:06.911294
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com/path?foo=bar&foo=foos"
    exp = 'http://example.com/path?foo=fubar&foo=foos'
    assert update_query_params(url, dict(foo='fubar')) == exp

# Generated at 2022-06-21 22:33:16.393881
# Unit test for function update_query_params
def test_update_query_params():
    # Try adding a parameter
    url = 'http://example.com?foo=bar'
    result = update_query_params(url, dict(biz='baz'))
    assert result
    assert result == "http://example.com?biz=baz&foo=bar"

    # Add a parameter that should be in front
    result = update_query_params(result, dict(foo='stuff'), doseq=False)
    assert result == "http://example.com?foo=stuff&biz=baz"

    # Try updating a parameter
    url = 'http://example.com?foo=bar&biz=baz'
    result = update_query_params(url, dict(foo='stuff', biz='boop'))

# Generated at 2022-06-21 22:33:22.607502
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?foo=stuff&biz=buzz'

# Generated at 2022-06-21 22:33:27.412914
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    url = update_query_params(url, params)
    if url != 'http://example.com?foo=stuff&biz=baz':
        print("FAIL")
    else:
        print("PASS")


if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:33:35.473809
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://test.com?test=test', {'test': 'test3'}) == 'http://test.com?test=test3'

# End of unit test for function update_query_params


# Generated at 2022-06-21 22:33:38.574145
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

test_update_query_params()

# Generated at 2022-06-21 22:33:42.262437
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo':'stuff'}
    assert update_query_params(url,params) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:33:52.926947
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baaz')) == 'http://example.com?biz=baaz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='baaz'), doseq=False) == 'http://example.com?biz=baaz&foo=stuff'



# Generated at 2022-06-21 22:33:56.521250
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    assert update_query_params(test_url, params) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:33:58.744028
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:34:09.811593
# Unit test for function update_query_params
def test_update_query_params():
    url_1 = 'http://example.com?foo=bar&biz=baz'
    url_2 = update_query_params(url_1, dict(foo='stuff'))
    assert 'foo=stuff' in url_2

    url_3 = update_query_params(url_2, dict(foo=['stuff2', 'stuff3'], bar='stuff4'))
    assert 'foo=stuff2' in url_3
    assert 'foo=stuff3' in url_3
    assert 'bar=stuff4' in url_3


###############################################################################################################
#
# Support for accessing rows in a CSV file by column name
#
###############################################################################################################


# Generated at 2022-06-21 22:34:13.277329
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://www.example.com/?foo=bar&biz=baz', dict(foo='stuff')
    ) == 'http://www.example.com/?foo=stuff&biz=baz'


# Generated at 2022-06-21 22:34:18.496161
# Unit test for function update_query_params
def test_update_query_params():
    orig_url = 'http://example.com?foo=bar&biz=baz'
    result_url = 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(orig_url, dict(foo='stuff')) == result_url
    print(update_query_params(orig_url, dict(foo='stuff')))

test_update_query_params()

# Generated at 2022-06-21 22:34:28.210503
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', meep='moop')) == 'http://example.com?foo=stuff&biz=baz&meep=moop'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=None, meep='moop', biz='bar')) == 'http://example.com?biz=bar&meep=moop'



# Generated at 2022-06-21 22:34:41.364321
# Unit test for function update_query_params
def test_update_query_params():
    url = update_query_params('http://example.com?foo=bar&biz=baz',
                              dict(foo='stuff'))
    assert_equals(url, 'http://example.com?biz=baz&foo=stuff')

# Generated at 2022-06-21 22:34:46.233025
# Unit test for function update_query_params
def test_update_query_params():
    # url to test
    url = 'http://example.com/some/path?foo=bar&biz=baz'

    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com/some/path?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:34:51.455133
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    result = update_query_params(url, params)
    expected = 'http://example.com?biz=baz&foo=stuff'
    assert result == expected

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:34:54.949024
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:34:57.792286
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
           'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:35:00.813559
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    url2 = update_query_params(url, dict(foo='stuff'))
    assert url2 == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-21 22:35:03.715712
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == \
        'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-21 22:35:08.133196
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', {}) == 'http://example.com'
    assert update_query_params('http://example.com?foo=bar', {}) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com', {'foo': 'bar'}) == 'http://example.com?foo=bar'
    assert update_query_params('http://example.com?foo=bar', {'foo': 'biz'}) == 'http://example.com?foo=biz'
    assert update_query_params('http://example.com?foo=bar', {'biz': 'baz'}) == 'http://example.com?foo=bar&biz=baz'

# Generated at 2022-06-21 22:35:14.142631
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='stuff2')) == 'http://example.com?foo=stuff&biz=stuff2'

test_update_query_params()

# Generated at 2022-06-21 22:35:22.125750
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://dev.piwik.pro/piwik/index.php?module=CoreHome&action=index&viewDataTable=sparkline&columns=nb_visits&rows=10&idSite=1&period=week&date=yesterday&filter_limit=5&format=HTML&filter_offset=5&token_auth=anonymous'

# Generated at 2022-06-21 22:35:47.606513
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    'http://example.com?foo=stuff&biz=baz'

    >>> update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bing=1, bing=2))
    'http://example.com?foo=stuff&biz=baz&bing=1&bing=2'
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:35:52.683231
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://e.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://e.com?foo=stuff&biz=baz'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:35:58.709396
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')

    new_url = 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params(url, params) == new_url

    params = dict(foo='stuff', biz='buzz')

    new_url = 'http://example.com?foo=stuff&biz=buzz'
    assert update_query_params(url, params) == new_url

# Generated at 2022-06-21 22:36:05.535901
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(baz='stuff')) == 'http://example.com?baz=stuff&biz=baz&foo=bar'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:36:09.020438
# Unit test for function update_query_params
def test_update_query_params():
    url = 'https://www.example.com/oauth/token?key=value'
    new_url = update_query_params(url, dict(foo=42))
    assert 'foo=42' in new_url



# Generated at 2022-06-21 22:36:15.360273
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url, params)
    if new_url != 'http://example.com?biz=baz&foo=stuff':
        raise Exception("test_update_query_params failed!")

test_update_query_params()

print('update_query_params:', update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))


# Generated at 2022-06-21 22:36:26.756727
# Unit test for function update_query_params
def test_update_query_params():
    # Test updating of a url with parameters
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff', zap='zam')
    expected = 'http://example.com?foo=stuff&biz=baz&zap=zam'
    assert update_query_params(url, params) == expected

    # Test updating of a url with parameters and with a path
    url = 'http://example.com/this/that?foo=bar&biz=baz'
    params = dict(foo='stuff', zap='zam')
    expected = 'http://example.com/this/that?foo=stuff&biz=baz&zap=zam'
    #assert update_query_params(url, params) == expected

    # Test updating of a url with parameters and with a

# Generated at 2022-06-21 22:36:29.292869
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/?hello=world'
    assert update_query_params(url, dict(foo='bar')) == 'http://example.com/?foo=bar&hello=world'



# Generated at 2022-06-21 22:36:38.818552
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(stuff='stuff')) == 'http://example.com?foo=bar&biz=baz&stuff=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='stuff')) == 'http://example.com?foo=bar&biz=stuff'

# Generated at 2022-06-21 22:36:44.595883
# Unit test for function update_query_params
def test_update_query_params():
    assert (update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) ==
            'http://example.com?biz=baz&foo=stuff'
            or
            update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) ==
            'http://example.com?foo=stuff&biz=baz'
        )

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:37:28.542949
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:37:31.610862
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://www.example.com?foo=bar&biz=baz"
    new_url = update_query_params(url, dict(foo='stuff'))
    assert new_url == "http://www.example.com?foo=stuff&biz=baz"



# Generated at 2022-06-21 22:37:39.151488
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == \
           'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == \
           'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff', 'things'])) == \
           'http://example.com?biz=baz&foo=stuff&foo=things'

# Generated at 2022-06-21 22:37:44.344915
# Unit test for function update_query_params
def test_update_query_params():
    answer = 'http://example.com?biz=baz&foo=stuff'
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    new_url = update_query_params(url, params)

    assert new_url == answer

# Generated at 2022-06-21 22:37:51.251122
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff')
    assert(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff',baz='doo')) == 'http://example.com?baz=doo&biz=baz&foo=stuff')

test_update_query_params()
# End of Unit test for function update_query_params

# Function to create a 'pretty' print of a dictionary

# Generated at 2022-06-21 22:37:53.645835
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:37:59.833398
# Unit test for function update_query_params
def test_update_query_params():
    # Add a parameter
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=True) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:38:10.082821
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test the function update_query_params.
    """
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='is')) == 'http://example.com?foo=stuff&biz=is'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='is', test='new')) == 'http://example.com?foo=stuff&biz=is&test=new'

test_update_query_params()

# Generated at 2022-06-21 22:38:19.293065
# Unit test for function update_query_params
def test_update_query_params():

    ######################################################
    # Normal Usage
    ######################################################

    url = "http://example.com?foo=bar&biz=baz"
    params = dict(foo='stuff')
    expected = "http://example.com?foo=stuff&biz=baz"
    actual = update_query_params(url, params)
    assert actual == expected

    ######################################################
    # Update existing parameter
    ######################################################

    url = "http://example.com?foo=bar&foo=a&foo=b"
    params = dict(foo='stuff')
    expected = "http://example.com?foo=stuff"
    actual = update_query_params(url, params)
    assert actual == expected

    ######################################################
    # Merge multiple existing parameters
    ######################################################

   