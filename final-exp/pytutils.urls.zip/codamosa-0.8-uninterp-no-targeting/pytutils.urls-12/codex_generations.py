

# Generated at 2022-06-21 22:28:26.666151
# Unit test for function update_query_params
def test_update_query_params():
    url = 'https://user:pass@example.com:8080/path?foo=bar&biz=baz#fragment'
    new_url = update_query_params(url, {'foo': 'stuff'})
    assert new_url == 'https://user:pass@example.com:8080/path?foo=stuff&biz=baz#fragment'
    new_url = update_query_params(url, {'foo': 'stuff', 'new': 'true'})
    assert new_url == 'https://user:pass@example.com:8080/path?foo=stuff&biz=baz&new=true#fragment'
    new_url = update_query_params(url, {'foo': 'stuff', 'biz': 'buzz'})

# Generated at 2022-06-21 22:28:28.937466
# Unit test for function update_query_params
def test_update_query_params():
    url_updated = update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff'))
    if url_updated != 'http://example.com?foo=stuff&biz=baz':
        raise Exception("test_update_query_params failed")
test_update_query_params()


# Generated at 2022-06-21 22:28:35.915190
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff&foo2=stuff2')) == 'http://example.com?biz=baz&foo=stuff%26foo2%3Dstuff2'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff&foo2=stuff2', foo3='stuff3')) == 'http://example.com?biz=baz&foo=stuff%26foo2%3Dstuff2&foo3=stuff3'

# Generated at 2022-06-21 22:28:39.486995
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params("http://example.com?foo=bar", dict(foo='stuff'))=='http://example.com?foo=stuff')



# Generated at 2022-06-21 22:28:43.843524
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://example.com?foo=bar&biz=baz"
    test_string = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert test_string == "http://example.com?biz=baz&foo=stuff"


# Generated at 2022-06-21 22:28:48.598813
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    updated_url = update_query_params(url, {'foo': 'stuff'})
    assert updated_url == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:28:58.365844
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='buzz')) == 'http://example.com?biz=buzz&foo=stuff'
    # Also test urlencoding of parameters
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff with spaces')) == 'http://example.com?biz=baz&foo=stuff%20with%20spaces'

# TODO Add tests for other functions

if __name__ == "__main__":
    import doctest

    doct

# Generated at 2022-06-21 22:29:05.379999
# Unit test for function update_query_params
def test_update_query_params():
    print("test_update_query_params")

    url = 'http://example.com?foo=bar&biz=baz'

    params = dict(foo='stuff')
    new_url = update_query_params(url,params)

    url = 'http://example.com?foo=stuff&biz=baz'
    assert(new_url == url)

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:29:16.399839
# Unit test for function update_query_params

# Generated at 2022-06-21 22:29:26.953751
# Unit test for function update_query_params
def test_update_query_params():
    if not os.path.exists('logs'):
        os.makedirs('logs')
    with open('logs/test_update_query_params.log', 'w') as f:
        f.write('Initial URL: http://example.com?foo=bar&biz=baz\n')
        new_url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
        f.write('Updated URL: %s\n' % new_url)

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:29:36.771581
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', foo='stuff') == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', foo='stuff', biz='wut') == 'http://example.com?foo=stuff&biz=wut'
    assert update_query_params('http://example.com?foo=bar&biz=baz', foo='stuff', biz='wut', yolo='swag') == 'http://example.com?foo=stuff&biz=wut&yolo=swag'


# Generated at 2022-06-21 22:29:40.317550
# Unit test for function update_query_params
def test_update_query_params():
    """Unit test for function update_query_params."""
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='stuff')) == 'http://example.com?bar=stuff&biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar=['stuff','stuff2'])) == 'http://example.com?bar=stuff&bar=stuff2&biz=baz&foo=stuff'

# Generated at 2022-06-21 22:29:50.055212
# Unit test for function update_query_params
def test_update_query_params():
    # Base URL
    base_url = 'http://example.com?foo=bar&biz=baz'

    # Add param
    new_url = update_query_params(base_url, dict(foo='stuff'))
    assert new_url == 'http://example.com?foo=stuff&biz=baz'

    # Add params
    new_url = update_query_params(base_url, dict(foo='stuff', biz='stuff'))
    assert new_url == 'http://example.com?foo=stuff&biz=stuff'

    # Remove param
    new_url = update_query_params(base_url, dict(foo=None))
    assert new_url == 'http://example.com?biz=baz'

    # Remove params

# Generated at 2022-06-21 22:29:58.989085
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(foo='stuff', biz='baz')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(foo='stuff', bar=1)) == 'http://example.com?bar=1&biz=baz&foo=stuff'



# Generated at 2022-06-21 22:30:11.381140
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params("http://example.com?foo=bar&biz=baz", {'foo': 'stuff'}) == "http://example.com?biz=baz&foo=stuff")
    assert(update_query_params("http://example.com?foo=bar&biz=baz", {'biz': 'stuff'}) == "http://example.com?biz=stuff&foo=bar")
    assert(update_query_params("http://example.com?foo=bar&biz=baz", {'biz': 'foo', 'foo': 'stuff'}) == "http://example.com?biz=foo&foo=stuff")

# Generated at 2022-06-21 22:30:15.611145
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    expected = 'http://example.com?foo=stuff&biz=baz'
    updated = update_query_params(url, dict(foo='stuff'))
    assert updated == expected



# Generated at 2022-06-21 22:30:20.399622
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    result = update_query_params(url, params)
    expected = "http://example.com?foo=stuff&biz=baz"
    assert expected == result, "expected %s, got %s" % (expected, result)

# Generated at 2022-06-21 22:30:24.289183
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com?foo=bar&biz=baz", dict(foo='stuff')) == "http://example.com?foo=bar&biz=baz&foo=stuff"

# Generated at 2022-06-21 22:30:28.451737
# Unit test for function update_query_params
def test_update_query_params():
    test_str = "http://example.com?foo=bar&biz=baz"
    test_dict = dict(foo='stuff')
    result = update_query_params(test_str, test_dict)
    print(result)


# Generated at 2022-06-21 22:30:32.359548
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
if __name__ == '__main__':
    test_update_query_params()
 
import urllib # need urllib for py2.6?


# Generated at 2022-06-21 22:30:40.828881
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    result = update_query_params(url, params)

    assert result == 'http://example.com?foo=stuff&biz=baz'

# Call unit test
test_update_query_params()

# Generated at 2022-06-21 22:30:48.538326
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    assert update_query_params(url, params) == 'http://example.com?biz=baz&foo=stuff'

    url = 'http://example.com?foo=bar&biz=baz'
    params = {'baz': ['qux', 'quux'], 'corge': ''}
    assert update_query_params(url, params) == 'http://example.com?biz=baz&baz=qux&baz=quux&corge=&foo=bar'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:30:59.609944
# Unit test for function update_query_params
def test_update_query_params():
    # Params should be inserted
    sample1 = 'http://example.com?foo=bar&biz=baz'
    updated1 = update_query_params(sample1, dict(foo='stuff'))
    assert updated1 == 'http://example.com?foo=stuff&biz=baz'

    # Params should be replaced
    sample2 = 'http://example.com?foo=bar&biz=baz'
    updated2 = update_query_params(sample2, dict(foo='stuff'))
    assert updated2 == 'http://example.com?foo=stuff&biz=baz'

    # Params should be inserted at end of query string
    sample3 = 'http://example.com?foo=bar&biz=baz'

# Generated at 2022-06-21 22:31:08.427874
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://localhost:8000/raynor?foo=bar&biz=baz"
    params = {
        "foo": "stuff",
        "biz": "buzz"
    }
    new_url = update_query_params(url, params)
    assert new_url == "http://localhost:8000/raynor?biz=buzz&foo=stuff", new_url

if __name__ == '__main__':
    test_update_query_params()
    print("Done")

# Generated at 2022-06-21 22:31:17.814348
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz&bar=1', {'foobar': 'stuff'}) == 'http://example.com?bar=1&biz=baz&foo=bar&foobar=stuff'
    assert update_query_params('http://example.com#foobar', {'foo': 'stuff'}) == 'http://example.com?foo=stuff#foobar'


# Generated at 2022-06-21 22:31:26.882523
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    assert(update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff')
    assert(update_query_params(url, dict(foo='stuff', biz='baz', cool='guy')) == 'http://example.com?biz=baz&cool=guy&foo=stuff')
    assert(update_query_params(url, dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff')
    assert(update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff')

# Generated at 2022-06-21 22:31:29.531061
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://www.example.com?foo=bar"
    assert update_query_params(url, {'foo': 'stuff'}) == "http://www.example.com?foo=stuff"

# Generated at 2022-06-21 22:31:33.577536
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

test_update_query_params()


# Generated at 2022-06-21 22:31:38.434986
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(biz='stuff')) == 'http://example.com?biz=stuff'

# Generated at 2022-06-21 22:31:43.443363
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    new_url = update_query_params(url,params)
    print(new_url)

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-21 22:31:59.000781
# Unit test for function update_query_params
def test_update_query_params():
    '''
    Simple unit test for function update_query_params
    '''
    url = 'http://example.com?foo=bar&biz=baz'

    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(url, dict(foo='stuff', biz='boo')) == 'http://example.com?biz=boo&foo=stuff'



# Generated at 2022-06-21 22:32:08.757223
# Unit test for function update_query_params
def test_update_query_params():
    from nose.tools import eq_
    eq_(update_query_params(
        u'http://example.com?foo=bar&biz=baz', dict(foo=u'stuff')
    ), u'http://example.com?foo=stuff&biz=baz')
    eq_(update_query_params(
        u'http://example.com?foo=bar&biz=baz', dict(biz=u'stuff')
    ), u'http://example.com?foo=bar&biz=stuff')
    eq_(update_query_params(
        u'http://example.com?foo=bar&biz=baz', dict(foo=u'stuff', biz=u'bang')
    ), u'http://example.com?foo=stuff&biz=bang')

# Generated at 2022-06-21 22:32:17.821689
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', foo='stuff') == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', foo=('stuff', 'extra')) == 'http://example.com?biz=baz&foo=stuff&foo=extra'
    assert update_query_params('http://example.com?foo=bar&biz=baz', foo=('stuff', 'extra'), doseq=False) == 'http://example.com?biz=baz&foo=stuff,extra'

# Generated at 2022-06-21 22:32:29.064594
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com/?id=1', dict(id=2)) == 'http://example.com/?id=2'
    assert update_query_params('http://example.com/?id=1', dict(id=2), doseq=False) == 'http://example.com/?id=2'
    assert update_query_params('http://example.com/?id=1', dict(id=2), doseq=True) == 'http://example.com/?id=2'
    assert update_query_params('http://example.com/?') == 'http://example.com/'
    assert update_query_params('http://example.com/?', dict(id=2)) == 'http://example.com/?id=2'

# Generated at 2022-06-21 22:32:34.620185
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    result = 'http://example.com?foo=stuff'
    assert update_query_params(url, dict(foo='stuff')) == result

if __name__ == '__main__':
    test_update_query_params()
    print("Function update_query_params succesfully tested :)")

# Generated at 2022-06-21 22:32:41.804951
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {
        'foo': 'stuff',
        'baz': 'more stuff',
    }
    assert update_query_params(url, params) == 'http://example.com?baz=more+stuff&foo=stuff'
    assert update_query_params(url, params, doseq=False) == 'http://example.com?baz=more stuff&foo=stuff'



# Generated at 2022-06-21 22:32:47.511719
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected_url = 'http://example.com?biz=baz&foo=stuff'
    actual_url = update_query_params(url, params)
    assert actual_url == expected_url


# Generated at 2022-06-21 22:32:55.520422
# Unit test for function update_query_params
def test_update_query_params():
    """Tests for function update_query_params"""

    # Testing with basic example.
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    # Testing with multiple kwargs.
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='boo')) == 'http://example.com?biz=boo&foo=stuff'
    # Testing with multiple nested kwargs

# Generated at 2022-06-21 22:33:02.563905
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = dict(foo='stuff')
    expected = 'http://example.com?biz=baz&foo=stuff'
    actual = update_query_params(url, params)
    assert actual == expected

# Run test
if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:33:09.169180
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz=[])) == 'http://example.com?foo=stuff&biz='
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['biz', 'baz'], biz=['foo', 'bar'])) == 'http://example.com?foo=biz&foo=baz&biz=foo&biz=bar'

test_update_query_params()

# Generated at 2022-06-21 22:33:34.143420
# Unit test for function update_query_params
def test_update_query_params():
    test_url = 'http://example.com?foo=bar&biz=baz'
    result_url = 'http://example.com?biz=baz&foo=stuff'
    assert(update_query_params(test_url, {'foo':'stuff'}) == result_url)

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:33:37.076619
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-21 22:33:41.924285
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz&biz=buz'
    url2 = update_query_params(url, {'foo': 'stuff', 'bar': 'baz'})
    assert url2 == 'http://example.com?biz=baz&biz=buz&foo=stuff&bar=baz'



# Generated at 2022-06-21 22:33:52.580718
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://www.google.com", {'foo': 'bar'}) == 'http://www.google.com?foo=bar'
    assert update_query_params("http://www.google.com?foo=bar", {'baz': 'zap'}) == 'http://www.google.com?baz=zap&foo=bar'
    assert update_query_params("http://www.google.com?foo=bar", {'baz': 'zap', 'foo': 'bar'}) == 'http://www.google.com?baz=zap&foo=bar'
    assert update_query_params("http://www.google.com?foo=bar", {}) == 'http://www.google.com?foo=bar'

# Generated at 2022-06-21 22:33:59.181257
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    True
    """
    # Simple case: only existing parameter
    url = 'http://example.com?foo=bar'
    assert update_query_params(url, dict(foo='stuff')) == 'http://example.com?foo=stuff'

    # Simple case: only new parameter
    url = 'http://example.com?foo=bar'
    assert update_query_params(url, dict(baz='stuff')) == 'http://example.com?foo=bar&baz=stuff'

    # New parameter with existing value
    url = 'http://example.com?foo=bar'
    assert update_query_params(url, dict(foo='baz')) == 'http://example.com?foo=baz'

    # Parameters with empty values

# Generated at 2022-06-21 22:34:05.390857
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

# Run unit test
if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:34:10.538460
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    new_url = 'http://example.com?foo=stuff&biz=baz'
    expected_url = update_query_params(url, params)
    assert(expected_url == new_url)



# Generated at 2022-06-21 22:34:20.336088
# Unit test for function update_query_params
def test_update_query_params():
    # make sure original URIs aren't changed
    original_uri_1 = 'http://example.com?foo=bar&biz=baz'
    original_uri_2 = 'http://example.com?foo=bar&biz=baz'
    uri_1 = update_query_params(original_uri_1, dict(foo='stuff', biz='baz'))
    uri_2 = update_query_params(original_uri_1, dict(biz='baz', foo='stuff'))
    assert uri_1 == original_uri_1
    assert uri_2 == original_uri_2

    # make sure original URIs aren't changed
    uri_1 = update_query_params(uri_1, dict(foo='other_stuff'))

# Generated at 2022-06-21 22:34:24.499458
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'




# Generated at 2022-06-21 22:34:28.207788
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff', baz='quux')
    ) == 'http://example.com?biz=baz&baz=quux&foo=stuff'

# Generated at 2022-06-21 22:35:15.357435
# Unit test for function update_query_params
def test_update_query_params():
    expected_new_url = 'http://example.com?foo=stuff&biz=baz'
    new_url = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    assert new_url == expected_new_url
# END test_update_query_params

# Generated at 2022-06-21 22:35:20.252808
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='something')) == 'http://example.com?biz=something&foo=stuff'

# Generated at 2022-06-21 22:35:29.997214
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&baz=boo&foo=stuff'
    updated_url = update_query_params(url, dict(foo='stuff'))
    assert updated_url == 'http://example.com?baz=boo&foo=stuff'
    updated_url = update_query_params(updated_url, dict(foo='updated stuff'))
    assert updated_url == 'http://example.com?baz=boo&foo=updated+stuff'
    url = 'http://example.com'
    updated_url = update_query_params(url, dict(foo='stuff'))
    assert updated_url == 'http://example.com?foo=stuff'
    updated_url = update_query_params(updated_url, dict(foo='updated stuff'), doseq=False)
   

# Generated at 2022-06-21 22:35:32.447579
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-21 22:35:36.522180
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com/?foo=bar&biz=baz&foo=stuff", {"foo": "newstuff"}) == "http://example.com/?foo=newstuff&biz=baz"
    assert update_query_params("http://example.com/?foo=bar&biz=baz&foo=stuff", {"foo": "newstuff", "biz": "foo"}) == "http://example.com/?foo=newstuff&biz=foo"


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:35:43.676068
# Unit test for function update_query_params
def test_update_query_params():
    from nose.tools import assert_equal
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    url_updated = update_query_params(url, params)
    assert_equal(url_updated, 'http://example.com?biz=baz&foo=stuff')
    params = {'foo': 'stuff', 'new_param': 'new_value'}
    url_updated = update_query_params(url, params)
    assert_equal(url_updated, 'http://example.com?biz=baz&foo=stuff&new_param=new_value')



# Generated at 2022-06-21 22:35:48.322549
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff')
    ) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo=['stuff'])
    ) == 'http://example.com?biz=baz&foo=stuff'



# Generated at 2022-06-21 22:35:54.332671
# Unit test for function update_query_params
def test_update_query_params():
    """
    >>> test_update_query_params()
    """
    test_url = 'http://example.com?foo=bar&biz=baz'
    test_params = dict(foo='stuff', baz='buz')
    url = update_query_params(test_url, test_params)
    assert url == 'http://example.com?biz=baz&foo=stuff&baz=buz'



# Generated at 2022-06-21 22:35:56.046098
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-21 22:36:05.897082
# Unit test for function update_query_params
def test_update_query_params():
    assert('http://example.com?foo=stuff&biz=baz'==update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    assert('http://example.com?foo=stuff&biz=baz'==update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    assert('http://example.com?foo=stuff&biz=baz'==update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    assert('http://example.com?foo=stuff&biz=baz'==update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))

# Generated at 2022-06-21 22:37:34.263560
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    assert update_query_params(url, params) == 'http://example.com?biz=baz&foo=stuff'

# Generated at 2022-06-21 22:37:41.009651
# Unit test for function update_query_params

# Generated at 2022-06-21 22:37:51.252913
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz&biz=fiz', dict(foo='stuff')) == 'http://example.com?biz=baz&biz=fiz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo=['stuff'])) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_

# Generated at 2022-06-21 22:37:54.220552
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'

if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:38:04.367960
# Unit test for function update_query_params
def test_update_query_params():
    """Test the function update_query_params."""
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(lorem='ipsum')) == 'http://example.com?foo=bar&lorem=ipsum'
    assert update_query_params('http://example.com', dict(foo='bar')) == 'http://example.com?foo=bar'

# Generated at 2022-06-21 22:38:10.560662
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz&foo=stuff'
    new_params = dict(biz='baz')
    url2 = update_query_params(url, new_params)
    assert 'http://example.com?foo=bar&foo=stuff&biz=baz' == url2


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-21 22:38:14.439908
# Unit test for function update_query_params
def test_update_query_params():
    """
    Insert a new query parameter.
    """
    url = 'http://example.com'
    params = dict(foo='stuff')
    url = update_query_params(url, params)

    assert url == 'http://example.com?foo=stuff'


# Generated at 2022-06-21 22:38:22.118178
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('https://example.com?test=test&test=test2', dict(foo='stuff')) == 'https://example.com?foo=stuff&test=test&test=test2'
    assert update_query_params('https://example.com?test=test&test=test2', dict(foo='stuff', bar='bar')) == 'https://example.com?bar=bar&foo=stuff&test=test&test=test2'
    assert update_query_params('https://example.com?test=test&test=test2', dict(bar='bar', foo='stuff')) == 'https://example.com?bar=bar&foo=stuff&test=test&test=test2'