

# Generated at 2022-06-26 02:59:39.544858
# Unit test for function update_query_params
def test_update_query_params():
    print('Testing function: update_query_params')

    # Test case 0
    print('\tTest case 0: Default test case')
    str_0 = '<0fcT{&J\\\n20G%'
    int_0 = 147
    var_0 = update_query_params(str_0, int_0)
    assert var_0 == '<0fcT{&J\\\n20G%147'
    print('\t\tResult: Pass')
    print('\t\tExpected: <0fcT{&J\\\n20G%147')


# Generated at 2022-06-26 02:59:41.579588
# Unit test for function update_query_params
def test_update_query_params():
    # Verify that this function does what it was meant to
    assert True

# Generated at 2022-06-26 02:59:52.696164
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = '<0fcT{&J\\\n20G%'
    int_0 = 147
    var_0 = update_query_params(str_0, int_0)
    str_1 = '_'
    float_0 = 3.9
    var_1 = update_query_params(str_1, float_0)
    str_2 = set()
    var_2 = update_query_params(str_2, int_0)
    str_3 = 'B]Dv)n&#W8XH'
    int_1 = 558
    var_3 = update_query_params(str_3, int_1)
    str_4 = '3'
    int_2 = 292
    var_4 = update_query_params(str_4, int_2)
   

# Generated at 2022-06-26 02:59:58.244270
# Unit test for function update_query_params
def test_update_query_params():
    params = {'key1': 'value1',
              'key2': 'value2',
              'key3': 'value3',
              'key4': 'value4'}
    url = 'http://www.example.com/test.php?var=foo'
    result_str = update_query_params(url, params)

test_case_0()
test_update_query_params()

# Generated at 2022-06-26 03:00:06.146211
# Unit test for function update_query_params
def test_update_query_params():
    assert 'http://example.com?foo=bar&biz=baz&biz=1' == update_query_params('http://example.com?foo=bar&biz=baz', dict(biz=1))
    assert 'http://example.com?foo=bar&biz=baz&biz=1&biz=2' == update_query_params('http://example.com?foo=bar&biz=baz&biz=1', dict(biz=2))
    assert 'http://example.com?foo=bar&biz=baz&biz=1&biz=2' == update_query_params('http://example.com?foo=bar&biz=baz', dict(biz=1, biz=2))


if __name__ == '__main__':
    test_update_query_params()

# Generated at 2022-06-26 03:00:07.085033
# Unit test for function update_query_params

# Generated at 2022-06-26 03:00:12.313658
# Unit test for function update_query_params
def test_update_query_params():
    print('Test update_query_params')
    test_case_0()

# Warning
# print(update_query_params('http://example.com', dict(foo='bar')))
if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-26 03:00:19.357813
# Unit test for function update_query_params
def test_update_query_params():

    assert update_query_params('http://example.com?foo=bar&biz=baz', foo='stuff') == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', foo=None) == 'http://example.com?biz=baz&foo=bar'


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-s', __file__]))

# Generated at 2022-06-26 03:00:25.493938
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz='bazzy')) == 'http://example.com?foo=stuff&biz=bazzy'
    # from nose.tools import set_trace; set_trace()



# Generated at 2022-06-26 03:00:28.211178
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


# Generated at 2022-06-26 03:00:31.179696
# Unit test for function update_query_params
def test_update_query_params():
    print('Unit test for function update_query_params')
    test_case_0()

# Generated at 2022-06-26 03:00:41.013186
# Unit test for function update_query_params
def test_update_query_params():
    a = 'http://example.com?foo=bar&biz=baz'
    b = update_query_params(a, {'foo': 'stuff'})
    assert b == 'http://example.com?biz=baz&foo=stuff', 'Expecting stuff, but got ' + b
    b = update_query_params(a, {'foo': 'stuff', 'foo': 'baz'})
    assert b == 'http://example.com?biz=baz&foo=baz', 'Expecting baz, but go ' + b
    b = update_query_params(a, {'foo': 'stuff', 'foo': 'baz', 'fjar': 'jar'})

# Generated at 2022-06-26 03:00:52.018910
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'), doseq=False) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', biz=['bop']), doseq=False) == 'http://example.com?biz=bop&foo=stuff'
    # Pass arguments with keywords for the purpose of coverage

# Generated at 2022-06-26 03:00:53.417463
# Unit test for function update_query_params
def test_update_query_params():
    assert 0 == test_case_0()


# Generated at 2022-06-26 03:00:58.516165
# Unit test for function update_query_params
def test_update_query_params():
    import sys
    import io
    import contextlib
    f = io.StringIO()
    with contextlib.redirect_stdout(f):
        test_case_0()
        sys.stdout.seek(0)
        out = f.read()
        assert out == '<0fcT{&J\\\n20G%'

# Generated at 2022-06-26 03:01:06.248838
# Unit test for function update_query_params
def test_update_query_params():
    kwargs = {'key1': 'value1', 'key2': 'value2'}
    url_base = 'http://example.com'
    url = update_query_params(url_base, **kwargs)
    assert url == 'http://example.com?key1=value1&key2=value2'
    url = update_query_params(url, **kwargs)
    assert url == 'http://example.com?key1=value1&key2=value2&key1=value1&key2=value2'
    url = update_query_params(url, key3='value3')
    assert url == 'http://example.com?key1=value1&key2=value2&key1=value1&key2=value2&key3=value3'



# Generated at 2022-06-26 03:01:08.649418
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('<0fcT{&J\\\n20G%', 147) == '<0fcT{&J\\\n20G%'

# Generated at 2022-06-26 03:01:12.526622
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('c%3A\\anaconda3\\envs\\data_pipeline\\lib\\site-packages\\version_query\\examples\\%24RECYCLE.BIN',
                               'http://localhost:8088/capstone/') is not None

# Generated at 2022-06-26 03:01:20.446098
# Unit test for function update_query_params
def test_update_query_params():
    params = {"foo":"bar", "bar":"baz"}
    url = "http://example.com?foo=bar&bar=baz"
    new_params = {'baz': 'buz'}
    assert update_query_params(url, new_params) == "http://example.com?bar=baz&baz=buz&foo=bar"
    assert update_query_params(url, params) == "http://example.com?bar=baz&foo=bar"


# Generated at 2022-06-26 03:01:29.993520
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('https://example.com/', {'foo': 'bar'}) == 'https://example.com/?foo=bar'
    assert update_query_params('http://example.com/?foo=bar', {'foo': 'bar2'}) == 'http://example.com/?foo=bar2'
    assert update_query_params('http://example.com/?foo=bar', {'foo': 'bar2', 'biz': 'baz'}) == 'http://example.com/?biz=baz&foo=bar2'
    assert update_query_params('http://example.com/?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com/?biz=baz&foo=stuff'

# Generated at 2022-06-26 03:01:34.082083
# Unit test for function update_query_params
def test_update_query_params():
    # Capture the output to a file
    # sys.stdout = open("out.txt","w")

    test_case_0()


# Generated at 2022-06-26 03:01:41.182462
# Unit test for function update_query_params
def test_update_query_params():
    print("Unit Test Case : update_query_params")
    #assert_string_equal(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')), 'http://example.com?foo=stuff&biz=baz')
    #assert_string_equal(update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='stuff')), 'http://example.com?foo=bar&biz=stuff')
    return


test_update_query_params()

# Generated at 2022-06-26 03:01:50.505178
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='buzz')) == 'http://example.com?foo=bar&biz=buzz'


if __name__ == '__main__':
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(biz='buzz')))

# Generated at 2022-06-26 03:01:54.822871
# Unit test for function update_query_params
def test_update_query_params():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()


# Generated at 2022-06-26 03:02:08.566284
# Unit test for function update_query_params
def test_update_query_params():
    assert (update_query_params('something?foo=bar&biz=baz', {'foo': 'stuff'})) == (
        'something?foo=stuff&biz=baz')
    assert (update_query_params('something?foo=bar&biz=baz', foo='stuff')) == (
        'something?foo=stuff&biz=baz')
    assert (update_query_params('something?biz=baz', foo='bar')) == (
        'something?biz=baz&foo=bar')
    assert (update_query_params('something', foo='bar')) == (
        'something?foo=bar')
    assert (update_query_params('something', foo='bar', biz='foo')) == (
        'something?foo=bar&biz=foo')



# Generated at 2022-06-26 03:02:14.124324
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?%2Ffoo%2Fstuff%2F&biz=baz'


# Generated at 2022-06-26 03:02:19.104989
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = 'http://example.com?foo=bar&biz=baz'
    params = {'foo': 'stuff'}
    print(update_query_params(str_0, params))

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-26 03:02:23.186329
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = '<0fcT{&J\\\n20G%'
    int_0 = 147
    assert update_query_params(str_0, int_0) == str_0

# Verification with coverage tool
# test_update_query_params()

# Generated at 2022-06-26 03:02:28.813137
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'



# Generated at 2022-06-26 03:02:31.972025
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params(
        'http://example.com?foo=bar&biz=baz',
        dict(foo='stuff')
    ) == 'http://example.com?foo=stuff&biz=baz'



# Generated at 2022-06-26 03:02:37.644384
# Unit test for function update_query_params
def test_update_query_params():
    test_case_0()

# Generated at 2022-06-26 03:02:43.894476
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com?foo=bar&biz=baz'
    params = {
        'foo': 'stuff',
        'bar': 'biz'
    }
    new_url = update_query_params(url, params)
    print(new_url)
    assert new_url == 'http://example.com?bar=biz&biz=baz&foo=stuff'


if __name__ == '__main__':
    test_case_0()
    # test_update_query_params()

# Generated at 2022-06-26 03:02:48.154376
# Unit test for function update_query_params
def test_update_query_params():
    """
    Test case 0
    """
    str_0 = '<0fcT{&J\\\n20G%'
    int_0 = 147
    update_query_params(str_0, int_0)


# Generated at 2022-06-26 03:02:49.617094
# Unit test for function update_query_params
def test_update_query_params():
    print('Test 1')
    print(update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')))
    print('Test 2')
    print(update_query_params(''))


test_update_query_params()

# Generated at 2022-06-26 03:02:53.732529
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(["-v", "-s", "--pdb", __file__]))

# Generated at 2022-06-26 03:02:57.205878
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz',
                               dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-26 03:03:09.054297
# Unit test for function update_query_params
def test_update_query_params():
    array_0 = [1, 1, 2]
    array_1 = [3, 5, 8, 13, 21]
    array_2 = [2, 3, 5, 7, 11, 13]
    for index in range(5):
        if(array_0[index] > array_1[index]):
            array_0[index] = array_1[index]
        else:
            array_1[index] = array_2[index]
    var_0 = update_query_params(array_0, array_1, array_2)
    assert(((array_0[2] == 3) and (array_1[2] == 5)) and (array_2[2] == 5))

# Generated at 2022-06-26 03:03:13.441185
# Unit test for function update_query_params
def test_update_query_params():
    int_1 = 912
    str_0 = 'J\\\n20G%'
    int_0 = 147
    var_0 = update_query_params(str_0, int_0)

# Run unit tests when invoked as a script
if __name__ == 'main':
    test_case_0()
    test_update_query_params()

# Generated at 2022-06-26 03:03:16.009570
# Unit test for function update_query_params
def test_update_query_params():
    # Test case 0
    test_case_0()
    str_0 = 'https?://xyU2f{g^'
    i

# Generated at 2022-06-26 03:03:24.325260
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'

# Generated at 2022-06-26 03:03:35.999731
# Unit test for function update_query_params
def test_update_query_params():
    url = "http://foo.com/bar?baz=1&baz=3"
    params = dict(baz=2)
    new_url = update_query_params(url, params)
    assert new_url == "http://foo.com/bar?baz=1&baz=3&baz=2", new_url



# Generated at 2022-06-26 03:03:42.088907
# Unit test for function update_query_params
def test_update_query_params():
    url_0 = 'http://example.com?foo=bar&biz=baz'
    params_0 = {'foo': 'stuff'}
    result_0 = update_query_params(url_0, params_0)
    assert result_0 == 'http://example.com?foo=stuff&biz=baz', 'result_0 mismatch'


# Generated at 2022-06-26 03:03:47.826591
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = '<0fcT{&J\\\n20G%'
    int_0 = 147
    var_0 = update_query_params(str_0, int_0)

    assert str_0 == '<0fcT{&J\\\n20G%'
    assert int_0 == 147
    assert var_0 == '<0fcT{&J\\\n20G%?147=%d' % int_0

# Generated at 2022-06-26 03:03:56.889835
# Unit test for function update_query_params
def test_update_query_params():
    # Verify that the correct query params are added to a URL
    url = 'http://example.com'
    url_with_staging = update_query_params(url, {'staging': 'true'})
    assert url_with_staging == 'http://example.com?staging=true'

    # Verify that existing query params are replaced by new ones
    url = 'http://example.com?staging=true'
    url_with_staging = update_query_params(url, {'staging': 'true'})
    assert url_with_staging == 'http://example.com?staging=true'

    url_with_staging_false = update_query_params(url, {'staging': 'false'})

# Generated at 2022-06-26 03:04:08.256388
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'
    assert update_query_params('http://example.com?foo=bar', dict(foo='stuff', biz='baz')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&foo=baz', dict(foo='stuff'))

# Generated at 2022-06-26 03:04:09.583910
# Unit test for function update_query_params
def test_update_query_params():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-26 03:04:16.680416
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params("http://example.com?foo=bar&biz=baz", {'foo': 'stuff'}) == "http://example.com?foo=stuff&biz=baz"
    assert update_query_params("http://example.com?foo=bar&biz=baz", {'foo': 'stuff', 'biz': 'buzz'}) == "http://example.com?foo=stuff&biz=buzz"
    assert update_query_params("http://example.com?foo=bar&biz=baz", {'foo': 'stuff', 'biz': 'buzz', 'quux': 'quuux'}) == "http://example.com?foo=stuff&biz=buzz&quux=quuux"

# Generated at 2022-06-26 03:04:22.172426
# Unit test for function update_query_params
def test_update_query_params():
    url_0 = 'http://example.com/'
    url_1 = 'http://example.com?foo=bar&biz=baz'
    params_0 = {'foo': 'stuff'}

    new_url_0 = 'http://example.com/?foo=stuff'
    new_url_1 = 'http://example.com?biz=baz&foo=stuff'

    assert update_query_params(url_0, params_0) == new_url_0
    assert update_query_params(url_1, params_0) == new_url_1

# Generated at 2022-06-26 03:04:31.114737
# Unit test for function update_query_params
def test_update_query_params():

    str_0 = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    print( type(str_0) )
    print( str_0 )
    print( "---" )

    str_1 = update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff'))
    print( type(str_1) )
    print( str_1 )
    print( "---" )

    str_2 = update_query_params('http://example.com?foo=bar&biz=baz', dict(stuff='things'))
    print( type(str_2) )
    print( str_2 )
    print( "---" )


# Generated at 2022-06-26 03:04:40.869480
# Unit test for function update_query_params
def test_update_query_params():
    assert func_0() == '<0fcT{&J\\\n20G%'
    assert func_1() == '<0fcT{&J\\\n20G%'
    assert func_2() == '<0fcT{&J\\\n20G%'
    assert func_3() == '<0fcT{&J\\\n20G%'
    assert func_4() == '<0fcT{&J\\\n20G%'
    assert func_5() == '<0fcT{&J\\\n20G%'
    assert func_6() == '<0fcT{&J\\\n20G%'
    assert func_7() == '<0fcT{&J\\\n20G%'


test_case_0()

# Generated at 2022-06-26 03:05:01.778374
# Unit test for function update_query_params
def test_update_query_params():
    test_case_0()


if __name__ == '__main__':
    import sys
    import nose

    argv = sys.argv[:]
    argv.append('-v')
    nose.main(argv=argv, defaultTest=__file__)

# Generated at 2022-06-26 03:05:08.122973
# Unit test for function update_query_params
def test_update_query_params():
    url_0 = 'http://example.com?foo=bar&biz=baz'
    params_0 = {'foo': 'stuff'}
    int_0 = 147
    boolean_0 = True
    assert_equal(update_query_params(url_0, params_0), 'http://example.com?biz=baz&foo=stuff')
    assert_equal(update_query_params(url_0, params_0, True), 'http://example.com?biz=baz&foo=stuff')
    assert_equal(update_query_params(url_0, params_0, False), 'http://example.com?biz=baz&foo=stuff')
    assert_equal(update_query_params(url_0, params_0), 'http://example.com?biz=baz&foo=stuff')
   

# Generated at 2022-06-26 03:05:11.855523
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://google.com/index.html', a='stuff', b='morestuff') == 'http://google.com/index.html?b=morestuff&a=stuff'

# Generated at 2022-06-26 03:05:21.174954
# Unit test for function update_query_params
def test_update_query_params():
    print('Testing function update_query_params')
    # Test 0 - py3k
    try:
        print("Testing with input: ", " '<0fcT{&J\\n20G%' , 147")
        assert update_query_params("<0fcT{&J\\n20G%", 147) == "<0fcT{&J\\n20G%?%c3%8d=147"
        print("Passed!")
    except AssertionError as e:
        print("\033[1;31;0m Test 0 failed. \033[0m")
    except Exception as e:
        print("\033[1;31;0m Test 0 failed. \033[0m")
    # Test 1 - py3k

# Generated at 2022-06-26 03:05:22.172698
# Unit test for function update_query_params
def test_update_query_params():
    assert test_case_0()

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-26 03:05:22.945042
# Unit test for function update_query_params
def test_update_query_params():
    test_case_0()

# Generated at 2022-06-26 03:05:25.970680
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff&'

# Generated at 2022-06-26 03:05:35.016447
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = 'http://example.com?foo=bar&biz=baz'
    dict_0 = dict(foo='stuff')
    assert update_query_params(str_0, dict_0) == 'http://example.com?foo=stuff&biz=baz'
    str_0 = 'http://example.com?foo=bar&biz=baz'
    dict_0 = dict(foo='stuff', biz='buzz')
    assert update_query_params(str_0, dict_0) == 'http://example.com?foo=stuff&biz=buzz'

test_case_0()
test_update_query_params()

# Generated at 2022-06-26 03:05:42.041992
# Unit test for function update_query_params
def test_update_query_params():
    kwargs_value_0 = {'bar': 'biz', 'foo': 'baz'}
    url_value_0 = 'http://example.com?foo=bar&biz=baz'
    var_0 = update_query_params(url_value_0, kwargs_value_0)
    var_1 = 'http://example.com?foo=baz&biz=biz'
    
    assert var_0 == var_1
    return


# Generated at 2022-06-26 03:05:52.223913
# Unit test for function update_query_params
def test_update_query_params():
    # Testing with a single non-string input
    str_0 = '<0fcT{&J\\\n20G%'
    int_0 = 147
    var_0 = update_query_params(str_0, int_0)

    # Testing with multiple non-string inputs
    str_1 = 'tB4'
    int_1 = 185
    float_0 = 0.38
    var_1 = update_query_params(str_1, int_1, float_0)

    # Testing with a single string input
    str_2 = '|'
    str_3 = '@oH'
    var_2 = update_query_params(str_2, str_3)

    # Testing with multiple string inputs 
    str_4 = 'R-kp!o'

# Generated at 2022-06-26 03:06:34.542355
# Unit test for function update_query_params
def test_update_query_params():
    print('Imported.')
    print(update_query_params.__doc__)
#     test_update_query_params()
    print(update_query_params(0))
    assert(update_query_params(0) == 0)
    print(update_query_params(0) == 0)

if __name__ == '__main__':
    test_case_0()
    # test_update_query_params()

# Generated at 2022-06-26 03:06:43.634575
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com/?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com/?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?biz=baz', dict(foo='stuff')) == 'http://example.com?biz=baz&foo=stuff'
    assert update_query_params('http://example.com', dict(foo='stuff')) == 'http://example.com?foo=stuff'

# Generated at 2022-06-26 03:06:50.280348
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = '<0fcT{&J\\\n20G%'
    int_0 = 147
    var_0 = update_query_params(str_0, int_0)
    with pytest.raises(TypeError) as excinfo:
        update_query_params(str_0, int_0)
    assert "update_query_params() takes at least 1 argument (0 given)" == str(excinfo.value)



# Generated at 2022-06-26 03:06:58.486091
# Unit test for function update_query_params
def test_update_query_params():
    with patch('urls.urlparse') as urlparse:
        urlparse.urlsplit.return_value = ['http', 'example.com', '/query',
                                          'q=foo', 'f=bar']
        urlparse.urlunsplit.return_value = "http://example.com/query?q=foo&f=bar"
        urlparse.parse_qs.return_value = {'q': ['foo'], 'f': ['bar']}
        assert update_query_params('http://example.com/query', q=["pizza"], f=[]) == \
               "http://example.com/query?q=pizza&f=bar"
        urlparse.parse_qs.return_value = {'q': ['foo'], 'f': ['bar']}

# Generated at 2022-06-26 03:07:02.035018
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = '<0fcT{&J\\\n20G%'
    params = 147
    uri = 'http://localhost:8080/'
    uri = update_query_params(str_0, params)
    assert uri is not None


# Generated at 2022-06-26 03:07:06.389110
# Unit test for function update_query_params
def test_update_query_params():
    expected = 'http://example.com/path/to?foo=stuff'
    assert_equals(update_query_params('http://example.com/path/to?foo=bar', dict(foo='stuff')), expected)


# Generated at 2022-06-26 03:07:09.363662
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'


# Generated at 2022-06-26 03:07:18.179338
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff')) == 'http://example.com?foo=stuff&biz=baz'
    assert update_query_params('http://example.com?foo=bar&biz=baz', dict(foo='stuff', bar='stuff')) == 'http://example.com?foo=stuff&biz=baz&bar=stuff'
    assert update_query_params('http://example.com?foo=bar&biz=baz', 
                               dict(foo=['stuff', 'thing'], bar=['stuff', 'thing'])) == 'http://example.com?foo=stuff&foo=thing&biz=baz&bar=stuff&bar=thing'

# Generated at 2022-06-26 03:07:19.303687
# Unit test for function update_query_params
def test_update_query_params():
    assert(update_query_params() == True)


# Generated at 2022-06-26 03:07:21.113358
# Unit test for function update_query_params
def test_update_query_params():
    expected_output = {'2': '3'}
    actual_output = update_query_params('1', '2', '3')
    assert expected_output == actual_output

# Generated at 2022-06-26 03:08:44.763023
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo':'stuff'}) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-26 03:08:47.504367
# Unit test for function update_query_params
def test_update_query_params():
    test_case_0()


if __name__ == '__main__':
    test_update_query_params()



# Generated at 2022-06-26 03:08:52.086147
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = '<0fcT{&J\\\n20G%'
    str_1 = '<0fcT{&J\\\n20G%'
    assert update_query_params(str_0, str_1) == '<0fcT{&J\\\n20G%<0fcT{&J\\\n20G%'


# Generated at 2022-06-26 03:08:57.452501
# Unit test for function update_query_params
def test_update_query_params():
    url = 'http://example.com/path?a=1&b=2'
    new_url = update_query_params(url, dict(b='99', c='88'))
    assert new_url == 'http://example.com/path?a=1&b=99&c=88'

    new_url = update_query_params(url, dict(a=['1', '2']))
    assert new_url == 'http://example.com/path?a=1&a=2&b=2'

    new_url = update_query_params(url, dict(a=['1', '2']), doseq=False)
    assert new_url == 'http://example.com/path?a=1&b=2'

# Generated at 2022-06-26 03:09:03.540944
# Unit test for function update_query_params
def test_update_query_params():
    var_0 = 'http://example.com?foo=bar&biz=baz'
    var_1 = dict(foo='stuff')
    var_2 = update_query_params(var_0, var_1)
    print(var_2)

if __name__ == "__main__":
    test_update_query_params()

# Generated at 2022-06-26 03:09:11.824963
# Unit test for function update_query_params
def test_update_query_params():

    # Test 1
    str_0 = '/p0\x11%3q^E.\x17/'
    int_0 = -87
    var_0 = update_query_params(str_0, int_0)
    assert var_0 == '?0fcT[&J\\\n20G%'

    # Test 2
    str_0 = 'cG0\x11%3q^E.\x17p'
    int_0 = -87
    var_0 = update_query_params(str_0, int_0)
    assert var_0 == 'cG0\x11%3q^E.\x17p'

    # Test 3

# Generated at 2022-06-26 03:09:17.083141
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = "ABCDEFG"
    int_a, int_b, int_c, int_d, int_e, int_f, int_g = "A", "B", "C", "D", "E", "F", "G"
    dict_0 = {int_a, int_b, int_c, int_d, int_e, int_f, int_g}

    update_query_params(str_0, dict_0)

# Generated at 2022-06-26 03:09:27.411145
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com', 10) == 'http://example.com?10'
    assert update_query_params('http://example.com?a=9', 10) == 'http://example.com?a=9&10'
    assert update_query_params('http://example.com?a=9#hash', 10) == 'http://example.com?a=9&10#hash'
    assert update_query_params('http://example.com?a=9&a=10', 10) == 'http://example.com?a=9&a=10&10'
    assert update_query_params('http://example.com?a=9&b=10', 10) == 'http://example.com?a=9&b=10&10'

# Generated at 2022-06-26 03:09:29.716913
# Unit test for function update_query_params
def test_update_query_params():
    assert update_query_params('http://example.com?foo=bar&biz=baz', {'foo': 'stuff'}) == 'http://example.com?foo=stuff&biz=baz'

# Generated at 2022-06-26 03:09:36.459828
# Unit test for function update_query_params
def test_update_query_params():
    str_0 = 'http://example.com?foo=bar&biz=baz'
    params = {
        'foo': 'stuff',
        'insert': 'newvalue',
        'dontoverwrite': ['alreadythere'],
    }
    var_0 = update_query_params(str_0, params)
    assert var_0 == 'http://example.com?biz=baz&foo=stuff&insert=newvalue&dontoverwrite=alreadythere'

    params = {
        'dosq': True,
        'list': ['alreadythere', 'newvalue']
    }
    var_0 = update_query_params(str_0, params)