

# Generated at 2022-06-21 14:34:20.603120
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    a = PluginManager()
    assert isinstance(a.get_auth_plugin('oauth2'), HTTPTokenAuth)
    assert isinstance(a.get_auth_plugin('basic'), HTTPBasicAuth)

# Generated at 2022-06-21 14:34:27.268922
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import BuiltinAuthPlugin
    from httpie.plugins import BuiltinFormatterPlugin
    from httpie.plugins import BuiltinConverterPlugin
    from httpie.plugins import BuiltinTransportPlugin
    def f1():
        p1 = PluginManager()
        p1.append(BuiltinAuthPlugin)
        p1.append(BuiltinFormatterPlugin)
        p1.append(BuiltinConverterPlugin)
        p1.append(BuiltinTransportPlugin)
        p1.filter(AuthPlugin)

# Generated at 2022-06-21 14:34:33.506270
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins_All = [
        'httpie.plugins.auth.v1',
        'httpie.plugins.formatter.v1',
        'httpie.plugins.converter.v1',
        'httpie.plugins.transport.v1',
    ]
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print(plugins)
    assert len(plugins_All) == len(plugins)


# Generated at 2022-06-21 14:34:37.568181
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.register(HawkAuthPlugin, BasicAuthPlugin, OAuth1Plugin)
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugin('Basic') is BasicAuthPlugin
    
    

# Generated at 2022-06-21 14:34:39.871830
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.register(MyAuthPlugin)
    assert pm.get_auth_plugin('my-auth') == MyAuthPlugin


# Generated at 2022-06-21 14:34:42.297291
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters() == []
    plugin_manager.register(FormatterPlugin)
    assert FormatterPlugin in plugin_manager.get_formatters()


# Generated at 2022-06-21 14:34:45.072983
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert(PluginManager.__repr__(PluginManager()) == '<PluginManager: []>')

# Test for method get_transport_plugins of class PluginManager

# Generated at 2022-06-21 14:34:47.609246
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    assert len(p) == 0
    p.load_installed_plugins()
    assert len(p) != 0



# Generated at 2022-06-21 14:34:51.844896
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    Plugin = Type[BasePlugin](str('Plugin'), (BasePlugin,), {})
    assert Plugin not in pm
    pm.register(Plugin)
    assert Plugin in pm


# Generated at 2022-06-21 14:35:01.697362
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm.register
    assert pm.unregister
    assert pm.filter
    assert pm.get_auth_plugins
    assert pm.get_auth_plugin_mapping
    assert pm.get_auth_plugin
    assert pm.get_formatters
    assert pm.get_formatters_grouped
    assert pm.get_converters
    assert pm.get_transport_plugins
    assert repr(pm)   

#def test_register():

#def test_unregister():

#def test_filter():

#def test_get_auth_plugins():

#def test_get_auth_plugin_mapping():

#def test_get_auth_plugin():

#def test_get_formatters():

#def test_get_formatters_grouped():



# Generated at 2022-06-21 14:35:06.428986
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    import sys
    import pytest
    from httpie.plugins.manager import PluginManager
    plugins = PluginManager()
    plugins.load_installed_plugins()
    mapping = plugins.get_auth_plugin_mapping()
    assert mapping != {}

# Generated at 2022-06-21 14:35:08.660763
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(MockPlugin)
    assert len(plugin_manager) == 1
    plugin_manager.unregister(MockPlugin)
    assert len(plugin_manager) == 0

# Generated at 2022-06-21 14:35:10.750116
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm=PluginManager()
    pm.register(BasePlugin)
    pm.unregister(BasePlugin)
    assert len(pm)==0

# Generated at 2022-06-21 14:35:14.395488
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()

    assert(len(p) == 0)

    class A(BasePlugin):
        pass

    p.register(A)
    assert(len(p) == 1)

    class B(BasePlugin):
        pass

    p.register(B)
    assert(len(p) == 2)



# Generated at 2022-06-21 14:35:17.718076
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    import pytest
    pm = PluginManager()
    with pytest.raises(AttributeError) as attribute_error:
        print(pm)

plugins = PluginManager()

# Generated at 2022-06-21 14:35:20.032433
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    converter_plugins = plugin_manager.get_converters()
    assert converter_plugins



# Generated at 2022-06-21 14:35:26.066683
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from pytest import raises
    from typing import Dict
    # Case1
    manager = PluginManager()
    manager.register(JSONFormatterPlugin)
    
    result = manager.get_formatters()
    assert isinstance(result, list)
    assert result[0] == JSONFormatterPlugin

    #Case2
    manager.unregister(JSONFormatterPlugin)
    result = manager.get_formatters()
    assert result == []


# Generated at 2022-06-21 14:35:31.259294
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_list = PluginManager()
    plugin_list.append('')
    plugin_list.register('httpie')
    plugin_list.register('httpie', 'httpie')
    assert plugin_list[1] == 'httpie'
    assert plugin_list[2] == 'httpie'


# Generated at 2022-06-21 14:35:36.674047
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    mappings = pluginManager.get_auth_plugin_mapping()
    assert len(mappings) == 1
    assert "bearer" in mappings
    assert mappings["bearer"].__class__.__name__ == "BearerAuthPlugin"


# Generated at 2022-06-21 14:35:39.204214
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    p = PluginManager()
    p.register(BasicAuthPlugin, DigestAuthPlugin)
    auth_plugins = p.get_auth_plugins()
    assert(len(auth_plugins) == 2)



# Generated at 2022-06-21 14:35:53.841143
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print('\n'+"-"*80)
    print('Title: Unit test for method get_formatters_grouped of class PluginManager')
    print(plugins)
    print('\n'+"-"*80)
    d = plugins.get_formatters_grouped()
    for group_name, group in d.items():
        print(f'-----group_name: {group_name}, group: {group}')
        for plugin in group:
            print(f'----------plugin: {plugin}')
    print('\n'+"-"*80)
    assert plugins[2].format == 'k"v"'


if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-21 14:35:58.304610
# Unit test for constructor of class PluginManager
def test_PluginManager():
    # construct
    pm = PluginManager()
    assert isinstance(pm, PluginManager)

    # check entry points
    assert len(ENTRY_POINT_NAMES) == 4



# Generated at 2022-06-21 14:36:04.116312
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    f = plugin_manager.get_formatters_grouped()
    assert isinstance(f, dict)
    for group_name, group in f.items():
        assert group_name in ['screen', 'pager', 'browser', 'template']
        for plugin in group:
            assert issubclass(plugin, FormatterPlugin)



# Generated at 2022-06-21 14:36:07.403785
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(AuthPlugin)
    auth = list(manager.get_auth_plugin_mapping().keys())[0]
    print(auth)
    assert auth == 'auth'


# Generated at 2022-06-21 14:36:09.082415
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# Generated at 2022-06-21 14:36:13.044495
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    pluginManager.unregister(pluginManager.get_formatters()[0])
    assert len(pluginManager.get_formatters()) == len(pluginManager.get_formatters()) - 1

# Generated at 2022-06-21 14:36:16.745967
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.append(HttpieOAuth2Plugin)
    plugin_manager.append(HttpieHTTPBasicPlugin)
    plugin_manager.append(HttpieHTTPDigestPlugin)
    assert len(plugin_manager.get_auth_plugins()) == 3



# Generated at 2022-06-21 14:36:19.254271
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(CliTransportPlugin, CliAuthPlugin)
    assert len(plugin_manager.get_converters()) == 1

# Generated at 2022-06-21 14:36:23.038928
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    class Plugin(AuthPlugin):
        pass

    class Plugin2(AuthPlugin):
        pass

    manager = PluginManager([Plugin])
    assert Plugin in manager.get_auth_plugins() and Plugin2 not in manager.get_auth_plugins()


# Generated at 2022-06-21 14:36:26.911468
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin = PluginManager()
    plugin.load_installed_plugins()

    formatter = plugin.get_formatters()
    print(formatter)
    assert(len(formatter) > 0)

# Generated at 2022-06-21 14:36:44.136766
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()


# Generated at 2022-06-21 14:36:50.277042
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pl = PluginManager()
    class DemoPlugin(BasePlugin):
        pass

    # Before unregister
    pl.register(DemoPlugin)
    assert DemoPlugin in pl
    assert pl.count(DemoPlugin) == 1

    # After unregister
    pl.unregister(DemoPlugin)
    assert DemoPlugin not in pl
    assert pl.count(DemoPlugin) == 0

# Generated at 2022-06-21 14:37:01.316785
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONParseError, JSONFormatter
    from httpie.plugins.builtin import RawJSONFormatter, ConsoleFormatter
    from httpie.plugins.builtin import HeadersFormatter, StreamFormatter

    plugin_manager = PluginManager()
    plugin_manager.register(JSONParseError)
    plugin_manager.register(JSONFormatter)
    plugin_manager.register(RawJSONFormatter)
    plugin_manager.register(ConsoleFormatter)
    plugin_manager.register(HeadersFormatter)
    plugin_manager.register(StreamFormatter)

    grouped_formatters = plugin_manager.get_formatters_grouped()
    assert grouped_formatters['json'][0].__name__ == "JSONFormatter"

# Generated at 2022-06-21 14:37:06.204178
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()

    assert not pm.get_auth_plugins()
    assert not pm.get_formatters()
    assert not pm.get_converters()
    assert not pm.get_transport_plugins()


# PluginManager class has a method "register", but get_auth_plugins is an empty list

# Generated at 2022-06-21 14:37:10.137219
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_converters()
    # The list might be empty if the tests are run outside of the httpie dir
    return plugin_manager.get_converters()

# Generated at 2022-06-21 14:37:20.233943
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    import httpie.output.plugins

    assert PluginManager.get_formatters.__name__ == 'get_formatters'
    assert PluginManager.get_formatters.__qualname__ == 'PluginManager.get_formatters'
    assert PluginManager.get_formatters.__doc__ == 'Return a list of installed output formatters'

    # Instanciate a PluginManager without any plugins registered
    assert PluginManager().get_formatters() == []

    # Instanciate a PluginManager with the formatters registered
    plugin_manager = PluginManager()
    plugin_manager.register(*httpie.output.plugins.__all__)
    assert len(plugin_manager.get_formatters()) > 0
    formatter = plugin_manager.get_formatters()[0]
    assert hasattr(formatter, 'name')
    assert hasattr

# Generated at 2022-06-21 14:37:21.936054
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    assert (isinstance(p,list))
    assert (p == [])



# Generated at 2022-06-21 14:37:23.335390
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager().get_formatters()


# Generated at 2022-06-21 14:37:35.016604
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()

    class AuthPlugin1:
        auth_type = 'auth1'

    class AuthPlugin2:
        auth_type = 'auth2'

    plugin_manager.register(AuthPlugin1, AuthPlugin2)


    assert plugin_manager.get_auth_plugin('auth1') == AuthPlugin1
    assert plugin_manager.get_auth_plugin('auth2') == AuthPlugin2
    try:
        plugin_manager.get_auth_plugin('auth3')
    except KeyError:
        assert 1
    else:
        assert 0

    plugin_manager.unregister(AuthPlugin1)

    try:
        plugin_manager.get_auth_plugin('auth1')
    except KeyError:
        assert 1
    else:
        assert 0



# Generated at 2022-06-21 14:37:37.309832
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.append(AuthPlugin)
    got = manager.get_auth_plugin('token')
    assert got == AuthPlugin


# Generated at 2022-06-21 14:37:56.073518
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    p.register(AuthPlugin)
    assert AuthPlugin in p


# Generated at 2022-06-21 14:38:00.554155
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(AuthPlugin, ConverterPlugin)
    assert pm.filter(AuthPlugin) == [AuthPlugin]
    assert pm.filter(ConverterPlugin) == [ConverterPlugin]


# Generated at 2022-06-21 14:38:06.891450
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    # Create an instance of PluginManager
    pm1 = PluginManager()
    # Add a plugin to instance of PluginManager
    fp1 = FormatterPlugin()
    pm1.register(fp1)
    # Delete a plugin from the instance of PluginManager
    pm1.unregister(fp1)
    # Check if the plugin is deleted
    assert pm1 == []
    # Check if the current instance is an instance of PluginManager
    assert isinstance(pm1, PluginManager)


# Generated at 2022-06-21 14:38:16.570114
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert({} == pm.get_auth_plugin_mapping())
    pm.register(CustomAuthPlugin)
    assert({'CUSTOM_AUTH_PLUGIN': CustomAuthPlugin} == pm.get_auth_plugin_mapping())
    pm.register(AWSAuthPlugin)
    assert({'CUSTOM_AUTH_PLUGIN': CustomAuthPlugin, 'AWS_AUTH_PLUGIN': AWSAuthPlugin} == pm.get_auth_plugin_mapping())
    pm.unregister(CustomAuthPlugin)
    assert({'AWS_AUTH_PLUGIN': AWSAuthPlugin} == pm.get_auth_plugin_mapping())



# Generated at 2022-06-21 14:38:18.420662
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) > 0



# Generated at 2022-06-21 14:38:28.068935
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, HTTPBasicAuthPluginV1, HTTPBasicAuthPluginV2, HTTPTokenAuthPlugin, BasicPlugin
    import pytest
    from httpie.core import main as httpie_core
    from httpie.core import main
    from httpie.plugins import builtin
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, HTTPTokenAuthPlugin, BasicPlugin
    from httpie import ExitStatus
    from pytest_mock import mocker
    auth_plugin1 = HTTPBasicAuthPluginV1()
    auth_plugin2 = HTTPBasicAuthPluginV2()
    auth_plugin3 = HTTPTokenAuthPlugin()

    pm = PluginManager()
    pm.register(auth_plugin1, auth_plugin2, auth_plugin3)
    assert len(pm) == 3

# Generated at 2022-06-21 14:38:37.184059
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPBasicAuth

    mgr = PluginManager()
    assert len(mgr.get_converters()) == 0

    mgr.register(HTTPBasicAuth)
    mgr.register(HTTPBearerAuth)
    mgr.register(HTTPBasicAuth)

    assert len(mgr.get_converters()) == 2

    mgr.get_converters().remove(HTTPBasicAuth)

    assert len(mgr.get_converters()) == 1

# Generated at 2022-06-21 14:38:38.892148
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    x = plugin_manager.__repr__()
    s = str(x)
    assert s == '<PluginManager: []>'



# Generated at 2022-06-21 14:38:42.883099
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugins()) > 0
    assert len(pm.get_formatters()) > 0
    assert len(pm.get_converters()) > 0
    assert len(pm.get_transport_plugins()) > 0
    print(pm)

# Generated at 2022-06-21 14:38:44.587322
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_list = []
    PluginManager(plugin_list).unregister(AuthPlugin)
    assert PluginManager(plugin_list) == []

# Generated at 2022-06-21 14:39:26.726839
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    assert type(p) == PluginManager
    assert p.filter(AuthPlugin) == []
    assert p.filter(FormatterPlugin) == []
    assert p.filter(ConverterPlugin) == []
    assert p.filter(TransportPlugin) == []
    p.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert p.filter(AuthPlugin) == [AuthPlugin]
    assert p.filter(FormatterPlugin) == [FormatterPlugin]
    assert p.filter(ConverterPlugin) == [ConverterPlugin]
    assert p.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-21 14:39:30.150167
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(
        get_formatters.__class__,
        test_PluginManager_get_formatters.__class__
    )
    assert plugins.get_formatters() == [get_formatters.__class__]

# Generated at 2022-06-21 14:39:32.833194
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # ARRANGE
    plugin_manager = PluginManager()

    # ACT
    plugins = plugin_manager.get_transport_plugins()

    # ASSERT
    assert plugins == []

# Generated at 2022-06-21 14:39:34.192145
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager.__base__ is list


# Generated at 2022-06-21 14:39:37.121765
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    manager.load_installed_plugins()
    print('manager.formatters_grouped: ')
    print(manager.get_formatters_grouped())


# Generated at 2022-06-21 14:39:41.699363
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    import httpie.plugins
    pl = PluginManager()
    assert str(pl) == '<PluginManager: []>'
    pl.load_installed_plugins()
    assert str(pl) == f'<PluginManager: {sorted(pl)}>'

# Generated at 2022-06-21 14:39:44.970315
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # Setup
    pm = PluginManager()

    # Exercise
    r = pm.__repr__()

    # Verify
    assert r == '<PluginManager: []>'
    # Cleanup - none necessary



# Generated at 2022-06-21 14:39:47.352083
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.register(Plugin)
    assert pm.get_auth_plugin("a") == Plugin


# Generated at 2022-06-21 14:39:55.046999
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():

    PM = PluginManager()

    PM.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

    l1 = len(PM)

    plugin_instance = BasePlugin()

    PM.append(plugin_instance)
    l2 = len(PM)
    assert len(PM) == l2

    PM.remove(plugin_instance)
    l3 = len(PM)
    assert len(PM) == l3

    assert l2 == l1 + 1

    assert l3 == l2 - 1



# Generated at 2022-06-21 14:39:57.060019
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'


# Generated at 2022-06-21 14:41:16.468159
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins.get_transport_plugins()) == 6



# Generated at 2022-06-21 14:41:19.433595
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_mgr = PluginManager()
    plugin_mgr.register(TestFormatter1, TestFormatter2, TestFormatter3)
    assert plugin_mgr.get_formatters_grouped() == {
        'test': [TestFormatter1, TestFormatter2, TestFormatter3]
    }


# Generated at 2022-06-21 14:41:24.787598
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = [
            BasePlugin,
            TransportPlugin,
            ConverterPlugin,
            FormatterPlugin,
            AuthPlugin
        ]
    pm = PluginManager()
    pm.register(*plugins)
    assert pm == plugins


# Generated at 2022-06-21 14:41:35.219969
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    class PA(BasePlugin):
        pass
    class PB(PA):
        pass
    class PC(PA):
        pass
    class PD(PC):
        pass
    
    pm.register(PA)
    assert pm.filter(PA) == [PA]
    assert pm.filter(PB) == []
    assert pm.filter(PC) == [PC]
    assert pm.filter(PD) == [PD]

    pm.register(PB)
    assert pm.filter(PA) == [PA, PB]
    assert pm.filter(PB) == [PB]
    assert pm.filter(PC) == [PC]
    assert pm.filter(PD) == [PD]

    pm.register(PC)
    assert pm.filter(PA) == [PA, PB, PC]

# Generated at 2022-06-21 14:41:38.670141
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(TestPlugin)
    result = pm.get_auth_plugin_mapping()
    assert len(result.keys()) == 1
    assert 'auth-type' in result.keys()
    assert result['auth-type'] == TestPlugin



# Generated at 2022-06-21 14:41:50.144617
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    from httpie.plugins import ConverterPlugin, FormatterPlugin, AuthPlugin, TransportPlugin
    from httpie.plugins.core import HTTPBasicAuthPlugin, HTTPDigestAuthPlugin, JSONFormatterPlugin, HTMLFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.authentication.multipart import MultipartFormDataAuthPlugin
    PluginManager_1 = PluginManager()
    PluginManager_1.register(ConverterPlugin, FormatterPlugin, AuthPlugin, TransportPlugin, JSONFormatterPlugin, HTMLFormatterPlugin, URLEncodedFormatterPlugin, HTTPBasicAuthPlugin, HTTPDigestAuthPlugin, MultipartFormDataAuthPlugin)

# Generated at 2022-06-21 14:41:56.233068
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plug_man = PluginManager()
    plug_man.load_installed_plugins()

    for item in plug_man.get_formatters():
        if 'pretty' in item.name:
            assert item.name == 'Pretty'
            assert item.group_name == 'Pretty'
            assert item.can_prettify_body == True
            assert item.can_prettify_headers == True
            assert item.supports_color == True



# Generated at 2022-06-21 14:42:02.169821
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import auth
    pm = PluginManager().load_installed_plugins()
    print(pm.get_auth_plugins())
    auth_plugins = pm.get_auth_plugins()
    assert(len(auth_plugins) == 3)
    assert(auth.HTTPBasicAuthPlugin in auth_plugins)
    assert(auth.HTTPTokenAuthPlugin in auth_plugins)
    assert(auth.HTTPCookieAuthPlugin in auth_plugins)

if __name__ == '__main__':
    test_PluginManager_get_auth_plugins()

# Generated at 2022-06-21 14:42:03.441671
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.manager import PluginManager

    pm = PluginManager()
    pm.get_formatters()

# Generated at 2022-06-21 14:42:05.995557
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    rr = pm.get_transport_plugins()
    assert len(rr) == 5
    rr = pm.get_formatters()
    assert len(rr) == 7