

# Generated at 2022-06-21 14:34:31.554832
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.formatters.base import Formatter
    class MockFormatterA(Formatter):
        group_name = 'A'
    class MockFormatterB(Formatter):
        group_name = 'B'
    class MockFormatterC(Formatter):
        group_name = 'A'
    a, b, c = MockFormatterA, MockFormatterB, MockFormatterC
    testee = PluginManager()
    testee.register(b, c, a)
    assert testee.get_formatters_grouped() == {'A': [a, c], 'B': [b]}

# Generated at 2022-06-21 14:34:38.483472
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import BuiltinPlugin
    plugin_manager = PluginManager()
    plugin_manager.register(*BuiltinPlugin.__subclasses__())
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_auth_plugins())==6
    assert len(plugin_manager.get_formatters())==5
    assert plugin_manager[5].package_name=='httpie-jwt-auth'

test_PluginManager_load_installed_plugins()

# Generated at 2022-06-21 14:34:39.271830
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    PluginManager.register('http.py')

# Generated at 2022-06-21 14:34:45.841489
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
  from httpie.plugins.auth import AuthPlugin, HTTPBasicAuth
  from httpie.plugins.basic_auth import BasicAuthPlugin
  from httpie.plugins.digest_auth import DigestAuthPlugin
  plugins = PluginManager()
  assert all(isinstance(plugin, AuthPlugin) for plugin in plugins.get_auth_plugins())
  assert all(plugin in [BasicAuthPlugin, DigestAuthPlugin] for plugin in plugins.get_auth_plugins())
  assert all(plugin.auth_type in ['basic', 'digest'] for plugin in plugins.get_auth_plugins())


# Generated at 2022-06-21 14:34:49.275670
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_converters()) > 10
    # print(pm.get_converters())


# Generated at 2022-06-21 14:34:52.375237
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    assert manager.get_auth_plugin("basic") == "basic"

# Generated at 2022-06-21 14:35:00.092768
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    import sys
    import os

    sys.path.append('..')
    from httpie.session import Session

    if __name__ == '__main__':
        import pytest
        raise SystemExit(pytest.main([os.path.basename(__file__), '-v', '-s']))

    # Initialize Session and PluginManager
    session = Session()
    pm = PluginManager()

    # Test if we can get the auth plugins
    if pm.get_auth_plugins():
        pass
    else:
        assert False, "Expected to get the auth plugins"


# Generated at 2022-06-21 14:35:04.141201
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) >= 15
    assert len(plugin_manager.get_auth_plugins()) >= 5
    assert len(plugin_manager.get_formatters()) >= 3
    assert len(plugin_manager.get_formatters_grouped()) >= 2
    assert len(plugin_manager.get_converters()) == 2
    assert len(plugin_manager.get_transport_plugins()) == 1

# Generated at 2022-06-21 14:35:07.876567
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    assert p


# Generated at 2022-06-21 14:35:11.901782
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(TestAuthPlugin)

    # No such plugin
    assert manager.get_auth_plugin('unregistered') is None

    # Found
    assert manager.get_auth_plugin('test_auth').auth_type == 'test_auth'



# Generated at 2022-06-21 14:35:22.686768
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(test_PluginManager_get_formatters_grouped_Plugin1,
                     test_PluginManager_get_formatters_grouped_Plugin2,
                     test_PluginManager_get_formatters_grouped_Plugin3)
    assert plugins.get_formatters_grouped() == {
        'Group 1': [test_PluginManager_get_formatters_grouped_Plugin1],
        'Group 2': [test_PluginManager_get_formatters_grouped_Plugin2,
                    test_PluginManager_get_formatters_grouped_Plugin3],
    }


# Generated at 2022-06-21 14:35:23.543875
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()


# Generated at 2022-06-21 14:35:34.857475
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Mock plugins
    class Plugin1(FormatterPlugin):
        """
        documentation for Plugin1
        """
        group_name = 'group1'
        group_info = 'infos'

    class Plugin2(FormatterPlugin):
        """
        documentation for Plugin2
        """
        group_name = 'group1'
        group_info = 'infos'

    class Plugin3(FormatterPlugin):
        """
        documentation for Plugin3
        """
        group_name = 'group2'
        group_info = 'infos'

    # Unit test
    plugins = PluginManager()
    plugins.register(Plugin1, Plugin2, Plugin3)
    plugins_grouped = plugins.get_formatters_grouped()
    plugin1 = plugins_grouped['group1'][0]
    plugin2 = plugins_grouped

# Generated at 2022-06-21 14:35:38.458051
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    assert plugins == []
    plugins.register(AuthPlugin)
    assert AuthPlugin in plugins
    assert plugins == [AuthPlugin]
    plugins.register(AuthPlugin)
    assert plugins == [AuthPlugin, AuthPlugin]

# Generated at 2022-06-21 14:35:42.233475
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    converters = plugin_manager.get_converters()
    if converters == []:
        assert False
    

# Generated at 2022-06-21 14:35:47.742360
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    for plugin_group_name, plugins_group in plugin_manager.get_formatters_grouped().items():
        print(plugin_group_name)
        for plugin in plugins_group:
            print(plugin.name)

# Command Line Interface 'httpie-plugin-check'

# Generated at 2022-06-21 14:35:51.124782
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    p.load_installed_plugins()
    r = repr(p)
    assert r == '<PluginManager: []>'


# Generated at 2022-06-21 14:35:51.836838
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert str(PluginManager())


# Generated at 2022-06-21 14:35:55.134948
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    assert len(pm) == 0
    pm.register(AuthPlugin)
    assert len(pm) == 1
    pm.unregister(AuthPlugin)
    assert len(pm) == 0

# Generated at 2022-06-21 14:36:00.385434
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = [
        FormatterPlugin(),
        FormatterPlugin(),
        FormatterPlugin(),
        FormatterPlugin(),
    ]
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)

    assert plugin_manager.get_formatters_grouped() == {
        None: plugins,
    }

# Generated at 2022-06-21 14:36:08.930041
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    Manager = PluginManager()

# Generated at 2022-06-21 14:36:18.653756
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    import httpie.plugins
    manager = PluginManager()
    httpie.plugins.manager = manager
    manager.load_installed_plugins()

    expected_formatters = ['csv', 'json', 'jsonlines', 'ltsv', 'table', 'tsv', 'yaml']

    # we parse the following plugins
    # https://github.com/jakubroztocil/httpie/blob/master/httpie/output/formatters/__init__.py
    # which are available by default
    pprint(manager)
    formatters = manager.get_formatters()
    print(formatters)
    pprint(manager.get_formatters_grouped())

    assert set([f.name for f in formatters]) == set(expected_formatters)

test_PluginManager_get_formatters()

# Generated at 2022-06-21 14:36:29.682833
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    # Make sure that plugins are loaded
    assert len(manager.get_auth_plugins()) != 0
    assert len(manager.get_formatters()) != 0
    assert len(manager.get_converters()) != 0
    assert len(manager.get_transport_plugins()) != 0
    # Make sure that all formatters are grouped properly
    assert len(manager.get_formatters_grouped().keys()) != 0
    for v in manager.get_formatters_grouped().values():
        assert len(v) != 0
    # Make sure that all auth plugins are mapped properly
    assert len(manager.get_auth_plugin_mapping().keys()) != 0

# Generated at 2022-06-21 14:36:36.429599
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()

    class auth_plugin1(AuthPlugin):
        auth_type = 'dummy1'

    class auth_plugin2(AuthPlugin):
        auth_type = 'dummy2'

    plugin_manager.register(auth_plugin1, auth_plugin2)

    assert len(plugin_manager.get_auth_plugins()) == 2
    assert auth_plugin1 in plugin_manager.get_auth_plugins()
    assert auth_plugin2 in plugin_manager.get_auth_plugins()

# Generated at 2022-06-21 14:36:40.294122
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Given
    pm = PluginManager()
    pm.load_installed_plugins()
    # When
    auth_plugins = pm.get_auth_plugins()
    # Then
    assert len(auth_plugins) > 0
    auth_plugins[0]


# Generated at 2022-06-21 14:36:44.249790
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    expected_result = ['https']

    result = []
    for plugin in PluginManager.get_transport_plugins():
        result.append(plugin.name)
        
    try:
        assert result == expected_result
    except AssertionError:
        print('Method get_transport_plugins of class PluginManager is not working propertly')


# Generated at 2022-06-21 14:36:47.219829
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    t = len(plugins.get_formatters())
    assert t == 10



# Generated at 2022-06-21 14:36:48.326867
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_auth_plugins()) == 3

# Generated at 2022-06-21 14:36:53.365524
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from . import plugins
    from .plugins.formatter.__main__ import get_formatters_grouped
    from .plugins import formatter

    # Replace default plugin manager with our own
    plugins.manager = PluginManager()
    # Register only required plugins

# Generated at 2022-06-21 14:37:03.513003
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Create a request object
    from httpie import InputRequest
    from httpie.input import ParseError

    request = InputRequest('GET', 'http://127.0.0.1/', None)

    # Create a plugin manager
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # Define a new plugin class
    class Plugin(AuthPlugin):
        auth_type = 'test_plugin'
        description = 'My test plugin'

        def get_auth(self, username=None, password=None):
            if username and password:
                return username + ":" + password
            else:
                return None

    # Register the plugin
    plugin_manager.register(Plugin)

    # Get the plugin
    plugin = plugin_manager.get_auth_plugin('test_plugin')

# Generated at 2022-06-21 14:37:16.287531
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import auth, formatter, converter, transport
    from pkg_resources import iter_entry_points
    from typing import Dict
    from unittest import mock
    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin
    from httpie.plugins.base import BasePlugin

    pm = PluginManager()
    entry_point_name = 'httpie.plugins.auth.v1'
    entry_point_name2 = 'httpie.plugins.formatter.v1'
    entry_point_name3 = 'httpie.plugins.converter.v1'
    entry_point_name4 = 'httpie.plugins.transport.v1'
    plugin_name = 'httpie_aws_authv4.AwsAuthV4'

# Generated at 2022-06-21 14:37:21.424444
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins import AuthPlugin
    pluginManager = PluginManager()
    pluginManager.register(HTTPBasicAuth)
    for p in pluginManager.get_auth_plugins():
        assert issubclass(p, AuthPlugin)
    assert pluginManager.get_auth_plugin('basic') == HTTPBasicAuth

# Generated at 2022-06-21 14:37:30.009971
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.adapters import BaseAdapter, HTTPAdapter
    
    class MockAdapter(BaseAdapter):
        def __init__(self):
            super().__init__()

    mock = MockAdapter()
    plugin_manager = PluginManager()
    plugin_manager.register(MockAdapter, HTTPAdapter)
    
    res = plugin_manager.get_transport_plugins()
    assert res == [MockAdapter, HTTPAdapter]
    assert isinstance(res[0], type)
    assert isinstance(res[1], type)


# Generated at 2022-06-21 14:37:32.687357
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    _plugins = PluginManager()
    _plugins.append('test')
    _plugins.remove('test')
    assert _plugins == []


# Generated at 2022-06-21 14:37:35.357360
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    l = PluginManager()
    assert l == []
    l.register()
    assert l == []
    l.get_converters() == []


# Generated at 2022-06-21 14:37:42.060798
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginsM = PluginManager()
    pluginsM.register(JUnitXMLFormatter, XUnitXMLFormatter, RawJUnitXMLFormatter, HTMLExportFormatter)
    plugins = pluginsM.get_formatters()

# Generated at 2022-06-21 14:37:49.883340
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterA(FormatterPlugin):
        group_name = 'A'
        group_order = 1

    class FormatterB(FormatterPlugin):
        group_name = 'B'
        group_order = 2

    class FormatterC(FormatterPlugin):
        group_name = 'C'
        group_order = 3

    assert PluginManager().get_formatters_grouped() == {
        'A': [FormatterA], 'B': [FormatterB], 'C': [FormatterC]
    }


# Generated at 2022-06-21 14:37:53.647377
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugins = [Plugin]
    try:
        plugin_manager.register(*plugins)
        assert plugin_manager.get_converters() == plugins
    finally:
        plugin_manager.unregister(Plugin)


# Generated at 2022-06-21 14:38:05.687138
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    import httpie.plugins.auth.basic_auth
    import httpie.plugins.auth.digest_auth
    import httpie.plugins.auth.hmac_auth
    import httpie.plugins.auth.ntlm_auth
    import os
    import sys
    import tempfile

    # Simulate the presence of a plugin by creating an empty folder
    plugin_path = tempfile.mkdtemp()
    sys.path.insert(0, plugin_path)
    plugin_name = 'test_plugin_manager'
    os.mkdir(os.path.join(plugin_path, plugin_name))

    # Put in that folder a file containing a class that is a subclass of both BasePlugin and AuthPlugin

# Generated at 2022-06-21 14:38:06.656699
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# Generated at 2022-06-21 14:38:18.247813
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager.get_auth_plugins.__doc__ == 'Return a list of installed AuthPlugins'


# Generated at 2022-06-21 14:38:23.924523
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.transport import (
        LocalFileAdapter,
        http,
        https
    )
    from httpie import __version__
    from httpie.plugins import TransportPlugin

    x = PluginManager()
    x.register(LocalFileAdapter, http, https)
    assert x.get_transport_plugins() == [LocalFileAdapter, http, https]

    assert issubclass(LocalFileAdapter, TransportPlugin)
    assert issubclass(http, TransportPlugin)
    assert issubclass(https, TransportPlugin)



# Generated at 2022-06-21 14:38:28.572322
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugin_size_before = len(plugins)
    plugin_to_be_unregistered = plugins[0]
    plugins.unregister(plugin_to_be_unregistered)
    plugin_size_after = len(plugins)
    assert plugin_size_after != plugin_size_before

# Generated at 2022-06-21 14:38:37.695302
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginManager = PluginManager()

    pluginList = [
        {"auth_type": "basic",
         "auth_plugin_class": "BasicAuthPlugin"},
        {"auth_type": "jwt",
         "auth_plugin_class": "JwtAuthPlugin"}
    ]

    expected_dict = {
        'basic': "BasicAuthPlugin",
        'jwt': "JwtAuthPlugin",
    }

    result_dict = {
        'basic': pluginList[0]['auth_plugin_class'],
        'jwt': pluginList[1]['auth_plugin_class']
    }

    assert expected_dict == result_dict

# Generated at 2022-06-21 14:38:39.594406
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.register(BasicAuthPlugin, DigestAuthPlugin)

    assert plugins.get_auth_plugin('basic') == BasicAuthPlugin
    assert plugins.get_auth_plugin('digest') == DigestAuthPlugin

# Generated at 2022-06-21 14:38:41.503532
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]

# Generated at 2022-06-21 14:38:42.716632
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    PluginManager.get_auth_plugin()



# Generated at 2022-06-21 14:38:43.246252
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pass
    

# Generated at 2022-06-21 14:38:45.576267
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    # Check the number of installed plugins
    assert len(plugins) > 0


# Generated at 2022-06-21 14:38:47.403962
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}



# Generated at 2022-06-21 14:38:58.778581
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(CustomAuthPlugin)
    assert len(pm.get_auth_plugins()) == 1
    assert pm.get_auth_plugins()[0] == CustomAuthPlugin


# Generated at 2022-06-21 14:39:04.044644
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    assert repr(p) == '<PluginManager: []>'
    p.register(AuthPlugin)
    assert repr(p) == '<PluginManager: [httpie.plugins.auth.AuthPlugin]>'


# Singleton
plugins = PluginManager()
plugins.register(AuthPlugin)
plugins.register(FormatterPlugin)
plugins.register(ConverterPlugin)
plugins.register(TransportPlugin)

# Generated at 2022-06-21 14:39:07.629077
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    assert manager.get_auth_plugins() == []
    manager.register(AuthPlugin, TransportPlugin)
    assert manager.get_auth_plugins() == [AuthPlugin]   



# Generated at 2022-06-21 14:39:08.779602
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    PluginManager().get_converters()

# Generated at 2022-06-21 14:39:19.660202
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # Note: Plugins must be registered explicitly in order to be activated in test.
    from httpie.plugins.help.formatter import HelpFormatterPlugin
    from httpie.plugins.pretty.formatter import PrettyFormatterPlugin

    from httpie.plugins.json.formatter import JSONFormatterPlugin
    from httpie.plugins.json.pprint import PrettyJSONFormatterPlugin
    from httpie.plugins.json.stream import JSONStreamFormatterPlugin

    from httpie.plugins.html.formatter import HTMLFormatterPlugin

    plugin_manager.register(
        HelpFormatterPlugin,
        PrettyFormatterPlugin,
        JSONFormatterPlugin,
        PrettyJSONFormatterPlugin,
        JSONStreamFormatterPlugin,
        HTMLFormatterPlugin,
    )

   

# Generated at 2022-06-21 14:39:25.083120
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.register(HTTPBasicAuth, HTTPTokenAuth)
    print(pm)
    # <PluginManager: [<class 'httpie.plugins.auth.httpie.HTTPBasicAuth'>, <class 'httpie.plugins.auth.httpie.HTTPTokenAuth'>]>


# Instantiate global PluginManager
plugins = PluginManager()

# Generated at 2022-06-21 14:39:27.675297
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import HTTPBasicAuth
    from httpie.plugins import _HTTPiePlugin

    assert PluginManager.unregister(_HTTPiePlugin) == None

# Generated at 2022-06-21 14:39:29.469859
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    m = PluginManager()
    result =  m.get_formatters()
    print(result)



# Generated at 2022-06-21 14:39:32.113240
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_formatters())!=0


# Generated at 2022-06-21 14:39:34.601591
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Given
    plugins = PluginManager()
    plugins.register(AuthPlugin)

    # When
    result = plugins.get_auth_plugins()

    # Then
    assert type(result) == list
    assert len(result) == 1 and result[0] is AuthPlugin



# Generated at 2022-06-21 14:39:59.074918
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_formatters()) == 5
    assert len(pm.get_converters()) == 3
    assert len(pm.get_auth_plugins()) == 3
    assert len(pm.get_transport_plugins()) == 2

# Generated at 2022-06-21 14:40:00.992893
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pluginsManager = PluginManager()
    class Plugin():
        pass
    pluginsManager.register(Plugin)
    assert Plugin in pluginsManager


# Generated at 2022-06-21 14:40:09.769522
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from ..plugins.formatter import FormatterPlugin

    class DefaultFormatter(FormatterPlugin):

        def __init__(self):
            super(DefaultFormatter, self).__init__()
            self.group_name = 'Default'

    class ColoredFormatter(FormatterPlugin):

        def __init__(self):
            super(ColoredFormatter, self).__init__()
            self.group_name = 'Colored'

    class VerboseFormatter(FormatterPlugin):

        def __init__(self):
            super(VerboseFormatter, self).__init__()
            self.group_name = 'Verbose'

    class HeadersFormatter(FormatterPlugin):

        def __init__(self):
            super(HeadersFormatter, self).__init__()

# Generated at 2022-06-21 14:40:15.168184
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    print(dir(pm))
    print(pm.get_auth_plugin('basic'))
    print(pm.get_auth_plugin('digest'))
    print(pm.get_auth_plugin_mapping())


if __name__ == '__main__':
    test_PluginManager_get_auth_plugin()

# Generated at 2022-06-21 14:40:19.562536
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin1 = BasePlugin()
    plugin2 = BasePlugin()
    plugin3 = BasePlugin()
    plugin4 = BasePlugin()
    pm = PluginManager()
    pm.register(plugin1, plugin2, plugin3, plugin4)
    assert pm.get_formatters() == [plugin1, plugin2, plugin3, plugin4]


# Generated at 2022-06-21 14:40:21.319385
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    assert manager.get_auth_plugins() == []


# Generated at 2022-06-21 14:40:30.224872
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    print("test_PluginManager___repr__")
    plugin_manager = PluginManager()
    print(plugin_manager)
    assert str(plugin_manager) == "<PluginManager: []>"
    plugin_manager.register(FormatterPlugin)
    assert str(plugin_manager) == "<PluginManager: [<class 'httpie.plugins.formatter.FormatterPlugin'>]>"
    plugin_manager.register(FormatterPlugin)
    assert str(plugin_manager) == "<PluginManager: [<class 'httpie.plugins.formatter.FormatterPlugin'>, <class 'httpie.plugins.formatter.FormatterPlugin'>]>"

# Generated at 2022-06-21 14:40:31.361183
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert repr(pm) == '<PluginManager: []>'

# Generated at 2022-06-21 14:40:33.421188
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin)
    assert(len(pluginManager.get_auth_plugins()) == 1)


# Generated at 2022-06-21 14:40:40.733876
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import (
        BuiltinFormatterPlugin,
        BuiltinConverterPlugin,
    )
    from httpie.plugins.builtin import JSONFormatterPlugin, FormURLEncodedConverterPlugin
    
    pm = PluginManager()
    pm.register(JSONFormatterPlugin, FormURLEncodedConverterPlugin)

    formatters = pm.get_formatters()
    assert len(formatters) == 1
    assert isinstance(formatters[0], JSONFormatterPlugin)
    assert formatters[0].group_name == 'json'

    converters = pm.get_converters()
    assert len(converters) == 1
    assert isinstance(converters[0], FormURLEncodedConverterPlugin)
    assert converters[0].group_name == 'data'

   

# Generated at 2022-06-21 14:41:43.624769
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    test_manager = PluginManager()
    # test_manager.register(HTTPMockPlugin)
    assert test_manager.get_converters() == []

    class TestPlugin(BasePlugin):
        group_name = ''
        name = ''

        def load(cls):
            pass

    test_manager.register(TestPlugin)
    assert test_manager.get_converters() == []
    assert test_manager.get_formatters() == [TestPlugin]

    class TestConverterPlugin(TestPlugin, ConverterPlugin):
        pass

    test_manager.register(TestConverterPlugin)
    assert test_manager.get_converters() == [TestConverterPlugin]
    assert test_manager.get_formatters() == [TestPlugin]



# Generated at 2022-06-21 14:41:45.775959
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    assert isinstance(p, PluginManager)



# Generated at 2022-06-21 14:41:48.921640
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    assert manager.__repr__() == '<PluginManager: []>'

manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-21 14:41:55.112702
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    mock_plugin1 = MagicMock()
    mock_plugin1.auth_type = 'basic'
    mock_plugin2 = MagicMock()
    mock_plugin2.auth_type = 'digest'
    manager = PluginManager()
    manager.register(mock_plugin1, mock_plugin2)
    assert manager.get_auth_plugin_mapping() == {
        'basic': mock_plugin1,
        'digest': mock_plugin2
    }

# Generated at 2022-06-21 14:42:00.449898
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert True
    manager = PluginManager()
    manager.load_installed_plugins()
    formatters = manager.get_formatters()
    assert formatters != None
    assert formatters != [], 'no formatters found'
    # assert len(formatters) >= 2
    # assert formatters[0].__name__ == 'htmltableformatter.HTMLTableFormatter'
    # assert formatters[1].__name__ == 'jsonformatter.JSONFormatter'



# Generated at 2022-06-21 14:42:01.904337
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin
    p = PluginManager()
    c = ConverterPlugin

# Generated at 2022-06-21 14:42:04.207485
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.register(__class__)
    assert repr(pm) == "<PluginManager: [<class '__main__.test_PluginManager___repr__'>]>"

# Generated at 2022-06-21 14:42:11.845247
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # create new instance of class PluginManager
    plg = PluginManager()
    # create new list contains all auth plugins
    lst = plg.get_auth_plugins()
    plg.register(lst[0])
    # create new instance of class PluginManager
    result = plg.get_auth_plugin("digest")
    # test the result
    assert isinstance(result, type(lst[0])), "Error in PluginManager_get_auth_plugin()"
    # print result
    print("Test PluginManager_get_auth_plugin() - Successful!")


# Generated at 2022-06-21 14:42:12.742802
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == []

# Generated at 2022-06-21 14:42:13.656345
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()
    assert True


# Generated at 2022-06-21 14:44:14.196585
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.register(HTTPBasicAuth)
    assert plugins.get_auth_plugin('basic') == HTTPBasicAuth
    assert isinstance(plugins.get_auth_plugin('basic')('user', 'pass'), HTTPBasicAuth)


if __name__ == '__main__':
    test_PluginManager_get_auth_plugin()

# Generated at 2022-06-21 14:44:15.994855
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    assert pm.get_converters() == []


# Generated at 2022-06-21 14:44:16.502721
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pass

# Generated at 2022-06-21 14:44:19.496056
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    obj = PluginManager()
    obj.load_installed_plugins()
    num_PluginManager_init = len(obj)
    obj.unregister(obj[0])
    assert len(obj) == num_PluginManager_init - 1
    assert obj[0] != obj[-1]