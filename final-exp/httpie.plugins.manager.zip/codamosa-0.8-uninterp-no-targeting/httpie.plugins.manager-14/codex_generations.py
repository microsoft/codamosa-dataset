

# Generated at 2022-06-21 14:34:31.780420
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie import plugins
    from httpie.plugins import auth, converter, formatter, transport

    def assert_PluginManager_load_installed_plugins(
            plugin_manager: PluginManager):
        plugin_manager.load_installed_plugins()
        assert plugin_manager

        # Make sure that the entries in ENTRY_POINT_NAMES
        # are loaded as plugin types.
        assert auth.DigestAuthPlugin in plugin_manager
        assert converter.JSONPrettyPlugin in plugin_manager
        assert formatter.PrettyPlugin in plugin_manager
        assert transport.Urllib3Plugin in plugin_manager


# Generated at 2022-06-21 14:34:37.063041
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(
        TestPlugin("auth_type1", "package1"),
        TestPlugin("auth_type2", "package2"),
        TestPlugin("auth_type3", "package3"),
    )

    # Act
    actual = plugin_manager.get_auth_plugin_mapping()

    # Assert
    assert actual == {
        "auth_type1": TestPlugin("auth_type1", "package1"),
        "auth_type2": TestPlugin("auth_type2", "package2"),
        "auth_type3": TestPlugin("auth_type3", "package3"),
    }



# Generated at 2022-06-21 14:34:39.176920
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register(PluginManager)

    converters = manager.get_converters()
    assert converters == [PluginManager]

# Generated at 2022-06-21 14:34:43.403564
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    p1 = BasePlugin()
    p2 = ConverterPlugin()
    p3 = FormatterPlugin()
    plugin_manager.register(p1, p2, p3)
    print (plugin_manager.filter(by_type=ConverterPlugin))
    print (plugin_manager.filter(by_type=FormatterPlugin))
    print (plugin_manager.filter(by_type=BasePlugin))

test_PluginManager_filter()

# Generated at 2022-06-21 14:34:44.821956
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    obj = PluginManager([])
    obj.register()
    assert obj == []

# Generated at 2022-06-21 14:34:46.143552
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert isinstance(PluginManager(), PluginManager)


# Generated at 2022-06-21 14:34:50.566832
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    assert pm.register([1, 2, 3]) == [1, 2, 3]
    assert pm.unregister(2) == [1, 3]


# Generated at 2022-06-21 14:34:59.563427
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import (
        AuthPlugin, FormatterPlugin, TransportPlugin, ConverterPlugin
    )
    plugin_manager = PluginManager()
    plugin_manager.append(AuthPlugin())
    plugin_manager.append(TransportPlugin())
    plugin_manager.append(ConverterPlugin())
    plugin_manager.append(FormatterPlugin())
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]


# Generated at 2022-06-21 14:35:00.696756
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():

    pm = PluginManager()
    assert len(pm.get_formatters()) >= 5

# Generated at 2022-06-21 14:35:04.831239
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    mapping = plugin_manager.get_auth_plugin_mapping()
    for plugin in mapping.values():
        auth_type = plugin.auth_type
        assert auth_type in mapping
        assert mapping[auth_type] == plugin

import unittest


# Generated at 2022-06-21 14:35:15.694197
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPieHTTPAdapter, JSONAdapter
    from httpie.plugins.formatter.json import JSONFormatter
    from httpie.plugins.auth.httpie import HTTPieAuthPlugin
    from httpie.output.streams import RAW_RESPONSE_STREAM, RESPIECE_STREAM
    # Assume, the registered plugins will not change anymore.
    import httpie
    entry_points = {
        'httpie.plugins.auth.v1': [HTTPBasicAuth, HTTPieAuthPlugin],
        'httpie.plugins.transport.v1': [HTTPieHTTPAdapter],
        'httpie.plugins.formatter.v1': [JSONFormatter],
        'httpie.plugins.converter.v1': [JSONAdapter],
    }

# Generated at 2022-06-21 14:35:25.351055
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import TransportPlugin
    #httpie/plugins/builtin.py
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPHeaders
    #httpie/plugins/__init__.py
    from httpie.plugins import HTTPiePlugin
    pluginmanager = PluginManager()
    pluginmanager.register(TransportPlugin, HTTPiePlugin, HTTPBasicAuth, HTTPHeaders)
    print("\n" * 3, "*" * 10, "test_PluginManager_get_transport_plugins()", "*" * 10)
    #print(pluginmanager.get_transport_plugins())
    print("-"*50)
    print(pluginmanager)
    print("-"*50)
    print(pluginmanager.get_transport_plugins())
    print("-"*50)

# Generated at 2022-06-21 14:35:28.263624
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    class FakePlugin(object):
        def __init__(self):
            self.package_name = None
    p1 = FakePlugin()
    p2 = FakePlugin()
    manager.register(p1, p2)
    assert len(manager) == 2
#     manager.unregister(p1)
    assert len(manager) == 1

# Generated at 2022-06-21 14:35:32.192362
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuthPlugin

    pm = PluginManager()
    pm.register(BasicAuthPlugin)
    assert pm.get_auth_plugin_mapping() == {'basic': BasicAuthPlugin}

# Generated at 2022-06-21 14:35:34.318952
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    assert len(plugins.get_converters()) > 0
    

# Generated at 2022-06-21 14:35:40.392765
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.converter import JSONConverter
    from httpie.plugins.converter import URLEncodedConverter
    _plugins = PluginManager()
    _plugins.register(JSONConverter, URLEncodedConverter)
    assert _plugins.get_converters() == [JSONConverter, URLEncodedConverter]



# Generated at 2022-06-21 14:35:43.421018
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    t_plugin_manager = PluginManager()

    print(t_plugin_manager.get_formatters())

if __name__ == "__main__":
    test_PluginManager_get_formatters()

# Generated at 2022-06-21 14:35:54.004735
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager, PluginManager)

# Generated at 2022-06-21 14:36:03.481871
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class A(FormatterPlugin):
        group_name = 'group1'

    class B(FormatterPlugin):
        group_name = 'group1'

    class C(FormatterPlugin):
        group_name = 'group2'

    class D(FormatterPlugin):
        group_name = 'group2'

    plugin_manager = PluginManager()
    plugin_manager.register(A, B, C, D)
    formatters = plugin_manager.get_formatters_grouped()
    assert formatters['group1'] == [A, B]
    assert formatters['group2'] == [C, D]


# Generated at 2022-06-21 14:36:06.514489
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert 'httpie.plugins.formatter.prettyjson.PrettyJSONFormatterPlugin' in str(plugins.get_converters())



# Generated at 2022-06-21 14:36:13.264917
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import BasicAuthPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin)
    ref = {'basic': BasicAuthPlugin}
    assert plugin_manager.get_auth_plugin_mapping() == ref


# Generated at 2022-06-21 14:36:15.617238
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert str(pm) == '<PluginManager: [<class \'httpie.plugins.auth.AuthPlugin\'>]>'

# Generated at 2022-06-21 14:36:17.505969
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    p = PluginManager()
    assert len(p.get_auth_plugins()) == 0
    p.register(AuthPlugin)
    assert len(p.get_auth_plugins()) == 1
    p.unregister(AuthPlugin)
    assert len(p.get_auth_plugins()) == 0

# Generated at 2022-06-21 14:36:26.779750
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([1, 2, 3])) == '<PluginManager: [<class \'int\'>, <class \'int\'>, <class \'int\'>]>'
    assert repr(PluginManager(['1', '2', '3'])) == '<PluginManager: [<class \'str\'>, <class \'str\'>, <class \'str\'>]>'
    assert repr(PluginManager(['httpie.plugins.auth.v1', 'httpie.plugins.formatter.v1'])) == '<PluginManager: [<class \'str\'>, <class \'str\'>]>'

# Generated at 2022-06-21 14:36:31.279600
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    plugins.unregister(AuthPlugin)
    assert plugins.filter(AuthPlugin) == []
    assert plugins.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugins.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugins.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-21 14:36:37.708035
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.transport.http import HTTPTransportPlugin
    from httpie.plugins.transport.httpie import HTTPieTransportPlugin

    m = PluginManager()
    m.register(HTTPieTransportPlugin, HTTPTransportPlugin)

    assert HTTPieTransportPlugin in m.get_transport_plugins()
    assert HTTPTransportPlugin in m.get_transport_plugins()
    assert len(m.get_transport_plugins()) == 2

# Generated at 2022-06-21 14:36:39.365030
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    pm.register(PluginManager)
    assert PluginManager in pm


# Generated at 2022-06-21 14:36:40.950178
# Unit test for constructor of class PluginManager
def test_PluginManager():
    # Assert init is correct
    plugins = PluginManager()
    assert(plugins == [])



# Generated at 2022-06-21 14:36:51.864763
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie import __version__ as httpie_version
    from httpie.plugins.formatter.colors import ColorsFormatter
    from httpie.plugins.formatter.colors import __version__ as colors_version
    from httpie.plugins.formatter.format import FormattedFormatter
    from httpie.plugins.formatter.format import __version__ as format_version
    from httpie.plugins.formatter.json import JSONFormatter
    from httpie.plugins.formatter.json import __version__ as json_version
    from httpie.plugins.formatter.json import __version__ as json_version
    from httpie.plugins.formatter.json import __version__ as json_version

    PluginManager = PluginManager()
    PluginManager.register(ColorsFormatter, FormattedFormatter, JSONFormatter)


# Generated at 2022-06-21 14:36:55.733444
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    class Plugin(BasePlugin):
        pass
    plugin_manager.register(Plugin)
    assert len(plugin_manager) == 0


# Generated at 2022-06-21 14:37:05.514793
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    a = TransportPlugin()
    b = TransportPlugin()
    c = TransportPlugin()
    d = TransportPlugin()
    e = TransportPlugin()
    f = TransportPlugin()

    m = PluginManager().register(a, b, c, d, e, f)
    assert m.get_transport_plugins() == [a, b, c, d, e ,f]

# Generated at 2022-06-21 14:37:07.372195
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_converters()) == 0

# Generated at 2022-06-21 14:37:10.375849
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert manager.get_auth_plugin(auth_type = 'test') == AuthPlugin
test_PluginManager_get_auth_plugin()


# Generated at 2022-06-21 14:37:12.235132
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.append(BasePlugin)
    assert BasePlugin in manager
    manager.unregister(BasePlugin)
    assert BasePlugin not in manager

# Generated at 2022-06-21 14:37:17.112288
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    assert p == []
    p.register(BasePlugin)
    assert p == [BasePlugin]
    p.register(AuthPlugin)
    assert p == [BasePlugin, AuthPlugin]
    p.register(FormatterPlugin)
    assert p == [BasePlugin, AuthPlugin, FormatterPlugin]
    p.register(ConverterPlugin)
    assert p == [BasePlugin, AuthPlugin, FormatterPlugin, ConverterPlugin]
    p.register(TransportPlugin)
    assert p == [BasePlugin, AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]


# Generated at 2022-06-21 14:37:19.588598
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_converters()) == 2

# Generated at 2022-06-21 14:37:23.010436
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA:
        pass

    class PluginB:
        pass

    pm = PluginManager()
    pm.register(PluginA)
    pm.register(PluginB)
    result = pm.filter(PluginA)
    assert len(result) == 1


# Generated at 2022-06-21 14:37:30.098245
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class T:
        pass
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    T.__bases__=[A]
    a=[]
    a.append(T)
    a.append(B)
    a.append(C)
    b=PluginManager()
    b.register(T,B,C)
    assert a==b.filter(A)
    assert [C]==b.filter(C)

# Generated at 2022-06-21 14:37:33.948392
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager.get_converters())

if __name__ == '__main__':
    test_PluginManager_get_converters()

# Generated at 2022-06-21 14:37:37.473889
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(1)
    plugin_manager.register(2)
    plugin_manager.register(3)
    plugin_manager.unregister(2)
    assert plugin_manager == [1,3]



# Generated at 2022-06-21 14:37:51.096083
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import builtin
    from httpie.plugins.colors import ColorsPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(ColorsPlugin)
    plugin_manager.register(builtin.PrettyJsonPlugin)
    plugin_manager.register(builtin.PrettyJsonPlugin)

    assert len(plugin_manager.get_formatters()) == 3
    assert len(plugin_manager) == 3

# Generated at 2022-06-21 14:37:52.173352
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    #print(pm)

# Generated at 2022-06-21 14:37:56.733635
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # Create object of PluginManager
    plugin_manager = PluginManager()

    # Add multiple plugins
    plugin_manager.register(Plugin1, Plugin2)

    # Verify the results
    assert(plugin_manager.__repr__() == '<PluginManager: [Plugin1, Plugin2]>')


# Generated at 2022-06-21 14:38:05.731129
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert not pm
    PluginManager.register(pm, AuthPlugin)
    assert pm[0] == AuthPlugin
    pm = PluginManager()
    assert not pm
    PluginManager.register(pm, FormatterPlugin)
    assert pm[0] == FormatterPlugin
    pm = PluginManager()
    assert not pm
    PluginManager.register(pm, ConverterPlugin)
    assert pm[0] == ConverterPlugin
    pm = PluginManager()
    assert not pm
    PluginManager.register(pm, TransportPlugin)
    assert pm[0] == TransportPlugin


# Generated at 2022-06-21 14:38:10.884469
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    p = PluginManager()
    assert p.get_formatters_grouped() == {}

    p.register(PythonPygmentsFormatter, BashSessionFormatter)

    d = p.get_formatters_grouped()
    assert d['code'] == [PythonPygmentsFormatter]
    assert d['shell-session'] == [BashSessionFormatter]

# Generated at 2022-06-21 14:38:16.126288
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(HttpbinAuthPlugin, KintoAuthPlugin, ClientAuthPlugin, FormatterPlugin, JsonPointerConverterPlugin,
                     Oauth2ConverterPlugin, UrlencodedConverterPlugin, UrlencodedConverterPlugin)
    result = plugins.unregister(KintoAuthPlugin)
    assert result == 'PASSED'


# Generated at 2022-06-21 14:38:21.206992
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import JSONFileUploadPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFileUploadPlugin)

    assert len(plugin_manager.filter()) == 1
    assert len(plugin_manager.filter(ConverterPlugin)) == 1

    assert len(plugin_manager.filter(AuthPlugin)) == 0
    assert len(plugin_manager.filter(TransportPlugin)) == 0

# Generated at 2022-06-21 14:38:24.225440
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    converters = plugin_manager.get_converters()

    result = []
    for converter in converters:
        result.append(converter.name)

    assert ['json', 'xml', 'yaml'] == result

# Generated at 2022-06-21 14:38:28.489897
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    formatters = pluginManager.get_formatters()
    assert formatters == [httpie.plugins.formatter.JSONFormatter, httpie.plugins.formatter.URLEncodedFormatter, httpie.plugins.formatter.TableFormatter]

# Generated at 2022-06-21 14:38:36.330228
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print("\nAll plugins:")
    print(plugins)

    print("\nFormatter plugins grouped:")
    for k, v in plugins.get_formatters_grouped().items():
        print(f'{k} ({len(v)}): {v}')

    # Verify
    assert any([p.group_name == 'Syntax highlighting' for p in plugins])


if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-21 14:38:55.787632
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.register(PluginManager)
    assert plugins.get_auth_plugin('basic') == PluginManager


plugin_manager = PluginManager()

# Generated at 2022-06-21 14:38:57.047312
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == []


# Generated at 2022-06-21 14:39:01.083298
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    authplugins = pm.get_auth_plugins()
    if authplugins == []:
        print('There is not any auth plugins in the httpie.')
    else:
        for plugin in authplugins:
            print(plugin)


# Generated at 2022-06-21 14:39:06.188210
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth
    expected_result = True
    # create a new instance of class PluginManager
    plugin_manager = PluginManager()
    # register plugins
    plugin_manager.register(HTTPBasicAuth)
    # get plugins about authentication
    actual_result = HTTPBasicAuth in plugin_manager.get_auth_plugins()
    assert actual_result == expected_result

# Test for method get_auth_plugin_mapping of class PluginManager

# Generated at 2022-06-21 14:39:13.505371
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.compat import urllib3
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPiePlugin, HTTPieStream
    from httpie.plugins import builtin

    manager = PluginManager()

    assert manager.get_transport_plugins() == []

    manager.register(HTTPBasicAuth, HTTPiePlugin, HTTPieStream)
    assert manager.get_transport_plugins() == [HTTPBasicAuth]



# Generated at 2022-06-21 14:39:17.015145
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    class A:
        pass
    class B(A):
        pass
    pm.register(A,B)
    assert pm.filter(A) == [A,B]

# Generated at 2022-06-21 14:39:21.733738
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import http
    from httpie.plugins import socket

    pm = PluginManager()
    pm.register(http.HTTPieRequestPlugin, socket.SocketRequestPlugin)
    pm.register(http.HTTPieRequestPlugin, socket.SocketRequestPlugin)
    pm.register(http.HTTPieRequestPlugin, socket.SocketRequestPlugin)
    appropriate_transport_plugins = pm.get_transport_plugins()
    assert(len(appropriate_transport_plugins) == 2)



# Generated at 2022-06-21 14:39:24.877803
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    test_plugin = BasePlugin()
    pm.register(test_plugin)
    assert pm == [test_plugin]
    pm.unregister(test_plugin)
    assert pm == []

# Generated at 2022-06-21 14:39:33.450322
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.auth import BasicAuthPlugin, DigestAuthPlugin
    from httpie.plugins.auth import OAuth1Plugin, OAuth2Plugin
    from httpie.plugins.auth import HawkAuthPlugin
    from httpie.plugins.auth import AwsSigv4AuthPlugin
    from httpie.plugins.auth import PxAuthPlugin
    from httpie.plugins.auth import NtlmAuthPlugin, WsseAuthPlugin
    from httpie.plugins.auth import JWTAuthPlugin
    from httpie.plugins.auth import BearerAuthPlugin
    from httpie.plugins.auth import ApiKeyAuthPlugin


# Generated at 2022-06-21 14:39:34.148535
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    PluginManager.get_auth_plugin



# Generated at 2022-06-21 14:40:17.757575
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginManager = PluginManager()
    pluginManager.register(OAuth1AuthPlugin, OAuth2AuthPlugin)
    assert pluginManager.get_auth_plugins() == [OAuth1AuthPlugin, OAuth2AuthPlugin]
    assert pluginManager.get_auth_plugin_mapping() == {'oauth1': OAuth1AuthPlugin, 'oauth2': OAuth2AuthPlugin}
    assert pluginManager.get_auth_plugin('oauth1') == OAuth1AuthPlugin
    pluginManager.unregister(OAuth1AuthPlugin)
    assert pluginManager.get_auth_plugins() == [OAuth2AuthPlugin]
    assert pluginManager.get_auth_plugin_mapping() == {'oauth2': OAuth2AuthPlugin}
    pluginManager.register(OAuth1AuthPlugin)
    assert pluginManager.get_auth_plugins

# Generated at 2022-06-21 14:40:19.432236
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_transport_plugins()) == 1

# Generated at 2022-06-21 14:40:25.015749
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin1 = TransportPlugin()
    plugin2 = TransportPlugin()
    plugin_manager = PluginManager()
    plugin_manager.register(plugin1)
    plugin_manager.register(plugin2)
    plugin_manager.unregister(plugin1)
    assert len(plugin_manager) == 1
    assert plugin_manager[0] == plugin2


# Generated at 2022-06-21 14:40:28.600651
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'
    plugins.register(auth_jwt.JWTAuthPlugin)
    assert repr(plugins) == '<PluginManager: [auth_jwt.JWTAuthPlugin]>'

# Generated at 2022-06-21 14:40:32.576590
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager([int])) == '<PluginManager: [<class \'int\'>]>'
    assert repr(PluginManager([1, 2, 3])) == '<PluginManager: [1, 2, 3]>'
    assert repr(PluginManager()) == '<PluginManager: []>'


# Generated at 2022-06-21 14:40:35.539147
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.__repr__() == '<PluginManager: [<class HttpiePlugin>, <class AsyncHttpPlugin>, <class CurlPlugin>, <class PyCurlPlugin>]>'


# Generated at 2022-06-21 14:40:37.678045
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p1=PluginManager()
    p2=PluginManager()
    p2.register(BasePlugin)
    assert p1!=p2


# Generated at 2022-06-21 14:40:40.896533
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    list_plugins = [1, 2]
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2)
    plugin_manager.unregister(Plugin1)
    plugin_manager.filter(BasePlugin) == plugin_manager
    pass

# Generated at 2022-06-21 14:40:47.104664
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB, PluginC)
    assert plugin_manager.filter(BasePlugin) == [PluginA, PluginB, PluginC]
    assert plugin_manager.filter(PluginA) == [PluginA, PluginC]
    assert plugin_manager.filter(PluginB) == [PluginB]
    assert plugin_manager.filter(PluginC) == [PluginC]

# Generated at 2022-06-21 14:40:48.394430
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm.get_auth_plugins == []

# Generated at 2022-06-21 14:42:12.924166
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    assert isinstance(pm, list)
    assert isinstance(pm, PluginManager)
    # TODO implement test

# Generated at 2022-06-21 14:42:15.973061
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
	def fake_class(): pass
	plugins = PluginManager()
	plugins.register(fake_class)
	assert(plugins.get_auth_plugins() == [])


# Generated at 2022-06-21 14:42:19.621482
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # arrange
    from httpie.auth import BasicAuth
    from .utils import http
    pm = PluginManager()
    pm.get_auth_plugin(BasicAuth) # act
    # assert
    assert pm.get_auth_plugin("basic") == BasicAuth



# Generated at 2022-06-21 14:42:23.324200
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(BasicAuthPlugin, DigestAuthPlugin, HawkAuthPlugin)
    assert pm.get_auth_plugin_mapping() == {
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin,
        'hawk': HawkAuthPlugin,
    }

# Generated at 2022-06-21 14:42:25.060660
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-21 14:42:27.231823
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    assert issubclass(p.filter(TransportPlugin)[0], TransportPlugin)

# Generated at 2022-06-21 14:42:29.280191
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager().get_auth_plugins() == []
    assert PluginManager().get_auth_plugin_mapping() == {}

# Generated at 2022-06-21 14:42:33.699852
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    print('running test for method get_transport_plugins of class PluginManager')

    pm = PluginManager()
    pm.load_installed_plugins()

    assert len(pm.get_transport_plugins()) == 7


# Generated at 2022-06-21 14:42:35.511894
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin("auth") == AuthPlugin



# Generated at 2022-06-21 14:42:36.693410
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins_ = PluginManager()
    assert plugins_ == []
