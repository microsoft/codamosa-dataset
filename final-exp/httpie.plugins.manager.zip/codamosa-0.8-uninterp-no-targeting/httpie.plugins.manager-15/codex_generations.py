

# Generated at 2022-06-21 14:34:25.177957
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-21 14:34:28.624233
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert plugin_manager.get_auth_plugin('basic') == BasicAuthPlugin

# Generated at 2022-06-21 14:34:34.891495
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    import httpie.plugins.converter
    manager = PluginManager()
    manager.register(httpie.plugins.converter.PrettyJsonV1)
    manager.register(httpie.plugins.converter.JsonV1)
    assert len(manager.get_converters()) == 2
    assert manager.get_converters()[0] == httpie.plugins.converter.JsonV1
    assert manager.get_converters()[1] == httpie.plugins.converter.PrettyJsonV1


# Generated at 2022-06-21 14:34:36.716884
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    assert(pm.get_converters() == [])

# Generated at 2022-06-21 14:34:45.914126
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.compat import is_windows

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    plugins = plugin_manager.get_transport_plugins()

    if is_windows:
        expected_plugin_classes = [
            'httpie.plugins.transport.httpie.LocalhostProxyTransportPlugin',
            'httpie.plugins.transport.httpie.LocalhostSocks5TransportPlugin',
            'httpie.plugins.transport.httpie.WindowsTunnelProxyTransportPlugin',
        ]

# Generated at 2022-06-21 14:34:58.117352
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import transport
    from httpie.downloads import Downloader
    from httpie.utils import platform

    pm = PluginManager()
    pm.register(transport.curl.CurlHTTPTransport)
    pm.register(transport.urllib2.Urllib2HTTPTransport)
    pm.register(transport.httpcore.HTTPTransport)
    pm.register(transport.async_http.AsyncHTTPTransport)
    pm.register(Downloader)
    if platform.is_appveyor():
        pm.register(transport.appveyor.AppVeyorCurlHTTPTransport)
    else:
        pm.register(transport.httpie.HTTPieHTTPTransport)
    assert len(pm.get_transport_plugins()) == 8

# Generated at 2022-06-21 14:34:59.080003
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()


# Generated at 2022-06-21 14:35:03.341834
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.builtin import HTTPBasicAuth, DigestAuth
    pm = PluginManager()
    pm.register(HTTPBasicAuth, DigestAuth)
    assert pm.get_auth_plugin_mapping() == {'basic': HTTPBasicAuth, 'digest': DigestAuth }

# Generated at 2022-06-21 14:35:04.631428
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager.get_formatters_grouped()


# Generated at 2022-06-21 14:35:11.281058
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import AuthPlugin
    from httpie.plugin import PluginManager
    
    class AuthPluginMock(AuthPlugin):
        auth_type = 'auth_plugin_mock'
    
    plugins = PluginManager()
    plugins.register(AuthPluginMock)
    plugins.get_auth_plugins() == [AuthPluginMock]

# Generated at 2022-06-21 14:35:18.329516
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pass
    # plugins = PluginManager()
    # # plugins.load_installed_plugins()
    # conversions = plugins.get_converters()
    # print(conversions)
    # for convert in conversions:
    #     print(convert)
    # pass



# Generated at 2022-06-21 14:35:20.881684
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(TestFormatterPluginA, TestFormatterPluginB)
    print(pm.get_formatters_grouped())


# Generated at 2022-06-21 14:35:23.138459
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    actual = PluginManager().get_transport_plugins()

    assert actual
    assert not isinstance(actual, PluginManager)
    assert isinstance(actual, list)

# Generated at 2022-06-21 14:35:26.004701
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_converters()
    assert len(plugins) == 3
    for plugin in plugins:
        assert isinstance(plugin, ConverterPlugin)


# Generated at 2022-06-21 14:35:37.889260
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HttpiePlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import BasicAuth
    from httpie.plugins.builtin import DigestAuth
    from httpie.plugins.builtin import TokenAuth
    from httpie.plugins.builtin import OAuth1Auth
    from httpie.plugins.builtin import OAuth2Auth
    from httpie.plugins.builtin import ChunkedTransferEncoding
    from httpie.plugins.builtin import HTTPCookie
    from httpie.plugins.builtin import HTTPFollowRedirects
    from httpie.plugins.builtin import HTTPConnectionPool

# Generated at 2022-06-21 14:35:41.224832
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.prepare()
    manager.load_installed_plugins()
    manager.get_transport_plugins()

# Generated at 2022-06-21 14:35:46.286485
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # Test
    global_plugin_manager = PluginManager()
    global_plugin_manager.register(AuthPlugin, FormatterPlugin)
    assert repr(global_plugin_manager) == '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>, <class \'httpie.plugins.base.FormatterPlugin\'>]>'


# Generated at 2022-06-21 14:35:51.340268
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    class A:
        pass
    class B:
        pass
    class C:
        pass
    manager.register(A, B, C)
    assert manager.pop() == C
    assert manager.pop() == B
    assert manager.pop() == A


# Generated at 2022-06-21 14:35:55.991892
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins = plugin_manager.get_auth_plugins()
    assert 'digest' in auth_plugins
    auth_plugin = plugin_manager.get_auth_plugin('basic')
    assert auth_plugin == auth_plugins[0]


# Generated at 2022-06-21 14:36:06.946041
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class TypePlugin(object):
        pass

    class BasePlugin1(object):
        pass

    class BasePlugin2(object):
        pass

    class SubBasePlugin1(BasePlugin1):
        pass

    class SubBasePlugin2(BasePlugin2):
        pass

    class TypePlugin1(BasePlugin1, TypePlugin):
        pass

    class TypePlugin2(BasePlugin2, TypePlugin):
        pass

    class TypePlugin3(TypePlugin):
        pass

    assert list(PluginManager([
        BasePlugin1(),
        BasePlugin2(),
        SubBasePlugin1(),
        SubBasePlugin2(),
        TypePlugin1(),
        TypePlugin2(),
        TypePlugin3(),
    ]).filter(TypePlugin)) == [
        TypePlugin1(),
        TypePlugin2(),
        TypePlugin3(),
    ]


plugin_

# Generated at 2022-06-21 14:36:11.174534
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    PluginManager = PluginManager()
    assert isinstance(PluginManager.get_transport_plugins(), list)

# Generated at 2022-06-21 14:36:14.481513
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    pm.register(AuthPlugin, TransportPlugin, FormatterPlugin)
    assert len(pm) == 3
    pm.unregister(AuthPlugin)
    assert len(pm) == 2


# Generated at 2022-06-21 14:36:16.077797
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    mgr = PluginManager()
    assert mgr.get_formatters_grouped() == dict()


# Generated at 2022-06-21 14:36:20.425802
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.get_converters()) == 2


# Generated at 2022-06-21 14:36:27.109333
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class PluginA(BasePlugin):
        name = 'A'
    class PluginB(BasePlugin):
        name = 'B'
    manager = PluginManager()
    manager.register(PluginA, PluginB)
    assert manager == [PluginA, PluginB]
    manager.unregister(PluginA)
    assert manager == [PluginB]
    manager.unregister(PluginB)
    assert manager == []


# Generated at 2022-06-21 14:36:29.391042
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    from httpie.plugins import HTTPBasicAuth
    p.register(HTTPBasicAuth)
    assert len(p) == 1



# Generated at 2022-06-21 14:36:30.597714
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    r = PluginManager.__repr__()
    assert r[0:9] == '<PluginMa'

# Generated at 2022-06-21 14:36:36.418381
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugins = register_plugins()
    plugin_manager.register(*plugins)
    plugin_manager.get_auth_plugin("basic")
    plugin_manager.get_auth_plugin("digest")
    assert plugin_manager.get_auth_plugin("digest") == plugins[0]
    assert plugin_manager.get_auth_plugin("basic") == plugins[1]



# Generated at 2022-06-21 14:36:39.960213
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginmanager = PluginManager()
    pluginmanager.register(*ENTRY_POINT_NAMES)
    pluginmanager.unregister(pluginmanager[0])
    assert pluginmanager[0] != ENTRY_POINT_NAMES[0]

# Generated at 2022-06-21 14:36:44.795300
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Create a plugin manager
    plugin_manager = PluginManager()
    # Add 2 plugins to a group
    plugin_manager.register(MockFormatterPlugin_1, MockFormatterPlugin_2, MockFormatterPlugin_3)

    # An assertion to check the results
    assert plugin_manager.get_formatters_grouped() == {'group_name': [MockFormatterPlugin_1, MockFormatterPlugin_2]}

# A class for creating mock plugins

# Generated at 2022-06-21 14:36:57.361375
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import builtin
    from httpie.downloads import LocalFileAdapter
    from httpie.downloads import Downloader
    from httpie.downloads import BufferedDownloader

    plugins = PluginManager()
    plugins.register(LocalFileAdapter, Downloader, BufferedDownloader)
    # Unit test for method get_transport_plugins
    assert plugins.get_transport_plugins() == [LocalFileAdapter, Downloader, BufferedDownloader]


# Generated at 2022-06-21 14:36:58.730403
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_auth_plugins()
    assert plugins is not None

# Generated at 2022-06-21 14:37:06.159895
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    try:
        from httpie.plugins.auth.basic import BasicAuthPlugin
        from httpie.plugins.auth.digest import DigestAuthPlugin
    except ImportError:
        print("[Notice]: test_PluginManager_get_auth_plugins ignored because basic or digest auth isn't available.")
        return
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugins()) == 2
    assert BasicAuthPlugin in pm.get_auth_plugins()
    assert DigestAuthPlugin in pm.get_auth_plugins()


# Generated at 2022-06-21 14:37:09.753266
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(type('TestAuthPlugin', (AuthPlugin,), {'auth_type': 'test'}))
    assert 'test' in pm.get_auth_plugin_mapping()


# Generated at 2022-06-21 14:37:14.644995
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}
    class AP(AuthPlugin):
        auth_type = 'AP'
    class BP(AuthPlugin):
        auth_type = 'BP'
    class CP(AuthPlugin):
        auth_type = 'CP'
    pm = PluginManager()
    pm.register(AP,BP,CP)
    assert pm.get_auth_plugin_mapping() == {'AP': AP, 'BP': BP, 'CP': CP}

# Generated at 2022-06-21 14:37:15.639019
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager().get_transport_plugins() == []

# Generated at 2022-06-21 14:37:20.882835
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin = PluginManager()
    auth_plugin_mapping = {
        'basic': 'httpie_digest_auth',
        'digest': 'httpie_digest_auth'
    }
    auth_type = 'digest'
    assert plugin.get_auth_plugin(auth_type) is auth_plugin_mapping[auth_type]

# Generated at 2022-06-21 14:37:25.576236
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.append(TransportPlugin)
    manager.append(TransportPlugin)
    manager.append(AuthPlugin)
    assert manager.get_transport_plugins() == [TransportPlugin, TransportPlugin]


# Generated at 2022-06-21 14:37:27.255929
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert len(get_PluginManager().get_formatters()) == 2


# Generated at 2022-06-21 14:37:28.993933
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginManager = PluginManager()
    assert (pluginManager.get_formatters() == [])


# Generated at 2022-06-21 14:37:40.573457
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    import pytest
    pm = PluginManager()
    pm.register(1,2,3,4,5)
    assert len(pm) == 5
    pm.unregister(3)
    assert len(pm) == 4
    with pytest.raises(ValueError):
        pm.unregister(10)



# Generated at 2022-06-21 14:37:43.207312
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    assert len(plugins.get_auth_plugins()) == 0



# Generated at 2022-06-21 14:37:46.681161
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert issubclass(pm[0], BasePlugin)


# Generated at 2022-06-21 14:37:47.648967
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.unregister(plugin_manager)
    assert len(plugin_manager) == 0



# Generated at 2022-06-21 14:37:54.957234
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter.json import JsonConverter
    from httpie.plugins.converter.keyvalue import KeyValueConverter
    class PluginManager_test(PluginManager):
        def __init__(self):
            self.register(JsonConverter, KeyValueConverter)
    pluginmanager = PluginManager_test()
    converters = pluginmanager.get_converters()
    assert len(converters) == 2
    assert converters[0] == JsonConverter
    assert converters[1] == KeyValueConverter



# Generated at 2022-06-21 14:38:06.421623
# Unit test for method __repr__ of class PluginManager

# Generated at 2022-06-21 14:38:10.400822
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    p1 = PluginManager()
    p1.register(ConverterPlugin, FormatterPlugin)
    assert len(p1) == 2
    p1.unregister(ConverterPlugin)
    assert len(p1) == 1


# Generated at 2022-06-21 14:38:12.350391
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert PluginManager.__repr__(PluginManager()) == '<PluginManager: []>'



# Generated at 2022-06-21 14:38:14.789737
# Unit test for constructor of class PluginManager
def test_PluginManager():
    # Init
    PluginManager().load_installed_plugins()
    # Throws Error because exception is not implemented
    # Test
    assert True

# Generated at 2022-06-21 14:38:18.424774
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # call method get_transport_plugins of class PluginManager
    PluginManager.get_transport_plugins()

    # call method get_transport_plugins of class PluginManager in several times
    for i in range(10):
        PluginManager.get_transport_plugins()

# Generated at 2022-06-21 14:38:39.605108
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.append("a")
    plugins.append("b")
    plugins.unregister("a")
    assert plugins == ["b"]
    assert plugins != ["a"]
    assert plugins != ["a", "b"]
    assert plugins != []


# Generated at 2022-06-21 14:38:47.411330
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Formatter1(FormatterPlugin):
        group_name = 'group1'
        order = 1

    class Formatter2(FormatterPlugin):
        group_name = 'group1'
        order = 2

    class Formatter3(FormatterPlugin):
        group_name = 'group2'
        order = 1

    class Formatter4(FormatterPlugin):
        group_name = 'group2'
        order = 2

    class Formatter5(FormatterPlugin):
        group_name = 'group2'
        order = 3

    pm = PluginManager()
    pm.register(Formatter1, Formatter2, Formatter3, Formatter4, Formatter5)
    groups = pm.get_formatters_grouped()

# Generated at 2022-06-21 14:38:49.700563
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert isinstance(PluginManager().get_converters(),list)

# Generated at 2022-06-21 14:38:53.944886
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    manager.register(TestPluginA, TestPluginB)
    f = manager.get_formatters()
    assert(len(f) == 2)
    assert(f[0] == TestPluginA)
    assert(f[1] == TestPluginB)


# Generated at 2022-06-21 14:38:56.012180
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    assert 0 == manager.load_installed_plugins()


# Generated at 2022-06-21 14:38:59.321192
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import converter
    from httpie.plugins.manager import PluginManager
    pm = PluginManager()
    pm.register(converter.JSONToFormDataConverter, converter.JSONConverter, converter.JSONToXMLConverter)
    pm.append(converter.JSONToFormDataConverter)
    assert pm.get_converters() == list([converter.JSONConverter, converter.JSONToFormDataConverter, converter.JSONToXMLConverter, converter.JSONToFormDataConverter])

# Generated at 2022-06-21 14:39:00.671365
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm


# Generated at 2022-06-21 14:39:05.070859
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    assert plugins == []
    plugins.register(HTTPBasicAuth)
    assert plugins == [HTTPBasicAuth]
    plugins.register(HTTPDigestAuth)
    assert plugins == [HTTPBasicAuth, HTTPDigestAuth]
    plugins.unregister(HTTPBasicAuth)
    assert plugins == [HTTPDigestAuth]



# Generated at 2022-06-21 14:39:09.987800
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.auth import BasicAuthPlugin, DigestAuthPlugin
    pm = PluginManager()
    pm.register(BasicAuthPlugin, DigestAuthPlugin)
    assert pm.get_auth_plugins() == [BasicAuthPlugin, DigestAuthPlugin]



# Generated at 2022-06-21 14:39:12.584859
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins=PluginManager()
    assert(type(plugins.get_auth_plugin_mapping()) == dict)


# Generated at 2022-06-21 14:39:58.361983
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_plugin_manager = PluginManager()
    test_plugin_manager.load_installed_plugins()
    assert type(test_plugin_manager.get_auth_plugin_mapping()) == dict

# Generated at 2022-06-21 14:40:01.638829
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pluginManager = PluginManager()
    pluginManager.register(BearerAuthPlugin, BasicAuthPlugin())
    assert pluginManager.get_auth_plugin('basic') == BasicAuthPlugin
    assert pluginManager.get_auth_plugin('bearer') == BearerAuthPlugin



# Generated at 2022-06-21 14:40:07.989403
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():

    # Prepare data
    httpie.plugins.manager.register(httpie.plugins.builtin.auth.BasicAuth)
    httpie.plugins.manager.register(httpie.plugins.builtin.auth.DigestAuth)
    httpie.plugins.manager.register(
    httpie.plugins.builtin.auth.HawkAuth)
    httpie.plugins.manager.register(httpie.plugins.builtin.auth.BearerTokenAuth)
    httpie.plugins.manager.register(httpie.plugins.builtin.auth.AuthPlugin)
    httpie.plugins.manager.register(httpie.plugins.builtin.auth.AuthPluginV1)

    # Excute and verify

# Generated at 2022-06-21 14:40:14.338629
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    assert (plugin_manager.filter(BasePlugin) == [BasePlugin, AuthPlugin, FormatterPlugin])
    assert (plugin_manager.filter(AuthPlugin) == [AuthPlugin])
    assert (plugin_manager.filter(FormatterPlugin) == [FormatterPlugin])


# Generated at 2022-06-21 14:40:24.629256
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    # Expected values:
    # Expect 'Basic' authentication, since there are two plugins that are eligble to be installed, 
    # and Basic is the first one in the list
    auth_type = 'Basic' 
    # Expect 'json' formatter, since there are two plugins that are eligble to be installed, 
    # and json is the first one in the list
    formatter = 'json'
    # Expect one plugin
    transports = 1

    # Test if expected values match actual values
    assert auth_type in pm.get_auth_plugin_mapping()
    assert formatter in pm.get_formatters_grouped().keys()
    assert len(pm.get_transport_plugins()) == transports

# Generated at 2022-06-21 14:40:28.480125
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # Assert get_formatters method is not empty
    assert plugin_manager.get_formatters()
    # Assert return type of get_formatters method is List
    assert isinstance(plugin_manager.get_formatters(), list)

# Generated at 2022-06-21 14:40:31.815480
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert len(pm) == 0
    pm.register(1, 2, 3)
    assert len(pm) == 3
    assert list(pm) == [1, 2, 3]



# Generated at 2022-06-21 14:40:37.301501
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():

    plugins = PluginManager()

    assert plugins.get_formatters() == []

    plugins.register(PluginManager)

    assert plugins.get_formatters() == []

    class Formatter1(FormatterPlugin):
        pass

    plugins.register(Formatter1)

    assert plugins.get_formatters() == [Formatter1]

    class Formatter2(FormatterPlugin):
        pass

    plugins.register(Formatter2)

    assert plugins.get_formatters() == [Formatter1, Formatter2]


# Generated at 2022-06-21 14:40:39.699412
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert isinstance(plugins.get_formatters(), list)
    assert isinstance(plugins.get_formatters()[0], FormatterPlugin)


# Generated at 2022-06-21 14:40:47.617209
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    # Pre-condition
    assert not pm.get_converters()
    # Add data
    from httpie.converters import JSONConverter
    from httpie.converters import URLEncodedConverter
    from httpie.converters import HTTPieConverter
    pm.register(JSONConverter, URLEncodedConverter, HTTPieConverter)
    # Test
    assert pm.get_converters() == [JSONConverter, URLEncodedConverter, HTTPieConverter]
    # Delete data
    pm.unregister(JSONConverter)
    assert pm.get_converters() == [URLEncodedConverter, HTTPieConverter]


# Generated at 2022-06-21 14:42:36.963628
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert(isinstance(plugin_manager,PluginManager))


# Generated at 2022-06-21 14:42:38.670345
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_transport_plugins()
    assert isinstance(plugins, list)


# Generated at 2022-06-21 14:42:45.969400
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_auth_plugins()
    assert plugins == []
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugins() != []

    global_return_value = ""
    for plugin in plugin_manager.get_auth_plugins():
        global_return_value += str(plugin)

    return_value = ""
    for auth_plugin in iter_entry_points('httpie.plugins.auth.v1'):
        return_value += str(auth_plugin.load())

    assert global_return_value == return_value



# Generated at 2022-06-21 14:42:49.995202
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins.get_converters()) == 2
    assert plugins.get_converters()[0] == plugins.get_converters()[1]
    assert plugins.get_converters()[1] == plugins.get_converters()[0]

# Generated at 2022-06-21 14:42:53.154975
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    assert plugin_manager.filter(BasePlugin) == [BasePlugin]
    plugin_manager.unregister(BasePlugin)
    assert plugin_manager.filter(BasePlugin) == []


# Generated at 2022-06-21 14:42:55.603943
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin1 = PluginManager()
    plugin1.register(AuthPlugin)
    assert plugin1[0] == AuthPlugin
    assert plugin1[0].__name__ == 'AuthPlugin'



# Generated at 2022-06-21 14:42:58.905702
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
	manager = PluginManager()
	manager.load_installed_plugins()
	converters = manager.get_converters()
	assert len(converters) > 0
	for converter in converters:
		assert issubclass(converter, ConverterPlugin)


# Generated at 2022-06-21 14:43:02.516512
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == []
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_converters()) > 0


# Generated at 2022-06-21 14:43:07.147596
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():

    import httpie.plugins.builtin

    from httpie.plugins import builtin
    from httpie.plugins import FormatterPlugin

    fmts = builtin.__file__.replace('__init__.py', '*.py')
    plugin_mgr = PluginManager()
    plugin_mgr.register(*(FormatterPlugin.load_entry_point_plugins(fmts)))

    assert isinstance(plugin_mgr.get_formatters(), list)
    assert len(plugin_mgr.get_formatters()) > 1

# Generated at 2022-06-21 14:43:08.986569
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import builtin
    from httpie.plugins.manager import PluginManager
    PluginManager.register(builtin.BuiltinTransportPlugin())
    PluginManager.get_transport_plugins() == [builtin.BuiltinTransportPlugin]