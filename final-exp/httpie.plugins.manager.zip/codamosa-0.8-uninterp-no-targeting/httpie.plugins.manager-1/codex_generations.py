

# Generated at 2022-06-21 14:34:25.075051
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 10
    for plugin in pm:
        assert issubclass(plugin, BasePlugin)

# Generated at 2022-06-21 14:34:28.478197
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert not len(plugin_manager)
    plugin_manager.register(BasePlugin)
    assert len(plugin_manager)



# Generated at 2022-06-21 14:34:39.469565
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A(object):
        pass
    class B(object):
        pass
    class C(object):
        pass
    class D(A):
        pass
    class E(B):
        pass
    class F(E):
        pass
    pm = PluginManager()
    pm.register(A, B, D, E, F)
    assert(pm.filter() == [A, B, D, E, F])
    assert(pm.filter(A) == [A, D])
    assert(pm.filter(C) == [])
    pm.register(C)
    assert(pm.filter(C) == [C])
    assert(pm.filter(B) == [B, E, F])
    pm.unregister(F)
    assert(pm.filter(B) == [B, E])

# Generated at 2022-06-21 14:34:48.024761
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    """
    class PluginManager(list):
        def unregister(self, plugin: Type[BasePlugin]):
            self.remove(plugin)
    """
    from httpie.plugins import AuthPlugin   # pylint: disable=unused-variable
    from httpie.plugins import FormatterPlugin   # pylint: disable=unused-variable
    from httpie.plugins import ConverterPlugin   # pylint: disable=unused-variable
    from httpie.plugins import TransportPlugin   # pylint: disable=unused-variable

    class TestAuth(AuthPlugin):
        auth_type = 'test'
        description = 'Test'
        lock = False

        def get_auth(self, username=None, password=None):
            return None, None

        def __init__(self):
            pass


# Generated at 2022-06-21 14:34:48.962859
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()



# Generated at 2022-06-21 14:34:53.688057
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'
    plugins.register(BasePlugin)
    assert repr(plugins) == '<PluginManager: [httpie.plugins.base.BasePlugin]>'

# Generated at 2022-06-21 14:35:02.465089
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import sys
    import types
    from httpie.plugins import FormatterPlugin
    PluginManager.register = types.MethodType(lambda self,*plugins:self.append(plugins),PluginManager)
    sys.modules['pkg_resources'] = types.ModuleType('pkg_resources')
    sys.modules['pkg_resources'].iter_entry_points = types.MethodType(lambda self,entry_point_name: iter([types.SimpleNamespace(load=lambda: FormatterPlugin())]),sys.modules['pkg_resources'])
    pluginmanager = PluginManager()
    try:
        pluginmanager.load_installed_plugins()
    except ImportError:
        print("ImportError: 'pkg_resources' is not a package")
    else:
        assert(pluginmanager == [FormatterPlugin])

# Generated at 2022-06-21 14:35:07.565572
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
     
    class MyPlugin(BasePlugin):
        pass
   
    # Create an instance of PluginManager
    plugin_manager = PluginManager()
    
    # Register a plugin
    plugin_manager.register(MyPlugin)
    # Test that the plugin has been registered
    assert MyPlugin in plugin_manager
    
    # Unregister the plugin
    plugin_manager.unregister(MyPlugin)
    # Test that the plugin has been removed
    assert MyPlugin not in plugin_manager

# Generated at 2022-06-21 14:35:10.343190
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.append(TestFormatterPlugin)
    assert pm.get_formatters() == [TestFormatterPlugin]


# Generated at 2022-06-21 14:35:16.908139
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converters.builtin import get_plugin_manager
    pm = get_plugin_manager()
    converters = pm.get_converters()
    assert len(converters) == 2
    assert converters[0].__name__ == 'Json'
    assert converters[1].__name__ == 'Xml'


# Generated at 2022-06-21 14:35:25.769178
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    class TestPlugin(TransportPlugin):
        pass
    class TestPlugin1(TransportPlugin):
        pass
    class TestPlugin2(TransportPlugin):
        pass
    plugin_manager.register(TestPlugin, TestPlugin1, TestPlugin2)
    assert isinstance(plugin_manager.get_transport_plugins(), list)
    assert TestPlugin in plugin_manager.get_transport_plugins()
    assert TestPlugin1 in plugin_manager.get_transport_plugins()
    assert TestPlugin2 in plugin_manager.get_transport_plugins()


# Generated at 2022-06-21 14:35:29.008498
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert isinstance(formatters_grouped, dict)

# Generated at 2022-06-21 14:35:31.678748
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register('test')
    assert plugins == ['test']


# Generated at 2022-06-21 14:35:33.776560
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    p_manager = PluginManager()
    assert p_manager.get_formatters() == []


# Generated at 2022-06-21 14:35:40.285638
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    try:
        pm = PluginManager()
        pm.append(PluginManager())
        pm.append(PluginManager())
        pm.append(PluginManager())
        pm.get_formatters()
    except Exception as e:
        if 'object not iterable' not in str(e):
            raise
        else:
            print('test pass')
            return

    raise 'test failed'


if __name__ == '__main__':
    test_PluginManager_get_formatters()

# Generated at 2022-06-21 14:35:45.208071
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    class DummyPlugin(TransportPlugin):
        scheme = 'dummy'
        name = 'dummy'
        description = 'dummy'
        version = 'dummy'

    manager = PluginManager()
    manager.register(DummyPlugin)
    assert manager.get_transport_plugins() == [DummyPlugin]


# Generated at 2022-06-21 14:35:48.296853
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert PluginManager().get_auth_plugin('basic') == BasicAuthPlugin
    assert PluginManager().get_auth_plugin('digest') == DigestAuthPlugin


# Generated at 2022-06-21 14:35:54.277336
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB, PluginC)
    assert len(plugin_manager) == 3
    plugin_manager.unregister(PluginB)
    assert len(plugin_manager) == 2
    assert PluginA in plugin_manager
    assert PluginB not in plugin_manager
    assert PluginC in plugin_manager



# Generated at 2022-06-21 14:35:59.908462
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(HawkAuthPlugin)
    pm.register(DigestAuthPlugin)
    assert pm.get_auth_plugins() == [HawkAuthPlugin, DigestAuthPlugin]
    pm.unregister(DigestAuthPlugin)
    assert pm.get_auth_plugins() == [HawkAuthPlugin]

# Generated at 2022-06-21 14:36:02.508543
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert plugin_manager == []
    plugin_manager.register(BasePlugin)
    assert plugin_manager == [BasePlugin]



# Generated at 2022-06-21 14:36:10.438763
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    converters = plugins.get_converters()
    assert len(converters) == 1

# Generated at 2022-06-21 14:36:13.087510
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_transport_plugins()) == 0



# Generated at 2022-06-21 14:36:19.011678
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2, Plugin3)

    assert plugin_manager.filter(PluginManager) == [PluginManager]
    assert plugin_manager.filter(BasePlugin) == [Plugin1, Plugin2, Plugin3]
    assert plugin_manager.filter(Plugin1) == [Plugin1]



# Generated at 2022-06-21 14:36:24.011507
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            if entry_point.load().__name__ == 'CurlTransportPlugin':
                assert len(list(PluginManager().get_transport_plugins())) == 1
                break

# Generated at 2022-06-21 14:36:26.287285
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert plugin_manager is not None


# Generated at 2022-06-21 14:36:33.145785
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    #TestCase-1 :  Verifying the installed plugin count
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    installed_plugin_count = len(plugin_manager)
    print("Total Count of plugins installed : "+ str(installed_plugin_count))
    assert(installed_plugin_count > 0)
    #TestCase-2 :  Verifying the installed plugin class types
    assert(isinstance(plugin_manager, PluginManager))
    installed_plugin_class = set(type(item) for item in plugin_manager)
    assert(len(installed_plugin_class) > 0)
    print("Total Count of plugin class types installed : "+ str(len(installed_plugin_class)))
    #TestCase-3 : Verifying the return type of method load_installed_plugins

# Generated at 2022-06-21 14:36:42.710064
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import JSONConverter
    # Assert type of JSONConverter
    assert  isinstance(JSONConverter, Type)
    assert  isinstance(JSONConverter, Type[ConverterPlugin])

    # Assert creation of PluginManager instance
    plugin_manager = PluginManager()
    assert  isinstance(plugin_manager, PluginManager)

    # Register plugins in plugin_manager instance
    plugin_manager.register(JSONConverter)
    assert plugin_manager[0] == JSONConverter
    assert  isinstance(plugin_manager[0], Type[ConverterPlugin])

    # Assert calling method to get list of converters
    assert plugin_manager.get_converters()[0] == JSONConverter

# Generated at 2022-06-21 14:36:47.181377
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()
    res = pm.get_auth_plugin_mapping()

# Generated at 2022-06-21 14:36:59.269920
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    # First call
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    # Second call
    plugin_manager.register(PluginAuth)
    assert plugin_manager.get_auth_plugin_mapping() == {'plugin': PluginAuth}
    # Third call
    plugin_manager.register(PluginAuth2)
    assert plugin_manager.get_auth_plugin_mapping() == {'plugin': PluginAuth, 'plugin2': PluginAuth2}
    # Fourth call
    plugin_manager.unregister(PluginAuth)
    assert plugin_manager.get_auth_plugin_mapping() == {'plugin2': PluginAuth2}
    # Fifth call
    plugin_manager.unregister(PluginAuth2)

# Generated at 2022-06-21 14:37:00.877646
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert len(p) > 0


# Generated at 2022-06-21 14:37:11.133996
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# 2 - Call function test_PluginManager_load_installed_plugins
test_PluginManager_load_installed_plugins()

# Generated at 2022-06-21 14:37:13.552901
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    PluginManager_obj1 = PluginManager()
    PluginManager_obj1.register(AuthPlugin)
    assert PluginManager_obj1.get_auth_plugin_mapping() == {'auth_plugin': AuthPlugin}

# Generated at 2022-06-21 14:37:14.897342
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager().get_transport_plugins() == list()


# Generated at 2022-06-21 14:37:20.929907
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    group_formatters = {
        'group1': [
            object(), object()
        ],
        'group2': [
            object(), object(), object()
        ]
    }
    plugins.extend(group_formatters['group1'])
    plugins.extend(group_formatters['group2'])
    assert plugins.get_formatters_grouped() == group_formatters

# Generated at 2022-06-21 14:37:26.541945
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins.get_formatters_grouped()
    plugin_list = plugins.get_formatters_grouped()['group_name']
    for plugin in plugin_list:
        assert plugin.group_name == 'group_name'

# Generated at 2022-06-21 14:37:30.654313
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter.groups import FormattersGroup
    from httpie.plugins.formatter.colors import ColorFormatter
    from httpie.plugins.formatter.format import FormFormatter
    from httpie.plugins.formatter.colors import ColorScheme
    formatter_group_num = 0
    for group_name, group in PluginManager.get_formatters_grouped():
        formatter_group_num += 1
        assert isinstance(group, FormattersGroup)
        assert isinstance(group_name, str)
        formatter_num = 0
        for formatter in group:
            formatter_num += 1
            assert isinstance(formatter, FormatterPlugin)
    assert formatter_group_num == 2
    assert formatter_num == 2

# Generated at 2022-06-21 14:37:33.660670
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(AuthPlugin, FormatterPlugin)
    assert manager[0] == AuthPlugin
    assert manager[1] == FormatterPlugin


# Generated at 2022-06-21 14:37:41.801182
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    """
    Test for method get_converters of class PluginManager.
    """
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    converters = plugin_manager.get_converters()
    if __debug__:
        assert isinstance(converters,list)
        assert len(converters) == 3
        assert isinstance(converters[0],type)
        assert isinstance(converters[0](),httpie.plugins.converter.v1.BaseConverter)
        assert isinstance(converters[1],type)
        assert isinstance(converters[1](),httpie.plugins.converter.v1.BaseConverter)
        assert isinstance(converters[2],type)

# Generated at 2022-06-21 14:37:46.847358
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    import mocks
    p = PluginManager()
    p.register(mocks.FooAuthPlugin, mocks.BarAuthPlugin)
    assert p.get_auth_plugins() == [mocks.FooAuthPlugin, mocks.BarAuthPlugin]


# Generated at 2022-06-21 14:37:51.779328
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.v1.kubectl import KubectlAuthPlugin
    manager = PluginManager()
    manager.register(KubectlAuthPlugin)
    print(manager.get_auth_plugin_mapping())
    assert manager.get_auth_plugin_mapping()

test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-21 14:38:10.983864
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class TestPlugin(BasePlugin):
        pass
    manager = PluginManager()
    manager.register(TestPlugin)
    assert TestPlugin in manager
    manager.unregister(TestPlugin)
    assert TestPlugin not in manager



# Generated at 2022-06-21 14:38:14.798228
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    int_class = int
    manager.register(float,int)
    manager.register(str,float)
    result_list = manager.filter(int_class)
    assert result_list == [float,int]

# Generated at 2022-06-21 14:38:19.566001
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    data = {'group_name': 'abc', 'description': 'abc'}
    plugin_manager.register(FormatterPlugin)
    assert len(plugin_manager.get_formatters_grouped()) == 0
    plugin_manager.register(lambda: data)
    assert len(plugin_manager.get_formatters_grouped()) == 1

# Generated at 2022-06-21 14:38:21.817394
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pl = PluginManager()
    pl.load_installed_plugins()
    assert issubclass(pl.get_auth_plugins()[0], AuthPlugin)


# Generated at 2022-06-21 14:38:23.171675
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HeadersFo

# Generated at 2022-06-21 14:38:33.670572
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin,\
        PrettyJsonFormatterPlugin,\
        FormURLEncodedFormatterPlugin,\
        RawOrFormDataFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin,
                            PrettyJsonFormatterPlugin,
                            FormURLEncodedFormatterPlugin,
                            RawOrFormDataFormatterPlugin)
    print(f"plugin_manager = {plugin_manager}")
    print(f"plugin_manager.get_formatters() = {plugin_manager.get_formatters()}")
    print(f"plugin_manager.get_formatters_grouped() = {plugin_manager.get_formatters_grouped()}")


plugin_manager = PluginManager()

# Generated at 2022-06-21 14:38:43.556108
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    import io
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.httpie import HTTPieSession
    from httpie.plugins.base import TransportPlugin
    plugin_manager = PluginManager()
    print('test_PluginManager_get_transport_plugins()')
    plugin_manager.load_installed_plugins()
    # assert len(plugin_manager.get_transport_plugins()) == 2
    assert len(plugin_manager.get_formatters()) == 8
    assert len(plugin_manager.get_formatters_grouped()['Debug']) == 1
    assert len(plugin_manager.get_formatters_grouped()['Syntax highlighting']) == 3
    assert len(plugin_manager.get_formatters_grouped()['Syntax highlighting']) == 3

# Generated at 2022-06-21 14:38:44.967765
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == dict()

# Generated at 2022-06-21 14:38:48.155242
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group'

    manager = PluginManager()
    manager.register(FormatterPlugin1, FormatterPlugin2)
    assert manager.get_formatters_grouped()['group'] == [FormatterPlugin1, FormatterPlugin2]

# Generated at 2022-06-21 14:38:59.236901
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    p1 = FormatterPlugin(name="default", group_name="default")
    p2 = FormatterPlugin(name="json", group_name="default")
    p3 = FormatterPlugin(name="html", group_name="default")
    p4 = FormatterPlugin(name="prettyjson", group_name="default")
    p5 = FormatterPlugin(name="xml", group_name="default")
    p6 = FormatterPlugin(name="csv", group_name="default")

    pm = PluginManager()
    pm.register(p1, p2, p3, p4, p5, p6)

    assert pm.get_formatters_grouped() == {
        "default": [p1, p2, p3, p4, p5, p6]
    }


# Generated at 2022-06-21 14:39:17.643171
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm is not None

# Generated at 2022-06-21 14:39:18.816805
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    print(pluginManager.get_converters())

# Generated at 2022-06-21 14:39:23.976421
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth import BasicAuthPlugin
    from httpie.plugins.auth import DigestAuthPlugin

    pm = PluginManager([BasicAuthPlugin, DigestAuthPlugin])
    assert pm.get_auth_plugin_mapping() == {
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin,
    }

# Generated at 2022-06-21 14:39:30.473674
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth import JWTAuthPlugin
    from httpie.plugins.auth import BasicAuthPlugin
    from httpie.plugins.auth import DigestAuthPlugin
    from httpie.plugins.auth import HawkAuthPlugin
    from httpie.plugins.auth import OAuth1AuthPlugin
    from httpie.plugins.auth import OAuth2AuthPlugin

    auth_plugins = PluginManager().register(
        JWTAuthPlugin,
        BasicAuthPlugin,
        DigestAuthPlugin,
        HawkAuthPlugin,
        OAuth1AuthPlugin,
        OAuth2AuthPlugin
    )

# Generated at 2022-06-21 14:39:35.660283
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_mgr = PluginManager()
    plugin_mgr.register('Plugin_1', 'Plugin_2', 'Plugin_3')
    assert len(plugin_mgr) == 3
    plugin_mgr.unregister('Plugin_1')
    assert len(plugin_mgr) == 2
    assert 'Plugin_2' in plugin_mgr
    assert 'Plugin_3' in plugin_mgr


# Generated at 2022-06-21 14:39:37.823263
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager() == []


# Unit tests for register() and unregister() of class PluginManager

# Generated at 2022-06-21 14:39:45.290151
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    class BasePlugin_1(BasePlugin):
        def hello(self):
            return 'world_1'
    class BasePlugin_2(BasePlugin):
        def hello(self):
            return 'world_2'
    plugin_manager.register(BasePlugin_1, BasePlugin_2)
    assert(plugin_manager[0].hello() == 'world_1')
    assert(plugin_manager[1].hello() == 'world_2')


# Generated at 2022-06-21 14:39:49.231467
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.register(BearerAuth)
    plugin_manager.register(DigestAuth)
    print(repr(plugin_manager))
    

# Generated at 2022-06-21 14:39:53.220580
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    assert plugin_manager == [BasePlugin]
    plugin_manager.unregister(BasePlugin)
    assert plugin_manager == []


# Generated at 2022-06-21 14:40:00.568017
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert 'basic' in manager.get_auth_plugin_mapping()
    assert 'digest' in manager.get_auth_plugin_mapping()
    assert 'JWT' in manager.get_auth_plugin_mapping()
    assert 'bearer' in manager.get_auth_plugin_mapping()
    assert 'hawk' in manager.get_auth_plugin_mapping()
    assert 'AWS' in manager.get_auth_plugin_mapping()

if __name__ == '__main__':
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-21 14:40:38.035348
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.append('auth.plugin')
    assert_equals(plugin_manager.get_auth_plugin('auth.plugin'), 'auth.plugin')

# Generated at 2022-06-21 14:40:39.588571
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    for plugin in p:
        print(plugin)


# Generated at 2022-06-21 14:40:40.548433
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager.register()
    assert PluginManager.get_formatters()



# Generated at 2022-06-21 14:40:50.022388
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()

# Generated at 2022-06-21 14:40:57.802661
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBasicAuthPlugin, HTTPDigestAuth, \
        HTTPDigestAuthPlugin, HTTPAuthPlugin, HTTPBearerAuthPlugin, HTTPBearerAuth, \
        HTTPNTLMAuthPlugin, HTTPNTLMAuth

    PluginManager.register(HTTPBasicAuthPlugin, HTTPDigestAuthPlugin, HTTPAuthPlugin,
                           HTTPBearerAuthPlugin, HTTPNTLMAuthPlugin)
    assert isinstance(PluginManager.get_auth_plugins, list)
    assert isinstance(PluginManager.get_auth_plugins[0], AuthPlugin)



# Generated at 2022-06-21 14:41:05.603788
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.manager import PluginManager
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_names = [plugin.name for plugin in plugin_manager.get_formatters()]
    assert 'Pretty' in plugin_names
    assert 'Json' in plugin_names
    assert 'Html' in plugin_names
    assert 'Tsv' in plugin_names
    assert 'JsonStream' in plugin_names
    assert 'ColoredJson' in plugin_names
    assert 'ColoredTsv' in plugin_names
    assert 'ColoredJsonStream' in plugin_names
    assert 'Curl' in plugin_names


# Generated at 2022-06-21 14:41:15.121969
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuthPlugin
    from httpie.plugins.builtin import HTTPNTLMAuthPlugin
    from httpie.plugins.builtin import MultipartFormDataItemInjectorPlugin
    from httpie.plugins.builtin import JSONItemInjectorPlugin
    from httpie.plugins.builtin import URLEncodedItemInjectorPlugin
    from httpie.plugins.builtin import HTTPGzipTransportPlugin
    from httpie.plugins.builtin import HTTPDeflateTransportPlugin
    from httpie.plugins.builtin import HTTPJSONParserPlugin
    from httpie.plugins.builtin import HTTPPrettyJSONParserPlugin
    from httpie.plugins.builtin import HTTPXMLParserPlugin
    from httpie.plugins.builtin import HTTPHTMLParserPlugin

    # Example
    pm = PluginManager()

# Generated at 2022-06-21 14:41:16.341983
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    assert isinstance(manager, PluginManager)
    assert len(manager) == 0
    assert isinstance(manager, list)

# Unit test of method register of class PluginManager

# Generated at 2022-06-21 14:41:18.068610
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert isinstance(plugins.get_auth_plugins(), list)


# Generated at 2022-06-21 14:41:31.231038
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # 生成实例
    pm = PluginManager()

    # 获得所有的 auth plugins
    auth_plugins = pm.get_auth_plugins()

    # 测试生成的 auth plugin 的类型
    assert type(auth_plugins) == list

    # 测试生成的 auth plugin 的数量
    assert len(auth_plugins) == 9

    # 测试生成的 auth plugin 的类型 Type[AuthPlugin]
    assert type(auth_plugins[0]) == type
    assert issubclass(auth_plugins[0], AuthPlugin)

    # 测试生成的 auth plugin 的 auth_type