

# Generated at 2022-06-21 14:34:31.610904
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)
    assert plugins == [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin, AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]


# Generated at 2022-06-21 14:34:33.904597
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register()
    print(manager.get_formatters_grouped())


plugins = PluginManager()

# Generated at 2022-06-21 14:34:37.616702
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin, AuthPlugin, CustomPlugin)

    assert isinstance(plugin_manager.filter(TransportPlugin)[0], TransportPlugin)



# Generated at 2022-06-21 14:34:39.603111
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    instance = PluginManager()
    instance.register()
    assert instance.get_auth_plugin_mapping() == dict()


# Generated at 2022-06-21 14:34:43.734872
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)
    assert plugin_manager == [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]


# Generated at 2022-06-21 14:34:44.316638
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    assert True

# Generated at 2022-06-21 14:34:52.796033
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.converter import ConverterPlugin
    assert PluginManager().filter(by_type=FormatterPlugin) == []
    assert PluginManager().filter(by_type=ConverterPlugin) == []
    plugins = [FormatterPlugin, ConverterPlugin]
    PluginManager().register(*plugins)
    assert PluginManager().filter(by_type=FormatterPlugin) == plugins
    assert PluginManager().filter(by_type=ConverterPlugin) == plugins


# Generated at 2022-06-21 14:34:55.066417
# Unit test for constructor of class PluginManager
def test_PluginManager():
    obj = PluginManager()
    assert repr(obj) == '<PluginManager: []>'


# Generated at 2022-06-21 14:34:58.217747
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) >= 4, plugin_manager
    assert plugin_manager[0].auth_type == 'basic'


# Generated at 2022-06-21 14:34:59.768056
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pluginManager = PluginManager()
    pluginManager.register()
    pluginManager.get_auth_plugin("basic")

# Generated at 2022-06-21 14:35:03.815001
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    a = PluginManager()
    a.load_installed_plugins()
    a.unregister(a[5])
    assert type(a[6]) == type(a[5])

# Generated at 2022-06-21 14:35:06.616498
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import converter

    assert PluginManager().get_converters() == []
    assert PluginManager().get_converters() == []

    assert PluginManager().get_converters() == [converter.JsonConverter]

# Generated at 2022-06-21 14:35:15.635216
# Unit test for constructor of class PluginManager

# Generated at 2022-06-21 14:35:21.456887
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class A(BasePlugin):
        pass

    class B(BasePlugin):
        pass

    pm = PluginManager()
    pm.register(A)
    pm.register(B)

    assert len(pm.filter()) == 2
    assert len(pm.filter(A)) == 1

    pm.unregister(A)

    assert len(pm.filter()) == 1
    assert len(pm.filter(A)) == 0

# Generated at 2022-06-21 14:35:22.348392
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pass


# Generated at 2022-06-21 14:35:24.470260
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert isinstance(PluginManager().get_formatters(), list)
    assert isinstance(PluginManager().get_formatters()[0], FormatterPlugin)


# Generated at 2022-06-21 14:35:27.289160
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    PluginManager.register(JsonPlugin, JsonLinesPlugin, XmlPlugin)
    assert len(PluginManager.get_converters()) == 3
    PluginManager.unregister(XmlPlugin)
    PluginManager.unregister(JsonLinesPlugin)
    PluginManager.unregister(JsonPlugin)

# Generated at 2022-06-21 14:35:31.786675
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(TestAuthPlugin)

    mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(mapping.items()) == 1
    assert mapping.get('basic')



# Generated at 2022-06-21 14:35:33.877454
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    assert isinstance(pm.get_formatters(), list)


# Generated at 2022-06-21 14:35:42.872802
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.gssnegotiate import GssNegotiateAuthPlugin
    from httpie.plugins.auth.hawk import HawkAuthPlugin
    from httpie.plugins.auth.jwt import JWTAuthPlugin
    from httpie.plugins.auth.ntlm import NTLMAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1AuthPlugin
    from httpie.plugins.auth.aws import AWSv4AuthPlugin

    session = Session()
    pluginManager = PluginManager()

    pluginManager.register(BasicAuthPlugin())
    pluginManager.register(DigestAuthPlugin())
    pluginManager.register(GssNegotiateAuthPlugin())
    pluginManager.register

# Generated at 2022-06-21 14:35:51.708155
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter import JSONConverter, URLEncodedConverter
    plugin_manager = PluginManager()
    plugin_manager.register(JSONConverter, URLEncodedConverter)
    assert plugin_manager.get_converters() == [JSONConverter, URLEncodedConverter]

# Generated at 2022-06-21 14:35:53.844725
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    root = PluginManager()
    root.register(HttpiePlugin)
    assert root.get_auth_plugin('httpie') == HttpiePlugin



# Generated at 2022-06-21 14:36:02.258405
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(
        type('foo', (AuthPlugin,), {'auth_type': 'foo'}),
        type('bar', (AuthPlugin,), {'auth_type': 'bar'}),
    )
    assert plugin_manager.get_auth_plugin_mapping() == {
        'foo': type('foo', (AuthPlugin,), {'auth_type': 'foo'}),
        'bar': type('bar', (AuthPlugin,), {'auth_type': 'bar'}),
    }

# Generated at 2022-06-21 14:36:08.663584
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    pm = PluginManager()
    pm.register(A, B, C)
    assert pm.filter() == [A, B, C]
    assert pm.filter(A) == [A, B, C]
    assert pm.filter(B) == [B, C]
    assert pm.filter(C) == [C]

# Generated at 2022-06-21 14:36:14.126846
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert (AuthPlugin in plugin_manager)
    assert (plugin_manager.get_auth_plugin('oauth1') is not None)
    assert (plugin_manager.get_auth_plugin('basic') is not None)
    assert (plugin_manager.get_auth_plugin('bearer') is not None)


# Generated at 2022-06-21 14:36:24.158501
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONTableFormatterPlugin, JSONFormatterPlugin
    from httpie.output.streams import StdoutBytesIO
    class CustomJSONPlugin(JSONFormatterPlugin):
        group_name = 'custom-json'
        name = 'cjson'
    class CustomJSONTablePlugin(JSONTableFormatterPlugin):
        group_name = 'custom-json'
        name = 'cjson-table'
    plugins_to_register = [CustomJSONPlugin, CustomJSONTablePlugin]
    manager = PluginManager()
    manager.register(*plugins_to_register)
    formatters_grouped = manager.get_formatters_grouped()
    assert len(formatters_grouped) == 4

# Generated at 2022-06-21 14:36:27.299080
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin = Type[BasePlugin]
    plugins = PluginManager()
    plugins.register(plugin)
    assert plugin in plugins



# Generated at 2022-06-21 14:36:31.731347
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert len(PluginManager().filter()) == 0
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPAdapter)
    assert len(plugin_manager.filter()) == 1
    assert len(plugin_manager.filter(TransportPlugin)) == 1
    assert len(plugin_manager.filter(AuthPlugin)) == 0
    assert len(plugin_manager.filter(FormatterPlugin)) == 0
    assert len(plugin_manager.filter(ConverterPlugin)) == 0

# Generated at 2022-06-21 14:36:38.196169
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    auth1 = AuthPlugin
    auth2 = AuthPlugin

    auth1.auth_type = 'a'
    auth2.auth_type = 'b'

    pm.register(auth1, auth2)
    auths = pm.get_auth_plugins()
    assert auths[0].auth_type in ['a', 'b']
    assert auths[1].auth_type in ['a', 'b']


# Generated at 2022-06-21 14:36:39.863956
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin = PluginManager()
    plugin.register(PluginManager)
    assert plugin[0] == PluginManager


# Generated at 2022-06-21 14:36:50.363015
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.__repr__() == '<PluginManager: [httpie.plugins.auth.AuthPlugin]>'


# Generated at 2022-06-21 14:36:56.186432
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(mapping) == 0
    mapping = plugin_manager.register(TestAuthPlugin).get_auth_plugin_mapping()
    assert len(mapping) == 1
    assert mapping['test'] == TestAuthPlugin


# Generated at 2022-06-21 14:37:00.681066
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.load_installed_plugins()
    # Unit test for method unregister of class PluginManager
    assert len(manager) > 0
    assert len(manager.get_auth_plugins()) > 0
    manager.unregister(manager.get_auth_plugin('basic'))
    assert len(manager.get_auth_plugins()) == 0

# Generated at 2022-06-21 14:37:05.599416
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    for plugin in plugin_manager:
        assert issubclass(plugin, BasePlugin)


plugin_manager = PluginManager()

# Generated at 2022-06-21 14:37:08.062419
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert plugin_manager.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-21 14:37:10.181412
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register()

    converters = manager.get_converters()

    assert converters == []


# Generated at 2022-06-21 14:37:17.075351
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from __init__ import PluginManager
    from httpie.plugins import AuthPlugin
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.kerberos import KerberosAuthPlugin

    # Basic Auth
    assert PluginManager().get_auth_plugin('basic') == BasicAuthPlugin
    assert PluginManager().get_auth_plugin_mapping()['basic'] == BasicAuthPlugin

    # Digest Auth
    assert PluginManager().get_auth_plugin('digest') == DigestAuthPlugin
    assert PluginManager().get_auth_plugin_mapping()['digest'] == DigestAuthPlugin

    # Kerberos Auth
    assert PluginManager().get_auth_plugin('kerberos') == KerberosAuthPlugin
    assert PluginManager().get_auth_

# Generated at 2022-06-21 14:37:24.438422
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    assert plugins.get_formatters() == []
    assert plugins.get_formatters_grouped() == {}
    plugins.register(e)
    assert plugins.get_formatters() == [e]
    assert plugins.get_formatters_grouped() == {'Name': [e]}
    plugins.register(f)
    assert plugins.get_formatters() == [e, f]
    assert plugins.get_formatters_grouped() == {'Name': [e], 'Name2': [f]}


manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-21 14:37:27.611213
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    print("get_transport_plugins : ",pm.get_transport_plugins())

test_PluginManager_get_transport_plugins()


# Generated at 2022-06-21 14:37:29.304514
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins


# Generated at 2022-06-21 14:37:49.881692
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import http, parsed_transport
    from requests.sessions import Session
    expected_size = 2
    test_manager = PluginManager()
    test_manager.load_installed_plugins()
    transport_plugins = test_manager.get_transport_plugins()
    assert len(transport_plugins) == expected_size
    for transport_plugin in transport_plugins:
        assert isinstance(transport_plugin.session_class(), Session)


# Generated at 2022-06-21 14:37:56.572400
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins import FormatterPlugin


    # Mock plugin
    class MyPlugin(HTTPiePlugin):
        name = 'myplugin'
        fmt_group_class = FormatterPlugin


    manager = PluginManager()
    manager.register(MyPlugin)
    # First assert
    assert list(manager.get_formatters()) == [MyPlugin]

    class MyPlugin2(HTTPiePlugin):
        name = 'myplugin2'
        fmt_group_class = FormatterPlugin

    manager.register(MyPlugin2)
    # Second assert
    assert list(manager.get_formatters()) == [MyPlugin, MyPlugin2]

# Generated at 2022-06-21 14:38:08.162399
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()

    assert plugins.filter() == []

    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    assert len(plugins.filter(AuthPlugin)) == 1
    assert len(plugins.filter(FormatterPlugin)) == 1
    assert len(plugins.filter()) == 2

    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    assert len(plugins.filter(AuthPlugin)) == 2
    assert len(plugins.filter(FormatterPlugin)) == 2
    assert len(plugins.filter()) == 4

    plugins.unregister(AuthPlugin)
    plugins.unregister(FormatterPlugin)
    assert len(plugins.filter(AuthPlugin)) == 0
    assert len(plugins.filter(FormatterPlugin)) == 0
    assert len(plugins.filter()) == 0

    plugins.register

# Generated at 2022-06-21 14:38:10.740727
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_converters()


# Generated at 2022-06-21 14:38:20.895905
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    entry_point_names = set()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            entry_point_names.add(entry_point.name)
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    plugins = plugin_manager.filter()
    plugin_names = set()
    plugin_categories = set()
    for plugin in plugins:
        plugin_names.add(plugin.name)
        plugin_categories.add(plugin.category)

    # Test if the names of all entry points are added to the set entry_point_names

# Generated at 2022-06-21 14:38:24.017109
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    # Register Redis Plugin
    class RedisPlugin(TransportPlugin):
        name='RedisPlugin'
    plugin_manager.register(RedisPlugin)
    # Verify Redis Plugin is registered successfully
    assert isinstance(plugin_manager, PluginManager)


# Generated at 2022-06-21 14:38:31.581011
# Unit test for method get_formatters of class PluginManager

# Generated at 2022-06-21 14:38:37.694711
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from json import JSONConverter
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    pm = PluginManager()
    pm.register(JSONConverter)
    pm.register(HTTPBasicAuth)
    assert pm.get_converters() == [JSONConverter]
    assert pm.get_auth_plugins() == [HTTPBasicAuth]


# Generated at 2022-06-21 14:38:45.134079
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin
    class plugin_1(BasePlugin):
        def hello():
            print("hello")
    class plugin_2(BasePlugin):
        def world():
            print("world")
    class plugin_3(AuthPlugin):
        def auth_type():
            print("auth_type")
    plugin_manager = PluginManager()
    plugin_manager.register(plugin_1, plugin_2, plugin_3)
    result = plugin_manager.filter(by_type=AuthPlugin)
    assert len(result) == 1
    assert isinstance(result[0], AuthPlugin)


# Generated at 2022-06-21 14:38:47.039406
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    pm.register(BasePlugin)
    assert BasePlugin in pm



# Generated at 2022-06-21 14:39:23.675009
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie import ExitStatus
    from httpie.plugins.auth.httpie_auth import HttpAuthPlugin, BasicAuth, DigestAuth
    from httpie.plugins.auth.ntlm_auth import NTLMAuthPlugin, NTLMAuth
    from httpie.plugins.auth.native_auth import NativeAuthPlugin, ClientAuth
    from httpie.plugins.auth.aws_auth import AWSAuthPlugin, S3Auth

    manager = PluginManager()
    manager.register(BasicAuth)
    manager.register(DigestAuth)
    manager.register(NTLMAuth)
    manager.register(ClientAuth)
    manager.register(S3Auth)
    auth_plugin = manager.get_auth_plugin('httpie-auth')
    assert auth_plugin == HttpAuthPlugin
    auth_plugin = manager.get_auth_plugin

# Generated at 2022-06-21 14:39:25.289736
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)

# Generated at 2022-06-21 14:39:29.112311
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.register(MockTransportPlugin)
    manager.register(MockTransportPlugin2)
    assert manager.get_transport_plugins() == [MockTransportPlugin, MockTransportPlugin2]


# Generated at 2022-06-21 14:39:36.287008
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert isinstance(pm.filter(), list)
    assert len(pm.filter()) == 0
    assert len(pm.filter(Type)) == 0
    assert len(pm.filter(Type[BasePlugin])) > 0
    assert len(pm.filter(Type[AuthPlugin])) > 0
    assert len(pm.filter(Type[FormatterPlugin])) > 0
    assert len(pm.filter(Type[ConverterPlugin])) > 0


# Generated at 2022-06-21 14:39:38.938616
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([1, 2])) == '<PluginManager: [1, 2]>'



# Generated at 2022-06-21 14:39:43.166402
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = [jsonie.JSONiePlugin, json.JSONPlugin, pretty.PrettyPlugin]
    manager = PluginManager(plugins)
    assert sorted(manager.get_formatters()) == sorted(plugins)



# Generated at 2022-06-21 14:39:45.699751
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager.register(PluginManager, AuthPlugin, TransportPlugin)
    assert PluginManager.get_auth_plugin == [AuthPlugin]
    assert PluginManager.get_transport_plugins == [TransportPlugin]


# Generated at 2022-06-21 14:39:49.880768
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-21 14:39:52.830046
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins=PluginManager()
    plugins.load_installed_plugins()
    plugins.filter(FormatterPlugin)
    print(plugins.get_formatters_grouped())
    return True

# Generated at 2022-06-21 14:39:55.140354
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    converters = plugin_manager.get_converters()
    assert converters

# Generated at 2022-06-21 14:41:02.758368
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    available_plugins = [
        PluginManager().get_auth_plugin_mapping(),
        PluginManager().get_formatters_grouped(),
        PluginManager().get_converters(),
        PluginManager().get_transport_plugins()
    ]
    for plugins in available_plugins:
        for name in plugins.keys():
            plugins[name].unregister()
            assertplugins(name in plugins, False)



# Generated at 2022-06-21 14:41:05.521490
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    assert PluginManager().unregister(BasePlugin)
if __name__ == '__main__':
    test_PluginManager_unregister()

# Generated at 2022-06-21 14:41:08.034357
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    expected = [BasicAuthPlugin, DigestAuthPlugin, HawkAuthPlugin, OAuth1AuthPlugin, OAuth2AuthPlugin]
    actual = PluginManager().get_auth_plugins()
    assert actual == expected


# Generated at 2022-06-21 14:41:13.261020
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(PluginManager, str)
    assert isinstance(plugins.filter(), list)
    assert isinstance(plugins.filter(PluginManager), list)
    assert plugins.filter(PluginManager) == [PluginManager]
    assert isinstance(plugins.filter(str), list)
    assert plugins.filter(str) == [str]


# Generated at 2022-06-21 14:41:19.593848
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class C(BasePlugin): pass
    class D(C): pass
    class E(BasePlugin): pass
    plugins = PluginManager()
    plugins.register(C, D, E)
    assert plugins.filter(by_type=C) == [C, D]
    assert plugins.filter(by_type=D) == [D]
    assert plugins.filter(by_type=E) == [E]
    assert plugins.filter(by_type=BasePlugin) == [C, D, E]


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    # test_PluginManager_filter()

# Generated at 2022-06-21 14:41:24.787712
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins=PluginManager()
    assert plugins.filter(auth_type='os')==[name for name in plugins if name=='os']
    assert plugins.filter(auth_type='oauth2')==[name for name in plugins if name=='oauth2']

# Generated at 2022-06-21 14:41:34.877103
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    class BasePlugin1:
        pass

    class BasePlugin2:
        pass

    class PluginType1(BasePlugin1):
        pass

    class PluginType2(BasePlugin1):
        pass

    class PluginType3(BasePlugin2):
        pass

    manager = PluginManager()
    manager.register(PluginType1, PluginType2, PluginType3)

    assert manager.filter(BasePlugin) == [PluginType1, PluginType2, PluginType3]
    assert manager.filter(BasePlugin1) == [PluginType1, PluginType2]
    assert manager.filter(BasePlugin2) == [PluginType3]
    assert manager.filter(BasePlugin1) != [PluginType3]
    assert manager.filter(BasePlugin2) != [PluginType1, PluginType2]

# Generated at 2022-06-21 14:41:41.253754
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(FormatterPlugin)
    manager.register(FormatterPlugin)
    manager.register(FormatterPlugin)
    manager.register(FormatterPlugin)
    manager.register(FormatterPlugin)
    manager.register(FormatterPlugin)

    formatters_grouped = manager.get_formatters_grouped()

    assert len(formatters_grouped) == 1

    groups = list(formatters_grouped.keys())
    assert groups[0] == 'Default'

    group = formatters_grouped[groups[0]]
    assert len(group) == 6

# Generated at 2022-06-21 14:41:48.194038
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # GIVEN: Test data
    test_plugins = [
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin
    ]

    # WHEN: Running the method get_formatters_grouped
    result = PluginManager().register(*test_plugins).get_formatters_grouped()

    # THEN: Verify the result
    assert len(result) == 1
    assert list(result.values())[0] == test_plugins

# Generated at 2022-06-21 14:41:50.990272
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    import httpie
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert httpie.plugins.formatter.get_formatters() == plugin_manager.get_formatters()