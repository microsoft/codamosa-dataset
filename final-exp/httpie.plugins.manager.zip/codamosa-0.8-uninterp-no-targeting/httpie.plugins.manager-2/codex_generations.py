

# Generated at 2022-06-21 14:34:19.369970
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins.get_transport_plugins()
    print('PluginManager_get_transport_plugins')
    print('===================================')
    print(plugins.get_transport_plugins())


# Generated at 2022-06-21 14:34:20.593428
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plg_manager = PluginManager()
    assert plg_manager is not None

# Generated at 2022-06-21 14:34:21.799146
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert PluginManager().get_formatters() == []


# Generated at 2022-06-21 14:34:30.948056
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.input import ParseError
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    pm = PluginManager()
    c = HTTPBasicAuth()
    pm.register(c)
    assert len(pm) == 1
    pm.unregister(c)
    assert len(pm) == 0
    pm.register(HTTPBasicAuth())
    assert len(pm) == 1
    pm.unregister(HTTPBasicAuth)
    assert len(pm) == 0


# Generated at 2022-06-21 14:34:34.988209
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(ConverterPlugin)
    pm.register(TransportPlugin)
    pm.load_installed_plugins()
    # Make sure new plugins are populated
    assert len(pm) == 4

# Generated at 2022-06-21 14:34:42.437395
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Authentication():
        pass
    class Formatter():
        pass

    class Test1(Authentication):
        pass
    class Test2(Formatter):
        pass
    class Test3(Authentication):
        pass
    class Test4(Formatter):
        pass
    class Test5():
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(Test1, Test2, Test3, Test4, Test5)

    assert plugin_manager.filter(Authentication) == [Test1, Test3]
    assert plugin_manager.filter(Formatter) == [Test2, Test4]

# Generated at 2022-06-21 14:34:47.410292
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class MyPlugin(BasePlugin):
        pass
    myplugin = MyPlugin()

    # Create plugin manager and register plugin to it
    plugin_manager = PluginManager()
    plugin_manager.register(myplugin)

    # check plugin was registered
    assert myplugin in plugin_manager

    # unregister plugin
    plugin_manager.unregister(myplugin)

    # check plugin was unregistered
    assert myplugin not in plugin_manager



# Generated at 2022-06-21 14:34:52.039775
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    Unit_test_plugins_length_1 = len(plugins)
    plugins.unregister(plugins[0])
    assert len(plugins) == Unit_test_plugins_length_1 - 1

# Generated at 2022-06-21 14:35:00.241903
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import PKG_NAME as HTTPIE_PKG_NAME
    from httpie_jwt_auth import PKG_NAME as JWT_PKG_NAME

    manager = PluginManager()
    manager.load_installed_plugins()

    auth_plugin_mapping = manager.get_auth_plugin_mapping()
    assert 'jwt' in auth_plugin_mapping
    assert auth_plugin_mapping['jwt'].package_name == JWT_PKG_NAME

    assert 'json' in auth_plugin_mapping
    assert auth_plugin_mapping['json'].package_name == HTTPIE_PKG_NAME

# Generated at 2022-06-21 14:35:01.435919
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    assert manager.get_converters() == []


# Generated at 2022-06-21 14:35:07.817533
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    manager.load_installed_plugins()
    plugin_list = list(manager)
    assert len(plugin_list) == 137

# Generated at 2022-06-21 14:35:16.104013
# Unit test for constructor of class PluginManager
def test_PluginManager():

    http_mock = mock.Mock()

    # Constructor of class PluginManager
    def __init__(self):
        super(PluginManager, self).__init__()
        self.load_installed_plugins()

    # Register plugins
    def register(self, *plugins):
        for plugin in plugins:
            self.append(plugin)

    # Unregister plugins
    def unregister(self, plugin):
        self.remove(plugin)

    # Filter plugins
    def filter(self, by_type=BasePlugin):
        # Return the subclasses of each plugin
        return [plugin for plugin in self if issubclass(plugin, by_type)]

    # Load installed plugins

# Generated at 2022-06-21 14:35:19.701281
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    Check if unit test works
    """
    plugin_manager = PluginManager()
    if plugin_manager:
        print('Unit test success')
    else:
        print('Unit test failed')


# Generated at 2022-06-21 14:35:21.903118
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    """Unit test for method get_converters of class PluginManager
    """
    plugin_manager = PluginManager()
    plugin_manager.register(ConverterPlugin)
    assert isinstance(plugin_manager.get_converters()[0], ConverterPlugin)

# Generated at 2022-06-21 14:35:26.327674
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie_plugins.auth.v1 import httpie_auth_plugin
    from httpie.plugins import AuthPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(httpie_auth_plugin)
    assert issubclass(plugin_manager.get_auth_plugins()[0], AuthPlugin) == True
    assert plugin_manager.get_auth_plugins()[0].auth_type == 'httpie'

# Generated at 2022-06-21 14:35:30.125750
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    PluginManager1 = PluginManager()
    PluginManager1.register(Type[BasePlugin])
    assert isinstance(PluginManager1[0], Type[BasePlugin])
    PluginManager1.unregister(Type[BasePlugin])
    assert PluginManager1 == []

# Generated at 2022-06-21 14:35:37.688957
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    p1 = PluginManager()
    p1.register(ConverterPlugin)
    p1.register(ConverterPlugin)
    p2 = PluginManager()
    p2.register(ConverterPlugin)
    p3 = PluginManager(p1.get_converters())
    assert p1.get_converters() == p3.get_converters()
    assert p1.get_converters() != p2.get_converters()



# Generated at 2022-06-21 14:35:40.325528
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    assert pluginManager is not None

# Generated at 2022-06-21 14:35:42.578715
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(BasePlugin)
    assert manager.get_auth_plugin_mapping() == {}


# Generated at 2022-06-21 14:35:53.378604
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    def get_plugin_manager():
        plugin_manager = PluginManager()
        entry_point_name = 'httpie.plugins.formatter.v1'
        entry_points = [
            Mock(name='json', load=lambda: Mock(name='json', group_name='json')),
            Mock(name='csv', load=lambda: Mock(name='csv', group_name='csv')),
            Mock(name='json', load=lambda: Mock(name='json', group_name='json')),
            Mock(name='yaml', load=lambda: Mock(name='yaml', group_name='yaml')),
        ]
        m = Mock(name='iter_entry_points', spec=['__call__'])
        m.return_value = entry_points
        plugin_manager.iter_entry_points = m
        return

# Generated at 2022-06-21 14:35:57.352013
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()


# Generated at 2022-06-21 14:36:06.769986
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter import AnyFormatterPlugin
    from httpie.plugins.builtin import (
        HtmlFormatterPlugin,
        JsonFormatterPlugin,
        UrlencodedFormatterPlugin,
    )
    plugin_manager = PluginManager()
    plugin_manager.register(AnyFormatterPlugin)
    plugin_manager.register(HtmlFormatterPlugin)
    plugin_manager.register(JsonFormatterPlugin)
    plugin_manager.register(UrlencodedFormatterPlugin)
    print(plugin_manager.get_formatters_grouped())


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

if __name__ == "__main__":
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-21 14:36:11.374172
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Create instance of test PluginManager class
    manager = PluginManager()
    # Registar the pluginmanager with plugins
    manager.register()
    # Test pluginmanager get_auth_plugin_mapping
    assert manager.get_auth_plugin_mapping() == {}



# Generated at 2022-06-21 14:36:20.894382
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()

    cnt = 0
    for plugin in plugins:
        assert(issubclass(plugin, BasePlugin))
        cnt += 1
    assert(cnt==0)

    plugins.register(TransportPlugin)
    plugins.register(AuthPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(FormatterPlugin)

    cnt = 0
    for plugin in plugins:
        assert(issubclass(plugin, BasePlugin))
        cnt += 1
    assert(cnt==4)

    plugins.unregister(TransportPlugin)
    cnt = 0
    for plugin in plugins:
        assert(issubclass(plugin, BasePlugin))
        cnt += 1
    assert(cnt==3)

    assert(plugins.filter(TransportPlugin)==[])

# Generated at 2022-06-21 14:36:25.436848
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    class Plugin:
        def record_info(self, request, args):
            pass
    plugin_manager.register(Plugin)
    assert len(plugin_manager) == 1
    assert plugin_manager[0] == Plugin



# Generated at 2022-06-21 14:36:27.267819
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginManager=PluginManager()
    class test_plugin():
        pass
    pluginManager.register(test_plugin)
    assert test_plugin in pluginManager.get_auth_plugins()


# Generated at 2022-06-21 14:36:33.510895
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieSessionPlugin, HTTPieUnixSocketPlugin
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import JSONFormat
    from httpie.plugins.builtin import URLEncodedFormat

    mgr = PluginManager()
    mgr.register(HTTPBasicAuth)
    mgr.register(HTTPiePlugin)
    mgr.register(HTTPieSessionPlugin)
    mgr.register(HTTPieUnixSocketPlugin)
    mgr.register(JSONStreamFormatter)
    mgr.register(JSONFormat)
    mgr.register(URLEncodedFormat)
    assert len(mgr) == 8  # 8 plugin
    m

# Generated at 2022-06-21 14:36:37.137215
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert len(pm) == 0
    pm.register(BasePlugin)
    assert len(pm) == 1
    pm.register(BasePlugin)
    assert len(pm) == 2


# Generated at 2022-06-21 14:36:40.004958
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(ConverterPlugin)
    assert len(plugin_manager.get_converters()) == 2

# Generated at 2022-06-21 14:36:41.828373
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    assert all([isinstance(plugin, Type[FormatterPlugin]) for plugin in pm.get_formatters()])


# Generated at 2022-06-21 14:36:48.571532
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert ('httpie' in plugin.package_name for plugin in manager)


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-21 14:36:51.636704
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) > 0


# Generated at 2022-06-21 14:36:56.662134
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins import AuthBasicPlugin
    manager = PluginManager()
    manager.register(AuthBasicPlugin)
    assert repr(manager) == '<PluginManager: [<class \'httpie.plugins.AuthBasicPlugin\'>]>'

# Generated at 2022-06-21 14:37:00.867876
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 2
    plugin_manager.unregister(BasePlugin)
    assert len(plugin_manager.get_transport_plugins()) == 1

# Generated at 2022-06-21 14:37:04.350908
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    httpie_plugins = PluginManager()
    httpie_plugins.load_installed_plugins()
    assert len(httpie_plugins.get_formatters()) > 0


# Generated at 2022-06-21 14:37:06.970476
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    print("\nTesting plugin manager...")
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) > 0
    print("Tests completed!")


# Generated at 2022-06-21 14:37:12.913785
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(httpie_compression_auth.CompressionAuthPlugin)
    pm.register(httpie_digest_auth.DigestAuthPlugin)
    pm.register(httpie_hmac_auth.HmacAuthPlugin)
    pm.register(httpie_aws_auth.AWSv4AuthPlugin)
    assert same_elements(
        pm.get_auth_plugins(),
        [
           httpie_compression_auth.CompressionAuthPlugin,
           httpie_digest_auth.DigestAuthPlugin,
           httpie_hmac_auth.HmacAuthPlugin,
           httpie_aws_auth.AWSv4AuthPlugin,
        ]
    )


# Generated at 2022-06-21 14:37:18.771636
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB)
    assert repr(plugin_manager) == '<PluginManager: [<class \'tests.test_plugin_manager.PluginA\'>, <class \'tests.test_plugin_manager.PluginB\'>]>'


# Generated at 2022-06-21 14:37:26.502873
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_formatters()

# Generated at 2022-06-21 14:37:27.611324
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager.register()



# Generated at 2022-06-21 14:37:37.974442
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = [1, 2, 3]
    plugin_manager = PluginManager(plugins)
    assert plugin_manager.__repr__() == '<PluginManager: [1, 2, 3]>'


plugins = PluginManager()

# Generated at 2022-06-21 14:37:42.471667
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert repr(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.auth_plugins.AuthPlugin\'>]>'
    plugin_manager.register(FormatterPlugin)
    assert repr(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.auth_plugins.AuthPlugin\'>, <class \'httpie.plugins.formatter_plugins.FormatterPlugin\'>]>'


# Generated at 2022-06-21 14:37:53.436909
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """Unit test for method get_formatters_grouped of class PluginManager"""
    # Test Normal Case
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    formatters_grouped_1 = plugin_manager.get_formatters_grouped()
    assert groupby is not None

    # Test no Exception
    try:
        formatters_grouped_2 = plugin_manager.get_formatters_grouped()
    except ValueError:
        assert False

    # Test Exception Case
    class test_empty_class:
        def __str__(self):
            return "test_empty_class"
    plugin_manager.append(test_empty_class)

# Generated at 2022-06-21 14:38:05.458521
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Given
    from multiprocessing import Process
    from httpie.output.writers import StdoutBytesWriter
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBasicAuthPlugin
    from httpie.plugins import manager as plugin_manager
    plugin_manager.clear()
    plugin_manager.load_installed_plugins()
    # When
    p = Process(target=plugin_manager.load_installed_plugins)
    p.start()
    p.join()

    # Then
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

    assert plugin_manager.filter(AuthPlugin)
    assert plugin_manager.filter(ConverterPlugin)
    assert plugin

# Generated at 2022-06-21 14:38:16.432225
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    import os
    import stat
    import shutil
    import sys
    import tempfile
    import unittest
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.core import main_gi as main
    from httpie.output.streams import RAW_JSON_CONTENT_TYPES
    from httpie.output.formatters.colors import NO_COLOR_PALETTE
    import httpie.plugins.builtin
    
    # Check if the builtin plugin is 'httpie.plugins.builtin'
    name = plugin_manager.PluginManager.get_formatters_grouped().keys()[0]

# Generated at 2022-06-21 14:38:21.165624
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(TransportPlugin)
    assert all([issubclass(plugin, ConverterPlugin) for plugin in plugin_manager.get_converters()])



# Generated at 2022-06-21 14:38:28.850067
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.stream import Stream
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin

    class DummyAuthPlugin(AuthPlugin):
        name = 'dummy'
        auth_type = 'dummy'

    class DummyFormatterPlugin(FormatterPlugin):
        name = 'dummy'
        group_name = 'dummy'
        format_name = 'dummy'

    class DummyConverterPlugin(ConverterPlugin):
        name = 'dummy'

    class DummyTransportPlugin(TransportPlugin):
        name = 'dummy'

    pm = PluginManager()

    pm.register(DummyAuthPlugin, DummyFormatterPlugin, DummyConverterPlugin, DummyTransportPlugin)


# Generated at 2022-06-21 14:38:34.371312
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert list(plugins) == []
    assert plugins.get_auth_plugins() == []
    assert plugins.get_formatters() == []
    assert plugins.get_converters() == []
    assert plugins.get_transport_plugins() == []
    assert plugins.__repr__() == "<PluginManager: []>"


# Generated at 2022-06-21 14:38:36.834091
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    assert len(plugins) == 0
    plugins.register(BasePlugin)
    assert len(plugins) == 1


# Generated at 2022-06-21 14:38:39.693126
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginmanager = PluginManager()
    pluginmanager.register(AuthPlugin)
    assert pluginmanager.get_auth_plugins() == [AuthPlugin]


# Generated at 2022-06-21 14:39:00.259530
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawOrParseErrorFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin

    plugin1 = JSONFormatterPlugin
    plugin2 = PrettyURLEncodedFormatterPlugin
    plugin3 = RawOrParseErrorFormatterPlugin
    plugin4 = URLEncodedFormatterPlugin
    plugin5 = HTMLFormatterPlugin
    plugin_list = [plugin1, plugin2, plugin3, plugin4, plugin5]

    # instantiate class
    plugin_manager = PluginManager()
    # register plugin to plugin_manager


# Generated at 2022-06-21 14:39:03.469547
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    assert len(plugins) == 0
    plugins.register(object, object)
    assert len(plugins) == 2
    plugins.unregister(object)
    assert len(plugins) == 1


# Generated at 2022-06-21 14:39:05.218269
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # initializing a new PluginManager Object
    plugin = PluginManager()
    # checking if load_installed_plugins is working
    assert plugin.load_installed_plugins

# Generated at 2022-06-21 14:39:07.629113
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert(isinstance(PluginManager(), PluginManager))

# Show all attributes of class PluginManager

# Generated at 2022-06-21 14:39:13.555259
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager= PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin = plugin_manager.get_auth_plugin('jwt')
    assert auth_plugin.name == 'jwt'
    assert auth_plugin.auth_type == 'jwt'
    assert auth_plugin.help == 'JSON Web Token Authentication'


# Generated at 2022-06-21 14:39:15.579073
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert BasePlugin not in plugin_manager
    plugin_manager.register(BasePlugin)
    assert BasePlugin in plugin_manager

# Generated at 2022-06-21 14:39:21.367970
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    auth_type = 'basic'
    plugin = plugin_manager.get_auth_plugin(auth_type)
    assert auth_type == plugin.auth_type

    auth_type2 = 'digest'
    plugin_manager.unregister(plugin)
    plugin_manager.register(plugin)
    plugin_manager.get_auth_plugin(auth_type2)
    assert auth_type2 == plugin.auth_type

# Generated at 2022-06-21 14:39:25.916004
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class a(BasePlugin):
        pass
    class b(a):
        pass
    class c(a):
        pass

    pm = PluginManager()
    pm.register(b)
    pm.register(c)
    pm.unregister(b)
    print(pm)
    assert pm == [c]


# Generated at 2022-06-21 14:39:27.953440
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    assert isinstance(plugins.filter(), list)


# Generated at 2022-06-21 14:39:31.777412
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    plugin_class = type('plugin', (FormatterPlugin,), {'group_name': 'group1'})
    manager.register(plugin_class)
    assert isinstance(manager.get_formatters_grouped(), dict)
    assert manager.get_formatters_grouped().get('group1') == [plugin_class]

# Generated at 2022-06-21 14:40:04.744934
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()


# Generated at 2022-06-21 14:40:11.006687
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Given
    class A:
        pass

    class B:
        pass

    class C(A):
        pass

    class D(A):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(A)
    plugin_manager.register(B)
    plugin_manager.register(C)
    plugin_manager.register(D)

    # When
    result = plugin_manager.filter(A)

    # Then
    assert result == [A, C, D]

# Generated at 2022-06-21 14:40:12.996290
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == []


# Generated at 2022-06-21 14:40:17.001072
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}

# Generated at 2022-06-21 14:40:25.054791
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    m = PluginManager()
    m.load_installed_plugins()
    list_of_converters = m.get_converters()
    list_of_names = []
    for converter in list_of_converters:
        list_of_names.append(converter.name)
    assert 'junit' in list_of_names
    assert 'pretty' in list_of_names
    assert 'format' in list_of_names
    assert 'sh' in list_of_names
    assert 'truncate' in list_of_names


# Generated at 2022-06-21 14:40:30.777659
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth

    pm = PluginManager()
    pm.register(HTTPBasicAuth, HTTPBearerAuth)

    assert pm.get_auth_plugins() == [HTTPBasicAuth, HTTPBearerAuth]
    assert all(issubclass(plugin, AuthPlugin) for plugin in pm.get_auth_plugins())

# Generated at 2022-06-21 14:40:34.392580
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert isinstance(plugin_manager.get_auth_plugins(), list)
    assert len(plugin_manager.get_auth_plugins()) > 0

    for item in plugin_manager.get_auth_plugins():
        assert issubclass(item, AuthPlugin)

# Generated at 2022-06-21 14:40:39.862883
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plu = PluginManager()
    plu.register(BasicAuthPlugin, DigestAuthPlugin)
    assert plu.get_auth_plugin('basic') == BasicAuthPlugin
    assert plu.get_auth_plugin('digest') == DigestAuthPlugin
    # If a wrong parameter is given, an error should raise
    try:
        plu.get_auth_plugin('wrong')
    except KeyError:
        print('KeyError raised. ')
    else:
        assert False
        
if __name__ == '__main__':
    test_PluginManager_get_auth_plugin()

# Generated at 2022-06-21 14:40:44.473843
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin('basic') == BasicAuthPlugin
    assert plugin_manager.get_auth_plugin('bearer') == BearerAuthPlugin
    assert plugin_manager.get_auth_plugin('digest') == DigestAuthPlugin
    assert plugin_manager.get_auth_plugin('hawk') == HawkAuthPlugin
    assert plugin_manager.get_auth_plugin('ntlm') == NTLMAuthPlugin



# Generated at 2022-06-21 14:40:46.779860
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manage = PluginManager()
    formatters = plugin_manage.get_formatters()
    assert len(formatters) == 2

# Generated at 2022-06-21 14:42:08.028940
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == []


# Generated at 2022-06-21 14:42:18.912562
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Create a PluginManager object
    pm = PluginManager()

    # Loads all plugins (for the testing purpose, only the entry point
    # 'httpie.plugins.auth.v1' will be loaded)
    pm.load_installed_plugins()

    # Test the method get_auth_plugin of class PluginManager.
    # The first argument of function 'get_auth_plugin' is the name of plugin
    # 'BasicAuth' in the module 'httpie.plugins.auth.basic_auth', which is
    # required by the test.
    # If the value of argument 'plugin_name' is invalid, method
    # 'get_auth_plugin' will raise a KeyError.
    assert pm.get_auth_plugin('basic') is httpie.plugins.auth.basic_auth.BasicAuth

# Generated at 2022-06-21 14:42:21.875688
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    mngr = PluginManager()
    mngr.load_installed_plugins()

    # PluginManager itself isn't a plugin, so it's not counted in the result
    assert len(mngr) > 1

# Generated at 2022-06-21 14:42:27.574390
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    A = type('A', (FormatterPlugin,), dict(group='1'))
    B = type('B', (FormatterPlugin,), dict(group='1'))
    C = type('C', (FormatterPlugin,), dict(group='2'))
    D = type('D', (FormatterPlugin,), dict(group='3'))

    plugin_manager = PluginManager()
    plugin_manager.register(A, B, C, D)

    grouped_formatters = plugin_manager.get_formatters_grouped()
    assert grouped_formatters['1'] == [A, B]
    assert grouped_formatters['2'] == [C]
    assert grouped_formatters['3'] == [D]

# Generated at 2022-06-21 14:42:33.175458
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(HttpAuthPlugin)
    manager.register(IgnoreAuthPlugin)
    dict1 = {'http': HttpAuthPlugin, 'ignore': IgnoreAuthPlugin}
    dict2 = manager.get_auth_plugin_mapping()
    assert dict1 == dict2

# Generated at 2022-06-21 14:42:38.602157
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    try:
        # test with argument normal
        plugins = PluginManager()
        plugins.register(DigestAuthPlugin, AuthBasicPlugin)
        assert plugins.get_auth_plugins() == [DigestAuthPlugin, AuthBasicPlugin]
        # test without argument
        plugins = PluginManager()
        plugins.register(DigestAuthPlugin, AuthBasicPlugin)
        assert plugins.get_auth_plugins() == [DigestAuthPlugin, AuthBasicPlugin]
    except:
        return False
    return True


# Generated at 2022-06-21 14:42:42.635445
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
	expected_auth_plugin = "BasicAuthPlugin"
	plugin = PluginManager()
	plugin.load_installed_plugins()
	result = plugin.get_auth_plugin("basic")
	assert result.__name__ == expected_auth_plugin

# Generated at 2022-06-21 14:42:45.388279
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(AuthPlugin, FormatterPlugin)
    assert len(plugins) == 2
    plugins.unregister(AuthPlugin)
    assert len(plugins) == 1
    assert plugins[0] == FormatterPlugin


# Generated at 2022-06-21 14:42:53.930152
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter import JSONConverter, URLEncodedConverter, MultipartFormDataConverter
    PluginManager().register(JSONConverter, URLEncodedConverter, MultipartFormDataConverter)
    assert PluginManager().get_converters() == [JSONConverter, URLEncodedConverter, MultipartFormDataConverter]
    PluginManager().unregister(JSONConverter)
    assert PluginManager().get_converters() == [URLEncodedConverter, MultipartFormDataConverter]
    assert PluginManager().get_formatters_grouped() == {'pygments': [MultipartFormDataConverter, URLEncodedConverter]}


# Generated at 2022-06-21 14:42:55.812053
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(BasePlugin)
    plugins.unregister(BasePlugin)
    assert plugins.__len__() == 0
    assert plugins.filter().__len__() == 0