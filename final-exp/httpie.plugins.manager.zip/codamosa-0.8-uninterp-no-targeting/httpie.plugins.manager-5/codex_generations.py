

# Generated at 2022-06-21 14:34:25.347119
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterA(FormatterPlugin):
        group_name = 'A'

    class FormatterB(FormatterPlugin):
        group_name = 'B'

    class FormatterC(FormatterPlugin):
        group_name = 'A'

    class FormatterD(FormatterPlugin):
        group_name = 'B'

    plugins = PluginManager()
    plugins.register(FormatterA, FormatterB, FormatterC, FormatterD)
    assert plugins.get_formatters_grouped() == {
        'A': [FormatterA, FormatterC],
        'B': [FormatterB, FormatterD],
    }

plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-21 14:34:28.375789
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_formatters()

    assert len(plugins) == 1



# Generated at 2022-06-21 14:34:29.931200
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == []

# Generated at 2022-06-21 14:34:31.823115
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm  # TODO

# Generated at 2022-06-21 14:34:35.279133
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugins()!=[]
    assert plugin_manager.get_formatters()!=[]
    assert plugin_manager.get_converters()!=[]
    assert plugin_manager.get_transport_plugins()!=[]


# Generated at 2022-06-21 14:34:39.912644
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    try:
        plugin_manager = PluginManager()
        list1 = plugin_manager.get_auth_plugins()
        list2 = plugin_manager.filter(AuthPlugin)
        assert list1 == list2
    except Exception as e:
        print("PluginManager: cannot get auth plugins")
        print(e)



# Generated at 2022-06-21 14:34:40.753166
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    assert pluginManager != None

# Generated at 2022-06-21 14:34:43.181590
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    g = PluginManager()
    g.load_installed_plugins()
    result = g.get_formatters()
    assert len(result) > 0


# Generated at 2022-06-21 14:34:45.271852
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin
    assert isinstance(PluginManager().get_converters()[0], ConverterPlugin)

# Generated at 2022-06-21 14:34:47.778186
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin = BasePlugin()

    plugin_manager.register(plugin)
    assert plugin in plugin_manager



# Generated at 2022-06-21 14:34:53.305703
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_converters()) > 0


# Generated at 2022-06-21 14:34:55.922587
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register(AuthPlugin, FormatterPlugin, ConverterPlugin)
    assert len(plugins) == 3


# Generated at 2022-06-21 14:34:59.724754
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register('auth', 'formatter', 'converter', 'transport')
    assert len(plugin_manager) == 4
    plugin_manager.unregister('auth')
    assert len(plugin_manager) == 3
    assert 'auth' not in plugin_manager

# Generated at 2022-06-21 14:35:02.081990
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(TransportPlugin)
    assert pm.filter(TransportPlugin) == [TransportPlugin]
    assert pm.filter(ConverterPlugin) == []

# Generated at 2022-06-21 14:35:06.689864
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    try:
        from httpie.plugins.transport.aiohttp import AiohttpPlugin
    except ImportError:
        pass
    else:
        expected = [AiohttpPlugin]
        manager = PluginManager()
        manager.register(AiohttpPlugin)
        actual = manager.get_transport_plugins()
        assert expected == actual


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-21 14:35:08.839533
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from plugins import plugins
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_formatters() == plugins.get_formatters()



# Generated at 2022-06-21 14:35:13.760125
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import transport
    plugin_manager = PluginManager()
    plugin_manager.register(transport.PipeTransport, transport.TCPTransport, transport.HTTPTransport)
    assert transport.PipeTransport in plugin_manager.get_transport_plugins()
    assert transport.TCPTransport in plugin_manager.get_transport_plugins()
    assert transport.HTTPTransport in plugin_manager.get_transport_plugins()

# Generated at 2022-06-21 14:35:15.863119
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager


# Generated at 2022-06-21 14:35:19.377573
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()

# Generated at 2022-06-21 14:35:24.856990
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import KeyValueConverter
    from httpie.plugins.builtin import JUnitFormatter
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PygmentsHTTPieFormatter
    from httpie.plugins.builtin import PygmentsCLIFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import URLEncodedFormatter

    plugin_manager = PluginManager()

    plugin_manager.load_installed_plugins()

    # Auth
    assert HTTPBasic

# Generated at 2022-06-21 14:35:35.569613
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    import httpie.plugins.auth.basic
    assert plugin_manager.get_auth_plugins() == []
    plugin_manager.register(httpie.plugins.auth.basic.BasicAuthPlugin)
    assert plugin_manager.get_auth_plugins() == [httpie.plugins.auth.basic.BasicAuthPlugin]


# Generated at 2022-06-21 14:35:40.884512
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    Unit test for method load_installed_plugins of class PluginManager
    """
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 5



# Generated at 2022-06-21 14:35:42.725341
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'



# Generated at 2022-06-21 14:35:47.457879
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping is not None
    assert len(auth_plugin_mapping) > 0


# Generated at 2022-06-21 14:35:52.506131
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.register(type('DummyPlugin1', (BasePlugin,), {'auth_type': 'dummy'}))
    manager.register(type('DummyPlugin2', (BasePlugin,), {'auth_type': 'dummy'}))
    assert len(manager.get_auth_plugins()) == 2


# Generated at 2022-06-21 14:35:54.056595
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.get_transport_plugins() == []

# Generated at 2022-06-21 14:35:57.541331
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins.get_transport_plugins()) > 0

# Generated at 2022-06-21 14:36:02.157917
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
  plugin_manager = PluginManager()
  plugin_manager.register(*[AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin])
  assert plugin_manager.get_auth_plugin_mapping() == {
      plugin.auth_type: plugin for plugin in plugin_manager.get_auth_plugins()
  }


# Generated at 2022-06-21 14:36:05.337879
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    p1 = PluginManager()
    p2 = PluginManager()
    p1.append(p2)
    p1.unregister(p2)
    assert len(p1) == 0



# Generated at 2022-06-21 14:36:08.877893
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-21 14:36:27.963025
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    def check_plugin_package(plugin, package):
        assert plugin.package_name == package

    # The plugins of these packages will be loaded.
    package_names = ['httpie_sh_formatter', 'httpie_json_diff', 'httpie_http2_bug_workaround']

    plugin_manager = PluginManager()

    plugin_manager.load_installed_plugins()

    for package in package_names:
        for plugin in plugin_manager:
            if plugin.package_name == package:
                check_plugin_package(plugin, package)

    plugin_manager.unregister(plugin)
    assert plugin_manager.count(plugin) == 0


# Generated at 2022-06-21 14:36:30.309410
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.register(AuthPlugin)

    assert repr(pm) == '<PluginManager: [<class \'httpie.plugins.auth.AuthPlugin\'>]>'



# Generated at 2022-06-21 14:36:40.909232
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    """Unit test for method get_transport_plugins of class PluginManager"""

    from httpie.adapters import TransportAdapter
    from httpie.plugins.transport.http import HTTPTransport
    class MockTransport1(TransportAdapter):
        def __init__(self, *args, **kwargs):
            pass

    class MockTransport2(TransportAdapter):
        def __init__(self, *args, **kwargs):
            pass

    class MockTransport3(TransportAdapter):
        def __init__(self, *args, **kwargs):
            pass

    # Expects HTTPTransport to be registered by default.
    assert HTTPTransport in PluginManager.get_transport_plugins()

    class MockPlugin1(TransportPlugin):
        def get_transport(self):
            return MockTransport1()

   

# Generated at 2022-06-21 14:36:48.069446
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import auth, converter, formatter, transport
    from httpie import __version__
    from pkg_resources import get_distribution

    try:
        dist = get_distribution('httpie')
        dist.activate()
    except pkg_resources.DistributionNotFound:
        pass

    plugins = PluginManager()
    plugins.load_installed_plugins()

    # Testing whether all the builtin plugins are loaded.
    # This can be done by testing whether all the modules under the four plugin
    # categories are loaded as classes inheriting BasePlugin with the
    # same name as its module.
    assert len(plugins) == len(
        auth.__all__) + len(formatter.__all__) + len(
        converter.__all__) + len(transport.__all__)


# Generated at 2022-06-21 14:36:51.795321
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert repr(pm)[:36] == '<PluginManager: [<class \'httpie.plugins.'
    assert repr(pm)[-8:] == 'Plugin\'>]>'

# Generated at 2022-06-21 14:36:55.682511
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    before = pm.register(AuthPlugin)
    pm.unregister(AuthPlugin)

    assert list(pm) != list(before)


# Generated at 2022-06-21 14:36:57.825494
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == []
    assert isinstance(pm, list)


# Generated at 2022-06-21 14:37:02.778566
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.load_installed_plugins()
    print("------Unit test for method get_formatters_grouped of class PluginManager------")
    print(plugin_manager.get_formatters_grouped())



# Generated at 2022-06-21 14:37:03.690949
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    print(pm)

# test_PluginManager()

# Generated at 2022-06-21 14:37:11.575894
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginManager = PluginManager()
    pluginManager.register(FormatterPlugin)
    
    assert pluginManager.get_formatters() == [FormatterPlugin]
    pluginManager.register(ConverterPlugin)
    assert pluginManager.get_formatters() == [FormatterPlugin]
    pluginManager.register(AuthPlugin)
    assert pluginManager.get_formatters() == [FormatterPlugin]
    pluginManager.register(TransportPlugin)
    assert pluginManager.get_formatters() == [FormatterPlugin]
    
    pluginManager.unregister(FormatterPlugin)
    assert pluginManager.get_formatters() == []
    pluginManager.unregister(ConverterPlugin)
    assert pluginManager.get_formatters() == []
    pluginManager.unregister(AuthPlugin)
    assert pluginManager.get_formatters() == []


# Generated at 2022-06-21 14:37:29.435549
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import AsyncHTTPTransport
    from httpie.plugins import TCP4HTTPTransport
    from httpie.plugins import UnixHTTPTransport
    from httpie.plugins import HTTPTransport

    manager = PluginManager()
    manager.register(AsyncHTTPTransport, TCP4HTTPTransport, UnixHTTPTransport, HTTPTransport)

    transport_plugin = manager.get_transport_plugins()

    assert transport_plugin == [AsyncHTTPTransport, TCP4HTTPTransport, UnixHTTPTransport, HTTPTransport]


# Generated at 2022-06-21 14:37:36.888110
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    _plugin = PluginManager()
    _plugin.register(HTTPBasicAuth)
    assert len(_plugin.filter(AuthPlugin)) == 1
    assert HTTPBasicAuth in _plugin.filter(AuthPlugin), "Fail"
    assert len(_plugin.filter(FormatterPlugin)) == 0
    assert len(_plugin.get_auth_plugins()) == 1
    assert HTTPBasicAuth in _plugin.get_auth_plugins()
    assert HTTPBasicAuth in _plugin.filter(AuthPlugin)


# Generated at 2022-06-21 14:37:45.727250
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    entry_point_list = list(iter_entry_points('httpie.plugins.auth.v1'))
    plugin = entry_point_list[0].load()
    plugin.package_name = entry_point_list[0].dist.key
    a = PluginManager()
    a.register(plugin)
    a.load_installed_plugins()
    assert a.__repr__() == '<PluginManager: [<AuthPlugin: httpie_aws_auth:aws-auth@0.3.4>]>'
    assert isinstance(a, PluginManager)


# Generated at 2022-06-21 14:37:53.521384
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    author_1 = "author1"
    author_2 = "author2"
    author_3 = "author3"
    plugin_1 = BasePlugin("plugin1",author_1)
    plugin_2 = BasePlugin("plugin2", author_2)
    plugin_3 = BasePlugin("plugin3", author_3)
    plugin_manager.register(plugin_1,plugin_2,plugin_3)
    assert plugin_manager[0] == plugin_1
    assert plugin_manager[1] == plugin_2
    assert plugin_manager[2] == plugin_3


# Generated at 2022-06-21 14:38:02.037838
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    assert isinstance(pm, list)
    pm.load_installed_plugins()
    import httpie.plugins.auth.v1 as auth_v1
    auth_plugins = pm.get_auth_plugins()
    assert auth_plugins
    assert isinstance(auth_plugins[0], type)
    assert issubclass(auth_plugins[0], auth_v1.BaseAuth)
    assert issubclass(auth_plugins[0], BasePlugin)


# Generated at 2022-06-21 14:38:04.631002
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters()==PluginManager.filter(Type[ConverterPlugin])

manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-21 14:38:06.710861
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    assert len(plugins) == 0
    plugins.load_installed_plugins()
    assert len(plugins) != 0

# Generated at 2022-06-21 14:38:09.408808
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    formatters = plugin_manager.get_formatters()
    assert len(formatters) > 0



# Generated at 2022-06-21 14:38:13.671085
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert repr(pm) == '<PluginManager: []>'
    pm.append(TransportPlugin)
    assert repr(pm) == '<PluginManager: [<class \'httpie.plugins.base.TransportPlugin\'>]>'


# Generated at 2022-06-21 14:38:19.951981
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    formatter_plugins = plugin_manager.get_formatters()
    assert formatter_plugins == [httpie.output.formatters.default.DefaultFormatter]
    assert formatter_plugins[0]().info == {
        'name': 'default',
        'description': 'Human-friendly output',
        'group_name': 'format',
        'input_stream': False,
    }



# Generated at 2022-06-21 14:38:42.294233
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    m = PluginManager()
    assert isinstance(m, PluginManager)

    m.load_installed_plugins()
    assert len(m) > 1

    for plugin in m:
        assert isinstance(plugin, BasePlugin)


# Generated at 2022-06-21 14:38:44.662407
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(NoAdaptiveTransportPlugin, CurlAdaptiveTransportPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 2

# Generated at 2022-06-21 14:38:46.809820
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    converter_plugins = plugin_manager.get_converters()
    assert len(converter_plugins) > 0

# Generated at 2022-06-21 14:38:51.279743
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([])) == '<PluginManager: []>'
    assert repr(PluginManager([1, 2])) == '<PluginManager: [1, 2]>'

# Generated at 2022-06-21 14:38:54.733125
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    p = PluginManager()
    assert len(p) == 0
    p.append(1)
    assert len(p) == 1 
    p.unregister(1)
    assert len(p) == 0

# Generated at 2022-06-21 14:38:56.111612
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    PluginManager.register(AuthPlugin, FormatterPlugin)
    assert len(PluginManager) == 2
    PluginManager.unregister(AuthPlugin)
    assert len(PluginManager) == 1


# Generated at 2022-06-21 14:39:00.824263
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D:
        pass
    pe = PluginManager()
    pe.register(A, B, C, D)
    breakpoint()
    print(pe)
    pe.unregister(A)
    print(pe)

# Generated at 2022-06-21 14:39:04.895048
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    m1 = PluginManager()
    m1.register(ConverterPlugin)
    assert ConverterPlugin in m1.get_converters()

    m2 = PluginManager()
    m2.register(m1.filter(ConverterPlugin))
    assert ConverterPlugin in m2.get_converters()



# Generated at 2022-06-21 14:39:13.797817
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    assert hasattr(pluginManager, 'get_auth_plugins')
    assert hasattr(pluginManager, 'get_auth_plugin_mapping')
    assert hasattr(pluginManager, 'get_auth_plugin')
    assert hasattr(pluginManager, 'get_formatters')
    assert hasattr(pluginManager, 'get_formatters_grouped')
    assert hasattr(pluginManager, 'get_converters')
    assert hasattr(pluginManager, 'get_transport_plugins')
#-------------------------------


# Test register and unregister of class PluginManager

# Generated at 2022-06-21 14:39:20.159415
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

    result = plugin_manager.get_formatters_grouped()
    expected_result = {
        group_name: list(group)
        for group_name, group
        in groupby(plugin_manager.get_formatters(), key=attrgetter('group_name'))
    }
    assert result == expected_result

# Generated at 2022-06-21 14:40:02.540852
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-21 14:40:07.013281
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Get actual output
    plugins = PluginManager()
    plugins.load_installed_plugins()
    actual_output = plugins.get_formatters_grouped()
    # Get expected output

# Generated at 2022-06-21 14:40:09.507573
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-21 14:40:12.805502
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pluginList = PluginManager()
    pluginList.register(BasePlugin)
    assert pluginList == [BasePlugin]

# Unit Test for method unregister of class PluginManager

# Generated at 2022-06-21 14:40:19.220366
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter.json import JSONConverter
    from httpie.plugins.converter.json import HTTPieJSONV1
    """
    This method is used to get a list of converters in python file httpie/plugins/__init__.py.
    """
    plugin_manager = PluginManager()
    try:
        assert(JSONConverter in plugin_manager.get_converters())
        print('Test 1 Succeed!')
    except:
        print('Test 1 Failed!')
    
    try:
        assert(HTTPieJSONV1 in plugin_manager.get_converters())
        print('Test 2 Succeed!')
    except:
        print('Test 2 Failed!')
        

if __name__ == "__main__":
    test_PluginManager_get_converters

# Generated at 2022-06-21 14:40:30.351582
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    # create a PluginManager instance
    pluginmanager = PluginManager()

    # create some plugins:
    def test_auth_plugin():
        pass

    def test_output_plugin():
        pass

    def test_transport_plugin():
        pass

    # register the plugins to the PluginManager instance:
    pluginmanager.register(test_auth_plugin, test_output_plugin, test_transport_plugin)

    # test whether the plugins are registered correctly:
    assert test_auth_plugin in pluginmanager.get_auth_plugins()
    assert test_output_plugin in pluginmanager.get_formatters()
    assert test_transport_plugin in pluginmanager.get_transport_plugins()

    # unregister one the plugins
    pluginmanager.unregister(test_auth_plugin)
    assert test_auth_plugin not in pluginmanager.get

# Generated at 2022-06-21 14:40:35.502182
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import HTMLFormatter
    class TestFormatter(FormatterPlugin): pass
    class TestFormatter2(FormatterPlugin): pass
    plugin_manager = PluginManager()
    plugin_manager.register(TestFormatter, TestFormatter2)
    plugin_manager.unregister(TestFormatter2)
    assert isinstance(TestFormatter, FormatterPlugin)
    assert not isinstance(TestFormatter2, FormatterPlugin)


# Generated at 2022-06-21 14:40:39.776432
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    class PluginA(AuthPlugin):
        auth_type = 'A'

    class PluginB(AuthPlugin):
        auth_type = 'B'

    pm = PluginManager()
    pm.register(PluginA, PluginB)
    assert pm.get_auth_plugin('A') == PluginA
    assert pm.get_auth_plugin('B') == PluginB
    with pytest.raises(KeyError):
        pm.get_auth_plugin('C')

# Generated at 2022-06-21 14:40:43.151202
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    example = ["p1", "p2", "p3"]
    pm.register(*example)
    assert pm.filter(str) == ["p1", "p2", "p3"]
    assert pm.filter() == ["p1", "p2", "p3"]
    assert pm.filter(list) == []



# Generated at 2022-06-21 14:40:45.666598
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    httpbin_plugin_mgr=PluginManager()
    httpbin_plugin_mgr.register(mock_plugin)
    assert(mock_plugin in httpbin_plugin_mgr.get_formatters())

# Generated at 2022-06-21 14:41:39.616183
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins_list = [
        FormatterPlugin,
        TransportPlugin,
        ConverterPlugin,
        AuthPlugin
    ]
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins_list)
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]

# Generated at 2022-06-21 14:41:45.188029
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(BasePlugin)
    pm.register(Helper1)
    pm.register(Helper2)
    pm.register(Helper3)
    pm.register(Helper4)
    pm.register(Helper5)
    pm.register(Helper6)
    assert pm.get_converters() == [Helper4, Helper6]



# Generated at 2022-06-21 14:41:49.150074
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins_mapping = plugin_manager.get_auth_plugin_mapping()
    print(auth_plugins_mapping)


# Generated at 2022-06-21 14:41:55.941714
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.append({"httpie.plugins.formatter.v1": {
            "output": "httpie_plugin_formatter_html.HTMLFormatter",
            "group_name": "HTML",
            "package_name": "x.y.z"
        }
    })
    plugins_grouped = plugins.get_formatters_grouped()
    assert len(plugins_grouped) == 1
    assert plugins_grouped['HTML'][0]['package_name'] == 'x.y.z'

# Generated at 2022-06-21 14:41:57.946814
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.append(AuthPlugin)
    assert pm.get_auth_plugins() == [AuthPlugin]



# Generated at 2022-06-21 14:42:05.888122
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import (
        DateTimeJSONFormatterPlugin,
        PrettyJSONFormatterPlugin,
    )

    class PluginA(FormatterPlugin):
        group_name = 'group1'
    class PluginB(FormatterPlugin):
        group_name = 'group1'
    class PluginC(FormatterPlugin):
        group_name = 'group2'

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB, PluginC,
                            JSONFormatterPlugin,
                            PrettyJSONFormatterPlugin,
                            DateTimeJSONFormatterPlugin)

    assert plugin_manager.get_formatters_grouped()['group1'] == [PluginA, PluginB]
   

# Generated at 2022-06-21 14:42:13.567795
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    instance = PluginManager()
    # Load all plugins
    instance.load_installed_plugins()
    # Get all plugins
    formatters = instance.get_formatters()
    # Check the description is valid
    assert type(formatters[0].description) is str
    # Check the description exists
    assert formatters[0].description
    # Check the name is valid
    assert type(formatters[0].name) is str
    # Check the name is valid
    assert formatters[0].name
    # Check the name is valid
    assert formatters[0].group_name


# Generated at 2022-06-21 14:42:14.716803
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    print(p)


# Generated at 2022-06-21 14:42:20.583167
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    test_formatters = [
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
    ]
    pm = PluginManager()
    pm.register(*test_formatters)
    assert pm.get_formatters_grouped() == {'None': test_formatters}

# Generated at 2022-06-21 14:42:25.488089
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.register(PluginManager)
    assert PluginManager in pm
    pm.unregister(PluginManager)
    assert PluginManager not in pm
    pm.load_installed_plugins()
    # confirm the entry_point importation
    pm2 = PluginManager()
    pm2.register(PluginManager)
    assert PluginManager in pm2, "The import failed"
    pm2.unregister(PluginManager)

plugin_manager = PluginManager()