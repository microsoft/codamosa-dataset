

# Generated at 2022-06-21 14:34:25.932275
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins.base import BasePlugin
    class TestPlugin(BasePlugin):
        pass
    pm = PluginManager()
    pm.register(TestPlugin)
    assert str(pm) == '<PluginManager: [__main__.TestPlugin]>'

# Generated at 2022-06-21 14:34:33.996356
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    assert pm.filter(BasePlugin) == []
    pm.register(BasePlugin)
    assert pm.filter(BasePlugin) == [BasePlugin]
    pm.register(FormatterPlugin)
    assert pm.filter(FormatterPlugin) == [FormatterPlugin]
    assert pm.filter(BasePlugin) == [BasePlugin, FormatterPlugin]
    pm.unregister(FormatterPlugin)
    assert pm.filter(FormatterPlugin) == []
    assert pm.filter(BasePlugin) == [BasePlugin]


# Generated at 2022-06-21 14:34:38.483892
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    from httpie.plugins.builtin import PythonHttpPlugin

    pm = PluginManager()
    pm.register(PythonHttpPlugin)

    plugins = pm.filter(by_type=TransportPlugin)

    assert plugins == [PythonHttpPlugin]
    assert type(plugins) == list

# Generated at 2022-06-21 14:34:39.386552
# Unit test for constructor of class PluginManager
def test_PluginManager():
    temp = PluginManager()



# Generated at 2022-06-21 14:34:43.484898
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    test_list = []
    test_manager = PluginManager(test_list)
    test_manager.register(Plugin1, Plugin2)
    test_manager.unregister(Plugin1)
    assert Plugin1 not in test_manager


# Generated at 2022-06-21 14:34:46.004441
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager_test = PluginManager()
    assert len(manager_test.filter()) == 0
    manager_test.register(BasePlugin)
    assert len(manager_test.filter()) == 1

# Generated at 2022-06-21 14:34:48.602178
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
	manager=PluginManager()
	manager.load_installed_plugins()
	assert manager.get_converters()


# Generated at 2022-06-21 14:34:53.451195
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_transport_plugins()) == 0

    plugin_manager.register(Type[TransportPlugin]())
    assert len(plugin_manager.get_transport_plugins()) == 1

# Generated at 2022-06-21 14:34:55.352984
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins
    for plugin in plugins:
        assert plugins

# Generated at 2022-06-21 14:34:58.117060
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.register(auth_plugin1, auth_plugin2, auth_plugin3)
    assert pm.get_auth_plugin('auth_plugin3') == auth_plugin3


# Generated at 2022-06-21 14:35:04.393101
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    manager = PluginManager()
    manager.register(Plugin1)
    assert list(manager) == [Plugin1]

    manager.unregister(Plugin1)
    assert not manager

    manager.register(Plugin1, Plugin2)
    assert list(manager) == [Plugin1, Plugin2]

    manager.unregister(Plugin2)
    assert list(manager) == [Plugin1]

    manager.unregister(Plugin1)
    assert not manager

# Generated at 2022-06-21 14:35:10.934160
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    class TestPlugin(BasePlugin):
        def __init__(self):
            pass
        def __repr__(self):
            return "TestPlugin"
    plugin_manager.register(TestPlugin)
    assert plugin_manager == [TestPlugin]


# Generated at 2022-06-21 14:35:16.084092
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)
    assert repr(plugins) == '<PluginManager: [httpie.plugins.base.AuthPlugin, httpie.plugins.base.FormatterPlugin, httpie.plugins.base.ConverterPlugin, httpie.plugins.base.TransportPlugin]>'
test_PluginManager___repr__()

# Generated at 2022-06-21 14:35:21.834320
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert plugins.filter(AuthPlugin) == [AuthPlugin]
    assert plugins.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugins.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugins.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-21 14:35:22.765022
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager().get_auth_plugins()

# Generated at 2022-06-21 14:35:27.129494
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin1 = object()
    plugin2 = object()
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.register(plugin1, plugin2)
    assert len(plugin_manager) == 2
    assert plugin_manager[0] == plugin1
    assert plugin_manager[1] == plugin2


# Generated at 2022-06-21 14:35:31.624436
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.builtin import HTTPBasicAuth

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth)
    assert plugin_manager.get_auth_plugin('basic') == HTTPBasicAuth



# Generated at 2022-06-21 14:35:34.138372
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    m = PluginManager()
    m.register()
    print(m.get_auth_plugin_mapping())


# Generated at 2022-06-21 14:35:39.204280
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager = PluginManager()
    foo = type('foo', (), {})
    bar = type('bar', (), {})
    PluginManager.register(foo, bar)
    assert PluginManager.filter(foo) == [foo]
    assert PluginManager.filter(bar) == [bar]
    assert PluginManager.filter(Type[BasePlugin]) == [foo, bar]



# Generated at 2022-06-21 14:35:41.679938
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print(plugins.get_auth_plugin_mapping())


# Generated at 2022-06-21 14:35:51.464098
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert not plugin_manager.filter(TransportPlugin)

# Generated at 2022-06-21 14:35:52.650481
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}

# Generated at 2022-06-21 14:35:58.744446
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
  plugin_manager = PluginManager()
  plugin_manager.register(JsonPlugin, TextPlugin)
  plugin_collection = plugin_manager.get_converters()
  assert(len(plugin_collection) == 2)
  assert(type(plugin_collection[0]) == JsonPlugin)
  assert(type(plugin_collection[1]) == TextPlugin)


# Generated at 2022-06-21 14:36:09.723801
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    class MockAuthPlugin1(AuthPlugin):
        auth_type = 'mock-auth-type-1'

        def get_auth(self, username, password):
            return ('mock-auth-type-1', username, password)

    class MockAuthPlugin2(AuthPlugin):
        auth_type = 'mock-auth-type-2'

        def get_auth(self, username, password):
            return ('mock-auth-type-2', username, password)

    pm = PluginManager()
    pm.load_installed_plugins()
    pm.register(MockAuthPlugin1, MockAuthPlugin2)

    assert len(pm.get_auth_plugins()) == 2
    assert MockAuthPlugin1 in pm.get_auth_plugins()
    assert MockAuthPlugin2 in pm.get_auth_plugins()

# Unit test

# Generated at 2022-06-21 14:36:13.176654
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    dic = plugin_manager.get_formatters_grouped()
    assert dic == {'json': [], 'html': [], 'terminal': [], 'colors': []}


# Generated at 2022-06-21 14:36:15.189165
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pluginmanager_odj = PluginManager()
    assert pluginmanager_odj.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-21 14:36:16.266712
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert isinstance(plugins, PluginManager)


# Generated at 2022-06-21 14:36:18.731044
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPiePlugin)
    assert plugin_manager.get_transport_plugins() == [HTTPiePlugin]


# Generated at 2022-06-21 14:36:29.754947
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin
    from httpie.plugins.base import BasePlugin
    manager = PluginManager()
    manager.load_installed_plugins()
    list1 = manager.get_auth_plugins()
    list2 = manager.get_formatters()
    list3 = manager.get_converters()
    list4 = manager.get_transport_plugins()
    assert isinstance(list1, list)
    assert isinstance(list2, list)
    assert isinstance(list3, list)
    assert isinstance(list4, list)
    assert all(isinstance(l, BasePlugin) for l in list1)
    assert all(isinstance(l, BasePlugin) for l in list2)

# Generated at 2022-06-21 14:36:31.727808
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-21 14:36:41.788126
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register(type('Plugin1', (BasePlugin,), {}), type('Plugin2', (BasePlugin,), {}))
    assert plugins == [type('Plugin1', (BasePlugin,), {}), type('Plugin2', (BasePlugin,), {})]

# Generated at 2022-06-21 14:36:43.238047
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

# Generated at 2022-06-21 14:36:45.657937
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    pm = PluginManager()
    pm.register(*plugins)
    assert pm.unregister(AuthPlugin) == [FormatterPlugin, ConverterPlugin, TransportPlugin]



# Generated at 2022-06-21 14:36:50.363042
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(object):
        pass
    class Plugin2(object):
        pass
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2)

    assert plugin_manager.filter(Type[BasePlugin]) == [Plugin1, Plugin2]



# Generated at 2022-06-21 14:36:55.734773
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert len(pm.get_transport_plugins()) == 0

    #  add some plugin
    class myclass(TransportPlugin):
        pass

    pm = PluginManager()
    pm.register(myclass)
    assert len(pm.get_transport_plugins()) == 1

# Generated at 2022-06-21 14:36:57.334226
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(test_auth_plugin)
    assert plugin_manager.get_auth_plugin_mapping() == {test_auth_plugin.auth_type: test_auth_plugin}

test_auth_plugin = AuthPlugin('test', 'test', None, None, None)

# Generated at 2022-06-21 14:36:59.223681
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    global PluginManager

    assert len(PluginManager.get_formatters()) > 0


# Generated at 2022-06-21 14:37:05.556280
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    # Create a PluginManager object
    p = PluginManager()
    # List of plugins
    plugins = [AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin]
    # Register all plugins
    p.register(*plugins)
    # Remove AuthPlugin plugin
    p.unregister(AuthPlugin)
    # The new plugins list
    new_plugins = [ConverterPlugin, FormatterPlugin, TransportPlugin]
    assert p == new_plugins
    assert p != plugins

# Generated at 2022-06-21 14:37:08.036165
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'auth': AuthPlugin}



# Generated at 2022-06-21 14:37:14.074031
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    class CsvFormatter(FormatterPlugin):
        group_name = 'csv'

    class JsonFormatter(FormatterPlugin):
        group_name = 'json'

    class XmlFormatter(FormatterPlugin):
        group_name = 'xml'

    class YamlFormatter(FormatterPlugin):
        group_name = 'yaml'

    class HtmlFormatter(FormatterPlugin):
        group_name = 'html'

    class HtmlFormatter(FormatterPlugin):
        group_name = 'html'

    class HtmlFormatter2(FormatterPlugin):
        group_name = 'html'

    plugin_manager = PluginManager()

# Generated at 2022-06-21 14:37:29.304517
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert isinstance(pm.get_transport_plugins(), list)


plugins = PluginManager()

# Generated at 2022-06-21 14:37:33.710800
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()

    # Test fails if either of these doesn't exist
    try:
        plugins.load_installed_plugins()
    except:
        assert False

    assert len(plugins) > 0

    print("Success!", "Class PluginManager has passed test.")

# Generated at 2022-06-21 14:37:40.574048
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin)
    plugin_manager.register(DigestAuthPlugin)
    plugin_manager.register(OAuth1AuthPlugin)
    assert isinstance(plugin_manager.get_auth_plugin('basic'), BasicAuthPlugin)
    assert isinstance(plugin_manager.get_auth_plugin('digest'), DigestAuthPlugin)
    assert isinstance(plugin_manager.get_auth_plugin('oauth1'), OAuth1AuthPlugin)
    print('Test pass!')


PLUGIN_MANAGER = PluginManager()
PLUGIN_MANAGER.load_installed_plugins()

# Generated at 2022-06-21 14:37:52.414219
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    import httpie_oauth1
    auth_oauth1=httpie_oauth1.OAuth1AuthPlugin
    import httpie_oauth2
    auth_oauth2=httpie_oauth2.OAuth2AuthPlugin
    import httpie_aws_auth
    auth_aws=httpie_aws_auth.AWSAuthPlugin
    import httpie_auth_hmac
    auth_hmac=httpie_auth_hmac.AuthHMACPlugin
    import httpie_krb_auth
    auth_krb=httpie_krb_auth.KerberosAuthPlugin
    import httpie_jwt_auth
    auth_jwt=httpie_jwt_auth.JWTAuthPlugin
    import httpie_ntlm_auth
    auth_ntlm=httpie_ntlm_

# Generated at 2022-06-21 14:37:58.206586
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    
    plugin0 = BasePlugin()
    plugins.register(plugin0)
    assert len(plugins) == 1

    plugin1 = BasePlugin()
    plugins.register(plugin1)
    assert len(plugins) == 2

    plugins.unregister(plugin0)
    assert len(plugins) == 1
    assert plugin1 in plugins


# Generated at 2022-06-21 14:38:09.752511
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    import httpie.plugins.builtin
    from httpie.plugins import AuthPlugin
    from httpie.output.streams import ColorizedStream
    from httpie.streams import Stream
    from httpie.utils import env, StdoutBytesIO
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import TransportPlugin
    from httpie.plugins import ConverterPlugin
    import httpie.compat
    import httpie.cli
    import httpie.core
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.input
    import httpie.output
    import httpie.streams
    import httpie.utils
    import httpie

# Generated at 2022-06-21 14:38:15.086485
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    import pytest
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager

    plugins = PluginManager()
    assert len(plugins) == 0

    plugins.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert len(plugins) == 4


# Generated at 2022-06-21 14:38:17.428098
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager([AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin]) == [AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin]


# Generated at 2022-06-21 14:38:19.692606
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_formatters()


# Generated at 2022-06-21 14:38:22.943053
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'
    plugins.register(AuthPlugin)
    assert repr(plugins) == '<PluginManager: [httpie.plugins.auth.v1]>'

# Generated at 2022-06-21 14:38:41.410004
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    # assert len(plugin_manager.get_formatters()) == 3
    # assert len(plugin_manager.get_formatters_grouped()) == 0
    # assert len(plugin_manager.get_transport_plugins()) == 2

# Generated at 2022-06-21 14:38:45.353145
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    assert repr(manager) == '<PluginManager: []>'

    class Plugin:
        pass
    manager.register(Plugin)
    assert repr(manager) == '<PluginManager: [<class \'tests.httpie_plugins.test_manager.test_PluginManager___repr__.<locals>.Plugin\'>]>'


manager = PluginManager()

# Generated at 2022-06-21 14:38:46.675639
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    assert plugins.get_auth_plugins() == []


# Generated at 2022-06-21 14:38:55.154318
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()

    class BasePluginP1(BasePlugin):
        pass
    
    class BasePluginP2(BasePlugin):
        pass

    class BasePluginP3(BasePlugin):
        pass

    class BasePluginP4(BasePluginP1, BasePluginP2, BasePluginP3):
        pass

    pm.register(BasePluginP4, BasePluginP3)
    assert pm.filter(BasePlugin) == [BasePluginP4, BasePluginP3]
    assert pm.filter(TransportPlugin) == []



# Generated at 2022-06-21 14:38:57.137772
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugin_mapping() != {}



# Generated at 2022-06-21 14:39:00.812748
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginManager = PluginManager()
    pluginManager.register(FormatterPlugin, ConvertPlugin, TransportPlugin)
    assert pluginManager.get_formatters()
    pluginManager.unregister(FormatterPlugin)
    assert pluginManager.get_formatters() == False


# Generated at 2022-06-21 14:39:08.141564
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PM = PluginManager()
    for formatter_plugin in PM.get_formatters() :

        if formatter_plugin.group_name == 'JSON':
            assert formatter_plugin.group_name == 'JSON'
        elif formatter_plugin.group_name == 'HTML':
            assert formatter_plugin.group_name == 'HTML'
        elif formatter_plugin.group_name == 'colors':
            assert formatter_plugin.group_name == 'colors'
        elif formatter_plugin.group_name == 'markdown':
            assert formatter_plugin.group_name == 'markdown'
        elif formatter_plugin.group_name == 'table':
            assert formatter_plugin.group_name == 'table'

# Generated at 2022-06-21 14:39:12.000885
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    auth_type = 'basic'
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert auth_type == plugin_manager.get_auth_plugin(auth_type).auth_type

# Generated at 2022-06-21 14:39:13.404596
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    assert plugins == list()



# Generated at 2022-06-21 14:39:15.052001
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    print(plugin_manager.get_auth_plugins())



# Generated at 2022-06-21 14:39:46.500163
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    p.register(int, str)
    assert p == [int, str]

# Generated at 2022-06-21 14:39:57.108377
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # The plugins below are imported as a central point of configuration
    # They are not directly imported in any other file
    from httpie.plugins import core
    from httpie.plugins import builtin
    from httpie.plugins import outfile
    from httpie.plugins import alias
    from httpie.plugins import lxml

    plugin_manager = PluginManager()

# Generated at 2022-06-21 14:39:58.801392
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    assert plugins != None
    assert plugins.get_formatters() != None


# Generated at 2022-06-21 14:40:01.395196
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert repr(plugin_manager) == '<PluginManager: []>'
    print(repr(plugin_manager))

# Generated at 2022-06-21 14:40:02.886370
# Unit test for constructor of class PluginManager
def test_PluginManager():
    from httpie import plugins

    assert isinstance(plugins, PluginManager)
    


# Generated at 2022-06-21 14:40:10.907799
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class BasePlugin1(BasePlugin):
        pass

    class BasePlugin2(BasePlugin1):
        pass

    class BasePlugin3(BasePlugin2):
        pass

    class BasePlugin4(BasePlugin1):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin1, BasePlugin2, BasePlugin3, BasePlugin4)

    current_list = [BasePlugin1, BasePlugin2, BasePlugin3, BasePlugin4]
    assert set(plugin_manager) == set(current_list)

    # Remove only one instance
    plugin_manager.unregister(BasePlugin1)
    current_list.remove(BasePlugin1)
    assert set(plugin_manager) == set(current_list)

# Generated at 2022-06-21 14:40:15.671267
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins1 = PluginManager()
    plugins1.register(httpie.plugins.colored.ColoredFormatter)
    plugins1.register(httpie.plugins.httpie.HTTPie)
    assert plugins1.get_transport_plugins() == [httpie.plugins.httpie.HTTPie]


# Generated at 2022-06-21 14:40:18.331980
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    entry_points = ['httpie.plugins.converter.v1']
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_converters()) > 0



# Generated at 2022-06-21 14:40:21.608048
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert (len(PluginManager().get_transport_plugins()) > 0)

# Generation of test data
PluginManager().load_installed_plugins()
test_data = [(plugin.__name__, plugin) for plugin in PluginManager()]


# Generated at 2022-06-21 14:40:27.322948
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager().get_auth_plugins()
    PluginManager().get_auth_plugin_mapping()
    PluginManager().get_auth_plugin('bearer')
    PluginManager().get_formatters()
    PluginManager().get_formatters_grouped()
    PluginManager().get_converters()
    PluginManager().get_transport_plugins()
    PluginManager.__repr__()

# Generated at 2022-06-21 14:41:47.291261
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register()
    auth_plugins = plugin_manager.get_auth_plugins()
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(mapping) == len(auth_plugins)
    for plugin in auth_plugins:
        assert plugin.auth_type in mapping
        assert isinstance(mapping[plugin.auth_type], type)
        assert issubclass(mapping[plugin.auth_type], AuthPlugin)

# Generated at 2022-06-21 14:41:51.977333
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuthPlugin)

    mapping = plugin_manager.get_auth_plugin_mapping()
    assert mapping['basic'] == HTTPBasicAuthPlugin

    http_basic_auth_plugin = plugin_manager.get_auth_plugin('basic')
    assert http_basic_auth_plugin == HTTPBasicAuthPlugin

# Generated at 2022-06-21 14:41:56.269628
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    a = PluginManager()
    b = PluginManager()
    c = PluginManager()
    d = PluginManager()
    a.register(b)
    b.register(c)
    c.register(d)
    a.unregister(b)
    assert a.index(b) != 0



# Generated at 2022-06-21 14:41:59.085479
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    _ = PluginManager.get_auth_plugin({"auth": "basic"})
    assert True

if __name__ == "__main__":
    test_PluginManager_get_auth_plugin()

# Generated at 2022-06-21 14:42:02.101076
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    assert len(manager) == 0
    manager.register(A, B, C)
    assert len(manager) == 3
    assert manager[0] == A
    assert manager[1] == B
    assert manager[2] == C


# Generated at 2022-06-21 14:42:04.713707
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    fake_plugin = type('fake_plugin', (object,), {})
    plugin = PluginManager()
    plugin.register(fake_plugin)
    assert(len(plugin.filter(by_type=type(fake_plugin))) == 1)

# Generated at 2022-06-21 14:42:05.778926
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p=PluginManager()
    p.load_installed_plugins()

# Generated at 2022-06-21 14:42:11.241909
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import HTTPBasicAuth
    pm = PluginManager()
    pm.append(HTTPBasicAuth)
    assert pm.get_converters() == [HTTPBasicAuth]
    assert pm.get_converters() != [HTTPBasicAuth, HTTPBasicAuth]

manager = PluginManager()
manager.load_installed_plugins()

plugins = manager

# Generated at 2022-06-21 14:42:19.916690
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # Set up
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(TransportPlugin)
    # Exercise
    actual = plugin_manager.__repr__()
    # Verify
    assert actual == '<PluginManager: [<class \'httpie.plugins.auth.AuthPlugin\'>, <class \'httpie.plugins.converter.ConverterPlugin\'>, <class \'httpie.plugins.formatter.FormatterPlugin\'>, <class \'httpie.plugins.transport.TransportPlugin\'>]>'



# Generated at 2022-06-21 14:42:22.342006
# Unit test for constructor of class PluginManager
def test_PluginManager():
    # Test case 1
    assert PluginManager([1, 2]) == [1, 2]
    # Test case 2
    assert PluginManager([]) == []

