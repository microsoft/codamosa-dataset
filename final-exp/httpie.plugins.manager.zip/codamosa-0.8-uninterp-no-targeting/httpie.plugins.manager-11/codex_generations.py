

# Generated at 2022-06-21 14:34:26.909598
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin)
    plugin_manager.register(DigestAuthPlugin)
    plugin_manager.register(OAuth1Plugin)
    plugin_manager.register(OAuth2Plugin)
    plugin_manager.register(OAuth2ImplicitPlugin)

    assert plugin_manager.get_auth_plugin('basic') == BasicAuthPlugin
    assert plugin_manager.get_auth_plugin('digest') == DigestAuthPlugin
    assert plugin_manager.get_auth_plugin('oauth1') == OAuth1Plugin
    assert plugin_manager.get_auth_plugin('oauth2') == OAuth2Plugin
    assert plugin_manager.get_auth_plugin('oauth2_implicit') == OAuth2ImplicitPlugin
    assert plugin_manager.get_auth_plugin('fake')

# Generated at 2022-06-21 14:34:32.051371
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie import __main__
    from httpie.plugins import auth
    test_plugin_manager = PluginManager()
    test_plugin_manager.append(auth.BasicAuthPlugin)

    mapping = test_plugin_manager.get_auth_plugin_mapping()
    assert mapping == {'basic': auth.BasicAuthPlugin}


# Generated at 2022-06-21 14:34:33.862007
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert PluginManager().get_auth_plugin('basic') == BasicAuthPlugin
test_PluginManager_get_auth_plugin()

# Generated at 2022-06-21 14:34:40.349825
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginmanager = PluginManager()
    pluginmanager.register(FormatterPlugin)
    pluginmanager.register(FormatterPlugin)

    output = pluginmanager.get_formatters_grouped()
    print(f"\noutput: \n{output}")

# Generated at 2022-06-21 14:34:43.485507
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # Verify if the plugin contains the detail of the package
    for plugin in plugin_manager:
        assert plugin.package_name is not None


# Generated at 2022-06-21 14:34:44.864969
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()


pm = PluginManager()

# Generated at 2022-06-21 14:34:48.169346
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm.get_converters())
    assert len(pm.get_converters()) > 0


# Generated at 2022-06-21 14:34:54.301956
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)
    PluginManager().get_formatters_grouped() == {}


# Generated at 2022-06-21 14:35:03.042741
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # set up test data
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.hawk import HawkAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1AuthPlugin
    from httpie.plugins.auth.oauth2 import OAuth2AuthPlugin
    from httpie.plugins.auth.aws import AWSV4AuthPlugin
    test_auth_plugins = [
        BasicAuthPlugin,
        DigestAuthPlugin,
        HawkAuthPlugin,
        OAuth1AuthPlugin,
        OAuth2AuthPlugin,
        AWSV4AuthPlugin,
    ]

    # begin test
    pm = PluginManager()
    pm.register(*test_auth_plugins)


# Generated at 2022-06-21 14:35:10.380728
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            PluginManager().register(entry_point.load())
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin = plugin_manager.get_auth_plugin('basic')
    assert(plugin.auth_type == 'basic')


# Generated at 2022-06-21 14:35:16.098747
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import pytest
    plugins = PluginManager()
    with pytest.raises(AttributeError) as excinf:
        plugins.load_installed_plugins()
    assert str(excinf.value) == 'module'

plugins = PluginManager()

# Generated at 2022-06-21 14:35:25.666135
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    TestPlugin1 = type('TestPlugin1', (AuthPlugin,), {})
    TestPlugin2 = type('TestPlugin2', (ConverterPlugin,), {})
    TestPlugin3 = type('TestPlugin3', (FormatterPlugin,), {})
    TestPlugin4 = type('TestPlugin4', (BasePlugin,), {})

    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin1, TestPlugin2, TestPlugin3)

    assert plugin_manager.filter(Type[BasePlugin]) == [TestPlugin1, TestPlugin2, TestPlugin3, TestPlugin4]
    assert plugin_manager.filter(Type[AuthPlugin]) == [TestPlugin1, TestPlugin4]
    assert plugin_manager.filter(Type[ConverterPlugin]) == [TestPlugin2, TestPlugin4]

# Generated at 2022-06-21 14:35:28.388490
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert(plugin_manager.get_auth_plugins()==[])
    assert(plugin_manager.get_formatters()==[])

# Generated at 2022-06-21 14:35:34.168662
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert plugin_manager == []
    assert plugin_manager.get_auth_plugins() == []
    assert plugin_manager.get_formatters() == []
    assert plugin_manager.get_converters() == []
    assert plugin_manager.get_transport_plugins() == []


# Generated at 2022-06-21 14:35:35.571074
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert repr(pm)

# Generated at 2022-06-21 14:35:37.261837
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    global Plugin
    class Plugin(BasePlugin):
        def __init__(self):
            self.value = 1
    plugin_manager = PluginManager()
    plugin = Plugin()
    plugin_manager.register(plugin)
    assert plugin in plugin_manager


# Generated at 2022-06-21 14:35:44.084255
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugins.register(entry_point.load())
    assert plugins.get_converters() != None


# Generated at 2022-06-21 14:35:48.777934
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugin = BasePlugin()
    plugins.register(plugin)
    assert plugin in plugins.filter()
    plugins.unregister(plugin)
    assert plugin not in plugins.filter()
    assert len(plugins.filter()) == 0


# Generated at 2022-06-21 14:35:55.151072
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class PluginA(object):
        group_name = 'group-a'
    class PluginB(object):
        group_name = 'group-b'
    class PluginC(object):
        group_name = 'group-b'
    class PluginD(object):
        group_name = 'group-b'

    plugins = PluginManager()
    plugins.register(PluginA, PluginB, PluginC, PluginD)
    expected = {'group-a':[PluginA], 'group-b':[PluginB, PluginC, PluginD]}

    assert plugins.get_formatters_grouped() == expected

# Generated at 2022-06-21 14:35:55.717723
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert True

# Generated at 2022-06-21 14:36:03.387443
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import JSONConverter, JSONPConverter, URLEncodeConverter

    assert PluginManager().get_converters() == []

    pm = PluginManager()
    pm.register(JSONConverter, JSONPConverter, URLEncodeConverter)

    assert pm.get_converters() == [JSONConverter, JSONPConverter, URLEncodeConverter]

# Generated at 2022-06-21 14:36:05.755805
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    print("Starting test_PluginManager_get_converters for class PluginManager")
    result = PluginManager()
    assert len(result) == 0

# Generated at 2022-06-21 14:36:09.376003
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin('bearer')
    # TODO: CI is not stable under Windows
    # assert plugin_manager.get_auth_plugin('oauth2')

# Generated at 2022-06-21 14:36:13.641583
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    transport_plugins = PluginManager().get_transport_plugins()

# Generated at 2022-06-21 14:36:15.617179
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    result = PluginManager().__repr__()
    print(result)
    assert result == '<PluginManager: []>'



# Generated at 2022-06-21 14:36:21.398810
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    assert len(pm.get_auth_plugins()) > 0, 'At least one Auth plugin'
    assert len(pm.get_converters()) > 0, 'At least one Converter plugin'
    assert len(pm.get_formatters()) > 0, 'At least one Formatter plugin'
    assert len(pm.get_transport_plugins()) > 0, 'At least one Transport plugin'



# Generated at 2022-06-21 14:36:22.916309
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginmanager = PluginManager()


# Generated at 2022-06-21 14:36:26.350384
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    formatters = pluginManager.get_formatters()
    assert len(formatters) > 0


# Generated at 2022-06-21 14:36:33.187705
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    import httpie.plugins.transport.http
    import httpie.plugins.transport.urllib3
    import httpie.plugins.transport.curl
    all_transport_plugins = [
        plugin for plugin in PluginManager.get_transport_plugins()
        if plugin != TransportPlugin
    ]
    assert len(all_transport_plugins) == 5
    assert httpie.plugins.transport.http.HTTPTransportPlugin in all_transport_plugins
    assert httpie.plugins.transport.urllib3.Urllib3TransportPlugin in all_transport_plugins
    assert httpie.plugins.transport.curl.CurlTransportPlugin in all_transport_plugins

managers = {
    'httpie': PluginManager(),
}

_manager_default = managers['httpie']


# Generated at 2022-06-21 14:36:35.725407
# Unit test for method register of class PluginManager
def test_PluginManager_register():
	manager = PluginManager()
	manager.register(AuthPlugin, FormatterPlugin)
	lst = [AuthPlugin, FormatterPlugin]
	assert manager == lst


# Generated at 2022-06-21 14:36:41.431706
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    pluginManager.register(ConverterPlugin)
    assert pluginManager.get_converters() == [ConverterPlugin]

# Generated at 2022-06-21 14:36:43.200384
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    #for i in pm.get_formatters():
    #    print(i)


# Generated at 2022-06-21 14:36:45.097886
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    items = [1, 2, 3]
    plugin_manager = PluginManager(items)
    assert repr(plugin_manager) == '<PluginManager: [1, 2, 3]>'

# Generated at 2022-06-21 14:36:46.355167
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()


# Singleton
plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-21 14:36:47.476161
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager().get_formatters()


# Generated at 2022-06-21 14:36:48.810076
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager, PluginManager)

# Generated at 2022-06-21 14:36:49.873888
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    assert str(manager) == '<PluginManager: %s>' % manager

# Generated at 2022-06-21 14:36:53.599636
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.builtin import HTTPiePlugin
    pm = PluginManager()
    pm.register(HTTPiePlugin)
    assert len(pm) == 1
    assert pm[0]== HTTPiePlugin


# Generated at 2022-06-21 14:37:00.604768
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    from httpie.plugins.builtin import AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin
    auth_plugin_1 = AuthPlugin()
    auth_plugin_2 = AuthPlugin()
    pm.register(auth_plugin_1, auth_plugin_2)
    pm.unregister(auth_plugin_2)
    assert(auth_plugin_1 in pm.get_auth_plugins() and auth_plugin_2 not in pm.get_auth_plugins())

# Generated at 2022-06-21 14:37:10.317357
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins.builtin_plugins import HTTPBasicAuth
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import JSONFormatter

    # 构造一个PluginManager对象
    manager = PluginManager()
    # 注册三个插件
    manager.register(JSONFormatter, JSONStreamFormatter, HTTPBasicAuth)
    # 删除已注册的一个插件
    manager.unregister(HTTPBasicAuth)
    # 筛选出当前注册的所有插件
    print(manager.filter(FormatterPlugin))
    #

# Generated at 2022-06-21 14:37:20.786794
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register(TestConverterPlugin)
    assert manager.get_converters() == [TestConverterPlugin]


# Generated at 2022-06-21 14:37:25.428803
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == [], "Constructor of class PluginManager does not initialize PluginManager with an empty list."
    print("test_pluginmanager_constructor: Constructor of class PluginManager initializes PluginManager with an empty list.")



# Generated at 2022-06-21 14:37:36.247511
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert(len(plugin_manager)==0)
    plugin_manager.register(py_no_color.PyNoColorConverter)
    plugin_manager.register(json_name_color.JsonNameColorConverter)
    plugin_manager.register(json_value_color.JsonValueColorConverter)
    plugin_manager.register(json_syntax_color.JsonSyntaxColorConverter)
    plugin_manager.register(json_no_color.JsonNoColorConverter)
    plugin_manager.register(xml_syntax_color.XmlSyntaxColorConverter)
    plugin_manager.register(http_syntax_color.HttpSyntaxColorConverter)

# Generated at 2022-06-21 14:37:39.127286
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in mapping.keys()
    assert 'digest' in mapping.keys()



# Generated at 2022-06-21 14:37:48.035903
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Arrange
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_list=plugin_manager.get_auth_plugins()
    # Act
    auth_plugin_list=plugin_manager.get_auth_plugins()
    actual_auth_plugin_list=auth_plugin_list
    # Assert
    assert actual_auth_plugin_list is not None
    # print(actual_auth_plugin_list)
    assert len(actual_auth_plugin_list) == 5


# Generated at 2022-06-21 14:37:49.786945
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {}



# Generated at 2022-06-21 14:37:51.314193
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager().get_converters()
    assert plugins



# Generated at 2022-06-21 14:37:57.849460
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'Group 1'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'Group 1'
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'Group 2'
    class FormatterPlugin4(FormatterPlugin):
        group_name = ''
    class AuthPlugin1(AuthPlugin):
        auth_type = 'AuthPlugin1'
    class TransportPlugin1(TransportPlugin):
        name = 'TransportPlugin1'
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins.register(FormatterPlugin1)
    plugins.register(FormatterPlugin2)
    plugins.register(FormatterPlugin3)
    plugins.register(FormatterPlugin4)
    plugins.register(AuthPlugin1)
   

# Generated at 2022-06-21 14:38:02.986713
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(HTTPBasicAuthPlugin)
    manager.register(HTTPDigestAuthPlugin)
    assert manager.get_auth_plugin('basic') == HTTPBasicAuthPlugin
    assert manager.get_auth_plugin('digest') == HTTPDigestAuthPlugin

# Generated at 2022-06-21 14:38:04.037201
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert isinstance(PluginManager(), PluginManager)

# Generated at 2022-06-21 14:38:24.308003
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager.get_auth_plugins()) > 0
    assert len(pluginManager.get_auth_plugin_mapping()) > 0
    assert pluginManager.get_auth_plugin("basic")
    assert len(pluginManager.get_formatters()) > 0
    assert len(pluginManager.get_converters()) > 0
    assert len(pluginManager.get_transport_plugins()) > 0


# Generated at 2022-06-21 14:38:35.204864
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin(): 
    plugin_manager = PluginManager()

    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)

    plugin_manager.get_auth_plugin("basic")
    plugin_manager.get_auth_plugin("bearer")
    plugin_manager.get_auth_plugin("client-certs")
    plugin_manager.get_auth_plugin("digest")
    plugin_manager.get_auth_plugin("httpie-password")
    plugin_manager.get_auth_plugin("jwt")
    plugin_manager.get_auth_plugin("multi-dict")
    plugin_manager.get_auth_plugin("oauth2")
    plugin_manager.get_auth_plugin("hawk")
    plugin_manager.get_auth_plugin("any-auth")



# Generated at 2022-06-21 14:38:36.936851
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    assert isinstance(manager, list)


# Generated at 2022-06-21 14:38:39.070805
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginManager = PluginManager()
    class test1:
        pass
    class test2:
        pass
    pluginManager.register(test1, test2)
    assert len(pluginManager)==2
    pluginManager.unregister(test1)
    assert len(pluginManager)==1

# Generated at 2022-06-21 14:38:47.078242
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import DEFAULT as DEFAULT_GROUP_NAME
    from httpie.plugins import FormatterPlugin

    class MockFormatterPlugin(FormatterPlugin):
        group_name = DEFAULT_GROUP_NAME
        name = 'MockFormatterPlugin'

    class MockFormatterPlugin1(FormatterPlugin):
        group_name = 'test_group'
        name = 'MockFormatterPlugin1'

    class MockFormatterPlugin2(FormatterPlugin):
        group_name = 'test_group'
        name = 'MockFormatterPlugin2'

    plugin_manager = PluginManager()
    plugin_manager.register(MockFormatterPlugin, MockFormatterPlugin1, MockFormatterPlugin2)
    formatters_grouped = plugin_manager.get_formatters_grouped()

# Generated at 2022-06-21 14:38:52.620390
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_list = PluginManager.get_converters()
    expected_list = [{'name': 'json', 'group_name': 'converters', 'priority': 1000}]
    assert plugin_list == expected_list, "ERROR in get_converters()"

    
# Unit test get_formatters_grouped()

# Generated at 2022-06-21 14:38:54.480466
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()


# Generated at 2022-06-21 14:38:56.581445
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    p = PluginManager()
    p.load_installed_plugins()
    print(p.get_auth_plugin_mapping())


# Generated at 2022-06-21 14:38:57.340886
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert len(PluginManager().get_formatters()) == 0



# Generated at 2022-06-21 14:39:00.672283
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    #vars(pm)
    print(pm)

if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-21 14:39:40.190196
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.auth import AuthPluginV1

    class Test1AuthPlugin(AuthPlugin):
        auth_type = 'test1'

    class Test2AuthPlugin(AuthPlugin):
        auth_type = 'test2'

    class Test3AuthPlugin(AuthPluginV1):
        auth_type = 'test3'

    # 实例化一个PluginManager类的对象
    pm = PluginManager()

    # 注册 Test1AuthPlugin 和 Test2AuthPlugin
    pm.register(Test1AuthPlugin, Test2AuthPlugin)

    # 获取字典 {auth_type: plugin}
    ret1 = pm.get_auth_plugin_mapping()

    # 注册 Test

# Generated at 2022-06-21 14:39:42.107036
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'


# Generated at 2022-06-21 14:39:47.378006
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    """
    The function test the method get_auth_plugin
    of class PluginManager to check if it gets
    the correct plugin for the Argument parser.
    """
    test_plugin_manager = PluginManager()
    test_plugin_manager.load_installed_plugins()
    httpie_plugin = test_plugin_manager.get_auth_plugin("http-auth")
    assert httpie_plugin.auth_type == "http-auth"

# test get_formatters_grouped() of class PluginManager

# Generated at 2022-06-21 14:39:49.116074
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager().get_transport_plugins() == []



# Generated at 2022-06-21 14:39:51.264618
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager([1, 2])) == '<PluginManager: [1, 2]>'

# Generated at 2022-06-21 14:39:54.709244
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.register(BasicAuthPlugin, DigestAuthPlugin)
    assert len(manager.get_auth_plugins()) == 2
    assert manager.get_auth_plugins() == [BasicAuthPlugin, DigestAuthPlugin]

# Generated at 2022-06-21 14:40:02.618037
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register()
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(TestAuthPlugin1, TestAuthPlugin2, TestAuthPlugin3)
    assert plugin_manager.get_auth_plugin_mapping() == {
        'test1': TestAuthPlugin1,
        'test2': TestAuthPlugin2,
        'test3': TestAuthPlugin3,
    }
    plugin_manager.unregister(TestAuthPlugin2)
    assert plugin_manager.get_auth_plugin_mapping() == {
        'test1': TestAuthPlugin1,
        'test3': TestAuthPlugin3,
    }


# Generated at 2022-06-21 14:40:12.426470
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
# Set the return values
    class BasePlugin:
        pass
    class AuthPlugin(BasePlugin):
        pass
    class FormatterPlugin(BasePlugin):
        pass
    class ConverterPlugin(BasePlugin):
        pass
    class TransportPlugin(BasePlugin):
        pass
    class AnotherPlugin(BasePlugin):
        pass
    class AnotherPlugin2(FormatterPlugin):
        pass
    class AnotherPlugin3(AuthPlugin):
        pass
    class AnotherPlugin4(ConverterPlugin):
        pass
    class AnotherPlugin5(TransportPlugin):
        pass

# Create a PluginManager
    plugin_manager = PluginManager()

# Generated at 2022-06-21 14:40:14.615029
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginManager = PluginManager()
    assert pluginManager.get_auth_plugins() == []
    pluginManager.register(JSONAuthPlugin, BasicAuthPlugin)

    assert pluginManager.get_auth_plugins() == [JSONAuthPlugin, BasicAuthPlugin]



# Generated at 2022-06-21 14:40:20.551712
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    pm.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert pm.get_auth_plugins() == [AuthPlugin]
    assert pm.get_formatters() == [FormatterPlugin]
    assert pm.get_converters() == [ConverterPlugin]
    assert pm.get_transport_plugins() == [TransportPlugin]
    pm.unregister(AuthPlugin)
    assert pm.get_auth_plugins() == []
test_PluginManager()

# Generated at 2022-06-21 14:41:42.289401
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class A(FormatterPlugin):
        group_name = 'a'
    class B(FormatterPlugin):
        group_name = 'b'
    class C(FormatterPlugin):
        group_name = 'b'

    mgr = PluginManager()
    mgr.register(A)
    mgr.register(B)
    mgr.register(C)

    assert mgr.get_formatters_grouped() == {'a': [A], 'b': [B, C]}

# Generated at 2022-06-21 14:41:49.057741
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pluginManager = PluginManager()
    pluginManager.register(HttpAdmin)
    
    pluginManager.filter(by_type=HttpAdmin)
    print(pluginManager.filter(by_type=HttpAdmin))
    assert(isinstance(pluginManager.filter(by_type=HttpAdmin),list))
    
    
plugins = PluginManager()
plugins.load_installed_plugins()
test_PluginManager_filter()

# Generated at 2022-06-21 14:41:50.314595
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert json.dumps(PluginManager().get_converters()) == '[]'

# Generated at 2022-06-21 14:41:51.975808
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    assert type(pm.get_auth_plugins) == list



# Generated at 2022-06-21 14:41:57.159636
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    """
    Testing whether the get_formatters method of class PluginManager gives the list of all the formatters registered
    in httpie.plugins.formatter
    """
    pm = PluginManager()
    pm.load_installed_plugins()
    formatter_plugins = pm.get_formatters()
    for plugin in formatter_plugins:
        assert issubclass(plugin, FormatterPlugin)
        

# Generated at 2022-06-21 14:41:58.998283
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager.get_auth_plugins() == list(self.filter(AuthPlugin))



# Generated at 2022-06-21 14:42:00.485526
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register()
    print(plugins.get_formatters_grouped())

# Generated at 2022-06-21 14:42:05.250079
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class JSONPlugin(FormatterPlugin):
        group_name = 'first group'
    class HTMLPlugin(FormatterPlugin):
        group_name = 'second group'
    class XMLPlugin(FormatterPlugin):
        group_name = 'first group'
    class XMLLPlugin(FormatterPlugin):
        group_name = 'second group'
    plugins = PluginManager([JSONPlugin, XMLPlugin, HTMLPlugin, XMLLPlugin])
    assert plugins.get_formatters_grouped() == {
        'first group': [JSONPlugin, XMLPlugin],
        'second group': [HTMLPlugin, XMLLPlugin]
    }

# Generated at 2022-06-21 14:42:06.642688
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    print(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-21 14:42:10.016359
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(CredentialsAuthPlugin)
    manager.register(TokenAuthPlugin)
    assert manager.get_auth_plugin_mapping() == {'credentials': CredentialsAuthPlugin, 'token': TokenAuthPlugin}