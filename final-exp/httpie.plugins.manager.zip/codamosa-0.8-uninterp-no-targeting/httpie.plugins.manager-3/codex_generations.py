

# Generated at 2022-06-21 14:34:30.948047
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    list_plugins = [
        'httpie.plugins.auth.v1',
        'httpie.plugins.formatter.v1',
        'httpie.plugins.converter.v1',
        'httpie.plugins.transport.v1',
        'httpie.plugins.base'
    ]

    for plugin in list_plugins:
        if plugin.split('.')[1] == 'formatter':
            print(plugin)


# Generated at 2022-06-21 14:34:32.045641
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert len(PluginManager()) == 0


# Generated at 2022-06-21 14:34:36.440910
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins_mgr = PluginManager()
    plugins_mgr.load_installed_plugins()
    transport_plugins = plugins_mgr.get_transport_plugins()
    assert len(transport_plugins) is 1
    assert transport_plugins[0].__name__ == 'HTTPAdapter'

# Generated at 2022-06-21 14:34:42.853764
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # GIVEN
    # Create a plugin manager
    plugin_manager = PluginManager()
    # Register the FakeFormatterPlugin
    plugin_manager.register(FakeFormatterPlugin)
    # WHEN
    # Retrieve the grouped formatters
    grouped_formatters = plugin_manager.get_formatters_grouped()
    # THEN
    # Retrieve the list of formatters for the group 'fake'
    assert len(grouped_formatters['fake']) == 1
    assert grouped_formatters['fake'][0] is FakeFormatterPlugin

# Generated at 2022-06-21 14:34:44.687435
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm.__repr__() != ''

# Generated at 2022-06-21 14:34:56.813750
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterA(FormatterPlugin):
        name = "NameA"
        group_name = "Group-1"

    class FormatterB(FormatterPlugin):
        name = "NameB"
        group_name = "Group-1"

    class FormatterC(FormatterPlugin):
        name = "NameC"
        group_name = "Group-2"

    class FormatterD(FormatterPlugin):
        name = "NameD"
        group_name = "Group-2"

    class FormatterE(FormatterPlugin):
        name = "NameE"
        group_name = "Group-3"

    plugins = PluginManager()
    plugins.register(FormatterA, FormatterB, FormatterC, FormatterD, FormatterE)

# Generated at 2022-06-21 14:35:01.058181
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert(plugin_manager.get_transport_plugins() == [])
    plugin_manager.register(TransportPlugin)
    assert(plugin_manager.get_transport_plugins() == [TransportPlugin])


# Generated at 2022-06-21 14:35:06.117907
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    # -- setup
    mock_iter_plugin_entry_points = MagicMock()
    mock_iter_plugin_entry_points.entry_point.return_value.load.return_value = BasePlugin()

    with patch('httpie.plugins.manager.iter_entry_points', iter_entry_points):
        # -- test
        plugins = PluginManager()
        plugins.load_installed_plugins()

        assert len(plugins) == 1



# Generated at 2022-06-21 14:35:11.437082
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    print('Testing __repr__ of class PluginManager')
    manager = PluginManager()
    manager.register(AuthPlugin)
    manager.register(FormatterPlugin)
    manager.register(TransportPlugin)
    print(manager)
    assert manager == list(manager)
test_PluginManager___repr__()


# Generated at 2022-06-21 14:35:18.011508
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    class TestAuthenticationPlugin(AuthPlugin):
        name = 'TestAuthenticationPlugin'
        auth_type = 'test'

    assert TestAuthenticationPlugin not in pm
    pm.register(TestAuthenticationPlugin)
    assert TestAuthenticationPlugin in pm

    assert pm.get_auth_plugins() == [TestAuthenticationPlugin]

# Generated at 2022-06-21 14:35:27.700395
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie.plugins.builtin
    httpie.plugins.builtin.load_plugins()
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # assert isinstance(plugin_manager.get_formatters_grouped(),dict)
    # assert isinstance(plugin_manager.get_formatters_grouped()['group_name'],list)
    # assert isinstance(plugin_manager.get_formatters_grouped()['group_name'][0],type)
    # assert issubclass(plugin_manager.get_formatters_grouped()['group_name'][0],FormatterPlugin)
    assert isinstance(plugin_manager.get_formatters_grouped(), dict)
    assert isinstance(plugin_manager.get_formatters_grouped()['group_name'], list)

# Generated at 2022-06-21 14:35:31.785831
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugins() == [AuthPlugin]
    pm.unregister(AuthPlugin)
    assert pm.get_auth_plugins() == []

# Generated at 2022-06-21 14:35:41.822220
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class FormatterA(FormatterPlugin):
        group_name = 'name'
        group_title = 'title'
        output_stream_class = None
    class FormatterB(FormatterPlugin):
        group_name = 'name'
        group_title = 'title'
        output_stream_class = None
    class FormatterC(FormatterPlugin):
        group_name = 'name'
        group_title = 'title'
        output_stream_class = None
    class PluginManagerA(PluginManager):
        pass
    pl_manager = PluginManager()
    pl_manager.register(FormatterA,FormatterB,FormatterC)
    act = pl_manager.get_formatters()
    exp = [FormatterA,FormatterB,FormatterC]
    assert act == exp


# Generated at 2022-06-21 14:35:46.521131
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_converters()) == 2


pm = PluginManager()
pm.load_installed_plugins()

if __name__ == '__main__':
    test_PluginManager_get_converters()

# Generated at 2022-06-21 14:35:48.621396
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    assert manager.get_auth_plugin('basic') is None


# Generated at 2022-06-21 14:35:54.220096
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import httpie.plugins as plugins

    plugin_manager = PluginManager()
    plugin_manager.register(plugins.FormatterPlugin)
    plugin_manager.register(plugins.AuthPlugin)

    assert plugin_manager.filter(Type[BasePlugin]) == [plugins.FormatterPlugin, plugins.AuthPlugin]
    assert plugin_manager.filter(Type[AuthPlugin]) == [plugins.AuthPlugin]
    assert plugin_manager.filter(Type[FormatterPlugin]) == [plugins.FormatterPlugin]

# Generated at 2022-06-21 14:35:58.354039
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin = PluginManager()
    plugin.load_installed_plugins()
    assert len(plugin.get_formatters_grouped()) == 3


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-21 14:36:04.708792
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert repr(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.auth.AuthPlugin\'>, <class \'httpie.plugins.converter.ConverterPlugin\'>, <class \'httpie.plugins.format.FormatterPlugin\'>, <class \'httpie.plugins.transport.TransportPlugin\'>]>'


# Generated at 2022-06-21 14:36:10.693925
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    """
    Check the output of the repr function for the PluginManager object when the argument is a list of plugins.
    """
    plugins = PluginManager()
    plugins.register(AuthBasicPlugin, AuthPlugin)
    if repr(plugins) != '<PluginManager: [AuthBasicPlugin, AuthPlugin]>':
        raise AssertionError("repr function of class PluginManager gives wrong output.")


# Generated at 2022-06-21 14:36:16.790730
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    pm.register()
    pm.unregister()
    pm.filter(Type[BasePlugin])
    pm.load_installed_plugins()
    pm.get_auth_plugins()
    pm.get_auth_plugin_mapping()
    pm.get_auth_plugin(auth_type="")
    pm.get_formatters()
    pm.get_formatters_grouped()
    pm.get_converters()
    pm.get_transport_plugins()
    str(pm)

# Generated at 2022-06-21 14:36:20.284264
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager.register(1)
    assert PluginManager == 1


# Generated at 2022-06-21 14:36:30.824294
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(BoxJsonPlugin,
                            BoxJsonLinesPlugin,
                            BoxJsonRawPlugin,
                            BoxJsonPrettyPlugin,
                            BoxJsonpPlugin,
                            BoxJsonpLinesPlugin,
                            BoxJsonpPrettyPlugin,
                            BoxJsonpRawPlugin,
                            BoxJsonStreamPlugin,
                            BoxJsonPrettyStreamPlugin,
                            JsonPlugin,
                            JsonLinesPlugin,
                            JsonpPlugin)

# Generated at 2022-06-21 14:36:33.122413
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    assert manager.get_transport_plugins() == []

# Generated at 2022-06-21 14:36:39.005636
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) !=0 and len(plugin_manager.get_auth_plugin_mapping()) !=0 and len(plugin_manager.get_formatters()) !=0 and len(plugin_manager.get_converters()) !=0
    print("Successful unit test for method load_installed_plugins of class PluginManager")


# Generated at 2022-06-21 14:36:41.642852
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugin = BasePlugin()
    plugins.register(plugin)
    assert "<PluginManager: [<class 'httpie.plugins.base.BasePlugin'>]>" == repr(plugins)


# Generated at 2022-06-21 14:36:45.624849
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class AuthPluginA(AuthPlugin):
        name = 'Test for AuthPluginA'
        auth_type = 'auth_a'

    plugin_manager = PluginManager()
    plugin_manager.register(AuthPluginA)
    assert len(plugin_manager.get_auth_plugins()) == 1
    plugin_manager.unregister(AuthPluginA)
    assert len(plugin_manager.get_auth_plugins()) == 0

# Generated at 2022-06-21 14:36:50.706596
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class TestA(BasePlugin):
        pass

    class TestB(TestA):
        pass

    class TestC(TestA):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(TestA)
    plugin_manager.register(TestB)
    plugin_manager.register(TestC)

    assert plugin_manager.filter(BasePlugin) == [TestA, TestB, TestC]
    assert plugin_manager.filter(TestA) == [TestA, TestB, TestC]
    assert plugin_manager.filter(TestB) == [TestB,]
    assert plugin_manager.filter(TestC) == [TestC,]

# Generated at 2022-06-21 14:36:55.734248
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.register(BasePlugin)
    assert len(plugin_manager) == 1
    plugin_manager.unregister(BasePlugin)
    assert len(plugin_manager) == 0

# Generated at 2022-06-21 14:36:57.061752
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    # Arrange
    plugins = PluginManager()
    plugins.register(TestAuthPlugin)
    # Act
    plugins.unregister(TestAuthPlugin)
    # Assert
    assert len(plugins) == 0



# Generated at 2022-06-21 14:36:59.309222
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert plugin_manager.register(TestPlugin1, TestPlugin2) == [TestPlugin1, TestPlugin2]



# Generated at 2022-06-21 14:37:03.130979
# Unit test for method register of class PluginManager
def test_PluginManager_register():   
    pm = PluginManager()
    pm.register(BasePlugin)
    assert pm == [BasePlugin]


# Generated at 2022-06-21 14:37:07.077519
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Unit test for method load_installed_plugins of class PluginManager
    print("loading the installed plugins...")
    plugin=PluginManager()
    plugin.load_installed_plugins()
    print(f'len of plugin is {len(plugin)}')
    print('successful loading')


if __name__ == '__main__':
    print('test start')
    test_PluginManager_load_installed_plugins()
    print('test end')

# Generated at 2022-06-21 14:37:10.155093
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    assert set(plugins) == set()
    assert isinstance(plugins, list)

    plugins.register(AuthPlugin)
    assert plugins
    assert set(plugins) == {AuthPlugin}

    plugins.unregister(AuthPlugin)
    assert not plugins

# Generated at 2022-06-21 14:37:14.462135
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import httpie.plugins.auth
    assert PluginManager().filter(AuthPlugin) == [httpie.plugins.auth.DigestAuthPlugin]
    PluginManager().unregister(httpie.plugins.auth.DigestAuthPlugin)
    assert PluginManager().filter(AuthPlugin) == []
    assert PluginManager().filter(AuthPlugin) != [httpie.plugins.auth.DigestAuthPlugin]

# Generated at 2022-06-21 14:37:17.344074
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugins = plugin_manager.get_auth_plugins()
    assert len(plugins) == 1

# Generated at 2022-06-21 14:37:18.361628
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()

# Generated at 2022-06-21 14:37:19.527861
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()


# Generated at 2022-06-21 14:37:24.500349
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import JSONBodyConverter
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import HTTPieTransport
    pm = PluginManager()
    pm.register(HTTPBasicAuth, JSONBodyConverter, JSONFormatter, HTTPieTransport)
    print(pm.get_converters())



# Generated at 2022-06-21 14:37:35.780863
# Unit test for method get_formatters of class PluginManager

# Generated at 2022-06-21 14:37:37.974581
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    assert pm.get_converters() == []
    pm.register(PluginManager)
    assert pm.get_converters() == []

# Generated at 2022-06-21 14:37:42.804602
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    assert manager.get_auth_plugins() == []


# Generated at 2022-06-21 14:37:43.411136
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    Pass

# Generated at 2022-06-21 14:37:44.015705
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pass

# Generated at 2022-06-21 14:37:54.692432
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from .plugins import TransportPlugin
    from .plugins.builtin import (HTTP0Adapter, HTTP1Adapter,
                                  HTTP2Adapter, HTTP2CAdapter)
    from .plugins.builtin import (CryptographySSLAdapter,
                                  PyopensslSSLAdapter)

    # Test 1
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    plugins = plugin_manager.get_transport_plugins()
    assert HTTP0Adapter in plugins
    assert HTTP1Adapter in plugins
    assert HTTP2Adapter in plugins
    assert HTTP2CAdapter in plugins
    assert CryptographySSLAdapter in plugins
    assert PyopensslSSLAdapter in plugins

    # Test 2
    plugin_manager = PluginManager()
    plugin_manager.register(HTTP0Adapter, HTTP1Adapter)
    plugin_manager.load_installed_plugins()

    plugins

# Generated at 2022-06-21 14:37:55.612659
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager().register()

# Generated at 2022-06-21 14:37:56.980868
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager.get_auth_plugins()


manager = PluginManager()

# Generated at 2022-06-21 14:38:04.038010
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    assert len(plugins) == 0
    plugins.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert len(plugins) == 4
    plugins.unregister(AuthPlugin)
    assert len(plugins) == 3
    assert type(plugins[0]) == ConverterPlugin
    assert type(plugins[1]) == FormatterPlugin
    assert type(plugins[2]) == TransportPlugin


# Generated at 2022-06-21 14:38:06.276646
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.auth.builtin import BasicAuthPlugin, DigestAuthPlugin

    assert PluginManager().get_auth_plugin('basic') == BasicAuthPlugin
    assert PluginManager().get_auth_plugin('digest') == DigestAuthPlugin

# Generated at 2022-06-21 14:38:17.188067
# Unit test for method __repr__ of class PluginManager

# Generated at 2022-06-21 14:38:19.070219
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print(plugins)
    assert len(plugins)

# Generated at 2022-06-21 14:38:24.147243
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    auth_plugins = manager.get_auth_plugins()
    assert len(auth_plugins) == 2



# Generated at 2022-06-21 14:38:33.414918
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert AuthPlugin in manager
    manager.unregister(AuthPlugin)
    assert AuthPlugin not in manager
    manager.register(FormatterPlugin)
    assert FormatterPlugin in manager
    manager.unregister(FormatterPlugin)
    assert FormatterPlugin not in manager
    manager.register(ConverterPlugin)
    assert ConverterPlugin in manager
    manager.unregister(ConverterPlugin)
    assert ConverterPlugin not in manager
    manager.register(TransportPlugin)
    assert TransportPlugin in manager
    manager.unregister(TransportPlugin)
    assert TransportPlugin not in manager


# Generated at 2022-06-21 14:38:42.335754
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class A(BasePlugin):
        group_name = 'a'

    class AX(A):
        group_name = 'ax'

    class AY(A):
        group_name = 'ay'

    class B(BasePlugin):
        group_name = 'b'

    class C(BasePlugin):
        pass

    plugins = PluginManager()
    plugins.register(A, AX, AY, B, C)
    assert set(plugins.get_formatters()) == set([A, AX, AY, B])
    assert set(plugins.get_formatters_grouped()) == set({
        'a': [A, AX, AY],
        'b': [B],
    })

# Generated at 2022-06-21 14:38:45.149632
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.register(CsvFormatterPlugin)
    assert plugin_manager.get_formatters() == [CsvFormatterPlugin]


# Generated at 2022-06-21 14:38:47.972537
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([1, 2])) == '<PluginManager: [1, 2]>'

# Generated at 2022-06-21 14:38:59.197502
# Unit test for method filter of class PluginManager

# Generated at 2022-06-21 14:39:01.260734
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    print(plugin_manager)

PLUGINS = PluginManager()
PLUGINS.load_installed_plugins()

# Generated at 2022-06-21 14:39:08.375544
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    def get_plugin_manager():
        plugin_manager = PluginManager()
        plugin_manager.register(BasePlugin)
        plugin_manager.register(Type[BasePlugin])

        plugin_manager.register(AuthPlugin)
        plugin_manager.register(Type[AuthPlugin])

        plugin_manager.register(ConverterPlugin)
        plugin_manager.register(Type[ConverterPlugin])

        plugin_manager.register(FormatterPlugin)
        plugin_manager.register(Type[FormatterPlugin])

        plugin_manager.register(TransportPlugin)
        plugin_manager.register(Type[TransportPlugin])

        return plugin_manager

    plugin_manager = get_plugin_manager()
    assert len(plugin_manager) == 10
    assert len(plugin_manager.filter(by_type=AuthPlugin)) == 2

# Generated at 2022-06-21 14:39:11.458862
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_mgr = PluginManager()
    assert plugin_mgr.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-21 14:39:12.861934
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager.get_converters() == ['a']


# Generated at 2022-06-21 14:39:22.705879
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(MockPlugin)
    assert pm.get_converters() == [MockConverter], \
        "Failed Test PluginManager's method get_converters()"


if __name__ == '__main__':
    test_PluginManager_get_converters()

# Generated at 2022-06-21 14:39:26.913603
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter import JSONConverter, TextConverter
    from httpie.plugins.default import DEFAULT_CONVERTERS

    plugin_manager = PluginManager()
    plugin_manager.register(JSONConverter, TextConverter)
    result = plugin_manager.get_converters()
    assert result == DEFAULT_CONVERTERS


# Generated at 2022-06-21 14:39:34.039510
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Plugin1(FormatterPlugin):
        group_name = 'test1'
        name = 'test1'

    class Plugin2(FormatterPlugin):
        group_name = 'test1'
        name = 'test2'

    class Plugin3(FormatterPlugin):
        group_name = 'test2'
        name = 'test3'

    class Plugin4(FormatterPlugin):
        group_name = 'test2'
        name = 'test4'

    pm = PluginManager()

# Generated at 2022-06-21 14:39:38.164730
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin)
    transport_plugins = plugin_manager.get_transport_plugins()
    assert isinstance(transport_plugins, list)
    assert isinstance(transport_plugins[0], TransportPlugin)



# Generated at 2022-06-21 14:39:46.901178
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    test_data = """
        - test_data:
            status: 200
            body:
                an_union: one
        - test_data:
            status: 200
            body:
                an_union: two
        - test_data:
            status: 200
            body:
                an_union: three
        - test_data:
            status: 200
            body:
                an_union: four
    """
    pm = PluginManager()
    pm.register(TestConverter)
    converters = pm.get_converters()
    converter = converters[0]
    assert converter.from_text(test_data) == test_data



# Generated at 2022-06-21 14:39:53.576208
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(
        plugin1,
        plugin2,
        plugin3,
        plugin4,
    )
    assert manager.get_auth_plugin_mapping() == {
        'plugin1': plugin1,
        'plugin2': plugin2,
        'plugin3': plugin3,
        'plugin4': plugin4,
        'basic': plugin5,
    }
    pass


# Generated at 2022-06-21 14:39:59.896488
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.register(HTTPDigestAuth)
    plugin_manager.register(JWTAuth)
    assert plugin_manager.get_auth_plugin("basic") == HTTPBasicAuth
    assert plugin_manager.get_auth_plugin("digest") == HTTPDigestAuth
    assert plugin_manager.get_auth_plugin("jwt") == JWTAuth
    assert plugin_manager.get_auth_plugin("") is None

# Generated at 2022-06-21 14:40:04.862100
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    assert plugins.get_auth_plugin_mapping() == {}

    class FakeAuthPlugin:
        auth_type = 'fake'


    assert plugins.get_auth_plugin('fake') is None

    plugins.register(FakeAuthPlugin)

    assert plugins.get_auth_plugin('fake') is FakeAuthPlugin

    plugins.unregister(FakeAuthPlugin)

    assert plugins.get_auth_plugin('fake') is None


plugins = PluginManager()

# Generated at 2022-06-21 14:40:06.183551
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager(self)
    self.register()
    self.append()



# Generated at 2022-06-21 14:40:13.360490
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_plugin_manager = PluginManager()
    auth_plugin_manager.load_installed_plugins()
    auth_plugin_mapping = auth_plugin_manager.get_auth_plugin_mapping()
    for key, value in auth_plugin_mapping.items():
        print("{0}:{1}".format(key, value))

if __name__ == '__main__':
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-21 14:40:33.614077
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    L=[]
    plugin = PluginManager()
    L = plugin.get_auth_plugin_mapping()
    assert type(L) == type({})

# Generated at 2022-06-21 14:40:40.861076
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Test cases
    test_params = [(
        # get_auth_plugins()
        {"plugins_list": [AuthPlugin(), AuthPlugin()]},
        # Expected output
        {"output": 2}
    ), (
        # get_auth_plugins()
        {"plugins_list": [AuthPlugin(), AuthPlugin(), "test"]},
        # Expected output
        {"output": 2},
    )]
    # Check with each test case
    for (param, result) in test_params:
        # Create an PluginManager object
        plugins_manager = PluginManager()
        # Register plugins to the plugins manager
        plugins_manager.register(*param['plugins_list'])
        # Call the method to be tested
        auth_plugins = plugins_manager.get_auth_plugins()
        # Check the result

# Generated at 2022-06-21 14:40:44.116277
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin)
    pluginManager.register(FormatterPlugin)
    pluginManager.register(ConverterPlugin)
    pluginManager.register(TransportPlugin)
    assert len(pluginManager.get_converters()) == 1


# Generated at 2022-06-21 14:40:46.706711
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager.get_auth_plugins(), list)

# Generated at 2022-06-21 14:40:49.854856
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    p.register(AuthPlugin, AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

    assert p.filter(AuthPlugin) == [AuthPlugin, AuthPlugin]


plugin_manager = PluginManager()

# Generated at 2022-06-21 14:40:52.223017
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(PluginManager)

    assert pm.get_converters() == []


# Generated at 2022-06-21 14:40:55.379733
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Arrange
    plugin = PluginManager()
    plugin.load_installed_plugins()
    expected = 1
    # Act
    result = len(plugin.get_auth_plugins())
    # Assert
    assert result == expected



# Generated at 2022-06-21 14:40:59.141606
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {}
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_formatters_grouped() == {'colon': [], 'json': [], 'json-prettyprint': [], 'yaml': []}

# Generated at 2022-06-21 14:41:04.067446
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    groups = plugin_manager.get_formatters_grouped()
    assert isinstance(groups, dict)
    assert 'Addons' in groups.keys()
    assert 'Switches' in groups.keys()
    assert 'JSON' in groups.keys()
    assert 'Text' in groups.keys()
    assert 'XML' in groups.keys()


# Generated at 2022-06-21 14:41:14.394503
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, JSONLinesFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, TableFormatterPlugin, FormURLEncodedFormatterPlugin
    
    # 可以看出来FormatterPlugin的JSONFormatterPlugin,JSONLinesFormatterPlugin,PrettyJSONFormatterPlugin,RawJSONFormatterPlugin,TableFormatterPlugin,FormURLEncodedFormatterPlugin对应的group返回的都是json，这样就可以按照group进行分组
    # {'json': [<class 'httpie.plugins.builtin.JSONFormatterPlugin'>, <class 'httpie.plugins.builtin.JSONLinesFormatter

# Generated at 2022-06-21 14:41:41.937474
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
    )
    manager[2].group_name = 'A'
    manager[2].name = 'F'
    manager[4].group_name = 'A'
    manager[4].name = 'G'
    manager[0].group_name = 'C'
    manager[0].name = 'I'
    manager[3].group_name = 'B'
    manager[3].name = 'H'
    manager[1].group_name = 'B'
    manager[1].name = 'J'


# Generated at 2022-06-21 14:41:46.138704
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    p.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert AuthPlugin in p
    assert FormatterPlugin in p
    assert ConverterPlugin in p
    assert TransportPlugin in p


# Generated at 2022-06-21 14:41:49.967115
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert isinstance(plugins.get_auth_plugin('basic'), BasicAuthPlugin)
    assert isinstance(plugins.get_auth_plugin('digest'), DigestAuthPlugin)


# Generated at 2022-06-21 14:41:55.113132
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(None, None, None)
    assert manager.get_auth_plugin('auth_type') is None
    manager.unregister(None)
    assert manager.get_auth_plugin('auth_type') is None
    manager.register(BasePlugin)
    assert manager.get_auth_plugin('auth_type') is None

# Generated at 2022-06-21 14:41:56.858890
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert(isinstance(pm, List))
    assert(pm)


# Generated at 2022-06-21 14:41:58.327068
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert isinstance(PluginManager().get_converters(), list)


# Generated at 2022-06-21 14:42:05.014379
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import json
    import pytest
    from httpie.plugins.formatter.json import JSONFormatter

    # Create instance of PluginManager
    plugins = PluginManager()

    # Mock get_formatters method
    plugins.get_formatters = lambda : [JSONFormatter]

    # Call get_formatters_grouped method
    formatters_grouped = plugins.get_formatters_grouped()

    # Assert formatters_grouped['Group name'] == [JSONFormatter]
    assert formatters_grouped['Group name'] == [JSONFormatter]

    # Assert formatters_grouped['Group name'] == JSONFormatter
    assert formatters_grouped['Group name'] == JSONFormatter

# Generated at 2022-06-21 14:42:11.072181
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter import JsonTest, UrlencodedTest
    from httpie.plugins.converter.core import CoreConverters
    from httpie.plugins.converter.test import TestConverters
    plugins = PluginManager()
    plugins.register(TestConverters, CoreConverters)
    assert plugins.get_converters() == [
        JsonTest, UrlencodedTest
    ]

# Generated at 2022-06-21 14:42:21.354343
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import HTTPieTransportPlugin
    from httpie.plugins.builtin import CurlHTTPTransportPlugin
    from httpie.plugins.builtin import CurlHTTPSTransportPlugin
    from httpie.plugins.builtin import WgetTransportPlugin
    from httpie.plugins.builtin import WorkerTransportPlugin
    from httpie.plugins.builtin import DefaultTransportPlugin

    manager = PluginManager()
    manager.register(HTTPieTransportPlugin, CurlHTTPTransportPlugin, CurlHTTPSTransportPlugin, WgetTransportPlugin,
                     WorkerTransportPlugin, DefaultTransportPlugin)


# Generated at 2022-06-21 14:42:23.180597
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.load_installed_plugins()
    print(manager.get_auth_plugin('basic'))


# Generated at 2022-06-21 14:43:11.997745
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    A = BasePlugin.register
    class A(BasePlugin):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    class E(D):
        pass
    class F(E):
        pass
    X = A.register
    class X(A, TransportPlugin):
        pass
    class Y(X, C):
        pass
    class Z(Y):
        pass
    class W(Z, D):
        pass

    assert PluginManager().get_transport_plugins() == [W]
    # Currently, X and Z are also subclasses of TransportPlugin, but that
    # is likely to change soon.



# Generated at 2022-06-21 14:43:15.294409
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    p = PluginManager()

    assert p.get_converters() == []

    p.register(ConverterPlugin)
    assert p.get_converters() == [ConverterPlugin]

    p.register(ConverterPlugin)
    assert p.get_converters() == [ConverterPlugin, ConverterPlugin]


# Generated at 2022-06-21 14:43:16.189465
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin = PluginManager()
    assert plugin.get_converters() == []

# Generated at 2022-06-21 14:43:18.342192
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import HTTPiePlugin
    a = HTTPiePlugin()
    b = PluginManager()
    b.register(a)
    assert isinstance(b.get_transport_plugins()[0], HTTPiePlugin)

# Generated at 2022-06-21 14:43:20.473635
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print("Converters:", plugin_manager.get_converters())
    print("Auth:", plugin_manager.get_auth_plugins())


# Generated at 2022-06-21 14:43:23.320227
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    assert len(plugin_manager) == 1
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager) == 5



# Generated at 2022-06-21 14:43:28.004928
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    mapping = pluginmanager.get_auth_plugin_mapping()

# Generated at 2022-06-21 14:43:35.859466
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(PluginManager)
    plugins.unregister(PluginManager)
    assert not plugins

    plugins.register([PluginManager, PluginManager])
    plugins.unregister(PluginManager)
    assert not plugins

    plugins.register([PluginManager, PluginManager])
    plugins.unregister(PluginManager)
    assert not plugins

    plugins.register([
        PluginManager,
        PluginManager,
        PluginManager,
        PluginManager,
        PluginManager,
        PluginManager,
        PluginManager,
        PluginManager,
    ])
    plugins.unregister(PluginManager)
    assert not plugins



# Generated at 2022-06-21 14:43:37.547238
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    a = PluginManager()
    a.register(123, 456)
    assert len(a) == 2
    a.unregister(123)
    assert len(a) == 1

# Generated at 2022-06-21 14:43:42.830558
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins_manager = PluginManager()

    assert [] == plugins_manager.get_transport_plugins()

    # Not an adapter
    class NotAdapter(BasePlugin):
        pass

    plugins_manager.register(NotAdapter)
    assert [] == plugins_manager.get_transport_plugins()

    # An adapter
    class IsAdapter(TransportPlugin):
        pass

    plugins_manager.register(IsAdapter)
    assert [IsAdapter] == plugins_manager.get_transport_plugins()

    # Two adapters
    plugins_manager.register(IsAdapter)
    assert [IsAdapter, IsAdapter] == plugins_manager.get_transport_plugins()