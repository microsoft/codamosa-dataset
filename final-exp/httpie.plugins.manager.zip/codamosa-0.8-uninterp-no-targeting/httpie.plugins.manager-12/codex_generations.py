

# Generated at 2022-06-21 14:34:21.798865
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    newmanager = PluginManager()
    newmanager.load_installed_plugins()
    a = newmanager.get_auth_plugins()
    assert len(a) > 1
    assert all(isinstance(item, type) for item in a)


# Generated at 2022-06-21 14:34:31.351398
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    # create a PluginManager
    plugin_manager = PluginManager()
    assert (isinstance(plugin_manager, PluginManager))
    assert (len(plugin_manager) == 0)

    from httpie.plugins.builtin import HTTPiePlugin

    plugin_manager.register(HTTPiePlugin)
    # Before calling get_formatters, there is only one plugin registered.
    assert (len(plugin_manager) == 1)
    list_formats = plugin_manager.get_formatters()
    assert (isinstance(list_formats, list))
    assert (len(list_formats) > 0)


test_PluginManager_get_formatters()

# Generated at 2022-06-21 14:34:39.673377
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.__main__ import HTTPBasicAuth, HTTPDigestAuth
    def get_auth_plugin_mapping():
        return {
            'basic': HTTPBasicAuth,
            'digest': HTTPDigestAuth
        }
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPDigestAuth)
    assert plugin_manager.get_auth_plugin_mapping() == get_auth_plugin_mapping()
    assert plugin_manager.get_auth_plugin('basic') == get_auth_plugin_mapping()['basic']

# Generated at 2022-06-21 14:34:44.196667
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    auth_mapping = manager.get_auth_plugin_mapping()
    print(auth_mapping)
    assert auth_mapping == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'bearer': httpie.plugins.auth.bearer.BearerAuthPlugin
    }


# Generated at 2022-06-21 14:34:46.196176
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # f-string should be used for formatting the output
    assert '<PluginManager:' in str(PluginManager())

# Generated at 2022-06-21 14:34:55.068289
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    a = PluginManager()
    a.register(JSONConverter, URLEncodedConverter)
    res = a.get_converters()
    assert isinstance(res, list)
    assert len(res) == 2
    assert res[0] == JSONConverter
    assert res[1] == URLEncodedConverter



# Generated at 2022-06-21 14:34:56.649083
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class P1(BasePlugin):
        pass
    class P2(BasePlugin):
        pass
    class P3(BasePlugin):
        pass
    manager = PluginManager()
    manager.register(P1, P2)
    res = manager.filter(by_type=P1)
    assert res == [P1]



# Generated at 2022-06-21 14:35:03.669291
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = []
    plugins.append(AuthPlugin)
    plugins.append(TransportPlugin)
    plugins.append(ConverterPlugin)

    manager = PluginManager()
    manager.register(*plugins)
    assert len(manager.get_auth_plugin_mapping()) == 0

    manager.append(AuthPlugin)
    assert len(manager.get_auth_plugin_mapping()) == 1

    manager.remove(AuthPlugin)
    assert len(manager.get_auth_plugin_mapping()) == 0

    manager.extend(plugins)
    assert len(manager.get_auth_plugin_mapping()) == 0

    manager.insert(0, AuthPlugin)
    assert len(manager.get_auth_plugin_mapping()) == 1

# Generated at 2022-06-21 14:35:09.350872
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import sys
    print(sys.path)
    # TODO: For the moment, the unit test only works if httpie is installed
    if not PluginManager().load_installed_plugins:
        print("Do not work")
    else:
        print("Work")

# Generated at 2022-06-21 14:35:16.669656
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    class MyPlugin1(BasePlugin):
        pass

    class MyPlugin2(BasePlugin):
        pass

    class MyPlugin3(BasePlugin):
        pass

    class MyPlugin4(BasePlugin):
        pass

    pm = PluginManager()
    pm.register(MyPlugin1, MyPlugin2, MyPlugin3, MyPlugin4)
    
    assert pm.filter(MyPlugin1) == [MyPlugin1]
    assert pm.filter(MyPlugin2) == [MyPlugin2]
    assert pm.filter(MyPlugin3) == [MyPlugin3]
    assert pm.filter(MyPlugin4) == [MyPlugin4]

    assert pm.filter(BasePlugin) == [MyPlugin1, MyPlugin2, MyPlugin3, MyPlugin4]


a_plugin_manager = PluginManager()

# Generated at 2022-06-21 14:35:22.651594
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager) == 4


# Generated at 2022-06-21 14:35:27.129314
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = []
    class A(FormatterPlugin):
        group_name = 'a'
    class B(FormatterPlugin):
        group_name = 'a'
    class C(FormatterPlugin):
        group_name = 'b'
    plugins.append(A)
    plugins.append(B)
    plugins.append(C)
    result = {'a': [A, B], 'b': [C]}
    assert PluginManager().get_formatters_grouped() == result

# Generated at 2022-06-21 14:35:35.102402
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    import pytest
    p = PluginManager()
    assert p.__repr__() == '<PluginManager: []>'
    p.register('AuthPlugin')
    assert p.__repr__() == "<PluginManager: ['AuthPlugin']>"
    p.register('ConverterPlugin')
    assert p.__repr__() == "<PluginManager: ['AuthPlugin', 'ConverterPlugin']>"
    with pytest.raises(TypeError):
        p.register(1)

plugins = PluginManager()

# Generated at 2022-06-21 14:35:39.241044
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    assert repr(manager) == '<PluginManager: []>'
    manager.register(A, B)
    assert repr(manager) == '<PluginManager: [<class \'tests.test_plugins.A\'>, <class \'tests.test_plugins.B\'>]>'


# Generated at 2022-06-21 14:35:48.434454
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    def test_filter_with_parameter_by_type_as_Type_BasePlugin(self):
        pm = PluginManager([])
        assert pm.filter(by_type=BasePlugin) == []

        pm = PluginManager([BasePlugin])
        assert pm.filter(by_type=BasePlugin) == [BasePlugin]

        pm = PluginManager([AuthPlugin, ConverterPlugin])
        assert pm.filter(by_type=BasePlugin) == [AuthPlugin, ConverterPlugin]

        pm = PluginManager([FormatterPlugin, TransportPlugin])
        assert pm.filter(by_type=BasePlugin) == [FormatterPlugin, TransportPlugin]

# Generated at 2022-06-21 14:35:51.954267
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    pm.register(ConverterPlugin)
    assert pm.get_converters()[0].__name__ == "ConverterPlugin"

# Generated at 2022-06-21 14:35:55.264355
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.register(TestPlugin1)
    manager.register(TestPlugin2)
    assert manager.get_transport_plugins() == [TestPlugin1, TestPlugin2]


# Generated at 2022-06-21 14:35:58.601175
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import __version__

    plugins = PluginManager()
    assert not plugins

    plugins.load_installed_plugins()
    assert plugins



# Generated at 2022-06-21 14:36:00.752588
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager.get_converters == '<bound method PluginManager.get_converters of <PluginManager: []>>'


# Generated at 2022-06-21 14:36:03.824628
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_list = PluginManager()
    plugin_list.append(classmethod)
    plugin_list.append(list)
    assert plugin_list.filter(list) == [list]


# Generated at 2022-06-21 14:36:13.865473
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import BuiltinTransportPlugin
    from httpie.plugins.http.transport import HTTPTransport
    from httpie.plugins.httpie.transport import HTTPieTransport
    from httpie.plugins.curl.transport import CurlTransport
    from httpie.plugins.wget.transport import WgetTransport

    assert PluginManager().get_transport_plugins() == [
        BuiltinTransportPlugin,
        HTTPTransport,
        HTTPieTransport,
        CurlTransport,
        WgetTransport,
    ]

# Generated at 2022-06-21 14:36:15.146171
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager().get_transport_plugins() == []



# Generated at 2022-06-21 14:36:20.894313
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    class TestPlugin(BasePlugin):
        pass

    class TestPlugin1(TestPlugin):
        pass

    class TestPlugin2(TestPlugin):
        pass

    pm = PluginManager()
    pm.register(TestPlugin1, TestPlugin2)

    assert set(pm.filter(TestPlugin)) == {TestPlugin1, TestPlugin2}
    assert pm.filter(AuthPlugin) == []
    assert set(pm.filter(TestPlugin1)) == {TestPlugin1}

# Generated at 2022-06-21 14:36:31.198601
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import auth
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.hawk import HawkAuthPlugin
    from httpie.plugins.auth.jwt import JWTAuthPlugin
    from httpie.plugins.auth.multiauth import MultiAuthPlugin
    from httpie.plugins.auth.ntlm import NTLMAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1Plugin
    from httpie.plugins.auth.oauth2 import OAuth2Plugin

    # Create a plugin manager
    plugin_manager = PluginManager()

    # Register plugins to the manager

# Generated at 2022-06-21 14:36:36.139220
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister(): 
    print('Start testing function unregister of class PluginManager')
    manager = PluginManager()

    manager.register('hi', 'there')

    assert manager == ['hi', 'there']

    manager.unregister('hi')

    assert manager == ['there']

    print('Function unregister of class PluginManager works fine')


# Generated at 2022-06-21 14:36:42.670344
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()        # Create the instance of PluginManager
    manager.register(2)              # Test the input is an int type
    manager.register(2,23)           # Test the input is a tuple type
    manager.register([1,2,3])        # Test the input is a list type
    manager.register(lambda: 22)     # Test the input is a lambda expression
    manager.register("test")         # Test the input is a string type
    print("Passed the test for method register of class PluginManager")



# Generated at 2022-06-21 14:36:44.057540
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.get_transport_plugins() == []

# Generated at 2022-06-21 14:36:45.592726
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_formatters()


# Generated at 2022-06-21 14:36:47.576745
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    plugin = BasePlugin
    pm.register(plugin)
    assert len(pm) == 1
    pm.unregister(plugin)
    assert len(pm) == 0


# Generated at 2022-06-21 14:36:55.786407
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(MockTransport1, MockTransport2)
    plugin_manager.register(MockAuth, MockFormatter)
    assert len(plugin_manager.get_transport_plugins()) == 2
    assert {MockTransport1, MockTransport2} == set(
        plugin_manager.get_transport_plugins()
    )
    assert {MockAuth, MockFormatter} == set(plugin_manager)


# Generated at 2022-06-21 14:37:07.415501
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JsonPoetFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonPoetFormatterPlugin

    pm = PluginManager()
    pm.register(FormatterPlugin, JSONFormatterPlugin, PrettyJSONFormatterPlugin, JsonPoetFormatterPlugin, PrettyJsonPoetFormatterPlugin)
    pm.get_formatters_grouped()



# Generated at 2022-06-21 14:37:09.876981
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert isinstance(pm.get_formatters(), list)
    assert len(pm.get_formatters()) is 2


# Generated at 2022-06-21 14:37:11.234445
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert len(PluginManager().filter()) == 0
    assert PluginManager.filter.__doc__ == 'Return all plugins of the specified type.'

# Generated at 2022-06-21 14:37:13.660955
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert repr(pm) == '<PluginManager: []>'
    pm.register(str)
    assert repr(pm) == "<PluginManager: [<class 'str'>]>"

# Generated at 2022-06-21 14:37:21.894791
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test'

    class TestAuthPlugin2(AuthPlugin):
        auth_type: str = 'test2'

    class TestAuthPlugin3(AuthPlugin):
        auth_type: str = 'test3'

    p = PluginManager()
    p.register(TestAuthPlugin, TestAuthPlugin2, TestAuthPlugin3)

    assert p.get_auth_plugin('test') is TestAuthPlugin
    assert p.get_auth_plugin('test2') is TestAuthPlugin2
    assert p.get_auth_plugin('test3') is TestAuthPlugin3

# Generated at 2022-06-21 14:37:24.506245
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    assert manager.get_auth_plugin("basic") is basic_auth



# Generated at 2022-06-21 14:37:29.172542
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(TestAuthPlugin)
    plugin_manager.register(TestAuthPlugin2)
    plugin_manager.append(TestItem)
    assert plugin_manager.get_auth_plugins() == [TestAuthPlugin, TestAuthPlugin2]


# Generated at 2022-06-21 14:37:33.562247
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import httpie.plugins
    httpie.plugins.manager = PluginManager()
    httpie.plugins.manager.load_installed_plugins()

    assert httpie.plugins.manager is not None
    assert len(httpie.plugins.manager) > 0



# Generated at 2022-06-21 14:37:37.778743
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_map = plugin_manager.get_auth_plugin_mapping()
    plugin_keys = plugin_map.keys()
    plugin_vals = plugin_map.values()
    assert hasattr(plugin_vals[0],'auth_type')

# Generated at 2022-06-21 14:37:41.130258
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p1 = PluginManager()
    p1.register(BasePlugin)
    p1.register(TransportPlugin)
    p1.register(AuthPlugin)
    p1.register(FormatterPlugin)
    p1.register(ConverterPlugin)
    assert p1.get_transport_plugins() == [TransportPlugin]



# Generated at 2022-06-21 14:37:46.530761
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(Test_Auth_Plugin)
    assert(plugin_manager.get_auth_plugin("test") == Test_Auth_Plugin)


# Generated at 2022-06-21 14:37:51.052612
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {
        'AuthPlugin': AuthPlugin
    }
    plugin_manager.unregister(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}


# Generated at 2022-06-21 14:37:55.382074
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    import httpie.plugins.auth
    plugin_manager.register(httpie.plugins.auth.BasicAuth, httpie.plugins.auth.JWTAuth)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': httpie.plugins.auth.BasicAuth, 'jwt': httpie.plugins.auth.JWTAuth}

# Generated at 2022-06-21 14:37:57.245769
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
	PluginManager_1 = PluginManager()
	assert(PluginManager_1.filter() == list())

# Generated at 2022-06-21 14:38:00.441826
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) != 0


# Generated at 2022-06-21 14:38:04.037159
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.load_installed_plugins()
    plugin = manager.filter(AuthPlugin)
    assert len(plugin) == 1
    assert isinstance(plugin[0], AuthPlugin), "Not an auth plugin."

# Generated at 2022-06-21 14:38:05.359087
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager().get_transport_plugins() == []


# Generated at 2022-06-21 14:38:08.555728
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_types = {
        'basic': 'httpie.plugins.auth.basic.BasicAuthPlugin'
    }
    assert PluginManager().get_auth_plugin_mapping() == auth_types


# Generated at 2022-06-21 14:38:12.451846
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    auth_plugin = Type[AuthPlugin]
    plugin_manager.register(auth_plugin)
    result = plugin_manager.get_auth_plugins()
    assert result == [auth_plugin]


# Generated at 2022-06-21 14:38:14.519340
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {}

# Generated at 2022-06-21 14:38:22.512206
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth
    from httpie.plugins.base import BasePlugin

    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    for plugin in pm:
        assert issubclass(plugin, BasePlugin)
    assert HTTPBasicAuth in pm
    assert HTTPBearerAuth in pm

# Generated at 2022-06-21 14:38:26.060152
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    PluginManager_ = PluginManager()
    PluginManager_.register(PluginManager)
    assert repr(PluginManager_) == '<PluginManager: [<class \'httpie.plugins.manager.PluginManager\'>]>'


# Generated at 2022-06-21 14:38:37.086739
# Unit test for constructor of class PluginManager
def test_PluginManager():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin

    class TestPlugin(FormatterPlugin):
        pass

    class OtherPlugin(FormatterPlugin):
        pass

    class AnotherPlugin(TransportPlugin):
        pass

    class AnotherTransportPlugin(TransportPlugin):
        pass

    class SamplePlugin(AuthPlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin)
    plugin_manager.register(AnotherTransportPlugin)
    plugin_manager.register(SamplePlugin)
    plugin_manager.register(AnotherPlugin)
    plugin_manager.register(OtherPlugin)
    assert(isinstance(plugin_manager, PluginManager))
    assert(TestPlugin in plugin_manager)
    assert(OtherPlugin in plugin_manager)

# Generated at 2022-06-21 14:38:40.206092
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()

    class Plugin(BasePlugin):
        pass

    plugins.register(Plugin)

    assert isinstance(plugins.filter()[0], Plugin)
    assert type(plugins.filter()[0]) == Plugin

# Generated at 2022-06-21 14:38:42.083101
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm.get_auth_plugin_mapping())



# Generated at 2022-06-21 14:38:51.012531
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.append(object)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.append(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    auth_plugin = type('AuthPlugin', (AuthPlugin, object), {})
    plugin_manager.append(auth_plugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    auth_plugin.auth_type = 'HTTPie'
    assert plugin_manager.get_auth_plugin_mapping() == {'HTTPie': auth_plugin}

# Generated at 2022-06-21 14:38:53.211261
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin('Bearer')

# Generated at 2022-06-21 14:38:57.230834
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    class plugin1(BasePlugin):
        pass
    class plugin2(BasePlugin):
        pass
    p.register(plugin1, plugin2)
    print(p)
    assert p == [plugin1, plugin2]


# Generated at 2022-06-21 14:38:58.553808
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class testplugin():
        pass
    tp = testplugin
    pm.register(tp)
    assert pm[0] == tp


# Generated at 2022-06-21 14:39:02.948833
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.auth.basic.base import BasicAuthPlugin
    import httpie.plugins.auth.digest.base
    assert PluginManager().get_auth_plugin('basic') is BasicAuthPlugin
    assert PluginManager().get_auth_plugin('digest') is httpie.plugins.auth.digest.base.DigestAuthPlugin

# Generated at 2022-06-21 14:39:13.698729
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugin('aws4') == \
           manager.get_auth_plugin_mapping()['aws4']

# Generated at 2022-06-21 14:39:22.098489
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin


    # class BasePlugin:
    #     name = None
    #     description = None
    #     version = None
    #     priority = 0


    # class AuthPlugin(BasePlugin):
    #     auth_type = None
    #     scheme = None
    #     auth_require = False


    # class FormatterPlugin(BasePlugin):
    #     group_name = None


    # class ConverterPlugin(BasePlugin):
    #     pass


    # class TransportPlugin(BasePlugin):
    #     pass


    # plugin_manager.py

# Generated at 2022-06-21 14:39:29.993896
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    p.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert len(p.get_auth_plugins()) == 1
    assert p.get_auth_plugins()[0] == AuthPlugin
    assert len(p.get_converters()) == 1
    assert p.get_converters()[0] == ConverterPlugin
    assert len(p.get_formatters()) == 1
    assert p.get_formatters()[0] == FormatterPlugin
    assert len(p.get_transport_plugins()) == 1
    assert p.get_transport_plugins()[0] == TransportPlugin

# Generated at 2022-06-21 14:39:35.320096
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager == []
    plugin_manager.load_installed_plugins()
    assert plugin_manager != []
    transport_adapters = plugin_manager.get_transport_plugins()
    assert transport_adapters != []

# Generated at 2022-06-21 14:39:46.208969
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    def check_map(manager):
        got = manager.get_auth_plugin_mapping()
        assert got['basic'] == auth_plugin1
        assert got['digest'] == auth_plugin2
        assert got['hmac'] == auth_plugin3
        assert got['aws-sigv4'] == auth_plugin4

    auth_plugin1 = type('BasicAuthPlugin', (AuthPlugin,), {'auth_type': 'basic'})
    auth_plugin2 = type('DigestAuthPlugin', (AuthPlugin,), {'auth_type': 'digest'})
    auth_plugin3 = type('HMACAuthPlugin', (AuthPlugin,), {'auth_type': 'hmac'})

# Generated at 2022-06-21 14:39:49.116056
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_auth_plugins()) >= 5


# Generated at 2022-06-21 14:39:57.356907
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(PluginA):
        pass

    class PluginC(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB, PluginC)

    assert plugin_manager.filter() == [PluginA, PluginB, PluginC]
    assert plugin_manager.filter(by_type=PluginA) == [PluginA, PluginB]
    assert plugin_manager.filter(by_type=PluginB) == [PluginB]
    assert plugin_manager.filter(by_type=PluginC) == [PluginC]


# Generated at 2022-06-21 14:40:03.368997
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    def foo():
        pass
    class PluginBar(BasePlugin):
        pass
    class PluginFoo(BasePlugin):
        pass
    p = PluginManager()
    p.load_installed_plugins()
    for plugin in p:
        if plugin.__name__ == 'PluginFoo':
            foo_plugin = plugin
        if plugin.__name__ == 'PluginBar':
            bar_plugin = plugin
    p.unregister(foo_plugin)
    p.unregister(bar_plugin)
    ls = p.filter()
    assert ls == []

# Generated at 2022-06-21 14:40:13.404900
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # when
    PLUGIN_A = BasePlugin
    PLUGIN_B = AuthPlugin
    PLUGIN_C = FormatterPlugin
    PLUGIN_D = ConverterPlugin
    PLUGIN_E = TransportPlugin

    manager = PluginManager()
    manager.register(PLUGIN_A, PLUGIN_B, PLUGIN_C, PLUGIN_D, PLUGIN_E)

    # then
    assert PLUGIN_A in manager.filter(BasePlugin)
    assert PLUGIN_B in manager.filter(AuthPlugin)
    assert PLUGIN_C in manager.filter(FormatterPlugin)
    assert PLUGIN_D in manager.filter(ConverterPlugin)
    assert PLUGIN_E in manager.filter(TransportPlugin)


# Generated at 2022-06-21 14:40:19.040554
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    import pytest
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin

    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    pluginManager.unregister(AuthPlugin)
    assert pluginManager.__repr__() == '<PluginManager: [<class \'httpie.plugins.formatter.base.FormatterPlugin\'>, <class \'httpie.plugins.converter.base.ConverterPlugin\'>, <class \'httpie.plugins.transport.base.TransportPlugin\'>]>'
    with pytest.raises(ValueError):
        pluginManager.unregister(AuthPlugin)


# Generated at 2022-06-21 14:40:41.047615
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(auth_plugin.BaseAuthPlugin)
    plugins.register(formatter_plugin.BaseFormatterPlugin)
    plugins.register(converter_plugin.BaseConverterPlugin)
    plugins.register(transport_plugin.BaseTransportPlugin)
    assert plugins.filter() == [auth_plugin.BaseAuthPlugin,
                                formatter_plugin.BaseFormatterPlugin,
                                converter_plugin.BaseConverterPlugin,
                                transport_plugin.BaseTransportPlugin]
    assert plugins.filter(auth_plugin.BaseAuthPlugin) == [auth_plugin.BaseAuthPlugin]

# Generated at 2022-06-21 14:40:48.022913
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_plugin_manager = PluginManager()
    auth_plugin_manager.register(DigestAuthPlugin)
    auth_plugin_manager.register(BasicAuthPlugin)
    auth_plugin_manager.register(BearerAuthPlugin)

    # DigestAuthPlugin
    assert isinstance(auth_plugin_manager.get_auth_plugins()[0], DigestAuthPlugin)

    # BasicAuthPlugin
    assert isinstance(auth_plugin_manager.get_auth_plugins()[1], BasicAuthPlugin)

    # BearerAuthPlugin
    assert isinstance(auth_plugin_manager.get_auth_plugins()[2], BearerAuthPlugin)

# Generated at 2022-06-21 14:40:53.397810
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    # plugin_class is a class which inherit from BasePlugin
    class plug_1(BasePlugin):
        name = 'plug_1'
        # ...

    class plug_2(BasePlugin):
        name = 'plug_2'

    pm.register(plug_1, plug_2)
    # ...
    pm.unregister(plug_2)


# Generated at 2022-06-21 14:40:59.037058
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters_grouped()
    assert 'Generic' in formatters and 'Output Processing' in formatters
    assert 'Auto' in formatters['Generic'] and 'Json' in formatters['Generic']
    assert 'Pretty' in formatters['Output Processing'] and 'Table' in formatters['Output Processing']
    assert 'Pygments' in formatters and 'Browser' in formatters and 'Images' in formatters

# Generated at 2022-06-21 14:41:00.710937
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    assert list(plugins.get_formatters()) != None


# Generated at 2022-06-21 14:41:07.038075
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Setup
    plugin_list_mock = [1,2,3,4]
    plugin_manager_mock = PluginManager()
    plugin_manager_mock.filter = MagicMock(return_value=plugin_list_mock)

    # Exercise
    actual = plugin_manager_mock.get_auth_plugins()

    # Verify
    plugin_manager_mock.filter.assert_called_once_with(AuthPlugin)
    assert actual == plugin_list_mock


# Generated at 2022-06-21 14:41:08.344947
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'

plugin_manager = PluginManager()

# Generated at 2022-06-21 14:41:11.374172
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert list(PluginManager().get_auth_plugin_mapping().keys()) == ['basic', 'digest', 'ntlm']

# Generated at 2022-06-21 14:41:13.458639
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    plugins = pm.register(AuthPlugin)
    assert len(pm) > 0
    pm.unregister(AuthPlugin)
    assert len(pm) == 0

# Generated at 2022-06-21 14:41:20.387986
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins = plugin_manager.get_auth_plugin_mapping()
    assert len(auth_plugins) != 0
    new_plugin_manager = PluginManager()
    new_plugin_manager.register(AuthBasicPlugin)
    assert new_plugin_manager.get_auth_plugin_mapping()['basic'] == AuthBasicPlugin
    new_plugin_manager.unregister(AuthBasicPlugin)
    assert new_plugin_manager.get_auth_plugin_mapping()['basic'] == None
    # assert new_plugin_manager.get_auth_plugin_mapping()['basic'] == None # make sure AuthBasicPlugin was unregistered


# Generated at 2022-06-21 14:42:04.610670
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.register(None)
    with pytest.raises(KeyError):
        assert pm.get_auth_plugin('something')

    class Plugin1(AuthPlugin):
        auth_type = 'plugin1'

    class Plugin2(AuthPlugin):
        auth_type = 'plugin2'

    class FakePlugin(BasePlugin):
        pass

    pm.register(Plugin1)
    pm.register(Plugin2)
    assert pm.get_auth_plugin('plugin1') == Plugin1
    assert pm.get_auth_plugin('plugin2') == Plugin2

    with pytest.raises(KeyError):
        assert pm.get_auth_plugin('plugin3')

    pm.register(FakePlugin)

# Generated at 2022-06-21 14:42:07.474838
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginManager = PluginManager()
    assert len(pluginManager) == 0
    pluginManager.register(AuthPlugin)
    assert len(pluginManager) == 1
    pluginManager.unregister(AuthPlugin)
    assert len(pluginManager) == 0

# Generated at 2022-06-21 14:42:08.840546
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager_object = PluginManager()
    assert isinstance(pluginManager_object, list)

# Generated at 2022-06-21 14:42:11.241872
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert isinstance(plugins, list)
    assert isinstance(plugins, PluginManager)

# Generated at 2022-06-21 14:42:17.203803
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import httpie.plugins.builtin
    lst = PluginManager()
    lst.register(httpie.plugins.builtin.HTTPBasicAuthPlugin)
    lst.register(httpie.plugins.builtin.HTTPBearerAuthPlugin)
    lst.register(httpie.plugins.builtin.HTTPBasicAuthPlugin)
    assert len(lst.filter()) == 3
    assert len(lst.filter(AuthPlugin)) == 2


# Generated at 2022-06-21 14:42:18.213848
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager()


# Generated at 2022-06-21 14:42:19.952092
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    PluginManager1 = PluginManager()
    assert PluginManager1.get_converters() == []

# Generated at 2022-06-21 14:42:23.921213
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugin_mapping()['basic'] == plugins[0]
    assert plugins.get_auth_plugin_mapping()['digest'] == plugins[1]
    assert plugins.get_auth_plugin_mapping()['hawk'] == plugins[2]


# Generated at 2022-06-21 14:42:35.435703
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from .builtin import BuiltinAuthPlugin, BuiltinFormatOption, BuiltinFormatPlugin
    from .keen_io import KeenIOAuthPlugin
    from .key_value import KeyValue, KeyValueConverter
    from .raw import RawJSONFormatPlugin
    from .json_lines import JSONLinesFormatPlugin
    from .pretty import PrettyJSONFormatPlugin
    from .http import HTTPTransportPlugin
    from .httpie import HttpiePlugin

    plugins = PluginManager()

    plugins.load_installed_plugins()

    # auth
    assert KeenIOAuthPlugin in plugins
    assert BuiltinAuthPlugin in plugins

    # converter
    assert KeyValueConverter in plugins

    # formatter
    assert RawJSONFormatPlugin in plugins
    assert JSONLinesFormatPlugin in plugins
    assert PrettyJSONFormatPlugin in plugins
    assert BuiltinFormatPlugin in plugins



# Generated at 2022-06-21 14:42:37.682975
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert AuthPlugin in manager
    manager.unregister(AuthPlugin)
    assert AuthPlugin not in manager


# Generated at 2022-06-21 14:44:19.904384
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()

    class AuthPluginX(AuthPlugin):
        auth_type = 'x'

    class AuthPluginY(AuthPlugin):
        auth_type = 'y'

    plugin_manager.register(AuthPluginX, AuthPluginY)

    assert plugin_manager.get_auth_plugin('x') is AuthPluginX
    assert plugin_manager.get_auth_plugin('y') is AuthPluginY
    # Unit test for method get_formatters_grouped of class PluginManager
    def test_PluginManager_get_formatters_grouped():
        plugin_manager = PluginManager()

        class FormatterPluginA(FormatterPlugin):
            group_name = 'a'

        class FormatterPluginB(FormatterPlugin):
            group_name = 'b'
