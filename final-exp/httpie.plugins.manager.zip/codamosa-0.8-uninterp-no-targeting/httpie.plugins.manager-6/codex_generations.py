

# Generated at 2022-06-21 14:34:23.379953
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert len(pm) == 0

    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test-auth'

    class TestFormatterPlugin(FormatterPlugin):
        format = 'test-format'

    class TestConverterPlugin(ConverterPlugin):
        content_types = ['test-type']

    assert TestAuthPlugin not in pm
    assert TestFormatterPlugin not in pm
    assert TestConverterPlugin not in pm

    pm.register(TestAuthPlugin, TestFormatterPlugin, TestConverterPlugin)

    assert TestAuthPlugin in pm
    assert TestFormatterPlugin in pm
    assert TestConverterPlugin in pm

    assert len(pm) == 3


# Generated at 2022-06-21 14:34:32.208058
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert isinstance(pm, list)
    assert isinstance(pm, PluginManager)
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert isinstance(pm.get_transport_plugins(), list)
    assert all([isinstance(e, Type) for e in pm.get_transport_plugins()])
    assert all([issubclass(e, TransportPlugin) for e in pm.get_transport_plugins()])
    assert len(pm.get_transport_plugins()) > 1

plugin_manager = PluginManager()

# Generated at 2022-06-21 14:34:33.647788
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    assert len(pm.get_converters()) > 0

# Generated at 2022-06-21 14:34:39.173518
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthBasicPlugin, AuthDigestPlugin)
    assert str(pm.get_auth_plugin_mapping()) == \
        "{'basic': <class 'httpie.plugins.auth.basic.AuthBasicPlugin'>, " \
        "'digest': <class 'httpie.plugins.auth.digest.AuthDigestPlugin'>}"



# Generated at 2022-06-21 14:34:41.315198
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    pm.register('a', 'b', 'c')
    pm.unregister('b')
    assert pm == ['a', 'c']

# Generated at 2022-06-21 14:34:49.129055
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONPathFormatter

    class TestPlugin(FormatterPlugin):
        group_name = 'test'
        group_priority = 0

    class TestPlugin2(FormatterPlugin):
        group_name = 'test'
        group_priority = 2

    class TestPlugin3(FormatterPlugin):
        group_name = 'test'
        group_priority = 1

    class TestPlugin4(FormatterPlugin):
        group_name = 'test2'
        group_priority = 0

    list_plugin = [ TestPlugin, TestPlugin2, TestPlugin3, TestPlugin4]
    plugin_manager = PluginManager(list_plugin).get_formatters_grouped()

    assert 'test' in plugin_manager
    assert TestPlugin3 in plugin_manager['test']

# Generated at 2022-06-21 14:35:00.432370
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    def assert_registred(obj, plugin):
        assert plugin in obj
        assert len(obj) > 0

    plugins = PluginManager()
    plugins.register(FakePlugin)
    assert_registred(plugins, FakePlugin)
    
    plugins.register(FakePlugin, FakePlugin)
    assert_registred(plugins, FakePlugin)
    
    plugins.register(FakePlugin(), FakePlugin)
    assert_registred(plugins, FakePlugin)
    
    plugins.register(FakePlugin, FakePlugin(), FakePlugin)
    assert_registred(plugins, FakePlugin)
    
    plugins.register(FakePlugin(), FakePlugin, FakePlugin())
    assert_registred(plugins, FakePlugin)
    
    plugins.register([FakePlugin(), FakePlugin, FakePlugin()])

# Generated at 2022-06-21 14:35:04.255422
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
	plugin_manager = PluginManager()
	plugin_manager.load_installed_plugins()
	plugin_manager.register(TestAuthPlugin)
	auth_plugins = plugin_manager.get_auth_plugins()
	assert type(auth_plugins) is list
	assert len(auth_plugins) > 0


# Generated at 2022-06-21 14:35:12.223506
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm.get_transport_plugins() == [
        httpie.plugins.transport.http.HTTPTransport,
        httpie.plugins.transport.https.HTTPSTransport,
        httpie.plugins.transport.unixsocket.UnixSocketTransport,
        httpie.plugins.transport.httpie.HTTPieTransport,
    ]  # noqa: E501

# Generated at 2022-06-21 14:35:16.099380
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()

    pm.register(AuthPlugin)
    pm.register(FormatterPlugin)

    assert issubclass(pm[0], AuthPlugin)
    assert issubclass(pm[1], FormatterPlugin)


# Generated at 2022-06-21 14:35:23.338755
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(MockFormatter1, MockFormatter2, MockFormatter3)

# Generated at 2022-06-21 14:35:34.509659
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import JSON
    from httpie.core import http
    from httpie.plugins.builtin import (
        HTTPDebugger, HTTPieDebugger, HTTPPrettyPrinter,
        HTTPVerboseTracer, UnixStreamTracer
    )

    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import UnixStream

    local_plugins = [
        UnixStreamTracer,
        HTTPVerboseTracer,
        HTTPieDebugger,
        HTTPDebugger,
        HTTPPrettyPrinter,
        JSON,
    ]
    formatters = PluginManager()
    formatters.register(*local_plugins)

    assert formatters.get_formatters() == local_plugins

    # Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-21 14:35:38.175978
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Foo:
        pass
    t = PluginManager()
    a = t.append(Foo)
    b = t.unregister(Foo)
    assert a == None
    assert b == None
    assert t == []

# Unit test

# Generated at 2022-06-21 14:35:46.143028
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plug = PluginManager()
    plugin_map = plug.get_auth_plugin_mapping()
    assert plugin_map['basic'] == plugin_map['bearer']\
        == plugin_map['digest'] == plugin_map['aws4-hmac-sha256'] == plugin_map['awsv4'] == plugin_map['hawk'] == plugin_map['oauth1'] == plugin_map['ntlm']\
        == plugin_map['jwt'] == plugin_map['hawk-auth']

# Generated at 2022-06-21 14:35:55.126507
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    class NonePlugin(FormatterPlugin):
        group_name = None
        name = 'none'
        output_type = None

    class SpecificPlugin(FormatterPlugin):
        group_name = 'specific'
        name = 'specific'
        output_type = 'specific'

    class GeneralPlugin(FormatterPlugin):
        group_name = 'specific'
        name = 'general'
        output_type = 'general'

    plugins = PluginManager()
    plugins.register(NonePlugin, SpecificPlugin, GeneralPlugin)
    grouped = plugins.get_formatters_grouped()
    assert grouped[FormatterPlugin.group_name] == [NonePlugin]
    assert grouped['specific'] == [SpecificPlugin]


plugin_manager = PluginManager()
plugin_manager.register(NonePlugin)
plugin_manager.load_installed_plugins()

# Generated at 2022-06-21 14:35:56.832587
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert isinstance(PluginManager().get_formatters(), list)


# Generated at 2022-06-21 14:36:00.896948
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(TransportPlugin)
    assert len(pm.get_transport_plugins()) == 0
    pm.unregister(TransportPlugin)
    assert len(pm.get_transport_plugins()) == 0



# Generated at 2022-06-21 14:36:07.107321
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    try:
        import httpie.plugins.formatter.v1 as httpie_plugins_formatter_v1
    except ImportError:
        pytest.skip("Couldn't import httpie.plugins.formatter.v1")
    manager = PluginManager()
    manager.register(httpie_plugins_formatter_v1.JsonFormatter)
    assert [httpie_plugins_formatter_v1.JsonFormatter] == manager.get_formatters()


# Generated at 2022-06-21 14:36:11.322031
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(FormatterPlugin, FormatterPlugin)
    assert len(plugins.get_formatters()) == 2
    assert all(issubclass(p, FormatterPlugin) for p in plugins.get_formatters())

# Generated at 2022-06-21 14:36:20.099548
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {}
    plugin_manager.register(MockFormatterPlugin1,MockFormatterPlugin2,MockFormatterPlugin3,MockFormatterPlugin4)
    assert plugin_manager.get_formatters_grouped() == {'name1': [MockFormatterPlugin1, MockFormatterPlugin2], 'name2': [MockFormatterPlugin3, MockFormatterPlugin4]}
    plugin_manager.unregister(MockFormatterPlugin1)
    plugin_manager.unregister(MockFormatterPlugin2)
    assert plugin_manager.get_formatters_grouped() == {'name2': [MockFormatterPlugin3, MockFormatterPlugin4]}

# Generated at 2022-06-21 14:36:32.049798
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    
    class my_plugin(FormatterPlugin):
        name = 'my_plugin'
        media_types = ['my_plugin']
        type = 'my_plugin'
    
    class your_plugin(FormatterPlugin):
        name = 'your_plugin'
        media_types = ['your_plugin']
        type = 'your_plugin'
        
    plugins = PluginManager()
    
    plugins.register(my_plugin)
    plugins.register(your_plugin)
    
    formatters = plugins.get_formatters()
    # print(formatters)
    assert formatters[0] == my_plugin
    assert formatters[1] == your_plugin
    
test_PluginManager_get_formatters()


# Generated at 2022-06-21 14:36:34.201585
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    manager.register(PluginManager)
    assert manager.get_formatters() == [PluginManager]

# Generated at 2022-06-21 14:36:36.947288
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(FormatterPlugin)
    assert pm.get_formatters_grouped() == {'BaseFormatterPlugin': [FormatterPlugin]}

# Generated at 2022-06-21 14:36:42.747196
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert len(manager.filter(AuthPlugin)) == 1
    manager.register(AuthPlugin)
    assert len(manager.filter(AuthPlugin)) == 2
    manager.unregister(AuthPlugin)
    assert len(manager.filter(AuthPlugin)) == 1
    manager.unregister(AuthPlugin)
    assert len(manager.filter(AuthPlugin)) == 0
    manager.append(AuthPlugin)
    assert len(manager.filter(AuthPlugin)) == 1

# Generated at 2022-06-21 14:36:46.277864
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    manager.register(BasePlugin)
    assert str(manager) == "<PluginManager: [<class 'httpie.plugins.base.BasePlugin'>]>"


plugin_manager = PluginManager()

# Generated at 2022-06-21 14:36:47.489533
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    PluginManager_obj = PluginManager()
    print(PluginManager_obj.get_converters())


# Generated at 2022-06-21 14:36:50.187661
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    
    # test
    assert pm.filter(by_type=Type[BasePlugin]) == []



# Generated at 2022-06-21 14:36:52.612076
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert type(pm.get_auth_plugins()) == list


# Generated at 2022-06-21 14:37:01.115067
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.output.formatters.json import JSONFormatterPlugin
    from httpie.output.formatters.http import HTTPFormatterPlugin
    from httpie.output.formatters.html import HTMLFormatterPlugin

    plugin = PluginManager()
    plugin.register(JSONFormatterPlugin(), HTTPFormatterPlugin(), HTMLFormatterPlugin)
    test = {'JSON': [JSONFormatterPlugin], 'HTTP': [HTTPFormatterPlugin]}
    result = {'JSON': [JSONFormatterPlugin], 'HTTP': [HTTPFormatterPlugin], 'HTML': [HTMLFormatterPlugin]}
    assert plugin.get_formatters_grouped() == result

# Generated at 2022-06-21 14:37:04.253357
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    converters = plugins.get_converters()
    print(converters)

# Generated at 2022-06-21 14:37:18.670454
# Unit test for constructor of class PluginManager
def test_PluginManager():  # NOQA
    plugins = PluginManager()

    assert plugins.register
    assert plugins.unregister
    assert plugins.filter
    assert plugins.load_installed_plugins
    assert plugins.get_auth_plugins
    assert plugins.get_auth_plugin_mapping
    assert plugins.get_auth_plugin
    assert plugins.get_formatters
    assert plugins.get_formatters_grouped
    assert plugins.get_converters
    assert plugins.get_transport_plugins

# Generated at 2022-06-21 14:37:25.041323
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert 0 == len(plugins)
    assert str(plugins) == '<PluginManager: []>'
    plugins.register(BasePlugin)
    assert 1 == len(plugins)
    plugins.register(BasePlugin)
    assert 2 == len(plugins)
    plugins.unregister(BasePlugin)
    assert 1 == len(plugins)
    plugin_type = BasePlugin
    plugins.unregister(plugin_type)
    assert 0 == len(plugins)
    assert str(plugins) == '<PluginManager: []>'


# Generated at 2022-06-21 14:37:33.610853
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    assert plugins.filter() == []
    class BasePlugin1(BasePlugin): pass
    class BasePlugin2(BasePlugin): pass
    class BasePlugin3(BasePlugin): pass
    plugins.register(BasePlugin1, BasePlugin2)
    assert plugins.filter() == [BasePlugin1, BasePlugin2]
    assert plugins.filter(BasePlugin1) == [BasePlugin1]
    plugins.register(BasePlugin3)
    assert plugins.filter() == [BasePlugin1, BasePlugin2, BasePlugin3]
    assert plugins.filter(BasePlugin1) == [BasePlugin1]

# Generated at 2022-06-21 14:37:41.516119
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugins_list = [
        {'auth_type': 'basic', 'doc': 'Basic auth.'},
        {'auth_type': 'digest', 'doc': 'Digest auth.'},
        {'auth_type': 'bearer-token', 'doc': 'Bearer token auth.'}
    ]
    plugin_manager.register(*[
        MockPlugin(plugin['auth_type'], plugin['doc'])
        for plugin in plugins_list
    ])

    expected_result = {
        plugin['auth_type']: MockPlugin(plugin['auth_type'], plugin['doc'])
        for plugin in plugins_list
    }

    assert plugin_manager.get_auth_plugin_mapping() == expected_result


# Generated at 2022-06-21 14:37:46.632699
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import HTTPBasicAuth, JSONConverter, JSONPrettyFormatter, KeyValueConverter, URLEncodedFormAuth
    assert PluginManager().get_converters() == [
        JSONConverter, KeyValueConverter
        ]


# Generated at 2022-06-21 14:37:48.391842
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    x = PluginManager()
    x.register(TransportPlugin)
    x.get_transport_plugins()

# Generated at 2022-06-21 14:37:56.621756
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from .colors import SolarizedColors
    from .formatters import SolarizedFormatter
    solarizedColors = SolarizedColors(Group('test'))
    solarizedColors.group_name = 'test'
    solarizedColors.name = 'test'
    solarizedColors2 = SolarizedColors(Group('test'))
    solarizedColors2.group_name = 'test2'
    solarizedColors2.name = 'test2'
    formatterList = []
    formatterList.append(solarizedColors)
    formatterList.append(solarizedColors2)
    solarizedFormatter = SolarizedFormatter(Group('test'))
    solarizedFormatter.group_name = 'test'
    solarizedFormatter.name = 'test'

# Generated at 2022-06-21 14:38:08.211521
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    result = PluginManager()
    result.register(type('a', (AuthPlugin,), {'name':'a'}))
    result.register(type('a', (AuthPlugin,), {'name':'a'}))
    result.register(type('a', (AuthPlugin,), {'name':'a'}))
    result.register(type('a', (AuthPlugin,), {'name':'a'}))
    assert result.__repr__() == '<PluginManager: [<class \'a\'>, <class \'a\'>, <class \'a\'>, <class \'a\'>]>'
    result.register(type('a', (AuthPlugin,), {'name':'a'}))

# Generated at 2022-06-21 14:38:09.998964
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    print(PluginManager())


plugin_manager = PluginManager()

# Generated at 2022-06-21 14:38:13.026053
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager.get_formatters_grouped(), dict)


# Generated at 2022-06-21 14:38:48.227187
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Given
    class Dummy:
        def __init__(self, auth_type):
            self.auth_type = auth_type

        def __repr__(self):
            return f'<Dummy: {self.auth_type}>'

    dummy_plugin1 = Dummy(auth_type='basic')
    dummy_plugin2 = Dummy(auth_type='digest')

    manager = PluginManager()
    manager.register(dummy_plugin1, dummy_plugin2)

    # When
    plugin = manager.get_auth_plugin('digest')

    # Then
    assert plugin is dummy_plugin2

# Generated at 2022-06-21 14:38:56.281024
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie import plugins  # noqa
    
    class Plugin1(plugins.ConverterPlugin):
        convert_mimetype = 'application/x-test1'

    class Plugin2(plugins.ConverterPlugin):
        convert_mimetype = 'application/x-test2'
        
    pm = PluginManager()
    pm.register(Plugin1, Plugin2)
    
    converters = pm.get_converters()
    assert len(converters) == 2
    assert Plugin1 in converters and Plugin2 in converters

# Generated at 2022-06-21 14:39:02.949133
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    class dummy_plugin1(object):
        pass
    class dummy_plugin2(object):
        pass
    class dummy_plugin3(object):
        pass
    manager.register(dummy_plugin1, dummy_plugin2, dummy_plugin3)
    assert dummy_plugin1 in manager
    assert dummy_plugin2 in manager
    assert dummy_plugin3 in manager
    manager.unregister(dummy_plugin2)
    assert dummy_plugin2 not in manager


manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-21 14:39:08.593763
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pluginList = PluginManager()
    pluginList.register(BasePlugin)
    pluginList.register(TransportPlugin)
    pluginList.register(AuthPlugin)
    pluginList.register(FormatterPlugin)
    pluginList.register(ConverterPlugin)
    assert pluginList.__repr__() == '<PluginManager: [<class \'httpie.plugins.base.BasePlugin\'>, <class \'httpie.plugins.transport.TransportPlugin\'>, <class \'httpie.plugins.auth.AuthPlugin\'>, <class \'httpie.plugins.formatter.FormatterPlugin\'>, <class \'httpie.plugins.converter.ConverterPlugin\'>]>'


plugin_manager = PluginManager()

# Generated at 2022-06-21 14:39:18.942656
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import AuthPlugin, AuthPlugin, BuiltinAuthPlugin
    from httpie.plugins import AuthPlugin, OAuth1Plugin
    from httpie.plugins import AuthPlugin, OAuth2TokenPlugin
    from httpie.plugins import AuthPlugin, OAuth2ImplicitPlugin

    entry_points_unacceptable = [AuthPlugin, BuiltinAuthPlugin, OAuth1Plugin, OAuth2TokenPlugin, OAuth2ImplicitPlugin]
    entry_points_expected = [AuthPlugin, BuiltinAuthPlugin]

    plugin_manager = PluginManager()
    plugin_manager.register(*entry_points_unacceptable)

    result_actual = plugin_manager.get_auth_plugins()

    assert result_actual == entry_points_expected


# Generated at 2022-06-21 14:39:24.368788
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugins() == []
    assert plugin_manager.get_formatters() == []
    assert plugin_manager.get_converters() == []
    assert plugin_manager.get_transport_plugins() == []
    assert plugin_manager == []



# Generated at 2022-06-21 14:39:28.243337
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.get_transport_plugins() == []
    plugin_manager.append(TransportPlugin)
    assert plugin_manager.get_transport_plugins() == [TransportPlugin]


# Generated at 2022-06-21 14:39:31.818661
# Unit test for constructor of class PluginManager
def test_PluginManager():
    print('>>> test_PluginManager')
    plugins = PluginManager()
    print(plugins)
    assert True
    print('\n<<< test_PluginManager')

if __name__ == '__main__':
    test_PluginManager()

# Generated at 2022-06-21 14:39:32.925406
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_formatters()) == 0


# Generated at 2022-06-21 14:39:39.495631
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.append(FormatterPlugin(group_name="a"))
    plugins.append(FormatterPlugin(group_name="a"))
    plugins.append(FormatterPlugin(group_name="b"))
    plugins.append(FormatterPlugin(group_name="a"))
    plugins.append(FormatterPlugin(group_name="b"))
    plugins.append(FormatterPlugin(group_name="b"))
    actual = plugins.get_formatters_grouped()
    expected = {
        "a": [FormatterPlugin(group_name="a"), FormatterPlugin(group_name="a"), FormatterPlugin(group_name="a")],
        "b": [FormatterPlugin(group_name="b"), FormatterPlugin(group_name="b"), FormatterPlugin(group_name="b")]
    }


# Generated at 2022-06-21 14:40:15.495340
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin = PluginManager()
    plugin.register(AuthPlugin)
    assert plugin.get_auth_plugins() == [AuthPlugin]

# Generated at 2022-06-21 14:40:18.475389
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    class A(object): pass
    plugin_manager.register(A)
    assert A in plugin_manager
    plugin_manager.unregister(A)
    assert A not in plugin_manager


# Generated at 2022-06-21 14:40:20.210599
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert len(pm.get_auth_plugins()) == 1

# Generated at 2022-06-21 14:40:23.720682
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.append(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {'http': AuthPlugin}


# Generated at 2022-06-21 14:40:26.652938
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manger = PluginManager()
    plugin_manger.load_installed_plugins()
    plugins = plugin_manger
    assert len(plugins) > 0
    print(plugins)



# Generated at 2022-06-21 14:40:28.768145
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    formatters = PluginManager.get_formatters(PluginManager())
    assert formatters == [], f'formatters: {formatters}'



# Generated at 2022-06-21 14:40:32.423547
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():

    # Global plugin manager
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager.get_converters()) == 2
    assert len(plugin_manager.get_formatters()) == 3



# Generated at 2022-06-21 14:40:34.780694
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p = PluginManager()
    assert p.get_transport_plugins() == []
    p.register(TransportPlugin)
    assert p.get_transport_plugins()[0] == TransportPlugin


# Generated at 2022-06-21 14:40:37.879768
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 9
    assert all([plugin.package_name for plugin in plugin_manager])

plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-21 14:40:38.905962
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert pm == eval(repr(pm))

# Generated at 2022-06-21 14:41:59.406196
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    man = PluginManager()
    assert len(list(man.get_formatters())) != 0


# Generated at 2022-06-21 14:42:01.577042
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # Mock instance of PluginManager
    PluginManager_instance = PluginManager.register("httpie.plugins.auth.v1")
    # Assert "PluginManager_instance" object is of class PluginManager
    assert isinstance(PluginManager_instance, PluginManager)


# Generated at 2022-06-21 14:42:03.732371
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.register(TestPlugin_v1,TestPlugin_v2)
    assert len(manager) == 2
    assert len(manager.get_transport_plugins()) == 1


# Generated at 2022-06-21 14:42:05.413794
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert isinstance(pm, PluginManager)



# Generated at 2022-06-21 14:42:06.535503
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()


# Generated at 2022-06-21 14:42:11.083866
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert(pm == [])

    pm.register(BasePlugin)
    assert(pm == [BasePlugin])

    pm.register(TransportPlugin, ConverterPlugin)
    assert(pm == [BasePlugin, TransportPlugin, ConverterPlugin])


# Generated at 2022-06-21 14:42:19.715489
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import JSONPointer
    from httpie.plugins.theme import Solarized

    # Create an instance of PluginManager
    plugin_manager = PluginManager()

    # Register JSON Pointer
    plugin_manager.register(JSONPointer)

    # The plugin_manager.get_formatters() should return a list with JSONPointer
    # in it.
    assert JSONPointer in plugin_manager.get_formatters()
    
    # Unregister JSON Pointer
    plugin_manager.unregister(JSONPointer)

    # The plugin_manager.get_formatters() should return an empty list.
    assert plugin_manager.get_formatters() == []

# Generated at 2022-06-21 14:42:21.510632
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    plugins = pm.get_formatters()
    assert isinstance(plugins, list)

# Generated at 2022-06-21 14:42:25.771286
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Base:
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    class C(Base):
        pass

    plugins = PluginManager()
    
    plugins.register(C)
    plugins.register(B)
    plugins.register(C)
    plugins.register(A)
    plugins.register(A)

    plugins = plugins.filter(by_type=A)

    assert len(plugins) == 2

# Generated at 2022-06-21 14:42:29.475498
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register()
    assert manager == []
    manager.register(AuthPlugin)
    assert manager == [AuthPlugin]
    manager.register(AuthPlugin)
    assert manager == [AuthPlugin]
