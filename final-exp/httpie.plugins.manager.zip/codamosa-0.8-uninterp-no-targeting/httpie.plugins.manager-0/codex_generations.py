

# Generated at 2022-06-21 14:34:22.900712
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manger = PluginManager()
    try:
        manger.load_installed_plugins()
    except Exception as e:
        print(e)

# Generated at 2022-06-21 14:34:25.364941
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.append(object())
    assert [] == plugin_manager.get_converters()



# Generated at 2022-06-21 14:34:25.800481
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert 1 == 1

# Generated at 2022-06-21 14:34:37.713330
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() is not None
    assert plugin_manager.get_auth_plugin_mapping()['jwt'] == JWTAuthPlugin
    assert plugin_manager.get_auth_plugin_mapping()['basic'] == BasicAuthPlugin
    assert plugin_manager.get_auth_plugin_mapping()['digest'] == DigestAuthPlugin
    assert plugin_manager.get_auth_plugin_mapping()['bearer'] == BearerAuthPlugin
    assert plugin_manager.get_auth_plugin_mapping()['hawk'] == HawkAuthPlugin
    assert plugin_manager.get_auth_plugin_mapping()['ntlm'] == NTLMAuthPlugin
    assert plugin_manager.get_auth_plugin

# Generated at 2022-06-21 14:34:39.387210
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager()
    assert len(PluginManager().register(BasePlugin)) > 0
    

# Generated at 2022-06-21 14:34:46.321027
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {}

    plugin_manager.register(HttpieJsonPlugin)
    assert plugin_manager.get_formatters_grouped() == {'json': [HttpieJsonPlugin]}

    plugin_manager.register(HttpieJsonPlugin)
    assert plugin_manager.get_formatters_grouped() == {'json': [HttpieJsonPlugin, HttpieJsonPlugin]}

    plugin_manager.register(HttpieHtmlPlugin)
    assert plugin_manager.get_formatters_grouped() == {'json': [HttpieJsonPlugin, HttpieJsonPlugin], 'html': [HttpieHtmlPlugin]}

# Generated at 2022-06-21 14:34:49.801237
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register(List)
    assert len(manager) == 1
    manager.unregister(List)
    assert len(manager) == 0



# Generated at 2022-06-21 14:34:57.572756
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = [AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin]
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)
    assert plugin_manager.__repr__() == '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>, <class \'httpie.plugins.base.ConverterPlugin\'>, <class \'httpie.plugins.base.FormatterPlugin\'>, <class \'httpie.plugins.base.TransportPlugin\'>]>'


# Generated at 2022-06-21 14:34:59.890152
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert eval(f'{repr(PluginManager())}') == PluginManager()
    assert eval(f'{repr([1, 2, 3])}') == [1, 2, 3]

# Generated at 2022-06-21 14:35:02.465911
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p = PluginManager()
    assert not p.get_transport_plugins()
    from httpie.plugins.builtin.__main__ import plugin_manager
    assert plugin_manager.get_transport_plugins()


# Generated at 2022-06-21 14:35:14.994918
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    test_plugin_manager = PluginManager()

    class Format1(FormatterPlugin):
        group_name = 'group1'

    class Format2(FormatterPlugin):
        group_name = 'group1'

    class Format3(FormatterPlugin):
        group_name = 'group2'

    test_plugin_manager.register(Format1)
    test_plugin_manager.register(Format2)
    test_plugin_manager.register(Format3)

    group1 = test_plugin_manager.get_formatters_grouped()['group1']
    group2 = test_plugin_manager.get_formatters_grouped()['group2']

    assert (group1 == [Format1, Format2])
    assert (group2 == [Format3])

# Generated at 2022-06-21 14:35:24.593244
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import (
        accent_json,
        json,
        pretty_json,
        json_lines,
        table,
        console
    )
    plugin_manager = PluginManager()
    plugin_manager.register(
        json,
        accent_json,
        pretty_json,
        json_lines,
        table,
        console
    )

    result = plugin_manager.get_formatters_grouped()
    expected = {
        'json': [
            json.JSONFormatterPlugin,
            pretty_json.PrettyJSONFormatterPlugin,
            json_lines.JSONLinesFormatterPlugin,
        ],
        'text': [
            table.TableFormatterPlugin,
        ]
    }

    assert result == expected



# Generated at 2022-06-21 14:35:26.703583
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # Setup
    pm = PluginManager()

    # Exercise
    result = pm.__repr__()

    # Verify
    assert result == '<PluginManager: []>'
    

# Generated at 2022-06-21 14:35:30.127419
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(AuthPlugin)
    plugins = plugin_manager.get_formatters()
    assert plugins == [FormatterPlugin]

# Generated at 2022-06-21 14:35:33.678593
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters_grouped()) > 0

# Generated at 2022-06-21 14:35:42.737409
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # There is one plugin registered under:
    # 'httpie.plugins.auth.v1' = 'httpie_netrc_auth'
    assert len(plugin_manager.get_auth_plugins()) == 1

    # There is two plugins registered under 'httpie.plugins.formatter.v1'
    # 'formatter-prettyjson' and 'formatter-pretty'
    assert len(plugin_manager.get_formatters()) == 2
    assert len(plugin_manager.get_formatters_grouped()) == 1

    # There is one converter plugin (gzip) under:
    # 'httpie.plugins.converter.v1'
    assert len(plugin_manager.get_converters()) == 1

    # There is one transport plugin

# Generated at 2022-06-21 14:35:45.256859
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    plugins.get_converters()



# Generated at 2022-06-21 14:35:49.131291
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(TestConverterPlugin)
    converters = plugin_manager.get_converters()
    assert(converters[0] == TestConverterPlugin)



# Generated at 2022-06-21 14:35:56.367785
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
  
    # Test unregister function
    def test_unregister():
        # Test if plugins is empty
        def test_is_empty():
            temp = PluginManager()
            temp.register(FormatPlugin)
            assert temp.unregister(FormatPlugin)
            
        # Test if plugins is not empty
        def test_is_not_empty():
            temp = PluginManager()
            temp.register(FormatPlugin)
            assert temp.unregister(FormatPlugin)
          
        test_is_empty()
        test_is_not_empty()
    
    # Test plugin class  
    class FormatPlugin(FormatterPlugin):
        """A plugin for httpie.
        """
        Group = 'formatters'
        Form = 'format'
        name = 'Format'


# Generated at 2022-06-21 14:36:00.436100
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.register(TestPlugin, TestPlugin2)
    assert str(plugins) == "<PluginManager: [<class 'test_plugins.TestPlugin'>, <class 'test_plugins.TestPlugin2'>]>"



# Generated at 2022-06-21 14:36:12.816430
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin

    class BasicAuthPlugin(AuthPlugin):
        auth_type = 'basic'

    class DigestAuthPlugin(AuthPlugin):
        auth_type = 'digest'

    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin, DigestAuthPlugin)
    result = plugin_manager.get_auth_plugin_mapping()

    assert result == {
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin,
    }


# Generated at 2022-06-21 14:36:18.138982
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()

    class Plugin1(AuthPlugin):
        auth_type = 'test_plugin1'
    class Plugin2(AuthPlugin):
        auth_type = 'test_plugin2'

    plugin_manager.register(Plugin1, Plugin2)

    assert plugin_manager.get_auth_plugin_mapping() == {
        'test_plugin1': Plugin1,
        'test_plugin2': Plugin2,
    }

# Generated at 2022-06-21 14:36:21.677275
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from .plugin_manager import PluginManager
    from .plugins import TransportPlugin
    inst = PluginManager()
    assert isinstance(inst.get_transport_plugins(), list)

    for plugin in inst.get_transport_plugins():
        assert isinstance(plugin, TransportPlugin)

# Generated at 2022-06-21 14:36:24.347464
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_manager = PluginManager()
    assert test_manager.get_auth_plugin_mapping() == {}


# Generated at 2022-06-21 14:36:28.554220
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager_proto = PluginManager()
    PluginManager_proto.register(my_auth_plugin)
    assert(PluginManager_proto.get_auth_plugins() == [my_auth_plugin])


# Generated at 2022-06-21 14:36:29.511957
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    pm.unregister(BasePlugin)
    assert pm == []

# Generated at 2022-06-21 14:36:31.358706
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    assert pm.get_auth_plugins() == [], 'The result should be empty'


# Generated at 2022-06-21 14:36:34.390232
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    assert eval(repr(p)) == p
    p.register()
    assert eval(repr(p)) == p



# Generated at 2022-06-21 14:36:39.048113
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.register(
        ConverterPlugin,
        ConverterPlugin,
        ConverterPlugin,
        ConverterPlugin,
    )
    plugins.register(TransportPlugin, AuthPlugin, FormatterPlugin)

    assert plugins.get_converters() == [ConverterPlugin, ConverterPlugin, ConverterPlugin, ConverterPlugin]

# Generated at 2022-06-21 14:36:42.149876
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    assert len(manager) == 0
    manager.register(Type[BasePlugin])
    assert len(manager) == 1
    manager.register(Type[AuthPlugin])
    assert len(manager) == 2
    manager.unregister(Type[BasePlugin])
    assert len(manager) == 1


# Generated at 2022-06-21 14:37:02.962751
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter

    class CustomFormatter(FormatterPlugin):
        group_name = 'custom_group'

    class CustomFormatter1(FormatterPlugin):
        group_name = 'custom_group'

    class CustomFormatter2(FormatterPlugin):
        group_name = 'custom_group1'

    class CustomFormatter3(FormatterPlugin):
        group_name = 'custom_group1'

    pm = PluginManager()
    res = pm._PluginManager__get_formatters_grouped()
    assert res == {}
    pm.register(JSONFormatter, PrettyJSONFormatter)
    res = pm._PluginManager__get_formatters_grouped()

# Generated at 2022-06-21 14:37:05.599987
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    a = PluginManager()
    a.register(object)
    assert a.__repr__() == '<PluginManager: [<class "object">]>'


# Generated at 2022-06-21 14:37:12.491882
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # Arrange
    import httpie.plugins.digest
    import httpie.plugins.http
    from httpie.plugins.http_async import AsyncHTTPTransport
    # Act
    plugins = PluginManager()
    plugins.register(httpie.plugins.http.HTTPTransport,
                     httpie.plugins.digest.HTTPDigestAuth,
                     AsyncHTTPTransport)
    result = plugins.get_transport_plugins()
    # Assert
    assert len(result) == 3
    assert isinstance(result[0], AsyncHTTPTransport)
    assert isinstance(result[1], httpie.plugins.http.HTTPTransport)
    assert isinstance(result[2], httpie.plugins.digest.HTTPDigestAuth)


# Generated at 2022-06-21 14:37:22.973630
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from .auth.base import AuthPlugin
    from .auth.plugins import digestauth, basic_auth, gssnegotiate
    assert issubclass(digestauth.DigestAuthPlugin, AuthPlugin) and \
        issubclass(basic_auth.BasicAuthPlugin, AuthPlugin) and \
        issubclass(gssnegotiate.GssNegotiateAuthPlugin, AuthPlugin)
    PluginManager().register(basic_auth.BasicAuthPlugin,
                             digestauth.DigestAuthPlugin,
                             gssnegotiate.GssNegotiateAuthPlugin)
    assert PluginManager().get_auth_plugin('basic') == basic_auth.BasicAuthPlugin
    assert PluginManager().get_auth_plugin('digest') == \
        digestauth.DigestAuthPlugin

# Generated at 2022-06-21 14:37:25.428500
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    print("function: test_PluginManager_get_auth_plugin")
    assert None


# Generated at 2022-06-21 14:37:27.043499
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    print(repr(PluginManager()))


# Generated at 2022-06-21 14:37:30.009083
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin('basic') == BasicAuthPlugin
    assert plugin_manager.get_auth_plugin('digest') == DigestAuthPlugin

# Generated at 2022-06-21 14:37:34.769298
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    assert all(isinstance(plugin, BasePlugin)
               for plugin in plugins), 'All plugins must be BasePlugin'
    plugins.unregister(httpbin.HttpbinAuthPlugin)
    assert all(not isinstance(plugin, httpbin.HttpbinAuthPlugin)
               for plugin in plugins), 'HttpbinAuthPlugin must be unregistered'

# Generated at 2022-06-21 14:37:35.729602
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    PluginManager().get_auth_plugin('basic')

# Generated at 2022-06-21 14:37:39.456171
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == [], "get_converters should return an empty list"
    pm_2 = PluginManager()
    pm_2.register(TestPlugin)
    assert pm_2.get_converters() == [TestPlugin], "get_converters should return a list with value of the plugin"


# Generated at 2022-06-21 14:38:05.985353
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_plugin1 = AuthPlugin()
    auth_plugin2 = AuthPlugin()
    auth_plugin1.auth_type = 'auth-plugin-1'
    auth_plugin2.auth_type = 'auth-plugin-2'
    PluginManager.register(auth_plugin1, auth_plugin2)
    assert PluginManager.get_auth_plugin_mapping() == {'auth-plugin-1': auth_plugin1, 'auth-plugin-2': auth_plugin2}

# Generated at 2022-06-21 14:38:09.078195
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pluginManager = PluginManager()
    pluginManager.register(PluginManager)
    assert '[<class \'httpie.__main__.PluginManager\'>]' == str(pluginManager)

# Generated at 2022-06-21 14:38:19.490901
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.filter(FormatterPlugin)
    # print(plugin_manager.get_formatters())
    # print(plugin_manager.get_formatters_grouped())

# Generated at 2022-06-21 14:38:21.070772
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager=PluginManager()
    assert plugin_manager.get_auth_plugin('http') is None



# Generated at 2022-06-21 14:38:23.377559
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    # Testa pra retornar false quando não tiver nenhum plugin registrado
    assert plugin_manager.get_auth_plugins() != True


# Generated at 2022-06-21 14:38:28.068362
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    class FakePlugin():
        pass
    pm.register(FakePlugin)
    assert 'FakePlugin' in [str(x.__name__) for x in pm.filter()]
    pm.unregister(FakePlugin)
    assert 'FakePlugin' not in [str(x.__name__) for x in pm.filter()]

# Generated at 2022-06-21 14:38:33.711933
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Load plugins
    a = PluginManager()
    a.load_installed_plugins()
    # Filter out formatters
    auths = a.get_auth_plugins()
    # Check if all are of type auth
    for plugin in auths:
        assert issubclass(plugin, AuthPlugin)
    # If so, test passed
    print('TEST PASSED')



# Generated at 2022-06-21 14:38:43.554341
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from .json import JSONFormatterPlugin
    from .json import JSONLinesFormatterPlugin
    from .json import JSONLinesPrettyFormatterPlugin
    from .json import JSONPrettyFormatterPlugin
    from .syntax import SyntaxHighlightingFormatterPlugin
    from .colors import ColorsFormatterPlugin
    from .formatters import FormatterPlugin
    from .table import TableFormatterPlugin
    from .utils import strip_colors

    plugins = PluginManager()
    plugins.register(JSONFormatterPlugin, JSONLinesFormatterPlugin, JSONLinesPrettyFormatterPlugin, JSONPrettyFormatterPlugin, SyntaxHighlightingFormatterPlugin, ColorsFormatterPlugin, FormatterPlugin, TableFormatterPlugin)
    plugin_dict = plugins.get_formatters_grouped()


# Generated at 2022-06-21 14:38:46.007040
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    authPlugin1 = AuthPlugin()
    authPlugin2 = AuthPlugin()
    assert PluginManager().get_auth_plugins() == [authPlugin1, authPlugin2]


# Generated at 2022-06-21 14:38:50.966017
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(Type[BasePlugin])
    assert len(list(plugin_manager)) == 1
    plugin_manager.unregister(Type[BasePlugin])
    assert len(list(plugin_manager)) == 0


# Generated at 2022-06-21 14:39:33.831178
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin = PluginManager()
    plugin.register('hello')
    assert plugin[0] == 'hello', f'{plugin[0]} is not equal to hello'



# Generated at 2022-06-21 14:39:40.865591
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import MessagePlugin, JSONPlugin
    from httpie.plugins import FormatterPlugin

    from httpie.plugins.http import HTTPPlugin
    from httpie.plugins.http.processors import HTTPProcessor

    import io
    import os

    manager = PluginManager()
    manager.append(MessagePlugin)
    manager.append(JSONPlugin)

    from typing import cast

    assert len(manager.get_formatters()) == 2
    for plugin in manager.get_formatters():
        assert isinstance(plugin, FormatterPlugin)
        assert issubclass(plugin, MessagePlugin) or \
               issubclass(plugin, JSONPlugin)

    manager.append(HTTPPlugin)
    assert len(manager.get_formatters()) == 2

# Generated at 2022-06-21 14:39:45.210023
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Create a PluginManager instance
    pm = PluginManager()
    # Call the method
    auth_plugins = pm.get_auth_plugins()
    # Assert
    assert isinstance(auth_plugins, list)
    assert issubclass(auth_plugins[0], AuthPlugin)


# Generated at 2022-06-21 14:39:54.354654
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert PluginManager.get_formatters_grouped(plugin_manager) == {}
    plugin_manager.register(1, 2, 3)
    assert PluginManager.get_formatters_grouped(plugin_manager) == {1: [1, 2, 3], 2: [], 3: []}
    plugin_manager.register('a', 'a', 'b', 'c')
    assert sorted(PluginManager.get_formatters_grouped(plugin_manager).items()) == [('a', ['a', 'a', 'b']), ('b', []), ('c', []), ('d', [])]

# Generated at 2022-06-21 14:39:56.304759
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager=PluginManager()
    plugins=plugin_manager.get_formatters()
    assert len(plugins)==7


# Generated at 2022-06-21 14:40:04.886792
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(FormatterPlugin)
    pm.register(ConverterPlugin)
    pm.register(TransportPlugin)
    assert str(pm.get_auth_plugins()) == '[<class \'httpie.plugins.auth.v1.AuthPlugin\'>]'
    assert str(pm.get_formatters()) == '[<class \'httpie.plugins.formatter.v1.FormatterPlugin\'>]'
    assert str(pm.get_converters()) == '[<class \'httpie.plugins.converter.v1.ConverterPlugin\'>]'
    assert str(pm.get_transport_plugins()) == '[<class \'httpie.plugins.transport.v1.TransportPlugin\'>]'

# Generated at 2022-06-21 14:40:12.810149
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class A(BasePlugin):
        pass

    class B(BasePlugin):
        p = True

    class C(BasePlugin):
        pass

    class D(BasePlugin):
        pass

    manager = PluginManager()
    manager.register(A, B, C, D)

    assert len(manager) == 4

    manager.unregister(A)
    assert len(manager) == 3
    assert manager.count(B) == 1

    manager.unregister(C)
    assert len(manager) == 2
    assert manager.count(D) == 1


# Generated at 2022-06-21 14:40:16.630077
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():

    from httpie.plugins import TransportPlugin
    from httpie.plugins.adapters.base import BaseAdapter

    class MockTransportPlugin(TransportPlugin):
        def get_adapters(self):
            return [BaseAdapter]

    plugin_manager = PluginManager()
    plugin_manager.register(MockTransportPlugin)
    assert plugin_manager.get_transport_plugins() == [MockTransportPlugin]



# Generated at 2022-06-21 14:40:27.102403
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert repr(plugins) == "<PluginManager: [<class 'httpie.plugins.basic_auth.BasicAuth'>," \
                            " <class 'httpie.plugins.digest_auth.DigestAuth'>, " \
                            "<class 'httpie.plugins.hawk.Hawk'>, " \
                            "<class 'httpie.plugins.netrc_auth.NetrcAuth'>, " \
                            "<class 'httpie.plugins.ntlm.NTLM'>, " \
                            "<class 'httpie.plugins.oauth1.OAuth1'>, " \
                            "<class 'httpie.plugins.oauth2.OAuth2'>, " \
                            "<class 'httpie.plugins.colors.Colors'>]"
    assert repr

# Generated at 2022-06-21 14:40:31.035430
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    class TestPlugin(AuthPlugin):
        auth_type = 'test'
    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'test': TestPlugin}


# Generated at 2022-06-21 14:42:13.354366
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    assert pm.filter() == []


plugins = PluginManager()

# Generated at 2022-06-21 14:42:14.829026
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginmanager = PluginManager()
    assert repr(pluginmanager) == '<PluginManager: []>'

# Generated at 2022-06-21 14:42:20.621649
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class DummyAuthPlugin(AuthPlugin):
        auth_type = 'dummy'
    class DummyFormatterPlugin(FormatterPlugin):
        pass
    pm = PluginManager()
    pm.register(DummyFormatterPlugin)
    pm.register(DummyAuthPlugin)
    assert len(pm) == 2
    pm.unregister(DummyFormatterPlugin)
    assert len(pm) == 1

# Generated at 2022-06-21 14:42:22.608311
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    filtered_list = PluginManager.filter(by_type=Type[BasePlugin])
    print (filtered_list)



# Generated at 2022-06-21 14:42:26.122287
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    '''
    Test function for method PluginManager.get_formatters.
    Args:
        None
    Returns:
        None
    '''

    plugins = PluginManager()
    plugins.load_installed_plugins()

    assert list(plugins.get_formatters())[0].__class__.__name__ in ['JsonFormatter', 'ColorsFormatter']



# Generated at 2022-06-21 14:42:36.963955
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()

    assert( pm.register(1) == [1] )
    assert( pm.unregister(1) == [] )
    assert( pm.register(2) == [2] )
    assert( pm.register(2, 3, 4) == [2, 3, 4] )
    assert( pm.filter() == [2, 3, 4] )
    assert( len(pm.get_auth_plugins()) > 0 )
    assert( len(pm.get_formatters()) > 0 )
    assert( len(pm.get_converters()) > 0 )
    assert( len(pm.get_transport_plugins()) > 0 )
    assert( len(pm.get_formatters_grouped()) > 0 )
    assert( len(pm.get_auth_plugin_mapping()) > 0 )

# Generated at 2022-06-21 14:42:40.768584
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}
    assert manager.get_auth_plugin('basic') == AuthPlugin
    manager.unregister(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}

# Generated at 2022-06-21 14:42:41.509461
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager.get_formatters()

# Generated at 2022-06-21 14:42:48.430633
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_n = PluginManager()
    plugin_manager_n.register(Plugin, TransportPlugin, BasePlugin, FormatterPlugin, ConverterPlugin)
    plugin_manager_n_instance1_list = plugin_manager_n.filter(Type[BasePlugin])
    plugin_manager_n_instance1_list_expected = [Plugin, Type, TransportPlugin, BasePlugin, FormatterPlugin, ConverterPlugin]
    plugin_manager_n_instance2_list = plugin_manager_n.filter(Type[ConverterPlugin])
    plugin_manager_n_instance2_list_expected = [ConverterPlugin]
    assert plugin_manager_n_instance1_list == plugin_manager_n_instance1_list_expected
    assert plugin_manager_n_instance2_list == plugin_manager_n_instance2_list_expected



# Generated at 2022-06-21 14:42:52.090390
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    class A1(BasePlugin):
        pass
    class A2(BasePlugin):
        pass
    plugin_manager = PluginManager()
    plugin_manager.register(A1, A2)
    assert A1 in plugin_manager
    assert A2 in plugin_manager
