

# Generated at 2022-06-21 14:34:32.261484
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert(len(pm.filter()) == 1)
    assert(len(pm.filter(by_type=AuthPlugin)) == 1)
    assert(len(pm.filter(by_type=TransportPlugin)) == 0)
    pm.register(TransportPlugin)
    assert(len(pm.filter()) == 1)
    assert(len(pm.filter(by_type=AuthPlugin)) == 0)
    assert(len(pm.filter(by_type=TransportPlugin)) == 1)


# Generated at 2022-06-21 14:34:36.625834
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    Manager = PluginManager()
    Manager.register(AuthPlugin)
    assert len(Manager) == 1
    Manager.unregister(AuthPlugin)
    assert len(Manager) == 0
    
    
if __name__ == '__main__':
    test_PluginManager_unregister()

# Generated at 2022-06-21 14:34:38.880739
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    a = PluginManager()
    a.load_installed_plugins()
    assert a.get_transport_plugins()


# Generated at 2022-06-21 14:34:42.897923
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.register(json.JSONFormatter)
    pm.register(colors.ColorsFormatter)
    pm.register(colors.ColorsFormatter)
    assert pm.get_formatters() == [
        json.JSONFormatter,
        colors.ColorsFormatter,
        colors.ColorsFormatter
    ]

# Generated at 2022-06-21 14:34:47.381783
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.load_installed_plugins()

    for group_name, group in pm.get_formatters_grouped().items():
        print('group=', group_name)
        for plugin in group:
            print('  ', plugin.name, plugin.group_name)
        print()

if __name__ == "__main__":
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-21 14:34:55.066691
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert [] == plugin_manager.get_transport_plugins()

    class MockTransportPlugin(TransportPlugin):
        pass

    class MockTransportPlugin2(TransportPlugin):
        pass

    plugin_manager.register(MockTransportPlugin, MockTransportPlugin2)
    assert [MockTransportPlugin, MockTransportPlugin2] == plugin_manager.get_transport_plugins()

# Generated at 2022-06-21 14:34:57.125446
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert issubclass(plugin_manager.get_converters()[0], ConverterPlugin)

# Generated at 2022-06-21 14:35:01.401638
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    pluginManager.register(TestPlugin1, TestPlugin2, TestPlugin3)
    groupDict = pluginManager.get_formatters_grouped()
    assert groupDict['root'] == [TestPlugin1]
    assert groupDict['group1'] == [TestPlugin2]
    assert groupDict['group2'] == [TestPlugin3]

    

# Generated at 2022-06-21 14:35:06.690116
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()

    class PluginA(object): 
        pass

    class PluginB(object): 
        pass

    class PluginC(object): 
        pass

    pm.register(PluginA, PluginB)
    assert PluginA in pm
    assert PluginB in pm
    assert PluginC not in pm

    pm.unregister(PluginB)
    assert PluginA in pm
    assert PluginB not in pm
    assert PluginC not in pm


# Generated at 2022-06-21 14:35:15.413488
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    class NoAuthTypePlugin(AuthPlugin):
        pass

    class AuthPlugin1(AuthPlugin):
        auth_type = 'auth1'

    class AuthPlugin2(AuthPlugin):
        auth_type = 'auth2'

    plugins = PluginManager()

    with pytest.raises(ValueError, match='no auth_type specified'):
        plugins.register(NoAuthTypePlugin)

    plugins.register(AuthPlugin1, AuthPlugin2)

    assert plugins.get_auth_plugin('auth1') == AuthPlugin1
    assert plugins.get_auth_plugin('auth2') == AuthPlugin2
    assert set(plugins.get_auth_plugin_mapping().keys()) == {
        'auth1', 'auth2'
    }



# Generated at 2022-06-21 14:35:19.700743
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()

    assert manager



# Generated at 2022-06-21 14:35:23.099005
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(AutoAuthPlugin)
    plugin_manager.register(HttpcryptoPlugin)
    plugin_manager.unregister(HttpcryptoPlugin)
    assert len(plugin_manager.filter(AuthPlugin)) == 1

# Generated at 2022-06-21 14:35:24.593823
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins is not None
    assert isinstance(plugins, PluginManager)

# Generated at 2022-06-21 14:35:32.194209
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_auth_plugin_mapping()) > 0
    assert isinstance(plugin_manager.get_auth_plugin_mapping(), dict)
    assert len(plugin_manager.get_auth_plugin_mapping())
    assert 'basic' in plugin_manager.get_auth_plugin_mapping()
    assert 'digest' in plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-21 14:35:38.176262
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugins() == []
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert len(plugin_manager.get_auth_plugins()) == 1
    assert plugin_manager.get_auth_plugin_mapping() == {
        'auth-plugin': AuthPlugin
    }


# Generated at 2022-06-21 14:35:50.690316
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    class PluginD(PluginC):
        pass

    class PluginE(PluginB):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, 
                            PluginB, 
                            PluginC, 
                            PluginD, 
                            PluginE)

    assert plugin_manager.filter() == [PluginA, PluginB, PluginC, PluginD, PluginE]
    assert plugin_manager.filter(BasePlugin) == [PluginA, PluginB, PluginC, PluginD, PluginE]
    assert plugin_manager.filter(PluginA) == [PluginA, PluginC, PluginD]

# Generated at 2022-06-21 14:35:53.355071
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    class TestPlugin(BasePlugin):
        pass
    plugin_manager.register(TestPlugin)
    plugin_manager.unregister(TestPlugin)
    assert len(plugin_manager)==0


# Generated at 2022-06-21 14:35:58.149872
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Base:
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    manager = PluginManager()
    manager.register(A, B)
    assert manager.filter(by_type=A) == [A]

# Generated at 2022-06-21 14:36:06.379532
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)

    print("enumerate plugin_manager.get_transport_plugins(): ")
    for idx, plugin in enumerate(plugin_manager.get_transport_plugins()):
        print("idx = {}: plugin = {}".format(idx, plugin))
    print("")



# Generated at 2022-06-21 14:36:10.543740
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter import JSONConverter
    assert len(PluginManager().get_converters()) == 1
    assert len(PluginManager([JSONConverter]).get_converters()) == 1


# Generated at 2022-06-21 14:36:18.100851
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    # Create instance of plugin manager
    plugin_manager = PluginManager()

    # Register plugins for testing
    from httpie.plugins.builtin import HTTPBasicAuthPlugin
    plugin_manager.register(HTTPBasicAuthPlugin)
    assert len(plugin_manager.get_auth_plugins()) == 1

    # Unregister plugin
    plugin_manager.unregister(HTTPBasicAuthPlugin)
    assert len(plugin_manager.get_auth_plugins()) == 0

# Generated at 2022-06-21 14:36:21.263774
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(MockAuthPlugin, MockAuthPlugin2)
    auth_plugin = plugins.get_auth_plugin_mapping()
    assert isinstance(auth_plugin, dict)


# Generated at 2022-06-21 14:36:28.011777
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'

    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    assert repr(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>, <class \'httpie.plugins.base.FormatterPlugin\'>]>'


# Generated at 2022-06-21 14:36:30.637747
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    converters = plugin_manager.get_converters()

    assert type(converters) == list
    assert len(converters) > 0


# Generated at 2022-06-21 14:36:34.968253
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    class FooPlugin:
        pass
    plugins.register(FooPlugin)
    assert len(plugins) == 1
    assert plugins[0] == FooPlugin
    assert plugins[0].__name__ == 'FooPlugin'



# Generated at 2022-06-21 14:36:38.148784
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    assert pm.get_converters() == []
    pm.register(TestPlugin)
    assert pm.get_converters() == [TestPlugin]


# Generated at 2022-06-21 14:36:39.470539
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == []


# Generated at 2022-06-21 14:36:47.064760
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import GraphQLFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import UrlencodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import DefaultFormatterPlugin
    from httpie.plugins.json import JSONStreamFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-21 14:36:50.110402
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_converters()
    result = len(plugins) == 0
    assert result is True


# Generated at 2022-06-21 14:36:53.332478
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm1 = PluginManager()
    pm.register(pm1)
    assert repr(pm) == '<PluginManager: [<PluginManager: []>]>'


# Generated at 2022-06-21 14:36:58.767107
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pass


# Generated at 2022-06-21 14:36:59.161341
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert True

# Generated at 2022-06-21 14:37:04.002417
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    converters = plugin_manager.get_converters()
    assert len(converters) > 0
    for converter in converters:
        assert issubclass(converter, ConverterPlugin)



# Generated at 2022-06-21 14:37:07.608908
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin = PluginManager()
    plugin.register(BasicAuthPlugin, DigestAuthPlugin)
    assert plugin.get_auth_plugin('basic') == BasicAuthPlugin
    assert plugin.get_auth_plugin('digest') == DigestAuthPlugin
    assert plugin.get_auth_plugin('non-exist') is None


# Generated at 2022-06-21 14:37:12.375568
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    """
    The function test_PluginManager_get_auth_plugin is
    to test the method get_auth_plugin() of class PluginManager
    :return:
    """
    pluginManager = PluginManager()
    pluginManager.append(PluginManager)
    assert pluginManager.get_auth_plugin('auth_type') == AuthPlugin, \
        'The type of function get_auth_plugin is not correct'



# Generated at 2022-06-21 14:37:22.819720
# Unit test for constructor of class PluginManager
def test_PluginManager():
    from httpie.plugins import AuthPlugin, FormatterPlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, AutoJSONPlugin
    assert issubclass(HTTPBasicAuthPlugin, AuthPlugin)
    assert issubclass(AutoJSONPlugin, FormatterPlugin)
    # A builtin plugin
    assert issubclass(AutoJSONPlugin, TransportPlugin)
    # A httpie plugin
    assert issubclass(HTTPBasicAuthPlugin, TransportPlugin)
    # Check constructor
    import pytest
    from httpie.plugins.manager import PluginManager as PM
    from httpie.plugins.base import BasePlugin as BP
    class PMTest(PM):
        pass
    class BP1(BP):
        pass
    class BP2(BP):
        pass
    class BP3(BP):
        pass
    pm = PMTest()
   

# Generated at 2022-06-21 14:37:26.721300
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_mgr = PluginManager()
    plugin_mgr.load_installed_plugins()
    assert len(plugin_mgr) == 11
    assert isinstance(plugin_mgr[0], type)


# Generated at 2022-06-21 14:37:29.731989
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    s=PluginManager()
    assert(len(s) == 0)
    list_formatters=s.get_formatters()
    assert(len(list_formatters) == 0)



# Generated at 2022-06-21 14:37:35.684937
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    a1 = type('a1', (BasePlugin,), {})
    a2 = type('a2', (BasePlugin,), {})
    am = PluginManager()
    am.register(a1, a2)
    assert len(am) == 2
    am.unregister(a1)
    assert len(am) == 1
    am.unregister(a2)
    assert len(am) == 0



# Generated at 2022-06-21 14:37:42.891215
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()

    assert len(plugin_manager) == 0
    
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)
    
    assert len(plugin_manager) == 4

    plugin_manager.unregister(AuthPlugin)
    assert len(plugin_manager) == 3
    plugin_manager.unregister(FormatterPlugin)
    assert len(plugin_manager) == 2
    plugin_manager.unregister(ConverterPlugin)
    assert len(plugin_manager) == 1
    plugin_manager.unregister(TransportPlugin)
    assert len(plugin_manager) == 0

    print('Unit test unregister passed')


# Generated at 2022-06-21 14:37:54.102153
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert (PluginManager([]).get_formatters() == [])
    assert (PluginManager([AuthPlugin]).get_formatters() == [])
    assert (PluginManager([FormatterPlugin]).get_formatters() == [FormatterPlugin])
    assert (PluginManager([TransportPlugin]).get_formatters() == [])
    assert (PluginManager([FormatterPlugin, TransportPlugin]).get_formatters() == [FormatterPlugin])
    assert (PluginManager([FormatterPlugin, ConverterPlugin]).get_formatters() == [FormatterPlugin])


# Generated at 2022-06-21 14:38:04.736011
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(
        Type[BasePlugin],
        Type[BasePlugin],
        Type[AuthPlugin],
        Type[ConverterPlugin],
        Type[FormatterPlugin],
        Type[TransportPlugin]
    )
    assert len(plugin_manager.filter(by_type=Type[AuthPlugin])) == 1
    assert len(plugin_manager.filter(by_type=Type[ConverterPlugin])) == 1
    assert len(plugin_manager.filter(by_type=Type[FormatterPlugin])) == 1
    assert len(plugin_manager.filter(by_type=Type[TransportPlugin])) == 1


# Generated at 2022-06-21 14:38:10.641302
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class AuthPlugin1(AuthPlugin):
        auth_type = 'type1'

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2, AuthPlugin1)
    assert list(plugin_manager) == [Plugin1, Plugin2, AuthPlugin1]


# Generated at 2022-06-21 14:38:15.186775
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.append(1)
    plugin_manager.append(2)
    plugin_manager.append(3)
    plugin_manager.append(4)
    assert plugin_manager.get_auth_plugins() == [1, 2, 3, 4]

# Generated at 2022-06-21 14:38:17.188479
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    transport_plugins = PluginManager().get_transport_plugins()
    print(transport_plugins)

test_PluginManager_get_transport_plugins()

# Generated at 2022-06-21 14:38:25.300765
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter() == []
    assert PluginManager().register().filter() == []

    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass

    assert PluginManager().register(A, B, C).filter(by_type=A) == [A, B, C]
    assert PluginManager().register(A, B, C).filter(by_type=B) == [B]
    assert PluginManager().register(A, B, C).filter(by_type=C) == [C]
    assert PluginManager().register(A, B, C).filter(by_type=D) == []
    assert PluginManager().register(A, B, C).filter(by_type=E) == []


# Generated at 2022-06-21 14:38:26.921069
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    p = PluginManager()
    p.load_installed_plugins()
    assert p.get_converters() is not None

# Generated at 2022-06-21 14:38:28.447929
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-21 14:38:32.913559
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import core
    plugin = PluginManager()
    plugin.register(core.HTTPBasicAuthPlugin)
    assert core.HTTPBasicAuthPlugin in plugin
    plugin.unregister(core.HTTPBasicAuthPlugin)
    assert core.HTTPBasicAuthPlugin not in plugin


# Generated at 2022-06-21 14:38:42.964715
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPGSSAPIAuth
    from httpie.plugins.builtin import HTTPNegotiateAuth
    from httpie.plugins.builtin import HTTPAWS4Auth
    from httpie.plugins.builtin import HTTPAWS4SigV4Auth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPSigAuth
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import ConverterPlugin
    from httpie.plugins.builtin import Transport

# Generated at 2022-06-21 14:38:55.000585
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    AuthPlugin = plugin_manager.filter(AuthPlugin)
    assert AuthPlugin == []

# Generated at 2022-06-21 14:38:55.907396
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    m = PluginManager()
    assert eval(repr(m)) == m



# Generated at 2022-06-21 14:38:57.833001
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugins = [BasePlugin, AuthPlugin, TransportPlugin, ConverterPlugin, FormatterPlugin]
    plugin_manager.register(*plugins)
    print(plugin_manager)


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-21 14:39:00.826991
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    print(plugin_manager)
    print(plugin_manager.get_auth_plugins())

if __name__ == "__main__":
    test_PluginManager()

# Generated at 2022-06-21 14:39:08.140776
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert pm.get_auth_plugin_mapping() == {}

    pm.register(FakePlugin)
    assert pm.get_auth_plugin_mapping() == {
        'fake': FakePlugin
    }

    pm.append(Plugin2)
    assert pm.get_auth_plugin_mapping() == {
        'fake': FakePlugin,
        'fake2': Plugin2
    }

    pm.unregister(FakePlugin)
    assert pm.get_auth_plugin_mapping() == {
        'fake2': Plugin2
    }

    pm.remove(Plugin2)
    assert pm.get_auth_plugin_mapping() == {}


# Generated at 2022-06-21 14:39:18.304232
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'Group1'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'Group1'
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'Group2'
    class FormatterPlugin4(FormatterPlugin):
        group_name = None
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin1, FormatterPlugin2, FormatterPlugin3, FormatterPlugin4)
    assert plugin_manager.get_formatters_grouped() == {'Group1': [FormatterPlugin1, FormatterPlugin2], 'Group2': [FormatterPlugin3], None: [FormatterPlugin4]}



# Generated at 2022-06-21 14:39:21.602663
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    auth_plugins = plugins.get_auth_plugins()
    assert len(auth_plugins) != 0


# Generated at 2022-06-21 14:39:29.545693
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    data = plugin_manager.get_auth_plugin_mapping()
    expected = {'auto': httpie.plugins.auth.builtin.AutoAuthPlugin,
                'bearer': httpie.plugins.auth.builtin.BearerAuthPlugin,
                'basic': httpie.plugins.auth.builtin.BasicAuthPlugin,
                'digest': httpie.plugins.auth.builtin.DigestAuthPlugin,
                'hawk': httpie.plugins.auth.builtin.HawkAuthPlugin,
                'ntlm': httpie.plugins.auth.builtin.NTLMAuthPlugin,
                'fcrd': httpie.plugins.auth.builtin.FCRDAuthPlugin,
                'fcra': httpie.plugins.auth.builtin.FCRAAuthPlugin}
    assert data

# Generated at 2022-06-21 14:39:34.152005
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.register(HttpTransportPlugin)
    plugins.register(HttpiePlugin)

    assert plugins.get_transport_plugins() == [HttpTransportPlugin]

    plugins.register(HttpiePlugin)
    assert plugins.get_transport_plugins() == [HttpiePlugin]

# Generated at 2022-06-21 14:39:37.590852
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin = BasePlugin()
    plugin_manager = PluginManager()
    plugin_manager.register(plugin)
    plugin_manager.filter(BasePlugin) == [plugin]
    assert plugin_manager.filter(BasePlugin) == [plugin]


# Generated at 2022-06-21 14:40:01.003720
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter import JSONConverter, URLEncodedConverter
    pm = PluginManager()
    pm.register(JSONConverter)
    pm.register(URLEncodedConverter)
    assert JSONConverter in pm.get_converters()
    assert URLEncodedConverter in pm.get_converters()



# Generated at 2022-06-21 14:40:03.576329
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p1 = PluginManager()
    p1.register(AuthPlugin)
    p1.register(AuthPlugin)
    p1.register(FormatterPlugin)
    p1.register(ConverterPlugin)
    p1.register(TransportPlugin)
    assert len(p1) == 5


# Generated at 2022-06-21 14:40:08.785838
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(FormatterPlugin)
    pm.register(ConverterPlugin)
    pm.register(TransportPlugin)
    assert isinstance(pm, list)
    assert isinstance(pm.get_formatters(), list)
    assert isinstance(pm.get_formatters()[0], type)
    assert issubclass(pm.get_formatters()[0], FormatterPlugin)
    assert pm.get_formatters()[0].__name__ == 'FormatterPlugin'
    assert repr(pm.get_formatters()[0]) == '<class \'httpie.plugins.base.FormatterPlugin\'>'


# Generated at 2022-06-21 14:40:17.913096
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
  a = PluginManager()
  a.register(Http)
  a.register(Curl)
  a.register(Pretty)
  a.register(PrettyColors)
  a.register(PrettyJson)
  f_list = a.get_formatters_grouped()

# Generated at 2022-06-21 14:40:20.555332
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    manager.get_auth_plugin("basic")
    manager.get_auth_plugin("digest")
    manager.get_auth_plugin("bearer")

# Generated at 2022-06-21 14:40:27.528827
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    import httpie

    httpie.plugins.manager.register(HTTPBasicAuth)
    try:
        assert httpie.plugins.manager.get_auth_plugin('basic') == HTTPBasicAuth
    finally:
        httpie.plugins.manager.unregister(HTTPBasicAuth)


manager = PluginManager()

# Generated at 2022-06-21 14:40:32.344588
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(1, 2, 1.1, 2.1, 'a')
    result = plugins.filter(int)
    assert len(result) == 2
    assert 1 in result
    assert 2 in result
    assert 1.1 not in result
    assert 2.1 not in result
    assert 'a' not in result


test_PluginManager_filter()

# Generated at 2022-06-21 14:40:34.085008
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    p = PluginManager()
    p.load_installed_plugins()
    assert len(p.get_converters()) > 0



# Generated at 2022-06-21 14:40:37.965710
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.cli.argtypes import KeyValue
    manager = PluginManager()
    manager.register(JSONFormatterPlugin, PrettyFormatterPlugin)
    assert manager.get_formatters_grouped() == {'json': [JSONFormatterPlugin], 'pretty': [PrettyFormatterPlugin]}

# Generated at 2022-06-21 14:40:39.798052
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugins() == [AuthPlugin]


# Generated at 2022-06-21 14:41:27.343272
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plg = PluginManager()
    assert isinstance(plg.get_auth_plugins(), list)


# Generated at 2022-06-21 14:41:34.329539
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_plugins = [
        Type('AuthPlugin1', (object,), {'auth_type': 'AuthPlugin1'}),
        Type('AuthPlugin2', (object,), {'auth_type': 'AuthPlugin2'})
    ]
    plugin_manager = PluginManager()
    plugin_manager.register(*auth_plugins)
    assert plugin_manager.get_auth_plugin_mapping() == \
        {'AuthPlugin1': auth_plugins[0], 'AuthPlugin2': auth_plugins[1]}



# Generated at 2022-06-21 14:41:38.670033
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBasicAuthPlugin
    from httpie.plugins.manager import PluginManager

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuthPlugin)

    assert plugin_manager.get_auth_plugins() == [HTTPBasicAuth]

# Generated at 2022-06-21 14:41:41.513043
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm.get_formatters())
    assert list(pm.get_formatters()) != []


# Generated at 2022-06-21 14:41:52.674085
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.standard import (
        HTTPHeaderAuthPlugin, HTTPCookieAuthPlugin, JSONPathFilterPlugin,
        JSONPointerFilterPlugin, CURLConverter, Json3dPrintFormat
    )

    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    pluginmanager.register(
        HTTPHeaderAuthPlugin, HTTPCookieAuthPlugin, JSONPathFilterPlugin,
        JSONPointerFilterPlugin, CURLConverter, Json3dPrintFormat
    )
    pluginmanager.unregister(CURLConverter)
    assert pluginmanager.get_formatters_grouped()['Output processing'] == [JSONPathFilterPlugin, JSONPointerFilterPlugin]
    print('Done unittest for method get_formatters_grouped of class PluginManager')



# Generated at 2022-06-21 14:41:55.872331
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager_register_return = manager.register('HTTPie', 'Python')
    assert isinstance(manager_register_return, NoneType)
    assert manager_register_return is None


# Generated at 2022-06-21 14:41:57.887123
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin = PluginManager()
    plugin.register(AuthPlugin)
    assert plugin.get_auth_plugin_mapping() == {}

# Generated at 2022-06-21 14:42:02.315107
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    for entry_point in iter_entry_points('httpie.plugins.transport.v1'):
        plugin = entry_point.load()
        plugin.package_name = entry_point.dist.key
        pm.register(entry_point.load())                
    tpl = pm.get_transport_plugins()
    assert isinstance(tpl, list)


# Generated at 2022-06-21 14:42:03.351076
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # should be instantiated without fail
    _ = PluginManager()


# Generated at 2022-06-21 14:42:05.341706
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(BasicAuthPlugin)
    assert manager.get_auth_plugin_mapping() == {"basic": BasicAuthPlugin}


# Generated at 2022-06-21 14:43:55.881503
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert 9 == len(manager.get_auth_plugins())
    assert type(manager.get_auth_plugins()[0].auth_type) == str


# Generated at 2022-06-21 14:43:58.142936
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register(type('Item', (BasePlugin,), {}))
    assert manager[0] in manager
    manager.unregister(manager[0])
    assert manager[0] not in manager



# Generated at 2022-06-21 14:44:01.556385
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    def fun():
        entry_point_name = 'httpie.plugins.converter.v1'
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            return plugin
    manager = PluginManager()
    manager.register(fun)
    assert len(manager.get_converters()) == 1



# Generated at 2022-06-21 14:44:03.617440
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()

# Plugins is a global singleton instance of PluginManager
plugins = PluginManager()

# Generated at 2022-06-21 14:44:08.335269
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B: pass
    class C(A): pass
    class D(B): pass
    class E(A): pass
    class F(C): pass
    lst = [A, B, C, D, E, F]
    pm = PluginManager(lst)
    filtered_pm = pm.filter(A)
    assert filtered_pm == [A, C, E, F]

# Generated at 2022-06-21 14:44:12.989048
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin)
    plugin_manager.register(DigestAuthPlugin)
    plugin_manager.register(FakeAuthPlugin)
    assert len(plugin_manager.get_auth_plugins()) == 3
    assert [type(plugin) for plugin in plugin_manager.get_auth_plugins()] ==[
        BasicAuthPlugin, DigestAuthPlugin, FakeAuthPlugin
    ]


# Generated at 2022-06-21 14:44:15.728916
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(BasicAuthPlugin)
    plugins.register(DigestAuthPlugin)
    assert plugins.get_auth_plugins() == [BasicAuthPlugin, DigestAuthPlugin]



# Generated at 2022-06-21 14:44:20.950945
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pl = PluginManager()
    formatter_dict = {
        'application': [
            'application/json (httpie.format.json.JSONFormatter)',
            'application/xml (httpie.format.xml.XMLFormatter)'
        ],
        'text': [
            'text/html (httpie.format.html.HTMLFormatter)',
            'text/plain (httpie.format.terminal.TerminalFormatter)'
        ]
    }
    assert pl.get_formatters_grouped() == formatter_dict

# Generated at 2022-06-21 14:44:23.066574
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    p.register('a','b','c')
    assert (p.__repr__()=='<PluginManager: [\'a\', \'b\', \'c\']>')