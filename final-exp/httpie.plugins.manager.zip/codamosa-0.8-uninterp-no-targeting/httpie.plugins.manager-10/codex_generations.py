

# Generated at 2022-06-21 14:34:24.839350
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Arrange
    auth_plugins = []
    class TestPlugin1(AuthPlugin):
        auth_type = 'foo'
    class TestPlugin2(AuthPlugin):
        auth_type = 'bar'
    auth_plugins.append(TestPlugin1)
    auth_plugins.append(TestPlugin2)
    plugin_manager = PluginManager()
    plugin_manager.register(*auth_plugins)

# Generated at 2022-06-21 14:34:36.393157
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """
    get_formatters_grouped produces a dictionary whose keys are group names,
    and whose values are lists of FormatterPlugins.

    This test checks that the dictionary produced by get_formatters_grouped
    contains the expected keys and FormatterPlugins.
    """
    all_plugins = PluginManager()
    all_plugins.load_installed_plugins()
    group_names, plugins = set(), set()
    for group_name, plugin_list in all_plugins.get_formatters_grouped().items():
        group_names.add(group_name)
        plugins.add(plugin_list[0])
    assert len(plugins) > 10
    assert 'JSON' in group_names
    assert 'HTTPie' in group_names
    assert 'Browser' in group_names

# Generated at 2022-06-21 14:34:45.731389
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from .v1.plugins.json import JSONFormatterPlugin
    from .v1.plugins.str import StrFormatterPlugin
    from .v1.plugins.table import TableFormatterPlugin
    from .v1.plugins.uglyjson import UglyJSONFormatterPlugin
    from .v1.plugins.xml import XMLFormatterPlugin

    plugins = PluginManager()

    plugins.register(JSONFormatterPlugin)
    plugins.register(XMLFormatterPlugin)
    plugins.register(StrFormatterPlugin)
    plugins.register(TableFormatterPlugin)
    plugins.register(UglyJSONFormatterPlugin)


# Generated at 2022-06-21 14:34:50.894668
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
	PluginManager = PluginManager()
	PluginManager.load_installed_plugins()
	mapping = PluginManager.get_auth_plugin_mapping()
	assert mapping['digest'] == DigestAuthPlugin
	assert mapping['jwt'] == JWTAuthPlugin


# Generated at 2022-06-21 14:35:01.034084
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # test class AuthPlugin
    assert hasattr(AuthPlugin, 'get_auth')
    assert callable(AuthPlugin.get_auth)
    assert hasattr(AuthPlugin, 'get_credentials')
    assert callable(AuthPlugin.get_credentials)
    # test class HmacAuthPlugin
    assert hasattr(HmacAuthPlugin, 'auth_type')
    assert HmacAuthPlugin.auth_type == None
    assert hasattr(HmacAuthPlugin, 'get_hash')
    assert callable(HmacAuthPlugin.get_hash)
    # test class PluginManager
    assert hasattr(PluginManager, '_plugins')
    assert hasattr(PluginManager, 'register')
    assert callable(PluginManager.register)
    assert hasattr(PluginManager, 'unregister')

# Generated at 2022-06-21 14:35:03.341158
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_converters()) > 0


# Generated at 2022-06-21 14:35:10.266902
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(ConverterPlugin)
    auth_plugins = plugin_manager.filter(AuthPlugin)
    assert auth_plugins == [AuthPlugin, ]
    converters = plugin_manager.filter(ConverterPlugin)
    assert converters == [ConverterPlugin, ]

# Generated at 2022-06-21 14:35:12.782555
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    converters = plugin_manager.get_converters()
    assert type(converters) == list


# Generated at 2022-06-21 14:35:13.730859
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()

    

# Generated at 2022-06-21 14:35:15.863447
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager.get_formatters_grouped(this) is not None


# Generated at 2022-06-21 14:35:18.606749
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager.register(BasicAuth, DigestAuth)
    assert PluginManager.get_auth_plugins() == [BasicAuth, DigestAuth]


# Generated at 2022-06-21 14:35:21.834010
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)
    assert len(plugins) == 4


# Generated at 2022-06-21 14:35:24.316350
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    import httpie.plugins
    plugin_manager = httpie.plugins.plugin_manager
    plugins_list = plugin_manager.get_transport_plugins()
    assert len(plugins_list) > 1

# Generated at 2022-06-21 14:35:28.523713
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) == 5
    assert len(plugin_manager.get_formatters_grouped()) == 3
    assert len(plugin_manager.get_auth_plugins()) == 2
    assert len(plugin_manager.get_auth_plugin_mapping()) == 2
    assert len(plugin_manager.get_transport_plugins()) == 3
    assert len(plugin_manager.get_converters()) == 4

# Generated at 2022-06-21 14:35:34.759076
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Given/When
    manager = PluginManager()
    manager.load_installed_plugins()

    # Then
    # assert_that(manager, equal_to(['..."httpie.plugins.auth.v1",...']))
    assert_that(manager, instance_of(PluginManager))


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-21 14:35:38.052927
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()

# Generated at 2022-06-21 14:35:50.688797
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    class AuthPlugin1(AuthPlugin):
        auth_type = 'auth_type_1'
    class AuthPlugin2(AuthPlugin):
        auth_type = 'auth_type_2'
    class AuthPlugin3(AuthPlugin):
        auth_type = 'auth_type_3'
    class AuthPlugin4(AuthPlugin):
        auth_type = 'auth_type_4'
    class FormatPlugin1(FormatterPlugin):
        format_name = 'format_1'
    class FormatPlugin2(FormatterPlugin):
        format_name = 'format_2'

    plugins = PluginManager()
    plugins.register(AuthPlugin1, AuthPlugin2, AuthPlugin3, AuthPlugin4, FormatPlugin1, FormatPlugin2)
    auth_plugins = plugins.get_auth_plugins()
    assert type(auth_plugins) == list
   

# Generated at 2022-06-21 14:35:52.363474
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert str(plugin_manager) == '<PluginManager: []>'


# Generated at 2022-06-21 14:35:56.168027
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    class Plug1:
        pass
    class Plug2:
        pass
    plugin_manager.register(Plug1, Plug2)
    assert plugin_manager._container == [Plug1, Plug2]


# Generated at 2022-06-21 14:35:58.010904
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager().register(AuthPlugin)

# Generated at 2022-06-21 14:36:00.800795
# Unit test for constructor of class PluginManager
def test_PluginManager():
	plugin_manager = PluginManager()
	assert plugin_manager is not None


# Generated at 2022-06-21 14:36:02.606579
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    from httpie.plugins.builtin import HTTPBasicAuth

    PluginManager().register(HTTPBasicAuth)


# Generated at 2022-06-21 14:36:08.613767
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    # Test case: if the element is in the list, the method will work
    plugin_manager.unregister(BasePlugin)
    assert BasePlugin not in plugin_manager
    # Test case: if the element is not in the list, the method will not work
    plugin_manager.unregister(BasePlugin)
    assert BasePlugin not in plugin_manager

# Generated at 2022-06-21 14:36:10.544233
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) > 4



# Generated at 2022-06-21 14:36:13.906688
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    # assert len(plugin_manager.get_auth_plugins()) == 1
    assert len(plugin_manager.get_auth_plugins()) == 0


# Generated at 2022-06-21 14:36:16.202852
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

test_PluginManager_load_installed_plugins()


# Generated at 2022-06-21 14:36:18.653285
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pluginM = PluginManager()
    pluginM.register(AuthPlugin)
    assert issubclass(pluginM[0], AuthPlugin), "Should be an AuthPlugin"

# Generated at 2022-06-21 14:36:20.425629
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_formatters()) == 22

# Generated at 2022-06-21 14:36:24.197548
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    assert(plugins.get_transport_plugins() == [])
    plugins.register(TransportPlugin)
    assert(plugins.get_transport_plugins() == [TransportPlugin])


# Generated at 2022-06-21 14:36:28.429263
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    class Adapter(TransportPlugin):
        name = 'adapter'

    plugins = PluginManager()
    plugins.register(Adapter)

    assert plugins.get_transport_plugins() == [Adapter]

plugin_manager = PluginManager()

# Generated at 2022-06-21 14:36:33.170164
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    assert PluginManager.register(PluginManager(), AuthPlugin)



# Generated at 2022-06-21 14:36:36.046554
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    pmg = plugin_manager.get_converters()
    assert pmg != []
    assert pmg[0].mimetype == 'text/html'


# Generated at 2022-06-21 14:36:44.097141
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Create a PluginManager
    pm = PluginManager()

    assert len(pm.get_auth_plugins()) == 0
    assert len(pm.get_formatters_grouped()) == 0
    assert len(pm.get_converters()) == 0
    assert len(pm.get_transport_plugins()) == 0

    # Load installed plugins
    pm.load_installed_plugins()


    # Check whether plugins are loaded
    assert len(pm.get_auth_plugins()) >= 1
    assert len(pm.get_formatters_grouped()) >= 1
    assert len(pm.get_converters()) >= 1
    assert len(pm.get_transport_plugins()) >= 1



# Generated at 2022-06-21 14:36:46.823399
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    __converters = get_plugin_manager().get_converters()
    assert len(__converters) == 1


# Generated at 2022-06-21 14:36:51.753615
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    """
    This function tests the unit test for method get_converters of class PluginManager
    :return:
    """
    plugins = PluginManager()
    plugins.load_installed_plugins() # include in this method the import for all converter plugins
    converters = plugins.get_converters()
    assert len(converters) > 0



# Generated at 2022-06-21 14:36:54.722875
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()
    cnvs = pm.get_converters()
    assert len(cnvs) > 0
    cnvs_expected = [
        'httpie.plugins.converter.HighlightJSONConverter',
        'httpie.plugins.converter.JSONConverter',
        'httpie.plugins.converter.PrettyOptionsConverter',
    ]
    for e in cnvs_expected:
        assert e in cnvs



# Generated at 2022-06-21 14:36:56.915746
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert(len(plugins) == 0)

# Generated at 2022-06-21 14:37:04.891422
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import builtin
    from httpie.plugins.builtin import JSONFormatter as JSONFormatterBuiltin
    from httpie.plugins.builtin import (
        TableFormatter as TableFormatterBuiltin
    )
    from httpie.plugins.builtin import (
        URLEncodedFormatter as URLEncodedFormatterBuiltins
    )
    from httpie.plugins.json import JSONFormatter as JSONFormatterPlugin
    from httpie.plugins.pretty import PrettyFormatter as PrettyFormatterPlugin
    from httpie.plugins.table import TableFormatter as TableFormatterPlugin
    from httpie.plugins.urlencoded import (
        URLEncodedFormatter as URLEncodedFormatterPlugin
    )

    # Initialization of plugin manager for testing
    plugin_manager = PluginManager()
    plugin_manager.register

# Generated at 2022-06-21 14:37:08.370796
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager([mock_plugin])
    manager.load_installed_plugins()

    plugins = manager.get_auth_plugin_mapping()
    assert len(plugins.keys()) == 0

    plugin = manager.get_auth_plugin("OAuth1")
    assert plugin == mock_plugin



# Generated at 2022-06-21 14:37:09.389299
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager() == []


# Generated at 2022-06-21 14:37:22.702273
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import HTTP as HTTPAdapter
    from httpie.plugins.builtin import HTTP2 as HTTP2Adapter
    from httpie.plugins.builtin import HTTPS as HTTPSAdapter
    from httpie.plugins.builtin import (
        HTTP11, HTTP20, HTTP01, HTTP11_SSL, HTTP20_SSL,
        HTTP01_SSL,
        #  HTTP01ssl_compress_port,
        HTTP01_COMPRESS_PORT, HTTP01_SSL_COMPRESS_PORT,
    )
    from httpie.plugins.builtin import WS as WebSocketAdapter

    assert PluginManager([HTTPAdapter, HTTP2Adapter, HTTPSAdapter, WebSocketAdapter]).get_transport_plugins() == [HTTPAdapter, HTTP2Adapter, HTTPSAdapter, WebSocketAdapter]

# Generated at 2022-06-21 14:37:32.685335
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin

    # when
    manager = PluginManager()
    manager.register(AuthPlugin, TransportPlugin, FormatterPlugin, ConverterPlugin)

    # then
    assert str(manager) == '<PluginManager: [<class \'httpie.plugins.auth.auth_plugin.AuthPlugin\'>, <class \'httpie.plugins.transport.transport_plugin.TransportPlugin\'>, <class \'httpie.plugins.formatter.formatter_plugin.FormatterPlugin\'>, <class \'httpie.plugins.converter.converter_plugin.ConverterPlugin\'>]>'


m = PluginManager()

# Generated at 2022-06-21 14:37:33.709799
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert True == True 


# Generated at 2022-06-21 14:37:37.268801
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    print(plugins)
    assert plugins.get_auth_plugin_mapping() == {'AuthPlugin': AuthPlugin}



# Generated at 2022-06-21 14:37:39.309619
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) > 0


# Generated at 2022-06-21 14:37:42.336845
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

    class TestFormatterPlugin:
        group_name = 'group_name'

    assert plugin_manager.get_formatters_grouped() == {}

    plugin_manager.register(TestFormatterPlugin)

    assert plugin_manager.get_formatters_grouped() == {'group_name': [TestFormatterPlugin]}

# Generated at 2022-06-21 14:37:44.159672
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p = PluginManager()
    assert not p.get_transport_plugins()



# Generated at 2022-06-21 14:37:54.767466
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.builtin import JSONQuerystringConverterPlugin
    from httpie.plugins.builtin import JSONResponseConverterPlugin
    from httpie.plugins.builtin import MultipartFormDataConverterPlugin
    from httpie.plugins.builtin import MultipartFormDataToFormURLEncodedConverterPlugin
    from httpie.plugins.builtin import MultipartFormDataToJSONConverterPlugin
    from httpie.plugins.builtin import MultipartFormDataToQuerystrinConverterPlugin
    from httpie.plugins.builtin import MultipartFormDataToYAMLConverterPlugin
    from httpie.plugins.builtin import YAMLResponseConverterPlugin
    assert ConverterPlugin in PluginManager.get_converters()

# Generated at 2022-06-21 14:37:56.450607
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert plugin_manager == []


# Generated at 2022-06-21 14:38:03.119585
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.append(AuthPlugin)
    assert plugin_manager.get_auth_plugins() == [AuthPlugin]
    assert not plugin_manager.get_auth_plugins() == [BasePlugin]
    assert not plugin_manager.get_auth_plugins() == [ConverterPlugin]
    assert len(plugin_manager.get_auth_plugins())==1


# Generated at 2022-06-21 14:38:13.805831
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.transport.stream import StreamTransportPlugin
    from httpie.plugins.transport.sync import SyncTransportPlugin
    from httpie.plugins.transport.aio import AsyncTransportPlugin

    manager = PluginManager()
    assert manager.get_transport_plugins() == []
    manager.register(StreamTransportPlugin, SyncTransportPlugin, AsyncTransportPlugin)
    assert sorted(manager.get_transport_plugins()) == [
        AsyncTransportPlugin, SyncTransportPlugin, StreamTransportPlugin
    ]

# Generated at 2022-06-21 14:38:15.186626
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == []


# Generated at 2022-06-21 14:38:22.866346
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugins = plugin_manager.get_auth_plugin_mapping()
    assert plugins == {
        "basic": httpie.plugins.auth.http.HttpAuthPlugin,
        "digest": httpie.plugins.auth.digest.DigestAuthPlugin,
        "jwt": httpie.plugins.auth.jwt.JWTAuthPlugin,
        "oauth1": httpie.plugins.auth.oauth1.OAuth1AuthPlugin,
        "oauth2": httpie.plugins.auth.oauth2.OAuth2AuthPlugin,
    }



# Generated at 2022-06-21 14:38:27.986093
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0

    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    plugin_manager.register(Plugin1, Plugin2)

    assert len(plugin_manager) == 2
    assert Plugin1 in plugin_manager
    assert Plugin2 in plugin_manager


# Generated at 2022-06-21 14:38:34.420219
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    p = PluginManager()

    class foo(BasePlugin):
        pass

    class bar(BasePlugin):
        pass

    class foobar(foo):
        pass

    p.register(foo, bar, foobar)

    assert len(p.filter()) == 3
    assert len(p.filter(foo)) == 2
    assert len(p.filter(bar)) == 1
    assert len(p.filter(foobar)) == 1



# Generated at 2022-06-21 14:38:37.234106
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert plugin_manager.get_formatters_grouped() is not None



# Generated at 2022-06-21 14:38:39.220911
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    assert manager.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-21 14:38:47.140841
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class FirstPlugin(BasePlugin):
        def __init__(self):
            pass

    class SecondPlugin(FirstPlugin):
        def __init__(self):
            pass

    class ThirdPlugin(FirstPlugin):
        def __init__(self):
            pass
    
    class FourthPlugin(SecondPlugin, ThirdPlugin):
        def __init__(self):
            pass

    plugins = PluginManager()
    plugins.register(FirstPlugin, SecondPlugin, ThirdPlugin, FourthPlugin)
    
    assert plugins.filter(ThirdPlugin) == [ThirdPlugin]
    assert plugins.filter(SecondPlugin) == [SecondPlugin]
    assert plugins.filter(FirstPlugin) == [FirstPlugin]
    assert plugins.filter(BasePlugin) == [FourthPlugin, ThirdPlugin, SecondPlugin, FirstPlugin]
    assert plugins.filter(object) == plugins


# Generated at 2022-06-21 14:38:48.776416
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager().register(AuthPlugin)


# Generated at 2022-06-21 14:38:51.281561
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)


# Generated at 2022-06-21 14:38:58.376651
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class A(BasePlugin): pass
    class B(BasePlugin): pass
    pm.register(A, B)
    assert A in pm
    assert B in pm



# Generated at 2022-06-21 14:39:03.507174
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    p = PluginManager()
    assert p.get_converters() == []
    a = AuthPlugin()
    f = FormatterPlugin()
    c = ConverterPlugin()
    T = TransportPlugin()
    p.register(a, f, c, T)
    assert p.get_converters() == [c]
test_PluginManager_get_converters()


# Generated at 2022-06-21 14:39:05.253300
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    actual = PluginManager().get_auth_plugin("basic")
    expected = "basic"
    assert actual == expected


# Generated at 2022-06-21 14:39:10.194704
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Testing for a valid authentication plugin
    assert PluginManager.get_auth_plugin(None, 'httpie.plugins.auth.httpie_auth.HTTPAuthPlugin')
    # Testinh for an invalid authentication plugin
    assert not PluginManager.get_auth_plugin(None, 'None')

# Generated at 2022-06-21 14:39:12.440739
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    assert plugins.get_transport_plugins() == []


# Generated at 2022-06-21 14:39:21.484006
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():

    from httpie.plugins.auth import AuthPlugin
    import httpie.plugins.auth.builtin
    from httpie.plugins.auth.generic import AuthPlugin as GenericAuthPlugin
    from httpie.plugins.auth.kerberos_auth import AuthPlugin as KerberosAuthPlugin

    _plugins = [
        httpie.plugins.auth.builtin.BasicAuthPlugin,
        httpie.plugins.auth.builtin.DigestAuthPlugin,
        httpie.plugins.auth.builtin.BearerTokenAuthPlugin,
        httpie.plugins.auth.builtin.AWSAuthPlugin,
        GenericAuthPlugin,
        KerberosAuthPlugin,
    ]

    plugins = PluginManager()
    for plugin in _plugins:
        plugins.register(plugin)

    auth_plugins = plugins.get_auth_plugins()

# Generated at 2022-06-21 14:39:29.497171
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    obj = PluginManager()
    obj.load_installed_plugins()

# Generated at 2022-06-21 14:39:32.925823
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pluginManager = PluginManager()
    pluginManager.register(auth_plugin.DigestAuthPlugin)
    pluginManager.register(auth_plugin.BasicAuthPlugin)
    assert pluginManager.get_auth_plugin('basic').auth_type == 'basic'
    assert pluginManager.get_auth_plugin('digest') == auth_plugin.DigestAuthPlugin


# Generated at 2022-06-21 14:39:35.534981
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert len(pm.get_auth_plugins()) == 1
    assert pm.get_auth_plugins()[0] is AuthPlugin


# Generated at 2022-06-21 14:39:45.210021
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(PluginA):
        pass

    p = PluginManager()
    p.register(PluginA, AuthPlugin, PluginB, ConverterPlugin)
    assert PluginA in p.filter(AuthPlugin)
    assert PluginB in p.filter(AuthPlugin)
    assert PluginB in p.filter(ConverterPlugin)
    assert PluginB not in p.filter(TransportPlugin)

    assert p.filter(ConverterPlugin)


test_PluginManager_filter()
#from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
from httpie.plugins.base import BasePlugin, TransportPlugin



# Generated at 2022-06-21 14:39:59.729366
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    p.register(int)
    assert int in p
    p.unregister(int)
    assert int not in p


plugin_manager = PluginManager()

# Generated at 2022-06-21 14:40:01.274184
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert pm.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-21 14:40:05.691198
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    class TestPlugin(TransportPlugin):
        name = 'TestPlugin'
        description = 'TestPlugin for testing'

    class TestPlugin1(TransportPlugin):
        name = 'TestPlugin1'
        description = 'TestPlugin1 for testing'

    manager = PluginManager()
    manager.register(TestPlugin, TestPlugin1)
    assert manager.get_transport_plugins() == [TestPlugin, TestPlugin1]


# Generated at 2022-06-21 14:40:09.945450
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert isinstance(plugins_manager.get_formatters()[0],type(FormatterPlugin))
    assert isinstance(plugins_manager.get_formatters()[1],type(FormatterPlugin))
    assert isinstance(plugins_manager.get_formatters()[2],type(FormatterPlugin))
    

# Generated at 2022-06-21 14:40:17.031710
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.formatter.formatters import Formatter
    from httpie.plugins.formatter.image import ImageResultRenderer
    from httpie.plugins.formatter.json import JSONResultRenderer
    from httpie.plugins.formatter.terminal_output import TerminalRenderer

    pm = PluginManager()
    pm = [Formatter,ImageResultRenderer,JSONResultRenderer,TerminalRenderer]
    assert pm.get_formatters() == [Formatter,ImageResultRenderer,JSONResultRenderer,TerminalRenderer]

# Generated at 2022-06-21 14:40:23.668499
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_pluginManager = PluginManager()
    test_pluginManager.load_installed_plugins()
    test_auth_plugin_mapping = test_pluginManager.get_auth_plugin_mapping()
    assert isinstance(test_auth_plugin_mapping, dict)
    assert len(test_auth_plugin_mapping) >= 2
    assert "basic" in test_auth_plugin_mapping
    assert "digest" in test_auth_plugin_mapping


# Generated at 2022-06-21 14:40:27.006511
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugins()
    assert manager.get_formatters()
    assert manager.get_converters()
    assert manager.get_transport_plugins()

# Generated at 2022-06-21 14:40:34.703879
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins import converters, formatters, auth, transport

    testPluginManager = PluginManager()
    testPluginManager.register(formatters.ContentTypeFormatter,
                               converters.JSONPathConverter,
                               auth.BasicAuth,
                               transport.HTTPTransport
                               )
    assert testPluginManager.__repr__() == '<PluginManager: [<class \'httpie.plugins.formatters.ContentTypeFormatter\'>, <class \'httpie.plugins.converters.JSONPathConverter\'>, <class \'httpie.plugins.auth.BasicAuth\'>, <class \'httpie.plugins.transport.HTTPTransport\'>]>'

# Generated at 2022-06-21 14:40:40.321356
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    """
    Test unit to get_formatters of PluginManager class
    """
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = ['curl', 'colors', 'format', 'json', 'pretty', 'table', 'text']
    for plugin_manager_item in plugin_manager.get_formatters():
        # Evaluate if formatters are in the plugin_manager
        if plugin_manager_item.name in formatters:
            assert plugin_manager_item.name in formatters
        # The formatters must be 7
        assert len(formatters) == 7

# Generated at 2022-06-21 14:40:43.494761
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register(HTTPDate, HTTPDateToEpoch)
    manager.register(ISO8601)
    assert isinstance(manager.get_converters(), list)
    assert len(manager.get_converters()) == 3


# Generated at 2022-06-21 14:41:15.987533
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    # given
    plugins = PluginManager()
    class Plugin1(FormatterPlugin):
        group_name = 'Group 1'
    class Plugin2(FormatterPlugin):
        group_name = 'Group 2'
    plugins.register(Plugin1, Plugin2)
    # expect
    assert len(plugins.get_formatters()) == 2


# Generated at 2022-06-21 14:41:17.666593
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-21 14:41:20.282130
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugins = [ {'plugin_name':'HTTPieFileUploadPlugin'} ]
    plugin_manager.register(plugins)

# Generated at 2022-06-21 14:41:28.536687
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins_mgr = PluginManager()
    plugins_mgr.load_installed_plugins()
    transport_plugins = plugins_mgr.get_transport_plugins()
    assert (len(transport_plugins) == 2)
    assert (transport_plugins[0].name == 'sync' and transport_plugins[1].name == 'httpx')
    assert (issubclass(transport_plugins[0], TransportPlugin) and issubclass(transport_plugins[1], TransportPlugin))


# Generated at 2022-06-21 14:41:30.171288
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager.register(BasePlugin)
    assert PluginManager.filter() == []

plugin_manager = PluginManager()

# Generated at 2022-06-21 14:41:34.370354
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    converters = pm.get_converters()
    assert converters == []
    pm.register(ManualConverter1, ManualConverter2)
    converters = pm.get_converters()
    assert len(converters) == 2

# Manual Converters

# Generated at 2022-06-21 14:41:37.926538
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.register(BasicAuthPlugin)
    plugins.register(DigestAuthPlugin)
    assert plugins.get_auth_plugin('basic') == BasicAuthPlugin
    assert plugins.get_auth_plugin('digest') == DigestAuthPlugin


# Generated at 2022-06-21 14:41:41.926422
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    CurrentManager = PluginManager()

    def SamplePlugin_0():
        pass

    def SamplePlugin_1():
        pass

    CurrentManager.register(SamplePlugin_0)
    CurrentManager.register(SamplePlugin_1)
    assert len(CurrentManager) == 2

    CurrentManager.unregister(SamplePlugin_0)
    assert len(CurrentManager) == 1
    assert SamplePlugin_0 not in CurrentManager

# Generated at 2022-06-21 14:41:48.194396
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    plugins = PluginManager()
    plugins.register(Plugin1)
    plugins.register(Plugin2)

    assert Plugin1 in plugins
    assert Plugin2 in plugins

    plugins.unregister(Plugin1)

    assert Plugin1 not in plugins
    assert Plugin2 in plugins


# Generated at 2022-06-21 14:41:57.888574
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    
    class _TestFormatter1(FormatterPlugin):
        group_name = 'test_group'
        output_types = FormatterPlugin.OUTPUT_TYPES + ('test1',)

    class _TestFormatter2(FormatterPlugin):
        group_name = 'test_group'
        output_types = FormatterPlugin.OUTPUT_TYPES + ('test2',)

    class _TestFormatter3(FormatterPlugin):
        group_name = 'test_group2'
        output_types = FormatterPlugin.OUTPUT_TYPES + ('test3',)

    plugin_manager = PluginManager()
    plugin_manager.register(_TestFormatter1,
                            _TestFormatter2,
                            _TestFormatter3)

# Generated at 2022-06-21 14:43:02.481504
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    a = PluginManager()
    a.register(auth.BearerAuthPlugin)
    assert a.get_auth_plugins() == [auth.BearerAuthPlugin]


# Generated at 2022-06-21 14:43:09.055169
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Test if the method load_installed_plugins is working
    # Load all plugins and print the package name and plugin name
    manager = PluginManager()
    manager.load_installed_plugins()
    for plugin in manager.get_formatters():
        print('Package name : ', plugin.package_name, ' | Plugin name : ', plugin.name)
    print()
    for plugin in manager.get_converters():
        print('Package name : ', plugin.package_name, ' | Plugin name : ', plugin.name)
    print()
    for plugin in manager.get_transport_plugins():
        print('Package name : ', plugin.package_name, ' | Plugin name : ', plugin.name)
    print()

# Generated at 2022-06-21 14:43:12.639561
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pluginManager = PluginManager()
    assert 0 == len(pluginManager)
    pluginManager.register(None)
    assert 1 == len(pluginManager)
    pluginManager.register(None)
    assert 2 == len(pluginManager)


# Generated at 2022-06-21 14:43:15.437508
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register(BinaryJSONToJSON, BinaryResponseDataToJSON, JSONToCompactJSON)
    converters: List[Type[ConverterPlugin]] = manager.get_converters()
    assert converters == [BinaryJSONToJSON, BinaryResponseDataToJSON, JSONToCompactJSON]

# Generated at 2022-06-21 14:43:16.102241
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# Generated at 2022-06-21 14:43:17.490250
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert list(
        PluginManager([json.JSONPlugin]).filter(by_type=ConverterPlugin)
    ) == [json.JSONPlugin]

# Generated at 2022-06-21 14:43:18.678478
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager.register(AuthPlugin)
    assert len(PluginManager.get_auth_plugins()) == 1


# Generated at 2022-06-21 14:43:20.296580
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.register(BasePlugin)
    assert repr(pm) == '<PluginManager: [<class httpie.plugins.base.BasePlugin>]>'

# Generated at 2022-06-21 14:43:24.139683
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D: pass
    pm = PluginManager()
    assert pm.register(A, B, C, D) == [A, B, C, D]
    assert pm.filter(A) == [A, B, C]
    assert pm.filter(B) == [B]
    assert pm.filter(C) == [C]
    assert pm.filter(D) == [D]
    assert pm.filter() == [A, B, C, D]

# Generated at 2022-06-21 14:43:31.215512
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import core
    # 1. clear all previously loaded plugins
    PluginManager().clear()
    # 1.1 assert that no plugin is loaded.
    assert PluginManager().filter() == []
    # 2. load all installed plugins
    PluginManager().load_installed_plugins()
    # 3. assert that exactly one plugin is loaded.
    assert PluginManager().filter() == [core.CorePlugin]