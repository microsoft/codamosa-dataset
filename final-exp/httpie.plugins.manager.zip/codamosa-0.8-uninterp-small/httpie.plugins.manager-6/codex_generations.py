

# Generated at 2022-06-25 19:10:22.786752
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(ConverterPlugin)
    assert plugin_manager_0.get_converters() == [ConverterPlugin], "line 66 get_converters did not return [] after registering ConverterPlugin"
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_converters() != [ConverterPlugin], "line 68 get_converters returns [] after running load_installed_plugins"

# Generated at 2022-06-25 19:10:25.124737
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.filter()


# Generated at 2022-06-25 19:10:32.011854
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    class FormatterPlugin_0(FormatterPlugin):
        group_name = 'Dummy type: formatter'

    class FormatterPlugin_1(FormatterPlugin):
        group_name = 'Dummy type: formatter'

    class FormatterPlugin_2(FormatterPlugin):
        group_name = 'Dummy type: formatter'

    class FormatterPlugin_3(FormatterPlugin):
        group_name = 'Dummy type: formatter'

    # def get_formatters_grouped(self) -> Dict[str, List[Type[FormatterPlugin]]]:
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_formatters_grouped()
    assert list_0 == {}

    # group_name: List[Type[FormatterPlugin]]
    plugin_manager_1 = Plugin

# Generated at 2022-06-25 19:10:33.854953
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:10:40.248907
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    result = plugin_manager.get_auth_plugins()
    #if len(result) == 0:
    #    raise AssertionError(result)
    #else:
    #    print(result)


plugin_manager_0 = PluginManager()
plugin_manager_0.load_installed_plugins()
list_0 = plugin_manager_0.get_auth_plugins()

test_case_0()

# Generated at 2022-06-25 19:10:41.927265
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:10:53.186509
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    with open('plugin_manager/plugin_manager_load_installed_plugins.json', 'r') as file:
        expected_plugins = json.load(file)
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(expected_plugins) == len(plugin_manager_0)
    for expected_plugin in expected_plugins:
        plugin_exists = False
        for plugin in plugin_manager_0:
            if plugin.label == expected_plugin['label']:
                plugin_exists = True
                break
        assert plugin_exists
        assert plugin.label == expected_plugin['label']
        assert plugin.package_name == expected_plugin['package_name']
        assert plugin.version == expected_plugin['version']

# Generated at 2022-06-25 19:11:01.613105
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(BasePlugin)
    plugin_manager_0.append(TransportPlugin)
    plugin_manager_0.append(ConverterPlugin)
    plugin_manager_0.append(AuthPlugin)
    plugin_manager_0.append(AuthPlugin)
    plugin_manager_0.append(ConverterPlugin)
    plugin_manager_0.append(TransportPlugin)
    plugin_manager_0.append(ConverterPlugin)
    plugin_manager_0.append(AuthPlugin)
    plugin_manager_0.append(AuthPlugin)
    plugin_manager_0.append(TransportPlugin)
    plugin_manager_0.append(AuthPlugin)
    plugin_manager_0.append(ConverterPlugin)
    plugin_manager_0.append

# Generated at 2022-06-25 19:11:11.066769
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(AuthPlugin)
    plugin_manager_0.register(BasicAuthPlugin)
    plugin_manager_0.register(DigestAuthPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.register(TransportPlugin)
    plugin_manager_0.register(NetrcAuthPlugin)
    plugin_manager_0.register(OAuth1AuthPlugin)
    plugin_manager_0.register(OAuth2AuthPlugin)
    plugin_manager_0.register(HawkAuthPlugin)
    plugin_manager_0.register(BearerTokenAuthPlugin)
    plugin_manager_0.register(CookieJarPlugin)
    assert plugin_manager_0.get_

# Generated at 2022-06-25 19:11:12.723611
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:25.731298
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
	plugin_manager_1 = PluginManager()
	plugin_manager_1.register(MyFormatter_A)
	plugin_manager_1.register(MyFormatter_B)
	plugin_manager_1.register(MyFormatter_C)
	plugin_manager_1.register(MyFormatter_D)
	plugin_manager_1.register(MyFormatter_E)
	plugin_manager_1.register(MyFormatter_F)
	plugin_manager_1_output = plugin_manager_1.get_formatters_grouped()
	plugin_manager_1_output_str = [str(i) for i in plugin_manager_1_output.values()]
	plugin_manager_1_output_str.sort()

# Generated at 2022-06-25 19:11:30.902068
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_auth_plugin_mapping()
    assert plugin_manager_0.get_formatters_grouped()
    assert plugin_manager_0.get_converters()
    assert plugin_manager_0.get_transport_plugins()


# Generated at 2022-06-25 19:11:37.927875
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins_0 = PluginManager()
    plugins_0.load_installed_plugins()
    assert type(plugins_0.get_auth_plugin_mapping()) is dict
    assert type(plugins_0.get_formatters()) is list
    assert type(plugins_0.get_converters()) is list
    assert type(plugins_0.get_transport_plugins()) is list


# test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:11:47.443255
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import pkg_resources

    d = {}
    d['entry_point'] = MagicMock(name='entry_point',
                                 load=MagicMock(return_value='loaded plugin',
                                                name='load'))
    d['entry_point_name'] = 'httpie.plugins.formatter.v1'

    def mock_iter_entry_points(entry_point_name):
        if entry_point_name == d['entry_point_name']:
            yield d['entry_point']

    pkg_resources.iter_entry_points = mock_iter_entry_points

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_formatters_grouped()
    print(plugin_manager.filter(FormatterPlugin))

# Generated at 2022-06-25 19:11:50.656794
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:11:53.917760
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # Check if the loaded plugins have the correct attribute package_name
    for plugin in plugin_manager:
        assert hasattr(plugin, "package_name")


# Generated at 2022-06-25 19:11:56.011915
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugins = plugin_manager_0.get_auth_plugin_mapping()
    assert (len(plugins) >= 1)


# Generated at 2022-06-25 19:11:58.516960
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    try:
        plugin_manager_1 = PluginManager()
        assert plugin_manager_1.filter(by_type=Type[BasePlugin]) == []
    except AssertionError:
        raise AssertionError("PluginManager filter wrong")



# Generated at 2022-06-25 19:12:01.669291
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    group_dict = plugin_manager_1.get_formatters_grouped()
    for group in group_dict:
        assert True


# Generated at 2022-06-25 19:12:11.097996
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()

# Generated at 2022-06-25 19:12:15.925121
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1[0].package_name == 'httpie'

# Generated at 2022-06-25 19:12:22.586879
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import FormatterPlugin, ConverterPlugin, AuthPlugin
    from httpie.plugins.base import TransportPlugin
    from httpie.plugins.builtin import BuiltinAuthPlugin
    from httpie.plugins.builtin import BuiltinFormattersPlugin
    from httpie.plugins.builtin import BuiltinConvertersPlugin
    from httpie.plugins.builtin import BuiltinTransportPlugin

    from httpie.plugins.base import HTTPBasicAuthPlugin

    plugin_manager_0 = PluginManager()

    plugin_manager_0.load_installed_plugins()

    assert len(plugin_manager_0) == 21

    assert plugin_manager_0.get_auth_plugin_mapping()['basic'] == HTTPBasicAuthPlugin
    assert plugin_manager_0.get_auth_plugin_mapping()['custom'] == BuiltinAuthPlugin

   

# Generated at 2022-06-25 19:12:24.607419
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-25 19:12:26.280320
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register()
    ret = plugin_manager.filter()
    assert ret



# Generated at 2022-06-25 19:12:31.419151
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) > 0
    for plugin in plugin_manager_1:
        assert hasattr(plugin, 'package_name')

# Unit tests for method filter of class PluginManager

# Generated at 2022-06-25 19:12:34.749908
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(object())
    plugin_manager_0.append(None)
    plugin_manager_0.append(object())
    expected = {object: [object, object], None: [None]}
    assert plugin_manager_0.get_formatters_grouped() == expected


# Generated at 2022-06-25 19:12:39.124626
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # print(plugin_manager.filter(AuthPlugin))
    # print(plugin_manager.filter(FormatterPlugin))
    # print(plugin_manager.filter(ConverterPlugin))
    # print(plugin_manager.filter(TransportPlugin))
    # print(plugin_manager.filter(BasePlugin))



# Generated at 2022-06-25 19:12:43.654007
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    local_plugins = PluginManager()
    local_plugins.load_installed_plugins()
    return local_plugins

# Generated at 2022-06-25 19:12:45.812008
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1)


# Generated at 2022-06-25 19:12:54.219728
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:13:10.263570
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    class FakeEntryPoint():
        def __init__(self, entry_point_name):
            self.entry_point_name = entry_point_name
            self.load = lambda: entry_point_name

    class Fake(list):
        def __init__(self, key, value):
            super().__init__([FakeEntryPoint(value)])
            self.key = key

        def __repr__(self):
            return f'Plugin: {self.key}'

        def __iter__(self):
            return iter(self[0])

    class FakeEntryPointGroup():
        def __init__(self, key, values):
            self.values = values
            self.key = key
            self.dist = Fake(key, values)

        def __iter__(self):
            return iter(self.values)

       

# Generated at 2022-06-25 19:13:15.223322
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(AuthPlugin)
    assert len(plugin_manager.filter(TransportPlugin)) == 1
    assert isinstance(plugin_manager.filter(TransportPlugin)[0], TransportPlugin)
    assert issubclass(plugin_manager.filter(TransportPlugin)[0], TransportPlugin)

# Generated at 2022-06-25 19:13:20.471742
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    class DummyPlugin(BasePlugin):
        pass

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(DummyPlugin)
    assert len(plugin_manager_1) == 1
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) == 1
    assert issubclass(DummyPlugin, BasePlugin)
    assert issubclass(DummyPlugin, FormatterPlugin)


if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:13:27.358507
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert 'httpie_akamai-edgegrid' in plugin_manager
    assert 'httpie-aws-authv4' in plugin_manager
    assert 'httpie-aws-authv4-test' not in plugin_manager
    assert 'httpie-aws-authv4-test' not in plugin_manager


# Generated at 2022-06-25 19:13:31.638744
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_PluginManager = PluginManager()
    auth_plugins = test_PluginManager.get_auth_plugins()
    assert(auth_plugins == [])



# Generated at 2022-06-25 19:13:37.488161
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_2 = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin_manager_2.register(entry_point.load())
    assert str(plugin_manager_1) == str(plugin_manager_2)


# Generated at 2022-06-25 19:13:38.802356
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:13:47.064843
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) > 0
    assert len(plugin_manager_1.get_auth_plugins()) > 0
    assert len(plugin_manager_1.get_formatters()) > 0
    assert len(plugin_manager_1.get_converters()) > 0
    assert len(plugin_manager_1.get_transport_plugins()) > 0
    assert len(plugin_manager_1.get_auth_plugin_mapping()) > 0
    assert len(plugin_manager_1.get_formatters_grouped()) > 0


# Generated at 2022-06-25 19:13:51.099600
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_2 = PluginManager()
    assert plugin_manager_2.get_auth_plugin_mapping() == {}


# Generated at 2022-06-25 19:13:53.986366
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
  plugin_manager_0 = PluginManager()
  assert plugin_manager_0.get_formatters_grouped() == {u'group-name': [u'mock-type-formatter-v1']}


# Generated at 2022-06-25 19:13:58.897410
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()


# Generated at 2022-06-25 19:14:00.807576
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.filter()
    list_1 = plugin_manager_0.filter(by_type=Type[BasePlugin])


# Generated at 2022-06-25 19:14:05.074738
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    list_1 = plugin_manager_1.get_formatters_grouped()
    list_2 = {}
    assert list_1 == list_2


# Generated at 2022-06-25 19:14:07.256148
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 20

# Generated at 2022-06-25 19:14:12.610726
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()

    #
    # Test 1
    try:
        pm.get_formatters_grouped()
    except Exception as e:
        print('Test 1 failed: ' + str(e))
    else:
        print('Test 1 success.')



# Generated at 2022-06-25 19:14:13.266404
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pass

# Generated at 2022-06-25 19:14:17.054113
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

# Generated at 2022-06-25 19:14:21.420336
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(str)
    plugin_manager_0.register(int)
    plugin_manager_0.register(bool)
    plugin_manager_0.unregister(str)
    list_0 = plugin_manager_0.filter()
    assert len(list_0) == 2


# Generated at 2022-06-25 19:14:25.414439
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.filter(Type)
    list_1 = plugin_manager_0.filter()
    print(plugin_manager_0.get_formatters())
    print(plugin_manager_0.get_formatters_grouped())

# Generated at 2022-06-25 19:14:28.672726
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) >= 3


# Generated at 2022-06-25 19:14:42.276932
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    x_0 = plugin_manager_0.get_auth_plugins()
    x_1 = plugin_manager_0.get_formatters()
    x_2 = plugin_manager_0.get_formatters_grouped()
    x_3 = plugin_manager_0.get_converters()
    x_4 = plugin_manager_0.get_auth_plugin_mapping()
    x_5 = plugin_manager_0.get_auth_plugin('oauth2')
    x_6 = plugin_manager_0.get_transport_plugins()

# Generated at 2022-06-25 19:14:45.429960
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    list_0 = list(plugin_manager_0.get_formatters_grouped())
    list_1 = list(plugin_manager_0.get_formatters_grouped())
    list_2 = list(plugin_manager_0.get_formatters_grouped())
    list_1.sort()
    list_2.sort()
    assert list_0 == list_1 == list_2


# Generated at 2022-06-25 19:14:48.334289
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:14:53.384448
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_converters()
    assert len(list_0) == 2
    assert BasePlugin in list_0
    assert ConverterPlugin in list_0
    assert len(plugin_manager_0) == 4

    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) == 4

# Generated at 2022-06-25 19:14:55.649747
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:14:57.584301
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_formatters_grouped()


if __name__ == '__main__':
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 19:15:00.660614
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_formatters()


# Generated at 2022-06-25 19:15:03.461522
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    by_type = Type[BasePlugin]
    plugin_manager_0.register(**{'_BasePlugin_'})
    plugin_manager_0.filter(by_type=Type[BasePlugin])


# Generated at 2022-06-25 19:15:05.093982
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert True


# Generated at 2022-06-25 19:15:14.953212
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    list_1 = plugin_manager_1.filter(by_type=Type[BasePlugin])
    list_2 = plugin_manager_1.filter(by_type=Type[AuthPlugin])
    list_3 = plugin_manager_1.filter(by_type=Type[ConverterPlugin])
    list_4 = plugin_manager_1.filter(by_type=Type[FormatterPlugin])
    list_5 = plugin_manager_1.filter(by_type=Type[TransportPlugin])
    list_6 = plugin_manager_1.filter(by_type=object)


# Generated at 2022-06-25 19:15:38.822256
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasePlugin)
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.filter(by_type=FormatterPlugin)
    assert(len(list_0) > 0)
    list_0 = plugin_manager_0.filter(by_type=Type[FormatterPlugin])
    assert(len(list_0) > 0)
    list_0 = plugin_manager_0.filter(by_type=AuthPlugin)
    assert(len(list_0) > 0)



# Generated at 2022-06-25 19:15:46.570633
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    # TODO: Real test for method filter of class PluginManager
    assert plugin_manager_0.filter(auth_type='basic')

    # TODO: Actual test for method filter of class PluginManager
    assert plugin_manager_0.filter(auth_type='basic')

    # TODO: Actual test for method filter of class PluginManager
    assert plugin_manager_0.filter(auth_type='basic')

    # TODO: Actual test for method filter of class PluginManager
    assert plugin_manager_0.filter(auth_type='basic')



# Generated at 2022-06-25 19:15:52.458885
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    assert type(plugin_manager_0.get_auth_plugin_mapping()) == dict
    plugin_manager_0.get_auth_plugin_mapping().clear()
    assert type(plugin_manager_0.get_auth_plugin_mapping()) == dict
    plugin_manager_0.get_auth_plugin_mapping().clear()
    assert type(plugin_manager_0.get_auth_plugin_mapping()) == dict


# Generated at 2022-06-25 19:16:02.346356
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.append(class_0)
    plugin_manager.append(class_1)
    plugin_manager.append(class_2)
    plugin_manager.append(class_3)
    dict_ = plugin_manager.get_formatters_grouped()
    keys = dict_.keys()
    assert len(keys) == 2
    assert 'group0' in keys
    assert 'group1' in keys
    group0 = dict_['group0']
    group1 = dict_['group1']
    assert len(group0) == 2
    assert len(group1) == 2
    assert class_0 in group0
    assert class_1 in group0
    assert class_2 in group1
    assert class_3 in group1



# Generated at 2022-06-25 19:16:04.324293
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:16:06.105708
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:16:13.404927
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Initialisation
    plugin_manager_0 = PluginManager()
    plugin_manager_1 = PluginManager()
    plugin_manager_2 = PluginManager()
    plugin_manager_3 = PluginManager()
    plugin_manager_4 = PluginManager()
    plugin_manager_5 = PluginManager()
    plugin_manager_6 = PluginManager()
    plugin_manager_7 = PluginManager()

    # Test 1
    plugin_manager_0.filter()
    plugin_manager_1.filter(by_type='hello')
    plugin_manager_2.filter(by_type=(1, 2, 3))
    plugin_manager_3.filter(by_type=0)
    plugin_manager_4.filter(by_type=0.0)
    plugin_manager_5.filter(by_type=())
    plugin_manager_6

# Generated at 2022-06-25 19:16:17.512027
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:16:20.973131
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_formatters_grouped()
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:16:22.662778
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:17:07.790512
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_auth_plugins()


# Generated at 2022-06-25 19:17:09.149292
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.load_installed_plugins() is None


# Generated at 2022-06-25 19:17:10.426309
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plg_mgr = PluginManager()
    print(plg_mgr.get_formatters_grouped())

# Generated at 2022-06-25 19:17:12.586592
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_case_0()

test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-25 19:17:15.943249
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_formatters_grouped()
    assert len(list_0) > 0


# Generated at 2022-06-25 19:17:18.899113
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:17:21.004309
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:17:22.704594
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:17:27.991341
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_object = PluginManager()
    plugin_manager_object.load_installed_plugins()
    installed_plugins_list = plugin_manager_object.get_formatters()


if __name__ == "__main__":

    test_case_0()
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:17:32.877426
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(PluginManager)
    plugin_manager_0.load_installed_plugins()
    plugin_manager_1 = plugin_manager_0.get_formatters_grouped()
    print(plugin_manager_1)
    print(plugin_manager_0)


# Generated at 2022-06-25 19:19:10.099707
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert(plugin_manager.filter() == [])
    assert(plugin_manager.filter(BasePlugin) == [])

    class MockBasePlugin(BasePlugin):
        pass

    class MockDerivedPlugin(MockBasePlugin):
        pass

    plugin_manager.register(MockBasePlugin, MockDerivedPlugin)
    assert(plugin_manager.filter(BasePlugin) == [
        MockBasePlugin, MockDerivedPlugin
    ])
    assert(plugin_manager.filter(MockBasePlugin) == [MockDerivedPlugin])
    assert(plugin_manager.filter(Type[int]) == [])

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 19:19:14.206593
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    class_dict_0 = {}
    class_dict_0['get_formatters_grouped'] = 'get_formatters_grouped'
    if class_dict_0['get_formatters_grouped'] == 'get_formatters_grouped':
        dict_0 = plugin_manager_0.get_formatters_grouped(plugin_manager_0)
        print(str(dict_0))


# Generated at 2022-06-25 19:19:20.397090
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_converters()
    list_1 = plugin_manager_0.get_auth_plugins()
    list_2 = plugin_manager_0.get_formatters()
    list_3 = plugin_manager_0.get_transport_plugins()

if __name__ == '__main__':
    test_case_0()
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:19:22.463144
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert(plugin_manager_0.get_formatters_grouped())

# Generated at 2022-06-25 19:19:23.706447
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:19:25.478265
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:19:27.913098
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(entry_point_name)
    str_0 = plugin_manager_0.get_auth_plugin_mapping()
    str_1 = plugin_manager_0.get_auth_plugin_mapping()
    str_1 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:19:30.805696
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register('', '', '')
    plugin_manager_0.register('', '', '')
    list_0 = plugin_manager_0.filter(by_type=Type[BasePlugin])
    assert list_0 is not None


# Generated at 2022-06-25 19:19:34.711744
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    # Test for method .filter of class PluginManager
    try:
        plugin_manager_0.filter()
    except KeyError:
        assert False, 'let failed'


# Generated at 2022-06-25 19:19:37.561375
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    # It should return a list of modules after it is loaded
    len(plugin_manager_0) > 0
