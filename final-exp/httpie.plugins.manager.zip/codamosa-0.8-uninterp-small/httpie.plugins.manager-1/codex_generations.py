

# Generated at 2022-06-25 19:10:22.965630
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    import httpie
    http_session = httpie.Session()
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    var_1 = plugin_manager.get_formatters_grouped()
    assert var_1 != None and len(var_1) > 1



# Generated at 2022-06-25 19:10:25.321914
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    var_0 = plugin_manager_0.filter()



# Generated at 2022-06-25 19:10:28.123911
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.load_installed_plugins()
    var_1 = plugin_manager_0.get_formatters_grouped()
    assert len(var_1) > 0

# Generated at 2022-06-25 19:10:40.249379
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    var_0 = plugin_manager.get_auth_plugin_mapping()
    var_1 = plugin_manager.get_formatters_grouped()
    var_2 = plugin_manager.get_transport_plugins()
    var_3 = plugin_manager.get_auth_plugins()
    var_4 = plugin_manager.get_converters()
    var_5 = plugin_manager.get_formatters()
    var_6 = plugin_manager.get_auth_plugin('basic').name
    var_7 = plugin_manager.get_auth_plugin('digest').name
    plugin_manager.register(BasePlugin)
    var_8 = plugin_manager.filter(BasePlugin)
    plugin_manager.unregister(BasePlugin)

# Generated at 2022-06-25 19:10:44.677701
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.load_installed_plugins()
    var_0 = plugin_manager_0.get_auth_plugin_mapping()
    print(var_0)
    
    

# Generated at 2022-06-25 19:10:45.671350
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    test_case_0()
    assert True


# Generated at 2022-06-25 19:10:47.886297
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:10:51.074014
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    var_0 = plugin_manager_0.filter(by_type=TransportPlugin)
    print("var_0 = ", var_0)



# Generated at 2022-06-25 19:10:53.844793
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    # Call function being tested
    var_0 = plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:10:57.550155
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    class_name = 'PluginManager'
    method_name = 'load_installed_plugins'
    test_func(class_name, method_name, test_case_0)

plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()



# Generated at 2022-06-25 19:11:02.569504
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert 1


# Generated at 2022-06-25 19:11:11.671440
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    r = plugin_manager_1.get_formatters_grouped()
    assert r['Console'] == [httpie.plugins.builtin.formatter.HTTPieFormatterPlugin]

# Generated at 2022-06-25 19:11:16.836554
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(HTMLFormatter, XMLEncoder, JSONEncoder)
    assert plugin_manager_1.get_formatters_grouped() == {
        'None': [HTMLFormatter],
        'text/xml': [XMLEncoder],
        'application/json': [JSONEncoder]
    }


# Generated at 2022-06-25 19:11:19.906394
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugins = plugin_manager_0.filter(by_type=Type[BasePlugin])
    assert(len(plugins) == 0)


# Generated at 2022-06-25 19:11:22.877622
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:11:25.988429
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(PrettyJsonFormatterPlugin, PrettyJsonFormatterV2Plugin)
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict)

# Generated at 2022-06-25 19:11:31.121953
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from unittest.mock import patch
    from httpie.plugins.auth import AuthPlugin

    class AuthPluginOne(AuthPlugin):
        auth_type = 'test_auth_plugin_one'

    class AuthPluginTwo(AuthPlugin):
        auth_type = 'test_auth_plugin_two'

    plugin_manager = PluginManager()
    plugin_manager.register(AuthPluginOne, AuthPluginTwo)

    # The expected mapping
    expected_mapping = {
        'test_auth_plugin_one': AuthPluginOne,
        'test_auth_plugin_two': AuthPluginTwo,
    }

    assert plugin_manager.get_auth_plugin_mapping() == expected_mapping


# Integration test for method get_auth_plugin_mapping of class PluginManager
# loading installed plugins

# Generated at 2022-06-25 19:11:34.954414
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(repr(pm))
    assert len(pm) > 0

# Generated at 2022-06-25 19:11:37.268451
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_formatters_grouped() != dict()

# Generated at 2022-06-25 19:11:45.220807
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import auth

    version = 'v1'
    auth_plugin_mapping = dict()
    for entry_point in iter_entry_points('httpie.plugins.auth.{}'.format(version)):
        auth_plugin_mapping[entry_point.name] = entry_point.load()

    assert isinstance(auth_plugin_mapping, dict)
    assert set(auth_plugin_mapping.keys()) == {'bearer', 'basic', 'digest'}
    assert set(auth_plugin_mapping.values()) == \
        {auth.BearerAuthPlugin, auth.BasicAuthPlugin, auth.DigestAuthPlugin}



# Generated at 2022-06-25 19:11:50.214532
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) > 0

# Generated at 2022-06-25 19:11:52.250917
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert len(plugin_manager.filter(FormatterPlugin)) == 0


# Generated at 2022-06-25 19:11:54.441969
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) == 4


# Generated at 2022-06-25 19:11:55.970434
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(TestFormatter)
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:12:02.231531
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_1 = PluginManager()
    plugin_manager_2 = PluginManager()
    plugin_manager_3 = PluginManager()
    plugin_manager_4 = PluginManager()

    plugin_manager_1.register(AuthPlugin)
    plugin_manager_2.register(TransportPlugin)
    plugin_manager_3.register(ConverterPlugin)
    plugin_manager_4.register(FormatterPlugin)
    plugin_manager_4.register(AuthPlugin)
    plugin_manager_4.register(AuthPlugin)
    plugin_manager_2.register(TransportPlugin)
    plugin_manager_3.register(ConverterPlugin)
    plugin_manager_1.register(TransportPlugin)
    plugin_manager_3.register(ConverterPlugin)
    plugin_manager

# Generated at 2022-06-25 19:12:06.534847
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasePlugin)
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:12:08.669637
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    result = plugin_manager_0.get_formatters_grouped()
    assert True


# Generated at 2022-06-25 19:12:15.870148
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin0(BasePlugin):
        pass

    class Plugin1(BasePlugin):
        pass

    class Plugin2(Plugin1):
        pass

    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(Plugin1, Plugin0)
    var_1 = plugin_manager_0.filter(by_type=Plugin1)
    assert var_1 == [Plugin1]
    var_1 = plugin_manager_0.filter(by_type=Plugin2)
    assert var_1 == []
    var_1 = plugin_manager_0.filter(by_type=Plugin0)
    assert var_1 == [Plugin0]


# Generated at 2022-06-25 19:12:19.969557
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    a = AuthPlugin
    b = FormatterPlugin
    c = ConverterPlugin
    d = TransportPlugin
    e = BasePlugin
    f = list
    plugin_manager.register(a, b, c, d, e, f)
    if len(plugin_manager.filter()) != 6:
        print('Error while testing method filter of class PluginManager')


# Generated at 2022-06-25 19:12:21.063413
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:12:31.134736
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # Check the number of plugins in the plugin_manager
    assert len(plugin_manager) == 9

if __name__ == '__main__':
    test_case_0()
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:12:32.863843
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    # Installed plugins are loaded
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:12:35.206295
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.filter(FormatterPlugin) != []
    plugin_manager_0.filter(FormatterPlugin)


# Generated at 2022-06-25 19:12:46.106731
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-25 19:12:56.447944
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert plugin_manager_1.filter(Type[BasePlugin]) == [
        AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin
    ]
    assert plugin_manager_1.filter(Type[AuthPlugin]) == [AuthPlugin]
    assert plugin_manager_1.filter(Type[ConverterPlugin]) == [ConverterPlugin]
    assert plugin_manager_1.filter(Type[FormatterPlugin]) == [FormatterPlugin]
    assert plugin_manager_1.filter(Type[TransportPlugin]) == [TransportPlugin]


# Generated at 2022-06-25 19:13:02.960862
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    # group_name = None
    class Formatter:
        group_name = None
    assert plugin_manager.get_formatters_grouped() == {}
    # group_name = 'video'
    class Formatter_video:
        group_name = 'video'
    class Formatter_video_1:
        group_name = 'video'
    plugin_manager.register(Formatter_video, Formatter_video_1)
    assert plugin_manager.get_formatters_grouped() == {'video': [Formatter_video, Formatter_video_1]}
    # group_name = 'image'
    class Formatter_image:
        group_name = 'image'
    plugin_manager.register(Formatter_image)
    assert plugin_manager.get_formatters_grouped

# Generated at 2022-06-25 19:13:07.843614
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(TestClass1, TestClass2, TestClass3)
    assert plugin_manager.filter(by_type=TestClass2) == [TestClass2]

# Generated at 2022-06-25 19:13:11.746516
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert plugin_manager.filter(by_type=Type[BasePlugin]) == [], "PluginManager.filter() returned wrong value"
    assert plugin_manager.filter(by_type=Type[AuthPlugin]) == [], "PluginManager.filter() returned wrong value"


# Generated at 2022-06-25 19:13:16.158584
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:13:18.733232
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager.filter(), list)
    assert isinstance(plugin_manager.filter(by_type=Type[AuthPlugin]), list)



# Generated at 2022-06-25 19:13:34.564348
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    expected = {'basic': AuthPlugin, 'digest': AuthPlugin, 'ntlm': AuthPlugin, 'oaut': AuthPlugin, 'token': AuthPlugin}
    actual = plugin_manager_0.get_auth_plugin_mapping()
    assert expected == actual



# Generated at 2022-06-25 19:13:38.881620
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_formatters_grouped()



# Generated at 2022-06-25 19:13:44.010723
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    print(plugin_manager_0.get_formatters_grouped())


if __name__ == '__main__':
    test_case_0()
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:13:47.997827
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugins_1 = [
        mock.Mock(spec=('auth_type',)),
        mock.Mock(spec=('auth_type',)),
        mock.Mock(spec=('auth_type',)),
    ]
    plugin_manager_1.register(*plugins_1)
    assert plugin_manager_1.filter(by_type=mock.Mock(spec=('auth_type',))) == plugins_1


# Generated at 2022-06-25 19:13:57.928701
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class AuthPlugin1:
        group_name = "AuthPlugin1"

    class AuthPlugin2:
        group_name = "AuthPlugin1"

    class AuthPlugin3:
        group_name = "AuthPlugin2"

    class AuthPlugin4:
        group_name = "AuthPlugin2"

    class AuthPlugin5:
        group_name = "AuthPlugin3"

    class AuthPlugin6:
        group_name = "AuthPlugin3"

    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin1, AuthPlugin2, AuthPlugin3, AuthPlugin4, AuthPlugin5, AuthPlugin6)
    plugin_manager_grouped_dict = plugin_manager.get_formatters_grouped()
    assert len(plugin_manager_grouped_dict) == 3

# Generated at 2022-06-25 19:14:00.844741
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) > 0



# Generated at 2022-06-25 19:14:08.604556
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    formatters_grouped = plugin_manager_1.get_formatters_grouped()
    assert sorted(formatters_grouped.keys()) == ['assign', 'display', 'none']
    assert len(formatters_grouped['assign']) == 3
    assert len(formatters_grouped['display']) == 1
    assert len(formatters_grouped['none']) == 1

# Generated at 2022-06-25 19:14:12.723124
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1.get_auth_plugins()) > 0
    assert len(plugin_manager_1.get_formatters()) > 0
    assert len(plugin_manager_1.get_converters()) > 0


# Generated at 2022-06-25 19:14:14.383289
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:14:21.451786
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.filter(by_type=Type[BasePlugin])
    assert plugin_manager_0.filter(by_type=Type[AuthPlugin])
    assert plugin_manager_0.filter(by_type=Type[FormatterPlugin])
    assert plugin_manager_0.filter(by_type=Type[ConverterPlugin])
    assert plugin_manager_0.filter(by_type=Type[TransportPlugin])
    assert plugin_manager_0.get_auth_plugins()
    assert plugin_manager_0.get_auth_plugin_mapping()
    assert plugin_manager_0.get_auth_plugin()
    assert plugin_manager_0.get_formatters()

# Generated at 2022-06-25 19:15:00.170147
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Test 0
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    groups_0 = plugin_manager_0.get_formatters_grouped()
    assert len(groups_0) in (0, 1, 2)



# Generated at 2022-06-25 19:15:06.921652
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:15:17.836716
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_2 = PluginManager()
    plugin_manager_3 = PluginManager()
    plugin_manager_4 = PluginManager()
    plugin_manager_5 = PluginManager()
    plugin_manager_6 = PluginManager()
    # Ensures that all the plugins are added to the PluginManager
    plugin_manager_1.register(Plugin1)
    plugin_manager_2.register(Plugin2)
    plugin_manager_3.register(Plugin3)
    plugin_manager_4.register(Plugin4)
    plugin_manager_5.register(Plugin5)
    plugin_manager_6.register(Plugin6)
    # Checks whether the plugins are grouped by the attribute group_name
    assert(plugin_manager_1.get_formatters_grouped() == {})

# Generated at 2022-06-25 19:15:21.156752
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_1.get_formatters_grouped()

# Generated at 2022-06-25 19:15:27.327416
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    # Register all the plugins
    plugin_manager_1.register(FormatterPlugin,FormatterPlugin)
    # Call the method to test
    output=plugin_manager_1.get_formatters_grouped()
    assert type(output) is dict


# Generated at 2022-06-25 19:15:31.833828
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert 1 == len(plugin_manager)
    # print(plugin_manager)
    # print(plugin_manager.get_formatters())
    # print(plugin_manager.get_formatters_grouped())
    # print(plugin_manager.get_converters())
    print(plugin_manager.get_auth_plugins())
    # print(plugin_manager.get_auth_plugin_mapping())
    print(plugin_manager.get_transport_plugins())
    # print(len(plugin_manager.get_transport_plugins()))

# Generated at 2022-06-25 19:15:35.690159
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(TestPluginJson, TestPluginTable)
    assert plugin_manager.get_formatters_grouped() == {
        'JSON': [TestPluginJson],
        'Table': [TestPluginTable],
        'Generic': [],
    }


# Generated at 2022-06-25 19:15:38.209340
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    result = plugin_manager_0.get_auth_plugin_mapping()
    # assert(plugin_manager_0)


# Generated at 2022-06-25 19:15:40.012958
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) > 0


# Generated at 2022-06-25 19:15:42.970413
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.get_formatters_grouped() == {}


# Generated at 2022-06-25 19:16:25.867619
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_1.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:16:27.101927
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()


# Generated at 2022-06-25 19:16:28.737855
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager



# Generated at 2022-06-25 19:16:30.269596
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    

# Generated at 2022-06-25 19:16:32.347567
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    formatters = plugin_manager.get_formatters_grouped()
    assert formatters['base']
    for i in formatters['base']:
        assert i.group_name == 'base'


# Generated at 2022-06-25 19:16:43.026990
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import TransportPlugin

    plugin_manager_1 = PluginManager()
    auth_plugin_1 = AuthPlugin()
    auth_plugin_2 = AuthPlugin()
    formatter_plugin = FormatterPlugin()
    converter_plugin = ConverterPlugin()
    transport_plugin = TransportPlugin()
    plugin_manager_1.register(auth_plugin_1, auth_plugin_2, formatter_plugin,
                              converter_plugin, transport_plugin)
    mapping = plugin_manager_1.get_auth_plugin_mapping()
    assert AuthPlugin in mapping.keys()
    assert FormatterPlugin not in mapping.values()
    assert FormatterPlugin.name not in mapping.keys()
   

# Generated at 2022-06-25 19:16:46.770260
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter.colors import ColorsPlugin
    from httpie.plugins.formatter.format import FormatterPlugin
    plugin_manager_1 = PluginManager()
    plugin_manager_1.append(ColorsPlugin)
    plugin_manager_1.append(FormatterPlugin)
    ems = {'header_color': [ColorsPlugin], 'formatter': [FormatterPlugin]}
    assert plugin_manager_1.get_formatters_grouped() == ems


# Generated at 2022-06-25 19:16:55.821178
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Try load plugins of different type
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) != 0
    # Check auth plugins
    assert len(plugin_manager_1.get_auth_plugins()) != 0
    # Check output plugins
    assert len(plugin_manager_1.get_formatters()) != 0
    # Check input plugins
    assert len(plugin_manager_1.get_converters()) != 0
    # Check adapters
    assert len(plugin_manager_1.get_transport_plugins()) != 0

# Generated at 2022-06-25 19:17:00.630964
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

    # Filter standard plugins to test
    auth_plugins = plugin_manager_1.filter(AuthPlugin)
    assert len(auth_plugins) > 0

    # Filter non-standard plugins
    custom_plugins = plugin_manager_1.filter(object)
    assert custom_plugins == []


# Generated at 2022-06-25 19:17:02.000302
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_formatters_grouped()
    return plugins['Pretty']

# Generated at 2022-06-25 19:18:34.507450
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasicAuthPlugin)
    plugin_manager_0.register(DigestAuthPlugin)
    plugin_manager_0.register(JWTAuthPlugin)
    plugin_manager_0.register(OAuth1AuthPlugin)
    plugin_manager_0.register(OAuth2AuthPlugin)
    print(plugin_manager_0.get_auth_plugin_mapping())


# Generated at 2022-06-25 19:18:40.114328
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin)
    plugin_manager_1.register(ConverterPlugin)
    plugin_manager_1.register(FormatterPlugin)
    plugin_manager_1.register(TransportPlugin)
    assert len(plugin_manager_1.filter()) == 4
    assert len(plugin_manager_1.filter(AuthPlugin)) == 1
    assert len(plugin_manager_1.filter(ConverterPlugin)) == 1
    assert len(plugin_manager_1.filter(FormatterPlugin)) == 1
    assert len(plugin_manager_1.filter(TransportPlugin)) == 1


# Generated at 2022-06-25 19:18:41.872248
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    expected = dict()
    assert plugin_manager.get_auth_plugin_mapping() == expected, "Failed!"


# Generated at 2022-06-25 19:18:45.060858
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.get_formatters_grouped()



# Generated at 2022-06-25 19:18:46.456559
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:18:50.436564
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    # Asserts type of object returned by method get_formatters_grouped
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict)
    # Asserts number of keys in return value
    assert len(plugin_manager_0.get_formatters_grouped().keys()) == 3


# Generated at 2022-06-25 19:18:53.253262
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()

    try:
        plugin_manager_0.load_installed_plugins()
    except:
        assert False



# Generated at 2022-06-25 19:18:57.880859
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) > 0
    assert 'logger' in plugins
    assert 'json' in plugins
    assert 'pickle' in plugins
    assert 'logger' in plugins.get_formatters_grouped()['Human']


# Generated at 2022-06-25 19:19:02.857262
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1.get_auth_plugin_mapping()["basic"] == plugin_manager_1.get_auth_plugin_mapping()["basic"]
    assert plugin_manager_1.get_auth_plugin_mapping()["digest"] == plugin_manager_1.get_auth_plugin_mapping()["digest"]
    print("test_PluginManager_load_installed_plugins: passed")


# Generated at 2022-06-25 19:19:05.413146
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    print(plugin_manager_1.get_auth_plugin_mapping(),'\n\n')
