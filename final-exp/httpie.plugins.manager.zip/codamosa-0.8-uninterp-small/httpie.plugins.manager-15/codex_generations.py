

# Generated at 2022-06-25 19:10:21.981494
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
# /Unit test for method load_installed_plugins of class PluginManager


if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:10:30.279949
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    formatters_grouped = plugin_manager_1.get_formatters_grouped()
    assert formatters_grouped is not None
    assert isinstance(formatters_grouped, dict)
    assert len(formatters_grouped) != 0
    for key, value in formatters_grouped.items():
        assert isinstance(key, str)
        assert key == 'grouped' or key == 'ungrouped'
        assert isinstance(value, list)
        for item in value:
            assert issubclass(item, FormatterPlugin) or issubclass(item, BasePlugin)


if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:10:41.085555
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.get_auth_plugin_mapping() == {}

    plugin_manager_2 = PluginManager()
    plugin_manager_2.append(0)
    plugin_manager_2.append(True)
    assert plugin_manager_2.get_auth_plugin_mapping() == {}

    class plugin_class_0(AuthPlugin):
        auth_type = "Basic"

    class plugin_class_1(AuthPlugin):
        auth_type = "Digest"

    class plugin_class_2(AuthPlugin):
        auth_type = "Basic"

    plugin_manager_3 = PluginManager()
    plugin_manager_3.register(plugin_class_0, plugin_class_1, plugin_class_2)

    assert plugin_manager_3.get_

# Generated at 2022-06-25 19:10:45.931780
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin_mapping()

if __name__ == '__main__':
    test_case_0()
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-25 19:10:56.640968
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.filter( by_type = Type[AuthPlugin] ) == [], "PluginManager.filter should return \'[AuthPlugin]\', return value: " + str( plugin_manager_1.filter( by_type = Type[AuthPlugin] ) )
    assert plugin_manager_1.filter( by_type = Type[ConverterPlugin] ) == [], "PluginManager.filter should return \'[ConverterPlugin]\', return value: " + str( plugin_manager_1.filter( by_type = Type[ConverterPlugin] ) )

# Generated at 2022-06-25 19:10:59.745606
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(AuthPlugin)
    # Test if object returned is empty.
    assert not plugin_manager.filter(ConverterPlugin)
    # Test if object returned is of correct type.
    assert isinstance(plugin_manager.filter(TransportPlugin), list)

# Generated at 2022-06-25 19:11:01.679582
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:11:04.079729
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_auth_plugin_mapping() == {}


# Generated at 2022-06-25 19:11:12.397425
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin)
    assert plugin_manager_1.get_formatters_grouped() == {None: [FormatterPlugin,
                                                                 FormatterPlugin,
                                                                 FormatterPlugin]}
    # Test with 3 plugins in 2 groups
    class Plugin_0(FormatterPlugin):
        group_name = 'group_0'

    class Plugin_1(FormatterPlugin):
        group_name = 'group_0'

    class Plugin_2(FormatterPlugin):
        group_name = 'group_1'

    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(
        Plugin_0,
        Plugin_1,
        Plugin_2)
   

# Generated at 2022-06-25 19:11:14.571138
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-25 19:11:24.728869
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class APlugin(FormatterPlugin):
        group_name = 'a'

    class BPlugin(FormatterPlugin):
        group_name = 'b'

    class CPlugin(FormatterPlugin):
        group_name = 'a'

    plugin_manager = PluginManager()
    plugin_manager.register(APlugin, BPlugin, CPlugin)
    expected_result = {'a': [CPlugin, APlugin], 'b': [BPlugin]}
    assert plugin_manager.get_formatters_grouped() == expected_result

# Generated at 2022-06-25 19:11:27.691292
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    result = plugin_manager_1.get_formatters_grouped()
    assert isinstance(result, dict)


# Generated at 2022-06-25 19:11:38.801409
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import formatter
    from httpie.plugins import core
    import sys
    import os
    import httpie.plugins.builtin
    from httpie.plugins.manager import PluginManager as PM
    from importlib import reload
    from pkg_resources import iter_entry_points
    ENTRY_POINT_NAMES = ["httpie.plugins.formatter.v1"]
    Plugin_Manager = PM()
    # reload(sys.modules.get('httpie.plugins.builtin'))
    # reload(sys.modules.get('httpie.plugins.manager'))
    Plugin_Manager.load_installed_plugins()
    output = Plugin_Manager.get_formatters_grouped()

# Generated at 2022-06-25 19:11:43.260228
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert all(isinstance(key, str)
                   for key in plugin_manager.get_formatters_grouped().keys())
    assert all(isinstance(value, list)
                   for value in plugin_manager.get_formatters_grouped().values())

# Generated at 2022-06-25 19:11:50.178305
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(PluginManager)
    plugin_manager_0.register(BasePlugin)
    plugin_manager_0.register(TransportPlugin)
    plugin_manager_0.register(AuthPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.load_installed_plugins()
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict)

# Generated at 2022-06-25 19:11:58.688365
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()

# Generated at 2022-06-25 19:12:08.254014
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    pp = plugin_manager.load_installed_plugins()
    print("\n")
    print("###############################")
    print("Test Case 0")
    print("###############################")
    print("\n")
    print("Test Case 0: Number of Load Installed Plugins: ")
    print("\n")
    print(len(pp))
    print("\n")
    print("Plugins: ")
    print("\n")
    if len(pp) > 0:
        for p in pp:
            print(pp)



# Generated at 2022-06-25 19:12:11.345374
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    formatters_grouped = plugin_manager_1.get_formatters_grouped()
    assert type(formatters_grouped) == dict


# Generated at 2022-06-25 19:12:13.714117
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(auth_plugin_mapping) == 6

# Generated at 2022-06-25 19:12:20.320488
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    expected_result = {'A': [httpie_jmespath.JMESPathPlugin], 'B': [httpie_paginate.PaginatePlugin, httpie_pretty.PrettyPlugin], 'C': [httpie_csv.CSVFormatter]}
    plugin_manager_1.register(httpie_csv.CSVFormatter, httpie_pretty.PrettyPlugin, httpie_jmespath.JMESPathPlugin, httpie_paginate.PaginatePlugin)
    actual_result = plugin_manager_1.get_formatters_grouped()
    assert actual_result == expected_result


# Generated at 2022-06-25 19:12:34.387766
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # create an empty list of plugins
    plugin_manager_0 = PluginManager()

    # check the list is empty
    assert len(plugin_manager_0) == 0

    # load the plugins into the list
    plugin_manager_0.load_installed_plugins()

    # check that none of the plugins are of the wrong type
    for i in plugin_manager_0:
        assert isinstance(i,BasePlugin)

    # check that there are none with the same name
    for i in range(len(plugin_manager_0)):
        for j in range(len(plugin_manager_0)):
            if i != j:
                assert plugin_manager_0[i].name != plugin_manager_0[j].name, "duplicate plugin name"



# Generated at 2022-06-25 19:12:37.311153
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:12:48.169989
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(httpie.plugins.colors.ColorsPlugin)
    plugin_manager.register(httpie.plugins.format.FormatPlugin)
    plugin_manager.register(httpie.plugins.json.JSONPlugin)
    plugin_manager.register(httpie.plugins.json.PrettyJSONPlugin)
    plugin_manager.register(httpie.plugins.pretty.PrettyPlugin)
    plugin_manager.register(httpie.plugins.raw.RawPlugin)
    plugin_manager.register(httpie.plugins.unicode.UnicodePlugin)
    plugin_manager.register(httpie.plugins.xml.XMLPlugin)

# Generated at 2022-06-25 19:12:52.580359
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    assert isinstance(plugin_manager_1.get_auth_plugin_mapping(), dict)

# Generated at 2022-06-25 19:12:54.549149
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:13:01.681652
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()

    plugin_manager_0.load_installed_plugins()

    #assert plugin_manager_0[0].package_name == 'httpie'
    #assert plugin_manager_0[1].package_name == 'httpie'
    #assert plugin_manager_0[2].package_name == 'httpie'
    #assert plugin_manager_0[3].package_name == 'httpie'
    #assert plugin_manager_0[4].package_name == 'httpie'
    #assert plugin_manager_0[5].package_name == 'httpie'
    #assert plugin_manager_0[6].package_name == 'httpie'
    #assert plugin_manager_0[7].package_name == 'httpie'
    #assert plugin_manager_0[8].package_name

# Generated at 2022-06-25 19:13:05.355530
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    class Test(BasePlugin):
        pass
    class Test1(Test):
        pass
    class Test2(Test):
        pass
    plugin_manager.register(Test1, Test2)
    assert plugin_manager.filter(BasePlugin) == [Test1, Test2]
    assert plugin_manager.filter(Test) == [Test1, Test2]
    assert plugin_manager.filter(Test1) == [Test1]
    assert plugin_manager.filter(Test2) == [Test2]


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 19:13:14.969499
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager_object_0 = test_case_0()
    PluginManager_object_0.load_installed_plugins()
    result = PluginManager_object_0.get_formatters_grouped()

# Generated at 2022-06-25 19:13:16.623549
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    assert(len(plugin_manager_1.filter()) == 0)


# Generated at 2022-06-25 19:13:18.278711
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:13:29.646759
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Create instances for class PluginManager
    plugin_manager_0 = PluginManager()
    # Create an instance for class Type[BasePlugin]
    base_plugin_0 = Type[BasePlugin]()
    # Store the results of calling method filter of plugin_manager_0
    # with the arguments base_plugin_0
    plugin_manager_0_filter_result_0 = plugin_manager_0.filter(by_type=base_plugin_0)
    # Check the size of plugin_manager_0_filter_result_0
    assert len(plugin_manager_0_filter_result_0) == 0
    # Check the value of plugin_manager_0_filter_result_0[0]
    assert plugin_manager_0_filter_result_0[0] == BasePlugin


# Generated at 2022-06-25 19:13:34.955092
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    fmt_output_0 = plugin_manager_0.get_formatters_grouped()
    print(fmt_output_0)

if __name__ == "__main__":
    test_case_0()
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:13:40.933423
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # First, in order to test if filter() works, we need to load a PluginManager to be tested by calling 
    # load_installed_plugins() and then check if the number of loaded plugins is greater than 0
    PluginManager().load_installed_plugins()
    num_installed_plugins = len(PluginManager())
    assert num_installed_plugins > 0
    num_auth_plugins = 0
    num_formatter_plugins = 0
    num_converter_plugins = 0
    num_transport_plugins = 0
    for plugin_type in PluginManager():
        if issubclass(plugin_type, AuthPlugin):
            num_auth_plugins += 1
        elif issubclass(plugin_type, FormatterPlugin):
            num_formatter_plugins += 1

# Generated at 2022-06-25 19:13:44.647436
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) > 0


# Generated at 2022-06-25 19:13:51.908844
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(PluginAuth1)
    plugin_manager.register(PluginAuth2)
    plugin_manager.register(PluginFormatter1)
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert mapping['auth_plugin_1'] == PluginAuth1
    assert mapping['auth_plugin_2'] == PluginAuth2
    assert mapping.get('auth_plugin_3') is None


# Generated at 2022-06-25 19:13:53.947050
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Setup
    plugin_manager = PluginManager()
    # Assert
    assert plugin_manager.get_auth_plugin_mapping() == {}


# Generated at 2022-06-25 19:13:55.682020
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    int_0 = plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:02.173690
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # testing the function when the list of formatters is empty
    plugin_manager_1 = PluginManager()
    assert {} == plugin_manager_1.get_formatters_grouped()
    # testing the function when only one formatter is present in the list
    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(FormatterPlugin)
    expected_output = {'FormatterPlugin': [FormatterPlugin]}
    assert expected_output == plugin_manager_2.get_formatters_grouped()
    # testing the function when two formatters are present in the list
    plugin_manager_3 = PluginManager()
    plugin_manager_3.register(FormatterPlugin)
    plugin_manager_3.register(Json)

# Generated at 2022-06-25 19:14:08.299598
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import testing_plugins
    plugin_manager = PluginManager()
    plugin_manager.register(testing_plugins.TestingPlugin0, testing_plugins.TestingPlugin1, testing_plugins.TestingPlugin2, testing_plugins.TestingPlugin3)
    # assert
    assert plugin_manager.get_formatters_grouped() == {'Test': [testing_plugins.TestingPlugin0, testing_plugins.TestingPlugin1]}

# Generated at 2022-06-25 19:14:13.985795
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    formatter_plugins_0 = plugin_manager_0.filter(FormatterPlugin)

    assert(formatter_plugins_0 != [])

    plugin_manager_0.register(BasePlugin)
    formatter_plugins_1 = plugin_manager_0.filter(FormatterPlugin)

    assert(formatter_plugins_1 == [])



# Generated at 2022-06-25 19:14:33.471275
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin_mapping() == {}


# Generated at 2022-06-25 19:14:35.819594
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    from httpie.plugins.builtin import HTTPBasicAuth
    plugins = plugin_manager_1.filter(HTTPBasicAuth)
    assert len(plugins) == 0



# Generated at 2022-06-25 19:14:38.799504
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = test_case_0()
    temp_var_0 = plugin_manager_0.get_formatters_grouped()
    assert isinstance(temp_var_0, dict)
    assert temp_var_0 == {}



# Generated at 2022-06-25 19:14:42.459559
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    '''
    Test class PluginManager() , method filter
    '''
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(FileUploadPlugin, TransportPlugin, FormatterPlugin,
                              ConverterPlugin, AuthPlugin, HTTPiePlugin)
    assert (plugin_manager_0.filter() == [FileUploadPlugin, TransportPlugin,
                                          FormatterPlugin, ConverterPlugin,
                                          AuthPlugin, HTTPiePlugin])


# Generated at 2022-06-25 19:14:51.835507
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    auth_plugin_mapping = plugin_manager_1.get_auth_plugin_mapping()

# Generated at 2022-06-25 19:14:54.214232
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager



# Generated at 2022-06-25 19:14:55.615192
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.filter() is not None


# Generated at 2022-06-25 19:15:00.449150
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Execute the test and assert that it does not raise an exception
    try:
        plugin_manager_0 = PluginManager()
        plugin_manager_0.load_installed_plugins()
    except Exception as e:
        print(f'Exception caught: {e}')
        assert False


# Generated at 2022-06-25 19:15:02.574281
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert not plugin_manager_0[0].package_name



# Generated at 2022-06-25 19:15:06.268582
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert isinstance(auth_plugin_mapping, dict)
    assert len(auth_plugin_mapping) > 0
    for auth_type, plugin in auth_plugin_mapping.items():
        assert issubclass(plugin, AuthPlugin)
        assert plugin().auth_type == auth_type


# Generated at 2022-06-25 19:15:41.196271
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-25 19:15:47.728013
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    
    assert len(plugin_manager.get_auth_plugins()) == 0
    assert len(plugin_manager.get_formatters()) == 0
    assert len(plugin_manager.get_converters()) == 0
    assert len(plugin_manager.get_transport_plugins()) == 0

    plugin_manager.load_installed_plugins()

    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-25 19:15:53.554379
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin0)
    plugin_manager.register(TestPlugin1)
    plugin_manager.register(TestPlugin2)
    plugin_manager.register(TestPlugin3)
    plugin_manager.register(TestPlugin4)
    plugin_manager.register(TestPlugin5)
    test_case = plugin_manager.get_formatters_grouped()
    assert test_case.get('test_group') != None


# Generated at 2022-06-25 19:16:03.682473
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(AWS)
    plugin_manager_0.register(AuthBasic())
    plugin_manager_0.register(AuthDigest())
    plugin_manager_0.register(AuthPlugin())
    plugin_manager_0.register(Bearer())
    plugin_manager_0.register(DigestAuth())
    plugin_manager_0.register(FormatterPlugin())
    plugin_manager_0.register(HTTPBasicAuth())
    plugin_manager_0.register(HTTPDigestAuth())
    plugin_manager_0.register(HTTPiePlugin())
    plugin_manager_0.register(HTTPiePlugin())
    plugin_manager_0.register(HTTPiePlugin())
    plugin_manager_0.register(HTTPiePlugin())

# Generated at 2022-06-25 19:16:07.098236
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    formatter_plugin = FormatterPlugin()
    pm.register(formatter_plugin)
    assert (isinstance(pm.get_formatters_grouped(), type(dict())))
    assert (pm.get_formatters_grouped()[FormatterPlugin.group_name] == [formatter_plugin])


# Generated at 2022-06-25 19:16:09.413800
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    result = plugin_manager.get_formatters_grouped()
    assert('Extra' in result)
    assert('Main' in result)
    assert('Non-HTTP' in result)


# Generated at 2022-06-25 19:16:15.271612
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.append(plugin_manager_0.get_auth_plugin('basic'))
    plugin_manager_0.append(plugin_manager_0.get_auth_plugin('digest'))
    plugin_manager_0.append(plugin_manager_0.get_auth_plugin('aws4'))

    assert plugin_manager_0 is not None

# Generated at 2022-06-25 19:16:17.398264
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-25 19:16:18.804360
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:16:21.671249
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()

    assert plugin_manager_1.get_formatters_grouped() == {}

    plugin_manager_1.load_installed_plugins()

    assert plugin_manager_1.get_formatters_grouped() != {}


# Generated at 2022-06-25 19:17:42.200954
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(AuthPlugin)
    assert issubclass(AuthPlugin, AuthPlugin)



# Generated at 2022-06-25 19:17:44.941457
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass

    items = [A(), B(), C(), D()]
    
# End Class, Method unit test


# Generated at 2022-06-25 19:17:46.846618
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    # Assert
    assert len(plugin_manager_1) > 0


# Generated at 2022-06-25 19:17:49.318839
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict), 'Failed at test_PluginManager_get_formatters_grouped'


if __name__ == "__main__":
    test_case_0()
    print("Everything passed")

# Generated at 2022-06-25 19:17:53.720355
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(BasePlugin())
    plugin_manager_1.register(TransportPlugin())
    result_1 = plugin_manager_1.filter(TransportPlugin)
    assert result_1 == [TransportPlugin]

    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(TransportPlugin())
    plugin_manager_2.register(TransportPlugin())
    result_2 = plugin_manager_2.filter(TransportPlugin)
    assert result_2 == [TransportPlugin, TransportPlugin]

    plugin_manager_3 = PluginManager()
    plugin_manager_3.register(TransportPlugin())
    plugin_manager_3.register(AuthPlugin())
    plugin_manager_3.register(FormatterPlugin())
    result_3 = plugin_

# Generated at 2022-06-25 19:17:57.063019
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    res = plugin_manager.get_auth_plugin_mapping()
    print(res)
    assert plugin_manager.length == 0


# Generated at 2022-06-25 19:17:58.143685
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert 1 == 1

# Generated at 2022-06-25 19:18:02.152348
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

    plugin_manager.register(DebugFormatter, JSONFormatter, ColoredJSONFormatter)

    formatters_grouped = plugin_manager.get_formatters_grouped()

    assert formatters_grouped == {
        'colors': [ColoredJSONFormatter],
        'debug': [DebugFormatter],
        'json': [JSONFormatter],
    }

# Generated at 2022-06-25 19:18:03.910472
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


plugins = PluginManager()

# Generated at 2022-06-25 19:18:07.070955
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    Test that a plugin manager correctly loads installed plugins
    """
    # load empty plugin manager
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

    # load non-empty plugin manager
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(FormatterPlugin)
    plugin_manager_1.load_installed_plugins()



# Generated at 2022-06-25 19:19:36.593224
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_formatters()) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) > 0

# Generated at 2022-06-25 19:19:39.162090
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    # Check if the number of plugins has increased after loading installed plugins
    assert len(plugin_manager_0) > 0


# Generated at 2022-06-25 19:19:40.362249
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:19:43.033446
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 1
    assert all([issubclass(plugin, BasePlugin) for plugin in plugin_manager])



# Generated at 2022-06-25 19:19:44.154849
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:19:45.727574
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:19:47.030147
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.filter
    print(var_0)


# Generated at 2022-06-25 19:19:49.282377
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_formatters_grouped() == {
        # 'group': [<class 'httpie.plugins.formatter.JSONPrettydev.JSONPrettydev'>]
    }

# Generated at 2022-06-25 19:19:51.161284
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    var_0 = PluginManager()
    var_1 = var_0.get_auth_plugin_mapping()

# Generated at 2022-06-25 19:19:53.145575
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(PluginManager())
    plugin_manager_0.append(PluginManager())
    var_0 = plugin_manager_0.get_formatters_grouped()
