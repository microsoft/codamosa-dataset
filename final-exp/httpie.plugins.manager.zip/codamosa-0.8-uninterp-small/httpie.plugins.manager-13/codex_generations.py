

# Generated at 2022-06-25 19:10:28.082825
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    # There is no plugins installed
    assert plugin_manager == []
    plugin_manager.load_installed_plugins()

    #Auth
    assert plugin_manager.get_auth_plugins() == []
    assert plugin_manager.get_auth_plugin_mapping() == {}

    #Formatters
    assert plugin_manager.get_formatters() != []
    assert plugin_manager.get_formatters_grouped() != {}
    assert plugin_manager.get_converters() != []

    # Adapters
    assert plugin_manager.get_transport_plugins() != []


# Generated at 2022-06-25 19:10:32.442037
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) != 0

# Generated at 2022-06-25 19:10:34.657788
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    print(plugin_manager_0.get_formatters_grouped())


# Generated at 2022-06-25 19:10:42.833181
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Create a plugin manager object
    plugin_manager = PluginManager()

    # Get a list of installed plugins and append it to the plugin manager object
    plugin_manager.load_installed_plugins()

    # Get the formatters from the plugin manager and group them
    formatters_grouped = plugin_manager.get_formatters_grouped()

    # Test for the grouped formatters
    assert 'pretty' in formatters_grouped
    assert 'syntax' in formatters_grouped
    assert 'format' in formatters_grouped

    assert formatters_grouped['pretty'] != formatters_grouped['syntax']
    assert formatters_grouped['pretty'] != formatters_grouped['format']
    assert formatters_grouped['syntax'] != formatters_grouped['format']


# Generated at 2022-06-25 19:10:48.165074
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(AuthPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.register(TransportPlugin)
    plugin_manager_0.filter()


# Generated at 2022-06-25 19:10:53.604430
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.get_formatters_grouped() == {'default': [httpie.plugins.formatter.pretty.PrettyFormatterPlugin],
                                                         'json': [httpie.plugins.formatter.json.JSONFormatterPlugin],
                                                         'xml': [httpie.plugins.formatter.xml.XMLFormatterPlugin]}


# Generated at 2022-06-25 19:10:56.678836
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert set(plugin_manager.get_formatters_grouped().keys()) == {"JSON", "HTML", "Image"}



# Generated at 2022-06-25 19:10:58.647783
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters_grouped()



# Generated at 2022-06-25 19:11:02.281090
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()

    # Verify that the correct type is returned
    assert type(plugin_manager_0.filter(by_type=Type[BasePlugin])) == list


# Generated at 2022-06-25 19:11:06.476179
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPluginMock(FormatterPlugin):
        group_name = 'test'
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(FormatterPluginMock)
    assert(plugin_manager_1.get_formatters_grouped() == {'test': []})


# Generated at 2022-06-25 19:11:10.857079
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-25 19:11:17.124607
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    result = plugin_manager_0.get_formatters_grouped()
    assert len(result) == 2, "Error in class PluginManger method get_formatters_grouped"
    assert result["json"] == list(plugin_manager_0.filter(FormatterPlugin)), "Error in class PluginManger method get_formatters_grouped"
    assert result["other"] == list(plugin_manager_0.filter(FormatterPlugin)), "Error in class PluginManger method get_formatters_grouped"


# Generated at 2022-06-25 19:11:22.579730
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    plugin_manager_0 = PluginManager()

    plugin_manager_0.register(AuthPlugin)
    assert len(plugin_manager_0.filter()) == 1
    plugin_manager_0.register(TransportPlugin)
    assert len(plugin_manager_0.filter()) == 2


# Generated at 2022-06-25 19:11:30.266823
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Create a PluginManager
    plugin_manager = PluginManager()
    # Load plugins
    plugin_manager.load_installed_plugins()
    # Check if AuthPlugin is a subclass of BasePlugin
    assert issubclass(AuthPlugin, BasePlugin)
    # Test filter function
    plugins = plugin_manager.filter(AuthPlugin)
    # Check if it's a list
    assert isinstance(plugins, list)
    # Check if the first plugin is a subclass of AuthPlugin
    assert issubclass(type(plugins[0]), AuthPlugin)
    # Check if the first plugin is a subclass of BasePlugin
    assert issubclass(type(plugins[0]), BasePlugin)


# Generated at 2022-06-25 19:11:36.914206
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasePlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    assert plugin_manager_0.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager_0.filter(ConverterPlugin) == [ConverterPlugin]



# Generated at 2022-06-25 19:11:42.980166
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    auth_plugins = plugin_manager.get_auth_plugins()
    assert auth_plugins == plugin_manager.filter(AuthPlugin) and auth_plugins is not plugin_manager.filter(AuthPlugin)
    assert plugin_manager.filter(AuthPlugin) is not plugin_manager.filter(ConverterPlugin)
    assert plugin_manager.filter(AuthPlugin) == plugin_manager.filter(AuthPlugin)
    assert plugin_manager.filter(BasePlugin) == plugin_manager


# Generated at 2022-06-25 19:11:45.141576
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)


# Generated at 2022-06-25 19:11:54.997378
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # The list of plugins
    plugin_list = [
        'httpie.plugins.auth.v1',
        'httpie.plugins.formatter.v1',
        'httpie.plugins.converter.v1',
        'httpie.plugins.transport.v1'
    ]
    
    plugin_manager = PluginManager()

    # Add all the plugins to manager
    for plugin in plugin_list:
        plugin_manager.register(plugin)

    plugin_manager.register()

    # Test for method for getting format plugins
    plugins_format = plugin_manager.filter("httpie.plugins.formatter.v1")
    assert isinstance(plugins_format, List)
    for plugin_format in plugins_format:
        assert isinstance(plugin_format, Type[FormatterPlugin])

    # Test for method for getting

# Generated at 2022-06-25 19:11:56.959664
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) != 0



# Generated at 2022-06-25 19:11:59.077915
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert mapping is plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:12:07.503958
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(FormatterPlugin)
    assert plugin_manager_1.get_formatters_grouped() == {}
    plugin_manager_1.append(FormatterPlugin)
    assert plugin_manager_1.get_formatters_grouped() == {}
    plugin_manager_1.append(FormatterPlugin)
    assert plugin_manager_1.get_formatters_grouped() == {}
    plugin_manager_1.append(FormatterPlugin)
    assert plugin_manager_1.get_formatters_grouped() == {}

# Generated at 2022-06-25 19:12:12.000746
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert isinstance(formatters_grouped, dict)
    for key in formatters_grouped:
        assert isinstance(key, str)
        for i in formatters_grouped[key]:
            assert isinstance(i, FormatterPlugin)

# Generated at 2022-06-25 19:12:18.474160
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager1 = PluginManager()
    plugin_manager1.register(httpie.plugins.formatter.v1.JSONFormatterPlugin,
                             httpie.plugins.formatter.v1.XMLFormatterPlugin,
                             httpie.plugins.formatter.v1.PrettytablesFormatterPlugin,
                             httpie.plugins.formatter.v1.JSONStreamFormatterPlugin)

    # Test for default results
    test_result_formatters_grouped = plugin_manager1.get_formatters_grouped()
    assert test_result_formatters_grouped == {'json': [JSONFormatterPlugin], 'xml': [XMLFormatterPlugin], 'tables': [PrettytablesFormatterPlugin], 'debug': [JSONStreamFormatterPlugin]}


# Generated at 2022-06-25 19:12:25.780758
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert 0 == len(plugin_manager_0.filter(by_type=Type[AuthPlugin]))
    assert 0 == len(plugin_manager_0.filter(by_type=Type[FormatterPlugin]))
    assert 0 == len(plugin_manager_0.filter(by_type=Type[ConverterPlugin]))
    assert 0 == len(plugin_manager_0.filter(by_type=Type[TransportPlugin]))



# Generated at 2022-06-25 19:12:34.974776
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

    # Case 0
    _output = plugin_manager_0.get_auth_plugin_mapping()
    assert _output == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
        'oauth1': httpie.plugins.auth.oauth1.OAuth1Plugin,
        'jwt': httpie.plugins.auth.jwt.JWTAuthPlugin
    }


# Generated at 2022-06-25 19:12:45.812437
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    test_case = PluginManager()
    test_case.register(JsonPlugin)
    test_case.register(ColoredJsonPlugin)
    test_case.register(JythonJsonPlugin)
    test_case.register(TsvPlugin)
    test_case.register(JsonColor)
    test_case.register(TablePlugin)
    test_case.register(JsonPrettyPlugin)
    test_case.register(CsvPlugin)
    test_case.register(ColoredTsvPlugin)
    test_case.register(ColoredTablePlugin)
    test_case.register(JsonPrettyColoredPlugin)
    test_case.register(JsonHtmlPlugin)
    test_case.register(ColoredJsonPrettyPlugin)
    test_case.register(JsonHtmlColoredPlugin)
    test_

# Generated at 2022-06-25 19:12:46.534174
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:12:56.718568
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(OAuth1AuthPlugin, OAuth2AuthPlugin)

    # the method get_auth_plugin_mapping returns a dictionary
    assert type(plugin_manager.get_auth_plugin_mapping()) == dict

    # the dictionary returned by method get_auth_plugin_mapping contains all the
    # plugin instances for which the key equals to their auth_type
    for auth_plugin in plugin_manager.get_auth_plugins():
        assert auth_plugin.auth_type in plugin_manager.get_auth_plugin_mapping()
        assert auth_plugin == plugin_manager.get_auth_plugin_mapping()[auth_plugin.auth_type]

# Generated at 2022-06-25 19:12:58.991585
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin_0,FormatterPlugin_1)
    plugin_manager.get_formatters_grouped()


# Generated at 2022-06-25 19:13:00.247796
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:13:09.665591
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    assert isinstance(plugin_manager_0.get_auth_plugin_mapping(), dict)


# Generated at 2022-06-25 19:13:12.468791
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register()
    plugin_manager_0.get_formatters_grouped()
    assert True


# Generated at 2022-06-25 19:13:15.705435
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    # plugin_manager.load_installed_plugins()
    # print(plugin_manager)


# Generated at 2022-06-25 19:13:18.664139
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    plugins = [Plugin1, Plugin2]
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)

    grouped_plugins_dict = plugin_manager.get_formatters_grouped()

    assert grouped_plugins_dict


# Generated at 2022-06-25 19:13:23.154340
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

    assert len(plugin_manager_1) == 7

    assert len(plugin_manager_1.filter(AuthPlugin)) == 1
    assert len(plugin_manager_1.filter(FormatterPlugin)) == 4
    assert len(plugin_manager_1.filter(ConverterPlugin)) == 1
    assert len(plugin_manager_1.filter(TransportPlugin)) == 1


# Generated at 2022-06-25 19:13:24.972791
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) > 0

# Generated at 2022-06-25 19:13:28.263459
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.append(AuthPlugin)
    plugin_manager_1.append(TransportPlugin)
    assert plugin_manager_1.get_auth_plugin_mapping() == {'auth': AuthPlugin}



# Generated at 2022-06-25 19:13:30.955486
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:13:39.582834
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasicAuthPlugin, DigestAuthPlugin)
    # Verify that the object plugin_manager_0 is instance of PluginManager class
    assert isinstance(plugin_manager_0, PluginManager)
    # Verify that the method get_auth_plugin_mapping returns a dictionary
    assert isinstance(plugin_manager_0.get_auth_plugin_mapping(), dict)
    # Verify that the method get_auth_plugin_mapping returns a correct mapping
    assert plugin_manager_0.get_auth_plugin_mapping()['basic'] == BasicAuthPlugin
    assert plugin_manager_0.get_auth_plugin_mapping()['digest'] == DigestAuthPlugin
    assert len(plugin_manager_0.get_auth_plugin_mapping()) == 2

# Unit test

# Generated at 2022-06-25 19:13:41.218490
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_auth_plugin_mapping()

# Generated at 2022-06-25 19:13:58.923378
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_1.append(plugin_manager_1)
    assert (plugin_manager_1[0].get_formatters_grouped()['_all'][4].__name__ == 'HighlightFormatter')

# Generated at 2022-06-25 19:14:05.127490
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    print(plugin_manager_1.get_converters())
    print(plugin_manager_1.get_formatters())

if __name__ == '__main__':
    test_case_0()
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:14:06.166287
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pass


# Generated at 2022-06-25 19:14:09.277616
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    exp_result = {}
    assert plugin_manager_0.get_formatters_grouped() == exp_result



# Generated at 2022-06-25 19:14:12.858029
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1 == []
    # load installed plugins
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) != 0
    for plugin in plugin_manager_1:
        assert type(plugin) == type

# Generated at 2022-06-25 19:14:18.828305
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    fake_plugin_manager = PluginManager()
    fake_plugin_manager.register(FakeGroupedPlugin0,
                                 FakeGroupedPlugin1,
                               )
    grouped_test = fake_plugin_manager.get_formatters_grouped()
    assert len(grouped_test) == 2
    assert list(grouped_test['group0']) == [FakeGroupedPlugin0, FakeGroupedPlugin1]
    assert list(grouped_test['group1']) == [FakeGroupedPlugin0, FakeGroupedPlugin1]



# Generated at 2022-06-25 19:14:28.875351
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin, FormatterPlugin)
    assert plugin_manager_1.get_auth_plugin_mapping() == {}
    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(AuthPlugin, FormatterPlugin, ConverterPlugin)
    assert plugin_manager_2.get_auth_plugin_mapping() == {}
    plugin_manager_3 = PluginManager()
    plugin_manager_3.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    plugin_manager_3.register(AuthBasicAuth)

# Generated at 2022-06-25 19:14:31.385976
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:14:33.671888
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()

    plugin_manager.register(Plugin_0, Plugin_1)




# Generated at 2022-06-25 19:14:37.221306
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    print('passed')

if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:14:57.705099
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Test with a given input value
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:58.972761
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_case_0()



# Generated at 2022-06-25 19:15:04.931267
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_formatters_grouped()
    plugin_manager_0.load_installed_plugins()
    dict_1 = plugin_manager_0.get_formatters_grouped()
    assert dict_1 != dict_0


# Generated at 2022-06-25 19:15:06.736808
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:15:08.168567
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:15:11.381621
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    test_case_0()

# Generated at 2022-06-25 19:15:13.460974
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_8 = PluginManager()
    dict_0 = plugin_manager_8.get_auth_plugin_mapping()



# Generated at 2022-06-25 19:15:16.973380
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Create plugin manager instance
    plugin_manager_2 = PluginManager()
    # Load installed plugins
    plugin_manager_2.load_installed_plugins()
    # Get formatters grouped
    dict_0 = plugin_manager_2.get_formatters_grouped()



# Generated at 2022-06-25 19:15:25.165453
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Initialize plugin_manager_0 with parameter list [],
    plugin_manager_0 = PluginManager()
    # Initialize plugin_manager_1 with parameters list [TransportPlugin] and
    # list [plugin_manager_2]
    plugin_manager_1 = PluginManager([TransportPlugin], [plugin_manager_2])
    # Initialize plugin_manager_2 with parameters list [],
    plugin_manager_2 = PluginManager([])
    # Initialize plugin_manager_3 with parameters list [] and list
    # [plugin_manager_0]
    plugin_manager_3 = PluginManager([], [plugin_manager_0])
    # Initialize plugin_manager_4 with parameters list [] and list
    # [plugin_manager_0, plugin_manager_1, plugin_manager_2, plugin_manager_3]
    plugin_manager_

# Generated at 2022-06-25 19:15:36.618310
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()

    class A:
        pass

    class B:
        pass

    class C:
        pass

    pm.register(A, B, C)

    assert pm.filter() == pm
    assert pm.filter(by_type=A) == [A]
    assert pm.filter(by_type=B) == [B]
    assert pm.filter(by_type=C) == [C]

    class AB(A, B):
        pass

    class X:
        pass

    pm.register(AB, X)

    assert pm.filter(by_type=A) == [A, AB]
    assert pm.filter(by_type=X) == [X]

    assert pm == [A, B, C, AB, X]


# Generated at 2022-06-25 19:16:21.323113
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_formatters_grouped()
    dict_1 = {'json': [], 'html': [], 'org': [], 'unix': [], 'table': [], 'colors': [], 'syntax': [], 'multipart': [], 'csv': []}
    assert dict_0 == dict_1

# Generated at 2022-06-25 19:16:27.918036
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(type('_SuppressWriteAny_0', (object,), {'_SuppressWriteAny_0': (lambda self: None)}))
    plugin_manager_0.register(type('_SuppressWriteAny_1', (object,), {'_SuppressWriteAny_1': (lambda self: None)}))
    plugin_manager_0.register(type('_SuppressWriteAny_2', (object,), {'_SuppressWriteAny_2': (lambda self: None)}))
    plugin_manager_0.register(type('_SuppressWriteAny_3', (object,), {'_SuppressWriteAny_3': (lambda self: None)}))

# Generated at 2022-06-25 19:16:29.265635
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:16:39.177093
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(auth_aws.AwsAuthPlugin)
    plugin_manager_1.register(auth_aws.AwsAuthPlugin)
    plugin_manager_1.register(auth_aws.AwsAuthPlugin)
    plugin_manager_1.register(auth_aws.AwsAuthPlugin)
    plugin_manager_1.register(auth_aws.AwsAuthPlugin)
    plugin_manager_1.register(auth_aws.AwsAuthPlugin)
    plugin_manager_1.register(auth_aws.AwsAuthPlugin)
    plugin_manager_1.register(auth_aws.AwsAuthPlugin)
    plugin_manager_1.register(auth_aws.AwsAuthPlugin)

# Generated at 2022-06-25 19:16:40.725436
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.filter()


# Generated at 2022-06-25 19:16:45.282638
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()

    # Unit test for method get_formatters_grouped of class PluginManager
    # Basic test: assert that value returned is proper type and not empty
    assert plugin_manager_0.get_formatters_grouped() is not None, \
        "get_formatters_grouped method of PluginManager returns None"

    format_dict = plugin_manager_0.get_formatters_grouped()

    assert isinstance(format_dict, dict)

# Generated at 2022-06-25 19:16:51.613609
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    #test method's behavior
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()
    assert 'basic' in dict_0
    assert 'digest' in dict_0
    assert isinstance(dict_0['basic'], type)
    assert isinstance(dict_0['digest'], type)


# Generated at 2022-06-25 19:17:01.265709
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_formatters_grouped()
    plugin_manager_0.register(dict_0)
    plugin_manager_0.unregister(dict_0)
    list_0 = plugin_manager_0.filter([])
    output = plugin_manager_0.get_auth_plugin_mapping()
    plugin_manager_0.get_formatters()
    plugin_manager_0.get_transport_plugins()
    plugin_manager_0.get_auth_plugins()
    plugin_manager_0.get_converters()
    plugin_manager_0.get_auth_plugin('basic')
    plugin_manager_0.__repr__()



# Generated at 2022-06-25 19:17:06.731252
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:17:12.289752
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    # Enable cext
    import httpie.plugins.builtin
    plugin_manager_0.register(httpie.plugins.builtin.S3AuthPlugin, httpie.plugins.builtin.KeyAuthPlugin)
    # Disable cext
    # plugin_manager_0.register(httpie.plugins.builtin.S3AuthPlugin)

# Generated at 2022-06-25 19:18:40.531406
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_formatters_grouped()

    assert(dict_0 != None)
    assert(len(dict_0) > 0)


# Generated at 2022-06-25 19:18:41.821530
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    
    # Test with no arguments / defaults
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    


# Generated at 2022-06-25 19:18:50.125619
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Test code here
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_formatters_grouped()
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict_0
    dict

# Generated at 2022-06-25 19:18:56.277021
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

    # Method filter is called on an object of type PluginManager
    assert len(plugin_manager.filter(AuthPlugin)) == 1
    assert len(plugin_manager.filter(FormatterPlugin)) == 1
    assert len(plugin_manager.filter(ConverterPlugin)) == 1
    assert len(plugin_manager.filter(TransportPlugin)) == 1


# Generated at 2022-06-25 19:18:58.988487
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    list_0 = plugin_manager_1.filter(by_type='QyGnym')


# Generated at 2022-06-25 19:19:01.353588
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    expected_value_0 = {}
    actual_value_0 = plugin_manager_0.get_formatters_grouped()
    assert (actual_value_0 == expected_value_0)


# Generated at 2022-06-25 19:19:02.589816
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.filter()



# Generated at 2022-06-25 19:19:09.620124
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasePlugin, AuthPlugin, FormatterPlugin,
                              ConverterPlugin, TransportPlugin)
    # assert(plugin_manager_0.filter() == [BasePlugin, AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin])
    # assert(plugin_manager_0.filter(Type[BasePlugin]) == [BasePlugin, AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin])
    # assert(plugin_manager_0.filter(Type[AuthPlugin]) == [AuthPlugin])
    # assert(plugin_manager_0.filter(Type[FormatterPlugin]) == [FormatterPlugin])
    # assert(plugin_manager_0.filter(Type[ConverterPlugin]) == [ConverterPlugin])
    # assert(plugin_manager_0.filter(Type[

# Generated at 2022-06-25 19:19:16.058873
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()

# Generated at 2022-06-25 19:19:19.538458
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.filter(FormatterPlugin)
    assert(len(dict_0) == 1)