

# Generated at 2022-06-25 19:10:21.011059
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0.get_transport_plugins()) == 1

# Generated at 2022-06-25 19:10:22.922243
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:10:26.633919
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()

    assert plugin_manager_1.get_auth_plugin_mapping() == {}

    plugin_manager_1.register(AuthPlugin)

    assert plugin_manager_1.get_auth_plugin_mapping() == {'Plugin_auth': AuthPlugin}



# Generated at 2022-06-25 19:10:29.045217
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    # Instantiating a PluginManager object
    plugin_manager_2 = PluginManager()
    plugin_manager_2.load_installed_plugins()
    assert len(plugin_manager_2) > 0


# Generated at 2022-06-25 19:10:35.863237
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    Test case for method load_installed_plugins of class PluginManager.

    To test whether the method load_installed_plugins of class PluginManager
    is working properly.

    """
    pm_0 = PluginManager()
    pm_0.load_installed_plugins()
    assert len(pm_0) > 0, "Possible problem with the method PluginManager.load_installed_plugin"



# Generated at 2022-06-25 19:10:38.942433
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

    assert plugin_manager_1[0].__name__ == 'HTTPBasicAuth'


# Generated at 2022-06-25 19:10:41.847410
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_formatters_grouped()
    assert 1


# Generated at 2022-06-25 19:10:45.618277
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()
    assert len(dict_0) == 2


# Generated at 2022-06-25 19:10:49.632638
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert mapping.keys() == {'basic', 'digest'}
    assert mapping['basic'] == BasicAuthPlugin


# Generated at 2022-06-25 19:10:54.350957
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Create a PluginManager object and load installed plugins in it
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # Load installed plugins in a new PluginManager object
    plugin_manager_0 = PluginManager()
    # Compare two objects of PluginManager class
    assert plugin_manager == plugin_manager_0



# Generated at 2022-06-25 19:11:01.576869
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1.__len__() == 5



# Generated at 2022-06-25 19:11:04.445484
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    result = plugin_manager.filter(by_type=Type[BasePlugin])
    assert (not result)


# Generated at 2022-06-25 19:11:12.608851
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # test case 0
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(AuthPlugin)
    assert plugin_manager_0.get_auth_plugin_mapping() == {}
    # test case 1
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin)
    plugin_manager_1.register(AuthenticationPlugin)
    assert plugin_manager_1.get_auth_plugin_mapping() == {}
    # test case 2
    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(AuthPlugin)
    plugin_manager_2.register(AuthenticationPlugin)
    plugin_manager_2.register(BasicAuthPlugin)
    assert plugin_manager_2.get_auth_plugin_mapping() == {}
    # test case 3
   

# Generated at 2022-06-25 19:11:23.023170
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-25 19:11:27.212695
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    auth_plugins = plugin_manager.get_auth_plugins()
    assert isinstance(auth_plugins, list)


# Generated at 2022-06-25 19:11:29.337687
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    print(plugin_manager_0.get_formatters_grouped())


# Generated at 2022-06-25 19:11:40.299949
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

    # Get a list of formatters from the plugin manager
    formatters = plugin_manager.get_formatters_grouped()
    group_name = list(formatters.keys())[0]

    # Check if we can get the correct names of the formatters
    assert formatters[group_name][0].mimetype == "application/json"
    assert formatters[group_name][1].mimetype == "application/javascript"
    assert formatters[group_name][2].mimetype == "text/json"
    assert formatters[group_name][3].mimetype == "text/javascript"
    assert formatters[group_name][4].mimetype == "text/x-json"

# Generated at 2022-06-25 19:11:45.259488
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin0, Plugin1, Plugin2, Plugin3)

    assert list(plugin_manager.filter(Plugin1)) == [Plugin1]
    assert set(plugin_manager.filter(Plugin0)) == {Plugin0, Plugin1}
    assert list(plugin_manager.filter(Plugin4)) == []



# Generated at 2022-06-25 19:11:50.311406
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.append(httpie.plugins.formatter.pretty.PrettyPlugin)
    plugin_manager_1.append(httpie.plugins.formatter.colors.ColorsPlugin)

    assert_equals(type(plugin_manager_1.get_formatters_grouped()),type({}))


# Generated at 2022-06-25 19:11:52.963624
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:11:57.946328
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugins_by_type = plugin_manager_0.filter(AuthPlugin)
    assert len(plugins_by_type) == 0



# Generated at 2022-06-25 19:12:04.895231
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(DesiredClass1, DesiredClass2)
    plugin_manager_1.filter()
    plugin_manager_1.get_formatters_grouped()
    plugin_manager_1.get_converters()
    plugin_manager_1.get_auth_plugins()
    plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:12:14.566005
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-25 19:12:16.169812
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:12:18.501905
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_1.get_auth_plugin_mapping()



# Generated at 2022-06-25 19:12:28.333663
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    """Testing with one plugin"""
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.get_formatters_grouped()
    """Testing with multiple plugins"""
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.get_formatters_grouped()
    """Testing with all plugins"""
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0

# Generated at 2022-06-25 19:12:39.179071
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(HTTPBasicAuth)
    plugin_manager_0.register(HTTPBasicAuth)
    plugin_manager_0.register(HTTPBasicAuth)
    plugin_manager_0.register(HTTPBasicAuth)
    assert plugin_manager_0.__sizeof__() == 56
    assert plugin_manager_0.__sizeof__() == 56
    assert plugin_manager_0.__sizeof__() == 56
    assert plugin_manager_0.__sizeof__() == 56
    assert plugin_manager_0.__sizeof__() == 56
    assert plugin_manager_0.__sizeof__() == 56
    assert plugin_manager_0.__sizeof__() == 56
    assert plugin_manager_0.__sizeof__() == 56
    assert plugin_

# Generated at 2022-06-25 19:12:44.316220
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert(len(plugin_manager_1) > 0)

# Generated at 2022-06-25 19:12:45.812526
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:12:47.668439
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.filter() == []


# Generated at 2022-06-25 19:12:54.305606
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    assert isinstance(plugin_manager_1.get_formatters_grouped(), dict)

# Generated at 2022-06-25 19:12:56.411554
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_formatters_grouped()


# Generated at 2022-06-25 19:12:58.120712
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager.get_auth_plugin_mapping(), dict)



# Generated at 2022-06-25 19:12:59.967315
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    mapping = plugin_manager.get_auth_plugin_mapping()
    # print("\n", mapping)
    assert mapping == {}


# Generated at 2022-06-25 19:13:08.286247
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(FormatterPlugin)
    plugin_manager_1.register(FormatterPlugin)
    plugin_manager_1.register(FormatterPlugin)
    assert plugin_manager_1.get_formatters() == [FormatterPlugin, FormatterPlugin, FormatterPlugin]
    assert plugin_manager_1.get_formatters_grouped() == {'Base': [FormatterPlugin, FormatterPlugin, FormatterPlugin]}


# Generated at 2022-06-25 19:13:09.497232
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()



# Generated at 2022-06-25 19:13:12.580281
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugins_grouped = plugin_manager_0.get_formatters_grouped()
    assert(len(plugins_grouped) == 0)



# Generated at 2022-06-25 19:13:14.111885
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:13:15.704752
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()



# Generated at 2022-06-25 19:13:17.267280
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:13:31.394096
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert True


# Generated at 2022-06-25 19:13:39.767692
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # create
    pm = PluginManager()
    pm.load_installed_plugins()
    # test size
    assert len(pm) == 32
    # test auth plugins
    assert isinstance(pm[0], PluginManager.get_auth_plugin_mapping()['basic'])
    assert isinstance(pm[1], PluginManager.get_auth_plugin_mapping()['digest'])
    assert isinstance(pm[2], PluginManager.get_auth_plugin_mapping()['hawk'])
    assert isinstance(pm[3], PluginManager.get_auth_plugin_mapping()['ntlm'])
    assert isinstance(pm[4], PluginManager.get_auth_plugin_mapping()['oauth1'])
    # test filter auth plugins
    assert len(plugin_manager.filter(AuthPlugin)) == 5



# Generated at 2022-06-25 19:13:41.330981
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:13:48.045770
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.get_auth_plugin_mapping() == {}

    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(AuthPlugin)
    assert plugin_manager_2.get_auth_plugin_mapping() == {AuthPlugin.auth_type: AuthPlugin}

    plugin_manager_3 = PluginManager()
    plugin_manager_3.register(AuthPlugin, AuthPlugin)
    assert plugin_manager_3.get_auth_plugin_mapping() == {AuthPlugin.auth_type: AuthPlugin}



# Generated at 2022-06-25 19:13:57.640659
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class html_formatter(FormatterPlugin):
        group_name = 'HTML'

    class json_formatter(FormatterPlugin):
        group_name = 'JSON'

    class xml_formatter(FormatterPlugin):
        group_name = 'XML'

    plugin_manager = PluginManager()
    plugin_manager.register(
        html_formatter,
        json_formatter,
        xml_formatter
    )

    expected = {'HTML': [html_formatter,],
                'XML': [xml_formatter,],
                'JSON': [json_formatter,]}
    assert plugin_manager.get_formatters_grouped() == expected


if __name__ == "__main__":
    pytest.main(['-x', __file__])

# Generated at 2022-06-25 19:14:02.839342
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Test case 0
    plugin_manager_0 = PluginManager()
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict), f"plugin_manager_0.get_formatters_grouped() returned {plugin_manager_0.get_formatters_grouped()}, but should return <class 'dict'>"


# Generated at 2022-06-25 19:14:07.401725
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import pytest
    plugin_manager_1 = PluginManager()
    plugin_manager_1.append(BasePlugin)
    d_expected = {'default': [HttpiePlugin, CurlFormatPlugin, AddonFormatPlugin]}
    assert d_expected == plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:14:11.688181
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:14:14.655305
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(FormatterPlugin)
    dict_0 = plugin_manager_0.get_formatters_grouped()
    assert dict_0 == {}

# Generated at 2022-06-25 19:14:21.574009
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    formatters_grouped = plugin_manager_0.get_formatters_grouped()

    assert type(formatters_grouped) is dict, 'Grouped formatters are not returned as a dict'

    # Validate that all formatters have a corresponding key in the dict
    for formatter in plugin_manager_0.get_formatters():
        assert formatter.group_name in formatters_grouped, 'Not all formatters are included in the dict'

    # Validate that all keys in the dict map to a list
    for group_name in formatters_grouped:
        assert type(formatters_grouped[group_name]) is list, 'Formatters are not returned as a list of formatters in the dict'

    # Validate

# Generated at 2022-06-25 19:14:54.743887
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    #   Test that the method outputs dictionaries grouped by the class attribute `group_name`
    formatters_grouped_1 = plugin_manager_1.get_formatters_grouped()
    assert formatters_grouped_1
    assert len(formatters_grouped_1.keys()) >= len(plugin_manager_1.get_formatters())
    for key in formatters_grouped_1.keys():
        for value in formatters_grouped_1[key]:
            assert hasattr(value, 'group_name')
            assert value.group_name == key


# Generated at 2022-06-25 19:15:01.406666
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, JSONStreamSinkAdapter
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(HTTPBasicAuth)
    plugin_manager_0.register(JSONStreamSinkAdapter)
    plugin_manager_0.filter(AuthPlugin).__eq__([HTTPBasicAuth])
    plugin_manager_0.filter(ConverterPlugin).__eq__([JSONStreamSinkAdapter])
    plugin_manager_0.filter(FormatterPlugin).__eq__([])
    plugin_manager_0.filter(TransportPlugin).__eq__([])
    plugin_manager_0.filter(BasePlugin).__eq__([HTTPBasicAuth, JSONStreamSinkAdapter])
    # For line coverage only
    plugin_manager_0.filter(by_type=AuthPlugin)
    plugin_

# Generated at 2022-06-25 19:15:11.885309
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    formatters_0 = plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:15:17.323552
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin0 = type('plugin0', (FormatterPlugin,), {'group_name': 'group0'})
    plugin1 = type('plugin1', (FormatterPlugin,), {'group_name': 'group1'})
    plugin_manager0 = PluginManager()
    plugin_manager0.extend([plugin0, plugin1])
    assert plugin_manager0.get_formatters_grouped() == {'group0': [plugin0], 'group1': [plugin1]}

# Generated at 2022-06-25 19:15:20.513397
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    return len(plugin_manager)


# Generated at 2022-06-25 19:15:25.497524
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager.get_formatters_grouped())

# Generated at 2022-06-25 19:15:29.662010
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 0



# Generated at 2022-06-25 19:15:35.649493
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(HttpiePlugin, HttpiePlugin_Another)
    plugin_manager_1_output = plugin_manager_1.get_formatters_grouped()
    expected_output = {'group_1': [HttpiePlugin, HttpiePlugin_Another],
                       'group_2': [HttpiePlugin, HttpiePlugin_Another]}
    assert plugin_manager_1_output == expected_output


# Generated at 2022-06-25 19:15:37.390511
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    a = PluginManager()
    assert a.get_auth_plugin_mapping() == {}


# Generated at 2022-06-25 19:15:39.657350
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) == 8


# Generated at 2022-06-25 19:16:31.994159
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:16:36.583906
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    """
    Get a mapping of auth plugins
    """
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin(), FormatterPlugin(), TransportPlugin())
    assert plugin_manager_1.get_auth_plugin_mapping() == \
        {'auth_type': AuthPlugin()}



# Generated at 2022-06-25 19:16:40.726214
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(TestFormatter)
    formatters = pm.get_formatters_grouped()
    assert 'TestGroup' in formatters
    assert TestFormatter in formatters['TestGroup']



# Generated at 2022-06-25 19:16:45.283446
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2, Plugin3, Plugin4)
    group_name_dict = plugin_manager.get_formatters_grouped()
    assert group_name_dict['httpie.plugins'] == [Plugin1, Plugin2]
    assert group_name_dict['httpie.plugins.distutils'] == [Plugin3]
    assert group_name_dict['httpie.plugins.distutils.tests'] == [Plugin4]

# Generated at 2022-06-25 19:16:50.956215
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_auth_plugins() != []

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(HttpiePlugin)
    assert plugin_manager_1.get_auth_plugins() == []


# Generated at 2022-06-25 19:16:51.498999
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert True

# Generated at 2022-06-25 19:16:56.786497
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(JUnitXmlFormatter, JUnitXmlv2Formatter)
    assert plugin_manager_1.get_formatters_grouped() == {
        '': [JUnitXmlFormatter, JUnitXmlv2Formatter],
    }


# Generated at 2022-06-25 19:17:00.798283
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    result = plugin_manager_1.get_formatters_grouped()
    assert isinstance(result, dict)
    assert len(result) > 0

    expected_group_name = 'image'
    assert expected_group_name in result
    assert isinstance(result[expected_group_name][0], type)


# Generated at 2022-06-25 19:17:06.692234
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:17:08.736321
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0



# Generated at 2022-06-25 19:18:06.913854
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_formatters_grouped()
    value_0 = filter(plugin_manager_0.get_formatters_grouped())


# Generated at 2022-06-25 19:18:13.166065
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    global p1, p2, p3
    p1 = PluginManager()
    p2 = PluginManager()
    p3 = PluginManager()
    p1.load_installed_plugins()
    p2.load_installed_plugins()
    p3.load_installed_plugins()
    assert p1.get_auth_plugins() == p2.get_auth_plugins() == p3.get_auth_plugins() == \
        [], "Failure in test_case_1"
    assert p1.get_formatters() == p2.get_formatters() == p3.get_formatters() == \
        [], "Failure in test_case_2"

# Generated at 2022-06-25 19:18:16.139207
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:18:20.854059
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(MockPlugin, MockPlugin, MockPlugin)
    mock_plugin_0 = MockPlugin()
    list_0 = plugin_manager_0.filter(MockPlugin)
    list_1 = plugin_manager_0.filter(BasePlugin)
    assert len(list_1) == 3


# Generated at 2022-06-25 19:18:22.852745
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    dict_1 = plugin_manager_1.get_formatters_grouped()

# Generated at 2022-06-25 19:18:28.597492
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    # The builtin plugins should be in the list
    if 'httpie.plugins.auth.basic.BasicAuthPlugin' not in [str(item) for item in plugin_manager_0]:
        return False
    if 'httpie.plugins.auth.digest.DigestAuthPlugin' not in [str(item) for item in plugin_manager_0]:
        return False
    if 'httpie.plugins.auth.hawk.HawkAuthPlugin' not in [str(item) for item in plugin_manager_0]:
        return False
    if 'httpie.plugins.auth.oauth1.OAuth1Plugin' not in [str(item) for item in plugin_manager_0]:
        return False

# Generated at 2022-06-25 19:18:31.247348
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()



# Generated at 2022-06-25 19:18:37.286359
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    dict_0 = plugin_manager.get_formatters_grouped()
    dict_1 = plugin_manager.get_formatters_grouped()
    dict_2 = plugin_manager.get_formatters_grouped()
    dict_3 = plugin_manager.get_formatters_grouped()
    dict_4 = plugin_manager.get_formatters_grouped()


# Generated at 2022-06-25 19:18:40.443870
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Make a new instance of PluginManager
    plugin_manager_0 = PluginManager()
    # Store the result of calling get_auth_plugin_mapping() of PluginManager
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()
    # Assert that dict_0 is empty
    assert len(dict_0) <= 0
    

# Generated at 2022-06-25 19:18:43.610951
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(JSONFormatterPlugin)
    dict_0 = plugin_manager_0.get_formatters_grouped()
