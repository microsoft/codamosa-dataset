

# Generated at 2022-06-25 19:10:20.302757
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    formatters = plugin_manager_0.get_formatters()
    assert len(formatters) == 0


# Generated at 2022-06-25 19:10:22.455859
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert True
    # TODO: implement test case for method get_formatters_grouped
    # of class PluginManager



# Generated at 2022-06-25 19:10:24.446748
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-25 19:10:31.711581
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    # Successfully registered with the entry point name "httpie.plugins.auth.v1"
    plugin_manager_1.register(AuthPlugin)
    # Successfully registered with the entry point name "httpie.plugins.formatter.v1"
    plugin_manager_1.register(FormatterPlugin)
    # Successfully registered with the entry point name "httpie.plugins.converter.v1"
    plugin_manager_1.register(ConverterPlugin)
    # Successfully registered with the entry point name "httpie.plugins.transport.v1"
    plugin_manager_1.register(TransportPlugin)

    # Load the installed plugins and check them
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:10:34.911599
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    formatter_grouped_1 = plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:10:37.385208
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.isNotEmpty()


# Generated at 2022-06-25 19:10:43.960793
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert hasattr(PluginManager, 'load_installed_plugins')
    #
    # @attr.s
    # class FakeEntryPoint:
    #     def load(self):
    #         class FakeFormatter(FormatterPlugin):
    #             name = 'FakeFormatter'
    #         return FakeFormatter
    #     dist = None
    # #
    # from pkg_resources import iter_entry_points
    # import unittest.mock
    # with unittest.mock.patch.object(iter_entry_points, '__call__', return_value=[FakeEntryPoint(), FakeEntryPoint(), ]):
    #     plugin_manager = PluginManager()
    #     plugin_manager.load_installed_plugins()
    #     assert len(plugin_manager.get_formatters()) == 2, 'load_installed_plugins

# Generated at 2022-06-25 19:10:53.374717
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthBasicPlugin)
    plugin_manager_1.register(AuthDigestPlugin)
    plugin_manager_1.register(AuthNTLMPlugin)
    plugin_manager_1.register(AuthOauth1Plugin)
    plugin_manager_1.register(AuthOauth2Plugin)
    plugin_manager_1.register(AuthPlugin)
    assert plugin_manager_1.get_auth_plugin_mapping() == {'basic': AuthBasicPlugin, 'digest': AuthDigestPlugin, 'ntlm': AuthNTLMPlugin, 'oauth1': AuthOauth1Plugin, 'oauth2': AuthOauth2Plugin}


# Generated at 2022-06-25 19:10:56.523031
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm_0 = PluginManager()
    assert len(pm_0) == 0
    pm_0.load_installed_plugins()
    assert len(pm_0) > 0


# Generated at 2022-06-25 19:11:04.715614
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1.filter()) == 0
    assert len(plugin_manager_1.filter(BasePlugin)) == 0
    assert len(plugin_manager_1.filter(AuthPlugin)) != 0
    assert len(plugin_manager_1.filter(FormatterPlugin)) != 0
    assert len(plugin_manager_1.filter(ConverterPlugin)) != 0


# Generated at 2022-06-25 19:11:08.727271
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    assert not plugin_manager_1.filter(by_type=Type[BasePlugin])



# Generated at 2022-06-25 19:11:13.902848
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_formatters_grouped()
    assert sorted(dict_0.keys()) == ['debug', 'html', 'table', 'terminal']



# Generated at 2022-06-25 19:11:16.835992
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:11:22.630243
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_formatters_grouped()
    assert len(list_0) == 3
# Test: test_PluginManager_get_formatters_grouped
test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:11:31.772465
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(HTTPiePlugin, 
                              HTTPie2Plugin)
    list_1 = plugin_manager_1.filter(
        by_type=Type[HTTPiePlugin]
    )
    print(
        'list_1:', 
        list_1
    )
    list_2 = plugin_manager_1.filter(
        by_type=Type[HTTPie2Plugin]
    )
    print(
        'list_2:', 
        list_2
    )
    list_3 = plugin_manager_1.filter(
        by_type=Type[TransportPlugin]
    )
    print(
        'list_3:', 
        list_3
    )


# Generated at 2022-06-25 19:11:42.903958
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import sys
    import os.path
    import traceback
    import io
    import json
    import os

    file_path = os.path.join(os.getcwd(), 'pkgs/httpie-1.0.2/httpie/')
    sys.path.append(file_path)

    from httpie.plugins.manager import PluginManager


# Generated at 2022-06-25 19:11:45.101199
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.load_installed_plugins() == None


# Generated at 2022-06-25 19:11:48.959036
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    # Define the expected value
    expected_value = [
        'PluginA',
        'PluginB',
        'PluginC'
    ]
    assert plugin_manager.load_installed_plugins() == expected_value


# Generated at 2022-06-25 19:11:57.815086
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class MyClass0():
        @property
        def __name__(self):
            return "MyClass0"
    class MyClass1():
        @property
        def __name__(self):
            return "MyClass1"
    class MyClass2():
        @property
        def __name__(self):
            return "MyClass2"
    class MyClass3():
        @property
        def __name__(self):
            return "MyClass3"
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(MyClass3, MyClass1, MyClass0)
    plugin_manager_0.register(MyClass2)
    list_0 = plugin_manager_0.filter()
    assert(list_0 == [MyClass3, MyClass1, MyClass0, MyClass2])



# Generated at 2022-06-25 19:12:01.170115
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Setup
    plugin_manager_0 = PluginManager()
    # Assertion
    assert len(plugin_manager_0.filter(AuthPlugin)) == 0
    assert len(plugin_manager_0.filter(FormatterPlugin)) == 0
    assert len(plugin_manager_0.filter(ConverterPlugin)) == 0
    assert len(plugin_manager_0.filter(TransportPlugin)) == 0


# Generated at 2022-06-25 19:12:07.677484
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugins = plugin_manager.filter()
    assert(plugins == [])


# Generated at 2022-06-25 19:12:09.371283
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:12:11.714127
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PLUGIN_MANAGER = PluginManager()
    PLUGIN_MANAGER.load_installed_plugins()
    PLUGIN_MANAGER.get_formatters_grouped()

# Generated at 2022-06-25 19:12:14.673634
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1


if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:12:18.392567
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()


# Generated at 2022-06-25 19:12:22.366654
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert isinstance(pm.get_auth_plugin_mapping(), dict)


# Generated at 2022-06-25 19:12:25.003933
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin_mapping() == {}, \
        "Wrong implementation of method get_auth_plugin_mapping of class PluginManager"


# Generated at 2022-06-25 19:12:32.309346
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    list_0 = plugin_manager_0.filter(ConverterPlugin)

# Generated at 2022-06-25 19:12:34.455419
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(NumberConverterPlugin, JsonPrettyPlugin)
    list_0 = plugin_manager_0.filter(json)


# Generated at 2022-06-25 19:12:36.450516
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    expected = {'group_name': [Type[FormatterPlugin]]}
    x = PluginManager()
    x.append(Type[FormatterPlugin])
    assert x.get_formatters_grouped() == expected

# Generated at 2022-06-25 19:12:46.018227
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.filter()

# Generated at 2022-06-25 19:12:57.256823
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    str_0 = str(plugin_manager_0.get_formatters_grouped())

# Generated at 2022-06-25 19:13:00.446566
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_transport_plugins()


# Generated at 2022-06-25 19:13:03.035065
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_transport_plugins()
    list_1 = plugin_manager_0.get_formatters()
    list_2 = plugin_manager_0.get_auth_plugins()


# Generated at 2022-06-25 19:13:08.902201
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_2 = PluginManager()
    plugin_manager_2.load_installed_plugins()
    converters = plugin_manager_2.filter()
    assert len(converters) > 0

    converters = plugin_manager_2.filter(by_type=FormatterPlugin)
    assert len(converters) > 0


# Generated at 2022-06-25 19:13:10.421139
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:13:16.346444
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    # assert plugin_manager_0.get_formatters_grouped() == {('binary', ): [], (): [], ('csv', 'json'): [], ('json', ): []}, 'Incorrect param value'
    plugin_manager_0.get_formatters_grouped()
    # assert plugin_manager_0.get_formatters_grouped() == {('csv', 'json'): [], ('json', ): []}, 'Incorrect param value'


# Generated at 2022-06-25 19:13:18.314887
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:13:23.337938
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(MyAuthPlugin, MyAuthPlugin_0)
    plugin_manager_0.filter(MyAuthPlugin)
    plugin_manager_0.filter(MyAuthPlugin_0)
    plugin_manager_0.get_auth_plugins()
    plugin_manager_0.get_formatters()

    try:
        plugin_manager_0.filter(MyAuthPlugin_1)
    except TypeError:
        pass



# Generated at 2022-06-25 19:13:25.173576
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_formatters_grouped() == {}


# Generated at 2022-06-25 19:13:47.681600
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    print('Testing get_auth_plugin_mapping...')

    dict_0 = {}

    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_auth_plugins()

    list_1 = list(list_0)
    dict_1 = dict(dict_0)

    dict_0 = plugin_manager_0.get_auth_plugin_mapping()

    assert dict_0 == dict_1

    assert len(list_0) == 0

    assert len(dict_1) == 0


# Generated at 2022-06-25 19:13:52.399072
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    test_PluginManager = PluginManager()
    test_PluginManager.load_installed_plugins()
    assert len(test_PluginManager) > 0



# Generated at 2022-06-25 19:13:59.920217
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.base import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin

    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.filter(Type[BasePlugin])
    assert list_0 == [], "assertion 'list_0 == []' failed"

    plugin_manager_1 = PluginManager()
    list_1 = plugin_manager_1.filter(Type[AuthPlugin])
    assert list_1 == [], "assertion 'list_1 == []' failed"

    plugin_manager_2 = PluginManager()
    list_2 = plugin_manager_2.filter(Type[ConverterPlugin])
    assert list_2 == [], "assertion 'list_2 == []' failed"

    plugin_manager_3 = PluginManager()
    list_3 = plugin_manager_3

# Generated at 2022-06-25 19:14:11.206041
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    dict_0 = plugin_manager_1.get_formatters_grouped()
    assert(dict_0.get("Group 0") != None)
    assert(dict_0.get("Group 1") != None)
    assert(dict_0.get("Group 2") != None)
    assert(dict_0.get("Group 3") != None)
    assert(dict_0.get("Group 4") != None)

    assert(dict_0.get("Group 5") == None)
    assert(dict_0.get("Group 6") == None)
    assert(dict_0.get("Group 7") == None)
    assert(dict_0.get("Group 8") == None)
    assert(dict_0.get("Group 9") == None)



# Generated at 2022-06-25 19:14:15.613167
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    print("----------test_PluginManager_load_installed_plugins----------")
    plg_mgr = PluginManager()
    plg_mgr.load_installed_plugins()
    for plugin in plg_mgr:
        print(plugin)
    print("----------test_PluginManager_load_installed_plugins----------\n")


# Generated at 2022-06-25 19:14:17.552771
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:14:19.527432
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    dictionary_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:14:21.834405
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_formatters_grouped()
    assert list_0 == {}


# Generated at 2022-06-25 19:14:26.333638
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager.get_auth_plugin_mapping(), dict)
    assert plugin_manager.get_auth_plugin_mapping().keys() >= {'basic',
                                                               'digest',
                                                               'aws4-hmac-sha256'}


# Generated at 2022-06-25 19:14:37.324681
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from io import StringIO
    from unittest import TestCase, TextTestRunner

    from httpie.plugins import FormatterPlugin


    class FakeFormatter1(FormatterPlugin):
        group_name = 'fake'


    class FakeFormatter2(FormatterPlugin):
        group_name = 'fake'


    class FakeFormatter3(FormatterPlugin):
        group_name = 'fake'


    class FakeFormatter4(FormatterPlugin):
        group_name = 'other'


    class FakeFormatter5(FormatterPlugin):
        group_name = 'other'


    class PluginManagerTestCase(TestCase):
        def test_formatters_grouped(self):
            plugin_manager = PluginManager()

# Generated at 2022-06-25 19:15:16.821847
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(AuthBasicPlugin, DigestAuthPlugin)
    list_0 = plugin_manager_0.get_auth_plugin_mapping()
    list_1 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:15:20.101066
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    list_1 = plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:15:22.975672
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_transport_plugins()

if __name__ == "__main__":
    #test_case_0()
    test_PluginManager_load_installed_plugins()
    print("Execution completed")

# Generated at 2022-06-25 19:15:25.822060
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    test_case_0()

# Generated at 2022-06-25 19:15:30.269088
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Setup
    plugin_manager_0 = PluginManager()
    # Exercise
    plugin_manager_0.load_installed_plugins()
    # Verify
    # Teardown
    return


# Generated at 2022-06-25 19:15:39.036397
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(*())
    plugin_manager_0.append(0)
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.register(FormatterPlugin, AuthPlugin, ConverterPlugin, BasePlugin)
    plugin_manager_0.append(AuthPlugin())
    plugin_manager_0.update((0 for _ in (0 for _ in range(6))))
    plugin_manager_0.sort(key=(lambda x: x))
    plugin_manager_0.get_formatters()
    plugin_manager_0_get_formatters_grouped = plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:15:42.097077
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.filter(by_type=Type[TransportPlugin])


# Generated at 2022-06-25 19:15:44.298820
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Test case for method get_auth_plugins of class PluginManager

# Generated at 2022-06-25 19:15:46.756537
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    class_0 = plugin_manager_0.filter(TransportPlugin)
    assert not (class_0)
    assert type(class_0) is list


# Generated at 2022-06-25 19:15:56.697474
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    # Assert if the returned value is not a dictionary
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict), "Class PluginManager method get_formatters_grouped returns the value which is not a dict"
    # Assert if the dictionary, returned by the get_formatters_grouped, has keys which are not strings
    assert not {k for k in plugin_manager_0.get_formatters_grouped() if not isinstance(k, str)}, "Class PluginManager method get_formatters_grouped returns dict with keys which are not strings"
    # Assert if the dictionary, returned by the get_formatters_grouped, has values which are not lists

# Generated at 2022-06-25 19:17:32.004171
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    expected_keys = ['aws', 'aws-v4']
    assert set(plugin_mapping.keys()) == set(expected_keys)
    assert 'aws' in plugin_mapping
    assert 'aws-v4' in plugin_mapping


# Generated at 2022-06-25 19:17:34.282885
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:17:36.867269
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    list_0 = plugin_manager_1.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:17:45.361177
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.append(type('FormatterPlugin_0', (object,), {}))
    group_name_1 = 'all'
    plugin_manager_2 = PluginManager()
    plugin_manager_2.append(type('FormatterPlugin_0', (object,), {}))
    group_name_2 = 'all'
    list_1 = plugin_manager_2.get_formatters_grouped()
    for group_name, group in groupby(plugin_manager_2.get_formatters(), key=attrgetter('group_name')):
        assert group_name == group_name_2
        assert group == list_1[group_name_2]


# Generated at 2022-06-25 19:17:47.281769
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    dict_0 = plugin_manager_1.get_formatters_grouped()
    assert isinstance(dict_0, dict)



# Generated at 2022-06-25 19:17:49.479134
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Create an instance of PluginManager
    plugin_manager_0 = PluginManager()
    # Invoke method filter of plugin_manager_0
    by_type_0 = Type[BasePlugin]
    plugin_manager_0.filter(by_type_0)


# Generated at 2022-06-25 19:17:58.577943
# Unit test for method filter of class PluginManager
def test_PluginManager_filter(): 
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(Polly.PollyPlugin())
    plugin_manager_0.register(Cookie.CookiePlugin())
    plugin_manager_0.register(Ipv6.Ipv6Plugin())
    plugin_manager_0.register(Pretty.PrettyPlugin())
    assert len(plugin_manager_0.filter(Pretty.PrettyPlugin)) > 0
    assert len(plugin_manager_0.filter(Cookie.CookiePlugin)) > 0
    assert len(plugin_manager_0.filter(Ipv6.Ipv6Plugin)) > 0

# Generated at 2022-06-25 19:17:59.908327
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    test_case_0()

if __name__ == '__main__':
    test_PluginManager_filter()

# Generated at 2022-06-25 19:18:03.246859
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Instance of class PluginManager
    plugin_manager_0 = PluginManager()
    # get_auth_plugin_mapping for plugin_manager_0
    mapping_0 = plugin_manager_0.get_auth_plugin_mapping()
    # Print of the length of list mapping_0
    print(len(mapping_0))



# Generated at 2022-06-25 19:18:06.196187
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(AuthPlugin)
    result_formatters_grouped = plugin_manager_0.get_formatters_grouped()
    assert len(result_formatters_grouped) == 1
    assert result_formatters_grouped == {'auth': [AuthPlugin]}
