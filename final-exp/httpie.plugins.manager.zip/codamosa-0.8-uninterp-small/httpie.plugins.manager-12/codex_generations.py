

# Generated at 2022-06-25 19:10:21.258886
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:10:28.274524
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Local variables of the test are defined
    test_plugin_manager = [Type[BasePlugin]()]
    by_type = BasePlugin()

    # Defining 'httpie_plugins' attribute of 'BasePlugin' class
    BasePlugin().httpie_plugins = plugin_manager_0

    # The 'expected' value is defined
    expected = [plugin_manager_0[0]]

    # The 'actual' value is calculated
    actual = plugin_manager_0.filter(by_type)

    # The 'actual' value is compared with the 'expected' value
    assert actual == expected



# Generated at 2022-06-25 19:10:35.728725
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()

    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()  # Returns list of plugins

    plugin_manager_2 = PluginManager()
    plugin_manager_2.load_installed_plugins()

    plugin_manager_3 = PluginManager()
    plugin_manager_3.load_installed_plugins()




# Generated at 2022-06-25 19:10:40.508161
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import httpie.plugins as plugins

    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

    for attr in dir(plugins):
        if attr.endswith('Plugin'):
            if attr not in dir(plugin_manager_1):
                exec("plugin_manager_1.append(plugins." + attr + ")")

# Generated at 2022-06-25 19:10:51.715100
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin, get_formatter
    class fmt_base(FormatterPlugin):
        group_name = 'base'
    class fmt_a(fmt_base):
        group_name = 'a'
    class fmt_b(fmt_base):
        group_name = 'b'
    class fmt_c(fmt_base):
        group_name = 'c'
    group_dict_1 = {'base': [fmt_base, fmt_a, fmt_b, fmt_c],
                    'a': [fmt_a],
                    'b': [fmt_b],
                    'c': [fmt_c]}
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(fmt_a)

# Generated at 2022-06-25 19:10:53.465800
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:10:58.146239
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    print(plugin_manager_0.get_auth_plugins())
    print(plugin_manager_0.get_formatters())
    print(plugin_manager_0.get_converters())
    print(plugin_manager_0.get_transport_plugins())


# Generated at 2022-06-25 19:11:05.837158
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_type_0 = 'basic'
    auth_type_1 = 'digest'
    auth_type_2 = 'aws'

    plugin_manager_0 = PluginManager()

    assert(auth_type_0 in plugin_manager_0.get_auth_plugin_mapping())
    assert(auth_type_1 in plugin_manager_0.get_auth_plugin_mapping())
    assert(auth_type_2 in plugin_manager_0.get_auth_plugin_mapping())



# Generated at 2022-06-25 19:11:09.505865
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1 is not None
    print("test_PluginManager_load_installed_plugins PASS")


test_case_0()
test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:11:11.401356
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_load_installed_plugins = PluginManager()
    assert len(plugin_manager_load_installed_plugins) == 0



# Generated at 2022-06-25 19:11:24.852742
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    httpie_plugins = [
        HttpBinFormatter(),
        JSONFormatter(),
        JSONLinesFormatter(),
        PrettyHttpBinFormatter(),
        PrettyJSONFormatter(),
        PrettyJSONLinesFormatter(),
        HeadersFormatter(),
        TableFormatter(),
        UrlencodedFormatter()
    ]
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(*httpie_plugins)
    # assertEqual(expected, PluginManager.get_formatters_grouped(plugin_manager))

# Generated at 2022-06-25 19:11:36.070520
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(TestFormatPlugin_0, TestFormatPlugin_1,
        TestFormatPlugin_2, TestFormatPlugin_3, TestFormatPlugin_4,
        TestFormatPlugin_5)
    plugin_manager_1.register(TestConverterPlugin_0, TestConverterPlugin_1,
        TestConverterPlugin_2, TestConverterPlugin_3, TestConverterPlugin_4,
        TestConverterPlugin_5)
    plugin_manager_1.register(TestAuthPlugin_0, TestAuthPlugin_1,
        TestAuthPlugin_2, TestAuthPlugin_3, TestAuthPlugin_4,
        TestAuthPlugin_5)

# Generated at 2022-06-25 19:11:45.374564
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(formatter_html.HtmlFormatter)
    plugin_manager_1.register(formatter_colors.ColoredFormatter)
    plugin_manager_1.register(formatter_json.JsonFormatter)
    plugin_manager_1.register(formatter_jsonpretty.JsonPrettyFormatter)
    plugin_manager_1.register(formatter_raw.RawFormatter)
    plugin_manager_1.register(formatter_escaped.EscapedFormatter)
    plugin_manager_1.register(formatter_lines_0d.Lines0dFormatter)
    plugin_manager_1.register(formatter_lines_0a.Lines0aFormatter)

# Generated at 2022-06-25 19:11:47.855627
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:11:50.215048
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert(len(plugin_manager) > 0)


# Generated at 2022-06-25 19:11:54.200317
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

    formatters_grouped = plugin_manager_0.get_formatters_grouped()
    keys = formatters_grouped.keys()
    for key in keys:
        print(key)

# Generated at 2022-06-25 19:12:01.170491
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(*[AuthPlugin])
    plugin_manager_0.register(*[FormatterPlugin])
    plugin_manager_0.register(*[ConverterPlugin])
    plugin_manager_0.register(*[TransportPlugin])
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:12:04.991470
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    def f():
        return plugin_manager_0.load_installed_plugins()
    f()


# Generated at 2022-06-25 19:12:07.146175
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.get_auth_plugin_mapping()

    

# Generated at 2022-06-25 19:12:15.870697
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()


# Generated at 2022-06-25 19:12:26.454550
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    # plugin_manager_0.load_installed_plugins()
    # assert plugin_manager_0.get_auth_plugins() == ['BasicAuthPlugin']
    # assert plugin_manager_0.get_auth_plugin_mapping() == {'BasicAuthPlugin': 'BasicAuthPlugin'}
    # assert plugin_manager_0.get_auth_plugin('BasicAuthPlugin') == 'BasicAuthPlugin'
    pass



# Generated at 2022-06-25 19:12:35.774910
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    class Plugin0(FormatterPlugin):
        group_name = 'test'

    class Plugin1(FormatterPlugin):
        group_name = 'test'

    class Plugin2(FormatterPlugin):
        group_name = 'test'

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(Plugin0, Plugin1, Plugin2)
    test1 = plugin_manager_1.get_formatters_grouped()['test']
    assert test1 == [Plugin0, Plugin1, Plugin2]

    from itertools import groupby
    from operator import attrgetter

    t = [Plugin0, Plugin1, Plugin2]
    g = groupby(t, key=attrgetter('group_name'))
    list(g) == [('test', [Plugin0, Plugin1, Plugin2])]

# Generated at 2022-06-25 19:12:36.956953
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    return True


# Generated at 2022-06-25 19:12:44.151131
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Initialize the PluginManager
    plugin_manager_0 = PluginManager()

    # Initialize the list of plugins
    plugin_manager_0.register(AuthPlugin)

    # Call the get_auth_plugin_mapping with the appropriate arguements
    assert plugin_manager_0.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-25 19:12:45.657547
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:12:54.125729
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin(BasePlugin):
        pass

    class AuthPlugin(Plugin):
        pass

    class TransportPlugin(Plugin):
        pass

    class TransportPlugin2(TransportPlugin):
        pass

    class FormatterPlugin(Plugin):
        pass
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin, Plugin, AuthPlugin, TransportPlugin, TransportPlugin2, FormatterPlugin)
    plugin1 = PluginManager()
    plugin1.register(Plugin, AuthPlugin, TransportPlugin, TransportPlugin2, FormatterPlugin)
    plugin2 = PluginManager()
    plugin2.register(AuthPlugin, TransportPlugin, TransportPlugin2)
    plugin3 = PluginManager()
    plugin3.register(TransportPlugin, TransportPlugin2)
    plugin4 = PluginManager()
    plugin4.register(TransportPlugin2)
    assert plugin_manager

# Generated at 2022-06-25 19:12:55.955338
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    print(plugin_manager_1.get_formatters_grouped())


# Generated at 2022-06-25 19:13:00.141432
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:13:02.764299
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager != None

# Generated at 2022-06-25 19:13:09.023723
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(JsonTest, JsonTest1, JsonTest2, JsonTest3)
    r_dict = plugin_manager_1.get_formatters_grouped()
    result = ['YAML', 'JSON', 'Table', 'HTML']
    assert list(r_dict.keys()) == result



# Generated at 2022-06-25 19:13:21.242268
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-25 19:13:28.786647
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.client import HTTPieClient
    from httpie.plugins.manager import PluginManager

    plugins_manager = PluginManager()
    plugins_manager.load_installed_plugins()

    client = HTTPieClient()
    plugins_manager.install_to_client(client)

    from httpie.plugins.builtin import HTTPBasicAuth

    assert HTTPBasicAuth in plugins_manager
    assert HTTPBasicAuth in client.auth_plugins
    assert HTTPBasicAuth in [
        plugin.__class__
        for plugin in client.auth_plugins
    ]

    # print(plugins_manager)



# Generated at 2022-06-25 19:13:33.876374
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Test case 0
    # Test with valid plugin
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    # Test whether the installed plugin is loaded
    assert len(plugin_manager_0) > 0


# Generated at 2022-06-25 19:13:38.719349
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins = plugin_manager.get_auth_plugins()
    assert len(auth_plugins) != 0
    assert len(plugin_manager.filter(AuthPlugin)) != 0
    assert len(plugin_manager.filter(TransportPlugin)) != 0
    assert len(plugin_manager.filter(FormatterPlugin)) != 0
    assert len(plugin_manager.filter(ConverterPlugin)) != 0



# Generated at 2022-06-25 19:13:41.182288
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    # plugin_manager_0.filter
    assert type(plugin_manager_0.filter()) == list


# Generated at 2022-06-25 19:13:47.364711
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    """
    Test case for method get_auth_plugin_mapping of class PluginManager
    in which testing whether it returns a dictionary of the auth plugins
    """
    test_case_0()
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins = plugin_manager.get_auth_plugin_mapping()
    assert isinstance(auth_plugins, dict), \
        'get_auth_plugin_mapping() should return a dictionary.'


# Generated at 2022-06-25 19:13:54.120528
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_dict = plugin_manager.get_formatters_grouped()
    assert isinstance(plugin_dict, dict)
    assert 'Json' in plugin_dict
    assert 'Debug' in plugin_dict
    assert 'Html' in plugin_dict
    assert 'Table' in plugin_dict


# Generated at 2022-06-25 19:13:57.965726
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    if(len(plugin_manager.filter()) == 0):
        assert(1)
    else:
        assert(0)

    if(len(plugin_manager.filter(FormatterPlugin)) != 0):
        assert(1)
    else:
        assert(0)



# Generated at 2022-06-25 19:14:09.440722
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()


# Generated at 2022-06-25 19:14:15.297595
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Initialize plugin_manager
    plugin_manager = PluginManager()
    # Check if the function returns a dict
    if type(plugin_manager.get_auth_plugin_mapping()) != dict:
        raise TypeError('Return value must be a dict')
    # Check if the function returns an empty dict
    if len(plugin_manager.get_auth_plugin_mapping()) != 0:
        raise AssertionError('Return value must be an empty dict')



# Generated at 2022-06-25 19:14:39.539974
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    #should return a dictionary
    get_formatters_grouped_dict = plugin_manager_0.get_formatters_grouped()
    assert(isinstance(get_formatters_grouped_dict, dict))  
    #dict key must be string
    assert(isinstance(next(iter(get_formatters_grouped_dict)), str))
    #dict value must be a list
    assert(isinstance(next(iter(get_formatters_grouped_dict.values())), list))
    #dict value item must be instance of Plugin
    assert(isinstance(next(iter(next(iter(get_formatters_grouped_dict.values())))), BasePlugin))



# Generated at 2022-06-25 19:14:42.251302
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    mapping_1 = plugin_manager_1.get_auth_plugin_mapping()
    assert mapping_1 == {
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin,
        'hdr': AuthPlugin,
        'jwt': JWTAuthPlugin
    }


# Generated at 2022-06-25 19:14:43.082097
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    assert pm.filter(1) == []


# Generated at 2022-06-25 19:14:50.326182
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    result_0 = plugin_manager_0.get_formatters_grouped()
    assert result_0 == {'group1': [FormatterPlugin, FormatterPlugin], 'group2': [FormatterPlugin, FormatterPlugin]}



# Generated at 2022-06-25 19:14:53.344102
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert 'group_0' in plugin_manager.get_formatters_grouped()
    assert 'group_1' in plugin_manager.get_formatters_grouped()


# Generated at 2022-06-25 19:14:59.111103
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    result = plugin_manager_1.get_auth_plugin_mapping()
    assert isinstance(result, dict)


# Generated at 2022-06-25 19:15:03.841075
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert all(map(lambda x: issubclass(x, BasePlugin), plugin_manager))



# Generated at 2022-06-25 19:15:05.843762
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:15:08.133704
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert isinstance(plugin_manager_0._plugins, list)



# Generated at 2022-06-25 19:15:17.590545
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    class PluginA(FormatterPlugin):
        group_name = 'a'

    class PluginB(FormatterPlugin):
        group_name = 'a'

    class PluginC(FormatterPlugin):
        group_name = 'c'

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(PluginA, PluginB, PluginC)

    assert plugin_manager_1.get_formatters_grouped() == {'a': [PluginA, PluginB], 'c': [PluginC]}


if __name__ == '__main__':
    test_case_0()
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:16:04.128881
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(
        ConverterPlugin,
        FormatterPlugin,
        TransportPlugin,
        AuthPlugin,
        BasePlugin,
    )
    plugin_manager_1.filter()
    plugin_manager_1.filter(AuthPlugin)
    plugin_manager_1.filter(ConverterPlugin)
    plugin_manager_1.filter(FormatterPlugin)
    plugin_manager_1.filter(TransportPlugin)

    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(
        ConverterPlugin,
        FormatterPlugin,
        TransportPlugin,
        AuthPlugin,
        BasePlugin,
    )
    plugin_manager_2.filter()
    plugin_manager_2.filter(AuthPlugin)
    plugin_manager_2.filter

# Generated at 2022-06-25 19:16:07.846130
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(httpie.plugins.JSONFormatter)
    plugin_manager_0.register(httpie.plugins.URLEncodedFormatter)
    plugin_manager_0.register(httpie.plugins.ColoredFormatter)
    plugin_manager_0.register(httpie.plugins.DefaultFormatter)


# Generated at 2022-06-25 19:16:11.717691
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(AuthPlugin)

    assert len(plugin_manager.filter(TransportPlugin)) == 3
    assert len(plugin_manager.filter(AuthPlugin)) == 3
    assert len(plugin_manager.filter(ConverterPlugin)) == 1

# Generated at 2022-06-25 19:16:13.889460
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    result = plugin_manager_0.get_formatters_grouped()
    assert result

    

# Generated at 2022-06-25 19:16:20.512245
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(TestFormatterPlugin1,TestFormatterPlugin4,TestFormatterPlugin5)
    expected_output = {
        'Group1': [TestFormatterPlugin1,TestFormatterPlugin5],
        'Group2': [TestFormatterPlugin4]
    }
    assert plugin_manager.get_formatters_grouped() == expected_output


# Generated at 2022-06-25 19:16:22.828669
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    x :Dict[str, List[Type[FormatterPlugin]]] = plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:16:24.104712
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:16:25.568444
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_auth_plugin_mapping() == {}


# Generated at 2022-06-25 19:16:27.153326
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager.get_formatters_grouped(), dict)

# Generated at 2022-06-25 19:16:28.275005
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-25 19:18:02.436735
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert list(plugin_manager_0) != []


# Generated at 2022-06-25 19:18:02.846775
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugi

# Generated at 2022-06-25 19:18:09.229220
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    class Plugin_0:
        def __init__(self):
            pass
    pm0 = PluginManager()
    pm0.register(Plugin_0)
    assert isinstance(pm0.get_transport_plugins()[0](), Plugin_0)
    pm0.load_installed_plugins()
    assert pm0.get_auth_plugin('basic') == plugins.auth.BasicAuthPlugin
    assert pm0.get_converters()[0] == plugins.converter.BytesConverter
    assert pm0.get_formatters()[0] == plugins.formatter.ColorsFormatter
    assert 'httpie.plugins.transport.v1' in ENTRY_POINT_NAMES
    assert 'httpie.plugins.auth.v1' in ENTRY_POINT_NAMES

# Generated at 2022-06-25 19:18:09.965889
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict)


# Generated at 2022-06-25 19:18:11.047985
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:18:17.163487
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_get_auth_plugin_mapping = PluginManager()
    plugin_manager_get_auth_plugin_mapping.register()
    plugin_manager_get_auth_plugin_mapping.unregister()
    plugin_manager_get_auth_plugin_mapping.filter()
    plugin_manager_get_auth_plugin_mapping.get_auth_plugins()
    plugin_manager_get_auth_plugin_mapping.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:18:19.253349
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert plugin_manager.filter() == []


# Generated at 2022-06-25 19:18:21.302969
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert True



# Generated at 2022-06-25 19:18:25.006864
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(PlainTextFormatter, JSONFormatter)
    plugin_manager_1.get_formatters_grouped() == {'Formatters': [PlainTextFormatter, JSONFormatter]}


# Generated at 2022-06-25 19:18:25.852710
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_case_0()

