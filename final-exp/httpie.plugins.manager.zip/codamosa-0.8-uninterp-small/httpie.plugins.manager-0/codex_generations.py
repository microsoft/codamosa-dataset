

# Generated at 2022-06-25 19:10:19.850888
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager_list = list(plugin_manager)
    assert len(plugin_manager_list) > 0

# Generated at 2022-06-25 19:10:23.778173
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    base_plugin_manager_1 = PluginManager()
    base_plugin_manager_1.load_installed_plugins()
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) is not 0



# Generated at 2022-06-25 19:10:31.321893
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(PluginManagerTest_0_FormatterPlugin_0,
                PluginManagerTest_0_FormatterPlugin_0)
    pm.register(PluginManagerTest_0_FormatterPlugin_1,
                PluginManagerTest_0_FormatterPlugin_1)
    pm.register(PluginManagerTest_0_FormatterPlugin_2,
                PluginManagerTest_0_FormatterPlugin_2)
    pm.register(PluginManagerTest_0_FormatterPlugin_3,
                PluginManagerTest_0_FormatterPlugin_3)
    pm.register(PluginManagerTest_0_FormatterPlugin_4,
                PluginManagerTest_0_FormatterPlugin_4)
    pm.register(PluginManagerTest_0_FormatterPlugin_5,
                PluginManagerTest_0_FormatterPlugin_5)


# Generated at 2022-06-25 19:10:33.205713
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.filter(by_type=Type[BasePlugin]) == []
    plugin_manager_2 = PluginManager()
    assert plugin_manager_2.filter(by_type=Type[TransportPlugin]) == []



# Generated at 2022-06-25 19:10:42.188531
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()

    pluginManager.register(TestFormatter1)
    pluginManager.register(TestFormatter2)
    pluginManager.register(TestFormatter3)

    formatter_grouped = pluginManager.get_formatters_grouped()

    assert len(formatter_grouped) == 2
    assert TestFormatter1.group_name in formatter_grouped
    assert TestFormatter2.group_name in formatter_grouped
    assert TestFormatter3.group_name not in formatter_grouped

    assert len(formatter_grouped[TestFormatter1.group_name]) == 2
    assert TestFormatter1 in formatter_grouped[TestFormatter1.group_name]
    assert TestFormatter2 in formatter_grouped[TestFormatter1.group_name]

    assert len

# Generated at 2022-06-25 19:10:45.424540
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    print("Load installed plugins success: ", plugin_manager_0)


# Generated at 2022-06-25 19:10:47.976295
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    assert isinstance(plugin_manager_1.filter(), list)


# Generated at 2022-06-25 19:10:56.640063
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    """Test to check if plugin_manager.filter() method works properly"""

    class SubclassOfBasePlugin(BasePlugin):
        pass

    class OtherSubclassOfBasePlugin(BasePlugin):
        pass

    class SubclassOfOtherSubclassOfBasePlugin(OtherSubclassOfBasePlugin):
        pass

    plugin_manager_1 = PluginManager()

    plugin_manager_1.register(SubclassOfBasePlugin,
                              OtherSubclassOfBasePlugin,
                              SubclassOfOtherSubclassOfBasePlugin)

    assert plugin_manager_1.filter(by_type=SubclassOfBasePlugin) == \
        [SubclassOfBasePlugin, SubclassOfOtherSubclassOfBasePlugin]

# Generated at 2022-06-25 19:11:02.236718
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()

    auth_plugins = BasePlugin.check_plugins_base_class(plugins, AuthPlugin)
    assert not auth_plugins
    formatters = BasePlugin.check_plugins_base_class(plugins, FormatterPlugin)
    assert not formatters
    converters = BasePlugin.check_plugins_base_class(plugins, ConverterPlugin)
    assert not converters

    plugins.load_installed_plugins()
    auth_plugins = BasePlugin.check_plugins_base_class(plugins, AuthPlugin)
    assert len(auth_plugins) >= 3
    formatters = BasePlugin.check_plugins_base_class(plugins, FormatterPlugin)
    assert len(formatters) >= 2
    converters = BasePlugin.check_plugins_base_class(plugins, ConverterPlugin)
    assert len(converters) == 1

# Generated at 2022-06-25 19:11:11.170392
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(TransportPlugin)
    plugin_manager_0.register(ConverterPlugin)
    assert plugin_manager_0.filter(BasePlugin) == [TransportPlugin, ConverterPlugin]
    assert plugin_manager_0.filter(TransportPlugin) == [TransportPlugin]
    assert plugin_manager_0.filter(ConverterPlugin) == [ConverterPlugin]
    plugin_manager_0.unregister(TransportPlugin)
    assert plugin_manager_0.filter(TransportPlugin) == []
    assert plugin_manager_0.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager_0.filter(BasePlugin) == [ConverterPlugin]


# Generated at 2022-06-25 19:11:19.040101
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    # plugin_manager_1.load_installed_plugins()
    # if len(plugin_manager_1.get_formatters_grouped()) > 0:
    #     return 1
    # else:
    #     return 0
    plugin_manager_1.register(FormatterPlugin)
    if len(plugin_manager_1.get_formatters_grouped()) > 0:
        return 1
    else:
        return 0


# Generated at 2022-06-25 19:11:27.270289
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert (len(ENTRY_POINT_NAMES) == 4)
    assert (len(plugin_manager_1.get_transport_plugins()) == 2)
    assert (len(plugin_manager_1.get_auth_plugins()) == 1)
    assert (len(plugin_manager_1.get_formatters()) == 1)
    assert (len(plugin_manager_1.get_converters()) == 1)

# Output processing unit tests

# Generated at 2022-06-25 19:11:28.426184
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:11:39.433312
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(BasicAuthPlugin)

# Generated at 2022-06-25 19:11:49.446897
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    class Plugin_0(BasePlugin):
        pass

    class Plugin_1(BasePlugin):
        pass

    class Plugin_2(BasePlugin):
        pass

    class Plugin_3(BasePlugin):
        pass

    class Plugin_4(BasePlugin):
        auth_type = 'my_auth'

    class Plugin_5(BasePlugin):
        auth_type = 'my_auth_1'

    class Plugin_6(BasePlugin):
        auth_type = 'my_auth_2'

    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(Plugin_0, Plugin_1, Plugin_2, Plugin_3, Plugin_4, Plugin_5, Plugin_6)
    plugin_manager_1 = PluginManager()

# Generated at 2022-06-25 19:11:57.968040
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONStreams
    from httpie.plugins.builtin import JSONStreamsPP
    from httpie.plugins.builtin import URLEncoded
    from httpie.plugins.builtin import URLEncodedPP
    from httpie.plugins.builtin import RawJSON
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(JSONStreams)
    plugin_manager_0.register(JSONStreamsPP)
    plugin_manager_0.register(URLEncoded)
    plugin_manager_0.register(URLEncodedPP)
    plugin_manager_0.register(RawJSON)
    plugin_manager_1 = plugin_manager_0
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:12:00.492895
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager([AuthPlugin, AuthPlugin])
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert isinstance(mapping, dict)

# Generated at 2022-06-25 19:12:05.498417
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    for plugin in plugin_manager_1.load_installed_plugins():
        pass


if __name__ == '__main__':
    test_case_0()
    # test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:12:10.610243
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register()
    plugin_manager.register(test_case_0())
    # plugin_manager.filter()
    plugin_manager.filter(test_case_0())
    # plugin_manager.register()
    # plugin_manager.unregister()
    # plugin_manager.get_converters()



# Generated at 2022-06-25 19:12:13.123952
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 19:12:27.413526
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Create a PluginManager object
    plugin_manager_0 = PluginManager()

    # Create a FormatterPlugin object
    class FormatterPlugin_0(FormatterPlugin):
        group_name = 'foo'
    plugin_manager_0.append(FormatterPlugin_0)

    # Create a FormatterPlugin object
    class FormatterPlugin_1(FormatterPlugin):
        group_name = 'foo'
    plugin_manager_0.append(FormatterPlugin_1)

    # Create a FormatterPlugin object
    class FormatterPlugin_2(FormatterPlugin):
        group_name = 'bar'
    plugin_manager_0.append(FormatterPlugin_2)

    # Invoke method 'get_formatters_grouped'
    formatters = plugin_manager_0.get_formatters_grouped()

    # Assert that

# Generated at 2022-06-25 19:12:33.571598
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()

    # test with no installed plugins
    plugins.register()
    assert plugins.get_auth_plugin_mapping() == {}
    plugins = [plugin for plugin in plugins]

    # test with installed plugins
    plugins.register()
    assert plugins.get_auth_plugin_mapping() == {'basic': BasicAuthPlugin, 'digest': DigestAuthPlugin}
    plugins = [plugin for plugin in plugins]


# Generated at 2022-06-25 19:12:38.421776
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin)
    plugin_manager_1.register(AuthPlugin)
    plugin_manager_1.register(AuthPlugin)
    plugin_manager_1.get_auth_plugin_mapping()
    if not isinstance(plugin_manager_1.get_auth_plugin_mapping(), dict):
        raise AssertionError
    if len(plugin_manager_1.get_auth_plugin_mapping()) != 3:
        raise AssertionError


# Generated at 2022-06-25 19:12:45.657457
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    test_case = PluginManager()
    test_case.register(AuthPlugin)

    assert test_case.filter(AuthPlugin) == [AuthPlugin]
    assert test_case.filter(FormatterPlugin) == []
    assert test_case.filter(ConverterPlugin) == []
    assert test_case.filter(TransportPlugin) == []



# Generated at 2022-06-25 19:12:48.128114
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-25 19:12:52.507723
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    filter_output = p.filter(BasePlugin)
    assert len(filter_output) == 0


# Generated at 2022-06-25 19:12:54.842112
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(test_case_0)
    plugin_manager_0.filter(test_case_0)

# Generated at 2022-06-25 19:12:56.297671
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert(len(plugin_manager_0.get_auth_plugin_mapping()) > 0)

# Generated at 2022-06-25 19:13:01.402036
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(test_class_1,test_class_2)
    assert pm.filter(BasePlugin) == [test_class_1,test_class_2]


# Generated at 2022-06-25 19:13:05.813044
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register()
    plugin_manager_0.filter()
    plugin_manager_0.filter()


# Generated at 2022-06-25 19:13:16.200469
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.get_formatters_grouped()



# Generated at 2022-06-25 19:13:19.033341
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0



# Generated at 2022-06-25 19:13:20.808519
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert type(plugin_manager_0.get_formatters_grouped()) is dict


# Generated at 2022-06-25 19:13:24.188826
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:13:25.990970
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1


# Generated at 2022-06-25 19:13:27.048673
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugins = plugin_manager_0.get_formatters_grouped()
    assert type(plugins) == dict


# Generated at 2022-06-25 19:13:31.465151
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    class PluginA(BasePlugin):
        pass

    class PluginB(PluginA):
        pass

    class PluginC(BasePlugin):
        pass

    class PluginD(BasePlugin):
        pass

    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(PluginA(), PluginB(), PluginC(), PluginD())
    assert plugin_manager_0.filter(BasePlugin) == [PluginA, PluginB, PluginC, PluginD]
    assert plugin_manager_0.filter(PluginA) == [PluginA, PluginB]


# Generated at 2022-06-25 19:13:35.506787
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    Formatters_grouped = plugin_manager_0.get_formatters_grouped()
    assert 0 < len(Formatters_grouped)
    assert 'Formatters' in Formatters_grouped

# Generated at 2022-06-25 19:13:40.023137
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:13:45.320252
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = []
    for i in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(i):
            plugins.append(entry_point.load())
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager == plugins



# Generated at 2022-06-25 19:14:03.131927
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert isinstance(plugin_manager[0], BasePlugin)


# Generated at 2022-06-25 19:14:06.165967
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1.get_auth_plugins()) >= 1


# Generated at 2022-06-25 19:14:09.598740
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    result = plugin_manager_1.get_formatters_grouped()
    assert result != None


# Generated at 2022-06-25 19:14:14.752005
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class plugin(BasePlugin):
        pass
    class test(AuthPlugin):
        pass
    p = PluginManager()
    p.register(plugin,test)
    assert p.filter() == [plugin,test]
    assert p.filter(AuthPlugin) == [test]
    assert p.filter(BasePlugin) == [plugin]
    assert p.filter(plugin) == []


# Generated at 2022-06-25 19:14:20.822483
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    class FakeFormatterPluginA(FormatterPlugin):
        group_name = 'foo'

    class FakeFormatterPluginB(FormatterPlugin):
        group_name = 'bar'

    class FakeFormatterPluginC(FormatterPlugin):
        group_name = 'bar'

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(FakeFormatterPluginA, FakeFormatterPluginB, FakeFormatterPluginC)

    assert plugin_manager_1.get_formatters_grouped() == {
        'foo': [FakeFormatterPluginA],
        'bar': [FakeFormatterPluginB, FakeFormatterPluginC],
    }



# Generated at 2022-06-25 19:14:23.413758
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasePlugin)
    plugin_manager_1 = plugin_manager_0.filter(BasePlugin)

# Generated at 2022-06-25 19:14:25.118164
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    test_case_0()

# Execute the unit test
test_PluginManager_filter()

# Generated at 2022-06-25 19:14:30.568739
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    formatters_grouped = plugin_manager_0.get_formatters_grouped()
    assert formatters_grouped['Colors'] == [
        httpie.plugins.formatter.colors.ColorsFormatter
    ]


# Generated at 2022-06-25 19:14:39.474484
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

    auth_plugins = plugin_manager_1.filter(AuthPlugin)
    assert len(auth_plugins) == 1
    assert isinstance(auth_plugins[0], AuthPlugin)
    
    formatter_plugins = plugin_manager_1.filter(FormatterPlugin)
    assert len(formatter_plugins) == 1
    assert isinstance(formatter_plugins[0], FormatterPlugin)

    converter_plugins = plugin_manager_1.filter(ConverterPlugin)
    assert len(converter_plugins) == 1
    assert isinstance(converter_plugins[0], ConverterPlugin)

    transport_plugins = plugin_manager_1.filter(TransportPlugin)
    assert len

# Generated at 2022-06-25 19:14:41.122381
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    result = plugin_manager_0.get_formatters_grouped()
    assert (isinstance(result, dict))

# Generated at 2022-06-25 19:15:18.616579
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from pkg_resources import DistributionNotFound, iter_entry_points
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie._plugins_manager import PluginManager

    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

    for entry_point_name in ['httpie.plugins.auth.v1', 'httpie.plugins.formatter.v1', 'httpie.plugins.converter.v1', 'httpie.plugins.transport.v1']:
        i = iter_entry_points(entry_point_name)

# Generated at 2022-06-25 19:15:21.083040
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_2 = PluginManager()
    plugin_manager_2.load_installed_plugins()


# Generated at 2022-06-25 19:15:28.522404
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0.get_auth_plugin_mapping()) != 0
    assert len(plugin_manager_0.get_formatters()) != 0
    assert len(plugin_manager_0.get_converters()) != 0
    assert len(plugin_manager_0.get_transport_plugins()) != 0


# Generated at 2022-06-25 19:15:30.043218
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:15:35.224097
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    # Testing filter method with no parameter
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.filter()) > 0
    # Testing filter method with parameter specified
    formatter_plugins = plugin_manager.filter(FormatterPlugin)
    assert all(issubclass(plugin, FormatterPlugin) for plugin in formatter_plugins)



# Generated at 2022-06-25 19:15:37.796468
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    test_plugins = [AuthPlugin, FormatterPlugin]
    assert len(plugin_manager.load_installed_plugins()) == 0


# Generated at 2022-06-25 19:15:46.371991
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager_1 = PluginManager()
    # We expect that after the loading procedure is finished, the list returned
    # by get_auth_plugins should not be empty.
    assert manager_1.get_auth_plugins() == []
    manager_1.load_installed_plugins()
    assert manager_1.get_auth_plugins() != []
    assert manager_1.get_transport_plugins() != []
    assert manager_1.get_formatters() != []
    assert manager_1.get_converters() != []
    # We check if a very famous and important HTTP plugin installed in the system is loaded
    assert manager_1.get_transport_plugin('http') is not None


# Generated at 2022-06-25 19:15:56.490986
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.custom_formatters import CustomJsonFormatterPlugin
    from httpie.plugins.custom_formatters import CustomPrettyURLEncodedFormatterPlugin
    plugin_manager = PluginManager()
    dict1 = dict()
    dict1.update({'group_name': 'Pretty'})
    dict1.update({'formatter': JSONFormatterPlugin})
    dict2 = dict()
    dict2.update({'group_name': 'Pretty'})
    dict2.update({'formatter': CustomPrettyURLEncodedFormatterPlugin})
    dict3 = dict()
    dict3.update({'group_name': 'Preview'})
    dict3.update({'formatter': PrettyURLEncodedFormatterPlugin})

# Generated at 2022-06-25 19:15:58.094420
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:16:03.398301
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.append('aaa')
    plugin_manager.append('bbb')
    plugin_manager.append('ccc')
    d = plugin_manager.get_formatters_grouped()
    assert d is None
    assert d['aaa'] is None
    assert d['bbb'] is None
    assert d['ccc'] is None


# Generated at 2022-06-25 19:17:19.564761
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Test case 0
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_auth_plugin_mapping() == {}



# Generated at 2022-06-25 19:17:21.371684
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugins = plugin_manager.load_installed_plugins()

# Generated at 2022-06-25 19:17:23.353415
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugins = plugin_manager_1.get_converters()
    assert isinstance(plugins, list)
    assert len(plugins) == 0


# Generated at 2022-06-25 19:17:31.076553
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(FakePlugin)
    manager.load_installed_plugins()
    if len(manager.filter(TransportPlugin)) != 1:
        raise Exception('Number of FilterPlugin should be equal to 1')
    if len(manager.filter(FakePlugin)) != 1:
        raise Exception('Number of FakePluginPlugin should be equal to 1')
    if len(manager.filter(FakePlugin2)) != 0:
        raise Exception('Number of FakePlugin2Plugin should be 0')

# Generated at 2022-06-25 19:17:33.726132
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert type(plugin_manager_0.get_formatters_grouped()) == dict
    return True


# Generated at 2022-06-25 19:17:37.951735
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_dict = plugin_manager_0.get_auth_plugin_mapping()
    assert 'basic' in plugin_dict
    assert 'digest' in plugin_dict


# Generated at 2022-06-25 19:17:40.232598
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    with pytest.raises(TypeError):
        plugin_manager_0 = PluginManager()
        plugin_manager_0.get_formatters_grouped().filter()

# Generated at 2022-06-25 19:17:42.572308
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager

# Generated at 2022-06-25 19:17:44.023503
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {}



# Generated at 2022-06-25 19:17:50.663313
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_result = plugin_manager_0.get_formatters_grouped()
    dict_expected = {'Default': [httpie.plugins.formatter.json.JSONFormatter, httpie.plugins.formatter.parsable.ParsableFormatter, httpie.plugins.formatter.pretty.PrettyFormatter], 'Syntax-highlighted': [httpie.plugins.formatter.colors.ColorsFormatter, httpie.plugins.formatter.colors.ColorsFormatter]}
    success = True
    for x in dict_expected.keys():
        if x not in dict_result.keys():
            print ("Key missing: " + x)
            success = False