

# Generated at 2022-06-25 19:10:20.762238
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert type(plugin_manager_1.get_auth_plugin_mapping()) == dict



# Generated at 2022-06-25 19:10:22.582594
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:10:30.636507
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    # Check the number of plugins loaded
    assert len(pm) == 4

    # Check the names of the plugins loaded
    plugin_names = []
    for plugin in pm:
        plugin_names.append(plugin.name)
    assert "AutoAuthPlugin" in plugin_names
    assert "JSONPlugin" in plugin_names
    assert "PrettyPlugin" in plugin_names
    assert "HTMLPlugin" in plugin_names

    # Check the names of the packages to which the plugins belong
    package_names = []
    for plugin in pm:
        package_names.append(plugin.package_name)
    assert "httpie-auth-auto" in package_names
    assert "httpie-output-formatters-json" in package_names

# Generated at 2022-06-25 19:10:34.760286
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert len(plugin_manager_0.get_formatters_grouped()) > 0
    assert plugin_manager_0.get_formatters_grouped()['text'] == list()

# Generated at 2022-06-25 19:10:39.398115
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.plugin_manager_0 = PluginManager()

        def test_0(self):
            self.assertEqual(self.plugin_manager_0.filter(
                Type[BasePlugin]), [])

    Test().test_0()


# Generated at 2022-06-25 19:10:42.256329
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(AuthPlugin, FormatterPlugin)
    plugin_manager_0.filter(AuthPlugin)


# Generated at 2022-06-25 19:10:45.131319
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager)>0

# Generated at 2022-06-25 19:10:55.663299
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.append(TestFormatter)
    plugin_manager_1.append(TestFormatter)
    plugin_manager_1.append(TestFormatter2)
    plugin_manager_1.append(TestFormatter2)
    plugin_manager_1.append(TestFormatter2)
    plugin_manager_1.append(TestFormatter3)
    plugin_manager_1.append(TestFormatter3)


# Generated at 2022-06-25 19:11:02.239732
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class ClassA: pass
    class ClassB(ClassA): pass
    class ClassC(ClassB): pass
    class ClassD(ClassC): pass

    a = ClassA()
    b = ClassB()
    c = ClassC()
    d = ClassD()

    plugin_manager = PluginManager()
    plugin_manager.register(ClassA, ClassB)

    assert plugin_manager.filter(ClassA) == [ClassA, ClassB]
    assert plugin_manager.filter(ClassB) == [ClassB]
    assert plugin_manager.filter(ClassC) == [ClassC]
    assert plugin_manager.filter(ClassD) == [ClassD]

    assert plugin_manager.filter(ClassA) == [ClassA, ClassB]
    assert plugin_manager.filter(ClassB) == [ClassB]
    assert plugin

# Generated at 2022-06-25 19:11:05.655558
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    formatters_grouped = plugin_manager_1.get_formatters_grouped()
    print(formatters_grouped)



# Generated at 2022-06-25 19:11:14.013670
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:11:19.848804
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.filter(FormatterPlugin) == [
        httpie_clipboard.ClipboardFormatterPlugin,
        httpie_columnize.ColumnizeFormatterPlugin,
        httpie_json.JSONFormatterPlugin,
        httpie_no_style.NoStyleFormatterPlugin,
        httpie_pretty_json.PrettyJsonFormatterPlugin,
        httpie_table.TableFormatterPlugin,
        httpie_table_org.TableFormatterPlugin,
        httpie_truncate.TruncateFormatterPlugin,
        httpie_unicode.UnicodeFormatterPlugin,
    ]


# Generated at 2022-06-25 19:11:23.207505
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register()
    plugin_manager_0.filter()



# Generated at 2022-06-25 19:11:27.692127
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin
    )

    assert plugin_manager_1.get_formatters_grouped() == {
        '': [FormatterPlugin, FormatterPlugin, FormatterPlugin, FormatterPlugin]
    }

# Generated at 2022-06-25 19:11:29.432610
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:11:31.574462
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()

    assert plugin_manager_0 is not None
    assert plugin_manager_0.load_installed_plugins() is None

# Generated at 2022-06-25 19:11:35.913177
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(FormatterPlugin)
    assert plugin_manager_0.get_formatters_grouped() is not None

# Generated at 2022-06-25 19:11:37.524464
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:11:39.005404
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:40.593046
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:11:46.787427
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin, FormatterPlugin)
    plugin_manager_1.filter(AuthPlugin)


# Generated at 2022-06-25 19:11:55.736626
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import os
    os.environ['HTTPIE_PLUGINS'] = 'httpie_plugins'

    pm = PluginManager()
    pm.load_installed_plugins()
    #import pdb; pdb.set_trace()

    assert len(pm) == 2
    assert pm[0].__name__ == 'DummyAuthPlugin'
    assert pm[1].__name__ == 'DummyAuthPlugin2'

    from httpie.plugins.builtin import AuthPlugin
    assert isinstance(pm[0], AuthPlugin)
    assert isinstance(pm[1], AuthPlugin)

    assert pm[0].package_name == 'httpie_plugins'
    assert pm[1].package_name == 'httpie_plugins'

    # No errors

# Generated at 2022-06-25 19:11:59.620954
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.filter() == []
    plugin_manager_2 = PluginManager()
    plugin_manager_2.register()
    assert plugin_manager_2.filter() == []
    plugin_manager_3 = PluginManager()
    plugin_manager_3.register(BasePlugin)
    assert plugin_manager_3.filter() == [BasePlugin]


# Generated at 2022-06-25 19:12:04.551547
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    plugin_manager = PluginManager()

    class TestPlugin(BasePlugin):
        pass

    plugin_manager.register(TestPlugin)
    assert len(plugin_manager.filter(TestPlugin)) == 1, 'plugin_manager.filter() with correct argument should return correct result'



# Generated at 2022-06-25 19:12:08.624325
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in auth_plugin_mapping.keys()



# Generated at 2022-06-25 19:12:16.533018
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(TestFormatB, TestFormatA)
    assert plugin_manager_1.get_formatters_grouped() == {
        'test': [TestFormatA, TestFormatB],
    }

    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(TestFormatD, TestFormatA, TestFormatC)
    plugin_manager_2.register(TestFormatB)
    assert plugin_manager_2.get_formatters_grouped() == {
        'test': [TestFormatA, TestFormatB, TestFormatC, TestFormatD],
    }

    plugin_manager_3 = PluginManager()
    assert plugin_manager_3.get_formatters_grouped() == {}



# Generated at 2022-06-25 19:12:20.941214
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert str(plugin_manager_0.get_formatters_grouped()) == '{}'


# Generated at 2022-06-25 19:12:23.316521
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    res = plugin_manager_0.get_formatters_grouped()
    assert isinstance(res, dict)

# Generated at 2022-06-25 19:12:24.716066
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) != 0


# Generated at 2022-06-25 19:12:26.891236
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = plugin_manager()
    assert (plugin_manager_0.get_formatters_grouped() == {'a': [Type[FormatterPlugin_0]]})


# Generated at 2022-06-25 19:12:35.175015
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    formatters_grouped = plugin_manager_0.get_formatters_grouped()

    assert 'primary' in formatters_grouped.keys()
    assert 'secondary' in formatters_grouped.keys()

if __name__ == '__main__':
    test_case_0()
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:12:36.384818
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:12:45.012602
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin)
    plugin_manager_1.register(FormatterPlugin)
    plugin_manager_1.register(ConverterPlugin)
    plugin_manager_1.register(TransportPlugin)

    # The class BasePlugin shouldn't be filtered out
    result = plugin_manager_1.filter(AuthPlugin)
    assert(len(result) == 1)
    assert(plugin_manager_1.filter(FormatterPlugin)[0] is FormatterPlugin)



# Generated at 2022-06-25 19:12:46.765635
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_formatters_grouped() == {}


# Generated at 2022-06-25 19:12:48.369261
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:12:52.835853
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    assert type(plugin_manager_1.get_formatters_grouped()) is dict


# Generated at 2022-06-25 19:12:54.073125
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert type(plugin_manager_0.filter()) is list


# Generated at 2022-06-25 19:12:56.485345
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
        plugin_list = []
        plugin_manager3 = PluginManager()
        plugin_manager3.register(plugin_list)
        assert plugin_manager3.get_auth_plugin_mapping() == {}


# Generated at 2022-06-25 19:12:59.297845
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    Test method load_installed_plugins of class PluginManager with
    object plugin_manager_0
    """
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0 != []


# Generated at 2022-06-25 19:13:07.982008
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    get_formatters_grouped_0 = plugin_manager_0.get_formatters_grouped()
    assert len(get_formatters_grouped_0) >= 2
    assert 'group_json' in get_formatters_grouped_0
    assert 'group_html' in get_formatters_grouped_0
    assert len(get_formatters_grouped_0) <= 3

# Generated at 2022-06-25 19:13:21.185158
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()

# Generated at 2022-06-25 19:13:26.137914
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:13:29.185431
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0.filter()) >= 16

    plugin_manager_1 = PluginManager()
    assert len(plugin_manager_1.filter()) == 0



# Generated at 2022-06-25 19:13:33.780099
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    # AssertionError raised if assertion fails.
    assert (plugin_manager_0.get_auth_plugin_mapping()) == {}, " get_auth_plugin_mapping failed"


# Generated at 2022-06-25 19:13:36.264284
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped != {}

# Generated at 2022-06-25 19:13:43.742288
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import HTTPieFormatterPlugin

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(HTTPieFormatterPlugin)
    mapping_1 = plugin_manager_1.get_formatters_grouped()
    assert len(mapping_1) == 1


# Generated at 2022-06-25 19:13:45.627610
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Initialize
    pl = PluginManager()

    # Assert
    assert isinstance(pl.get_formatters_grouped(), dict)

# Generated at 2022-06-25 19:13:55.858857
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()

    from httpie.plugins.formatter.colors import ColoredFormatterPlugin
    from httpie.plugins.formatter.format import FormattedFormatterPlugin
    from httpie.plugins.formatter.json import JSONFormatterPlugin
    from httpie.plugins.formatter.pretty import PrettyFormatterPlugin

    plugin_manager_1.extend([
        JSONFormatterPlugin(),
        PrettyFormatterPlugin(),
        FormattedFormatterPlugin(),
        ColoredFormatterPlugin()
    ])

    assert(len(plugin_manager_1.get_formatters_grouped()) == 2)
    assert("format" in plugin_manager_1.get_formatters_grouped())
    assert("colored" in plugin_manager_1.get_formatters_grouped())


# Generated at 2022-06-25 19:13:57.565116
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert True


# Generated at 2022-06-25 19:14:06.758526
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.formatter import JSONFormatterPlugin
    from httpie.plugins.converter import JSONConverterPlugin
    from httpie.plugins.transport.http import HTTPTransportPlugin
    from httpie.output.streams import OutputStream, stdout_bytes_writer, stdout_unicode_writer
    plugin_manager.register(BasicAuthPlugin, JSONFormatterPlugin, JSONConverterPlugin, HTTPTransportPlugin, OutputStream, stdout_bytes_writer, stdout_unicode_writer)
    print(plugin_manager.filter(FormatterPlugin))



# Generated at 2022-06-25 19:14:17.365023
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:14:20.269516
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    plugin_manager_1 = PluginManager()
    result_0 = plugin_manager_1.load_installed_plugins()
    assert result_0 == None, 'Expected None, but got %s' % repr(result_0)


# Generated at 2022-06-25 19:14:23.603003
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters_grouped()
    assert formatters.keys() == {'formatters', 'debug'}

# Generated at 2022-06-25 19:14:25.336131
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:29.233460
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    assert len(plugin_manager_0) == 0
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) > 0


# Generated at 2022-06-25 19:14:35.453214
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    #
    plugin_manager_0 = PluginManager()
    #
    #
    plugin_manager_0.load_installed_plugins()
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    #
    assert plugin_manager_0.get_formatters_grouped() == plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:14:37.131817
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.filter() != None


# Generated at 2022-06-25 19:14:43.020873
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert list(mapping.keys()) == ['basic', 'digest', 'hawk']


# Generated at 2022-06-25 19:14:51.175462
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    
    assert issubclass(plugin_manager_0.filter(tuple)[0], BasePlugin)
    assert issubclass(plugin_manager_0.filter(TransportPlugin)[0], TransportPlugin)
    assert issubclass(plugin_manager_0.filter(FormatterPlugin)[0], FormatterPlugin)
    assert issubclass(plugin_manager_0.filter(AuthPlugin)[0], AuthPlugin)
    assert issubclass(plugin_manager_0.filter(ConverterPlugin)[0], ConverterPlugin)


# Generated at 2022-06-25 19:14:56.062299
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(f"loaded_plugins:{plugin_manager}\n")
    print(f"auth plugins:{plugin_manager.get_auth_plugins()}\n")
    print(f"auth plugin mapping:{plugin_manager.get_auth_plugin_mapping()}\n")


if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:15:13.657082
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:15:15.104400
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager().load_installed_plugins()



# Generated at 2022-06-25 19:15:19.671327
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    # This test currently fails due to ImportError: No module named 'httpie_multipart'
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:15:21.657170
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert(len(formatters_grouped) == 2)
    assert(formatters_grouped["Beautiful"])
    assert(formatters_grouped["Syntax"])


# Generated at 2022-06-25 19:15:29.746770
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    class plugin_1(BasePlugin):
        pass
    class plugin_2(BasePlugin):
        pass
    class plugin_3(Type[BasePlugin]):
        pass
    class plugin_4(ConverterPlugin):
        pass
    plugin_manager_1.register(plugin_1,plugin_2,plugin_3,plugin_4)
    assert plugin_manager_1.filter(by_type=Type[BasePlugin]) == [plugin_1,plugin_2,plugin_3,plugin_4]


# Generated at 2022-06-25 19:15:32.456728
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert type(plugin_manager_1[0]).__name__ == 'AuthPlugin'

# Generated at 2022-06-25 19:15:33.322301
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert test_case_0() == PluginManager()

# Generated at 2022-06-25 19:15:35.768944
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

    assert len(plugin_manager_1) != 0


# Generated at 2022-06-25 19:15:39.584278
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FakeFormatterPlugin1, FakeFormatterPlugin2, FakeFormatterPlugin3)
    formatter_group =_get_fake_formatters_grouped()
    assert plugin_manager.get_formatters_grouped() == formatter_group


# Generated at 2022-06-25 19:15:43.234206
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert 'httpie-no-content-length-auth' in plugin_manager_0


# Generated at 2022-06-25 19:16:25.997883
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager().get_formatters_grouped()


# Generated at 2022-06-25 19:16:28.147144
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() != {}


# Generated at 2022-06-25 19:16:29.867435
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.load_installed_plugins() is None


# Generated at 2022-06-25 19:16:31.027677
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:16:36.516623
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_1_result = plugin_manager_1.get_auth_plugin_mapping()

# Generated at 2022-06-25 19:16:39.997754
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) > 0


# Generated at 2022-06-25 19:16:41.711096
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:16:43.709675
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_formatters()


# Generated at 2022-06-25 19:16:45.340610
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugins = plugin_manager.filter(AuthPlugin)
    assert plugins == []
    assert isinstance(plugins, list)


# Mock plugin

# Generated at 2022-06-25 19:16:50.227295
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    class SubPlugin(BasePlugin):
        pass
    class SuperPlugin(SubPlugin):
        pass
    plugin_manager_0.register(SuperPlugin)
    assert plugin_manager_0.filter(by_type=SubPlugin) == [SuperPlugin]



# Generated at 2022-06-25 19:18:23.512130
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(
        (BasePlugin,
        AuthPlugin,
        FormatterPlugin,
        ConverterPlugin,
        TransportPlugin))
    get_formatters_grouped = plugin_manager.get_formatters_grouped()
    assert '' in get_formatters_grouped.keys()
    assert 'json' in get_formatters_grouped.keys()
    assert 'table' in get_formatters_grouped.keys()



# Generated at 2022-06-25 19:18:24.952581
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:18:26.065142
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins(PluginManager)



# Generated at 2022-06-25 19:18:30.685977
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(test_plugin_0,test_plugin_1,test_plugin_2,test_plugin_3)
    assert isinstance(plugin_manager.filter(test_plugin_0), list)


# Generated at 2022-06-25 19:18:35.505272
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    # Testing for load_installed_plugins
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.__repr__() == '<PluginManager: [<class httpie.plugins.httpie.HttpiePlugin>]>'



# Generated at 2022-06-25 19:18:38.068472
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    auth_plugin_mapping_1 = plugin_manager_1.get_auth_plugin_mapping()
    assert(auth_plugin_mapping_1)


# Generated at 2022-06-25 19:18:42.758132
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(
        httpie.plugins.builtin.HTTPLook.HTTPLookPlugin,
        httpie.plugins.builtin.JSONLook.JSONLookPlugin,
        httpie.plugins.builtin.Table.TablePlugin,
        httpie.plugins.builtin.URLLib3.URLLib3Plugin,
    )
    plugins.load_installed_plugins()
    groups = plugins.get_formatters_grouped()
    assert list(groups.keys()) == ['HTTP', 'JSON']


# Generated at 2022-06-25 19:18:44.885570
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert type(plugin_manager_0.get_formatters_grouped())== dict
    return


# Generated at 2022-06-25 19:18:47.232230
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    try:
        plugin_manager_0.load_installed_plugins()
    except:
        return False
    else:
        return True


# Generated at 2022-06-25 19:18:52.186411
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

    # Check if all plugins are in the plugin manager
    plugin_manager_1.filter()
    nb_plugins = len(plugin_manager_1.filter())
    assert nb_plugins > 0

    # Check if only formatter plugins are in the plugin manager
    only_formatter_plugins = plugin_manager_1.filter(FormatterPlugin)
    assert len(only_formatter_plugins) > 0 and len(only_formatter_plugins) < nb_plugins
    assert all(issubclass(plugin, FormatterPlugin) for plugin in only_formatter_plugins)
