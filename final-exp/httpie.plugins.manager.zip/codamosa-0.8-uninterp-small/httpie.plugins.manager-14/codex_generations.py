

# Generated at 2022-06-25 19:10:22.833110
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.filter()
    plugin_manager_2 = PluginManager()
    plugin_manager_2.filter(by_type=Type[BasePlugin])

# Generated at 2022-06-25 19:10:25.565375
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_1 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:10:26.507635
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    print(plugin_manager_0)

# Generated at 2022-06-25 19:10:29.478471
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasePlugin)
    plugin_manager_0.load_installed_plugins()
    assert issubclass(plugin_manager_0.filter(AuthPlugin)[0], AuthPlugin)



# Generated at 2022-06-25 19:10:33.259812
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0 = plugin_manager_0.get_formatters_grouped() # test get_formatters_grouped


# Generated at 2022-06-25 19:10:35.212825
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:10:38.083706
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager_instance = PluginManager()
    result = PluginManager_instance.get_formatters_grouped()
    assert(result == {})


# Generated at 2022-06-25 19:10:41.116434
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    mapping = plugin_manager_0.get_auth_plugin_mapping()
    assert mapping == {plugin.auth_type: plugin for plugin in plugin_manager_0.get_auth_plugins()}


# Generated at 2022-06-25 19:10:52.327435
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()

    plugin1_0 = FormatterPlugin(name='Pretty',
                                  description='Pretty formatting.',
                                  group_name='Style',
                                  )
    plugin1_1 = FormatterPlugin(name='Nice',
                                  description='Nice formatting.',
                                  group_name='Style',
                                  )
    plugin2_0 = FormatterPlugin(name='Mute',
                                  description='Mute formatting.',
                                  group_name='Style',
                                  )
    plugin3_0 = FormatterPlugin(name='Compact',
                                  description='Compact formatting.',
                                  group_name='Style',
                                  )


# Generated at 2022-06-25 19:10:54.857982
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

    print("PluginManager installed plugins loaded")



# Generated at 2022-06-25 19:10:58.381801
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) > 0



# Generated at 2022-06-25 19:11:09.000944
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.get_formatters_grouped () == {}

    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(PluginA)
    assert plugin_manager_2.get_formatters_grouped () == {'group_name': [PluginA]}

    plugin_manager_3 = PluginManager()
    plugin_manager_3.register(PluginA,PluginB,PluginC)
    assert plugin_manager_3.get_formatters_grouped () == {'group_name': [PluginA, PluginB, PluginC]}

    plugin_manager_4 = PluginManager()
    plugin_manager_4.register(PluginA,PluginB,PluginC,PluginD,PluginE)

# Generated at 2022-06-25 19:11:14.801056
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin)
    plugin_manager_1.register(FormatterPlugin)
    plugin_manager_1.register(ConverterPlugin)
    plugin_manager_1.register(TransportPlugin)
    assert plugin_manager_1.get_formatters_grouped() == {}



# Generated at 2022-06-25 19:11:20.791440
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    actual = plugin_manager.get_formatters_grouped()

# Generated at 2022-06-25 19:11:23.492862
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()


# Generated at 2022-06-25 19:11:28.399291
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) >= 12
    assert len([plugin for plugin in plugin_manager_0 if plugin.name.lower() == "httpie-auth-jwt"]) == 1
    return True

# Test Cases for testing registered plugins

# Generated at 2022-06-25 19:11:31.612374
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import sys
    
    # Unit test for method filter of class PluginManager
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.filter(by_type=sys.stderr.__class__) == []


# Generated at 2022-06-25 19:11:38.921168
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatter, PrettyJSONFormatter, JSONLinesFormatter)
    plugin_manager.register(NullFormatter, ColoredJSONFormatter)
    assert plugin_manager.get_formatters_grouped() == {
        'General': [NullFormatter, JSONFormatter, JSONLinesFormatter, PrettyJSONFormatter],
        'Special': [ColoredJSONFormatter],
    }


# Generated at 2022-06-25 19:11:42.615927
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    result = plugin_manager_0.get_formatters_grouped()
    assert result != None
    # Ending method test_PluginManager_get_formatters_grouped


# Generated at 2022-06-25 19:11:48.291677
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugins_list_before = plugin_manager_0.filter(Type[BasePlugin])
    assert plugins_list_before == []
    plugin_manager_0.load_installed_plugins()
    plugins_list_after = plugin_manager_0.filter(Type[BasePlugin])
    assert plugins_list_after != []


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-25 19:11:55.238779
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_a = PluginManager()
    plugin_manager_a.load_installed_plugins()
    plugin_manager_b = PluginManager()
    plugin_manager_b.register(httpie.plugins.general.Headers)
    if not plugin_manager_b == plugin_manager_a.filter(httpie.plugins.general.Headers):
        raise Exception("For method 'filter' of class PluginManager: Fail!")


# Generated at 2022-06-25 19:11:56.650756
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:11:58.308363
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_formatters_grouped()

# Generated at 2022-06-25 19:12:06.582161
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0.filter(by_type=FormatterPlugin)) == 3
    assert len(plugin_manager_0.filter(by_type=ConverterPlugin)) == 2
    assert len(plugin_manager_0.filter(by_type=AuthPlugin)) == 7
    assert len(plugin_manager_0.filter(by_type=TransportPlugin)) == 5


# Generated at 2022-06-25 19:12:09.762186
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    get_formatters_grouped_0 = plugin_manager_0.get_formatters_grouped()
    assert isinstance(get_formatters_grouped_0,dict)


# Generated at 2022-06-25 19:12:14.808036
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()

# Generated at 2022-06-25 19:12:17.896584
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager.get_auth_plugin_mapping())
    assert len(plugin_manager.get_auth_plugin_mapping()) > 0


# Generated at 2022-06-25 19:12:26.420173
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """Check that PluginManager.get_formatters_grouped() returns a correctly sorted dictionary"""
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(Class_0, Class_1, Class_2, Class_3)
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict)
    assert (({'group_0': [Class_0, Class_1], 'group_1': [Class_3], 'group_2': [Class_2]}) == (plugin_manager_0.get_formatters_grouped()))


# Generated at 2022-06-25 19:12:28.273230
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin_mapping() == {}



# Generated at 2022-06-25 19:12:38.818476
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie import __version__ as version_str

    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_auth_plugins()
    assert plugin_manager_0.get_converters()
    assert plugin_manager_0.get_formatters()

# def test_case_1():
#     plugin_manager_0 = PluginManager()
#     plugin_manager_0.load_installed_plugins()
#     plugin_type_specification_0 = 'httpie.plugins.auth.v1'
#     plugin_manager_1 = plugin_manager_0.load_installed_plugins(plugin_type_specification_0)



# Generated at 2022-06-25 19:12:41.919820
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_auth_plugin_mapping() == {'basic': httpie_http2_auth.BasicAuthPlugin}

# Generated at 2022-06-25 19:12:44.124080
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    int_expected_1 = {}
    int_actual_1 = plugin_manager_1.get_auth_plugin_mapping()
    assert int_expected_1 == int_actual_1



# Generated at 2022-06-25 19:12:52.915596
# Unit test for method filter of class PluginManager

# Generated at 2022-06-25 19:12:58.226226
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # PluginManager instance which has been created
    plugin_manager_0 = PluginManager()
    # call the get_auth_plugin_mapping method, the value returned from get_auth_plugin_mapping method should be a Dict type
    get_auth_plugin_return_value = plugin_manager_0.get_auth_plugin_mapping()
    # check the return type of get_auth_plugin_mapping method is Dict
    assert(type(get_auth_plugin_return_value) == type({}))

# Generated at 2022-06-25 19:13:04.040868
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPluginA(FormatterPlugin):
        group_name = 'group_A'
    class FormatterPluginB(FormatterPlugin):
        group_name = 'group_B'
    class FormatterPluginC(FormatterPlugin):
        group_name = 'group_C'
    class FormatterPluginD(FormatterPlugin):
        group_name = 'group_D'
    class FormatterPluginE(FormatterPlugin):
        group_name = 'group_A'

    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPluginA, FormatterPluginB, FormatterPluginC, FormatterPluginD, FormatterPluginE)
    group_mapping = plugin_manager.get_formatters_grouped()
    assert group_mapping['group_A'] == [FormatterPluginA, FormatterPluginE]

# Generated at 2022-06-25 19:13:07.635743
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugins = plugin_manager_0.filter()
    assert plugins == []


# Generated at 2022-06-25 19:13:10.087546
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(AuthPlugin, AuthPlugin)
    assert plugin_manager_0.get_auth_plugin_mapping() == {}


# Generated at 2022-06-25 19:13:12.543940
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) > 0


# Generated at 2022-06-25 19:13:19.250326
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    print(plugin_manager_0.get_auth_plugin_mapping())
    try:
        assert len(plugin_manager_0.get_auth_plugin_mapping()) == 4
    except AssertionError as e:
        print(e)
        print('Auth list length not equal 4')
    else:
        print('Auth list length equal 4')


# Generated at 2022-06-25 19:13:20.738108
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()



# Generated at 2022-06-25 19:13:29.037584
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugin_manager_0.register(entry_point.load())
    assert plugin_manager_0 is not None


# Generated at 2022-06-25 19:13:30.017154
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()

# Generated at 2022-06-25 19:13:38.319834
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Step 1: Get the list of formatters
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(FormatterPluginA, FormatterPluginB)
    formatters_1: List[Type[FormatterPlugin]] = plugin_manager_1.get_formatters()
    assert len(formatters_1) == 2

    # Step 2: Get the result of the method
    formatters_grouped_1: Dict[str, List[Type[FormatterPlugin]]] = plugin_manager_1.get_formatters_grouped()
    assert isinstance(formatters_grouped_1, dict)
    assert len(formatters_grouped_1) == 2



# Generated at 2022-06-25 19:13:42.777099
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin
    from httpie.plugins.base import BasePlugin

    class PluginManagerTest(PluginManager):
        def register(self, *plugins: Type[BasePlugin]):
            for plugin in plugins:
                self.append(plugin)
        def unregister(self, plugin: Type[BasePlugin]):
            self.remove(plugin)
    
    class Plugin1(AuthPlugin):
        pass
    class Plugin2(FormatterPlugin):
        pass
    class Plugin3(ConverterPlugin):
        pass
    class Plugin4(TransportPlugin):
        pass

    plugin_manager_test = PluginManagerTest()
    plugin_manager_test.register(Plugin1, Plugin2, Plugin3, Plugin4)

    assert plugin_manager_test.filter(AuthPlugin)

# Generated at 2022-06-25 19:13:44.689300
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:13:46.233892
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:13:49.359401
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()

    assert plugin_manager_0.get_auth_plugin_mapping() == {}, 'Failed at case 0'


# Generated at 2022-06-25 19:13:59.272309
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    # Entry point 'httpie.plugins.auth.v1' found
    # Entry point 'httpie.plugins.formatter.v1' found
    # Entry point 'httpie.plugins.converter.v1' found
    # Entry point 'httpie.plugins.transport.v1' found
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:14:09.359902
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    # Workflow
    plugin_manager = PluginManager()
    
    # Entry point data
    entry_point_names = ["httpie.plugins.auth.v1"]
    entry_points = {
        "httpie.plugins.auth.v1": ["httpie_jwt_auth"]
    }

    # Loaded plugins
    plugins = {
        "jwt": "httpie_jwt_auth"
    }

    # Method call
    plugin_manager.load_installed_plugins()

    # Expected result
    expected = plugins

    # Actual result
    actual = plugin_manager

    # Assert
    assert actual == expected



# Generated at 2022-06-25 19:14:18.401647
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # The format name of formatter_plugin_0 is 'formatter_plugin_0'
    # The format name of formatter_plugin_1 is 'formatter_plugin_1'
    # The format name of formatter_plugin_2 is 'formatter_plugin_2'
    # The format name of formatter_plugin_3 is 'formatter_plugin_2'
    # The format name of formatter_plugin_4 is 'formatter_plugin_3'
    # The format name of formatter_plugin_5 is 'formatter_plugin_3'
    # The format name of formatter_plugin_6 is 'formatter_plugin_3'
    # The format name of formatter_plugin_7 is 'formatter_plugin_3'
    formatter_plugin_0 = FormatterPlugin()
    formatter_plugin_1 = Formatter

# Generated at 2022-06-25 19:14:26.795118
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Create instance of PluginManager
    pm = PluginManager()
    # Call function load_installed_plugins
    pm.load_installed_plugins()
    # Test if function return value is #Expected output
    assert pm is not None

if __name__ == "__main__":
    test_case_0()
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:14:31.265652
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_formatters_grouped()
    assert dict_0 is not None


# Generated at 2022-06-25 19:14:36.046169
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(TestPlugin_0, TestPlugin_1, TestPlugin_2, TestPlugin_3)
    assert plugin_manager_1.get_formatters_grouped() == {'test_group': [TestPlugin_0, TestPlugin_1], 'test_group_2': [TestPlugin_2, TestPlugin_3]}

# Generated at 2022-06-25 19:14:41.384984
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.filter(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.filter(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0

# Generated at 2022-06-25 19:14:42.884953
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    assert isinstance(plugin_manager_1.get_formatters_grouped(), dict)
    return



# Generated at 2022-06-25 19:14:50.886531
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(type('a0', (TransportPlugin, ), {'name': 'a0'}), type('a1', (TransportPlugin, ), {'name': 'a1'}))
    class Formatter(FormatterPlugin):
        name = ''
        format = 'format'
    plugin_manager.register(Formatter())
    assert len(plugin_manager.filter(TransportPlugin)) == 2
    assert len(plugin_manager.filter(FormatterPlugin)) == 1
    assert len(plugin_manager.filter()) == 3


# Generated at 2022-06-25 19:14:53.106323
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    auth_plugins = plugin_manager.filter(AuthPlugin)
    assert(len(auth_plugins) == 0)



# Generated at 2022-06-25 19:14:57.392627
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:15:00.484478
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.append(FormatterPlugin)
    plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:15:02.005719
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

    print(plugin_manager.get_formatters_grouped())

# Generated at 2022-06-25 19:15:16.017850
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    format_name = "json"

    # Test whether it is true that the method returns a dictionary
    assert isinstance(plugin_manager_1.get_formatters_grouped(), dict)

    # Test whether it is true that the method returns the correct value
    assert isinstance(plugin_manager_1.get_formatters_grouped()[format_name], list)


# Generated at 2022-06-25 19:15:21.761630
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

if __name__ == "__main__":
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    print(len(plugin_manager_0))
    print(plugin_manager_0.get_transport_plugins())

# Generated at 2022-06-25 19:15:25.739542
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
  plugin_manager_0 = PluginManager()
  plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:15:32.086026
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert {
        "Core": list,
        "Developer": list,
        "Network": list,
        "Processing": list,
        "Programming languages": list,
        "Protocols": list,
    } == plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:15:33.663979
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()



# Generated at 2022-06-25 19:15:39.147852
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(type('', (), {'name': 'test_plugin'}))
    plugin_manager_0.append(type('', (), {'name': 'test_plugin_1'}))
    plugin_manager_0.append(type('', (), {'name': 'test_plugin_2'}))
    @plugin_manager_0.filter
    def test_function():
        pass

# Generated at 2022-06-25 19:15:48.006101
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-25 19:15:49.886681
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1 is not None


# Generated at 2022-06-25 19:15:56.897848
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    import httpie.plugins.auth.basic
    import httpie.plugins.auth.digest

    plugin_manager = PluginManager()
    plugin_manager.register(httpie.plugins.auth.basic.BasicAuthPlugin,
                            httpie.plugins.auth.digest.DigestAuthPlugin)

    assert plugin_manager.get_auth_plugin_mapping() \
            == {'basic': httpie.plugins.auth.basic.BasicAuthPlugin, 'digest': httpie.plugins.auth.digest.DigestAuthPlugin}



# Generated at 2022-06-25 19:15:59.183752
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:16:09.626573
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
	manager = PluginManager()
	manager.register(BasePlugin, BasePlugin)
	assert manager.filter(by_type = Type[BasePlugin]) == [BasePlugin, BasePlugin]



# Generated at 2022-06-25 19:16:18.877195
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
  plugin_manager_0 = PluginManager()
  plugin_manager_0.load_installed_plugins()
  dict_0 = plugin_manager_0.get_auth_plugin_mapping()

  # Did we get back a dictionary?
  if not isinstance(dict_0, dict):
    raise AssertionError("Expected dictionary, got " + str(type(dict_0)))

  # Did we get back a dictionary with a key that matches the expected key?
  expected_key = 'basic'
  if expected_key not in dict_0:
    raise AssertionError(f"Expected key {expected_key} not in dictionary {dict_0}")


# Generated at 2022-06-25 19:16:20.438556
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_formatters_grouped() == {}



# Generated at 2022-06-25 19:16:25.207835
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # plugins = PluginManager()
    # plugins.load_installed_plugins()
    # print(type(plugins))
    # print(len(plugins))
    # print(plugins.get_auth_plugin_mapping())
    # print(plugins.get_formatters_grouped())
    # print(plugins.get_converters())
    pass

if __name__ == '__main__':
    # test_PluginManager_load_installed_plugins()
    test_case_0()

# Generated at 2022-06-25 19:16:27.443503
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    plugin_manager = PluginManager()
    dict_ = plugin_manager.get_formatters_grouped()

    assert dict_.keys() == {'group1', 'group2'}
    assert len(dict_['group1']) == 2 and len(dict_['group2']) == 0

# Generated at 2022-06-25 19:16:29.129232
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_formatters_grouped()
    assert dict_0 == None


# Generated at 2022-06-25 19:16:31.681499
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    # AssertionError: TypeError: plugins() missing 1 required positional argument: 'self'
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:16:42.247129
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from hypothesis import given
    from hypothesis.strategies import lists, dictionaries, tuples, integers
    from httpie.plugins import FormatterPlugin

    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.get_formatters_grouped()
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(FormatterPlugin)
    plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:16:47.007963
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append('Authentication')
    plugin_manager_0.append('HTTP')
    plugin_manager_0.append('Terminal formatting')
    dict_0 = plugin_manager_0.get_formatters_grouped()
    assert "HTTP" in dict_0.keys()
    assert "Authentication" in dict_0.keys()
    assert "Terminal formatting" in dict_0.keys()
    assert dict_0["HTTP"] == []
    assert dict_0["Authentication"] == []
    assert dict_0["Terminal formatting"] == []


# Generated at 2022-06-25 19:16:58.197927
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    dict_0 = dict()
    dict_0 = dict(dict_0)
    dict_0['json'] = '[<class \'httpie.plugins.builtin.JsonFormatter\'>, <class \'httpie.plugins.builtin.PrettyJsonFormatter\'>]'
    dict_0['text'] = '[<class \'httpie.plugins.builtin.ColorsFormatter\'>, <class \'httpie.plugins.builtin.HtmlFormatter\'>, <class \'httpie.plugins.builtin.SubFormatter\'>, <class \'httpie.plugins.builtin.UnicodeFormatter\'>]'

# Generated at 2022-06-25 19:17:18.345736
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    try:
        plugin_manager = PluginManager()
        plugin_manager.load_installed_plugins()
        res = plugin_manager.get_auth_plugin_mapping()
        assert(isinstance(res, dict))
    except:
        assert(False)


# Generated at 2022-06-25 19:17:22.640262
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    arg_0 = []
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(*arg_0)

    # Call the method
    result = plugin_manager_0.get_formatters_grouped()

    # Check the result
    assert type(result) == dict
    assert len(result) == 0

# Generated at 2022-06-25 19:17:25.700103
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    test_case_0()



if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:17:27.565743
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:17:30.130473
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict)


# Generated at 2022-06-25 19:17:33.359950
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_formatters_grouped()

test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:17:37.326434
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:17:39.628410
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    class_0 = plugin_manager_0.filter(BasePlugin)
    assert len(class_0) == 0



# Generated at 2022-06-25 19:17:42.256223
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()



# Generated at 2022-06-25 19:17:49.379016
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from pkg_resources import iter_entry_points
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

    # Test to check that filter filters plugins of the type ConverterPlugin
    list_0 = plugin_manager_0.filter(ConverterPlugin)
    assert len(list_0) == 1 and isinstance(list_0[0], ConverterPlugin)
    # Test to check that filter filters plugins of the type FormatterPlugin
    list_1 = plugin_manager_0.filter(FormatterPlugin)
    assert len(list_1) == 4 and isinstance(list_1[0], FormatterPlugin)
    # Test to check that filter filters plugins of the type AuthPlugin
    list_2 = plugin

# Generated at 2022-06-25 19:18:28.170678
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    test_case_0()



# Generated at 2022-06-25 19:18:37.605494
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_formatters_grouped()
    dict_1 = {}
    dict_1['_group_names'] = [
        'Builtin',
        'JSON',
        'HTML',
        'Markdown',
        'XML',
        '_other',
    ]

# Generated at 2022-06-25 19:18:39.978942
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_formatters_grouped()

if __name__ == '__main__':
    test_case_0()
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:18:41.575597
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    dict_1 = plugin_manager_1.get_formatters_grouped()
    assert dict_1 != None


# Generated at 2022-06-25 19:18:49.529935
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(type('', (), {'group_name': 'json'}))
    plugin_manager_0.append(type('', (), {'group_name': 'json'}))
    plugin_manager_0.append(type('', (), {'group_name': 'redirected'}))
    plugin_manager_0.append(type('', (), {'group_name': 'verbose'}))
    plugin_manager_0.append(type('', (), {'group_name': 'verbose'}))
    dict_0 = plugin_manager_0.get_formatters_grouped()
    print(dict_0)

test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:18:55.417161
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Init a PluginManager object
    plugin_manager = PluginManager()
    dict_0 = plugin_manager.filter(by_type=BasePlugin)
    dict_1 = plugin_manager.filter(by_type=AuthPlugin)
    dict_2 = plugin_manager.filter(by_type=FormatterPlugin)
    dict_3 = plugin_manager.filter(by_type=ConverterPlugin)


# Generated at 2022-06-25 19:19:03.078711
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.filter()
    plugin_manager_0.filter(by_type=Type[BasePlugin])
    assert_type('plugin_manager_0', plugin_manager_0, PluginManager)
    assert_type('plugin_manager_0.filter()', plugin_manager_0.filter(), List[Type[BasePlugin]])
    assert_type('plugin_manager_0.filter(by_type=Type[BasePlugin])', plugin_manager_0.filter(by_type=Type[BasePlugin]), List[Type[BasePlugin]])



# Generated at 2022-06-25 19:19:05.917675
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # this is a dummy test case
    # Unit test method load_installed_plugins of class PluginManager
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:19:08.709944
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    if (test_PluginManager_get_formatters_grouped.__doc__):
        print(test_PluginManager_get_formatters_grouped.__doc__)

if __name__ == "__main__":
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:19:10.040130
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()