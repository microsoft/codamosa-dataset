

# Generated at 2022-06-25 19:10:22.543456
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin, ConverterPlugin, FormatterPlugin)
    assert plugin_manager_1.filter(BasePlugin) == plugin_manager_1
    assert plugin_manager_1.filter(ConverterPlugin) == [ConverterPlugin]


# Generated at 2022-06-25 19:10:24.867217
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # testing if requested groups are returned
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_formatters_grouped() != None


# Generated at 2022-06-25 19:10:27.766013
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    assert plugins.get_formatters_grouped() == {'FormatterPlugin': [FormatterPlugin, FormatterPlugin]}

# Generated at 2022-06-25 19:10:32.545284
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    plugin_manager.get_auth_plugin('basic')

    plugin_manager.get_auth_plugin('digest')

    plugin_manager.get_auth_plugin('gssnegotiate')

    plugin_manager.get_auth_plugin('multipart')

    plugin_manager.get_auth_plugin('oauth1')

    plugin_manager.get_auth_plugin('ntlm')

    # plugin_manager.get_formatters()

    # plugin_manager.get_converters()

    # plugin_manager.get_transport_plugins()

# Generated at 2022-06-25 19:10:40.477932
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(Group1Formatter1)
    plugin_manager_1.register(Group2Formatter1)
    plugin_manager_1.register(Group1Formatter2)
    plugin_manager_1.register(Group2Formatter2)

    grouped_formatters_dict = plugin_manager_1.get_formatters_grouped()
    assert grouped_formatters_dict == {
        'group1': [Group1Formatter1, Group1Formatter2],
        'group2': [Group2Formatter1, Group2Formatter2],
    }



# Generated at 2022-06-25 19:10:42.756289
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.filter(by_type=Type[BasePlugin]) == []

# Generated at 2022-06-25 19:10:45.810478
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    installed_plugins = plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1 != installed_plugins


# Generated at 2022-06-25 19:10:48.028347
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:10:55.122621
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # test case 1
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    formatters_1 = plugin_manager_1.get_formatters_grouped()
    print(formatters_1)
    assert formatters_1 is not None

    # test case 2
    plugin_manager_2 = PluginManager()
    formatters_2 = plugin_manager_2.get_formatters_grouped()
    print(formatters_2)
    assert formatters_2 is None



# Generated at 2022-06-25 19:10:59.808333
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    print('Unit test for method load_installed_plugins of class PluginManager')
    plugin_manager_2 = PluginManager()
    plugin_manager_2.load_installed_plugins()
    assert len(plugin_manager_2) > 0
    print('pass')


# Generated at 2022-06-25 19:11:04.804501
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.append(Type[BasePlugin])
    assert plugin_manager.filter() != None
    assert plugin_manager.filter(Type[BasePlugin]) != None


# Generated at 2022-06-25 19:11:06.521897
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:09.803507
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    # print(plugin_manager_0.get_formatters_grouped())
    assert plugin_manager_0.get_formatters_grouped()['Syntax highlighting'] != []

# Generated at 2022-06-25 19:11:14.134684
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()

    assert isinstance(plugin_manager_1.filter(), list)
    assert isinstance(plugin_manager_1.filter( Type[BasePlugin] ), list)
    assert isinstance(plugin_manager_1.filter( AuthPlugin ), list)



# Generated at 2022-06-25 19:11:16.433224
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert isinstance(plugin_manager_0.filter(by_type=Type[BasePlugin]), list)



# Generated at 2022-06-25 19:11:18.491551
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:11:25.010187
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin0, TestPlugin1, TestPlugin2, TestPlugin3)

    assert plugin_manager.get_formatters_grouped() == {'group_name_0': [test.TestPlugin0, test.TestPlugin1],
                                                       'group_name_1': [test.TestPlugin2, test.TestPlugin3]}


# Generated at 2022-06-25 19:11:28.000707
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    formatters_grouped = plugin_manager_0.get_formatters_grouped()
    assert len(formatters_grouped) > 0

# Generated at 2022-06-25 19:11:35.256754
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.append(FormatterPlugin)
    plugin_manager.append(FormatterPlugin)
    plugin_manager.append(ConverterPlugin)
    plugin_manager.append(ConverterPlugin)
    plugin_manager.append(AuthPlugin)
    plugin_manager.append(AuthPlugin)
    plugin_manager.append(TransportPlugin)
    plugin_manager.get_formatters_grouped()

# Generated at 2022-06-25 19:11:43.552772
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    from httpie.plugins.auth.v1 import AuthPlugin
    from httpie.plugins.platform.v1 import NonWindowsAuthPlugin
    from httpie.plugins.platform.v1 import WindowsAuthPlugin

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin, WindowsAuthPlugin, NonWindowsAuthPlugin)

    plugin_manager_1.get_auth_plugin_mapping()
    assert plugin_manager_1._get_auth_plugin_mapping({
        AuthPlugin.auth_type: [AuthPlugin],
        WindowsAuthPlugin.auth_type: [WindowsAuthPlugin],
        NonWindowsAuthPlugin.auth_type: [NonWindowsAuthPlugin],
    })


# Generated at 2022-06-25 19:11:55.432561
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin)
    # Print the AuthPlugin
    print(AuthPlugin)
    # Print the plugin mapping
    plugin_mapping = plugin_manager_1.get_auth_plugin_mapping()
    print(plugin_mapping)
    # Print the auth type and auth plugin
    for a_type, plugin in plugin_manager_1.get_auth_plugin_mapping().items():
        print(f'Auth type: {a_type}, Auth plugin: {plugin}')


# Generated at 2022-06-25 19:12:05.448414
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.get_formatters_grouped()
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager_0.append(FormatterPlugin)
    plugin_manager

# Generated at 2022-06-25 19:12:07.589893
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:12:12.399612
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert type(plugin_manager_0.get_formatters_grouped()) == dict
    # Non-registered plugin should raise an error
    plugin_manager_0 = PluginManager()
    try:
        plugin_manager_0.get_formatters_grouped()
    except:
        assert True



# Generated at 2022-06-25 19:12:15.278076
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.get_formatters_grouped() == {'Default': [], 'Graphical': [], 'JSON': [], 'Terminal': [], 'HTTP': []}


# Generated at 2022-06-25 19:12:22.165893
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    formatters_grouped = plugin_manager_0.get_formatters_grouped()
    group_names = list(formatters_grouped)

    # Test if the output is a dictionary
    assert isinstance(formatters_grouped, dict)

    # Test if the keys in dictionary are the group names
    assert group_names[0] == 'Networking'
    assert group_names[1] == 'Internet Message Formats'
    assert group_names[2] == 'Database'
    assert group_names[3] == 'Archiving'
    assert group_names[4] == 'Presentation'
    assert group_names[5] == 'Configuration'
    assert group_names[6] == 'Developer'
    assert group_names[7] == 'Text'
    assert group_names[8] == 'Video'
    assert group

# Generated at 2022-06-25 19:12:23.311607
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:12:25.816328
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    # TODO Unit test for method load_installed_plugins of class PluginManager



# Generated at 2022-06-25 19:12:35.270599
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    formatter_grouped_dict = plugin_manager.get_formatters_grouped()
    assert isinstance(formatter_grouped_dict, dict)

# Generated at 2022-06-25 19:12:37.744064
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(**ENTRY_POINT_NAMES)
    plugin_manager.filter(by_type=Type[BasePlugin])
    assert(plugin_manager)


# Generated at 2022-06-25 19:12:55.444959
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_0 = PluginManager()
    plugins_0.load_installed_plugins()
    plugins_1 = plugins_0.get_formatters_grouped()
    assert(len(plugins_1) == 3)
    assert('json' in plugins_1)
    assert('html' in plugins_1)
    assert('terminal' in plugins_1)
    assert(len(plugins_1['json']) == 1)
    assert(len(plugins_1['html']) == 1)



# Generated at 2022-06-25 19:13:00.445435
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.filter(by_type=Type[BasePlugin]) == []


# Generated at 2022-06-25 19:13:04.031001
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginmanager = PluginManager()

# Generated at 2022-06-25 19:13:12.311963
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_1 = PluginManager()
    plugins_0 = plugin_manager_0.get_formatters()
    plugins_1 = plugin_manager_1.get_formatters()
    plugins_0_grouped = plugin_manager_0.get_formatters_grouped()
    plugins_1_grouped = plugin_manager_1.get_formatters_grouped()
    assert plugins_0 == plugins_1
    assert plugins_0_grouped == plugins_1_grouped

# Generated at 2022-06-25 19:13:21.005358
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin)
    plugin_manager_1.register(FormatterPlugin)
    plugin_manager_1.register(TransportPlugin)
    assert plugin_manager_1.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager_1.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager_1.filter(TransportPlugin) == [TransportPlugin]
    plugin_manager_1.unregister(AuthPlugin)
    assert plugin_manager_1.filter(AuthPlugin) == []
    assert plugin_manager_1.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager_1.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-25 19:13:30.370930
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_temp = PluginManager()
    # register plugins
    plugin_manager_temp.register(PluginManager)
    type_of_class_PluginManager = Type[PluginManager]
    type_of_class_BasePlugin = Type[BasePlugin]
    assert plugin_manager_temp.filter(by_type=type_of_class_BasePlugin).__len__() == 1
    assert plugin_manager_temp.filter(by_type=type_of_class_PluginManager).__len__() == 1
    plugin_manager_temp.register(TestCasePlugin)
    assert plugin_manager_temp.filter(by_type=type_of_class_BasePlugin).__len__() == 2
    assert plugin_manager_temp.filter(by_type=type_of_class_PluginManager).__len__() == 1
#Unit test for

# Generated at 2022-06-25 19:13:39.282308
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import sys
    import os
    import glob
    import json
    import shutil

    sys.path.append('/tests/httpie')

    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_path = glob.glob('/usr/local/lib/python*/dist-packages/')
    plugin_list = os.listdir(plugin_path[0])
    plugin_list.sort()
    installed_json = json.load(open('./tests/httpie/json/installed_plugins.json',encoding='utf-8'))
    installed_json.sort()

    for i in range(len(plugin_list)):
        assert plugin_list[i] == installed_json[i]


# Generated at 2022-06-25 19:13:48.113840
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugins_of_type_BasePlugin = plugin_manager.filter(BasePlugin)
    len_include_names_of_plugins_of_type_BasePlugin = len(
        [plugin.include_name for plugin in plugins_of_type_BasePlugin])
    plugins_of_type_BasePlugin_including_no_plugin = plugin_manager.filter(
        BasePlugin)
    len_include_names_of_plugins_of_type_BasePlugin_including__no_plugin = len(
        [plugin.include_name for plugin in
         plugins_of_type_BasePlugin_including_no_plugin])
    plugins_of_type_AuthPlugin = plugin_manager.filter(AuthPlugin)
    len_include_names_of_plugins_of_type

# Generated at 2022-06-25 19:13:52.958053
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager.get_formatters_grouped(test_case_0) == {'JSON Formatter': ['json'], 'Table Formatter': ['table'], 'Pretty Formatter': ['pretty']}

# Generated at 2022-06-25 19:13:54.960865
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager.get_auth_plugin_mapping(), dict)


# Generated at 2022-06-25 19:14:15.941163
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-25 19:14:17.297811
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register()


# Generated at 2022-06-25 19:14:19.350503
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 5


# Generated at 2022-06-25 19:14:29.426780
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

    # Expected result of get_formatters_grouped

# Generated at 2022-06-25 19:14:32.726918
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:38.376343
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()

    created_mapping = plugin_manager.get_auth_plugin_mapping()
    assert isinstance(created_mapping, dict)
    assert created_mapping == {}

    class DummyPlugin:
        auth_type = "dummy"

    plugin_manager.register(DummyPlugin)

    created_mapping = plugin_manager.get_auth_plugin_mapping()
    assert isinstance(created_mapping, dict)
    assert created_mapping == {"dummy": DummyPlugin}


# Generated at 2022-06-25 19:14:39.992529
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    print(plugin_manager_0)



# Generated at 2022-06-25 19:14:42.907503
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    formatters = plugin_manager_1.filter(FormatterPlugin)
    assert formatters
    auth_plugins = plugin_manager_1.filter(AuthPlugin)
    assert auth_plugins
    converters = plugin_manager_1.filter(ConverterPlugin)
    assert converters
    transport_plugins = plugin_manager_1.filter(TransportPlugin)
    assert transport_plugins


# Generated at 2022-06-25 19:14:52.043488
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    import pkg_resources
    from urllib.parse import urlunparse, urlparse

    class FakeEntryPoint:
        def load(self):
            return FormatterPlugin

        def parsed_url(self, scheme='http'):
            return urlparse(urlunparse((scheme, 'example.org', '', '', '', '')))

    class FakeDistribution:
        def __init__(self):
            self.key = 'hello'

    class FakePluginManager:
        def __init__(self, plugin=None):
            if plugin is None:
                plugin = FormatterPlugin
            self.plugin = plugin

        def filter(self, by_type=Type[FormatterPlugin]):
            return [self.plugin]

    plugin_manager_1 = FakePluginManager()

# Generated at 2022-06-25 19:14:55.410768
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    dict = plugin_manager_0.get_auth_plugin_mapping()
    assert len(dict) == 0
    # Delete the existing instance
    plugin_manager_0 = None


# Generated at 2022-06-25 19:15:39.071858
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert all([
                any([
                    issubclass(type(plugin), BasePlugin) for plugin in plugin_manager_0
                ])
            ])



# Generated at 2022-06-25 19:15:41.338828
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:15:48.240407
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin

    plugin_manager = PluginManager()

    plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin)

    assert plugin_manager.filter() == [AuthPlugin, ConverterPlugin, FormatterPlugin]
    assert plugin_manager.filter(by_type=FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(by_type=ConverterPlugin) == [ConverterPlugin]

    assert plugin_manager.filter(by_type=None) == []
    assert plugin_manager.filter(by_type=BasePlugin) == []
    assert plugin_manager.filter(by_type=int) == []

# Generated at 2022-06-25 19:15:56.779441
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    temp_dict_0 = {'Text': [httpie.plugins.formatter.json.JsonFormatter], 'JSON': [httpie.plugins.formatter.json.JsonFormatter], 'CSV': [httpie.plugins.formatter.csv.CsvFormatter, httpie.plugins.formatter.csv.CsvvFormatter, httpie.plugins.formatter.csv.CsvhFormatter], 'HTML': [httpie.plugins.formatter.html.HtmlFormatter]}
    temp_dict_1 = plugin_manager_0.get_formatters_grouped()
    assert temp_dict_0 == temp_dict_1


# Generated at 2022-06-25 19:15:59.141884
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.filter()


# Generated at 2022-06-25 19:16:04.480105
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) > 0
    group_name = "Debug"
    assert group_name in plugin_manager_0.get_formatters_grouped().keys()

if __name__ == "__main__":
    test_case_0()
    test_PluginManager_get_formatters_grouped()
    print("Everything passed")

# Generated at 2022-06-25 19:16:06.980763
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(TableFormatter)
    assert plugin_manager_1.get_formatters_grouped() == {'table': [TableFormatter]}


# Generated at 2022-06-25 19:16:09.031846
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)

    print(plugin_manager_0.get_formatters_grouped())

# Generated at 2022-06-25 19:16:10.842981
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:16:12.281815
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:18:01.302742
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    group_dict = plugin_manager.get_formatters_grouped()
    for group in group_dict:
        for plugin in group_dict[group]:
            assert issubclass(plugin, FormatterPlugin)
        assert group in ['colors','misc','output','progress','unicode']

# Generated at 2022-06-25 19:18:02.657621
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
#    plugin_manager.load_installed_plugins()

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:18:09.180484
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(
        AuthPlugin(),
        FormatterPlugin(),
        ConverterPlugin(),
        TransportPlugin(),
        FormatterPlugin(),
        ConverterPlugin(),
        TransportPlugin(),
        FormatterPlugin(),
        ConverterPlugin(),
        TransportPlugin(),
        FormatterPlugin(),
        ConverterPlugin(),
        TransportPlugin(),
        FormatterPlugin(),
        ConverterPlugin(),
        TransportPlugin()
    )

    assert len(plugin_manager_0.filter(AuthPlugin)) == 1
    assert len(plugin_manager_0.filter(FormatterPlugin)) == 5
    assert len(plugin_manager_0.filter(ConverterPlugin)) == 5
    assert len(plugin_manager_0.filter(TransportPlugin)) == 5


# Generated at 2022-06-25 19:18:10.309849
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:18:13.268069
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Unit test: case 0
    plugin_manager_0 = PluginManager()

    # Unit test: case 1
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    # TODO: Unit test for each installed plugin
    # for plugin in plugin_manager_1:
    #     pass



# Generated at 2022-06-25 19:18:20.701955
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    assert not plugin_manager_1.get_auth_plugin_mapping()
    class fakeAuthPlugin(AuthPlugin):
        auth_type = 'test'
        def __init__(self, username, password):
            pass
        def _get_auth_header(self):
            pass
    plugin_manager_1.append(fakeAuthPlugin)
    assert plugin_manager_1.get_auth_plugin_mapping() == {'test': fakeAuthPlugin}


# Generated at 2022-06-25 19:18:25.927950
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin, TransportPlugin, ConverterPlugin)
    assert len(plugin_manager_1.filter(FormatterPlugin)) == 0
    assert len(plugin_manager_1.filter(AuthPlugin)) == 1
    assert len(plugin_manager_1.filter(TransportPlugin)) == 1
    assert len(plugin_manager_1.filter(ConverterPlugin)) == 1


# Generated at 2022-06-25 19:18:30.483034
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager is not None
    assert len(plugin_manager) > 0
    plugin_manager_0 = plugin_manager
    return plugin_manager_0


# Generated at 2022-06-25 19:18:39.169619
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    test1 = PluginManager()
    test1.register(TestAuthPlugin)
    test1.register(TestAuthPlugin2)
    mapping_dict_test1 = test1.get_auth_plugin_mapping()
    assert mapping_dict_test1['test'] == TestAuthPlugin
    assert mapping_dict_test1['test2'] == TestAuthPlugin2

    test2 = PluginManager()
    test2.register(TestAuthPlugin)
    test2.register(TestAuthPlugin2)
    test2.register(TestFormatterPlugin)
    test2.register(TestConverterPlugin)
    mapping_dict_test2 = test2.get_auth_plugin_mapping()
    assert mapping_dict_test2['test'] == TestAuthPlugin
    assert mapping_dict_test2['test2'] == TestAuthPlugin2

# Generated at 2022-06-25 19:18:44.395612
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager0 = PluginManager()
    # There are 9 plugins installed
    assert len(plugin_manager0.get_formatters()) == 9
    # Group the plugins by their group_name
    assert len(plugin_manager0.get_formatters_grouped()) == 3
    # Plugins in the same group have the same name
    assert plugin_manager0.get_formatters_grouped()['Group 0'][0].group_name == plugin_manager0.get_formatters_grouped()['Group 0'][1].group_name
