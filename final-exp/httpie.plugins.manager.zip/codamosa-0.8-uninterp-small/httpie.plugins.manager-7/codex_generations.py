

# Generated at 2022-06-25 19:10:27.485475
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    def get_packages_of_plugin_manager(plugin_manager_1):
        L_plugin_manager_1 = []
        for plugin in plugin_manager_1:
            L_plugin_manager_1.append(plugin.package_name)
        return L_plugin_manager_1

    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert get_packages_of_plugin_manager(plugin_manager_1) == ['httpie-jwt-auth', 'httpie-jwt-auth', 'httpie-jwt-auth', 'plugin-manager-mockup']



# Generated at 2022-06-25 19:10:28.260081
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:10:29.700049
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pass

# Generated at 2022-06-25 19:10:34.408335
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) == (len(ENTRY_POINT_NAMES) + 1)


# Generated at 2022-06-25 19:10:38.409482
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(HtmlFormatter, VegaFormatter)
    plugin_manager.get_formatters_grouped() == {'other': [HtmlFormatter], 'image': [VegaFormatter]}


# Generated at 2022-06-25 19:10:50.102439
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Ensure that the plugins list is empty
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0 == []
    # Load the plugins from the entry points
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0 != []
    # Ensure that all the entry points have been loaded
    for entry_point_name in ENTRY_POINT_NAMES:
        assert entry_point_name in vars(plugin_manager_0)
    # Ensure that each plugin list is not empty
    for entry_point_name in ENTRY_POINT_NAMES:
        plugin_list = vars(plugin_manager_0)[entry_point_name]
        assert plugin_list != []
    # Ensure that the plugin_manager_0 is not empty
    assert plugin_manager_0 != []

# Test get

# Generated at 2022-06-25 19:10:59.399131
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(httpie.plugins.builtin.FormatterPlugin())
    plugin_manager_0.append(httpie.plugins.builtin.FormatterPlugin())
    plugin_manager_0.append(httpie.plugins.builtin.FormatterPlugin())
    plugin_manager_0.append(httpie.plugins.builtin.FormatterPlugin())
    plugin_manager_0.append(httpie.plugins.builtin.FormatterPlugin())
    plugin_manager_0.append(httpie.plugins.builtin.FormatterPlugin())
    plugin_manager_0.append(httpie.plugins.builtin.FormatterPlugin())
    plugin_manager_0.append(httpie.plugins.builtin.FormatterPlugin())

# Generated at 2022-06-25 19:11:09.352774
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.filter()
    assert plugin_manager_0.filter() == []
    plugin_manager_0.get_auth_plugins()
    assert plugin_manager_0.get_auth_plugins() == []
    plugin_manager_0.get_auth_plugin(auth_type = "bG9nb24=")
    assert plugin_manager_0.get_auth_plugin(auth_type = "bG9nb24=") == []
    plugin_manager_0.get_formatters()
    assert plugin_manager_0.get_formatters() == []
    plugin_manager_0.get_formatters_grouped()
    assert plugin_manager_0.get_formatters_grouped() == []
   

# Generated at 2022-06-25 19:11:12.841105
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin_mapping() == {}


test_case_0()
test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-25 19:11:17.618001
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1.get_formatters()
    assert plugin_manager_1.get_converters()
    assert plugin_manager_1.get_auth_plugins()
    assert plugin_manager_1.get_transport_plugins()


# Generated at 2022-06-25 19:11:23.869098
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()

    # Getter 'filter' of class 'PluginManager' returns unexpected type
    var_0 = plugin_manager_0.filter()



# Generated at 2022-06-25 19:11:25.730676
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:28.110198
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert type(plugin_manager) == PluginManager
    assert len(plugin_manager) > 0

# Generated at 2022-06-25 19:11:30.349491
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:11:31.243183
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()

# Generated at 2022-06-25 19:11:37.618576
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    var_0 = plugin_manager_0.get_auth_plugin_mapping()
    # This plugin is listed in the Httpie docs, but is not in the PyPI repository.


# Generated at 2022-06-25 19:11:41.296767
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    # AssertionError: <PluginManager: []> != <PluginManager: [{pytest_plugin_1}]>
    assert not plugin_manager_0.get_formatters_grouped() == plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:11:42.480430
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pass


# Generated at 2022-06-25 19:11:44.310457
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert len(plugin_manager_0.filter()) == 0


# Generated at 2022-06-25 19:11:45.806708
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:49.947062
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:54.320722
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters_grouped()
    if formatters is None:
        raise Exception("Unit test for PluginManager.get_formatters_grouped() failed, test returns None")
    else:
        assert True


# Generated at 2022-06-25 19:11:57.269921
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register()
    assert plugin_manager_0.get_formatters_grouped() == {}
    assert plugin_manager_0.get_formatters_grouped() == {}



# Generated at 2022-06-25 19:11:58.476216
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager_0 = PluginManager()
    PluginManager_0.load_installed_plugins()


# Generated at 2022-06-25 19:12:05.056876
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    # Creates an object of class PluginManager
    obj_PluginManager_2 = PluginManager([])

    # Calls the method get_formatters_grouped of class PluginManager on obj_PluginManager_2
    var_PluginManager__return_value_get_formatters_grouped_1 = obj_PluginManager_2.get_formatters_grouped()

    # Asserts the return type of the method get_formatters_grouped of class PluginManager on obj_PluginManager_2
    testlib.assert_isinstance(var_PluginManager__return_value_get_formatters_grouped_1, dict)

    # Asserts the return value of the method get_formatters_grouped of class PluginManager on obj_PluginManager_2

# Generated at 2022-06-25 19:12:07.633956
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:12:08.255266
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pass


# Generated at 2022-06-25 19:12:09.194776
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert False


# Generated at 2022-06-25 19:12:11.221105
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:12:13.057398
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    method_0 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:12:22.989530
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

    # Tests for invalid return type
    formatters = plugin_manager.get_formatters_grouped()
    if not isinstance(formatters, dict):
        raise Exception('The return type was invalid')


# Generated at 2022-06-25 19:12:26.929440
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    var_0 = {
        'foo': plugin_manager_0.filter(),
        'bar': plugin_manager_0.filter(by_type=Type[BasePlugin]),
    }
    var_1 = [
        var_0['foo'],
        var_0['bar'],
    ]


# Generated at 2022-06-25 19:12:27.821831
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    pass

# Generated at 2022-06-25 19:12:36.763543
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_2 = PluginManager()
    plugin_manager_3 = PluginManager()
    plugin_manager_4 = PluginManager()
    plugin_manager_5 = PluginManager()
    plugin_manager_6 = PluginManager()
    plugin_manager_7 = PluginManager()
    plugin_manager_8 = PluginManager()
    plugin_manager_9 = PluginManager()
    plugin_manager_10 = PluginManager()
    plugin_manager_11 = PluginManager()
    plugin_manager_12 = PluginManager()
    plugin_manager_13 = PluginManager()
    plugin_manager_14 = PluginManager()
    plugin_manager_15 = PluginManager()
    plugin_manager_16 = PluginManager()
    plugin_manager_17 = PluginManager()
    plugin_manager_18 = PluginManager()
   

# Generated at 2022-06-25 19:12:44.890371
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()

    # Case 0: Test if the plugin manager is not loading anything
    assert len(plugin_manager) == 0

    # Case 1: Test if the plugin manager loads all plugins correctly
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) > 0

    dependency_names = [item.package_name for item in plugin_manager]

    assert 'httpie' in dependency_names
    assert 'httpie-assume' in dependency_names

# Generated at 2022-06-25 19:12:53.586977
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from _pytest.tmpdir import TempdirFactory
    tmpdir = TempdirFactory()
    from pkg_resources import Distribution
    from pkg_resources import EntryPoint
    from pkg_resources import PathMetadata
    from pkg_resources import working_set
    plugin_manager_2 = PluginManager()
    plugin_manager_2.load_installed_plugins()
    var_0 = plugin_manager_2.register()
    tmpdir.join('plugin_101.py').write(textwrap.dedent('''
        import httpie.plugins

        class Plugin_101(httpie.plugins.BasePlugin):
            pass
    '''))
    path = Path(tmpdir.strpath, 'plugin_101.py')
    tmp_dist_2 = Distribution(location=path)

# Generated at 2022-06-25 19:12:55.720709
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    var_1 = plugin_manager_1.register()
    var_0 = plugin_manager_1.filter()



# Generated at 2022-06-25 19:13:02.468107
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.get_auth_plugin_mapping()
    var_0 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:13:05.860061
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:13:07.931154
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.filter()


# Generated at 2022-06-25 19:13:25.040699
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    x = PluginManager()
    assert x.get_formatters_grouped() == {}
    assert x.get_formatters_grouped() == x.get_formatters_grouped()
    assert x.get_formatters_grouped() == x.get_formatters_grouped()
    assert x.get_formatters_grouped() == x.get_formatters_grouped()
    assert x.get_formatters_grouped() == x.get_formatters_grouped()
    assert x.get_formatters_grouped() == x.get_formatters_grouped()
    assert x.get_formatters_grouped() == x.get_formatters_grouped()
    assert x.get_formatters_grouped() == x.get_formatters_grouped()
    assert x.get_formatters_

# Generated at 2022-06-25 19:13:28.334592
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    var_0 = plugin_manager_0.get_formatters_grouped()

test_case_0()
test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:13:31.345767
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.filter()
    assert var_0 is not None


# Generated at 2022-06-25 19:13:34.009423
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.filter()


# Generated at 2022-06-25 19:13:37.431409
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager(object_0)

    # Test with good parameter
    var_0 = plugin_manager_0.get_auth_plugin_mapping()

    # Test with bad parameter
    # TODO: Out of bound parameter
    # TODO: Null parameter
    # TODO: Type mismatch



# Generated at 2022-06-25 19:13:47.656131
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_auth_plugin('basic')
    # plugin_manager_0.load_installed_plugins()
    # assert plugin_manager_0.get_auth_plugin('basic')
    # plugin_manager_0.load_installed_plugins()
    # assert plugin_manager_0.get_auth_plugin('basic')
    # plugin_manager_0.load_installed_plugins()
    # assert plugin_manager_0.get_auth_plugin('basic')
    # plugin_manager_0.load_installed_plugins()
    # assert plugin_manager_0.get_auth_plugin('basic')
    # plugin_manager_0.load_installed_plugins()
    # assert plugin_manager_0.get

# Generated at 2022-06-25 19:13:54.350117
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # default args
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.register()
    var_1 = plugin_manager_0.filter()

    # one-arg override
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.register()
    var_1 = plugin_manager_0.filter(by_type=list)


# Generated at 2022-06-25 19:13:56.106820
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:05.285676
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    if var_0:
        var_0.load_installed_plugins()
    var_1 = plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:14:07.432775
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:14:37.867488
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(AuthenticationPlugin)
    plugin_manager_0.register(AuthPlugin, FormatterPlugin, ConverterPlugin)
    var_0 = plugin_manager_0.filter(AuthPlugin)
    var_1 = plugin_manager_0.filter(ConverterPlugin)
    var_2 = plugin_manager_0.filter(AuthPlugin, FormatterPlugin)
    # Check if var_2 is a list

# Generated at 2022-06-25 19:14:39.301352
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:14:42.493148
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_auth_plugins() == [], 'PluginManager.get_auth_plugins() returned wrong value'
    assert plugin_manager_0.get_auth_plugin_mapping() == {}, 'PluginManager.get_auth_plugin_mapping() returned wrong value'
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:44.950841
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:14:48.134336
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:49.780171
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:56.675230
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    group_names = ["group_name", "group_name"]
    group_names_expected = ["group_name"]
    func_result = plugin_manager.get_formatters_grouped()
    group_names_result = list(func_result.keys())
    assert group_names_result == group_names_expected

# Generated at 2022-06-25 19:15:04.463709
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Instantiate plugin_manager_0
    plugin_manager_0 = PluginManager()
    # Call get_auth_plugin_mapping(plugin_manager_0)
    result = plugin_manager_0.get_auth_plugin_mapping()
    # Assert type of result is Dict[str, Type[AuthPlugin]]
    assert_equals(type(result), Dict[str, Type[AuthPlugin]], "message")


# Generated at 2022-06-25 19:15:07.007342
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    pytest.raises(TypeError, plugin_manager_1.get_formatters_grouped)



# Generated at 2022-06-25 19:15:07.826652
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    obj_0 = PluginManager()


# Generated at 2022-06-25 19:15:57.777449
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1)
    plugin_manager.register(Plugin2)
    plugin_manager.register(Plugin3)
    plugin_manager.register(Plugin4)

    expected = {
        'Group-1': [Plugin1, Plugin2],
        'Group-2': [Plugin4],
        'Group-3': [Plugin3],
    }
    assert plugin_manager.get_formatters_grouped() == expected


# Helper classes for test_PluginManager_get_formatters_grouped

# Generated at 2022-06-25 19:16:00.273820
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager


# Generated at 2022-06-25 19:16:05.659252
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters_grouped()
    assert formatters == {'Cookie': [], 'Form': [], 'Pretty': [], 'Body': []}


# Generated at 2022-06-25 19:16:06.859608
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:16:08.200565
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:16:10.690517
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    var_1 = plugin_manager_0.get_formatters_grouped()
    assert True


# Generated at 2022-06-25 19:16:12.395729
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    """
    Test for get_auth_plugin_mapping of class PluginManager
    """
    plugin_manager_0 = PluginManager()


# Generated at 2022-06-25 19:16:13.975615
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    var_1 = plugin_manager_1.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:16:17.695296
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()


# Generated at 2022-06-25 19:16:19.141314
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:18:05.144593
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    var_0 = plugin_manager_0.filter()



# Generated at 2022-06-25 19:18:05.805915
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert True


# Generated at 2022-06-25 19:18:07.094444
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Arguments
    plugin_manager = PluginManager()

    # Action
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:18:09.064959
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0.get_formatters_grouped() is not None


# Generated at 2022-06-25 19:18:10.401428
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:18:13.131809
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert (plugin_manager.get_formatters_grouped() == {})

if __name__ == "__main__":
    test_case_0()
    test_PluginManager_get_formatters_grouped()
    print("TEST PASSED")

# Generated at 2022-06-25 19:18:16.055104
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    var_1 = plugin_manager_1.register()

# Generated at 2022-06-25 19:18:22.852820
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
	# Create a plugin manager
	plugin_manager = PluginManager()
	# Create plugin manager
	plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
	# Create a list of plugins
	plugins = [AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin]
	# Call method filter with the list of plugins
	plugins_filtered = plugin_manager.filter(by_type=Type[BasePlugin])
	# Verify that the result is the same
	assert plugins_filtered == plugins


# Generated at 2022-06-25 19:18:24.800787
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # TEST_CASE_0
    try:
        test_case_0()
    except Exception as ex:
        print(ex)


# Generated at 2022-06-25 19:18:26.663096
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.load_installed_plugins() == None
