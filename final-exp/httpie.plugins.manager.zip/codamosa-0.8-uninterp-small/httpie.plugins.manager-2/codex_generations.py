

# Generated at 2022-06-25 19:10:25.787836
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    group_name_list = ['VIM','JSON','HTTPIE','V']
    group_name_list_set = set(group_name_list)

    result = plugin_manager_1.get_formatters_grouped()
    result = list(result.keys())

    if (group_name_list_set.issubset(result)):
        assert("True")
    else:
        assert("False")

# Generated at 2022-06-25 19:10:27.606090
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.load_installed_plugins() == None


# Generated at 2022-06-25 19:10:29.835208
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()

    plugin_manager_0.load_installed_plugins()
    formatters = plugin_manager_0.filter(FormatterPlugin)

    assert len(formatters) > 0

# Generated at 2022-06-25 19:10:35.685820
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    try:
        plugin_manager_1.load_installed_plugins()
    except Exception as e:
        assert False, 'load_installed_plugins() of class PluginManager failed!'
    else:
        assert True, 'load_installed_plugins() of class PluginManager succeeded!'


# Generated at 2022-06-25 19:10:37.073835
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pass


# Generated at 2022-06-25 19:10:43.816883
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    BuiltinAuthPlugin = PluginManager.get_auth_plugin(plugin_manager_0, 'basic')
    BuiltinBasicAuthPlugin = PluginManager.get_auth_plugin(plugin_manager_0, 'digest')
    BuiltinDigestAuthPlugin = PluginManager.get_auth_plugin(plugin_manager_0, 'digest')
    BuiltinHawkAuthPlugin = PluginManager.get_auth_plugin(plugin_manager_0, 'hawk')
    BuiltinNetrcAuthPlugin = PluginManager.get_auth_plugin(plugin_manager_0, 'netrc')
    BuiltinNoAuthPlugin = PluginManager.get_auth_plugin(plugin_manager_0, 'no')

# Generated at 2022-06-25 19:10:48.767266
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register()
    expected = {}
    actual = plugin_manager_0.get_auth_plugin_mapping()
    assert actual == expected, f'Expected: {expected}, but got: {actual}'
    plugin_manager_0.unregister()


# Generated at 2022-06-25 19:10:49.664512
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    # Case 0: non-empty plugin_manager_0
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:10:56.225745
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    entry_point_name = 'httpie.plugins.auth.v1'
    for entry_point in iter_entry_points(entry_point_name):
        plugin = entry_point.load()
        plugin.package_name = entry_point.dist.key
        plugin_manager_0 = PluginManager()
        plugin_manager_0.register(plugin)
        plugin_manager_0.get_auth_plugin_mapping()
    return True


# Generated at 2022-06-25 19:10:59.011238
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    u = plugin_manager_0.get_formatters_grouped()
    assert isinstance(u, dict)

# Generated at 2022-06-25 19:11:10.790942
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    # We test only JSON formatters in this function
    list_0 = plugin_manager_0.get_formatters_grouped()['JSON']
    list_1 = plugin_manager_0.get_formatters() # list_1 is a collection of classes
    list_2 = plugin_manager_0.filter(FormatterPlugin)
    assert list_0 == list_2
    assert list_1 == list_2
    assert list_0 != list_1
    assert len(list_1) == len(list_0)
    assert len(list_0) == len(list_2)
    assert isinstance(list_0[0], FormatterPlugin)
    assert list_0[0] == list_2[0]
   

# Generated at 2022-06-25 19:11:11.728689
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()


# Generated at 2022-06-25 19:11:22.877208
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(GitHubAuth, GitHubEnterpriseAuth, GitHubTokenAuth)
    plugin_manager_0.register(ColoredStream, ColoredStreamOutput, PrettyStreamOutput)
    plugin_manager_0.register(NetRCAuth, NoAuth, HTTPBasicAuth)
    plugin_manager_0.register(JSONHARFormat, JSONHARViewerFormat)
    plugin_manager_0.register(BytesToHexBinaryConverter, HexBinaryToBytesConverter)
    plugin_manager_0.register(JSONValidator, XMLValidator)
    plugin_manager_0.register(TCPTransport, UNIXSocketTransport, HTTPTransport, LocalhostAuthentication)
    plugin_manager_0.register(JSONHARComposer, JSONHARFormat)

# Generated at 2022-06-25 19:11:25.417037
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.filter()
    if len(list_0) == 0:
        return


# Generated at 2022-06-25 19:11:26.209284
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager.get_formatters_grouped()

# Generated at 2022-06-25 19:11:37.608200
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    # Check whether plugin_manager_1.list contains all plugins in ENTRY_POINT_NAMES
    list_0 = plugin_manager_1.get_formatters()
    # Check whether the length of list_0 is the same as the number of plugins in ENTRY_POINT_NAMES
    assert len(list_0) == 2
    list_1 = plugin_manager_1.get_auth_plugins()
    # Check whether the length of list_1 is the same as the number of plugins in ENTRY_POINT_NAMES
    assert len(list_1) == 2
    list_2 = plugin_manager_1.get_converters()
    # Check whether the length of list_2 is the same as the number of plugins in

# Generated at 2022-06-25 19:11:39.432589
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:11:49.448046
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(BasePlugin)
    plugin_manager_1.register(FormatterPlugin)
    plugin_manager_1.register(ConverterPlugin)
    list_1 = plugin_manager_1.filter()
    assert list_1 == [BasePlugin, FormatterPlugin, ConverterPlugin], "list_1.actual is not equal to list_1.expected"
    list_2 = plugin_manager_1.filter(FormatterPlugin)
    assert list_2 == [FormatterPlugin], "list_2.actual is not equal to list_2.expected"
    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(FormatterPlugin)
    plugin_manager_2.register(ConverterPlugin)

# Generated at 2022-06-25 19:11:58.205167
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0

# Generated at 2022-06-25 19:11:59.499112
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:12:08.017246
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import pytest_httpie_0

    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:12:11.141819
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) > 0, "Calling method load_installed_plugins of class PluginManager failed"


# Generated at 2022-06-25 19:12:18.174800
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpbinPlugin)
    plugin_manager_0.register(UserAgentPlugin)
    plugin_manager_0.register(JsonPlugin)
    plugin_manager_0.register(AuthPlugin)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.register(TransportPlugin)
    plugin_manager_0.register(HttpiePlugin)
    plugin_manager_0.register(HttpbinPlugin)
    plugin_manager_0.register(UserAgentPlugin)
    plugin_manager_0.register(JsonPlugin)
    plugin_manager_0.register(AuthPlugin)

# Generated at 2022-06-25 19:12:22.141497
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:12:23.904780
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:12:25.292930
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:12:27.369820
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert type(plugin_manager_0.filter(Type[BasePlugin])) == list


# Generated at 2022-06-25 19:12:31.454150
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    print(formatters_grouped)


# Generated at 2022-06-25 19:12:35.298081
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.append(test_case_0)
    plugin_manager_1.append(test_case_0)
    plugin_manager_1.append(test_case_0)
    plugin_manager_1.append(test_case_0)
    list_1 = plugin_manager_1.filter(test_case_0)


# Generated at 2022-06-25 19:12:36.757198
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    list_1 = plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:12:48.465062
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    list_0 = []
    plugin_manager_0 = PluginManager()
    try:
        dct_0 = plugin_manager_0.get_formatters_grouped()
        list_0.append(dct_0)
    except:
        pass
    finally:
        assert (isinstance(list_0[0], dict))


# Generated at 2022-06-25 19:12:52.936981
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    dict_0 = plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:12:54.125870
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:12:55.915244
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    assert isinstance(plugin_manager_0.get_auth_plugin_mapping(), dict)



# Generated at 2022-06-25 19:13:00.880191
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    try:
        instance = PluginManager()
        instance.load_installed_plugins()
    except Exception:
        traceback.print_exc()


# Generated at 2022-06-25 19:13:03.889660
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:13:10.422325
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_formatters()
    list_1 = plugin_manager_0.get_auth_plugins()
    list_2 = plugin_manager_0.get_converters()
    list_3 = plugin_manager_0.get_transport_plugins()



# Generated at 2022-06-25 19:13:20.982583
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.get_auth_plugin("bearer")
    plugin_manager_0.get_auth_plugin("basic")
    plugin_manager_0.get_auth_plugin("digest")
    plugin_manager_0.get_auth_plugin("")
    plugin_manager_0.get_auth_plugin("hawk")
    plugin_manager_0.get_auth_plugin("aws4-hmac-sha256")
    plugin_manager_0.get_auth_plugin("aws4-hmac-sha1")
    plugin_manager_0.get_auth_plugin("aws4-hmac-sha512")
    plugin_manager_0.get_auth_plugin("aws4-hmac-sha384")
   

# Generated at 2022-06-25 19:13:24.821579
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.append(FormatterPlugin())
    assert plugin_manager_0.get_formatters_grouped()



# Generated at 2022-06-25 19:13:27.238503
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.filter(Type[BasePlugin])
    assert not list_0


# Generated at 2022-06-25 19:13:46.116970
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:13:54.267411
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    _entry = [
        ('httpie.plugins.auth.v1', TransportPlugin),
        ('httpie.plugins.formatter.v1', TransportPlugin),
        ('httpie.plugins.converter.v1', TransportPlugin),
        ('httpie.plugins.transport.v1', TransportPlugin),
    ]
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0[1].package_name == 'requests'
    assert plugin_manager_0[1] == requests.HTTPAdapter


# Generated at 2022-06-25 19:13:56.624939
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.filter(ConverterPlugin)


# Generated at 2022-06-25 19:13:57.857096
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert type(pm.get_auth_plugin_mapping()) is dict


# Generated at 2022-06-25 19:14:01.456208
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.load_installed_plugins()
    str_0 = 'JQ'
    str_1 = 'json'
    str_2 = 'variables'
    plugin_manager_0.load_installed_plugins()
    str_3 = 'image'
    str_4 = 'table'


# Generated at 2022-06-25 19:14:03.614872
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.filter()

# Generated at 2022-06-25 19:14:05.494377
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:14:08.387097
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_formatters_grouped()


# Generated at 2022-06-25 19:14:12.814541
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_0.load_installed_plugins()


if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:14:20.221155
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    result_0 = plugin_manager_0.filter(AuthPlugin)
    assert result_0 is not None
    assert result_0 == []
    result_1 = plugin_manager_0.filter(TransportPlugin)
    assert result_1 is not None
    assert result_1 == []
    assert result_1 is not None
    result_2 = plugin_manager_0.filter(FormatterPlugin)
    assert result_2 is not None
    assert result_2 == []
    result_3 = plugin_manager_0.filter(ConverterPlugin)
    assert result_3 is not None
    assert result_3 == []



# Generated at 2022-06-25 19:15:03.664018
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasePlugin)
    plugin_manager_0.register(TransportPlugin)
    plugin_manager_0.register(AuthPlugin)
    list_0 = plugin_manager_0.filter(TransportPlugin)
    assert len(list_0) == 1


# Generated at 2022-06-25 19:15:07.675505
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.get_auth_plugin_mapping()
    plugin_manager_0.get_formatters_grouped()
    plugin_manager_0.get_formatters()
    plugin_manager_0.get_auth_plugins()

# Generated at 2022-06-25 19:15:11.773252
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:15:13.069512
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


test_case_0()
#test_PluginManager_load_installed_plugins()

# Generated at 2022-06-25 19:15:15.834828
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_formatters()


# Generated at 2022-06-25 19:15:22.195296
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    list_0 = [ColorizeFormatter, JSONLinesFormatter, TabularFormatter, URLEncodedFormatter]
    set_0 = PluginManager()
    set_0.register(list_0)
    # Code coverage basic path of PluginManager.get_formatters_grouped
    dic_0 = set_0.get_formatters_grouped()
    assert set_0 in dic_0


# Generated at 2022-06-25 19:15:26.418548
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(class_0())
    plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:15:29.694704
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.filter(by_type=Type[BasePlugin])


# Generated at 2022-06-25 19:15:33.124978
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Instanciation of a PluginManager
    plugin_manager = PluginManager()
    # Temporary local variables
    ret: dict = None

    ret = plugin_manager.get_formatters_grouped()
    assert ret


# Generated at 2022-06-25 19:15:34.763966
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:17:09.310706
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    plugin_manager_1 = PluginManager()
    list_0 = plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:17:11.038139
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    r = plugin_manager.get_formatters_grouped()
    print(r)

# Generated at 2022-06-25 19:17:14.800046
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager_get_formatters_grouped_0 = plugin_manager.get_formatters_grouped()


# Generated at 2022-06-25 19:17:16.224763
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    mapping_0 = plugin_manager_1.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:17:19.647784
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    dict = plugin_manager_0.get_formatters_grouped()
    assert dict is not None


# Generated at 2022-06-25 19:17:22.852000
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    list_0 = plugin_manager_0.get_formatters_grouped()
    list_1 = plugin_manager_0.get_formatters()
    assert list_0 is list_1



# Generated at 2022-06-25 19:17:29.903234
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert(plugin_manager_0.filter(by_type=AuthPlugin))
    # assert(plugin_manager_0.filter(by_type=AuthPlugin))
    # assert(plugin_manager_0.filter(by_type=AuthPlugin))
    # assert(plugin_manager_0.filter(by_type=AuthPlugin))

# Generated at 2022-06-25 19:17:31.431700
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:17:38.027706
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    list_0 = plugin_manager_0.get_formatters()
    list_len = len(list_0)
    list_0_item_0 = list_0[0]
    list_0_item_1 = list_0[1]
    list_0_item_2 = list_0[2]
    list_0_item_3 = list_0[3]


# Generated at 2022-06-25 19:17:46.685347
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # set up fixtures
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(HttpiePrettyJson)
    plugin_manager_0.register(HttpiePrettyJson)
    plugin_manager_0.register(HttpiePrettyJson)
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(HttpieJson)
    plugin_manager_1.register(HttpiePrettyJson)
    plugin_manager_1.register(HttpiePrettyJson)
    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(HttpiePrettyJson)
    plugin_manager_2.register(HttpieJson)
    plugin_manager_2.register(HttpiePrettyJson)
    plugin_manager_3 = PluginManager()