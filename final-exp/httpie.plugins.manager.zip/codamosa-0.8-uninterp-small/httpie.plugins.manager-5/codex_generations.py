

# Generated at 2022-06-25 19:10:22.583322
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert  len(plugin_manager_0) == 1


# Generated at 2022-06-25 19:10:24.530758
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.filter(Type[BasePlugin]) is not []


# Generated at 2022-06-25 19:10:26.881216
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(BasePlugin)
    assert plugin_manager_1.filter() == [BasePlugin]


# Generated at 2022-06-25 19:10:28.475191
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

# Generated at 2022-06-25 19:10:34.961467
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    formatters_grouped_1 = plugin_manager_1.get_formatters_grouped()
    assert type(formatters_grouped_1) == type(dict())
    assert sorted(list(formatters_grouped_1.keys())) == ['grouped', 'ungrouped']

# Generated at 2022-06-25 19:10:37.793460
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert len(plugin_manager_0) > 3


# Generated at 2022-06-25 19:10:42.489929
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert isinstance(plugin_manager_1, PluginManager) and plugin_manager_1 is not None
    assert len(plugin_manager_1) >= 1
    print("Test method load_installed_plugins of class PluginManager is passed")

if __name__ == "__main__":
    test_case_0()
    test_PluginManager_load_installed_plugins()
    print("Unit test for class PluginManager is passed")

# Generated at 2022-06-25 19:10:53.650112
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-25 19:11:01.053517
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

    from httpie.plugins import auth
    from httpie.plugins import formatter
    from httpie.plugins import converter
    from httpie.plugins import transport

    # mock
    def iter_entry_points(entry_point_name):
        def entry_point_load():
            class MockPlugin(auth.AuthPlugin):
                pass
            return MockPlugin
        entry_point = type('MockEntryPoint', (object,),
            {'load': entry_point_load, 'dist': type('MockPkgResources', (object,),{'key':'mock'})})
        return [entry_point]


# Generated at 2022-06-25 19:11:06.566623
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(ABCFormatter)
    plugin_manager_1.register(HtmlFormatter)
    plugin_manager_1.register(JsonFormatter)
    plugin_manager_1.register(JsonLinesFormatter)

    assert isinstance(plugin_manager_1.get_formatters_grouped(), dict)



# Generated at 2022-06-25 19:11:19.906630
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import FormatterPlugin, ConverterPlugin
    from httpie.plugins.base import BasePlugin
    plugin_manager_1 = PluginManager()
    formatter1 = type('FormatterPlugin1', (FormatterPlugin,), {})
    formatter2 = type('FormatterPlugin2', (FormatterPlugin,), {})
    converter1 = type('ConverterPlugin1', (ConverterPlugin,), {})
    converter2 = type('ConverterPlugin2', (ConverterPlugin,), {})
    base = type('BasePlugin',(BasePlugin,), {})
    plugin_manager_1.register(formatter1, formatter2, converter1, converter2, base)
    result = plugin_manager_1.filter(FormatterPlugin)
    expected = [formatter1, formatter2]

# Generated at 2022-06-25 19:11:23.869424
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) > 0


# Generated at 2022-06-25 19:11:25.693423
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    p = PluginManager()
    p.register(FormatterPlugin)
    p.get_formatters_grouped()

# Generated at 2022-06-25 19:11:26.906554
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:28.973599
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_auth_plugin_mapping()
    assert plugins is not None


# Generated at 2022-06-25 19:11:34.799759
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    global entry_point_name, entry_point
    plugin_manager_0 = PluginManager()
    if (entry_point_name):
        for entry_point in iter_entry_points(entry_point_name):
            plugin_manager_0.append(entry_point.load())



# Generated at 2022-06-25 19:11:37.114167
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuthPlugin)
    plugin_manager.get_auth_plugin_mapping()
    

# Generated at 2022-06-25 19:11:38.641791
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:41.332717
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    a = plugin_manager_0.get_auth_plugin_mapping()
    assert a != None


# Generated at 2022-06-25 19:11:45.181754
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    assert len(plugin_manager_1) == 0
    plugin_manager_1.load_installed_plugins()
    # The number of plugins after loading installed plugins
    assert len(plugin_manager_1) > 0



# Generated at 2022-06-25 19:11:53.504655
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()

    plugin_class_0 = plugin_manager_1.get_formatters_grouped()
    assert isinstance(plugin_class_0, dict)
    assert isinstance(list(plugin_class_0.keys())[0], str)
    assert isinstance(list(plugin_class_0.values())[0], list)
    assert isinstance(list(plugin_class_0.values())[0][0], type)

# Generated at 2022-06-25 19:11:55.317758
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager


# Generated at 2022-06-25 19:11:59.672083
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    installed_plugins = plugin_manager_1.__repr__()
    # TODO: should be fixed, but the result of __repr__() is arbitrary and may change
    if "Package1" in installed_plugins and "Package2" in installed_plugins:
        pass
    else:
        raise Exception("Test Failed")


# Generated at 2022-06-25 19:12:04.556190
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    result = plugin_manager.get_formatters_grouped()
    assert type(result) == dict
    assert all((
        item in plugin_manager.get_formatters()
        for item in result['Main']
    ))



# Generated at 2022-06-25 19:12:10.201930
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    mapping = plugin_manager_1.get_auth_plugin_mapping()
    print("First mapping: " + str(mapping))
    for k in mapping:
        print("key: " + k)
        print("value: " + str(mapping[k]))
    
    

# Generated at 2022-06-25 19:12:17.606067
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_1.get_formatters_grouped()

# Generated at 2022-06-25 19:12:22.948759
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    df = plugin_manager_1.get_formatters_grouped()
    print(df)
    assert df


# Generated at 2022-06-25 19:12:27.357846
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    '''
    A test case for testing for method get_auth_plugin_mapping of class PluginManager
    '''

    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(BasicAuth, DigestAuth)
    plugin_manager_0.get_auth_plugin_mapping()
    assert plugin_manager_0.get_auth_plugin_mapping() == {'basic': BasicAuth, 'digest': DigestAuth}


# Generated at 2022-06-25 19:12:31.455383
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_load_installed_plugins = PluginManager()
    plugin_manager_load_installed_plugins.load_installed_plugins()
    assert plugin_manager_load_installed_plugins


# Generated at 2022-06-25 19:12:35.903583
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_test = PluginManager()
    class mock_formatter_plugin_1:
        group_name = 'mock_formatter_plugin_1'
    class mock_formatter_plugin_2:
        group_name = 'mock_formatter_plugin_2'
    class mock_formatter_plugin_3(BasePlugin):
        group_name = 'mock_formatter_plugin_1'
    class mock_formatter_plugin_4(BasePlugin):
        group_name = 'mock_formatter_plugin_3'
    class mock_formatter_plugin_5(BasePlugin):
        group_name = 'mock_formatter_plugin_2'

# Generated at 2022-06-25 19:12:43.696838
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.filter() == []


# Generated at 2022-06-25 19:12:45.539287
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.filter(AuthPlugin) == []


# Generated at 2022-06-25 19:12:47.767988
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    print(plugin_manager_1.get_formatters_grouped())


# Generated at 2022-06-25 19:12:53.984772
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Check for empty formatters group
    plugin_manager_1 = PluginManager()
    
    expected_result_1 = {}
    assert plugin_manager_1.get_formatters_grouped() == expected_result_1
    
    # Check for non-empty formatters group
    


# Generated at 2022-06-25 19:12:58.514532
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = []
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugin_manager.register(plugin)
    assert plugin_manager == plugins, "Output mismatch"

# Generated at 2022-06-25 19:13:02.581803
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(test_auth_plugin_0)
    plugin_manager_0.register(test_transport_plugin_0)
    plugin_manager_0.register(test_formatter_plugin_0)
    plugin_manager_0.register(test_converter_plugin_0)
    plugin_manager_0.append(test_auth_plugin_1)
    plugin_manager_0.append(test_transport_plugin_1)
    plugin_manager_0.append(test_formatter_plugin_1)
    plugin_manager_0.append(test_converter_plugin_1)

# Generated at 2022-06-25 19:13:07.348314
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    formatters = plugin_manager_1.get_formatters_grouped()
    assert len(formatters.keys()) > 0
    assert 'Formatted' in formatters.keys()


# Generated at 2022-06-25 19:13:12.912260
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    import httpie.plugins.builtin
    plugin_manager_1.register(httpie.plugins.builtin.BasicAuthPlugin)
    plugin_manager_1.register(httpie.plugins.builtin.DigestAuthPlugin)

    plugin_manager_2 = PluginManager()
    plugin_manager_2.load_installed_plugins()
    assert plugin_manager_1 == plugin_manager_2



# Generated at 2022-06-25 19:13:14.782278
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0



# Generated at 2022-06-25 19:13:16.802175
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager


# Generated at 2022-06-25 19:13:36.335449
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert set(plugin_manager_1.get_formatters_grouped().keys()) == {'default', 'extended'}
    assert 'DefaultFormatter' in [obj.__name__ for obj in plugin_manager_1.get_formatters_grouped()['default']]
    assert 'ExtendedFormatter' in [obj.__name__ for obj in plugin_manager_1.get_formatters_grouped()['extended']]


# Generated at 2022-06-25 19:13:44.272396
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    # If the calling method is filter and the parameter by_type is Type[BasePlugin],
    # then the plugin_manager_1 should return all plugins of type BasePlugin.
    assert issubclass(plugin_manager_1.filter(by_type=Type[BasePlugin])[0], Type[BasePlugin])


# Generated at 2022-06-25 19:13:47.833546
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Create one instance of class PluginManager
    plugin_manager_1 = PluginManager()
    # Load initialized plugins
    plugin_manager_1.load_installed_plugins()
    # Check if the length of plugin list is equal to the expected value
    assert len(plugin_manager_1) == 10


# Generated at 2022-06-25 19:13:52.264817
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_formatters_grouped() == {}


# Generated at 2022-06-25 19:13:57.929259
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    for entry_point in iter_entry_points('httpie.plugins.formatter.v1'):
        plugin_manager_1.register(entry_point.load())
    result = plugin_manager_1.get_formatters_grouped()

# Generated at 2022-06-25 19:13:58.737474
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    

# Generated at 2022-06-25 19:14:01.720991
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    assert type(plugin_manager_0.get_formatters_grouped()) == dict


# Generated at 2022-06-25 19:14:08.561484
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
	plugin_manager_0 = PluginManager()
	assert plugin_manager_0.filter(by_type=Type[BasePlugin]) == []

global PluginManager_instance_0
try:
	PluginManager_instance_0 = PluginManager()
except:
	PluginManager_instance_0 = None
else:
	if type(PluginManager_instance_0) is not PluginManager:
		PluginManager_instance_0 = None


# Generated at 2022-06-25 19:14:11.250464
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

    assert len(plugin_manager_1.get_formatters_grouped()) > 0


# Generated at 2022-06-25 19:14:15.297709
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin)
    assert plugin_manager_0.get_formatters_grouped() == {
        '': [FormatterPlugin, FormatterPlugin]
    }


# Generated at 2022-06-25 19:14:41.670508
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    formatters_grouped_dict = plugin_manager_1.get_formatters_grouped()
    print(formatters_grouped_dict)
    for group_name, group in formatters_grouped_dict.items():
        print('Group name: ', group_name)
        print('List of plugins in this group: ')
        for plugin in group:
            print(plugin)
        #assert type(group) == list
        #assert len(group) >= 1
        #assert len(group) > 0
        print('\n')
    assert len(formatters_grouped_dict) >= 1


# Generated at 2022-06-25 19:14:45.234691
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Initialize plugin_manager with an empty list
    plugin_manager = PluginManager()

    # Load installed plugins for plugin_manager
    plugin_manager.load_installed_plugins()

    # Assert that the list of installed plugins is not empty
    assert len(plugin_manager) > 0

# Generated at 2022-06-25 19:14:49.724088
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert(auth_plugin_mapping)


# Generated at 2022-06-25 19:14:51.863137
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:14:53.896347
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()



# Generated at 2022-06-25 19:14:59.712497
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(AuthPlugin)
    plugin_manager_0.register(AuthPlugin_1)
    plugin_manager_0.register(AuthPlugin_2)
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.register(FormatterPlugin_1)
    plugin_manager_0.register(FormatterPlugin_2)
    plugin_manager_0.register(ConverterPlugin)
    plugin_manager_0.register(ConverterPlugin_1)
    plugin_manager_0.register(ConverterPlugin_2)
    plugin_manager_0.register(TransportPlugin)
    plugin_manager_0.register(TransportPlugin_1)
    plugin_manager_0.register(TransportPlugin_2)
    str_0

# Generated at 2022-06-25 19:15:06.321131
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()

    plugin_manager_1.register(PromptFormatter)
    plugin_manager_1.register(ColorsFormatter)
    plugin_manager_1.register(ColorsFormatter)

    required_output = {'Prompt': [httpie_prompt.PromptFormatter], 'Colors': [httpie_colors.ColorsFormatter, httpie_colors.ColorsFormatter]}

    output_PluginManager_get_formatters_grouped = plugin_manager_1.get_formatters_grouped()
    assert output_PluginManager_get_formatters_grouped == required_output

# Test case for method get_transport_plugins of class PluginManager

# Generated at 2022-06-25 19:15:11.507342
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager
    dict = plugins.get_formatters_grouped()

# Generated at 2022-06-25 19:15:14.757859
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.load_installed_plugins() is None, "Method load_installed_plugins cannot return None if PluginManager.load_installed_plugins returns None"



# Generated at 2022-06-25 19:15:23.324915
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    # plugin_manager_0.load_installed_plugins()
    auth_plugin_mapping = plugin_manager_0.get_auth_plugin_mapping()
    assert 'basic' in auth_plugin_mapping.keys()
    assert 'digest' in auth_plugin_mapping.keys()
    assert 'hawk' in auth_plugin_mapping.keys()
    assert 'oauth1' in auth_plugin_mapping.keys()
    assert 'oauth2' in auth_plugin_mapping.keys()
    assert 'aws4-hmac-sha256' in auth_plugin_mapping.keys()


# Generated at 2022-06-25 19:17:02.601562
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # Test a list with the same type of plugin
    # plugin_type = plugin_manager.get_formatters()[0]
    # plugin_type = plugin_manager.get_transport_plugins()[0]
    #
    # AssertionError: <MagicMock name='FormatterPlugin.group_name'
    # id='140365847447488'> != 'auth'
    plugin_type = plugin_manager.get_auth_plugins()[0]

    expected_result = list()
    expected_result.append(plugin_type)

    result = plugin_manager.filter(by_type=plugin_type)
    assert result == expected_result, "Wrong Result!"

    # Test a list with different type of plugins
    plugin_

# Generated at 2022-06-25 19:17:09.216036
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert issubclass(FormatterPlugin, Type[BasePlugin])
    assert isinstance(plugin_manager_0, PluginManager)
    assert issubclass(plugin_manager_0.filter(FormatterPlugin), list)
    assert len(plugin_manager_0.filter(FormatterPlugin)) == 0


# Generated at 2022-06-25 19:17:10.487280
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:17:11.732010
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 19:17:15.622735
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Testing Iter Plugin Manager
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    assert plugin_manager_0 != 'PluginManager([])'


# Generated at 2022-06-25 19:17:20.693855
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, ConverterPlugin)
    assert issubclass(plugin_manager.filter(AuthPlugin)[0], AuthPlugin)
    assert issubclass(plugin_manager.filter(ConverterPlugin)[0], ConverterPlugin)



# Generated at 2022-06-25 19:17:23.111496
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.filter(by_type=Type[BasePlugin]) == plugin_manager_0
    assert plugin_manager_0.filter(by_type=Type[AuthPlugin]) == []

# Generated at 2022-06-25 19:17:29.469422
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1.get_auth_plugins() != []
    assert plugin_manager_1.get_formatters() != []
    assert plugin_manager_1.get_converters() != []
    assert plugin_manager_1.get_transport_plugins() != []

# Generated at 2022-06-25 19:17:34.434488
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    Object plugin_manager_0s is an instance of PluginManager.
    The method load_installed_plugins is called on object plugin_manager_0
    This method loads all installed plugins and returns nothing.

    @since: 0.14.2
    """
    plugin_manager_0s = PluginManager()
    plugin_manager_0s.load_installed_plugins()


# Generated at 2022-06-25 19:17:35.101224
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager.registe

# Generated at 2022-06-25 19:19:39.674340
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin)
    assert plugin_manager_1.get_auth_plugin_mapping() == {'basic': AuthPlugin}
    plugin_manager_2 = PluginManager()
    plugin_manager_2.register(AuthPlugin)
    assert plugin_manager_2.get_auth_plugin_mapping() == {'basic': AuthPlugin}



# Generated at 2022-06-25 19:19:43.739268
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    fmt_group = plugin_manager_1.get_formatters_grouped()
    assert isinstance(fmt_group, dict)
    assert 'group-name' in fmt_group

test_case_0()
test_PluginManager_get_formatters_grouped()
print("Test for PluginManager: OK")

# Test for class OutputFormatPlugin
# Test case 0

# Generated at 2022-06-25 19:19:46.167985
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    # PluginManager.filter(by_type=Type[BasePlugin])
    try:
        plugin_manager_0.filter(by_type=Type[BasePlugin])
    except AttributeError:
        assert False

# Generated at 2022-06-25 19:19:48.109055
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    p = PluginManager()
    p.example_formatter = lambda: None
    p.example_formatter.group_name = 'test'
    assert p.get_formatters_grouped() == {'test': [p.example_formatter]}

# Generated at 2022-06-25 19:19:50.886068
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()

    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()

# Generated at 2022-06-25 19:19:53.729938
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    # Initialization
    plugin_manager = PluginManager()

    # Method call
    plugin_manager.load_installed_plugins()

    # Test
    assert isinstance(plugin_manager, PluginManager)
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-25 19:19:56.096131
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    print(plugin_manager_0.get_formatters_grouped())


# Generated at 2022-06-25 19:19:57.427751
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


# Generated at 2022-06-25 19:20:03.156043
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    l_no_plugin = []
    l_plugin = [{'digest': {'auth_type': 'digest'}, 'basic': {'auth_type': 'basic'}, 'hawk': {'auth_type': 'hawk'}}]
    expected_d = {'digest': {'auth_type': 'digest'}, 'basic': {'auth_type': 'basic'}, 'hawk': {'auth_type': 'hawk'}}
    actual_d = plugin_manager.get_auth_plugin_mapping("")
    assert actual_d == expected_d

# Generated at 2022-06-25 19:20:06.589310
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert(len(plugin_manager_0.get_formatters_grouped()) > 0)
    assert(isinstance(plugin_manager_0.get_formatters_grouped(), dict))

