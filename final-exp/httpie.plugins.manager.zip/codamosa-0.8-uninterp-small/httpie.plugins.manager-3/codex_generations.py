

# Generated at 2022-06-25 19:10:23.398894
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter, URLEncodedFormatter, XMLEncoder, HTMLFormatter
    from httpie.plugins.builtin import ImageFormatter
    from httpie.plugins import JSONFormatter, FormatterPlugin

    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(ImageFormatter, JSONFormatter, URLEncodedFormatter, XMLEncoder, HTMLFormatter)
    assert isinstance(plugin_manager_0.get_formatters_grouped(), dict)

# Generated at 2022-06-25 19:10:25.424420
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()


plugin_manager = PluginManager()



# Generated at 2022-06-25 19:10:28.215440
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()
    assert dict_0 == {}


# Generated at 2022-06-25 19:10:32.118969
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:10:36.423734
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters_grouped()
    assert 3 == len(formatters)
    assert formatters['Raw Formatter']
    assert formatters['Color Formatter']
    assert formatters['Debug Formatter']

# Generated at 2022-06-25 19:10:39.068143
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    assert(len(plugins) == 0)
    plugins.load_installed_plugins()
    assert(len(plugins) > 0)


# Generated at 2022-06-25 19:10:45.081312
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()

# Generated at 2022-06-25 19:10:49.505115
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    result = plugin_manager.get_formatters_grouped()
    print(result)


if __name__ == '__main__':
    test_case_0()
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-25 19:10:51.904243
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    formatters_grouped = plugin_manager_1.get_formatters_grouped()


# Generated at 2022-06-25 19:10:53.698964
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:11:00.083496
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    with pytest.raises(Exception):
        plugin_manager_0.get_auth_plugin_mapping()


# Generated at 2022-06-25 19:11:05.016137
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(FormatterPlugin)
    plugin_manager_0.get_formatters_grouped()
    test_grouped_formatters = plugin_manager_0.get_formatters_grouped()
    assert test_grouped_formatters == {}


# Generated at 2022-06-25 19:11:12.953321
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    class Plugin1(BasePlugin):
        pass
    class Plugin2(Plugin1):
        pass
    class Plugin3(BasePlugin):
        pass
    class Plugin4(Plugin2):
        pass
    plugin_manager_1.register(Plugin1, Plugin2, Plugin3, Plugin4)
    class PluginType1(BasePlugin):
        pass
    class PluginType2(BasePlugin):
        pass
    class PluginType3(PluginType1):
        pass
    class PluginType4(PluginType2):
        pass
    assert plugin_manager_1.filter(by_type=PluginType1) == [Plugin2, Plugin4]
    assert plugin_manager_1.filter(by_type=PluginType2) == []

# Generated at 2022-06-25 19:11:19.867955
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(StdInPlugin, SocketPlugin)

    formatters = plugin_manager_1.filter(FormatterPlugin)
    assert len(formatters) == 0

    converters = plugin_manager_1.filter(ConverterPlugin)
    assert len(converters) == 0

    transports = plugin_manager_1.filter(TransportPlugin)
    assert len(transports) == 2
    assert StdInPlugin in transports
    assert SocketPlugin in transports



# Generated at 2022-06-25 19:11:22.829963
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:26.784636
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    formatters = [
        {'group_name': 'a'},
        {'group_name': 'b'},
        {'group_name': 'a'},
        {'group_name': 'b'},
    ]
    print(plugin_manager_0.get_formatters_grouped())

# Generated at 2022-06-25 19:11:37.965943
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters import BaseFormatter
    from httpie.output.streams import StdoutStream

    mocked_FormatterPlugin = FormatterPlugin

    class CustomFormatterPlugin0(mocked_FormatterPlugin):
        group_name = 'custom0'
        name = 'custom_formatter0'
        title = 'Custom Formatter 0'
        description = 'Custom Formatter description 0'

        class Formatter(BaseFormatter):
            def __init__(self, **kwargs):
                super().__init__(StdoutStream(**kwargs))

    class CustomFormatterPlugin1(mocked_FormatterPlugin):
        group_name = 'custom1'
        name = 'custom_formatter1'
        title = 'Custom Formatter 1'

# Generated at 2022-06-25 19:11:41.664668
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    plugin_manager_1 = PluginManager()
    plugin_manager_0.register(plugin_manager_1)
    # Unit test for method get_formatters_grouped of class PluginManager
    assert plugin_manager_0.get_formatters_grouped()

# Generated at 2022-06-25 19:11:43.938090
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    loaded_plugins = plugin_manager.load_installed_plugins()
    print(loaded_plugins)



# Generated at 2022-06-25 19:11:45.532509
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:11:55.812975
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    fake_auth_plugin_0 = BasePlugin()
    fake_auth_plugin_1 = BasePlugin()
    plugin_manager_0 = PluginManager()
    if plugin_manager_0.get_auth_plugin_mapping():
        assert False
    else:
        assert True


# Generated at 2022-06-25 19:11:57.540159
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_2 = PluginManager()
    plugin_manager_2.load_installed_plugins()
    plugin_manager_2.get_auth_plugin_mapping()

# Generated at 2022-06-25 19:11:59.149339
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_auth_plugin_mapping() == {}

    return

# Generated at 2022-06-25 19:12:05.550958
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.append(type("FakePlugin", (BasePlugin,), {}))
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 1
    assert type("FakePlugin", (BasePlugin,), {}) in plugin_manager


###

# Generated at 2022-06-25 19:12:15.026396
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    res = plugin_manager_0.filter(AuthPlugin)
    assert res == [httpie.plugins.auth.basic.BasicAuthPlugin, httpie.plugins.auth.digest.DigestAuthPlugin]
    res = plugin_manager_0.filter(ConverterPlugin)
    assert res == [httpie.plugins.converter.json.JSONConverter, httpie.plugins.converter.form.FormConverter]
    res = plugin_manager_0.filter(FormatterPlugin)
    assert res == [httpie.plugins.formatter.colors.ColorsFormatter, httpie.plugins.formatter.format.FormatFormatter, httpie.plugins.formatter.pretty.PrettyFormatter]

# Generated at 2022-06-25 19:12:17.134173
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    class_0 = plugin_manager_0.filter()
    assert class_0 == []

# Generated at 2022-06-25 19:12:18.572434
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:12:24.373398
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    assert plugin_manager_1.get_auth_plugin_mapping() == {}
    plugin_manager_1.load_installed_plugins()
    assert plugin_manager_1.get_auth_plugin_mapping() != {}


# Generated at 2022-06-25 19:12:26.610785
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {}

# Generated at 2022-06-25 19:12:35.870509
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    class AuthPlugin_1(AuthPlugin):
        auth_type = 'auth_type_1'
    
    class FormatterPlugin_1(FormatterPlugin): pass
    
    class ConverterPlugin_1(ConverterPlugin): pass
    
    class TransportPlugin_1(TransportPlugin): pass
    
    class FormatterPlugin_2(FormatterPlugin): pass
    
    class TransportPlugin_2(TransportPlugin): pass
    plugin_manager_1.register(AuthPlugin_1, FormatterPlugin_1, ConverterPlugin_1, TransportPlugin_1, FormatterPlugin_2, TransportPlugin_2)

    

# Generated at 2022-06-25 19:12:59.708010
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    # Load installed plugins via entrypoint(s)
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    plugin_manager_1

    assert 'httpie.plugins.auth.aws' in [
        plugin.package_name for plugin in plugin_manager_1
    ]
    assert 'httpie.plugins.auth.jwt' in [
        plugin.package_name for plugin in plugin_manager_1
    ]
    assert 'httpie.plugins.auth.aws' in [
        plugin.package_name for plugin in plugin_manager_1
    ]
    assert 'httpie.plugins.auth.aws_sigv4' in [
        plugin.package_name for plugin in plugin_manager_1
    ]

# Generated at 2022-06-25 19:13:02.992597
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    result = plugin_manager_0.get_formatters_grouped()
    assert result == {}


# Generated at 2022-06-25 19:13:09.576642
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Base:
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    class C(object):
        pass

    a = A()
    b = B()
    c = C()
    plugin_list = PluginManager()
    plugin_list.register(a, b, c)
    assert plugin_list.filter(Base) == [a, b]


# Generated at 2022-06-25 19:13:15.118861
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    if ENTRY_POINT_NAMES[0] in list(plugin_manager_1):
        plugin_manager_1.load_installed_plugins()
    else:
        assert False


# Generated at 2022-06-25 19:13:18.799320
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(plugin=AuthPlugin)

    plugin_manager_1.load_installed_plugins()

    assert type(plugin_manager_1) is PluginManager
    assert len(plugin_manager_1) > 0


# Generated at 2022-06-25 19:13:20.128141
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_0 = PluginManager()
    print(plugin_manager_0.get_formatters_grouped())

# Generated at 2022-06-25 19:13:21.639060
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    print(plugin_manager_1.filter(TransportPlugin))


# Generated at 2022-06-25 19:13:24.660267
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_list = plugin_manager.filter()
    assert type(plugin_list) == list



# Generated at 2022-06-25 19:13:31.560879
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    print("test for method get_auth_plugin_mapping of class PluginManager")
    

# Generated at 2022-06-25 19:13:37.665522
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    print('TEST: test_PluginManager_get_formatters_grouped')
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    formatters_grouped = plugin_manager_0.get_formatters_grouped()
    assert formatters_grouped is not None
    assert len(formatters_grouped) == 1
    assert formatters_grouped['default'] is not None
    assert len(formatters_grouped['default']) == 7

# Generated at 2022-06-25 19:14:07.079758
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(BasePlugin, BasePlugin)
    assert pm.filter(BasePlugin) == [BasePlugin, BasePlugin]


# Generated at 2022-06-25 19:14:09.439263
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:18.435421
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    """
    max_count = 0
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            max_count = max_count + 1
    print("max_count", max_count)
    assert max_count >= len(plugin_manager_1)
    """
    # check installed plugins are some of httpie plugins
    plugin_manager_2 = PluginManager()
    httpie_plugins = [BasePlugin, AuthPlugin, ConverterPlugin, FormatterPlugin]
    for plugin in plugin_manager_1:
        assert any([issubclass(plugin, httpie_plugin) for httpie_plugin in httpie_plugins])


    #

# Generated at 2022-06-25 19:14:23.639538
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Given
    plugin_manager = PluginManager()
    plugin_manager.register(DictFormatterPlugin)
    plugin_manager.register(JsonFormatterPlugin)

    # When
    formatters_grouped = plugin_manager.get_formatters_grouped()

    # Then
    assert formatters_grouped == {
        'json': [JsonFormatterPlugin],
        'dict': [DictFormatterPlugin]
    }



# Generated at 2022-06-25 19:14:25.732349
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-25 19:14:35.265781
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(test_plugin_0,test_plugin_1)
    plugin_manager_1_test1=plugin_manager_1.filter(BasePlugin)
    plugin_manager_1_test2=plugin_manager_1.filter(AuthPlugin)
    assert test_plugin_0 not in plugin_manager_1_test2
    assert test_plugin_1 not in plugin_manager_1_test2
    assert test_plugin_0 in plugin_manager_1_test1
    assert test_plugin_1 in plugin_manager_1_test1


# Generated at 2022-06-25 19:14:36.901279
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:14:37.687225
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()

# Generated at 2022-06-25 19:14:42.244339
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert len(plugin_manager_1) > 0



# Generated at 2022-06-25 19:14:47.390155
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_0 = PluginManager()
    dict_0 = plugin_manager_0.get_auth_plugin_mapping()
    assert_equal(len(dict_0), 0)
    assert_equal(type(dict_0), dict)


# Generated at 2022-06-25 19:15:50.658162
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    # Negative inputs
    try:
        plugin_manager_0.filter(by_type=str())
    except:
        return
    # Positive inputs
    plugin_manager_0.load_installed_plugins()
    assert isinstance(plugin_manager_0.filter(by_type=AuthPlugin), list)
    assert plugin_manager_0.filter(by_type=AuthPlugin)
    assert isinstance(plugin_manager_0.filter(by_type=FormatterPlugin), list)
    assert plugin_manager_0.filter(by_type=FormatterPlugin)
    assert isinstance(plugin_manager_0.filter(by_type=ConverterPlugin), list)
    assert plugin_manager_0.filter(by_type=ConverterPlugin)

# Generated at 2022-06-25 19:15:57.467129
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    plugin_manager_0 = PluginManager()
    assert plugin_manager_0.get_auth_plugin_mapping() == {}

    plugin_manager_0.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

    expected_dict = {
        base_plugin.auth_type: base_plugin
        for base_plugin in plugin_manager_0.get_auth_plugins()
    }

    assert plugin_manager_0.get_auth_plugin_mapping() == expected_dict



# Generated at 2022-06-25 19:16:00.361941
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
	plugin_manager = PluginManager()
	plugin_manager.load_installed_plugins()
	plugin_manager.get_formatters_grouped()


# Generated at 2022-06-25 19:16:04.441805
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """Test for the get_formatters_grouped(self) method"""
    plugin_manager_0 = PluginManager()
    result_0 = plugin_manager_0.get_formatters_grouped()

    assert isinstance(result_0, dict)
    assert result_0 == {}
    assert len(result_0) == 0


# Generated at 2022-06-25 19:16:05.944590
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert filter(lambda plugin: issubclass(plugin, AuthPlugin) == True, list) == True

# Generated at 2022-06-25 19:16:11.562561
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Arrange
    plugins = []
    # An auth plugin
    class FakeAuthPlugin(AuthPlugin):
        auth_type = 'fakeAuth'
    plugins.append(FakeAuthPlugin)
    # A formatter plugin
    class FakeFormatterPlugin(FormatterPlugin):
        group_name = 'fakeGroup'
    plugins.append(FakeFormatterPlugin)
    # A converter plugin
    class FakeConverterPlugin(ConverterPlugin):
        pass
    plugins.append(FakeConverterPlugin)
    # A transport plugin
    class FakeTransportPlugin(TransportPlugin):
        pass
    plugins.append(FakeTransportPlugin)
    # A request plugin
    class FakeRequestPlugin(TransportPlugin):
        pass
    plugins.append(FakeRequestPlugin)

    # Act
    plugin_manager_0 = PluginManager()
   

# Generated at 2022-06-25 19:16:20.214899
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()

    # test for when by_type = None
    assert plugin_manager_0.filter() == []

    # test for when by_type = Type[BasePlugin]
    assert plugin_manager_0.filter(by_type=Type[BasePlugin]) == []
    plugin_manager_0.register(BasePlugin)
    assert plugin_manager_0.filter(by_type=Type[BasePlugin]) == [BasePlugin]
    plugin_manager_0.register(BasePlugin)
    assert plugin_manager_0.filter(by_type=Type[BasePlugin]) == [BasePlugin, BasePlugin]


# Generated at 2022-06-25 19:16:21.708268
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()


# Generated at 2022-06-25 19:16:24.664499
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_case_1 = copy.copy(plugin_manager_0)
    test_case_1.register(AuthPlugin)
    assert test_case_1.get_auth_plugin_mapping() == {
        'basic': AuthPlugin
    }


# Generated at 2022-06-25 19:16:26.995771
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin, ConverterPlugin)

    c_list = plugin_manager_1.filter(by_type=ConverterPlugin)
    assert c_list == [ConverterPlugin]

# Generated at 2022-06-25 19:18:29.545759
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()



# Generated at 2022-06-25 19:18:35.212854
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager_1 = PluginManager()
    plug_in_1 = FormatterPlugin()
    plug_in_2 = FormatterPlugin()
    plugin_manager_1.register(plug_in_1, plug_in_2)
    group_keys = plugin_manager_1.get_formatters_grouped().keys()
    assert 'default' in group_keys


# Generated at 2022-06-25 19:18:36.205649
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-25 19:18:38.495114
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    Unit test for method load_installed_plugins of class PluginManager
    """
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_transport_plugins()) == 1

# Generated at 2022-06-25 19:18:45.856748
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    print("\n..Test:: test_PluginManager_get_formatters_grouped()")
    # initialize class instance
    plugin_manager_0 = PluginManager()
    plugin_manager_0.load_installed_plugins()
    print("\n..Input:: \n\tplugin_manager_0.get_formatters_grouped()")
    # class method
    rst = plugin_manager_0.get_formatters_grouped()
    # check class method returns the proper type
    print("\n..Check:: \n\tassert type(rst) == dict")
    assert type(rst) == dict
    # test if class method returns the desired output
    print("\n..Output:: \n\t{}".format(rst))

test_case_0()
test_PluginManager_get_formatters_group

# Generated at 2022-06-25 19:18:48.929189
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(ContentTypeConverter, TestFormatter)
    class_type = Type[BasePlugin]
    plugin_manager_0.filter(class_type)


# Generated at 2022-06-25 19:18:54.060923
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped(): 
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(PseudoFormatterPlugin)

# Generated at 2022-06-25 19:18:58.161975
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_1 = PluginManager()
    plugin_manager_1.load_installed_plugins()
    assert isinstance(plugin_manager_1.get_auth_plugin_mapping(), dict)


# Generated at 2022-06-25 19:19:05.738114
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    del plugin_manager_0
    plugin_manager_0 = PluginManager()
    plugin_manager_0.register(TestFormatterPlugin_0)
    plugin_manager_0.register(TestFormatterPlugin_1)
    plugin_manager_0.register(TestFormatterPlugin_2)
    expected_0 = {'group_name_0': [TestFormatterPlugin_0,
                                   TestFormatterPlugin_1],
                  'group_name_1': [TestFormatterPlugin_2]}
    assert plugin_manager_0.get_formatters_grouped() == expected_0
    plugin_manager_0.register(TestFormatterPlugin_3)

# Generated at 2022-06-25 19:19:07.836053
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(SimpleAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {
        'simple': SimpleAuthPlugin
    }
