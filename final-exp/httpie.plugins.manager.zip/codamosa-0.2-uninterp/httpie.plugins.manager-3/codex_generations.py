

# Generated at 2022-06-17 21:06:39.978391
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import DevNullFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin

# Generated at 2022-06-17 21:06:42.415809
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:06:52.581889
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D:
        pass

    class E(D):
        pass

    class F(D):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(A, B, C, D, E, F)
    assert plugin_manager.filter(A) == [A, B, C]
    assert plugin_manager.filter(D) == [D, E, F]
    assert plugin_manager.filter(E) == [E]
    assert plugin_manager.filter(F) == [F]
    assert plugin_manager.filter(B) == [B]
    assert plugin_manager.filter(C) == [C]
    assert plugin_manager.filter(Type) == []

# Unit

# Generated at 2022-06-17 21:06:54.187837
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:04.500567
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import HTTPFormatterPlugin, PrettyHTTPFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin
    from httpie.plugins.builtin import CookiesFormatterPlugin
    from httpie.plugins.builtin import FileUploadFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin

# Generated at 2022-06-17 21:07:08.728558
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:07:11.010222
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:16.395239
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D:
        pass

    class E(D):
        pass

    class F(D):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E, F)
    assert pm.filter(A) == [A, B, C]
    assert pm.filter(D) == [D, E, F]

# Generated at 2022-06-17 21:07:21.340601
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:07:30.654207
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
        'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin,
        'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin,
    }

# Generated at 2022-06-17 21:07:41.002651
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(E):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass

   

# Generated at 2022-06-17 21:07:51.632771
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class A(FormatterPlugin):
        group_name = 'a'
    class B(FormatterPlugin):
        group_name = 'b'
    class C(FormatterPlugin):
        group_name = 'a'
    class D(FormatterPlugin):
        group_name = 'b'
    class E(FormatterPlugin):
        group_name = 'a'
    class F(FormatterPlugin):
        group_name = 'b'
    class G(FormatterPlugin):
        group_name = 'a'
    class H(FormatterPlugin):
        group_name = 'b'
    class I(FormatterPlugin):
        group_name = 'a'
    class J(FormatterPlugin):
        group_name = 'b'

# Generated at 2022-06-17 21:08:01.684739
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPNTLMAuth, HTTPNegotiateAuth
    from httpie.plugins.builtin import JSONConverter, URLEncodedFormConverter
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter, URLEncodedFormFormatter
    from httpie.plugins.builtin import HTTPieTransport
    from httpie.plugins.manager import PluginManager
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPBearerAuth, HTTPNTLMAuth, HTTPNegotiateAuth)

# Generated at 2022-06-17 21:08:03.447912
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:08:13.192987
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:08:15.848773
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:08:17.357107
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0


# Generated at 2022-06-17 21:08:28.556654
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import ImageFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import URLEncodedConverter
    from httpie.plugins.builtin import KeyValueConverter
    from httpie.plugins.builtin import ImageConverter
    from httpie.plugins.builtin import HTMLConverter

# Generated at 2022-06-17 21:08:35.825451
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:08:38.698888
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:45.119055
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:48.011810
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:01.558929
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    from httpie.plugins.builtin import PrettyJSONFormatter, PrettyURLEncodedFormatter
    from httpie.plugins.builtin import HTTPieTransport
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPTokenAuth, JSONConverter, URLEncodedConverter, PrettyJSONFormatter, PrettyURLEncodedFormatter, HTTPieTransport)
    assert plugin_manager.filter(AuthPlugin) == [HTTPBasicAuth, HTTPTokenAuth]

# Generated at 2022-06-17 21:09:13.338638
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, StreamFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin, VerboseFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, AutoJSONFormatterPlugin
    from httpie.plugins.builtin import OneLineFormatterPlugin, ColoredJSONFormatterPlugin
    from httpie.plugins.builtin import ColoredStreamFormatterPlugin, ColoredAutoJSONForm

# Generated at 2022-06-17 21:09:15.321423
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:18.158725
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:27.685977
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:09:37.963356
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:09:45.940253
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class Plugin1(FormatterPlugin):
        group_name = 'group1'
    class Plugin2(FormatterPlugin):
        group_name = 'group2'
    class Plugin3(FormatterPlugin):
        group_name = 'group1'
    class Plugin4(FormatterPlugin):
        group_name = 'group2'
    class Plugin5(FormatterPlugin):
        group_name = 'group1'
    class Plugin6(FormatterPlugin):
        group_name = 'group2'
    class Plugin7(FormatterPlugin):
        group_name = 'group1'
    class Plugin8(FormatterPlugin):
        group_name = 'group2'
    class Plugin9(FormatterPlugin):
        group_name = 'group1'

# Generated at 2022-06-17 21:09:51.412713
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'
        group_info = 'test'
        group_order = 1
        type = 'test'
        info = 'test'
        order = 1
    plugin_manager = PluginManager()
    plugin_manager.register(TestFormatterPlugin)
    assert plugin_manager.get_formatters_grouped() == {'test': [TestFormatterPlugin]}

# Generated at 2022-06-17 21:10:09.413350
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import JUnitXMLFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import JSONLinesPrettyFormatterPlugin

# Generated at 2022-06-17 21:10:20.139301
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import HTTPieArgumentParser
    from httpie.plugins.builtin import HTTPieRequest
    from httpie.plugins.builtin import HTTPieResponse
    from httpie.plugins.builtin import HTTPieStream

# Generated at 2022-06-17 21:10:22.291485
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:32.412302
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'
        group_title = 'Test'
        group_order = 1
    class TestFormatterPlugin2(FormatterPlugin):
        group_name = 'test'
        group_title = 'Test'
        group_order = 2
    class TestFormatterPlugin3(FormatterPlugin):
        group_name = 'test2'
        group_title = 'Test2'
        group_order = 1
    class TestFormatterPlugin4(FormatterPlugin):
        group_name = 'test2'
        group

# Generated at 2022-06-17 21:10:33.781687
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:41.427802
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:10:47.995157
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 5
    assert plugin_manager[0].__name__ == 'HTTPBasicAuth'
    assert plugin_manager[1].__name__ == 'HTTPDigestAuth'
    assert plugin_manager[2].__name__ == 'JSONFormatter'
    assert plugin_manager[3].__name__ == 'JSONConverter'
    assert plugin_manager[4].__name__ == 'HTTPieHTTPAdapter'


# Generated at 2022-06-17 21:11:00.441164
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth, HTTPNTLMAuth, HTTPDigestAuth, HTTPAWSAuth, HTTPProxyAuth, HTTPAuthPlugin, HTTPCookieAuth, HTTPFileAuth, HTTPPassAuth, HTTPDigestAuth, HTTPOAuth1Auth, HTTPOAuth2Auth, HTTPOAuth2ImplicitGrantAuth, HTTPOAuth2PasswordAuth, HTTPOAuth2ClientCredentialsAuth, HTTPOAuth2AuthorizationCodeAuth, HTTPOAuth2DeviceAuth, HTTPOAuth2RefreshTokenAuth, HTTPOAuth2JWTAuth, HTTPOAuth2OpenIDConnectAuth, HTTPOAuth

# Generated at 2022-06-17 21:11:11.654780
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, HTMLFormatterPlugin, \
        ImageFormatterPlugin, StreamFormatterPlugin, DefaultFormatterPlugin
    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin,
                            RawJSONFormatterPlugin, HTMLFormatterPlugin, ImageFormatterPlugin,
                            StreamFormatterPlugin, DefaultFormatterPlugin)

# Generated at 2022-06-17 21:11:15.762001
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:11:48.576187
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:12:01.429329
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin
    from httpie.plugins.builtin import JSONConverterPlugin, URLEncodedConverterPlugin
    from httpie.plugins.builtin import HTTPiePlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyJSONFormatterPlugin,
                            URLEncodedFormatterPlugin, JSONConverterPlugin,
                            URLEncodedConverterPlugin, HTTPiePlugin)

# Generated at 2022-06-17 21:12:03.125401
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:13.228909
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:12:21.816489
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJsonFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, JSONLinesFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin, ImageFormatterPlugin, HtmlFormatterPlugin
    from httpie.plugins.builtin import JsonLinesLinesFormatterPlugin, JsonLinesTableFormatterPlugin
    from httpie.plugins.builtin import JsonLinesPygmentsFormatterPlugin, JsonLinesImageFormatterPlugin
    from httpie.plugins.builtin import JsonLinesHtmlFormatterPlugin, JsonLinesRawFormatterPlugin
    from httpie.plugins.builtin import JsonLinesJson

# Generated at 2022-06-17 21:12:29.911832
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, JSONLinesFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, StreamFormatterPlugin, DevNullFormatterPlugin
    from httpie.plugins.builtin import DefaultFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, RedirectFormatterPlugin, CookiesFormatterPlugin
    from httpie.plugins.builtin import FileUploadFormatterPlugin, FileDownloadFormatterPlugin
    from httpie.plugins.builtin import LegacyFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:12:31.833486
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:42.676388
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin, \
        StreamFormatterPlugin, JSONStreamFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, \
        ColoredJSONFormatterPlugin, ColoredStreamFormatterPlugin, \
        ColoredURLEncodedFormatterPlugin, ColoredRawJSONFormatterPlugin, \
        TableFormatterPlugin, ColoredTableFormatterPlugin
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:12:44.342574
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:45.884076
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:13:21.969730
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:13:31.647881
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:13:34.004432
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:13:37.951157
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:13:39.374964
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:13:40.563136
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:13:45.130122
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PygmentsFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, StreamFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, JSONLinesPrettyFormatterPlugin
    from httpie.plugins.builtin import JSONLinesRawFormatterPlugin, JSONLinesStreamFormatterPlugin

# Generated at 2022-06-17 21:13:48.716171
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:14:01.901189
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, JSONLinesFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, StreamFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, HTMLPageFormatterPlugin, HTMLTableFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin
    from httpie.plugins.builtin import MarkdownFormatterPlugin
    from httpie.plugins.builtin import JUnitXMLFormatterPlugin
    from httpie.plugins.builtin import HarFormatterPlugin
    from httpie.plugins.builtin import XmlFormatterPlugin

# Generated at 2022-06-17 21:14:04.712485
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:15:29.158341
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:15:39.895247
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:15:41.194020
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:15:50.460863
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'jwt': httpie.plugins.auth.jwt.JWTAuthPlugin,
        'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin,
        'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin,
    }

# Generated at 2022-06-17 21:16:00.686722
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import XMLEncoderPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin
    from httpie.plugins.builtin import XMLTreeFormatterPlugin
    pm = PluginManager()
    pm.register(JSONFormatterPlugin, PrettyFormatterPlugin, RawJSONFormatterPlugin, StreamFormatterPlugin, TableFormatterPlugin, URLEncodedFormatterPlugin, XMLEncoderPlugin, XMLFormatterPlugin, XMLTreeFormatterPlugin)

# Generated at 2022-06-17 21:16:07.928807
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:16:13.093547
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:16:18.979436
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert plugin_manager.get_auth_plugin_mapping()
    assert plugin_manager.get_formatters_grouped()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

# Generated at 2022-06-17 21:16:23.292174
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:16:33.311762
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['basic'] == BasicAuthPlugin
    assert auth_plugin_mapping['digest'] == DigestAuthPlugin
    assert auth_plugin_mapping['hawk'] == HawkAuthPlugin
    assert auth_plugin_mapping['ntlm'] == NTLMAuthPlugin
    assert auth_plugin_mapping['oauth1'] == OAuth1AuthPlugin
    assert auth_plugin_mapping['oauth2'] == OAuth2AuthPlugin
    assert auth_plugin_mapping['jwt'] == JWTAuthPlugin