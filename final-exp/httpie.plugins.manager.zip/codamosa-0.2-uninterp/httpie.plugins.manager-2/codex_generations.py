

# Generated at 2022-06-17 21:06:38.956916
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': AuthPlugin,
        'digest': AuthPlugin,
        'hawk': AuthPlugin,
        'ntlm': AuthPlugin,
        'oauth1': AuthPlugin,
        'oauth2': AuthPlugin,
    }


# Generated at 2022-06-17 21:06:44.828850
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(D): pass

    pm = PluginManager()
    pm.register(A, B, C, D, E)

    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:06:56.718390
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:07:00.209852
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:08.358246
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPNTLMAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import RawJsonFormatter
    from httpie.plugins.builtin import URLEncodedFormatter


# Generated at 2022-06-17 21:07:11.770892
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:07:20.232298
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:07:31.310190
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import PrettyHTMLFormatterPlugin
    from httpie.plugins.builtin import RawHTMLFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
   

# Generated at 2022-06-17 21:07:34.542508
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'auth': AuthPlugin}


# Generated at 2022-06-17 21:07:40.563500
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:07:47.797012
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) > 0
    assert len(plugins.get_auth_plugins()) > 0
    assert len(plugins.get_formatters()) > 0
    assert len(plugins.get_converters()) > 0
    assert len(plugins.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:07:53.744513
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert plugin_manager[0].__class__.__name__ == 'BasicAuthPlugin'


# Generated at 2022-06-17 21:08:02.199940
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import RawJsonFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:08:03.696492
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0

# Generated at 2022-06-17 21:08:07.147333
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'auth': AuthPlugin}


# Generated at 2022-06-17 21:08:13.801798
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(BasePlugin):
        pass
    class Plugin4(Plugin1):
        pass
    class Plugin5(Plugin2):
        pass
    class Plugin6(Plugin3):
        pass
    class Plugin7(Plugin4):
        pass
    class Plugin8(Plugin5):
        pass
    class Plugin9(Plugin6):
        pass
    class Plugin10(Plugin7):
        pass
    class Plugin11(Plugin8):
        pass
    class Plugin12(Plugin9):
        pass
    class Plugin13(Plugin10):
        pass
    class Plugin14(Plugin11):
        pass
    class Plugin15(Plugin12):
        pass
    class Plugin16(Plugin13):
        pass

# Generated at 2022-06-17 21:08:17.937004
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert len(pm.get_auth_plugins()) > 0
    assert len(pm.get_formatters()) > 0
    assert len(pm.get_converters()) > 0
    assert len(pm.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:08:29.280675
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    class G(C):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(E):
        pass

    class K(E):
        pass

    class L(F):
        pass

    class M(F):
        pass

    class N(G):
        pass

    class O(G):
        pass

    class P(H):
        pass

    class Q(H):
        pass

    class R(I):
        pass

    class S(I):
        pass

    class T(J):
        pass

   

# Generated at 2022-06-17 21:08:36.191954
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import OneLinerFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin

# Generated at 2022-06-17 21:08:43.457096
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-17 21:08:59.174958
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:09:05.097307
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': httpie.plugins.auth.basic_auth.BasicAuthPlugin, 'digest': httpie.plugins.auth.digest_auth.DigestAuthPlugin, 'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin, 'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin, 'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin, 'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin}

# Generated at 2022-06-17 21:09:08.085967
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:09:19.038856
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:09:28.253680
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:09:38.625570
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E:
        pass

    class F(E):
        pass

    class G(E):
        pass

    class H(F, G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass

# Generated at 2022-06-17 21:09:40.625813
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:47.550787
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedConverter
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieTransportPlugin
    from httpie.plugins.builtin import HTTPieTransportPlugin
    from httpie.plugins.builtin import HTTPieTransportPlugin
    from httpie.plugins.builtin import HTTPieTransportPlugin

# Generated at 2022-06-17 21:09:59.635409
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:10:08.825665
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:17.815309
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:23.138725
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:10:26.981029
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-17 21:10:29.654574
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:31.735546
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:33.779131
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:41.427432
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:10:50.375533
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:10:53.535375
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:11:02.062734
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E, F)

    assert pm.filter(A) == [A, B, C, D, E, F]
    assert pm.filter(B) == [B, D, F]
    assert pm.filter(C) == [C, E, F]
    assert pm.filter(D) == [D, F]
    assert pm.filter(E) == [E, F]
    assert pm.filter(F) == [F]

# Generated at 2022-06-17 21:11:18.197594
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:28.944314
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:11:37.043130
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:11:38.777176
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:11:40.392017
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:45.253970
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:11:53.594469
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:12:00.795814
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:12:02.715332
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:04.183172
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:40.104331
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:12:47.676830
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-17 21:13:00.065858
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:13:05.259997
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:13:15.998830
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth
    from httpie.plugins.builtin import HTTPiePlugin, JSONPlugin
    from httpie.plugins.builtin import PrettyJSONPlugin, PrettyPlugin
    from httpie.plugins.builtin import URLEncodedPlugin, XMLPlugin
    from httpie.plugins.builtin import HTTPieTransport
    from httpie.plugins.manager import PluginManager
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPBearerAuth, HTTPiePlugin, JSONPlugin, PrettyJSONPlugin, PrettyPlugin, URLEncodedPlugin, XMLPlugin, HTTPieTransport)

# Generated at 2022-06-17 21:13:26.431749
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-17 21:13:35.754916
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins

# Generated at 2022-06-17 21:13:45.678521
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin
    from httpie.plugins.builtin import SolarizedFormatterPlugin
    from httpie.plugins.builtin import OneDarkFormatterPlugin
    from httpie.plugins.builtin import MonokaiFormatterPlugin

# Generated at 2022-06-17 21:13:53.427545
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:13:56.874220
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:15:21.559443
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:15:24.499619
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:30.369374
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E:
        pass
    class F(E):
        pass
    class G(E):
        pass
    class H(F, G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:15:40.464548
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:15:50.403335
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AssertJSONFormatterPlugin
    from httpie.plugins.builtin import AssertURLEncodedFormatterPlugin

# Generated at 2022-06-17 21:15:56.716039
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:15:59.984804
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    assert plugin_manager.get_formatters_grouped() == {'FormatterPlugin': [FormatterPlugin, FormatterPlugin, FormatterPlugin]}

# Generated at 2022-06-17 21:16:09.263569
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:16:14.026285
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.hawk import HawkAuthPlugin
    from httpie.plugins.auth.ntlm import NTLMAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1AuthPlugin
    from httpie.plugins.auth.oauth2 import OAuth2AuthPlugin
    from httpie.plugins.auth.aws import AWSAuthPlugin
    from httpie.plugins.auth.aws_s3 import AWSS3AuthPlugin
    from httpie.plugins.auth.aws_sigv4 import AWSSigv4AuthPlugin
    from httpie.plugins.auth.aws_sigv4_header import AWSSigv4HeaderAuthPlugin

# Generated at 2022-06-17 21:16:16.539804
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
