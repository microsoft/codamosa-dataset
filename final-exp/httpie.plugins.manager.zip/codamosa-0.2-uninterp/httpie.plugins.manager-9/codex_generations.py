

# Generated at 2022-06-17 21:06:40.415628
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    class PluginD(PluginB):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB, PluginC, PluginD)

    assert plugin_manager.filter(PluginA) == [PluginA, PluginC]
    assert plugin_manager.filter(PluginB) == [PluginB, PluginD]
    assert plugin_manager.filter(BasePlugin) == [PluginA, PluginB, PluginC, PluginD]

# Generated at 2022-06-17 21:06:45.432055
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin, DigestAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin,
    }

# Generated at 2022-06-17 21:06:46.735147
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:06:50.028859
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:06:51.756516
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:01.201561
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import AssertJSONFormatterPlugin, AssertXMLFormatterPlugin
    from httpie.plugins.builtin import AssertHTMLFormatterPlugin, AssertHeadersFormatterPlugin
    from httpie.plugins.builtin import AssertURLEncodedFormatterPlugin, AssertTableFormatterPlugin
    from httpie.plugins.builtin import AssertRawJSONFormatterPlugin, AssertJSONStreamFormatterPlugin

# Generated at 2022-06-17 21:07:08.877011
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D:
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(B, C, E, F):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E, F, G)
    assert pm.filter(A) == [A, B, C, G]
    assert pm.filter(D) == [D, E, F, G]
    assert pm.filter(B) == [B, G]
    assert pm.filter(E) == [E, G]
    assert pm.filter(G) == [G]

# Generated at 2022-06-17 21:07:18.166101
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import HTTPieArgumentParser
    from httpie.plugins.builtin import HTTPieRequest
    from httpie.plugins.builtin import HTTPieResponse
    from httpie.plugins.builtin import HTTPieStream

# Generated at 2022-06-17 21:07:29.460382
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:07:37.620511
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Arrange
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    # Act
    auth_plugins = plugin_manager.filter(AuthPlugin)
    converter_plugins = plugin_manager.filter(ConverterPlugin)
    formatter_plugins = plugin_manager.filter(FormatterPlugin)
    transport_plugins = plugin_manager.filter(TransportPlugin)
    # Assert
    assert len(auth_plugins) == 1
    assert len(converter_plugins) == 1
    assert len(formatter_plugins) == 1
    assert len(transport_plugins) == 1


# Generated at 2022-06-17 21:07:43.692401
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:07:46.527376
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:54.762205
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:08:05.232955
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import RawJSONPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import ZeroClipboardPlugin
    from httpie.plugins.builtin import ZeroMQPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONPlugin
    from httpie.plugins.builtin import FileUploadPlugin
    from httpie.plugins.builtin import MultipartFormDataPlugin
    from httpie.plugins.builtin import PrettyJSONPlugin


# Generated at 2022-06-17 21:08:12.112789
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-17 21:08:20.323820
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin,
                            JSONStreamFormatterPlugin,
                            RawJSONFormatterPlugin,
                            StreamFormatterPlugin,
                            TableFormatterPlugin,
                            URLEncodedFormatterPlugin,
                            PrettyOptionsPlugin)


# Generated at 2022-06-17 21:08:21.890003
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:32.720500
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:08:41.944355
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F:
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:08:49.216396
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:09:03.703002
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped['json'] == [
        httpie.plugins.formatter.json.JSONFormatter,
        httpie.plugins.formatter.json.JSONLinesFormatter,
    ]
    assert formatters_grouped['colors'] == [
        httpie.plugins.formatter.colors.ColoredFormatter,
    ]
    assert formatters_grouped['formatting'] == [
        httpie.plugins.formatter.formatting.FormattedFormatter,
    ]

# Generated at 2022-06-17 21:09:05.714424
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:17.384530
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBasic

# Generated at 2022-06-17 21:09:19.692968
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:09:28.671831
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, HeadersFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin, ImageFormatterPlugin
    from httpie.plugins.builtin import JUnitFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin, JSONLinesFormatterPlugin
    from httpie.plugins.builtin import FormFormatterPlugin, JsonLinesStreamFormatterPlugin
    from httpie.plugins.builtin import JsonStreamFormatterPlugin, JsonLinesFormatter

# Generated at 2022-06-17 21:09:39.148987
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:09:46.740985
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin

# Generated at 2022-06-17 21:09:51.453146
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert pm.filter(AuthPlugin) == [AuthPlugin]
    assert pm.filter(ConverterPlugin) == [ConverterPlugin]
    assert pm.filter(FormatterPlugin) == [FormatterPlugin]
    assert pm.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-17 21:10:01.908159
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:03.715884
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

# Generated at 2022-06-17 21:10:21.643358
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D, E): pass
    class G(F): pass
    class H(G): pass
    class I(H): pass
    class J(I): pass
    class K(J): pass
    class L(K): pass
    class M(L): pass
    class N(M): pass
    class O(N): pass
    class P(O): pass
    class Q(P): pass
    class R(Q): pass
    class S(R): pass
    class T(S): pass
    class U(T): pass
    class V(U): pass
    class W(V): pass
    class X(W): pass
    class Y(X): pass

# Generated at 2022-06-17 21:10:23.546397
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:10:25.466396
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:35.219087
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass

   

# Generated at 2022-06-17 21:10:37.164236
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'auth': AuthPlugin}

# Generated at 2022-06-17 21:10:38.763186
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:48.918526
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, DefaultHeadersFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, DefaultFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, ImageFormatterPlugin
    from httpie.plugins.builtin import ColoredStreamFormatterPlugin, ColoredFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, DefaultTableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin, PygmentsHTTPieFormatter

# Generated at 2022-06-17 21:10:57.782238
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:59.193649
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:03.387425
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:11:25.592732
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:11:27.644990
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:29.615336
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:11:35.068222
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:11:42.729385
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, JSONLinesFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, ColoredJSONFormatterPlugin
    from httpie.plugins.builtin import ColoredTableFormatterPlugin, ColoredURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, ColoredHeadersFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, ColoredStreamFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, ColoredImageFormatterPlugin

# Generated at 2022-06-17 21:11:52.976555
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import KeyValueConverter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonConverter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawJSONConverter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedConverter
    from httpie.plugins.builtin import Transport


# Generated at 2022-06-17 21:12:03.107768
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, BodyFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, VerboseFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin
    from httpie.plugins.builtin import HTMLForm

# Generated at 2022-06-17 21:12:13.190310
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import XMLEncodedFormatterPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import LineFormatterPlugin

# Generated at 2022-06-17 21:12:14.834270
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:12:18.949047
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': httpie.plugins.auth.basic.BasicAuthPlugin, 'digest': httpie.plugins.auth.digest.DigestAuthPlugin, 'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin, 'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin, 'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin, 'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin}


# Generated at 2022-06-17 21:12:59.670942
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0

# Generated at 2022-06-17 21:13:05.012892
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class BasePlugin1(BasePlugin):
        pass

    class BasePlugin2(BasePlugin):
        pass

    class BasePlugin3(BasePlugin):
        pass

    class BasePlugin4(BasePlugin):
        pass

    class BasePlugin5(BasePlugin):
        pass

    class BasePlugin6(BasePlugin):
        pass

    class BasePlugin7(BasePlugin):
        pass

    class BasePlugin8(BasePlugin):
        pass

    class BasePlugin9(BasePlugin):
        pass

    class BasePlugin10(BasePlugin):
        pass

    class BasePlugin11(BasePlugin):
        pass

    class BasePlugin12(BasePlugin):
        pass

    class BasePlugin13(BasePlugin):
        pass

    class BasePlugin14(BasePlugin):
        pass

    class BasePlugin15(BasePlugin):
        pass


# Generated at 2022-06-17 21:13:13.191937
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:13:23.921866
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import RawJsonFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin

# Generated at 2022-06-17 21:13:33.422827
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(D):
        pass

    class F(E):
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass

   

# Generated at 2022-06-17 21:13:44.223021
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:13:52.523978
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:13:53.867559
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'auth': AuthPlugin}

# Generated at 2022-06-17 21:14:00.657036
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import DevNullFormatterPlugin
    from httpie.plugins.builtin import NullFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import JUnitFormatterPlugin

# Generated at 2022-06-17 21:14:05.527693
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import MultipartFormatter
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import ImageFormatter
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPieArgumentParser
    from httpie.plugins.builtin import HTTPieColors
   

# Generated at 2022-06-17 21:15:29.590649
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:40.040469
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:15:49.940252
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class Plugin1(FormatterPlugin):
        group_name = 'group1'
    class Plugin2(FormatterPlugin):
        group_name = 'group2'
    class Plugin3(FormatterPlugin):
        group_name = 'group1'
    class Plugin4(FormatterPlugin):
        group_name = 'group2'
    class Plugin5(FormatterPlugin):
        group_name = 'group1'
    class Plugin6(FormatterPlugin):
        group_name = 'group2'
    class Plugin7(FormatterPlugin):
        group_name = 'group1'
    class Plugin8(FormatterPlugin):
        group_name = 'group2'
    class Plugin9(FormatterPlugin):
        group_name = 'group1'

# Generated at 2022-06-17 21:15:53.078321
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:15:56.169590
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:58.694252
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:16:04.241667
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:16:08.414484
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:16:10.067970
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:16:14.364818
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F:
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass
