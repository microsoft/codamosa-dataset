

# Generated at 2022-06-17 21:06:35.695977
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-17 21:06:38.043557
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:06:44.630226
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': httpie.plugins.auth.basic.BasicAuthPlugin, 'digest': httpie.plugins.auth.digest.DigestAuthPlugin, 'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin, 'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin, 'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin, 'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin}


# Generated at 2022-06-17 21:06:56.301073
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin4(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin5(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin6(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin7(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin8(FormatterPlugin):
        group_name = 'group2'

# Generated at 2022-06-17 21:07:06.924987
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin

# Generated at 2022-06-17 21:07:09.944502
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:15.425272
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(FormatterPlugin)
    pm.register(ConverterPlugin)
    pm.register(TransportPlugin)
    assert len(pm.filter(AuthPlugin)) == 1
    assert len(pm.filter(FormatterPlugin)) == 1
    assert len(pm.filter(ConverterPlugin)) == 1
    assert len(pm.filter(TransportPlugin)) == 1


# Generated at 2022-06-17 21:07:22.643619
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, JSONStreamFormatterPlugin,
                            PrettyOptionsPlugin, RawJSONFormatterPlugin,
                            StreamFormatterPlugin, URLEncodedFormatterPlugin,
                            XMLFormatterPlugin)

# Generated at 2022-06-17 21:07:25.171448
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}

# Generated at 2022-06-17 21:07:34.718859
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, JSONLinesFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin, ImageFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, DevNullFormatterPlugin, FileFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:07:42.683436
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:07:52.445399
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import JSONLinesPrettyFormatterPlugin
    from httpie.plugins.builtin import JSONLinesStreamFormatterPlugin
    from httpie.plugins.builtin import JSONLinesTableForm

# Generated at 2022-06-17 21:08:01.909309
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:08:03.448613
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-17 21:08:13.193010
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Plugin1(FormatterPlugin):
        group_name = 'group1'
    class Plugin2(FormatterPlugin):
        group_name = 'group1'
    class Plugin3(FormatterPlugin):
        group_name = 'group2'
    class Plugin4(FormatterPlugin):
        group_name = 'group2'
    class Plugin5(FormatterPlugin):
        group_name = 'group2'
    class Plugin6(FormatterPlugin):
        group_name = 'group3'
    class Plugin7(FormatterPlugin):
        group_name = 'group3'
    class Plugin8(FormatterPlugin):
        group_name = 'group3'
    class Plugin9(FormatterPlugin):
        group_name = 'group3'
    class Plugin10(FormatterPlugin):
        group_name = 'group3'

# Generated at 2022-06-17 21:08:21.224765
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F:
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:08:28.196924
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:08:35.632305
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:08:45.197489
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:08:53.965559
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['basic'] == BasicAuthPlugin
    assert auth_plugin_mapping['digest'] == DigestAuthPlugin
    assert auth_plugin_mapping['hawk'] == HawkAuthPlugin
    assert auth_plugin_mapping['ntlm'] == NTLMAuthPlugin
    assert auth_plugin_mapping['oauth1'] == OAuth1Plugin
    assert auth_plugin_mapping['oauth2'] == OAuth2Plugin
    assert auth_plugin_mapping['jwt'] == JWTAuthPlugin
    assert auth_plugin_mapping['aws4'] == AWS4AuthPlugin

# Generated at 2022-06-17 21:09:05.159689
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.hawk import HawkAuthPlugin
    from httpie.plugins.auth.ntlm import NTLMAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1AuthPlugin
    from httpie.plugins.auth.oauth2 import OAuth2AuthPlugin
    from httpie.plugins.auth.aws import AWSAuthPlugin
    from httpie.plugins.auth.aws_sigv4 import AWSSigv4AuthPlugin
    from httpie.plugins.auth.aws_sigv4_header import AWSSigv4HeaderAuthPlugin
    from httpie.plugins.auth.aws_sigv4_query import AWSSigv4QueryAuthPlugin

# Generated at 2022-06-17 21:09:08.136862
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:09:10.224486
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:21.874680
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager
    class AuthPlugin1(AuthPlugin):
        pass
    class AuthPlugin2(AuthPlugin):
        pass
    class FormatterPlugin1(FormatterPlugin):
        pass
    class FormatterPlugin2(FormatterPlugin):
        pass
    class ConverterPlugin1(ConverterPlugin):
        pass
    class ConverterPlugin2(ConverterPlugin):
        pass
    class TransportPlugin1(TransportPlugin):
        pass
    class TransportPlugin2(TransportPlugin):
        pass
    class BasePlugin1(BasePlugin):
        pass
    class BasePlugin2(BasePlugin):
        pass
    class BasePlugin3(BasePlugin):
        pass

# Generated at 2022-06-17 21:09:25.284680
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:09:31.226848
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(
        JSONFormatterPlugin,
        PrettyFormatterPlugin,
        RawJSONFormatterPlugin,
        RawFormatterPlugin,
        StreamFormatterPlugin,
        TableFormatterPlugin,
        URLEncodedFormatterPlugin,
    )


# Generated at 2022-06-17 21:09:41.513886
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:09:50.179146
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
        'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin,
        'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin,
    }

# Generated at 2022-06-17 21:10:01.542949
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:10:10.360707
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F:
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:10:25.847710
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(BasePlugin):
        pass
    class Plugin4(BasePlugin):
        pass
    class Plugin5(BasePlugin):
        pass
    class Plugin6(BasePlugin):
        pass
    class Plugin7(BasePlugin):
        pass
    class Plugin8(BasePlugin):
        pass
    class Plugin9(BasePlugin):
        pass
    class Plugin10(BasePlugin):
        pass
    class Plugin11(BasePlugin):
        pass
    class Plugin12(BasePlugin):
        pass
    class Plugin13(BasePlugin):
        pass
    class Plugin14(BasePlugin):
        pass
    class Plugin15(BasePlugin):
        pass
    class Plugin16(BasePlugin):
        pass

# Generated at 2022-06-17 21:10:33.466810
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]
    assert plugin_manager.filter(BasePlugin) == [AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin]


# Generated at 2022-06-17 21:10:39.717194
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(BasePlugin):
        pass

    class Plugin4(Plugin1):
        pass

    class Plugin5(Plugin2):
        pass

    class Plugin6(Plugin3):
        pass

    class Plugin7(Plugin4):
        pass

    class Plugin8(Plugin5):
        pass

    class Plugin9(Plugin6):
        pass

    class Plugin10(Plugin7):
        pass

    class Plugin11(Plugin8):
        pass

    class Plugin12(Plugin9):
        pass

    class Plugin13(Plugin10):
        pass

    class Plugin14(Plugin11):
        pass

    class Plugin15(Plugin12):
        pass

    class Plugin16(Plugin13):
        pass


# Generated at 2022-06-17 21:10:42.943879
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:44.796020
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:10:52.216034
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBasicAuthPlugin
    from httpie.plugins.builtin import HTTPBearerAuth, HTTPBearerAuthPlugin
    from httpie.plugins.builtin import HTTPTokenAuth, HTTPTokenAuthPlugin
    from httpie.plugins.builtin import HTTPDigestAuth, HTTPDigestAuthPlugin
    from httpie.plugins.builtin import HTTPAuthPlugin, HTTPAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import JSONStreamFormatter, JSONLinesFormatter
    from httpie.plugins.builtin import PrettyStreamFormatter, PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonLinesFormatter, PrettyJsonStreamFormatter
    from httpie.plugins.builtin import PrettyStreamForm

# Generated at 2022-06-17 21:10:57.713678
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, DevNullFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, RedirectFormatterPlugin
    from httpie.plugins.builtin import DownloadFormatterPlugin, FileUploadFormatterPlugin
    from httpie.plugins.builtin import FormFormatterPlugin, LineFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin, JSONLinesFormatterPlugin

# Generated at 2022-06-17 21:10:59.023723
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:11:01.156269
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:08.846819
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin
    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin)
    assert plugin_manager.get_formatters_grouped() == {
        'json': [JSONFormatterPlugin, PrettyJSONFormatterPlugin],
        'data': [URLEncodedFormatterPlugin]
    }

# Generated at 2022-06-17 21:11:19.081607
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}


# Generated at 2022-06-17 21:11:29.449469
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:11:38.033930
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:11:39.226202
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:43.429848
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-17 21:11:53.166834
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:12:03.889092
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, RawHeadersFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, RawStreamFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, RawHTMLFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin, RawRedirectFormatterPlugin
    from httpie.plugins.builtin import BinaryFormatterPlugin, RawBinaryFormatterPlugin

# Generated at 2022-06-17 21:12:14.153495
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:12:15.076874
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}

# Generated at 2022-06-17 21:12:19.010215
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:12:46.046839
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F:
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:12:59.066402
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin,\
        PrettyJSONFormatterPlugin,\
        URLEncodedFormatterPlugin,\
        RawJSONFormatterPlugin,\
        JSONLinesFormatterPlugin,\
        JSONLinesPrettyFormatterPlugin,\
        XMLFormatterPlugin,\
        PrettyXMLFormatterPlugin,\
        HTMLFormatterPlugin,\
        PrettyHTMLFormatterPlugin,\
        CSVFormatterPlugin,\
        PrettyCSVFormatterPlugin,\
        ImageFormatterPlugin,\
        StreamFormatterPlugin,\
        FileFormatterPlugin,\
        DevNullFormatterPlugin,\
        HeadersFormatterPlugin,\
        RedirectFormatterPlugin,\
        DownloadFormatterPlugin,\
        HarFormatterPlugin,\
        HarPrettyFormatterPlugin,\
        HarStream

# Generated at 2022-06-17 21:13:02.907041
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F:
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass


# Generated at 2022-06-17 21:13:04.995605
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:13:15.999025
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import HTTPHeadersFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import FileUploadFormatterPlugin
    from httpie.plugins.builtin import FormFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin

# Generated at 2022-06-17 21:13:24.293960
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin,\
        PrettyJsonFormatterPlugin,\
        URLEncodedFormatterPlugin

    manager = PluginManager()
    manager.register(JSONFormatterPlugin, PrettyJsonFormatterPlugin,
                     URLEncodedFormatterPlugin)

    assert manager.get_formatters_grouped() == {
        'json': [JSONFormatterPlugin, PrettyJsonFormatterPlugin],
        'form': [URLEncodedFormatterPlugin]
    }


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-17 21:13:31.775242
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:13:39.116636
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D, E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:13:49.226688
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin
    from httpie.plugins.builtin import OneFormatterPlugin
    from httpie.plugins.builtin import CustomFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin
    from httpie.plugins.builtin import PygmentsForm

# Generated at 2022-06-17 21:13:50.602394
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:14:39.386742
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, PrettyHeadersFormatterPlugin, RawHeadersFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, PrettyStreamFormatterPlugin, RawStreamFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, PrettyHTMLFormatterPlugin, RawHTMLFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin, PrettyRedirectFormatterPlugin, RawRedirectFormatterPlugin
    from httpie.plugins.builtin import JUnitXMLFormatterPlugin, PrettyJUnitX

# Generated at 2022-06-17 21:14:49.408217
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(BasePlugin):
        pass
    class Plugin4(BasePlugin):
        pass
    class Plugin5(BasePlugin):
        pass
    class Plugin6(BasePlugin):
        pass
    class Plugin7(BasePlugin):
        pass
    class Plugin8(BasePlugin):
        pass
    class Plugin9(BasePlugin):
        pass
    class Plugin10(BasePlugin):
        pass
    class Plugin11(BasePlugin):
        pass
    class Plugin12(BasePlugin):
        pass
    class Plugin13(BasePlugin):
        pass
    class Plugin14(BasePlugin):
        pass
    class Plugin15(BasePlugin):
        pass
    class Plugin16(BasePlugin):
        pass

# Generated at 2022-06-17 21:15:00.883966
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:15:06.334795
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
    }

# Generated at 2022-06-17 21:15:12.670045
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-17 21:15:14.513849
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:22.137183
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin, RawJSONFormatterPlugin, \
        JSONLinesFormatterPlugin, TableFormatterPlugin, URLEncodedFormatterPlugin, HTMLFormatterPlugin, \
        ImageFormatterPlugin, StreamFormatterPlugin, DevNullFormatterPlugin, FileFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyFormatterPlugin, RawJSONFormatterPlugin,
                            JSONLinesFormatterPlugin, TableFormatterPlugin, URLEncodedFormatterPlugin,
                            HTMLFormatterPlugin, ImageFormatterPlugin, StreamFormatterPlugin,
                            DevNullFormatterPlugin, FileFormatterPlugin)

# Generated at 2022-06-17 21:15:29.152748
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:15:39.895894
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, \
        PrettyJsonFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import JSONConverterPlugin, \
        URLEncodedConverterPlugin
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, \
        HTTPDigestAuthPlugin, HTTPBearerAuthPlugin
    from httpie.plugins.builtin import LocalhostAdapterPlugin, \
        TCPAdapterPlugin, UnixSocketAdapterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:15:49.783113
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)