

# Generated at 2022-06-17 21:06:43.978746
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['basic'] == BasicAuthPlugin
    assert auth_plugin_mapping['digest'] == DigestAuthPlugin
    assert auth_plugin_mapping['jwt'] == JWTAuthPlugin
    assert auth_plugin_mapping['oauth1'] == OAuth1AuthPlugin
    assert auth_plugin_mapping['oauth2'] == OAuth2AuthPlugin
    assert auth_plugin_mapping['hawk'] == HawkAuthPlugin
    assert auth_plugin_mapping['ntlm'] == NTLMAuthPlugin
    assert auth_plugin_mapping['aws4-hmac-sha256'] == AWS4HMACSHA256AuthPlugin


# Generated at 2022-06-17 21:06:46.836373
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:06:59.178800
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import JSONLinesPrettyFormatterPlugin
    from httpie.plugins.builtin import JSONLinesRawFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin

# Generated at 2022-06-17 21:07:02.080493
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:07:09.346180
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E:
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:07:18.390266
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import RawJSONRenderer
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedParser
    from httpie.plugins.builtin import HTTPieArgumentParser
    from httpie.plugins.builtin import HTTPieRequest
    from httpie.plugins.builtin import HTTPieResponse
    from httpie.plugins.builtin import HTTPieStream
    from httpie.plugins.builtin import HTTPieTransport

# Generated at 2022-06-17 21:07:20.899412
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:07:31.674959
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.hawk import HawkAuthPlugin
    from httpie.plugins.auth.ntlm import NTLMAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1AuthPlugin
    from httpie.plugins.auth.oauth2 import OAuth2AuthPlugin
    from httpie.plugins.auth.aws import AWSAuthPlugin
    from httpie.plugins.auth.aws_sigv4 import AWSSigv4AuthPlugin
    from httpie.plugins.auth.aws_sigv4_hmac import AWSSigv4HMACAuthPlugin
    from httpie.plugins.auth.aws_sigv4_clikey import AWSSigv4CLI

# Generated at 2022-06-17 21:07:38.901855
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import PythonFormatterPlugin, ImageFormatterPlugin
    from httpie.plugins.builtin import JUnitFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, CSVFormatterPlugin
    from httpie.plugins.builtin import MarkdownFormatterPlugin, XMLFormatterPlugin

# Generated at 2022-06-17 21:07:42.131978
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:53.503965
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:07:54.759417
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {'auth': AuthPlugin}

# Generated at 2022-06-17 21:08:00.479963
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}
    manager.register(AuthPlugin)
    assert manager.get_auth_

# Generated at 2022-06-17 21:08:07.047196
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:08:14.649423
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]


# Generated at 2022-06-17 21:08:20.628190
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-17 21:08:24.381668
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-17 21:08:34.388157
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:08:43.945132
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin

# Generated at 2022-06-17 21:08:50.479214
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    class PluginD(PluginB):
        pass

    class PluginE(PluginC):
        pass

    class PluginF(PluginD):
        pass

    class PluginG(PluginE):
        pass

    class PluginH(PluginF):
        pass

    class PluginI(PluginG):
        pass

    class PluginJ(PluginH):
        pass

    class PluginK(PluginI):
        pass

    class PluginL(PluginJ):
        pass

    class PluginM(PluginK):
        pass

    class PluginN(PluginL):
        pass

    class PluginO(PluginM):
        pass

    class PluginP(PluginN):
        pass


# Generated at 2022-06-17 21:09:03.988576
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin

    class CustomFormatterPlugin(FormatterPlugin):
        group_name = 'custom'

    class CustomFormatterPlugin2(FormatterPlugin):
        group_name = 'custom'

    class CustomFormatterPlugin3(FormatterPlugin):
        group_name = 'custom2'

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyJSONFormatterPlugin,
                            CustomFormatterPlugin, CustomFormatterPlugin2, CustomFormatterPlugin3)


# Generated at 2022-06-17 21:09:14.983919
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:09:20.533910
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert len(pm.get_auth_plugins()) > 0
    assert len(pm.get_formatters()) > 0
    assert len(pm.get_converters()) > 0
    assert len(pm.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:09:23.913138
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:09:29.960302
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin4(FormatterPlugin):
        group_name = 'group2'
    pm = PluginManager()
    pm.register(FormatterPlugin1, FormatterPlugin2, FormatterPlugin3, FormatterPlugin4)
    assert pm.get_formatters_grouped() == {'group1': [FormatterPlugin1, FormatterPlugin3], 'group2': [FormatterPlugin2, FormatterPlugin4]}

# Generated at 2022-06-17 21:09:36.747037
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
    }

# Generated at 2022-06-17 21:09:45.576124
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E:
        pass
    class F(E):
        pass
    class G(F):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E, F, G)
    assert pm.filter(A) == [A, B, C, D]
    assert pm.filter(B) == [B, D]
    assert pm.filter(C) == [C, D]
    assert pm.filter(D) == [D]
    assert pm.filter(E) == [E, F, G]
    assert pm.filter(F) == [F, G]

# Generated at 2022-06-17 21:09:54.348090
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F:
        pass

    class G(F):
        pass

    class H(F):
        pass

    class I(G):
        pass

    class J(H):
        pass

    class K(I):
        pass

    class L(J):
        pass

    class M(K):
        pass

    class N(L):
        pass

    class O(M):
        pass

    class P(N):
        pass

    class Q(O):
        pass

    class R(P):
        pass

    class S(Q):
        pass

    class T(R):
        pass


# Generated at 2022-06-17 21:10:04.150037
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager

# Generated at 2022-06-17 21:10:08.325710
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in auth_plugin_mapping
    assert 'digest' in auth_plugin_mapping
    assert 'aws4-hmac-sha256' in auth_plugin_mapping
    assert 'aws4-signer-v4' in auth_plugin_mapping
    assert 'aws-sigv4' in auth_plugin_mapping
    assert 'aws-sigv4-unsigned-body' in auth_plugin_mapping
    assert 'aws-sigv4-unsigned-headers' in auth_plugin_mapping
    assert 'aws-sigv4-unsigned-payload' in auth_plugin_mapping

# Generated at 2022-06-17 21:10:22.003205
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, JSONLinesFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin, ImageFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, DevNullFormatterPlugin
    from httpie.plugins.builtin import get_group_name

    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin2(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin3(FormatterPlugin):
        group_name = 'test2'


# Generated at 2022-06-17 21:10:32.076226
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    from httpie.plugins.builtin import HTTPieTransport
    from httpie.plugins.manager import PluginManager
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPTokenAuth, JSONFormatter, PrettyJSONFormatter, JSONConverter, URLEncodedConverter, HTTPieTransport)
    assert plugin_manager.filter(AuthPlugin) == [HTTPBasicAuth, HTTPTokenAuth]
    assert plugin_manager

# Generated at 2022-06-17 21:10:38.919162
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, StreamFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, ImageFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, CSVFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, JSONLinesPrettyFormatterPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin, YAMLFormatterPlugin
    from httpie.plugins.builtin import DebugFormatterPlugin, PygmentsFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin, JSONLinesStreamFormatterPlugin

# Generated at 2022-06-17 21:10:45.431134
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:10:50.316601
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-17 21:10:56.442516
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert pm.get_auth_plugin_mapping()
    assert pm.get_formatters_grouped()
    assert pm.get_converters()
    assert pm.get_transport_plugins()

# Generated at 2022-06-17 21:11:00.720657
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert plugin_manager.get_auth_plugin_mapping()
    assert plugin_manager.get_formatters_grouped()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

# Generated at 2022-06-17 21:11:10.062720
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:11:21.872908
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(Plugin1):
        pass
    class Plugin4(Plugin2):
        pass
    class Plugin5(Plugin3):
        pass
    class Plugin6(Plugin4):
        pass
    class Plugin7(Plugin5):
        pass
    class Plugin8(Plugin6):
        pass
    class Plugin9(Plugin7):
        pass
    class Plugin10(Plugin8):
        pass
    class Plugin11(Plugin9):
        pass
    class Plugin12(Plugin10):
        pass
    class Plugin13(Plugin11):
        pass
    class Plugin14(Plugin12):
        pass
    class Plugin15(Plugin13):
        pass
    class Plugin16(Plugin14):
        pass

# Generated at 2022-06-17 21:11:32.221251
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['basic'] == BasicAuthPlugin
    assert auth_plugin_mapping['digest'] == DigestAuthPlugin
    assert auth_plugin_mapping['hawk'] == HawkAuthPlugin
    assert auth_plugin_mapping['ntlm'] == NTLMAuthPlugin
    assert auth_plugin_mapping['oauth1'] == OAuth1AuthPlugin
    assert auth_plugin_mapping['oauth2'] == OAuth2AuthPlugin
    assert auth_plugin_mapping['jwt'] == JWTAuthPlugin
    assert auth_plugin_mapping['aws4-hmac-sha256'] == AWS4HMACSHA256AuthPlugin


# Generated at 2022-06-17 21:11:40.917230
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:48.539216
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:11:56.342179
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0
    assert len(manager.get_auth_plugins()) > 0
    assert len(manager.get_formatters()) > 0
    assert len(manager.get_converters()) > 0
    assert len(manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:12:04.418236
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import HTTPieHTTPAdapter
    from httpie.plugins.builtin import HTTPieHTTPSAdapter
    from httpie.plugins.builtin import HTTPieUnixAdapter

# Generated at 2022-06-17 21:12:14.695421
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:12:19.403389
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F:
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass


# Generated at 2022-06-17 21:12:26.952392
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:12:28.875464
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:32.477330
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0
    assert len(manager.get_auth_plugins()) > 0
    assert len(manager.get_formatters()) > 0
    assert len(manager.get_converters()) > 0
    assert len(manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:12:43.340263
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D, E):
        pass
    class G:
        pass
    class H(G):
        pass
    class I(G):
        pass
    class J(H, I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:13:12.515806
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D:
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:13:23.465072
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter, URLEncodedFormatter
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    from httpie.plugins.builtin import HTTPiePlugin, HTTPieSSLPlugin
    from httpie.plugins.builtin import HTTPieUnixSocketPlugin
    from httpie.plugins.builtin import HTTPieUnixSocketSSLPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:13:29.045283
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:13:35.787960
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(D):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:13:45.680683
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(FormatterPlugin)
    assert pm.get_formatters_grouped() == {'default': [FormatterPlugin]}
    pm.register(FormatterPlugin)
    assert pm.get_formatters_grouped() == {'default': [FormatterPlugin, FormatterPlugin]}
    pm.register(FormatterPlugin)
    assert pm.get_formatters_grouped() == {'default': [FormatterPlugin, FormatterPlugin, FormatterPlugin]}
    pm.register(FormatterPlugin)
    assert pm.get_formatters_grouped() == {'default': [FormatterPlugin, FormatterPlugin, FormatterPlugin, FormatterPlugin]}
    pm.register(FormatterPlugin)

# Generated at 2022-06-17 21:13:52.174165
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2, Plugin3, Plugin4)
    assert plugin_manager.filter(Plugin1) == [Plugin1, Plugin3]
    assert plugin_manager.filter(Plugin2) == [Plugin2, Plugin4]
    assert plugin_manager.filter(BasePlugin) == [Plugin1, Plugin2, Plugin3, Plugin4]

# Generated at 2022-06-17 21:14:03.060904
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:14:10.287017
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped['group1'][0].name == 'formatter1'
    assert formatters_grouped['group2'][0].name == 'formatter2'
    assert formatters_grouped['group2'][1].name == 'formatter3'


# Generated at 2022-06-17 21:14:15.309903
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin
    from httpie.plugins.builtin import Mark

# Generated at 2022-06-17 21:14:22.841771
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class A(FormatterPlugin):
        group_name = 'a'
    class B(FormatterPlugin):
        group_name = 'b'
    class C(FormatterPlugin):
        group_name = 'a'
    class D(FormatterPlugin):
        group_name = 'b'
    class E(FormatterPlugin):
        group_name = 'a'
    class F(FormatterPlugin):
        group_name = 'b'
    class G(FormatterPlugin):
        group_name = 'a'
    class H(FormatterPlugin):
        group_name = 'b'
    class I(FormatterPlugin):
        group_name = 'a'
    class J(FormatterPlugin):
        group_name = 'b'

# Generated at 2022-06-17 21:15:28.819955
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:39.583062
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:15:41.572626
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:15:45.374011
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:15:47.153029
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:59.697748
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:16:03.326613
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:16:10.685116
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, PrettyJSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PrettyTableFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin, PrettyRawFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin, PrettyPygmentsFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, PrettyHTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, PrettyImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, PrettyStreamFormatter

# Generated at 2022-06-17 21:16:12.035736
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:16:13.258088
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
