

# Generated at 2022-06-17 21:06:33.855412
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:06:35.858693
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:06:38.086044
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:06:45.669534
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin
    from httpie.plugins.builtin import DevNullFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONStreamFormatterPlugin
    from httpie.plugins.builtin import PrettyStreamFormatterPlugin
   

# Generated at 2022-06-17 21:06:53.814766
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin

# Generated at 2022-06-17 21:07:00.598539
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:07:08.552506
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import PrettyTableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin

# Generated at 2022-06-17 21:07:17.938626
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:07:21.179700
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'auth': AuthPlugin}


# Generated at 2022-06-17 21:07:31.798074
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager

# Generated at 2022-06-17 21:07:34.594799
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:07:40.605096
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, PrettyJSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PrettyTableFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawJSONLinesFormatterPlugin
    from httpie.plugins.builtin import RawTableFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import RedirectForm

# Generated at 2022-06-17 21:07:51.596806
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin

    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin2(FormatterPlugin):
        group_name = 'test'


# Generated at 2022-06-17 21:08:01.664411
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:08:05.886654
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

# Generated at 2022-06-17 21:08:12.444129
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:08:22.041231
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-17 21:08:24.876943
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}

# Generated at 2022-06-17 21:08:33.012340
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:08:42.270156
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.hawk import HawkAuthPlugin
    from httpie.plugins.auth.jwt import JWTAuthPlugin
    from httpie.plugins.auth.multipart import MultipartAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1AuthPlugin
    from httpie.plugins.auth.oauth2 import OAuth2AuthPlugin
    from httpie.plugins.auth.aws import AWSv4AuthPlugin
    from httpie.plugins.auth.aws import AWSv4AuthPlugin
    from httpie.plugins.auth.aws import AWSv4AuthPlugin
    from httpie.plugins.auth.aws import AWSv4AuthPlugin

# Generated at 2022-06-17 21:08:51.296027
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': httpie.plugins.auth.basic_auth.BasicAuthPlugin, 'digest': httpie.plugins.auth.digest_auth.DigestAuthPlugin, 'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin, 'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin, 'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin, 'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin}


# Generated at 2022-06-17 21:08:58.195859
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F:
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass


# Generated at 2022-06-17 21:09:00.158701
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:06.251626
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import MultipartFormatter
    from httpie.plugins.builtin import PrettyURLEncodedFormatter
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import URLEncodedConverter
    from httpie.plugins.builtin import MultipartCon

# Generated at 2022-06-17 21:09:17.918352
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import SingleValueJSONLinesFormatterPlugin
    from httpie.plugins.builtin import SingleValueTableFormatterPlugin

# Generated at 2022-06-17 21:09:20.115140
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:09:28.921897
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import DevNullFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin

# Generated at 2022-06-17 21:09:39.405733
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuthPlugin
    from httpie.plugins.builtin import HTTPTokenAuthPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import KeyValueFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawKeyValueFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedStreamFormatterPlugin

# Generated at 2022-06-17 21:09:41.515132
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:51.836034
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.hawk import HawkAuthPlugin
    from httpie.plugins.auth.ntlm import NTLMAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1AuthPlugin
    from httpie.plugins.auth.oauth2 import OAuth2AuthPlugin
    from httpie.plugins.auth.aws import AWSAuthPlugin
    from httpie.plugins.auth.aws_sigv4 import AWSSigv4AuthPlugin
    from httpie.plugins.auth.aws_sigv4_hmac import AWSSigv4HMACAuthPlugin
    from httpie.plugins.auth.aws_sigv4_clikey import AWSSigv4CLI

# Generated at 2022-06-17 21:10:06.620557
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, PrettyJSONLinesFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyRawJSONFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PrettyTableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin, PrettyXMLFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, PrettyHTMLFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, PrettyStreamFormatterPlugin
    from httpie.plugins.builtin import FormFormatterPlugin, PrettyFormForm

# Generated at 2022-06-17 21:10:08.222232
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

# Generated at 2022-06-17 21:10:19.481986
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth, JSONFormatter, JSONLinesFormatter, URLEncodedFormatter, PrettyURLEncodedFormatter, KeyValue, PythonPrettyPrinter, HTTPieHTTPAdapter
    pm = PluginManager()
    pm.register(HTTPBasicAuth, HTTPTokenAuth, JSONFormatter, JSONLinesFormatter, URLEncodedFormatter, PrettyURLEncodedFormatter, KeyValue, PythonPrettyPrinter, HTTPieHTTPAdapter)
    assert pm.filter(AuthPlugin) == [HTTPBasicAuth, HTTPTokenAuth]

# Generated at 2022-06-17 21:10:30.173366
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:38.156849
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:10:39.375501
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:42.653725
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:10:50.844106
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-17 21:11:01.441851
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D:
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:11:11.651161
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E, F)
    assert pm.filter(A) == [A, B, C, D, E, F]
    assert pm.filter(B) == [B, D, F]
    assert pm.filter(C) == [C, E, F]
    assert pm.filter(D) == [D, F]
    assert pm.filter(E) == [E, F]
    assert pm.filter(F) == [F]

# Generated at 2022-06-17 21:11:23.097397
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0


# Generated at 2022-06-17 21:11:33.601938
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager

    class Plugin1(BasePlugin):
        pass

    class Plugin2(AuthPlugin):
        pass

    class Plugin3(ConverterPlugin):
        pass

    class Plugin4(FormatterPlugin):
        pass

    class Plugin5(TransportPlugin):
        pass

    plugins = PluginManager()
    plugins.register(Plugin1, Plugin2, Plugin3, Plugin4, Plugin5)

    assert plugins.filter(BasePlugin) == [Plugin1, Plugin2, Plugin3, Plugin4, Plugin5]
    assert plugins.filter(AuthPlugin) == [Plugin2]
    assert plugins.filter(ConverterPlugin) == [Plugin3]
    assert plugins

# Generated at 2022-06-17 21:11:41.723564
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E:
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:11:52.273008
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D:
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(E, F):
        pass

    class H(G):
        pass

    class I(G):
        pass

    class J(I):
        pass

    class K(I):
        pass

    class L(J, K):
        pass

    class M(L):
        pass

    class N(L):
        pass

    class O(M, N):
        pass

    class P(O):
        pass

    class Q(O):
        pass

    class R(P, Q):
        pass

    class S(R):
        pass


# Generated at 2022-06-17 21:11:53.377742
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:12:04.023145
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, DefaultHeadersFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, DefaultFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, DefaultTableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin, DefaultPygmentsFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, DefaultImageFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin, DefaultJSONStreamFormatterPlugin
    from httpie.plugins.builtin import JSONLinesForm

# Generated at 2022-06-17 21:12:07.936091
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}

# Generated at 2022-06-17 21:12:16.121391
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass
   

# Generated at 2022-06-17 21:12:17.764581
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:26.673888
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin
    from httpie.plugins.builtin import JSONConverterPlugin, URLEncodedConverterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyJSONFormatterPlugin,
                            URLEncodedFormatterPlugin, RawJSONFormatterPlugin,
                            JSONConverterPlugin, URLEncodedConverterPlugin)
    assert plugin_manager.get_formatters_grouped() == {
        'JSON': [JSONFormatterPlugin, PrettyJSONFormatterPlugin, RawJSONFormatterPlugin],
        'URL-encoded': [URLEncodedFormatterPlugin],
    }

# Generated at 2022-06-17 21:12:57.084348
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:12:59.033113
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:13:00.134045
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:13:04.399776
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:13:11.005905
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:13:22.282824
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, StreamFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin, DownloadFormatterPlugin, ImageFormatterPlugin
    from httpie.plugins.builtin import JUnitFormatterPlugin, HarFormatterPlugin, JsonLinesFormatterPlugin
    from httpie.plugins.builtin import JsonLinesLinesFormatterPlugin, JsonLinesLinesLinesFormatterPlugin
    from httpie.plugins.builtin import JsonLinesLinesLinesLinesFormatterPlugin

# Generated at 2022-06-17 21:13:24.293551
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:13:33.753071
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import SyntaxHighlightPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(
        JSONFormatterPlugin,
        JSONStreamFormatterPlugin,
        PrettyOptionsPlugin,
        StreamFormatterPlugin,
        SyntaxHighlightPlugin,
        TableFormatterPlugin,
        URLEncodedFormatterPlugin,
    )


# Generated at 2022-06-17 21:13:44.736069
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:13:49.823272
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

# Generated at 2022-06-17 21:14:37.036112
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:14:38.810086
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}

# Generated at 2022-06-17 21:14:40.763883
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:14:49.293343
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2, Plugin3, Plugin4, Plugin5, Plugin6)

    assert plugin_manager.filter(Plugin1) == [Plugin1, Plugin3, Plugin5]
    assert plugin_manager.filter(Plugin2) == [Plugin2, Plugin4, Plugin6]
    assert plugin_manager.filter(BasePlugin) == [Plugin1, Plugin2, Plugin3, Plugin4, Plugin5, Plugin6]


# Generated at 2022-06-17 21:14:53.369370
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:14:56.406599
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-17 21:14:59.535718
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:06.516498
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D:
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E, F, G)
    assert pm.filter(A) == [A, B, C]
    assert pm.filter(D) == [D, E, F, G]
    assert pm.filter(E) == [E]
    assert pm.filter(F) == [F]
    assert pm.filter(G) == [G]


# Generated at 2022-06-17 21:15:16.359944
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin

    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin2(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin3(FormatterPlugin):
        group_name = 'test2'

    plugin_manager = PluginManager()
    plugin_manager.register(TestFormatterPlugin, TestFormatterPlugin2, TestFormatterPlugin3)
    plugin_manager.register(JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin)


# Generated at 2022-06-17 21:15:24.094822
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_