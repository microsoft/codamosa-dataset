

# Generated at 2022-06-17 21:06:40.610353
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:06:50.861900
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth


# Generated at 2022-06-17 21:06:57.720747
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:07:03.226480
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert len(formatters_grouped) == 2
    assert len(formatters_grouped['group1']) == 2
    assert len(formatters_grouped['group2']) == 1

# Generated at 2022-06-17 21:07:10.020027
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import RawJSONRenderer
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedParser
    from httpie.plugins.builtin import HTTPieArgumentParser
    from httpie.plugins.builtin import HTTPieRequest
    from httpie.plugins.builtin import HTTPieResponse
    from httpie.plugins.builtin import HTTPieStream
    from httpie.plugins.builtin import HTTPieTransport

# Generated at 2022-06-17 21:07:17.704724
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]
    assert pm.filter(int) == []

# Generated at 2022-06-17 21:07:19.370903
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:07:24.566623
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:07:34.227900
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    class PluginD(PluginA):
        pass

    class PluginE(PluginB):
        pass

    class PluginF(PluginB):
        pass

    class PluginG(PluginC):
        pass

    class PluginH(PluginC):
        pass

    class PluginI(PluginD):
        pass

    class PluginJ(PluginD):
        pass

    class PluginK(PluginE):
        pass

    class PluginL(PluginE):
        pass

    class PluginM(PluginF):
        pass

    class PluginN(PluginF):
        pass

    class PluginO(PluginG):
        pass

    class PluginP(PluginG):
        pass


# Generated at 2022-06-17 21:07:42.116451
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in auth_plugin_mapping
    assert 'digest' in auth_plugin_mapping
    assert 'aws4-hmac-sha256' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-signed-body' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-unsigned-payload' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-unsigned-headers' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-unsigned-payload-unsigned-headers' in auth_plugin_mapping

# Generated at 2022-06-17 21:07:53.888908
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:07:55.101084
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:05.569116
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter
    from httpie.plugins.builtin import HTTPieTransport

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPTokenAuth, JSONConverter, URLEncodedConverter, JSONFormatter, PrettyJSONFormatter, HTTPieTransport)
    assert plugin_manager.filter(AuthPlugin) == [HTTPBasicAuth, HTTPTokenAuth]

# Generated at 2022-06-17 21:08:07.588711
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:16.514917
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import DefaultFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import OneLineFormatterPlugin

# Generated at 2022-06-17 21:08:22.135307
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D:
        pass
    class E(D):
        pass
    class F(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E, F)
    assert pm.filter(A) == [A, B, C]
    assert pm.filter(D) == [D, E, F]

# Generated at 2022-06-17 21:08:32.939490
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:08:34.530037
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:08:44.064801
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin, StreamFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, VerboseFormatterPlugin
    from httpie.plugins.builtin import OneLineFormatterPlugin, JUnitFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, ImageURLEncodedFormatterPlugin
    from httpie.plugins.builtin import ImageJSONFormatterPlugin, ImageJSONStreamForm

# Generated at 2022-06-17 21:08:45.185628
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:09:02.330304
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import FormattersHelpFormatterPlugin

# Generated at 2022-06-17 21:09:04.370865
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:15.407855
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:09:22.363412
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:09:29.829268
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter, URLEncodedFormatter
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    from httpie.plugins.builtin import HTTPieTransport
    from httpie.plugins.builtin import HTTPieTransport
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONForm

# Generated at 2022-06-17 21:09:36.049095
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:09:38.977876
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:09:46.630016
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Plugin1(FormatterPlugin):
        group_name = 'group1'
    class Plugin2(FormatterPlugin):
        group_name = 'group1'
    class Plugin3(FormatterPlugin):
        group_name = 'group2'
    class Plugin4(FormatterPlugin):
        group_name = 'group2'
    class Plugin5(FormatterPlugin):
        group_name = 'group2'
    class Plugin6(FormatterPlugin):
        group_name = 'group3'
    class Plugin7(FormatterPlugin):
        group_name = 'group3'
    class Plugin8(FormatterPlugin):
        group_name = 'group3'
    class Plugin9(FormatterPlugin):
        group_name = 'group3'
    class Plugin10(FormatterPlugin):
        group_name = 'group3'

# Generated at 2022-06-17 21:09:48.404269
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:59.736526
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:10:13.439477
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin
    from httpie.plugins.builtin import CustomFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin

# Generated at 2022-06-17 21:10:22.035294
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]


# Generated at 2022-06-17 21:10:32.124613
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in auth_plugin_mapping
    assert 'digest' in auth_plugin_mapping
    assert 'hawk' in auth_plugin_mapping
    assert 'ntlm' in auth_plugin_mapping
    assert 'oauth1' in auth_plugin_mapping
    assert 'oauth2' in auth_plugin_mapping
    assert 'aws4-hmac-sha256' in auth_plugin_mapping
    assert 'aws4-signature' in auth_plugin_mapping
    assert 'aws-sigv4' in auth_plugin_mapping
    assert 'aws-sigv4-unsigned-body' in auth

# Generated at 2022-06-17 21:10:38.969606
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D, E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:10:48.962901
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:10:59.545397
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class BasePlugin1(BasePlugin):
        pass

    class BasePlugin2(BasePlugin):
        pass

    class BasePlugin3(BasePlugin1):
        pass

    class BasePlugin4(BasePlugin2):
        pass

    pm = PluginManager()
    pm.register(BasePlugin1, BasePlugin2, BasePlugin3, BasePlugin4)
    assert pm.filter(BasePlugin1) == [BasePlugin1, BasePlugin3]
    assert pm.filter(BasePlugin2) == [BasePlugin2, BasePlugin4]
    assert pm.filter() == [BasePlugin1, BasePlugin2, BasePlugin3, BasePlugin4]



# Generated at 2022-06-17 21:11:03.869696
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == len(ENTRY_POINT_NAMES)

# Generated at 2022-06-17 21:11:06.668700
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}

# Generated at 2022-06-17 21:11:10.729471
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0
    assert len(manager.get_auth_plugins()) > 0
    assert len(manager.get_formatters()) > 0
    assert len(manager.get_converters()) > 0
    assert len(manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:11:18.197585
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:11:26.284006
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:30.744491
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()


# Generated at 2022-06-17 21:11:38.039216
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:11:45.123844
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(A, B, C, D, E)
    assert plugin_manager.filter(A) == [A, B, C, D, E]
    assert plugin_manager.filter(B) == [B, D, E]
    assert plugin_manager.filter(C) == [C]
    assert plugin_manager.filter(D) == [D, E]
    assert plugin_manager.filter(E) == [E]

# Generated at 2022-06-17 21:11:53.527447
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import FormattersHelpFormatterPlugin
    from httpie.plugins.builtin import FormattersDocsFormatterPlugin


# Generated at 2022-06-17 21:12:03.378364
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTPBasicAuth, HTTPTokenAuth, HTTPBearerAuth, HTTP

# Generated at 2022-06-17 21:12:13.522111
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter, URLEncodedFormatter
    from httpie.plugins.builtin import HTTPieTransport
    from httpie.plugins.manager import PluginManager
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth)
    plugin_manager.register(JSONConverter, URLEncodedConverter)

# Generated at 2022-06-17 21:12:14.940151
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0


# Generated at 2022-06-17 21:12:23.595077
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:12:31.187491
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:12:48.811345
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import PrettyHeadersFormatterPlugin
    from httpie.plugins.builtin import RawHeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import PrettyHTMLFormatterPlugin

# Generated at 2022-06-17 21:13:00.573305
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter, URLEncodedFormatter
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    from httpie.plugins.builtin import HTTPiePlugin, HTTPieSSLPlugin, HTTPieUnixSocketPlugin
    from httpie.plugins.builtin import HTTPieCurlBackend, HTTPieRequestsBackend
    from httpie.plugins.builtin import HTTPiePrettyBackend
    from httpie.plugins.builtin import HTTPiePrettyBackend
   

# Generated at 2022-06-17 21:13:12.399483
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJsonFormatterPlugin,\
        URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin,\
        RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, PrettyHTMLFormatterPlugin,\
        RawHTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, PrettyImageFormatterPlugin,\
        RawImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, PrettyStreamFormatterPlugin,\
        RawStreamFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin, PrettyFileFormatterPlugin,\
        RawFileFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PrettyTableFormatter

# Generated at 2022-06-17 21:13:23.410940
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, PrettyJSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PrettyTableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyRawJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONLinesFormatterPlugin, PrettyRawJSONLinesFormatterPlugin
    from httpie.plugins.builtin import RawTableFormatterPlugin, PrettyRawTableFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin, PrettyRawURLEncodedFormatterPlugin

# Generated at 2022-06-17 21:13:32.912719
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin, \
        DefaultFormatterPlugin, HeadersFormatterPlugin, StreamFormatterPlugin, \
        HTMLFormatterPlugin, ImageFormatterPlugin, JUnitFormatterPlugin, \
        CSVFormatterPlugin, TableFormatterPlugin, PygmentsFormatterPlugin, \
        JSONLinesFormatterPlugin, JSONStreamFormatterPlugin, \
        JSONLinesStreamFormatterPlugin, XMLFormatterPlugin, \
        XMLStreamFormatterPlugin, OneDarkFormatterPlugin, \
        OneLightFormatterPlugin, SolarizedDarkFormatterPlugin, \
        SolarizedLightFormatterPlugin, MonokaiFormatterPlugin, \
        DraculaFormatterPlugin, GruvboxDarkFormatterPlugin

# Generated at 2022-06-17 21:13:43.552959
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:13:47.611164
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.load_installed_plugins()

# Generated at 2022-06-17 21:13:50.073237
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-17 21:13:59.695528
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:14:05.052573
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawOrParseErrorFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import HexdumpFormatterPlugin
    from httpie.plugins.builtin import HtmlFormatterPlugin
    from httpie.plugins.builtin import JsonLinesFormatterPlugin

# Generated at 2022-06-17 21:14:40.517330
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-17 21:14:49.490993
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:14:53.577141
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:14:57.710680
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin_mapping()
    assert True

# Generated at 2022-06-17 21:14:58.771805
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:01.242196
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:15:08.499045
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:15:17.626302
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
        'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin,
        'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin,
    }


# Generated at 2022-06-17 21:15:27.036633
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import OAuth1Auth
    from httpie.plugins.builtin import OAuth2Auth
    from httpie.plugins.builtin import DigestAuth
    from httpie.plugins.builtin import HawkAuth
    from httpie.plugins.builtin import NetrcAuth
    from httpie.plugins.builtin import BearerTokenAuth
    from httpie.plugins.builtin import JWTAuth
    from httpie.plugins.builtin import JWTAuthHeader
    from httpie.plugins.builtin import JWTAuthQuery
    from httpie.plugins.builtin import JWTAuthCookie
    from httpie.plugins.builtin import JW

# Generated at 2022-06-17 21:15:36.800402
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import RawJSONRenderer
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedParser
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieTransport
    from httpie.plugins.builtin import KeyValue
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import KeyValueParser