

# Generated at 2022-06-17 21:06:43.342271
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin1):
        pass

    class Plugin5(Plugin2):
        pass

    class Plugin6(Plugin2):
        pass

    class Plugin7(Plugin3):
        pass

    class Plugin8(Plugin3):
        pass

    class Plugin9(Plugin4):
        pass

    class Plugin10(Plugin4):
        pass

    class Plugin11(Plugin5):
        pass

    class Plugin12(Plugin5):
        pass

    class Plugin13(Plugin6):
        pass

    class Plugin14(Plugin6):
        pass

    class Plugin15(Plugin7):
        pass

    class Plugin16(Plugin7):
        pass


# Generated at 2022-06-17 21:06:49.182317
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-17 21:06:59.932008
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:07:08.240804
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:07:13.730569
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:07:15.632946
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:22.772467
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:07:32.800781
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-17 21:07:36.845443
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth, HTTPNTLMAuth, HTTPProxyAuth, HTTPOAuth1Auth, HTTPOAuth2Auth, HTTPAWSAuth, HTTPDigestAuth, HTTPHawkAuth, HTTPFileUpload, HTTPJSON, HTTPXML, HTTPYAML, HTTPHeaders, HTTPPretty, HTTPStream, HTTPBinary, HTTPVerbose, HTTPTraceback, HTTPTrace, HTTPBrotli, HTTPGzip, HTTPZip, HTTP2, HTTP3
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 21:07:42.823452
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import DevNullFormatterPlugin
    from httpie.plugins.builtin import NullFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import Red

# Generated at 2022-06-17 21:07:54.297934
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:08:00.200999
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, JSONLinesFormatterPlugin, \
        TableFormatterPlugin, HTMLFormatterPlugin, ImageFormatterPlugin, \
        StreamFormatterPlugin, DevNullFormatterPlugin, FileFormatterPlugin, \
        HarFormatterPlugin, PrettyHarFormatterPlugin, JUnitFormatterPlugin, \
        PrettyJUnitFormatterPlugin, CSVFormatterPlugin, PrettyCSVFormatterPlugin, \
        MarkdownFormatterPlugin, PrettyMarkdownFormatterPlugin, \
        XmlFormatterPlugin, PrettyXmlFormatterPlugin, \
        PygmentsFormatterPlugin, PrettyPygmentsFormatterPlugin, \
        TerminalFormatterPlugin, PrettyTerminalFormatterPlugin, \
        JsonLinesFormatterPlugin, Pretty

# Generated at 2022-06-17 21:08:06.942445
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin

    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin2(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin3(FormatterPlugin):
        group_name = 'test2'

    class TestFormatterPlugin4(FormatterPlugin):
        group_name = 'test2'

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:08:15.892841
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:08:23.131957
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class FormatterPluginA(FormatterPlugin):
        group_name = 'A'
    class FormatterPluginB(FormatterPlugin):
        group_name = 'B'
    class FormatterPluginC(FormatterPlugin):
        group_name = 'C'
    class FormatterPluginD(FormatterPlugin):
        group_name = 'D'
    class FormatterPluginE(FormatterPlugin):
        group_name = 'E'
    class FormatterPluginF(FormatterPlugin):
        group_name = 'F'
    class FormatterPluginG(FormatterPlugin):
        group_name = 'G'
    class FormatterPluginH(FormatterPlugin):
        group_name = 'H'
    class FormatterPluginI(FormatterPlugin):
        group_name = 'I'

# Generated at 2022-06-17 21:08:33.745655
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)

# Generated at 2022-06-17 21:08:43.174160
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, RawHeadersFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin, RawRedirectFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, RawStreamFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, RawHTMLFormatterPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin, RawXMLFormatterPlugin


# Generated at 2022-06-17 21:08:45.002160
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:51.109255
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import URLEncodedConverter
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieSSLPlugin
    from httpie.plugins.builtin import HTTPieUnixSocketPlugin
    from httpie.plugins.builtin import HTTPieCurlPlugin
    from httpie.plugins.builtin import HTTPieMultipartFormDataPlugin
    from httpie.plugins.builtin import HTTPieMultipartFormDataPlugin

# Generated at 2022-06-17 21:08:54.440704
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:59.861480
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:09:01.773220
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:09:13.379705
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:09:17.964905
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()


# Generated at 2022-06-17 21:09:27.549837
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:09:37.728303
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:09:42.472572
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-17 21:09:52.248201
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:02.132035
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:04.241227
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:12.093240
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:19.675898
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
    }


# Generated at 2022-06-17 21:10:30.173364
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import HTTPFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin

# Generated at 2022-06-17 21:10:31.271610
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0


# Generated at 2022-06-17 21:10:38.528046
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:10:47.137273
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:11:00.305728
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:11:11.479401
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin, \
        JSONLinesFormatterPlugin, TableFormatterPlugin, HTMLFormatterPlugin, \
        ImageFormatterPlugin, StreamFormatterPlugin, FileUploadFormatterPlugin, \
        FormFormatterPlugin, CustomFormatterPlugin, HeadersFormatterPlugin, \
        BodyFormatterPlugin, RedirectFormatterPlugin, ErrorFormatterPlugin, \
        StreamFormatterPlugin, FileUploadFormatterPlugin, FormFormatterPlugin, \
        CustomFormatterPlugin, HeadersFormatterPlugin, BodyFormatterPlugin, \
        RedirectFormatterPlugin, ErrorFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:11:22.717608
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    from httpie.plugins.builtin import HTTPieTransport
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPTokenAuth, JSONFormatter, PrettyJSONFormatter, JSONConverter, URLEncodedConverter, HTTPieTransport)
    assert plugin_manager.filter(AuthPlugin) == [HTTPBasicAuth, HTTPTokenAuth]
    assert plugin_manager.filter(FormatterPlugin) == [JSONFormatter, PrettyJSONFormatter]

# Generated at 2022-06-17 21:11:26.657985
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'auth': AuthPlugin}

# Generated at 2022-06-17 21:11:42.641927
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-17 21:11:46.061775
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:53.968162
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:12:04.076621
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped['json'] == [
        httpie.plugins.formatter.json.JSONFormatter,
        httpie.plugins.formatter.json_lines.JSONLinesFormatter,
    ]
    assert formatters_grouped['html'] == [
        httpie.plugins.formatter.html.HTMLFormatter,
    ]
    assert formatters_grouped['colors'] == [
        httpie.plugins.formatter.colors.ColorsFormatter,
    ]

# Generated at 2022-06-17 21:12:08.284580
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:12:16.429021
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPNTLMAuth, HTTPNegotiateAuth
    from httpie.plugins.builtin import JSONConverter, URLEncodedFormConverter
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter, URLEncodedFormFormatter
    from httpie.plugins.builtin import HTTPiePlugin, HTTPieTransport
    from httpie.plugins.manager import PluginManager
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:12:22.535405
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert plugins.filter(AuthPlugin) == [AuthPlugin]
    assert plugins.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugins.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugins.filter(TransportPlugin) == [TransportPlugin]
    assert plugins.filter(BasePlugin) == [AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin]


# Generated at 2022-06-17 21:12:24.489288
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:12:31.579783
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, JSONLinesFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, ImageFormatterPlugin, StreamFormatterPlugin
    from httpie.plugins.builtin import JUnitXMLFormatterPlugin, HarFormatterPlugin, CSVFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin, StreamHARFormatterPlugin, StreamJSONLinesFormatterPlugin
    from httpie.plugins.builtin import StreamHTMLFormatterPlugin, StreamImageFormatterPlugin, StreamTableFormatterPlugin

# Generated at 2022-06-17 21:12:41.714170
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:13:21.672606
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:13:31.651586
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin, RawJSONFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin, StreamFormatterPlugin
    from httpie.plugins.builtin import SingleFormatterPlugin, VerboseFormatterPlugin
    from httpie.plugins.builtin import LineFormatterPlugin, ColoredJSONFormatterPlugin
    from httpie.plugins.builtin import ColoredStreamFormatterPlugin, ColoredLineFormatterPlugin
    from httpie.plugins.builtin import ColoredFormatterPlugin, ColoredHTMLFormatterPlugin
    from httpie.plugins.builtin import Col

# Generated at 2022-06-17 21:13:39.028030
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:13:41.823486
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:13:49.664805
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:14:02.324435
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, HeadersFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import AssertJSONFormatterPlugin
    from httpie.plugins.builtin import AssertURLEncodedFormatterPlugin
    from httpie.plugins.builtin import AssertTableFormatterPlugin
    from httpie.plugins.builtin import AssertHeadersFormatterPlugin
    from httpie.plugins.builtin import AssertRawJSONFormatterPlugin


# Generated at 2022-06-17 21:14:12.531932
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:14:19.490768
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:14:26.130641
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'group3'
    class FormatterPlugin4(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin5(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin6(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin7(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin8(FormatterPlugin):
        group_name = 'group3'

# Generated at 2022-06-17 21:14:29.210106
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:15:43.962731
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:15:46.373629
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:53.745077
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth, KeyValue, JSON
    from httpie.plugins.builtin import PrettyJSONStream, PrettyStream
    from httpie.plugins.builtin import HTTPiePlugin, HTTPieTransportPlugin

    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test'

    class TestConverterPlugin(ConverterPlugin):
        name = 'test'

    class TestFormatterPlugin(FormatterPlugin):
        name = 'test'

    class TestTransportPlugin(TransportPlugin):
        name = 'test'

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:16:01.599632
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, HTMLFormatterPlugin, \
        ImageFormatterPlugin, StreamFormatterPlugin, DefaultFormatterPlugin
    from httpie.plugins.builtin import JSONConverterPlugin, URLEncodedConverterPlugin, \
        MultipartFormDataConverterPlugin, DefaultConverterPlugin
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, DigestAuthPlugin, \
        OAuth1AuthPlugin, OAuth2AuthPlugin, BearerTokenAuthPlugin, \
        JWTAuthPlugin, HawkAuthPlugin, NetrcAuthPlugin, FileAuthPlugin
    from httpie.plugins.builtin import LocalhostAdapterPlugin, HTTPAdapterPlugin, \
        HTTPSAdapterPlugin, TCPAdapterPlugin, UnixSocket

# Generated at 2022-06-17 21:16:10.039979
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    class PluginD(PluginB):
        pass

    class PluginE(PluginC):
        pass

    class PluginF(PluginD):
        pass

    class PluginG(PluginE):
        pass

    class PluginH(PluginF):
        pass

    class PluginI(PluginG):
        pass

    class PluginJ(PluginH):
        pass

    class PluginK(PluginI):
        pass

    class PluginL(PluginJ):
        pass

    class PluginM(PluginK):
        pass

    class PluginN(PluginL):
        pass

    class PluginO(PluginM):
        pass

    class PluginP(PluginN):
        pass


# Generated at 2022-06-17 21:16:15.076392
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin, \
        RawJSONFormatterPlugin, PrettyRawJSONFormatterPlugin, \
        RawURLEncodedFormatterPlugin, PrettyRawURLEncodedFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyJSONFormatterPlugin,
                            URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin,
                            RawJSONFormatterPlugin, PrettyRawJSONFormatterPlugin,
                            RawURLEncodedFormatterPlugin, PrettyRawURLEncodedFormatterPlugin)

# Generated at 2022-06-17 21:16:20.651236
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
    }

# Generated at 2022-06-17 21:16:31.604390
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:16:37.440268
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin4(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin5(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin6(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin7(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin8(FormatterPlugin):
        group_name = 'group2'