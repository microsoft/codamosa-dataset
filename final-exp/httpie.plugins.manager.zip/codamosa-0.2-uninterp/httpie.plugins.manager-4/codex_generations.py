

# Generated at 2022-06-17 21:06:35.658406
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

# Generated at 2022-06-17 21:06:38.997660
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped['group_name'] == ['plugin_name']

# Generated at 2022-06-17 21:06:43.484443
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:06:46.649250
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:06:48.474378
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:06:50.295453
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:00.293647
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, StreamFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, RedirectFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:07:08.415036
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:07:17.822344
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import AutomaticJSONFormatterPlugin
    from httpie.plugins.builtin import AutomaticFormatterPlugin
    from httpie.plugins.builtin import LineFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin

    manager = PluginManager()

# Generated at 2022-06-17 21:07:19.439615
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:29.175509
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
    }


# Generated at 2022-06-17 21:07:38.658283
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:07:49.664124
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin,\
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin,\
        JSONLinesFormatterPlugin, TableFormatterPlugin, HTMLFormatterPlugin,\
        ImageFormatterPlugin, StreamFormatterPlugin, DevNullFormatterPlugin,\
        FileFormatterPlugin, HarFormatterPlugin, RedirectFormatterPlugin,\
        StreamHARFormatterPlugin, StreamRedirectFormatterPlugin,\
        StreamDevNullFormatterPlugin, StreamFileFormatterPlugin,\
        StreamImageFormatterPlugin, StreamHTMLFormatterPlugin,\
        StreamTableFormatterPlugin, StreamJSONLinesFormatterPlugin,\
        StreamRawJSONFormatterPlugin, StreamPrettyURLEncodedFormatterPlugin,\
        StreamPrettyJSONFormatterPlugin

# Generated at 2022-06-17 21:08:01.304400
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class Plugin1(FormatterPlugin):
        group_name = 'group1'
    class Plugin2(FormatterPlugin):
        group_name = 'group2'
    class Plugin3(FormatterPlugin):
        group_name = 'group1'
    class Plugin4(FormatterPlugin):
        group_name = 'group2'
    class Plugin5(FormatterPlugin):
        group_name = 'group1'
    class Plugin6(FormatterPlugin):
        group_name = 'group2'
    class Plugin7(FormatterPlugin):
        group_name = 'group1'
    class Plugin8(FormatterPlugin):
        group_name = 'group2'
    class Plugin9(FormatterPlugin):
        group_name = 'group1'

# Generated at 2022-06-17 21:08:06.305644
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert len(pm.get_auth_plugins()) > 0
    assert len(pm.get_formatters()) > 0
    assert len(pm.get_converters()) > 0
    assert len(pm.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:08:15.314446
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D:
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(B, C):
        pass
    class H(E, F):
        pass
    class I(G, H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass

# Generated at 2022-06-17 21:08:17.115855
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:24.008280
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:08:31.497565
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-17 21:08:41.525413
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(BasePlugin):
        pass

    class Plugin4(BasePlugin):
        pass

    class Plugin5(Plugin4):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin4):
        pass

    class Plugin8(Plugin4):
        pass

    class Plugin9(Plugin4):
        pass

    class Plugin10(Plugin4):
        pass

    class Plugin11(Plugin4):
        pass

    class Plugin12(Plugin4):
        pass

    class Plugin13(Plugin4):
        pass

    class Plugin14(Plugin4):
        pass

    class Plugin15(Plugin4):
        pass

    class Plugin16(Plugin4):
        pass


# Generated at 2022-06-17 21:08:45.312975
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:51.258632
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:08:59.783817
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D:
        pass

    class E(D):
        pass

    class F(D):
        pass

    pm = PluginManager()
    pm.register(B, C, E, F)

    assert pm.filter(A) == [B, C]
    assert pm.filter(D) == [E, F]



# Generated at 2022-06-17 21:09:06.088591
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin, \
        DefaultFormatterPlugin, RawJSONFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyJSONFormatterPlugin,
                            URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin,
                            DefaultFormatterPlugin, RawJSONFormatterPlugin)
    assert plugin_manager.get_formatters_grouped() == {
        'json': [JSONFormatterPlugin, PrettyJSONFormatterPlugin, RawJSONFormatterPlugin],
        'urlencoded': [URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin],
        'default': [DefaultFormatterPlugin]
    }

# Generated at 2022-06-17 21:09:17.724081
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:09:19.927942
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:23.635621
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:09:30.520652
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:09:33.731544
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:35.570376
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:09:47.597788
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, PrettyJSONLinesFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyRawJSONFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PrettyTableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, PrettyHTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, PrettyImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, PrettyStreamFormatterPlugin
    from httpie.plugins.builtin import CustomFormatterPlugin, PrettyCustomFormatter

# Generated at 2022-06-17 21:09:51.475342
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:57.248982
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F(C):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:10:07.542748
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:10.696625
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:21.085646
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:10:30.991578
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin, \
        RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin, \
        TableFormatterPlugin, CSVFormatterPlugin, HTMLFormatterPlugin, \
        ImageFormatterPlugin, StreamFormatterPlugin, \
        FileUploadFormatterPlugin, FileDownloadFormatterPlugin
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:34.310785
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager.get_formatters_grouped(), dict)
    assert 'group_name' in plugin_manager.get_formatters_grouped().keys()

# Generated at 2022-06-17 21:10:35.877833
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:37.984401
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:10:52.204249
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:01.862239
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import ColoredJSONFormatterPlugin, ColoredURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, CSVFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, StreamFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, JavaScriptFormatterPlugin
    from httpie.plugins.builtin import MarkdownFormatterPlugin, PygmentsFormatterPlugin

# Generated at 2022-06-17 21:11:06.665236
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:11:13.745211
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin
    from httpie.plugins.builtin import DownloadFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin

# Generated at 2022-06-17 21:11:19.358071
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-17 21:11:29.734823
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(BasePlugin):
        pass

    class Plugin4(BasePlugin):
        pass

    class Plugin5(BasePlugin):
        pass

    class Plugin6(BasePlugin):
        pass

    class Plugin7(BasePlugin):
        pass

    class Plugin8(BasePlugin):
        pass

    class Plugin9(BasePlugin):
        pass

    class Plugin10(BasePlugin):
        pass

    class Plugin11(BasePlugin):
        pass

    class Plugin12(BasePlugin):
        pass

    class Plugin13(BasePlugin):
        pass

    class Plugin14(BasePlugin):
        pass

    class Plugin15(BasePlugin):
        pass

    class Plugin16(BasePlugin):
        pass


# Generated at 2022-06-17 21:11:37.486704
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, TableFormatterPlugin, \
        HTMLFormatterPlugin, CSVFormatterPlugin, ImageFormatterPlugin, \
        StreamFormatterPlugin, DevNullFormatterPlugin, JSONLinesFormatterPlugin, \
        JSONStreamFormatterPlugin, HarFormatterPlugin, PrettyOptionsFormatterPlugin, \
        PrettyRequestFormatterPlugin, PrettyResponseFormatterPlugin, \
        PrettyStreamFormatterPlugin, PrettyTracebackFormatterPlugin, \
        PrettyTracebackFormatterPlugin, PrettyTracebackFormatterPlugin, \
        PrettyTracebackFormatterPlugin, PrettyTracebackFormatterPlugin, \
        PrettyTracebackFormatterPlugin, PrettyTracebackFormatterPlugin, \
        PrettyTracebackForm

# Generated at 2022-06-17 21:11:43.242694
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:11:53.167293
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
        'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin,
        'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin,
        'jwt': httpie.plugins.auth.jwt.JWTAuthPlugin,
    }

# Generated at 2022-06-17 21:12:03.215898
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyRawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin, PrettyRawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, PrettyHeadersFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, PrettyStreamFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, PrettyHTMLFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin, PrettyRedirectFormatterPlugin
    from httpie.plugins.builtin import Stream

# Generated at 2022-06-17 21:12:33.203183
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:12:38.825612
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-17 21:12:46.919973
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:12:50.033285
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:52.718130
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-17 21:13:02.129446
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:13:12.326902
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    class PluginD(PluginA):
        pass

    class PluginE(PluginB):
        pass

    class PluginF(PluginB):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB, PluginC, PluginD, PluginE, PluginF)

    assert plugin_manager.filter(PluginA) == [PluginA, PluginC, PluginD]
    assert plugin_manager.filter(PluginB) == [PluginB, PluginE, PluginF]
    assert plugin_manager.filter(BasePlugin) == [PluginA, PluginB, PluginC, PluginD, PluginE, PluginF]

# Generated at 2022-06-17 21:13:23.355678
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:13:32.858755
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:13:41.574245
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:14:36.671327
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:14:42.649345
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped['json'] == [
        httpie.plugins.formatter.json.JSONFormatter,
        httpie.plugins.formatter.json.JSONLinesFormatter,
    ]
    assert formatters_grouped['colors'] == [
        httpie.plugins.formatter.colors.ColoredFormatter,
        httpie.plugins.formatter.colors.ColoredStreamFormatter,
    ]
    assert formatters_grouped['format'] == [
        httpie.plugins.formatter.format.FormatFormatter,
        httpie.plugins.formatter.format.FormatStreamFormatter,
    ]
    assert formatters_

# Generated at 2022-06-17 21:14:46.036300
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin, 'digest': AuthPlugin}

# Generated at 2022-06-17 21:14:51.998689
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, BodyFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, StreamPrettyFormatterPlugin

    class CustomFormatterPlugin(FormatterPlugin):
        group_name = 'custom'

    class CustomFormatterPlugin2(FormatterPlugin):
        group_name = 'custom'


# Generated at 2022-06-17 21:15:03.245073
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:15:09.566301
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:15:12.420783
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:15:14.897985
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:15:22.684738
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, \
        PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin, \
        RawJSONFormatterPlugin, JSONLinesFormatterPlugin, \
        JSONLinesPrettyFormatterPlugin, JSONLinesStreamFormatterPlugin, \
        StreamFormatterPlugin, TableFormatterPlugin, \
        HTMLFormatterPlugin, ImageFormatterPlugin, \
        ImageURLEncodedFormatterPlugin, ImageJSONFormatterPlugin, \
        ImageJSONPrettyFormatterPlugin, ImageJSONLinesFormatterPlugin, \
        ImageJSONLinesPrettyFormatterPlugin, ImageJSONLinesStreamFormatterPlugin, \
        ImageStreamFormatterPlugin, ImageTableFormatterPlugin, \
        ImageHTMLFormatterPlugin, ImageURLEncodedPrettyFormatterPlugin, \
        Image

# Generated at 2022-06-17 21:15:29.429083
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group1'
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin4(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin5(FormatterPlugin):
        group_name = 'group2'
    class FormatterPlugin6(FormatterPlugin):
        group_name = 'group3'

    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin1, FormatterPlugin2, FormatterPlugin3, FormatterPlugin4, FormatterPlugin5, FormatterPlugin6)