

# Generated at 2022-06-17 21:06:38.582765
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin
    from httpie.plugins.builtin import AutoURLEncodedFormatterPlugin
    from httpie.plugins.builtin import AutoHTMLFormatterPlugin
    from httpie.plugins.builtin import AutoImageFormatterPlugin
    from httpie.plugins.builtin import AutoPrettyOptionsPlugin

# Generated at 2022-06-17 21:06:40.415569
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:06:44.008714
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:06:46.826017
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:06:56.361978
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB, PluginC)

    assert plugin_manager.filter(PluginA) == [PluginA, PluginC]
    assert plugin_manager.filter(PluginB) == [PluginB]
    assert plugin_manager.filter(BasePlugin) == [PluginA, PluginB, PluginC]

# Generated at 2022-06-17 21:07:06.936802
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    class PluginD(PluginB):
        pass

    class PluginE(PluginC):
        pass

    class PluginF(PluginD):
        pass

    class PluginG(PluginE):
        pass

    class PluginH(PluginF):
        pass

    class PluginI(PluginG):
        pass

    class PluginJ(PluginH):
        pass

    class PluginK(PluginI):
        pass

    class PluginL(PluginJ):
        pass

    class PluginM(PluginK):
        pass

    class PluginN(PluginL):
        pass

    class PluginO(PluginM):
        pass

    class PluginP(PluginN):
        pass


# Generated at 2022-06-17 21:07:17.155752
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:07:27.811228
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:07:34.191280
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
    }


# Generated at 2022-06-17 21:07:38.094096
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:07:42.825877
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:07:44.914496
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:07:47.748323
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:00.709991
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONPPFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import RawJSONRenderer
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedParser
    from httpie.plugins.builtin import KeyValue
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import KeyValueParser
    from httpie.plugins.builtin import NetrcAuth
    from httpie.plugins.builtin import OAuth1

# Generated at 2022-06-17 21:08:07.116383
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import DefaultFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin

# Generated at 2022-06-17 21:08:09.127870
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:11.074077
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:18.252707
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]


# Generated at 2022-06-17 21:08:24.743831
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import HTTPFormatterPlugin, PrettyHTTPFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawHTTPFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, RedirectFormatterPlugin
    from httpie.plugins.builtin import FormFormatterPlugin, BodyFormatterPlugin
    from httpie.plugins.builtin import AssertJSONFormatterPlugin, AssertFormatterPlugin
    from httpie.plugins.builtin import AssertHeaderFormatterPlugin, AssertHeaderJSONFormatterPlugin
    from httpie.plugins.builtin import AssertStatusFormatterPlugin, AssertStatusJSONForm

# Generated at 2022-06-17 21:08:34.464051
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import DevNullFormatterPlugin
    from httpie.plugins.builtin import NullFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin

# Generated at 2022-06-17 21:08:40.167939
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:08:44.416134
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()


# Generated at 2022-06-17 21:08:53.350645
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPNTLMAuth
    from httpie.plugins.builtin import HTTPOAuth1
    from httpie.plugins.builtin import HTTPOAuth2
    from httpie.plugins.builtin import HTTPAWSAuth
    from httpie.plugins.builtin import HTTPHawkAuth
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 21:09:03.762391
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D:
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(D):
        pass

    class I(D):
        pass

    class J(D):
        pass

    class K(D):
        pass

    class L(D):
        pass

    class M(D):
        pass

    class N(D):
        pass

    class O(D):
        pass

    class P(D):
        pass

    class Q(D):
        pass

    class R(D):
        pass

    class S(D):
        pass

    class T(D):
        pass


# Generated at 2022-06-17 21:09:06.211453
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}

# Generated at 2022-06-17 21:09:09.125927
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:20.154284
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E: pass
    class F(E): pass
    class G(E): pass
    class H(F, G): pass
    class I: pass
    class J(I): pass
    class K(I): pass
    class L(J, K): pass
    class M(L): pass
    class N(M): pass
    class O(N): pass
    class P(O): pass
    class Q(P): pass
    class R(Q): pass
    class S(R): pass
    class T(S): pass
    class U(T): pass
    class V(U): pass
    class W(V): pass
    class X(W): pass
    class Y(X): pass

# Generated at 2022-06-17 21:09:27.134948
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-17 21:09:36.668162
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:09:42.472569
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:09:52.658712
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:56.020693
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:02.353071
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:10.305508
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E, F)
    assert pm.filter(A) == [A, B, C, D, E, F]
    assert pm.filter(B) == [B, D]
    assert pm.filter(C) == [C, E]
    assert pm.filter(D) == [D]
    assert pm.filter(E) == [E]
    assert pm.filter(F) == [F]



# Generated at 2022-06-17 21:10:12.353719
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:10:23.020686
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins

# Generated at 2022-06-17 21:10:24.927214
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:25.792968
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter() == []


# Generated at 2022-06-17 21:10:32.502750
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:38.084927
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin,
        'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin,
    }


# Generated at 2022-06-17 21:10:58.092229
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-17 21:10:59.389181
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

# Generated at 2022-06-17 21:11:06.704913
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0

# Generated at 2022-06-17 21:11:13.758889
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:11:18.469305
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in auth_plugin_mapping
    assert 'digest' in auth_plugin_mapping
    assert 'aws4' in auth_plugin_mapping
    assert 'aws4-hmac-sha256' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-signed-headers' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-unsigned-payload' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-unsigned-headers' in auth_plugin_mapping

# Generated at 2022-06-17 21:11:24.791162
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': httpie.plugins.auth.basic_auth.BasicAuthPlugin, 'digest': httpie.plugins.auth.digest_auth.DigestAuthPlugin, 'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin, 'jwt': httpie.plugins.auth.jwt.JWTAuthPlugin, 'oauth1': httpie.plugins.auth.oauth1.OAuth1Plugin, 'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin}


# Generated at 2022-06-17 21:11:30.248358
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:11:37.773797
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import MultipartFormatter
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieSession
    from httpie.plugins.builtin import HTTPieStream
    from httpie.plugins.builtin import HTTPieFileUpload

# Generated at 2022-06-17 21:11:46.014581
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin

    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin2(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin3(FormatterPlugin):
        group_name = 'test2'

    pm = PluginManager()
    pm.register(JSONFormatterPlugin, URLEncodedFormatterPlugin, TestFormatterPlugin, TestFormatterPlugin2, TestFormatterPlugin3)

# Generated at 2022-06-17 21:11:53.949601
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:12:26.650939
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:12:32.447400
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin

    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin2(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin3(FormatterPlugin):
        group_name = 'test2'

    class TestFormatterPlugin4(FormatterPlugin):
        group_name = 'test2'

    class TestFormatterPlugin5(FormatterPlugin):
        group_name = 'test2'

    plugin

# Generated at 2022-06-17 21:12:43.340522
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(B):
        pass
    class F(C):
        pass
    class G(C):
        pass
    class H(D):
        pass
    class I(D):
        pass
    class J(E):
        pass
    class K(E):
        pass
    class L(F):
        pass
    class M(F):
        pass
    class N(G):
        pass
    class O(G):
        pass
    class P(H):
        pass
    class Q(H):
        pass
    class R(I):
        pass
    class S(I):
        pass
    class T(J):
        pass
   

# Generated at 2022-06-17 21:12:49.383346
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin
    from httpie.plugins.builtin import AutoURLEncodedFormatterPlugin
    from httpie.plugins.builtin import AutoHTMLFormatterPlugin
    from httpie.plugins.builtin import AutoImageFormatterPlugin
    from httpie.plugins.builtin import AutoPrettyOptionsPlugin

# Generated at 2022-06-17 21:12:52.576628
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:55.719847
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:13:02.182887
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:13:12.667064
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, JSONLinesFormatterPlugin
    from httpie.plugins.builtin import HeadersInOutputFormatterPlugin, \
        HeadersInOutputJSONFormatterPlugin, HeadersInOutputJSONLinesFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, \
        StreamJSONFormatterPlugin, StreamJSONLinesFormatterPlugin
    from httpie.plugins.builtin import FormURLEncodedFormatterPlugin
    from httpie.plugins.builtin import ColoredStreamFormatterPlugin, \
        ColoredStreamJSONFormatterPlugin, ColoredStreamJSONLinesFormatterPlugin
    from httpie.plugins.builtin import PrettyColoredStreamFormatterPlugin, \
        PrettyColored

# Generated at 2022-06-17 21:13:23.566674
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter, PrettyJSONFormatter
    from httpie.plugins.builtin import JSONConverter, URLEncodedConverter
    from httpie.plugins.builtin import HTTPieTransport
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPTokenAuth, JSONFormatter, PrettyJSONFormatter, JSONConverter, URLEncodedConverter, HTTPieTransport)
    assert plugin_manager.filter(AuthPlugin) == [HTTPBasicAuth, HTTPTokenAuth]
    assert plugin_manager.filter(FormatterPlugin) == [JSONFormatter, PrettyJSONFormatter]

# Generated at 2022-06-17 21:13:33.070787
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin
    from httpie.plugins.builtin import AutoURLEncodedFormatterPlugin
    from httpie.plugins.builtin import AutoHTMLFormatterPlugin
    from httpie.plugins.builtin import AutoImageFormatterPlugin
    from httpie.plugins.builtin import AutoPrettyOptionsPlugin

# Generated at 2022-06-17 21:14:50.154209
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:14:55.128542
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.load_installed_plugins()

# Generated at 2022-06-17 21:15:05.194891
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import MultipartFormatter
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import ImageFormatter
    from httpie.plugins.builtin import TableFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import URLEncodedConverter

# Generated at 2022-06-17 21:15:15.167594
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F:
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:15:22.918737
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:15:33.907272
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:15:44.072585
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:15:48.233185
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

# Generated at 2022-06-17 21:16:00.052512
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:16:09.294892
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   