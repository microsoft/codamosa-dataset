

# Generated at 2022-06-17 21:06:40.337545
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]
    assert plugin_manager.filter(BasePlugin) == [AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin]


# Generated at 2022-06-17 21:06:42.937430
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}

# Generated at 2022-06-17 21:06:47.479086
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2)
    assert plugin_manager.get_auth_plugin_mapping() == {'plugin1': Plugin1, 'plugin2': Plugin2}


# Generated at 2022-06-17 21:06:59.440450
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.builtin import AssertJSONFormatterPlugin, AssertFormatterPlugin
    from httpie.plugins.builtin import DebugFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import AutoJSONFormatterPlugin
    from httpie.plugins.builtin import DevNullFormatterPlugin
    from httpie.plugins.builtin import RedirectFormatterPlugin
    from httpie.plugins.builtin import DownloadFormatter

# Generated at 2022-06-17 21:07:07.981492
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:07:17.469610
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin, RawJSONFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, CSVFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, JSONLinesFormatterPlugin
    from httpie.plugins.builtin import ServerSentEventsFormatterPlugin
    from httpie.plugins.builtin import OneDarkFormatterPlugin, SolarizedFormatterPlugin
    from httpie.plugins.builtin import MonokaiFormatterPlugin, DraculaFormatterPlugin
    from httpie.plugins.builtin import DefaultFormatterPlugin, PygmentsFormatterPlugin

# Generated at 2022-06-17 21:07:23.641482
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin, RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, HTMLFormatterPlugin, CSVFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, StreamFormatterPlugin, JSONStreamFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, RedirectFormatterPlugin, DownloadFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, BodyFormatterPlugin, VerboseFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin, FormattersHelp

# Generated at 2022-06-17 21:07:33.469359
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:07:39.951904
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(C):
        pass
    class F(D):
        pass
    class G(E):
        pass
    class H(F):
        pass
    class I(G):
        pass
    class J(H):
        pass
    class K(I):
        pass
    class L(J):
        pass
    class M(K):
        pass
    class N(L):
        pass
    class O(M):
        pass
    class P(N):
        pass
    class Q(O):
        pass
    class R(P):
        pass
    class S(Q):
        pass
    class T(R):
        pass
   

# Generated at 2022-06-17 21:07:51.415696
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:08:04.098764
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(C): pass
    class F(D, E): pass
    class G(F): pass
    class H: pass
    class I(H): pass
    class J(I): pass
    class K(J): pass
    class L(K): pass
    class M(L): pass
    class N(M): pass
    class O(N): pass
    class P(O): pass
    class Q(P): pass
    class R(Q): pass
    class S(R): pass
    class T(S): pass
    class U(T): pass
    class V(U): pass
    class W(V): pass
    class X(W): pass
    class Y(X): pass
   

# Generated at 2022-06-17 21:08:06.838965
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:08:15.809979
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import DefaultFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin

# Generated at 2022-06-17 21:08:18.143343
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-17 21:08:24.689546
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin

# Generated at 2022-06-17 21:08:34.437038
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F:
        pass

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass

    class L(K):
        pass

    class M(L):
        pass

    class N(M):
        pass

    class O(N):
        pass

    class P(O):
        pass

    class Q(P):
        pass

    class R(Q):
        pass

    class S(R):
        pass

    class T(S):
        pass


# Generated at 2022-06-17 21:08:43.993727
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:08:50.518043
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:09:00.129618
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    manager = PluginManager()
    manager.register(Plugin1, Plugin2, Plugin3, Plugin4)

    assert manager.filter(Plugin1) == [Plugin1, Plugin3]
    assert manager.filter(Plugin2) == [Plugin2, Plugin4]
    assert manager.filter(BasePlugin) == [Plugin1, Plugin2, Plugin3, Plugin4]

# Generated at 2022-06-17 21:09:04.153097
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in auth_plugin_mapping
    assert 'digest' in auth_plugin_mapping
    assert 'aws4' in auth_plugin_mapping
    assert 'aws4-hmac-sha256' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-signed-headers' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-unsigned-payload' in auth_plugin_mapping
    assert 'aws4-hmac-sha256-unsigned-headers' in auth_plugin_mapping

# Generated at 2022-06-17 21:09:16.612391
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E(D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, B, C, D, E]
    assert pm.filter(B) == [B, D, E]
    assert pm.filter(C) == [C, D, E]
    assert pm.filter(D) == [D, E]
    assert pm.filter(E) == [E]

# Generated at 2022-06-17 21:09:19.294264
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager.get_auth_plugin_mapping(), dict)


# Generated at 2022-06-17 21:09:28.421775
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D:
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(E,F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:09:30.223813
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:09:40.113666
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Test filter by type
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]
    # Test filter by default type
    assert plugin_manager.filter() == [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]


# Generated at 2022-06-17 21:09:47.298416
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import KeyValueConverter
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieSSLPlugin
    from httpie.plugins.builtin import HTTPieUnixSocketPlugin
    from httpie.plugins.builtin import HTTPieUnixSocketSSLPlugin
    from httpie.plugins.builtin import HTTPieUnixSocketHTTPPlugin
    from httpie.plugins.builtin import HTTPieUnixSocketHTTPSPlugin
    from httpie.plugins.builtin import HTTPieUnixSocket

# Generated at 2022-06-17 21:09:58.521647
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D:
        pass

    class E(D):
        pass

    class F(D):
        pass

    pm = PluginManager()
    pm.register(B, C, E, F)
    assert pm.filter(A) == [B, C]
    assert pm.filter(D) == [E, F]
    assert pm.filter(E) == [E]
    assert pm.filter(F) == [F]

# Generated at 2022-06-17 21:10:01.114536
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:10:09.981101
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin, RawJSONFormatterPlugin, HeadersFormatterPlugin, \
        HTMLFormatterPlugin, PrettyOptionsFormatterPlugin, TableFormatterPlugin, \
        CSVFormatterPlugin, JSONLinesFormatterPlugin, ImageFormatterPlugin, \
        StreamFormatterPlugin, FileUploadFormatterPlugin, FileDownloadFormatterPlugin, \
        FormFormatterPlugin, RedirectFormatterPlugin, ErrorFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:16.604297
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:10:34.010021
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:10:41.530125
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import RawURLEncodedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import PrettyTableFormatterPlugin
    from httpie.plugins.builtin import RawTableFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import PrettyHTMLFormatterPlugin

# Generated at 2022-06-17 21:10:45.741947
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    assert len(plugin_manager.get_auth_plugin_mapping()) == 4

# Generated at 2022-06-17 21:10:52.775307
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, PrettyJSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PrettyTableFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawJSONLinesFormatterPlugin
    from httpie.plugins.builtin import RawTableFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, PrettyHeadersFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, PrettyHTMLFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:10:58.348961
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import MultipartFormatter
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import HeadersFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawURLEncodedFormatter
    from httpie.plugins.builtin import RawMultipartFormatter
    from httpie.plugins.builtin import RawKeyValueForm

# Generated at 2022-06-17 21:11:09.432670
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin, \
        URLEncodedFormatterPlugin
    from httpie.plugins.builtin import JSONConverterPlugin, URLEncodedConverterPlugin
    from httpie.plugins.builtin import HTTPiePlugin, HTTPieTransportPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import FormatterPlugin, ConverterPlugin, TransportPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyJSONFormatterPlugin, URLEncodedFormatterPlugin,
                            JSONConverterPlugin, URLEncodedConverterPlugin,
                            HTTPiePlugin, HTTPieTransportPlugin,
                            AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    plugin_manager

# Generated at 2022-06-17 21:11:11.202703
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:15.441864
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:17.366838
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:11:27.949078
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)

# Generated at 2022-06-17 21:11:48.018552
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    class E(D):
        pass
    class F:
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass

# Generated at 2022-06-17 21:11:52.135772
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:02.748372
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(AuthPlugin)
    plugin_

# Generated at 2022-06-17 21:12:12.863722
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:12:14.554200
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-17 21:12:18.665296
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:12:26.473451
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['basic'] == BasicAuthPlugin
    assert auth_plugin_mapping['digest'] == DigestAuthPlugin
    assert auth_plugin_mapping['hawk'] == HawkAuthPlugin
    assert auth_plugin_mapping['ntlm'] == NTLMAuthPlugin
    assert auth_plugin_mapping['oauth1'] == OAuth1AuthPlugin
    assert auth_plugin_mapping['oauth2'] == OAuth2AuthPlugin

# Generated at 2022-06-17 21:12:32.637909
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import JUnitFormatterPlugin

# Generated at 2022-06-17 21:12:39.974953
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:12:41.675531
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-17 21:13:26.430240
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import DevNullFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:13:33.497118
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONStreamFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin

    plugins = PluginManager()
    plugins.register(JSONFormatterPlugin, JSONStreamFormatterPlugin, TableFormatterPlugin, PrettyOptionsPlugin)
    assert plugins.get_formatters_grouped() == {
        'format': [JSONFormatterPlugin, JSONStreamFormatterPlugin, TableFormatterPlugin],
        'options': [PrettyOptionsPlugin]
    }

# Generated at 2022-06-17 21:13:40.121980
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, PrettyJSONLinesFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, PrettyRawJSONFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PrettyTableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin, PrettyURLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, PrettyHTMLFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin, PrettyCSVFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin, PrettyImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, PrettyStreamForm

# Generated at 2022-06-17 21:13:49.732670
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-17 21:14:02.353783
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import XMLEncodedFormatterPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import FileFormatterPlugin
    from httpie.plugins.builtin import PrettyFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin

# Generated at 2022-06-17 21:14:12.532622
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin, PrettyURLEncodedFormatterPlugin

    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin2(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin3(FormatterPlugin):
        group_name = 'test2'

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:14:21.809108
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    class E:
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass
    class R(Q):
        pass
    class S(R):
        pass
    class T(S):
        pass
   

# Generated at 2022-06-17 21:14:28.084868
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(Plugin1):
        pass

    class Plugin4(Plugin2):
        pass

    class Plugin5(Plugin3):
        pass

    class Plugin6(Plugin4):
        pass

    class Plugin7(Plugin5):
        pass

    class Plugin8(Plugin6):
        pass

    class Plugin9(Plugin7):
        pass

    class Plugin10(Plugin8):
        pass

    class Plugin11(Plugin9):
        pass

    class Plugin12(Plugin10):
        pass

    class Plugin13(Plugin11):
        pass

    class Plugin14(Plugin12):
        pass

    class Plugin15(Plugin13):
        pass

    class Plugin16(Plugin14):
        pass


# Generated at 2022-06-17 21:14:38.388050
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': httpie.plugins.auth.basic.BasicAuthPlugin, 'digest': httpie.plugins.auth.digest.DigestAuthPlugin, 'hawk': httpie.plugins.auth.hawk.HawkAuthPlugin, 'ntlm': httpie.plugins.auth.ntlm.NTLMAuthPlugin, 'oauth1': httpie.plugins.auth.oauth1.OAuth1AuthPlugin, 'oauth2': httpie.plugins.auth.oauth2.OAuth2AuthPlugin}


# Generated at 2022-06-17 21:14:43.505082
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin, PrettyJSONLinesFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin, PrettyTableFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawJSONLinesFormatterPlugin
    from httpie.plugins.builtin import RawTableFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin, BodyFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    from httpie.plugins.builtin import FormURLEncodedFormatterPlugin
    from httpie.plugins.builtin import MultipartFormatterPlugin

    plugin_manager = PluginManager()

# Generated at 2022-06-17 21:16:10.067909
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin, RawFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin, TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HeadersFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    from httpie.plugins.builtin import JUnitFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin
    from httpie.plugins.builtin import MarkdownFormatterPlugin
    from httpie.plugins.builtin import PygmentsFormatterPlugin
    from httpie.plugins.builtin import Terminal

# Generated at 2022-06-17 21:16:20.821000
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import RawJsonFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import XmlFormatterPlugin
    from httpie.plugins.builtin import XmlPrettyFormatterPlugin
    from httpie.plugins.builtin import XmlRawFormatterPlugin
    from httpie.plugins.builtin import JsonLinesFormatterPlugin
    from httpie.plugins.builtin import JsonLinesPrettyFormatterPlugin
    from httpie.plugins.builtin import JsonLinesRawFormatterPlugin
    from httpie.plugins.builtin import HtmlFormatterPlugin

# Generated at 2022-06-17 21:16:27.043503
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-17 21:16:27.866406
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-17 21:16:35.935578
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin

    class Plugin1(BasePlugin):
        pass

    class Plugin2(AuthPlugin):
        pass

    class Plugin3(ConverterPlugin):
        pass

    class Plugin4(FormatterPlugin):
        pass

    class Plugin5(TransportPlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2, Plugin3, Plugin4, Plugin5)

    assert plugin_manager.filter(BasePlugin) == [Plugin1, Plugin2, Plugin3, Plugin4, Plugin5]
    assert plugin_manager.filter(AuthPlugin) == [Plugin2]
    assert plugin_manager.filter(ConverterPlugin) == [Plugin3]
    assert plugin_manager