

# Generated at 2022-06-23 19:50:57.621391
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()

    class Dummy_Plugin1:
        pass

    class Dummy_Plugin2:
        pass

    manager.__init__([Dummy_Plugin1, Dummy_Plugin2])
    assert manager.get_transport_plugins() == []


PLUGIN_MANAGER = PluginManager()
PLUGIN_MANAGER.load_installed_plugins()

# Generated at 2022-06-23 19:50:58.990564
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert len(PluginManager()) > 0

# Generated at 2022-06-23 19:51:04.031918
# Unit test for method get_transport_plugins of class PluginManager

# Generated at 2022-06-23 19:51:10.157066
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class A(FormatterPlugin):
        group_name = 'a'
    class B(FormatterPlugin):
        group_name = 'a'
    class C(FormatterPlugin):
        group_name = 'c'
    class D(FormatterPlugin):
        group_name = 'd'
    plugins = PluginManager()
    plugins.register(A, B, C, D)
    assert plugins.get_formatters_grouped() == {'a': [A, B], 'c': [C], 'd': [D]}

# Generated at 2022-06-23 19:51:15.454110
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():

    plugin_manager = PluginManager()
    assert plugin_manager.get_converters() == []

    class FakeConverter(ConverterPlugin):
        pass

    plugin_manager.register(FakeConverter)

    assert plugin_manager.get_converters() == [FakeConverter]


# Generated at 2022-06-23 19:51:18.286784
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm)


if __name__ == "__main__":
    test_PluginManager()

# Generated at 2022-06-23 19:51:25.999352
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.append(AuthPlugin)
    plugin_manager.append(ConverterPlugin)
    plugin_manager.append(FormatterPlugin)
    plugin_manager.append(TransportPlugin)
    plugin_manager.append(ConverterPlugin)
    converter_plugins = plugin_manager.get_converters()
    assert len(converter_plugins) == 2
    assert converter_plugins[0] == ConverterPlugin
    assert converter_plugins[1] == ConverterPlugin


# Generated at 2022-06-23 19:51:28.558296
# Unit test for constructor of class PluginManager
def test_PluginManager():
    my_plugin_manager = PluginManager()

# test for registering

# Generated at 2022-06-23 19:51:31.805343
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import AuthBasicPlugin

    instance = PluginManager()
    instance.register(AuthBasicPlugin)
    result = instance.get_auth_plugins()
    assert issubclass(result[0], AuthPlugin)
    assert result[0] == AuthBasicPlugin


# Generated at 2022-06-23 19:51:34.548170
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(HTTPBasicAuth)
    assert manager.get_auth_plugin('basic') is HTTPBasicAuth
    assert manager.get_auth_plugin('digest') is None


# Generated at 2022-06-23 19:51:38.157557
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    import json
    import httpie.plugins
    manager = httpie.plugins.manager
    manager.unregister(httpie.plugins.JSONConverterPlugin)
    assert json not in manager.get_converters()
    class NewJSONConverterPlugin: pass
    manager.register(NewJSONConverterPlugin)
    assert NewJSONConverterPlugin in manager.get_converters()

manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-23 19:51:39.464126
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert PluginManager().get_auth_plugin('basic')



# Generated at 2022-06-23 19:51:43.538386
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
	e = PluginManager()
	assert e.get_transport_plugins() == [], "Failed test_PluginManager_get_transport_plugins"




# Entry points
# ============

_plugin_manager = PluginManager()



# Generated at 2022-06-23 19:51:45.014089
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = [VerifySSLPlugin, HTTPiePlugin]
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)
    assert plugin_manager.get_transport_plugins() == plugins



# Generated at 2022-06-23 19:51:52.142018
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_plugins = PluginManager().get_auth_plugin_mapping()
    assert 'basic' in auth_plugins
    assert 'digest' in auth_plugins
    assert 'hawk' in auth_plugins
    assert 'aws4-hmac-sha256' in auth_plugins
    assert 'bearer' in auth_plugins


# Generated at 2022-06-23 19:51:53.723555
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    assert list(pm.get_auth_plugins()) == []
    pm.register(HTTPBasicAuth)
    assert pm.get_auth_plugins() == [HTTPBasicAuth]


# Generated at 2022-06-23 19:51:56.423961
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.formatter.v1 import FormatterPlugin
    plugins = PluginManager()
    assert plugins.filter(by_type=FormatterPlugin) == []

# Generated at 2022-06-23 19:52:01.183904
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

    pm.load_installed_plugins()
    assert len(pm) > 4


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:52:04.668784
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    transport_plugins = plugin_manager.get_transport_plugins()
    assert len(transport_plugins) != 0
    assert 'httpie.plugins.http2:HTTP2Adapter' in str(transport_plugins)



# Generated at 2022-06-23 19:52:13.670192
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group1'
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group2'
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
        group_order = 1
    manager = PluginManager()

# Generated at 2022-06-23 19:52:19.302651
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(list(plugin_manager.get_auth_plugins()))==3
    assert len(list(plugin_manager.get_transport_plugins()))==1
    assert len(list(plugin_manager.get_formatters()))==1
    assert len(list(plugin_manager.get_converters()))==1
    
    


# Generated at 2022-06-23 19:52:21.186288
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginManager = PluginManager()
    expected_output = []
    assert pluginManager.get_auth_plugins() == expected_output



# Generated at 2022-06-23 19:52:22.422092
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()



# Generated at 2022-06-23 19:52:30.997114
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # plugin class definition
    class test_plugin1(TransportPlugin):
        pass
    class test_plugin2(TransportPlugin):
        pass
    class test_plugin3(TransportPlugin):
        pass
    # test
    plugin_manager = PluginManager()
    # test plugins registered
    plugin_manager.register(test_plugin1, test_plugin2, test_plugin3)
    assert plugin_manager.get_transport_plugins() == [test_plugin1, test_plugin2, test_plugin3]
    # test plugins unregistered
    plugin_manager.unregister(test_plugin2)
    assert plugin_manager.get_transport_plugins() == [test_plugin1, test_plugin3]
    # test plugins registered then unregistered
    plugin_manager.register(test_plugin2)
    plugin_manager.un

# Generated at 2022-06-23 19:52:32.817549
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    # TODO: Need add mock data
    print(pm.get_formatters_grouped())
    assert True

# Generated at 2022-06-23 19:52:35.602882
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import builtin
    plugin_manager = PluginManager()
    plugin_manager.register(builtin.HTTPBasicAuthPlugin)
    auth_plugin = plugin_manager.get_auth_plugin('basic')
    assert isinstance(auth_plugin, builtin.HTTPBasicAuthPlugin)

# Generated at 2022-06-23 19:52:46.124743
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.aws import AWSv4AuthPlugin
    from httpie.plugins.auth.hawk import HawkAuthPlugin
    from httpie.plugins.auth.aws import AWSv2AuthPlugin
    from httpie.plugins.auth.ntlm import NTLMAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1AuthPlugin
    from httpie.plugins.auth.oauth2 import OAuth2AuthPlugin
    from httpie.plugins.auth.multipart import MultipartAuthPlugin

    pm = PluginManager()
    pm.load_installed_plugins()


# Generated at 2022-06-23 19:52:48.163150
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert plugin_manager.get_converters() == []


# Generated at 2022-06-23 19:52:57.320988
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    pluginManager.register(BasePlugin)
    assert pluginManager.__str__() == '[<class \'httpie.plugins.base.BasePlugin\'>]'

    # Test register(), unregister()
    pluginManager.register(AuthPlugin)
    assert pluginManager.__str__() == '[<class \'httpie.plugins.base.BasePlugin\'>, <class \'httpie.plugins.auth.AuthPlugin\'>]'
    pluginManager.unregister(BasePlugin)
    assert pluginManager.__str__() == '[<class \'httpie.plugins.auth.AuthPlugin\'>]'

    # Test filter()
    assert pluginManager.filter(AuthPlugin) == [AuthPlugin]
    assert pluginManager.filter(TransportPlugin) == []

    # Test get_auth_plugins(), get_auth_plugin_mapping(), get_

# Generated at 2022-06-23 19:53:00.355032
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert pm == []
    pm.register(type("test_plugin", (BasePlugin,), {}))
    assert pm == [type("test_plugin", (BasePlugin,), {})]


# Generated at 2022-06-23 19:53:12.355702
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.auth.builtin import BasicAuthPlugin
    from httpie.plugins.auth.builtin import DigestAuthPlugin
    from httpie.plugins.auth.builtin import HawkAuthPlugin
    from httpie.plugins.auth.builtin import OAuth1Plugin
    from httpie.plugins.auth.builtin import OAuth2Plugin
    from httpie.plugins.auth.builtin import OIDCAuthPlugin

    # Variable user_input.
    user_input_1 = 'basic'
    user_input_2 = 'digest'
    user_input_3 = 'hawk'
    user_input_4 = 'oauth1'
    user_input_5 = 'oauth2'
    user_input_6 = 'oauth'
    user_input_7 = 'oidc'

# Generated at 2022-06-23 19:53:21.391970
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters()
    assert len(formatters) == 4
    assert formatters[0].name == "json"
    assert formatters[1].name == "jsonl"
    assert formatters[2].name == "table"
    assert formatters[3].name == "html"
    assert formatters[0].group_name == "format_group"
    assert formatters[1].group_name == "format_group"
    assert formatters[2].group_name == "format_group"
    assert formatters[3].group_name == "format_group"


# Generated at 2022-06-23 19:53:28.311724
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    test_manager = PluginManager()
    class TestPluginAuth(AuthPlugin):
        auth_type = 'test_plugin_auth'
    test_manager.register(TestPluginAuth)
    assert test_manager.get_auth_plugin(TestPluginAuth.auth_type) == TestPluginAuth
    assert test_manager.get_auth_plugin_mapping() == {TestPluginAuth.auth_type: TestPluginAuth}


# Generated at 2022-06-23 19:53:34.519782
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    print("Executing unregister test")
    manager = PluginManager()
    assert manager.unregister(AuthPlugin) == None
    assert manager.unregister(FormatterPlugin) == None
    assert manager.unregister(ConverterPlugin) == None
    assert manager.unregister(TransportPlugin) == None
    assert manager.unregister(BasePlugin) == None
    assert manager == []
    print("Test completed successfully")


# Generated at 2022-06-23 19:53:41.574445
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F:
        pass

    manager = PluginManager()
    manager.register(A, B, C, D, E, F)
    assert manager.filter(by_type=A) == [A, B, C, D, E]
    assert manager.filter(by_type=C) == [C, D]

# Generated at 2022-06-23 19:53:47.292650
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert [type(plugin) for plugin in plugins.get_converters()] == [
        httpie_json.Json,
        httpie_json_pprint.JsonPPrint,
        httpie_prettyjson.PrettyJson,
        httpie_prettyjson_html.PrettyJsonHtml,
        httpie_xml.Xml,
    ]

# Generated at 2022-06-23 19:53:50.249168
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class TestPlugin(BasePlugin):
        pass
    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin)
    plugin_manager.unregister(TestPlugin)
    assert TestPlugin not in plugin_manager
    print("PluginManager.unregister method works")


# Generated at 2022-06-23 19:53:54.309207
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    mng = PluginManager()
    assert mng == []
    mng.register(BasePlugin, BasePlugin)
    assert mng == [BasePlugin, BasePlugin]
    mng.register(TransportPlugin)
    assert mng == [BasePlugin, BasePlugin, TransportPlugin]


# Generated at 2022-06-23 19:54:05.156240
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p=PluginManager()
    p.append(httpie.plugins.httpie.auth.httpie_auth.HTTPBasicAuth)
    p.append(httpie.plugins.httpie.auth.httpie_auth.HTTPTokenAuth)
    p.append(httpie.plugins.httpie.auth.httpie_auth.HTTPDigestAuth)
    p.append(httpie.plugins.httpie.auth.httpie_auth.HTTPAuthPlugin)
    p.append(httpie.plugins.httpie.auth.httpie_auth.NetrcAuth)
    p.append(httpie.plugins.httpie.auth.httpie_auth.AuthPlugin)
    p.append(httpie.plugins.httpie.formatter.colors.ColorsFormatter)

# Generated at 2022-06-23 19:54:07.599086
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print(plugins.get_transport_plugins())


# Generated at 2022-06-23 19:54:11.074297
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(MockAuthPlugin, MockAuthPlugin2)

    plugin = manager.get_auth_plugin('mock')
    assert plugin == MockAuthPlugin

    with pytest.raises(KeyError):
        manager.get_auth_plugin('invalid_key')



# Generated at 2022-06-23 19:54:11.836532
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pass

# Generated at 2022-06-23 19:54:19.525447
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    for i in range(3):
        class AuthPlugin(BasePlugin):
            auth_type = str(i)
        plugin_manager.register(AuthPlugin)
    for i in range(3):
        auth_type = str(i)
        assert plugin_manager.get_auth_plugin(auth_type).auth_type == auth_type

PLUGIN_MANAGER = PluginManager()

# Generated at 2022-06-23 19:54:21.495712
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    plugin = manager.register()
    manager.unregister(plugin)
    assert list(manager) == []

# Generated at 2022-06-23 19:54:31.524851
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugins() == []

    class Auth1Plugin(AuthPlugin):
        auth_type = 'auth1'

    class Auth2Plugin(AuthPlugin):
        auth_type = 'auth2'

    class Format1Plugin(FormatterPlugin):
        format_name = 'format1'

    class Convert1Plugin(ConverterPlugin):
        convert_name = 'convert1'

    class Transport1Plugin(TransportPlugin):
        scheme = 'http'

    class Transport2Plugin(TransportPlugin):
        scheme = 'https'

    plugin_manager.register(Auth1Plugin, Auth2Plugin, Format1Plugin,
                            Convert1Plugin, Transport1Plugin, Transport2Plugin)

# Generated at 2022-06-23 19:54:33.562209
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert len(plugin_manager.get_auth_plugins()) == 1

# Generated at 2022-06-23 19:54:37.749710
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.extend([str, int])

    assert (pm.filter(str) == [str])
    assert (pm.filter(int) == [int])
    assert (pm.filter(by_type=str) == [str])
    assert (pm.filter(by_type=int) == [int])

# Generated at 2022-06-23 19:54:49.200374
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth import BasicAuthPlugin
    from httpie.plugins.auth import DigestAuthPlugin
    from httpie.plugins.auth import HawkAuthPlugin
    from httpie.plugins.auth import OAuth1AuthPlugin
    from httpie.plugins.auth import OAuth2AuthPlugin

    manager = PluginManager()
    manager.register(
        BasicAuthPlugin,
        DigestAuthPlugin,
        OAuth1AuthPlugin,
        OAuth2AuthPlugin,
        HawkAuthPlugin
    )

    expected_results = {
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin,
        'hawk': HawkAuthPlugin,
        'oauth1': OAuth1AuthPlugin,
        'oauth2': OAuth2AuthPlugin,
    }
    assert manager.get_auth_plugin_mapping() == expected_results

# Generated at 2022-06-23 19:54:58.849570
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.core import FormatterPlugin

    class Mock(FormatterPlugin):
        group_name = 'mock'

    class Mock2(FormatterPlugin):
        group_name = 'mock2'

    class Mock3(FormatterPlugin):
        group_name = 'mock3'

    pm = PluginManager()
    pm.register(Mock, Mock, Mock2, Mock2, Mock3)

    assert pm.get_formatters_grouped() == {
        'mock': [Mock, Mock],
        'mock2': [Mock2, Mock2],
        'mock3': [Mock3],
    }


# Generated at 2022-06-23 19:55:06.022795
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.sdk import plugin_manager
    from httpie.plugins import AuthPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import TransportPlugin
    test = [plugins for plugins in plugin_manager.filter(AuthPlugin)]
    test = [plugins for plugins in plugin_manager.filter(ConverterPlugin)]
    test = [plugins for plugins in plugin_manager.filter(FormatterPlugin)]
    test = [plugins for plugins in plugin_manager.filter(TransportPlugin)]


# Generated at 2022-06-23 19:55:09.632386
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_mapping = PluginManager().get_auth_plugin_mapping()
    assert auth_mapping.get('basic') is not None


# Generated at 2022-06-23 19:55:13.631108
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, FormatterPlugin)
    assert 2 == len(plugin_manager.get_auth_plugins())
    assert 1 == len(plugin_manager.get_formatters())

# Generated at 2022-06-23 19:55:19.129237
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from pkg_resources import iter_entry_points
    pm = PluginManager()
    entry_point_name = 'httpie.plugins.transport.v1'
    for entry_point in iter_entry_points(entry_point_name):
        plugin = entry_point.load()
        plugin.package_name = entry_point.dist.key
        pm.register(entry_point.load())
    assert(pm.__repr__() == '<PluginManager: [<class \'httpie_keepalive.KeepAliveAuthPlugin\'>]>')

# Generated at 2022-06-23 19:55:21.830481
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.append(Type[FormatterPlugin])
    plugin_manager.get_formatters_grouped()

# Generated at 2022-06-23 19:55:29.340982
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert manager.filter(AuthPlugin) == [AuthPlugin]
    assert manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert manager.filter(TransportPlugin) == [TransportPlugin]

    # Test for filter with class BasePlugin
    assert manager.filter(BasePlugin) == [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]

manager = PluginManager()

# Generated at 2022-06-23 19:55:33.302222
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class Plugin(FormatterPlugin):
        group_name = 'test_group'

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin)
    assert plugin_manager.get_formatters() == [Plugin]
    assert plugin_manager.get_formatters_grouped() == \
        {'test_group': [Plugin]}

# Generated at 2022-06-23 19:55:37.183397
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class PluginBase(BasePlugin):
        pass

    class PluginSub(PluginBase):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginBase, PluginSub)

    plugin_manager.unregister(PluginBase)

    assert isinstance(plugin_manager, PluginManager)
    assert issubclass(plugin_manager[0], PluginSub)

# Generated at 2022-06-23 19:55:43.567216
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin)
    pluginManager.register(TransportPlugin)
    pluginManager.register(ConverterPlugin)
    pluginManager.register(FormatterPlugin)
    print(pluginManager.get_auth_plugins())
    print(pluginManager.get_formatters())
    print(pluginManager.get_converters())
    print(pluginManager.get_transport_plugins())

test_PluginManager()

# Generated at 2022-06-23 19:55:45.546823
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    instance = PluginManager()
    assert len(instance) == 0
    instance.register(BasePlugin)
    assert len(instance) == 1


# Generated at 2022-06-23 19:55:48.099975
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'


plugins = PluginManager()

# Generated at 2022-06-23 19:55:51.954322
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    expected= [1,2]
    plugins = PluginManager()
    plugins.register(int, int)
    plugins.append(int)
    assert plugins == expected


# Generated at 2022-06-23 19:55:52.928015
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager = PluginManager()


# Generated at 2022-06-23 19:55:57.222195
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginManager = PluginManager()

    class Foo(BasePlugin):
        name = 'foo'
    
    class Bar(BasePlugin):
        name = 'bar'

    pluginManager.register(Foo,Bar)

    assert len(pluginManager) == 2
    pluginManager.unregister(Foo)
    assert len(pluginManager) == 1

# Generated at 2022-06-23 19:55:58.562026
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager.register()
    pm = PluginManager()



# Generated at 2022-06-23 19:56:01.162266
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    p = PluginManager()
    p.register(AuthPlugin)
    assert p.get_auth_plugin('basic') == type(AuthPlugin)


# Generated at 2022-06-23 19:56:04.625049
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin=BasePlugin()
    plugin_manager =PluginManager()
    plugin_manager.register(plugin)
    auth_plugin = list(plugin_manager.get_auth_plugins())
    assert type(auth_plugin) == list
    assert len(auth_plugin) == 1



# Generated at 2022-06-23 19:56:14.014608
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    import sys

    from pkg_resources import working_set
    from pytest import raises
    from requests.exceptions import InvalidSchema

    from httpie.plugins.manager import PluginManager

    # noinspection PyProtectedMember
    plugin_manager = PluginManager()

    # test empty
    assert len(plugin_manager) == 0

    # test with httpie.plugins.auth.v1 test entry point
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 1

    auth_plugin = plugin_manager.get_auth_plugin_mapping()['null']

    # noinspection PyProtectedMember
    assert auth_plugin.auth_type == 'null'

    auth = auth_plugin(None)
    auth.__init__()
    auth.init_auth_kwargs()


# Generated at 2022-06-23 19:56:16.029972
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    # print(manager)
    assert len(manager) >= 1

# Generated at 2022-06-23 19:56:19.929590
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.register(TransportPlugin)
    assert plugins.get_transport_plugins() == [TransportPlugin]

    class A(TransportPlugin):
        pass
    plugins.register(A)
    assert len(plugins.get_transport_plugins()) == 2

    class B:
        pass
    plugins.register(B)
    assert len(plugins.get_transport_plugins()) == 2


# Generated at 2022-06-23 19:56:23.786103
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    PLUGIN_MANAGER = PluginManager()
    PLUGIN_MANAGER.load_installed_plugins()

    print(PLUGIN_MANAGER.get_converters())

    assert False

# Generated at 2022-06-23 19:56:26.666869
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    list1=[]
    # Plugins.unregister(Plugin.instance())
    PluginManager.unregister(list1)
    print(list1)

test_PluginManager_unregister()

# Generated at 2022-06-23 19:56:30.610166
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    plugin_manager = PluginManager()
    assert (HTTPBasicAuth, HTTPTokenAuth) == tuple(plugin_manager.get_transport_plugins())

# Generated at 2022-06-23 19:56:38.295462
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    assert pm.get_auth_plugins() == []
    pm.register(type_mock)
    assert pm.get_auth_plugins() == []
    pm.register(auth_type_mock)
    assert pm.get_auth_plugins() == [auth_type_mock]
    pm.register(format_type_mock)
    assert pm.get_auth_plugins() == [auth_type_mock]


# Generated at 2022-06-23 19:56:50.474127
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Test case 1
    pluginmanager = PluginManager()
    assert pluginmanager.get_auth_plugin_mapping() == {}

    # Test case 2
    pluginmanager.register(AuthBasicPlugin, AuthDigestPlugin)
    assert pluginmanager.get_auth_plugin_mapping() == {'basic': AuthBasicPlugin, 'digest': AuthDigestPlugin}

    # Test case 3
    pluginmanager.append(AuthBasicPlugin)
    auth_mapping = pluginmanager.get_auth_plugin_mapping()
    assert pluginmanager[-1] == 'AuthBasicPlugin'
    assert auth_mapping['basic'] == 'AuthBasicPlugin'

    # Test case 4
    pluginmanager.remove(AuthBasicPlugin)
    auth_mapping = pluginmanager.get_auth_plugin_mapping()

# Generated at 2022-06-23 19:56:54.004039
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.register(BasePlugin)
    assert repr(plugins) == '<PluginManager: [<class \'httpie.plugins.base.BasePlugin\'>]>'

# Generated at 2022-06-23 19:56:58.914915
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class MockClass(BasePlugin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.group_name = 'mock'
    pm = PluginManager()
    pm.register(MockClass)
    assert MockClass in pm
    pm.unregister(MockClass)
    assert MockClass not in pm

# Generated at 2022-06-23 19:57:00.273686
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import KEY_VALUE
    assert PluginManager().get_converters() == [KEY_VALUE]

# Generated at 2022-06-23 19:57:10.291288
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Load plugin in PluginManager
    entry_point_name = 'httpie.plugins.auth.v1'
    parser = argparse.ArgumentParser()
    pm = PluginManager()
    assert len(pm) == 0
    plugins = []
    for entry_point in iter_entry_points(entry_point_name):
        plugin = entry_point.load()
        plugin.package_name = entry_point.dist.key
        plugins.append(plugin)
        pm.register(plugin)
    assert len(pm) == len(plugins)
    
    # Filter plugin by_type
    plugin_by_type = pm.filter(AuthPlugin)
    assert len(plugin_by_type) == len(plugins)

# Generated at 2022-06-23 19:57:12.985910
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(MockPlugin)
    assert manager.get_auth_plugin('mock_plugin') == MockPlugin


# Generated at 2022-06-23 19:57:16.562575
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    test_PluginManager = PluginManager()
    test_PluginManager.register(testPlugin)
    res = test_PluginManager.get_auth_plugins()
    assert res == [testPlugin]


# Generated at 2022-06-23 19:57:21.337674
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # arrange
    class TestPlugin(AuthPlugin):
        auth_type = 'test'
        description = 'Test'
        auth_parse = lambda self, arg_auth: None

    plugins = PluginManager()
    plugins.register(TestPlugin)

    # act
    result = plugins.get_auth_plugin('test')

    # assert
    assert result == TestPlugin

# Generated at 2022-06-23 19:57:28.737343
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    """
    测试PluginManager类中get_transport_plugins方法
    """
    from httpie.plugins.transport.http import HTTPTransportPlugin
    from httpie.plugins.transport.http2 import HTTP2TransportPlugin
    from httpie.plugins.transport.wsgi import WSGITransportPlugin
    from httpie.plugins.transport.urllib import Urllib2TransportPlugin
    from httpie.plugins.transport.pycurl import PycurlTransportPlugin

    manager = PluginManager()
    manager.register(HTTPTransportPlugin)
    manager.register(HTTP2TransportPlugin)
    manager.register(WSGITransportPlugin)
    manager.register(Urllib2TransportPlugin)
    manager.register(PycurlTransportPlugin)
    print

# Generated at 2022-06-23 19:57:35.561196
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(
        TestPlugin_class1, TestPlugin_class2, TestPlugin_class3
    )
    assert plugins.get_auth_plugin_mapping() == {
        'test_plugin_type1': TestPlugin_class1,
        'test_plugin_type2': TestPlugin_class2,
        'test_plugin_type3': TestPlugin_class3
    }


# Generated at 2022-06-23 19:57:39.718644
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    def test_PluginManager_get_converters():
        from httpie import plugins
        from httpie.plugins.converter import JSONConverter, XMLConverter
        # test for convert
        manager = PluginManager()
        assert set(manager.get_converters()) == set([JSONConverter, XMLConverter])

# Generated at 2022-06-23 19:57:40.572054
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    PluginManager().__repr__()


# Generated at 2022-06-23 19:57:43.991463
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    test_manager = PluginManager()
    from httpie.plugins.auth.basic import BasicAuthPlugin
    test_manager.register(BasicAuthPlugin)
    assert test_manager.get_auth_plugin('basic') == BasicAuthPlugin


# Generated at 2022-06-23 19:57:47.560687
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_mgr = PluginManager()
    plugin_mgr.load_installed_plugins()
    assert len(plugin_mgr.get_converters()) == 4
    assert (plugin_mgr.get_converters()[0].__name__ == 
            'RequestDataJSONV1')


# Generated at 2022-06-23 19:57:59.381044
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Initialize new object of class PluginManager
    PluginManager.plugins = PluginManager()
    # Fill plugins list with plugins
    PluginManager.plugins.register(
        auth_digest.DigestAuthPlugin,
        aws.AWSAuthPlugin,
        aws_sigv4.AWSSigv4AuthPlugin,
        basic.BasicAuthPlugin,
        digest.DigestAuthPlugin,
        hawk.HawkAuthPlugin,
        oauth1.OAuth1AuthPlugin,
        oauth2.OAuth2AuthPlugin,
        oauth2_password.OAuth2PasswordPlugin,
    )
    # Run and check method

# Generated at 2022-06-23 19:58:01.147080
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    assert len(pm) == 0

    # When
    pm.load_installed_plugins()

    # Then
    assert len(pm) > 0


# Generated at 2022-06-23 19:58:02.457356
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert True


# Generated at 2022-06-23 19:58:04.313600
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    assert plugins.get_formatters()


# Generated at 2022-06-23 19:58:13.715031
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    import sys
    sys.path.insert(0, '../httpie/plugins/converter/')
    from jmespath import JMESPathConverter
    from json_pygments import JSONPygmentsConverter

    pm = PluginManager()
    pm.register(JMESPathConverter, JSONPygmentsConverter)
    print(f'test_PluginManager_get_converters(): {list(pm.get_converters())}')
    assert list(pm.get_converters()) == [JMESPathConverter, JSONPygmentsConverter]


if __name__ == '__main__':
    test_PluginManager_get_converters()

# Generated at 2022-06-23 19:58:20.260248
# Unit test for method get_converters of class PluginManager

# Generated at 2022-06-23 19:58:21.988137
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    assert len(plugins.get_converters()) == 0

# Generated at 2022-06-23 19:58:31.114344
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class DummyPlugin(BasePlugin):
        def load(self):
            return DummyPlugin()

    DummyPlugin1 = DummyPlugin
    DummyPlugin2 = DummyPlugin
    DummyPlugin3 = DummyPlugin

    plugin1 = DummyPlugin1()
    plugin2 = DummyPlugin2()
    plugin3 = DummyPlugin3()
    plugins = PluginManager()
    plugins.register(plugin1, plugin2, plugin3)
    assert plugins[0] in [plugin1, plugin2, plugin3]
    assert plugins[1] in [plugin1, plugin2, plugin3]
    assert plugins[2] in [plugin1, plugin2, plugin3]
    assert len(plugins) == 3

    plugins.unregister(plugin1)
    assert plugins[0] in [plugin2, plugin3]

# Generated at 2022-06-23 19:58:33.461186
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    print(plugin_manager)

if __name__ == '__main__':
    test_PluginManager___repr__()

# Generated at 2022-06-23 19:58:36.515929
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    entries=['entry1', 'entry2', 'entry3']
    manager=PluginManager()
    manager.register(*entries)
    assert manager == ['entry1', 'entry2', 'entry3']
    manager.unregister('entry2')
    assert manager == ['entry1', 'entry3']



# Generated at 2022-06-23 19:58:43.911493
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    cmd = 'import pyperclip; pyperclip.copy(repr(plugin_manager.get_transport_plugins()))'
    os.system(f'python -c "{cmd}"')

if __name__ == '__main__':
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    cmd = 'import pyperclip; pyperclip.copy(repr(plugin_manager.get_transport_plugins()))'
    os.system(f'python -c "{cmd}"')

# Generated at 2022-06-23 19:58:49.619791
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class GroupA(FormatterPlugin): group_name = 'a'
    class GroupB(FormatterPlugin): group_name = 'b'
    class GroupA1(FormatterPlugin): group_name = 'a'
    class GroupA2(FormatterPlugin): group_name = 'a'

    plugin_manager = PluginManager()
    plugin_manager.register(GroupA, GroupB, GroupA1, GroupA2)

    assert plugin_manager.get_formatters_grouped() == {
        'a': [GroupA, GroupA1, GroupA2],
        'b': [GroupB],
    }


# Generated at 2022-06-23 19:58:52.255955
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import auth

    manager = PluginManager()
    manager.register(auth.BasicAuth)
    manager.register(auth.DigestAuth)
    manager.register(auth.ApiKeyAuth)
    assert manager.get_auth_plugins() == [auth.BasicAuth, auth.DigestAuth, auth.ApiKeyAuth]



# Generated at 2022-06-23 19:58:54.717277
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_transport_plugins()), 'list of transport plugins should not be empty'


# Generated at 2022-06-23 19:59:03.096633
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(type('JsonPlugin', (FormatterPlugin,), {'name': 'json'}))
    plugins.register(type('PrettyPlugin', (FormatterPlugin,), {'name': 'pretty'}))
    plugins.register(type('ExpandedPlugin', (FormatterPlugin,), {'name': 'expanded'}))
    plugins.register(type('LinePlugin', (TransportPlugin,), {}))
    plugins.register(type('FilePlugin', (TransportPlugin,), {}))

    formatter = plugins.get_formatters()
    assert len(formatter) == 3


# Generated at 2022-06-23 19:59:08.846882
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    assert plugins

    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key

            assert plugin in plugins

# Generated at 2022-06-23 19:59:11.945852
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm)
    print(pm.get_formatters())
    print(pm.get_converters())


if __name__ == '__main__':
    test_PluginManager_get_converters()

# Generated at 2022-06-23 19:59:13.968576
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(Type)
    assert Type in plugin_manager

    plugin_manager.unregister(Type)
    assert Type not in plugin_manager



# Generated at 2022-06-23 19:59:16.917548
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    return pm

pm = test_PluginManager_load_installed_plugins()

# Generated at 2022-06-23 19:59:19.627411
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugins()) == 5
    assert len(pm.get_formatters())== 6

# Generated at 2022-06-23 19:59:22.246530
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugins()


# Generated at 2022-06-23 19:59:28.264741
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.register(OAuth1Plugin, BasicAuthPlugin)
    assert plugins.get_auth_plugin_mapping() == {
        OAuth1Plugin.auth_type: OAuth1Plugin,
        BasicAuthPlugin.auth_type: BasicAuthPlugin,
    }
    assert plugins.get_auth_plugin(OAuth1Plugin.auth_type) == OAuth1Plugin
    assert plugins.get_auth_plugin(BasicAuthPlugin.auth_type) == BasicAuthPlugin

# Generated at 2022-06-23 19:59:32.175229
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import transport

    manager = PluginManager()
    manager.register(transport.TransportPlugin)
    manager.register(transport.TransportPlugin)

    assert len(manager.get_transport_plugins()) == 2

# Generated at 2022-06-23 19:59:33.773859
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()
    pm.get_converters()

# Generated at 2022-06-23 19:59:35.412317
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert plugins.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-23 19:59:38.003028
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == []


# Generated at 2022-06-23 19:59:40.623181
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    print(manager.get_auth_plugins())
    assert manager.get_auth_plugins()


# Generated at 2022-06-23 19:59:41.839865
# Unit test for constructor of class PluginManager
def test_PluginManager():
    instance = PluginManager()
    assert(instance == [])



# Generated at 2022-06-23 19:59:50.401381
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(
        FormatterPlugin("json", "application/json", "JSON formatter"),
        FormatterPlugin("json", "application/json", "Pretty JSON formatter"),
        FormatterPlugin("html", "application/json", "HTML formatter"),
        FormatterPlugin("html", "application/json", "Pretty HTML formatter"),
    )
    # Run method
    plugin_map = pm.get_formatters_grouped()
    # Assert
    assert len(plugin_map) == 2
    assert len(plugin_map.get("json")) == 2
    assert len(plugin_map.get("html")) == 2

# Generated at 2022-06-23 19:59:55.322079
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    class BasicAuthPlugin(AuthPlugin):
        auth_type = 'basic'
        auth_type_name = 'Basic'
    class DigestAuthPlugin(AuthPlugin):
        auth_type = 'digest'
        auth_type_name = 'Digest'
    pm.register(BasicAuthPlugin, DigestAuthPlugin)
    assert pm.get_auth_plugins() == [BasicAuthPlugin, DigestAuthPlugin]

# Generated at 2022-06-23 19:59:59.801905
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(TestPlugin1)
    pm.register(TestPlugin2)
    assert pm.get_auth_plugin_mapping() == {'type1': TestPlugin1, 'type2': TestPlugin2}

test_PluginManager_get_auth_plugin_mapping()


# Generated at 2022-06-23 20:00:01.844871
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 5

test_PluginManager_load_installed_plugins()

# Generated at 2022-06-23 20:00:03.098702
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert isinstance(pm, list)

# Generated at 2022-06-23 20:00:04.276242
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager().get_auth_plugins() == []


# Generated at 2022-06-23 20:00:06.647918
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    print(plugins.filter())


# This variable acts as a singleton
plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 20:00:08.202184
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    PluginManager.get_auth_plugins()
    PluginManager.get_auth_plugin('basic')


# Generated at 2022-06-23 20:00:12.470760
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Given: a new instance of class PluginManager is created
    pm = PluginManager()
    # When: the method load_installed_plugins is invoked on the instance
    pm.load_installed_plugins()
    # Then: the list of plugins is not empty after invoking
    assert len(pm) > 0

# Generated at 2022-06-23 20:00:16.488061
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    """Unit test for method __repr__ of class PluginManager"""
    assert repr(PluginManager()) == '<PluginManager: []>'


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 20:00:19.887849
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin = PluginManager()
    plugin.load_installed_plugins()
    qwe = plugin.get_auth_plugins()
    # print(qwe)
    # print(type(qwe))



# Generated at 2022-06-23 20:00:22.303116
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 5

# Generated at 2022-06-23 20:00:28.757183
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Checking if the class PluginManager has the method filter
    assert hasattr(PluginManager, 'filter'), '''The class PluginManager
                                                should have the method filter'''

    # Checking if the method filter returns a list of object from the type
    # BasePlugin
    assert isinstance(PluginManager().filter(), list), '''The method filter
                                    should return a list of object from the type
                                    BasePlugin'''

    # Checking if the method filter returns a list of object from the type
    # BasePlugin
    assert isinstance(PluginManager().filter()[0], BasePlugin), '''The method
                                    filter should return a list of object from
                                    the type BasePlugin'''



# Generated at 2022-06-23 20:00:30.577013
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin)
    assert pluginManager.get_auth_plugin_mapping() == {'plugin': AuthPlugin}


# Generated at 2022-06-23 20:00:34.230047
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()

    A = type('A', (), {})
    B = type('B', (), {})
    C = type('C', (), {})

    class D(A):
        pass

    class E(B):
        pass

    pm.register(A, B, C, D, E)
    assert pm.filter(A) == [A, D]

# Generated at 2022-06-23 20:00:41.570476
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(DigestAuthPlugin)
    plugins.register(BearerTokenAuthPlugin)
    plugins.register(BasicAuthPlugin)
    plugin_types = [type(plugin) for plugin in plugins.get_auth_plugins()]
    assert BasicAuthPlugin in plugin_types
    assert DigestAuthPlugin in plugin_types
    assert BearerTokenAuthPlugin in plugin_types
    assert len(plugins.get_auth_plugins()) == 3

# Generated at 2022-06-23 20:00:45.323986
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.filter(AuthPlugin) == []
    assert manager.filter(FormatterPlugin) > 0

manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-23 20:00:49.007381
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    pluginManager.register(httpie.plugins.builtin.TestPlugin)
    assert pluginManager.get_formatters_grouped()['Test'] == [httpie.plugins.builtin.TestPlugin]

# Generated at 2022-06-23 20:00:55.439086
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Create insatnces of plugin types
    class FormatterPlugin(BasePlugin):
        pass

    class AuthPlugin(BasePlugin):
        pass

    class ConverterPlugin(BasePlugin):
        pass

    class TransportPlugin(BasePlugin):
        pass

    # Create PluginManager
    plugins = PluginManager()

    # Register plugins
    plugins.register(AuthPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)

    # Check
    assert plugins.filter(AuthPlugin) == [AuthPlugin], 'PluginManager.filter() failed'

test_PluginManager_filter()