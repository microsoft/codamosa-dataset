

# Generated at 2022-06-23 19:50:49.492781
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert str(manager) == f'<PluginManager: {list(manager)}>'

# Generated at 2022-06-23 19:50:50.719306
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert pm.get_auth_plugin_mapping() == {}


# Generated at 2022-06-23 19:50:51.859248
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    pass

# Generated at 2022-06-23 19:50:54.409950
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    listConverters = pluginManager.get_converters()
    assert listConverters



# Generated at 2022-06-23 19:50:59.968095
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    print(manager)
    print(manager.get_auth_plugin_mapping())
    print(manager.get_auth_plugin('basic'))

test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-23 19:51:06.657386
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    """Unit test for PluginManager.get_auth_plugins()"""
    plugin_manager = PluginManager()
    plugin_manager.register(TestAuthPlugin1)
    plugin_manager.register(TestAuthPlugin2)
    plugin_manager.register(TestFormatPlugin1)
    assert plugin_manager.get_auth_plugins() == [TestAuthPlugin1, TestAuthPlugin2]


# Generated at 2022-06-23 19:51:14.822621
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pl = PluginManager()
    pl.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert repr(pl) == '<PluginManager: [httpie.plugins.base.AuthPlugin, '\
                       'httpie.plugins.base.FormatterPlugin, '\
                       'httpie.plugins.base.ConverterPlugin, '\
                       'httpie.plugins.base.TransportPlugin]>'
    assert pl.get_auth_plugins() == [AuthPlugin]
    assert pl.get_formatters() == [FormatterPlugin]
    assert pl.get_converters() == [ConverterPlugin]
    assert pl.get_transport_plugins() == [TransportPlugin]
    assert pl.get_auth_plugin('auth_type') == AuthPlugin
    assert pl.get_auth_plugin_m

# Generated at 2022-06-23 19:51:24.771809
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    import requests
    from requests.auth import HTTPDigestAuth, HTTPBasicAuth, HTTPBasicAuth
    from httpie.plugins.auth.named import NamedAuthPlugin
    from httpie.plugins.auth.ntlm import NTLMPlugin
    from httpie.plugins.auth.generic import GenericAuthPlugin

    auth_method_map = {
        'basic': HTTPBasicAuth,
        'digest': HTTPDigestAuth,
        'ntlm': HTTPDigestAuth
    }

    def get_auth_plugin(auth, args) -> BasePlugin:
        if not auth:
            return

        if isinstance(auth, str):
            name, sep, value = auth.partition(':')
            if sep and value:
                auth = name, value

        if isinstance(auth, tuple):
            auth_type

# Generated at 2022-06-23 19:51:27.103138
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins=[]
    pl = PluginManager(plugins)
    class temp(object):
        pass
    class cls(temp):
        pass
    pl.register(cls)
    assert plugins[0] == cls


# Generated at 2022-06-23 19:51:34.158220
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import ConverterPlugin

    class PluginSuite1(AuthPlugin):
        auth_type = 'my_plugin'

    class PluginSuite2(ConverterPlugin):
        pass

    class PluginSuite3(ConverterPlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginSuite1, PluginSuite2, PluginSuite3)
    assert PluginSuite1 in plugin_manager

    plugin_manager.unregister(PluginSuite1)
    assert PluginSuite1 not in plugin_manager

    plugin_manager.unregister(PluginSuite2)
    assert PluginSuite2 not in plugin_manager and PluginSuite3 in plugin_manager


# Generated at 2022-06-23 19:51:36.146189
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin, DigestAuthPlugin)
    assert plugin_manager.get_auth_plugins() == [BasicAuthPlugin, DigestAuthPlugin]



# Generated at 2022-06-23 19:51:39.517453
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin_mapping()
    return True

# Generated at 2022-06-23 19:51:47.843339
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    import httpie.plugins.builtin.transport.cachecontrol
    import httpie.plugins.builtin.transport.h2
    import httpie.plugins.builtin.transport.http1
    import httpie.plugins.builtin.transport.http2
    import httpie.plugins.builtin.transport.prompt
    import httpie.plugins.builtin.transport.proxy
    import httpie.plugins.builtin.transport.ssl
    import httpie.plugins.builtin.transport.tls
    import httpie.plugins.builtin.transport.verify
    plugins = PluginManager()

# Generated at 2022-06-23 19:51:56.034862
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-23 19:52:02.089335
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    class FooPlugin:
        pass
    class BarPlugin:
        pass
    plugins.register(FooPlugin, BarPlugin)
    print(plugins)
    assert len(plugins) == 2
    assert plugins[0] == FooPlugin
    assert plugins[1] == BarPlugin
    
    

# Generated at 2022-06-23 19:52:06.933697
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager=PluginManager()
    manager.load_installed_plugins()
    for plugin in manager.get_formatters():
        assert 'FormatterPlugin' in [base.__name__ for base in plugin.__bases__]

# Generated at 2022-06-23 19:52:09.970649
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    mgr = PluginManager()
    mgr.load_installed_plugins()
    print(mgr.get_auth_plugin_mapping())

if __name__ == '__main__':
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-23 19:52:14.780008
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.builtin import HTTPBasicAuthPlugin
    from httpie.plugins import AuthPlugin

    plugins = PluginManager()
    plugins.register(HTTPBasicAuthPlugin)

    assert len(plugins.get_auth_plugins()) == 1
    assert issubclass(plugins.get_auth_plugins()[0], AuthPlugin)


# Generated at 2022-06-23 19:52:20.578781
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginManager = PluginManager()
    pluginManager.register()
    
    formatters_grouped = pluginManager.get_formatters_grouped()

    # Assertion:
    # . Check if the key of the formatter are present.
    # . Check if the values in the formatter are of type FormatterPlugin
    assert 'Formatters' in formatters_grouped
    assert 'Display options' in formatters_grouped
    assert all(isinstance(formatter, FormatterPlugin) for formatter in formatters_grouped['Formatters'])

# Generated at 2022-06-23 19:52:23.716242
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([1, 2, 3])) == '<PluginManager: [1, 2, 3]>'



# Generated at 2022-06-23 19:52:32.164605
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from pytest import raises
    from httpie.plugins import AuthPlugin, ConverterPlugin, HTTPBasicAuth
    from httpie.plugins import DEFAULT_FORMAT
    from httpie.plugins.core import CorePlugin
    from httpie.plugins.manager import PluginManager

    class DummyPlugin(AuthPlugin, ConverterPlugin):
        auth_type = 'a'
        auth_require = True
        auth_parse = True
        auth_help = ''
        convert_mime = 'b'

    plugin_manager = PluginManager()
    plugin_manager.register(DummyPlugin)
    assert f'<PluginManager: [{DummyPlugin}]>' == str(plugin_manager)
    plugin_manager.unregister(DummyPlugin)
    assert f'<PluginManager: []>' == str(plugin_manager)

# Generated at 2022-06-23 19:52:33.454552
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    return plugin_manager.get_formatters_grouped()

# Generated at 2022-06-23 19:52:40.092943
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert len(manager.get_transport_plugins()) == 1, "Expected number 1 in length of list returned."
    assert isinstance(manager.get_transport_plugins()[0], TransportPlugin)


# Generated at 2022-06-23 19:52:42.542792
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    with pytest.raises(AssertionError):
        class TestPlugin:
            pass
        pm = PluginManager()
        pm.unregister(TestPlugin)



# Generated at 2022-06-23 19:52:47.846923
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(type)
    plugin_manager.register(BasePlugin)
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)

    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]



# Generated at 2022-06-23 19:52:56.333227
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.v1 import KeyAuthPlugin
    from httpie.plugins.auth.v2 import OAuth2AuthPlugin
    from httpie.plugins.auth.v3 import DigestAuthPlugin
    from httpie.plugins.auth.v4 import JWTAuthPlugin

    pm = PluginManager()
    pm.register(KeyAuthPlugin, OAuth2AuthPlugin, DigestAuthPlugin, JWTAuthPlugin)

    assert pm.get_auth_plugin_mapping() == {
        'key': KeyAuthPlugin,
        'oauth2': OAuth2AuthPlugin,
        'digest': DigestAuthPlugin,
        'jwt': JWTAuthPlugin,
    }


# Generated at 2022-06-23 19:52:59.954974
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pluginManager = PluginManager()
    plugins = [BasePlugin]

    prv_num_plugins = len(pluginManager)
    pluginManager.register(*plugins)
    new_num_plugins = len(pluginManager)

    # Assert it got the correct number of plugins
    assert new_num_plugins - prv_num_plugins == len(plugins)

    # Assert it actually got the plugins
    for plugin in plugins:
        assert plugin in pluginManager


# Generated at 2022-06-23 19:53:03.351788
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginm = PluginManager()
    pluginm.register(PluginManager)
    assert PluginManager in pluginm
    pluginm.unregister(PluginManager)
    assert PluginManager not in pluginm


# Generated at 2022-06-23 19:53:13.571162
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins_manager = PluginManager()
    plugins_manager.register(
        type(
            'PasswordAuthPlugin',
            (AuthPlugin,),
            {
                'auth_type': 'password',
                'auth_parse_arguments': lambda args: print('password-auth')
            }
        ),
        type(
            'BearerTokenAuthPlugin',
            (AuthPlugin,),
            {
                'auth_type': 'bearer-token',
                'auth_parse_arguments': lambda args: print('bearer-token-auth')
            }
        ),
    )

    print(plugins_manager.get_auth_plugin('bearer-token'))
    print(plugins_manager.get_auth_plugin_mapping())
    print(plugins_manager.get_auth_plugins())



# Generated at 2022-06-23 19:53:19.198208
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(JsonDevNull)
    pm.register(JsonDevNull)
    pm.register(JsonDevNull2)
    assert len(pm.get_formatters_grouped()) == 1
    assert pm.get_formatters_grouped(
    )["JSON"] == [JsonDevNull, JsonDevNull, JsonDevNull2]



# Generated at 2022-06-23 19:53:22.351874
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin = PluginManager()
    plugins = plugin.get_converters()
    assert plugins is not None
    for item in plugins:
        assert isinstance(item, ConverterPlugin)



# Generated at 2022-06-23 19:53:28.378930
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """ 
    Unit test for method get_formatters_grouped of class PluginManager 
    """
    plugin_manager = PluginManager()
    plugin_manager.register(CustomFormatterPlugin_1, CustomFormatterPlugin_2, CustomFormatterPlugin_3)
    plugin_manager.load_installed_plugins()

    # Test if the returned dict. from the method is correct
    assert sorted(plugin_manager.get_formatters_grouped().keys()) == sorted(['CustomFormatterGroup_1', 'CustomFormatterGroup_2'])
    assert sorted(plugin_manager.get_formatters_grouped()['CustomFormatterGroup_1']) == sorted([CustomFormatterPlugin_1, CustomFormatterPlugin_2])

# Generated at 2022-06-23 19:53:35.546754
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.extend([
        'httpie_plugin_example.plugin.AuthPlugin',
        'httpie_plugin_example.plugin.HTTPiePlugin',
        'httpie_plugin_example.plugin.FormatterPlugin',
        'httpie_plugin_example.plugin.ConverterPlugin',
        'httpie_plugin_example.plugin.TransportPlugin',
    ])
    assert manager.get_auth_plugins() == [
        'httpie_plugin_example.plugin.AuthPlugin',
    ]


# Generated at 2022-06-23 19:53:38.300444
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(Type[FormatterPlugin])
    ass = (plugins.get_formatters() == [FormatterPlugin])
    assert ass == True

# Generated at 2022-06-23 19:53:42.145078
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.register(FormatterPlugin)
    assert len(pm.get_formatters()) == 1


plugins = PluginManager()
plugins.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

# Generated at 2022-06-23 19:53:45.254338
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    try:
        plugin_manager = PluginManager()
        plugin_manager.load_installed_plugins()
        assert len(plugin_manager) == 14
    except Exception as e:
        print(e)

# Generated at 2022-06-23 19:53:47.871051
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(MyConverterPlugin)
    pm.register(MyConverterPlugin1)
    assert pm.get_converters() == [MyConverterPlugin]


# Generated at 2022-06-23 19:53:50.327469
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    assert plugins.get_auth_plugins() == [AuthPlugin]


# Generated at 2022-06-23 19:53:56.540920
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_mgr = PluginManager()
    plugins_mgr.load_installed_plugins()

    def assert_type(plugins_mgr):
        result = plugins_mgr.get_formatters_grouped()
        assert type(result) == dict
        assert type(list(result.values())[0]) == list
        assert type(list(result.values())[0][0]) == FormatterPlugin

    assert_type(plugins_mgr)
    plugins_mgr.append(FormatterPlugin)
    assert_type(plugins_mgr)

# Generated at 2022-06-23 19:54:02.338096
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # mock
    assert PluginManager().get_auth_plugins() == []
    plugin_manager = PluginManager()
    plugin_manager.append('httpie.plugins.auth.v1')

    # run
    plugin_manager.get_auth_plugins()
    assert plugin_manager.get_auth_plugins() == ['httpie.plugins.auth.v1']


# Generated at 2022-06-23 19:54:04.051903
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    assert len(plugins) == 0


# Generated at 2022-06-23 19:54:11.774335
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    class A:
        pass
    class B(A):
        pass
    class C:
        pass
    plugin_manager.register(A)
    print(plugin_manager)
    plugin_manager.register(B,C)
    print(plugin_manager)
    assert plugin_manager.__repr__() == '<PluginManager: [<class \'httpie.plugins.base.A\'>, <class \'httpie.plugins.base.B\'>, <class \'httpie.plugins.base.C\'>]>'


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:54:14.779890
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    assert '<PluginManager: []>' == p.__repr__()


# Generated at 2022-06-23 19:54:19.212693
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
	# Unit test for method load_installed_plugins of class PluginManager
	def test_PluginManager_load_installed_plugins():
		manager = PluginManager()
		manager.load_installed_plugins()
		assert len(manager) > 0



# Generated at 2022-06-23 19:54:26.933521
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import builtin
    # Load plugins
    manager = PluginManager()
    manager.register(builtin.PrettyJsonFormatter)
    manager.register(builtin.HTMLFormatter)
    manager.register(builtin.JSONFormatter)
    manager.register(builtin.ColoredJSONFormatter)
    manager.register(builtin.JunitFormatter)
    manager.register(builtin.Ansi2HTMLFormatter)
    # Test
    assert isinstance(manager.get_formatters_grouped(), dict)
    assert manager.get_formatters_grouped()['text'] == [builtin.HTMLFormatter]
    assert manager.get_formatters_grouped()['json'] == [builtin.JSONFormatter, builtin.ColoredJSONFormatter, builtin.PrettyJsonFormatter]
   

# Generated at 2022-06-23 19:54:34.237792
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    def load_auth_plugins():
        for entry_point in iter_entry_points('httpie.plugins.auth.v1'):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugin_manager.register(entry_point.load())

    plugin_manager = PluginManager()
    load_auth_plugins()
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert type(mapping) == dict
    assert len(mapping) == 9, mapping

    return plugin_manager

if __name__ == "__main__":
    plugin_manager = test_PluginManager_get_auth_plugin_mapping()
    print(plugin_manager.get_auth_plugin_mapping())

# Generated at 2022-06-23 19:54:36.854034
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(MyAuthPlugin, MyAuthPlugin2)
    assert manager.get_auth_plugin('type') == MyAuthPlugin
    assert manager.get_auth_plugin('type2') == MyAuthPlugin2


# Generated at 2022-06-23 19:54:48.281433
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()

# Generated at 2022-06-23 19:54:56.364887
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    print(plugin_manager.get_auth_plugin_mapping())
    print(plugin_manager.get_auth_plugin('basic'))
    print(plugin_manager.get_auth_plugin_mapping())
    print(plugin_manager.get_auth_plugin('digest'))
    print(plugin_manager.get_auth_plugin_mapping())
    print(plugin_manager.get_auth_plugin('token'))
    print(plugin_manager.get_auth_plugin_mapping())



# Generated at 2022-06-23 19:55:01.527414
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    auth_plugins = [
        'httpie.plugins.kerberos_auth',
        'httpie.plugins.httpauth',
    ]
    auth_plugin_names = [plugin.auth_type for plugin in PluginManager.get_auth_plugins()]
    for auth_plugin in auth_plugins:
        assert auth_plugin in auth_plugin_names

# Generated at 2022-06-23 19:55:07.092904
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter.v1 import JSONConverter, DataConverter
    from httpie.plugins.format.v1 import JSONFormatter, PrettyJSONFormatter
    from httpie.plugins.transport.v1 import AsyncHttpTransport
    pm = PluginManager()
    pm.register(JSONConverter, DataConverter, JSONFormatter, PrettyJSONFormatter, AsyncHttpTransport)
    assert pm.get_converters() == [JSONConverter, DataConverter]

# Generated at 2022-06-23 19:55:14.406039
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    converters = plugins.get_converters()
    assert converters[0].__name__ == 'JsonConverter'
    assert converters[1].__name__ == 'NullConverter'
    assert converters[2].__name__ == 'JsonConverter'


# Generated at 2022-06-23 19:55:14.943903
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()

# Generated at 2022-06-23 19:55:16.466927
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    assert str(pluginManager) == '<PluginManager: []>'


# Generated at 2022-06-23 19:55:18.295366
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) == 6



# Generated at 2022-06-23 19:55:28.752390
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converters import BaseConverter
    from httpie.plugins.converters.json import JSONConverter
    from httpie.plugins.converters.html import HTMLConverter
    from httpie.plugins.converters.url import URLConverter
    converter = PluginManager()
    converter.register(JSONConverter, HTMLConverter, URLConverter)
    # Test that the length of the return of get_converters is 3
    assert len(converter.get_converters()) == 3
    # Test that all the returned objects are instance of BaseConverter
    for i in converter.get_converters():
        assert isinstance(i, BaseConverter)


# Generated at 2022-06-23 19:55:36.539021
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    
    class B(A):
        pass
    
    class C(A):
        pass
    
    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()
    c1 = C()
    c2 = C()
    
    pluginManager = PluginManager()
    
    pluginManager.register(a1, a2, b1, b2, c1, c2)
    assert pluginManager.filter(A) == [a1, a2, b1, b2, c1, c2]
    assert pluginManager.filter(B) == [b1, b2]
    assert pluginManager.filter(C) == [c1, c2]



# Generated at 2022-06-23 19:55:42.422756
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    import requests
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'myauth'
        def get_auth(self, username='', password=''):
            return requests.auth.HTTPBasicAuth(username, password)

    manager = PluginManager()
    manager.register(MyAuthPlugin)
    assert manager.get_auth_plugin('myauth') == MyAuthPlugin


# Generated at 2022-06-23 19:55:45.954884
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_list = [A, B, C]
    plugin_manager = PluginManager()
    plugin_manager.register(A, B, C)
    plugin_manager.unregister(B)
    assert plugin_manager == plugin_list[:1] + plugin_list[2:]


# Generated at 2022-06-23 19:55:48.633081
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert isinstance(manager, PluginManager)


# Generated at 2022-06-23 19:55:58.800370
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, FormatterPlugin)
    auth_plugins = plugin_manager.get_auth_plugins()
    formatter_plugins = plugin_manager.get_formatters()
    assert len(auth_plugins) == 1
    assert auth_plugins[0] is AuthPlugin
    assert len(formatter_plugins) == 1
    assert formatter_plugins[0] is FormatterPlugin

    # Test for 'plugin_manager.register(*plugins: Type[BasePlugin])'
    plugin_manager.register(TransportPlugin)
    transport_plugins = plugin_manager.get_transport_plugins()
    assert len(transport_plugins) == 1
    assert transport_plugins[0] is TransportPlugin


# Generated at 2022-06-23 19:56:08.788647
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    class AuthPlugin(BasePlugin):
        pass

    class FormatterPlugin(BasePlugin):
        pass

    class TransportPlugin(BasePlugin):
        pass

    class ConverterPlugin(BasePlugin):
        pass

    class PluginManager1(PluginManager):
        pass

    class PluginManager2(PluginManager):
        pass

    class PluginManager3(PluginManager):
        pass

    class PluginManager4(PluginManager):
        pass

    PluginManager1.register(AuthPlugin)
    PluginManager1.register(FormatterPlugin)

    PluginManager2.register(TransportPlugin)
    PluginManager2.register(ConverterPlugin)

    PluginManager3.register(TransportPlugin)
    PluginManager3.register(FormatterPlugin)

    PluginManager4.register(AuthPlugin)
    PluginManager4.register(FormatterPlugin)

    Plugin

# Generated at 2022-06-23 19:56:10.818734
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_type = 'basic'
    assert PluginManager().get_auth_plugin_mapping()[auth_type].auth_type == auth_type

# Generated at 2022-06-23 19:56:12.729782
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(list(plugin_manager)) > 0



# Generated at 2022-06-23 19:56:13.601789
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == []

# Generated at 2022-06-23 19:56:20.136718
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.auth.httpie_auth_plugin import HttpieAuthPlugin
    from httpie.plugins.auth.httpie_oauth1_auth import HttpieOauth1Plugin
    from httpie.plugins.auth.httpie_oauth2_auth import HttpieOauth2Plugin
    manager = PluginManager()
    manager.register(HttpieAuthPlugin, HttpieOauth1Plugin, HttpieOauth2Plugin)
    assert manager.get_auth_plugins() == [HttpieAuthPlugin,
                                          HttpieOauth1Plugin,
                                          HttpieOauth2Plugin]


# Generated at 2022-06-23 19:56:23.218982
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.filter(AuthPlugin)) > 0


# Generated at 2022-06-23 19:56:27.580433
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    manager.register(AuthPlugin)
    manager.register(FormatterPlugin)
    assert manager.__repr__() == '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>, <class \'httpie.plugins.base.FormatterPlugin\'>]>'


# Generated at 2022-06-23 19:56:39.591927
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import httpie.plugins.http.angry.httpie_angry_http_plugin as angry_http
    pm = PluginManager()

    def fake_iter_entry_points(entry_point_name: str) -> List[Type[BasePlugin]]:
        if entry_point_name == ENTRY_POINT_NAMES[0]:
            return [angry_http]
        else:
            return []

    for entry_point_name in ENTRY_POINT_NAMES:
        assert entry_point_name not in pm
        assert len(pm) == 0

    from pkg_resources import iter_entry_points
    iter_entry_points_saved = iter_entry_points
    iter_entry_points = fake_iter_entry_points
    pm.load_installed_plugins()
    iter_entry_points = iter_

# Generated at 2022-06-23 19:56:49.318061
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    """
    Test method __repr__ of PluginManager Class
    :return: void
    """
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_auth_plugin_mapping()) == 0
    manager = PluginManager()
    manager.register(FooAuthPlugin)
    assert len(manager.get_auth_plugin_mapping()) == 1
    assert manager.get_auth_plugin('foo') == FooAuthPlugin
    manager.unregister(FooAuthPlugin)
    assert len(manager.get_auth_plugin_mapping()) == 0



# Generated at 2022-06-23 19:56:54.557191
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    pluginManager.register()
    assert pluginManager.get_formatters_grouped() == {}
    pluginManager.register(MockFormatterPlugin1, MockFormatterPlugin2)
    assert pluginManager.get_formatters_grouped() == {
        'group1': [MockFormatterPlugin1], 'group2': [MockFormatterPlugin2]
    }

# Mock Formatter Plugin class

# Generated at 2022-06-23 19:57:01.190053
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert 'httpie-httpbin-auth' in [
        plugin.package_name
        for plugin in plugin_manager.get_auth_plugins()
    ]
    assert 'httpie-httpbin-auth' in [
        plugin.package_name
        for plugin in plugin_manager.get_formatters_grouped()['Colors']
    ]
    assert 'httpie-httpbin-auth' in [
        plugin.package_name
        for plugin in plugin_manager.get_transport_plugins()
    ]

# Generated at 2022-06-23 19:57:05.313371
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert plugin_manager.get_formatters() == [
        plugin for plugin in plugin_manager if issubclass(plugin, FormatterPlugin)
    ]


# Generated at 2022-06-23 19:57:06.710716
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    class NamePlugin(BasePlugin):
        name = 'test'
    plugins = PluginManager()
    plugins.register(NamePlugin)
    assert plugins.register == NamePlugin


# Generated at 2022-06-23 19:57:09.107425
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    a = PluginManager()
    a.register(AuthPlugin)
    assert 'PluginManager: [httpie.plugins.auth.AuthPlugin]' == a.__repr__()


# Generated at 2022-06-23 19:57:10.915695
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    assert manager.get_auth_plugin('basic') == 'basic'


# Generated at 2022-06-23 19:57:12.974737
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager.get_formatters())

test_PluginManager()

# Generated at 2022-06-23 19:57:17.162913
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth
    pm = PluginManager()
    pm.register(HTTPBasicAuth, HTTPDigestAuth)
    assert pm.get_auth_plugin_mapping() == {
        HTTPBasicAuth.auth_type: HTTPBasicAuth,
        HTTPDigestAuth.auth_type: HTTPDigestAuth,
    }

# Generated at 2022-06-23 19:57:20.192339
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.register()
    assert plugin_manager.get_auth_plugin_mapping()!=None

# Generated at 2022-06-23 19:57:24.971188
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    print('Unit test for method get_transport_plugins of class PluginManager')
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins() # Load all plugins
    plugin_manager.get_transport_plugins()
    print(f'The number of transport plugins is {len(plugin_manager.get_transport_plugins())}')
    print('Test passed!')

if __name__ == "__main__":
    test_PluginManager_get_transport_plugins()

# Generated at 2022-06-23 19:57:26.966328
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    for formatter_plugin in plugin_manager.get_formatters():
        formatter_plugin.get_header_formatter()

# Generated at 2022-06-23 19:57:37.114116
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    PLUGIN_AUTH_TYPE = 'AUTH_TYPE'
    PLUGIN_AUTH_NAME = 'PLUGIN_AUTH_NAME'
    PLUGIN_CUSTOM_HEADER_NAME = 'X-Custom-Header'

    class DummyPlugin(AuthPlugin):
        auth_type = PLUGIN_AUTH_TYPE
        name = PLUGIN_AUTH_NAME
        custom_header = PLUGIN_CUSTOM_HEADER_NAME
        auth_require = True

        def get_auth(self, username, password):
            return {self.custom_header: 'true'}

    # A plugin manager is created with the default plugins
    pm = PluginManager()
    pm.load_installed_plugins()

    # The plugin manager should have a list with default plugins and the dummy plugin

# Generated at 2022-06-23 19:57:39.462298
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_formatters_grouped()



# Generated at 2022-06-23 19:57:40.520026
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert False, 'Test is missing'


# Generated at 2022-06-23 19:57:43.991940
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm.get_auth_plugins() != []
    assert pm.get_auth_plugins()
    assert len(pm.get_auth_plugins()) >= 2


# Generated at 2022-06-23 19:57:48.483746
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import AuthPlugin, TransportPlugin
    from typing import List
    from httpie import ExitStatus
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.filter(AuthPlugin)) == 1
    assert len(plugin_manager.filter(TransportPlugin)) == 1
    assert plugin_manager.get_formatter('json') != None


# Generated at 2022-06-23 19:57:52.072647
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm=PluginManager()
    assert len(pm)==0

    pm.register(BasePlugin)
    assert len(pm)==1

    pm.register(BasePlugin)
    assert len(pm)==2

# Generated at 2022-06-23 19:57:54.269464
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(PluginManager)
    assert manager.get_auth_plugin('basic') == PluginManager

# Generated at 2022-06-23 19:57:57.419752
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert isinstance(pm, PluginManager)


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:57:59.619434
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    local_plugins = PluginManager()
    class Test(BasePlugin):
        name = 'test'
    local_plugins.register(Test)
    assert Test.name in [plugin.name for plugin in local_plugins]
    local_plugins.unregister(Test)
    assert len(local_plugins) == 0

# Generated at 2022-06-23 19:58:04.144024
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin.formatter import BuiltinFormatterPlugin, builtin_formatter_classes
    plugins = PluginManager()
    plugins.register(*builtin_formatter_classes)
    assert len(plugins) > 0
    expected = {'builtin': list(builtin_formatter_classes)}
    assert plugins.get_formatters_grouped() == expected


# Generated at 2022-06-23 19:58:06.325949
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    assert p.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-23 19:58:09.597318
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([1,2])) == '<PluginManager: [1, 2]>'

# Generated at 2022-06-23 19:58:11.104797
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == []


# Generated at 2022-06-23 19:58:16.271093
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    authPlugins = []
    expected_output = 4

    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            authPlugins.append(entry_point.load())

    output = len(authPlugins)
    assert expected_output == output



# Generated at 2022-06-23 19:58:19.107710
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(list)
    assert len(pm.get_formatters_grouped()) == 1 
    print(pm.get_formatters_grouped())

# Generated at 2022-06-23 19:58:22.136668
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) > 2


# Generated at 2022-06-23 19:58:25.490884
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    assert plugins == []
    plugins.register(AuthPlugin)
    plugins.register(TransportPlugin)
    assert plugins[0] == AuthPlugin
    assert plugins[1] == TransportPlugin



# Generated at 2022-06-23 19:58:31.761791
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Test empty PluginManager
    plugins = PluginManager()
    assert plugins.get_auth_plugins() == []

    # Test PluginManager with some plugins
    class Plugin1(AuthPlugin):
        pass

    class Plugin2(AuthPlugin):
        pass

    class Plugin3(TransportPlugin):
        pass

    plugins.register(Plugin1, Plugin2, Plugin3)
    assert plugins.get_auth_plugins() == [Plugin1, Plugin2]



# Generated at 2022-06-23 19:58:33.510212
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'

# Generated at 2022-06-23 19:58:41.414107
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    auth_plugins = []
    auth_plugins.append(PluginManager().get_auth_plugin("basic"))
    auth_plugins.append(PluginManager().get_auth_plugin("digest"))
    auth_plugins.append(PluginManager().get_auth_plugin("aws"))
    auth_plugins.append(PluginManager().get_auth_plugin("hawk"))
    auth_plugins.append(PluginManager().get_auth_plugin("oauth1"))
    auth_plugins.append(PluginManager().get_auth_plugin("ntlm"))
    return auth_plugins


# Generated at 2022-06-23 19:58:43.497848
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager.register(BasePlugin)

print(test_PluginManager_filter())


# Generated at 2022-06-23 19:58:45.683549
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
  pm = PluginManager()
  pm.load_installed_plugins()
  for plugin in pm:
    assert(plugin.package_name)
    assert(plugin.group_name)

# Generated at 2022-06-23 19:58:47.398982
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager, PluginManager)

# Generated at 2022-06-23 19:58:50.913763
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    p = PluginManager()
    assert p.get_converters() == [], 'The list is empty'
    assert p.get_converters() == p.get_converters()

# Generated at 2022-06-23 19:58:52.548853
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert (str(pm)) == '<PluginManager: []>'

plugins = PluginManager()

# Generated at 2022-06-23 19:58:59.464859
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    class Plugin1:
        pass

    class Plugin2:
        pass

    class Plugin3(Plugin2):
        pass

    pm = PluginManager()
    pm.register(Plugin1, Plugin2, Plugin3)

    assert pm.filter(Plugin1) == [Plugin1]
    assert pm.filter(Plugin2) == [Plugin2, Plugin3]
    assert pm.filter() == [Plugin1, Plugin2, Plugin3]
    assert pm.filter(Type[Plugin1]) == [Plugin1, Plugin2, Plugin3]

# Generated at 2022-06-23 19:59:03.824014
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Create a PluginManager object
    plugin_manager = PluginManager()
    # Register 3 plugins
    plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin)
    # Test the output of filter when the parameter by_type is FormatterPlugin
    assert plugin_manager.filter(by_type=FormatterPlugin) == [FormatterPlugin]


# Generated at 2022-06-23 19:59:05.502629
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugins() == [], "Should be empty"


# Generated at 2022-06-23 19:59:12.677766
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # 构造实例
    plugin_manager = PluginManager()
    # 加载安装的插件
    plugin_manager.load_installed_plugins()
    # 验证
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugin('basic')) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_formatters_grouped()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-23 19:59:17.637645
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(MockAuthPlugin)
    
    assert len(pm.get_auth_plugins()) == 1

# Generated at 2022-06-23 19:59:21.783478
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    print("\nTesting method get_auth_plugins()...")
    print("\n".join(str(auth_plugin) for auth_plugin in pluginmanager.get_auth_plugins()))


# Generated at 2022-06-23 19:59:26.222609
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_auth_plugins()) == 1
    assert len(plugin_manager.get_formatters()) == 12
    assert len(plugin_manager.get_transport_plugins()) == 3

# Generated at 2022-06-23 19:59:33.663185
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import formatter
    from httpie.plugins.builtin import JSONPrettyPlugin
    from httpie.plugins.builtin import JSONStreamPlugin
    from httpie.plugins.builtin import RawJSONPlugin
    pm = PluginManager()
    pm.load_installed_plugins()

    # make sure the test data is correct
    assert len(pm.get_formatters()) == 0
    assert len(pm.get_formatters_grouped()) == 0

    # register JSONPrettyPlugin manually
    # make sure the methods get_formatters and get_formatters_grouped work correctly
    pm.register(JSONPrettyPlugin)
    assert len(pm.get_formatters()) == 1
    assert len(pm.get_formatters_grouped()) == 1
    # make sure that:
    # 1) the names of the items in the dictionary

# Generated at 2022-06-23 19:59:37.019585
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin1:
        pass

    class Plugin2:
        pass

    class Plugin3:
        pass

    pm = PluginManager()
    pm.register(Plugin1)
    assert len(pm) == 1

    pm.unregister(Plugin1)
    assert len(pm) == 0


# Generated at 2022-06-23 19:59:41.801360
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    from httpie.plugins import AuthPlugin
    plugins.register(AuthPlugin)
    assert repr(plugins) == '<PluginManager: [<class \'httpie.plugins.auth.AuthPlugin\'>]>'
    plugins.unregister(AuthPlugin)
    assert repr(plugins) == '<PluginManager: []>'


# Generated at 2022-06-23 19:59:43.317776
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager.get_formatters_grouped()

plugins = PluginManager()

# Generated at 2022-06-23 19:59:50.253307
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin

    class Formatter(FormatterPlugin):
        name = 'testing'
        group_name = 'group1'

    class OtherFormatter(FormatterPlugin):
        name = 'testing'
        group_name = 'group2'

    plugins = PluginManager()
    plugins.register(Formatter, OtherFormatter)
    assert plugins.get_formatters_grouped() == {
        'group1': [Formatter],
        'group2': [OtherFormatter]
    }

# Generated at 2022-06-23 19:59:55.210840
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register(
        MockJsonConverterPlugin,
        MockJsonLinesConverterPlugin,
    )
    converter_list = manager.get_converters()
    assert len(converter_list) == 2
    assert converter_list[0] == MockJsonConverterPlugin
    assert converter_list[1] == MockJsonLinesConverterPlugin

# Mock plugins below

# Generated at 2022-06-23 19:59:58.579916
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    pm.load_installed_plugins()

    assert isinstance(pm, PluginManager)

    # Test if plugins are loaded properly
    for plugin in pm:
        assert isinstance(plugin, BasePlugin)



# Generated at 2022-06-23 20:00:04.709250
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert repr(plugin_manager) == '<PluginManager: [<class httpie.plugins.core.FormatterPlugin>, <class httpie.plugins.core.ConverterPlugin>, <class httpie.plugins.core.TransportPlugin>, <class httpie.plugins.core.AuthPlugin>, <class httpie.plugins.auth.clientcert.ClientCertAuthPlugin>]>'


# Generated at 2022-06-23 20:00:11.827807
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins import AuthPlugin, ConverterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.formatter.csv import CsvFormatter
    
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my'
        scheme = 'MY'

    class MyFormatterPlugin(FormatterPlugin):
        group_name = 'my'

    class MyConverterPlugin(ConverterPlugin):
        pass

    class MyTransportPlugin(TransportPlugin):
        pass
                                                                                                                                                                                                                   

# Generated at 2022-06-23 20:00:23.360519
# Unit test for method get_auth_plugin_mapping of class PluginManager

# Generated at 2022-06-23 20:00:24.167570
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert PluginManager().get_auth_plugin('basic')

# Generated at 2022-06-23 20:00:31.423410
# Unit test for method get_converters of class PluginManager

# Generated at 2022-06-23 20:00:37.899998
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class FormatterPlugin_1(FormatterPlugin):
        group_name = 'test_group_name_1'
    class FormatterPlugin_2(FormatterPlugin):
        group_name = 'test_group_name_2'
    class FormatterPlugin_3(FormatterPlugin):
        group_name = 'test_group_name_2'
    class AuthPlugin_1(AuthPlugin):
        auth_type = 'test_auth_type_1'
    class AuthPlugin_2(AuthPlugin):
        auth_type = 'test_auth_type_2'
    class AuthPlugin_3(AuthPlugin):
        auth_type = 'test_auth_type_2'
    class ConverterPlugin_1(ConverterPlugin):
        pass
    class ConverterPlugin_2(ConverterPlugin):
        pass

# Generated at 2022-06-23 20:00:47.781987
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class AuthPlugin1(AuthPlugin):
        auth_type = 'AuthPlugin1'
        auth_name = 'test_AuthPlugin1'
    class AuthPlugin2(AuthPlugin):
        auth_type = 'AuthPlugin2'
        auth_name = 'test_AuthPlugin2'
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'test_group_name'
        group_title = 'test_group_title'
        fmt = 'test_fmt'
        description = 'test_description'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'test_group_name2'
        group_title = 'test_group_title2'
        fmt = 'test_fmt2'
        description = 'test_description2'

# Generated at 2022-06-23 20:00:54.116469
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = []