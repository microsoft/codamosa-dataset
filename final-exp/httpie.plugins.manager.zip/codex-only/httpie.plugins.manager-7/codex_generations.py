

# Generated at 2022-06-23 19:50:54.364840
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert isinstance(pm, PluginManager)
    assert pm.get_transport_plugins() == []
    pm.load_installed_plugins()
    assert pm.get_transport_plugins() != []

# Generated at 2022-06-23 19:50:58.521273
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin(" ") == AuthPlugin

# Generated at 2022-06-23 19:51:00.499495
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(TestAuthPlugin)
    assert manager.get_auth_plugin('TestAuthPlugin') == TestAuthPlugin



# Generated at 2022-06-23 19:51:06.085477
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        AuthPlugin,
        TransportPlugin,
        ConverterPlugin
    )
    assert plugins.get_formatters() == [FormatterPlugin, FormatterPlugin, FormatterPlugin]


# Generated at 2022-06-23 19:51:14.365994
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import OutputOptions
    from httpie.plugins.builtin import HTTPieOutputPlugin
    pm = PluginManager()
    pm.register(HTTPieOutputPlugin)
    OutputOptions.quiet = True
    assert len(pm.get_formatters()) == 1
    assert pm.get_formatters()[0].name == 'httpie'
    assert next(iter(pm.get_formatters_grouped().items()))[1][0].name == 'httpie'
    OutputOptions.quiet = False
    assert len(pm.get_formatters()) == 2
    assert pm.get_formatters()[0].name == 'httpie'
    assert pm.get_formatters()[1].name == 'json'
    assert len(pm.get_formatters_grouped()) == 2
test_PluginManager_get_format

# Generated at 2022-06-23 19:51:17.870573
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    auth_plugins = PluginManager().get_auth_plugins()
    assert len(auth_plugins) == 1
    assert auth_plugins[0].auth_type == "basic"
    assert auth_plugins[0].name == "Basic Auth"



# Generated at 2022-06-23 19:51:20.373569
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    assert p == []
    p.register('a', 'b', 'c')
    assert p == ['a', 'b', 'c']


# Generated at 2022-06-23 19:51:23.852861
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert str(pm) == '<PluginManager: []>'
    pm.register(AuthPlugin)
    assert str(pm) == '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>]>'



# Generated at 2022-06-23 19:51:25.911629
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert(pm.__repr__() == '<PluginManager: []>')


# Generated at 2022-06-23 19:51:30.970072
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONPathFormatter, DefaultFormatter
    plugin_manager = PluginManager()
    plugin_manager.register(JSONPathFormatter)
    plugin_manager.register(DefaultFormatter)
    assert len(plugin_manager) == 2
    assert len(plugin_manager.get_formatters()) == 2
    assert len(plugin_manager.get_formatters_grouped()) == 1
    assert len(plugin_manager.get_formatters_grouped()['json']) == 1
    assert len(plugin_manager.get_formatters_grouped()['default']) == 1


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:51:33.096027
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_converters()) == 2

# Generated at 2022-06-23 19:51:36.021788
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert type(manager).__name__ == 'PluginManager'
    assert type(manager.get_formatters()).__name__ == 'list'
    assert len(manager.get_formatters()) > 0


# Generated at 2022-06-23 19:51:39.904549
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # Test Register
    plugin = PluginManager()
    plugin.register(AuthPlugin)
    assert issubclass(AuthPlugin, BasePlugin)
    assert plugin[0] == AuthPlugin



# Generated at 2022-06-23 19:51:43.133526
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    test_plugin = PluginManager.register(PluginManager(), BasePlugin)
    assert PluginManager.get_converters(PluginManager()) == []
    assert test_plugin == []


# Generated at 2022-06-23 19:51:47.081194
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import BasePlugin, FormatterPlugin
    class Plugin(BasePlugin, FormatterPlugin):
        pass
    plugin = Plugin()

    try:
        plugin.load_installed_plugins()
        assert plugin.package_name == 'httpie'
    except:
        pass


# Generated at 2022-06-23 19:51:57.210456
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    lst = [
        ('basic', 'httpie.plugins.auth.basic.BasicAuthPlugin'),
        ('digest', 'httpie.plugins.auth.digest.DigestAuthPlugin'),
        ('jwt', 'httpie.plugins.auth.jwt.JWTAuthPlugin'),
        ('hawk', 'httpie.plugins.auth.hawk.HAWKAuthPlugin'),
        ('netrc', 'httpie.plugins.auth.netrc.NetrcAuthPlugin'),
        ('ntlm', 'httpie.plugins.auth.ntlm.NTLMAuthPlugin'),
        ('oauth1', 'httpie.plugins.auth.oauth1.OAuth1Plugin'),
    ]
    auth_plugins = PluginManager().get_auth_plugin_mapping()

# Generated at 2022-06-23 19:51:59.192258
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert isinstance(pm, PluginManager)


# Generated at 2022-06-23 19:52:02.295974
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    def test_plugin():
        pass
    pm.register(test_plugin)
    assert len(pm) == 1
    assert pm[0] == test_plugin


# Generated at 2022-06-23 19:52:06.329551
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert plugin_manager
    assert len(plugin_manager) >= 1


# Generated at 2022-06-23 19:52:11.387978
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    tr = pm.get_transport_plugins()
    assert tr == [httpie_curl.CurlTransportPlugin,
 httpie_async.AsyncTransportPlugin,
 httpie_http2.HTTP2TransportPlugin,
 httpie_okhttp.OkHTTPTransportPlugin,
 httpie_urllib3.Urllib3Plugin]


# Generated at 2022-06-23 19:52:12.800512
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    print(plugin_manager.get_auth_plugin())

# Generated at 2022-06-23 19:52:14.105967
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    assert(isinstance(PluginManager(), PluginManager))



# Generated at 2022-06-23 19:52:16.782528
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin.transport.http import HTTPTransport, HTTP2Transport
    from httpie.plugins.builtin.transport.async_http import AsyncHTTPTransport
    pm = PluginManager()
    pm.register(HTTPTransport, HTTP2Transport, AsyncHTTPTransport)
    assert len(pm.get_transport_plugins()) == 3
    assert all(isinstance(plugin, TransportPlugin) for plugin in pm.get_transport_plugins())

# Generated at 2022-06-23 19:52:24.567968
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPTokenAuth
    from httpie.plugins.auth import AuthPlugin
    from httpie import input

    def confirm(msg):
        return True

    def get_password(prompt):
        return '123456'

    # Create plugin manager instance
    plugins = PluginManager()
    # Register AuthPlugin
    plugins.register(HTTPBasicAuth, HTTPTokenAuth)
    # Call get_auth_plugin method

# Generated at 2022-06-23 19:52:27.536809
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    m = PluginManager([1,2,3])
    assert repr(m) == '<PluginManager: [1, 2, 3]>'

# Generated at 2022-06-23 19:52:31.687196
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(MockPlugin1, MockPlugin2, MockPlugin3)
    assert plugin_manager.get_formatters_grouped() == {
        'one': [MockPlugin1],
        'two': [MockPlugin2, MockPlugin3],
    }


# Mock plugins for the tests

# Generated at 2022-06-23 19:52:37.317189
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(AwsAuthPlugin)
    plugins.register(BearerTokenAuthPlugin)
    plugins.register(DigestAuthPlugin)
    plugins.register(HawkAuthPlugin)
    plugins.register(NetrcAuthPlugin)
    plugins.register(Oauth1AuthPlugin)
    plugins.register(Oauth2AuthPlugin)
    plugins.register(RawAuthPlugin)
    plugins.register(WebauthPlugin)

    p = plugins.get_auth_plugins()

# Generated at 2022-06-23 19:52:39.820376
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert repr(pm) == '<PluginManager: []>'
    pm.register(AuthPlugin)
    assert repr(pm) == '<PluginManager: [httpie_auth_jwt.auth_jwt, httpie_auth_jwt.auth_jwt]>'

# Generated at 2022-06-23 19:52:45.443076
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import httpie.plugins.converter.takeout
    import httpie.plugins.formatter.takeout
    import httpie.plugins.transport.takeout

    pm = PluginManager()
    pm.load_installed_plugins()

    assert pm
    assert httpie.plugins.converter.takeout.TakeoutConverter in pm
    assert httpie.plugins.formatter.takeout.TakeoutFormatter in pm
    assert httpie.plugins.transport.takeout.TakeoutTransportPlugin in pm



# Generated at 2022-06-23 19:52:47.217276
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert type(PluginManager().get_auth_plugin('Basic')) == BasicAuthPlugin


# Generated at 2022-06-23 19:52:50.562687
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    m=PluginManager()
    m.register('hah','hah')
    assert m[0]=='hah' and m[1]=='hah'


# Generated at 2022-06-23 19:52:52.182664
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert isinstance(pm,  PluginManager)


# Generated at 2022-06-23 19:52:56.000457
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pluginManager = PluginManager()
    plugin1 = object()
    pluginManager.register(plugin1)
    plugin2 = object()
    pluginManager.register(plugin2)
    assert pluginManager[0] == plugin1
    assert pluginManager[1] == plugin2
    assert len(pluginManager) == 2
    

# Generated at 2022-06-23 19:52:59.652474
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_pm = PluginManager()
    test_pm.register(CustomAuthPlugin)
    assert test_pm.get_auth_plugin_mapping() == {'test': CustomAuthPlugin}

test_PluginManager_get_auth_plugin_mapping()



# Generated at 2022-06-23 19:53:04.059000
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    if __name__ == '__main__':
        pm = PluginManager()
        #print(pm.get_converters())
        converters = pm.get_converters()
        assert len(converters) == 1
        assert converters[0].converter_type == 'json'


# Generated at 2022-06-23 19:53:11.966469
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    expected_formatters = ["json", "prettyjson", "table", "html", "junit", "csv", "colors", "colors-extended", "uglyjson"]
    assert sorted([i.name for i in pm.get_formatters()]) == expected_formatters
    print("test_get_formatters passed")

if __name__ == "__main__":
    test_PluginManager_get_formatters()

# Generated at 2022-06-23 19:53:13.813554
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(TransportPlugin)
    assert len(pm.get_transport_plugins()) == 1

# Generated at 2022-06-23 19:53:16.055146
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    def get_auth_plugin_mapping():
        plugin_manager = PluginManager()
        plugin_manager.load_installed_plugins()
        plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-23 19:53:24.216000
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    _manager = PluginManager()
    _manager.register(AuthPlugin)
    _manager.register(BasePlugin)

# Generated at 2022-06-23 19:53:28.417807
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin = AuthPlugin()
    plugin_manager.register(plugin)
    assert plugin_manager.filter(AuthPlugin)[0] == plugin
    assert plugin_manager.filter(FormatterPlugin) == []

# Generated at 2022-06-23 19:53:34.268473
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    testPluginManager = PluginManager()
    list1 = testPluginManager.get_converters()
    list2 = [
        'httpie.plugins.converter.json.JsonConverter',
        'httpie.plugins.converter.xml.XmlConverter'
    ]
    assert list1 == list2, "test_PluginManager_get_converters failed"


# Generated at 2022-06-23 19:53:37.004761
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert f'<PluginManager: [{AuthPlugin.__name__}]>' == repr(manager)

# Test get_auth_plugins

# Generated at 2022-06-23 19:53:44.225690
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin1 = AuthPlugin()
    plugin1.auth_type = 'test1'
    plugin2 = AuthPlugin()
    plugin2.auth_type = 'test2'
    plugin_manager = PluginManager()
    plugin_manager.register(plugin1, plugin2)

    expected_plugin_mapping = {'test1': plugin1, 'test2': plugin2}
    assert plugin_manager.get_auth_plugin_mapping() == expected_plugin_mapping


# Generated at 2022-06-23 19:53:45.524418
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(BasePlugin)
    assert BasePlugin in manager

# Generated at 2022-06-23 19:53:51.744217
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class FooBase:
        pass

    class Foo1(FooBase):
        pass

    class Foo2(FooBase):
        pass

    class Foo3(FooBase):
        pass

    class Boo(FooBase):
        pass

    list_of_class = [Foo1,Foo2,Foo3,Boo]
    test_plugin_manager = PluginManager()
    test_plugin_manager.register(*list_of_class)
    test_plugin_manager

    assert test_plugin_manager.filter(FooBase) == list_of_class
    assert test_plugin_manager.filter(Boo) == [Boo]

# Generated at 2022-06-23 19:53:55.404508
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert len(pm) == 0
    print(pm)
    pm.register(1,2,3,4)
    assert len(pm) == 4
    print(pm)

if __name__ == '__main__':
    test_PluginManager_register()

# Generated at 2022-06-23 19:53:57.111787
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plgMng = PluginManager()
    assert plgMng is not None
    assert plgMng == []


# Generated at 2022-06-23 19:54:06.268281
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    installed_auth = plugin_manager.get_auth_plugin_mapping()
    installed_converter = plugin_manager.get_converters()
    installed_formatters = plugin_manager.get_formatters_grouped()
    installed_transports = plugin_manager.get_transport_plugins()

    assert 'digest' in installed_auth
    assert 'json' in installed_converter
    assert 'hex' in installed_formatters
    assert 'httpie.plugins.transport.http' in installed_transports

# Generated at 2022-06-23 19:54:08.876909
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import JSONFormatterPlugin, JSONLinesFormatterPlugin
    plugins = PluginManager()
    plugins.append(JSONFormatterPlugin)
    plugins.append(JSONLinesFormatterPlugin)
    assert len(plugins.get_formatters()) == 2
    assert plugins.get_formatters()[0] == JSONFormatterPlugin
    assert plugins.get_formatters()[1] == JSONLinesFormatterPlugin


# Generated at 2022-06-23 19:54:12.697734
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(PluginManager)
    assert isinstance(plugin_manager, PluginManager)
    assert plugin_manager.__repr__() == '<PluginManager: [<class \'__main__.PluginManager\'>]>'



# Generated at 2022-06-23 19:54:16.235016
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_converters()==[]


# Generated at 2022-06-23 19:54:18.324037
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register(1)
    assert plugins == [1]


# Generated at 2022-06-23 19:54:23.258932
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    AUTH_PLUGIN_MAPPING_TEST = {
        'bearer': 'bearer',
        'basic': 'basic'
    }
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin, BearerAuthPlugin)
    assert AUTH_PLUGIN_MAPPING_TEST == plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-23 19:54:26.946096
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters() == []
    plugin_manager.load_installed_plugins()
    assert len(list(plugin_manager.get_formatters())) > 0


# Generated at 2022-06-23 19:54:35.594187
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # 1. Arrange
    plugin_manager = PluginManager()
    class SubPlugin1(BasePlugin):
        pass
    class SubPlugin2(BasePlugin):
        pass
    class Plugin1(SubPlugin1):
        pass
    class Plugin2(SubPlugin2):
        pass
    class Plugin3(SubPlugin1):
        pass
    class Plugin4(SubPlugin2):
        pass
    plugin_manager.register(Plugin1,
                            Plugin2,
                            Plugin3,
                            Plugin4)
    # 2. Act
    filtered_plugin = plugin_manager.filter(SubPlugin1)
    # 3. Assert
    assert len(filtered_plugin) == 2
    assert filtered_plugin == [Plugin1, Plugin3]

# Generated at 2022-06-23 19:54:36.787207
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    PluginManager.get_auth_plugin(auth_type='http')


# Generated at 2022-06-23 19:54:43.315393
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)

    assert len(plugins.get_formatters_grouped()['Unicode']) == 8

# Generated at 2022-06-23 19:54:52.630031
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import inspect
    from httpie.plugins.base import BasePlugin
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import TransportPlugin

    # Get instances of PluginManager
    plugin_manager = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugin_manager.register(entry_point.load())
   
    # Unit test for method filter of class PluginManager
    assert isinstance(plugin_manager.filter(AuthPlugin), dict)
    assert isinstance(plugin_manager.filter(FormatterPlugin), dict)

# Generated at 2022-06-23 19:54:55.724203
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins[0].__name__ == 'BasicAuthPlugin'

# Generated at 2022-06-23 19:55:01.988144
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(MockAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'mock': MockAuthPlugin}
    plugin_manager.register(MockAuthPlugin2)
    assert plugin_manager.get_auth_plugin_mapping() == {'mock': MockAuthPlugin,
                                                        'mock2': MockAuthPlugin2}


# Generated at 2022-06-23 19:55:06.322792
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # initialize the pluginmanager
    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    # run the original method
    origin = pluginmanager.get_transport_plugins()
    # run the unit test method
    unit = pluginmanager.filter(TransportPlugin)
    # assert two results are the same
    assert origin == unit


# Generated at 2022-06-23 19:55:08.372065
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert plugin_manager.__repr__() == '<PluginManager: []>'

plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:55:13.783830
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = [PluginManager(['test']), PluginManager(['test1', 'test2', 'test3'])]
    for plu in plugins:
        assert plu.__repr__() == f'<PluginManager: {plu}>'



# Generated at 2022-06-23 19:55:14.997014
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    print("test complete")



# Generated at 2022-06-23 19:55:15.611716
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pass

# Generated at 2022-06-23 19:55:21.356801
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class TestPlugin(FormatterPlugin):
        group_name = 'test-plugin'
        list_delimiter = ','
    class TestPlugin2(FormatterPlugin):
        group_name = 'test-plugin'
    class TestPlugin3(FormatterPlugin):
        group_name = 'test-plugin2'
        
    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin, TestPlugin2, TestPlugin3)
    assert len(plugin_manager) == 3
    assert plugin_manager[0] == TestPlugin
    assert plugin_manager[1] == TestPlugin2
    assert plugin_manager[2] == TestPlugin3
    assert isinstance(plugin_manager[0](), TestPlugin)
    assert plugin_manager[0].group_name == 'test-plugin'

# Generated at 2022-06-23 19:55:28.752747
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class ApplesPlugin(BasePlugin):
        pass

    class OrangesPlugin(BasePlugin):
        pass

    class ApplesAndOrangesPlugin(ApplesPlugin, OrangesPlugin):
        pass

    pluginA = ApplesPlugin()
    pluginB = ApplesAndOrangesPlugin()
    pluginC = OrangesPlugin()

    pluginManager = PluginManager()
    pluginManager.register(pluginA, pluginB, pluginC)
    pluginManager.filter()
    pluginManager.filter(ApplesPlugin)
    pluginManager.filter(OrangesPlugin)

# Generated at 2022-06-23 19:55:30.612887
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-23 19:55:37.451975
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    def test_with_elements(obj):
        # GIVEN
        obj.register(object())
        output = '<PluginManager: [<class \'object\'>]>'
        # WHEN
        result = repr(obj)
        # THEN
        assert result == output
    def test_without_elements(obj):
        # GIVEN
        output = '<PluginManager: []>'
        # WHEN
        result = repr(obj)
        # THEN
        assert result == output
    # GIVEN
    obj = PluginManager()
    # WHEN
    # THEN
    test_without_elements(obj)
    test_with_elements(obj)


# Generated at 2022-06-23 19:55:40.657540
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    expected = [AuthPlugin, ConverterPlugin]
    plugins.register(AuthPlugin, ConverterPlugin)
    assert plugins.filter(AuthPlugin) == expected



# Generated at 2022-06-23 19:55:45.309029
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    from httpie.plugins import core
    from httpie.plugins import builtin
    pm.register(core.HTTPiePlugin)
    assert len(pm) == 1
    pm.unregister(core.HTTPiePlugin)
    assert len(pm) == 0
    assert core.HTTPiePlugin not in pm



# Generated at 2022-06-23 19:55:49.832523
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, AuthPlugin, AuthPlugin)
    assert (plugin_manager.get_auth_plugin_mapping() == {
        'auth_test': AuthPlugin,
        'auth_test': AuthPlugin,
        'auth_test': AuthPlugin,
    })


# Generated at 2022-06-23 19:55:52.251032
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'



# Generated at 2022-06-23 19:55:54.384596
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.register(TestPlugin)
    assert manager.get_transport_plugins() == [TestPlugin]


# Generated at 2022-06-23 19:56:03.800145
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import unittest
    from httpie.plugins.builtin.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin
    class AuthPlugin1(AuthPlugin):
        pass
    class AuthPlugin2(AuthPlugin):
        pass
    class FormatterPlugin1(FormatterPlugin):
        pass
    class FormatterPlugin2(FormatterPlugin):
        pass
    class ConverterPlugin1(ConverterPlugin):
        pass
    class ConverterPlugin2(ConverterPlugin):
        pass
    class TransportPlugin1(TransportPlugin):
        pass
    class TransportPlugin2(TransportPlugin):
        pass
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(BasePlugin):
        pass

# Generated at 2022-06-23 19:56:08.845291
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.manager import PluginManager
    manager = PluginManager()
    manager.load_installed_plugins()
    
    # Verify that there is only one group with formatters
    groups = manager.get_formatters_grouped()
    assert len(groups) == 1
    assert list(groups)[0] == 'Formatters'

    # Verify that there is only one element in the group
    group = groups['Formatters']
    assert len(group) == 1

    # Verify that the single element is the default formatter
    from httpie.plugins.formatters.default import DefaultFormatter
    assert group[0] == DefaultFormatter

# Generated at 2022-06-23 19:56:11.715895
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginmanager_obj = PluginManager()

    installed_plugins = pluginmanager_obj.get_formatters()
    installed_plugins = pluginmanager_obj.get_converters()
    print(installed_plugins)
    print(type(installed_plugins))
    assert type(installed_plugins) == list

# Generated at 2022-06-23 19:56:14.908805
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    result = {'auth': AuthPlugin}
    assert plugin_manager.get_auth_plugin_mapping() == result

# Generated at 2022-06-23 19:56:18.389617
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert repr(manager) == '<PluginManager: [httpie_hawk.HawkAuthPlugin, httpie_digest.DigestAuthPlugin, httpie_aws_authv4.AWSv4AuthPlugin]>'


# Generated at 2022-06-23 19:56:21.753653
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    assert pm.get_converters() == []
    pm.register(ConverterPlugin)
    assert pm.get_converters() == [ConverterPlugin]

# Generated at 2022-06-23 19:56:27.391946
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    class Foo:
        pass
    class Bar:
        pass
    class Baz:
        pass
    plugins = PluginManager()
    plugins.register(Foo, Bar, Baz)
    assert plugins[0].__name__ == 'Foo'
    assert plugins[1].__name__ == 'Bar'
    assert plugins[2].__name__ == 'Baz'


# Generated at 2022-06-23 19:56:36.905457
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from collections import Counter
    from httpie.plugins.formatter.json import JSONFormatter
    from httpie.plugins.formatter.colors import ColoredFormatter
    from httpie.plugins.formatter.format import Formatter
    from httpie.plugins.formatter.headers import HeadersFormatter

    PluginManager = PluginManager()
    PluginManager.register(JSONFormatter, ColoredFormatter, Formatter, HeadersFormatter)
    PluginManager.unregister(HeadersFormatter)
    assert(Counter(PluginManager) == Counter([JSONFormatter, ColoredFormatter, Formatter]))

# Generated at 2022-06-23 19:56:44.724725
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # Remove: Python json, Python yaml and Pygments plugins
    # which are already pre-installed with the httpie.
    pm = PluginManager()
    pm.load_installed_plugins()
    converters = pm.get_converters()
    assert len(converters) == len(pm) - 3


plugins = PluginManager()
plugins.load_installed_plugins()

if __name__ == '__main__':
    test_PluginManager_get_converters()

# Generated at 2022-06-23 19:56:47.432850
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugin = BasePlugin
    plugins.register(plugin)
    assert plugin in plugins

# Generated at 2022-06-23 19:56:49.427883
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    assert plugins.get_auth_plugin('bearer') == AuthPlugin
    assert plugins.get_auth_plugin('basic') == AuthPlugin

# Generated at 2022-06-23 19:56:55.603747
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins == []
    plugin = plugins.get_transport_plugins()
    assert plugin == []
    mapping = plugins.get_auth_plugin_mapping()
    assert mapping == {}
    plug = plugins.get_formatters_grouped()
    assert plug == {}
    add = plugins.get_converters()
    assert add == []



# Generated at 2022-06-23 19:56:56.826536
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    p = PluginManager()
    assert len(p.get_formatters()) == 0

# Generated at 2022-06-23 19:57:04.425634
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import TransportPlugin
    from httpie.plugins.base import BasePlugin

    class MockPlugin(BasePlugin):
        pass

    assert '<PluginManager: []>' == str(PluginManager())

    manager = PluginManager()
    manager.register(
        BasePlugin,
        AuthPlugin,
        FormatterPlugin,
        ConverterPlugin,
        TransportPlugin,
        MockPlugin
    )
    assert '<PluginManager: [<class \'BasePlugin\'>, <class \'AuthPlugin\'>, <class \'FormatterPlugin\'>, <class \'ConverterPlugin\'>, <class \'TransportPlugin\'>, <class \'MockPlugin\'>]>' == str(manager)

# Generated at 2022-06-23 19:57:06.496966
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.register(TransportPlugin, TransportPlugin)
    assert len(manager.get_transport_plugins()) == 2
    manager.register(AuthPlugin)
    assert len(manager.get_transport_plugins()) == 2


# Generated at 2022-06-23 19:57:07.731016
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert not plugin_manager
    plugin_manager.load_installed_plugins()
    assert plugin_manager


# Generated at 2022-06-23 19:57:12.226766
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.register(ConverterPlugin, AuthPlugin, TransportPlugin)
    assert not plugins.get_transport_plugins()

    plugins.register(DummyTransport)
    assert plugins.get_transport_plugins() and plugins.get_transport_plugins()[0].name == DummyTransport.name

# Generated at 2022-06-23 19:57:19.521036
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.debug import DebugFormatter
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import ColorsFormatter

    # test for JSONFormatter and ColorsFormatter
    x = PluginManager([FormatterPlugin, JSONFormatter, ColorsFormatter])
    assert x.get_formatters_grouped() == {'Group: Debug': [], 'Group: Colors': [ColorsFormatter], 'Group: JSON': [JSONFormatter]}

    # test for DebugFormatter
    y = PluginManager([FormatterPlugin, DebugFormatter])
    assert y.get_formatters_grouped() == {'Group: Debug': [DebugFormatter], 'Group: Colors': [], 'Group: JSON': []}

    # test

# Generated at 2022-06-23 19:57:24.408122
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin = FormatterPlugin()
    plugin_manager.register(plugin)
    plugin_manager.unregister(plugin)
    print('Unit test for method unregister of class PluginManager,', 'checkpoint 1')
    if len(plugin_manager) == 0:
        print('Unit test for method unregister of class PluginManager,', 'checkpoint 2, pass')


# Generated at 2022-06-23 19:57:26.501560
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager(['A', 'B'])) == "<PluginManager: ['A', 'B']>"



# Generated at 2022-06-23 19:57:30.373525
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    v1 = FormatterPlugin('json', 'test')
    v2 = FormatterPlugin('json', 'test')
    v3 = FormatterPlugin('html', 'test')
    
    manager = PluginManager()
    manager.register(v1, v2, v3)

    assert manager.get_formatters_grouped() == {
        'json': [v1, v2],
        'html': [v3]
    }, "Does not return the expected result"

# Generated at 2022-06-23 19:57:39.757530
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.output.streams import BinaryBytesIO, RawBytesIO
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPNTLMAuth
    from httpie.plugins.converter.gzip import GZIPConverter
    from httpie.plugins.converter.json import JSONConverter
    convertor_list = [
        JSONConverter,
        GZIPConverter,
        HTTPBasicAuth,
        HTTPNTLMAuth,
        BinaryBytesIO,
        RawBytesIO,
    ]
    manager = PluginManager()
    manager.register(*convertor_list)
    assert manager.get_converters() == [
        JSONConverter,
        GZIPConverter,
    ]

# Generated at 2022-06-23 19:57:46.546336
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    '''
    Unit test for method unregister of class PluginManager
    '''

    plugin_mapping = {
            'auth_type1': plugin1,
            'auth_type2': plugin2,
            'auth_type3': plugin3
        }
    plugin_mapping1 = {
            'auth_type1': plugin1,
            'auth_type2': plugin2
        }
    collection = PluginManager()
    collection.register(plugin_mapping)
    assert collection.unregister(plugin3) == plugin_mapping1


# Generated at 2022-06-23 19:57:50.986322
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    out = pluginManager.get_converters()
    assert len(out) == 3

# Generated at 2022-06-23 19:57:52.527036
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins


# Generated at 2022-06-23 19:58:02.673947
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
  manager = PluginManager()
  manager.register(
    BasicAuthPlugin,
    DigestAuthPlugin,
    FragmentDigestAuthPlugin,
    HawkAuthPlugin,
    OAuth1Plugin,
    OAuth2Plugin,
  )
  assert len(manager.get_auth_plugin_mapping()) == 6
  assert manager.get_auth_plugin_mapping()['basic'] == BasicAuthPlugin
  assert manager.get_auth_plugin_mapping()['digest'] == DigestAuthPlugin
  assert manager.get_auth_plugin_mapping()['fragment digest'] == FragmentDigestAuthPlugin
  assert manager.get_auth_plugin_mapping()['hawk'] == HawkAuthPlugin
  assert manager.get_auth_plugin_mapping()['oauth1'] == OAuth1Plugin
  assert manager.get_auth_plugin

# Generated at 2022-06-23 19:58:06.589326
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    list1 = [1, 2, 3, 4]
    list2 = []
    for i in list1:
        list2.append(i)
    list2.remove(3)
    assert list2 == [1, 2, 4]


# Generated at 2022-06-23 19:58:14.537080
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class Plugins:
        class Plugin1(FormatterPlugin):
            group_name = 'group1'

        class Plugin2(FormatterPlugin):
            group_name = 'group2'

        class Plugin3(FormatterPlugin):
            group_name = 'group2'

    manager = PluginManager()
    manager.register(getattr(Plugins, plugin_name) for plugin_name in dir(Plugins) if plugin_name.startswith('Plugin'))
    assert manager.get_formatters() == [Plugins.Plugin1, Plugins.Plugin2, Plugins.Plugin3]


# Generated at 2022-06-23 19:58:20.213551
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.base import FormatterPlugin
    from json import loads

    class GroupAFormatter(FormatterPlugin):
        output_type = 'json'
        group_name = 'A'

    class GroupAFormatter2(FormatterPlugin):
        output_type = 'json'
        group_name = 'A'

    class GroupBFormatter(FormatterPlugin):
        output_type = 'json'
        group_name = 'B'

    pm = PluginManager()
    pm.register(GroupAFormatter, GroupAFormatter2, GroupBFormatter)

    result = pm.get_formatters_grouped()

# Generated at 2022-06-23 19:58:22.728436
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin('basic')

# Generated at 2022-06-23 19:58:31.615343
# Unit test for method get_converters of class PluginManager

# Generated at 2022-06-23 19:58:34.131333
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin = PluginManager()
    assert plugin == []
    assert isinstance(plugin, list)


# Generated at 2022-06-23 19:58:37.973935
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    class plugin:
        pass
    plugin_manager.register(plugin)
    plugin_manager.register(plugin)
    assert(plugin_manager == [plugin,plugin])
    return True


# Generated at 2022-06-23 19:58:42.614717
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    import pytest
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth

    pm = PluginManager()
    pm.register(HTTPBasicAuth, HTTPBearerAuth)

    assert len(pm) == 2
    assert pm[0] == HTTPBasicAuth
    assert pm[1] == HTTPBearerAuth


# Generated at 2022-06-23 19:58:44.616956
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    import httpie
    cm = PluginManager()
    cm.register(httpie.plugins.auth.BasicAuth)
    assert len(cm) == 1

# Generated at 2022-06-23 19:58:47.782033
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    import pytest

    pl_manager = PluginManager()
    pl_manager.register(TestAuthPlugin)
    assert pl_manager.get_auth_plugin('test') == TestAuthPlugin

    with pytest.raises(KeyError):
        pl_manager.get_auth_plugin('not_test')


# Generated at 2022-06-23 19:58:56.851178
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(
        importlib.import_module(
            'httpie.plugins.basic_auth.BasicAuthPlugin'
        ).BasicAuthPlugin
    )
    plugin_manager.register(
        importlib.import_module(
            'httpie.plugins.digest_auth.DigestAuthPlugin'
        ).DigestAuthPlugin
    )

    assert plugin_manager.get_auth_plugins() == [
        importlib.import_module(
            'httpie.plugins.basic_auth.BasicAuthPlugin'
        ).BasicAuthPlugin,
        importlib.import_module(
            'httpie.plugins.digest_auth.DigestAuthPlugin'
        ).DigestAuthPlugin,
    ]

plugin_manager = PluginManager()

# Generated at 2022-06-23 19:59:03.497467
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class DummyClass1(BasePlugin): pass
    class DummyClass2(BasePlugin): pass
    class DummyClass3(BasePlugin): pass
    
    dummy_instance1 = DummyClass1()
    dummy_instance2 = DummyClass2()
    dummy_instance3 = DummyClass3()

    plugin_manager = PluginManager()
    plugin_manager.append(dummy_instance1)
    plugin_manager.append(dummy_instance2)
    plugin_manager.append(dummy_instance3)
    assert plugin_manager.filter() == [dummy_instance1, dummy_instance2, dummy_instance3]
    assert plugin_manager.filter(DummyClass2) == [dummy_instance2]

# Generated at 2022-06-23 19:59:06.162323
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    s = str()
    for plugin in plugins.get_converters():
        s = s + str(plugin())
    print(s)
    return s



# Generated at 2022-06-23 19:59:08.259061
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0
    

# Generated at 2022-06-23 19:59:14.324738
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import JSONStreamConverter
    from httpie.plugins.builtin import UrlencodedConverter
    from httpie.plugins.builtin import RawJSONConverter

    pm = PluginManager()
    pm.register(JSONConverter)
    pm.register(JSONStreamConverter)
    pm.register(UrlencodedConverter)
    pm.register(RawJSONConverter)
    assert pm.get_converters() == [JSONConverter, JSONStreamConverter, UrlencodedConverter, RawJSONConverter]

# Generated at 2022-06-23 19:59:23.188263
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # testcase 1
    plugin=PluginManager()
    plugin.register(object)
    plugin.register(object)
    try:
        assert repr(plugin)=='<PluginManager: [object, object]>'
    except:
        print("Tescase 1 faild")
    # testcase 2
    plugin = PluginManager()
    plugin.register(object)
    plugin.register(object)
    try:
        assert repr(plugin) != '<PluginManager: [object, object]>'
    except:
        print("Tescase 2 pass")
test_PluginManager___repr__()


# Generated at 2022-06-23 19:59:29.114069
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    #Test for '<PluginManager: >'
    expected = '<PluginManager: []>'
    actual = repr(PluginManager())
    assert actual == expected
    #Test for '<PluginManager: [Plugin1, Plugin2]>'
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    pm = PluginManager()
    expected = '<PluginManager: [Plugin1, Plugin2]>'
    actual = repr(pm)
    assert actual == expected


# Generated at 2022-06-23 19:59:33.571326
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) == 60
    assert len(plugin_manager.get_auth_plugins()) == 14

    plugin_manager.get_auth_plugin("basic")

    plugin_manager.get_auth_plugin("bearer")

# Generated at 2022-06-23 19:59:36.130349
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_converters()[0].__name__ == 'JSONConverter'


# Generated at 2022-06-23 19:59:40.118456
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(TestAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'testAuth': TestAuthPlugin}


# Generated at 2022-06-23 19:59:43.978392
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    p_m = PluginManager()
    p_m.load_installed_plugins()
    print(p_m.get_auth_plugins())
    print(p_m.get_auth_plugin_mapping())

# Generated at 2022-06-23 19:59:47.399516
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    assert plugins.get_auth_plugin_mapping() == {}
    plugins.register(AuthPlugin)
    assert plugins.get_auth_plugin_mapping() == {
        'basic': AuthPlugin
    }

# Generated at 2022-06-23 19:59:50.773213
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(TransportPlugin)
    assert plugin_manager.get_auth_plugins() == [AuthPlugin]

# Generated at 2022-06-23 19:59:52.070785
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager)>0

# Generated at 2022-06-23 19:59:59.890957
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():    
    # Create an instance of the object to be tested.
    authplugin = PluginManager()

    # Call the method under test.
    plugin_names = authplugin.get_auth_plugin_mapping()

    assert plugin_names == {
        'basic': httpie.plugins.auth.basic.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest.DigestAuthPlugin,
        'wsse': httpie.plugins.auth.wsse.WsseAuthPlugin
    }



# Generated at 2022-06-23 20:00:01.570319
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert isinstance(plugins, list)
    assert len(plugins) == 0


# Generated at 2022-06-23 20:00:09.706662
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.formatters import FormatterPlugin

    class Formatter(FormatterPlugin):
        group_name = None
        group_title = None

    class JSONFormatter(Formatter):
        group_name = 'json'
        group_title = 'JSON'

    class HTMLFormatter(Formatter):
        group_name = 'html'
        group_title = 'HTML'

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatter, HTMLFormatter)
    assert plugin_manager.get_formatters() == [JSONFormatter, HTMLFormatter]

# Generated at 2022-06-23 20:00:12.257470
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    a = PluginManager()
    # a.register('1','2')
    print(a)


# demo
# https://github.com/psf/requests/blob/master/requests/__init__.py

# Generated at 2022-06-23 20:00:16.564029
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
	PluginManager.unregister(AuthPlugin)
	PluginManager.unregister(FormatterPlugin)
	PluginManager.unregister(ConverterPlugin)
	PluginManager.unregister(TransportPlugin)
	print(FolderManager.unregister(AuthPlugin))
	print(FolderManager.unregister(FormatterPlugin))
	print(FolderManager.unregister(TransportPlugin))
	print(FolderManager.unregister(ConverterPlugin))
test_PluginManager_unregister()

# Generated at 2022-06-23 20:00:18.142439
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    assert len(pluginManager) == 0


# Generated at 2022-06-23 20:00:28.072517
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    print("--- PluginManager: test get_transport_plugins ---")
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_transport_plugins()) == 0
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 1
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 2
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 3
    plugin_manager.register(AuthPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 3
    plugin_manager.register(ConverterPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 3

# Generated at 2022-06-23 20:00:30.437746
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    auth_plugin = AuthPlugin()
    pm.register(auth_plugin)
    assert len(pm) == 1
    assert isinstance(pm[0], AuthPlugin)


# Generated at 2022-06-23 20:00:32.373606
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class T: pass
    pm.register(T)
    assert(pm[0] == T)
    # Unit test for method unregister of class PluginManager

# Generated at 2022-06-23 20:00:36.262250
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()

    from httpie.plugins import auth
    from httpie.plugins.auth import basic
    from httpie.plugins.auth import digest

    plugin_manager.register(basic.BasicAuthPlugin, digest.DigestAuthPlugin)

    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': auth.BasicAuthPlugin,
        'digest': auth.DigestAuthPlugin,
    }

# Generated at 2022-06-23 20:00:46.680666
# Unit test for method get_auth_plugin of class PluginManager

# Generated at 2022-06-23 20:00:47.781948
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    my_manager = PluginManager()
    assert my_manager.get_auth_plugin("basic") == AuthBasicPlugin, True

# Generated at 2022-06-23 20:00:51.835120
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    class Plugin1: pass
    class Plugin2: pass
    class Plugin3: pass
    plugins = PluginManager()
    plugins.register(Plugin1, Plugin2, Plugin3)
    assert repr(plugins) == '<PluginManager: [<class \'httpie.plugin.Plugin1\'>, <class \'httpie.plugin.Plugin2\'>, <class \'httpie.plugin.Plugin3\'>]>'
# --- END OF TEST---