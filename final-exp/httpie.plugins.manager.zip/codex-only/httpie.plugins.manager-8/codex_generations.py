

# Generated at 2022-06-23 19:50:50.259719
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    assert pm.get_formatters() == list()


# Generated at 2022-06-23 19:50:57.520768
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    def check(plugin_manager, auth_type, plugin):
        assert isinstance(plugin_manager.get_auth_plugin(auth_type), plugin)

    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin, DigestAuthPlugin)
    check(plugin_manager, 'basic', BasicAuthPlugin)
    check(plugin_manager, 'digest', DigestAuthPlugin)

# Generated at 2022-06-23 19:51:02.099574
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    expected_output = {'basic': 'httpie.plugins.httpie_auth_plugin.HttpieAuthPlugin', 'digest': 'httpie.plugins.httpie_auth_plugin.HttpieAuthPlugin'}
    check = PluginManager()
    check.register(httpie_auth_plugin.HttpieAuthPlugin)
    assert check.get_auth_plugin_mapping() == expected_output

# Generated at 2022-06-23 19:51:12.197593
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    from httpie.parsers import AuthCredentialsParser
    from httpie.plugins import AuthPlugin

    class BaseAuthPlugin(AuthPlugin):
        auth_type = None
        auth_parse = AuthCredentialsParser()

    class A(BaseAuthPlugin):
        auth_type = 'a'

    class B(BaseAuthPlugin):
        auth_type = 'b'

    pm = PluginManager()
    pm.register(A)
    pm.register(B)

    assert len(pm.get_auth_plugin_mapping()) == 2
    assert 'a' in pm.get_auth_plugin_mapping()
    assert 'b' in pm.get_auth_plugin_mapping()
    assert pm.get_auth_plugin_mapping().get('a').auth_type == 'a'
    assert pm.get_auth

# Generated at 2022-06-23 19:51:18.434873
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    '''
    test_PluginManager_get_auth_plugin
    '''
    local = PluginManager()
    remote = PluginManager()
    with mock.patch.object(local, 'get_auth_plugins') as mock_get_auths:
        remote.get_auth_plugin_mapping()
        remote.get_auth_plugin('basic')
    mock_get_auths.assert_called_once_with()

# Generated at 2022-06-23 19:51:23.955969
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_auth_plugins()) != 0
    assert len(manager.get_formatters()) != 0
    assert len(manager.get_formatters_grouped()) != 0
    assert len(manager.get_converters()) != 0
    assert len(manager.get_transport_plugins()) != 0

# Generated at 2022-06-23 19:51:27.071897
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(test_plugin_auth_plugin)
    plugin_list = plugin_manager.get_auth_plugins()
    assert plugin_list == [test_plugin_auth_plugin]


# Generated at 2022-06-23 19:51:28.761944
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager().filter(by_type=Type[TransportPlugin])

# Generated at 2022-06-23 19:51:36.841086
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class JSONFormatterPlugin(FormatterPlugin):
        name = 'json'
        media_types = ['application/json']
        group_name = 'json'
    class JSONXFormatterPlugin(FormatterPlugin):
        name = 'jsonx'
        media_types = ['application/jsonx']
        group_name = 'json'
    class CSVFormatterPlugin(FormatterPlugin):
        name = 'csv'
        media_types = ['text/csv']
        group_name = 'text'

    plugins = PluginManager()

    plugins.register(JSONFormatterPlugin, JSONXFormatterPlugin, CSVFormatterPlugin)

    expected = {
        'json': [JSONFormatterPlugin, JSONXFormatterPlugin],
        'text': [CSVFormatterPlugin],
    }


# Generated at 2022-06-23 19:51:39.623258
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert 'aws' in plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-23 19:51:48.939901
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import os
    import sys
    import subprocess
    import tempfile
    # find setuptools
    if hasattr(sys, "real_prefix"):
        print("We are in a virtualenv.")
    else:
        print("We are NOT in a virtualenv.")
    try:
        import setuptools
        print("setuptools found at " + os.path.dirname(setuptools.__file__))
    except ImportError:
        print("setuptools not found. Trying to build from source...")
        from subprocess import check_call
        from urllib import urlopen
        from glob import glob
        from os import chdir
        from os.path import abspath, basename, dirname, exists, join
        from shutil import rmtree
        from tarfile import open as tar_open
        setuptools

# Generated at 2022-06-23 19:51:56.635125
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    assert len(plugins) == 0
    
    class Plugin1(BasePlugin):
        pass
    
    class Plugin2(BasePlugin):
        pass
    
    class Plugin3(BasePlugin):
        pass
    
    plugins.register(Plugin1, Plugin2, Plugin3)
    
    assert len(plugins) == 3
    assert plugins[0] == Plugin1
    assert plugins[1] == Plugin2
    assert plugins[2] == Plugin3
    
    plugins.unregister(Plugin2)
    
    assert len(plugins) == 2
    assert plugins[0] == Plugin1
    assert plugins[1] == Plugin3


# Generated at 2022-06-23 19:52:04.606478
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_list = [BasePlugin, AuthPlugin, FormatterPlugin,
                ConverterPlugin, TransportPlugin]
    pluginManager = PluginManager()
    pluginManager.register(*plugin_list)
    assert repr(pluginManager) == "<PluginManager: [<class 'httpie.plugins.base.BasePlugin'>, <class 'httpie.plugins.auth.AuthPlugin'>, <class 'httpie.plugins.formatter.FormatterPlugin'>, <class 'httpie.plugins.converter.ConverterPlugin'>, <class 'httpie.plugins.transport.TransportPlugin'>]>"

# Generated at 2022-06-23 19:52:08.480593
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    class DummyPlugin(BasePlugin):
        pass
    
    pm = PluginManager()
    pm.register(DummyPlugin)
    assert DummyPlugin in pm
    pm.unregister(DummyPlugin)
    assert DummyPlugin not in pm


# Generated at 2022-06-23 19:52:18.038416
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import TransportPlugin
    class TestAuthPlugin1(AuthPlugin):
        pass
    class TestAuthPlugin2(AuthPlugin):
        pass
    class TestFormatterPlugin(FormatterPlugin):
        pass
    class TestConverterPlugin(ConverterPlugin):
        pass
    class TestTransportPlugin(TransportPlugin):
        pass

    pm = PluginManager()
    pm.register(TestAuthPlugin1, TestAuthPlugin2, TestFormatterPlugin, TestConverterPlugin, TestTransportPlugin)
    assert len(pm.get_auth_plugins()) == 2

# Generated at 2022-06-23 19:52:20.874719
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(FTPLineAuthPluginTest)
    assert repr(plugin_manager) == "<PluginManager: [<class 'FTPLineAuthPlugin'>]>"


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:52:24.077978
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    print(manager.get_auth_plugin_mapping())

test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-23 19:52:25.316348
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:52:27.709043
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    import requests
    import httpie
    from httpie.plugins.transport.urllib3 import Urllib3Plugin
    from httpie.plugins.transport.httpcore import Httpc

# Generated at 2022-06-23 19:52:30.861210
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(TransportPlugin)
    assert pm.get_transport_plugins() == [TransportPlugin]
    assert isinstance(pm.get_transport_plugins(), list)



# Generated at 2022-06-23 19:52:33.684778
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_dict = plugin_manager.get_auth_plugin_mapping()
    print(plugin_dict)
    print(plugin_manager)

# Generated at 2022-06-23 19:52:42.492969
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    def foo():
        foo.unregister(foo.get_auth_plugin('basic'))
        if any(plugin.auth_type == 'basic' for plugin in foo.get_auth_plugins()):
            return False
        assert foo.get_auth_plugin('basic') == None
        return True

    # Create manager for input format
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins.unregister(plugins.get_auth_plugin('basic'))

    assert plugins.get_auth_plugin('basic') == None

# Generated at 2022-06-23 19:52:46.234138
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.converter import JSONConverter

    plugins = PluginManager()
    plugins.register(JSONConverter)
    converters = plugins.get_converters()
    assert converters == [JSONConverter]
    assert all(isinstance(plugin, ConverterPlugin) for plugin in converters)



# Generated at 2022-06-23 19:52:47.775407
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pl = PluginManager()
    assert pl == []


# Generated at 2022-06-23 19:52:54.058231
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.register(
        HTTPBasicAuth,
        HTTPBearerAuth,
        HTTPDigestAuth,
        HTTPBearerAuth,
    )
    assert len(plugins) == 3
    assert plugins.get_auth_plugin('basic') == HTTPBasicAuth
    assert plugins.get_auth_plugin('bearer') == HTTPBearerAuth
    assert plugins.get_auth_plugin('digest') == HTTPDigestAuth



# Generated at 2022-06-23 19:52:57.923906
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(BasicAuthPlugin, DigestAuthPlugin, JWTAuthPlugin)
    assert manager.get_auth_plugin('basic') == BasicAuthPlugin
    assert manager.get_auth_plugin('digest') == DigestAuthPlugin
    assert manager.get_auth_plugin('jwt') == JWTAuthPlugin

test_PluginManager_get_auth_plugin()

# Generated at 2022-06-23 19:53:06.405534
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.register(BasePlugin)
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)
    plugins.register(object)
    assert str(plugins) == "<PluginManager: [<class 'httpie.plugins.base.BasePlugin'>, <class 'httpie.plugins.auth.AuthPlugin'>, <class 'httpie.plugins.formatter.FormatterPlugin'>, <class 'httpie.plugins.converter.ConverterPlugin'>, <class 'httpie.plugins.transport.TransportPlugin'>, <class 'object'>]>"


# Generated at 2022-06-23 19:53:12.317813
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class MockPlugin:
        pass

    class Mock1(MockPlugin):
        pass

    class Mock2(MockPlugin):
        pass

    class Mock3(MockPlugin):
        pass

    manager = PluginManager()
    manager.register(Mock2, Mock1, Mock3)

    assert manager.filter(MockPlugin) == [Mock2, Mock1, Mock3]

# Generated at 2022-06-23 19:53:22.351015
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.output.JSONFormat import JSONFormat
    from httpie.output.Formats import Formats
    from httpie.output.PygmentsFormat import PygmentsFormat
    from httpie.output.PrettyFormat import PrettyFormat
    from httpie.output.RawFormat import RawFormat
    from httpie.output.TerminalFormatter import TerminalFormatter
    from httpie.output.formatters.JSONFormatter import JSONFormatter
    from httpie.output.formatters.Formatter import Formatter
    from httpie.output.formatters.FormFormatter import FormFormatter
    from httpie.output.formatters.GraphQLFormatter import GraphQLFormatter
    from httpie.output.formatters.URLEncodedFormatter import URLEncodedFormatter
    from httpie.output.formatters.ImageFormatter import ImageFormatter

# Generated at 2022-06-23 19:53:23.155550
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager() == []

# Generated at 2022-06-23 19:53:25.412735
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'

    plugins.register(type(1))
    assert repr(plugins) == '<PluginManager: [int]>'

plugin_manager = PluginManager()

# Generated at 2022-06-23 19:53:36.085318
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class DummyFormatterPlugin(FormatterPlugin):
        """This is a dummy formatter plugin
        """
        name = "Dummy"
        group_name = "dummy"

    class AnotherDummyFormatterPlugin(FormatterPlugin):
        """This is another dummy formatter plugin"""
        name = "AnotherDummy"
        group_name = "dummy"

    class NotDummyFormatterPlugin(FormatterPlugin):
        """This is not a dummy formatter plugin"""
        name = "NotDummy"
        group_name = "notdummy"

    manager = PluginManager()
    manager.register(DummyFormatterPlugin, NotDummyFormatterPlugin)

# Generated at 2022-06-23 19:53:45.164233
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    class Plugin1(AuthPlugin):
        auth_type = 'plugin1'

    class Plugin2(AuthPlugin):
        auth_type = 'plugin2'

    class Plugin3(AuthPlugin):
        auth_type = 'plugin3'

    class Plugin4(AuthPlugin):
        auth_type = 'plugin4'

    manager = PluginManager()
    manager.register(Plugin1, Plugin2, Plugin3, Plugin4)

    assert manager.get_auth_plugin_mapping() == {
        'plugin1': Plugin1,
        'plugin2': Plugin2,
        'plugin3': Plugin3,
        'plugin4': Plugin4
    }

# Generated at 2022-06-23 19:53:52.679364
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONPathFormatterPlugin, URLEncodeFormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin, ImageFormatterPlugin
    from httpie.plugins.builtin import StreamFormatterPlugin
    PluginManager_test_instance = PluginManager()
    PluginManager_test_instance.register(JSONPathFormatterPlugin, URLEncodeFormatterPlugin, JSONFormatterPlugin, PrettyJSONFormatterPlugin, HTMLFormatterPlugin, ImageFormatterPlugin, StreamFormatterPlugin)
    PluginManager_test_instance.get_formatters_grouped()

# Generated at 2022-06-23 19:53:54.920135
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_converters()) > 0


# Generated at 2022-06-23 19:54:00.595040
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    
    # Check that plugin_manager has the required plugins
    assert any(cls for cls in plugin_manager if issubclass(cls, AuthPlugin))
    assert any(cls for cls in plugin_manager if issubclass(cls, FormatterPlugin))
    assert any(cls for cls in plugin_manager if issubclass(cls, ConverterPlugin))
    assert any(cls for cls in plugin_manager if issubclass(cls, TransportPlugin))

    # Check that all plugins are unique, i.e. no duplicates
    assert len(plugin_manager) == len(set(plugin_manager))


pm = PluginManager()
pm.load_installed_plugins()

# Generated at 2022-06-23 19:54:03.295983
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    manager.append('i am a manager')
    assert repr(manager) == '<PluginManager: [\'i am a manager\']>'



# Generated at 2022-06-23 19:54:05.352713
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # There are 11 plugins in the package httpie
    assert len(PluginManager().load_installed_plugins()) == 11

# Generated at 2022-06-23 19:54:13.392440
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins.register.__doc__ == 'Register a plugin/s.'
    assert plugins.unregister.__doc__ == 'Unregister a plugin.'
    assert plugins.filter.__doc__ == 'Return a sublist containing only the specified types.'
    assert plugins.get_auth_plugins.__doc__ == 'Return the list of AuthPlugins.'
    assert plugins.get_auth_plugin_mapping.__doc__ == 'Return a dict mapping auth types to their AuthPlugins.'
    assert plugins.get_auth_plugin.__doc__ == 'Return the first AuthPlugin matching the given auth type.'
    assert plugins.get_formatters.__doc__ == 'Return the list of FormatterPlugins.'
    assert plugins.get_formatters_grouped.__doc__ == 'Return the list of FormatterPlugins in groups.'

# Generated at 2022-06-23 19:54:15.177558
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()


# Generated at 2022-06-23 19:54:16.580597
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    assert manager.get_formatters() == []

# Generated at 2022-06-23 19:54:22.740347
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_auth_plugin_mapping()
    assert isinstance(plugins, dict)
    assert plugins.keys() == {'AUTH_BASIC', 'AUTH_DIGEST', 'AUTH_JWT', 'AUTH_OAUTH2', 'AUTH_AWS4HMAC'}
    for x in plugins.values():
        assert isinstance(x, type)

test_PluginManager_get_auth_plugin()

# Generated at 2022-06-23 19:54:33.018211
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.output.streams import StdoutStream
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPieStream
    from httpie.auth.base import AuthPlugin
    from httpie.formatter import FormatterPlugin
    from httpie.converters import ConverterPlugin
    from httpie.transport import TransportPlugin
    from httpie import exit_status

    # create a list of plugin object in order to be able to use PluginManager.filter() method
    list_auth: List[Type[BasePlugin]] = [HTTPBasicAuth]
    list_formatter: List[Type[BasePlugin]] = [HTTPiePlugin]
    list_converter: List[Type[BasePlugin]] = [HTTPieStream]
    list_

# Generated at 2022-06-23 19:54:36.711174
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import builtin
    plugin_manager = PluginManager()
    plugin_manager.register(*builtin.BUILTIN_PLUGINS)
    assert len(plugin_manager.get_formatters()) == 21


_manager = PluginManager()
_manager.load_installed_plugins()
plugin_manager = _manager

# Generated at 2022-06-23 19:54:43.221657
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class X(): pass
    class Y(X): pass
    class Z(Y): pass
    class W(X): pass
    plugins = PluginManager()
    plugins.register(W, Z, Y, X)
    assert plugins.filter(X) == [W, Z, Y, X]
    assert plugins.filter(Y) == [Z, Y]
    assert plugins.filter(Z) == [Z]
    assert plugins.filter(W) == [W]

# Generated at 2022-06-23 19:54:52.573440
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert len(pm) == 0
    pm.load_installed_plugins()
    assert len(pm) > 0
    tps = pm.get_transport_plugins()
    assert len(tps) > 0
    assert tps[0].name == 'http'
    assert tps[0].help == 'Use HTTPie as the backend, no special features'

    assert tps[1].name == 'httpie-keyring'
    assert tps[1].help == 'Sends the password through the keychain instead of ' \
                          'the command line, if Keyring is installed'

    assert tps[2].name == 'httpie-oauth2'
    assert tps[2].help == 'Authenticate with OAuth 2.0'


# Generated at 2022-06-23 19:54:56.408441
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class PluginStub(BasePlugin):
        pass

    PLUGIN = PluginStub()
    plugins = PluginManager([PLUGIN])
    plugins.unregister(PluginStub)
    assert plugins == []

# Generated at 2022-06-23 19:55:02.300115
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'
    class TestPlugin(BasePlugin):
        def __repr__(self):
            return 'TestPlugin()'
    plugin_manager.register(TestPlugin)
    # Test for multiple plugins
    assert repr(plugin_manager) == '<PluginManager: [TestPlugin()]>'

plugins = PluginManager()

# Generated at 2022-06-23 19:55:03.237992
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()


# Generated at 2022-06-23 19:55:07.023451
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    assert p == []
    assert p.get_auth_plugin_mapping() == {}
    assert p.get_formatters() == []
    assert p.get_formatters_grouped() == {}
    assert p.get_converters() == []
    assert p.get_transport_plugins() == []

# Generated at 2022-06-23 19:55:14.130239
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager=PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.register()
    assert len(plugin_manager) == 0
    plugin_manager.register(None)
    assert len(plugin_manager) == 0
    class Plugin:
        pass
    plugin_manager.register(Plugin)
    assert len(plugin_manager) == 1


# Generated at 2022-06-23 19:55:15.610004
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()

# Generated at 2022-06-23 19:55:18.359333
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    result = PluginManager([]).get_auth_plugin_mapping()
    assert result == {'basic': httpie.plugins.auth.basic_auth.BasicAuthPlugin, 'digest': httpie.plugins.auth.digest_auth.DigestAuthPlugin}


# Generated at 2022-06-23 19:55:28.006646
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # Parser is used to complete the initialization of the arguments
    args = cli.parser.parse_args([])

    # Create a PluginManager and register the plugins
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # Create a BaseTransport class
    base_transport = TransportPlugin()

    # Get the TransportPlugin from the plugin_manager
    plugins = plugin_manager.get_transport_plugins()

    # Verify that the list of plugins is not empty
    assert plugins != []

    # Verify that all plugins are instances of the BaseTransport class
    for plugin in plugins:
        assert isinstance(plugin, type(base_transport))

# Generated at 2022-06-23 19:55:32.468481
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    plugins = pm.get_auth_plugins()
    assert plugins[0].__name__ == 'HTTPBasicAuth'
    assert plugins[1].__name__ == 'HTTPAuthPlugin'
    assert plugins[2].__name__ == 'HTTPieJWTPlugin'

# Generated at 2022-06-23 19:55:39.493197
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    import re
    import httpie.plugins.auth.basic
    import httpie.plugins.auth.digest
    import httpie.plugins.auth.jwt
    import httpie.plugins.auth.hawk
    import httpie.plugins.auth.ntlm
    import httpie.plugins.auth.aws
    import httpie.plugins.auth.aws4
    import httpie.plugins.auth.netrc
    import httpie.plugins.auth.oauth1
    import httpie.plugins.auth.oauth2

# Generated at 2022-06-23 19:55:43.469497
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_formatters()
    assert len(plugins) > 2
    assert plugins[0].__name__ == 'ColoredStdoutFormatter'
    assert plugins[1].__name__ == 'EchoFormatter'

# Generated at 2022-06-23 19:55:45.508042
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pluginManager = PluginManager()
    print(pluginManager)
    pluginManager.register(BasePlugin)
    print(pluginManager)


# Generated at 2022-06-23 19:55:52.216400
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugins_list = plugin_manager.get_converters()
    assert len(plugins_list) == 0

    plugin_manager.register(ConverterPlugin)
    plugins_list = plugin_manager.get_converters()
    assert len(plugins_list) == 1

    plugin_manager.register(ConverterPlugin)
    plugins_list = plugin_manager.get_converters()
    assert len(plugins_list) == 2

    plugin_manager.unregister(ConverterPlugin)
    plugins_list = plugin_manager.get_converters()
    assert len(plugins_list) == 1


# Generated at 2022-06-23 19:56:00.540174
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import AuthPlugin

    class Plugin1(AuthPlugin):
        auth_type = 'plugin1'

    class Plugin2(AuthPlugin):
        auth_type = 'plugin2'

    class Plugin3(AuthPlugin):
        auth_type = 'plugin3'

    class Plugin4(AuthPlugin):
        auth_type = 'plugin4'

    plugins = PluginManager()
    plugins.register(Plugin1, Plugin2, Plugin3, Plugin4)
    
    assert plugins.get_auth_plugin('plugin1') == Plugin1
    assert plugins.get_auth_plugin('plugin3') == Plugin3
    assert plugins.get_auth_plugin('plugin2') == Plugin2

# Generated at 2022-06-23 19:56:10.403984
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # 测试框架在这里要用到的模块，pytest，unittest，unittest2
    # 测试的是一个类的方法，测试是每个方法都有一个test开头的方法
    # 具体的测试用例在这里写
    pm = PluginManager()
    pm.load_installed_plugins()
    assert hasattr(pm, 'get_converters')

    assert isinstance(pm.get_converters(), list)

# Generated at 2022-06-23 19:56:14.665409
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(Test_PluginManager_get_formatters_1, Test_PluginManager_get_formatters_2)
    formatters = plugins.get_formatters()
    assert len(formatters) == 2
    assert formatters[0] == Test_PluginManager_get_formatters_1
    assert formatters[1] == Test_PluginManager_get_formatters_2


# Generated at 2022-06-23 19:56:18.025118
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.append(AuthPlugin)
    plugin_manager.append(AuthPlugin)
    d = plugin_manager.get_auth_plugin_mapping()
    assert type(d) is dict
    assert len(d) == 1
    assert AuthPlugin in d.values()

# Generated at 2022-06-23 19:56:19.637192
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin = PluginManager()
    assert plugin is not None


# Generated at 2022-06-23 19:56:25.418380
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.register(BasicAuthPlugin)
    pm.register(DigestAuthPlugin)
    pm.register(DigestAuthPlugin)

    auth_types = pm.get_auth_plugin_mapping()
    assert auth_types.get("basic") == BasicAuthPlugin
    assert auth_types.get("digest") == DigestAuthPlugin

# Generated at 2022-06-23 19:56:28.171089
# Unit test for method register of class PluginManager
def test_PluginManager_register():

    plugin_manager = PluginManager()
    plugin_manager.register(1, 2, 3)
    assert plugin_manager == [1, 2, 3]
    assert plugin_manager.filter() == [1, 2, 3]

import pytest


# Generated at 2022-06-23 19:56:39.773214
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugin("basic").auth_type == "basic"
    assert manager.get_auth_plugin("bearer").auth_type == "bearer"
    assert manager.get_auth_plugin("digest").auth_type == "digest"
    assert manager.get_auth_plugin("hawk").auth_type == "hawk"
    assert manager.get_auth_plugin("netrc").auth_type == "netrc"
    assert manager.get_auth_plugin("aws-sigv4").auth_type == "aws-sigv4"
    assert manager.get_auth_plugin("oauth2").auth_type == "oauth2"

# Generated at 2022-06-23 19:56:51.857467
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    import pkg_resources

    class FakeEntryPoint(object):
        def __init__(self, dist, load=None):
            self.dist = dist
            self.load = load

    class FakeDistribution(object):
        def __init__(self, key):
            self.key = key

    class FakePlugin(BasePlugin):
        pass

    class FakePlugin1(FakePlugin):
        pass

    class FakePlugin2(FakePlugin):
        pass

    class FakePlugin3(FakePlugin):
        pass

    class FakePlugin4(FakePlugin):
        pass

    class FakePlugin5(FakePlugin):
        pass

    class FakePlugin6(FakePlugin):
        pass

    from httpie.plugins import core


# Generated at 2022-06-23 19:56:54.970720
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    assert manager.get_auth_plugins() == []
    manager.register(AuthPlugin)
    assert manager.get_auth_plugins() == [AuthPlugin]


# Generated at 2022-06-23 19:56:58.382075
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert not plugin_manager
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert plugin_manager[0].package_name
    assert plugin_manager[0].name



# Generated at 2022-06-23 19:57:00.789726
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import plugin_manager
    list_of_formatters_classes = plugin_manager.get_formatters()
    assert isinstance(list_of_formatters_classes, list)


# Generated at 2022-06-23 19:57:03.578886
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == []


# Generated at 2022-06-23 19:57:07.296745
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plgMgr = PluginManager()
    plgMgr.load_installed_plugins()
    try:
        auth_plugin_mapping = plgMgr.get_auth_plugin_mapping()
    except KeyError:
        assert False
    else:
        assert True

# Generated at 2022-06-23 19:57:16.275047
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
  from httpie.plugins.base import BasePlugin
  from httpie.plugins.converter import ConverterPlugin
  from httpie.plugins.formatter import FormatterPlugin
  from httpie.plugins.transport import TransportPlugin
  from httpie.plugins.auth import AuthPlugin
  test_plugins = [BasePlugin, ConverterPlugin, FormatterPlugin, TransportPlugin, AuthPlugin]
  manager = PluginManager()
  manager.register(*test_plugins)
  assert manager.filter(by_type=ConverterPlugin) == [ConverterPlugin]
  assert manager.filter(by_type=TransportPlugin) == [TransportPlugin]
  assert manager.filter(by_type=FormatterPlugin) == [FormatterPlugin]
  assert manager.filter(by_type=AuthPlugin) == [AuthPlugin]

# Generated at 2022-06-23 19:57:22.313914
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class AuthPlugin1(AuthPlugin):
        auth_type = 'something'

    class AuthPlugin2(AuthPlugin):
        auth_type = 'another'

    class TransportPlugin1(TransportPlugin):
        name = 'transport1'

    class TransportPlugin2(TransportPlugin):
        name = 'transport2'

    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin1, AuthPlugin2, TransportPlugin1,
                            TransportPlugin2)
    assert len(plugin_manager.get_auth_plugins()) == 2
    assert len(plugin_manager.get_transport_plugins()) == 2

    plugin_manager.unregister(AuthPlugin2)
    assert len(plugin_manager.get_auth_plugins()) == 1

    plugin_manager.unregister(TransportPlugin1)

# Generated at 2022-06-23 19:57:23.443629
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()

    assert pm.register() == pm

# Generated at 2022-06-23 19:57:25.981581
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm.get_auth_plugin('basic').__name__ == 'BasicAuthPlugin'
    assert pm.get_auth_plugin('digest').__name__ == 'DigestAuthPlugin'


# Generated at 2022-06-23 19:57:31.419734
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # build an instance of PluginManager
    pm = PluginManager()

    #assert the len of auth plugins is 0
    assert len(pm.get_auth_plugins()) == 0

    #define one class which its base class is AuthPlugin
    class AuthPluginOne(AuthPlugin):
        auth_type = 'testauthone'

    #register the class
    pm.register(AuthPluginOne)

    #get one auth plugin
    auth_plugin_one = pm.get_auth_plugin('testauthone')

    #assert the auth plugins len is 1
    assert len(pm.get_auth_plugins()) == 1

    #assert the auth plugin is the AuthPluginOne
    assert auth_plugin_one == AuthPluginOne


# Generated at 2022-06-23 19:57:32.841687
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager.register(FormatterPlugin)



# Generated at 2022-06-23 19:57:38.848225
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager_test = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            PluginManager_test.register(entry_point.load())
    assert len(PluginManager_test.get_formatters()) == 2


# Generated at 2022-06-23 19:57:40.898860
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.register()
    manager.get_auth_plugins()


# Generated at 2022-06-23 19:57:44.749781
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()
    converters_list = pm.get_converters()
    assert isinstance(converters_list, list)
    for p in converters_list:
        assert issubclass(p, ConverterPlugin)



# Generated at 2022-06-23 19:57:51.926215
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:57:52.847994
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    PluginManager.unregister()

# Generated at 2022-06-23 19:58:01.941115
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    assert plugins.get_auth_plugin('Password') is None

    import httpie_kerberos_auth
    plugins.register(httpie_kerberos_auth.KerberosAuthPlugin)

    import httpie_aws_auth
    plugins.register(httpie_aws_auth.AWSAuthPlugin)

    assert plugins.get_auth_plugin('Password') is None
    assert plugins.get_auth_plugin('Kerberos') == httpie_kerberos_auth.KerberosAuthPlugin
    assert plugins.get_auth_plugin('AWS') == httpie_aws_auth.AWSAuthPlugin
    assert plugins.get_auth_plugin('Password') is None


# Generated at 2022-06-23 19:58:11.718191
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(MockFormatterPlugin, MockFormatterPlugin2)

    # Data provided by MockFormatterPlugin and MockFormatterPlugin2
    output = {'group_name': ['MockFormatterPlugin', 'MockFormatterPlugin2']}
    # Compare output to expected output
    assert(plugin_manager.get_formatters_grouped() == output)


# MockFormatterPlugin and MockFormatterPlugin2 exist just to make test_PluginManager_get_formatters_grouped
# pass.  It is true that they are not formatted plugins, but they are designed to test the functionality
# of the get_formatters_grouped method in the PluginManager class.

# Generated at 2022-06-23 19:58:13.016838
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    assert isinstance(manager, PluginManager)


# Generated at 2022-06-23 19:58:19.077632
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth, HTTPBearerAuth, HTTPProxyAuth
    plugins = PluginManager()
    plugins.register(HTTPBasicAuth, HTTPDigestAuth, HTTPBearerAuth, HTTPProxyAuth)
    plugins.register(HTTPBasicAuth)
    plugins.register(HTTPBasicAuth)
    plugins.register(HTTPBasicAuth)
    get_auth_plugin = plugins.get_auth_plugin
    assert get_auth_plugin('basic') is HTTPBasicAuth
    assert get_auth_plugin('basic') is HTTPBasicAuth
    assert get_auth_plugin('digest') is HTTPDigestAuth
    assert get_auth_plugin('bearer') is HTTPBearerAuth
    assert get_auth_plugin('proxy') is HTTPProxyAuth


manager = PluginManager()

# Generated at 2022-06-23 19:58:22.087957
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager = __import__(__name__).PluginManager
    m = PluginManager()
    m.load_installed_plugins()
    m.get_formatters()

# Generated at 2022-06-23 19:58:30.933598
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plm = PluginManager()
    assert plm.register is not None
    assert plm.unregister is not None
    assert plm.__repr__ is not None
    assert plm.filter is not None
    assert plm.load_installed_plugins is not None
    assert plm.get_auth_plugins is not None
    assert plm.get_auth_plugin_mapping is not None
    assert plm.get_auth_plugin is not None
    assert plm.get_formatters is not None
    assert plm.get_formatters_grouped is not None
    assert plm.get_converters is not None
    assert plm.get_transport_plugins is not None

if __name__ == '__main__':
    test_PluginManager_unregister()

# Generated at 2022-06-23 19:58:40.034724
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    print("**** TEST: test_PluginManager_load_installed_plugins ****")
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print("PluginManager: ", plugin_manager)
    for plugin in plugin_manager:
        print("plugin: ", plugin)
        print("plugin.group_name: ", plugin.group_name)
        print("plugin.package_name: ", plugin.package_name)
        print("plugin.args: ", plugin.args)
        #print("plugin.__doc__: ", plugin.__doc__)


# Generated at 2022-06-23 19:58:42.544314
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    print(plugins)
    assert str(plugins) == '<PluginManager: []>'

# Generated at 2022-06-23 19:58:48.075815
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    import httpie_ntlm
    p=httpie_ntlm.NTLMAuthPlugin()
    p.auth_type='ntlm'

    #plugins = [p]
    #PluginManager.register(plugins)

    pm=PluginManager()

    #pm.register(*plugins)
    pm.append(p)

    plugin_mapping = pm.get_auth_plugin_mapping()
    print(plugin_mapping)

    plugin = pm.get_auth_plugin('ntlm')
    print(plugin)



# Generated at 2022-06-23 19:58:51.713119
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    from httpie.plugins.standard import ExtendedJSONV1

    plugin_manager = PluginManager()
    plugin_manager.register(ExtendedJSONV1)
    assert ExtendedJSONV1 in plugin_manager


# Generated at 2022-06-23 19:58:59.635308
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.manager import PluginManager
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager.get_formatters())

# Generated at 2022-06-23 19:59:03.340575
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # create instance of class PluginManager
    plugin_manager = PluginManager()
    # add plugins to plugin_manager
    plugin_manager.load_installed_plugins()
    # test method get_formatters_grouped of class PluginManager
    assert plugin_manager.get_formatters_grouped()



# Generated at 2022-06-23 19:59:10.739451
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin1 = type('plugin1', (BasePlugin,), {})
    plugin2 = type('plugin2', (AuthPlugin,), {})
    plugin3 = type('plugin3', (AuthPlugin,), {})
    plugin4 = type('plugin4', (ConverterPlugin,), {})
    manager = PluginManager()
    manager.register(plugin1, plugin2, plugin3, plugin4)
    assert manager.filter() == [plugin1, plugin2, plugin3, plugin4]
    assert manager.filter(AuthPlugin) == [plugin2, plugin3]
    assert manager.filter(ConverterPlugin) == [plugin4]
    assert manager.filter(FormatterPlugin) == []

# Generated at 2022-06-23 19:59:12.620521
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # init a plugin manager
    plugin_mananger = PluginManager()
    plugin_mananger.load_installed_plugins()
    assert plugin_mananger.get_auth_plugin('basic')

# Generated at 2022-06-23 19:59:15.551165
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    assert isinstance(pm.get_converters(), list)


# Generated at 2022-06-23 19:59:17.838078
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin('type') == AuthPlugin



# Generated at 2022-06-23 19:59:19.251740
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'



# Generated at 2022-06-23 19:59:29.315915
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    '''
        Method get_formatters_grouped should return a dict with
        formatters grouped
        {'group':[formatters]}
    '''

    class MockFormat1(FormatterPlugin):
        '''
            This mock object is used to simulate a FormatterPlugin
            with group "group1"
        '''

        group_name = 'group1'

    class MockFormat2(FormatterPlugin):
        '''
            This mock object is used to simulate a FormatterPlugin
            with group "group1"
        '''

        group_name = 'group1'

    class MockFormat3(FormatterPlugin):
        '''
            This mock object is used to simulate a FormatterPlugin
            with group "group2"
        '''

        group_name = 'group2'

    plugin_manager = PluginManager()
    plugin

# Generated at 2022-06-23 19:59:38.117745
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.transport.asyncio import AsyncioTransportPlugin, AiohttpTransportPlugin
    from httpie.plugins.transport.curl import CurlTransportPlugin
    from httpie.plugins.transport.local import LocalTransportPlugin
    from httpie.plugins.transport.requests import RequestsTransportPlugin, Urllib3TransportPlugin
    from httpie.plugins.transport.urllib import UrllibTransportPlugin

    assert set(PluginManager().get_transport_plugins()) == {
        UrllibTransportPlugin,
        CurlTransportPlugin,
        AiohttpTransportPlugin,
        RequestsTransportPlugin,
        Urllib3TransportPlugin,
        AsyncioTransportPlugin,
        LocalTransportPlugin
    }


# Generated at 2022-06-23 19:59:46.548994
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    import base64
    from httpie.plugins.converter import ConverterPlugin

    class B64Encoding(ConverterPlugin):
        name = 'b64'
        encoding_name = 'b64'

        def encode(self, obj: object) -> str:
            return base64.b64encode(obj).decode('utf-8')

        def decode(self, b64: str) -> str:
            return base64.b64decode(b64).decode('utf-8')

    assert B64Encoding.encoding_name == "b64"
    pm = PluginManager()
    pm.register(B64Encoding)
    assert len(pm.get_converters()) == 1
    assert pm.get_converters()[0] == B64Encoding
    assert pm.get_converters

# Generated at 2022-06-23 19:59:52.884322
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import HTTPBasicAuth

    plugin_manager = PluginManager()

    plugin_manager.register(HTTPBasicAuth)

    assert repr(plugin_manager) == "<PluginManager: [httpie.plugins.auth.v1.HTTPBasicAuth]>"


manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-23 19:59:58.258548
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.append(type('A', (), {'group_name': 'a'}))
    plugin_manager.append(type('A1', (), {'group_name': 'a'}))
    plugin_manager.append(type('B', (), {'group_name': 'b'}))
    plugin_manager.append(type('C', (), {'group_name': 'c'}))
    plugin_manager.append(type('C1', (), {'group_name': 'c'}))
    plugin_manager.append(type('D', (), {'group_name': 'd'}))

# Generated at 2022-06-23 20:00:02.156855
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(TransportPlugin)
    actual = plugin_manager.get_auth_plugins()
    expected = [AuthPlugin]
    assert actual == expected

test_PluginManager_get_auth_plugins()


# Generated at 2022-06-23 20:00:09.797067
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_converters() == [
        httpie_unixsocket.UnixSocketAuthPlugin,
        httpie_unixsocket.UnixSocketHTTPAdapter,
    ]
    manager.unregister(httpie_unixsocket.UnixSocketHTTPAdapter)
    assert manager.get_converters() == [
        httpie_unixsocket.UnixSocketAuthPlugin,
    ]
    manager.unregister(httpie_unixsocket.UnixSocketAuthPlugin)
    assert manager.get_converters() == []

# Generated at 2022-06-23 20:00:10.999378
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert isinstance(PluginManager(), PluginManager)


# Generated at 2022-06-23 20:00:15.051010
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(
        JsonPlugin,
        PrettyJsonPlugin,
        UrlencodedPlugin)
    assert plugin_manager.get_formatters_grouped() == {
        'json': [JsonPlugin, PrettyJsonPlugin],
        'application/x-www-form-urlencoded': [UrlencodedPlugin]
    }

# Generated at 2022-06-23 20:00:21.735627
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    entry_point_names = ENTRY_POINT_NAMES
    epgroup = entry_point_names[0]
    pm = PluginManager()
    pm.load_installed_plugins()
    assert 'httpie.plugins.auth.v1' in epgroup
    assert 'httpie.plugins.formatter.v1' in epgroup
    assert 'httpie.plugins.converter.v1' in epgroup
    

# Generated at 2022-06-23 20:00:27.072573
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    formatters = [
        FormatterPlugin('a', 'a'),
        FormatterPlugin('b', 'b'),
        FormatterPlugin('b', 'b'),
    ]
    plugin_manager = PluginManager()
    plugin_manager.register(*formatters)
    assert plugin_manager.get_formatters_grouped() == {
        'a': [formatters[0]],
        'b': [formatters[1]],
    }

# Generated at 2022-06-23 20:00:31.832516
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    all_plugins = PluginManager()
    all_plugins.register(SampleAuthPlugin, SampleFormatterPlugin,
                         SampleConverterPlugin, SampleTransportPlugin)
    assert all_plugins.pop().__name__ == 'SampleTransportPlugin'
    assert all_plugins.pop().__name__ == 'SampleConverterPlugin'
    assert all_plugins.pop().__name__ == 'SampleFormatterPlugin'
    assert all_plugins.pop().__name__ == 'SampleAuthPlugin'
    assert len(all_plugins) == 0



# Generated at 2022-06-23 20:00:32.911811
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager().get_auth_plugins()


# Generated at 2022-06-23 20:00:38.798577
# Unit test for constructor of class PluginManager
def test_PluginManager():
	pm = PluginManager()
	pm.register(BasePlugin)
	pm.register(AuthPlugin)
	pm.register(FormatterPlugin)
	pm.register(ConverterPlugin)
	pm.register(TransportPlugin)
	assert len(pm) == 5
	assert BasePlugin in pm
	assert BasePlugin not in pm.get_auth_plugins()
	assert BasePlugin not in pm.get_converters()
	assert BasePlugin not in pm.get_formatters()
	assert BasePlugin not in pm.get_transport_plugins()
	assert AuthPlugin in pm
	assert len(pm.get_auth_plugins()) == 1
	assert AuthPlugin not in pm.get_converters()
	assert AuthPlugin not in pm.get_formatters()
	assert AuthPlugin not in pm.get_transport_plugins()


# Generated at 2022-06-23 20:00:47.521461
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import HTTPiePlugin

    class MockPlugin1(object):
        auth_type = 'mock_a'

    class MockPlugin2(object):
        auth_type = 'mock_b'

    mock_plugin_manager = PluginManager()
    mock_plugin_manager.register(MockPlugin1, HTTPiePlugin)
    mock_plugin_manager.register(MockPlugin2)

    assert mock_plugin_manager.get_auth_plugin('mock_a') == MockPlugin1
    assert mock_plugin_manager.get_auth_plugin('mock_b') == MockPlugin2
    assert mock_plugin_manager.get_auth_plugin('httpie') == HTTPiePlugin

# Generated at 2022-06-23 20:00:51.912642
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie.plugins.builtin
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.register(httpie.plugins.builtin.BuiltinPlugin)
    grouped_formatters = plugin_manager.get_formatters_grouped()
    assert 'Group 1' in grouped_formatters
    assert 'Group 2' in grouped_formatters