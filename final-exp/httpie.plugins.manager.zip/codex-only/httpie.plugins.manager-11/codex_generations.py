

# Generated at 2022-06-23 19:50:51.740978
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_PluginManager = PluginManager()
    test_PluginManager.load_installed_plugins()
    auth_plugin_mapping = test_PluginManager.get_auth_plugin_mapping()
    assert('basic' in auth_plugin_mapping)
    assert('digest' in auth_plugin_mapping)
    assert('hmac' in auth_plugin_mapping)
    assert('jwt' in auth_plugin_mapping)


test_PluginManager()

# Generated at 2022-06-23 19:50:58.993277
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert issubclass(A, PluginManager)
    assert issubclass(A, BasePlugin)

# Generated at 2022-06-23 19:51:02.471541
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    # Testing with empty plugin list
    assert repr(pm) == '<PluginManager: []>'
    # Adding some elements to plugin list
    class test_plugin(BasePlugin):
        """ Plugin class used for unit testing
        """
        package_name = 'test_plugin'
        version = '0.0.1'
    class another_plugin(BasePlugin):
        """ Plugin class used for unit testing
        """
        package_name = 'another_plugin'
        version = '0.0.1'
    pm.register(test_plugin, another_plugin)
    assert repr(pm) == '<PluginManager: [<class \'httpie.plugins.test_plugin\'>, <class \'httpie.plugins.another_plugin\'>]>'




# Generated at 2022-06-23 19:51:09.939155
# Unit test for constructor of class PluginManager
def test_PluginManager():
    class Plugin(BasePlugin):
        pass
    p=PluginManager()
    p.load_installed_plugins()
    assert(p.register(Plugin))
    assert(p.get_auth_plugins())
    assert(p.get_auth_plugins())
    assert(p.get_auth_plugin_mapping())
    assert(p.get_auth_plugin('basic'))
    assert(p.get_formatters())
    assert(p.get_formatters_grouped())
    assert(p.get_converters())
    assert(p.get_transport_plugins())
    assert(p)


# Generated at 2022-06-23 19:51:11.493751
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    lst = plugins.get_auth_plugins()
    assert isinstance(lst, list)


# Generated at 2022-06-23 19:51:16.859665
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Create an instance of class PluginManager
    plugin_manager = PluginManager()
    # Register all plugins
    plugin_manager.load_installed_plugins()
    # Get plugins of AuthPlugin
    auth_plugins = plugin_manager.get_auth_plugins()
    for plugin in auth_plugins:
        print(plugin.auth_type)


# Generated at 2022-06-23 19:51:18.768074
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins == []
    assert isinstance(plugins, PluginManager)


# Generated at 2022-06-23 19:51:22.688069
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert issubclass(PluginManager, list)
    plugins = PluginManager()
    print(plugins)
    plugins.register(*ENTRY_POINT_NAMES)
    print(plugins.filter(AuthPlugin))
    print(plugins.filter(FormatterPlugin))

# Generated at 2022-06-23 19:51:25.099509
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    _list = PluginManager()
    _list.register(SessionAuthPlugin)
    assert (len(list(_list.get_auth_plugins())) == 1)


# Generated at 2022-06-23 19:51:26.704437
# Unit test for constructor of class PluginManager
def test_PluginManager():
    print("Unit test for constructor of class PluginManager")
    pm1 = PluginManager()
    assert pm1 == []
    print("pass")


# Generated at 2022-06-23 19:51:29.314256
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager().register(test_PluginManager)
    assert PluginManager().filter(test_PluginManager)[0] == test_PluginManager



# Generated at 2022-06-23 19:51:31.036663
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager.get_auth_plugins(), list)


# Generated at 2022-06-23 19:51:33.772471
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    assert pm.get_auth_plugins() == []
    pm.load_installed_plugins()
    assert pm.get_auth_plugins() != []


# Generated at 2022-06-23 19:51:35.491728
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    installed_plugins = pm.get_auth_plugins()
    assert installed_plugins

# Generated at 2022-06-23 19:51:41.556546
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm.filter(by_type=Type[AuthPlugin]))
    print(pm.filter(by_type=Type[ConverterPlugin]))
    print(pm.filter(by_type=Type[FormatterPlugin]))
    print(pm.filter(by_type=Type[TransportPlugin]))

# Generated at 2022-06-23 19:51:46.292879
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager
    for plugin in manager:
        assert isinstance(plugin, BasePlugin)
        assert plugin.package_name

if __name__ == "__main__":
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-23 19:51:50.151056
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0




# Generated at 2022-06-23 19:51:54.415840
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm.get_auth_plugins() == []
    assert pm.get_auth_plugin_mapping() == {}
    assert pm.get_formatters() == []
    assert pm.get_converters() == []
    assert pm.get_transport_plugins() == []



# Generated at 2022-06-23 19:52:00.540890
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert len(plugin_manager.filter(by_type=Type[BasePlugin])) == 0
    assert len(plugin_manager.filter(by_type=Type[TransportPlugin])) == 0
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.filter(by_type=Type[TransportPlugin])) == 1
    assert len(plugin_manager.filter(by_type=Type[BasePlugin])) == 1
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.filter(by_type=Type[TransportPlugin])) == 2
    assert len(plugin_manager.filter(by_type=Type[BasePlugin])) == 2

# Generated at 2022-06-23 19:52:05.326221
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins=PluginManager()
    p1=BasePlugin
    p2=BasePlugin
    p3=BasePlugin
    plugins.register(p1,p2,p3)
    plugins.filter(p1)


# Generated at 2022-06-23 19:52:09.094647
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert repr(pm) == '<PluginManager: []>'
    pm.register(PluginManager)
    assert repr(pm) == '<PluginManager: [<class \'httpie.plugins.__init__.PluginManager\'>]>'

# Generated at 2022-06-23 19:52:16.271041
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.load_installed_plugins()
    auth_plugins = manager.get_auth_plugin_mapping()
    assert 'basic' in auth_plugins
    assert 'bearer' in auth_plugins
    assert 'digest' in auth_plugins
    assert 'hawk' in auth_plugins
    assert 'aws4-hmac-sha256' in auth_plugins
    assert 'aws-sig-v4' in auth_plugins
    assert 'aws-sig-v4-streaming' in auth_plugins

# Generated at 2022-06-23 19:52:20.948306
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class FakePlugin1(BasePlugin): pass
    class FakePlugin2(BasePlugin): pass
    class FakePlugin3(BasePlugin): pass
    
    pluginManager = PluginManager()
    
    pluginManager.register(FakePlugin1,FakePlugin2,FakePlugin3)

    pluginManager.unregister(FakePlugin3)

    assert pluginManager.filter() == [FakePlugin1,FakePlugin2]



# Generated at 2022-06-23 19:52:24.834281
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 3


# Generated at 2022-06-23 19:52:26.141239
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert isinstance(pm, list)



# Generated at 2022-06-23 19:52:26.818241
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pass



# Generated at 2022-06-23 19:52:30.097779
# Unit test for method get_auth_plugin_mapping of class PluginManager

# Generated at 2022-06-23 19:52:31.978965
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_transport_plugins()

# Generated at 2022-06-23 19:52:34.157269
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    import pytest
    from httpie.plugins import formatter

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters()
    assert formatter.FormatterPlugin in formatters


# Generated at 2022-06-23 19:52:37.906561
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugins()) == 1


# Generated at 2022-06-23 19:52:42.061297
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters() == []
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) >= 5
    assert len(plugin_manager.get_formatters_grouped()) >= 2

# Generated at 2022-06-23 19:52:44.047632
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugin = BasePlugin()
    plugins.register(plugin)
    assert plugins[0] == plugin


# Generated at 2022-06-23 19:52:50.463573
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    a = PluginManager()
    a.load_installed_plugins()
    print(a.get_converters())
    print(a.get_formatters())
    print(a.get_auth_plugins())
    print(a.get_transport_plugins())


if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-23 19:52:55.152699
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    """
    Unit test for get_auth_plugins.
    """
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert "PluginManager: [httpie_s3_auth.S3AuthPlugin, httpie_oauth1_plugin.OAuth1Plugin, httpie_oauth2_auth.OAuth2AuthPlugin]" == repr(plugins.get_auth_plugins())



# Generated at 2022-06-23 19:53:02.734369
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D:
        pass

    manager = PluginManager()
    manager.register(A, B, C, D)

    assert len(manager.filter()) == 4
    assert len(manager.filter(by_type=A)) == 3
    assert len(manager.filter(by_type=B)) == 2
    assert len(manager.filter(by_type=C)) == 1
    assert len(manager.filter(by_type=D)) == 1

    manager.unregister(D)
    assert len(manager.filter()) == 3
    assert len(manager.filter(by_type=A)) == 3
    assert len(manager.filter(by_type=B)) == 2

# Generated at 2022-06-23 19:53:08.420119
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():

    # setup
    plugin_manager = PluginManager()
    plugin_manager.register(MockTransportPlugin1, MockTransportPlugin2)
    result = None

    # exercise
    result = plugin_manager.get_transport_plugins()

    # verify
    assert result == [MockTransportPlugin1, MockTransportPlugin2]



# Generated at 2022-06-23 19:53:16.202564
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin

    class DummyFormatter1(FormatterPlugin):
        group_name = 'dummy'

    class DummyFormatter2(FormatterPlugin):
        group_name = 'dummy'

    class AnotherFormatter1(FormatterPlugin):
        group_name = 'another'

    plugin_manager = PluginManager()
    plugin_manager.register(DummyFormatter1, DummyFormatter2, AnotherFormatter1)
    assert plugin_manager.get_formatters_grouped() == {
        'dummy': [DummyFormatter1, DummyFormatter2],
        'another': [AnotherFormatter1]
    }

# Generated at 2022-06-23 19:53:19.441759
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    auth_plugins = plugin_manager.get_auth_plugins()
    plugin_manager.get_auth_plugin(auth_type=auth_plugins[0].auth_type)


# Generated at 2022-06-23 19:53:21.196625
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    PluginManager.unregister()
    pass



# Generated at 2022-06-23 19:53:24.272446
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin = PluginManager()
    plugin.load_installed_plugins()
    assert plugin.get_converters() != []
    assert plugin.get_converters()[0].group_name == "json"
    assert plugin.get_converters()[0].convert_table != []


# Generated at 2022-06-23 19:53:26.017617
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    assert plugins.filter() is not None

# Generated at 2022-06-23 19:53:36.523429
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import TransportPlugin
    from httpie.plugins import builtin
    from httpie.plugins.builtin import BaseTransport
    from httpie.plugins.builtin import LocalTransport
    from httpie.plugins.builtin import LocalhostUnixSocketTransport
    from httpie.plugins.builtin import TCP4Transport
    from httpie.plugins.builtin import TCP6Transport

    plugins = PluginManager()
    plugins.register(BaseTransport)
    plugins.register(LocalTransport)
    plugins.register(LocalhostUnixSocketTransport)
    plugins.register(TCP4Transport)
    plugins.register(TCP6Transport)

# Generated at 2022-06-23 19:53:43.663319
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth, JSONConverter, JSONPrettyConverter, JSONPointerConverter, URLEncodedFormConverter

    plugins = PluginManager()
    plugins.register(HTTPBasicAuth, HTTPDigestAuth, JSONConverter, JSONPrettyConverter, JSONPointerConverter, URLEncodedFormConverter)
    assert len(plugins.get_converters()) == 5

# Generated at 2022-06-23 19:53:44.768696
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert AuthPlugin in manager


# Generated at 2022-06-23 19:53:48.019428
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin('bearer')
    assert plugin_manager.get_transport_plugins()[0]
    assert plugin_manager.get_converters()[0]
    assert plugin_manager.get_formatters()[0]

# Generated at 2022-06-23 19:53:55.959725
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # Define variable 'PKG_NAME'
    PKG_NAME = 'httpie'

    # Define variable 'plugin_manager'
    plugin_manager = PluginManager()

    # Call method '__repr__' of 'plugin_manager'
    assert plugin_manager.__repr__() == '<PluginManager: []>'

    # Call method 'register' of 'plugin_manager'
    plugin_manager.register(PKG_NAME)

    # Call method '__repr__' of 'plugin_manager'
    assert plugin_manager.__repr__() == f'<PluginManager: [{PKG_NAME}]>'

# Generated at 2022-06-23 19:54:07.336690
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert not plugin_manager.get_auth_plugins()

    class AuthPluginA(AuthPlugin):
        pass

    class AuthPluginB(AuthPlugin):
        pass

    class AuthPluginC(AuthPlugin):
        pass

    class FormatterPluginA(FormatterPlugin):
        pass

    plugin_manager.register(AuthPluginA, FormatterPluginA)
    assert len(plugin_manager.get_auth_plugins()) == 1
    assert isinstance(plugin_manager.get_auth_plugins()[0], AuthPluginA)

    plugin_manager.register(AuthPluginB, AuthPluginC)
    assert len(plugin_manager.get_auth_plugins()) == 3
    assert plugin_manager.get_auth_plugins()[1] == AuthPluginB
    assert plugin_manager.get_auth_plugins()

# Generated at 2022-06-23 19:54:11.296741
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # Arrange
    import httpie.plugins.converter as converter
    import httpie.plugins.converter.v1.base as base

    converter.__all__ = [base.__name__]
    entry_point_names = [base.__name__]

    manager = PluginManager()

    # Act
    manager.load_installed_plugins()

    # Assert
    assert len(manager.get_converters()) == 1
    assert manager.get_converters()[0].__name__ == base.__name__
    assert manager.get_converters()[0].__module__ == base.__module__

    # Reset
    converter.__all__ = []
    entry_point_names = []


# Generated at 2022-06-23 19:54:22.890022
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    formatters_json = FormatterPlugin()
    formatters_json.group_name = 'json'
    formatters_pretty = FormatterPlugin()
    formatters_pretty.group_name = 'pretty'
    formatters_radio = FormatterPlugin()
    formatters_radio.group_name = 'radio'
    formatters_unix = FormatterPlugin()
    formatters_unix.group_name = 'unix'
    formatters_pipeline = FormatterPlugin()
    formatters_pipeline.group_name = 'pipeline'

    plugin_manager = PluginManager()
    plugin_manager.register(formatters_json)
    plugin_manager.register(formatters_pretty)
    plugin_manager.register(formatters_radio)
    plugin_manager.register(formatters_unix)
    plugin_

# Generated at 2022-06-23 19:54:25.481640
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manger = PluginManager()
    assert plugin_manger.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-23 19:54:29.288523
# Unit test for method register of class PluginManager
def test_PluginManager_register():
  plugins = PluginManager()
  class plugin0(BasePlugin):
    def __init__(self):
      pass
  class plugin1(plugin0):
    def __init__(self):
      pass
  plugins.register(plugin0, plugin1)
  assert plugins == [plugin0, plugin1]
  return

# Generated at 2022-06-23 19:54:33.230366
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    assert pm.get_formatters() == []
    pm.append(httpie.plugins.raw.RawFormatter)
    assert pm.get_formatters() == [httpie.plugins.raw.RawFormatter]



# Generated at 2022-06-23 19:54:34.897950
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert plugin_manager.get_converters() == []


# Generated at 2022-06-23 19:54:36.613470
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(BasePlugin)
    assert plugins.filter() == [BasePlugin]


# Generated at 2022-06-23 19:54:48.061345
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    import os
    dirname = os.path.dirname(__file__)
    path = os.path.join(dirname, '../../httpie/plugins/auth/')
    files = os.listdir(path)
    plugin_list = []
    for file in files:
        if file == '__init__.py':
            continue
        if not file.endswith('.py'):
            continue
        plugin_list.append(file.strip('.py'))

    plugin_mgr = PluginManager()
    plugin_mgr.load_installed_plugins()

    auth_list = plugin_mgr.get_auth_plugins()
    auth_name_list = [auth.implementation.__name__ for auth in auth_list]
    assert set(auth_name_list) == set(plugin_list)



# Generated at 2022-06-23 19:54:51.214103
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # unit test for load_installed_plugins
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_formatters() == []
    assert manager.get_converters()[0].name == 'json'



# Generated at 2022-06-23 19:55:01.040879
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import FormatterPlugin, ConsolePlugin
    from httpie.plugins import JSONPathFormatPlugin
    from httpie.plugins.pretty import PrettyPlugin
    from httpie.plugins.pretty.__main__ import Pretty
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.json.__main__ import JSON
    from httpie.plugins.jsonpath import JSONPathFormat

    class Test(FormatterPlugin):

        def __init__(self, request, filename):
            super(Test, self).__init__(request, filename)

    assert [PrettyPlugin, JSONPlugin, JSONPathFormatPlugin] == PluginManager().get_formatters()



# Generated at 2022-06-23 19:55:05.871506
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(FirstGroupPlugin, SecondGroupPlugin, ThirdGroupPlugin,
                     FourthGroupPlugin)
    assert plugins.get_formatters_grouped() == {
        'first_group': [FirstGroupPlugin],
        'second_group': [SecondGroupPlugin],
        'third_group': [ThirdGroupPlugin],
        'fourth_group': [FourthGroupPlugin],
    }



# Generated at 2022-06-23 19:55:16.505491
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert len(pm.get_transport_plugins()) == 0
    # Fill the instance of PluginManager
    class TestTransportPlugin1(TransportPlugin):
        pass
    class TestTransportPlugin2(TransportPlugin):
        pass
    class TestTransportPlugin3(TransportPlugin):
        pass
    pm.extend((
        TestTransportPlugin1,
        TestTransportPlugin2,
        TestTransportPlugin3))
    assert pm.get_transport_plugins() == [
        TestTransportPlugin1, TestTransportPlugin2, TestTransportPlugin3]


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:55:19.875178
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(ConverterPlugin)
    pm.register(FormatterPlugin)
    pm.register(TransportPlugin)
    result = pm.get_transport_plugins()
    assert isinstance(result, list)
    assert isinstance(result[0], type)
    assert issubclass(result[0], TransportPlugin)

# Generated at 2022-06-23 19:55:23.468696
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.builtin import HTTPBasicAuth

    import pytest
    pm = PluginManager()
    pm.register(HTTPBasicAuth)
    assert pm.get_auth_plugin('basic') == HTTPBasicAuth

# Generated at 2022-06-23 19:55:31.439724
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPNTLMAuth
    from httpie.plugins.builtin import HTTPClientCertAuth, HTTPKerberosAuth, HTTPProxyAuth
    from httpie.plugins.builtin import JSONStreamFormatter, JSONLinesFormatter, URLEncodedFormat
    from httpie.plugins.builtin import RawJSONStreamFormatter, RawJSONLinesFormatter, RawURLEncodedFormat
    from httpie.plugins.builtin import FileUploadConverter, FileDownloadTransport
    from httpie.plugins.builtin import AuthPlugin, FormatterPlugin, ConverterPlugin
    from httpie.plugins.builtin import TransportPlugin

    plugin_

# Generated at 2022-06-23 19:55:35.606939
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.filter(AuthPlugin)) > 0
    assert len(plugin_manager.filter(ConverterPlugin)) > 0
    assert len(plugin_manager.filter(FormatterPlugin)) > 0
    assert len(plugin_manager.filter(TransportPlugin)) > 0

# Generated at 2022-06-23 19:55:46.513593
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    def test_auth_plugins_removed():
        pm = PluginManager()
        assert len(pm.get_auth_plugins()) == 0
        pm.register(test_auth1, test_auth2)
        assert len(pm.get_auth_plugins()) == 2
        pm.unregister(test_auth1)
        assert len(pm.get_auth_plugins()) == 1
        assert test_auth1 not in pm.get_auth_plugins()
        assert test_auth2 in pm.get_auth_plugins()

    def test_all_plugins_removed():
        pm = PluginManager()
        assert len(pm.get_auth_plugins()) == 0
        assert len(pm.get_formatters()) == 0
        assert len(pm.get_converters()) == 0

# Generated at 2022-06-23 19:55:50.294979
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert not plugin_manager
    plugin_manager.register(BasicAuthPlugin, DigestAuthPlugin)
    assert plugin_manager.get_auth_plugin('basic') == BasicAuthPlugin
    assert plugin_manager.get_auth_plugin('digest') == DigestAuthPlugin



# Generated at 2022-06-23 19:55:55.175336
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manger = PluginManager()
    # no transport plugins
    assert plugin_manger.get_transport_plugins() == []
    # the filters of the transport plugins are not the  transport plugins
    plugin_manger.register(FormatterPlugin)
    assert plugin_manger.get_transport_plugins() == []

# Generated at 2022-06-23 19:55:59.536214
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    """
    test function: get_converters()
    :return:
    """
    manager = PluginManager()
    plugin_classes = manager.get_converters()
    assert len(plugin_classes) == 3
    assert all(issubclass(plugin_class, ConverterPlugin)
               for plugin_class in plugin_classes)



# Generated at 2022-06-23 19:56:02.937564
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # test PluginManager.__repr__() return a string indicating the type of the object and its contents
    assert str(type(PluginManager)) == "<class 'list'>"
    # test __repr__ function is a function of type str
    assert type(PluginManager.__repr__) == str

# Generated at 2022-06-23 19:56:05.406659
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.register(TestPlugin)
    assert len(manager.get_auth_plugins()) == 1
    assert type(manager.get_auth_plugins()[0]) == TestPlugin


# Generated at 2022-06-23 19:56:09.843569
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Arrange
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin)
    plugin_manager.register(DigestAuthPlugin)

    # Act
    basic = plugin_manager.get_auth_plugin('basic')
    digest = plugin_manager.get_auth_plugin('digest')

    # Assert
    assert basic == BasicAuthPlugin, \
        f'Expected {BasicAuthPlugin}, got {basic}'
    assert digest == DigestAuthPlugin, \
        f'Expected {DigestAuthPlugin}, got {digest}'


# Generated at 2022-06-23 19:56:14.933455
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # 1. Arrange:
    plugin_manager = PluginManager()

    # 2. Act:
    plugin_manager.register(
        HTTPiePlugin,
        HTTP2Plugin,
        AsyncHTTPiePlugin,
        AsyncHTTP2Plugin
    )

    # 3. Assert:
    assert set(plugin_manager.get_transport_plugins()) == {
        HTTPiePlugin,
        HTTP2Plugin,
        AsyncHTTPiePlugin,
        AsyncHTTP2Plugin
    }

# Generated at 2022-06-23 19:56:18.132013
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert pm.__repr__() == '<PluginManager: []>'
    pm.register(AuthPlugin, AuthPlugin)
    assert pm.__repr__() == '<PluginManager: [AuthPlugin, AuthPlugin]>'

manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-23 19:56:28.802026
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import plugin_manager
    from httpie.compat import urlparse
    import httpie.plugins.auth.basic
    import httpie.plugins.formatter.colors
    import httpie.plugins.transport.sync
    import httpie.plugins.transport.asyncio
    plugin_manager.load_installed_plugins()

    assert httpie.plugins.auth.basic.BasicAuthPlugin() in plugin_manager
    assert httpie.plugins.formatter.colors.ColorsFormatterPlugin() in plugin_manager
    assert httpie.plugins.transport.sync.SyncHTTPPlugin() in plugin_manager
    assert httpie.plugins.transport.asyncio.AsyncioHTTPPlugin() in plugin_manager

    for plugin in plugin_manager:
        assert plugin.package_name is not None


# Generated at 2022-06-23 19:56:33.753118
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert len(pm) == 0
    class FakePlugin:
        pass
    pm.register(FakePlugin)
    assert len(pm) == 1
    assert pm[0] == FakePlugin


# Generated at 2022-06-23 19:56:39.517935
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class testplugin(BasePlugin):
        pass
    class testplugin2(BasePlugin):
        pass
    assert testplugin not in pm
    pm.register(testplugin)
    assert testplugin in pm
    pm.unregister(testplugin)
    assert testplugin not in pm
    pm.register(testplugin,testplugin2)
    assert testplugin in pm
    assert testplugin2 in pm



# Generated at 2022-06-23 19:56:46.867216
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = [AuthPlugin, FormatterPlugin, ConverterPlugin]
    pm = PluginManager()
    pm.register(*plugins)
    s = repr(pm)
    assert s == '<PluginManager: [httpie.plugins.auth.AuthPlugin, ' \
        'httpie.plugins.formatter.FormatterPlugin, ' \
        'httpie.plugins.converter.ConverterPlugin]>'


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:56:49.468430
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert PluginManager().get_auth_plugin('abc') == None
    # print(PluginManager().get_auth_plugin('basic'))


# Generated at 2022-06-23 19:56:52.399579
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(ConverterPlugin)
    pm.register(FormatterPlugin)
    converters = pm.get_converters()
    assert converters == [ConverterPlugin]

# Generated at 2022-06-23 19:56:54.284181
# Unit test for constructor of class PluginManager
def test_PluginManager():
    Manager = PluginManager()
    assert isinstance(Manager, PluginManager)
    assert Manager == []


# Generated at 2022-06-23 19:56:55.572677
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert isinstance(PluginManager(), PluginManager)


# Generated at 2022-06-23 19:56:59.576232
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import default_plugins
    from httpie.client import TCPv4HTTPAdapter, TransportAdapter
    import urllib3
    tcp_plugins = list(
        filter(lambda plugin: isinstance(plugin(), TCPv4HTTPAdapter),
            default_plugins
        )
    )
    assert(len(tcp_plugins) > 0)

# Generated at 2022-06-23 19:57:04.675619
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    pm.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert 'httpie.plugins.auth.AuthPlugin' in repr(pm)
    assert 'httpie.plugins.converter.ConverterPlugin' in repr(pm)
    assert 'httpie.plugins.formatter.FormatterPlugin' in repr(pm)
    pm.unregister(AuthPlugin)
    assert 'httpie.plugins.auth.AuthPlugin' not in repr(pm)
    assert 'httpie.plugins.converter.ConverterPlugin' in repr(pm)

# Generated at 2022-06-23 19:57:06.901393
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    a = PluginManager()
    a.load_installed_plugins()
    #assert len(a.get_converters())==0



# Generated at 2022-06-23 19:57:08.637448
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginmanager = PluginManager()
    assert pluginmanager.get_formatters() == []

    testplugin = type('TestFormatterPlugin', (FormatterPlugin,), {})
    pluginmanager.register(testplugin)
    assert pluginmanager.get_formatters() == [testplugin]


# Generated at 2022-06-23 19:57:16.485461
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.formatter import UnicodeFormatterPlugin, RawFormatterPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie import plugins
    from httpie.compat import is_py26
    from httpie.converter import JSONConverterPlugin
    from httpie.plugins.builtin import ConverterPlugin
    plugin_manager = PluginManager()
    plugins.plugin_manager.register(ConverterPlugin)
    plugins.plugin_manager.register(JSONConverterPlugin)
    plugins.plugin_manager.register(FormatterPlugin)
    plugins.plugin_manager.register(RawFormatterPlugin)
    plugins.plugin_manager.register(UnicodeFormatterPlugin)
    assert True

# Generated at 2022-06-23 19:57:20.640441
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # Setup
    PluginManager.clear()

    plugins_name = ['plugin1', 'plugin2', 'plugin3']

    # Exercise
    for  _ in plugins_name:
        PluginManager.register(BasePlugin)

    # Asserts
    assert issubclass(BasePlugin, PluginManager)


# Generated at 2022-06-23 19:57:21.796787
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    print('Plugin Manager: ', plugin_manager)

# Generated at 2022-06-23 19:57:23.735138
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register(1, 2, 3)
    assert plugin_manager == [1, 2, 3]


# Generated at 2022-06-23 19:57:26.046640
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Arrange
    manager = PluginManager()
    # Act
    auth_plugin_mapping = manager.get_auth_plugin_mapping()
    # Assert
    assert isinstance(auth_plugin_mapping, dict)


# Generated at 2022-06-23 19:57:29.154446
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    class PluginA(BasePlugin):
        pass
    class PluginB(BasePlugin):
        pass

    assert len(manager) == 0

    manager.register(PluginA)
    assert len(manager) == 1

    manager.register(PluginA, PluginB)
    assert len(manager) == 3


# Generated at 2022-06-23 19:57:29.957801
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    a = PluginManager()
    a.get_auth_plugin("http")

# Generated at 2022-06-23 19:57:31.091829
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    PluginManager.unregister()
    assert True

# Generated at 2022-06-23 19:57:33.511869
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(DummyPlugin, DummyPlugin2)
    assert plugins.get_auth_plugins() == []



# Generated at 2022-06-23 19:57:35.839351
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager.__new__(PluginManager)
    print(p)


# Generated at 2022-06-23 19:57:42.058030
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class FooPlugin(BasePlugin):
        pass
    class BarPlugin(BasePlugin):
        pass
    class BazPlugin(BasePlugin):
        pass
    foobarbaz = PluginManager()
    foobarbaz.register(FooPlugin, BarPlugin, BazPlugin)
    assert foobarbaz == [FooPlugin, BarPlugin, BazPlugin]
    foobarbaz.unregister(BarPlugin)
    assert foobarbaz == [FooPlugin, BazPlugin]

# Generated at 2022-06-23 19:57:47.522830
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """Method get_formatters_grouped of class PluginManagerのユニットテスト"""

    # Test for method get_formatters_grouped when HTTPIE_PLUGINS is set
    def test1():
        """Test for method get_formatters_grouped when HTTPIE_PLUGINS is set"""
        # set environment variable HTTPIE_PLUGINS
        os.environ['HTTPIE_PLUGINS'] = 'test_plugins.test_plugin_manager.test_plugin.test_plugin'
        # Load plugins
        import plugins
        plugins_loader = plugins.Loader(plugins.__path__)
        plugins_loader.load_installed_plugins()
        # Create Plugin Manager
        plugin_manager = PluginManager()
        plugin_manager.load_installed_plugins()
        # Test
        registry = plugin_manager.get_formatters

# Generated at 2022-06-23 19:57:57.166270
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register()
    # print(manager.get_formatters_grouped())
    assert manager.get_formatters_grouped() == {'Syntax highlighting': [httpie.plugins.formatter.highlight.HighlightFormatter], 'Pretty printing': [httpie.plugins.formatter.colors.ColorsFormatter, httpie.plugins.formatter.format.FormatFormatter, httpie.plugins.formatter.headers.HeadersFormatter, httpie.plugins.formatter.json.JSONFormatter, httpie.plugins.formatter.jsonb.JSONBFormatter]}

# Generated at 2022-06-23 19:57:58.440359
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    c = plugins.get_auth_plugin('test')
    assert c == None


# Generated at 2022-06-23 19:58:06.592052
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    plugin_manager_formatters = plugin_manager.get_formatters()

    assert len(plugin_manager_formatters) == 3
    assert plugin_manager_formatters[0].__name__ == 'PrettyHTTPiePlugin'
    assert plugin_manager_formatters[1].__name__ == 'SwaggerToHTTPiePlugin'
    assert plugin_manager_formatters[2].__name__ == 'GHGistPlugin'

    plugin_manager_converters = plugin_manager.get_converters()

    assert len(plugin_manager_converters) == 3
    assert plugin_manager_converters[0].__name__ == 'SwaggerToHTTPiePlugin'

# Generated at 2022-06-23 19:58:13.948788
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # Create instance of PluginManager
    plugin_manager = PluginManager()
    # Load plugins
    plugin_manager.load_installed_plugins()
    # Get transport plugins
    transport_plugins = plugin_manager.get_transport_plugins()
    # Check that it is List[Type[TransportPlugin]]
    assert isinstance(transport_plugins, list)
    assert len(transport_plugins) > 0
    # Check that it has only type TransportPlugin
    assert all(map(lambda x: issubclass(x, TransportPlugin), transport_plugins))

# Generated at 2022-06-23 19:58:16.907773
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    p = PluginManager()
    p.register(AWSAuthPlugin, BasicAuthPlugin, DigestAuthPlugin)
    assert p.get_auth_plugin_mapping() == {
        'aws': AWSAuthPlugin,
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin,
    }


plugins = PluginManager()

# Generated at 2022-06-23 19:58:27.065158
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    list_formatter = [
        FormatterPlugin.from_entry_point(
            'httpie.plugins.formatter.v1',
            'httpie_json_pp_formatter',
            'httpie_json_pp_formatter'
        ),
        FormatterPlugin.from_entry_point(
            'httpie.plugins.formatter.v1',
            'httpie_json_formatter',
            'httpie_json_formatter'
        ),
        FormatterPlugin.from_entry_point(
            'httpie.plugins.formatter.v1',
            'httpie_json_formatter',
            'httpie_json_formatter'
        )
    ]
    plugin_manager = PluginManager()
    plugin_manager.register(*list_formatter)
    output = {}

# Generated at 2022-06-23 19:58:30.024670
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.builtin import HTTPBasicAuth

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': HTTPBasicAuth}

# Generated at 2022-06-23 19:58:30.860305
# Unit test for constructor of class PluginManager
def test_PluginManager():
    n = PluginManager()

# Output processing

# Generated at 2022-06-23 19:58:42.186756
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginmanager = PluginManager()
    pluginmanager.register(*ENTRY_POINT_NAMES)
    assert list(pluginmanager) == ENTRY_POINT_NAMES
    pluginmanager.unregister(ENTRY_POINT_NAMES[0])
    assert list(pluginmanager) != ENTRY_POINT_NAMES
    assert pluginmanager.get_formatters() != None
    assert pluginmanager.get_formatters_grouped() != None
    assert pluginmanager.get_converters() != None
    assert pluginmanager.get_auth_plugins() != None
    assert pluginmanager.get_auth_plugin_mapping() != None
    assert pluginmanager.get_auth_plugin("v1") != None

if __name__ == '__main__':
    test_PluginManager()

# Generated at 2022-06-23 19:58:46.688710
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(PluginA):
        pass

    class PluginC(BasePlugin):
        pass

    plugins = PluginManager()
    plugins.register(PluginA, PluginB, PluginC)
    assert plugins.filter(PluginA) == [PluginA, PluginB]
    assert plugins.filter(BasePlugin) == [PluginA, PluginB, PluginC]

# Generated at 2022-06-23 19:58:52.591995
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()

    # verify "raw" request is selected when no option is given in command line
    assert pm.get_transport_plugins()[0].args[0] == ("--raw",)


# We provide a singleton PluginManager for easy access.
# This is mostly for convenience.
plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:58:54.476132
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert isinstance(pm, PluginManager)



# Generated at 2022-06-23 19:59:02.890802
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    # Install new plugins
    pm.register(AuthPlugin)
    pm.register(ConverterPlugin)
    pm.register(FormatterPlugin)
    pm.register(TransportPlugin)
    # Get the plugins installed
    plugins = set(pm.filter(AuthPlugin))
    plugins.add(pm.filter(ConverterPlugin))
    plugins.add(pm.filter(FormatterPlugin))
    plugins.add(pm.filter(TransportPlugin))
    # Set of installed plugins
    set_plugins = {AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin}
    assert plugins == set_plugins


# Generated at 2022-06-23 19:59:08.083593
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class D:
        pass
    class E(D):
        pass
    class F(D):
        pass
    class G(D):
        pass
    plugins = [E,F,G]
    pm = PluginManager()
    pm.register(*plugins)
    assert pm.filter(D) == plugins

# Generated at 2022-06-23 19:59:11.355995
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert len(pm) == 0
    pm.register(TestFormatterPlugin)
    assert len(pm) == 1
    pm.register(TestFormatterPlugin)
    assert len(pm) == 1


# Generated at 2022-06-23 19:59:16.957120
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(CookieAuthPlugin, DigestAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'cookie': CookieAuthPlugin, 'digest': DigestAuthPlugin}

# Generated at 2022-06-23 19:59:19.256165
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_converters()) == 1

# Generated at 2022-06-23 19:59:20.631272
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    assert PluginManager().unregister(AuthPlugin) == None


# Generated at 2022-06-23 19:59:21.935291
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    PluginManager().unregister(AuthPlugin)

# Generated at 2022-06-23 19:59:25.613206
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    if not pluginManager:
        print("PluginManager is empty")
    else:
        print("There are some plugins in PluginManager")


# Generated at 2022-06-23 19:59:30.047466
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager
    plugin_manager.register = MagicMock(return_value = None)
    plugin_manager.get_auth_plugins = MagicMock(
        return_value = [
            [1, 2, 3, 4],
            [5, 6, 7, 8],
        ]
    )

    assert plugin_manager.get_auth_plugin('test')


# Generated at 2022-06-23 19:59:33.203011
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm)

test_PluginManager_load_installed_plugins()


# Generated at 2022-06-23 19:59:34.809428
# Unit test for constructor of class PluginManager
def test_PluginManager():
    # create an instance of class PluginManager
    pm = PluginManager()
    # test if it is empty
    assert not pm


# Generated at 2022-06-23 19:59:37.907066
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    mgr = PluginManager()
    mgr.load_installed_plugins()
    assert(len(mgr) > 0)


# Generated at 2022-06-23 19:59:43.564439
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import BasicAuth
    from httpie.plugins.builtin import DigestAuth

    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuth)
    plugin_manager.register(DigestAuth)
    assert isinstance(plugin_manager.get_auth_plugin('basic'), AuthPlugin)
    assert isinstance(plugin_manager.get_auth_plugin('digest'), AuthPlugin)


# Generated at 2022-06-23 19:59:47.708284
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth)
    assert plugin_manager.get_auth_plugin("basic") == HTTPBasicAuth
    plugin_manager.unregister(HTTPBasicAuth)
    assert plugin_manager.get_auth_plugin("basic") == None


# Generated at 2022-06-23 19:59:54.753995
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    p = PluginManager()
    p.load_installed_plugins()
    assert len(p.get_formatters()) == 3

# Generated at 2022-06-23 19:59:59.258187
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    converters = plugins.get_converters()
    assert isinstance(converters, list)
    assert len(converters) > 0
    for converter in converters:
        assert issubclass(converter, ConverterPlugin)


# Generated at 2022-06-23 20:00:04.325597
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    mgr = PluginManager()
    mgr.register(GitHubAuthPlugin)
    assert len(mgr) == 1
    mgr.unregister(GitHubAuthPlugin)
    assert len(mgr) == 0

test_PluginManager_unregister()

# Generated at 2022-06-23 20:00:06.052171
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(PluginManager)
    assert plugin_manager.get_auth_plugins() == []

# Generated at 2022-06-23 20:00:09.370162
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
  from httpie.plugins import AuthPlugin
  from httpie.plugins.builtin import HTTPBasicAuth
  manager = PluginManager()
  manager.register(HTTPBasicAuth())
  assert manager.get_auth_plugin('basic') == HTTPBasicAuth


# Generated at 2022-06-23 20:00:11.527671
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    registry = PluginManager()
    registry.load_installed_plugins()
    registry.unregister(HTTPBasicAuth)
    assert registry.get_auth_plugin('basic') != HTTPBasicAuth

# Generated at 2022-06-23 20:00:14.854871
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, JSONStreamFormatter
    pm = PluginManager()
    pm.register(HTTPBasicAuth, JSONStreamFormatter)
    assert pm.filter(AuthPlugin) == [HTTPBasicAuth]
    assert pm.filter(FormatterPlugin) == [JSONStreamFormatter]
    assert pm.filter(ConverterPlugin) == []


# Generated at 2022-06-23 20:00:20.343692
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    """
    This function tests method get_auth_plugin() of class PluginManager.
    """
    path = os.path.dirname(__file__)
    os.chdir(path)
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin('basic') is BasicAuthPlugin

# Generated at 2022-06-23 20:00:22.420309
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    assert isinstance(plugins.get_formatters_grouped(), dict)

# Generated at 2022-06-23 20:00:26.021595
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters()
    assert isinstance(formatters, list)
    assert len(formatters) >= 1
    assert all([issubclass(formatter, FormatterPlugin) for formatter in formatters])


# Generated at 2022-06-23 20:00:32.051185
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    a_PluginManager = PluginManager()
    a_PluginManager.register(
        Plugins.Formatter.with_name(
            'my-formatter', 'my-group', 'my-description'))
    a_PluginManager.register(
        Plugins.Formatter.with_name(
            'another-formatter', 'another-group', 'another-description'))
    actual_formatters = a_PluginManager.get_formatters()
    assert actual_formatters[0].name == 'my-formatter'
    assert actual_formatters[1].name == 'another-formatter'

# Generated at 2022-06-23 20:00:33.025754
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    test_objects = PluginManager()
    assert test_objects.get_auth_plugins() == []


# Generated at 2022-06-23 20:00:34.306652
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    plugins = manager.get_transport_plugins()

# Generated at 2022-06-23 20:00:45.628718
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.transport.v1 import TransportPlugin

    pm = PluginManager()
    assert len(pm.get_transport_plugins()) == 1
    assert issubclass(pm.get_transport_plugins()[0], TransportPlugin)


plugin_manager = PluginManager()
plugin_manager.register(
    HTTPAdapterPlugin,
    HTTPXAdapterPlugin,
    GCSAuthPlugin,
    OAuth1Plugin,
    OAuth2Plugin,
    DigestAuthPlugin,
    FileUploadPlugin,
    JSONPlugin,
    JSONLinesPlugin,
    TemplatePlugin,
    FormPlugin,
    URLEncodedPlugin,
    PrettyPlugin,
    ConsolePlugin,
    HeadersPlugin,
    DotDictPlugin,
    HTMLFormatter,
    DefaultFormatter,
)
plugin_manager.load_installed_plugins

# Generated at 2022-06-23 20:00:48.883955
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert pluginManager.get_auth_plugin('basic')
    assert pluginManager.get_auth_plugin('digest')

