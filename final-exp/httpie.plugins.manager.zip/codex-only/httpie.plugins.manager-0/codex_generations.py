

# Generated at 2022-06-23 19:50:50.093111
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.register(MockTransportPlugin)
    assert manager.get_transport_plugins() == [MockTransportPlugin]
    manager.unregister(MockTransportPlugin)


# Generated at 2022-06-23 19:51:02.100380
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # instantiate plugin manager
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin, AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert plugin_manager.__repr__() == '<PluginManager: [<class \'httpie.plugins.base.BasePlugin\'>, <class \'httpie.plugins.auth.AuthPlugin\'>, <class \'httpie.plugins.formatter.FormatterPlugin\'>, <class \'httpie.plugins.converter.ConverterPlugin\'>, <class \'httpie.plugins.transport.TransportPlugin\'>]>'
    # test filter with parameter
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    # test filter without parameter
    assert plugin_manager.filter

# Generated at 2022-06-23 19:51:11.296775
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    assert len(pm) == 0
    assert pm.get_auth_plugins() == []

    pm.register(AuthPlugin)
    assert len(pm) == 1
    assert pm.get_auth_plugins() == [AuthPlugin]

    pm.register(FormatterPlugin)
    assert len(pm) == 2
    assert pm.get_auth_plugins() == [AuthPlugin]

    pm.unregister(AuthPlugin)
    assert len(pm) == 1
    assert pm.get_auth_plugins() == []

    pm.unregister(FormatterPlugin)
    assert len(pm) == 0
    assert pm.get_auth_plugins() == []


# Generated at 2022-06-23 19:51:18.859935
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie import plugins
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth, HTTPTokenAuth
    from httpie.output.formatters.colors import SolarizedDark256Formatter

    assert SolarizedDark256Formatter in plugins.manager.get_formatters()
    assert HTTPBasicAuth in plugins.manager.get_auth_plugins()
    assert HTTPBearerAuth in plugins.manager.get_auth_plugins()
    assert HTTPTokenAuth in plugins.manager.get_auth_plugins()

# Generated at 2022-06-23 19:51:28.631381
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    class AuthPlugin_A(AuthPlugin):
        auth_type = 'A'

    class AuthPlugin_B(AuthPlugin):
        auth_type = 'B'

    class FormatterPlugin_A(FormatterPlugin):
        name = 'A'

    class FormatterPlugin_B(FormatterPlugin):
        name = 'B'

    class ConverterPlugin_A(ConverterPlugin):
        name = 'A'

    class ConverterPlugin_B(ConverterPlugin):
        name = 'B'

    manager = PluginManager()
    manager.register(AuthPlugin_A,
                     AuthPlugin_B,
                     FormatterPlugin_A,
                     FormatterPlugin_B,
                     ConverterPlugin_A,
                     ConverterPlugin_B)


# Generated at 2022-06-23 19:51:29.166935
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert True

# Generated at 2022-06-23 19:51:34.046302
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(test_PluginManager_resolver.testAuthPlugin)
    plugin_map = plugins.get_auth_plugin_mapping()
    assert len(plugin_map) == 1
    assert 'test' in plugin_map
    assert plugin_map['test'] == test_PluginManager_resolver.testAuthPlugin

# AuthPlugin for testing PluginManager.get_auth_plugin_mapping()

# Generated at 2022-06-23 19:51:36.563709
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin, DigestAuthPlugin)
    expected = {"basic": BasicAuthPlugin, "digest": DigestAuthPlugin}
    assert plugin_manager.get_auth_plugin_mapping() == expected

# Generated at 2022-06-23 19:51:39.571071
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    assert pm.get_auth_plugin("bearer") == "plugin.auth.bearer.BearerAuthPlugin"



# Generated at 2022-06-23 19:51:42.774600
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    ret = PluginManager().get_transport_plugins()
    print('The return value of method get_transport_plugins of class PluginManager is {}'.format(ret))


# Generated at 2022-06-23 19:51:48.827070
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    # check for return value of get_formatters()
    assert isinstance(plugins.get_formatters(), list), "Return value of get_formatters() should be list"
    # check for return value of get_formatters_grouped()
    assert isinstance(plugins.get_formatters_grouped(), dict), "Return value of get_formatters_grouped() should be dict"
    # check for return value of get_converters()
    assert isinstance(plugins.get_converters(), list), "Return value of get_converters() should be list"

# Generated at 2022-06-23 19:51:51.609968
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # Given
    pm = PluginManager()
    # When
    pm.register(TransportPlugin)
    # Then
    assert [TransportPlugin] == pm.get_transport_plugins()



# Generated at 2022-06-23 19:51:55.774916
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth)
    mapping = plugin_manager.get_auth_plugin_mapping()

    assert len(mapping) == 1
    assert mapping['basic'] == HTTPBasicAuth

# Generated at 2022-06-23 19:52:02.295944
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    # create instance
    instance = PluginManager()
    # load plugins
    instance.load_installed_plugins()
    # get all formatter plugins
    formatters = instance.get_formatters()
    # print all plugins
    for formatter in formatters:
        print(formatter)

if __name__ == '__main__':
    test_PluginManager_get_formatters()

# Generated at 2022-06-23 19:52:09.012471
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    x = PluginManager()
    assert repr(x) == '<PluginManager: []>'
    from httpie.plugins.builtin import HTTPBasicAuth
    x.register(HTTPBasicAuth)
    assert repr(x) == '<PluginManager: [<class \'httpie.plugins.builtin.HTTPBasicAuth\'>]>'

plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:52:10.340759
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}

# Generated at 2022-06-23 19:52:14.370810
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    plugins = manager.get_auth_plugin_mapping()
    assert plugins


if __name__ == '__main__':
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-23 19:52:15.788765
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pytest.main(["-s", "-v", __file__])



# Generated at 2022-06-23 19:52:19.345425
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert isinstance(pm.get_auth_plugins(), list)
    assert len(pm.get_auth_plugins()) == 1
    assert pm.get_auth_plugins()[0] == AuthPlugin


# Generated at 2022-06-23 19:52:22.277500
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    PluginManager.register(AuthPlugin, FormatterPlugin)
    PluginManager.unregister(AuthPlugin)
    PluginManager.unregister(FormatterPlugin)
    assert PluginManager == []
        

# Generated at 2022-06-23 19:52:25.054283
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # Test the method register of class PluginManager
    pm = PluginManager()
    class PluginTest(BasePlugin):
        pass
    pm.register(PluginTest)
    assert pm[0] == PluginTest


# Generated at 2022-06-23 19:52:33.030842
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_windows
    manager = PluginManager()
    class Formatter1(FormatterPlugin):
        """Formatter1"""
        group_name = 'Group1'
        name = 'Formatter1'
    class Formatter2(FormatterPlugin):
        """Formatter2"""
        group_name = 'Group2'
        name = 'Formatter2'
    class Formatter3(FormatterPlugin):
        """Formatter3"""
        group_name = 'Group1'
        name = 'Formatter3'
    class Formatter4(FormatterPlugin):
        """Formatter4"""
        group_name = 'Group3'
        name = 'Formatter4'
    manager.register(Formatter1)
    manager.register(Formatter2)
   

# Generated at 2022-06-23 19:52:35.265564
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    m = PluginManager()
    m.register()
    assert str(m) == '<PluginManager: []>'


# Generated at 2022-06-23 19:52:40.234790
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    response = PluginManager().get_transport_plugins()
    assert type(response) is list
    assert len(response) > 0
    assert response[0].__name__ == 'RequestsTransport'


# Generated at 2022-06-23 19:52:45.745714
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.mock import ConverterPluginMock
    assert issubclass(ConverterPluginMock, ConverterPlugin)
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_converters()) == 0
    plugin_manager.register(ConverterPluginMock)
    assert len(plugin_manager.get_converters()) == 1


# Generated at 2022-06-23 19:52:46.803410
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == []

# Generated at 2022-06-23 19:52:50.208651
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    formatters = PluginManager([A, B, C, D, E]).get_formatters()
    assert formatters == [A, B, C, D, E]


# Generated at 2022-06-23 19:52:53.937223
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginsManager = PluginManager()
    pluginsManager.register(TestPlugin1)
    pluginsManager.register(TestPlugin2)

    assert pluginsManager.get_auth_plugin_mapping() == {
        'test1': TestPlugin1,
        'test2': TestPlugin2,
    }


# Generated at 2022-06-23 19:52:56.670380
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(MyPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'MyPlugin': MyPlugin}

# Generated at 2022-06-23 19:52:59.394492
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    num_converters = len(plugins.get_converters())
    assert num_converters > 1


# Generated at 2022-06-23 19:53:03.682461
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(FormatterPlugin)
    auth_types = pm.get_auth_plugins()
    assert len(auth_types) == 1
    assert issubclass(auth_types[0], AuthPlugin)


# Generated at 2022-06-23 19:53:14.614371
# Unit test for constructor of class PluginManager

# Generated at 2022-06-23 19:53:16.163876
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert 1 == 1

manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-23 19:53:22.820850
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class MockPluginA(BasePlugin):
        pass

    class MockPluginB(BasePlugin):
        pass

    plugin_manager = PluginManager()
    assert(plugin_manager.filter(by_type=Type[BasePlugin]) == [])

    plugin_manager.register(MockPluginA, MockPluginB)
    assert(plugin_manager.filter(by_type=Type[BasePlugin]) == [MockPluginA, MockPluginB])



# Generated at 2022-06-23 19:53:25.609381
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    # test if auth_type 'bearer' is in mapping of auth_plugins
    assert 'bearer' in pm.get_auth_plugin_mapping()
    # test if auth_plugin is an instance of AuthPlugin
    assert isinstance(pm.get_auth_plugin('bearer'), AuthPlugin)

# Generated at 2022-06-23 19:53:28.262016
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {'auth': AuthPlugin}

# Generated at 2022-06-23 19:53:30.903961
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    plugins.register(AuthPlugin, FormatterPlugin, ConverterPlugin)
    assert(plugins)


# Generated at 2022-06-23 19:53:37.370271
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_list = []
    plugin = PluginManager(plugin_list)
    assert plugin.get_transport_plugins() == []
    plugin.register(TransportPlugin)
    assert plugin.get_transport_plugins() == [TransportPlugin]
    plugin.register(TransportPlugin)
    assert plugin.get_transport_plugins() == [TransportPlugin, TransportPlugin]
    plugin.unregister(TransportPlugin)
    assert plugin.get_transport_plugins() == [TransportPlugin]
    print('method get_transport_plugins of class PluginManager is OK')


# Generated at 2022-06-23 19:53:40.584788
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
        plugin_manager = PluginManager()
        plugin_manager.register(TestPlugin)
        assert TestPlugin in plugin_manager.get_transport_plugins()


# Generated at 2022-06-23 19:53:46.864612
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import auth, transport, converter, formatter
    p = PluginManager()
    p.load_installed_plugins()
    assert len(p.get_auth_plugins()) >= len(auth.plugins)
    assert len(p.get_converters()) >= len(converter.plugins)
    assert len(p.get_formatters()) >= len(formatter.plugins)
    assert len(p.get_transport_plugins()) >= len(transport.plugins)

# Generated at 2022-06-23 19:53:47.747426
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()


# Generated at 2022-06-23 19:53:49.792380
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager, list)
    assert plugin_manager.__repr__() == '<PluginManager: []>'


# Generated at 2022-06-23 19:53:52.866911
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin = PluginManager()
    plugin.register(1)
    plugin.register(2)
    plugin.register(3)
    assert plugin == [1, 2, 3]


# Generated at 2022-06-23 19:53:54.796154
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert isinstance(pm.get_auth_plugin('basic'), AuthPlugin)

# Generated at 2022-06-23 19:54:02.634564
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter.pretty import PrettyFormatter
    from httpie.plugins.formatter.colors import ColorsFormatter
    from httpie.plugins.formatter.format import FormatFormatter

    plugin_manager = PluginManager()
    plugin_manager.register(PrettyFormatter, ColorsFormatter, FormatFormatter)

    assert plugin_manager.get_formatters_grouped() == {
        'format': [FormatFormatter],
        'colors': [ColorsFormatter],
        None: [PrettyFormatter]
    }

# Generated at 2022-06-23 19:54:09.200406
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_transport_plugins()) == 0

    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 1

    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 2

if __name__ == '__main__':
    test_PluginManager_get_transport_plugins()

# Generated at 2022-06-23 19:54:10.218825
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()


# Generated at 2022-06-23 19:54:14.255298
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert (pm.get_transport_plugins() == [])
    pm.unregister(TransportPlugin)
    
    

# Generated at 2022-06-23 19:54:16.235143
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    assert isinstance(pm.get_formatters(), list)


# Generated at 2022-06-23 19:54:20.928034
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p = PluginManager()
    p.register(Plugin1, Plugin2)
    assert len(p.get_transport_plugins()) == 2
    assert p.get_transport_plugins()[0] == Plugin1
    assert p.get_transport_plugins()[1] == Plugin2


# Generated at 2022-06-23 19:54:22.398410
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(FakePlugin)
    assert manager[0] == FakePlugin


# Generated at 2022-06-23 19:54:26.394008
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    converters = pluginManager.get_converters()
    assert len(converters) == 1
    assert converters[0] == ConverterPlugin



# Generated at 2022-06-23 19:54:31.723251
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager.pop(), TransportPlugin)
    assert isinstance(plugin_manager.pop(), FormatterPlugin)
    assert isinstance(plugin_manager.pop(), ConverterPlugin)
    assert isinstance(plugin_manager.pop(), AuthPlugin)


# Generated at 2022-06-23 19:54:33.726944
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin('basic') == AuthPlugin

# Generated at 2022-06-23 19:54:39.492834
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    names = [p.name for p in plugin_manager.filter(TransportPlugin)]
    assert 'httpie' in names
    plugin_manager.unregister(plugin_manager.get_transport_plugins()[0])
    names = [p.name for p in plugin_manager.filter(TransportPlugin)]
    assert 'httpie' not in names

# Generated at 2022-06-23 19:54:43.973726
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    i = p.append(1)
    j = p.append(2)
    assert repr(p) == "<PluginManager: [1, 2]>"
    assert i == None
    assert j == None

# Generated at 2022-06-23 19:54:46.116299
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plg_mg = PluginManager()
    plg_mg.load_installed_plugins()

# Generated at 2022-06-23 19:54:49.195443
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(ConverterPlugin)
    manager.register(FormatterPlugin)
    assert manager.get_formatters_grouped() == {'text': [FormatterPlugin, ConverterPlugin]}
    manager.register(AuthPlugin)
    assert manager.get_formatters_grouped() == {'text': [FormatterPlugin, ConverterPlugin, AuthPlugin]}



# Generated at 2022-06-23 19:54:52.322660
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    list_plugins = PluginManager().filter()
    expected_len = 124
    assert len(list_plugins) == expected_len

if __name__ == '__main__':
    test_PluginManager_filter()

# Generated at 2022-06-23 19:54:56.545658
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()

    # check_register
    assert len(plugins) == 0
    plugins.register(plugins)
    assert len(plugins) == 1
    assert plugins[0] == plugins

#Unit test for method unregister of class PluginManager

# Generated at 2022-06-23 19:55:02.078261
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)  # register a Type() that inherits from BasePlugin
    assert repr(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>]>'
    plugin_manager.unregister(AuthPlugin)
    assert repr(plugin_manager) == '<PluginManager: []>'

# Generated at 2022-06-23 19:55:04.842172
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 5

plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:55:07.077565
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    # TODO: mock plugin classes
    #   - pm.register(mock_class)
    #   - assert all plugin classes display in the group
    pass

# Generated at 2022-06-23 19:55:15.890917
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    print(plugins.get_auth_plugin('basic'))
    print(plugins.get_auth_plugin('digest'))
    print(plugins.get_auth_plugin('jwt'))
    print(plugins.get_auth_plugin('hawk'))
    print(plugins.get_auth_plugin('netrc'))
    print(plugins.get_auth_plugin('oauth1'))
    print(plugins.get_auth_plugin('ntlm'))


# Generated at 2022-06-23 19:55:21.269010
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped is not None

# Generated at 2022-06-23 19:55:28.661186
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    """
    get_auth_plugin: Return what has been registered
    """
    class AuthPlugin1(AuthPlugin):
        auth_type = 'type1'

    class AuthPlugin2(AuthPlugin):
        auth_type = 'type2'

    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin1, AuthPlugin2)

    assert plugin_manager.get_auth_plugin('type1') == AuthPlugin1
    assert plugin_manager.get_auth_plugin('type2') == AuthPlugin2

    

# Generated at 2022-06-23 19:55:31.909188
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(AuthPlugin)
    result = manager.get_auth_plugin_mapping()
    assert result == {'debug': AuthPlugin}, f'expected: {{"debug": AuthPlugin}}; actual: {result}'


# Generated at 2022-06-23 19:55:38.572684
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.builtin import AuthPlugin, FormatterPlugin
    plugin_manager = PluginManager()
    class A(AuthPlugin):
        auth_type = 'A'
    class B(AuthPlugin):
        auth_type = 'B'
    class C(FormatterPlugin):
        group_name = 'C'
    class D(FormatterPlugin):
        group_name = 'D'
    class E(TransportPlugin):
        group_name = 'E'
    class F(TransportPlugin):
        group_name = 'F'

    plugin_manager.register(A, B, C, D, E, F)
    assert plugin_manager.get_auth_plugins() == [A, B]

# Generated at 2022-06-23 19:55:41.633527
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    p = PluginManager()
    p.register(base.AuthPlugin)
    expected = {'basic': base.AuthPlugin}
    assert p.get_auth_plugin_mapping() == expected


# Generated at 2022-06-23 19:55:50.734839
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin

    class AuthPlugin1(AuthPlugin):
        pass

    class FormatterPlugin1(FormatterPlugin):
        pass

    class FormatterPlugin2(FormatterPlugin):
        pass

    class ConverterPlugin1(ConverterPlugin):
        pass

    class ConverterPlugin2(ConverterPlugin):
        pass

    class ConverterPlugin3(ConverterPlugin):
        pass

    pm = PluginManager()
    pm.register(AuthPlugin1, FormatterPlugin1, FormatterPlugin2, ConverterPlugin1, ConverterPlugin2, ConverterPlugin3)

    assert len(pm.filter(AuthPlugin)) == 1
    assert pm.filter(AuthPlugin)[0] == AuthPlugin1

    assert len(pm.filter(FormatterPlugin)) == 2
    assert Form

# Generated at 2022-06-23 19:55:52.775491
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    dict_auth_plugin = plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in dict_auth_plugin


# Generated at 2022-06-23 19:55:57.131974
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(FakePluginAuthBasic)
    plugin_manager.register(FakePluginAuthDigest)
    assert plugin_manager.get_auth_plugin('basic') is FakePluginAuthBasic
    assert plugin_manager.get_auth_plugin('digest') is FakePluginAuthDigest

# Generated at 2022-06-23 19:56:03.610218
# Unit test for constructor of class PluginManager
def test_PluginManager():
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def stdoutIO(stdout):
        old = sys.stdout
        sys.stdout = stdout
        yield
        sys.stdout = old
    f = io.StringIO()
    # Constructor for class PluginManager
    with stdoutIO(f):
        a = PluginManager()
        a.register()
        # print(a)
    # assert f.getvalue() == '<PluginManager: []>'

test_PluginManager()

# Generated at 2022-06-23 19:56:06.712609
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    class A(BasePlugin):
        pass
    class B(BasePlugin):
        pass
    plugin_manager = PluginManager(A, B)
    assert str(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.base.A\'>, <class \'httpie.plugins.base.B\'>]>'


# Generated at 2022-06-23 19:56:10.226191
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pluginManager = PluginManager()
    pluginManager.register(DigestAuthPlugin)
    pluginManager.register(BasicAuthPlugin)
    assert pluginManager.get_auth_plugin('digest') == DigestAuthPlugin
    assert pluginManager.get_auth_plugin('basic') == BasicAuthPlugin

# Generated at 2022-06-23 19:56:11.132785
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager().get_converters() == []


# Generated at 2022-06-23 19:56:17.237021
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(httpie_auth_plugin_httpie_auth_plugin)
    assert plugin_manager.get_auth_plugins() == [httpie_auth_plugin_httpie_auth_plugin]
    assert list(plugin_manager.get_auth_plugin_mapping().values()) == [httpie_auth_plugin_httpie_auth_plugin]
    assert plugin_manager.get_auth_plugin('httpie_auth_plugin') == httpie_auth_plugin_httpie_auth_plugin


# Generated at 2022-06-23 19:56:18.010156
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager.filter()
    pass


# Generated at 2022-06-23 19:56:21.278257
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(BasePlugin)
    assert BasePlugin in plugins
    plugins.unregister(BasePlugin)
    assert BasePlugin not in plugins


# Generated at 2022-06-23 19:56:25.296511
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.load_installed_plugins()

    for plugin in manager:
        manager.unregister(plugin)
    assert not manager
    manager.unregister(plugin)
    assert not manager


# Generated at 2022-06-23 19:56:26.392082
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pass


# Generated at 2022-06-23 19:56:29.385764
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager1 = PluginManager()
    manager1.load_installed_plugins()
    assert len(manager1) > 0

    manager2 = PluginManager()
    manager2.register(AuthPlugin)
    assert len(manager2) == 1

    manager2.load_installed_plugins()
    assert len(manager2) > 1

# Generated at 2022-06-23 19:56:34.794916
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    p = PluginManager()
    assert p.get_auth_plugins() == []
    p.register(PluginManager)
    assert p.get_auth_plugins() == [PluginManager]
    p.unregister(PluginManager)
    assert p.get_auth_plugins() == []

# Generated at 2022-06-23 19:56:36.714774
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    PluginManager = PluginManager()
    result = PluginManager.get_auth_plugin("")
    assert result is None

# Generated at 2022-06-23 19:56:41.613306
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    import sys
    import os
    # Add a directory to the sys.path
    target_dir = os.getcwd() + '/tests/test_plugin'
    sys.path.append(target_dir)
    from test_plugin import TestPlugin
    test_plugin = TestPlugin()
    assert test_plugin.auth_type == 'test'
    assert test_plugin.description == 'test description'
    assert test_plugin.test_var == 'var'
    assert test_plugin.test_method() == True

# Generated at 2022-06-23 19:56:53.246851
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import ConverterPlugin, FormatterPlugin

    class CustomConverter(ConverterPlugin):
        pass

    class CustomFormatter(FormatterPlugin):
        pass

    plugins = PluginManager()
    plugins.register(CustomConverter, CustomFormatter)
    assert CustomConverter in plugins
    assert CustomFormatter in plugins

    assert plugins.filter(ConverterPlugin)
    assert len(plugins.filter(ConverterPlugin)) == 1
    assert len(plugins.filter(FormatterPlugin)) == 1

    plugins.unregister(CustomConverter)
    assert CustomConverter not in plugins
    assert CustomFormatter in plugins

    assert plugins.filter(ConverterPlugin)
    assert len(plugins.filter(ConverterPlugin)) == 0
    assert len(plugins.filter(FormatterPlugin)) == 1

# Generated at 2022-06-23 19:56:55.114947
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_converters()) > 0


# Generated at 2022-06-23 19:56:57.829973
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    pm.register(AuthPlugin,FormatterPlugin)
    assert issubclass(pm[0], AuthPlugin)
    assert issubclass(pm[1], FormatterPlugin)


# Generated at 2022-06-23 19:56:58.709711
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm

# Generated at 2022-06-23 19:57:05.605326
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    TEST_PLUGIN_EP_NAMES = [
        'httpie.test.plugins.auth.v1',
        'httpie.test.plugins.output.v1',
        'httpie.test.plugins.converter.v1',
        'httpie.test.plugins.adapter.v1',
    ]

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    for ep_name in TEST_PLUGIN_EP_NAMES:
        test_ep_name_found = [
            ep_name in str(ep)
            # environ is 'tests'
            for ep in iter_entry_points('httpie.plugins.auth.v1', 'tests')
        ]
        assert any(test_ep_name_found)


# Generated at 2022-06-23 19:57:08.844474
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    def get_auth_plugin_mapping():
        manager = PluginManager()
        manager.register(AuthPlugin)
        return manager.get_auth_plugin_mapping()

    assert get_auth_plugin_mapping() == {}


# Generated at 2022-06-23 19:57:11.590096
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugman = PluginManager()
    plugman.load_installed_plugins()
    assert(len(plugman.get_transport_plugins()) > 0)



# Generated at 2022-06-23 19:57:14.237231
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    assert manager.get_converters() == []
    manager.register(JSONConverter)
    assert manager.get_converters() == [JSONConverter]

# Generated at 2022-06-23 19:57:15.952177
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert isinstance(plugins.get_transport_plugins(), list)


# Generated at 2022-06-23 19:57:18.078338
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert any([
        isinstance(plugin, AuthPlugin) for plugin in plugins
    ])

# Generated at 2022-06-23 19:57:19.449753
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager.get_transport_plugins.__doc__ == 'Get transport plugins'

# Generated at 2022-06-23 19:57:21.406850
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert len(pm) == 0


# Generated at 2022-06-23 19:57:22.554048
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert repr(pm) == '<PluginManager: []>'

# Generated at 2022-06-23 19:57:25.616235
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.append({'httpie.plugins.auth.v1': 'httpie.plugins.auth.basic.BasicAuthPlugin'})
    assert manager.get_auth_plugins() == [{'httpie.plugins.auth.v1': 'httpie.plugins.auth.basic.BasicAuthPlugin'}]

# Generated at 2022-06-23 19:57:28.240044
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class testPlugin(BasePlugin):
        pass
    class testPlugin2(BasePlugin):
        pass
    pm.register(testPlugin)
    pm.register(testPlugin2)
    assert len(pm) == 2


# Generated at 2022-06-23 19:57:31.897354
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class TestPlugin(BasePlugin):
        pass

    class TestPluginChild(TestPlugin):
        pass

    manager = PluginManager()
    manager.register(TestPlugin)
    manager.register(TestPluginChild)

    class OtherPlugin(BasePlugin):
        pass

    plugins = manager.filter(TestPlugin)
    assert plugins == [TestPlugin, TestPluginChild]

    plugins = manager.filter(TestPluginChild)
    assert plugins == [TestPluginChild]

    plugins = manager.filter(OtherPlugin)
    assert plugins == []

# Generated at 2022-06-23 19:57:35.414934
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm.get_auth_plugin("basic") == BasicAuthPlugin
    assert pm.get_auth_plugin("digest") == DigestAuthPlugin

# Generated at 2022-06-23 19:57:37.560672
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    l = [1,2,3,4]
    l.remove(2)
    assert l == [1,3,4]


# Generated at 2022-06-23 19:57:38.484321
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == []

# Generated at 2022-06-23 19:57:41.296638
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # Create instance
    plugin_manager = PluginManager()

    # Call function and assert
    assert plugin_manager.get_converters() == []


# Generated at 2022-06-23 19:57:47.159567
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import HTTPJSONJSONTabularFormatter, HTTPPrettyFormatter, HTTPPrintFormatter, HTTPFormFormatter, HTTPTableFormatter, HTTPStatusFormatter, HTTPDetailedTableFormatter, HTTPCURLFormatter
    lst = [HTTPDetailedTableFormatter, HTTPFormFormatter,HTTPJSONJSONTabularFormatter, HTTPCURLFormatter, HTTPPrintFormatter, HTTPPrettyFormatter, HTTPStatusFormatter, HTTPTableFormatter]
    assert PluginManager().get_formatters_grouped() == {'Per request': [HTTPFormFormatter, HTTPJSONJSONTabularFormatter, HTTPCURLFormatter, HTTPPrintFormatter, HTTPPrettyFormatter, HTTPStatusFormatter], 'Per response': [HTTPDetailedTableFormatter, HTTPTableFormatter]}

# Generated at 2022-06-23 19:57:56.709752
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert PluginManager().get_formatters() == [
        pkg_resources.EntryPoint.parse('json = httpie.plugins.formatter.json:JSONFormatter').load(),
        pkg_resources.EntryPoint.parse('pretty = httpie.plugins.formatter.pretty:PrettyFormatter').load(),
        pkg_resources.EntryPoint.parse('solarized = httpie.plugins.formatter.solarized:SolarizedFormatter').load(),
        pkg_resources.EntryPoint.parse('table = httpie.plugins.formatter.table:TableFormatter').load(),
    ]

# Generated at 2022-06-23 19:57:59.945675
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    auth_plugin = PluginManager()
    auth_plugin.load_installed_plugins()
    assert auth_plugin.get_auth_plugin('basic') == BasicAuthPlugin
    assert auth_plugin.get_auth_plugin('digest') == DigestAuthPlugin

# Generated at 2022-06-23 19:58:01.939208
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.get_auth_plugins() == [AuthPlugin]


# Generated at 2022-06-23 19:58:03.593469
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pass
if __name__ == '__main__':
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-23 19:58:07.870401
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm.get_auth_plugins()
    assert pm.get_formatters()
    assert pm.get_converters()
    assert pm.get_transport_plugins()


# Generated at 2022-06-23 19:58:09.116807
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# Generated at 2022-06-23 19:58:17.787432
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager_a = PluginManager()
    # Testing for different size of PluginManager
    PluginManager_a.register(auth_plugin_X)
    PluginManager_a.register(auth_plugin_Y)
    PluginManager_b = PluginManager()
    PluginManager_b.register(auth_plugin_X)
    PluginManager_b.register(auth_plugin_Y)
    PluginManager_b.register(auth_plugin_Z)
    # Testing for different used plugins
    PluginManager_c = PluginManager()
    PluginManager_c.register(auth_plugin_Y)
    PluginManager_c.register(auth_plugin_Z)
    # Testing for different combination of plugins
    PluginManager_d = PluginManager()
    PluginManager_d.register(auth_plugin_X)

# Generated at 2022-06-23 19:58:21.777280
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuthPlugin)
    assert plugin_manager.get_auth_plugins() == [HTTPBasicAuthPlugin]
    assert plugin_manager.get_auth_plugin_mapping() == {"basic": HTTPBasicAuthPlugin}



# Generated at 2022-06-23 19:58:23.973242
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin)
    assert pluginManager.get_auth_plugin(auth_type='basic') == AuthPlugin

# Generated at 2022-06-23 19:58:26.814584
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin = Type[BasePlugin]
    pm = PluginManager()
    pm.register(plugin)
    assert plugin in pm
    pm.unregister(plugin)
    assert plugin not in pm


# Generated at 2022-06-23 19:58:30.535062
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.load_installed_plugins()
    formatters_grouped = pm.get_formatters_grouped()
    assert len(formatters_grouped) == 5
    assert len([group for group in formatters_grouped.values() if group]) == 4



# Generated at 2022-06-23 19:58:37.420461
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_mgr = PluginManager()
    plugin_mgr.register(MockFormatPlugin('json', 'group1'))
    plugin_mgr.register(MockFormatPlugin('yaml', 'group1'))
    plugin_mgr.register(MockFormatPlugin('json', 'group2'))
    plugin_mgr.register(MockFormatPlugin('yaml', 'group2'))

    result = plugin_mgr.get_formatters_grouped()
    assert len(result) == 2
    assert 'group1' in result
    assert 'group2' in result
    assert len(result['group1']) == 2
    assert len(result['group2']) == 2
    assert result['group1'] != result['group2']



# Generated at 2022-06-23 19:58:43.289458
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(object):
        pass

    class Plugin2(object):
        pass

    class Plugin3(object):
        pass

    pm = PluginManager()
    pm.register(Plugin1, Plugin2, Plugin3)

    expected = [Plugin1, Plugin2, Plugin3]
    assert pm.filter() == expected

    expected = [Plugin2]
    assert pm.filter(Plugin2) == expected

    expected = []
    assert pm.filter(lambda p: False) == expected

# Generated at 2022-06-23 19:58:45.485875
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    try:
        pm.register(BasePlugin, FormatterPlugin)
        assert pm
    except Exception as e:
        raise e



# Generated at 2022-06-23 19:58:48.534012
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class Formatter(FormatterPlugin):
        pass
    pm.register(Formatter)
    assert Formatter in pm.get_formatters()

# Generated at 2022-06-23 19:58:53.446168
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A(BasePlugin): ...
    class B(BasePlugin): ...
    manager = PluginManager()
    manager.register(A, B)
    assert manager.filter(BasePlugin) == [A, B]
    assert manager.filter(A) == [A]
    assert manager.filter(B) == [B]


# Generated at 2022-06-23 19:59:00.135273
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(A)
    manager.register(B)
    manager.register(C)
    manager.register(D)
    manager.register(E)

    assert manager.get_formatters_grouped() == {
        "group_name_1": [A, B],
        "group_name_2": [C, D],
        "group_name_3": [E],
        "group_name_4": []
    }

# Generated at 2022-06-23 19:59:03.574981
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(TestPlugin_1, TestPlugin_2)
    assert len(plugins) == 2
    assert test_plugin_1 in plugins
    assert test_plugin_2 in plugins

    plugins.unregister(TestPlugin_1)
    assert len(plugins) == 1
    assert test_plugin_1 not in plugins
    assert test_plugin_2 in plugins

    plugins.unregister(TestPlugin_2)
    assert len(plugins) == 0
    assert test_plugin_1 not in plugins
    assert test_plugin_2 not in plugins



# Generated at 2022-06-23 19:59:07.763622
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert AuthPlugin in manager
    assert FormatterPlugin in manager
    assert ConverterPlugin in manager
    assert TransportPlugin in manager

    manager.unregister(AuthPlugin)
    assert AuthPlugin not in manager
    manager.unregister(FormatterPlugin)
    assert FormatterPlugin not in manager
    manager.unregister(ConverterPlugin)
    assert ConverterPlugin not in manager
    manager.unregister(TransportPlugin)
    assert TransportPlugin not in manager

# Generated at 2022-06-23 19:59:13.092607
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    class TestAuthPlugin1(AuthPlugin):
        auth_type = 'test_auth_type_1'

    class TestAuthPlugin2(AuthPlugin):
        auth_type = 'test_auth_type_2'

    plugin_manager = PluginManager()
    plugin_manager.register(TestAuthPlugin1, TestAuthPlugin2)
    assert plugin_manager.get_auth_plugin_mapping() == {
        'test_auth_type_1': TestAuthPlugin1,
        'test_auth_type_2': TestAuthPlugin2
    }

# Generated at 2022-06-23 19:59:18.506942
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import httpie.plugins.builtin.transport.http.adapters
    import httpie.plugins.builtin.formatters.json
    import httpie.plugins.builtin.auth.digest
    pm = PluginManager()
    pm.register(*[
        httpie.plugins.builtin.formatters.json.JSONFormatterPlugin,
        httpie.plugins.builtin.transport.http.adapters.HTTPAdapterPlugin,
        httpie.plugins.builtin.auth.digest.DigestAuthPlugin,
    ])
    assert pm.filter(FormatterPlugin) == [
        httpie.plugins.builtin.formatters.json.JSONFormatterPlugin
    ]
    assert pm.filter(AuthPlugin) == [
        httpie.plugins.builtin.auth.digest.DigestAuthPlugin
    ]
    assert pm

# Generated at 2022-06-23 19:59:21.481500
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    _plugin_manager = PluginManager()
    _plugin_manager.register(BasePlugin)
    _plugin_manager.unregister(BasePlugin)
    assert len(_plugin_manager)==0

# Generated at 2022-06-23 19:59:23.589847
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins.get_formatters()) > 0

# Generated at 2022-06-23 19:59:26.823199
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    a = PluginManager()
    a.load_installed_plugins()
    print(a)
    print()
    print(a.get_formatters())
    print()
    print(a.get_formatters_grouped())


# Generated at 2022-06-23 19:59:28.658342
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
   plugins_manager = PluginManager()
   assert repr(plugins_manager) == '<PluginManager: []>', 'PluginManager variable contains incorrect value'

# Generated at 2022-06-23 19:59:34.726778
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    class PluginOne(BasePlugin):
        pass
    class PluginTwo(BasePlugin):
        pass
    plugin_manager = PluginManager()
    plugin_manager.register(PluginOne)
    plugin_manager.register(PluginTwo)
    assert str(plugin_manager) == '<PluginManager: [<class \'tests.httpie.test_plugin_manager.PluginOne\'>, <class \'tests.httpie.test_plugin_manager.PluginTwo\'>]>'

# Generated at 2022-06-23 19:59:39.570990
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_auth_plugins()) > 0
    plugin = manager.get_auth_plugins()[0]
    manager.unregister(plugin)
    assert plugin not in manager.get_auth_plugins()

# Generated at 2022-06-23 19:59:47.040797
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    print(help(PluginManager))

    manager = PluginManager()
    #manager.register(ConverterPlugin)
    #manager.register(FormatterPlugin)
    #manager.register(TransportPlugin)
    manager.load_installed_plugins()

    #manager.get_formatters()
    result = manager.get_formatters_grouped()
    print(result)

if __name__ == '__main__':
    test_PluginManager_get_formatters()

# Generated at 2022-06-23 19:59:48.888089
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 4



# Generated at 2022-06-23 19:59:51.408192
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm.__repr__() == f'<PluginManager: {list(pm)}>'


# Generated at 2022-06-23 19:59:55.248640
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    all_plugins = PluginManager()
    all_plugins.load_installed_plugins()
    for auth_type in all_plugins.get_auth_plugin_mapping():
        # plugin is the class of auth plugin
        plugin = all_plugins.get_auth_plugin(auth_type)
        assert(issubclass(plugin, BasePlugin))


# Generated at 2022-06-23 20:00:04.557485
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(NetrcAuthPlugin)
    pm.register(MultiAuthPlugin)
    pm.register(DigestAuthPlugin)
    pm.register(BasicAuthPlugin)
    pm.register(BearerAuthPlugin)
    pm.register(AWS4AuthPlugin)
    pm.register(WSSEAuthPlugin)
    assert pm.get_auth_plugin_mapping() == {
        "basic": BasicAuthPlugin,
        "bearer": BearerAuthPlugin,
        "digest": DigestAuthPlugin,
        "multi": MultiAuthPlugin,
        "aws4": AWS4AuthPlugin,
        "wsse": WSSEAuthPlugin,
        "netrc": NetrcAuthPlugin,
    }
    assert pm.get_auth_plugin("aws4") == AWS4AuthPlugin

# Generated at 2022-06-23 20:00:05.456906
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager().get_auth_plugins() == []


# Generated at 2022-06-23 20:00:14.019619
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import TransportPlugin
    from httpie.plugins.builtin import BasicAuthPlugin
    from httpie.plugins.builtin import DigestAuthPlugin
    from httpie.plugins.builtin import JSONConverterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import URLEncodedConverterPlugin
    from httpie.plugins.builtin import NullAuthPlugin
    from httpie.plugins.builtin import TREQTransportPlugin
   

# Generated at 2022-06-23 20:00:15.858413
# Unit test for constructor of class PluginManager
def test_PluginManager():
    test_PluginManager = PluginManager()

    assert test_PluginManager.filter(ConverterPlugin)[0].package_name == "httpie-0.9.9"


# Generated at 2022-06-23 20:00:22.863487
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginContainer=PluginManager()
    pluginContainer.load_installed_plugins()
    expected_formatters = ['csv','F1','F2','F3','F4','F5','F6','F7','F8','F9','json','jsonl','ltsv','pretty','pretty_stream','table','tsv']
    assert {i.name for i in pluginContainer.get_formatters()} == set(expected_formatters)


# Generated at 2022-06-23 20:00:30.082838
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin

    class FormatterPluginA(FormatterPlugin):
        group_name = 'A'

    class FormatterPluginB(FormatterPlugin):
        group_name = 'B'

    class FormatterPluginC(FormatterPlugin):
        group_name = 'B'

    # Test fixtures
    manager = PluginManager()
    manager.register(FormatterPluginA, FormatterPluginB, FormatterPluginC)
    # Test
    group_names = set(manager.get_formatters_grouped().keys())
    assert group_names == {'A', 'B'}
    assert manager.get_formatters_grouped() == {
        'A': [FormatterPluginA],
        'B': [FormatterPluginB, FormatterPluginC]
    }

# Generated at 2022-06-23 20:00:31.206487
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager().get_auth_plugins() == []



# Generated at 2022-06-23 20:00:33.182059
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(AuthPlugin)
    manager.register(TransportPlugin)
    manager.register(FormatterPlugin)
    manager.register(ConverterPlugin)
    assert list(manager) == [AuthPlugin, TransportPlugin, FormatterPlugin, ConverterPlugin]


# Generated at 2022-06-23 20:00:34.496608
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert repr(pm)


plugins = PluginManager()

# Generated at 2022-06-23 20:00:37.750207
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p_m = PluginManager()
    p_m.load_installed_plugins()
    assert len(p_m) == 5


# Generated at 2022-06-23 20:00:44.959511
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)
    assert repr(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>, <class \'httpie.plugins.base.FormatterPlugin\'>, <class \'httpie.plugins.base.ConverterPlugin\'>, <class \'httpie.plugins.base.TransportPlugin\'>]>'

# Generated at 2022-06-23 20:00:54.354891
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin, JSONPlugin
    from httpie.plugins.builtin import RawJSONPlugin
    from httpie.plugins.builtin import GNUScreenFormatter, PrettyURLLogFormatter

    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    pluginList = pluginManager
    assert (pluginList[0] == GNUScreenFormatter or pluginList[0] == PrettyURLLogFormatter)
    assert (pluginList[1] == GNUScreenFormatter or pluginList[1] == PrettyURLLogFormatter)
    assert (pluginList[2] == HTTPBasicAuth or pluginList[2] == HTTPDigestAuth)