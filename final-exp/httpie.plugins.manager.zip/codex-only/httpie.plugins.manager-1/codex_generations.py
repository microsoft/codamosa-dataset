

# Generated at 2022-06-23 19:50:49.782265
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    collection = PluginManager()
    collection.register(AuthPlugin, FormatterPlugin)
    assert list(set(collection.get_formatters())) == [FormatterPlugin]


# Generated at 2022-06-23 19:50:54.410390
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    _plugin_manager = PluginManager()
    _plugin_manager.register(AWSAuthPlugin, BasicAuthPlugin)
    assert _plugin_manager.get_auth_plugin('aws') == AWSAuthPlugin
    assert _plugin_manager.get_auth_plugin('basic') == BasicAuthPlugin



# Generated at 2022-06-23 19:50:59.618943
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie.plugins.builtin
    plugin_manager = PluginManager()

    plugin_manager.register(*httpie.plugins.builtin.__all__)
    print(plugin_manager.get_formatters_grouped())


# Generated at 2022-06-23 19:51:07.897366
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # GIVEN
    from httpie.converters import JSONConverter, URLEncodedConverter
    from httpie.plugins.converter import ConverterPlugin
    # WHEN
    plugin_manager = PluginManager()
    plugin_manager.register(JSONConverter, URLEncodedConverter)
    # THEN
    assert plugin_manager.get_converters() == [JSONConverter, URLEncodedConverter]


# Generated at 2022-06-23 19:51:10.119588
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert "unicode" in [x.name for x in plugins.get_converters()]



# Generated at 2022-06-23 19:51:12.198213
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert f'<PluginManager: {list(pluginManager)}>' == pluginManager.__repr__()

# Generated at 2022-06-23 19:51:17.275247
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin = PluginManager()
    plugin.load_installed_plugins()

    assert plugin is not None

    # Should be sorted by date and name
    assert plugin[0].package_name == 'httpie-parallel'
    assert plugin[-1].package_name == 'httpie-unixsocket'

# Generated at 2022-06-23 19:51:22.916585
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Setup
    existing_auth_plugins = ['BearerAuth']

    # Exercise
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins = plugin_manager.get_auth_plugins()

    # Verify
    for auth_type in existing_auth_plugins:
        assert auth_type in [plugin.auth_type for plugin in auth_plugins]


# Generated at 2022-06-23 19:51:26.787756
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    list_of_converters = PluginManager().get_converters()
    assert len(list_of_converters) == 1
    assert "json" in str(list_of_converters[0])
    assert "JSONConverter" in str(list_of_converters[0])

# Generated at 2022-06-23 19:51:31.153495
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plug_mgr = PluginManager()
    plug_mgr.load_installed_plugins()
    formatters = plug_mgr.get_formatters_grouped()
    assert(len(formatters) == 2)
    assert(len(formatters.get('json')) == 2)
    assert(len(formatters.get('html')) == 1)

# Generated at 2022-06-23 19:51:33.568829
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert AuthPlugin in manager
    manager.unregister(AuthPlugin)
    assert AuthPlugin not in manager

# Generated at 2022-06-23 19:51:39.020037
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class FooPlugin(BasePlugin):
        name = 'foo'

    class BarPlugin(BasePlugin):
        name = 'bar'

    class BazPlugin(BasePlugin):
        name = 'baz'

    pm = PluginManager()
    pm.register(FooPlugin)
    pm.register(BarPlugin)
    pm.register(BazPlugin)

    assert len(pm) == 3
    pm.remove(BazPlugin)
    assert len(pm) == 2
    assert BazPlugin not in pm
    assert BarPlugin in pm
    assert FooPlugin in pm
    pm.remove(FooPlugin)
    assert len(pm) == 1
    assert FooPlugin not in pm
    assert BarPlugin in pm


# Generated at 2022-06-23 19:51:40.451836
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins.register == [].append

# Generated at 2022-06-23 19:51:43.680663
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager().register(FormatterPlugin)
    my_pm = PluginManager()
    assert len(my_pm.get_formatters()) == 1


# Generated at 2022-06-23 19:51:47.203773
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatters import JsonIndent

    p = PluginManager()
    assert len(p.get_formatters_grouped()) == 0
    p.register(JsonIndent)
    assert len(p.get_formatters_grouped()) == 1

# Generated at 2022-06-23 19:51:50.938844
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    from httpie.plugins.builtin import CookiePlugin
    plugin_manager.register(CookiePlugin)
    assert plugin_manager[0] == CookiePlugin
    

# Generated at 2022-06-23 19:51:59.132443
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    assert p.filter(by_type=Type[AuthPlugin]) == []
    class AuthPlugin1(AuthPlugin):
        auth_type = 'AUTH'
    class AuthPlugin2(AuthPlugin):
        auth_type = 'AUTH2'
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'Formatter'
        group_order = 1
        group_help = ''
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'Formatter2'
        group_order = 2
        group_help = ''
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'Formatter3'
        group_order = 3
        group_help = ''

# Generated at 2022-06-23 19:52:01.482395
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    print(plugin_manager)
    assert isinstance(plugin_manager, PluginManager)



# Generated at 2022-06-23 19:52:06.755184
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(httpbin)
    plugin_manager.register(httpbin_basic_auth)
    assert plugin_manager.get_auth_plugin('basic') == plugin_manager.get_auth_plugin_mapping()['basic']

# Generated at 2022-06-23 19:52:09.818702
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'
    plugin_manager.load_installed_plugins()
    assert repr(plugin_manager) != '<PluginManager: []>'


# Generated at 2022-06-23 19:52:12.887130
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    import httpie.plugins as p
    assert PluginManager().get_auth_plugin('basic') is p.BasicAuthPlugin
    assert PluginManager().get_auth_plugin('digest') is p.DigestAuthPlugin

# Generated at 2022-06-23 19:52:16.828359
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    def filter(by_type=Type[BasePlugin]):
        return [plugin for plugin in pm if issubclass(plugin, by_type)]

    pm = PluginManager()
    pm.append(BasePlugin)
    assert filter(BasePlugin) == [BasePlugin]


# Generated at 2022-06-23 19:52:18.043946
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager() 
    assert pluginManager == []


# Generated at 2022-06-23 19:52:23.152549
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Arrange
    plugin_manager = PluginManager()
    # Approval
    assert plugin_manager.get_auth_plugin('basic') is None
    # Act
    plugin_manager.register(BasicAuthPlugin)
    # Assert
    assert plugin_manager.get_auth_plugin('basic') is BasicAuthPlugin



# Generated at 2022-06-23 19:52:24.248895
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert plugin_manager == []

# Generated at 2022-06-23 19:52:27.443343
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager.get_transport_plugins())


# Generated at 2022-06-23 19:52:32.336965
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin('basic')
    plugin_manager.get_auth_plugin('digest')
    plugin_manager.get_formatters()
    plugin_manager.get_converters()
    try:
        print(plugin_manager)
    except Exception:
        assert False
    assert True

# Generated at 2022-06-23 19:52:42.895453
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    def mock_load_installed_plugins():
        class Formatter(FormatterPlugin):
            fmt = 'mock'
            group_name = 'mock'
            group_title = 'Mock'
        mock_formatter = Formatter()
        PluginManager.load_installed_plugins(self=self)
        self.append(mock_formatter)

    m_load_installed_plugins = Mock(side_effect=mock_load_installed_plugins)
    PluginManager.load_installed_plugins = m_load_installed_plugins
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters()[0].group_title == 'Mock'

# Generated at 2022-06-23 19:52:47.979674
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    
    assert PluginManager().get_converters() == []
    assert [type(plugin) for plugin in PluginManager().get_converters()] == []
    assert PluginManager().get_converters() == list()



# Generated at 2022-06-23 19:52:57.222090
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    """
    初始化一下环境
    """
    
    pm = PluginManager()
    
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    
    pm.register(HTTPBasicAuth)
    pm.register(HTTPBearerAuth)
    
    assert len(pm.filter(AuthPlugin)) == 2
    assert len(pm.get_transport_plugins()) == 2
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
if __name__ == "__main__":
    test_PluginManager_get_transport_plugins()

# Generated at 2022-06-23 19:53:00.457540
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    count = len(plugins)
    for i in range(10):
        plugins.register(BasePlugin)
        assert plugins.count(BasePlugin) == i + 1
        assert len(plugins) == count + i + 1



# Generated at 2022-06-23 19:53:04.364279
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(ToPlugin, FromPlugin)
    result = plugin_manager.get_transport_plugins()
    assert result == [2, 1]

# Unit tests for method register of class PluginManager

# Generated at 2022-06-23 19:53:14.115983
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()

    class Formatter1(FormatterPlugin):
        """A formatter plugin."""
        group_name = 'first'

    class Formatter2(FormatterPlugin):
        """A formatter plugin."""
        group_name = 'first'

    class Formatter3(FormatterPlugin):
        """A formatter plugin."""
        group_name = 'second'

    manager.register(
        Formatter1,
        Formatter2,
        Formatter3
    )

    formatters_grouped = manager.get_formatters_grouped()
    assert (len(formatters_grouped['first']) == 2)
    assert (len(formatters_grouped['second']) == 1)

# Generated at 2022-06-23 19:53:20.046355
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(test.test_plugin.TestAuthPlugin_0, test.test_plugin.TestAuthPlugin_1)
    assert plugins.get_auth_plugin_mapping()['test_auth_0'] == test.test_plugin.TestAuthPlugin_0
    assert plugins.get_auth_plugin_mapping()['test_auth_1'] == test.test_plugin.TestAuthPlugin_1


# Generated at 2022-06-23 19:53:22.148952
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin("test") == AuthPlugin


# Generated at 2022-06-23 19:53:25.966640
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthBasicPlugin,AuthDigestPlugin)
    plugin = plugin_manager.get_auth_plugins()
    assert len(plugin) == 2


# Generated at 2022-06-23 19:53:36.490727
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    # Unit test for method unregister of class PluginManager with type is Type[BasePlugin]
    def test_unregister_with_type_is_Type_BasePlugin():
        from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
        # Arrange: Create a plugin manager
        plugin_manager = PluginManager()
        plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin)
        # Act: Unregister
        plugin_manager.unregister(AuthPlugin)
        # Assert
        assert plugin_manager.filter(AuthPlugin) == []
        assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
        assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    # Unit test for method unregister of class PluginManager with type is Type[AuthPlugin]

# Generated at 2022-06-23 19:53:46.993076
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager1 = PluginManager()
    class test_PluginManager_register:
        def __init__(self, test_case_1, test_case_2):
            self.test_PluginManager_register_1 = test_case_1
            self.test_PluginManager_register_2 = test_case_2
    test_PluginManager_register_1 = test_PluginManager_register(1, 2)
    test_PluginManager_register_2 = test_PluginManager_register(3, 4)
    PluginManager1.register(test_PluginManager_register_1, test_PluginManager_register_2)
    assert PluginManager1[0] == test_PluginManager_register_1
    assert PluginManager1[1] == test_PluginManager_register_2



# Generated at 2022-06-23 19:53:51.909458
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert list(pm.get_auth_plugin_mapping().keys()) == ['basic', 'digest', 'aws4', 'oauth1']
    assert pm.get_auth_plugin_mapping()['aws4'] == pm.get_auth_plugin('aws4')


# Generated at 2022-06-23 19:53:57.925398
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin(BasePlugin):
        pass

    class PluginAuth(AuthPlugin):
        pass

    class PluginTransport(TransportPlugin):
        pass

    plugin = Plugin()
    auth = PluginAuth()
    transport = PluginTransport()

    plugin_list = [plugin, auth, transport]

    plugin_manager = PluginManager()
    plugin_manager.register(*plugin_list)

    assert plugin_manager.filter(AuthPlugin) == [auth]
    assert plugin_manager.filter(BasePlugin) == [plugin, auth, transport]
    assert plugin_manager.filter(TransportPlugin) == [transport]


# Generated at 2022-06-23 19:54:05.399310
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins_types = [Type[AuthPlugin], Type[FormatterPlugin], Type[ConverterPlugin], Type[TransportPlugin]]
    plugins = [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    manager = PluginManager()
    manager.register(*plugins)

    assert manager.get_auth_plugins() == [AuthPlugin]
    assert manager.get_auth_plugins() == plugins[:1]

if __name__ == '__main__':
    test_PluginManager_get_auth_plugins()

# Generated at 2022-06-23 19:54:08.571842
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin = plugin_manager.get_auth_plugin("basic")
    assert plugin == AuthPlugin


# Generated at 2022-06-23 19:54:20.384203
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import os
    import tempfile

    class MockEntryPoint:
        def __init__(self, dist_key, plugin):
            self.dist = MockDistribution(dist_key)
            self.load = lambda: plugin

    class MockDistribution:
        def __init__(self, key):
            self.key = key

    # Create a temporary plugin file
    plugin_path = os.path.join(tempfile.gettempdir(), 'test_plugin.py')
    plugin_content = '''
    from httpie.plugins import AuthPlugin

    class MockAuthPlugin(AuthPlugin):
        pass
    '''
    with open(plugin_path, 'w') as plugin_file:
        plugin_file.write(plugin_content)

    # Make sure the plugin is loaded

# Generated at 2022-06-23 19:54:29.767065
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(ClassA, ClassB, ClassC)

    # issubclass(ClassA, BasePlugin) = True
    # issubclass(ClassB, BasePlugin) = True
    # issubclass(ClassC, BasePlugin) = True
    # issubclass(ClassD, BasePlugin) = True 
    plugin_manager.filter(Type[BasePlugin])

    # issubclass(ClassA, BasePlugin) = True
    # issubclass(ClassB, BasePlugin) = False
    # issubclass(ClassC, BasePlugin) = False
    # issubclass(ClassD, BasePlugin) = True 
    plugin_manager.filter(ClassD)

    # issubclass(ClassA, BasePlugin) = True
    # issubclass(ClassB, BasePlugin)

# Generated at 2022-06-23 19:54:32.976485
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # Given
    pluginManager = PluginManager()
    # When
    pluginManager.register(Type[pluginManager], Type[pluginManager])
    # Then
    assert len(pluginManager) == 2


# Generated at 2022-06-23 19:54:39.374932
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    """
    Unit test for method get_auth_plugin_mapping of class PluginManager

    :return:
    """
    from httpie.plugins.auth import AuthPlugin
    from httpie.plugins.formatter import FormatterPlugin
    from httpie.plugins.converter import ConverterPlugin
    from httpie.plugins.transport import TransportPlugin

    pm = PluginManager()
    pm.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    print(pm.get_auth_plugins())
    print(pm.get_auth_plugin_mapping())
    print(pm.get_auth_plugin('jwt'))
    print(pm.get_formatters())
    print(pm.get_formatters_grouped())
    print(pm.get_converters())

# Generated at 2022-06-23 19:54:41.326659
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    print(PluginManager())


# Generated at 2022-06-23 19:54:43.735901
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'

plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:54:51.095677
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    class AuthPlugin_gssapi(AuthPlugin):
        auth_type = 'gssapi'
    class AuthPlugin_aws(AuthPlugin):
        auth_type = 'aws'
    pm.register(AuthPlugin_gssapi, AuthPlugin_aws)

    plugin_mapping = pm.get_auth_plugin_mapping()
    # print(f'plugin_mapping = {plugin_mapping}')
    assert plugin_mapping == {'gssapi': AuthPlugin_gssapi, 'aws': AuthPlugin_aws}


# Generated at 2022-06-23 19:54:54.325739
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(BasicAuthPlugin)
    assert manager.get_auth_plugin('basic') is BasicAuthPlugin
    with pytest.raises(KeyError):
        manager.get_auth_plugin('bearer')

# Generated at 2022-06-23 19:54:56.266358
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    assert PluginManager().unregister()


# Generated at 2022-06-23 19:55:00.992408
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plg = PluginManager()
    plg.register(AuthPlugin)
    plg.register(FormatterPlugin)
    plg.register(TransportPlugin)
    plg.register(ConverterPlugin)
    assert (plg.get_converters() == [ConverterPlugin])


# Generated at 2022-06-23 19:55:05.176637
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    import sys

    lib_path = 'C:\\Users\\Admin\\AppData\\Local\\Programs\\Python\\Python36-32\\Lib\\site-packages'
    sys.path.insert(0, lib_path)
    plugin_manager = PluginManager()

    assert plugin_manager.__repr__() == '<PluginManager: []>'


# Generated at 2022-06-23 19:55:12.916667
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():

    plugin1 = MagicMock()
    plugin2 = MagicMock()

    plugins = PluginManager()
    plugins.register(plugin1, plugin2)
    plugins.unregister(plugin1)

    assert not any(g.startswith('PluginManager_unregister') for g in gc.get_referents(plugin1))
    assert any(g.startswith('PluginManager_unregister') for g in gc.get_referents(plugin2))


# Generated at 2022-06-23 19:55:18.989676
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Test:
    #   The method load_installed_plugins of class PluginManager can find plugin from installed entry points.
    # Precondition:
    #   Use HTTPie to install httpie-http2 plugin in entry_point=httpie.plugins.transport.v1
    # Expected:
    #   The method load_installed_plugins can find plugin httpie-http2 in entry points.
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len([plugin for plugin in plugin_manager if plugin.plugin_name == 'httpie-http2']) != 0

# Generated at 2022-06-23 19:55:23.972901
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_plugin_mapping = dict()
    auth_plugin_mapping['aws4'] = 'httpie_aws4.AuthPlugin'

    pm = PluginManager()
    pm.register(get_auth_plugin_mapping())

    assert auth_plugin_mapping == pm.get_auth_plugin_mapping()

# Generated at 2022-06-23 19:55:28.614237
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from unittest.mock import MagicMock
    plugin_manager = PluginManager()
    mock = MagicMock()
    mock.__repr__.return_value = "plugin1"
    plugin_manager.append(mock)
    assert plugin_manager.__repr__() == "<PluginManager: [plugin1]>"

# Generated at 2022-06-23 19:55:30.829254
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    formatters = plugin_manager.get_formatters()
    # print(formatters)
    assert type(formatters) is list


# Generated at 2022-06-23 19:55:34.081982
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.register(MockTransportPlugin1)
    plugins.register(MockTransportPlugin2)
    assert plugins.get_transport_plugins() == [MockTransportPlugin1, MockTransportPlugin2]


# Generated at 2022-06-23 19:55:38.250885
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    """
    Test unregister() method of PluginManager class.
    """
    class TestPlugin(BasePlugin):
        pass
    p = PluginManager()
    assert(p.__str__() == "[]")
    p.register(TestPlugin)
    assert(p.__str__() == "[<class 'httpie.plugins.manager.TestPlugin'>]")
    p.unregister(TestPlugin)
    assert(p.__str__() == "[]")

# Generated at 2022-06-23 19:55:44.556069
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        def foo(self):
            pass
    class PluginB(BasePlugin):
        def foo(self):
            pass
    manager = PluginManager()
    manager.register(PluginA,PluginB)
    assert list(manager.filter()) == [PluginA,PluginB]
    assert list(manager.filter(by_type=BasePlugin)) == [PluginA,PluginB]
    assert list(manager.filter(by_type=PluginA)) == [PluginA]

# Generated at 2022-06-23 19:55:51.069649
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # Create object for testing
    PluginManager1 = PluginManager()
    plugin_mapping = {
        'Basic': BasicAuthPlugin,
        'Digest': DigestAuthPlugin,
        'Hawk': HawkAuthPlugin,
        'Netrc': NetrcAuthPlugin,
        'OAuth1': OAuth1AuthPlugin,
        'OAuth2': OAuth2AuthPlugin,
        'Awssigv4': Awssigv4AuthPlugin
    }
    for auth_type, plugin in plugin_mapping.items():
        PluginManager1.register(plugin)
    return PluginManager1


# Generated at 2022-06-23 19:55:55.407162
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(TransportPlugin)

    assert len(plugin_manager.get_transport_plugins()) == 4

# Generated at 2022-06-23 19:56:04.018687
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    plugin1 = auth_plugin.OAuth1
    plugin2 = httpie.plugins.http.HTTPiePlugin
    plugin3 = httpie.plugins.http.HTTPSPlugin
    plugin4 = httpie.plugins.http.HTTPSProxyPlugin
    plugin5 = httpie.plugins.httpie.HTTPiePlugin
    pm.register(plugin1, plugin2, plugin3, plugin4, plugin5)
    print(pm.get_transport_plugins())
    assert plugin2 in pm.get_transport_plugins()
    assert plugin3 in pm.get_transport_plugins()
    assert plugin4 in pm.get_transport_plugins()
    assert plugin5 not in pm.get_transport_plugins()

# Generated at 2022-06-23 19:56:07.567535
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager.get_auth_plugins() == []
    assert PluginManager.get_auth_plugin_mapping() == {}
    assert PluginManager.get_auth_plugin('') == {}
    assert PluginManager.get_formatters() == []
    assert PluginManager.get_formatters_grouped() == {}
    assert PluginManager.get_converters() == []
    assert PluginManager.get_transport_plugins() == []

# Generated at 2022-06-23 19:56:11.756323
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.auth import BasicAuthPlugin
    from httpie.plugins.auth import DigestAuthPlugin
    p=PluginManager()
    p.register(BasicAuthPlugin,DigestAuthPlugin)
    assert BasicAuthPlugin in (p.get_auth_plugins())
    assert DigestAuthPlugin in (p.get_auth_plugins())



# Generated at 2022-06-23 19:56:13.642977
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert isinstance(plugins.get_formatters(), list)


# Generated at 2022-06-23 19:56:15.329329
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_mgr = PluginManager()
    assert plugin_mgr.get_auth_plugins() == []


# Generated at 2022-06-23 19:56:18.120434
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pl = PluginManager()
    pl.register(ConverterPlugin, AuthPlugin)
    assert len(pl.filter(by_type=ConverterPlugin)) == 1 and len(pl.filter(by_type=AuthPlugin)) == 1

# Generated at 2022-06-23 19:56:22.005230
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    for ep_name in ENTRY_POINT_NAMES:
        assert len(list(iter_entry_points(ep_name)))>0


# Generated at 2022-06-23 19:56:24.159559
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p = PluginManager()
    assert p.get_transport_plugins() == []
    from pyramid.response import Response
    from pyramid.request import Request
    class FakePlugin:
        pass
    FakePlugin.request_class = Request
    FakePlugin.response_class = Response
    p.register(FakePlugin)
    assert p.get_transport_plugins() == [FakePlugin]

# Generated at 2022-06-23 19:56:29.300172
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    mgr = PluginManager()
    class A(BasePlugin): pass
    class B(A): pass
    class C(B): pass
    mgr.register(A, B, C)
    mgr.register(B)
    assert mgr.filter(A) == [A, B, C, B]
    assert mgr.filter(B) == [B, C, B]
    assert mgr.filter(C) == [C]


# Singleton
plugins = PluginManager()

# Generated at 2022-06-23 19:56:32.217062
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugin_name = 'test'
    plugins.register(plugin_name)
    assert plugin_name in plugins


# Generated at 2022-06-23 19:56:35.827543
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()  
    assert len(plugin_manager.get_transport_plugins()) == 2

# Generated at 2022-06-23 19:56:42.404707
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.register(AuthPlugin, TransportPlugin)
    plugins.append(AuthPlugin)
    plugins.remove(AuthPlugin)
    assert repr(plugins) == '<PluginManager: [<class \'httpie.plugins.base.TransportPlugin\'>]>'


# Generated at 2022-06-23 19:56:43.864680
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    converters = pluginManager.get_converters()
    assert len(converters) > 0
    assert len(converters[0].extensions) > 0

# Generated at 2022-06-23 19:56:45.369827
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(PluginManager)
    assert plugin_manager.__repr__() == "<PluginManager: [<class 'httpie.plugins._manager.PluginManager'>]>"

# Generated at 2022-06-23 19:56:50.267466
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PM = PluginManager()
    test_formatters = [
        Type[FormatterPlugin](x) for x in range(30)
    ]
    PM.register(*test_formatters)
    assert PM.get_formatters() == test_formatters


# Generated at 2022-06-23 19:56:53.418941
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.register(BasicAuthPlugin)
    assert plugins.get_auth_plugin('basic') == BasicAuthPlugin


# Generated at 2022-06-23 19:56:56.030793
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manage = PluginManager()
    plugin_manage.register(BasePlugin)
    assert len(plugin_manage.filter(BasePlugin)) == 1


# Generated at 2022-06-23 19:57:02.520505
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    # 先注册两个插件于 PluginManager
    pluginManager.register(AuthPlugin)
    pluginManager.register(FormatterPlugin)
    # 然后在获取两个插件
    auth_plugins = pluginManager.get_auth_plugins()
    formatter_plugins = pluginManager.get_formatters()
    # 最后比较两个插件
    assert(auth_plugins == [AuthPlugin])
    assert(formatter_plugins == [FormatterPlugin])

# Generated at 2022-06-23 19:57:06.422363
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManagerInstance = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            PluginManagerInstance.register(entry_point.load())
    formatters = PluginManagerInstance.get_formatters()
    print(formatters)
    assert isinstance(formatters, list)


# Generated at 2022-06-23 19:57:09.580404
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    import pytest
    from httpie.plugins.transport.sync import SyncTransportPlugin

    plugins = PluginManager()

    assert True == plugins.get_transport_plugins() is not None
    # assert False == plugins.get_transport_plugins() is None

# Generated at 2022-06-23 19:57:16.414790
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Plugin1(FormatterPlugin):
        group_name = 'group_name1'

    class Plugin2(FormatterPlugin):
        group_name = 'group_name2'

    class Plugin3(FormatterPlugin):
        group_name = 'group_name2'

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1)
    plugin_manager.register(Plugin2)
    plugin_manager.register(Plugin3)

    assert plugin_manager.get_formatters_grouped() == \
        {'group_name1': [Plugin1], 'group_name2': [Plugin2, Plugin3]}

# Generated at 2022-06-23 19:57:19.448865
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class FPlugin(FormatterPlugin):
        pass
    pm = PluginManager()
    pm.register(FPlugin)
    assert pm.get_formatters() == [FPlugin]


# Generated at 2022-06-23 19:57:23.654927
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    # assert len(plugin_manager.get_converters()) == 0
    assert len(plugin_manager.get_converters()) == 4
    # assert len(plugin_manager.get_converters()[0]) == 0


# Generated at 2022-06-23 19:57:25.948981
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print(plugins.get_converters())

if __name__ == '__main__':
    test_PluginManager_get_converters()

# Generated at 2022-06-23 19:57:26.906296
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # TODO: Create unit test
    pass



# Generated at 2022-06-23 19:57:32.654949
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    expected_auth_plugin_mapping = {'basic': httpie.plugins.auth.BasicAuthPlugin,\
                                    'digest': httpie.plugins.auth.DigestAuthPlugin,\
                                    'hawk': httpie.plugins.auth.HawkAuthPlugin}
    # unit test for method get_auth_plugin_mapping of class PluginManager
    assert PluginManager().get_auth_plugin_mapping() == expected_auth_plugin_mapping
    # unit test for method get_auth_plugin of class PluginManager
    assert PluginManager().get_auth_plugin('basic') == httpie.plugins.auth.BasicAuthPlugin()
    assert PluginManager().get_auth_plugin('digest') == httpie.plugins.auth.DigestAuthPlugin()

# Generated at 2022-06-23 19:57:36.408814
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    assert len(manager) == 0
    class temp_plugin: pass
    manager.register(temp_plugin)
    assert len(manager) == 1
    assert manager[0] == temp_plugin


# Generated at 2022-06-23 19:57:44.850325
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import test1
    from httpie.plugins import test2
    from httpie.plugins import test3
    from httpie.plugins import test4
    from httpie.plugins.base import BasePlugin

    plugin_manager = PluginManager()
    plugin_manager.register(test1.TestFormatterPlugin, test2.TestAuthPlugin, test3.TestConverterPlugin, test4.TestTransportPlugin)
    res1 = plugin_manager.filter(BasePlugin)
    res2 = plugin_manager.filter(FormatterPlugin)
    res3 = plugin_manager.filter(AuthPlugin)
    res4 = plugin_manager.filter(ConverterPlugin)
    res5 = plugin_manager.filter(TransportPlugin)
    assert (len(res1) == 3)
    assert (len(res2) == 1)


# Generated at 2022-06-23 19:57:46.091238
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    
    assert self.get_transport_plugins() == []

# Generated at 2022-06-23 19:57:52.658512
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_manager = PluginManager()
    plugins_manager.register(
        FormatterPlugin("jd", "format_jd", "group_test"),
        FormatterPlugin("jd", "format_jd", "group_test"),
        FormatterPlugin("jd", "format_jd", "group_test2"),
        FormatterPlugin("jd", "format_jd", "group_test2"),
        FormatterPlugin("jd", "format_jd", "group_test3"),
        FormatterPlugin("jd", "format_jd", "group_test3")
    )

# Generated at 2022-06-23 19:57:58.165522
# Unit test for constructor of class PluginManager
def test_PluginManager():
    def _plugin():
        class DummyPlugin(BasePlugin):
            pass
        return DummyPlugin

    _plugin1 = _plugin()
    _plugin2 = _plugin()
    _plugin3 = _plugin()
    assert PluginManager([_plugin1, _plugin2, _plugin3]) == [_plugin1, _plugin2, _plugin3]



# Generated at 2022-06-23 19:57:59.900534
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    expect = '<PluginManager: []>'
    assert pm.__repr__() == expect

# Generated at 2022-06-23 19:58:05.106783
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()

    class PluginA(AuthPlugin):
        auth_type = 'a'

    class PluginB(AuthPlugin):
        auth_type = 'b'

    class PluginC(FormatterPlugin):
        name = 'c'

    manager.register(PluginA, PluginB, PluginC)

    assert manager.get_auth_plugin('a') == PluginA
    assert manager.get_auth_plugin('b') == PluginB
    assert manager.get_auth_plugin('c') == KeyError

# Generated at 2022-06-23 19:58:06.782030
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.formatter.colors import Formatter
    from httpie.plugins.formatter.format import Formatter as Formatter_format
    assert PluginManager().get_formatters() == [Formatter, Formatter_format]

# Generated at 2022-06-23 19:58:10.399815
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    new_pluginManager = PluginManager()
    new_pluginManager.load_installed_plugins()
    list_formatters = new_pluginManager.get_formatters()
    assert list_formatters is not None


# Generated at 2022-06-23 19:58:12.982471
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(MyAuthPlugin)
    assert plugin_manager.get_auth_plugin('my') == MyAuthPlugin


# Generated at 2022-06-23 19:58:19.399891
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Derived(BasePlugin):
        pass

    class Unrelated:
        pass

    class Base(BasePlugin):
        pass

    class Another(BasePlugin):
        pass

    class DerivedFromDerived(Derived):
        pass

    manager = PluginManager()
    manager.register(Base, Derived, Another, Unrelated, DerivedFromDerived)

    result = manager.filter(Base)
    assert sorted(x.__name__ for x in result) == ['Base', 'Derived', 'DerivedFromDerived', 'Another']

    result = manager.filter(Derived)
    assert sorted(x.__name__ for x in result) == ['Derived', 'DerivedFromDerived']

# Generated at 2022-06-23 19:58:27.021409
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginsManager = PluginManager()
    pluginsManager.load_installed_plugins()
    formattersList = pluginsManager.get_formatters()
    assert formattersList[0].__name__ == 'PrettyHttpieFormatter'
    assert formattersList[1].__name__ == 'PrettyUrllib3Formatter'
    assert formattersList[2].__name__ == 'PrettyRequestsFormatter'
    assert formattersList[3].__name__ == 'PrettyCurlFormatter'
    assert formattersList[4].__name__ == 'PrettyWgetFormatter'


# Generated at 2022-06-23 19:58:28.743089
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print(plugins)

# Generated at 2022-06-23 19:58:31.210299
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
  cap = PluginManager()
  plugins = cap.get_transport_plugins()
  assert 'httpie.plugins.transport.http.HTTPDefaultTransport' in str(plugins)


# Generated at 2022-06-23 19:58:35.975750
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin)

    assert Plugin in plugin_manager
    plugin_manager.unregister(Plugin)
    assert Plugin not in plugin_manager

# Generated at 2022-06-23 19:58:37.921487
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    for plugin in plugin_manager.get_auth_plugins():
        print(plugin)



# Generated at 2022-06-23 19:58:40.443778
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(BasicAuthPlugin)
    plugins.register(Plugin)
    assert plugins.get_auth_plugins() == [BasicAuthPlugin]


# Generated at 2022-06-23 19:58:42.735047
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    a = PluginManager()
    b = AuthPlugin()
    a.register(b)
    assert b in a
    a.unregister(b)
    assert b not in a

# Generated at 2022-06-23 19:58:49.940554
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin

    pm = PluginManager()

    assert pm.filter() == []
    assert pm.filter(AuthPlugin) == []
    assert pm.filter(ConverterPlugin) == []
    assert pm.filter(FormatterPlugin) == []
    assert pm.filter(TransportPlugin) == []

    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth-plugin'

    class MyConverterPlugin(ConverterPlugin):
        content_type = 'my-converter-plugin'

    class MyFormatterPlugin(FormatterPlugin):
        name = 'my-formatter-plugin'


# Generated at 2022-06-23 19:58:52.312947
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Arrange
    pm = PluginManager()
    # Act
    result = pm.get_auth_plugin("Basic")
    # Assert
    assert result == None

# Generated at 2022-06-23 19:59:01.345977
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()

    # class_to_test is the name of the method to test in class PluginManager
    class_to_test = plugins.get_converters

    # This test checks the return type of the method
    expected = list
    actual = type(class_to_test())
    # printing the results will place them at the end of all tests
    # print(expected == actual)
    print("Test get_converters 1: " + str(expected == actual))

    # Test 2: testing the length of the converters list in the manager
    expected = 1
    actual = len(class_to_test())
    print("Test get_converters 2: " + str(expected == actual))

# Generated at 2022-06-23 19:59:02.764431
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    auth_plugin = PluginManager()
    auth_plugin.register(ClassAuth)
    assert auth_plugin[0] == ClassAuth


# Generated at 2022-06-23 19:59:12.566555
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    import sys
    import pytest

    sys.path.append('../plugins/out')
    from out_auth_plugin import OutAuthPlugin
    from out_formatter_plugin import OutFormatterPlugin
    from out_converter_plugin import OutConverterPlugin
    from out_transport_plugin import OutTransportPlugin

    pm = PluginManager()

    pm.register(OutAuthPlugin, OutFormatterPlugin,
                OutConverterPlugin, OutTransportPlugin)

    assert pm.get_auth_plugin('out') == OutAuthPlugin
    assert pm.get_formatters_grouped().get('out') == [OutFormatterPlugin]
    assert pm.get_converters() == [OutConverterPlugin]
    assert pm.get_transport_plugins() == [OutTransportPlugin]


# Generated at 2022-06-23 19:59:15.553196
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'


# Global plugin manager instance.
plugins = PluginManager()

# Generated at 2022-06-23 19:59:16.568095
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager.register('plugin')


# Generated at 2022-06-23 19:59:18.844795
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager_object = PluginManager()
    PluginManager_object.load_installed_plugins()
    assert type(PluginManager_object)== PluginManager

# Generated at 2022-06-23 19:59:24.927262
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()
    result = pm.get_auth_plugin_mapping()
    print(result)
    assert result['basic'] == httpie.plugins.auth.basic.BasicAuthPlugin
    assert result['digest'] == httpie.plugins.auth.digest.DigestAuthPlugin
    assert result['ntlm'] == httpie.plugins.auth.NTLMAuthPlugin

# Generated at 2022-06-23 19:59:27.941218
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin, DigestAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': BasicAuthPlugin, 'digest': DigestAuthPlugin}

# Generated at 2022-06-23 19:59:37.266055
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.aws import AWSAuthPlugin
    from httpie.plugins.auth.aws_sigv4 import AWSSigv4AuthPlugin
    from httpie.plugins.auth.aws_v2 import AWSv2AuthPlugin
    from httpie.plugins.auth.aws_v4 import AWSv4AuthPlugin
    pm = PluginManager()
    pm.register(BasicAuthPlugin, DigestAuthPlugin, AWSAuthPlugin, AWSSigv4AuthPlugin(), AWSv2AuthPlugin(), AWSv4AuthPlugin())
    assert len(pm) == 6
    assert isinstance(pm.get_auth_plugin('basic'), BasicAuthPlugin)

# Generated at 2022-06-23 19:59:42.147741
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter.v1 import Json
    pm = PluginManager()
    pm.register(Json)
    assert pm.get_converters() == [Json]

# Generated at 2022-06-23 19:59:50.726831
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    plugin_list = []
    for plugin in manager:
        if plugin.package_name and plugin.package_name != "httpie":
            plugin_list.append(plugin.package_name)
    package_list = []
    try:
        module = importlib.import_module("httpie.plugins")
    except:
        pass
    else:
        for name in dir(module):
            if "httpie" not in str(name):
                package_list.append(name)
    assert set(plugin_list) == set(package_list)


# Generated at 2022-06-23 19:59:54.360093
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPiePlugin)
    assert len(plugin_manager) == 1
    assert plugin_manager[0] == HTTPiePlugin



# Generated at 2022-06-23 19:59:55.965830
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.get_transport_plugins() == []

# Generated at 2022-06-23 20:00:02.954985
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginmanager = PluginManager()
    pluginmanager.register(TestAuthA)
    pluginmanager.register(TestAuthB)
    pluginmanager.register(TestAuthC)
    pluginmanager.register(TestAuthD)

    auth_plugin_mapping = pluginmanager.get_auth_plugin_mapping()
    assert auth_plugin_mapping["A"] == TestAuthA
    assert auth_plugin_mapping["B"] == TestAuthB
    assert auth_plugin_mapping["C"] == TestAuthC
    assert auth_plugin_mapping["D"] == TestAuthD

# Generated at 2022-06-23 20:00:05.677098
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginManager = PluginManager()
    pluginManager.register(DummyAuthPlugin)
    assert pluginManager.get_auth_plugins() == [DummyAuthPlugin]


# Generated at 2022-06-23 20:00:07.242086
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert isinstance(pm, list)
    assert pm == []


# Generated at 2022-06-23 20:00:13.347619
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBasicAuthCredentialsInUrl
    PluginManager.register(HTTPBasicAuth,HTTPBasicAuthCredentialsInUrl)

    plugin_mapping = PluginManager.get_auth_plugin_mapping()
    print(plugin_mapping)
    assert plugin_mapping['basic'] == HTTPBasicAuth
    assert plugin_mapping['basicCredentialsInUrl'] == HTTPBasicAuthCredentialsInUrl

test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-23 20:00:14.760134
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
        transport_plugins = PluginManager().get_transport_plugins()
        assert len(transport_plugins) == 5

# Generated at 2022-06-23 20:00:20.895205
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class B: pass

    class A(B): pass

    class C(): pass

    class D(B): pass

    pm = PluginManager()
    pm.register(A, B, C, D)
    assert pm.unregister(B) == None
    assert (A in pm) == True
    assert (C in pm) == True
    assert (D in pm) == True



# Generated at 2022-06-23 20:00:26.052741
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 10
    assert len(plugin_manager.get_auth_plugins()) == 2
    assert len(plugin_manager.get_converters()) == 2
    assert len(plugin_manager.get_formatters_grouped()) == 2
    assert len(plugin_manager.get_transport_plugins()) == 4

# Generated at 2022-06-23 20:00:28.151428
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    p=PluginManager()
    p.register(1,2)
    p.unregister(1)
    assert p == [2]


# Generated at 2022-06-23 20:00:29.323396
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins == []



# Generated at 2022-06-23 20:00:31.606336
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    mgr = PluginManager()
    mgr.register(AuthPlugin)
    mgr.register(TransportPlugin)
    t = mgr.get_transport_plugins()
    assert t is not None


# Generated at 2022-06-23 20:00:32.410443
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager()


# Generated at 2022-06-23 20:00:38.542111
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.grouped import group_name
    from httpie.plugins.builtin import BuiltinPlugin
    from httpie.plugins.socks import SOCKSHTTPAuthPlugin, SOCKSHTTPPlugin
    from httpie.plugins.unicode import UnicodePlugin
    from httpie.plugins.json import JSONPlugin
    from httpie.plugins.html import HTMLPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(BuiltinPlugin, SOCKSHTTPAuthPlugin, SOCKSHTTPPlugin, UnicodePlugin, JSONPlugin, HTMLPlugin)

# Generated at 2022-06-23 20:00:45.160167
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class pluginA(BasePlugin):
        pass

    class pluginB(BasePlugin):
        pass

    class pluginC(pluginA):
        pass

    PluginManager().register(pluginA, pluginB, pluginC)

    plugins = PluginManager().filter()
    assert plugins == [pluginA, pluginB, pluginC]

    plugins = PluginManager().filter(pluginA)
    assert plugins == [pluginA, pluginC]

    plugins = PluginManager().filter(pluginB)
    assert plugins == [pluginB]

# Generated at 2022-06-23 20:00:46.162616
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    PluginManager().get_converters()
    # TODO: Add more tests

# Generated at 2022-06-23 20:00:50.850548
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert len(ENTRY_POINT_NAMES) == 4
    assert len(p.get_auth_plugins()) == 4
    assert len(p.get_converters()) == 4
    assert len(p.get_formatters()) == 2
    assert len(p.get_transport_plugins()) == 1