

# Generated at 2022-06-23 19:50:47.090499
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert 1==1

# Generated at 2022-06-23 19:50:53.354918
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-23 19:50:54.600586
# Unit test for method register of class PluginManager
def test_PluginManager_register():

    PluginManager().register()



# Generated at 2022-06-23 19:51:00.978178
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FirstFormatter, SecondFormatter, ThirdFormatter)
    formatters_grouped = plugin_manager.get_formatters_grouped()

    assert formatters_grouped['text'] == [FirstFormatter, ThirdFormatter]
    assert formatters_grouped['other'] == [SecondFormatter]


# Generated at 2022-06-23 19:51:04.068840
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    for plugin in PluginManager().get_converters():
        assert isinstance(plugin, ConverterPlugin)


# Generated at 2022-06-23 19:51:05.325504
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager.get_formatters_grouped(PluginManager())

# Generated at 2022-06-23 19:51:08.824223
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    transport_plugins = plugin_manager.get_transport_plugins()
    for i in transport_plugins:
        assert issubclass(i, TransportPlugin) == True
    assert len(transport_plugins) == 0
    return

# Generated at 2022-06-23 19:51:11.553326
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import plugin_manager

    assert len(plugin_manager.get_converters()) == 0
    plugin_manager.register(ConverterPlugin)
    assert len(plugin_manager.get_converters()) == 1

# Generated at 2022-06-23 19:51:12.983466
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'


# Generated at 2022-06-23 19:51:20.778332
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
      list_formatters = [
          type('json', (FormatterPlugin,), {'group_name': 'JSON'}),
          type('json2', (FormatterPlugin,), {'group_name': 'JSON'}),
          type('json3', (FormatterPlugin,), {'group_name': 'JSON'}),
          type('html', (FormatterPlugin,), {'group_name': 'HTML'})
      ]
      plugin_manager = PluginManager()
      plugin_manager.register(*list_formatters)
      print(plugin_manager.get_formatters_grouped())

# Generated at 2022-06-23 19:51:25.373960
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPHeaders
    pm = PluginManager()
    pm.register(HTTPBasicAuth, HTTPHeaders)
    assert len(pm) == 2
    assert isinstance(pm[0], type)
    pm.unregister(HTTPBasicAuth)
    assert len(pm) == 1
    assert isinstance(pm[0], type)

# Generated at 2022-06-23 19:51:27.030355
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert 'token' in pm.get_auth_plugin_mapping().keys()

# Generated at 2022-06-23 19:51:32.775610
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    class Plugin1(AuthPlugin):
        auth_type = 'plugin1'
    class Plugin2(AuthPlugin):
        auth_type = 'plugin2'
    p = PluginManager()
    p.register(Plugin1, Plugin2)
    assert p.get_auth_plugin_mapping() == {'plugin1': Plugin1, 'plugin2': Plugin2}

# 2. Load installed plugins
manager = PluginManager()
manager.load_installed_plugins()


# Generated at 2022-06-23 19:51:33.928639
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    PluginManager().get_auth_plugin_mapping()


# Generated at 2022-06-23 19:51:35.047592
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'

# Generated at 2022-06-23 19:51:36.869003
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(ConverterPlugin)
    assert plugin_manager.get_converters() == [ConverterPlugin]



# Generated at 2022-06-23 19:51:39.240897
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    print(manager)

# test_PluginManager_load_installed_plugins()

# Generated at 2022-06-23 19:51:46.755180
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    plugin_manager.register()
    plugin_manager.unregister()
    plugin_manager.filter()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugins()
    plugin_manager.get_auth_plugin_mapping()
    plugin_manager.get_auth_plugin()
    plugin_manager.get_formatters()
    plugin_manager.get_formatters_grouped()
    plugin_manager.get_converters()
    plugin_manager.get_transport_plugins()

# Generated at 2022-06-23 19:51:50.532322
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin = PluginManager()
    plugin.register(JsonConverter)
    plugin.register(JsonPrettyConverter)
    assert len(plugin.get_converters()) == 2

# Generated at 2022-06-23 19:51:53.734403
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p1 = PluginManager()
    p1.register('test1', 'test2')
    assert p1.__repr__() == '<PluginManager: [\'test1\', \'test2\']>'


# Generated at 2022-06-23 19:51:58.623965
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    manager.load_installed_plugins()
    formatters = manager.get_formatters()
    assert len(formatters) > 0
    assert 'MetaFormatter' in [type.__name__ for type in formatters]


# Generated at 2022-06-23 19:52:01.995768
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(Plugin1, Plugin2, Plugin3)
    assert plugins.get_auth_plugins() == [Plugin1, Plugin3]
    
    
    
    

# Generated at 2022-06-23 19:52:04.345237
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert list(pm) == []



# Generated at 2022-06-23 19:52:13.503512
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # test data
    class Plugin(BasePlugin):
        pass

    class FormatterPlugin(BasePlugin):
        pass

    class ConverterPlugin(BasePlugin):
        pass

    class TransportPlugin(BasePlugin):
        pass

    class AuthPlugin(BasePlugin):
        pass

    class OtherPlugin(BasePlugin):
        pass

    manager = PluginManager()
    manager.register(Plugin, FormatterPlugin, ConverterPlugin, TransportPlugin, AuthPlugin, OtherPlugin)

    # test
    assert manager.filter(BasePlugin) == [Plugin, FormatterPlugin, ConverterPlugin, TransportPlugin, AuthPlugin, OtherPlugin]
    assert manager.filter(OtherPlugin) == [OtherPlugin]
    assert manager.filter(AuthPlugin) == [AuthPlugin]
    assert manager.filter(TransportPlugin) == [TransportPlugin]

# Generated at 2022-06-23 19:52:16.967859
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(ConverterPlugin,FormatterPlugin)
    plugins.get_formatters()
    length = len(plugins.get_formatters())

    if length > 0:
        assert True
    else:
        assert False

# Generated at 2022-06-23 19:52:20.388551
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugin('digest') is not None
    assert manager.get_auth_plugin('baisc') is not None

# Generated at 2022-06-23 19:52:23.103445
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager=PluginManager()
    manager.load_installed_plugins()
    auth_plugins = manager.get_auth_plugins()
    assert len(auth_plugins)>=2


# Generated at 2022-06-23 19:52:29.917242
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    assert pluginManager.register
    assert pluginManager.unregister
    assert pluginManager.filter
    assert pluginManager.load_installed_plugins
    assert pluginManager.get_auth_plugins
    assert pluginManager.get_auth_plugin_mapping
    assert pluginManager.get_auth_plugin
    assert pluginManager.get_formatters
    assert pluginManager.get_formatters_grouped
    assert pluginManager.get_converters
    assert pluginManager.get_transport_plugins
    assert pluginManager.__repr__
    print("class PluginManager constructor test passed")


# Generated at 2022-06-23 19:52:33.972669
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager([])) == '<PluginManager: []>'
    assert repr(PluginManager([1, 2, 3])) == '<PluginManager: [1, 2, 3]>'
    assert repr(PluginManager([1, 2, 3, 4])) == '<PluginManager: [1, 2, 3, ...]>'


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:52:38.566847
# Unit test for constructor of class PluginManager
def test_PluginManager():
    print("\n Unit test for constructor of class PluginManager")
    plugins = PluginManager()
    assert len(plugins) == 0
    assert plugins.__repr__() == '<PluginManager: []>'


# Generated at 2022-06-23 19:52:40.423371
# Unit test for constructor of class PluginManager
def test_PluginManager():

    p = PluginManager()
    assert p == []


# Generated at 2022-06-23 19:52:45.340186
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    assert [plugin.auth_type for plugin in manager.get_auth_plugins()] == []
    manager.register(BasicAuthPlugin, DigestAuthPlugin)
    assert [plugin.auth_type for plugin in manager.get_auth_plugins()] == ['basic', 'digest']
    assert manager.get_auth_plugin_mapping() == {
        'basic':BasicAuthPlugin,
        'digest':DigestAuthPlugin
    }

# Generated at 2022-06-23 19:52:53.938879
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    from httpie.plugins.builtin.formatter.colors import ColorsFormatterPlugin
    from httpie.plugins.builtin.formatter.format import FormatFormatterPlugin
    plugin_manager.register(ColorsFormatterPlugin)
    plugin_manager.register(FormatFormatterPlugin)

# Generated at 2022-06-23 19:52:55.111300
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    a = PluginManager()
    assert a.get_auth_plugin_mapping() == {}

# Generated at 2022-06-23 19:52:58.096228
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # regester two auth plugins
    PluginManager().register(TestAuthPlugin1, TestAuthPlugin2)
    # get auth plugin mapping
    assert PluginManager().get_auth_plugin_mapping() == {
        'testauth1': TestAuthPlugin1, 'testauth2': TestAuthPlugin2
    }


# Generated at 2022-06-23 19:53:00.390559
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Create
    plugin_manager = PluginManager()
    # Load
    plugin_manager.load_installed_plugins()
    # Test 
    assert len(plugin_manager.get_auth_plugins()) > 0

# Generated at 2022-06-23 19:53:05.790326
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    group_name = 'group1'
    num_group = len(manager.get_formatters_grouped()[group_name])
    manager.append(PluginManager.get_formatters()[0])
    assert len(manager.get_formatters_grouped()[group_name]) == num_group


# Generated at 2022-06-23 19:53:13.168282
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.register(plugin_manager__test_plugin_manager__my_auth_plugin)
    assert len(plugin_manager) == 1
    assert plugin_manager.get_auth_plugin('my_auth') == plugin_manager__test_plugin_manager__my_auth_plugin
    assert plugin_manager.get_auth_plugins()[0] == plugin_manager__test_plugin_manager__my_auth_plugin


# Generated at 2022-06-23 19:53:20.544424
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    def test_format(value):
        time = value[0]
        tz = value[1]
        assert isinstance(time, str)
        assert isinstance(tz, str)

    pm = PluginManager()
    pm.load_installed_plugins()
    converters = pm.get_converters()

    json_to_time = [converter for converter in converters if converter.name == 'jsontotime'][0]
    assert json_to_time.output_type == 'datetime'
    assert len(json_to_time.example_output) == 2
    assert isinstance(json_to_time.example_output, list)
    map(test_format, json_to_time.example_output)

# Generated at 2022-06-23 19:53:25.581752
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    formatter_1 = FormatterPlugin()
    formatter_2 = FormatterPlugin()
    formatter_3 = FormatterPlugin()
    formatter_2.group_name = 'formatter'
    formatter_3.group_name = 'formatter'
    manager.register(formatter_1, formatter_2, formatter_3)

    assert manager.get_formatters_grouped() == {'formatter': [formatter_2, formatter_3]}

    return manager


# Generated at 2022-06-23 19:53:26.909800
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    assert p == []

# Generated at 2022-06-23 19:53:28.848257
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-23 19:53:30.613042
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert PluginManager().get_auth_plugin("basic") == BasicAuthPlugin

# Generated at 2022-06-23 19:53:35.467666
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, FormatterPlugin)
    assert len(plugin_manager) == 2
    plugin_manager.unregister(AuthPlugin)
    assert len(plugin_manager) == 1
    plugin_manager.register(AuthPlugin, TransportPlugin)
    assert len(plugin_manager) == 3


# Generated at 2022-06-23 19:53:39.175905
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    p = PluginManager()
    p.register(auth_plugin_cls1, auth_plugin_cls2)
    assert p.get_auth_plugins() == [auth_plugin_cls1, auth_plugin_cls2]



# Generated at 2022-06-23 19:53:44.025214
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth, KeyValue, KeyValueConverterPlugin, JSON, JSONConverterPlugin
    from httpie.plugins.converter.v1 import ConverterPlugin
    from httpie.plugins.formatter.v1 import FormatterPlugin
    
    plugins = PluginManager()
    plugins.register(HTTPBasicAuth, HTTPDigestAuth, KeyValue, JSON, KeyValueConverterPlugin, JSONConverterPlugin)
    plugins.get_converters()

# Generated at 2022-06-23 19:53:52.194618
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager(None)
    assert plugin_manager.register is not None
    assert plugin_manager.unregister is not None
    assert plugin_manager.filter is not None
    assert plugin_manager.load_installed_plugins is not None
    assert plugin_manager.get_auth_plugins is not None
    assert plugin_manager.get_auth_plugin_mapping is not None
    assert plugin_manager.get_auth_plugin is not None
    assert plugin_manager.get_formatters is not None
    assert plugin_manager.get_formatters_grouped is not None
    assert plugin_manager.get_converters is not None
    assert plugin_manager.get_transport_plugins is not None
    assert plugin_manager.__repr__ is not None

# Generated at 2022-06-23 19:53:58.104452
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # load plugin
    auth_basic_plugin = AuthPlugin()
    auth_ntlm_plugin = AuthPlugin()
    # create plugin manager
    plugin_manager = PluginManager()
    plugin_manager.register(auth_basic_plugin)
    plugin_manager.register(auth_ntlm_plugin)
    # test
    list_auth_plugins = plugin_manager.get_auth_plugins()
    assert len(list_auth_plugins) == 2
    assert auth_basic_plugin in list_auth_plugins
    assert auth_ntlm_plugin in list_auth_plugins


# Generated at 2022-06-23 19:54:01.408740
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([1, 2, 3])) == '<PluginManager: [1, 2, 3]>'


# Generated at 2022-06-23 19:54:04.420423
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(BasePlugin)
    assert pm.filter() == [BasePlugin]
    assert pm.filter(by_type=FormatterPlugin) == []

# Generated at 2022-06-23 19:54:07.694678
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert isinstance(pm, PluginManager)
    assert pm == []
    # repository class is initialised with a list
    assert isinstance(pm, list)


# Generated at 2022-06-23 19:54:10.571094
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    TransportPlugin.__dict__['PRIORITY'] = 1
    plugins = PluginManager()
    get_transport_plugins = plugins.get_transport_plugins()
    assert(type(get_transport_plugins) == list)


# Generated at 2022-06-23 19:54:21.579014
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class SubType(BasePlugin):
        pass

    class SubType2(SubType):
        pass

    class SuperType(TransportPlugin):
        pass

    class SuperType2(SuperType):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(SubType, SuperType, SubType2, SuperType2)
    # There are four types of subclasses of BasePlugin in plugins
    assert len(plugin_manager.filter()) == 4
    # There are two types of subclasses of SuperType in plugins
    assert len(plugin_manager.filter(SuperType)) == 2
    # There are two types of subclasses of SubType in plugins
    assert len(plugin_manager.filter(SubType)) == 2

# Generated at 2022-06-23 19:54:26.945245
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)
    plugins.unregister(AuthPlugin)
    plugins.unregister(FormatterPlugin)
    plugins.unregister(ConverterPlugin)
    plugins.unregister(TransportPlugin)
    assert plugins == []

# Generated at 2022-06-23 19:54:29.824287
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.register(test_1)
    pm.register(test_2)
    assert str(pm) == '<PluginManager: [<class \'{}.test_1\'>, <class \'{}.test_2\'>]>'.format(__name__, __name__)


# Generated at 2022-06-23 19:54:37.606717
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuth
    from httpie.plugins.auth.digest import DigestAuth
    from httpie.plugins.auth.oauth1 import OAuth1Auth
    from httpie.plugins.auth.oauth2 import OAuth2Auth
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuth)
    plugin_manager.register(DigestAuth)
    plugin_manager.register(OAuth1Auth)
    plugin_manager.register(OAuth2Auth)
    assert plugin_manager.get_auth_plugin_mapping() == \
        {'basic': BasicAuth,
         'digest': DigestAuth,
         'oauth1': OAuth1Auth,
         'oauth2': OAuth2Auth}

# Generated at 2022-06-23 19:54:49.071984
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    uninstalled_error_msg = f"httpie is not installed"

    assert plugin_manager.get_auth_plugin("basic").auth_type == "basic"
    assert plugin_manager.get_auth_plugin("digest").auth_type == "digest"
    assert plugin_manager.get_auth_plugin("jwt").auth_type == "jwt"
    assert plugin_manager.get_auth_plugin("hawk").auth_type == "hawk"
    assert plugin_manager.get_auth_plugin("ntlm").auth_type == "ntlm"
    assert plugin_manager.get_auth_plugin("oath").auth_type == "oath"
    assert plugin_manager.get_auth_plugin("accesstoken").auth_

# Generated at 2022-06-23 19:54:51.655889
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert (PluginManager(['a', 'b', 'c']) ==  ['a', 'b', 'c'])


# Generated at 2022-06-23 19:54:56.896075
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.append(AwsAuthPlugin)
    pm.append(BasicAuthPlugin)
    assert(isinstance(pm.get_auth_plugin_mapping()['aws'], AwsAuthPlugin))
    assert(isinstance(pm.get_auth_plugin_mapping()['basic'], BasicAuthPlugin))

# Generated at 2022-06-23 19:55:06.785754
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    mgr = PluginManager()
    mgr.load_installed_plugins()


# Generated at 2022-06-23 19:55:08.514569
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([1])) == '<PluginManager: [1]>'


# Generated at 2022-06-23 19:55:16.832451
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert repr(manager) == '<PluginManager: [colors, json, pretty, raw, table, terminal, xml]>'
    #test get_formatters_grouped
    manager.register(FormatterPlugin)
    assert manager.get_formatters_grouped() == {'Basic': [FormatterPlugin, colors.ColorsPlugin, json.JSONPlugin, pretty.PrettyPlugin, raw.RawPlugin], 'Extra': [table.TablePlugin, terminal.TerminalPlugin, xml.XMLPlugin]}

# Generated at 2022-06-23 19:55:17.842445
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert len(pm) == 0

# Generated at 2022-06-23 19:55:21.946091
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    base_plugin_manager = PluginManager()
    base_plugin_manager.load_installed_plugins()
    assert len(base_plugin_manager) == len(ENTRY_POINT_NAMES)

# Generated at 2022-06-23 19:55:24.037850
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert type(PluginManager().get_auth_plugins()).__name__ == 'list'



# Generated at 2022-06-23 19:55:26.338131
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager, PluginManager)


# Generated at 2022-06-23 19:55:32.605902
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie import __version__
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import OAuth1
    from httpie.plugins.builtin import OAuth2
    import httpie_oauth1
    pm = PluginManager()
    class httpie_oauth1_version(object):
        version = ''
    httpie_oauth1_version.version = httpie_oauth1.__version__
    class httpie_version(object):
        version = ''
    httpie_version.version = __version__
    class mock_dist(object):
        key = ''
    mock_dist.key = 'httpie'
    class httpie_oauth1_plugin(object):
        plugin_type = ''
        package

# Generated at 2022-06-23 19:55:38.138670
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager
    assert PluginManager.register
    assert PluginManager.unregister
    assert PluginManager.filter
    assert PluginManager.load_installed_plugins
    # Auth
    assert PluginManager.get_auth_plugins
    assert PluginManager.get_auth_plugin_mapping
    assert PluginManager.get_auth_plugin
    # Output processing
    assert PluginManager.get_formatters
    assert PluginManager.get_formatters_grouped
    assert PluginManager.get_converters
    # Adapters
    assert PluginManager.get_transport_plugins


# Generated at 2022-06-23 19:55:42.749647
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()

    # Create and mock a formatter plugin
    class MockFormatter(FormatterPlugin):
        pass

    plugin_manager.register(MockFormatter)
    formatter = plugin_manager.get_formatters()[0]
    assert formatter == MockFormatter
    assert isinstance(formatter, FormatterPlugin)

# Generated at 2022-06-23 19:55:48.608551
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager() # type: PluginManager
    pm.register(BearerAuthPlugin, DigestAuthPlugin, HTTPBasicAuthPlugin)
    assert pm.get_auth_plugins() == [BearerAuthPlugin, DigestAuthPlugin, HTTPBasicAuthPlugin]

    # Test
    pm.register(BasicAuthPlugin)
    assert pm.get_auth_plugins() == [BasicAuthPlugin, BearerAuthPlugin, DigestAuthPlugin, HTTPBasicAuthPlugin]
    return True


# Generated at 2022-06-23 19:55:51.533096
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert isinstance(pm.get_transport_plugins(), list)


# Generated at 2022-06-23 19:55:57.122926
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_plugins = PluginManager().get_auth_plugin_mapping()
    assert auth_plugins == {
        'basic': httpie.plugins.auth.basic_auth.BasicAuthPlugin,
        'digest': httpie.plugins.auth.digest_auth.DigestAuthPlugin,
        'hawk': httpie.plugins.auth.hawk.HAWKAuthPlugin,
        'jwt': httpie.plugins.auth.jwt.JWTAuthPlugin,
        'oauth1': httpie.plugins.auth.oauth1.OAuth1Plugin,
        'ntlm': httpie.plugins.auth.ntlm.NtlmPlugin
    }



# Generated at 2022-06-23 19:56:02.786079
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(TransportPlugin_mock_1)
    pm.register(TransportPlugin_mock_2)
    assert len(pm.get_transport_plugins()) == 2
    assert TransportPlugin_mock_1 in pm.get_transport_plugins()
    assert TransportPlugin_mock_2 in pm.get_transport_plugins()
    assert TransportPlugin_mock_3 not in pm.get_transport_plugins()


# Generated at 2022-06-23 19:56:03.761294
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()
    assert True



# Generated at 2022-06-23 19:56:06.608211
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    import tests.all_plugins
    assert PluginManager().get_converters() == []
    # initialize PluginManager
    pm = PluginManager()
    pm.register(tests.all_plugins.ConverterTestPlugin)
    assert pm.get_converters() == [tests.all_plugins.ConverterTestPlugin]

# Generated at 2022-06-23 19:56:08.158947
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    plugin = type('plugin', (BasePlugin,), {})
    pm.register(plugin)
    assert pm.pop() == plugin
    assert plugin not in pm


# Generated at 2022-06-23 19:56:17.171343
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    # It should return no elements when there are no elements
    assert manager.__repr__() == "<PluginManager: []>"

# It should show the elements which were added
manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
assert manager.__repr__() == "<PluginManager: [<class 'httpie.plugins.auth.AuthPlugin'>, <class 'httpie.plugins.converter.ConverterPlugin'>, <class 'httpie.plugins.formatter.FormatterPlugin'>, <class 'httpie.plugins.transport.TransportPlugin'>]>"

# It should show the elements that remain after deleting some element
manager.unregister(AuthPlugin)

# Generated at 2022-06-23 19:56:18.487518
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register()


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:56:20.167725
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    p = PluginManager()
    assert len(p.get_formatters()) == 5


# Generated at 2022-06-23 19:56:28.495752
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class APlugin(BasePlugin):
        pass

    class BPlugin(APlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(APlugin)
    plugin_manager.register(BPlugin)

    assert len(plugin_manager.filter()) == 2
    assert set(plugin_manager.filter()) == {APlugin, BPlugin}
    assert set(plugin_manager.filter(by_type=APlugin)) == {APlugin, BPlugin}
    assert set(plugin_manager.filter(by_type=BPlugin)) == {BPlugin}

# Generated at 2022-06-23 19:56:34.539894
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    result = manager.__repr__()
    assert result == '<PluginManager: []>'
    manager.register(1)
    manager.register(2)
    result = manager.__repr__()
    assert result == '<PluginManager: [1, 2]>'


# Generated at 2022-06-23 19:56:40.498548
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.load_installed_plugins()

    # Get all the formatters group
    group_fmt = pm.get_formatters_grouped()

    # TODO: Add the code below to the test of method get_formatters_grouped
    # Check if the group_fmt exists and is not empty
    assert group_fmt

    # Check if the group_fmt has the json and html as a key
    assert 'json' in group_fmt and 'html' in group_fmt

# Generated at 2022-06-23 19:56:45.159307
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter import ConverterPlugin

    class DummyPlugin(ConverterPlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(DummyPlugin)

    assert plugin_manager.get_converters()[0] == DummyPlugin

# Generated at 2022-06-23 19:56:55.711796
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Test data from httpie.plugins.manager.ENTRY_POINT_NAMES
    auth_entry_point_name = 'httpie.plugins.auth.v1'
    formatter_entry_point_name = 'httpie.plugins.formatter.v1'
    converter_entry_point_name = 'httpie.plugins.converter.v1'
    transport_entry_point_name = 'httpie.plugins.transport.v1'

    # Test data from httpie.plugins.manager.BasePlugin.package_name
    # that are not found in httpie.plugins.manager.ENTRY_POINT_NAMES
    package_name_not_found = 'httpie.plugins'

    # Create a PluginManager
    plugin_manager = PluginManager()

    # Create a new plugin entry_point that is not found in


# Generated at 2022-06-23 19:56:57.342534
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

# Generated at 2022-06-23 19:57:00.441589
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(ConverterPlugin)
    expected_output = [AuthPlugin]
    assert plugins.get_auth_plugins() == expected_output, "The method is not returning the all the auth plugins. The expected output is " + str(expected_output) + " but the actual output is " + str(plugins.get_auth_plugins())


# Generated at 2022-06-23 19:57:05.551627
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.unregister(plugin_manager.get_auth_plugin('basic'))
    assert 'basic' not in plugin_manager.get_auth_plugin_mapping().keys()


# Generated at 2022-06-23 19:57:06.609494
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Test code
    pass


# Generated at 2022-06-23 19:57:09.324553
# Unit test for constructor of class PluginManager
def test_PluginManager():
    # Test the constructor of class PluginManager
    plugin_man = PluginManager()
    assert len(plugin_man) == 0
    assert str(plugin_man) == '<PluginManager: []>'


# Generated at 2022-06-23 19:57:10.924237
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    p = PluginManager()
    p.register([1,2,3])
    assert p == [1,2,3]
    p.unregister(1)
    assert p == [2,3]

# Generated at 2022-06-23 19:57:12.017728
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p = PluginManager()
    assert type(p.get_transport_plugins()) is list

# Generated at 2022-06-23 19:57:14.566378
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) > 0
    for plugin in plugin_manager:
        assert 'httpie' not in plugin.package_name

# Generated at 2022-06-23 19:57:17.930730
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register(ConverterPlugin)
    assert manager.get_converters() == [ConverterPlugin]


# Generated at 2022-06-23 19:57:24.797675
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    installed_formatter_plugins = plugin_manager.get_formatters()
    for formatter_plugin in installed_formatter_plugins:
        # Verify that formatter_plugin is a subclass of FormatterPlugin.
        assert issubclass(formatter_plugin, FormatterPlugin)
        # Verify that formatter_plugin belongs to group 'formatter'.
        assert formatter_plugin.group_name == 'formatter'
        # Verify that posix of formatter_plugin is True or False.
        assert formatter_plugin.posix in [True, False]


# Generated at 2022-06-23 19:57:30.485069
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():

    # Test getting auth plugin for auth type 'XXX'
    class AuthPluginXXX(AuthPlugin):
        auth_type = 'XXX'

    plugin_manager = PluginManager()
    plugin_manager.register(AuthPluginXXX)
    auth_plugin = plugin_manager.get_auth_plugin('XXX')
    assert auth_plugin == AuthPluginXXX

    # Test getting auth plugin for auth type 'YYY'
    class AuthPluginYYY(AuthPlugin):
        auth_type = 'YYY'

    plugin_manager = PluginManager()
    plugin_manager.register(AuthPluginYYY)
    auth_plugin = plugin_manager.get_auth_plugin('YYY')
    assert auth_plugin == AuthPluginYYY

# Generated at 2022-06-23 19:57:35.082881
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    result = plugin_manager.get_formatters_grouped()
    assert type(result) == dict
    for key in result.keys():
        assert type(result[key]) == list
        for item in result[key]:
            assert issubclass(item, FormatterPlugin)

# Generated at 2022-06-23 19:57:37.615824
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.register(None)
    assert len(plugin_manager) == 1



# Generated at 2022-06-23 19:57:40.618426
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugins() == []
    manager.register(Mock)
    assert manager.get_auth_plugins() == []
    manager.register(MockAuthPlugin)
    assert m

# Generated at 2022-06-23 19:57:45.348646
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import JSONFormatPlugin, FormUrlEncodedFormatPlugin
    expected_lst = [JSONFormatPlugin, FormUrlEncodedFormatPlugin]
    manager = PluginManager()
    manager.register(JSONFormatPlugin, FormUrlEncodedFormatPlugin)
    output = manager.get_formatters()
    assert output == expected_lst, f"Expected {expected_lst} but got {output}"

test_PluginManager_get_formatters()


# Generated at 2022-06-23 19:57:46.589532
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm=PluginManager()
    assert type(pm) is PluginManager

# Generated at 2022-06-23 19:57:54.367797
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.load_installed_plugins()
    plugin = manager.get_auth_plugin('httpie-oauth1')
    assert plugin.name == 'HTTPie-OAuth1'
    try:
        plugin = manager.get_auth_plugin('no-such-auth-plugin')
        assert False
    except KeyError as e:
        assert 'no-such-auth-plugin' in str(e)

# Generated at 2022-06-23 19:57:58.981506
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Arrange
    plugin_manager = PluginManager()
    
    # Act
    auth_plugins = plugin_manager.get_auth_plugins()
    
    # Assert
    assert type(auth_plugins) is list
    assert len(auth_plugins) == 0
    
    

# Generated at 2022-06-23 19:58:01.770054
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    mng = PluginManager()
    mng.load_installed_plugins()
    assert mng is not None
    # check if the list is not empty
    assert len(mng) > 0



# Generated at 2022-06-23 19:58:11.304776
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class formatter(FormatterPlugin):
        package_name = 'test_package'

        def test_method(self):
            pass

    class formatter2(FormatterPlugin):
        package_name = 'test_package'

        def test_method_2(self):
            pass

    formatter3 = FormatterPlugin()

    pm = PluginManager()
    pm.register(formatter)
    pm.register(formatter2)
    pm.register(formatter3)

    assert(pm.get_formatters() == [formatter, formatter2, formatter3])
    assert(pm.filter(FormatterPlugin) == [formatter, formatter2, formatter3])

# Generated at 2022-06-23 19:58:14.031017
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    # print(pluginmanager.get_auth_plugin_mapping())
    assert len(pluginmanager.get_auth_plugin_mapping()) == 8


# Generated at 2022-06-23 19:58:16.118913
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin("basic")



# Generated at 2022-06-23 19:58:26.515819
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group 1'

    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group 1'

    class FormatterPlugin3(FormatterPlugin):
        group_name = 'group 2'

    class FormatterPlugin4(FormatterPlugin):
        group_name = 'group 1'

    manager = PluginManager()
    manager.register(FormatterPlugin1, FormatterPlugin2,
                     FormatterPlugin3, FormatterPlugin4)
    grouped = {
        'group 1': [FormatterPlugin1, FormatterPlugin2, FormatterPlugin4],
        'group 2': [FormatterPlugin3],
    }

    assert manager.get_formatters_grouped() == grouped


# Generated at 2022-06-23 19:58:33.573164
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Initializing python entry points within plugin package
    entry_points = [
        Mock(
            name=name,
            load=lambda: name
        )
        for name
        in ENTRY_POINT_NAMES
    ]
    iter_entry_points = Mock(return_value=entry_points)
    pkg_resources = Mock(iter_entry_points=iter_entry_points)
    with patch.dict(sys.modules, {'pkg_resources': pkg_resources}):
        manager = PluginManager()
        manager.load_installed_plugins()
        for ep in entry_points:
            assert issubclass(ep.load(), BasePlugin)

# Generated at 2022-06-23 19:58:35.924200
# Unit test for constructor of class PluginManager
def test_PluginManager():
	test = PluginManager()
	assert test.get_auth_plugins() == []


# Generated at 2022-06-23 19:58:45.157148
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.register('httpie.plugins.formatter.pretty_json.PrettyJSONConverter')
    plugins.register('httpie.plugins.formatter.json.JSONConverter')
    plugins.register('httpie.plugins.formatter.pretty_xml.PrettyXMLConverter')
    plugins.register('httpie.plugins.formatter.xml.XMLConverter')
    plugins.register('httpie.plugins.formatter.colors.ColoredStreamConverter')
    plugins.register('httpie.plugins.formatter.format.FormatConverter')

# Generated at 2022-06-23 19:58:52.680013
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    class Plugin1(AuthPlugin):
        auth_type = 'plug1authtype'
    class Plugin2(AuthPlugin):
        auth_type = 'plug2authtype'
    class Plugin3(AuthPlugin):
        auth_type = 'plug3authtype'
    
    plugin_manager.register(Plugin1, Plugin2, Plugin3)
    plugin = plugin_manager.get_auth_plugin('plug1authtype')
    assert type(plugin) == type(Plugin1)

# Generated at 2022-06-23 19:58:57.878829
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # Create a PluginManager and add a converter
    pm = PluginManager()
    pm.register(MyConverter)
    # Test that there is only one converter
    assert len(pm.get_converters()) == 1
    # Test that the converter is MyConverter
    assert pm.get_converters()[0] == MyConverter


# Generated at 2022-06-23 19:59:06.627702
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    try:
        import httpie.plugins.formatter
        import httpie.plugins.auth
        import httpie.plugins.converter
        import httpie.plugins.transport
        plugins.load_installed_plugins()
    except Exception:
        pass

    assert str(plugins) == '<PluginManager: [httpie.plugins.auth.httpie_auth_digest,'\
                           ' httpie.plugins.auth.httpie_auth_jwt,' \
                           ' httpie.plugins.auth.httpie_auth_hawk,' \
                           ' httpie.plugins.auth.httpie_auth_oauth2,' \
                           ' httpie.plugins.auth.httpie_auth_netrc,' \
                           ' httpie.plugins.auth.httpie_auth_multi,' \
                

# Generated at 2022-06-23 19:59:14.408118
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin

    manager = PluginManager()

    manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)

    assert len(manager.filter(AuthPlugin)) == 1
    assert len(manager.filter(ConverterPlugin)) == 1
    assert len(manager.filter(FormatterPlugin)) == 1
    assert len(manager.filter(TransportPlugin)) == 1

    manager.unregister(AuthPlugin)

    assert len(manager.filter(AuthPlugin)) == 0
    assert len(manager.filter(ConverterPlugin)) == 1
    assert len(manager.filter(FormatterPlugin)) == 1
    assert len(manager.filter(TransportPlugin)) == 1


# Generated at 2022-06-23 19:59:17.787226
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    #print("manager =",manager)
    assert len(manager) > 0
    
test_PluginManager_get_auth_plugins()


# Generated at 2022-06-23 19:59:24.287731
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager=PluginManager()
    plugin_manager.load_installed_plugins()
    l=plugin_manager.get_transport_plugins()
    assert l[0].__name__ == 'BaseTransport'
    assert l[1].__name__ == 'GoogleTransport'
    assert l[2].__name__ == 'FacebookTransport'
    assert l[3].__name__ == 'CrawlTransport'
    print(l)


# Generated at 2022-06-23 19:59:32.334310
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from collections import Counter
    from httpie import plugins

    pm = PluginManager()

    from httpie.plugins.base import BasePlugin
    from httpie.plugins.auth.v1 import AuthPlugin
    from httpie.plugins.formatter.v1 import FormatterPlugin
    from httpie.plugins.converter.v1 import ConverterPlugin
    from httpie.plugins.transport.v1 import TransportPlugin

    pm.register(BasePlugin, AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

    c = Counter(type(i) for i in pm.filter(AuthPlugin))
    assert c == Counter({
        BasePlugin: 0,
        AuthPlugin: 1,
        FormatterPlugin: 0,
        ConverterPlugin: 0,
        TransportPlugin: 0
    })


# Generated at 2022-06-23 19:59:34.936167
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    # Test the method filter can return all AuthPlugin classes
    assert pluginManager.filter(AuthPlugin) == self.get_auth_plugins()

# Generated at 2022-06-23 19:59:35.413469
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pass

# Generated at 2022-06-23 19:59:40.747910
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins.builtin import HTTPBasicAuth
    pm = PluginManager()
    assert HTTPBasicAuth() in pm
    assert HTTPBasicAuth not in pm
    pm.unregister(HTTPBasicAuth)
    assert HTTPBasicAuth() not in pm
    assert HTTPBasicAuth not in pm


# Generated at 2022-06-23 19:59:45.541530
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie.plugins.builtin
    plugin_manager = PluginManager()
    plugin_manager.register(httpie.plugins.builtin.JSONFormatter)

# Generated at 2022-06-23 19:59:47.904964
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == []
    assert len(pm) == 0
    assert repr(pm) == '<PluginManager: []>'

# Generated at 2022-06-23 19:59:51.585903
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register()
    auth_plugin_mapping = manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping
    assert isinstance(auth_plugin_mapping, dict)
    # test if the auth_type in the auth_plugin_mapping is valid,
    # and it has been loaded into the plugin manager
    plugin_mapping = manager.get_auth_plugin(auth_plugin_mapping.keys()[-1])
    assert plugin_mapping

# Generated at 2022-06-23 20:00:02.284385
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Ensure no plugins are registered
    pm = PluginManager()
    pm.clear()
    assert len(pm) == 0
    assert len(pm.get_formatters()) == 0
    assert len(pm.get_formatters_grouped()) == 0

    pm.register(
        JSONFormatter,
        URLEncodedFormatter,
        PrettyURLEncodedFormatter,
        HTMLFormatter,
        PrettyHTMLFormatter,
        ImageFormatter
    )

    assert JSONFormatter in pm
    assert URLEncodedFormatter in pm
    assert PrettyURLEncodedFormatter in pm
    assert HTMLFormatter in pm
    assert PrettyHTMLFormatter in pm
    assert ImageFormatter in pm

    assert len(pm.get_formatters()) == 6

    grouped = pm.get_formatters_grouped()


# Generated at 2022-06-23 20:00:07.713101
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    t = p.get_transport_plugins()
    t = str(t)

    assert t == '[httpie.downloads.<class \'httpie.plugins.transport._curl.CurlTransportAdapter\'>, httpie.downloads.<class \'httpie.plugins.transport._http2.HTTP2Transport\'>]'


# Generated at 2022-06-23 20:00:11.000482
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert (plugin_manager.get_auth_plugins() == [])
    plugin_manager.register(AuthPlugin)
    assert (plugin_manager.get_auth_plugins() == [AuthPlugin])


# Generated at 2022-06-23 20:00:15.051315
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert(str(plugin_manager.get_auth_plugin('basic')) == "<class 'httpie.plugins.auth.basic.BasicAuth'>")
    assert(str(plugin_manager.get_auth_plugin('digest')) == "<class 'httpie.plugins.auth.digest.DigestAuth'>")


# Generated at 2022-06-23 20:00:19.317619
# Unit test for constructor of class PluginManager
def test_PluginManager():
    print(PluginManager)

plugin_manager = PluginManager()
"""
PluginManager base class.

`plugin_manager` is the main instance,
which manages the installed plugins,
provides access to them, and so on.
"""


# Generated at 2022-06-23 20:00:21.613801
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class A(object):
        pass
    pm.register(A)
    assert A in pm


# Generated at 2022-06-23 20:00:25.176209
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():

    # arrange stage
    plugin_manager = PluginManager()

    # act stage
    formatters = plugin_manager.get_formatters()

    # assert stage
    assert len(formatters) > 0

if __name__ == '__main__':
    test_PluginManager_get_formatters()

# Generated at 2022-06-23 20:00:29.271930
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager.get_converters.__doc__ == "get list of ConverterPlugin objects"
    pm = PluginManager()
    cps = pm.get_converters()
    for plugin in cps:
        assert issubclass(plugin, ConverterPlugin)


# Generated at 2022-06-23 20:00:36.406204
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin

    from mock import Mock

    converter_vmock = Mock(spec=ConverterPlugin)
    converter_num = 15

    for i in range(converter_num):
        converter_vmock = Mock(spec=ConverterPlugin)
        converter_vmock.name = 'httpie_mock_converter_' + str(i)
        PluginManager().register(converter_vmock)

    converters = PluginManager().get_converters()
    assert (len(converters) == converter_num)
    for converter in converters:
        assert (issubclass(converter, ConverterPlugin))
    assert (converters[0].name == 'httpie_mock_converter_0')


# Generated at 2022-06-23 20:00:44.102211
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PLUGIN_MANAGER = PluginManager()
    PLUGIN_MANAGER.load_installed_plugins()
    assert len(PLUGIN_MANAGER) == 7
    assert {'httpie-jwt-auth', 'httpie-querystring', 'httpie-html', 'httpie-json', 'httpie-keyring', 'httpie-aws-auth', 'httpie-aws4-auth'} == set(PLUGIN_MANAGER.get_auth_plugin_mapping())


# Generated at 2022-06-23 20:00:47.833220
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager.load_installed_plugins()

    assert(len(plugin_manager) == 4)

