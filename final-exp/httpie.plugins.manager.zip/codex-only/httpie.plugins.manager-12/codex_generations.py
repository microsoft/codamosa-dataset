

# Generated at 2022-06-23 19:50:52.222640
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            p.register(entry_point.load())
    assert isinstance(p.get_auth_plugins(), list)
    assert isinstance(p.get_auth_plugin_mapping(), dict)
    assert isinstance(p.get_formatters(), list)
    assert isinstance(p.get_formatters_grouped(), dict)
    assert isinstance(p.get_converters(), list)
    assert isinstance(p.get_transport_plugins(), list)

# Generated at 2022-06-23 19:51:00.174034
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert 'get_formatters' in PluginManager.__dict__.keys()
    assert 'get_formatters' in dir(pm)
    assert 'get_formatters' in pm.__dict__.keys()
    assert 'get_formatters' in pm.__dir__()
    assert 'get_formatters' in pm.__dict__.keys()
    assert callable(pm.get_formatters)

# Generated at 2022-06-23 19:51:04.730735
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    a = PluginManager()
    a.register(AuthPlugin, AuthPlugin)
    a.register(TransportPlugin)
    assert len(a.get_auth_plugins()) == 2

# Generated at 2022-06-23 19:51:06.249672
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert isinstance(PluginManager(), PluginManager)


# Generated at 2022-06-23 19:51:12.085281
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert repr(plugins) == '<PluginManager: [<class \'httpie.plugins.auth.base.AuthPlugin\'>, <class \'httpie.plugins.converter.base.ConverterPlugin\'>, <class \'httpie.plugins.formatter.base.FormatterPlugin\'>, <class \'httpie.plugins.transport.base.TransportPlugin\'>]>'


# Generated at 2022-06-23 19:51:15.319074
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager=PluginManager()
    plugin_manager.append(get_auth_plugin())
    assert plugin_manager.get_auth_plugin() is not None


# Generated at 2022-06-23 19:51:17.732554
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(AuthPlugin)
    manager.get_auth_plugin("basic")


# Generated at 2022-06-23 19:51:19.953754
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins_manager = PluginManager()
    plugins_manager.register(HttpiePlugin)
    assert HttpiePlugin in plugins_manager


# Generated at 2022-06-23 19:51:29.002910
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pluginManager = PluginManager()
    pluginManager.register(Plugin1, Plugin2)
    # Test method with two plugin
    plugins = pluginManager.get_transport_plugins()
    assert(Plugin1 in plugins)
    assert(Plugin2 in plugins)
    assert(len(plugins) == 2)
    # Test if the method still works with another plugin that is not a transport plugin
    pluginManager.register(Plugin3)
    plugins = pluginManager.get_transport_plugins()
    assert(Plugin1 in plugins)
    assert(Plugin2 in plugins)
    assert(Plugin3 not in plugins)
    assert(len(plugins) == 2)
    # Test if the method still works with a plugin that is not a plugin
    pluginManager.register(Plugin4)
    plugins = pluginManager.get_transport_plugins()

# Generated at 2022-06-23 19:51:31.979831
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'
    plugin_manager.append(PluginManager)
    assert repr(plugin_manager) == '<PluginManager: [<class \'httpie_plugins.PluginManager\'>]>'

# Generated at 2022-06-23 19:51:34.461355
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin

    manager = PluginManager()
    manager.load_installed_plugins()

    assert manager.get_auth_plugins() == [BasicAuthPlugin, DigestAuthPlugin]





# Generated at 2022-06-23 19:51:37.958045
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # 1
    p = PluginManager()
    p1 = BasePlugin()
    p.register(p1)
    assert p1 in p
    # 2
    p2 = BasePlugin()
    p2_2 = BasePlugin()
    p.register(p2, p2_2)
    assert p2 in p
    assert p2_2 in p
    assert 2 == len(p)


# Generated at 2022-06-23 19:51:39.675113
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    p = PluginManager()
    assert isinstance(p.get_formatters(), list)


# Generated at 2022-06-23 19:51:48.626157
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin
    from httpie.plugins import AuthPluginDemo, ConverterPluginDemo, FormatterPluginDemo, TransportPluginDemo

    plugin_manager = PluginManager()
    plugin_manager.register(AuthPluginDemo, ConverterPluginDemo, FormatterPluginDemo, TransportPluginDemo)

    plugin_manager.unregister(AuthPluginDemo)

    assert len(plugin_manager.filter(AuthPlugin)) == 0
    assert len(plugin_manager.filter(ConverterPlugin)) == 1
    assert len(plugin_manager.filter(FormatterPlugin)) == 1
    assert len(plugin_manager.filter(TransportPlugin)) == 1


# Generated at 2022-06-23 19:51:51.787541
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(BasicAuthPlugin)
    assert pm.get_auth_plugin_mapping() == {
        'basic': BasicAuthPlugin
    }


# Generated at 2022-06-23 19:51:53.208347
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    assert PluginManager.register([]) == []


# Generated at 2022-06-23 19:51:56.156581
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert PluginManager().get_auth_plugin('Basic') == BasicAuthPlugin
    assert PluginManager().get_auth_plugin('Digest') == DigestAuthPlugin
    assert PluginManager().get_auth_plugin('AWS') == AWSAuthPlugin


# Generated at 2022-06-23 19:52:01.039586
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_transport_plugins()) == 1

if __name__ == '__main__':
    test_PluginManager_get_transport_plugins()

# Generated at 2022-06-23 19:52:07.175766
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.base import plugin_manager

    class FormatterPluginX(FormatterPlugin):
        group_name = 'x'

    class FormatterPluginY(FormatterPlugin):
        group_name = 'y'

    class FormatterPluginZ(FormatterPlugin):
        group_name = 'z'

    class FormatterPluginW(FormatterPlugin):
        group_name = 'w'

    # register
    plugin_manager.register(FormatterPluginX, FormatterPluginY, FormatterPluginZ, FormatterPluginW)

    # get_formatters_grouped
    grouped = plugin_manager.get_formatters_grouped()
    assert list(grouped) == ['x', 'y', 'z', 'w']

    # teardown
    plugin_manager.un

# Generated at 2022-06-23 19:52:13.494436
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    from httpie.plugins.builtin import HTTPBasicAuth

    plugin_manager.register(HTTPBasicAuth)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': HTTPBasicAuth}
    assert plugin_manager.get_auth_plugin('basic') == HTTPBasicAuth


# Generated at 2022-06-23 19:52:17.348141
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin1)
    plugin_manager.register(TestPlugin2)
    plugin_manager.load_installed_plugins()
    assert plugin_manager == [TestPlugin1, TestPlugin2]



# Generated at 2022-06-23 19:52:19.666614
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.load_installed_plugins()
    plugin = manager.get_auth_plugin('oauth2')
    assert plugin.auth_type == 'oauth2'

# Generated at 2022-06-23 19:52:22.188428
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    auth_plugins = PluginManager().get_auth_plugins()
    assert auth_plugins
    assert all(issubclass(p, AuthPlugin) for p in auth_plugins)


# Generated at 2022-06-23 19:52:26.784291
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    type_plugin_manager = PluginManager()
    type_plugin_manager.register(DummyAuthPlugin)
    type_plugin_manager.register(DummyAuthPlugin2)
    assert type_plugin_manager.get_auth_plugin_mapping() == {
        'dummy_auth': DummyAuthPlugin, 'dummy_auth2': DummyAuthPlugin2
    }


# Generated at 2022-06-23 19:52:29.675750
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    transports = pm.get_transport_plugins()
    assert len(transports) == 1
    assert transports[0].name == 'urllib3'



# Generated at 2022-06-23 19:52:33.836396
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import PluginManager
    from httpie.plugins.builtin import HTTPiePlugin

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugins = plugin_manager.get_formatters()

    assert isinstance(plugins, list)
    assert isinstance(plugins[0], type)
    assert issubclass(plugins[0], HTTPiePlugin)

# Generated at 2022-06-23 19:52:37.960975
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert isinstance(manager.get_auth_plugin('basic'), AuthPlugin)


# Generated at 2022-06-23 19:52:42.852411
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_mgr=PluginManager()
    plugin_mgr.append(AuthPlugin)
    plugin_mgr.remove(AuthPlugin)
    assert plugin_mgr == []
    plugin_mgr.append(AuthPlugin)
    plugin_mgr.remove(AuthPlugin)
    assert plugin_mgr == []


# Generated at 2022-06-23 19:52:44.956934
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert PluginManager().get_formatters() == []

# Generated at 2022-06-23 19:52:48.214868
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    auth_plugins = plugins.get_auth_plugins()
    assert len(auth_plugins) == 4


# Generated at 2022-06-23 19:52:50.949232
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(BasePlugin)
    plugins.unregister(BasePlugin)
    assert BasePlugin not in plugins

# Generated at 2022-06-23 19:52:56.124715
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Load FakeFormatterPlugin1, FakeFormatterPlugin2, FakeFormatterPlugin3 which will have
    # group_name 'fake_group'
    manager = PluginManager()
    manager.register(FakeFormatterPlugin1, FakeFormatterPlugin2, FakeFormatterPlugin3)
    group_list = manager.get_formatters_grouped()
    assert group_list == {'fake_group': [FakeFormatterPlugin1, FakeFormatterPlugin2, FakeFormatterPlugin3]}


# Generated at 2022-06-23 19:52:59.169669
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class Plugin(BasePlugin):
        pass

    plugin = Plugin()
    assert plugin not in pm
    pm.register(Plugin)
    assert plugin in pm



# Generated at 2022-06-23 19:53:10.165721
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    assert pm.filter() == [], 'Initial list should be empty'
    class Test(BasePlugin):
        pass
    class Test2(Test):
        pass
    pm.register(Test, Test2)
    assert pm.filter() == [Test, Test2], 'all plugins list should return both'
    assert pm.filter(Test) == [Test, Test2], f'{Test} should filter both'
    assert pm.filter(Test2) == [Test2], f'{Test2} should filter only itself'
    assert pm.filter(by_type=Test) == [Test, Test2], 'Filter by type should work'
    assert pm.filter(Test2) != [Test], f'Filter by {Test2} should not return {Test}'

# Generated at 2022-06-23 19:53:20.195325
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    result = plugin_manager.get_formatters()


# Generated at 2022-06-23 19:53:22.857713
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    assert type(plugins) == PluginManager
    assert type(plugins.get_formatters()) == list
    assert type(plugins.get_formatters()[0]) == type


# Generated at 2022-06-23 19:53:25.842347
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import AuthPlugin
    class HelloWorld(AuthPlugin):
        auth_type = 'hello-world'
    
    plugins = PluginManager()
    plugins.register(HelloWorld)
    assert len(plugins.get_auth_plugins()) == 1
    assert isinstance(plugins.get_auth_plugin('hello-world'), HelloWorld)

# Generated at 2022-06-23 19:53:27.625591
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager.get_auth_plugins().__class__.__name__ == 'list'

# Generated at 2022-06-23 19:53:36.008194
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter.v1 import FormatterPlugin
    
    def plugin_class(group_name):
        class MockFormatterPlugin(FormatterPlugin):
            group_name = group_name
            name = ''
        return MockFormatterPlugin
    
    manager = PluginManager()
    manager.register(plugin_class('group1'), plugin_class('group1'), plugin_class('group2'))
    assert manager.get_formatters_grouped() == {'group1': [plugin_class('group1'), plugin_class('group1')], 
                                                'group2': [plugin_class('group2')]}

# Generated at 2022-06-23 19:53:36.962651
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    assert manager == []

# Generated at 2022-06-23 19:53:39.275444
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plm = PluginManager()

    assert 'bearer' == plm.get_auth_plugin('bearer').auth_type

# Generated at 2022-06-23 19:53:41.140683
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
  from httpie.plugins import AuthPlugin
  plugin_manager = PluginManager()
  plugin_manager.register(RequireHTTPSHttpAuthPlugin)
  assert plugin_manager.get_auth_plugins == [RequireHTTPSHttpAuthPlugin]



# Generated at 2022-06-23 19:53:44.519331
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    assert repr(plugin_manager) == "<PluginManager: [<class 'httpie.plugins.base.BasePlugin'>]>"

# Generated at 2022-06-23 19:53:49.418729
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    global FormatterPlugin
    PluginManager.get_formatters_grouped()
    class FormatterPlugin(object):
        group_name = {'group_one': '1', 'group_two': '2'}
        def __init__(self):
            self.plugin_manager = PluginManager()
    assert FormatterPlugin.group_name == {'group_one': '1', 'group_two': '2'}
    return True


# Generated at 2022-06-23 19:53:53.337587
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager._plugins=[]
    PluginManager.register(AuthPlugin)
    PluginManager.register(FormatterPlugin)
    PluginManager.register(ConverterPlugin)
    PluginManager.register(TransportPlugin)
    assert len(PluginManager.filter(AuthPlugin)) == 1
    assert len(PluginManager.filter(FormatterPlugin)) == 1
    assert len(PluginManager.filter(ConverterPlugin)) == 1
    assert len(PluginManager.filter(TransportPlugin)) == 1


# Generated at 2022-06-23 19:53:54.231003
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert plugin_manager == []


# Generated at 2022-06-23 19:53:56.465457
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register(PluginManager)
    plugins.register(PluginManager)
    assert(len(plugins) == 2)


# Generated at 2022-06-23 19:53:58.646968
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_list = []
    pm = PluginManager(plugin_list)
    assert pm == plugin_list


# Generated at 2022-06-23 19:54:01.165279
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'



# Generated at 2022-06-23 19:54:04.151757
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(MockAuthPlugin)
    assert manager.get_auth_plugin('mock') == MockAuthPlugin


# Generated at 2022-06-23 19:54:08.827612
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    print('\n### Testing get_converters in class PluginManager')
    plugin_mgr = PluginManager()
    plugin_mgr.load_installed_plugins()
    print('get_converters:', plugin_mgr.get_converters())

test_PluginManager_get_converters()


# Generated at 2022-06-23 19:54:16.476405
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    import httpie.plugins.formatter.v1
    manager.register(httpie.plugins.formatter.v1.JsonFormatterPlugin)
    manager.register(httpie.plugins.formatter.v1.DebugFormatterPlugin)
    formatters = manager.get_formatters()
    assert formatters[0].name=='json'
    assert formatters[1].name=='debug'
    assert manager.filter(FormatterPlugin)[0].name=='json'


# Generated at 2022-06-23 19:54:19.158235
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    assert p.filter(AuthPlugin) == []
    assert isinstance(p, list)


# Generated at 2022-06-23 19:54:26.907240
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, ARGFormatterPlugin, FormURLEncodedFormatterPlugin, HTMLFormatterPlugin, PrettyJsonFormatterPlugin, URLEncodedFormatterPlugin, RawJSONRendererPlugin, ImageRendererPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, ARGFormatterPlugin, FormURLEncodedFormatterPlugin, HTMLFormatterPlugin, URLEncodedFormatterPlugin, RawJSONRendererPlugin, ImageRendererPlugin, PrettyJsonFormatterPlugin)
    grouped_formatters = plugin_manager.get_formatters_grouped()

    # test for key of grouped formatters
    assert 'Data Processors' in grouped_formatters
    assert 'Renderers' in grouped_formatters
    assert 'HTTP Headers' in grouped_format

# Generated at 2022-06-23 19:54:31.417195
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plg_manager = PluginManager()
    plg_manager.register(str)
    assert len(plg_manager) == 1
    assert plg_manager[0] == str
    plg_manager.register([])
    assert len(plg_manager) == 2
    assert plg_manager[1] == list


# Generated at 2022-06-23 19:54:35.739774
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    bar = lambda x:x
    test_plugin = type("test_plugin",(BasePlugin, ), dict(auth_type='test_auth_type', auth_plugin=bar))
    manager = PluginManager()
    manager.register(test_plugin)
    assert manager.get_auth_plugin_mapping() == {'test_auth_type':test_plugin }


# Generated at 2022-06-23 19:54:43.646417
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter.json import JSONFormatterPlugin
    from httpie.plugins.formatter.pretty import PrettyFormatterPlugin
    from httpie.plugins.formatter.ugly import UglyFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, PrettyFormatterPlugin, UglyFormatterPlugin)

    assert plugin_manager.get_formatters_grouped() == {
        'json': [JSONFormatterPlugin],
        'pretty': [PrettyFormatterPlugin],
        'ugly': [UglyFormatterPlugin]
    }

# Generated at 2022-06-23 19:54:48.401704
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
  from httpie.plugins.builtin import HTTPBasicAuth
  from httpie.plugins import AuthPlugin
  manager = PluginManager()
  manager.register(HTTPBasicAuth)
  assert manager.get_auth_plugin('basic') is HTTPBasicAuth


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:54:49.926407
# Unit test for constructor of class PluginManager
def test_PluginManager():
    a = PluginManager()
    assert a == a
    assert isinstance(a, list)



# Generated at 2022-06-23 19:54:56.218206
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager.get_formatters_grouped.__name__ == 'get_formatters_grouped'
    pm = PluginManager()
    pm.load_installed_plugins()
    groups = pm.get_formatters_grouped()
    assert groups != None
    assert groups.keys != None
    assert groups['group'] != None
    assert len(groups['group']) > 0

# Generated at 2022-06-23 19:54:58.105667
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert pm.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-23 19:55:07.452488
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import builtin
    from httpie.plugins import FormatterPlugin
    from httpie.output.formats import DEFAULT_FORMAT

    manager = PluginManager()
    manager.register(builtin.JSONFormatter)

    formatters = manager.get_formatters()
    assert len(formatters) == 1 and isinstance(formatters[0], FormatterPlugin)
    assert formatters[0] == builtin.JSONFormatter

    plugin = formatters[0]
    assert plugin.name == 'JSON'
    assert plugin.group_name == 'Pretty'
    assert plugin.group_index == 2
    assert plugin.format_name == 'json'
    assert plugin.output_type == 'json'
    assert plugin.output_stream_type == 'file'
    assert plugin.get_help() == plugin.help


# Generated at 2022-06-23 19:55:16.429379
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    obj = PluginManager()
    assert 'JSON' in obj.get_formatters_grouped()
    assert 'XML' in obj.get_formatters_grouped()
    assert 'HTML' in obj.get_formatters_grouped()
    assert 'DATA' in obj.get_formatters_grouped()
    assert 'YAML' in obj.get_formatters_grouped()
    assert 'Colored' in obj.get_formatters_grouped()
    assert 'Headers' in obj.get_formatters_grouped()

# Generated at 2022-06-23 19:55:25.018543
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugins() == []
    assert plugin_manager.get_auth_plugin_mapping() == {}
    assert plugin_manager.get_formatters() == []
    assert plugin_manager.get_formatters_grouped() == {}
    assert plugin_manager.get_converters() == []
    assert plugin_manager.get_transport_plugins() == []

# Generated at 2022-06-23 19:55:30.421966
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin,
    ConverterPlugin, AuthPlugin, FormatterPlugin)
    assert len(plugin_manager.filter(TransportPlugin)) == 1
    assert len(plugin_manager.filter(ConverterPlugin)) == 1
    assert len(plugin_manager.filter(AuthPlugin)) == 1
    assert len(plugin_manager.filter(FormatterPlugin)) == 1

if __name__ == '__main__':
    test_PluginManager_filter()

# Generated at 2022-06-23 19:55:32.070788
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert next(iter(pm)).__name__ == 'AuthPlugin'
    assert next(iter(pm)).__name__ != 'FormatterPlugin'


# Generated at 2022-06-23 19:55:34.134906
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin = plugin_manager.get_auth_plugin('basic')
    assert auth_plugin.auth_type == 'basic'
    assert auth_plugin.package_name == 'httpie'


# Generated at 2022-06-23 19:55:39.810350
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    assert len(plugin_manager) == 2
    plugin_manager.unregister(FormatterPlugin)
    assert len(plugin_manager) == 1
    assert AuthPlugin in plugin_manager
    assert FormatterPlugin not in plugin_manager

plugin_manager = PluginManager()

# Generated at 2022-06-23 19:55:49.501574
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin1 = type('plugin1', (), {})
    plugin2 = type('plugin2', (), {})
    plugin3 = type('plugin3', (), {})
    plugin4 = type('plugin4', (), {})
    plugin5 = type('plugin5', (), {})
    plugin6 = type('plugin6', (), {})
    plugin7 = type('plugin7', (), {})

    manager = PluginManager()

    class DummyFormatterPlugin(FormatterPlugin):
        def __init__(self, group_name: str, plugins: List[Type]):
            self.group_name = group_name
            self.plugins = plugins


# Generated at 2022-06-23 19:55:52.932973
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_converters()) >= 3


# Generated at 2022-06-23 19:55:54.357989
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager([1, 2])
    assert plugin_manager.__repr__() == '<PluginManager: [1, 2]>'

# Generated at 2022-06-23 19:55:55.233753
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}

# Generated at 2022-06-23 19:55:58.845574
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    p2 = PluginManager()
    p2.register(True)
    assert repr(p) == '<PluginManager: []>'
    assert repr(p2) == '<PluginManager: [True]>'



# Generated at 2022-06-23 19:56:00.596694
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert isinstance(PluginManager(), PluginManager)
    assert isinstance(PluginManager(), list)



# Generated at 2022-06-23 19:56:04.213938
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    PLUGINS = [1, 2, 3]
    pluginManager = PluginManager()
    pluginManager.register(*PLUGINS)
    assert repr(pluginManager) == '<PluginManager: [' + ', '.join(str(x) for x in PLUGINS) + ']>'

# Generated at 2022-06-23 19:56:08.505575
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(os.path)
    pm.register(os.path.normpath)
    
    result = pm.get_auth_plugins()
    expected_result = []

    assert result == expected_result, f'it should return {expected_result}'


# Generated at 2022-06-23 19:56:16.614638
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    validators.validate_instance(plugin_manager, PluginManager)

    plugin_manager.load_installed_plugins()
    validators.validate_instance(plugin_manager, PluginManager)

    formatters = plugin_manager.get_formatters()
    validators.validate_instance(formatters, list)

    grouped = plugin_manager.get_formatters_grouped()
    assert isinstance(grouped, dict)
    for k, v in grouped.items():
        assert isinstance(k, str)
        assert isinstance(v, list)
        for plugin_name in v:
            assert isinstance(plugin_name, str)


# Generated at 2022-06-23 19:56:27.440986
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    
    plug_manager = PluginManager()
    
    class Fmter1(FormatterPlugin):
        pass

    class Fmter2(FormatterPlugin):
        pass

    class Fmter3(FormatterPlugin):
        pass

    plug_manager.register(Fmter1, Fmter2, Fmter3)

    # Make sure that all formatters are registered
    assert(len(plug_manager.get_formatters()) == 3) 

    # Grouped version as expected
    assert(len(plug_manager.get_formatters_grouped()) == 1)

    # Grouped version constructed as expected
    assert(len(plug_manager.get_formatters_grouped()['all']) == 3)

    # Grouped version constructed as expected

# Generated at 2022-06-23 19:56:34.436826
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # arrange
    from httpie.plugins.formatter.colors import NoStyle, ColorsFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(NoStyle, ColorsFormatterPlugin)

    # act
    formatter_plugins = plugin_manager.filter(FormatterPlugin)

    # assert
    assert len(formatter_plugins) == 2


# Generated at 2022-06-23 19:56:38.453425
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager.get_auth_plugin_mapping())

if __name__ == "__main__":
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-23 19:56:43.851546
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    a = [1,2,3,4,5]
    for i in a:
        if i%2==0:
            a.remove(i)
    print(a)
    # for i in a:
    #     if i%2==0:
    #         a.remove(i)
    # print(a)
if __name__ == '__main__':
    a = [1,2,3,4,5]
    for i in a:
        if i%2==0:
            a.remove(i)
    print(a)
    b = [1,2,3,4,5]
    for i in range(len(b)):
        if b[i]%2==0:
            b.pop(i)
    print(b)

# Generated at 2022-06-23 19:56:53.671278
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(
        AbstractFormatterPlugin,
        PrettyPlugin,
        ColorsPlugin,
        JSONStreamPlugin,
        URLEncodedStreamPlugin,
        TablePlugin,
        RawPlugin,
        HeadersPlugin,
        HTMLFormatPlugin
    )
    test_output = plugin_manager.get_formatters_grouped()
    assert test_output == {'base': [AbstractFormatterPlugin], 'pretty': [PrettyPlugin], 'colors': [ColorsPlugin], 'formatters': [JSONStreamPlugin, URLEncodedStreamPlugin], 'print': [TablePlugin], 'raw': [RawPlugin], 'headers': [HeadersPlugin], 'html': [HTMLFormatPlugin]}

# Generated at 2022-06-23 19:56:54.725514
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager.filter()


# Generated at 2022-06-23 19:56:56.775204
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm: PluginManager = PluginManager()
    pm.register(TestPlugin)

    assert pm == [TestPlugin]


# Generated at 2022-06-23 19:56:58.710849
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager(['i', 'j'])
    assert plugins.__repr__() == '<PluginManager: ij>'



# Generated at 2022-06-23 19:57:00.362815
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginList = [Type[BasePlugin]]
    manager = PluginManager()
    manager.register(pluginList)
    manager.unregister(pluginList)
    assert pluginList not in manager

# Generated at 2022-06-23 19:57:04.725417
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin = plugin_manager.get_auth_plugin(auth_type = 'type')
    assert isinstance(plugin, AuthPlugin)

# Generated at 2022-06-23 19:57:06.757127
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager, PluginManager)
    assert plugin_manager.filter() == []
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]


# Generated at 2022-06-23 19:57:09.322745
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import AuthPlugin, ConverterPlugin
    class FakePlugin(AuthPlugin, ConverterPlugin):
        auth_type = 'fake'
    manager = PluginManager()
    manager.register(FakePlugin)
    auth = manager.get_auth_plugin('fake')
    assert auth == FakePlugin

# Generated at 2022-06-23 19:57:12.736573
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    expected = '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>]>'
    assert repr(plugin_manager) == expected


# Generated at 2022-06-23 19:57:15.226934
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
	pm = PluginManager()
	pm.register(PluginManager)
	assert PluginManager in pm
	assert pm.unregister(PluginManager)
	assert PluginManager not in pm
	

# Generated at 2022-06-23 19:57:19.897529
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    formatters = [
        {
            'name': 'json',
            'group_name': 'group1'
        },
        {
            'name': 'csv',
            'group_name': 'group1'
        },
        {
            'name': 'xml',
            'group_name': 'group2'
        },
        {
            'name': 'yaml',
            'group_name': 'group2'
        }
    ]

    class FormatterPlugin:
        def __init__(self, name, group_name):
            self.name = name
            self.group_name = group_name

    formatterPluginList = map(lambda f: FormatterPlugin(f['name'], f['group_name']), formatters)

    plugin_manager = PluginManager()

# Generated at 2022-06-23 19:57:21.177614
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    print(pluginmanager.get_auth_plugin('basic'))

# Generated at 2022-06-23 19:57:25.018886
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPiePlugin

    class MockPlugin(BasePlugin):
        pass

    class MockPlugin1(HTTPiePlugin):
        pass

    manager = PluginManager()
    manager.register(MockPlugin, MockPlugin1)

    list_of_plugins = manager.filter(HTTPiePlugin)
    assert list_of_plugins == [MockPlugin1]


# Generated at 2022-06-23 19:57:34.158417
# Unit test for constructor of class PluginManager
def test_PluginManager():

    plugins = PluginManager()
    assert plugins.register() == [], '不能register()'

    class AuthPlugin1:
        pass
    class AuthPlugin2:
        pass
    class FormatterPlugin1:
        pass

    PluginManager.register = plugins.register
    assert plugins.register(AuthPlugin1, AuthPlugin2, FormatterPlugin1) == [AuthPlugin1, AuthPlugin2, FormatterPlugin1], 'Pluginsの長さが間違ってる'

    assert plugins.unregister(AuthPlugin1) == [AuthPlugin2, FormatterPlugin1], 'AuthPlugin1をunregister()してない'
    assert plugins.unregister(AuthPlugin2) == [FormatterPlugin1], 'AuthPlugin2をunregister()してない'


# Generated at 2022-06-23 19:57:39.122760
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert len(manager.filter(AuthPlugin)) == 1
    assert len(manager.filter(ConverterPlugin)) == 1
    assert len(manager.filter(FormatterPlugin)) == 1
    assert len(manager.filter(TransportPlugin)) == 1


# Generated at 2022-06-23 19:57:41.974773
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    _plugins = PluginManager()
    _plugins.register(1, 2)
    _plugins.unregister(2)
    assert [1] == _plugins


manager = PluginManager()

# Generated at 2022-06-23 19:57:45.412931
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    class Foo:
        class Bar:
            pass
    manager.register(Foo, Foo.Bar)
    assert len(manager) == 2
    assert manager[0] == Foo
    assert manager[1] == Foo.Bar


# Generated at 2022-06-23 19:57:47.004569
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_converters()) == 0


# Generated at 2022-06-23 19:57:52.618249
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    m = PluginManager()  # New instance of class PluginManager
    m.load_installed_plugins() # load all installed plugins
    _ = m.get_auth_plugin('basic')
    print('PASSED: test_PluginManager_get_auth_plugin')


# Generated at 2022-06-23 19:57:59.210079
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    class Plugin1(AuthPlugin):
        auth_type = 'auth1'
    class Plugin2(AuthPlugin):
        auth_type = 'auth2'
    class Plugin3(AuthPlugin):
        auth_type = 'auth3'
    assert PluginManager().get_auth_plugin('auth1') == Plugin1
    assert PluginManager().get_auth_plugin('auth2') == Plugin2
    assert PluginManager().get_auth_plugin('auth3') == Plugin3


# Generated at 2022-06-23 19:58:00.947873
# Unit test for constructor of class PluginManager
def test_PluginManager():
    test_plugin_manager = PluginManager()
    assert type(test_plugin_manager) is PluginManager


# Generated at 2022-06-23 19:58:03.142792
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(HTTPiePlugin)
    manager.append(HTTPiePlugin)
    assert len(manager) == 2


# Generated at 2022-06-23 19:58:06.740172
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert {} == plugin_manager.get_auth_plugin_mapping()
    plugin_manager.load_installed_plugins()
    assert {} != plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-23 19:58:07.361116
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager.get_formatters()


# Generated at 2022-06-23 19:58:13.108518
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, HTTPTokenAuthPlugin


    plugins = [HTTPBasicAuthPlugin, HTTPTokenAuthPlugin]
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)
    assert len(plugin_manager.get_auth_plugins()) == 2
    assert plugin_manager.get_auth_plugins() == plugins

# Generated at 2022-06-23 19:58:14.575505
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from . import get_transport_plugins
    assert get_transport_plugins is PluginManager.get_transport_plugins

# Generated at 2022-06-23 19:58:23.927911
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    assert (pm.get_auth_plugins() == [])
    assert (pm.get_formatters() == [])
    assert (pm.get_converters() == [])
    assert (pm.get_transport_plugins() == [])
    pm.load_installed_plugins()
    assert (pm.get_auth_plugins() != [])
    assert (pm.get_formatters() != [])
    assert (pm.get_converters() != [])
    assert (pm.get_transport_plugins() != [])

# Generated at 2022-06-23 19:58:29.906556
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    def assert_repr(actual, expected):
        assert str(actual) == expected
    pm = PluginManager()
    pm.register('AuthPlugin', 'FormatterPlugin', 'ConverterPlugin')
    assert_repr(pm, "<PluginManager: ['AuthPlugin', 'FormatterPlugin', 'ConverterPlugin']>")
    pm.register('JSONFormatterPlugin')
    assert_repr(pm, "<PluginManager: ['AuthPlugin', 'FormatterPlugin', 'ConverterPlugin', 'JSONFormatterPlugin']>")

# Generated at 2022-06-23 19:58:37.454042
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.output.streams import get_available_streams
    from httpie.plugins.formatter.formatters import (
                        JSONFormatter,
                        JSONLinesFormatter,
                        PrettyJSONFormatter,
                        PrettyJSONLinesFormatter,
                        PythonFormatter,
                        RawJSONFormatter,
                        DefaultFormatter,
                        )

    pm = PluginManager()
    pm.load_installed_plugins()
    formatters = pm.get_formatters_grouped()
    assert set(formatters.keys()) == {'builtin', 'pre-installed'}

    # Verify if all the formatters are available                                                                                              

# Generated at 2022-06-23 19:58:41.619166
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    a=PluginManager()
    a.append('httpie.plugins.auth.v1')
    a.append('httpie.plugins.formatter.v1')
    a.append('httpie.plugins.converter.v1')
    a.append('httpie.plugins.transport.v1')
    assert a == ['httpie.plugins.auth.v1', 'httpie.plugins.formatter.v1',
                 'httpie.plugins.converter.v1', 'httpie.plugins.transport.v1']



# Generated at 2022-06-23 19:58:44.078159
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_formatters()) != 0
    assert pm.get_formatters() != []
    assert pm.get_formatters() != None
    assert pm.get_formatters_grouped() != None


# Generated at 2022-06-23 19:58:46.795391
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    pluginManager.register(HttpiePlugin)
    print(pluginManager.get_formatters_grouped())



# Generated at 2022-06-23 19:58:49.081746
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_list = PluginManager()
    assert(plugin_list != None)



# Generated at 2022-06-23 19:58:52.884522
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins_list_before = len(PluginManager().load_installed_plugins())
    plugins_list_after = len(PluginManager().load_installed_plugins())
    assert (plugins_list_before == plugins_list_after)

# Generated at 2022-06-23 19:58:56.202999
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    my_plugin_manager = PluginManager()
    print(my_plugin_manager.get_auth_plugin_mapping())

if __name__ == "__main__":
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-23 19:58:57.644554
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugins() == []


# Generated at 2022-06-23 19:59:00.706643
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    p = PluginManager()
    p.load_installed_plugins()
    print(p.get_converters())
    assert(len(p.get_converters()) >= 1)


# Generated at 2022-06-23 19:59:01.747335
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins == [], 'Init list should be empty.'


# Generated at 2022-06-23 19:59:07.315877
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    base = BasePlugin
    auth = AuthPlugin
    converter = ConverterPlugin
    formatter = FormatterPlugin
    transport = TransportPlugin
    
    PM = PluginManager()
    PM.register(base, auth, converter, formatter, transport)

    assert [base, auth] == PM.filter(AuthPlugin)
    assert [base, converter] == PM.filter(ConverterPlugin)
    assert [base, formatter] == PM.filter(FormatterPlugin)
    assert [base, transport] == PM.filter(TransportPlugin)


# Generated at 2022-06-23 19:59:14.876812
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth import AuthPlugin
    import httpie.plugins.auth.basic
    import httpie.plugins.auth.digest
    import httpie.plugins.auth.hawk
    l = PluginManager()
    l.register(AuthPlugin)
    assert  httpie.plugins.auth.basic.BasicAuth in l
    assert httpie.plugins.auth.digest.DigestAuth in l
    assert httpie.plugins.auth.hawk.HawkAuth in l
    m = l.get_auth_plugin_mapping()
    assert  httpie.plugins.auth.basic.BasicAuth in m.values()
    assert httpie.plugins.auth.digest.DigestAuth in m.values()
    assert httpie.plugins.auth.hawk.HawkAuth in m.values()


# Generated at 2022-06-23 19:59:17.147504
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    plugins = pm.get_auth_plugins()
    
    assert plugins == []


# Generated at 2022-06-23 19:59:18.997209
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager.get_transport_plugins(PluginManager) == [Type[TransportPlugin]]


# Generated at 2022-06-23 19:59:21.532750
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    l = PluginManager()
    class D:
        pass
    l.unregister(D)
    assert(l == [])

# Generated at 2022-06-23 19:59:25.974830
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert(PluginManager().get_transport_plugins() == [])
    assert(PluginManager([1,2,3]).get_transport_plugins() == [])
    assert(PluginManager([AuthPlugin, TransportPlugin, ConverterPlugin]).get_transport_plugins() == [TransportPlugin])

# Generated at 2022-06-23 19:59:27.644850
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins.get_converters()) <= 2, "Number of plugins should be 2 or less"

# Generated at 2022-06-23 19:59:31.736717
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(class_A, class_B)
    assert plugins.get_auth_plugin_mapping() == {'A': class_A, 'B': class_B}


# Generated at 2022-06-23 19:59:33.034593
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    print(plugin_manager.get_formatters())

# Generated at 2022-06-23 19:59:37.178305
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    output_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_json.json')
    output = open(output_file)
    plugin = PluginManager()
    plugin.load_installed_plugins()
    arg_formatters = plugin.get_formatters()
    for current_formatter in arg_formatters:
        if current_formatter.name == 'json' and current_formatter.group_name == 'group_name':
            assert True
            break
        else:
            assert False


# Generated at 2022-06-23 19:59:44.073132
# Unit test for method unregister of class PluginManager

# Generated at 2022-06-23 19:59:46.124016
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert str(PluginManager()) == '<PluginManager: []>'
    assert str(PluginManager().register()) == '<PluginManager: []>'

# Generated at 2022-06-23 19:59:50.497016
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager().get_transport_plugins() == []
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_transport_plugins()) > 0


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:59:52.248029
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # Test object
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    # Test
    converters = pluginManager.get_converters()
    assert len(converters) >= 1

# Generated at 2022-06-23 20:00:03.186781
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    expected = [
        {'name': 'github_token', 'doc': 'OAuth2 token for GitHub API'},
        {'name': 'jira_session', 'doc': 'Authentication for Jira API'},
        {'name': 'kerberos', 'doc': 'Kerberos auth for the requests library'},
        {'name': 'basic', 'doc': 'Basic HTTP auth'},
        {'name': 'digest', 'doc': 'Digest HTTP auth'},
        {'name': 'hmac', 'doc': 'HMAC auth'},
        {'name': 'bearer', 'doc': 'Bearer token auth'},
    ]
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins = plugin_manager.get_auth_plugins()

# Generated at 2022-06-23 20:00:06.903421
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(HTTPiePlugin_test)
    pm.load_installed_plugins()
    l = [HTTPiePlugin_test, HTTPiePlugin_test2]
    assert pm.get_transport_plugins() == l


# Generated at 2022-06-23 20:00:08.576403
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    try:
        manager = PluginManager()
        manager.get_auth_plugin("basic")
    except:
        assert False



# Generated at 2022-06-23 20:00:15.223065
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.cli.help import HelpFormatter, HTTPieHelpFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import ConverterPlugin

    pm = PluginManager()
    pm.register(HelpFormatter, HTTPieHelpFormatter)
    assert pm.get_formatters_grouped() == {
        'Help formats': [
            HTTPieHelpFormatter,
            HelpFormatter,
        ]
    }

    class JSONFormatter1(FormatterPlugin, ConverterPlugin):
        output_type = 'json'
        group_name = 'JSON'

    class JSONFormatter2(FormatterPlugin, ConverterPlugin):
        output_type = 'json'
        group_name = 'JSON'

    pm = PluginManager()

# Generated at 2022-06-23 20:00:17.714615
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginManager = PluginManager()
    assert pluginManager.get_auth_plugin_mapping() == {}


# Generated at 2022-06-23 20:00:20.422931
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0
    assert isinstance(manager, PluginManager)



# Generated at 2022-06-23 20:00:23.131106
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_auth_plugins()) >= 1


# Generated at 2022-06-23 20:00:31.735852
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class DummyFormatter(FormatterPlugin):
        name = 'DummyFormatter'

    class DummyFormatter2(FormatterPlugin):
        name = 'DummyFormatter2'

    def compare(plugins):
        return set(plugin.name for plugin in plugins) == {'DummyFormatter', 'DummyFormatter2'}

    plugin_manager = PluginManager()
    plugin_manager.register(DummyFormatter, DummyFormatter2)
    assert compare(plugin_manager.get_formatters())

    plugin_manager = PluginManager()
    plugin_manager.register(DummyFormatter2)
    plugin_manager.register(DummyFormatter)
    assert compare(plugin_manager.get_formatters())

test_PluginManager_get_formatters()

# Generated at 2022-06-23 20:00:33.947072
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin(BasePlugin):
        pass
    plugins = PluginManager()
    plugins.register(Plugin)
    assert len(plugins) == 1
    plugins.unregister(Plugin)
    assert len(plugins) == 0

# Generated at 2022-06-23 20:00:39.709732
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert(plugins.get_auth_plugins() == [])
    assert(plugins.get_formatters() == [])
    assert(plugins.get_converters() == [])
    assert(plugins.get_transport_plugins() == [])


manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-23 20:00:43.708693
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin, DigestAuthPlugin)
    assert plugin_manager.get_auth_plugin('basic') == BasicAuthPlugin
    assert plugin_manager.get_auth_plugin('digest') == DigestAuthPlugin

# Generated at 2022-06-23 20:00:53.724066
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(TransportPlugin)

    plugins.register(AuthPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(TransportPlugin)