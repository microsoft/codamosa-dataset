

# Generated at 2022-06-23 19:50:49.627755
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin = PluginManager()
    plugin.register(AuthHttpBasic, AuthDigest)
    assert plugin.get_auth_plugin_mapping() == {
        'basic': AuthHttpBasic,
        'digest': AuthDigest
    }

# Generated at 2022-06-23 19:50:52.416850
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_list = PluginManager()
    class TestPlugin(TransportPlugin):
        name = 'test_plugin'
        priority = 0
    plugin = TestPlugin()
    plugin_list.register(TestPlugin)
    assert(plugin in plugin_list)
    plugin_list.unregister(TestPlugin)
    assert(plugin not in plugin_list)

# Generated at 2022-06-23 19:50:59.352853
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugins()) > 0
    assert len(pm.get_formatters()) > 0
    assert len(pm.get_formatters_grouped()) > 0
    assert len(pm.get_converters()) > 0
    assert len(pm.get_transport_plugins()) > 0

# Generated at 2022-06-23 19:51:05.292354
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins.builtin import HTTPBasicAuth, JSONFormatter
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.register(JSONFormatter)
    if len(plugin_manager) != 2:
        return False
    plugin_manager.unregister(JSONFormatter)
    if len(plugin_manager) != 1:
        return False
    return True


# Generated at 2022-06-23 19:51:11.258196
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager() # manager is list
    assert plugin_manager.__repr__() == '<PluginManager: []>'


if __name__ == "__main__":
    test_PluginManager()


# # Request Adapters
#     def get_transport_plugins(self):
#         return self.filter(TransportPlugin)
#
#     def get_transport_adapters(self):
#         return [plugin().get_adapter() for plugin in self.get_transport_plugins()]

# Generated at 2022-06-23 19:51:13.897069
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = create_plugin_manager()
    assert not pm.get_formatters()


# Generated at 2022-06-23 19:51:18.169952
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    class Plugin1(FormatterPlugin):

        group_name = '1'

    class Plugin2(FormatterPlugin):

        group_name = '2'

    manager = PluginManager()
    manager.register(Plugin1, Plugin2)
    assert len(manager.get_formatters()) == 2


# Generated at 2022-06-23 19:51:21.835861
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    assert isinstance(plugins.get_auth_plugins(), list)
    assert issubclass(plugins.get_auth_plugins().__class__, list)


# Generated at 2022-06-23 19:51:26.045294
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    p = PluginManager()
    p.load_installed_plugins()
    c = p.get_converters()
    assert len(c) == 2
    assert c[0].content_type == 'application/x-www-form-urlencoded'
    assert c[1].content_type == 'multipart/form-data'



# Generated at 2022-06-23 19:51:32.978433
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugin_manager.register(entry_point.load())
    print(plugin_manager.get_transport_plugins())
    assert plugin_manager.get_transport_plugins() != []


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:51:38.563834
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin_mapping() == {}
    
    plugin_class = TypeVar('Type[AuthPlugin]', bound=AuthPlugin)
    class MockAuthPlugin(AuthPlugin):
        auth_type = 'mock_auth'
        def get_auth(self, username, password):
            pass
    plugin_manager.register(MockAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'mock_auth': MockAuthPlugin}
    
    plugin_manager.unregister(MockAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {}



# Generated at 2022-06-23 19:51:41.506771
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin, FormatterPlugin)
    assert plugin_manager.get_formatters_grouped() == {'formatter': [FormatterPlugin, FormatterPlugin]}

# Generated at 2022-06-23 19:51:45.585359
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert isinstance(pm.get_auth_plugin_mapping(), dict)
    assert isinstance(pm.get_auth_plugin_mapping()['basic'], type)

# Generated at 2022-06-23 19:51:50.445599
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugin('duo') == DuoAuthPlugin


# Generated at 2022-06-23 19:51:54.330724
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    """
    测试 一次注册一个插件
    """
    class Plugin:
        pass

    plugin_manager = PluginManager()

    plugin_manager.register(Plugin)

    assert plugin_manager == [Plugin]



# Generated at 2022-06-23 19:51:56.237419
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    # pm.register(name)
    assert len(pm) == 0
    pm.unregister(name)



# Generated at 2022-06-23 19:51:58.668142
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert PluginManager().get_formatters() == list()



# Generated at 2022-06-23 19:52:02.006563
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    assert(pm.get_auth_plugin("basic") == None)
    pm.load_installed_plugins()
    assert(pm.get_auth_plugin("basic") != None)


# Generated at 2022-06-23 19:52:03.683149
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pass



# Generated at 2022-06-23 19:52:05.744714
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert isinstance(PluginManager().get_formatters(), list)

# Generated at 2022-06-23 19:52:08.002009
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Tests for method get_auth_plugins of class PluginManager

# Generated at 2022-06-23 19:52:10.628817
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin("basic") == BasicAuthPlugin

# Generated at 2022-06-23 19:52:13.441482
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager([])
    plugins = [1,2,3]
    pm.register(*plugins)
    assert pm == [1,2,3]


# Generated at 2022-06-23 19:52:20.381457
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.auth.jwt import JWTAuthPlugin
    from httpie.plugins.formatter.prettyjson import PrettyJsonFormatterPlugin
    from httpie.plugins.converter import KeyValueConverterPlugin
    pm = PluginManager()
    print(pm)
    pm.load_installed_plugins()
    print(pm)
    assert JWTAuthPlugin in pm
    assert PrettyJsonFormatterPlugin in pm
    assert KeyValueConverterPlugin in pm


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:52:25.631395
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin = PluginManager()
    assert repr(plugin) == "<PluginManager: []>"


plugins = PluginManager()
plugins.load_installed_plugins()

# Give these managers a custom repr, it's very helpful in the debugger.
plugins.__repr__ = lambda self: f"<plugins: {list(self)}>"
transport.__repr__ = lambda self: f"<transport: {list(self)}>"

# Generated at 2022-06-23 19:52:27.331148
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) > 0


# Generated at 2022-06-23 19:52:33.568073
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.utils import MockEnvironment
    from httpie.config import Config
    from httpie.plugins.manager import PluginManager
    pm = PluginManager()
    pm.register(HTTPBasicAuth)
    assert pm.get_auth_plugin('basic') == HTTPBasicAuth
    assert pm.get_auth_plugin('invalid') == None
    pm.unregister(HTTPBasicAuth)
    assert pm.get_auth_plugin('basic') == None

# Generated at 2022-06-23 19:52:38.072299
# Unit test for method register of class PluginManager
def test_PluginManager_register():
	plugin_manager = PluginManager()
	plugin_type = type(BasePlugin())
	plugin_manager.register(plugin_type)
	print(plugin_manager)
	return plugin_manager


# Generated at 2022-06-23 19:52:43.072332
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import TransportPlugin
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import JSONConverter

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth,HTMLFormatter,JSONConverter)
    assert plugin_manager.get_auth_plugins() == [HTTPBasicAuth]
    assert plugin_manager.get_formatters() == [HTMLFormatter]
    assert plugin_manager.get_converters() == [JSONConverter]
    # Filter by Type

# Generated at 2022-06-23 19:52:48.424780
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert len(PluginManager().get_formatters()) == 0
    assert (len(PluginManager().get_formatters_grouped()) == 0)
    assert len(PluginManager().get_converters()) == 0

test_PluginManager_get_formatters()


# Generated at 2022-06-23 19:52:57.531763
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    ##################################
    # 函数功能：单元测试 PluginManager 类的 get_formatters_grouped 方法
    # 输入参数：无
    # 输出参数：无
    ##################################
    # 根据格式化类型为没有分组的 Python 格式化插件创建一个 PluginManager 示例对象
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(PythonFormatter)
    # 根据格式化类型

# Generated at 2022-06-23 19:53:00.183974
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPluginA, TransportPluginB)
    assert plugin_manager.get_transport_plugins() == [TransportPluginA, TransportPluginB]


# Generated at 2022-06-23 19:53:10.082588
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie import ExitStatus
    from httpie.compat import str
    from httpie.input import SEP_CREDENTIALS
    from httpie.plugins import BuiltinPlugin, plugin_manager
    from utils import http, HTTP_OK
    url = 'http://httpbin.org/html'
    try:
        r = http(url, '--auth-type=basic', '--auth=user:password',
                 'GET', env=env())
        assert HTTP_OK in r
        assert r.count('HTTP/1.1 200 OK') == 1
    except SystemExit as e:
        assert e.code == ExitStatus.OK

# Generated at 2022-06-23 19:53:13.095423
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager1 = PluginManager()
    from httpie.plugins.builtin import HTTPBasicAuth
    PluginManager1.register(HTTPBasicAuth)
    assert(HTTPBasicAuth in PluginManager1)



# Generated at 2022-06-23 19:53:17.485464
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    p1 = type('p1', (),{'__module__': 'a', 'type': 'http'})
    p2 = type('p2', (),{'__module__': 'a', 'type': 'socks'})
    plugin_manager.register(p1, p2)
    
    print(plugin_manager.get_transport_plugins())

test_PluginManager_get_transport_plugins()
    
    




# Generated at 2022-06-23 19:53:19.070591
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins == []


# Generated at 2022-06-23 19:53:21.899829
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_converters()) == 2



# Generated at 2022-06-23 19:53:24.377110
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class TestPlugin(BasePlugin):
        pass

    pm = PluginManager()
    pm.register(TestPlugin)
    assert TestPlugin in pm

    pm.unregister(TestPlugin)
    assert TestPlugin not in pm

# Generated at 2022-06-23 19:53:29.004195
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.register(SSLAdapter)
    assert manager.get_transport_plugins() == [SSLAdapter]
    # Test if there is no entry
    manager2 = PluginManager()
    assert manager2.get_transport_plugins() == []

# Generated at 2022-06-23 19:53:38.002892
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import (
        HTTPBasicAuth,
        HTTPTokenAuth,
        HTTPProxyAuth,
        HTTPCookieAuth,
        HTTPSignatureAuth
    )

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPTokenAuth, HTTPProxyAuth, HTTPCookieAuth, HTTPSignatureAuth)

    if plugin_manager.get_transport_plugins()[0] != HTTPBasicAuth or plugin_manager.get_transport_plugins()[1] != HTTPTokenAuth or plugin_manager.get_transport_plugins()[2] != HTTPProxyAuth or plugin_manager.get_transport_plugins()[3] != HTTPCookieAuth or plugin_manager.get_transport_plugins()[4] != HTTPSignatureAuth:
        raise AssertionError()

# Generated at 2022-06-23 19:53:40.584869
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    assert p.filter() == list
    assert p.filter(by_type=Type) == Type


# Generated at 2022-06-23 19:53:43.850631
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm1 = PluginManager()
    pm1.register()
    assert pm1 == []
    pm2 = PluginManager()
    pm2.register(AuthPlugin)
    assert pm2 == [AuthPlugin]


# Generated at 2022-06-23 19:53:45.567116
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager_ = PluginManager()
    assert isinstance(PluginManager_, PluginManager)


# Generated at 2022-06-23 19:53:53.175988
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, HTTPBearerAuthPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, JSONLinesFormatterPlugin
    from httpie.plugins.builtin import HTTPieJSONEncoderPlugin
    pl = PluginManager()
    pl.register(HTTPBasicAuthPlugin,
                HTTPBearerAuthPlugin,
                JSONFormatterPlugin,
                JSONLinesFormatterPlugin,
                HTTPieJSONEncoderPlugin)
    cv = pl.get_converters()
    print(cv)
    assert cv == [HTTPieJSONEncoderPlugin]

test_PluginManager_get_converters()

# Generated at 2022-06-23 19:53:53.929792
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    PluginManager().load_installed_plugins()
    assert len(PluginManager().get_transport_plugins()) == 4

# Generated at 2022-06-23 19:53:55.012536
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    print(plugins)



# Generated at 2022-06-23 19:53:55.863617
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pass

# Generated at 2022-06-23 19:54:07.164373
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    all_auth_plugins = ['BasicAuthPlugin', 'DigestAuthPlugin', 'HawkAuthPlugin', 'OAuth1AuthPlugin', 'OAuth2Plugin']
    pass_auth_plugins = ['BasicAuthPlugin', 'DigestAuthPlugin', 'HawkAuthPlugin', 'OAuth1AuthPlugin', 'OAuth2Plugin']
    all_plugin_dic = {'basic': 'BasicAuthPlugin', 'digest': 'DigestAuthPlugin', 'hawk': 'HawkAuthPlugin', 'oauth1': 'OAuth1AuthPlugin', 'oauth2': 'OAuth2Plugin'}
    # plugin_manager = PluginManager()
    # auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    # print(auth_plugin_mapping)
    # all_auth_plugins_in_map = auth_plugin_m

# Generated at 2022-06-23 19:54:08.126050
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin('basic') == BasicAuthPlugin



# Generated at 2022-06-23 19:54:13.321639
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    class TestPlugin(AuthPlugin):
        auth_type = 'test'
        auth_parse = lambda x: x
    manager = PluginManager()
    manager.register(TestPlugin)
    assert manager.get_auth_plugin('test') == TestPlugin
    assert manager.get_auth_plugin_mapping() == {'test': TestPlugin}


# Generated at 2022-06-23 19:54:17.575902
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_mangager = PluginManager()
    plugin_mangager.register(BasePlugin)
    assert BasePlugin in plugin_mangager
    plugin_mangager.unregister(BasePlugin)
    assert BasePlugin not in plugin_mangager


# Generated at 2022-06-23 19:54:21.967019
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    """
    Test the method get_converters of class PluginManager
    :return: Nothing to return
    """
    pm = PluginManager()
    plugins = pm.get_converters()
    assert plugins, 'Method get_converters of class PluginManager should return a list'


# Generated at 2022-06-23 19:54:25.482490
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager(["abc", "cde", "xyz"])
    assert plugin_manager.__repr__() == '<PluginManager: [\'abc\', \'cde\', \'xyz\']>'


# Generated at 2022-06-23 19:54:27.170187
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    pm.register(DummyPlugin)
    assert len(pm) == 1



# Generated at 2022-06-23 19:54:27.752384
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert 0


# Generated at 2022-06-23 19:54:32.360363
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Test instance of class PluginManager
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager, PluginManager)

    # Test method load_installed_plugins of class PluginManager
    plugin_manager.load_installed_plugins()
    print("PluginManager.load_installed_plugins() succeessfully.")


# Generated at 2022-06-23 19:54:36.111077
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    pm.register(TransportPlugin)
    pm.register(FormatterPlugin)
    assert issubclass(TransportPlugin, BasePlugin)
    assert issubclass(FormatterPlugin, BasePlugin)
    assert TransportPlugin in pm
    assert FormatterPlugin in pm
    assert len(pm) == 2


# Generated at 2022-06-23 19:54:38.698973
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class AuthPlugin1:
        pass
    class AuthPlugin2:
        pass
    pm.register(AuthPlugin1, AuthPlugin2)
    assert AuthPlugin1 in pm
    assert AuthPlugin2 in pm


# Generated at 2022-06-23 19:54:39.256129
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()

# Generated at 2022-06-23 19:54:43.034828
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2)
    print(plugin_manager.get_converters())



# Generated at 2022-06-23 19:54:47.105999
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'
    plugins.register('abc','def','hij')
    assert repr(plugins) == "<PluginManager: ['abc', 'def', 'hij']>"

# Generated at 2022-06-23 19:54:49.499683
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_manager = PluginManager()

    auth_types = []
    auth_types.append(test_manager.get_auth_plugin_mapping())
    print(auth_types)


    # assert len(auth_types) != 0, "No auth method detected!"
    # return auth_types

if __name__ == "__main__":
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-23 19:54:56.721091
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    p1 = AuthPlugins()
    p2 = FormatterPlugins()
    p3 = AuthPlugins()
    pl = PluginManager()
    pl.load_installed_plugins()
    pl.register(p1)
    pl.register(p2)
    pl.register(p3)
    assert pl.remove(p1) is None
    assert pl.remove(p2) is None
    assert pl.remove(p3) is None


# Generated at 2022-06-23 19:55:02.970549
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import get_transport_plugins
    from httpie.plugins import get_auth_plugin
    assert not get_transport_plugins()
    assert not get_auth_plugin('bearer')
    import httpie.plugins.omero
    from httpie.plugins import load_installed_plugins
    load_installed_plugins()
    assert get_transport_plugins()
    assert get_auth_plugin('bearer')

# Generated at 2022-06-23 19:55:10.084973
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.converters import BaseConverter
    from httpie.converters import JSONConverter
    from httpie.converters import URLEncodedConverter
    from httpie.converters import MultipartFormDataConverter
    from httpie.plugins import ConverterPlugin

    pluginmgr = PluginManager()
    class testJSONConverter(JSONConverter):
        pass
    class testURLEncodedConverter(URLEncodedConverter):
        pass
    class testMultipartFormDataConverter(MultipartFormDataConverter):
        pass
    class testConverterPlugin(BaseConverter, ConverterPlugin):
        pass
    class testConverterPlugin2(BaseConverter, ConverterPlugin):
        pass


# Generated at 2022-06-23 19:55:11.267692
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pass



# Generated at 2022-06-23 19:55:13.379852
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register()
    manager.unregister()


# Generated at 2022-06-23 19:55:17.232638
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plg_mgr = PluginManager()
    assert repr(plg_mgr) == '<PluginManager: []>'

    plg_mgr.register(0, 1)
    assert repr(plg_mgr) == '<PluginManager: [0, 1]>'


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:55:20.316706
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert str(plugin_manager) == '<PluginManager: []>'

# Generated at 2022-06-23 19:55:22.977164
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(ConverterPlugin)

    assert len(pm.get_converters()) == 1

# Generated at 2022-06-23 19:55:27.813146
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert(len(p.get_auth_plugins()) == 1)
    assert(len(p.get_formatters()) == 1)
    assert(len(p.get_converters()) == 1)
    assert(len(p.get_transport_plugins()) == 1)

# Generated at 2022-06-23 19:55:30.703734
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    p.register(TestPlugin)
    assert repr(p) == f'<PluginManager: [<{TestPlugin}>]>'


plugins = PluginManager()

# Generated at 2022-06-23 19:55:32.637356
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager().get_transport_plugins() == []
    # Insert method get_transport_plugins() here
    assert True


# Generated at 2022-06-23 19:55:36.130684
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(TransportPlugin)
    print(plugins.get_auth_plugin_mapping())
    print(plugins.get_auth_plugins())
    print(plugins.get_auth_plugin('basic'))
    print(plugins.get_converters())
    print(plugins.get_formatters())
    print(plugins.get_formatters_grouped())
    print(plugins.get_transport_plugins())

test_PluginManager()

# Generated at 2022-06-23 19:55:46.079336
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()

    class BasePlugin1: pass
    class BasePlugin2(BasePlugin): pass
    class BasePlugin3(BasePlugin): pass
    plugin_manager.register(BasePlugin1, BasePlugin2, BasePlugin3)

    assert plugin_manager.filter(by_type=BasePlugin) == [BasePlugin2, BasePlugin3]
    assert plugin_manager.filter(by_type=Type[BasePlugin]) == [BasePlugin2, BasePlugin3]
    assert plugin_manager.filter(by_type=BasePlugin1) == []
    assert plugin_manager.filter(by_type=BasePlugin2) == []
    assert plugin_manager.filter(by_type=BasePlugin3) == []

# Generated at 2022-06-23 19:55:52.851155
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class F1(FormatterPlugin):
        group_name = "g1"
    class F2(FormatterPlugin):
        group_name = "g2"
    class F3(FormatterPlugin):
        group_name = "g3"
    class F4(FormatterPlugin):
        group_name = "g3"
    class F5(FormatterPlugin):
        group_name = "g3"
    class F6(FormatterPlugin):
        group_name = "g2"

    pm = PluginManager()
    pm.register(F1, F2, F3, F4, F5, F6)
    print("pm:")
    print(pm)
    print("F1:")
    print(F1)
    print("pm.get_formatters_grouped():")

# Generated at 2022-06-23 19:55:54.196350
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    assert pm.__repr__() == '<PluginManager: []>'


manager = PluginManager()

# Generated at 2022-06-23 19:55:56.589996
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register(TransportPlugin)
    flag = False
    for plugin in plugins:
        if issubclass(plugin, TransportPlugin):
            flag = True
    assert flag


# Generated at 2022-06-23 19:55:59.335636
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.unregister(plugin=adapters.HTTPAdapter)
    assert len(plugin_manager.get_transport_plugins()) == 0

# Generated at 2022-06-23 19:56:05.299163
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins(): #TODO:
    import pkg_resources

# Generated at 2022-06-23 19:56:14.506096
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert plugin_manager.get_transport_plugins() == [
        httpie_cli_oauth2.OAuth2Plugin,
        httpie_cli_http2.HTTP2Plugin,
        httpie_cli_awssigv4.AWSSIGv4Plugin,
        httpie_cli_servererrors.ServerErrorsPlugin,
        httpie_cli_redirects.RedirectsPlugin,
        httpie_cli_sessions.SessionsPlugin,
        httpie_cli_pretty.PrettyPlugin,
        httpie_cli_json.JSONPlugin,
        httpie_cli_cookies.CookiesPlugin,
        httpie_cli_auth.AuthPlugin,
        httpie_cli_http.HTTPPlugin,
    ]


# Generated at 2022-06-23 19:56:16.514665
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {'basic': 'httpie.plugins.auth.basic'}


# Generated at 2022-06-23 19:56:26.195530
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie import plugins
    from httpie.compat import urlunparse
    from httpie.core import main
    from httpie.plugins import ConverterPlugin
    from pathlib import Path
    import json
    json_data='{"name": "John Doe", "age": 33}'
    main([Path('index.py').resolve(),'--output-format','json','--output','out.json','--body',json_data])
    assert Path('out.json').exists()
    with open('out.json','r') as file:
        data = json.load(file)
        assert "name" in data
        assert data["name"] == "John Doe"
        Path('out.json').unlink()

# Generated at 2022-06-23 19:56:29.243780
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins1 = PluginManager()
    plugins1.load_installed_plugins()
    plugins2 = PluginManager()
    plugins2.register(BasePlugin)
    assert plugins1.get_transport_plugins() == []
    assert plugins2.get_transport_plugins() == []


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:56:31.052777
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert plugin_manager.filter(AuthPlugin) == []


# Generated at 2022-06-23 19:56:34.379669
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugin_mapping()



# Generated at 2022-06-23 19:56:36.714525
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins=PluginManager()
    plugins.register()
    assert plugins.__repr__() == '<PluginManager: []>'


# Generated at 2022-06-23 19:56:40.785972
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class TestPlugin0(BasePlugin):
        pass

    class TestPlugin1(BasePlugin):
        pass

    class TestPlugin2(BasePlugin):
        pass

    class TestPlugin3(TransportPlugin):
        pass

    p = PluginManager()
    p.register(TestPlugin1, TestPlugin2, TestPlugin3)
    assert p.filter(TransportPlugin) == [TestPlugin3]

# Generated at 2022-06-23 19:56:42.683156
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager.get_converters() == FormatterPlugin

# Generated at 2022-06-23 19:56:47.668764
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(OAuth2Plugin)
    pm.register(OAuth1Plugin)
    pm.register(DigestAuthPlugin)
    assert pm.get_auth_plugins() == [OAuth2Plugin, OAuth1Plugin, DigestAuthPlugin]


# Generated at 2022-06-23 19:56:51.589722
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()

# Generated at 2022-06-23 19:56:54.214240
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    man = PluginManager()
    man.load_installed_plugins()
    assert type(man.get_auth_plugin("basic")) == type(man.get_auth_plugins()[0])

# Generated at 2022-06-23 19:56:55.601673
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    PluginManager.get_auth_plugin()



# Generated at 2022-06-23 19:56:57.358733
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    a = PluginManager()
    a.load_installed_plugins()
    assert len(a) == len(ENTRY_POINT_NAMES)

# Generated at 2022-06-23 19:56:59.878217
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.register(BasePlugin, BasePlugin, BasePlugin)
    assert len(plugin_manager) == 3


# Generated at 2022-06-23 19:57:04.247969
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin)
    pluginManager.register(FormatterPlugin)
    pluginManager.register(ConverterPlugin)
    pluginManager.register(TransportPlugin)
    pluginManager.load_installed_plugins()
    print(pluginManager.get_auth_plugins())
    print(pluginManager.get_formatters())
    print(pluginManager.get_transport_plugins())
    print(pluginManager.__repr__())

# Generated at 2022-06-23 19:57:06.045950
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    assert manager.get_formatters() == []



# Generated at 2022-06-23 19:57:07.808091
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager != []

# Generated at 2022-06-23 19:57:09.065587
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager())=='<PluginManager: []>'

# Generated at 2022-06-23 19:57:09.979762
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pass



# Generated at 2022-06-23 19:57:12.695132
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    manager.register(BasePlugin)
    assert manager.__repr__() == '<PluginManager: [<class httpie.plugins.base.BasePlugin>]>'

# Generated at 2022-06-23 19:57:14.878809
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.foo = 'bar'
    assert repr(plugin_manager) == "<PluginManager: [('foo', 'bar')]>"

# Generated at 2022-06-23 19:57:17.851182
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():

    import requests
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPHeaders
    
    plugins = PluginManager()
    plugins.register(HTTPBasicAuth, HTTPHeaders)
    print(plugins.__repr__())


if __name__ == '__main__':
    test_PluginManager___repr__()

# Generated at 2022-06-23 19:57:26.182420
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert isinstance(auth_plugin_mapping, dict)
    assert not auth_plugin_mapping
    plugins = [
        AuthPlugin('bar'),
        AuthPlugin('baz'),
        AuthPlugin('foo'),
    ]
    plugin_manager.register(*plugins)
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert isinstance(auth_plugin_mapping, dict)
    assert len(auth_plugin_mapping) == 3
    


# Generated at 2022-06-23 19:57:27.585876
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    pm.register(test_plugin)
    assert pm.get_auth_plugin('test') is test_plugin



# Generated at 2022-06-23 19:57:30.086606
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    tfm = PluginManager()
    g1 = tfm.get_formatters_grouped()
    assert len(g1) == 3



# Generated at 2022-06-23 19:57:31.859237
# Unit test for constructor of class PluginManager
def test_PluginManager():

    plugins = PluginManager()
    print('test_PluginManager_class_plugins: ' + str(plugins))


# Generated at 2022-06-23 19:57:41.338014
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    mime_type_map = {
        converter.from_: converter.to
        for converter in manager.get_converters()
    }
    assert 'application/json' in mime_type_map
    assert 'application/javascript' in mime_type_map
    assert 'text/javascript' in mime_type_map
    assert 'text/xml' in mime_type_map
    assert 'text/html' in mime_type_map
    assert 'text/plain' in mime_type_map
    assert 'text/css' in mime_type_map
    assert 'application/xml' in mime_type_map
    assert 'application/xhtml+xml' in mime_type_map
    assert 'application/rss+xml' in mime_type_map
   

# Generated at 2022-06-23 19:57:49.054396
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin

    class PluginFoo(FormatterPlugin):
        group_name = 'foo'
    class PluginBar(FormatterPlugin):
        group_name = 'foo'
    class PluginBaz(FormatterPlugin):
        group_name = 'baz'
    class PluginQux(FormatterPlugin):
        group_name = None

    manager = PluginManager()
    manager.register(PluginFoo, PluginBar, PluginBaz, PluginQux)

    assert manager.get_formatters_grouped() == {
        'foo': [PluginFoo, PluginBar],
        'baz': [PluginBaz],
        None: [PluginQux],
    }



# Generated at 2022-06-23 19:57:53.354392
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    m = PluginManager()
    m.register(DummyAuthPlugin, DummyAuthPlugin)
    m.register(DummyTransportPlugin, DummyTransportPlugin)
    assert m.get_auth_plugins() == [DummyAuthPlugin, DummyAuthPlugin]



# Generated at 2022-06-23 19:57:59.216664
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import FormatterPlugin

    class MyFormatter(FormatterPlugin):
        pass

    plugins = PluginManager()
    assert plugins.filter(FormatterPlugin) == []
    plugins.register(MyFormatter)
    assert plugins.filter(FormatterPlugin) == [MyFormatter]
    plugins.unregister(MyFormatter)
    assert plugins.filter(FormatterPlugin) == []


# Generated at 2022-06-23 19:58:02.633077
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(FormatterPlugin)
    pm.register(ConverterPlugin)
    pm.register(TransportPlugin)
    assert pm.get_transport_plugins() == [TransportPlugin]

# Generated at 2022-06-23 19:58:08.284213
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.http import HTTPTransportPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPTransportPlugin)
    plugin_manager.register(HTTPiePlugin)
    print(set(plugin_manager.get_transport_plugins()) == {HTTPTransportPlugin})


# Generated at 2022-06-23 19:58:15.165988
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    # Setup test case
    pm = PluginManager()
    for i in range(5):
        class FooFormatter(FormatterPlugin):
            name = f'name{i}'
            group_name = 'foo'
            __version__ = '1.0'
        pm.register(FooFormatter)

    # Verify
    assert len(pm.get_formatters()) == 5
    assert pm.get_formatters()[3].name == 'name3'
    assert pm.get_formatters()[1].group_name == 'foo'


# Generated at 2022-06-23 19:58:20.524409
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.register(AuthPlugin, FormatterPlugin)
    print(pm)
    assert str(pm) == "<PluginManager: [<class 'httpie.plugins.base.AuthPlugin'>, <class 'httpie.plugins.base.FormatterPlugin'>]>"


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:58:23.420856
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pmanager = PluginManager()
    assert len(pmanager) == 0
    pmanager.append(pmanager)
    assert len(pmanager) == 1


# Generated at 2022-06-23 19:58:25.976418
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    assert len(plugins) == 0
    assert isinstance(plugins.get_converters(), list)
    assert len(plugins.get_converters()) == 0

# Generated at 2022-06-23 19:58:28.818587
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    installed_plugins_before = len(PluginManager().load_installed_plugins())
    assert installed_plugins_before>0


# Generated at 2022-06-23 19:58:32.225594
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    PLUGIN_MANAGER = PluginManager()
    PLUGIN_MANAGER.load_installed_plugins()
    for plugin in PLUGIN_MANAGER.get_converters():
        print(plugin)
    assert len(PLUGIN_MANAGER.get_converters()) == 1

# Generated at 2022-06-23 19:58:39.284587
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.uglify import UglifyjsFormatter

    plugin_manager = PluginManager()

    plugin_manager.register(HTTPBasicAuth, UglifyjsFormatter)
    assert str(plugin_manager) == \
        '<PluginManager: [httpie.plugins.builtin.HTTPBasicAuth, ' \
        'httpie.plugins.uglify.UglifyjsFormatter]>'

# Generated at 2022-06-23 19:58:46.909400
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    entry_point_name = 'httpie.plugins.auth.v1'
    entry_point = iter_entry_points(entry_point_name)
    plugins = list(entry_point)
    for plugin in plugins:
        plugin.load().package_name = plugin.dist.key
    pm = PluginManager()
    pm.register(*plugins)
    assert len(pm) == 2
    auth_plugin_mapping = pm.get_auth_plugin_mapping()
    assert len(auth_plugin_mapping) == 2
    assert 'kerberos' in auth_plugin_mapping
    assert auth_plugin_mapping['kerberos'] == plugins[0].load()
    assert 'httpie-ntlm' in auth_plugin_mapping
    assert auth_plugin_mapping['httpie-ntlm'] == plugins

# Generated at 2022-06-23 19:58:50.738331
# Unit test for method register of class PluginManager
def test_PluginManager_register():

    class A:
        pass
    a=A()
    plugins = PluginManager()
    plugins.register(a)
    assert a in plugins



# Generated at 2022-06-23 19:58:58.325971
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    assert plugins.filter() == []
    plugins.register(AuthPlugin, ConverterPlugin, FormatterPlugin)
    assert set(plugins.filter(TransportPlugin)) == set()
    assert set(plugins.filter(BasePlugin)) == {AuthPlugin, ConverterPlugin, FormatterPlugin}
    assert set(plugins.filter(AuthPlugin)) == {AuthPlugin}
    assert set(plugins.filter(ConverterPlugin)) == {ConverterPlugin}
    assert set(plugins.filter(FormatterPlugin)) == {FormatterPlugin}

# Generated at 2022-06-23 19:59:03.178679
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    p = PluginManager()
    p.register(Plugin1)
    p.register(Plugin2)
    p.register(Plugin3)
    p.register(Plugin4)
    p.register(Plugin5)
    p.register(Plugin6)
    assert p.get_formatters() == [Plugin1, Plugin2, Plugin3, Plugin4, Plugin5, Plugin6]


# Generated at 2022-06-23 19:59:08.851511
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class _FormatterPlugin(FormatterPlugin):
        name = 'test1'
        group_name = 'group1'
    
    class _FormatterPlugin2(FormatterPlugin):
        name = 'test2'
        group_name = 'group2'
    pm = PluginManager()
    pm.register(_FormatterPlugin, _FormatterPlugin2)
    assert pm.get_formatters_grouped() == {'group1': [_FormatterPlugin], 'group2': [_FormatterPlugin2]}

# Generated at 2022-06-23 19:59:15.486077
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register( importlib.import_module("httpie.plugins.pretty.pretty").PrettyFormatterPlugin,
                      importlib.import_module("httpie.plugins.json.json").JSONFormatterPlugin)
    print(plugins)
    for i in plugins:
        print(i)
    print(plugins.get_formatters())
    for i in plugins.get_formatters():
        print(i)
    print(plugins.get_formatters_grouped())
    print(plugins.get_converters())
    print(plugins.get_auth_plugins())
    print(plugins.get_auth_plugin("any"))
    for i in plugins.get_auth_plugins():
        print(i)

# test_PluginManager_get_formatters()


# Generated at 2022-06-23 19:59:16.297007
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager().__repr__() == '<PluginManager: []>'

# Generated at 2022-06-23 19:59:18.996915
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register(
        DictToJSONConverter,
        
    )
    print(manager.get_converters())

# Generated at 2022-06-23 19:59:23.442685
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # test whether it could return the type of PluginManager
    # with the items in it
    pm = PluginManager()
    test_result = pm.__repr__()
    assert type(test_result) == str and 'PluginManager' in test_result

# Endpoints for unit tests

# Generated at 2022-06-23 19:59:25.249430
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugin_mapping()

# Generated at 2022-06-23 19:59:29.090015
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # arrange
    class MockAuthPlugin2(AuthPlugin):
        auth_type = 'MockAuthPlugin2'

    class MockAuthPlugin1(AuthPlugin):
        auth_type = 'MockAuthPlugin1'

    manager = PluginManager()
    manager.register(MockAuthPlugin1, MockAuthPlugin2)
    # act
    actual = manager.get_auth_plugins()
    # assert
    assert actual == [MockAuthPlugin1, MockAuthPlugin2]


# Generated at 2022-06-23 19:59:32.522313
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import HTTPiePlugin

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPiePlugin)

    assert len(plugin_manager.get_transport_plugins()) == 1

# Generated at 2022-06-23 19:59:34.844110
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm=PluginManager()
    pm.load_installed_plugins()
    print(pm)

if __name__=='__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-23 19:59:37.569079
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    assert isinstance(manager, list)
    assert len(manager) == 0



# Generated at 2022-06-23 19:59:40.588484
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(ConverterPlugin)
    result = plugin_manager.get_converters()
    assert result == [ConverterPlugin]


# Generated at 2022-06-23 19:59:42.496704
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    auth_plugins_list=manager.get_auth_plugins()
    assert [] == auth_plugins_list


# Generated at 2022-06-23 19:59:43.803045
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm


# Generated at 2022-06-23 19:59:45.498914
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    mgr = PluginManager()
    for item in mgr:
        assert item == item


# Generated at 2022-06-23 19:59:47.855616
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    a = PluginManager([])
    assert a.__repr__() == '<PluginManager: []>'


# Generated at 2022-06-23 19:59:48.890284
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()


# Generated at 2022-06-23 19:59:54.441411
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager=PluginManager()
    plugin_manager.register(HTMLConverter)
    assert len(plugin_manager.get_converters()) == 1
    assert plugin_manager.get_converters()[0] == HTMLConverter
    assert plugin_manager.get_converters() == [HTMLConverter]
    plugin_manager.unregister(HTMLConverter)
    assert len(plugin_manager.get_converters()) == 0

# Generated at 2022-06-23 19:59:59.257986
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    assert plugins.filter() == [AuthPlugin, FormatterPlugin]
    assert plugins.filter(BasePlugin) == [AuthPlugin, FormatterPlugin]
    assert plugins.filter(AuthPlugin) == [AuthPlugin]
    assert plugins.filter(FormatterPlugin) == [FormatterPlugin]

# Generated at 2022-06-23 20:00:01.306875
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager = PluginManager()
    PluginManager.load_installed_plugins()
    assert len(PluginManager) > 1


# Generated at 2022-06-23 20:00:05.458742
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
  plugin_mgr = PluginManager()
  plugin_mgr.load_installed_plugins()
  for auth_type in ['basic', 'digest', 'digest', 'digest', 'digest', 'digest']:
    assert auth_type == plugin_mgr.get_auth_plugin(auth_type).auth_type

test_PluginManager_get_auth_plugin()

# Generated at 2022-06-23 20:00:09.640421
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()

    # plugin_manager.get_converters() should return list of objects of type ConverterPlugin
    assert len(pm.get_converters()) > 0
    
    # every object of the list should be a ConverterPlugin
    assert all(issubclass(e, ConverterPlugin) for e in pm.get_converters())
    


# Generated at 2022-06-23 20:00:16.208248
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import BuiltinAuthPlugin, BuiltinHTTPPlugin

    plugin_manager = PluginManager()
    plugin_manager.append(BuiltinAuthPlugin)
    plugin_manager.append(BuiltinHTTPPlugin)
    plugin_manager.append(BuiltinHTTPPlugin)

    a = plugin_manager.filter()
    b = plugin_manager.filter(TransportPlugin)
    c = plugin_manager.filter(AuthPlugin)

    # a: []
    # b: [<class 'httpie_http2.http2.HTTP2Plugin'>, <class 'httpie.plugins.builtin.BuiltinHTTPPlugin'>,]
    # c: [<class 'httpie.plugins.builtin.BuiltinAuthPlugin'>]
    # assert a == b


plugin_manager = PluginManager()

# Generated at 2022-06-23 20:00:22.901303
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Instanciate class
    plugin_manager = PluginManager()
    # Verify before
    assert plugin_manager == []
    # Register two plugins
    plugin_manager.register(auth.BasicAuthPlugin, auth.DigestAuthPlugin)
    # Verify after
    assert plugin_manager == [auth.BasicAuthPlugin, auth.DigestAuthPlugin]
    # Verify get_auth_plugins
    assert plugin_manager.get_auth_plugins() == [auth.BasicAuthPlugin, auth.DigestAuthPlugin]

# Generated at 2022-06-23 20:00:27.925656
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert list(plugin_manager) == []
    assert plugin_manager.get_transport_plugins() == []

    plugin_manager.register(TCPTransport, HTTPTransport)
    assert list(plugin_manager) == [TCPTransport, HTTPTransport]
    assert plugin_manager.get_transport_plugins() == [TCPTransport, HTTPTransport]

    plugin_manager.unregister(HTTPTransport)
    assert list(plugin_manager) == [TCPTransport]
    assert plugin_manager.get_transport_plugins() == [TCPTransport]

    plugin_manager.register(HTTPTransport)
    assert list(plugin_manager) == [TCPTransport, HTTPTransport]

# Generated at 2022-06-23 20:00:29.705376
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(AuthPlugin, FormatterPlugin)
    assert len(manager) == 2



# Generated at 2022-06-23 20:00:31.605151
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping['a_auth'] == AuthPlugin


# Generated at 2022-06-23 20:00:34.789419
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(MyFormatterPlugin, MyAuthPlugin)

    assert plugin_manager.get_auth_plugins() == [MyAuthPlugin]
    assert plugin_manager.get_auth_plugins() != [MyFormatterPlugin]
    assert plugin_manager.get_auth_plugins() != [MyAuthPlugin, MyFormatterPlugin]

# Generated at 2022-06-23 20:00:41.918121
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    assert len(manager.get_converters()) == 0

    class MyConverterPlugin(ConverterPlugin):
        pass

    manager.register(MyConverterPlugin)
    assert len(manager.get_converters()) == 1
    assert manager.get_converters()[0] == MyConverterPlugin


if __name__ == '__main__':
    test_PluginManager_get_converters()

# Generated at 2022-06-23 20:00:44.490578
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register(BasePlugin)
    manager.register(ConverterPlugin)
    assert manager.get_converters() == [ConverterPlugin]

# Generated at 2022-06-23 20:00:45.783954
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert  PluginManager().get_converters() == []


# Generated at 2022-06-23 20:00:51.586200
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert PluginManager.get_transport_plugins.__doc__ == 'Return all the transport plugins in the plugin list'
    class TransportPlugin(BasePlugin):
        name = 'transport_plugin'
    class BasePlugin:
        name = 'base_plugin'
    plugins = [TransportPlugin(), BasePlugin()]
    plugin_manager = PluginManager(plugins)
    assert plugin_manager.get_transport_plugins() == [TransportPlugin()]
