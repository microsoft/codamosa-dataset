

# Generated at 2022-06-23 19:50:58.323119
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    assert len(plugins.get_formatters_grouped()) == 1
    assert len(plugins.get_formatters_grouped()['httpie']) == 3
    assert plugins.get_formatters_grouped()['httpie'][0] == FormatterPlugin

# Generated at 2022-06-23 19:51:02.165833
# Unit test for constructor of class PluginManager
def test_PluginManager():

    assert isinstance(pm,PluginManager)
    assert pm.__dict__ == {}
    assert pm.get_auth_plugins() == []
    assert pm.get_auth_plugin_mapping() == {}
    assert pm.get_auth_plugin('something') == {}
    assert pm.get_formatters() == []
    assert pm.get_formatters_grouped() == {}
    assert pm.get_converters() == []
    assert pm.get_transport_plugins() == []
    assert pm == []
    assert pm.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-23 19:51:03.731327
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(PluginA, PluginB)
    assert plugins.get_formatters() == [PluginB]
test_PluginManager_get_formatters()


# Generated at 2022-06-23 19:51:11.959866
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
	print("Testing get_auth_plugins method of PluginManager class...")
	print(" ")
	# Creating an instance of class PluginManager
	manager = PluginManager()
	manager.load_installed_plugins()
	
	# Testing if the method could return a list with the elements:
	# - httpie.plugins.auth.basic.BasicAuthPlugin
	# - httpie.plugins.auth.digest.DigestAuthPlugin
	# - httpie.plugins.auth.hmac.HMACAuthPlugin
	# - httpie.plugins.auth.jwt.JWTAuthPlugin
	# - httpie.plugins.auth.kerberos.KerberosAuthPlugin
	# - httpie.plugins.auth.multipart.MultipartAuthPlugin
	# - httpie.plugins.auth.ntlm.NTLMAuthPlugin


# Generated at 2022-06-23 19:51:15.546669
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin)
    print(plugin_manager.get_transport_plugins())

test_PluginManager_get_transport_plugins()

# Generated at 2022-06-23 19:51:17.920826
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager.get_converters.__doc__ == 'Return: List[Type[ConverterPlugin]]'


# Generated at 2022-06-23 19:51:20.081032
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_mgr = PluginManager()
    plugin_mgr.load_installed_plugins()

    assert len(plugin_mgr) != 0

# Generated at 2022-06-23 19:51:24.273370
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_auth_plugins()) > 0
    assert len(manager.get_formatters()) > 0
    assert len(manager.get_converters()) > 0
    assert len(manager.get_transport_plugins()) > 0


# Generated at 2022-06-23 19:51:27.381526
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_auth_plugin_mapping()

    assert 'basic' in plugins
    assert 'digest' in plugins
    assert 'hawk' in plugins
    assert 'jwt' in plugins
    assert 'oauth1' in plugins
    assert 'oauth2' in plugins

# Generated at 2022-06-23 19:51:31.646825
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    formatters_list = plugin_manager.get_formatters()
    for i in range(0, len(formatters_list)):
        if formatters_list[i].name == 'json':
            assert formatters_list[i].name == 'json'
            break
        if i == len(formatters_list) - 1 and formatters_list[i].name != 'json':
            assert False



# Generated at 2022-06-23 19:51:34.704559
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.register(
        AuthPlugin,
        ConverterPlugin,
        FormatterPlugin,
        TransportPlugin
    )
    assert manager.get_auth_plugins() == [AuthPlugin]


# Generated at 2022-06-23 19:51:40.093728
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class AuthPlugin1(AuthPlugin):
        name = 'auth plugin 1'
        auth_type = 'auth1'
    class AuthPlugin2(AuthPlugin):
        name = 'auth plugin 2'
        auth_type = 'auth2'

    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin1, AuthPlugin2)
    assert len(pluginManager) == 2
    assert AuthPlugin1 in pluginManager
    assert type(pluginManager[0]) == AuthPlugin1
    assert pluginManager[0].auth_type == "auth1"
    assert type(pluginManager[1]) == AuthPlugin2
    assert pluginManager[1].auth_type == "auth2"

    pluginManager.unregister(AuthPlugin1)
    assert len(pluginManager) == 1
    assert AuthPlugin2 in pluginManager

# Generated at 2022-06-23 19:51:43.792205
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin_1, Plugin_2)
    assert plugin_manager.get_formatters() == [Plugin_1, Plugin_2]


# Generated at 2022-06-23 19:51:47.268623
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_list = plugin_manager.filter(TransportPlugin)
    assert len(plugin_list) > 0
    assert plugin_list[0].name == 'http'


# Generated at 2022-06-23 19:51:51.298576
# Unit test for constructor of class PluginManager
def test_PluginManager():
    # test instantiation
    pm = PluginManager()
    assert(pm.get_auth_plugins() == [])
    assert pm.get_formatters_grouped() == {}
    assert(pm.get_transport_plugins() == [])

# Generated at 2022-06-23 19:51:55.133956
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    plugins = manager.get_auth_plugins()
    assert len(plugins)
    for plugin in plugins:
        assert issubclass(plugin, AuthPlugin)
    assert 'Basic' in [plugin.auth_type for plugin in plugins]


# Generated at 2022-06-23 19:51:57.838392
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # when:
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins = plugin_manager.get_auth_plugins()

    # then:
    assert len(auth_plugins) == 2



# Generated at 2022-06-23 19:51:59.974119
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    assert type(pluginManager.get_converters()) == list

# Generated at 2022-06-23 19:52:02.447130
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin = PluginManager()
    expected = "<PluginManager: []>"
    result = plugin.__repr__()
    assert result == expected


# Generated at 2022-06-23 19:52:06.933614
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    result = plugins.filter(type(AuthPlugin))


if __name__ == '__main__':
    test_PluginManager_filter()

# Generated at 2022-06-23 19:52:09.662616
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin('http') == HTTPBasicAuth


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:52:14.471876
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(JsonLines, Json)
    plugin = plugin_manager.get_formatters_grouped()
    assert plugin['Json'] == [Json, JsonLines]

if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-23 19:52:16.851361
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert str(pm[0]).split(':')[0] == '<PluginManager'
    assert str(pm[0]).split('.')[-1] == '>'

# Generated at 2022-06-23 19:52:18.146863
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'


# Generated at 2022-06-23 19:52:25.364110
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Given httpie
    # And httpie-oauthlib
    # And httpie-aws-auth
    # And httpie-jwt-auth
    # And httpie-oauth1-auth
    # When plugins are loaded
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # Then there should be at least 6 plugins loaded
    assert len(plugin_manager) >= 6

    # And httpie should be one of them
    assert any(plugin.package_name == 'httpie' for plugin in plugin_manager)

    # And httpie-oauthlib should be one of them
    assert any(plugin.package_name == 'httpie-oauthlib' for plugin in plugin_manager)

    # And httpie-aws-auth should be one of them

# Generated at 2022-06-23 19:52:33.218537
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    """
    Verify that method get_auth_plugins of class PluginManager returns a
    correct list of plugins.
    """
    import httpie.plugins.builtin
    import httpie.plugins.builtin.auth

    manager = PluginManager()
    manager.register(httpie.plugins.builtin.auth.ApiKeyAuthPlugin)
    manager.register(httpie.plugins.builtin.auth.BasicAuthPlugin)
    manager.register(httpie.plugins.builtin.auth.DigestAuthPlugin)
    manager.register(httpie.plugins.builtin.auth.HawkAuthPlugin)
    manager.register(httpie.plugins.builtin.auth.OAuth1AuthPlugin)
    manager.register(httpie.plugins.builtin.auth.OAuth2AuthPlugin)

    # pylint: disable=line-too-long

# Generated at 2022-06-23 19:52:34.661528
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}

# Generated at 2022-06-23 19:52:45.712280
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(plugins) == '<PluginManager: []>'

# Generated at 2022-06-23 19:52:55.820312
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-23 19:52:57.256099
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert isinstance(plugins, PluginManager)

# Generated at 2022-06-23 19:53:00.756116
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    m = PluginManager()
    m.register(Plugin1)
    m.register(Plugin2)
    assert m == [Plugin1, Plugin2]
    m.unregister(Plugin1)
    assert m == [Plugin2]
    m.unregister(Plugin2)
    assert m == []

# Generated at 2022-06-23 19:53:02.202990
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    return PluginManager().get_transport_plugins()


# Generated at 2022-06-23 19:53:06.928251
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(BasePlugin(),BasePlugin()) # 调用父类append
    out = plugins.filter()
    assert len(out) == 2
    assert isinstance(out[0], BasePlugin)


plugins = PluginManager()

# Generated at 2022-06-23 19:53:13.445442
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import auth
    from httpie.plugins import formatter
    from httpie.plugins import converter
    from httpie.plugins import transport
    pytest.importorskip('pkg_resources')
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert auth.BasicAuth
    assert formatter.ColoredFormatter
    assert converter.JSONConverter
    assert not transport.NoopTransport

# Generated at 2022-06-23 19:53:15.966835
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    # Plugins of types auth, formatter, converter and transport
    assert type(p) == PluginManager



# Generated at 2022-06-23 19:53:17.294379
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert len(PluginManager().get_auth_plugins()) == 0


# Generated at 2022-06-23 19:53:20.326079
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPiePlugin)
    assert plugin_manager.get_transport_plugins()[0] == HTTPiePlugin


manager = PluginManager()

# Generated at 2022-06-23 19:53:21.645505
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert 0, "TODO"

# Generated at 2022-06-23 19:53:33.559391
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import BuiltinFormatterPlugin
    from httpie.plugins.json import JSONFormatterPlugin
    from httpie.plugins.table import TableFormatterPlugin
    from httpie.plugins.pretty import PrettyFormatterPlugin
    from httpie.plugins.html import HTMLFormatterPlugin
    from httpie.plugins.three import ThreeFormatterPlugin
    from httpie.plugins.rfc822 import RFC822FormatterPlugin
    from httpie.plugins.xml import XMLFormatterPlugin
    #
    plugin_manager = PluginManager()
    plugin_manager.register(BuiltinFormatterPlugin, JSONFormatterPlugin, TableFormatterPlugin,
                            PrettyFormatterPlugin, HTMLFormatterPlugin,
                            ThreeFormatterPlugin, RFC822FormatterPlugin, XMLFormatterPlugin)
    assert plugin_manager.get_formatters()

# Generated at 2022-06-23 19:53:35.467871
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugins()


# Generated at 2022-06-23 19:53:37.542601
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin('Basic') == 'Basic'


# Generated at 2022-06-23 19:53:48.159747
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_1 = BasePlugin()
    plugin_2 = TransportPlugin()
    plugin_3 = AuthPlugin()
    plugin_4 = ConverterPlugin()
    plugin_5 = FormatterPlugin()
    pm = PluginManager()
    pm.register(plugin_1, plugin_2, plugin_3, plugin_4, plugin_5)
    get_transport_plugins = pm.filter(TransportPlugin)
    result = [plugin_2]
    assert get_transport_plugins == result
    get_auth_plugins = pm.filter(AuthPlugin)
    result = [plugin_3]
    assert get_auth_plugins == result
    get_converters = pm.filter(ConverterPlugin)
    result = [plugin_4]
    assert get_converters == result

# Generated at 2022-06-23 19:53:50.279625
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():

    formatters = get_formatters()
    assert formatters == [JSONFormatter, FormFormatter, ColoredJSONFormatter]

# Generated at 2022-06-23 19:53:54.633327
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()

    # test 
    plugin_manager.append(AuthPlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]

    # test
    plugin_manager.append(TransportPlugin)
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]


# Generated at 2022-06-23 19:53:56.161893
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = []
    pm = PluginManager()
    pm.register(plugins)
    assert isinstance(pm, PluginManager)
    assert pm.plugins == plugins


# Generated at 2022-06-23 19:54:01.358918
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_auth_plugins()) > 0
    assert len(manager.get_formatters()) > 0
    assert len(manager.get_converters()) > 0
    assert len(manager.get_transport_plugins()) > 0


# Generated at 2022-06-23 19:54:04.420413
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager().register(*ConverterPlugin.__subclasses__())
    converters = manager.get_converters()
    assert len(converters) == 2

# Generated at 2022-06-23 19:54:06.269198
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pluginManager = PluginManager()
    assert pluginManager.__repr__() == '<PluginManager: []>'
    pluginManager.register(BasePlugin)
    assert pluginManager.__repr__() == "<PluginManager: [<class 'httpie.plugins.base.BasePlugin'>]>"

# Generated at 2022-06-23 19:54:09.484502
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    formatters = manager.get_formatters()
    assert isinstance(formatters, list)
    assert isinstance(formatters[0], FormatterPlugin)

test_PluginManager_get_formatters()

# Generated at 2022-06-23 19:54:10.924281
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert pm.register(2, 3) == [2, 3]


# Generated at 2022-06-23 19:54:22.663699
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-23 19:54:28.138766
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    class A(AuthPlugin):
        auth_type = '_a'
    class B(AuthPlugin):
        auth_type = '_b'

    plugin_manager.register(A, B)

    assert plugin_manager.get_auth_plugin('_a') == A
    assert plugin_manager.get_auth_plugin('_b') == B



# Generated at 2022-06-23 19:54:31.533477
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    class MyPlugin(TransportPlugin):
        pass

    class MyOtherPlugin(MyPlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(MyPlugin, MyOtherPlugin)
    assert set(plugin_manager.get_transport_plugins()) == {MyPlugin, MyOtherPlugin}


plugins = PluginManager()

# Generated at 2022-06-23 19:54:36.951798
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    p1 = type('Plugin1', (), {'auth_type': 'auth_type_1'})
    p2 = type('Plugin2', (), {'auth_type': 'auth_type_2'})
    manager = PluginManager()
    manager.register(p1, p2)
    assert manager.get_auth_plugins() == [p1, p2]
    print('get_auth_plugins ok')


# Generated at 2022-06-23 19:54:44.249687
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(BasePlugin):
        pass

    manager = PluginManager()
    manager.register(Plugin1, Plugin2, Plugin3)
    assert manager[0] == Plugin1
    assert manager[1] == Plugin2
    assert manager[2] == Plugin3

    manager.unregister(Plugin2)
    assert manager[0] == Plugin1
    assert manager[1] == Plugin3



# Generated at 2022-06-23 19:54:48.656253
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(type('AuthPlugin', (AuthPlugin,), {}))
    plugin_manager.unregister(type('AuthPlugin', (AuthPlugin,), {}))
    assert list(plugin_manager) == []


# Generated at 2022-06-23 19:54:53.478688
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Formatter1(FormatterPlugin):
        group_name = 'group 1'

    class Formatter2(FormatterPlugin):
        group_name = 'group 2'

    class Formatter3(FormatterPlugin):
        group_name = 'group 2'

    pm = PluginManager()
    pm.register(Formatter1, Formatter2, Formatter3)
    assert pm.get_formatters_grouped() == {
        'group 1': [Formatter1],
        'group 2': [Formatter2, Formatter3]
    }

# Generated at 2022-06-23 19:54:59.135047
# Unit test for constructor of class PluginManager
def test_PluginManager():
    enpt = ENTRY_POINT_NAMES
    assert ENTRY_POINT_NAMES == ['httpie.plugins.auth.v1',
                                 'httpie.plugins.formatter.v1',
                                 'httpie.plugins.converter.v1',
                                 'httpie.plugins.transport.v1']

# Generated at 2022-06-23 19:55:01.760795
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    for plugin in plugins:
        assert isinstance(plugin, BasePlugin)

# Generated at 2022-06-23 19:55:03.784941
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(TestPlugin1, TestPlugin2)
    pm.get_converters()


# Generated at 2022-06-23 19:55:04.760333
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()


# Generated at 2022-06-23 19:55:05.965804
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(object)
    print(pm.filter(object))


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:55:09.632150
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    assert '{"error": "auth plugin not found"}' == pm.get_auth_plugin('sdfs')

# Generated at 2022-06-23 19:55:15.432039
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.packages.requests.auth import HTTPBasicAuth
    from httpie.plugins.builtin import (
        BasicAuthPlugin, DigestAuthPlugin
    )
    PluginManager().register(BasicAuthPlugin, DigestAuthPlugin)

    assert PluginManager().get_auth_plugin_mapping() == {
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin
    }

# Generated at 2022-06-23 19:55:20.761259
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()

    pm.register(HTTPBasicAuth)
    pm.unregister(HTTPBasicAuth)

    assert HTTPBasicAuth not in pm

# Generated at 2022-06-23 19:55:25.888182
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pass
    '''
    List<FormatterPlugin> list = new ArrayList<>();
    list.add(new table.TableFormatterPlugin());
    list.add(new json.JsonFormatterPlugin());
    list.add(new csv.CsvFormatterPlugin());
    Map<String,List<FormatterPlugin>> map = 
    '''

# Generated at 2022-06-23 19:55:29.371551
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import http as http_transport, http2
    plugins = PluginManager()
    plugins.register(http_transport.HTTPTransport,http2.HTTP2Transport)
    assert len(plugins.get_transport_plugins()) == 2 


# Generated at 2022-06-23 19:55:31.604003
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(TestClass)
    transport_plugins = pm.get_transport_plugins()
    assert transport_plugins == [TestClass]



# Generated at 2022-06-23 19:55:35.446160
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    '''
    find out if the function "get_converters" can pass the test
    '''
    pm = PluginManager()
    pm.load_installed_plugins()
    res = pm.get_converters()
    assert isinstance(res, list)
    assert(len(res)>0)


# Generated at 2022-06-23 19:55:41.585757
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # mock a Plugin
    class Plugin(AuthPlugin):

        auth_type = 'plugin-test'

        def get_auth(self, username, password):
            return username, password
    
    manager = PluginManager()
    
    # register plugin and make it appeared in the list of PluginManager
    manager.register(Plugin)

    assert list(manager)[0] == Plugin


# Generated at 2022-06-23 19:55:45.261315
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    
    assert len(plugin_manager.get_auth_plugins()) > 0
    for plugin in plugin_manager.get_auth_plugins():
        assert plugin.auth_type



# Generated at 2022-06-23 19:55:48.806352
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins.register(auth_plugins.BasicAuthPlugin)
    assert len(plugins.get_auth_plugins()) == 1
    assert auth_plugins.BasicAuthPlugin in plugins.get_auth_plugins()



# Generated at 2022-06-23 19:55:52.451531
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters()
    print(formatters)


# Generated at 2022-06-23 19:55:57.227226
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    global plugin_manager
    auth_plugins = plugin_manager.get_auth_plugins()
    assert (auth_plugins != None),"The auth_plugins cannot be None"
    assert (type(auth_plugins)  == list),"The auth_plugins must be a list"
    assert (len(auth_plugins) != 0),"The number of auth_plugins must be greater than zero"


# Generated at 2022-06-23 19:56:05.971165
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-23 19:56:07.335163
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
        plugins = PluginManager()
        assert plugins.get_transport_plugins() == []

# Generated at 2022-06-23 19:56:16.577400
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.load_installed_plugins()

# Generated at 2022-06-23 19:56:18.040704
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pluginManager=PluginManager()
    pluginManager.register(1,2,3)
    assert len(pluginManager)==3


# Generated at 2022-06-23 19:56:28.801915
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Mock
    class PluginManagerMock(PluginManager):
        def __init__(self):
            self.auth_plugins = [
                AuthPluginMock("auth-type1"),
                AuthPluginMock("auth-type2"),
                AuthPluginMock("auth-type3")
            ]

        def get_auth_plugin_mapping(self):
            return {
                "auth-type1": self.auth_plugins[0],
                "auth-type2": self.auth_plugins[1],
                "auth-type3": self.auth_plugins[2]
            }

    # Test
    plugin_manager = PluginManagerMock()
    assert plugin_manager.get_auth_plugin("auth-type1") == plugin_manager.get_auth_plugin_mapping()["auth-type1"]


# Generated at 2022-06-23 19:56:29.385384
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pass

# Generated at 2022-06-23 19:56:40.531876
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # test data
    entry_point_names = ['httpie.plugins.auth.v1', 'httpie.plugins.formatter.v1','httpie.plugins.converter.v1']

    class entry_point:
        class dist:
            key = 'key'

    class entry_point_load:
        auth_type = 'auth_type'
        group_name = 'group_name'

    class plugins(PluginManager):
        def filter(self, by_type=Type[BasePlugin]):
            return [entry_point_load]

    plugin = plugins()
    assert isinstance(plugin, PluginManager)
    assert isinstance(plugin.get_auth_plugin_mapping(), dict)
    assert len(plugin.get_auth_plugin_mapping()) == 1



# Generated at 2022-06-23 19:56:44.340502
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    assert len(manager) == 0
    manager.register(auth_plugin)
    assert len(manager) == 1
    assert auth_plugin in manager


# Generated at 2022-06-23 19:56:47.488235
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
	auth_plugin_manager = PluginManager()
	print("Auth plugin: ",auth_plugin_manager.get_auth_plugins())


# Generated at 2022-06-23 19:56:50.716119
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager == [AuthPlugin]
    manager.register(FormatterPlugin)
    assert manager == [AuthPlugin, FormatterPlugin]


# Generated at 2022-06-23 19:57:00.492697
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    def test_plugins():
        class FormatterPlugin1(FormatterPlugin):
            group_name = 'group1'
            name = 'FormatterPlugin1'

        class FormatterPlugin2(FormatterPlugin):
            group_name = 'group1'
            name = 'FormatterPlugin2'

        class FormatterPlugin3(FormatterPlugin):
            group_name = 'group2'
            name = 'FormatterPlugin3'

        return [FormatterPlugin1, FormatterPlugin2, FormatterPlugin3]

    manager = PluginManager()
    manager.register(*test_plugins())

    assert manager.get_formatters_grouped() == {
            'group1': [FormatterPlugin1, FormatterPlugin2],
            'group2': [FormatterPlugin3]
        }

# Generated at 2022-06-23 19:57:03.578926
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    print(manager)

# Generated at 2022-06-23 19:57:09.411782
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plm = PluginManager()
    class FormatterPlugin:
        pass
    class AuthPlugin:
        pass

    plm.register(FormatterPlugin)
    assert plm.filter(FormatterPlugin) == [FormatterPlugin]
    assert plm.filter(AuthPlugin) == []

    plm.register(AuthPlugin)

    assert plm.filter(FormatterPlugin) == [FormatterPlugin]
    assert plm.filter(AuthPlugin) == [AuthPlugin]

# Generated at 2022-06-23 19:57:10.869569
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    a=PluginManager()
    assert a.filter() == []


# Generated at 2022-06-23 19:57:11.930098
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager().get_formatters_grouped()

# Generated at 2022-06-23 19:57:15.115948
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2)
    group = plugin_manager.get_formatters_grouped()
    assert group['group1'] == [Plugin1]
    assert group['group2'] == [Plugin2]

# Generated at 2022-06-23 19:57:17.552366
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    plugins = pluginmanager.get_converters()
    assert 'httpie.plugins.converter.json.JsonConverterPlugin' in str(plugins)

# Generated at 2022-06-23 19:57:24.554361
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins_mgr = PluginManager()
    assert len(plugins_mgr.get_auth_plugins()) == 0

    plugins_mgr.register(BasicAuthPlugin)
    assert len(plugins_mgr.get_auth_plugins()) == 1

    plugins_mgr.register(DigestAuthPlugin)
    assert len(plugins_mgr.get_auth_plugins()) == 2

    plugins_mgr.unregister(BasicAuthPlugin)
    assert len(plugins_mgr.get_auth_plugins()) == 1

    plugins_mgr.unregister(DigestAuthPlugin)
    assert len(plugins_mgr.get_auth_plugins()) == 0

# Generated at 2022-06-23 19:57:27.904669
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    def test_plugin():
        class TestPlugin(ConverterPlugin):
            pass
        return TestPlugin
    p = PluginManager()
    p.register(test_plugin())
    assert p.get_converters() == [test_plugin()]
    assert p.get_converters()[0].__name__ == 'TestPlugin'

# Generated at 2022-06-23 19:57:30.843631
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    manager.register(FormatterPlugin)
    assert manager.get_formatters() == [FormatterPlugin]


# Generated at 2022-06-23 19:57:39.044675
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    print('测试方法filter(by_type)')
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin
    from httpie.plugins.base import BasePlugin
    x = PluginManager()
    x.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    print(x.filter(AuthPlugin))
    print(x.filter(ConverterPlugin))
    print(x.filter(FormatterPlugin))
    print(x.filter(TransportPlugin))
    print(x.filter(BasePlugin))
    print(x.filter(list))


# Generated at 2022-06-23 19:57:48.368917
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from json import loads
    from pygments import highlight
    from pygments.formatters import Terminal256Formatter
    from pygments.lexers import JsonLexer
    from httpie.plugins import AuthPlugin
    from httpie.output.formatters.base import BaseFormatter
    plugin_manager = PluginManager()
    class FormatterPluginTest(BaseFormatter):
        name = 'test'
        group_name = 'test'
    plugin_manager.register(FormatterPluginTest)
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.filter(Type[BaseFormatter]) == [FormatterPluginTest]
    assert plugin_manager.filter(Type[AuthPlugin]) == [AuthPlugin]
    plugin_manager.unregister(AuthPlugin)
    assert plugin_manager.filter(Type[AuthPlugin]) == []
    plugin_manager

# Generated at 2022-06-23 19:57:59.473920
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import os
    import pkg_resources
    old_entry_point_group_names = set()
    for entry_point in pkg_resources.iter_entry_points():
        old_entry_point_group_names.add(entry_point.name)
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    new_entry_point_group_names = set()
    for entry_point in pkg_resources.iter_entry_points():
        new_entry_point_group_names.add(entry_point.name)
    assert new_entry_point_group_names == (old_entry_point_group_names|set(ENTRY_POINT_NAMES))
    assert len(plugin_manager.filter(AuthPlugin)) == 2

# Generated at 2022-06-23 19:58:01.036080
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert isinstance(pm,list)
    assert len(pm) > 0


# Generated at 2022-06-23 19:58:12.167768
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    class Plugin(BasePlugin):
        pass
    class AuthPlugin(Plugin):
        auth_type = ''
    class TransportPlugin(Plugin):
        pass
    class FormatterPlugin(Plugin):
        pass
    class ConverterPlugin(Plugin):
        pass
    class AuthPlugin_1(AuthPlugin):
        auth_type = 'basic'
    class AuthPlugin_2(AuthPlugin):
        auth_type = 'digest'
    class TransportPlugin_1(TransportPlugin):
        pass
    class TransportPlugin_2(TransportPlugin):
        pass
    class AuthPlugin_3(AuthPlugin):
        auth_type = 'aws'
    class FormatterPlugin_1(FormatterPlugin):
        pass
    class FormatterPlugin_2(FormatterPlugin):
        pass

# Generated at 2022-06-23 19:58:17.049513
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    import httpie.plugins as plugins
    a = plugins.PluginManager()
    a.load_installed_plugins()
    a.get_formatters()
    a.get_formatters_grouped()
    a.get_converters()
    a.get_transport_plugins()
    a.get_auth_plugins()
    a.get_auth_plugin_mapping()
    a.get_auth_plugin('basic')
    a.filter()


# Generated at 2022-06-23 19:58:20.289033
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    test_PluginManager = PluginManager()
    test_PluginManager.load_installed_plugins()
    assert type(test_PluginManager).__name__ == "PluginManager"
    assert test_PluginManager.get_auth_plugins() != None

# Generated at 2022-06-23 19:58:24.019593
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plgmanager_test = PluginManager()
    plgmanager_test.register(plugins.BasicAuthPlugin)
    assert plgmanager_test.get_auth_plugin_mapping() == {'basic': plugins.BasicAuthPlugin}



# Generated at 2022-06-23 19:58:30.566005
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = []
    auth_plugin_mapping = {}

    class TestPlugin(AuthPlugin):
        auth_type = 'test_auth'

    plugins.append(TestPlugin)

    pm = PluginManager()
    for plugin in plugins:
        pm.register(plugin)

    auth_plugin_mapping = pm.get_auth_plugin_mapping()

    assert 'test_auth' in auth_plugin_mapping
    assert 'basic' not in auth_plugin_mapping
    assert pm.get_auth_plugin(auth_type='test_auth') == TestPlugin

# Generated at 2022-06-23 19:58:32.774723
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    for plugin in plugin_manager:
        assert issubclass(plugin, BasePlugin)


# Generated at 2022-06-23 19:58:39.935015
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.auth.v1 import AuthPlugin

    class MockAuthPlugin1(AuthPlugin):
        auth_type = 'mock'

    class MockAuthPlugin2(AuthPlugin):
        auth_type = 'mock'

    plugin_manager = PluginManager()
    plugin_manager.register(MockAuthPlugin1, MockAuthPlugin2)
    assert len(plugin_manager) == 2
    assert len(plugin_manager.get_auth_plugins()) == 2

# Generated at 2022-06-23 19:58:42.615343
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter import JSONConverter

    pluginManager = PluginManager()
    assert any(JSONConverter in converter for converter in pluginManager.get_converters())



# Generated at 2022-06-23 19:58:49.892691
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()

    class TransportPlugin_A(TransportPlugin):
        pass
    class TransportPlugin_B(TransportPlugin):
        pass
    class AuthPlugin_A(AuthPlugin):
        pass
    class AuthPlugin_B(AuthPlugin):
        pass
    class FormatterPlugin_A(FormatterPlugin):
        pass
    class FormatterPlugin_B(FormatterPlugin):
        pass
    class ConverterPlugin_A(ConverterPlugin):
        pass
    class ConverterPlugin_B(ConverterPlugin):
        pass

    pm.register(
        TransportPlugin_A,
        TransportPlugin_B,
        AuthPlugin_A,
        AuthPlugin_B,
        FormatterPlugin_A,
        FormatterPlugin_B,
        ConverterPlugin_A,
        ConverterPlugin_B,
    )

# Generated at 2022-06-23 19:58:52.326000
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginManager = PluginManager()
    pluginManager.register(Plugin())
    assert len(pluginManager.get_formatters()) == 1



# Generated at 2022-06-23 19:58:57.471819
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    '''
    Unit test for method __repr__ of class PluginManager
    '''
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'
    plugins.register(TransportPlugin)
    assert repr(plugins) == '<PluginManager: [httpie.plugins.transport.TransportPlugin]>'


# Generated at 2022-06-23 19:59:06.401411
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_formatters_grouped()['legacy'] == [
        httpie.plugins.formatter.colors.ColorsFormatter,
        httpie.plugins.formatter.format.FormattingFormatter,
        httpie.plugins.formatter.json.JSONFormatter,
        httpie.plugins.formatter.json_lines.JSONLinesFormatter,
        httpie.plugins.formatter.stream.StreamFormatter,
        httpie.plugins.formatter.terminal.TerminalFormatter,
        httpie.plugins.formatter.verbose.VerboseFormatter,
    ]

# Generated at 2022-06-23 19:59:07.780546
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert isinstance(PluginManager().get_auth_plugin_mapping(), dict)


# Generated at 2022-06-23 19:59:11.815426
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class A(BasePlugin):
        pass
    manager = PluginManager()
    manager.register(A)
    assert len(manager) == 1
    manager.unregister(A)
    assert len(manager) == 0
    manager.unregister(A)
    assert len(manager) == 0


# Generated at 2022-06-23 19:59:15.403290
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.register()
    print(plugin_manager.get_formatters())

# Generated at 2022-06-23 19:59:26.262626
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    auth_plugin = PluginManager()
    formatter_plugin = PluginManager()
    converter_plugin = PluginManager()
    adapter_plugin = PluginManager()

    plugin_manager.register(auth_plugin)
    plugin_manager.register(formatter_plugin)
    plugin_manager.register(converter_plugin)
    plugin_manager.register(adapter_plugin)
    assert len(plugin_manager) == 4
    assert auth_plugin in plugin_manager
    assert formatter_plugin in plugin_manager
    assert converter_plugin in plugin_manager
    assert adapter_plugin in plugin_manager

    plugin_manager.unregister(auth_plugin)
    plugin_manager.unregister(formatter_plugin)
    plugin_manager.unregister(converter_plugin)
    plugin_manager.unregister

# Generated at 2022-06-23 19:59:32.480330
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import TransportPlugin
    pm = PluginManager()
    assert len(pm.filter(by_type=TransportPlugin)) == 0
    from httpie.plugins.builtin import TCPPlugin
    pm.register(TCPPlugin)
    assert len(pm.filter(by_type=TransportPlugin)) == 1
    assert type(pm.filter(by_type=TransportPlugin)[0]) == TCPPlugin



# Generated at 2022-06-23 19:59:35.491083
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping()
    assert plugin_manager.get_auth_plugin_mapping()['basic']

# Generated at 2022-06-23 19:59:40.204352
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.get_transport_plugins() == []
    plugin_manager.register(TransportPlugin)
    assert plugin_manager.get_transport_plugins() == [TransportPlugin]

# Generated at 2022-06-23 19:59:45.075832
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(type(x) for x in range(20))
    assert len(plugin_manager) == 20
    plugin_manager.unregister(type(x) for x in range(10,20))
    assert len(plugin_manager) == 10

# Generated at 2022-06-23 19:59:51.319347
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.register(MY_AuthPlugin1)
    manager.register(MY_AuthPlugin2)
    manager.register(MY_AuthPlugin3)
    manager.register(MY_FormatterPlugin)
    manager.register(MY_ConverterPlugin)
    
    assert [MY_AuthPlugin1, MY_AuthPlugin2, MY_AuthPlugin3] == manager.get_auth_plugins()



# Generated at 2022-06-23 19:59:53.099702
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager.register(BasePlugin)
    assert PluginManager.filter(BasePlugin) == [BasePlugin]

# Generated at 2022-06-23 20:00:00.117051
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():

    def auth_plugin_factory(auth_type):
        class AuthPluginStub(AuthPlugin):
            auth_type = auth_type
            auth_parse = object
            auth_apply = object

        return AuthPluginStub

    class AuthPluginNotFoundStub(AuthPlugin):
        auth_type = 'baz'
        auth_parse = object
        auth_apply = object

    instance = PluginManager()

    def test_base():
        assert instance.get_auth_plugin('foo') is None
        assert instance.get_auth_plugin('bar') is None
        assert instance.get_auth_plugin('baz') is None

    def test_register_one():
        instance.register(auth_plugin_factory('foo'))
        assert isinstance(instance.get_auth_plugin('foo'), type)

# Generated at 2022-06-23 20:00:04.079926
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pl = PluginManager()
    assert pl.__repr__() == '<PluginManager: []>'
    pl.register(PluginManager)
    assert pl.__repr__() == '<PluginManager: [<class \'PluginManager\'>]>'

# Generated at 2022-06-23 20:00:06.096304
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # Instantiated class PluginManager
    plugins = PluginManager()
    # Call method get_converters of class PluginManager
    converters = plugins.get_converters()
    # Check the result
    assert converters == plugins


# Generated at 2022-06-23 20:00:14.463981
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # Prepare some plugins
    class Auth1(AuthPlugin):
        pass

    class Auth2(AuthPlugin):
        pass

    class Formatter1(FormatterPlugin):
        pass

    class Formatter2(FormatterPlugin):
        pass

    class Converter1(ConverterPlugin):
        pass

    class Converter2(ConverterPlugin):
        pass

    class Transport1(TransportPlugin):
        pass

    class Transport2(TransportPlugin):
        pass

    # Prepare plugin manager
    plugin_manager = PluginManager()

    # Register plugins
    plugin_manager.register(Auth1, Auth2)
    plugin_manager.register(Formatter1, Formatter2)
    plugin_manager.register(Converter1, Converter2)
    plugin_manager.register(Transport1, Transport2)

    # Test

# Generated at 2022-06-23 20:00:17.761241
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    result = plugin_manager.get_auth_plugin("basic")
    assert result == AuthPlugin



# Generated at 2022-06-23 20:00:20.776646
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.register(MyPlugin1, MyPlugin2)
    assert manager.get_transport_plugins() == [MyPlugin2]


plugin_manager = PluginManager()

# Generated at 2022-06-23 20:00:22.185865
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pass


plugins = PluginManager()

# Generated at 2022-06-23 20:00:28.035806
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    my_manager = PluginManager()
    my_manager.register(AuthPlugin)
    my_manager.register(ConverterPlugin)
    my_manager.register(FormatterPlugin)
    my_manager.register(TransportPlugin)
    assert my_manager[0] == AuthPlugin
    assert my_manager[1] == ConverterPlugin
    assert my_manager[2] == FormatterPlugin
    assert my_manager[3] == TransportPlugin


# Generated at 2022-06-23 20:00:29.069428
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager())

plugin_manager = PluginManager()

# Generated at 2022-06-23 20:00:33.534161
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.register(TransportPlugin)

    transport_plugins = plugin_manager.get_transport_plugins()
    assert len(transport_plugins) == 1
    assert transport_plugins[0] == TransportPlugin

    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 1
    assert len(plugin_manager.filter(TransportPlugin)) > 1

# Generated at 2022-06-23 20:00:39.549064
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import auth
    pm = PluginManager()
    pm.register(auth.BasicAuth, auth.DigestAuth)
    expected_value = {
        'basic': auth.BasicAuth,
        'digest': auth.DigestAuth
    }
    actual_value = pm.get_auth_plugin_mapping()
    assert expected_value == actual_value

# Generated at 2022-06-23 20:00:42.352366
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    manager.register(TestPlugin)
    assert repr(manager) == '<PluginManager: [TestPlugin]>'


# Generated at 2022-06-23 20:00:46.331868
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager_obj = PluginManager()
    assert {} == plugin_manager_obj.get_auth_plugin_mapping()

    plugin_manager_obj.register(HTTPBasicAuth, DigestAuth)
    assert {'basic': HTTPBasicAuth, 'digest': DigestAuth} == plugin_manager_obj.get_auth_plugin_mapping()


# Generated at 2022-06-23 20:00:51.550090
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugins() == []
    assert plugin_manager.get_auth_plugin_mapping() == {}
    assert plugin_manager.get_formatters() == []
    assert plugin_manager.get_formatters_grouped() == {}
    assert plugin_manager.get_converters() == []
    assert plugin_manager.get_transport_plugins() == []

