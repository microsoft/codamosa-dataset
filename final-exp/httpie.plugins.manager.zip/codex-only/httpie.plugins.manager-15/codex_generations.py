

# Generated at 2022-06-23 19:50:51.406688
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    expected_count_transport_plugins = 3
    assert len(plugin_manager.get_transport_plugins()) == expected_count_transport_plugins

# Generated at 2022-06-23 19:50:52.637852
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginmanager = PluginManager()
    assert(pluginmanager.get_formatters() == [])

# Generated at 2022-06-23 19:50:59.528026
# Unit test for constructor of class PluginManager
def test_PluginManager():
  m = PluginManager()
  assert m.__repr__() == '<PluginManager: []>'
  m.register(1)
  assert m.__repr__() == '<PluginManager: [1]>'
  m.unregister(1)
  assert m.__repr__() == '<PluginManager: []>'


# Generated at 2022-06-23 19:51:02.887473
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.append(1)
    plugin_manager.append(2)
    plugin_manager.append(3)
    plugin_manager.append(4)
    assert plugin_manager.get_converters() == [1, 2, 3, 4]

# Generated at 2022-06-23 19:51:11.251686
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    global plugin_manager
    plugin_manager = PluginManager()
    assert str(plugin_manager) == '<PluginManager: []>'
    plugin_manager.register(BasePlugin)
    assert str(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.base.BasePlugin\'>]>'
    plugin_manager.register(AuthPlugin)
    assert str(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.base.BasePlugin\'>, <class \'httpie.plugins.auth.AuthPlugin\'>]>'
    plugin_manager.unregister(BasePlugin)
    assert str(plugin_manager) == '<PluginManager: [<class \'httpie.plugins.auth.AuthPlugin\'>]>'


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:51:17.182108
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) == len(plugin_manager.get_auth_plugins())

    assert len(plugin_manager.filter(AuthPlugin)) == len(plugin_manager.get_auth_plugins())

# Generated at 2022-06-23 19:51:20.455278
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(MockPlugin, MockPlugin2)
    plugins.get_formatters_grouped()
    assert plugins.get_formatters_grouped() == {'group_1': [MockPlugin]}


# Generated at 2022-06-23 19:51:24.687917
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    app = PluginManager()
    plugins = app.get_formatters()

    def plugin1():
        pass

    def plugin2():
        pass

    app.register(plugin1, plugin2)

    plugins_new = app.get_formatters()

    assert len(plugins) == len(plugins_new) - 2


# Generated at 2022-06-23 19:51:28.363565
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    # type: () -> None

    def f1():
        pass

    def f2():
        pass

    pm_list = [f1, f2]
    pm = PluginManager()
    assert pm_list != pm
    pm.register(f1, f2)
    assert pm_list == pm



# Generated at 2022-06-23 19:51:29.542712
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    x = PluginManager()
    assert str(x) == '<PluginManager: []>'

# Generated at 2022-06-23 19:51:35.343385
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class FakePlugin(BasePlugin):
        pass

    class FakeFormatterPlugin(FormatterPlugin):
        pass

    class FakeAuthPlugin(AuthPlugin):
        pass

    class FakeConverterPlugin(ConverterPlugin):
        pass

    class FakeTransportPlugin(TransportPlugin):
        pass

    manager = PluginManager()


    manager.register(FakePlugin, FakeFormatterPlugin, FakeAuthPlugin, FakeConverterPlugin, FakeTransportPlugin)

    # Test all plugins of a class
    formatter_plugins = manager.filt

# Generated at 2022-06-23 19:51:47.040235
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    test_input = [
        FormatterPlugin('test-a', 'Test A'),
        FormatterPlugin('test-b', 'Test B'),
        FormatterPlugin('test-c', 'Test C'),
        FormatterPlugin('test-d', 'Test D')
    ]
    expected_output = {
        'test': [
            FormatterPlugin('test-a', 'Test A'),
            FormatterPlugin('test-b', 'Test B'),
            FormatterPlugin('test-c', 'Test C'),
            FormatterPlugin('test-d', 'Test D')
        ]
    }
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.register(*test_input)
    assert plugin_manager.get_formatters_grouped() == expected_output

# Generated at 2022-06-23 19:51:49.876614
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    print(manager.get_transport_plugins())


# Generated at 2022-06-23 19:51:53.429407
# Unit test for constructor of class PluginManager
def test_PluginManager():
    # Instance a PluginManager object
    plugins = PluginManager()
    # Load installed plugins
    plugins.load_installed_plugins()
    print(plugins.get_formatters_grouped())

if __name__ == "__main__":
    test_PluginManager()

# Generated at 2022-06-23 19:51:57.849818
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Arrange
    pm = PluginManager()
    # Arrange
    pm.register(AuthPlugin)
    # Act
    auth_plugin_mapping = pm.get_auth_plugin_mapping()
    
    # Assert
    assert len(auth_plugin_mapping) == 1
    assert 'auth' in auth_plugin_mapping
    assert auth_plugin_mapping['auth'] == AuthPlugin


# Generated at 2022-06-23 19:52:00.459525
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.register(SparkPostAuth, CurlAuth)

    assert len(plugins.get_auth_plugins()) == 2

# Generated at 2022-06-23 19:52:10.745935
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # plugin_manager.get_auth_plugin_mapping()


# p = PluginManager()
# p.register(auth.BasicAuthPlugin)
# print(p.get_auth_plugins())
# print(p.get_auth_plugin_mapping())
# print(p.get_auth_plugin('basic'))
#
# print(p.filter(FormatterPlugin))
# print(p.filter(ConverterPlugin))
# print(p.filter(TransportPlugin))
# print(p.get_formatters_grouped())
# print([f for f in sorted(p.get_formatters_grouped(), key=dict.keys)])

# Generated at 2022-06-23 19:52:12.356965
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register()
    assert plugins == []



# Generated at 2022-06-23 19:52:15.485156
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.auth import BasicAuth

    manager = PluginManager()

    manager.register(BasicAuth)

    assert manager.get_auth_plugin('basic') == BasicAuth


# Generated at 2022-06-23 19:52:20.068753
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    plugins = [
        BasePlugin,
        AuthPlugin,
        ConverterPlugin,
        FormatterPlugin,
        TransportPlugin,
    ]
    manager.register(*plugins)
    output = manager.get_formatters_grouped()
    assert output == {'json': [FormatterPlugin], 'xml': [FormatterPlugin], 'rfc': [FormatterPlugin]}

# Generated at 2022-06-23 19:52:22.324575
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.register(TestPlugin1)
    assert pm.get_formatters() == [TestPlugin1]


# Generated at 2022-06-23 19:52:24.747005
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(MyTransportPlugin)
    assert pm.get_transport_plugins() == [MyTransportPlugin]


# Generated at 2022-06-23 19:52:32.837263
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(
        FormatterPlugin(
            group_name='first',
            group_title='first'),
        FormatterPlugin(
            group_name='first',
            group_title='first'),
        FormatterPlugin(
            group_name='second',
            group_title='second'))

    assert (plugin_manager.get_formatters_grouped()) == {
        'first': [
            FormatterPlugin(
                group_name='first',
                group_title='first'),
            FormatterPlugin(
                group_name='first',
                group_title='first')
        ],
        'second': [
            FormatterPlugin(
                group_name='second',
                group_title='second')
        ]
    }


# Generated at 2022-06-23 19:52:38.182254
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin = PluginManager
    # Instantiate a new instance of PluginManager
    instance = plugin()
    # Register a plugin before trying to unregister it
    instance.register(HTTPBasicAuth)
    # Plugin is successfully unregistered
    instance.unregister(HTTPBasicAuth)


# Generated at 2022-06-23 19:52:41.551277
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert str(PluginManager()) == '<PluginManager: []>'
    assert str(PluginManager([1,2,3])) == '<PluginManager: [1, 2, 3]>'


# Generated at 2022-06-23 19:52:47.466328
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class ObsoleteFormatter(FormatterPlugin):
        pass

    class ObsoleteConverter(ConverterPlugin):
        pass

    class LatestFormatter(FormatterPlugin):
        pass

    class LatestConverter(ConverterPlugin):
        pass

    plugins = PluginManager()
    plugins.register(ObsoleteFormatter, ObsoleteConverter, LatestFormatter, LatestConverter)

    formatter_plugins = plugins.filter(FormatterPlugin)
    converter_plugins = plugins.filter(ConverterPlugin)

    assert formatter_plugins == [ObsoleteFormatter, LatestFormatter]
    assert converter_plugins == [ObsoleteConverter, LatestConverter]



# Generated at 2022-06-23 19:52:51.142063
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    m = PluginManager()
    try:
        assert m.get_auth_plugin_mapping()
    except:
        print("Failure")
        assert False
    else:
        assert True


# Generated at 2022-06-23 19:52:55.744641
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # 1. Arrange
    _plugins = [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    pm = PluginManager()

    # 2. Act
    pm.register(*_plugins)
    r = pm.filter(FormatterPlugin)

    # 3. Assert
    assert len(r) == 1
    assert r[0] == FormatterPlugin



# Generated at 2022-06-23 19:52:57.821480
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager.get_auth_plugins()) == 4



# Generated at 2022-06-23 19:53:02.758180
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.transport import UnixSocketTransportPlugin
    from httpie.plugins.transport import standard_transport
    from httpie.plugins.transport import httpie_transport
    from httpie.plugins.transport import httpx_transport

    manager = PluginManager()

    manager.register(UnixSocketTransportPlugin)
    manager.register(standard_transport)
    manager.register(httpie_transport)
    manager.register(httpx_transport)

    assert len(manager.get_transport_plugins()) == 3



# Generated at 2022-06-23 19:53:03.961170
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager().get_auth_plugins()

# Generated at 2022-06-23 19:53:06.880523
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins=PluginManager()
    formatters=plugins.get_formatters()
    assert len(formatters)==5
    assert 'json' in formatters


# Generated at 2022-06-23 19:53:13.024238
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    test_converter = '''
    class TestPlugin(ConverterPlugin):
        convert = 'test_plugin'

    plugin_manager.register(TestPlugin)
    '''
    before = PluginManager()
    exec(test_converter, globals(), {"plugin_manager": before})

    after = PluginManager()
    assert before.get_converters() == after.get_converters()

# Generated at 2022-06-23 19:53:16.433257
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatter, GzippedJSONFormatter

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatter, GzippedJSONFormatter)

    assert plugin_manager.get_formatters_grouped() == {
        'json': [JSONFormatter, GzippedJSONFormatter],
    }

# Generated at 2022-06-23 19:53:22.556062
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    # create a class which inherits from class AuthPlugin
    class testclass1(AuthPlugin):
        auth_type = 'testclass1'
    # create a class which inherits from class AuthPlugin
    class testclass2(AuthPlugin):
        auth_type = 'testclass2'
    manager.register(testclass1, testclass2)
    result = manager.get_auth_plugin_mapping()
    expected_result = {'testclass1': testclass1, 'testclass2': testclass2}
    assert result == expected_result


# Generated at 2022-06-23 19:53:28.625044
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter.json import JsonConverter
    from httpie.plugins.converter.json_lines import JsonLinesConverter
    from httpie.plugins.converter.form import FormConverter
    from httpie.plugins.converter.prettyjson import PrettyJsonConverter
    from httpie.plugins.converter.stream import StreamConverter
    from httpie.plugins.converter.lines import LinesConverter
    import os
    
    plugin_manager = PluginManager()
    plugins = [JsonConverter,
               JsonLinesConverter,
               FormConverter,
               PrettyJsonConverter,
               StreamConverter,
               LinesConverter]
    plugin_manager.register(*plugins)

# Generated at 2022-06-23 19:53:30.396192
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager(AuthPlugin)
    assert pluginManager == [AuthPlugin]

# Generated at 2022-06-23 19:53:37.308684
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    assert plugins.get_converters() == []

    plugins.register(DummyConverter)
    assert plugins.get_converters() == [DummyConverter]

    plugins.register(DummyConverter)
    assert plugins.get_converters() == [DummyConverter, DummyConverter]

    plugins.unregister(DummyConverter)
    assert plugins.get_converters() == [DummyConverter]

    plugins.unregister(DummyConverter)
    assert plugins.get_converters() == []


# Generated at 2022-06-23 19:53:41.415940
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    assert isinstance(plugin_manager.get_transport_plugins(), list)
    assert len(plugin_manager.get_transport_plugins()) == 0


# Generated at 2022-06-23 19:53:45.430950
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class TestPlugin(FormatterPlugin):
        group_name = 'test'
    plugins = PluginManager()
    plugins.register(TestPlugin)
    assert plugins.get_formatters_grouped() == {
        'test': [TestPlugin]
    }
    return 0

# Generated at 2022-06-23 19:53:48.356907
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register(HttpiePlugin)
    assert isinstance(manager[0], HttpiePlugin)
    manager.unregister(HttpiePlugin)
    assert len(manager) == 0


# Generated at 2022-06-23 19:53:51.048928
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager_instance = PluginManager()
    PluginManager_instance.register(AuthPlugin)
    assert AuthPlugin in PluginManager_instance

 # Unit test for method unregister of class PluginManager

# Generated at 2022-06-23 19:53:55.284203
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin_mapping()
    assert isinstance(plugin_manager.get_auth_plugin_mapping(), dict)
    assert len(plugin_manager.get_auth_plugin_mapping()) != 0
    return True

# Generated at 2022-06-23 19:54:01.115717
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_formatters_grouped()
    assert len(plugin_manager.get_formatters_grouped()) == 5
    assert plugin_manager.get_formatters_grouped()['debug'] is not None
    assert plugin_manager.get_formatters_grouped()['custom'] is not None

# Generated at 2022-06-23 19:54:05.303016
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    import httpie.plugins as plugins
    PluginManager.register(plugins.ConverterJSON, plugins.ConverterURLEncoded)

    assert PluginManager.get_converters() == [plugins.ConverterJSON, plugins.ConverterURLEncoded]



# Generated at 2022-06-23 19:54:07.740481
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) != 0

# Generated at 2022-06-23 19:54:09.322514
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pManager = PluginManager()
    pManager.load_installed_plugins()
    assert len(pManager) != 0

# Generated at 2022-06-23 19:54:14.628000
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import ConverterPlugin, FormatterPlugin

    plugins = PluginManager()
    plugins.register(ConverterPlugin, FormatterPlugin)

    assert isinstance(plugins.filter(ConverterPlugin), list)
    assert isinstance(plugins.filter(FormatterPlugin), list)


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:54:18.867258
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    instance_of_PluginManager = PluginManager()
    plugin_1 = BasePlugin
    plugin_2 = BasePlugin

    instance_of_PluginManager.register(plugin_1, plugin_2)
    assert plugin_1 in instance_of_PluginManager
    assert plugin_2 in instance_of_PluginManager

    instance_of_PluginManager.unregister(plugin_2)
    assert plugin_1 in instance_of_PluginManager
    assert plugin_2 not in instance_of_PluginManager

    instance_of_PluginManager.unregister(plugin_1)
    assert plugin_1 not in instance_of_PluginManager
    assert plugin_2 not in instance_of_PluginManager


# Generated at 2022-06-23 19:54:20.007812
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pass


# Generated at 2022-06-23 19:54:22.398498
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import JSONConverter
    plugins = PluginManager()
    plugins.register(JSONConverter)
    assert type(plugins.get_converters()[0]) == JSONConverter

# Generated at 2022-06-23 19:54:31.082160
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test group name'
    class TestFormatterPlugin2(FormatterPlugin):
        group_name = 'test group name'
    class TestFormatterPlugin3(FormatterPlugin):
        group_name = 'test group name2'
    plugin_manager = PluginManager()
    plugin_manager.register(TestFormatterPlugin, TestFormatterPlugin2, TestFormatterPlugin3)
    assert plugin_manager.get_formatters_grouped() == {'test group name': [TestFormatterPlugin, TestFormatterPlugin2], 'test group name2': [TestFormatterPlugin3]}

# Generated at 2022-06-23 19:54:32.890953
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    assert manager.get_formatters() == []


# Generated at 2022-06-23 19:54:36.543664
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # Test the method get_formatters_grouped
    assert plugin_manager.get_formatters_grouped() == {
        # group_name: [<FormatterPlugin>]
    }

# Generated at 2022-06-23 19:54:46.070008
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    a = PluginManager()
    print(a)
    assert str(a) == '<PluginManager: []>'
    a.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    print(a)
    assert str(a) == '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>, <class \'httpie.plugins.base.FormatterPlugin\'>, <class \'httpie.plugins.base.ConverterPlugin\'>, <class \'httpie.plugins.base.TransportPlugin\'>]>'
    print('Test method __repr__ for class PluginManager successfully!')
    print()



# Generated at 2022-06-23 19:54:48.866217
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.register(OAuth1AuthPlugin, OAuth2AuthPlugin)
    assert set(manager.get_auth_plugins()) == {OAuth1AuthPlugin, OAuth2AuthPlugin}

# Generated at 2022-06-23 19:54:51.595534
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    assert isinstance(manager, PluginManager)

if __name__ == '__main__':
    test_PluginManager()

# Generated at 2022-06-23 19:54:54.418471
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins import httpie_plugins
    assert httpie_plugins.get_auth_plugin_mapping() == {'basic': HTTPBasicAuth}

# Generated at 2022-06-23 19:54:57.141391
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register()
    assert plugin_manager == []



# Generated at 2022-06-23 19:54:59.449524
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    r = PluginManager()
    plugins = ['httpie.plugins.test']
    r.register(*plugins)
    assert plugins == r

# Generated at 2022-06-23 19:55:00.499225
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()

# Generated at 2022-06-23 19:55:01.855133
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert isinstance(PluginManager(), PluginManager)



# Generated at 2022-06-23 19:55:03.872416
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'
    assert isinstance(plugins, list)


# Generated at 2022-06-23 19:55:08.008721
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugin_manager.register(entry_point.load())
    assert plugin_manager.get_formatters()


# Generated at 2022-06-23 19:55:11.976946
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'


# List of plugins registered with the plugin manager.
plugins = PluginManager()

# Generated at 2022-06-23 19:55:18.476856
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from inspect import signature
    from pkg_resources import iter_entry_points
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    for entry_point in iter_entry_points('httpie.plugins.auth.v1'):
        plugin = entry_point.load()
    test_class = type(plugin)
    test_manager = PluginManager()
    expected = f'<PluginManager: [{test_class}]>'
    assert str(test_manager.register(test_class)) == expected
    assert str(test_manager) == expected

# Generated at 2022-06-23 19:55:21.664467
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager.get_auth_plugins()) == 5



# Generated at 2022-06-23 19:55:24.630471
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = []
    assert set(plugins) == set()
    plugins.register(1, 2)
    assert set(plugins) == set([1, 2])



# Generated at 2022-06-23 19:55:29.145918
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    import httpie.plugins.converter.json as json
    plugin_manager.register(json)
    flag = True
    for plugin in plugin_manager:
        flag = flag and issubclass(plugin, BasePlugin)
    assert flag


# Generated at 2022-06-23 19:55:30.702636
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register()
    print(plugins)


# Generated at 2022-06-23 19:55:36.500552
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(
        type(str.__str__),
        type(str.__str__),
        TestPlugin,
        type(TestPlugin)
    )

# Generated at 2022-06-23 19:55:47.425132
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Basic use cases
    pm = PluginManager()
    pm.register(FormatterPlugin, FormatterPlugin)
    assert pm.get_formatters_grouped() == {'FormatterPlugin': [FormatterPlugin]}

    pm = PluginManager()
    pm.register(FormatterPlugin, FormatterPlugin, FormatterPlugin)
    assert pm.get_formatters_grouped() == {'FormatterPlugin': [FormatterPlugin, FormatterPlugin, FormatterPlugin]}

    # Multiple type of formatters
    pm = PluginManager()
    pm.register(FormatterPlugin, FormatterPlugin, FormatterPlugin)
    pm.register(FormatterPlugin)
    assert pm.get_formatters_grouped() == {'FormatterPlugin': [FormatterPlugin, FormatterPlugin, FormatterPlugin, FormatterPlugin]}

# Generated at 2022-06-23 19:55:55.497171
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    manager.register(
        HTTPBasicAuth,
        HTTPBasicAuth,
        HTTPBasicAuth,
        HTTPBasicAuth,
    )
    assert repr(manager) == '<PluginManager: [<class \'httpie.plugins.auth.basic_auth.HTTPBasicAuth\'>, <class \'httpie.plugins.auth.basic_auth.HTTPBasicAuth\'>, <class \'httpie.plugins.auth.basic_auth.HTTPBasicAuth\'>, <class \'httpie.plugins.auth.basic_auth.HTTPBasicAuth\'>]>'


# Generated at 2022-06-23 19:55:57.975730
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    pm.register(BasePlugin)
    assert pm.filter() == [BasePlugin]
    pm.unregister(BasePlugin)
    assert pm.filter() == []

# Generated at 2022-06-23 19:55:59.710508
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'

# Generated at 2022-06-23 19:56:02.493495
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert (len(pm) == 1)
    pm.unregister(AuthPlugin)
    assert (len(pm) == 0)


# Generated at 2022-06-23 19:56:04.936211
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class TestPlugin(BasePlugin):
        pass
    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin)
    plugin_manager.unregister(TestPlugin)
    assert plugin_manager == []

# Generated at 2022-06-23 19:56:06.054025
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()


# Generated at 2022-06-23 19:56:08.877295
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    assert(pm.get_auth_plugin("basic") == None)
    pm.register(AuthPlugin)
    assert(pm.get_auth_plugin("basic") == AuthPlugin)



# Generated at 2022-06-23 19:56:11.041660
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert pm.get_transport_plugins() == []
    pm.register(TransportPlugin)
    assert pm.get_transport_plugins() == [TransportPlugin]



# Generated at 2022-06-23 19:56:12.771870
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(PluginManager)
    assert PluginManager in plugin_manager
    plugin_manager.unregister(PluginManager)
    assert PluginManager not in plugin_manager

# Generated at 2022-06-23 19:56:18.339332
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, JSONFPrettyFormatter

    plugins = [HTTPBasicAuth, JSONFPrettyFormatter]
    plugins = PluginManager(plugins)

    assert plugins.filter(AuthPlugin) == [HTTPBasicAuth]
    assert plugins.filter(FormatterPlugin) == [JSONFPrettyFormatter]
    assert plugins.filter(BasePlugin) == plugins


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:56:25.981065
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert {
        'basic': httpie.plugins.basic_auth.BasicAuthPlugin,
        'digest': httpie.plugins.digest_auth.DigestAuthPlugin,
        'hmac': httpie.plugins.hmac_auth.HMACAuthPlugin,
        'ntlm': httpie.plugins.ntlm_auth.NTLMAuthPlugin,
    } == manager.get_auth_plugin_mapping()

# Generated at 2022-06-23 19:56:27.818007
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    PluginManager.get_converters()


# Generated at 2022-06-23 19:56:31.154019
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugins() != []


# Generated at 2022-06-23 19:56:34.951990
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    plugin = None
    assert not manager
    manager.register(plugin)
    assert manager
    manager.unregister(plugin)
    assert not manager

# Generated at 2022-06-23 19:56:36.424096
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert isinstance(plugins, list)


# Generated at 2022-06-23 19:56:40.239508
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_mgr = PluginManager()
    plugin_mgr.load_installed_plugins()
    assert isinstance(plugin_mgr.get_converters(), list)


# Generated at 2022-06-23 19:56:47.768996
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plm = PluginManager()
    plm.register(AuthPlugin)
    plm.register(ConverterPlugin)
    assert plm.get_auth_plugins() == [AuthPlugin]
    assert plm.get_auth_plugin_mapping() == {'http': AuthPlugin}
    assert plm.get_auth_plugin('http') == AuthPlugin
    assert plm.get_converters() == [ConverterPlugin]


# Generated at 2022-06-23 19:56:50.951029
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins.get_transport_plugins()) == 1

PLUGINS = PluginManager()
PLUGINS.load_installed_plugins()

# Generated at 2022-06-23 19:56:55.801824
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugins = plugin_manager.get_auth_plugins()
    # Test if the plugins are correctly loaded
    assert len(plugins) == 2
    # Test if the plugin can be found using its name
    plugins['AWS']

# Generated at 2022-06-23 19:56:57.436769
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():

    # Test exception
    # raise Exception('Test case not implemented!')
    pass


# Generated at 2022-06-23 19:57:00.863470
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import core

    pm = PluginManager()
    pm.register(core.JsonPlugin, core.ImagesPlugin)

    assert pm.get_formatters_grouped() == {
        'json': [core.JsonPlugin],
        'images': [core.ImagesPlugin],
    }

# Generated at 2022-06-23 19:57:03.747337
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_mapping = PluginManager().get_auth_plugin_mapping()
    assert not auth_mapping

# Generated at 2022-06-23 19:57:05.502665
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(BasePlugin)
    assert [BasePlugin] == manager


# Generated at 2022-06-23 19:57:14.922535
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    """
    test sample:
        Dict[str, Dict[str, List[str]]]
    """
    plugin_manager = PluginManager()
    plugin_manager.register(plug1, plug2)

    plugins_mapping = dict()
    for plugin in plugin_manager:
        # new dict by key, get old dict by key of the new dict, or create a new one
        plugins_mapping[plugin.group_name] = plugins_mapping.get(plugin.group_name, dict())
        # new dict by key, get old dict by key of the new dict, or create a new one
        plugins_mapping[plugin.group_name][plugin.display_name] = plugins_mapping[plugin.group_name].get(plugin.display_name, list())

# Generated at 2022-06-23 19:57:18.576203
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    pm.register(Mock())
    assert pm == [Mock]
    pm.register(Mock())
    assert pm == [Mock, Mock]


# Generated at 2022-06-23 19:57:20.957566
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    x=PluginManager()
    x.load_installed_plugins()
    # print(x)
    print(x.get_auth_plugin_mapping())


# Generated at 2022-06-23 19:57:23.948688
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    PluginManager().register(*plugins)
    repr_str = repr(PluginManager())
    assert repr_str == f'<PluginManager: {list(plugins)}>'


# Generated at 2022-06-23 19:57:25.746664
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.append(TransportPlugin)
    assert plugins.get_transport_plugins() == [TransportPlugin]


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:57:27.449724
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0 and isinstance(plugin_manager[0], type)

# Generated at 2022-06-23 19:57:29.702412
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert(pm.get_transport_plugins() == [])
    pm.register(TransportPlugin)
    assert(pm.get_transport_plugins() == [TransportPlugin])


plugins = PluginManager()

# Generated at 2022-06-23 19:57:31.547751
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginmanager = PluginManager()
    assert repr(pluginmanager) == "<PluginManager: []>"

# Generated at 2022-06-23 19:57:32.967859
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    p=PluginManager()
    assert p.unregister==[].remove



# Generated at 2022-06-23 19:57:34.032459
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager.register(PluginManager)


# Generated at 2022-06-23 19:57:40.003899
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D:
        pass
    pm = PluginManager()
    pm.register(A, B, C, D)
    print(pm.filter(C))
    print(pm.filter(B))
    print(pm.filter(D))
    print(pm.filter(A))

if __name__ == '__main__':
    test_PluginManager_filter()

# Generated at 2022-06-23 19:57:42.180180
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(TestPlugin)
    assert manager.get_auth_plugin('test') == TestPlugin

# Generated at 2022-06-23 19:57:46.633105
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.formatter.colors import PygmentsFormatter
    from httpie.plugins.formatter.json import JSONFormatter
    expected_formatters = [JSONFormatter, PygmentsFormatter]
    plugin_manager = PluginManager()
    plugin_manager.register(*expected_formatters)
    assert expected_formatters == plugin_manager.get_formatters

# Generated at 2022-06-23 19:57:50.234474
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    a_plugin_manager = PluginManager()
    assert a_plugin_manager.get_auth_plugins() == []


# Generated at 2022-06-23 19:57:52.572409
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    assert plugins.get_formatters() == list()



# Generated at 2022-06-23 19:57:57.319363
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(TestFormatterPlugin1)
    plugin_manager.register(TestFormatterPlugin2)
    plugin_manager.register(TestFormatterPlugin3)

    result = plugin_manager.get_formatters_grouped()
    print(result)


# Generated at 2022-06-23 19:57:58.672260
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager().get_formatters() == None


# Generated at 2022-06-23 19:58:02.757834
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    def auth1_plugin(a, b):
        pass

    auth1_plugin.auth_type = 'auth1'
    auth2_plugin = lambda a, b: print(a, b)
    auth2_plugin.auth_type = 'auth2'

    pm = PluginManager()
    pm.register(auth1_plugin, auth2_plugin)

    mapping = pm.get_auth_plugin_mapping()
    assert mapping['auth1'] is auth1_plugin
    assert mapping['auth2'] is auth2_plugin
    assert len(mapping) == 2


# Generated at 2022-06-23 19:58:12.859361
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    print(plugin_manager.get_transport_plugins())
    print(plugin_manager.get_converters())
    plugin_manager.load_installed_plugins()
    print(plugin_manager.get_formatters())
    print(plugin_manager.get_formatters_grouped())
    print(plugin_manager.get_auth_plugins())
    print(plugin_manager.get_auth_plugin('basic'))
    print(plugin_manager.get_auth_plugin_mapping())
    print(plugin_manager.get_transport_plugins())
    print(plugin_manager.get_converters())
    
if __name__ == '__main__':
    test_PluginManager_get_transport_plugins()

# Generated at 2022-06-23 19:58:18.980247
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():

    from httpie.input import KeyValueArg
    from httpie.plugins.auth import AuthPlugin
    from httpie.plugins.auth.basic import BasicAuth
    from httpie.plugins.auth.digest import DigestAuth
    from httpie.plugins.auth.plugin import AuthPluginCommand
    from httpie.plugins.auth.plugin import get_auth_plugin_kwargs

    from httpie.plugins.auth.builtin import BuiltinAuthPlugin
    from httpie.compat import urlsplit, parse_auth

    basic_auth = BasicAuth()
    digest_auth = DigestAuth()

    # Input argument
    args = []

    # Input Key Value
    kwargs = {}
    kwargs['username'] = 'admin'
    kwargs['password'] = 'admin'

    # Get Auth

# Generated at 2022-06-23 19:58:23.125045
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print("plugins:", plugins)
    print("plugins.get_auth_plugins():", plugins.get_auth_plugins())
    assert len(plugins) == len(plugins.get_auth_plugins())


# Generated at 2022-06-23 19:58:27.817863
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    manager.register()
    formatters = {'json': 'JsonFormatter', 'prettyjson': 'PrettyJsonFormatter'}
    assert formatters['json'] in {format(formatter) for formatter in manager.get_formatters()}
    assert formatters['prettyjson'] in {format(formatter) for formatter in manager.get_formatters()}

# Generated at 2022-06-23 19:58:29.684356
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert pluginManager.get_auth_plugin("basic")



# Generated at 2022-06-23 19:58:32.381226
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    import httpie_credentials
    plugin_manager = PluginManager()
    plugin_manager.register(httpie_credentials.CredentialsPlugin)
    assert plugin_manager.get_auth_plugin_mapping().keys() == {'credentials'}

# Generated at 2022-06-23 19:58:43.175271
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from hypothesis import given
    from hypothesis.strategies import integers
    import hypothesis.strategies as st
    
    class TestPluginManager(PluginManager):
        def __init__(self):
            PluginManager.__init__(self)
            self.append(5)
            self.append(5)

        def register(self, *plugins: Type[BasePlugin]):
            for plugin in plugins:
                self.append(plugin)

        def unregister(self, plugin: Type[BasePlugin]):
            self.remove(plugin)

        def filter(self, by_type=Type[BasePlugin]):
            return [plugin for plugin in self if issubclass(plugin, by_type)]


# Generated at 2022-06-23 19:58:47.431955
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins import ConverterPlugin, FormatterPlugin
    assert issubclass(ConverterPlugin, BasePlugin)
    plugin_manager = PluginManager()
    plugin_manager.register(ConverterPlugin)
    plugin_manager.register(FormatterPlugin)
    converters = plugin_manager.get_converters()
    assert len(converters) == 1
    assert converters == [ConverterPlugin]

# Generated at 2022-06-23 19:58:50.977516
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager.__dict__['get_converters'].__doc__ == '''
        Return a list of plugins of type ConverterPlugin.
    '''

# Generated at 2022-06-23 19:58:53.501401
# Unit test for constructor of class PluginManager
def test_PluginManager():
    """
    Test PluginManager constructor
    """
    pm = PluginManager()
    assert pm == []
    assert pm.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-23 19:58:57.002057
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager_get_auth_plugins = PluginManager()
    PluginManager_get_auth_plugins.register()
    assert PluginManager_get_auth_plugins.get_auth_plugins() == []
    

# Generated at 2022-06-23 19:58:58.089328
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PM = PluginManager()
    PM.register(TestPlugin)


# Generated at 2022-06-23 19:59:05.002785
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.converter import ForcedConverter
    from httpie.plugins.converter.json import JSONConverter
    from httpie.plugins.converter.jsonraw import JSONRawConverter
    from httpie.plugins.converter.jsonlines import JSONLinesConverter
    from httpie.plugins.converter.form import FormConverter
    from httpie.plugins.converter.xml import XMLConverter
    from httpie.plugins.converter.yaml import YAMLConverter

    plugin_manager = PluginManager()


# Generated at 2022-06-23 19:59:06.003173
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    PluginManager.get_auth_plugin_mapping()

# Generated at 2022-06-23 19:59:06.516166
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pass

# Generated at 2022-06-23 19:59:10.813241
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(ConverterPlugin)
    assert AuthPlugin in plugins.filter()
    assert FormatterPlugin in plugins.filter()
    assert ConverterPlugin in plugins.filter()
    assert AuthPlugin in plugins.filter(AuthPlugin)

# Generated at 2022-06-23 19:59:12.424876
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    plugins = pm.get_converters()
    assert len(plugins) > 0


# Generated at 2022-06-23 19:59:16.364890
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    PluginManager1 = PluginManager()
    assert PluginManager1.__repr__() == '<PluginManager: []>'
# Other tests will be completed after the development of class PluginManager is completed

# Generated at 2022-06-23 19:59:21.379380
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie import __version__
    from httpie.plugins.builtin import JSONFormatter, PrettyJsonFormatter
    pm = PluginManager()
    pm.register(JSONFormatter, PrettyJsonFormatter)
    assert pm.get_formatters_grouped() == {'format': [JSONFormatter,
                                                      PrettyJsonFormatter]}

# Generated at 2022-06-23 19:59:26.908982
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert repr(PluginManager()) == '<PluginManager: []>'
    plugins = [
        mock.Mock(name='first'),
        mock.Mock(name='second'),
    ]
    manager = PluginManager(plugins)
    assert list(manager) == plugins
    # __getitem__
    assert manager[0] == plugins[0]
    # len
    assert len(manager) == 2



# Generated at 2022-06-23 19:59:28.736437
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert PluginManager.get_formatters(PluginManager()) == []
    assert PluginManager().get_formatters() == []


# Generated at 2022-06-23 19:59:37.788832
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # set up
    from httpie.plugins import FormatterPlugin
    from httpie.output.formatters.json import JsonFormatter
    from httpie.output.formatters.colors import ColorsFormatter
    from httpie.output.formatters.pretty import PrettyFormatter
    from httpie.output.formatters.html import HtmlFormatter
    plugin_manager = PluginManager()
    plugin_manager.register(JsonFormatter, ColorsFormatter, PrettyFormatter, HtmlFormatter)
    # test
    assert plugin_manager.get_formatters_grouped()['output'] == [JsonFormatter]
    assert plugin_manager.get_formatters_grouped()['format'] == [ColorsFormatter, PrettyFormatter]

# Generated at 2022-06-23 19:59:41.799205
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # create an instance of class PluginManager
    plugin_mgr = PluginManager()
    # invoke method load_installed_plugins to load installed plugins from
    # dataset entry points
    plugin_mgr.load_installed_plugins()
    # check if number of plugins is more than zero
    assert len(plugin_mgr) > 0

# Generated at 2022-06-23 19:59:44.395198
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    for p in pm.get_formatters():
        print(p)



# Generated at 2022-06-23 19:59:47.040092
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()



# Generated at 2022-06-23 19:59:52.241143
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    import httpie.plugins
    assert httpie.plugins.get_converters(), 'get_converters is empty'

    from httpie.plugins import ConverterPlugin
    assert isinstance(httpie.plugins.get_converters(), list)
    assert issubclass(httpie.plugins.get_converters()[0], ConverterPlugin)


# Generated at 2022-06-23 19:59:59.624762
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    assert list(manager) == [], f'Manager should be empty -> {list(manager)}'
    manager.register(TransportPlugin)
    assert list(manager) == [TransportPlugin], f"Manager should have one element -> {list(manager)}"
    assert manager.get_transport_plugins() == [TransportPlugin], f"Manager should have one transport plugin -> {manager.get_transport_plugins()}"
test_PluginManager_get_transport_plugins()

# Generated at 2022-06-23 20:00:06.204202
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm=PluginManager()

    pm.register(JSONFormatter)
    pm.register(PrettyFormatter)
    pm.register(ColoredFormatter)
    pm.register(ProfilingFormatter)

    # check the number of formatters that should be registered
    assert len(pm.get_formatters())==4

    # check if the formatters are listed
    assert JSONFormatter in pm.get_formatters()
    assert PrettyFormatter in pm.get_formatters()
    assert ColoredFormatter in pm.get_formatters()
    assert ProfilingFormatter in pm.get_formatters()


# Generated at 2022-06-23 20:00:09.535747
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    fakePlugin = BasePlugin
    fakeManager = PluginManager()
    fakeManager.append(fakePlugin)
    assert(fakePlugin in fakeManager)
    fakeManager.unregister(fakePlugin)
    assert(fakePlugin not in fakeManager)

# Generated at 2022-06-23 20:00:12.398007
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Arrange
    manager = PluginManager()
    manager.register(Bar, Foo)
    # Act
    result = manager.filter(Foo)
    print(result)
    # Assert
    assert result == [Foo]


# Generated at 2022-06-23 20:00:15.014206
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    tmp = len(pluginManager)
    pluginManager.unregister(AuthPlugin)
    assert len(pluginManager) == tmp - 1

# Generated at 2022-06-23 20:00:24.759828
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
	s = PluginManager()
	class A(BasePlugin):
		name = "name"
	class B(BasePlugin):
		name = "name"
	class C(BasePlugin):
		name = "name"
	class D(BasePlugin):
		name = "name"
	class E(BasePlugin):
		name = "name"
	class F(BasePlugin):
		name = "name"

	s.register(A, B, C, D, E, F)
	assert len(s) == 6
	s.unregister(B)
	assert len(s) == 5
	assert A in s
	assert B not in s
	assert C in s
	assert D in s
	assert E in s
	assert F in s


# Generated at 2022-06-23 20:00:26.512412
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin)
    assert pluginManager[0] == AuthPlugin


# Generated at 2022-06-23 20:00:28.100248
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins=PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_formatters() == []


# Generated at 2022-06-23 20:00:30.222588
# Unit test for constructor of class PluginManager
def test_PluginManager():
    a=PluginManager()
    a.load_installed_plugins()
    print(a)

if __name__ == '__main__':
    test_PluginManager()

# Generated at 2022-06-23 20:00:37.038214
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm.register == [AuthPlugin, FormatterPlugin, ConverterPlugin]
    assert pm.unregister == [AuthPlugin, FormatterPlugin, ConverterPlugin]
    assert pm.filter == [
        AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    assert pm.get_auth_plugins == [AuthPlugin]
    assert pm.get_auth_plugin_mapping == [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    assert pm.get_auth_plugin == [AuthPlugin]
    assert pm.get_formatters == [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    assert pm.get_formatters_grouped == [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]

# Generated at 2022-06-23 20:00:47.420094
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluauth = PluginManager()
    pluauth.register(httpie.plugins.auth.aws.AWSv4AuthPlugin)
    pluauth.register(httpie.plugins.auth.aws.AWSAuthPlugin)
    pluauth.register(httpie.plugins.auth.aws.AWSv2AuthPlugin)
    pluauth.register(httpie.plugins.auth.aws.AWSRestAuthPlugin)
    pluauth.register(httpie.plugins.auth.aws.AWSRestAuthPlugin)
    pluauth.register(httpie.plugins.auth.aws.AWSRestAuthPlugin)
    a = pluauth.get_auth_plugin_mapping()
    assert len(a) == 4
    assert type(a) == dict
    assert 'awsv4' in a

# Generated at 2022-06-23 20:00:53.296806
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    pm.register()
    pm.unregister()
    pm.filter()
    pm.load_installed_plugins()
    pm.get_auth_plugins()
    pm.get_auth_plugin_mapping()
    pm.get_auth_plugin('Basic')
    pm.get_formatters()
    pm.get_formatters_grouped()
    pm.get_converters()
    pm.get_transport_plugins()
    pm.__repr__()