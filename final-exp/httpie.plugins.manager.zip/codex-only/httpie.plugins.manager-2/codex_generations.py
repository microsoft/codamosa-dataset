

# Generated at 2022-06-23 19:50:50.423396
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import JSONPathFormatter
    from httpie.plugins.builtin import JSONPointerFormatter
    from httpie.plugins.builtin import CSVFormatter
    manager = PluginManager()
    manager.register(JSONPathFormatter, JSONPointerFormatter, CSVFormatter)
    assert manager.get_formatters() == [JSONPathFormatter, JSONPointerFormatter, CSVFormatter]

# Generated at 2022-06-23 19:50:55.800918
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    import httpie.plugins.builtin
    manager = PluginManager()
    manager.register(httpie.plugins.builtin.BasicAuthPlugin)
    assert manager.get_auth_plugin('basic') == httpie.plugins.builtin.BasicAuthPlugin


# Generated at 2022-06-23 19:50:59.931225
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin(BasePlugin): pass

    list = []
    list.append(Plugin)

    # if Plugin exist in list
    if list.count(Plugin) != 0:
        list.remove(Plugin)
        assert list == []


# Generated at 2022-06-23 19:51:09.937783
# Unit test for method get_transport_plugins of class PluginManager

# Generated at 2022-06-23 19:51:12.348272
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    plugins.register(PluginManager)
    assert repr(plugins) == "<PluginManager: [<class 'httpie.plugins.manager.PluginManager'>]>"



# Generated at 2022-06-23 19:51:15.589278
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    pluginManager.register(ConverterPlugin)
    converters = pluginManager.get_converters()
    assert converters == [ConverterPlugin]

# Generated at 2022-06-23 19:51:19.309684
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    '''
    This unit test test the method get_formatters of class PluginManager
    To run the test we need to include some assertions
    '''
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_formatters()

# Generated at 2022-06-23 19:51:28.770238
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin
    from httpie.plugins.http import HTTPBasicAuth
    from httpie.plugins.httpie import HTTPiePlugin
    from httpie.plugins.json import JSONFormatterPlugin
    from httpie.plugins.terminal_output import TerminalFormatter
    from httpie.plugins.local_auth import LocalAuthPlugin
    from httpie.plugins.aws_auth import AWSPlugin
    from httpie.plugins.awslocal_auth import AWSLocalAuthPlugin
    from httpie.plugins.multipart import MultipartFormData
    from httpie.plugins.pretty import PrettyJSON
    from httpie.plugins.pretty_xml import PrettyXML
    from httpie.plugins.json_kafka import JSONToKafka

# Generated at 2022-06-23 19:51:30.115230
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    assert plugins.filter(Type[BasePlugin]) == plugins


# Generated at 2022-06-23 19:51:37.781162
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import FormatterPlugin
    from io import TextIOWrapper
    from httpie.compat import is_py26
    from httpie.output.streams import write_to_stdout, write_to_stderr

    class TextIOWrapper_26(TextIOWrapper):
        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass
        
    class TestFormatter(FormatterPlugin):
        """Formatter plugin for testing mypymy."""

        group_name = 'test'
        group_description = 'test'
        output_stream_class = TextIOWrapper_26 if is_py26 else TextIOWrapper

# Generated at 2022-06-23 19:51:40.212302
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    assert len(p) == 0
    assert p.__repr__() == '<PluginManager: []>'

manager = PluginManager()

# Generated at 2022-06-23 19:51:45.872842
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins_list: List[Type[BasePlugin]] = []
    plugins_list.append(BasePlugin)
    plugins_list.append(AuthPlugin)
    def get_auth_plugin_mapping():
        return {plugin.auth_type: plugin for plugin in self.get_auth_plugins()}
    assert get_auth_plugin_mapping() == {}


# Generated at 2022-06-23 19:51:53.442084
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters = plugin_manager.get_formatters()
    assert formatters[0].__name__ == 'JSONFormatter'
    assert formatters[1].__name__ == 'PrettyJSONFormatter'
    assert formatters[2].__name__ == 'TableFormatter'
    assert formatters[3].__name__ == 'ColorsFormatter'

# Generated at 2022-06-23 19:51:55.246586
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p = PluginManager()
    assert p == []
    assert isinstance(p, PluginManager)



# Generated at 2022-06-23 19:52:01.010678
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    installed_plugins_before = sys.modules.get('httpie.plugins')
    pm = PluginManager()
    entries_before = sys.modules.copy()
    pm.load_installed_plugins()
    entries_after = sys.modules.copy()
    assert(len(entries_after) > len(entries_before))
    for entry in entries_before:
        assert(entry in entries_after)
    for entry in entries_after:
        assert(entry in entries_before or entry.startswith('httpie.plugins'))
    installed_plugins_after = sys.modules.get('httpie.plugins')
    assert(installed_plugins_before != installed_plugins_after)


# Generated at 2022-06-23 19:52:03.260882
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_transport_plugins()) == 0
    # TODO: add more tests


# Generated at 2022-06-23 19:52:11.788469
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.register(H2cTransport)
    manager.register(UnixSocketTransport)
    manager.register(H2Transport)
    manager.register(HttpTransport)
    manager.register(HttpsTransport)
    manager.register(Plugin)
    manager.register(HttpbinTransport)
    manager.register(FileTransport)
    manager.register(FormatterPlugin)
    manager.register(RemoteTransport)

    # get_converters method returns only plugins of types inherited from class ConverterPlugin
    # In this case the list should be empty
    assert manager.get_converters() == []



# Generated at 2022-06-23 19:52:21.391702
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.transport import TransportPlugin
    from httpie.utils import get_response_info_dict

    class EchoTransportPlugin(TransportPlugin):
        scheme = 'echo'

        def get_response(self, request):
            return request.url

        def get_response_info(self, response, request):
            return get_response_info_dict(
                request=request,
                response=response,
                code=200,
                reason='OK',
                content_type='',
                headers=[],
                charset='utf-8',
                history=[]
            )

    class HashTransportPlugin(TransportPlugin):
        scheme = 'hash'

        def get_response(self, request):
            return request.url

        def get_response_info(self, response, request):
            return get_response

# Generated at 2022-06-23 19:52:22.957968
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pluginManager = PluginManager()
    plugins = pluginManager.filter()
    print(plugins)

# Generated at 2022-06-23 19:52:29.170318
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    import httpie.plugins.builtin
    plugin_manager = PluginManager()
    plugin_manager.register(httpie.plugins.builtin.AbstractFormatter)
    plugin_manager.register(httpie.plugins.builtin.HTMLFormatter)
    plugin_manager.register(httpie.plugins.builtin.JSONFormatter)

    assert(plugin_manager.get_formatters() == [httpie.plugins.builtin.AbstractFormatter,httpie.plugins.builtin.HTMLFormatter,httpie.plugins.builtin.JSONFormatter])


# Generated at 2022-06-23 19:52:30.734273
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert plugin_manager.filter() == []


# Generated at 2022-06-23 19:52:35.258040
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins import TransportPlugin
    from httpie.tls import crypto_backend, CryptoBackend
    pm = PluginManager()
    pm.register(crypto_backend)
    assert len(pm.get_transport_plugins()) == 1
    assert isinstance(pm.get_transport_plugins()[0], type)
    assert issubclass(pm.get_transport_plugins()[0], TransportPlugin)

# Generated at 2022-06-23 19:52:38.581315
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    return plugin_manager

# Generated at 2022-06-23 19:52:43.029233
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    pm_length_before = len(plugin_manager)
    auth_plugin = AuthPlugin()
    plugin_manager.register(auth_plugin)
    plugin_manager.unregister(auth_plugin)
    assert len(plugin_manager) == pm_length_before

# Generated at 2022-06-23 19:52:48.828204
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugin_1 = type('BasePlugin', (BasePlugin,), {})
    plugin_2 = type('BasePlugin', (BasePlugin,), {})
    plugins.register(plugin_1, plugin_2)
    assert plugins == [plugin_1, plugin_2]


# Generated at 2022-06-23 19:52:51.901384
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager=PluginManager()
    if plugin_manager.__repr__()=='<PluginManager: []>':
        assert True
    else:
        assert False

# Generated at 2022-06-23 19:52:54.467912
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    assert plugin_manager.get_formatters() == [FormatterPlugin, FormatterPlugin]

# Generated at 2022-06-23 19:52:58.324861
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    m = PluginManager()
    class TestPlugin(BasePlugin):
        pass
    m.register(TestPlugin)
    assert isinstance(m[0], type)
    assert str(m[0]) == "<class '__main__.TestPlugin'>"



# Generated at 2022-06-23 19:53:04.126678
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONPathFormatterPlugin, JSONLinesFormatterPlugin
    from httpie.output.streams import HTTPResponse

    pm = PluginManager()
    pm.register(JSONPathFormatterPlugin)
    pm.register(JSONLinesFormatterPlugin)

    response_headers = {
        'content-encoding': 'gzip',
        'content-type': 'application/json',
        'content-length': '77',
        'Vary': 'Accept-Encoding',
        'Server': 'twisted',
        'Date': 'Sun, 12 May 2019 05:20:06 GMT',
        'Connection': 'keep-alive'
    }


# Generated at 2022-06-23 19:53:08.787216
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    assert isinstance(pm, list)
    assert isinstance(pm, PluginManager)


if __name__ == '__main__':
    try:
        test_PluginManager_get_formatters_grouped()
    except AssertionError:
        pass

# Generated at 2022-06-23 19:53:14.180042
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Arrange
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import DigestAuthPlugin

    plugins = [DigestAuthPlugin]
    plugin_manager = PluginManager()

    for plugin in plugins:
        plugin_manager.register(plugin)

    # Act
    result = plugin_manager.get_auth_plugin('digest')

    # Assert
    assert isinstance(result, AuthPlugin)



# Generated at 2022-06-23 19:53:23.294466
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class GroupA(FormatterPlugin):
        group_name = 'Group A'

    class GroupB(FormatterPlugin):
        group_name = 'Group B'

    class GroupC(FormatterPlugin):
        group_name = 'Group C'

    class GroupA1(FormatterPlugin):
        group_name = 'Group A'

    class GroupA2(FormatterPlugin):
        group_name = 'Group A'

    pm = PluginManager()
    pm.register(GroupA, GroupB, GroupC, GroupA1, GroupA2)
    expected_result = {
        'Group A': [GroupA1, GroupA2],
        'Group B': [GroupB],
        'Group C': [GroupC],
    }
    assert pm.get_formatters_grouped() == expected_result

# Generated at 2022-06-23 19:53:27.692612
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'default'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'default'
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'other'
    manager = PluginManager()
    manager.register(FormatterPlugin1, FormatterPlugin2, FormatterPlugin3)
    assert manager.get_formatters_grouped() == {
        'default': [FormatterPlugin1, FormatterPlugin2],
        'other': [FormatterPlugin3]
    }

# Generated at 2022-06-23 19:53:29.209215
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert plugin_manager == []

# Generated at 2022-06-23 19:53:33.150555
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pl = PluginManager()
    pl.register(MockTransportPlugin1, MockTransportPlugin2)
    assert pl.get_transport_plugins() == [MockTransportPlugin1, MockTransportPlugin2]


# Generated at 2022-06-23 19:53:34.503625
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# Generated at 2022-06-23 19:53:36.835263
# Unit test for constructor of class PluginManager
def test_PluginManager():
    test_PluginManager = PluginManager()
    assert test_PluginManager.__repr__() == '<PluginManager: []>'
test_PluginManager()


# Generated at 2022-06-23 19:53:39.123868
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager.get_auth_plugin_mapping(), dict)

# Generated at 2022-06-23 19:53:48.741346
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Setup of PluginManager
    plugin_manager = PluginManager()
    auth_plugin_map = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_map.keys() != 0
    # Asserts
    assert plugin_manager.get_auth_plugin('basic') == auth_plugin_map['basic']
    assert plugin_manager.get_auth_plugin('digest') == auth_plugin_map['digest']
    assert plugin_manager.get_auth_plugin('aws4hmac') == auth_plugin_map['aws4hmac']
    assert plugin_manager.get_auth_plugin('hawk') == auth_plugin_map['hawk']
    assert plugin_manager.get_auth_plugin('ntlm') == auth_plugin_map['ntlm']

# Generated at 2022-06-23 19:53:54.040142
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
	plugin_manager = PluginManager()
	plugin_manager.register(Plugin_auth_type)
	plugin_manager.register(Plugin_auth_other)
	plugin_manager_dict = {
		'auth_type' : Plugin_auth_type,
		'auth_other' : Plugin_auth_other,
	}
	assert plugin_manager.get_auth_plugin_mapping() == plugin_manager_dict

# Generated at 2022-06-23 19:53:56.111101
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager.get_formatters_grouped() == {
        'by_type': None, 'by_ext': None, 'general': None
    }

# Generated at 2022-06-23 19:54:01.705263
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0


# Generated at 2022-06-23 19:54:08.144612
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugins()
    assert plugins.get_auth_plugin_mapping()
    assert plugins.get_auth_plugin('basic')
    assert plugins.get_formatters()
    assert plugins.get_formatters_grouped()
    assert plugins.get_converters()
    assert plugins.get_transport_plugins()
    assert plugins

# Generated at 2022-06-23 19:54:11.192846
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(TestPlugin1)
    assert pm.get_transport_plugins() == [TestPlugin1]
    assert pm.get_transport_plugins()[0].name == 'TestPlugin1'


# Generated at 2022-06-23 19:54:14.728685
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert (pm.get_formatters_grouped()['auto'])

# Generated at 2022-06-23 19:54:16.262408
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    manager.register(MockBasicAuthPlugin)
    plugins = manager.get_auth_plugins()    
    assert plugins == [MockBasicAuthPlugin]


# Generated at 2022-06-23 19:54:25.025310
# Unit test for constructor of class PluginManager
def test_PluginManager():
    test_instance = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            test_instance.register(plugin)

# Generated at 2022-06-23 19:54:27.877476
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()

    # check if all the output formatters are available
    assert len(pluginManager.get_formatters()) >= 5


# Generated at 2022-06-23 19:54:30.934120
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import KerberosAuth

    pluginManager = PluginManager()
    pluginManager.register(KerberosAuth)

    assert len(pluginManager.get_auth_plugins()) == 1


# Generated at 2022-06-23 19:54:32.712666
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
  pm=PluginManager()
  assert(pm.get_auth_plugins()==list())



# Generated at 2022-06-23 19:54:37.364122
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(
        PluginManager_TestAuthPlugin1,
        PluginManager_TestAuthPlugin2,
        PluginManager_TestAuthPlugin3,
    )

    mapping = plugin_manager.get_auth_plugin_mapping()
    assert mapping["basic"] == PluginManager_TestAuthPlugin1
    assert mapping["digest"] == PluginManager_TestAuthPlugin2
    assert mapping["foo"] == PluginManager_TestAuthPlugin3


# Generated at 2022-06-23 19:54:40.979994
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.register(FormatterPlugin())
    pm.register(FormatterPlugin())
    pm.load_installed_plugins()

    assert len(pm) == 13+2


# Generated at 2022-06-23 19:54:43.032982
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_converters()

# Generated at 2022-06-23 19:54:44.728195
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(PluginAuthV1)
    plugin_manager.register(PluginAuthV1)
    assert len(plugin_manager.get_auth_plugins()) == 2


# Generated at 2022-06-23 19:54:47.481894
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-23 19:54:48.063916
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert True

# Generated at 2022-06-23 19:54:50.139906
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_transport_plugins()) > 0



# Generated at 2022-06-23 19:54:52.458932
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'

# Generated at 2022-06-23 19:55:03.782760
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(Plugin1):
        pass
    class Plugin3(Plugin2):
        pass
    class Plugin4(Plugin3):
        pass
    class Plugin5(Plugin1):
        pass
    class Plugin6(Plugin5):
        pass
    class Plugin7(BasePlugin):
        pass
    class Plugin8(Plugin7):
        pass
    class Plugin9(Plugin8):
        pass
    class Plugin10(Plugin9):
        pass

    pm = PluginManager()
    pm.register(Plugin1,Plugin2,Plugin3,Plugin4,Plugin5,Plugin6,Plugin7,Plugin8,Plugin9,Plugin10)
    assert pm.filter(by_type = Plugin1) == [Plugin1,Plugin2,Plugin3,Plugin4,Plugin5,Plugin6]

# Generated at 2022-06-23 19:55:05.661492
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(BasePlugin, AuthPlugin)
    assert manager.get_formatters_grouped() == {}

# Generated at 2022-06-23 19:55:10.105275
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(TestAuthPlugin, TestAuthPlugin2, TestConverterPlugin)
    assert pm.filter(AuthPlugin) == [TestAuthPlugin, TestAuthPlugin2]


# Generated at 2022-06-23 19:55:12.753221
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager.get_auth_plugins(), list)


# Generated at 2022-06-23 19:55:14.285469
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    manager.load_installed_plugins()
    formatters = manager.get_formatters()
    assert isinstance(formatters, list)
    assert formatters
    assert isinstance(formatters[0], type)


# Generated at 2022-06-23 19:55:16.274708
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(FakeAuthPlugin)
    assert manager.get_auth_plugin('fake') == FakeAuthPlugin


# Generated at 2022-06-23 19:55:21.324044
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
  plugin_manager = PluginManager()
  plugin_manager.load_installed_plugins()
  assert 'basic' == plugin_manager.get_auth_plugin('basic').auth_type

# Generated at 2022-06-23 19:55:23.412405
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register()
    assert list(plugins) == []


# Generated at 2022-06-23 19:55:26.589077
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    result = plugin_manager.__repr__()
    assert result
    assert isinstance(result, str)

# Generated at 2022-06-23 19:55:28.993967
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    assert pluginManager == [], 'Initialization of class PluginManager should be empty list'

# Generated at 2022-06-23 19:55:31.561340
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert (repr(plugin_manager) == f'<PluginManager: {list(plugin_manager)}>')

# Helpers for unit tests

# Generated at 2022-06-23 19:55:34.229541
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    converter_plugins = PluginManager().get_converters()
    assert(converter_plugins[1].mime_type == 'application/json')
    assert(converter_plugins[0].mime_type == 'application/x-www-form-urlencoded')
    

# Generated at 2022-06-23 19:55:35.249021
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:55:35.751445
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pass

# Generated at 2022-06-23 19:55:46.037340
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import TransportPlugin

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

    assert issubclass(plugin_manager.get_formatters()[0], FormatterPlugin)
    assert issubclass(plugin_manager.get_converters()[0], ConverterPlugin)
    assert issubclass(plugin_manager.get_transport_plugins()[0], TransportPlugin)

# Generated at 2022-06-23 19:55:48.925023
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin('basic')==httpie.plugins.BasicAuth


# Generated at 2022-06-23 19:55:52.202500
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins.get_auth_plugins()
    

# Generated at 2022-06-23 19:55:53.613534
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert isinstance(PluginManager(), list)


# Generated at 2022-06-23 19:55:56.561515
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    for p in pm:
        assert isinstance(p, BasePlugin)
    assert repr(pm) == f'<PluginManager: {list(pm)}>'

# Generated at 2022-06-23 19:56:01.041741
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    assert(len(manager) == 0)
    from httpie.plugins import formatter
    manager.register(formatter.PrettyJsonFormatter)
    assert(len(manager) == 1)
    manager.unregister(formatter.PrettyJsonFormatter)
    assert(len(manager) == 0)
    

# Generated at 2022-06-23 19:56:05.083784
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_auth_plugins()) == 0
    assert len(plugin_manager.get_formatters()) == 0
    assert len(plugin_manager.get_formatters_grouped()) == 0
    assert len(plugin_manager.get_transport_plugins()) == 0

# Generated at 2022-06-23 19:56:08.833710
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()
    assert manager.get_auth_plugins() == []
    from httpie.plugins.builtin import HTTPBasicAuth
    manager.register(HTTPBasicAuth)
    assert manager.get_auth_plugins() == [HTTPBasicAuth]



# Generated at 2022-06-23 19:56:11.207030
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(type(BasePlugin))
    plugin_manager.unregister(type(BasePlugin))
    assert len(plugin_manager)==0

# Generated at 2022-06-23 19:56:12.771868
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    p = PluginManager()
    assert {} == p.get_auth_plugin_mapping()


# Generated at 2022-06-23 19:56:17.488645
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManagerInstance = PluginManager()
    PluginManagerInstance.register(FormatterPlugin)
    PluginManagerInstance.register(FormatterPlugin)
    PluginManagerInstance.register(FormatterPlugin)
    plugin_Formatter_List = PluginManagerInstance.get_formatters()
    assert len(plugin_Formatter_List) == 3


# Generated at 2022-06-23 19:56:19.255252
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pluginManager = PluginManager()
    pluginManager.register(TransportPlugin)
    result = pluginManager.get_transport_plugins()
    print(result)



# Generated at 2022-06-23 19:56:25.424065
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    import httpie.plugins.auth as auth

    auth_plugin_manager = PluginManager()
    auth_plugin_manager.register(auth.HTBasicAuth, auth.DigestAuth)

    assert auth_plugin_manager.get_auth_plugin_mapping() == {
        'basic': auth.HTBasicAuth, 'digest': auth.DigestAuth
    }


# Generated at 2022-06-23 19:56:27.256279
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'
    plugin_manager.register(1)
    assert repr(plugin_manager) == '<PluginManager: [1]>'


# Generated at 2022-06-23 19:56:35.059980
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONStreamHtmlFormatter, JSONStreamFormatter
    pm = PluginManager()
    pm.register(JSONStreamHtmlFormatter,JSONStreamFormatter)
    formatters = pm.get_formatters()
    formatters_grouped = pm.get_formatters_grouped()
    assert len(formatters) == 2
    assert len(formatters_grouped['Builtin']) == 2
    

# Generated at 2022-06-23 19:56:40.562190
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    PluginManager.register(A,B,C,D)
    found_plugins = PluginManager.filter(A)
    assert len(found_plugins) == 3
    assert found_plugins == [B,C,D]

    found_plugins = PluginManager.filter(B)
    assert len(found_plugins) == 1
    assert found_plugins == [D]

# Generated at 2022-06-23 19:56:50.716135
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    # dummy class
    class A:
        pass

    # dummy class with base class A
    class B(A):
        pass

    # dummy class with base class A
    class C(A):
        pass

    # dummy class with base class A
    class D(A):
        pass

    for cls in [A, B, C, D]:
        plugins.register(cls)

    plugins.unregister(C)
    assert B in plugins.filter(A)
    assert D in plugins.filter(A)
    assert B in plugins.filter(A)
    assert B in plugins.filter(A)

# Generated at 2022-06-23 19:56:52.572051
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p=PluginManager

# Generated at 2022-06-23 19:56:54.046568
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 4

# Generated at 2022-06-23 19:56:55.454550
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_mgr = PluginManager()
    assert plugin_mgr

# Generated at 2022-06-23 19:56:57.081772
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager == [AuthPlugin]


# Generated at 2022-06-23 19:57:04.591301
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPPassBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPPassDigestAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPGSSAPIAuth
    from httpie.plugins.builtin import HTTPNegotiateAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPNTLMAuth
    from httpie.plugins.builtin import HTTPPassDigestAuth
    from httpie.plugins.builtin import HTTPPassDigestAuth
    from httpie.plugins.builtin import HTTPPassDigestAuth
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-23 19:57:08.292735
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    lista=[AuthPlugin,ConverterPlugin,FormatterPlugin,TransportPlugin]
    pm=PluginManager()
    pm.register(*lista)
    assert(pm.register(*lista)==[AuthPlugin,ConverterPlugin,FormatterPlugin,TransportPlugin])


# Generated at 2022-06-23 19:57:16.202980
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    plugins = pm.get_transport_plugins()
    assert plugins == [], "The return result is empty."
    class PluginA(TransportPlugin):
        name = "a"

    class PluginB(TransportPlugin):
        name = "b"

    pm.register(PluginA)
    pm.register(PluginB)
    plugins = pm.get_transport_plugins()
    assert len(plugins) == 2 and (
            plugins[0].name == "a" and plugins[1].name == "b" or
            plugins[0].name == "b" and plugins[1].name == "a"
            ), "The return result is wrong."



# Generated at 2022-06-23 19:57:21.685782
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    lst = PluginManager()
    lst.load_installed_plugins()
    d = lst.get_auth_plugin_mapping()
    assert len(d) == 5
    assert 'basic' in d
    assert 'digest' in d
    assert 'aws4-hmac-sha256' in d
    assert 'aws4-hmac-sha256-signed-headers' in d
    assert 'application-hawk' in d

# Generated at 2022-06-23 19:57:22.825779
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert plugins.filter() == []



# Generated at 2022-06-23 19:57:24.592990
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    #print(type(PluginManager.get_formatters()))
    assert(type(PluginManager.get_formatters())==type([]))



# Generated at 2022-06-23 19:57:29.127356
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
        
    from httpie.plugins.transport.httpcore import HTTPcoreTransport
    from httpie.plugins.transport.urllib3 import Urllib3Transport
    from httpie.plugins.transport.curl import CurlTransport
    manager.register(HTTPcoreTransport, Urllib3Transport, CurlTransport)
    
    assert (manager.get_transport_plugins() == [HTTPcoreTransport, Urllib3Transport, CurlTransport])

# Generated at 2022-06-23 19:57:30.322395
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_auth_plugin_mapping()) == 4

# Generated at 2022-06-23 19:57:32.356708
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert PluginManager.get_auth_plugin(PluginManager(), "basic") == "username:password"


# Generated at 2022-06-23 19:57:38.356107
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    def test_register():
        plugin_manager = PluginManager()
        plugin_manager.register(BasePlugin)
        assert BasePlugin in plugin_manager
    test_register()

    def test_unregister():
        plugin_manager = PluginManager()
        plugin_manager.register(BasePlugin)
        plugin_manager.unregister(BasePlugin)
        assert BasePlugin not in plugin_manager
    test_unregister()



# Generated at 2022-06-23 19:57:40.095186
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = PluginManager()
    assert len(plugins) == 0

# Generated at 2022-06-23 19:57:49.019868
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    # print(pm.get_formatters())
    # print(pm.get_formatters_grouped())

    # Unit test for method get_formatters_grouped of class PluginManager
    def test_PluginManager_get_formatters_grouped():
        pm = PluginManager()
        pm.load_installed_plugins()
        # print(pm.get_formatters_grouped())

    # Unit test for method get_converters of class PluginManager
    def test_PluginManager_get_converters():
        pm = PluginManager()
        pm.load_installed_plugins()
        # print(pm.get_converters())

    # Unit test for method get_auth_plugins of class PluginManager

# Generated at 2022-06-23 19:57:54.168991
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # 创建对象
    plugin_manager = PluginManager()
    # 调用方法,获取结果
    plugin_manager.load_installed_plugins()
    # 断言
    assert plugin_manager is not None


# Generated at 2022-06-23 19:57:56.777239
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin, URLEncodedFormatterPlugin)
    assert plugin_manager.get_formatters_grouped() == \
           {'json': [JSONFormatterPlugin], 'form': [URLEncodedFormatterPlugin]}

import pytest


# Generated at 2022-06-23 19:57:58.529512
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugins() == []

# Generated at 2022-06-23 19:58:02.673877
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(FormatterPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

# Generated at 2022-06-23 19:58:04.891457
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(HTTPBasicAuthPlugin)

    assert(HTTPBasicAuthPlugin == manager.get_auth_plugin_mapping()['basic'])

# Generated at 2022-06-23 19:58:09.364314
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    manager.register(AuthPlugin)

    assert manager.get_auth_plugins()[0] == AuthPlugin

    manager.unregister(AuthPlugin)
    assert manager.get_auth_plugins() == []

# Generated at 2022-06-23 19:58:17.926063
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    import httpie.compat
    import httpie.output
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import builtin

    plugin_manager = PluginManager()

    assert httpie.compat.any(
        issubclass(formatter, httpie.output.Formatter)
        for formatter in plugin_manager.get_formatters()
    )

    assert httpie.compat.any(
        issubclass(formatter, FormatterPlugin)
        for formatter in plugin_manager.get_formatters()
    )

    assert httpie.compat.any(
        issubclass(formatter, builtin.JSONFormatter)
        for formatter in plugin_manager.get_formatters()
    )


# Generated at 2022-06-23 19:58:27.937135
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    class DummyAuthPlugin(AuthPlugin):
        auth_type = 'dummy'
        auth_parse = lambda x: x
        auth_apply = lambda x, y: y

    class DummyFormatPlugin(FormatterPlugin):
        format_name = 'dummy'
        content_type = 'text/dummy'
        format_writer = lambda x, y, z: None

    class DummyConverterPlugin(ConverterPlugin):
        convert_mime_type = 'text/dummy'
        convert_from_text = lambda x: x
        convert_to_text = lambda x, y: y

    class DummyTransportPlugin(TransportPlugin):
        name = 'dummy'
        get_connection = lambda x, y, z: None
        get_connection_pool = lambda x, y, z: None

   

# Generated at 2022-06-23 19:58:29.437419
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register()
    assert plugin_manager == []


# Generated at 2022-06-23 19:58:32.411389
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.builtin import HTTPBasicAuthPlugin

    pm = PluginManager()
    assert {} == pm.get_auth_plugin_mapping()
    pm.register(HTTPBasicAuthPlugin)
    assert {'basic': HTTPBasicAuthPlugin} == pm.get_auth_plugin_mapping()



# Generated at 2022-06-23 19:58:39.144918
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins.builtin import HTTPFollowRedirectsPlugin
    pm = PluginManager()
    pm.load_installed_plugins()
    assert HTTPFollowRedirectsPlugin in pm
    assert len(pm) == len(ENTRY_POINT_NAMES)
    pm.unregister(HTTPFollowRedirectsPlugin)
    assert HTTPFollowRedirectsPlugin not in pm
    assert len(pm) == len(ENTRY_POINT_NAMES)-1

# Generated at 2022-06-23 19:58:41.931222
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()

    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) > 0
    assert plugin_manager.get_auth_plugin("basic")



# Generated at 2022-06-23 19:58:44.617594
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(ConverterPlugin)
    assert list(plugin_manager.get_converters()) == [ConverterPlugin]


# Generated at 2022-06-23 19:58:48.044271
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from .test_plugins.test_transport_plugin import AnyTransportPlugin, OtherTransportPlugin
    from httpie.core import LoadingPolicy

    plugin_manager = PluginManager()
    plugin_manager.register(AnyTransportPlugin, OtherTransportPlugin)
    assert len(plugin_manager.get_transport_plugins()) == 2


# Generated at 2022-06-23 19:58:52.060124
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    test_plugin_manager = PluginManager()
    test_plugin_manager.register(AuthPlugin)
    result1 = test_plugin_manager[-1]
    result2 = AuthPlugin
    assert result1 == result2


# Generated at 2022-06-23 19:58:54.986247
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    m = PluginManager()
    m.register(AuthPlugin)
    m.register(AuthPlugin)
    assert m.get_auth_plugin_mapping() == {
        'basic': AuthPlugin,
        'digest': AuthPlugin
    }

# Generated at 2022-06-23 19:59:04.896394
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """Simple test focusing on method get_formatters_grouped of class PluginManager."""
    
    import json
    import httpie.plugins.formatter.v1 as fv1

    class _FormatterPlugin1(fv1.FormatterPlugin):
        entries = ('A',)
        output_type = 'A'
        group_name = 'G1'

    class _FormatterPlugin2(fv1.FormatterPlugin):
        entries = ('B',)
        output_type = 'B'
        group_name = 'G1'

    class _FormatterPlugin3(fv1.FormatterPlugin):
        entries = ('C',)
        output_type = 'C'
        group_name = 'G2'


# Generated at 2022-06-23 19:59:07.855053
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin = plugin_manager.get_auth_plugin("auth")
    assert plugin == AuthPlugin


# Generated at 2022-06-23 19:59:11.811594
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    # Method get_formatters_grouped() returns dict
    assert type(manager.get_formatters_grouped()) is dict
    # Method get_formatters_grouped() returns dict
    assert type(manager.get_formatters_grouped()['Data']) is list

# Generated at 2022-06-23 19:59:13.852451
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins = plugin_manager.get_auth_plugins()
    assert len(auth_plugins) >= 3


# Generated at 2022-06-23 19:59:25.110629
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    # List of plugins
    plugins = plugin_manager.get_auth_plugins()
    assert len(plugins) == 1
    assert AuthPlugin in plugins
    # Mapping of plugins
    auth_mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(auth_mapping) == 1
    assert AuthPlugin in auth_mapping.values()
    # Get specific plugin class
    auth_class = plugin_manager.get_auth_plugin("AuthPlugin")
    assert auth_class == AuthPlugin
    # Type of plugins
    assert issubclass(auth_class, AuthPlugin)
    assert not issubclass(auth_class, FormatterPlugin)


# Generated at 2022-06-23 19:59:31.043924
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert isinstance(pm, list)
    print(pm)
    pm.register(TransportPlugin)
    pm.register(AuthPlugin)
    pm.register(ConverterPlugin)
    pm.register(FormatterPlugin)
    print(pm)
    pm.unregister(TransportPlugin)
    print(pm)
    print(pm.get_auth_plugins())
    print(pm.get_auth_plugin_mapping())
    print(pm.get_auth_plugin('digest'))
    print(pm.get_formatters())
    print(pm.get_formatters_grouped())
    print(pm.get_converters())
    print(pm.get_transport_plugins())

if __name__ == '__main__':
    test_PluginManager()

# Generated at 2022-06-23 19:59:31.800796
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()


# Generated at 2022-06-23 19:59:35.748800
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    # Empty plugin manager
    assert plugin_manager == []

    # New instance of class PluginManager
    plugin_manager_new = PluginManager()
    assert plugin_manager_new == []

    # Merge two instances of class PluginManager
    plugin_manager_new.register(plugin_manager)
    assert plugin_manager_new == []


test_PluginManager_register()



# Generated at 2022-06-23 19:59:40.372971
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(BrotliConverter)
    assert len(pm.get_converters()) == 1
    assert pm.get_converters()[0].name == 'brotli'


# Generated at 2022-06-23 19:59:43.254638
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin, BasePlugin, BasePlugin)
    print(plugin_manager, len(plugin_manager))
    plugin_manager.unregister(BasePlugin)
    print(plugin_manager)

# Generated at 2022-06-23 19:59:46.538302
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager.get_formatters_grouped(self) == {
        group_name: list(group)
        for group_name, group
        in groupby(self.get_formatters(), key=attrgetter('group_name'))
    }

# Generated at 2022-06-23 19:59:52.505305
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    converters = plugins.get_converters()
    assert converters == [
        httpie.plugins.converter.BytesConverter,
        httpie.plugins.converter.JSONConverter,
        httpie.plugins.converter.URLEncodeConverter,
        httpie.plugins.converter.JSONItemsConverter,
    ]

# Generated at 2022-06-23 19:59:57.389373
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert plugin_manager.get_converters() == []
    plugin_manager.register(BashConverterPlugin)
    assert plugin_manager.get_converters() == [BashConverterPlugin]



# Generated at 2022-06-23 20:00:01.714064
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(plugin_mapping) == 2
    assert plugin_mapping['basic'] == BasicAuthPlugin
    assert plugin_mapping['digest'] == DigestAuthPlugin


# Generated at 2022-06-23 20:00:04.900771
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_auth_plugins()) == 0
    plugin_manager.register(AuthPlugin)
    assert len(plugin_manager.get_auth_plugins()) == 1
test_PluginManager_get_auth_plugins()


# Generated at 2022-06-23 20:00:08.348572
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class MyPlugin1(BasePlugin):
        pass

    class MyPlugin2(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(MyPlugin1, MyPlugin2)
    assert plugin_manager[0] == MyPlugin1
    plugin_manager.unregister(MyPlugin1)
    assert plugin_manager[0] == MyPlugin2
# test cases
if __name__ == '__main__':
    test_PluginManager_unregister()

# Generated at 2022-06-23 20:00:11.099105
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class Plugin:
        pass
    pm.register(Plugin)
    assert Plugin in pm
    

# Generated at 2022-06-23 20:00:12.704222
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager_get_auth_plugins = PluginManager.get_auth_plugins
    manager = PluginManager()


# Generated at 2022-06-23 20:00:15.769861
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.register(PluginsTest.PluginA, PluginsTest.PluginB, PluginsTest.PluginC)
    plugin_a = plugins.get_auth_plugin(PluginsTest.PluginA.auth_type)
    assert plugin_a == PluginsTest.PluginA


# Generated at 2022-06-23 20:00:25.281740
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 20:00:32.224137
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins.builtin import JSONFlattener
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import transport
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    pm = PluginManager()
    pm.register(JSONFlattener, FormatterPlugin, transport.HTTPTransport, HTTPiePlugin, HTTPBasicAuth)
    pm.get_formatters()

    # json_flattener = JSONFlattener()
    # pm.register(json_flattener)
    # print(pm.get_formatters())

# Generated at 2022-06-23 20:00:33.231171
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager = PluginManager()
    assert PluginManager.get_formatters() is not None


# Generated at 2022-06-23 20:00:36.555962
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test'

    plugin_manager = PluginManager()
    plugin_manager.register(TestAuthPlugin)
    assert plugin_manager.get_auth_plugin('test') == TestAuthPlugin

# Generated at 2022-06-23 20:00:43.351909
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
        plugin = PluginManager()
        plugin.register(Plugins)
        plugin.register(Plugins)
        plugin.register(Plugins)
        plugin.register(Plugins)
        plugin.register(Plugins)
        plugin.register(Plugins)
        plugin.register(Plugins)
        assert plugin.filter(Type[BasePlugin]) == [BasePlugin, BasePlugin, BasePlugin, BasePlugin, BasePlugin, BasePlugin, BasePlugin]



# Generated at 2022-06-23 20:00:47.217366
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(BASIC_AUTH_PLUGIN, BEARER_TOKEN_AUTH_PLUGIN)
    assert pm.get_auth_plugins() == [BASIC_AUTH_PLUGIN, BEARER_TOKEN_AUTH_PLUGIN]
