

# Generated at 2022-06-23 19:50:49.311472
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager.get_auth_plugins()) != 0
    for plugin in plugin_manager.get_auth_plugins():
        assert issubclass(plugin, AuthPlugin)


# Generated at 2022-06-23 19:50:53.094364
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.core import HelpAuthPlugin

    plugin = HelpAuthPlugin()
    plugin_manager = PluginManager()
    plugin_manager.register(plugin)

    assert plugin == plugin_manager.filter(by_type=HelpAuthPlugin)[0]
    assert plugin == plugin_manager.filter(by_type=AuthPlugin)[0]
    assert plugin == plugin_manager.filter(by_type=BasePlugin)[0]
    assert len(plugin_manager.filter(by_type=FormatterPlugin)) == 0


# Generated at 2022-06-23 19:50:59.308997
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """Unit test for method load_installed_plugins of class PluginManager"""
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager, PluginManager)


if __name__ == "__main__":
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-23 19:51:09.368355
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    t1 = TransportPlugin()
    t2 = TransportPlugin()
    c1 = ConverterPlugin()
    c2 = ConverterPlugin()
    f1 = FormatterPlugin()
    f2 = FormatterPlugin()
    a1 = AuthPlugin()
    a2 = AuthPlugin()
    manager_list = list()
    manager_list.append(t1)
    manager_list.append(t2)
    manager_list.append(c1)
    manager_list.append(c2)
    manager_list.append(f1)
    manager_list.append(f2)
    manager_list.append(a1)
    manager_list.append(a2)
    new_plugin_manager = PluginManager(manager_list)
    assert new_plugin_manager != None
    assert new_plugin_manager.filter()

# Generated at 2022-06-23 19:51:12.927977
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    # Initialization
    plugin_manager = PluginManager()
    plugin_manager.append(type(1))
    plugin_manager.append(type(1))
    plugin_manager.append(type(2))

    # Check if unregister() function works
    plugin_manager.unregister(type(2))
    assert plugin_manager[0] == plugin_manager[1]
    assert plugin_manager[1] != plugin_manager[2]


# Generated at 2022-06-23 19:51:23.707569
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, HTTPBearerAuthPlugin, HTTPTokenAuthPlugin, HTTPDigestAuthPlugin, HTTPNTLMAuthPlugin, KeyValueFormatterPlugin, PrettyHttpieFormatterPlugin, GridFormatterPlugin, HTTPieJSONFormatterPlugin, HTTPieJSONPPFormatterPlugin, HTTPieColoredJSONFormatterPlugin, HTTPieColoredJSONPPFormatterPlugin, UrlencodedFormatterPlugin, URLEncodedQuerystringConverterPlugin, RawRequestBodyConverterPlugin, JSONConverterPlugin, KeyValueConverterPlugin, FileUploadConverterPlugin, UrlWithoutQuerystringConverterPlugin, UrlWithoutFragmentConverterPlugin, PrettyHttpieTransportPlugin, CurlTransportPlugin, RequestsTransportPlugin
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-23 19:51:28.169285
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager_instance = PluginManager()
    PluginManager_instance.load_installed_plugins()
    auth_plugins = PluginManager_instance.get_auth_plugins()
    assert len(auth_plugins) >= 1
    assert not auth_plugins[0] is None
    assert "AuthPlugin" in str(type(auth_plugins[0]))
    
    

# Generated at 2022-06-23 19:51:31.223906
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth
    pm = PluginManager()
    pm.register(HTTPBasicAuth, HTTPDigestAuth)
    assert pm.get_auth_plugins() == [HTTPBasicAuth, HTTPDigestAuth]


# Generated at 2022-06-23 19:51:32.085916
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()


# Generated at 2022-06-23 19:51:37.607238
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Alpha(FormatterPlugin):
        group_name = 'a'
        pass

    class Beta(FormatterPlugin):
        group_name = 'b'
        pass

    class Gamma(FormatterPlugin):
        group_name = 'a'
        pass

    class Delta(FormatterPlugin):
        group_name = 'a'
        pass

    class Epsilon(FormatterPlugin):
        group_name = 'b'
        pass

    plugins = PluginManager()
    plugins.register(Alpha, Beta, Gamma, Delta, Epsilon)
    assert plugins.get_formatters_grouped() == {
        'a': [Alpha, Gamma, Delta],
        'b': [Beta, Epsilon]
    }

# Generated at 2022-06-23 19:51:47.810408
# Unit test for method get_converters of class PluginManager

# Generated at 2022-06-23 19:51:53.255037
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    auth_plugin_mapping = {
        'basic': 'Basic',
        'digest': 'Digest',
        'aws-auth-v4': 'aws-auth-v4'
    }
    auth_plugin_mapping_result = PluginManager().get_auth_plugin_mapping()
    assert auth_plugin_mapping == auth_plugin_mapping_result
test_PluginManager_get_auth_plugin()

# Generated at 2022-06-23 19:52:00.451970
# Unit test for constructor of class PluginManager
def test_PluginManager():
    # Given
    def test_plugin_class(self):
        pass
    test_plugin = type("test_plugin", (), {"test_plugin_func": test_plugin_class})

    # When
    plugin_manager = PluginManager()
    plugin_manager.register(test_plugin)
    plugin_manager.unregister(test_plugin)
    plugin_manager.filter(test_plugin)
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugins()
    plugin_manager.get_auth_plugin_mapping()
    plugin_manager.get_auth_plugin("auth_type")
    plugin_manager.get_formatters()
    plugin_manager.get_formatters_grouped()
    plugin_manager.get_converters()
    plugin_manager.get_transport_plugins()


# Generated at 2022-06-23 19:52:01.856610
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(AuthPlugin)



# Generated at 2022-06-23 19:52:06.329468
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters= plugin_manager.get_formatters()
    assert len(formatters) == 3


# Generated at 2022-06-23 19:52:08.807694
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_auth_plugins()) == 2


# Generated at 2022-06-23 19:52:13.291126
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(MyAuthPlugin1, MyAuthPlugin2)
    assert plugin_manager.get_auth_plugin('TheAuthPlugin') == MyAuthPlugin1
    assert plugin_manager.get_auth_plugin('TheOtherAuthPlugin') == MyAuthPlugin2



# Generated at 2022-06-23 19:52:22.002507
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # Given
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.builtin import JSONConverter, JSONPointerConverter
    from httpie.plugins.builtin import XMLConverter, XPathConverter
    builtin_converters = [JSONConverter, XMLConverter, JSONPointerConverter, XPathConverter]
    plugin_manager = PluginManager()
    plugin_manager.register(JSONConverter, JSONPointerConverter, XMLConverter, XPathConverter)
    expected_converters = builtin_converters

    # When
    converters = plugin_manager.get_converters()

    # Then
    assert converters == expected_converters


# Generated at 2022-06-23 19:52:25.188792
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert PluginManager.get_auth_plugin is not None
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert 'basic' in pluginManager.get_auth_plugin_mapping().keys()


# Generated at 2022-06-23 19:52:26.484815
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pp = PluginManager()
    assert pp.filter() == []


# Generated at 2022-06-23 19:52:29.128264
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    test_PluginManager = PluginManager()
    test_PluginManager.load_installed_plugins()

    a = test_PluginManager.get_transport_plugins()
    assert len(a) == 2
    assert True

# Generated at 2022-06-23 19:52:31.686848
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    l = [0, 1, 2, 3]
    a = PluginManager()
    a.register(l)
    a.unregister(l)
    assert a == []


# Generated at 2022-06-23 19:52:34.506964
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    # Test 1
    plugin_manager.register(AuthBasicPlugin)
    auth_plugin = plugin_manager.get_auth_plugin('basic')
    assert(auth_plugin == AuthBasicPlugin)

    # Test 2
    auth_plugin = plugin_manager.get_auth_plugin('digest')
    assert(auth_plugin == None)



# Generated at 2022-06-23 19:52:36.804892
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    assert [] == plugins.get_converters()

# Generated at 2022-06-23 19:52:43.737956
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager=PluginManager()
    expected_results=plugin_manager.get_formatters()
    result=[]
    for plugin in expected_results:
        plugin_name=plugin.__name__
        result.append(plugin_name)
    assert result==['JsonFormatter','JsonLinesFormatter','JsonLinesLinesFormatter','ColoredFormatter','PrettyFormatter','PrettyJsonFormatter','PrettyJsonLinesFormatter','PrettyXmlFormatter','RawFormatter']

# Generated at 2022-06-23 19:52:52.222224
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Arrange
    # Create a new instance of the PluginManager class
    plugins = PluginManager()
    # Act
    # Create new instance of the class httpie.plugins.auth.BasicAuth
    basic_auth = BasicAuth()
    # Add the instance of the class httpie.plugins.auth.BasicAuth to the list of plugins
    plugins.register(basic_auth)
    # Assert
    # Test if the function get_auth_plugin returns the correct auth plugin
    assert plugins.get_auth_plugin('basic') == basic_auth


# Generated at 2022-06-23 19:52:55.439164
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.auth import BasicAuthPlugin
    pm = PluginManager()
    assert pm.get_auth_plugins() == []
    pm.register(BasicAuthPlugin)
    assert pm.get_auth_plugins() == [BasicAuthPlugin]


# Generated at 2022-06-23 19:52:57.453420
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    print(manager)
    
test_PluginManager_load_installed_plugins()

# Generated at 2022-06-23 19:53:02.807398
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.noauth import NoAuthPlugin
    from httpie.plugins.auth.bearer import BearerAuthPlugin
    PluginManager.register(
        BasicAuthPlugin, BearerAuthPlugin, DigestAuthPlugin, NoAuthPlugin
    )
    assert PluginManager.get_auth_plugin_mapping(
    ) == {'basic': BasicAuthPlugin,
          'bearer': BearerAuthPlugin, 'digest': DigestAuthPlugin,
          'noauth': NoAuthPlugin}

# Generated at 2022-06-23 19:53:06.702201
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pymanger = PluginManager()
    pymanger.load_installed_plugins()
    assert pymanger.get_auth_plugin('basic') == HTTPBasicAuth
    assert pymanger.get_auth_plugin('digest') == HTTPDigestAuth

# Generated at 2022-06-23 19:53:13.700674
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    auth_plugin_manager = PluginManager()
    auth_plugin_manager.register(BasicAuth, DigestAuth, HawkAuth, OAuth1Auth)
    expected = {
        'basic': BasicAuth,
        'digest': DigestAuth,
        'hawk': HawkAuth,
        'oauth1': OAuth1Auth,
    }
    actual = auth_plugin_manager.get_auth_plugin_mapping()
    assert expected == actual

# Generated at 2022-06-23 19:53:16.263897
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    p = PluginManager()
    assert repr(p) == '<PluginManager: []>'

plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:53:20.052126
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    print(p.get_transport_plugins())
    assert len(p.get_transport_plugins()) == 0



# Generated at 2022-06-23 19:53:23.354151
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class TestPlugin(BasePlugin):
        """Test plugin"""

    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin)
    assert TestPlugin in plugin_manager
    plugin_manager.unregister(TestPlugin)
    assert TestPlugin not in plugin_manager


# Generated at 2022-06-23 19:53:28.701104
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)
    assert plugins == [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]


# Generated at 2022-06-23 19:53:32.658945
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm1 = PluginManager()
    assert type(pm1.get_formatters()) == list

    pm2 = PluginManager()
    pm2.register(FormatterPlugin)
    assert type(pm2.get_formatters()) == list


# Generated at 2022-06-23 19:53:37.760650
# Unit test for constructor of class PluginManager
def test_PluginManager():
        plugin_manager = PluginManager()
        print(repr(plugin_manager))
        plugin_manager.load_installed_plugins()
        print(repr(plugin_manager))
        print(plugin_manager.get_auth_plugin_mapping())
        print(plugin_manager.get_formatters())
        print(plugin_manager.get_formatters_grouped())
        print(plugin_manager.get_converters())
        print(plugin_manager.get_transport_plugins())

test_PluginManager()

# Generated at 2022-06-23 19:53:41.639094
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginManager = PluginManager()
    pluginManager.append(type('AuthPlugin_1', (AuthPlugin,), {'auth_type': 'AUTH_TYPE_1'}))
    pluginManager.append(type('AuthPlugin_2', (AuthPlugin,), {'auth_type': 'AUTH_TYPE_2'}))

    assert pluginManager.get_auth_plugin_mapping() == {'AUTH_TYPE_1': AuthPlugin_1, 'AUTH_TYPE_2': AuthPlugin_2}

# Generated at 2022-06-23 19:53:47.045960
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(TestAuthPlugin1)
    plugin_manager.register(TestAuthPlugin2)
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['auth_type1'] == TestAuthPlugin1
    assert auth_plugin_mapping['auth_type2'] == TestAuthPlugin2


# Generated at 2022-06-23 19:53:56.322611
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FooFormatterPlugin(FormatterPlugin):
        group_name = 'foo'

    class BarFormatterPlugin(FormatterPlugin):
        group_name = 'bar'

    class BazFormatterPlugin(FormatterPlugin):
        group_name = 'baz'

    plugin_manager = PluginManager()
    plugin_manager.register(FooFormatterPlugin,
                            BarFormatterPlugin,
                            BarFormatterPlugin,
                            BazFormatterPlugin)

    assert plugin_manager.get_formatters_grouped() == {
        'foo': [FooFormatterPlugin],
        'bar': [BarFormatterPlugin, BarFormatterPlugin],
        'baz': [BazFormatterPlugin],
    }


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:54:07.835008
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    from httpie.plugins.auth.basic import BasicAuthPlugin

    pm = PluginManager()

    assert pm.get_auth_plugin('') == BasicAuthPlugin
    assert pm.get_auth_plugin('basic') == BasicAuthPlugin
    assert pm.get_auth_plugin('digest') == BasicAuthPlugin
    assert pm.get_auth_plugin('gssnegotiate') == BasicAuthPlugin
    assert pm.get_auth_plugin('harry') == BasicAuthPlugin
    assert pm.get_auth_plugin('jiney') == BasicAuthPlugin
    assert pm.get_auth_plugin('jwt') == BasicAuthPlugin
    assert pm.get_auth_plugin('oca') == BasicAuthPlugin
    assert pm.get_auth_plugin('oauth2') == BasicAuthPlugin
    assert pm.get_auth_plugin('ocean')

# Generated at 2022-06-23 19:54:10.079397
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    a = PluginManager()
    a.load_installed_plugins()
    assert isinstance(a.get_formatters_grouped(), dict)
    assert a.get_formatters_grouped() != {}

# Generated at 2022-06-23 19:54:12.204189
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin = PluginManager()
    assert plugin.get_converters() == []


# Generated at 2022-06-23 19:54:23.437701
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    import json
    from httpie.plugins import BuiltinConvertersPlugin, \
        ConverterPlugin, DeserializerPlugin, SerializerPlugin
    from httpie.plugins import JSONConverter, TextConverter
    class MyConverterPlugin(ConverterPlugin):
        convert_mimetypes = {'text/plain'}
        convert_fns = {'text': 'text'}

    class MySerializer(SerializerPlugin):
        serialize_mimetypes = {'text/plain'}
        serialize_fns = {'text': 'text'}

    class MyDeserializer(DeserializerPlugin):
        deserialize_mimetypes = {'text/plain'}
        deserialize_fns = {'text': 'text'}

    pm = PluginManager()
    pm.register

# Generated at 2022-06-23 19:54:30.434752
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(BasePlugin)
    plugins.register(AuthPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(converter.JSONConverter)
    plugins.register(converter.FormConverter)
    plugins.register(converter.URLEncodeConverter)
    plugins.register(transport.HTTPTransport)
    plugins.register(transport.UnixSocketTransport)
    assert len(plugins.get_formatters()) == 1



# Generated at 2022-06-23 19:54:34.655918
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth

    [
        HTTPBasicAuth,
        HTTPBearerAuth
    ]

    pm = PluginManager()
    pm.register(HTTPBasicAuth)
    print(pm)
    pm.unregister(HTTPBasicAuth)
    print(pm)


# Generated at 2022-06-23 19:54:36.013919
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register()
    assert plugin_manager == []

# Generated at 2022-06-23 19:54:37.332311
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager

# Generated at 2022-06-23 19:54:42.363993
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register(1, 2, 3, 4)
    assert len(manager) == 4
    assert manager.pop() == 4
    manager.unregister(3)
    assert len(manager) == 2
    assert manager.pop() == 2
    assert manager.pop() == 1

# Generated at 2022-06-23 19:54:44.409573
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    plugins = [
        Mock(spec=TransportPlugin),
        Mock(spec=TransportPlugin),
        Mock(spec=TransportPlugin),
    ]
    manager.register(*plugins)
    assert tuple(manager.get_transport_plugins()) == plugins



# Generated at 2022-06-23 19:54:46.616875
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert plugin_manager == []


# Generated at 2022-06-23 19:54:47.619400
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager()

# Generated at 2022-06-23 19:54:50.011719
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    assert pm.get_formatters_grouped() == {}


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:54:54.277757
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

    assert 'basic' in auth_plugin_mapping
    assert 'digest' in auth_plugin_mapping

# Generated at 2022-06-23 19:54:57.870603
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pluginmanager = PluginManager()
    pluginmanager.register(AuthPlugin)
    assert pluginmanager.get_auth_plugins() == [AuthPlugin]



# Generated at 2022-06-23 19:55:03.916707
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # test1: normal input
    manager = PluginManager()
    manager.load_installed_plugins()
    output = manager.get_transport_plugins()
    assert len(output) == 2
    assert all([issubclass(plugin, TransportPlugin) for plugin in output])
    # test2: empty plugin list
    manager = PluginManager()
    output = manager.get_transport_plugins()
    assert len(output) == 0

# Generated at 2022-06-23 19:55:05.769439
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_transport_plugins()) > 0

# Generated at 2022-06-23 19:55:09.482362
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    plugins_len = len(ENTRY_POINT_NAMES)
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)
    assert plugins_len + len(plugins) == len(plugin_manager)
    plugin_manager.unregister(FormatterPlugin)
    assert plugins_len + len(plugins) - 1 == len(plugin_manager)

# Generated at 2022-06-23 19:55:11.688157
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in auth_plugin_mapping
    assert 'bearer' in auth_plugin_mapping


# Generated at 2022-06-23 19:55:19.457008
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    pm = PluginManager()
    assert pm.get_auth_plugin('basic') is not None
    assert pm.get_auth_plugin('digest') is not None
    assert pm.get_auth_plugin('hawk') is not None
    assert pm.get_auth_plugin('aws4') is not None
    assert pm.get_auth_plugin('multipart') is not None
    assert pm.get_auth_plugin('netrc') is not None
    assert pm.get_auth_plugin('ntlm') is not None
    assert pm.get_auth_plugin('oauth1') is not None
    assert pm.get_auth_plugin('bearer') is not None
    assert pm.get_auth_plugin('jwt') is not None

# Generated at 2022-06-23 19:55:23.527094
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_formatters()) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) != 0
    # assert False

# Generated at 2022-06-23 19:55:25.481631
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 1



# Generated at 2022-06-23 19:55:29.810453
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager(range(3))) == '<PluginManager: [0, 1, 2]>'
    assert repr(PluginManager(range(10))) == '<PluginManager: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]>'


# Generated at 2022-06-23 19:55:34.726168
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(BasePlugin):
        pass
    pm = PluginManager()
    pm.append(Plugin1)
    pm.append(Plugin2)
    pm.append(Plugin3)
    pm.unregister(Plugin2)
    assert Plugin2 not in pm
    assert Plugin1 in pm and Plugin3 in pm


# Generated at 2022-06-23 19:55:39.032355
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert len(pm) == 0, \
        'The length of PluginManager() is not 0'
    assert repr(pm) == '<PluginManager: []>', \
        'The repr(PluginManager) is not "<PluginManager: []>"'

# Generated at 2022-06-23 19:55:44.513497
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # Initialize instances of class PluginManager
    plugin_manager = PluginManager()
    # Call get_transport_plugins method of class PluginManager
    result = plugin_manager.get_transport_plugins()
    # Check the type of result
    assert isinstance(result, list)
    # Check the type of result elements
    assert isinstance(result[0], type)
    assert isinstance(TransportPlugin, result[0])

# Generated at 2022-06-23 19:55:47.343760
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    for p in pluginManager.get_converters():
        assert issubclass(p, ConverterPlugin)


# Generated at 2022-06-23 19:55:47.999782
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager()


# Generated at 2022-06-23 19:55:49.411720
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter(by_type=Type[BasePlugin]) == []

# Generated at 2022-06-23 19:55:54.755459
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # input: None
    # output: dictionary

    # given
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)

    # when
    result = plugin_manager.get_auth_plugin_mapping()

    # then
    assert(result == {'base': AuthPlugin})

# Generated at 2022-06-23 19:55:57.600428
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    #assert len(pm.get_formatters()) == 1
    assert len(pm.get_formatters()) > 2




# Generated at 2022-06-23 19:56:06.202451
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()
    formatter_grouped = manager.get_formatters_grouped()
    assert 'JSON' in formatter_grouped
    assert 'HTML' in formatter_grouped
    assert 'XML' in formatter_grouped
    assert 'Terminal' in formatter_grouped
    assert 'CSV' in formatter_grouped
    assert 'YAML' in formatter_grouped
    assert 'HTML' in formatter_grouped
    assert 'Markdown' in formatter_grouped
    assert 'Pretty' in formatter_grouped
    assert 'Code' in formatter_grouped
    assert 'Raw' in formatter_grouped
    assert 'Debug' in formatter_grouped
    assert 'Table' in formatter_grouped

# Generated at 2022-06-23 19:56:08.269904
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # When
    plugins = PluginManager()
    # Then
    assert plugins.get_converters() == [], 'Empty plugin list should return empty list'

# Generated at 2022-06-23 19:56:11.671091
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    new_plugins = [AuthPlugin, ConverterPlugin, FormatterPlugin, BasePlugin, TransportPlugin]
    pm = PluginManager()
    for new in new_plugins:
        pm.register(new)
    print(pm.get_formatters())


# Generated at 2022-06-23 19:56:19.742228
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter import BaseFormatter
    from httpie.plugins.formatter.colors import ColorFormatter
    from httpie.plugins.formatter.json import JSONFormatter
    from httpie.plugins.formatter.utils import NoneZeroFormatter
    pm = PluginManager()

    class NoneZero(BaseFormatter):
        group_name = 'NoneZero'
        group_description = 'NoneZero'
        group_order = 0
        group_default = None

    pm.register(NoneZero)
    pm.register(NoneZeroFormatter)
    pm.register(JSONFormatter)
    pm.register(ColorFormatter)
    expectation = {
        'NoneZero': [NoneZero, NoneZeroFormatter],
        'Format': [JSONFormatter],
        'Color': [ColorFormatter],
    }
   

# Generated at 2022-06-23 19:56:21.919414
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    assert isinstance(pm.get_formatters(), list)



# Generated at 2022-06-23 19:56:25.711560
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth
    manager = PluginManager()
    manager.register(HTTPBasicAuth)
    assert manager.get_auth_plugins() == [HTTPBasicAuth]


# Generated at 2022-06-23 19:56:30.852705
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    f = FormatterPlugin()
    f.group_name = 'k1'
    g = FormatterPlugin()
    g.group_name = 'k2'
    h = FormatterPlugin()
    h.group_name = 'k1'
    pm.register(f)
    pm.register(g)
    pm.register(h)
    result = pm.get_formatters_grouped()
    expected = {
        'k1': [f, h],
        'k2': [g]
    }
    assert result == expected

# Generated at 2022-06-23 19:56:40.433183
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    result = PluginManager()
    result.load_installed_plugins()

    def get_class_name(obj):
        return type(obj).__name__

    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            # The class_name of the plugin should be in the property
            assert get_class_name(plugin) in str(result)
    # The result the method should be in format [<PluginManager: [class_name, ...]>]
    assert str(result).startswith('<PluginManager: ')
    assert str(result).endswith('>]')

# Generated at 2022-06-23 19:56:48.878162
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONAwareFormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin)
    plugin_manager.register(JSONAwareFormatterPlugin)

    expected_type = {'Builtin': {JSONAwareFormatterPlugin, JSONFormatterPlugin}}

    actual_type = plugin_manager.get_formatters_grouped()

    assert expected_type == actual_type

# Generated at 2022-06-23 19:56:52.998177
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    def is_FormatterPlugin(plugin_class):
        return issubclass(plugin_class, FormatterPlugin)
    assert all(map(is_FormatterPlugin, plugin_manager.get_formatters()))

# Generated at 2022-06-23 19:57:00.378776
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    pm.load_installed_plugins()
    # httpie.plugins.auth.v1
    pm.unregister(pm.get_auth_plugins()[0])
    # httpie.plugins.formatter.v1
    pm.unregister(pm.get_formatters()[0])
    # httpie.plugins.converter.v1
    pm.unregister(pm.get_converters()[0])
    # httpie.plugins.transport.v1
    pm.unregister(pm.get_transport_plugins()[0])
    assert len(pm) == 11


# Generated at 2022-06-23 19:57:07.089364
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    class FakePlugin:
        def __init__(self, arg):
            self.id = arg
        def __repr__(self):
            return f'<{self.id}>'
        
    plugins=[FakePlugin(i) for i in range(10)]
    pluginManager = PluginManager()
    pluginManager.register(*plugins)
    assert repr(pluginManager) == f'<PluginManager: {plugins}>'

# Generated at 2022-06-23 19:57:12.322660
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Init
    from httpie.plugins.builtin import JSONPrettyFormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    global json_Plugin
    json_Plugin = JSONFormatterPlugin()
    global json_pretty_Plugin
    json_pretty_Plugin = JSONPrettyFormatterPlugin()
    global table_Plugin
    table_Plugin = TableFormatterPlugin()

    # Test
    assert PluginManager.get_formatters_grouped(PluginManager([json_Plugin, json_pretty_Plugin, table_Plugin])) == {'JSON': [json_Plugin, json_pretty_Plugin], 'Table': [table_Plugin]}

# Generated at 2022-06-23 19:57:13.129296
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert True
    

# Generated at 2022-06-23 19:57:14.960520
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-23 19:57:17.633411
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_converters()) >= 2

# Generated at 2022-06-23 19:57:18.803736
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    assert pm.get_converters() == []


# Generated at 2022-06-23 19:57:21.412659
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(DummyAuthPlugin1, DummyAuthPlugin2)
    assert manager.get_auth_plugin('dummy-auth') == DummyAuthPlugin1


# Generated at 2022-06-23 19:57:23.993178
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([1, 2, 3])) == '<PluginManager: [1, 2, 3]>'



# Generated at 2022-06-23 19:57:25.779796
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager.get_auth_plugin('basic'))


# Generated at 2022-06-23 19:57:28.265328
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    assert manager == []

    manager.register(int, float)
    assert manager == [int, float]

    manager.register(str)
    assert manager == [int, float, str]


# Generated at 2022-06-23 19:57:30.513270
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == "<PluginManager: []>"
    plugin_manager.register(BasePlugin)
    assert repr(plugin_manager) == "<PluginManager: [<class 'httpie.plugins.base.BasePlugin'>]>"

# Generated at 2022-06-23 19:57:33.720986
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager([1, 2, 3])) == '<PluginManager: [1, 2, 3]>'


plugins = PluginManager()



# Generated at 2022-06-23 19:57:36.144785
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert plugin_manager.filter() == []
    assert plugin_manager.filter(by_type=Type[TransportPlugin]) == []
    plugin_manager.register(TransportPlugin)
    assert plugin_manager.filter() == [TransportPlugin]
    assert plugin_manager.filter(by_type=Type[TransportPlugin]) == [TransportPlugin]

# Generated at 2022-06-23 19:57:45.709528
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import pkg_resources
    entry_point_names = ['httpie.plugins.auth.v1', 'httpie.plugins.formatter.v1', 'httpie.plugins.converter.v1', 'httpie.plugins.transport.v1']
    def iter_entry_points(entry_point_name):
        from pkg_resources import iter_entry_points
        yield iter_entry_points(entry_point_name)[0]
        entry_point.dist.key
        
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    installed_plugins = plugin_manager
    auth_plugins = installed_plugins.get_auth_plugins()
    transport_plugins = installed_plugins.get_transport_plugins()
    formatters = installed_plugins.get_formatters()
    converters

# Generated at 2022-06-23 19:57:50.144634
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    from json import JSONDecodeError
    from httpie.output.json import JSONFormatter
    from httpie.plugins.builtin import HTMLFormatter
    plugin_manager.register(HTMLFormatter, JSONFormatter)

    result = plugin_manager.get_formatters_grouped()
    assert result['Json'] == [JSONFormatter]
    assert result['Html'] == [HTMLFormatter]

# Generated at 2022-06-23 19:57:52.942433
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins_mgr = PluginManager()
    plugins_mgr.load_installed_plugins()
    print(plugins_mgr.get_converters())

# Generated at 2022-06-23 19:57:57.327369
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    assert len(pm) == 0

    class SomePlugin(object):
        pass

    pm.register(SomePlugin)

    assert len(pm) == 1

    pm.unregister(SomePlugin)

    assert len(pm) == 0


# Generated at 2022-06-23 19:58:02.813526
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins import FormatterPlugin
    from httpie.compat import is_py2

    class TestPlugin(FormatterPlugin):
        pass

    plugins = PluginManager()
    plugins.register(HTTPiePlugin, TestPlugin)

    # the key of the dict depends on version of Python
    if is_py2:
        assert repr(plugins) == "<PluginManager: [<class 'httpie.plugins.builtin.HTTPiePlugin'>, <class 'httpie.plugins.builtin.TestPlugin'>]>"
    else:
        assert repr(plugins) == "<PluginManager: [<class 'httpie.plugins.builtin.HTTPiePlugin'>, <class 'httpie.plugins.builtin.TestPlugin'>]>"




# Generated at 2022-06-23 19:58:04.358642
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert plugin_manager.get_converters() == []

# Generated at 2022-06-23 19:58:13.109320
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    def plugin1(): pass
    def plugin2(): pass
    p = PluginManager()
    p.register(plugin1, plugin2)
    # Python calls __repr__() to get the string representation of an object.
    # It is typically used for debugging, so it is important that the output
    # is information-rich and unambiguous.
    # In this case, the output <PluginManager: [..., ...]> is meaningful for the developers.
    assert repr(p) == '<PluginManager: [<function plugin1 at 0x...>, <function plugin2 at 0x...>]>'


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:58:17.271391
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin)
    plugin_manager.register(DigestAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping()['basic'] == BasicAuthPlugin
    assert plugin_manager.get_auth_plugin_mapping()['digest'] == DigestAuthPlugin
    assert plugin_manager.get_auth_plugin('basic') == BasicAuthPlugin
    assert plugin_manager.get_auth_plugin('digest') == DigestAuthPlugin

# Generated at 2022-06-23 19:58:18.897530
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'

# Generated at 2022-06-23 19:58:22.234003
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert type(pm.get_auth_plugin_mapping()) == dict
    assert len(pm.get_auth_plugin_mapping()) == 5


# Generated at 2022-06-23 19:58:23.221700
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugi

# Generated at 2022-06-23 19:58:26.896858
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugin_instance = BasePlugin()
    plugins.register(plugin_instance)
    lst = plugins.filter()
    assert type(lst[0]) == type(plugin_instance), "test_PluginManager_filter() failed"


# Generated at 2022-06-23 19:58:28.181629
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert plugin_manager is not None


# Generated at 2022-06-23 19:58:36.014455
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import TransportPlugin
    from httpie.compat import is_windows
    from httpie.packages.urllib3 import PoolManager
    from httpie.config import DEFAULT_TIMEOUT
    from httpie.auth import BasicAuth
    from httpie.plugins import braille_formatter, echo_formatter
    from httpie.plugins import json_converter
    from httpie.plugins import httpie_auth_plugin, httpie_digest_auth
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager, PluginManager)

# Generated at 2022-06-23 19:58:43.210245
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from unittest.mock import MagicMock
    import sys
    import os.path
    sys.path.append(os.path.abspath('.'))
    from httpie.plugins.manager import PluginManager
    plugins_manager = PluginManager()
    plugins_manager.load_installed_plugins()
    auth_plugins_dict = plugins_manager.get_auth_plugin_mapping()
    assert auth_plugins_dict is not None
    assert 'basic' in auth_plugins_dict
    assert 'digest' in auth_plugins_dict
    assert 'hawk' in auth_plugins_dict

# Generated at 2022-06-23 19:58:50.261087
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.load_installed_plugins()

    class MockManagers():
        _current_converter = None
        _converter_plugin_mapping = {
            converter.content_type: converter
            for converter in pm.get_converters()
        }
        _current_formatter = None
        _formatter_plugin_mapping = {
            formatter.group_name: formatter
            for formatter in pm.get_formatters()
        }

        @property
        def current_converter(self):
            return self._current_converter
        @current_converter.setter
        def current_converter(self, value):
            self._current_converter = value
        @property
        def converter_plugin_mapping(self):
            return self

# Generated at 2022-06-23 19:58:52.432445
# Unit test for constructor of class PluginManager
def test_PluginManager():
    p1 = PluginManager()
    assert type(p1) == PluginManager
    assert p1.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-23 19:59:00.046903
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    m = PluginManager()
    m.register(GitHubAuthPlugin, AuthPlugin)
    m.register(BitBucketAuthPlugin, AuthPlugin)
    assert m.get_auth_plugin('github') == GitHubAuthPlugin
    assert m.get_auth_plugin('bitbucket') == BitBucketAuthPlugin
    assert m.get_auth_plugins() == [GitHubAuthPlugin, BitBucketAuthPlugin]
    assert m.get_auth_plugin_mapping() == {
        'github': GitHubAuthPlugin, 'bitbucket': BitBucketAuthPlugin}


# Generated at 2022-06-23 19:59:06.166585
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    type_dict = {}
    for plugin in manager:
        type_dict.setdefault(plugin.plugin_type, [])
        type_dict[plugin.plugin_type].append(plugin)

    assert len(manager) > 0

    for key in type_dict:
        plugins = type_dict[key]
        for idx, plugin in enumerate(plugins):
            if idx < len(plugins) - 1:
                assert plugin.priority >= plugins[idx+1].priority


# Generated at 2022-06-23 19:59:10.776165
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.register(auth_plugin.BasicAuthPlugin)
    pm.register(auth_plugin.DigestAuthPlugin)
    assert len(pm.get_auth_plugins()) == 2
    assert auth_plugin.BasicAuthPlugin in pm.get_auth_plugins()
    assert auth_plugin.DigestAuthPlugin in pm.get_auth_plugins()


# Generated at 2022-06-23 19:59:16.721821
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie.input.argtypes
    import httpie.plugins.formatter.json as json_formatter

    plugin_manager = PluginManager()
    plugin_manager.register(json_formatter.JSONFormatter)

    formatters_grouped = plugin_manager.get_formatters_grouped()

    # Test the output type and number
    assert isinstance(formatters_grouped, dict)
    assert len(formatters_grouped) == 1

    # Test the output value of key of formatters_grouped
    assert 'Formats' in formatters_grouped

    # Test the output type and number of the value of key of formatters_grouped
    formatters = formatters_grouped.get("Formats")
    assert isinstance(formatters, list)
    assert len(formatters) == 1

    # Test the output

# Generated at 2022-06-23 19:59:20.586682
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    PluginManager.unregister(PluginManager, 'httpie.plugins.formatter.v1')
    assert 'httpie.plugins.formatter.v1' not in PluginManager
if __name__ == '__main__':
    test_PluginManager_unregister()
plugins = PluginManager()

# Generated at 2022-06-23 19:59:22.761399
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    assert issubclass(plugin_manager[0], BasePlugin)


# Generated at 2022-06-23 19:59:27.034486
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(JsonConverter)
    pm.register(YamlConverter)
    pm.register(TextConverter)
    assert pm.get_converters() == [JsonConverter, YamlConverter, TextConverter]

# Generated at 2022-06-23 19:59:37.051361
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import builtin
    manager = PluginManager()
    manager.register(builtin.HTMLFormatter)
    manager.register(builtin.JSONFormatter)
    manager.register(builtin.PrettyJSONFormatter)
    manager.register(builtin.ColoredJSONFormatter)
    manager.register(builtin.SingleHTMLLineFormatter)
    manager.register(builtin.DevNullFormatter)
    manager.register(builtin.ImageFormatter)
    manager.register(builtin.URLEncodedFormatter)
    manager.register(builtin.RawJSONRenderer)
    manager.register(builtin.COLUMNIFormatter)
    manager.register(builtin.JSONLinesFormatter)
    formatters = manager.get_formatters()
    assert len(formatters) is 11

# Generated at 2022-06-23 19:59:46.110430
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuthPlugin
    from httpie.plugins.builtin import LazyAuthPlugin
    from httpie.plugins.builtin import JWTAuthPlugin
    from httpie.plugins.builtin import OAuth1AuthPlugin
    from httpie.plugins.builtin import OAuth2AuthPlugin
    from httpie.plugins.builtin import HawkAuthPlugin
    from httpie.plugins.builtin import DigestAuthPlugin
    from httpie.plugins.builtin import ClientCertAuthPlugin
    from httpie.plugins.builtin import BearerAuthPlugin
    from httpie.plugins.builtin import TokenAuthPlugin
    from httpie.plugins.builtin import ANAuthPlugin
    from httpie.plugins.builtin import AmazonAuthPlugin
    from httpie.plugins.builtin import Fun

# Generated at 2022-06-23 19:59:53.295729
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    # Test 1
    pm_test1 = PluginManager()
    assert pm_test1.get_formatters() == [], "get_formatters return NULL"

    # Test 2
    class Plugin1(FormatterPlugin):
        pass
    class Plugin2(FormatterPlugin):
        pass
    pm_test2 = PluginManager()
    pm_test2.register(Plugin1, Plugin2)
    assert pm_test2.get_formatters() == [Plugin1, Plugin2], "get_formatters return incorrect result"


# Generated at 2022-06-23 20:00:00.115858
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin

    class FormatterA(FormatterPlugin):
        name = 'formatter-a'
        group_name = 'group'
        priority = 1

    class FormatterB(FormatterPlugin):
        name = 'formatter-a'
        group_name = 'group'
        priority = 3

    class FormatterC(FormatterPlugin):
        name = 'formatter-a'
        group_name = 'group'
        priority = 2

    class FormatterX(FormatterPlugin):
        name = 'formatter-x'
        group_name = 'group-x'
        priority = 1

    class FormatterY(FormatterPlugin):
        name = 'formatter-y'
        group_name = 'group-y'
        priority = 1


# Generated at 2022-06-23 20:00:07.737676
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyPassAuth
    PluginManager().register(HTTPBasicAuth)
    PluginManager().register(HTTPBearerAuth)
    PluginManager().register(HTTPProxyAuth)
    PluginManager().register(HTTPProxyPassAuth)
    #print(PluginManager().filter())
    #print(PluginManager().filter(AuthPlugin))
    #print(PluginManager().filter(FormatterPlugin))
    #print(PluginManager().filter(ConverterPlugin))

if __name__ == "__main__":
    test_PluginManager_filter()

# Generated at 2022-06-23 20:00:13.503175
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin = PluginManager()
    assert plugin.get_auth_plugins() == []
    assert plugin.get_auth_plugin_mapping() == {}
    assert plugin.get_formatters() == []
    assert plugin.get_formatters_grouped() == {}
    assert plugin.get_converters() == []
    assert plugin.get_transport_plugins() == []
    assert list(plugin) == []


# Generated at 2022-06-23 20:00:24.009002
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    auth_plugins = PluginManager()
    auth_plugins.register(
        BasicAuthPlugin,
        DigestAuthPlugin,
        JWTAuthPlugin,
        AWSSigV4AuthPlugin,
        OAuth1Plugin,
        OAuth2Plugin,
        HawkAuthPlugin,
        BearerTokenAuthPlugin,
        AsyncAuthPlugin,
        HttpiePlugin,
        CredentialsPlugin,
        KeyringAuthPlugin,
        WwwAuthenticatePlugin,
        KerberosAuthPlugin,
        OIDCAuthPlugin,
        NTLMAuthPlugin
    )


# Generated at 2022-06-23 20:00:25.092532
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    assert plugins == []


# Generated at 2022-06-23 20:00:27.087978
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    a = PluginManager()
    a.register(AuthPlugin, FormatterPlugin)
    assert a.filter(AuthPlugin)[0].__class__.__name__ == "AuthPlugin"

# Generated at 2022-06-23 20:00:34.522579
# Unit test for method get_auth_plugin_mapping of class PluginManager

# Generated at 2022-06-23 20:00:42.600368
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0
    installed_plugins = manager
    installed_plugins = manager.get_auth_plugins()
    installed_plugins = manager.get_converters()
    installed_plugins = manager.get_formatters()
    installed_plugins = manager.get_formatters_grouped()
    installed_plugins = manager.get_transport_plugins()
    installed_plugins = manager.get_auth_plugin_mapping()

# Generated at 2022-06-23 20:00:43.663759
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert isinstance(PluginManager(), PluginManager)

# Generated at 2022-06-23 20:00:46.856484
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    assert plugins.get_auth_plugins()[0] == AuthPlugin

