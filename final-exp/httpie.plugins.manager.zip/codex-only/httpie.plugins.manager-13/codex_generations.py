

# Generated at 2022-06-23 19:50:52.893905
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin, plugin_manager
    class Plugin1(FormatterPlugin):
        """Plugin 1."""
        name = 'Plugin 1'
        group_name = 'group1'
    
    class Plugin2(FormatterPlugin):
        """Plugin 2."""
        name = 'Plugin 2'
        group_name = 'group2'
    
    class Plugin3(FormatterPlugin):
        """Plugin 3."""
        name = 'Plugin 3'
        group_name = 'group1'
    
    class Plugin4(FormatterPlugin):
        """Plugin 4."""
        name = 'Plugin 4'
        group_name = 'group1'
    plugin_manager.register(Plugin1, Plugin2, Plugin3, Plugin4)
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:50:58.321836
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class MyPlugin(BasePlugin):
        pass
    class MyPlugin2(BasePlugin):
        pass
    pm.register(MyPlugin, MyPlugin2)
    assert len(pm) == 2


# Generated at 2022-06-23 19:51:03.741640
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import HumanizePlugin, JSONPlugin
    plugins = PluginManager()
    plugins.register(JSONPlugin)
    plugins.register(HumanizePlugin)
    group_formatters = plugins.get_formatters_grouped()

    print(group_formatters)
    assert len(group_formatters) == 2
    assert group_formatters['Concurrency'] == [JSONPlugin]
    assert group_formatters['Data'] == [HumanizePlugin]


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:51:09.937942
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import HTTPFormatterPlugin
    List_formatters = [JSONFormatterPlugin, HTTPFormatterPlugin]
    # Instantiate a PluginManager in order to call its method get_formatters_grouped 
    pm = PluginManager()
    pm.register(*List_formatters)
    # Calling the method get_formatters_grouped
    result = pm.get_formatters_grouped()
    assert 'group_name' in result
    assert 'formatters' in result

# Generated at 2022-06-23 19:51:15.398673
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    class A: pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E: pass
    class F(E): pass
    class G(E): pass
    pm.register(A,B,C,D,E,F,G)
    # No argument
    assert pm.filter() == [A,B,C,D,E,F,G]
    # by_type=A
    assert pm.filter(A) == [A,B,C,D]
    # by_type=B
    assert pm.filter(B) == [B,C]
    # by_type=E
    assert pm.filter(E) == [E,F,G]



# Generated at 2022-06-23 19:51:17.780213
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    p = PluginManager()

    assert(p.unregister('Test') == False)

    assert(p.unregister(AuthPlugin) == False)

# Generated at 2022-06-23 19:51:19.304470
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-23 19:51:24.269407
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # Create a new plugin manager
    plugin_manager = PluginManager()

    # Get converters
    converters = plugin_manager.get_converters()

    # Test if converters is a list
    assert isinstance(converters, list)

    # Test if converters contains the correct elements
    assert issubclass(converters[0], ConverterPlugin)

# Generated at 2022-06-23 19:51:25.957851
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginManager = PluginManager()
    assert pluginManager.unregister(BasePlugin) == pluginManager



# Generated at 2022-06-23 19:51:28.931362
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    PluginManager().__repr__()

#Unit test for method get_formatters_grouped() of class PluginManager

# Generated at 2022-06-23 19:51:33.813358
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) > 0
    assert isinstance(plugins.get_auth_plugin_mapping(), dict)
    assert isinstance(plugins.get_formatters(), list)
    assert isinstance(plugins.get_formatters_grouped(), dict)
    assert isinstance(plugins.get_converters(), list)
    assert isinstance(plugins.get_transport_plugins(), list)

# Generated at 2022-06-23 19:51:36.429110
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    converters = plugin_manager.get_converters()
    assert 3 == len(converters)
    plugin_manager.unregister(converters[0])
    assert 2 == len(plugin_manager.get_converters())


# Generated at 2022-06-23 19:51:38.454029
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    print(pm)

test_PluginManager()

# Generated at 2022-06-23 19:51:42.419068
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_converters()

# Generated at 2022-06-23 19:51:44.287546
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    m = PluginManager()
    assert m.unregister() != None


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:51:47.928417
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    """
    Method: get_auth_plugin(self, auth_type: str) -> Type[AuthPlugin]
    """
    from httpie.plugins.auth.v1 import BasicAuth
    manager = PluginManager()
    res = manager.get_auth_plugin('basic')
    assert res == BasicAuth

# Generated at 2022-06-23 19:51:57.283300
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Group1(FormatterPlugin):
        group_name = 'Group1'
    group1_1 = Group1()
    group1_2 = Group1()
    class Group2(FormatterPlugin):
        group_name = 'Group2'
    group2_1 = Group2()
    group2_2 = Group2()
    class Group3(FormatterPlugin):
        group_name = 'Group3'
    group3_1 = Group3()
    group3_2 = Group3()
    class Group4(FormatterPlugin):
        group_name = 'Group4'
    group4 = Group4()
    pluginManager = PluginManager()
    pluginManager.register(group1_1,group1_2,group2_1,group2_2,group3_1,group3_2,group4)

# Generated at 2022-06-23 19:52:05.442445
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    # unit_tests_PluginManager_unregister
    test_manager = PluginManager()
    test_manager.load_installed_plugins()
    # test_manager.register(AuthPlugin)
    # print(test_manager)
    # test_manager.unregister(AuthPlugin)
    # print(test_manager)
    # test_manager.register(AuthPlugin)
    # print(test_manager)
    # test_manager.unregister(FormatterPlugin)
    # print(test_manager)
    test_manager.unregister(ConverterPlugin)
    print(test_manager)
    # test_manager.unregister(TransportPlugin)
    # print(test_manager)


# Generated at 2022-06-23 19:52:07.760172
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(AuthPlugin)  # register basic auth plugin
    assert manager.get_auth_plugin('basic') == AuthPlugin

# Generated at 2022-06-23 19:52:14.371114
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin = PluginManager()
    plugin.register(PluginManager)
    plugin.get_auth_plugin_mapping()
    plugin.get_auth_plugin('httpie.plugins.auth.v1')
    plugin.get_auth_plugins()
    plugin.get_formatters()
    plugin.get_formatters_grouped()
    plugin.get_converters()
    plugin.get_transport_plugins()

# Generated at 2022-06-23 19:52:17.797263
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    class AuthPlugin1(AuthPlugin):
        auth_type = 'type1'
    class AuthPlugin2(AuthPlugin):
        auth_type = 'type2'
    plugins.register(AuthPlugin1, AuthPlugin2)
    assert plugins.get_auth_plugin('type1') == AuthPlugin1


# Generated at 2022-06-23 19:52:23.616817
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import threading
    from httpie.plugins import FormatterPlugin
    
    threading.current_thread().name = 'MainThread'
    
    # Initialize an instance of PluginManager class
    pm = PluginManager()
    pm.load_installed_plugins()
    assert [pm[0] for pm in pm if isinstance(pm[1], FormatterPlugin)]
    
    
    

# Generated at 2022-06-23 19:52:32.073007
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    assert len(pm.get_formatters_grouped()) == 0, "There are no registered formatters without registering them"
    # create a new class that inherits from FormatterPlugin
    class NewFormatter(FormatterPlugin):
        format_name = "newformatter"
        group_name = "formatgroup1"
    pm.register(NewFormatter)
    assert len(pm.get_formatters_grouped()) == 0, \
        "There are no formatters in a group without specifying the group_name"
    # create a new class that inherits from FormatterPlugin
    class NewFormatter(FormatterPlugin):
        format_name = "newformatter"
        group_name = "formatgroup1"
    pm.register(NewFormatter)

# Generated at 2022-06-23 19:52:43.776684
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert plugin_manager.get_auth_plugins().__len__() > 0
    assert plugin_manager.get_formatters().__len__() > 0
    assert plugin_manager.get_transport_plugins().__len__() > 0
    assert plugin_manager.get_converters().__len__() > 0
    assert plugin_manager.filter(AuthPlugin).__len__() > 0
    assert plugin_manager.filter(FormatterPlugin).__len__() > 0
    assert plugin_manager.filter(TransportPlugin).__len__() > 0
    assert plugin_manager.filter(ConverterPlugin).__len__() > 0


# Generated at 2022-06-23 19:52:47.172048
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():  # pragma: no cover
    p = PluginManager()
    p.register(AuthPlugin)
    print(p.get_auth_plugins())



# Generated at 2022-06-23 19:52:50.035768
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    assert len(plugins)==0
    plugins.load_installed_plugins()
    assert len(plugins)>0

# Generated at 2022-06-23 19:52:52.802156
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    plugin1 = BasePlugin()
    plugin2 = BasePlugin()
    manager.register(plugin1, plugin2)
    assert len(manager) == 2


# Generated at 2022-06-23 19:52:57.044162
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    assert {} == manager.get_auth_plugin_mapping()
    manager2 = PluginManager()
    manager2.register("BasicAuthPlugin")
    manager2.register("DigestAuthPlugin")
    assert {"basic": "BasicAuthPlugin", "digest": "DigestAuthPlugin"} == \
           manager2.get_auth_plugin_mapping()


# Generated at 2022-06-23 19:52:58.863215
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert pm == []

# Test 1 for method register() of class PluginManager

# Generated at 2022-06-23 19:53:01.098404
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(type("Plugin", (object,), {}))
    plugins.unregister(type("Plugin", (object,), {}))
    assert plugins == []



# Generated at 2022-06-23 19:53:04.204791
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.extend([1, 2, 3])
    assert pm.__repr__() == '<PluginManager: [1, 2, 3]>'

# Generated at 2022-06-23 19:53:07.400297
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert(pluginManager.get_converters() != None)


# Generated at 2022-06-23 19:53:10.924489
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    assert repr(PluginManager()) == '<PluginManager: []>'
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager) == 1

# Generated at 2022-06-23 19:53:20.881083
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager([])
    plugins = pm.get_auth_plugins()
    assert plugins == []

    PluginManager.register = lambda x, *plugins: x.extend(plugins)
    class AuthPlugin1(AuthPlugin):
        auth_type = 'auth_type_1'
        auth_type_name = 'name_1'

    class AuthPlugin2(AuthPlugin):
        auth_type = 'auth_type_2'
        auth_type_name = 'name_2'

    class AuthPlugin3(AuthPlugin):
        auth_type = 'auth_type_3'
        auth_type_name = 'name_3'

    pm.register(AuthPlugin1, AuthPlugin2, AuthPlugin3)
    assert pm.get_auth_plugins() == [AuthPlugin1, AuthPlugin2, AuthPlugin3]

#

# Generated at 2022-06-23 19:53:22.257014
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pluginManager = PluginManager()
    assert pluginManager.get_formatters() == []


# Generated at 2022-06-23 19:53:25.183990
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    class TestPlugin(BasePlugin):
        pass

    class TestPlugin2(BasePlugin):
        pass

    pm.register(TestPlugin, TestPlugin2)
    assert len(pm) == 2
    pm.unregister(TestPlugin)
    assert len(pm) == 1



# Generated at 2022-06-23 19:53:28.260541
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {'auth': AuthPlugin}



# Generated at 2022-06-23 19:53:37.655618
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    list_plugins = [
        'httpie.plugins.auth.v1',
        'httpie.plugins.formatter.v1',
        'httpie.plugins.converter.v1',
        'httpie.plugins.transport.v1',
    ]
    for i in range(len(list_plugins)):
        # Finds the entry point for a group.
        for entry_point in iter_entry_points(list_plugins[i]):
            # Loads the entry point (which must be a subclass of BasePlugin).
            plugin = entry_point.load()
            pm.register(entry_point.load())
            #pm.register(plugin)

# Generated at 2022-06-23 19:53:44.560761
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Group1(FormatterPlugin):
        group_name = 'group1'

    class Group1_1(Group1):
        """"""

    class Group1_2(Group1):
        """"""

    class Group2(FormatterPlugin):
        group_name = 'group2'

    class Group2_1(Group2):
        """"""
    pm = PluginManager()
    pm.register(Group1_1, Group1_2, Group2_1)
    grouped = pm.get_formatters_grouped()
    assert sorted(list(grouped.keys())) == ['group1', 'group2']
    assert sorted(list(map(lambda x: type(x).__name__, grouped['group1']))) == ['Group1_1', 'Group1_2']

# Generated at 2022-06-23 19:53:52.010011
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    from pkg_resources import iter_entry_points
    from httpie.plugins import AuthPlugin, FormatterPlugin
    plugin_manager = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugin_manager.register(entry_point.load())
    plugins = plugin_manager.filter(AuthPlugin)
    plugins.extend(plugin_manager.filter(FormatterPlugin))
    assert repr(plugin_manager) == "<PluginManager: "+repr(plugins)+">"

# Generated at 2022-06-23 19:53:55.001798
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager.register(FormatterPlugins)
    PluginManager_get_formatters_grouped = PluginManager.get_formatters_grouped()
    assert PluginManager_get_formatters_grouped == {'group_name': []}

# Generated at 2022-06-23 19:53:58.526236
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    # create a PluginManager obj
    manager = PluginManager()
    # test __repr__ of PluginManager class
    assert repr(manager) == '<PluginManager: []>'

plugins = PluginManager()

# Generated at 2022-06-23 19:54:07.279069
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    manager = PluginManager()
    manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert manager.filter(AuthPlugin) == [AuthPlugin]
    assert manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert manager.filter(TransportPlugin) == [TransportPlugin]
    assert manager.filter() == [AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin]

# Generated at 2022-06-23 19:54:08.667477
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pms = PluginManager()
    pm1 = PluginManager()
    pm1.register(TestAuthPlugin)
    assert pm1.get_auth_plugin_mapping()['test'] == TestAuthPlugin


# Generated at 2022-06-23 19:54:20.462024
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p1 = '''from httpie.plugins.base import BasePlugin
    class MyPlugin(BasePlugin):
        pass
    '''
    p2 = '''from httpie.plugins.base import BasePlugin
    class MyPlugin2(BasePlugin):
        pass
    '''
    p3 = '''from httpie.plugins.base import BasePlugin
    class MyPlugin3(BasePlugin):
        pass
    '''
    p4 = '''from httpie.plugins import AuthPlugin
    class MyPlugin4(AuthPlugin):
        pass
    '''
    p5 = '''from httpie.plugins import AuthPlugin
    class MyPlugin5(AuthPlugin):
        pass
    '''
    ps = [p1,p2,p3,p4,p5]
    exec(ps[0])

# Generated at 2022-06-23 19:54:27.748990
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager_obj = PluginManager()
    # Loading plugins from entry points
    PluginManager_obj.load_installed_plugins()
    formatters_grouped = PluginManager_obj.get_formatters_grouped()
    # check existence in dictionary
    assert "group_name" in formatters_grouped
    assert "group_name1" in formatters_grouped
    assert "group_name2" in formatters_grouped
    assert "group_name3" in formatters_grouped
    # check list of group_name "group_name"
    assert len(formatters_grouped["group_name"]) == 4

# Generated at 2022-06-23 19:54:29.853535
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth
    manager = PluginManager()
    manager.register(HTTPBasicAuth)
    assert manager.get_transport_plugins() == [HTTPBasicAuth]

# Generated at 2022-06-23 19:54:32.712993
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin = PluginManager()
    assert plugin == []
    plugin.register(str)
    assert plugin == [str]
    plugin.unregister(str)
    assert plugin == []

# Generated at 2022-06-23 19:54:34.781091
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager.get_auth_plugins.__doc__ == 'Return List[Type[AuthPlugin]] of plugins associated with the manager'

# Generated at 2022-06-23 19:54:36.144837
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.register(TransportPlugin)
    plugins.get_transport_plugins()

# Generated at 2022-06-23 19:54:38.953052
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # GIVEN
    obj_PluginManager = PluginManager()
    # WHEN
    obj_PluginManager.load_installed_plugins()
    result = obj_PluginManager.get_auth_plugins()
    # THEN
    assert len(result) == 4


# Generated at 2022-06-23 19:54:39.510806
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    PluginManager.get_formatters()

# Generated at 2022-06-23 19:54:50.776808
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test'
    class TestFormatterPlugin(FormatterPlugin):
        name = 'test'
    class TestConverterPlugin(ConverterPlugin):
        name = 'test'
    class TestTransportPlugin(TransportPlugin):
        name = 'test'

    plugin_list = []
    plugin_list.append(TestAuthPlugin)
    plugin_list.append(TestFormatterPlugin)
    plugin_list.append(TestConverterPlugin)
    plugin_list.append(TestTransportPlugin)
    test_plugin_manager = PluginManager()
    test_plugin_manager.register(*plugin_list)

    test_plugin_manager.unregister(TestAuthPlugin)
    assert TestAuthPlugin not in test_plugin_manager.get_auth_plugins()

# Generated at 2022-06-23 19:55:02.343425
# Unit test for constructor of class PluginManager
def test_PluginManager():
    class Authentication:
        def __init__(self, name, age):
            self.name = name
            self.age = age
        def getName(self):
            return self.name
        def getAge(self):
            return self.age
    # Testing PluginManager()
    pm = PluginManager()
    assert isinstance(pm, PluginManager)

    # Testing register()
    a = Authentication("Tom", 34)
    pm.register(a)
    assert pm[0] == a

    # Testing unregister()
    a = Authentication("Jim", 29)
    pm.register(a)
    assert pm[1] == a
    pm.unregister(a)
    assert len(pm) < 2

    # Testing filter()
    a1 = Authentication("Bob", 29)
    a2 = Authentication("Bob", 34)
   

# Generated at 2022-06-23 19:55:03.645576
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    print(PluginManager().get_auth_plugin_mapping())

# Generated at 2022-06-23 19:55:05.294923
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    assert pm == []
    assert pm.register == []


# Generated at 2022-06-23 19:55:05.940380
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()


# Generated at 2022-06-23 19:55:17.709909
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import core
    from httpie.plugins import builtin
    import httpie_echo_plugin
    manager = PluginManager()
    manager.load_installed_plugins()

# Generated at 2022-06-23 19:55:23.302868
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    print(plugin_manager)
    assert plugin_manager == [AuthPlugin]
    print(plugin_manager.filter(AuthPlugin))
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]


# Generated at 2022-06-23 19:55:28.797858
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    class TestPlugin1(BasePlugin):
        pass

    class TestPlugin2(BasePlugin):
        pass

    plugin_manager = PluginManager()

    plugin_manager.register(TestPlugin1, TestPlugin2)

    assert repr(plugin_manager) == '<PluginManager: [<class \'tests.test_plugin_manager.TestPlugin1\'>, <class \'tests.test_plugin_manager.TestPlugin2\'>]>'

# Generated at 2022-06-23 19:55:31.003444
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pmg = PluginManager()
    pmg.load_installed_plugins()
    assert len(pmg.get_converters()) == 3


# Generated at 2022-06-23 19:55:32.252894
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    pm.unregister(Type[AuthPlugin])


# Generated at 2022-06-23 19:55:38.140907
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    import pytest
    from httpie.plugins.auth.v1 import AuthPlugin

    class PluginManagerTestPlugin(AuthPlugin):
        auth_type = 'TestPlugin'

    class PluginManagerTestPlugin2(AuthPlugin):
        auth_type = 'TestPlugin2'

    # Case for two same plugins
    with pytest.raises(KeyError):
        PluginManager().register(PluginManagerTestPlugin, PluginManagerTestPlugin).get_auth_plugin_mapping()

    # Case for two different plugins
    assert len(PluginManager().register(PluginManagerTestPlugin, PluginManagerTestPlugin2).get_auth_plugin_mapping()) == 2

# Generated at 2022-06-23 19:55:41.984082
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    assert not manager.get_formatters()
    manager.register(FormatterPlugin)
    assert len(manager.get_formatters()) == 1
    assert issubclass(manager.get_formatters()[0], FormatterPlugin)


# Generated at 2022-06-23 19:55:46.589754
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_instance = PluginManager()
    plugin_manager_instance.load_installed_plugins()
    assert plugin_manager_instance.get_auth_plugins()
    assert plugin_manager_instance.get_formatters()
    assert plugin_manager_instance.get_converters()
    assert plugin_manager_instance.get_transport_plugins()


# Generated at 2022-06-23 19:55:49.164993
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    assert None != PluginManager().get_auth_plugin("bearer")
    with pytest.raises(Exception):
        PluginManager().get_auth_plugin("invalid")

# Generated at 2022-06-23 19:55:52.543346
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin1=PluginManager()
    plugin1.register(1,2,3)
    print(plugin1)

test_PluginManager_register()

# Generated at 2022-06-23 19:56:02.198635
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class A(BasePlugin):
        pass
    class B(A):
        pass
    class C(BasePlugin):
        pass
    class D(C):
        pass
    plugin_manager = PluginManager()
    plugin_manager.register(A, B, C, D)
    assert plugin_manager.filter(BasePlugin) == [A, B, C, D]
    plugin_manager.unregister(A)
    assert plugin_manager.filter(BasePlugin) == [B, C, D]
    plugin_manager.unregister(C)
    assert plugin_manager.filter(BasePlugin) == [B, D]
    plugin_manager.unregister(D)
    assert plugin_manager.filter(BasePlugin) == [B]
    plugin_manager.unregister(B)

# Generated at 2022-06-23 19:56:05.792640
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    manager.register(tests.plugins.basic_auth.Plugin)
    assert manager.get_auth_plugin('basic') is tests.plugins.basic_auth.Plugin


manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-23 19:56:10.404303
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    assert True == isinstance(plugin_manager, PluginManager)
    plugin_manager.register(BasePlugin)
    assert True == isinstance(plugin_manager,list)
    assert True == isinstance(plugin_manager[0],type)
    plugin_manager.unregister(BasePlugin)
    assert True == plugin_manager == []


# Generated at 2022-06-23 19:56:15.269542
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()

    plugin_manager.load_installed_plugins()

    # testing to see that plugin_manager
    # is a list of a specified size
    assert isinstance(plugin_manager, list)
    assert len(plugin_manager) == 141

    # testing to see that the first item
    # in the list is a subclass of BasePlugin
    assert issubclass(plugin_manager[0], BasePlugin)


# Generated at 2022-06-23 19:56:17.526270
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'
    plugins.register(DummyPlugin)
    assert repr(plugins) == '<PluginManager: [DummyPlugin]>'

# Generated at 2022-06-23 19:56:19.956575
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1)
    plugin_manager.register(Plugin2)

    mapping = plugin_manager.get_auth_plugin_mapping()
    assert mapping == {'plugin1': Plugin1, 'plugin2': Plugin2}


# Generated at 2022-06-23 19:56:29.819035
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()

    from httpie.plugins.builtin import JSONTableFormatterPlugin, JSONPointerFormatterPlugin, \
        JsonLinesFormatterPlugin, URLEncodedFormatterPlugin, JSONLinesPointerFormatterPlugin

    formatter1 = JSONTableFormatterPlugin()
    formatter2 = JSONPointerFormatterPlugin()
    formatter3 = JsonLinesFormatterPlugin()
    formatter4 = URLEncodedFormatterPlugin()
    formatter5 = JSONLinesPointerFormatterPlugin()

    pm.register(formatter1, formatter2, formatter3, formatter4, formatter5)

    repr1 = repr(pm.get_formatters_grouped())

    # As of 2020-09-14, the expected output should be:
    # {'formatter': [<class 'httpie

# Generated at 2022-06-23 19:56:39.188411
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin

    class FooPlugin(FormatterPlugin):
        group_name = 'foo'

    class BarPlugin(FormatterPlugin):
        group_name = 'bar'

    class BazPlugin(FormatterPlugin):
        group_name = 'bar'

    manager = PluginManager()
    manager.register(FooPlugin, BarPlugin, BazPlugin)
    assert manager.get_formatters_grouped() == {
        'foo': [FooPlugin],
        'bar': [BarPlugin, BazPlugin],
    }


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-23 19:56:44.173987
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    plugin_manager.register(PluginManager)
    assert PluginManager in plugin_manager

    plugin_manager.unregister(PluginManager)
    assert PluginManager not in plugin_manager

    return True


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-23 19:56:47.375950
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins.get_converters()



# Generated at 2022-06-23 19:56:49.396308
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert isinstance(pm.get_transport_plugins(), list)

# Generated at 2022-06-23 19:56:57.508817
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register(AuthPlugin)
    manager.register(FormatterPlugin)
    manager.register(ConverterPlugin)
    manager.register(TransportPlugin)
    assert manager.unregister(AuthPlugin) is None
    a = manager.filter(AuthPlugin)
    assert a == []
    manager.register(AuthPlugin)
    assert manager.unregister(TransportPlugin) is None
    assert manager.unregister(ConverterPlugin) is None
    a = manager.filter(ConverterPlugin)
    assert a == []
    b = manager.filter(TransportPlugin)
    assert b == []
    manager.unregister(FormatterPlugin)
    assert manager.unregister(AuthPlugin) is None

# Generated at 2022-06-23 19:56:59.893524
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    assert len(plugins.get_formatters_grouped()) == 1
    assert len(list(plugins.get_formatters_grouped().values())[0]) == 3

# Generated at 2022-06-23 19:57:01.229525
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.register(FormatterPlugin)
    a = pm.get_formatters()
    
    assert a
    

# Generated at 2022-06-23 19:57:03.579020
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugins = []
    PluginManager.register(*plugins)

# Generated at 2022-06-23 19:57:08.030264
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    manager = PluginManager()

# Generated at 2022-06-23 19:57:10.870296
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(auth_type='a')
    plugins.register(auth_type='b')
    plugins.get_auth_plugin_mapping()


# Generated at 2022-06-23 19:57:13.994150
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    assert len(pm) == 0
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert pm[0].__name__ == 'HTTPBasicAuth'
    assert pm[0].__cli_name__ == 'basic'

# Generated at 2022-06-23 19:57:17.288126
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters())==6



# Generated at 2022-06-23 19:57:21.841750
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert len(plugin_manager) == 4



# Generated at 2022-06-23 19:57:25.053197
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    formatters = pm.get_formatters()
    print(formatters,len(formatters))
    # assert len(formatters) == 2, f'len(formatters)={len(formatters)}'
    for formatter in formatters:
        print(formatter)

# Generated at 2022-06-23 19:57:31.175011
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import BuiltinFormatterPlugin
    from httpie.plugins.human import HumanFormatterPlugin
    from httpie.plugins.tui import ANSIFormatterPlugin
    from httpie.plugins.html import HTMLFormatterPlugin

    manager = PluginManager()

    manager.register(BuiltinFormatterPlugin)
    manager.register(ANSIFormatterPlugin)
    manager.register(HTMLFormatterPlugin)
    manager.register(HumanFormatterPlugin)

    formatter_group = manager.get_formatters_grouped()
    assert('builtin' in formatter_group)
    assert ('html' in formatter_group)
    assert ('ansi' in formatter_group)
    assert ('human' in formatter_group)

# Generated at 2022-06-23 19:57:35.322877
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    assert len(pm) > 0, 'PluginManager should contain plugins'
    assert all(map(lambda p: isinstance(p, BasePlugin), pm)), 'PluginManager should only contain BasePlugin-s'

# Generated at 2022-06-23 19:57:40.384489
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(DummyFormatterPluginA, DummyFormatterPluginB, DummyFormatterPluginC)
    plugin_manager.get_formatters_grouped()
    assert plugin_manager.get_formatters_grouped() == {'A': [DummyFormatterPluginA], 'B': [DummyFormatterPluginB], 'C': [DummyFormatterPluginC]}



# Generated at 2022-06-23 19:57:42.025096
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    PluginManager().get_auth_plugins()


# Generated at 2022-06-23 19:57:45.123465
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert plugin_manager == []
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.filter() == [AuthPlugin]
    assert plugin_manager.filter(TransportPlugin) == []


# Generated at 2022-06-23 19:57:46.717853
# Unit test for method get_transport_plugins of class PluginManager

# Generated at 2022-06-23 19:57:49.968400
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    x = PluginManager()
    x.load_installed_plugins()
    x.get_converters()
    assert True

# Generated at 2022-06-23 19:58:01.035566
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter() == []
    assert (PluginManager(['one', 'two', 'three', 'four', 'five']).filter() ==
            ['one', 'two', 'three', 'four', 'five'])
    assert(PluginManager(['one', 'two', 'three', 'four', 'five']).filter(str) ==
           ['one', 'two', 'three', 'four', 'five'])
    assert(PluginManager(['one', 'two', 'three', 'four', 'five']).filter(int) ==
           [])
    assert (PluginManager(['one', 'two', 'three', 'four', 'five']).filter(list) ==
            ['one', 'two', 'three', 'four', 'five'])

# Generated at 2022-06-23 19:58:04.104907
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    transport_plugins = pm.get_transport_plugins()
    assert len(transport_plugins) == 1
    assert transport_plugins[0].__name__ == 'HTTPPlugin'


# Generated at 2022-06-23 19:58:08.423388
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(HttpiePlugin)
    plugins.register(HttpbinPlugin)
    print(plugins.get_formatters())

if __name__ == '__main__':
    test_PluginManager_get_formatters()

# Generated at 2022-06-23 19:58:09.893531
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
	assert PluginManager().__repr__() == "<PluginManager: []>"

# Generated at 2022-06-23 19:58:13.189870
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    try:
        PluginManager_obj = PluginManager() 
        PluginManager_obj.load_installed_plugins()
    except Exception as e:
        print(e)
    finally:
        print("Test finished")


# Generated at 2022-06-23 19:58:14.916425
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    class A():
        pass
    class B():
        pass
    manager.register(A,B)
    assert len(manager) == 2


# Generated at 2022-06-23 19:58:16.848781
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    assert repr(PluginManager()) == '<PluginManager: []>'
    assert repr(PluginManager((int, bool))) == '<PluginManager: [<class \'int\'>, <class \'bool\'>]>'

# Generated at 2022-06-23 19:58:18.897839
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-23 19:58:22.240862
# Unit test for constructor of class PluginManager
def test_PluginManager():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_auth_plugins()
    assert isinstance(plugin_manager, PluginManager)
    assert isinstance(plugins, List)



# Generated at 2022-06-23 19:58:24.453319
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin = BasePlugin()
    plugm = PluginManager()
    plugm.register(plugin)
    assert plugm.filter() == [plugin]

# Generated at 2022-06-23 19:58:27.275323
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    assert isinstance(plugins.get_auth_plugins(), list)
    assert any(p.__name__ == 'DigestAuthPlugin' for p in plugins.get_auth_plugins())



# Generated at 2022-06-23 19:58:31.386107
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(
        AConverterPlugin,
        BConverterPlugin,
        CConverterPlugin,
    )
    converters = pm.get_converters()
    assert [
        AConverterPlugin,
        BConverterPlugin,
        CConverterPlugin,
    ] == converters



# Generated at 2022-06-23 19:58:32.225373
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()


# Generated at 2022-06-23 19:58:36.449542
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()

    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin21(Plugin2):
        pass

    class Plugin3(Plugin2):
        pass

    pm.register(Plugin1, Plugin2, Plugin3, Plugin21)
    assert len(pm.filter(Plugin2)) == 1
    assert len(pm.filter(Plugin21)) == 1



# Generated at 2022-06-23 19:58:45.491383
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import DEFAULT_PLUGINS

    plugins = list(DEFAULT_PLUGINS)
    plugins.append(FormatPluginB)
    plugins.append(FormatPluginC)

    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)

    formatters_grouped = plugin_manager.get_formatters_grouped()
    formatter_groups = content_formatter_groups = [
        'JSON', 'JSON Lines', 'XML', 'YAML', 'INI', 'HTML', 'Extras Group 1', 'Extras Group 2'
    ]
    assert len(formatter_groups) == len(formatters_grouped)
    for key in formatter_groups:
        assert key in formatters_grouped


# Generated at 2022-06-23 19:58:53.008553
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    entry_point_names = ['httpie.plugins.auth.v1', 'httpie.plugins.formatter.v1', 'httpie.plugins.converter.v1', 'httpie.plugins.transport.v1']
    for entry_point_name in entry_point_names:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            PluginManager.append(plugin)

# Generated at 2022-06-23 19:59:00.352037
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}
    plugin_manager = PluginManager()
    plugin_manager.register(TestAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {
        'test-auth-plugin': TestAuthPlugin
    }
    try:
        assert plugin_manager.get_auth_plugin_mapping()['test-auth-plugin']
    except Exception:
        raise Exception("Test of PluginManager.get_auth_plugin_mapping ERROR")



# Generated at 2022-06-23 19:59:05.729220
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import BuiltinAuthPlugin, BuiltinFormatterPlugin
    plugins = PluginManager()
    plugins.register(BuiltinAuthPlugin)
    plugins.register(BuiltinFormatterPlugin)
    plugins_auth = plugins.filter(by_type=AuthPlugin)
    plugins_formatter = plugins.filter(by_type=FormatterPlugin)
    assert plugins_auth and plugins_formatter
    assert len(list(plugins_auth)) == 1 and len(list(plugins_formatter)) == 1

# Generated at 2022-06-23 19:59:08.301260
# Unit test for constructor of class PluginManager
def test_PluginManager():
    #Arrange
    #Act
    plugin_manager = PluginManager()
    #Assert
    assert plugin_manager
    assert isinstance(plugin_manager, list)

# Generated at 2022-06-23 19:59:09.896460
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert PluginManager().load_installed_plugins()
    

# Generated at 2022-06-23 19:59:11.310674
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    p = PluginManager()
    assert p.get_transport_plugins() == []

# Generated at 2022-06-23 19:59:16.981581
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    formatters = plugin_manager.get_formatters()
    assert formatters  # Make sure there are some formatters installed
    assert len(formatters) > 0


# Generated at 2022-06-23 19:59:21.524760
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    #print(PluginManager()[])
    assert PluginManager()[0] == BasePlugin
    assert PluginManager.get_transport_plugins() =="<PluginManager: [<class 'httpie.plugins.base.BasePlugin'>, <class 'httpie.plugins.transport.http.HTTPTransport'>, <class 'httpie.plugins.transport.httpie.HTTPieTransport'>]>"
    assert PluginManager.get_transport_plugins() != "<PluginManager: [<class 'httpie.plugins.base.BasePlugin'>, <class 'httpie.plugins.transport.http.HTTPTransport'>, <class 'httpie.plugins.transport.httpie.HTTPieTransport'>]>"

# Generated at 2022-06-23 19:59:26.350314
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(converter_plus.URIConverter, converter_plus.JSONConverter)
    converters = pm.get_converters()
    assert len(converters) == 2
    assert converter_plus.URIConverter in converters
    assert converter_plus.JSONConverter in converters

# Generated at 2022-06-23 19:59:27.616809
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    assert pm.get_transport_plugins() == []
    pm.register(TransportPlugin)
    assert pm.get_transport_plugins() == [TransportPlugin]


# Generated at 2022-06-23 19:59:34.279766
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    class ExamplePlugin(AuthPlugin):
        auth_type = 'example'
    class ExamplePlugin2(AuthPlugin):
        auth_type = 'example'
    plugin_manager.register(ExamplePlugin, ExamplePlugin2)
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(mapping) == 1
    assert mapping['example'] == ExamplePlugin
    assert ExamplePlugin in plugin_manager
# Test complete


# Generated at 2022-06-23 19:59:36.119001
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    assert len(pm) == 0
    assert repr(pm) == '<PluginManager: []>'


# Generated at 2022-06-23 19:59:38.001479
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager.get_auth_plugins()

# Generated at 2022-06-23 19:59:40.290248
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    x = PluginManager()
    assert x.filter() == []


# todo: add test for method register of class PluginManager

# Generated at 2022-06-23 19:59:42.037388
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# Generated at 2022-06-23 19:59:46.988896
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import URLEncodedConverter
    from httpie.plugins.builtin import DefaultConverter
    plugin_manager = PluginManager()
    assert plugin_manager.get_converters() == [JSONConverter, URLEncodedConverter, DefaultConverter]



# Generated at 2022-06-23 19:59:48.038752
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert isinstance(PluginManager(), PluginManager)

# Generated at 2022-06-23 19:59:51.318833
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.plugins.builtin import HTTPiePlugin

    plugins = PluginManager()
    plugins.register(HTTPiePlugin)
    assert plugins.get_transport_plugins() == [HTTPiePlugin]


# Generated at 2022-06-23 19:59:54.559188
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    # install some fake plugin
    pm.register(type('mock', (BasePlugin,), {}))
    assert len(pm) == 5
    assert len(pm[0].__class__.__name__) == 1

# Generated at 2022-06-23 20:00:03.635550
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    assert len(p) == 0
    assert p.get_auth_plugins() == []
    assert p.get_formatters() == []
    assert p.get_formatters_grouped() == {}
    assert p.get_converters() == []
    assert p.get_transport_plugins() == []

    class mock_plugin():
        pass

    p.register(mock_plugin)
    assert len(p) == 1
    assert p.get_auth_plugins() == [mock_plugin]
    assert p.get_formatters() == [mock_plugin]
    assert p.get_converters() == [mock_plugin]
    assert p.get_transport_plugins() == [mock_plugin]



# Generated at 2022-06-23 20:00:05.845926
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    p = PluginManager()

# Generated at 2022-06-23 20:00:09.159722
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins_mgr = PluginManager()
    assert repr(plugins_mgr) == '<PluginManager: []>'

    plugins_mgr.append(1)
    assert repr(plugins_mgr) == '<PluginManager: [1]>'

# Generated at 2022-06-23 20:00:13.205651
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    # Create PluginManager
    plugin_manager = PluginManager()
    # Register some plugins
    plugin_manager.register(
        TestAuthPlugin,
        TestAuthPlugin,
    )
    # Get plugin using method get_auth_plugin()
    plugin = plugin_manager.get_auth_plugin('test')
    # Check if the result is right
    assert plugin == TestAuthPlugin


# Generated at 2022-06-23 20:00:14.644874
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert 'PluginManager' in str(pm)

instance = PluginManager()

# Generated at 2022-06-23 20:00:19.560669
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    
    # Initialize variable
    plugin_manager = PluginManager()
    plugin = BasePlugin()
    
    # Register plugin
    plugin_manager.register(plugin)
    
    # Check whether the plugin is registered
    assert plugin_manager[0] == plugin



# Generated at 2022-06-23 20:00:21.432610
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    pluginManager.register()
    pluginManager.load_installed_plugins()



# Generated at 2022-06-23 20:00:23.749091
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginmanager = PluginManager()
    pluginmanager.register(AuthPlugin)
    assert pluginmanager.get_auth_plugin_mapping() == {'basic': AuthPlugin}


# Generated at 2022-06-23 20:00:24.862796
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}


# Generated at 2022-06-23 20:00:26.588731
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager.get_converters(), list)


# Generated at 2022-06-23 20:00:29.462407
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    class TestPlugin(BasePlugin):
        pass
    plugin_manager.register(TestPlugin)
    assert plugin_manager == [TestPlugin]
    plugin_manager.unregister(TestPlugin)
    assert plugin_manager == []

# Generated at 2022-06-23 20:00:32.523374
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    assert plugins.get_auth_plugins() == []
    plugins.append('PluginManager')
    plugins.append("Hello")
    plugins.append("World")
    assert plugins.get_auth_plugins() == ["PluginManager", "Hello", "World"]


# Generated at 2022-06-23 20:00:33.857401
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    assert len(plugins) == 0
    plugins.register('test')
    assert len(plugins) == 1


# Generated at 2022-06-23 20:00:34.926078
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    assert PluginManager().get_auth_plugins == []

# Generated at 2022-06-23 20:00:42.837023
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin

    # Create an instance of PluginManager
    plugins = PluginManager()

    # Create a collection of plugins and add them to the manager
    plugins.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)

    # Get the plugin list
    plugin_list = plugins.filter(FormatterPlugin)

    # Test length of the plugin list
    assert len(plugin_list) == 3

# Generated at 2022-06-23 20:00:50.892756
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(DebugPlugin())
    plugin_manager.register(HeadersPlugin())
    plugin_manager.register(PrettyJsonPlugin())
    plugin_manager.register(PrettyColorsPlugin())
    plugin_manager.register(PrettyAllOutputPlugin())
    plugin_manager.register(BodyColorsPlugin())
    plugin_manager.register(ColoredStreamPlugin())
    plugin_manager.register(CurlColorsPlugin())
    plugin_manager.register(BodyJsonPlugin())
    plugin_manager.register(BodyColorsPlugin())
    plugin_manager.register(BodySchemaPlugin())
    plugin_manager.register(BodyAllPlugin())
    plugin_manager.register(BodyJsonPlugin())
    plugin_manager.register(BodySchemaPlugin())