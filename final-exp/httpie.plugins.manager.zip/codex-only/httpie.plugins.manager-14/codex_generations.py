

# Generated at 2022-06-23 19:50:52.079206
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    assert isinstance(manager, list)



# Generated at 2022-06-23 19:51:03.140867
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.compat import is_windows

    pm = PluginManager()
    pm.register(
        type(
            'pygmentize',
            (FormatterPlugin,),
            {'name': 'pygmentize', 'group_name': 'syntax'},
        )
    )
    pm.register(
        type(
            'format',
            (FormatterPlugin,),
            {'name': 'format', 'group_name': 'colored'},
        )
    )
    pm.register(
        type(
            'format',
            (FormatterPlugin,),
            {'name': 'format', 'group_name': 'syntax'},
        )
    )
    formatters = pm.get_formatters()
    assert len(formatters) == 3


# Generated at 2022-06-23 19:51:05.847672
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(AuthPlugin)

    assert(manager.filter(AuthPlugin) == [AuthPlugin])
    assert(manager.filter(TransportPlugin) == [])



# Generated at 2022-06-23 19:51:07.753035
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert len(p) != 0


# Generated at 2022-06-23 19:51:15.343503
# Unit test for method load_installed_plugins of class PluginManager

# Generated at 2022-06-23 19:51:20.414349
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from .transport import HttpTransport, HttpsTransport
    test_pm = PluginManager()

    from .transport import HttpTransport, HttpsTransport
    transport_plugins = test_pm.get_transport_plugins()
    assert HttpTransport in transport_plugins
    assert HttpsTransport in transport_plugins



# Generated at 2022-06-23 19:51:29.381902
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    auth = [AuthPlugin]

    class T1(TransportPlugin):
        pass

    class T2(TransportPlugin):
        pass
    transport = [T1, T2]

    class F1(FormatterPlugin):
        pass

    class F2(FormatterPlugin):
        pass
    formatter = [F1, F2]

    class C1(ConverterPlugin):
        pass

    class C2(ConverterPlugin):
        pass
    converter = [C1, C2]

    plugin_manager = PluginManager()
    plugin_manager.register(*auth, *transport, *formatter, *converter)
    assert plugin_manager.filter(AuthPlugin) == auth
    assert plugin_manager.filter(TransportPlugin) == transport
    assert plugin_manager.filter(FormatterPlugin) == formatter


# Generated at 2022-06-23 19:51:36.327904
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Foo(BasePlugin):  
        pass

    class Bar(BasePlugin):
        pass
    
    class FooBar(BasePlugin):
        pass

    foo = Foo()
    bar = Bar()
    manager = PluginManager()

    manager.register(Foo, Bar)
    manager.unregister(Foo)
    assert Foo not in manager

    manager.register(FooBar)
    manager.unregister(FooBar)
    assert FooBar not in manager

    # Test for exception  
    try:
        manager.unregister(Foo)

    except Exception as e:
        assert type(e) == ValueError

    else:
        assert False


# Generated at 2022-06-23 19:51:42.573908
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    manager = PluginManager()
    manager.register(A, B)
    assert repr(manager) == "<PluginManager: [<class '__main__.A'>, <class '__main__.B'>]>"
    manager.unregister(A)
    assert repr(manager) == "<PluginManager: [<class '__main__.B'>]>"


# Generated at 2022-06-23 19:51:46.335885
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.register(AuthPlugin, TransportPlugin)
    assert repr(pm) == '<PluginManager: [<class \'httpie.plugins.base.AuthPlugin\'>, <class \'httpie.plugins.base.TransportPlugin\'>]>'

# Generated at 2022-06-23 19:51:51.567420
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager_test = PluginManager()
    plugin_manager_test.register(AuthPlugin)
    assert len(plugin_manager_test) == 1
    plugin_manager_test.unregister(AuthPlugin)
    assert len(plugin_manager_test) == 0


# Generated at 2022-06-23 19:51:54.384922
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    actual = len(plugins) >= 2
    expected = True
    assert actual == expected
# end test_PluginManager_load_installed_plugins



# Generated at 2022-06-23 19:52:01.093390
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.formatters.colors import (
        COLOR_OPTIONS_MAP,
        ColorsFormatterPlugin,
        style_error,
        style_note,
        style_success,
        style_warning,
    )
    from httpie.plugins import FormatterPlugin
    plugins = PluginManager()
    assert plugins.get_formatters() == []
    plugins.register(ColorsFormatterPlugin())
    assert plugins.get_formatters() == [ColorsFormatterPlugin]
    assert plugins.get_formatters_grouped()[FormatterPlugin.DEFAULT_GROUP_NAME] == [ColorsFormatterPlugin]
    assert plugins.get_formatters_grouped() is not None
    assert plugins.get_formatters() is not None

# Generated at 2022-06-23 19:52:03.318201
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager)>0, "PluginManager can't load plugins"



# Generated at 2022-06-23 19:52:07.951344
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p = PluginManager()
    assert not p.load_installed_plugins()
    assert not p.filter(TransportPlugin)
    assert not p.filter(AuthPlugin)
    assert not p.filter(ConverterPlugin)
    assert not p.filter(FormatterPlugin)

# Generated at 2022-06-23 19:52:14.471526
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    manager = PluginManager()
    auth_plugins = manager.get_auth_plugins()
    auth_type_mapping = manager.get_auth_plugin_mapping()
    plugin = manager.get_auth_plugin(auth_plugin.auth_type)
    assert len(auth_plugins) >= 1
    assert len(auth_type_mapping) >= 1
    assert isinstance(plugin, AuthPlugin)



# Generated at 2022-06-23 19:52:23.122705
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    class Formatter1(FormatterPlugin):
        group_name = 'group1'

    class Formatter2(FormatterPlugin):
        group_name = 'group2'

    class Formatter3(FormatterPlugin):
        group_name = 'group1'

    class Formatter4(FormatterPlugin):
        group_name = 'group1'

    class Formatter5(FormatterPlugin):
        group_name = 'group2'


    plugin_list = [Formatter1,Formatter2,Formatter3,Formatter4,Formatter5]

    plugin_manager = PluginManager()
    plugin_manager.register(*plugin_list)

    def get_formatters_grouped_by_method():
        return plugin_manager.get_formatters_grouped()

# Generated at 2022-06-23 19:52:25.144670
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0



# Generated at 2022-06-23 19:52:26.454570
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()

# Generated at 2022-06-23 19:52:33.428467
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class TestPlugin(BasePlugin):
        pass
    class TestPlugin2(BasePlugin):
        pass
    manager = PluginManager()
    assert len(manager) == 0
    manager.register(TestPlugin)
    manager.register(TestPlugin2)
    assert len(manager) == 2
    assert TestPlugin in manager
    assert TestPlugin2 in manager
    assert TestPlugin in manager.filter(TestPlugin)
    assert TestPlugin2 in manager.filter(TestPlugin2)
    manager.unregister(TestPlugin)
    assert len(manager) == 1
    assert TestPlugin not in manager
    assert TestPlugin2 in manager
    assert TestPlugin not in manager.filter(TestPlugin)
    assert TestPlugin2 in manager.filter(TestPlugin2)

# Generated at 2022-06-23 19:52:37.905551
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert isinstance(plugin_manager.get_auth_plugins()[0], AuthPlugin)


# Generated at 2022-06-23 19:52:40.247859
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugins = PluginManager()
    plugins.register()
    assert plugins == []


# Generated at 2022-06-23 19:52:41.325933
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Unit test for class PluginManager
    pm = PluginManager()
    pm.load_installed_plugins()



# Generated at 2022-06-23 19:52:45.744685
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():

    # Arrange
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # Act
    formatters = plugin_manager.get_formatters()

    # Assert
    assert len(formatters) > 0
    assert formatters[0].group_name is not None
    print(f'Number of formatters (output processors): {len(formatters)}')


# Generated at 2022-06-23 19:52:47.775566
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}


plugins = PluginManager()

# Generated at 2022-06-23 19:52:50.208465
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    print(pm)

test_PluginManager()

# -----------

# Generated at 2022-06-23 19:52:51.845325
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    pm.register(PluginA)
    assert pm[0] == PluginA


# Generated at 2022-06-23 19:52:58.374738
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert plugin_manager.__repr__() == '<PluginManager: []>'
    from httpie.plugins.httpproxy import HTTPProxyAuthPlugin
    from httpie.plugins.formatter.colors import (
        Python2BuiltinFormatter
    )
    plugin_manager.register(Python2BuiltinFormatter, HTTPProxyAuthPlugin)
    assert plugin_manager.__repr__() == \
    '<PluginManager: [<class \'httpie.plugins.formatter.colors.Python2BuiltinFormatter\'>, <class \'httpie.plugins.httpproxy.HTTPProxyAuthPlugin\'>]>'



# Generated at 2022-06-23 19:53:00.277548
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register(DummyPlugin)
    assert pm.get_converters() == [DummyPlugin]

# Generated at 2022-06-23 19:53:11.498971
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie import __main__
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.auth import AuthPlugin, BasicAuth

    # The basic auth should be default auth for httpie
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['basic'] == BasicAuth

    # Add a custom auth plugin
    class CustomAuth(AuthPlugin):
        auth_type = 'custom'

    # Register the custom auth plugin
    __main__.plugin_manager.register(CustomAuth)

    # The basic auth should be default auth for httpie
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['custom'] == CustomAuth

# Generated at 2022-06-23 19:53:12.658037
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    from httpie.output.formatters.colors import Color

# Generated at 2022-06-23 19:53:13.844734
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pl = PluginManager()
    pl.unregister('plugin')
    assert pl == []


# Generated at 2022-06-23 19:53:17.548995
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    auth_type = "basic"
    class AuthPlugin:
        auth_type = "basic"
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin(auth_type) == AuthPlugin


# Generated at 2022-06-23 19:53:23.780558
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    transport_plugins = PluginManager().get_transport_plugins()
    assert len(transport_plugins) == 2
    assert transport_plugins[0].__name__ == 'HTTPTransport'
    assert transport_plugins[1].__name__ == 'FFTransport'
    print('PASS: test_PluginManager_get_transport_plugins')

if __name__ == '__main__':
    test_PluginManager_get_transport_plugins()

# Generated at 2022-06-23 19:53:35.307689
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import TransportPlugin
    from httpie.plugins.base import BasePlugin
    pm = PluginManager()
    # Unit test for method register of class PluginManager without argument
    try:
        pm.register()
    except TypeError:
        assert True
    else:
        assert False
    # Unit test for method register of class PluginManager with argument list that have wrong type
    try:
        pm.register(1,2)
    except TypeError:
        assert True
    else:
        assert False
    # Unit test for method register of class PluginManager with argument list that have wrong type
    try:
        pm.register(BasePlugin, 0)
    except TypeError:
        assert True
   

# Generated at 2022-06-23 19:53:40.376309
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    class Foo(BasePlugin):
        pass

    class Bar(BasePlugin):
        pass

    manager = PluginManager()
    manager.append(Foo)
    manager.append(Bar)

    assert repr(manager) == '<PluginManager: [<class \'Foo\'>, <class \'Bar\'>]>'



# Generated at 2022-06-23 19:53:44.177660
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    auth_type = 'basic'
    plugin_manager = PluginManager()
    plugin_manager.register(BasicAuthPlugin)
    plugin = plugin_manager.get_auth_plugin(auth_type)
    assert plugin.auth_type == auth_type

# Generated at 2022-06-23 19:53:45.479973
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin = PluginManager()
    assert plugin.register(AuthPlugin)


# Generated at 2022-06-23 19:53:51.964908
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    mgr = PluginManager()
    PluginManager().register(type('PluginA', (object, ), {'name': 'PluginA'}))
    PluginManager().register(type('PluginB', (object, ), {'name': 'PluginB'}))
    mgr.register(type('PluginA', (object, ), {'name': 'PluginA'}))
    mgr.register(type('PluginB', (object, ), {'name': 'PluginB'}))
    mgr.unregister(type('PluginB', (object,), {'name': 'PluginB'}))
    assert mgr[0].name == 'PluginA'
    assert len(mgr) == 1


# Generated at 2022-06-23 19:53:54.633157
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    # print(pm)


## Unit test for method get_auth_plugins of class PluginManager

# Generated at 2022-06-23 19:54:00.619383
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Unit test for method get_formatters_grouped of class PluginManager
    from httpie.cli.formatter import Formatter, FORMAT_STYLES
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin
    from httpie.plugins.group_output import PrintOutputMixin

    class TestFormatterPlugin(FormatterPlugin, PrintOutputMixin):
        def __init__(self):
            self.group_name = 'Test Group'
            self.grouped = True

            self.formatters = [
                TestFormatter1(),
                TestFormatter2(),
                TestFormatter3(),
                TestFormatter4(),
            ]

    class TestFormatter1(Formatter):
        name = 'TestFormatter1'


# Generated at 2022-06-23 19:54:02.879706
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(Unregister)
    plugins.unregister(Unregister)
    assert plugins == []


# Generated at 2022-06-23 19:54:12.241213
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # prepare data
    class ExampleFormatterPlugin1(FormatterPlugin):
        format_name = 'example1'
    class ExampleFormatterPlugin2(FormatterPlugin):
        format_name = 'example2'
    class ExampleConverterPlugin(ConverterPlugin):
        convert_name = 'example'
    class ExampleAuthPlugin(AuthPlugin):
        auth_type = 'example'
    class ExampleTransportPlugin(TransportPlugin):
        pass

    plugins = PluginManager()
    plugins.register(ExampleFormatterPlugin1, ExampleFormatterPlugin2, ExampleConverterPlugin, ExampleAuthPlugin, ExampleTransportPlugin)
    # run the filter
    output = plugins.filter(FormatterPlugin)
    assert output == [ExampleFormatterPlugin1, ExampleFormatterPlugin2]
    assert isinstance(output[0], FormatterPlugin)
   

# Generated at 2022-06-23 19:54:19.007129
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    list_of_plugins = list()
    plugin1 = BasePlugin()
    plugin2 = AuthPlugin()
    plugin3 = BasePlugin()
    list_of_plugins.register(plugin1, plugin2, plugin3)
    assert plugin1 in list_of_plugins and plugin2 in list_of_plugins and plugin3 in list_of_plugins, 'Should be registered'


# Generated at 2022-06-23 19:54:29.162370
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    import httpie.plugins.builtin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPHeaderAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPNTLMAuth
    PluginManager().register(HTTPBasicAuth, HTTPHeaderAuth, HTTPBearerAuth, HTTPProxyAuth, HTTPDigestAuth, HTTPNTLMAuth)
    assert PluginManager().get_auth_plugin('basic') == HTTPBasicAuth
    assert PluginManager().get_auth_plugin('header') == HTTPHeaderAuth
    assert PluginManager().get_auth_plugin('bearer') == HTTPBearerAuth
    assert PluginManager().get

# Generated at 2022-06-23 19:54:32.360738
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    pm = PluginManager()
    pm.append(4)
    pm.append(2)
    assert f'<PluginManager: {[4, 2]}>' == pm.__repr__()

# Generated at 2022-06-23 19:54:36.771799
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class PluginA(BasePlugin):
        pass
    class PluginB(BasePlugin):
        pass
    class PluginC(BasePlugin):
        pass
    plugins = PluginManager()
    plugins.register(PluginA, PluginB, PluginC)
    # test
    plugins.unregister(PluginB)
    assert not (PluginB in plugins)
    assert PluginA in plugins and PluginC in plugins


# Generated at 2022-06-23 19:54:38.349297
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) >= 7

# Generated at 2022-06-23 19:54:42.365423
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins_obj = PluginManager()
    auth_plugins = plugins_obj.get_auth_plugins()  # type: List[Type[AuthPlugin]]
    assert isinstance(auth_plugins, list)


# Generated at 2022-06-23 19:54:44.032955
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    plugin_manager.register(AuthPlugin)
    assert plugin_manager[0] == BasePlugin
    assert plugin_manager[1] == AuthPlugin


# Generated at 2022-06-23 19:54:52.138656
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager.get_transport_plugins(), List)
    assert plugin_manager.get_transport_plugins() == []

    # Assert that all the entries in the list are of the type TransportPlugin
    for plugin in plugin_manager.get_transport_plugins():
        assert isinstance(plugin, TransportPlugin)

    plugin_manager.register(httpie.plugins.TestPlugin)
    assert plugin_manager.get_transport_plugins() == [httpie.plugins.TestPlugin]
    plugin_manager.unregister(httpie.plugins.TestPlugin)
    assert plugin_manager.get_transport_plugins() == []


# Generated at 2022-06-23 19:54:55.376877
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    enabledPlugins = plugin_manager.load_installed_plugins()
    assert len(enabledPlugins) == 4


# Generated at 2022-06-23 19:54:56.455358
# Unit test for constructor of class PluginManager
def test_PluginManager():
    PluginManager()


# Generated at 2022-06-23 19:54:58.521016
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    p = PluginManager()
    assert p.get_auth_plugin('basic') is None



# Generated at 2022-06-23 19:55:04.466491
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()
    assert pluginManager != None

    assert pluginManager.get_auth_plugins() == []
    assert pluginManager.get_auth_plugin_mapping() == {}
    assert pluginManager.get_formatters() == []
    assert pluginManager.get_formatters_grouped() == {}
    assert pluginManager.get_converters() == []
    assert pluginManager.get_transport_plugins() == []


# Generated at 2022-06-23 19:55:06.571878
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.register(Mock1, Mock2)
    assert pm.get_transport_plugins() == [Mock1]


# Generated at 2022-06-23 19:55:11.835002
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    from httpie.compat import str
    from httpie.plugins import TransportPlugin
    from httpie.transport.http import HTTPTransportAdapter
    from httpie.transport.ssh import SSHTransportAdapter

    manager = PluginManager()

    manager.register(HTTPTransportAdapter, SSHTransportAdapter)

    assert len(manager.get_transport_plugins()) == 2
    assert type(manager.get_transport_plugins()[0]) == type(TransportPlugin)
    assert type(manager.get_transport_plugins()[1]) == type(TransportPlugin)
    print("test_PluginManager_get_transport_plugins: ok")

if __name__ == '__main__':
    test_PluginManager_get_transport_plugins()

# Generated at 2022-06-23 19:55:14.406936
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert type(pm.get_formatters()) == list


# Generated at 2022-06-23 19:55:20.047190
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    plugins = PluginManager()
    plugins.register(plugins_object.formatters)
    plugins.register(plugins_object.converters)
    plugins.register(plugins_object.transport)
    unique_converters = [
        'MultipartFormDataConverter',
        'URLEncodeConverter',
        'JsonConverter',
        'StringConverter'
    ]
    converters = plugins.get_converters()
    converters_name = [c.__name__ for c in converters]
    assert set(unique_converters) == set(converters_name)


# Generated at 2022-06-23 19:55:28.888473
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    """Test that method __repr__ of class PluginManager
    which returns a string of the class name,
    the list's string representation (list of class names)
    and an angle bracket pair.
    """
    from httpie.plugins.builtin import (
        JSONStreamFormatter, PrettyJsonFormatter,
    )
    plugin_manager = PluginManager()
    plugin_manager.register(
        JSONStreamFormatter,
        PrettyJsonFormatter,
    )
    assert plugin_manager.__repr__() == \
        '<PluginManager: [JSONStreamFormatter, PrettyJsonFormatter]>'


# Generated at 2022-06-23 19:55:30.786579
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    mgr = PluginManager()
    mgr.register(1, 2)
    assert len(mgr) == 2



# Generated at 2022-06-23 19:55:34.041015
# Unit test for method register of class PluginManager
def test_PluginManager_register():
	"""register is used to add plugins in PluginManager list"""
	pm = PluginManager()
	import inspect
	test_plugin = type(inspect.getmodule(test_PluginManager_register))
	pm.register(test_plugin)
	assert test_plugin in pm


# Generated at 2022-06-23 19:55:36.466545
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    from httpie.plugins.builtin import HTTPBasicAuth
    plugin_manager.register(HTTPBasicAuth)
    assert plugin_manager == [HTTPBasicAuth]


# Generated at 2022-06-23 19:55:39.566886
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin)
    assert len(manager) == 3


# Generated at 2022-06-23 19:55:43.088756
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugins = PluginManager()
    plugins.register(AuthPlugin)

    assert len(plugins) == 1
    plugins.unregister(AuthPlugin)
    assert len(plugins) == 0
    print('test_PluginManager_unregister passed')


# Generated at 2022-06-23 19:55:44.850383
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    assert pm.get_converters() == []


# Generated at 2022-06-23 19:55:48.355489
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    a=PluginManager()
    a.load_installed_plugins()
    b=len(a)
    c=a[b-1]
    a.register(c)
    assert (b+1)==len(a)


# Generated at 2022-06-23 19:55:51.904136
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    assert isinstance(manager, list)
    assert manager == []

# Tests for loading of installed plugins

# Generated at 2022-06-23 19:55:53.701349
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager is not None

# Generated at 2022-06-23 19:55:57.269855
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    from httpie.plugins.auth.basic import BasicAuthPlugin, PluginClient
    plugins.register(BasicAuthPlugin)
    print(BasicAuthPlugin)
    print(PluginClient)
    print(plugins.get_auth_plugin_mapping())


# Generated at 2022-06-23 19:56:02.040689
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.register(Plugin1, Plugin2)
    assert plugins.get_auth_plugins() == [Plugin2]


# Create a new instance of PluginManager
# Load all entry points and their plugins into the manager
# When creating a new instance of a HTTPie instance, use this manager

# After loading all plugins, we can access all the loaded plugins from this manager

# Generated at 2022-06-23 19:56:03.767634
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) > 0
    return plugins

# Generated at 2022-06-23 19:56:05.887103
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    p1 = BasePlugin()
    p2 = BasePlugin()
    pm = PluginManager()
    pm.register(p1)
    pm.register(p2)
    assert len(pm) == 2
    assert p1 in pm and p2 in pm

# Generated at 2022-06-23 19:56:08.690294
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, OAuth1)
    assert plugin_manager.get_auth_plugins() == [HTTPBasicAuth, OAuth1]



# Generated at 2022-06-23 19:56:11.039182
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    PluginManager()
    assert pm.get_auth_plugin_mapping() == {
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin
    }

# Generated at 2022-06-23 19:56:12.940233
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    pm = PluginManager()
    pm.append(AuthPlugin)
    assert pm.get_auth_plugins() == [AuthPlugin]


# Generated at 2022-06-23 19:56:16.692566
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    class Plugin(TransportPlugin):
        name = 'plugin'
    pm = PluginManager()
    pm.register(Plugin)
    assert Plugin in pm
    pm.unregister(Plugin)
    assert Plugin not in pm



# Generated at 2022-06-23 19:56:22.319711
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    lst = PluginManager()
    lst.load_installed_plugins()
    converted_list = lst.get_converters()
    test_list = [
        'httpie.plugins.converter.json', 'httpie.plugins.converter.keyvalue',
        'httpie.plugins.converter.json'
    ]
    for i, j in zip(converted_list, test_list):
        assert i.converter_name == j
    assert isinstance(lst[0], BasePlugin) and isinstance(
        lst[0], ConverterPlugin
    ) and not isinstance(lst[0], TransportPlugin)


test_PluginManager_get_converters()


# Generated at 2022-06-23 19:56:25.006619
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin_manager = PluginManager()
    assert repr(plugin_manager) == '<PluginManager: []>'


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:56:26.578389
# Unit test for constructor of class PluginManager
def test_PluginManager():
    manager = PluginManager()
    assert list(manager) == []


# Generated at 2022-06-23 19:56:29.245286
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugins = PluginManager()
    plugins.register(FakePlugin, FakePlugin2)
    assert len(plugins.get_formatters()) == 2


# Generated at 2022-06-23 19:56:38.407815
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugin = PluginManager()
    assert plugin.__repr__() == '<PluginManager: []>'
    plugin.register(TestAuthPlugin)
    assert plugin.__repr__() == '<PluginManager: [<class \'tests.plugins.test_core.TestAuthPlugin\'>]>'
    plugin.register(TestAuthPlugin)
    assert plugin.__repr__() == '<PluginManager: [<class \'tests.plugins.test_core.TestAuthPlugin\'>, <class \'tests.plugins.test_core.TestAuthPlugin\'>]>'


plugin_manager = PluginManager()

# Generated at 2022-06-23 19:56:44.229241
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugins = PluginManager()
    plugins.register(TransportPlugin)
    plugins.register(TransportPlugin)
    a = plugins.get_transport_plugins()
    b = [TransportPlugin, TransportPlugin]
    msg = f"plugin 1: {a}, plugin 2: {b}, test result: {a == b}"
    assert a == b, msg


# Generated at 2022-06-23 19:56:47.828906
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugin_mapping()['digest'] == DigestAuthPlugin


# Generated at 2022-06-23 19:56:50.672018
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin)
    assert plugin_manager[0] == BasePlugin
    plugin_manager.unregister(BasePlugin)
    assert len(plugin_manager) == 0

# Generated at 2022-06-23 19:56:54.238670
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert AuthPlugin in pm
    pm.unregister(AuthPlugin)
    assert AuthPlugin not in pm



# Generated at 2022-06-23 19:56:57.786834
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager) == 1
    plugin_manager.register(TransportPlugin)
    assert len(plugin_manager) == 2


# Generated at 2022-06-23 19:56:59.953825
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    plugin_manager = PluginManager()
    formatters = plugin_manager.get_formatters()
    assert len(formatters) is not 0
    print(plugin_manager.get_formatters())

# Generated at 2022-06-23 19:57:03.625837
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    PluginManager.append(1)
    assert(list(PluginManager)==[1])


# Generated at 2022-06-23 19:57:13.316795
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

# Generated at 2022-06-23 19:57:20.759739
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    # Arrange
    import io
    from .test_auth import BearerAuthPlugin
    from .test_auth import DigestAuthPlugin
    from .test_auth import NoAuthPlugin

    plugins = PluginManager()

    plugins.register(NoAuthPlugin)
    plugins.register(DigestAuthPlugin)
    plugins.register(BearerAuthPlugin)

    # Act
    auth_plugins = plugins.get_auth_plugins()

    # Assert
    assert auth_plugins == [
        NoAuthPlugin, DigestAuthPlugin, BearerAuthPlugin
    ]

# Generated at 2022-06-23 19:57:22.552168
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugins()


# Generated at 2022-06-23 19:57:24.818878
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    pm = PluginManager()
    class A(BasePlugin):
        pass
    class B(BasePlugin):
        pass
    pm.register(A, B)
    assert A in pm
    assert B in pm


# Generated at 2022-06-23 19:57:26.730825
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert len(manager) == 1
    assert issubclass(manager[0], AuthPlugin)


# Generated at 2022-06-23 19:57:31.821662
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    def mock_filter_is_auth_plugin():
        return [
            mock.MagicMock(auth_type='first_auth_type'),
            mock.MagicMock(auth_type='second_auth_type'),
        ]
    plugin_manager = PluginManager()
    plugin_manager.filter = mock.MagicMock(side_effect=mock_filter_is_auth_plugin)
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(auth_plugin_mapping.items()) == 2
    assert 'first_auth_type' in auth_plugin_mapping
    assert 'second_auth_type' in auth_plugin_mapping

# Generated at 2022-06-23 19:57:41.307317
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = []
    
    mock1 = Mock()
    mock1.group_name = 'group1'
    plugins.append(mock1)
    mock2 = Mock()
    mock2.group_name = 'group2'
    plugins.append(mock2)
    mock3 = Mock()
    mock3.group_name = 'group1'
    plugins.append(mock3)
    mock4 = Mock()
    mock4.group_name = 'group2'
    plugins.append(mock4)
    mock5 = Mock()
    mock5.group_name = 'group1'
    plugins.append(mock5)
    
    manager = PluginManager()
    manager.register(*plugins)

# Generated at 2022-06-23 19:57:48.739132
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    m = PluginManager()
    assert m.get_auth_plugin_mapping() == {}
    from plugins.auth.basic_auth import BasicAuthPlugin
    m.register(BasicAuthPlugin)
    assert m.get_auth_plugin_mapping() == {'basic': BasicAuthPlugin}
    from plugins.auth.digest_auth import DigestAuthPlugin
    m.register(DigestAuthPlugin)
    assert m.get_auth_plugin_mapping() == {'basic': BasicAuthPlugin,
                                           'digest': DigestAuthPlugin}
    m.unregister(BasicAuthPlugin)
    assert m.get_auth_plugin_mapping() == {'digest': DigestAuthPlugin}

# Generated at 2022-06-23 19:57:50.052619
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    assert len(manager.get_formatters()) != 0

# Generated at 2022-06-23 19:57:52.527139
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    manager = PluginManager()
    assert manager.get_formatters() == []


# Generated at 2022-06-23 19:57:53.497476
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    PluginManager().register(BasePlugin)

# Generated at 2022-06-23 19:57:57.513371
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    config.plugins = PluginManager()
    config.plugins.load_installed_plugins()

    # config.plugins.get_auth_plugin('basic')
    # assert config.plugins.get_auth_plugin('none')



# Generated at 2022-06-23 19:57:59.987961
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    assert len(pm) == 0
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-23 19:58:01.298253
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert isinstance(PluginManager().filter(), list)


# Generated at 2022-06-23 19:58:04.359159
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins: PluginManager = PluginManager()
    plugins.load_installed_plugins()
    assert plugins
    for plugin in plugins:
        assert hasattr(plugin, 'package_name')
        print(plugin.package_name)

# Generated at 2022-06-23 19:58:08.323047
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    new_plugin = type('TestPlugin', (TransportPlugin,), {})
    p = PluginManager()
    p.register(new_plugin)
    assert new_plugin in p


# Generated at 2022-06-23 19:58:09.748008
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)

test_PluginManager_load_installed_plugins()

# Generated at 2022-06-23 19:58:12.731823
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(FormatterPlugin)
    assert len(pm.get_auth_plugins()) == 1
    assert len(pm.get_formatters()) == 1

# Generated at 2022-06-23 19:58:15.009361
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    plugin_manager = PluginManager()
    tmp = plugin_manager.get_transport_plugins()
    assert type(tmp) == list
    assert len(tmp) == 1
    assert all(isinstance(item, Type[TransportPlugin]) for item in tmp)

# Generated at 2022-06-23 19:58:22.037876
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    
    class B(A):
        pass

    class C:
        pass

    plg_manager = PluginManager()

    plg_manager.register(A, B, C)

    assert plg_manager.filter(by_type=A) == [A, B]


if __name__ == '__main__':
    test_PluginManager_filter()

# Generated at 2022-06-23 19:58:29.632325
# Unit test for method register of class PluginManager
def test_PluginManager_register():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(TransportPlugin)
    plugin_manager_1 = PluginManager()
    plugin_manager_1.register(AuthPlugin)
    plugin_manager_1.register(TransportPlugin)
    try:
        assert len(plugin_manager_1) == 2 and len(plugin_manager) == 2 and \
               plugin_manager[0] == plugin_manager_1[0] and plugin_manager[1] == plugin_manager_1[1]
    except AssertionError:
        print('test_PluginManager_register() failed')


# Generated at 2022-06-23 19:58:37.233005
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    """
    This unit test evaluates the method get_auth_plugin of class PluginManager.
    
    get_auth_plugin is a method that returns the plugin with a given auth_type.
    In this test, the auth type is 'basic'

    get_auth_plugin calls get_auth_plugin_mapping and this has to be implemented in order to get the plugin with a certain type
    """

    manager = PluginManager()
    manager.register(Plugin1)
    manager.register(Plugin2)
    manager.register(Plugin3)
    manager.register(Plugin4)
    manager.register(Plugin5)
    manager.register(Plugin6)
    manager.register(Plugin7)
    manager.register(Plugin8)
    manager.register(Plugin9)
    assert get_auth_plugin(manager, 'basic') == Plugin7
    print

# Generated at 2022-06-23 19:58:39.099408
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin('basic') == BaseAuthPlugin

# Generated at 2022-06-23 19:58:41.544462
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert type(pm[0]) == type

# Generated at 2022-06-23 19:58:45.841574
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(TransportPlugin)
    plugins.load_installed_plugins()
    plugin_list = list(plugins)
    assert(len(plugin_list) > 0)

# Generated at 2022-06-23 19:58:48.534358
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert(len(pm) > 0)


# Generated at 2022-06-23 19:58:55.633155
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, HTTPDigestAuthPlugin
    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuthPlugin, HTTPDigestAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {
        'basic': HTTPBasicAuthPlugin,
        'digest': HTTPDigestAuthPlugin,
    }
    plugin_manager.unregister(HTTPDigestAuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': HTTPBasicAuthPlugin}

# Generated at 2022-06-23 19:58:59.146366
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    pluginManager1 = PluginManager()
    pluginManager1.register(BasePlugin)
    pluginManager1.unregister(BasePlugin)
    assert len(pluginManager1) == 0



# Generated at 2022-06-23 19:59:00.092814
# Unit test for constructor of class PluginManager
def test_PluginManager():
    pluginManager = PluginManager()


# Generated at 2022-06-23 19:59:02.769830
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    test_plugin = PluginManager()
    test_plugin.register(AuthPlugin) # auth_plugin is base class so register it
    assert test_plugin.get_auth_plugins() == [AuthPlugin]



# Generated at 2022-06-23 19:59:07.498907
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(HttpieGDictPlugin)
    pm.register(HttpieTuplePlugin)
    assert pm.get_formatters_grouped() == {'group_name': [HttpieGDictPlugin, HttpieTuplePlugin]}


# Generated at 2022-06-23 19:59:09.133917
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    pm = PluginManager()
    pm.register()
    assert isinstance(pm.get_converters(), list)

# Generated at 2022-06-23 19:59:11.347365
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    PluginManager_ = PluginManager()
    if issubclass(PluginManager_.get_auth_plugin("DigestAuth"), AuthPlugin):
        return True
    else:
        return False


# Generated at 2022-06-23 19:59:17.836899
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(Type[TransportPlugin])
    manager.register(Type[ConverterPlugin])
    manager.register(Type[FormatterPlugin])
    assert manager.filter() == [Type[TransportPlugin], Type[ConverterPlugin], Type[FormatterPlugin]]

# Generated at 2022-06-23 19:59:21.104602
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    manager = PluginManager()
    manager.register_installed_plugins()
    assert len(manager) == 4

    manager.unregister(AuthPlugin)
    assert len(manager) == 0


# Generated at 2022-06-23 19:59:22.553267
# Unit test for method get_formatters of class PluginManager
def test_PluginManager_get_formatters():
    assert len(plugin_manager.get_formatters()) == 0


# Generated at 2022-06-23 19:59:29.429634
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass
    class PluginB(BasePlugin):
        pass
    class SubPluginB(PluginB):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB, SubPluginB)
    assert plugin_manager.filter(by_type=PluginA) == [PluginA]
    assert plugin_manager.filter(by_type=PluginB) == [PluginB, SubPluginB]
    assert plugin_manager.filter(by_type=SubPluginB) == [SubPluginB]



# Generated at 2022-06-23 19:59:32.522283
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
	PluginManager1=PluginManager()
	PluginManager1.load_installed_plugins()
	PluginManager1.get_auth_plugins()
	result=True
	assert result


# Generated at 2022-06-23 19:59:33.449093
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin = PluginManager()
    plugi

# Generated at 2022-06-23 19:59:37.843811
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    # Given
    mgr = PluginManager()
    mgr.register(ConverterPlugin)

    # When
    convs = mgr.get_converters()

    # Then
    assert convs == [ConverterPlugin]


# To run this unit test, run "coverage run --source=httpie --omit='*test*'"
# Then, run this unit test by "coverage run --append --source=httpie --omit='*test*' test_httpie.py"
# Run "coverage report" to reveal coverage
# Run "coverage html" to create html report under directory "htmlcov"
# Run "coverage xml" to create xml report file "coverage.xml"

# Generated at 2022-06-23 19:59:39.812596
# Unit test for constructor of class PluginManager
def test_PluginManager():

    m = PluginManager()

    assert type(m) is PluginManager
    assert m == []


# Generated at 2022-06-23 19:59:51.452496
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    from . import auth
    from . import formatter
    from . import converter
    from . import transport
    PluginManager.register(auth.BasicAuthPlugin)
    PluginManager.register(auth.DigestAuthPlugin)
    PluginManager.register(auth.BearerTokenAuthPlugin)
    PluginManager.register(formatter.JsonPointer)
    PluginManager.register(formatter.PrettyJsonPointer)
    PluginManager.register(formatter.JsonQuery)
    PluginManager.register(formatter.PrettyJsonQuery)
    PluginManager.register(formatter.Form)
    PluginManager.register(formatter.FormUrlencoded)
    PluginManager.register(formatter.Json)
    PluginManager.register(formatter.PrettyJson)
    PluginManager.register(formatter.Colors)
    PluginManager.register

# Generated at 2022-06-23 20:00:02.062580
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A(object):
        def __init__(self):
            self.name = 'A'

        def __repr__(self):
            return self.name

    class B(object):
        def __init__(self):
            self.name = 'B'

        def __repr__(self):
            return self.name

    class C(A, B):
        def __init__(self):
            self.name = 'C'

        def __repr__(self):
            return self.name

    class D(C):
        def __init__(self):
            self.name = 'D'

        def __repr__(self):
            return self.name

    class A1(A):
        def __init__(self):
            self.name = 'A1'


# Generated at 2022-06-23 20:00:07.884516
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie.formats.json
    import httpie.formats.json_lines
    import httpie.formats.ltsv
    import httpie.formats.ndjson
    import httpie.formats.html
    print(PluginManager.get_formatters_grouped([httpie.formats.json.JSONFormatter,httpie.formats.ltsv.LTSVFormatter,httpie.formats.json_lines.JSONLinesFormatter,httpie.formats.ndjson.NDJSONFormatter,httpie.formats.html.HTMLFormatter]))

# Generated at 2022-06-23 20:00:16.563553
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    # create 2 transport plugins
    class TransportPlugin1(TransportPlugin):
        name = 't1'
        priority = 100
        adapter_class = object
    class TransportPlugin2(TransportPlugin):
        name = 't2'
        priority = 200
        adapter_class = object
    # create a PluginManager
    plugin_manager = PluginManager([])
    # expect there is no transport plugin
    assert plugin_manager.get_transport_plugins() == []
    # register transport plugins
    plugin_manager.register(TransportPlugin1, TransportPlugin2)
    # expect there are 2 transport plugins
    assert len(plugin_manager.get_transport_plugins()) == 2
    # expect the TransportPlugin2 is in the front of the list
    assert isinstance(plugin_manager.get_transport_plugins()[0], TransportPlugin2)

# Generated at 2022-06-23 20:00:19.560615
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    x = PluginManager()
    x.register(AuthPlugin)
    assert x.get_auth_plugin_mapping() == {'auth-plugin': AuthPlugin}


# Generated at 2022-06-23 20:00:21.434080
# Unit test for method __repr__ of class PluginManager
def test_PluginManager___repr__():
    plugins = PluginManager()
    assert repr(plugins) == '<PluginManager: []>'


# Generated at 2022-06-23 20:00:23.131828
# Unit test for method get_auth_plugin of class PluginManager
def test_PluginManager_get_auth_plugin():
    import doctest
    doctest.testmod(verbose = True)

test_PluginManager_get_auth_plugin()

# Generated at 2022-06-23 20:00:25.483243
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(auth_plugin1)
    result = plugin_manager.get_auth_plugins()
    assert result[0] == auth_plugin1


# Generated at 2022-06-23 20:00:27.722551
# Unit test for method get_auth_plugins of class PluginManager
def test_PluginManager_get_auth_plugins():
    plugins = PluginManager()
    assert isinstance(plugins.get_auth_plugins(), list)


# Generated at 2022-06-23 20:00:29.669608
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    assert PluginManager.get_converters(PluginManager) == [httpie.plugins.json.JsonConverter,httpie.plugins.JsonConverter]

# Generated at 2022-06-23 20:00:30.166285
# Unit test for constructor of class PluginManager
def test_PluginManager():
    assert PluginManager == list

# Generated at 2022-06-23 20:00:32.662066
# Unit test for method unregister of class PluginManager
def test_PluginManager_unregister():
    plugin_manager = PluginManager()
    plugin_manager.register(VaultAuthPlugin)
    assert VaultAuthPlugin in plugin_manager
    plugin_manager.unregister(VaultAuthPlugin)
    assert VaultAuthPlugin not in plugin_manager


# Generated at 2022-06-23 20:00:38.538446
# Unit test for method get_converters of class PluginManager
def test_PluginManager_get_converters():
    from httpie.input import KeyValue, KeyValueArgType
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.custom_methods import Plugin
    class CustomConverter(ConverterPlugin):
        def __init__(self):
            self.name = 'mock'
            self.converter = KeyValueArgType
            self.help = ('mock help')

    assert(len(PluginManager().get_converters()) == 1)
    pluginManager = PluginManager()
    pluginManager.register(Plugin)
    assert(len(pluginManager.get_converters()) == 2)

    #Test the effect of unregister
    pluginManager.unregister(Plugin)
    assert(len(pluginManager.get_converters()) == 1)


# Generated at 2022-06-23 20:00:41.054670
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_transport_plugins()) == 2

# Generated at 2022-06-23 20:00:42.100305
# Unit test for method get_transport_plugins of class PluginManager
def test_PluginManager_get_transport_plugins():
    PluginManager().get_transport_plugins()

# Generated at 2022-06-23 20:00:47.905555
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(AuthPlugin):
        pass

    class PluginB(AuthPlugin):
        pass

    class PluginC(ConverterPlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginB, PluginC)

    assert plugin_manager.filter(AuthPlugin) == [PluginA, PluginB]
    assert plugin_manager.filter(ConverterPlugin) == [PluginC]
    assert plugin_manager.filter() == [PluginA, PluginB, PluginC]

# Generated at 2022-06-23 20:00:49.235582
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()

    assert plugin_manager.get_auth_plugin_mapping() == {}



# Generated at 2022-06-23 20:00:56.861991
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    def __init__(self, message):
        self.message = message

    class PluginManager(list):
        def filter(self, by_type):
            return [item for item in self if isinstance(item, by_type)]

    class Message(object):
        def __init__(self, message):
            self.message = message

        def __repr__(self):
            return '<Message>'

    class Conversation(object):
        def __init__(self, message):
            self.message = message

        def __repr__(self):
            return '<Conversation>'

    m = Message('Hello')
    c = Conversation('Greetings')
    manager = PluginManager()
    manager.register(Message)
    manager.register(Conversation)
    manager.register(Message)