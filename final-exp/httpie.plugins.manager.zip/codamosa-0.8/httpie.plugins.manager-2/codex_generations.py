

# Generated at 2022-06-12 00:19:47.417631
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    list = PluginManager()
    list.register(AuthPlugin, TransportPlugin, FormatterPlugin, ConverterPlugin)
    result1 = list.filter(AuthPlugin)
    result2 = list.filter(TransportPlugin)
    result3 = list.filter(FormatterPlugin)
    result4 = list.filter(ConverterPlugin)
    print(result1)
    print(result2)
    print(result3)
    print(result4)
    assert len(result1) == 1
    assert len(result2) == 1
    assert len(result3) == 1
    assert len(result4) == 1


# Generated at 2022-06-12 00:19:50.767511
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin.help import HelpFormatter

    pm = PluginManager()
    pm.append(HelpFormatter)
    assert pm.filter(HelpFormatter) == [HelpFormatter]

# Generated at 2022-06-12 00:19:54.508157
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    formatter_plugins = [
        formatter_plugin for formatter_plugin in PluginManager().filter(FormatterPlugin) if 
        formatter_plugin.group_name == 'image'
    ]
    print(formatter_plugins)
    return formatter_plugins

# Generated at 2022-06-12 00:20:05.273562
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert('bearer' in mapping)
    assert('aws' in mapping)
    assert('azure' in mapping)
    assert('credentials' in mapping)
    assert('digest' in mapping)
    assert('digest-ie' in mapping)
    assert('hmac' in mapping)
    assert('hawk' in mapping)
    assert('kerberos' in mapping)
    assert('netrc' in mapping)
    assert('ntlm' in mapping)
    assert('oauth1' in mapping)



# Generated at 2022-06-12 00:20:10.682319
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.unregister(PluginManager)
    plugin_manager.register(PluginManager)
    get_formatters_dict = plugin_manager.get_formatters_grouped()
    print(get_formatters_dict)

# Generated at 2022-06-12 00:20:23.032580
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class PluginFoo(FormatterPlugin):
        group_name = 'foo'
        group = group_name
        group_label = group_name

    class PluginBar(FormatterPlugin):
        group_name = 'bar'
        group = group_name
        group_label = group_name

    class PluginBaz(FormatterPlugin):
        group_name = 'baz'
        group = group_name
        group_label = group_name

    assert PluginManager().get_formatters_grouped() == {}

    manager = PluginManager()
    manager.register(PluginFoo, PluginBar, PluginBaz)
    assert manager.get_formatters_grouped() == {
        'foo': [PluginFoo],
        'bar': [PluginBar],
        'baz': [PluginBaz],
    }
    assert sorted

# Generated at 2022-06-12 00:20:31.908508
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.manager import PluginManager

    manager = PluginManager()
    manager.load_installed_plugins()
    

# Generated at 2022-06-12 00:20:35.360139
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm)

if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:20:38.154763
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager


# Generated at 2022-06-12 00:20:39.246280
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert type(object.get_formatters_grouped()) == dict


# Generated at 2022-06-12 00:20:46.343761
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            assert entry_point.load() in plugins

# Generated at 2022-06-12 00:20:55.048026
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.append(FormatterPlugin)
    pm.append(AuthPlugin)
    pm.append(ConverterPlugin)
    # TYPE check   
    assert type(pm.filter(FormatterPlugin)) == list
    # Using isinstance and issubclass for formatter plugin
    for plugin in pm.filter(FormatterPlugin):
        assert isinstance(plugin, FormatterPlugin)
        assert issubclass(plugin, FormatterPlugin)
    for plugin in pm.filter(AuthPlugin):
        assert isinstance(plugin, AuthPlugin)
        assert issubclass(plugin, AuthPlugin)
    for plugin in pm.filter(ConverterPlugin):
        assert isinstance(plugin, ConverterPlugin)
        assert issubclass(plugin, ConverterPlugin)
    # Test that only formatter plugin is being loaded
    assert len

# Generated at 2022-06-12 00:21:02.523938
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    my_auth = PluginManager()
    assert len(my_auth) == 0
    my_auth.register(AuthPlugin)
    assert len(my_auth) == 1
    print(my_auth.get_auth_plugin_mapping())
    assert isinstance(my_auth.get_auth_plugin_mapping(), dict)
    assert 'basic' in my_auth.get_auth_plugin_mapping()
    #assert isinstance(my_auth.get_auth_plugin_mapping()['basic'], AuthPlugin)
    my_auth.unregister(AuthPlugin)
    assert len(my_auth) == 0


# Generated at 2022-06-12 00:21:05.267693
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 6


# Generated at 2022-06-12 00:21:12.314042
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.auth import AuthPlugin
    from httpie.plugins import BasicAuthPlugin
    from httpie.plugins import DigestAuthPlugin
    from httpie.plugins import HawkAuthPlugin
    from httpie.plugins import OAuth1AuthPlugin

    PLUGIN_MANAGER = PluginManager()
    PLUGIN_MANAGER.register(AuthPlugin, BasicAuthPlugin, DigestAuthPlugin,
                            HawkAuthPlugin, OAuth1AuthPlugin)
    print(PLUGIN_MANAGER.get_auth_plugin_mapping())

# Generated at 2022-06-12 00:21:19.978236
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class HttpiePlugin(BasePlugin):
        pass

    class AuthPlugin(HttpiePlugin):
        pass

    class HttpBinPlugin(AuthPlugin):
        pass

    class FormatterPlugin(HttpiePlugin):
        pass

    class ConverterPlugin(FormatterPlugin):
        pass

    manager = PluginManager()
    manager.register(AuthPlugin, HttpBinPlugin, FormatterPlugin, ConverterPlugin)
    assert manager.filter(HttpiePlugin) == [AuthPlugin, HttpBinPlugin, FormatterPlugin, ConverterPlugin]
    assert manager.filter(AuthPlugin) == [AuthPlugin, HttpBinPlugin]
    assert manager.filter(HttpBinPlugin) == [HttpBinPlugin]
    assert manager.filter(FormatterPlugin) == [FormatterPlugin, ConverterPlugin]

# Generated at 2022-06-12 00:21:24.203713
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}

    manager = PluginManager()
    manager.register(BasePlugin)
    assert manager.get_auth_plugin_mapping() == {}

    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {}


# Generated at 2022-06-12 00:21:27.865776
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin, ConverterPlugin, AuthPlugin, ConverterPlugin, FormatterPlugin)
    assert len(plugins.filter(ConverterPlugin)) == 2


# Generated at 2022-06-12 00:21:29.130585
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(FormatterPlugin)

    assert manager.get_formatters_grouped()
    assert manager.get_formatters_grouped() == {'httpie': list(manager)}

# Generated at 2022-06-12 00:21:34.038803
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    p1 = AuthPlugin()
    p2 = AuthPlugin()
    pm = PluginManager()
    pm.register(p1)
    pm.register(p2)
    response = pm.get_auth_plugin_mapping()
    key1 = p1.auth_type
    key2 = p2.auth_type
    assert key1 in response
    assert key2 in response

# Generated at 2022-06-12 00:21:40.462991
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) > 0
    assert plugins[0].__name__ == 'DigestAuthPlugin'
    assert plugins[2].__name__ == 'BasicAuthPlugin'
    
    
    
    

# Generated at 2022-06-12 00:21:43.908797
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert isinstance(manager.get_formatters_grouped(), dict)


manager = PluginManager()
manager.load_installed_plugins()

# Generated at 2022-06-12 00:21:50.845339
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    from httpie.plugins.builtin import HTTPiePlugin
    pm.register(HTTPiePlugin)

    from httpie.plugins.builtin import JSONPlugin, XMLPlugin
    pm.register(JSONPlugin)
    pm.register(XMLPlugin)

    assert pm.get_formatters_grouped() == {
        'format': [XMLPlugin, JSONPlugin],
        'group': [HTTPiePlugin],
    }

# Generated at 2022-06-12 00:21:56.768204
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    #Given
    manager = PluginManager()
    package_name_1 = 'httpie'
    package_name_2 = 'httpie-unixsocket'
    package_name_3 = 'httpie-oauth1'

    #When
    manager.load_installed_plugins()

    #Then
    assert all(plugin.package_name in [package_name_1, package_name_2, package_name_3] for plugin in manager)
    assert len(manager) >= 8

# Generated at 2022-06-12 00:22:05.082576
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class PluginA(FormatterPlugin):
        group_name = 'A'
    class PluginAB(FormatterPlugin):
        group_name = 'A'
    class PluginB(FormatterPlugin):
        group_name = 'B'
    class PluginC(FormatterPlugin):
        group_name = 'C'
    PluginManager().register(PluginA, PluginAB, PluginB, PluginC)
    plugins_grouped = PluginManager().get_formatters_grouped()
    assert plugins_grouped == {'A': [PluginA, PluginAB], 'B': [PluginB], 'C': [PluginC]}

# Generated at 2022-06-12 00:22:14.001658
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import re
    import textwrap

    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin

    class Plugin_test_foo(BasePlugin):

        class Test_foo_1(BasePlugin):
            pass

        class Test_foo_2(BasePlugin):
            pass

    class Plugin_test_bar(BasePlugin):

        class Test_bar_1(BasePlugin):
            pass

        class Test_bar_2(BasePlugin):
            pass

    class Plugin_test_baz(BasePlugin):

        class Test_baz_1(BasePlugin):
            pass

        class Test_baz_2(BasePlugin):
            pass


# Generated at 2022-06-12 00:22:20.414799
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.append(BasePlugin)
    plugins.append(TransportPlugin)
    plugins.append(FormatterPlugin)
    plugins.append(ConverterPlugin)
    plugins.append(AuthPlugin)
    plugins.append(FormatterPlugin)
    plugins.append(AuthPlugin)
    plugins.append(ConverterPlugin)
    assert plugins.filter() == [
        BasePlugin,
        TransportPlugin,
        FormatterPlugin,
        FormatterPlugin,
        ConverterPlugin,
        ConverterPlugin,
        AuthPlugin,
        AuthPlugin,
    ]



# Generated at 2022-06-12 00:22:30.553666
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.output.streams import RawStream
    from httpie.plugins import (
        AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin
    )
    from httpie.plugins.base import BasePlugin

    class DummyPlugin(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin):
        pass

    class DummyPluginType(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(DummyPlugin)

    assert len(list(plugin_manager.filter())) == 1
    assert len(list(plugin_manager.filter(BasePlugin))) == 1
    assert len(list(plugin_manager.filter(AuthPlugin))) == 1
    assert len(list(plugin_manager.filter(FormatterPlugin))) == 1
    assert len(list(plugin_manager.filter(ConverterPlugin)))

# Generated at 2022-06-12 00:22:35.935869
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(None)
    plugins.register(1)
    plugins.register('abc')
    result = plugins.filter(by_type=int)
    assert result == [1]


# Generated at 2022-06-12 00:22:41.270471
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    assert len(pluginManager.filter(AuthPlugin)) == 1
    assert len(pluginManager.filter(ConverterPlugin)) == 1
    assert len(pluginManager.filter(FormatterPlugin)) == 1
    assert len(pluginManager.filter(TransportPlugin)) == 1

# Generated at 2022-06-12 00:22:53.754979
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class PlainType(FormatterPlugin):
        group_name = 'group-1'

    class OtherType(FormatterPlugin):
        group_name = 'group-1'

    class Group2Type(ConverterPlugin):
        group_name = 'group-2'

    class NoGroupType(ConverterPlugin):
        pass

    pm = PluginManager()
    pm.register(PlainType, OtherType, Group2Type, NoGroupType)

    expected = {
        'group-1': [PlainType, OtherType],
        'group-2': [Group2Type],
    }
    actual = pm.get_formatters_grouped()
    assert expected == actual



# Generated at 2022-06-12 00:23:03.025386
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class ClassA:
        pass
    class ClassB(ClassA):
        pass
    class ClassC(ClassA):
        pass
    class ClassD:
        pass
    class ClassE(ClassD):
        pass
    class ClassF(ClassD):
        pass
    class ClassG:
        pass
    class ClassH(ClassG):
        pass
    class ClassI(ClassG):
        pass
    pm = PluginManager()
    pm.register(ClassA, ClassB, ClassC, ClassD, ClassE, ClassF, ClassG, ClassH, ClassI)
    result1 = pm.filter(ClassA)
    result2 = pm.filter(ClassG)
    result3 = pm.filter(ClassD)

    assert result1 == [ClassA, ClassB, ClassC]

# Generated at 2022-06-12 00:23:09.065844
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    # auth
    assert pm.get_auth_plugin('digest')
    assert pm.get_auth_plugin('bearer')
    # formatter
    assert pm.get_formatters_grouped()['csv']
    assert pm.get_formatters_grouped()['colors']
    assert pm.get_formatters_grouped()['format']
    # converter
    assert pm.get_converters()
    # transport
    assert pm.get_transport_plugins()

# Generated at 2022-06-12 00:23:12.195658
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin_mapping() == {'basic': httpie.plugins.auth.basic.BasicAuthPlugin}

# Generated at 2022-06-12 00:23:18.056533
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatter, JSONLinesFormatter, URLSearchParamsFormatter, URLEncodedFormatter)
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped == {'raw': [URLEncodedFormatter, URLSearchParamsFormatter], 'json': [JSONFormatter, JSONLinesFormatter]}

# Generated at 2022-06-12 00:23:27.754130
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """
    test_PluginManager_get_formatters_grouped
    """
    # Case: Name is 'json'
    plugin_manager = PluginManager()
    plugin_manager.register(MockFormatterPlugin)
    result = plugin_manager.get_formatters_grouped()
    assert result == {'none': [MockNoneFormatterPlugin]}, \
        'Grouped formatters is wrong'

    result = plugin_manager.get_formatters_grouped()
    assert set(result.keys()) == set(['text', 'binary', 'none']), \
        'Grouped formatters is wrong'


# Generated at 2022-06-12 00:23:31.989740
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager.get_auth_plugins()) > 0
    assert len(manager.get_formatters()) > 0
    assert len(manager.get_converters()) > 0


# Generated at 2022-06-12 00:23:39.933956
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Initialize an empty PluginManager
    pm = PluginManager()
    # Call method load_installed_plugins
    pm.load_installed_plugins()
    # Returned value
    retval = pm.get_auth_plugin_mapping()
    # Valids
    valids = {'basic_auth': 'httpie.plugins.auth.basic_auth:BasicAuthPlugin', 'digest_auth': 'httpie.plugins.auth.digest_auth:DigestAuthPlugin'}
    # Will test returnd value with all the valids
    assert(retval == valids)


# Generated at 2022-06-12 00:23:48.156848
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.default import DefaultPlugin, JSONPlugin, PrettyPlugin
    from httpie import ExitStatus
    exit_codes = ExitStatus

    plugins = PluginManager()
    plugins.register(DefaultPlugin, JSONPlugin, PrettyPlugin, HTTPiePlugin)

    assert plugins.get_formatters_grouped() == {
        'formatters': [JSONPlugin, PrettyPlugin, HTTPiePlugin],
        'overrides': [DefaultPlugin],
    }

# Generated at 2022-06-12 00:23:52.758513
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugins()) == 4
    assert len(pm.get_formatters()) == 4
    assert len(pm.get_formatters_grouped()) == 3
    assert len(pm.get_converters()) == 3
    assert len(pm.get_transport_plugins()) == 1

# Generated at 2022-06-12 00:24:04.558077
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Initialize variable before load_installed_plugins is called.
    loaded_plugins: List[BasePlugin] = []

    # GIVEN a PluginManager
    plugin_manager = PluginManager()

    # WHEN load_installed_plugins is called
    plugin_manager.load_installed_plugins()

    # THEN load_installed_plugins should have been called.
    assert len(plugin_manager) > 0



# Generated at 2022-06-12 00:24:07.546916
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = [AuthPlugin, AuthPlugin]
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)
    output = plugin_manager.get_auth_plugin_mapping()
    assert output == {'auth-plugin': AuthPlugin}



# Generated at 2022-06-12 00:24:11.016790
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(Plugin1)
    plugins.register(Plugin2)
    assert plugins.filter(Plugin1) == [Plugin1]



# Generated at 2022-06-12 00:24:14.557488
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    a = PluginManager()
    a.register(AuthPlugin)
    a.register(ConverterPlugin)
    a.register(FormatterPlugin)
    a.register(TransportPlugin)
    b = a.filter(ConverterPlugin)
    assert len(b) == 1
    assert b[0] == ConverterPlugin


# Generated at 2022-06-12 00:24:25.795857
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # create a new package `new_package` in the same repository
    # with entry point in `setup.py`
    #     entry_points={
    #         'httpie.plugins.auth.v1': [
    #             'new_plugin = new_package.plugin',
    #         ],
    #     },
    # where the `plugin` class is defined in the module `new_package.py` in the same directory
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm
    assert issubclass(pm[-1], BasePlugin)
    assert pm[-1].auth_type == 'new_auth_type'

    # remove the package `new_package`
    # and reset the PluginManager
    pm = PluginManager()

    # reload the plugins and ensure `new_plugin` is not loaded


# Generated at 2022-06-12 00:24:37.303951
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    class BasePlugin:
        pass

    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(BasePlugin):
        pass

    plugin_1, plugin_2, plugin_3 = Plugin1(), Plugin2(), Plugin3()
    plugin_1_package, plugin_2_package = 'pkg-1', 'pkg-2'
    entry_point_1 = Mock()
    entry_point_1.load = Mock(return_value=plugin_1)
    entry_point_1.dist = Mock()
    entry_point_1.dist.key = plugin_1_package
    entry_point_2 = Mock()
    entry_point_2.load = Mock(return_value=plugin_2)
    entry_point_2.dist = Mock()
    entry_point_2

# Generated at 2022-06-12 00:24:39.681468
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm)


# Generated at 2022-06-12 00:24:41.770453
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.get_formatters_grouped()

# Generated at 2022-06-12 00:24:48.190716
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugins()) == 2
    assert pm.get_auth_plugin_mapping()
    assert pm.get_auth_plugin('basic')
    assert pm.get_formatters()
    assert pm.get_formatters_grouped()
    assert pm.get_converters()
    assert pm.get_transport_plugins()


# Generated at 2022-06-12 00:24:51.511845
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    p = PluginManager()
    p.register(MockFormatterPlugin1, MockFormatterPlugin3, MockFormatterPlugin4, MockFormatterPlugin2)
    assert p.get_formatters_grouped() == {
        'group1': [MockFormatterPlugin1, MockFormatterPlugin4],
        'group2': [MockFormatterPlugin2]
    }

# Generated at 2022-06-12 00:25:08.093607
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    assert len(pluginmanager) > 20
    assert pluginmanager[0].__class__.__name__ != ''

# Generated at 2022-06-12 00:25:12.956089
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()
    formatters = manager.get_formatters_grouped()
    for key, value in formatters.items():
        for item in value:
            assert item.group_name == key
    print('test_PluginManager_get_formatters_grouped(): ', 'OK')


# Generated at 2022-06-12 00:25:13.651143
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()

    assert len(manager) > 0

# Generated at 2022-06-12 00:25:15.713288
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0



# Generated at 2022-06-12 00:25:17.592535
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin, FormatterPlugin)
    plugin_manager.get_formatters_grouped()

# Generated at 2022-06-12 00:25:22.151574
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class MyPlugin(BasePlugin):
        pass

    class MySubPlugin(MyPlugin):
        pass

    class MyOtherPlugin(BasePlugin):
        pass

    manager = PluginManager()
    manager.register(MyPlugin, MySubPlugin, MyOtherPlugin)

    assert manager.filter(MyPlugin) == [MyPlugin, MySubPlugin]
    assert manager.filter(MyOtherPlugin) == [MyOtherPlugin]
    assert manager.filter(BasePlugin) == [MyPlugin, MySubPlugin, MyOtherPlugin]

# Generated at 2022-06-12 00:25:27.234971
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    plugin_manager.register(AuthPlugin)
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert set(auth_plugin_mapping.keys()) == {'keyring'}

if __name__ == '__main__':
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-12 00:25:29.352162
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager.filter([]) == []
    assert PluginManager.filter([BasePlugin, TransportPlugin]) == []


# Generated at 2022-06-12 00:25:38.391725
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    assert plugins.get_formatters_grouped() == {}

    class OutputFormatterPlugin(FormatterPlugin):
        name = None
        group_name = 'group1'

    class OutputFormatterPlugin2(FormatterPlugin):
        name = None
        group_name = 'group1'

    class OutputFormatterPlugin3(FormatterPlugin):
        name = None
        group_name = 'group2'

    plugins.register(OutputFormatterPlugin, OutputFormatterPlugin2, OutputFormatterPlugin3)
    assert plugins.get_formatters_grouped() == {'group1': [OutputFormatterPlugin, OutputFormatterPlugin2], 'group2': [OutputFormatterPlugin3]}

# Generated at 2022-06-12 00:25:46.863926
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(CliColorsFormatter, CliHtmlFormatter,
                            CliJsonFormatter)
    print(plugin_manager.get_formatters_grouped())
    assert plugin_manager.get_formatters_grouped() == {
        'colors': [CliColorsFormatter],
        'html': [CliHtmlFormatter],
        'json': [CliJsonFormatter]
    }


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-12 00:26:39.164552
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin = PluginManager()
    plugin.load_installed_plugins()

# Generated at 2022-06-12 00:26:43.076832
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    m = PluginManager()
    m.register(auths.BasicAuth, auths.DigestAuth)
    assert m.get_auth_plugin_mapping() == {
        'basic': auths.BasicAuth,
        'digest': auths.DigestAuth
    }

# Generated at 2022-06-12 00:26:47.583276
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONPrettyprintPlugin, JSONPlugin
    manager = PluginManager()
    manager.register(JSONPrettyprintPlugin, JSONPlugin)
    test_formatters = manager.get_formatters_grouped()
    assert test_formatters['JSON'][0] == JSONPrettyprintPlugin


# Generated at 2022-06-12 00:26:57.015704
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie import __version__
    p = PluginManager()
    p.load_installed_plugins()
    assert isinstance(p, list)
    assert len(p) == 52
    assert (
        p[-1].__name__ ==
        f'httpie_cloudflare_front_cookie.CloudflareFrontCookieAuthPlugin'
    )
    assert p[-1].auth_type == 'cf-cookie'
    assert isinstance(p[-1].__doc__, str)
    assert p[-1].__doc__.strip().startswith('Authentication plugin')
    assert p[-1].package_name == 'httpie-cloudflare-front-cookie'
    assert (
        p[-1].__module__ == f'httpie_cloudflare_front_cookie.plugin'
    )

# Generated at 2022-06-12 00:27:08.584225
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import builtin
    test = PluginManager()
    test.register(builtin.HTTPDebuggerFormatter)
    test.register(builtin.HTMLFormatter)
    test.register(builtin.JSONFormatter)
    test.register(builtin.PrettyJSONFormatter)
    test.register(builtin.PrettyStreamFormatter)
    test.register(builtin.RawJSONFormatter)
    test.register(builtin.TableFormatter)
    test.register(builtin.URLEncodedFormatter)
    test.register(builtin.RawFormatter)
    test.register(builtin.Colors)
    #test.register(builtin.AutoJSON)
    #test.register(builtin.AutoHeaders)

    print(test.get_formatters_grouped())

# Generated at 2022-06-12 00:27:14.812947
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Load plugins
    manager = PluginManager()
    manager.load_installed_plugins()

    # Check number of installed plugins
    assert len(manager) >= 50

    # Check exist some plugin with name 'json'
    names = [plugin().name for plugin in manager]
    assert 'json' in names

    # Check that all plugins are BasePlugins
    types = [type(plugin) for plugin in manager]
    assert all(issubclass(typ, BasePlugin) for typ in types)

    # Check that all plugins are plugins
    assert all(plugin().is_plugin for plugin in manager)



# Generated at 2022-06-12 00:27:17.824916
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0
    assert manager[0].package_name is not None


# Generated at 2022-06-12 00:27:23.011757
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)
    print(plugin_manager.get_formatters_grouped())
    # for plugin in plugin_manager:
    #     print(plugin.load)
    

if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:27:31.385552
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Unit test for method get_formatters_grouped of class PluginManager
    # Arrange
    manager = PluginManager()
    manager.register(JsonStdoutPlugin)
    manager.register(JsonPlugin)
    manager.register(JsonHtmlPlugin)
    # Act
    result = manager.get_formatters_grouped()
    # Assert

# Generated at 2022-06-12 00:27:33.782166
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    assert len(pm) == 0
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-12 00:28:33.344012
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {'group1': [], 'group2': [], 'group3': []}

# Generated at 2022-06-12 00:28:35.545978
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class TestFormatter(FormatterPlugin):
        group_name = 'Test'

    manager = PluginManager()
    manager.register(TestFormatter)
    assert manager.get_formatters_grouped() == {'Test': [TestFormatter]}

# Generated at 2022-06-12 00:28:39.459435
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}
    assert PluginManager([FormatterPlugin]).get_formatters_grouped() \
           == {'default': [FormatterPlugin]}
    assert PluginManager([FormatterPlugin, FormatterPlugin]).get_formatters_grouped() \
           == {'default': [FormatterPlugin, FormatterPlugin]}

# Generated at 2022-06-12 00:28:41.910780
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # 创建PluginManager对象
    plugin_manager = PluginManager()
    # 加载已安装的插件
    plugin_manager.load_installed_plugins()
    # 测试
    assert len(plugin_manager) == 0

# Generated at 2022-06-12 00:28:46.000756
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    print(pluginmanager.get_formatters())
    print(pluginmanager.get_formatters_grouped())
    print(pluginmanager.get_auth_plugins())
    print(pluginmanager.get_converters())
    print(pluginmanager)

# Generated at 2022-06-12 00:28:55.497415
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm=PluginManager()
    pm.register(plugin.ArgonautFormatter,plugin.CsvFormatter,plugin.JsonLinesFormatter,plugin.JsonFormatter)
    print(pm.get_formatters_grouped())
    #{'Browser / human readability': [<class 'httpie.plugins.http.formatter.JsonFormatter'>, <class 'httpie.plugins.http.formatter.JsonLinesFormatter'>, <class 'httpie.plugins.http.formatter.CsvFormatter'>, <class 'httpie.plugins.http.formatter.ArgonautFormatter'>], 'Data structure (JSON / YAML)': [<class 'httpie.plugins.http.formatter.JsonFormatter'>, <class 'httpie.plugins.http.formatter.JsonLinesFormatter'

# Generated at 2022-06-12 00:29:00.274796
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    lst_a = [1,2,3,4,5]
    lst_b = [6,7,8,9,10]
    dic = {}
    for i in range(len(lst_a)):
        dic[lst_a[i]] = lst_b[i]
    assert dic is {1:6, 2:7, 3:8, 4:9, 5:10}

# Generated at 2022-06-12 00:29:09.353570
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    _pluginManager = PluginManager()
    _pluginManager.register(type('FormatTest1',(FormatterPlugin,),{'group_name':'type1'}))
    _pluginManager.register(type('FormatTest2',(FormatterPlugin,),{'group_name':'type1'}))
    _pluginManager.register(type('FormatTest3',(FormatterPlugin,),{'group_name':'type2'}))
    _pluginManager.register(type('FormatTest4',(FormatterPlugin,),{'group_name':'type3'}))
    _pluginManager.register(type('FormatTest5',(FormatterPlugin,),{'group_name':'type4'}))

# Generated at 2022-06-12 00:29:14.782307
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
  plugins = PluginManager()
  auth_type = 'awsv4'
  class auth_plugin:
    auth_type = auth_type
  plugins.register(auth_plugin)
  expected = { auth_type: auth_plugin }
  actual = plugins.get_auth_plugin_mapping()
  assert actual == expected
  print("Test passed!")


if __name__ == '__main__':
  test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-12 00:29:22.322139
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Initialize formatter plugins
    colorama.init()
    BaseFormatter.sorted_plugins = sorted(
        BaseFormatter.plugins, key=lambda p: p.name
    )
    BaseFormatter.sorted_plugins_groups = {
        key: list(group)
        for key, group
        in groupby(BaseFormatter.sorted_plugins, key=lambda p: p.group_name)
    }
    # Make a PluginManager instance
    plugins = PluginManager()
    # Load installed plugins
    plugins.load_installed_plugins()
    # Get formatters grouped
    plugins.get_formatters_grouped()