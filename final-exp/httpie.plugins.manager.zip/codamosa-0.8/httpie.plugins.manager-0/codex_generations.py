

# Generated at 2022-06-12 00:19:48.155193
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(HawkAuthPlugin, BCryptAuthPlugin, BasicAuthPlugin, DigestAuthPlugin, FingerprintAuthPlugin,
                     FormAuthPlugin, NetrcAuthPlugin, OAuth1AuthPlugin, OAuth2AuthPlugin,
                     WsseAuthPlugin, OAuth1AuthPlugin, OAuth2AuthPlugin)
    assert manager.get_auth_plugin_mapping().keys() == {'hawk', 'bcrypt', 'basic', 'digest', 'fingerprint', 'form',
                                                        'netrc', 'oauth1', 'oauth2', 'wsse'}

test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-12 00:19:55.125028
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(HTTPieTestPlugin1)
    pm.register(HTTPieTestPlugin2)
    assert repr(pm) == "<PluginManager: [<class 'httpie.plugins.HTTPieTestPlugin1'>, <class 'httpie.plugins.HTTPieTestPlugin2'>]>"
    t = pm.get_formatters_grouped()
    assert t == {'test_formatters_grouped_group1': [HTTPieTestPlugin1], 'test_formatters_grouped_group2': [HTTPieTestPlugin2]}



# Generated at 2022-06-12 00:20:00.005604
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins_list = plugins.get_formatters_grouped()
    assert 'json' in plugins_list
    assert 'html' in plugins_list

# Generated at 2022-06-12 00:20:10.439674
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    auth_plugin_list = pluginManager.get_auth_plugins()
    transport_plugin_list = pluginManager.get_transport_plugins()
    formatter_plugin_list = pluginManager.get_formatters()
    converter_plugin_list = pluginManager.get_converters()
    for i in auth_plugin_list:
        assert issubclass(i, AuthPlugin)
    for i in transport_plugin_list:
        assert issubclass(i, TransportPlugin)
    for i in formatter_plugin_list:
        assert issubclass(i, FormatterPlugin)
    for i in converter_plugin_list:
        assert issubclass(i, ConverterPlugin)

__all__ = ('PluginManager',)

# Generated at 2022-06-12 00:20:22.860411
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    fmts = plugin_manager.get_formatters_grouped()
    converters = list(filter((lambda x: x.group_name == 'Converters'), fmts['Converters']))
    assert(len(converters) == 3)
    assert(converters[0].name == "json")
    assert(converters[1].name == "json-pp")
    assert(converters[2].name == "ndjson")
    assert(len(fmts['Output']) == 8)
    assert(fmts['Output'][0].group_name == 'Output')
    assert(fmts['Output'][0].name == 'colorized')

# Generated at 2022-06-12 00:20:24.169358
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins != []

# Generated at 2022-06-12 00:20:30.924389
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group1'

    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group2'

    class FormatterPlugin3(FormatterPlugin):
        group_name = 'group1'

    manager = PluginManager()
    manager.register(FormatterPlugin1, FormatterPlugin2, FormatterPlugin3)
    assert manager.get_formatters_grouped() == {
        'group1': [FormatterPlugin1, FormatterPlugin3],
        'group2': [FormatterPlugin2],
    }

# Generated at 2022-06-12 00:20:35.503329
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()
    authtypes = {}
    for k, v in pm.get_auth_plugin_mapping().items():
        authtypes[k] = v
    assert 'basic' in authtypes


# Generated at 2022-06-12 00:20:36.154186
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager().filter()

# Generated at 2022-06-12 00:20:40.636912
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_mgr = PluginManager()
    plugins_mgr.load_installed_plugins()
    plugins_mgr.append(FormatterPlugin)
    res = plugins_mgr.get_formatters_grouped()
    assert res == {'yaml': [FormatterPlugin]}

# Generated at 2022-06-12 00:20:50.801232
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJsonFormatterPlugin, \
        URLEncodedFormatterPlugin
    pm = PluginManager(
        [JSONFormatterPlugin, JSONFormatterPlugin, URLEncodedFormatterPlugin,
         PrettyJsonFormatterPlugin]
    )
    assert pm.get_formatters_grouped()['group2'] == [URLEncodedFormatterPlugin, PrettyJsonFormatterPlugin]
    assert pm.get_formatters_grouped()['group1'] == [JSONFormatterPlugin, JSONFormatterPlugin]

# Generated at 2022-06-12 00:20:54.372958
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugin_mapping()) != 0
    assert len(pm.get_formatters()) != 0
    assert len(pm.get_converters()) != 0
    assert len(pm.get_transport_plugins()) != 0

# Generated at 2022-06-12 00:21:00.331410
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    class plugin(BasePlugin):
        pass
    plugin_manager.register(plugin)
    assert plugin in plugin_manager.filter(by_type=BasePlugin)
    assert plugin in plugin_manager.filter(by_type=plugin)
    assert [plugin] == plugin_manager.filter(by_type=plugin)
    assert len([plugin]) == len(plugin_manager.filter(by_type=plugin))



# Generated at 2022-06-12 00:21:00.921277
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pass

# Generated at 2022-06-12 00:21:09.361532
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter import FormatterPlugin

    pm = PluginManager()

    class V1(FormatterPlugin):
        group_name = 'group'

    class V2(FormatterPlugin):
        group_name = 'group'

    class V3(FormatterPlugin):
        group_name = 'group'

    class V4(FormatterPlugin):
        group_name = 'group2'

    pm.register(V1)
    pm.register(V2)
    pm.register(V3)
    pm.register(V4)
    assert pm.get_formatters_grouped() == {'group': [V1, V2, V3],
                                           'group2': [V4]}


# Generated at 2022-06-12 00:21:18.394105
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugins = plugin_manager.filter()
    assert [] == plugins

    plugins = plugin_manager.filter(by_type=Type[BasePlugin])
    assert [] == plugins

    from httpie.plugins.base import BasePlugin
    class AuthPlugin(BasePlugin):
        auth_type = 'authPlugin'

    class FormatterPlugin(BasePlugin):
        group_name = 'formatterPlugin'

    class ConverterPlugin(BasePlugin):
        pass

    class TransportPlugin(BasePlugin):
        pass

    plugin_manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)

    plugins = plugin_manager.filter()
    assert [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin] == plugins

    plugins = plugin_manager.filter(by_type=Type[BasePlugin])
   

# Generated at 2022-06-12 00:21:22.493598
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            assert plugin.package_name == entry_point.dist.key

# Generated at 2022-06-12 00:21:29.096207
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    name_list = [plugin.name for plugin in manager]
    name_list_expected = ['json', 'pretty', 'table', 'colors', 'date', 'format', 'stream', 'httpbin', 'kakfa']
    assert name_list == name_list_expected


# Generated at 2022-06-12 00:21:30.063012
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager.get_formatters_grouped()

# Generated at 2022-06-12 00:21:36.141493
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    x = PluginManager()
    x.register(A, B, C)

    assert x.filter(A) == [A, B, C]
    assert x.filter(B) == [B, C]
    assert x.filter(C) == [C]


plugin_manager = PluginManager()

# Generated at 2022-06-12 00:21:43.666424
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class FooBar(BasePlugin):
        pass

    class Foobar(BasePlugin):
        pass

    class Bar(BasePlugin):
        pass

    class Foo(BasePlugin):
        pass


    class FooBar(BasePlugin):
        pass

    class Foo(BasePlugin):
        pass

    class Foobar(BasePlugin):
        pass

    class Bar(BasePlugin):
        pass

    pm = PluginManager()
    pm.register(FooBar, Foobar, Bar, Foo, FooBar, Foo, Foobar, Bar)
    assert len(pm.filter(Foo)) == 2
    assert len(pm.filter(FooBar)) == 2
    assert len(pm.filter(Bar)) == 2
    assert len(pm.filter(Foobar)) == 2
    assert len(pm.filter(BasePlugin)) == 8




# Generated at 2022-06-12 00:21:55.346148
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class A(FormatterPlugin):
        group_name = 'a'
    class B(FormatterPlugin):
        group_name = 'b'
    class C(FormatterPlugin):
        group_name = 'c'
    class D(FormatterPlugin):
        group_name = 'a'
    class E(FormatterPlugin):
        group_name = 'a'
    class F(FormatterPlugin):
        group_name = 'b'
    class G(FormatterPlugin):
        group_name = 'a'

    manager = PluginManager()
    manager.register(C, D, A, B, F, E, G)
    result = manager.get_formatters_grouped()

# Generated at 2022-06-12 00:22:06.793672
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    #define PluginManager
    plugM = PluginManager()
    #define group_name='a', group_name='b'
    group_name_a = 'a'
    group_name_b = 'b'
    class FormatterPlugin_a(FormatterPlugin):
        #define group_name attribute
        group_name = group_name_a
    class FormatterPlugin_b(FormatterPlugin):
        #define group_name attribute
        group_name = group_name_b
    #add FormatterPlugin_a, FormatterPlugin_b to PluginManager
    plugM.register(FormatterPlugin_a)
    plugM.register(FormatterPlugin_b)
    #test result of get_formatters_grouped()

# Generated at 2022-06-12 00:22:10.423545
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PKG_NAME = 'httpie-jwt-auth'
    EP_NAME = 'httpie.plugins.auth.v1'

    saved_installed_plugins = PluginManager().load_installed_plugins()

    uninstall_pkg(PKG_NAME)
    assert PKG_NAME in [p.package_name for p in saved_installed_plugins]

    remove_entry_points(PKG_NAME, EP_NAME)
    installed_plugins = PluginManager().load_installed_plugins()
    assert PKG_NAME not in [p.package_name for p in installed_plugins]

    install_pkg(PKG_NAME)
    install_entry_points(PKG_NAME, EP_NAME)
    installed_plugins = PluginManager().load_installed_plugins()

# Generated at 2022-06-12 00:22:13.772845
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()
    pm.get_auth_plugin_mapping()

# Generated at 2022-06-12 00:22:16.415976
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(PluginManager)
    assert pm.get_auth_plugin_mapping() == {'pm': PluginManager}



# Generated at 2022-06-12 00:22:24.925646
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugins = plugin_manager.get_auth_plugin_mapping()
    assert ("basic" in plugins)
    assert ("digest" in plugins)
    assert ("aws-sigv4" in plugins)
    assert ("ntlm" in plugins)
    assert ("oauth1" in plugins)
    assert ("aws-sigv4" in plugins)
    assert ("hawk" in plugins)
    assert ("http-signature" in plugins)
    assert ("jwt" in plugins)
    assert ("bearer" in plugins)



# Generated at 2022-06-12 00:22:29.353958
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth import JWTAuthPlugin, BasicAuthPlugin
    manager = PluginManager()
    manager.register(BasicAuthPlugin)
    manager.register(JWTAuthPlugin)
    mapping = manager.get_auth_plugin_mapping()
    assert mapping == {'basic': BasicAuthPlugin, 'jwt': JWTAuthPlugin}



# Generated at 2022-06-12 00:22:42.072786
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin

    # Create the plugin manager
    plugin_manager = PluginManager()
    plugin_manager.register(JSONFormatterPlugin,
                            PrettyJSONFormatterPlugin,
                            RawJSONFormatterPlugin)

    # Get the list of formatters
    formatters = plugin_manager.get_formatters()
    assert len(formatters) == 3
    assert formatters == [JSONFormatterPlugin,
                          PrettyJSONFormatterPlugin,
                          RawJSONFormatterPlugin]

    # Group the formatters
    formatters_grouped = plugin_manager.get_formatters_grouped()

# Generated at 2022-06-12 00:22:44.943303
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager(['Plugin1', 'Plugin2', 'Plugin3'])
    print(repr(plugins))

    plugins.load_installed_plugins()
    print(repr(plugins))



# Generated at 2022-06-12 00:22:51.965459
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm=PluginManager()
    pm.load_installed_plugins()
    print(pm.get_formatters_grouped())

if __name__=='__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:22:55.709282
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(AuthPlugin)
    pm.register(ConverterPlugin)
    assert pm.filter() == [AuthPlugin, ConverterPlugin]
    assert pm.filter(BasePlugin) == [AuthPlugin, ConverterPlugin]
    assert pm.filter(AuthPlugin) == [AuthPlugin]

# Generated at 2022-06-12 00:22:59.048529
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    # plugins.filter()  # TODO need to define the only condition?


# Generated at 2022-06-12 00:23:00.721844
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0



# Generated at 2022-06-12 00:23:07.085826
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin, TransportPlugin, ConverterPlugin, FormatterPlugin)
    assert plugins.get_auth_plugins() == [AuthPlugin]
    assert plugins.get_formatters() == [FormatterPlugin]
    assert plugins.get_converters() == [ConverterPlugin]
    assert plugins.get_transport_plugins() == [TransportPlugin]

# Generated at 2022-06-12 00:23:10.839051
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin = PluginManager()
    plugin.register(FormatterPlugin)
    plugin.register(FormatterPlugin)
    plugin.register(FormatterPlugin)
    assert len(plugin.get_formatters_grouped()) == 1
    assert len(plugin.get_formatters_grouped()['Formatter']) == 3

# Generated at 2022-06-12 00:23:13.098120
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert p[0].package_name == 'httpie'

# Generated at 2022-06-12 00:23:18.482658
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = [HttpiePlugin, HTTPiePlugin, BasePlugin, PluginManager]
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)
    assert plugin_manager.filter(BasePlugin) == plugins
    assert plugin_manager.filter(HttpiePlugin) == [HttpiePlugin]
    assert plugin_manager.filter(HTTPiePlugin) == [HTTPiePlugin]
    assert plugin_manager.filter(PluginManager) == [PluginManager]



# Generated at 2022-06-12 00:23:21.081155
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) != 0
    assert isinstance(pm[0], BasePlugin)

# Generated at 2022-06-12 00:23:28.991067
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    
    manager = PluginManager()
    manager.register(HTTPBasicAuth, HTTPTokenAuth, HTTPProxyAuth)
    # Create a dictionary of plugins
    mapping = manager.get_auth_plugin_mapping()
    print(mapping)
    
    
if __name__ == '__main__':
    test_PluginManager_get_auth_plugin_mapping()

# Generated at 2022-06-12 00:23:41.460061
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    # print(manager.get_auth_plugin_mapping())

# Generated at 2022-06-12 00:23:44.770876
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    for plugin in pm:
        assert issubclass(plugin, BasePlugin)

# Generated at 2022-06-12 00:23:49.400257
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {}
    plugin_manager.register(FormatterPlugin)
    assert plugin_manager.get_formatters_grouped() == {}
    plugin_manager.register(FormatterPlugin)
    assert plugin_manager.get_formatters_grouped() == {}

# Generated at 2022-06-12 00:23:56.357227
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Test case data
    entry_point_name =\
        'httpie.plugins.auth.v1'
    entry_point_class =\
        'httpie_authenticator_aws4.Aws4AuthPlugin'
    entry_point_dist =\
        'httpie-aws4auth'

    # Mocking
    import_module = 'httpie.plugins.manager.importlib.import_module'
    load_entry_point = 'httpie.plugins.manager.pkg_resources.get_distribution'
    attempt_load = 'httpie.plugins.manager.plugin_manager.attempt_to_load'
    entry_point_iterator = 'httpie.plugins.manager.iter_entry_points'
    exception_class = 'httpie.plugins.manager.pkg_resources.DistributionNotFound'


# Generated at 2022-06-12 00:24:06.368024
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie import ExitStatus
    from httpie.plugins import AuthPlugin
    from httpie.plugins.base import BasePlugin
    from httpie.utils import windows_stdout_redirected
    import sys

    # Creating test entry_point and testing is_installed_package function
    entry_point_name = 'httpie.plugins.auth.v1'
    entry_point_name_installed = 'httpie.plugins.auth.v1'
    entry_point_name_not_installed = 'httpie.plugins.auth.v2'

    # Create package_name_installed
    entry_point_installed = BasePlugin.entry_point_mock(entry_point_name_installed)
    entry_point_installed.load.package_name = 'httpie'

    # Create package_name_not_installed
    entry_point_not

# Generated at 2022-06-12 00:24:15.272385
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped == {
        None: [
            httpie.plugins.formatter.json.JSONFormatter,
            httpie.plugins.formatter.json.PrettyJSONFormatter,
            httpie.plugins.formatter.json.DisplayJSONFormatter,
            httpie.plugins.formatter.json.StreamJSONFormatter,
            httpie.plugins.formatter.json.StreamPrettyJSONFormatter,
            httpie.plugins.formatter.json.StreamDisplayJSONFormatter,
        ],
        'Html': [httpie.plugins.formatter.html.HTMLFormatter],
    }

# Generated at 2022-06-12 00:24:21.899198
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    # prepare
    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin1, TestPlugin2, TestPlugin3, TestPlugin4)

    # execute
    groups = plugin_manager.get_formatters_grouped()

    # assert
    assert len(groups['group1']) == 1
    assert len(groups['group2']) == 1
    assert len(groups['group3']) == 2



# Generated at 2022-06-12 00:24:24.665070
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPluginMock())
    print(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-12 00:24:29.053288
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    number_of_plugins = len(pluginManager)
    print(f'\nNumber of plugins: {number_of_plugins}')
    for plugin in pluginManager:
        print(plugin, plugin.package_name)
    assert number_of_plugins > 0


# Generated at 2022-06-12 00:24:35.462392
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager_instance = PluginManager()
    plugin_manager_instance.load_installed_plugins()
    assert len(plugin_manager_instance) == 4
    assert len(plugin_manager_instance.get_auth_plugins()) == 1
    assert len(plugin_manager_instance.get_formatters()) == 3
    assert len(plugin_manager_instance.get_transport_plugins()) == 1


# Generated at 2022-06-12 00:24:47.901259
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(FormatterPlugin1, FormatterPlugin2, FormatterPlugin3)
    
    format_groups = {
        'Format1': [FormatterPlugin1],
        'Format2': [FormatterPlugin2, FormatterPlugin3]
    }

    assert manager.get_formatters_grouped() == format_groups


# Generated at 2022-06-12 00:24:49.905449
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.standard import HTTPBasicAuth
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert HTTPBasicAuth in plugin_manager


# Generated at 2022-06-12 00:24:54.216276
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    formatter_plugins = plugin_manager.get_formatters()
    formatter_groups = plugin_manager.get_formatters_grouped()
    assert set(formatter_plugins) == set(formatter_groups['main'])

# Generated at 2022-06-12 00:24:58.538452
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONPrettyStreamFormatter

    class ExtendedPlugin(FormatterPlugin, JSONPrettyStreamFormatter):
        group_name = 'extended'

    plugin_manager = PluginManager()
    plugin_manager.register(ExtendedPlugin)
    assert plugin_manager.get_formatters_grouped() == {'extended': [ExtendedPlugin]}


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-12 00:25:08.011428
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """
    > python -c "from plugins import PluginManager; manager = PluginManager(); manager.register(FormatterPlugin); print (manager.get_formatters_grouped())"
    > python -c "from plugins import PluginManager; manager = PluginManager(); print (manager.get_formatters_grouped())"
    > python -c "from plugins import PluginManager; manager = PluginManager(); manager.register(FormatterPlugin); manager.register(BasePlugin); print (manager.get_formatters_grouped())"
    > python -c "from plugins import PluginManager; manager = PluginManager(); manager.register(FormatterPlugin); manager.register(FormatterPlugin); print (manager.get_formatters_grouped())"
    """
    pass

# Generated at 2022-06-12 00:25:14.336994
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugins.register(entry_point.load())
    assert len(plugins.filter(AuthPlugin)) == 1
    assert len(plugins.filter(TransportPlugin)) == 1
    assert len(plugins.filter(ConverterPlugin)) == 1
    assert len(plugins.filter(FormatterPlugin)) == 1


# Generated at 2022-06-12 00:25:16.966856
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class FormatterPluginMock(FormatterPlugin):
        group_name = 'Mock'
    pm = PluginManager()

# Generated at 2022-06-12 00:25:21.906787
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A():
        pass
    class B():
        pass
    class C():
        pass
    class D(A):
        pass
    class E(A):
        pass
    PluginManager.register(A, B, C)
    assert PluginManager.filter(A) == [A,D,E]


# Generated at 2022-06-12 00:25:23.304907
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins(PluginManager())



# Generated at 2022-06-12 00:25:29.196285
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

    class Dummy(FormatterPlugin):
        group_name = 'aaa'

    class Dummy2(FormatterPlugin):
        group_name = 'aaa'

    class Dummy3(FormatterPlugin):
        group_name = 'bbb'

    plugin_manager.register(Dummy, Dummy2, Dummy3)

    assert plugin_manager.get_formatters_grouped() == {'aaa': [Dummy, Dummy2], 'bbb': [Dummy3]}

# Generated at 2022-06-12 00:25:47.266521
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    formatters_grouped = manager.get_formatters_grouped()
    assert formatters_grouped['output']
    assert formatters_grouped['convert']

# Generated at 2022-06-12 00:25:49.992701
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    # Teste de validação da quantidade de plugins instalados com a classe PluginManager
    assert len(pm) == 29

# Generated at 2022-06-12 00:25:53.884889
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    result = pluginManager.get_formatters_grouped()
    print(result)


if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:25:59.018513
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(ListFormatter, PrettyFormatter, JsonFormatter, HtmlFormatter)
    assert plugin_manager.get_formatters_grouped() == {
        'default': [ListFormatter, PrettyFormatter],
        'json': [JsonFormatter],
        'html': [HtmlFormatter],
    }


# Generated at 2022-06-12 00:26:10.900403
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(httpie_plugins.__dict__["HTMLFormatter"])
    pm.register(httpie_plugins.__dict__["JSONFormatter"])
    pm.register(httpie_plugins.__dict__["PrettyJsonFormatter"])
    pm.register(httpie_plugins.__dict__["PrettyJsonStreamingFormatter"])
    pm.register(httpie_plugins.__dict__["RawBodyFormatter"])
    pm.register(httpie_plugins.__dict__["URLEncodedFormatter"])
    pm.register(httpie_plugins.__dict__["UppercaseFormatter"])
    pm.register(httpie_plugins.__dict__["URLCompactFormatter"])

# Generated at 2022-06-12 00:26:13.510172
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins_mgr = PluginManager()
    plugins_mgr.register(Type[BasePlugin], Type[AuthPlugin])
    p = plugins_mgr.filter(AuthPlugin)
    assert p == [Type[AuthPlugin]]


# Generated at 2022-06-12 00:26:15.825473
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert len(PluginManager().load_installed_plugins()) > 0
    assert len(PluginManager().get_auth_plugins()) > 0
    assert len(PluginManager().get_formatters()) > 0
    assert len(PluginManager().get_converters()) > 0
    assert len(PluginManager().get_transport_plugins()) > 0



# Generated at 2022-06-12 00:26:25.491375
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, JSONFormatter, CurlConverter, AsyncHTTPAdapter
    from httpie.plugins.builtin.tests.helpers import DummyFormatter, DummyConverter, DummyAdapter
    pm = PluginManager()
    pm.register(HTTPBasicAuth, JSONFormatter, DummyFormatter, DummyConverter, DummyAdapter)
    assert pm.filter(AuthPlugin) == [HTTPBasicAuth]
    assert pm.filter(ConverterPlugin) == [CurlConverter, DummyConverter]
    assert pm.filter() == [HTTPBasicAuth, JSONFormatter, CurlConverter, AsyncHTTPAdapter, DummyFormatter, DummyConverter, DummyAdapter]

# Generated at 2022-06-12 00:26:26.442514
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin
    assert len(PluginManager().filter(AuthPlugin)) == 0



# Generated at 2022-06-12 00:26:34.706992
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class BasePluginA(object):
        pass
    class BasePluginB(object):
        pass
    class PluginA(BasePluginA):
        pass
    class PluginB(BasePluginB):
        pass
    class PluginAB(BasePluginA, BasePluginB):
        pass
    m=PluginManager()
    m.register(PluginA, PluginB, PluginAB)
    assert m.filter(BasePluginA) == [PluginA, PluginAB]
    assert m.filter(BasePluginB) == [PluginB, PluginAB]


# Generated at 2022-06-12 00:27:38.336649
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    # Mock formatter plugins
    class MockFormatterPlugin_A(FormatterPlugin):
        group_name = 'Group_A'
    class MockFormatterPlugin_B(FormatterPlugin):
        group_name = 'Group_B'
    class MockFormatterPlugin_C(FormatterPlugin):
        group_name = 'Group_C'

    # Test
    class_list = [
        MockFormatterPlugin_A,
        MockFormatterPlugin_B,
        MockFormatterPlugin_B,
        MockFormatterPlugin_C,
        MockFormatterPlugin_C,
        MockFormatterPlugin_C,
    ]
    plugin_manager = PluginManager()
    plugin_manager.register(*class_list)
    result = plugin_manager.get_formatters_grouped()

    # Assert

# Generated at 2022-06-12 00:27:42.327031
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
	manager = PluginManager()
	manager.load_installed_plugins()
	print(manager.get_formatters_grouped())

# Generated at 2022-06-12 00:27:47.128324
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    Testing if load_installed_plugins method of class PluginManager works fine.
    """
    pm = PluginManager()
    # Loading plugin manager
    pm.load_installed_plugins()
    # Testing if loaded plugins are of type BasePlugin
    for plugin in pm:
        assert issubclass(plugin, BasePlugin)

# Generated at 2022-06-12 00:27:52.789521
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(
        type('VerboseFormatter', (FormatterPlugin,), {}),
        type('ColorfulFormatter', (FormatterPlugin,), {})
    )
    assert manager.get_formatters_grouped() == {
        'verbose': [manager[0]],
        'color': [manager[1]],
    }
    
test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:27:55.821756
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPluginTest(FormatterPlugin):
        group_name = 'test'
    p = PluginManager()
    p.register(FormatterPluginTest)
    assert p.get_formatters_grouped()['test'] == [FormatterPluginTest]

# Generated at 2022-06-12 00:27:57.563298
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    l = PluginManager()
    l.load_installed_plugins()
    assert( len(l) != 0 )

# Generated at 2022-06-12 00:28:01.395241
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    formatters = plugins.get_formatters()
    print('formatters:', formatters)
    print('grouped formatters:', plugins.get_formatters_grouped())

if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:28:06.095695
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class TestFormat(FormatterPlugin):
        pass
    class TestFormat2(FormatterPlugin):
        pass
    class TestFormat3(FormatterPlugin):
        group_name = 'test1'
    class TestFormat4(FormatterPlugin):
        group_name = 'test2'
    pluginManager = PluginManager()
    pluginManager.register(TestFormat,TestFormat2,TestFormat3,TestFormat4)
    print(pluginManager.get_formatters_grouped())

# Generated at 2022-06-12 00:28:08.741005
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.get_auth_plugin_mapping()
    if plugin_manager.get_auth_plugin_mapping():
        print('Pass')


# Generated at 2022-06-12 00:28:13.374235
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.append(FormatterPlugin)
    plugin_manager.append(FormatterPlugin)
    plugin_manager.append(FormatterPlugin)
    plugin_manager.append(FormatterPlugin)
    plugin_manager.append(FormatterPlugin)
    assert plugin_manager.get_formatters_grouped() == {}


plugin_manager = PluginManager()

# Generated at 2022-06-12 00:29:34.132343
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import (
        AuthPlugin,
        ConverterPlugin,
        FormatterPlugin,
        TransportPlugin
    )
    from httpie.plugins.adapter import AdapterPlugin
    from httpie.plugins.tool import ToolPlugin
    from httpie.plugins.builtin import AuthPlugin as BuiltinAuthPlugin
    from httpie.plugins.builtin import FormatterPlugin as BuiltinFormatterPlugin
    from httpie.plugins.builtin import ConverterPlugin as BuiltinConverterPlugin
    from httplugins.auth.bearer import BearerAuthPlugin
    from httplugins.auth.digest import DigestAuthPlugin
    from httplugins.auth.hawk import HawkAuthPlugin
    from httplugins.auth.oauth1 import OAuth1AuthPlugin
    from httplugins.auth.oauth2 import OAuth2AuthPlugin

# Generated at 2022-06-12 00:29:40.177878
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Base(TransportPlugin):
        pass
    class Plugin1(Base):
        group_name = 'group1'
    class Plugin2(Base):
        group_name = 'group2'
    class Plugin3(Base):
        group_name = 'group2'

    pm = PluginManager()
    pm.register(Plugin1, Plugin2, Plugin3)

    print(pm.get_formatters_grouped())

    for key, value in pm.get_formatters_grouped().items():
        print(key, value)

if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()