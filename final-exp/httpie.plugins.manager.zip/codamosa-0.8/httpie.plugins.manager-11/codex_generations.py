

# Generated at 2022-06-12 00:19:46.607797
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin

    pm = PluginManager()
    pm.register(JSONFormatterPlugin, PrettyJsonFormatterPlugin)
    pm.get_formatters_grouped() == {
        FormatterPlugin.group_name: [JSONFormatterPlugin, PrettyJsonFormatterPlugin]
    }


# Generated at 2022-06-12 00:19:51.254973
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}
    PluginManager().register(AuthPlugin)
    assert PluginManager().get_auth_plugin_mapping() == {'auth': AuthPlugin}
    PluginManager().unregister(AuthPlugin)
    assert PluginManager().get_auth_plugin_mapping() == {}



# Generated at 2022-06-12 00:19:55.721347
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(AuthPlugin)
    manager.register(TransportPlugin)
    assert issubclass(manager.filter(by_type=TransportPlugin)[0], TransportPlugin)
    assert not issubclass(manager.filter(by_type=TransportPlugin)[0], AuthPlugin)

# Unit tests for method load_installed_plugins of class PluginManager

# Generated at 2022-06-12 00:20:01.310291
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)

    assert not PluginManager.filter()
    assert PluginManager.filter(AuthPlugin)
    assert not PluginManager.filter(TransportPlugin)



# Generated at 2022-06-12 00:20:06.227192
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    a = PluginManager()
    a.register(AuthPlugin, ConverterPlugin)
    assert(a.filter(AuthPlugin) == [AuthPlugin])
    assert(a.filter(ConverterPlugin) == [ConverterPlugin])
    assert(a.filter(ConverterPlugin) != [AuthPlugin])


# Generated at 2022-06-12 00:20:16.878787
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    
    # Initialize a PluginManager object
    pm = PluginManager()
    
    # Check if the auth plugin mapping is what we want
    assert pm.get_auth_plugin_mapping() == {
        'basic': BasicAuthPlugin,
        'digest': DigestAuthPlugin,
        'hawk': HawkAuthPlugin,
        'aws-sigv4': AWSSigV4AuthPlugin,
        'aws-sigv4-with-session': AWSSigV4AuthWithSessionPlugin,
        'aws-sigv4-unsigned-payload': AWSSigV4AuthUnsignedPayloadPlugin,
        'jwt': JWTAuthPlugin,
        'ntlm': NTLMAuthPlugin,
        'oauth1': OAuth1Plugin
    }
    

# Generated at 2022-06-12 00:20:23.196470
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(A): pass
    p = PluginManager()
    p.register(A, B, C, D)
    assert p.filter(A) == [A, B, C, D]
    assert p.filter(B) == [B]
    assert p.filter(C) == [C]


# Generated at 2022-06-12 00:20:28.639064
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager.register([AuthPlugin, FormatterPlugin, ConverterPlugin])
    assert PluginManager.filter(AuthPlugin) == [AuthPlugin]
    assert PluginManager.filter(FormatterPlugin) == [FormatterPlugin]
    assert PluginManager.filter(ConverterPlugin) == [ConverterPlugin]
    assert PluginManager.filter(Type[BasePlugin]) == [AuthPlugin, FormatterPlugin, ConverterPlugin]

# Generated at 2022-06-12 00:20:40.676602
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import HTTPieJSONFormatter, HTTPiePrettyJsonFormatter
    from httpie.plugins.builtin import HTTPieColoredStreamFormatter
    from httpie.plugins.builtin import HTTPieStreamFormatter
    plugins = PluginManager()
    plugins.register(HTTPieJSONFormatter, HTTPiePrettyJsonFormatter)
    plugins.register(HTTPieColoredStreamFormatter, HTTPieStreamFormatter)
    plugins_get_formatters_grouped = plugins.get_formatters_grouped()
    assert plugins_get_formatters_grouped.get('builtin') == [HTTPieJSONFormatter, HTTPiePrettyJsonFormatter]
    assert plugins_get_formatters_grouped.get('colors') == [HTTPieColoredStreamFormatter, HTTPieStreamFormatter]

# Generated at 2022-06-12 00:20:52.330807
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert len(PluginManager().filter()) == 0
    assert len(PluginManager().filter(BasePlugin)) == 0
    assert len(PluginManager().filter(Type[BasePlugin])) == 0

    plugin1 = type('Plugin1', (BasePlugin,), {})
    plugin2 = type('Plugin2', (BasePlugin,), {})
    plugin3 = type('Plugin3', (BasePlugin,), {})

    plugin1_formatter1 = type('Plugin1_formatter1', (plugin1, FormatterPlugin), {})
    plugin1_formatter2 = type('Plugin1_formatter2', (plugin1, FormatterPlugin), {})
    plugin1_formatter3 = type('Plugin1_formatter3', (plugin1, FormatterPlugin), {})

# Generated at 2022-06-12 00:20:57.018054
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0

# Generated at 2022-06-12 00:21:00.331423
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    """
    Unit test for method load_installed_plugins of class PluginManager
    :return:assertion
    """

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-12 00:21:05.459455
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    formats_grouped = plugin_manager.get_formatters_grouped()

    # check if all of the plugins have been registered,
    # and they are all non-empty (they have at least one
    # plugin registered)
    assert all(formats_grouped.values())

# Generated at 2022-06-12 00:21:11.281384
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    pluginManager.get_auth_plugin_mapping() == {
        'basic': pluginManager.get_auth_plugin('basic'),
        'digest': pluginManager.get_auth_plugin('digest'),
        'hawk': pluginManager.get_auth_plugin('hawk'),
        'netrc': pluginManager.get_auth_plugin('netrc'),
        'ntlm': pluginManager.get_auth_plugin('ntlm'),
        '2fa-totp': pluginManager.get_auth_plugin('2fa-totp')
    }

# Generated at 2022-06-12 00:21:14.886775
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    assert plugin_manager == []
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert plugin_manager != []

# Generated at 2022-06-12 00:21:18.809739
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()

    plugin_manager.load_installed_plugins()

    len_plugin_manager = len(ENTRY_POINT_NAMES)
    assert len(plugin_manager) == len_plugin_manager, 'All plugins loaded'



# Generated at 2022-06-12 00:21:26.703514
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPlugin_Mock(FormatterPlugin):
        group_name = 'mock'
    class FormatterPlugin_Mock_1(FormatterPlugin_Mock):
        pass
    class FormatterPlugin_Mock_2(FormatterPlugin_Mock):
        pass
    class FormatterPlugin_A(FormatterPlugin):
        group_name = 'a'
    class FormatterPlugin_B(FormatterPlugin):
        group_name = 'b'
    plugin_manager = PluginManager()
    plugin_manager.register(
        FormatterPlugin_Mock_1,
        FormatterPlugin_Mock_2,
        FormatterPlugin_A,
        FormatterPlugin_B,
    )

# Generated at 2022-06-12 00:21:29.812762
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:21:32.192163
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager_0 = PluginManager()
    print(PluginManager_0.get_formatters_grouped())


# Generated at 2022-06-12 00:21:38.750477
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    class AuthPlugin:
        def __init__(self,):
            self.name = "Auth"
    class TransportPlugin:
        def __init__(self,):
            self.name = "Transport"
    plugin_manager.register(*[AuthPlugin, TransportPlugin])
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(TransportPlugin) == [TransportPlugin]



# Generated at 2022-06-12 00:21:54.724300
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from .helpers import TestPlugin
    from .helpers import TestAuthPlugin
    from .helpers import TestAuthPlugin2
    from .helpers import TestOutputPlugin
    from .helpers import TestOutputPlugin2
    from .helpers import TestTransportPlugin
    from .helpers import TestTransportPlugin2
    from .helpers import Test_get_auth_plugin_mapping
    from .helpers import Test_get_formatters_grouped
    from .helpers import Test_get_transport_plugins
    pl_mg = PluginManager()
    pl_mg.register(TestPlugin, TestAuthPlugin, TestAuthPlugin2,
                   TestOutputPlugin, TestOutputPlugin2, TestTransportPlugin,
                   TestTransportPlugin2)

# Generated at 2022-06-12 00:22:06.314401
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    #1 Test if the entry_point_name is correct.
    assert pm[0].__module__ == 'httpie_plugins_installed.auth.basic'
    assert pm[1].__module__ == 'httpie_plugins_installed.auth.digest'
    assert pm[2].__module__ == 'httpie_plugins_installed.formatter.colors'
    assert pm[3].__module__ == 'httpie_plugins_installed.formatter.format'
    assert pm[4].__module__ == 'httpie_plugins_installed.formatter.json'
    assert pm[5].__module__ == 'httpie_plugins_installed.formatter.pretty'

# Generated at 2022-06-12 00:22:09.223604
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()
    grouped_formatters = manager.get_formatters_grouped()
    assert sorted(grouped_formatters.keys()) == ['Data processing', 'Output']

# Generated at 2022-06-12 00:22:17.740765
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from json import JSONFormatter
    from httpie.plugins import FormatterPlugin

    class HttpBinOrgJSONFormatter(JSONFormatter):
        group_name = 'httpbin'

    class JSONFormatterV1(FormatterPlugin):
        group_name = 'httpbin'

    manager = PluginManager()
    manager.register(JSONFormatterV1, HttpBinOrgJSONFormatter)

    formatters_grouped = manager.get_formatters_grouped()

    assert formatters_grouped['httpbin'] == [JSONFormatterV1, HttpBinOrgJSONFormatter]

# Generated at 2022-06-12 00:22:19.404767
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert isinstance(pm.get_auth_plugin_mapping(), dict)

# Generated at 2022-06-12 00:22:27.165132
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_formatters()) > 0
    assert len(pm.get_auth_plugins()) > 0
    assert len(pm.get_converters()) > 0
    assert len(pm.get_transport_plugins()) > 0
    assert pm.get_auth_plugin('basic')
    assert pm.get_formatters_grouped()
    assert pm.get_auth_plugin_mapping()



# Generated at 2022-06-12 00:22:28.943870
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(Plugin)

    assert manager.get_auth_plugin_mapping() == {'test': Plugin}


# Generated at 2022-06-12 00:22:35.739039
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    list_formatters = [FormatterPlugin, FormatterPlugin]
    plugin_manager = PluginManager()
    plugin_manager.register(list_formatters[0])
    plugin_manager.register(list_formatters[1])
    assert plugin_manager.get_formatters_grouped() == [FormatterPlugin]


# Generated at 2022-06-12 00:22:39.097388
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    assert len(plugins.get_formatters_grouped()) == 1

# Generated at 2022-06-12 00:22:44.207210
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D: pass

    a = A()
    b = B()
    c = C()
    d = D()

    assert sorted(list(PluginManager().register(A, B, C, D).filter(A))) == [B, C]
    assert list(PluginManager().register(A, B, C, D).filter(D)) == [D]
    assert list(PluginManager().register(A, B, C, D).filter(object)) == [A, B, C, D]

# Generated at 2022-06-12 00:23:01.137277
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class BasePlugin1(BasePlugin):
        pass
    class BasePlugin2(BasePlugin):
        pass
    class BasePlugin3(BasePlugin1):
        pass
    plugin1 = BasePlugin1
    plugin2 = BasePlugin2
    plugin3 = BasePlugin3
    plugin_manager = PluginManager()
    plugin_manager.register(plugin1, plugin2)
    assert plugin_manager.filter() == [plugin1, plugin2]
    assert plugin_manager.filter(BasePlugin1) == [plugin1]
    assert plugin_manager.filter(BasePlugin2) == [plugin2]
    assert plugin_manager.filter(BasePlugin3) == [plugin3]


# Generated at 2022-06-12 00:23:05.221214
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()

    assert len(manager) > 0
    assert manager[0].__class__.__name__ == 'DigestAuthPlugin'

# Generated at 2022-06-12 00:23:07.047109
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    for plugin in p:
        assert plugin.name
        assert plugin.package_name

# Generated at 2022-06-12 00:23:07.842288
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()

# Generated at 2022-06-12 00:23:18.029861
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class B:
        pass
    class C:
        pass
    class D(B):
        pass
    class A(D,C):
        pass
    class E(A,B):
        pass
    class F(E):
        pass
    class G:
        pass
    class H(F):
        pass
    obj_list = [A,B,C,D,E,F,G,H]
    manager = PluginManager()
    manager.register(A)
    manager.register(B)
    manager.register(C)
    manager.register(D)
    manager.register(E)
    manager.register(F)
    manager.register(G)
    manager.register(H)
    result = manager.filter(C)
    expected = [C]
    assert result == expected

# Generated at 2022-06-12 00:23:24.014042
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    l = PluginManager()
    l.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    print()
    print(l.filter(AuthPlugin))
    print(l.filter(FormatterPlugin))
    print(l.filter(ConverterPlugin))
    print(l.filter(TransportPlugin))


if __name__ == "__main__":
    test_PluginManager_filter()

# Generated at 2022-06-12 00:23:32.486395
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin

    def ensure_installed_plugins_loaded(
            all_plugins: List[Type[BasePlugin]],
            installed_plugins: List[str]
    ):
        """
            Check installed plugin

            :param all_plugins: All plugins are load by program
            :param installed_plugins: List name of installed plugins
        """
        installed_plugins_names = list(map(lambda plugin_name: plugin_name.split('.')[-1],
                                           installed_plugins))
        expected_plugin_classes = [plugin_name for plugin_name in all_plugins if
                                   plugin_name.__name__ in installed_plugins_names]

        for plugin_class in expected_plugin_classes:
            assert plugin_class in all_plugins

# Generated at 2022-06-12 00:23:40.474042
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    try:
        from pytest import mark
        pytest = mark.skip
    except ImportError:
        pytest = lambda fn: fn

    @pytest
    def test_get_auth_plugin_mapping():
        PluginManager_one = PluginManager()
        PluginManager_one.register("httpie.plugins.auth.basic.BasicAuthPlugin ")
        PluginManager_one.register("httpie.plugins.auth.digest.DigestAuthPlugin ")
        PluginManager_one.register("httpie.plugins.auth.jwt.JWTAuthPlugin ")
        
        assert PluginManager_one.get_auth_plugin_mapping() is not None

# Generated at 2022-06-12 00:23:50.626067
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginB):
        pass

    class PluginD(BasePlugin):
        pass

    class PluginE(PluginD):
        pass

    plugins = PluginManager()
    plugins.register(PluginA, PluginB, PluginC, PluginD, PluginE)

    assert plugins.filter(BasePlugin) == [
        PluginA, PluginB, PluginC, PluginD, PluginE
    ]
    assert plugins.filter(PluginB) == [PluginB, PluginC]
    assert plugins.filter(PluginD) == [PluginD, PluginE]



# Generated at 2022-06-12 00:23:51.548413
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager=PluginManager()
    manager.load_installed_plugins()
    print(manager.get_auth_plugin_mapping())



# Generated at 2022-06-12 00:24:08.793915
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPBasicAuth

    plugin_manager = PluginManager()

    class FakeAuthPlugin(AuthPlugin):
        auth_type = 'fake-auth'
        auth_parse = False

    class FakeFormatterPlugin(FormatterPlugin):
        output_format = 'fake-formatter'

    class FakeConverterPlugin(ConverterPlugin):
        convert_mime = 'fake-converter'

    class FakeBasePlugin(BasePlugin):
        pass

    plugin_manager.register(FakeAuthPlugin, FakeFormatterPlugin, HTTPBasicAuth,
                            FakeConverterPlugin, FakeBasePlugin)

    auth_plugin_mapping = plugin_manager.get_auth_plugin_m

# Generated at 2022-06-12 00:24:13.010633
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    assert plugins.get_auth_plugins() != []
    assert plugins.get_formatters() != []
    assert plugins.get_converters() != []
    assert plugins.get_transport_plugins() != []


# Generated at 2022-06-12 00:24:14.501586
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager_filter = PluginManager().filter
    assert PluginManager_filter(by_type=BasePlugin) == []

# Generated at 2022-06-12 00:24:18.481518
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(Type[BasePlugin]):
        pass
    class Plugin2(Type[BasePlugin]):
        pass
    pm = PluginManager()
    pm.register(Plugin1, Plugin2)
    assert pm.filter() == [Plugin1, Plugin2]


# Generated at 2022-06-12 00:24:22.977163
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    for plugin in pluginManager:
        module = importlib.import_module(plugin.package_name + '.plugin')
        assert module.plugin.__name__ == plugin.__name__

# Generated at 2022-06-12 00:24:24.822038
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    assert len(pm) == 0
    pm.load_installed_plugins()
    assert l

# Generated at 2022-06-12 00:24:25.877374
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert type(PluginManager().get_formatters_grouped()) == dict



# Generated at 2022-06-12 00:24:30.512587
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.aws import AWSBasicAuth
    plugin = PluginManager()
    plugin.register(AWSBasicAuth)
    assert plugin.get_auth_plugin_mapping().get("aws-basic-auth") is not None
    assert type(plugin.get_auth_plugin_mapping().get("aws-basic-auth")) is type

# Generated at 2022-06-12 00:24:34.341399
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugin_mapping().__len__() >= 1


# Generated at 2022-06-12 00:24:42.988241
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import sys
    import json
    import unittest
    from httpie.plugins.formatter.formatters.colors import ColorsFormatter
    from httpie.plugins.formatter.formatters.format import FormatFormatter
    from httpie.plugins.formatter.formatters.json import JSONFormatter
    from httpie.plugins.formatter.formatters.pretty import PrettyFormatter
    from httpie.plugins.formatter.formatters.stream import StreamFormatter
    from httpie.plugins.formatter.formatters.table import TableFormatter
    from httpie.plugins.formatter.formatters.verbose import VerboseFormatter
    from httpie.plugins.formatter.formatters.raw import RawFormatter

    plugin_manager = PluginManager()
    plugin_manager.register(ColorsFormatter)

# Generated at 2022-06-12 00:25:06.368884
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    for entry_point_name in ENTRY_POINT_NAMES:
        assert all(isinstance(entry_point, BasePlugin) for entry_point in iter_entry_points(entry_point_name))
        assert plugin_manager[0] != plugin_manager[1]

# Generated at 2022-06-12 00:25:14.519909
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Initialize the object of class PluginManager
    plugin_manager = PluginManager()
    # Load the plugins which installed in conda environment
    plugin_manager.load_installed_plugins()
    # Get the grouped formatters
    grouped_formatters = plugin_manager.get_formatters_grouped()
    # Check if the length of the grouped formatters is 2
    assert len(grouped_formatters) == 2, \
        'Unexpected number of groups'
    # Check if the length of the 'display' group is 2
    assert len(grouped_formatters['Display']) == 2, \
        'Unexpected number of plugins in "Display" group'

# Generated at 2022-06-12 00:25:22.120501
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Initialize PluginManager instance.
    instance = PluginManager()

    # Load plugins from the entry points.
    instance.load_installed_plugins()

    # Test load auth plugins.
    result = instance.get_auth_plugins()
    expected = [plugin for plugin in result]
    assert result == expected

    # Test load formatters.
    result = instance.get_formatters()
    expected = [plugin for plugin in result]
    assert result == expected

    # Test load converters.
    result = instance.get_converters()
    expected = [plugin for plugin in result]
    assert result == expected

    # Test load transport plugins.
    result = instance.get_transport_plugins()
    expected = [plugin for plugin in result]
    assert result == expected

# Test for method get_auth_plugin_mapping of class

# Generated at 2022-06-12 00:25:28.375519
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(TestFormatters.Raw,
                     TestFormatters.Json,
                     TestFormatters.Json2,
                     TestFormatters.Json3)
    expected_result = {
        "Raw": [TestFormatters.Raw],
        "Json": [TestFormatters.Json, TestFormatters.Json2],
        "Json2": [TestFormatters.Json2]
    }
    assert plugins.get_formatters_grouped() == expected_result


# Generated at 2022-06-12 00:25:37.415313
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    class FakeEntryPoint:
        @staticmethod
        def load():
            return AuthPlugin

        @staticmethod
        def dist():
            return None

    class FakeEntryPoints:
        @staticmethod
        def iter_entry_points(name):
            yield FakeEntryPoint()

    m = PluginManager()
    pkg_resources_original = m.pkg_resources
    m.pkg_resources = FakeEntryPoints()

    try:
        m.load_installed_plugins()
        assert len(m) > 0
        for i in m:
            assert i.__name__ == 'AuthPlugin'
    finally:
        m.pkg_resources = pkg_resources_original



# Generated at 2022-06-12 00:25:47.725139
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Initialize
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    all_plugins = plugin_manager.filter(BasePlugin)
    auth_plugins = plugin_manager.get_auth_plugins()
    formatter_plugins = plugin_manager.get_formatters()
    converter_plugins = plugin_manager.get_converters()
    transport_plugins = plugin_manager.get_transport_plugins()

    # Check
    assert len(all_plugins) == 0
    assert len(auth_plugins) == 0
    assert len(formatter_plugins) == 1
    assert len(converter_plugins) == 2
    assert len(transport_plugins) == 2

# Generated at 2022-06-12 00:25:50.074255
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.append(Type[FormatterPlugin])
    assert 'Type[FormatterPlugin]' in manager.get_formatters_grouped()

# Generated at 2022-06-12 00:25:58.822483
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-12 00:26:02.530570
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    a = AuthenticationPlugin()
    b = AuthenticationPlugin()
    obj = PluginManager()
    obj.register(a,b)
    assert obj.get_auth_plugin_mapping() == {a.auth_type: a, b.auth_type: b}

# Generated at 2022-06-12 00:26:08.449018
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    # Unit test for method get_formatters_grouped of class PluginManager
    import json
    from httpie.plugins.builtin import JSONFormatter

    from httpie.plugins.manager import PluginManager
    tpm = PluginManager()

    print(tpm.get_formatters_grouped())

# Generated at 2022-06-12 00:26:48.815292
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()


# TODO: unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-12 00:26:54.170167
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    class Base:
        pass

    class Specific:
        pass

    class A(Base):
        pass

    class B(Specific):
        pass

    class C(Base):
        pass

    pm = PluginManager()
    pm.register(A, B, C)

    assert pm.filter(Base) == [A, C]
    assert pm.filter(Specific) == [B]

    assert pm.filter() == [A, B, C]

# Generated at 2022-06-12 00:27:00.798697
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager) == 0
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            pluginManager.append(plugin)
            assert plugin in pluginManager



# Generated at 2022-06-12 00:27:01.530445
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager.filter()

# Generated at 2022-06-12 00:27:07.005874
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(A): pass

    plugins = [A(), B(), C(), D()]
    pm = PluginManager(plugins)
    assert C in pm
    assert D in pm
    assert A  not in pm
    assert B  not in pm
    assert None not in pm

# Generated at 2022-06-12 00:27:11.342242
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter.default import DefaultFormatter
    from httpie.plugins import default_options
    manager = PluginManager()
    manager.register(DefaultFormatter)
    m = manager.get_formatters_grouped()
    expected = {'Default': [DefaultFormatter]}
    assert m  == expected
    

# Generated at 2022-06-12 00:27:15.096424
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(TransportPlugin):
        pass
    plugin_manager=PluginManager()
    plugin_manager.register(Plugin1, Plugin2, Plugin3)
    expected = [Plugin3]
    actual = plugin_manager.filter(TransportPlugin)
    assert actual == expected

# Generated at 2022-06-12 00:27:16.695222
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert len(p) > 0


# Generated at 2022-06-12 00:27:20.401725
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    """
    test get_auth_plugin_mapping()
    :return:
    """
    print(PluginManager().get_auth_plugin_mapping())



# Generated at 2022-06-12 00:27:25.442285
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-12 00:28:56.696510
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    formatters = [
        class_("html", "html"),
        class_("json", "json"),
        class_("json", "json"),
        class_("text", "text")
    ]
    manager = PluginManager()
    manager.register(*formatters)
    output = manager.get_formatters_grouped()
    expected_output = {
        "json": [class_("json", "json"), class_("json", "json")],
        "text": [class_("text", "text")],
        "html": [class_("html", "html")],
    }
    assert output == expected_output



# Generated at 2022-06-12 00:29:05.330678
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.base import BasePlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import TransportPlugin
    from typing import Type

    class DummyClass2(ConverterPlugin):
        name = 'xxx'
        group_name = 'test'

    class DummyClass1(TransportPlugin):
        name = 'xxx'
        group_name = 'test'

    manager = PluginManager()
    manager.register(DummyClass1)
    manager.register(DummyClass2)
    assert list(manager.filter(Type[DummyClass1])) == [DummyClass1]
    assert list(manager.filter(TransportPlugin)) == [DummyClass1]

# Generated at 2022-06-12 00:29:08.665852
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    for entry_point_name in ENTRY_POINT_NAMES:
        assert len(list(iter_entry_points(entry_point_name))) == len(pm.filter())


# Generated at 2022-06-12 00:29:10.402628
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert plugin_manager.filter(by_type=int) == []


# Generated at 2022-06-12 00:29:17.020894
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            pm.register(entry_point.load())

    t = pm.get_auth_plugin_mapping()
    assert 'basic' in t
    assert 'digest' in t
    return "OK"


if __name__ == "__main__":
    print(test_PluginManager_get_auth_plugin_mapping())

# Generated at 2022-06-12 00:29:22.254263
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import HTTPiePlugin

    pm = PluginManager()
    pm.register(HTTPiePlugin)
    # print(f'pm.get_formatters_grouped() = {pm.get_formatters_grouped()}')
    assert pm.get_formatters_grouped() == {
        'httpie-main': [HTTPiePlugin],
    }


plugin_manager = PluginManager()

# Generated at 2022-06-12 00:29:22.715794
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pass

# Generated at 2022-06-12 00:29:24.346289
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 4


# Generated at 2022-06-12 00:29:34.359864
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = [
        "httpie.plugins.auth.v1.BasicAuthPlugin",
        "httpie.plugins.auth.v1.DigestAuthPlugin",
        "httpie.plugins.formatter.pretty.PrettyJsonFormatter",
        "httpie.plugins.formatter.pretty.PrettyHttpieFormatter",
        "httpie.plugins.converter.header.BaseHeaderConverter",
        "httpie.plugins.transport.SyncRequestsSyncTransport",
        "httpie.plugins.transport.SyncRequestsAsyncTransport"
    ]
    auth = PluginManager()
    auth.register(*plugins)
    assert auth.filter(AuthPlugin) == ["httpie.plugins.auth.v1.BasicAuthPlugin", "httpie.plugins.auth.v1.DigestAuthPlugin"]
    assert auth.filter

# Generated at 2022-06-12 00:29:41.500870
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    actual = list()
    for plugin in manager:
        actual.append(plugin.__name__)