

# Generated at 2022-06-12 00:19:37.711733
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 1



# Generated at 2022-06-12 00:19:47.194928
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginmanager = PluginManager()
    pluginmanager.load_installed_plugins()
    keys = []
    for key in pluginmanager.__dict__.keys():
        if key.startswith('package_name') and key.endswith('v1'):
            keys.append(key)
    if keys[0] == 'package_name_for_httpie_plugins_auth_v1':
        if keys[1] == 'package_name_for_httpie_plugins_formatter_v1':
            if keys[2] == 'package_name_for_httpie_plugins_converter_v1':
                if keys[3] == 'package_name_for_httpie_plugins_transport_v1':
                    print('Unit test for method load_installed_plugins of class PluginManager: PASSED')

# Generated at 2022-06-12 00:19:56.494914
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # create an instance of the class
    pl = PluginManager()
    # check if it is a dictionary
    assert isinstance(pl.get_auth_plugin_mapping(),dict)
    # check if it is empty
    assert pl.get_auth_plugin_mapping() == {}
    # add an object of type BasePlugin
    class test(BasePlugin):
        def load(self):
            pass
        def init(self):
            pass
    pl.register(test)
    # check if the dictionary is still empty
    assert pl.get_auth_plugin_mapping() == {}
    # add an object of type AuthPlugin
    class test1(AuthPlugin):
        auth_type = 'test'
        def load(self):
            pass
        def init(self):
            pass
    pl.register(test1)
    #

# Generated at 2022-06-12 00:19:58.283799
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pass


# Generated at 2022-06-12 00:20:09.944575
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    def test_plugin_class(BasePlugin):
        pass

    def test_plugin_class_2(BasePlugin):
        pass

    def test_plugin_class_3(BasePlugin):
        pass

    plugin_manager = PluginManager()

    plugin_manager.register(test_plugin_class, test_plugin_class_2, test_plugin_class_3)
    assert len(plugin_manager) == 3

    assert list(plugin_manager.filter(by_type=BasePlugin)) == [test_plugin_class, test_plugin_class_2, test_plugin_class_3]
    assert list(plugin_manager.filter(by_type=test_plugin_class)) == [test_plugin_class]

    plugin_manager.unregister(test_plugin_class)

# Generated at 2022-06-12 00:20:22.408054
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    p.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    l_auth = p.filter(AuthPlugin)
    l_formatter = p.filter(FormatterPlugin)
    l_converter = p.filter(ConverterPlugin)
    l_transport = p.filter(TransportPlugin)
    assert len(l_auth) == 1
    assert len(l_formatter) == 1
    assert len(l_converter) == 1
    assert len(l_transport) == 1
    assert issubclass(l_auth[0], AuthPlugin)
    assert issubclass(l_formatter[0], FormatterPlugin)
    assert issubclass(l_converter[0], ConverterPlugin)

# Generated at 2022-06-12 00:20:23.519564
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins) >= 5


# Generated at 2022-06-12 00:20:28.407886
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Example test data
    plugins = [
        FormatterPlugin(),
        FormatterPlugin(),
    ]

    # Create a manager class with the defined test data
    plugin_manager = PluginManager()
    for plugin in plugins:
        plugin_manager.register(plugin)
    
    # Get the formatted data from PluginManager.get_formatters_grouped()
    data = plugin_manager.get_formatters_grouped()

    # Check that the data is formatted as expected
    assert all(isinstance(i, list) for i in data.values())
    assert len(data) == 1
    assert len(data['<default>']) == 2



# Generated at 2022-06-12 00:20:30.969466
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert isinstance(manager, PluginManager)



plugin_manager = PluginManager()

# Generated at 2022-06-12 00:20:33.013410
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()

# Generated at 2022-06-12 00:20:44.157822
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import httpie.plugins as plugins
    plugins.INSTANCE.clear()
    assert not plugins.INSTANCE.get_formatters()
    plugins.INSTANCE.load_installed_plugins()
    assert plugins.INSTANCE.get_formatters()
    
    import os
    import shutil
    import tempfile
    import subprocess
    
    with tempfile.TemporaryDirectory() as d:
        shutil.copytree(os.path.join(os.path.dirname(__file__),'plugin'), os.path.join(d, 'plugin'))
        shutil.copy(os.path.join(os.path.dirname(__file__),'setup.py'), d)
        subprocess.run('pip install .', cwd=d, shell=True, check=True)
        import httpie.plugins as plugins


# Generated at 2022-06-12 00:20:54.180304
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    # Count number of installed plugins, should be more than 0
    # print(f'{len(plugins)} plugins are loaded')
    assert len(plugins) > 0

    # Count the number of installed auth plugins
    # print(f'{len(plugins.get_auth_plugins())} auth plugins are loaded')
    assert len(plugins.get_auth_plugins()) > 0

    # Count the number of installed formatters
    # print(f'{len(plugins.get_formatters())} formatters are loaded')
    assert len(plugins.get_formatters()) > 0

    # Count the number of installed converters
    # print(f'{len(plugins.get_converters())} converters are loaded')

# Generated at 2022-06-12 00:21:01.945136
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager_ = PluginManager()
    manager_.register(
        # formatter
        TestJsonFormatter,
        TestJsonIndentFormatter,
        TestJsonIndentFormatter2,
        TestPrettyFormatter,
        TestPrettyFormatter2,
        # adapter
        TestAdapter
    )
    expected_ = {
        "JSON": [TestJsonFormatter, TestJsonIndentFormatter, TestJsonIndentFormatter2],
        "Pretty": [TestPrettyFormatter, TestPrettyFormatter2],
    }
    actual_ = manager_.get_formatters_grouped()
    assert actual_ == expected_


# Generated at 2022-06-12 00:21:06.971480
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    m = PluginManager()
    m.load_installed_plugins()
    # Httpie 1.0.x, 2.0.x, 2.1.x:
    assert len(m)>=12
    assert len(m.get_auth_plugins())>=3

test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:21:11.065307
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_plugins = [
        AuthPlugin,
        ConverterPlugin,
        FormatterPlugin,
        TransportPlugin,
    ]
    for plugin in test_plugins:
        assert plugin in PluginManager.get_auth_plugin_mapping()

# Generated at 2022-06-12 00:21:13.880125
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) == 6

# Generated at 2022-06-12 00:21:22.520689
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import DEFAULT_FORMAT_GROUP, AUTO_JSON_FORMAT_GROUP, AUTO_FORMAT_GROUP

    plugin_manager = PluginManager()

    class FormattingPluginA(FormatterPlugin):
        group_name = DEFAULT_FORMAT_GROUP
        format_name = 'a'
    class FormattingPluginB(FormatterPlugin):
        group_name = DEFAULT_FORMAT_GROUP
        format_name = 'b'
    class FormattingPluginC(FormatterPlugin):
        group_name = AUTO_FORMAT_GROUP
        format_name = 'c'
    class FormattingPluginD(FormatterPlugin):
        group_name = AUTO_JSON_FORMAT_GROUP
        format_name = 'd'

# Generated at 2022-06-12 00:21:32.796069
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
    )
    assert manager.get_formatters_grouped() == {
        'default': [
            FormatterPlugin,
            FormatterPlugin,
            FormatterPlugin,
            FormatterPlugin,
            FormatterPlugin,
            FormatterPlugin,
            FormatterPlugin,
            FormatterPlugin,
            FormatterPlugin,
            FormatterPlugin
        ]
    }

# Generated at 2022-06-12 00:21:38.034021
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager([TestFormatter1, TestFormatter2, TestFormatter3])
    actual = manager.get_formatters_grouped()

    expected = {
        'Test': [TestFormatter1, TestFormatter2],
        'Group': [TestFormatter3]
    }

    assert actual == expected, "Not match expected"


# Generated at 2022-06-12 00:21:41.349218
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0

# Generated at 2022-06-12 00:21:48.761868
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)
    assert len(plugin_manager) > 0


# Generated at 2022-06-12 00:21:57.950879
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(BasePlugin):
        pass
    plugin_manager.register(Plugin1, Plugin2, Plugin3)
    assert(plugin_manager.filter() == [Plugin1, Plugin2, Plugin3])
    assert(plugin_manager.filter(BasePlugin) == [Plugin1, Plugin2, Plugin3])
    assert(plugin_manager.filter(object) == [Plugin1, Plugin2, Plugin3])
    assert(plugin_manager.filter(Plugin1) == [Plugin1])
    assert(plugin_manager.filter(Plugin2) == [Plugin2])
    assert(plugin_manager.filter(Plugin3) == [Plugin3])
    assert(plugin_manager.filter(1) == [])


# Generated at 2022-06-12 00:22:05.936635
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin_mapping() == {}
    
    class DummyAuthPlugin(AuthPlugin):
        auth_type = 'dummy'
    plugin_manager.register(DummyAuthPlugin)

    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(auth_plugin_mapping) == 1
    assert auth_plugin_mapping['dummy'] == DummyAuthPlugin


# Generated at 2022-06-12 00:22:12.508160
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0
    assert len(plugin_manager.get_auth_plugin_mapping()) > 0
    assert len(plugin_manager.get_formatters_grouped()) > 0

# Generated at 2022-06-12 00:22:16.039998
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    pluginManager.register(JsonDevNull, CliColoredJson, CliColoredTraceback)
    pluginManager.get_formatters_grouped()

# Generated at 2022-06-12 00:22:21.619267
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    groups = plugin_manager.get_formatters_grouped()
    assert ['pretty', 'colors', 'format', 'formatvars', 'formatdict', 'headers'] == list(groups.keys())
    assert ['pretty', 'colors', 'format', 'formatvars', 'formatdict', 'headers'] == list(groups.keys())
    for group in groups.values():
        assert type(group) == list

    


# Generated at 2022-06-12 00:22:28.057643
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) == 2
    assert len(plugin_manager.get_converters()) == 2
    assert len(plugin_manager.get_auth_plugins()) == 4
    assert len(plugin_manager.get_transport_plugins()) == 2

# Generated at 2022-06-12 00:22:34.821050
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Test 1
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin)
    res = pluginManager.filter(AuthPlugin)
    assert res == [AuthPlugin]

    # Test 2
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin)
    res = pluginManager.filter(AuthPlugin)
    assert res != [BasePlugin]

# Generated at 2022-06-12 00:22:37.758529
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:22:41.111015
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(HtmlFormatter, JsonIceFormatter)
    assert plugin_manager.get_formatters_grouped() == {'Group1': [HtmlFormatter], 'Group2': [JsonIceFormatter]}

# Generated at 2022-06-12 00:22:57.971068
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class PluginA(FormatterPlugin):
        group_name = 'A'
    class PluginA1(FormatterPlugin):
        group_name = 'A'
    class PluginA2(FormatterPlugin):
        group_name = 'A'
    class PluginB(FormatterPlugin):
        group_name = 'B'

    plugin_manager = PluginManager()
    plugin_manager.register(PluginA, PluginA1, PluginA2, PluginB)

    assert plugin_manager.get_formatters_grouped() == {
        'A': [PluginA, PluginA1, PluginA2],
        'B': [PluginB],
    }

# Generated at 2022-06-12 00:23:03.457161
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = [
        FormatterPlugin(),
        FormatterPlugin(group_name='group1'),
        FormatterPlugin(group_name='group1'),
        FormatterPlugin(group_name='group2'),
        FormatterPlugin(),
        FormatterPlugin(group_name='group2'),
    ]
    pm = PluginManager(plugins)
    result = pm.get_formatters_grouped()
    assert result == {
        None: [plugins[0], plugins[4]],
        'group1': [plugins[1], plugins[2]],
        'group2': [plugins[3], plugins[5]],
    }

# Generated at 2022-06-12 00:23:05.814995
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-12 00:23:16.787257
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth import AuthPlugin
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.jwt import JWTAuthPlugin
    from httpie.plugins.auth.oauth1 import OAuth1Plugin
    from httpie.plugins.auth.oauth2 import OAuth2Plugin
    from httpie.plugins.auth.aws import AWSPlugin
    expected_result : Dict[str, Type[AuthPlugin]] = {'basic': BasicAuthPlugin, 'digest': DigestAuthPlugin, 'jwt': JWTAuthPlugin, 'oauth1': OAuth1Plugin, 'oauth2': OAuth2Plugin, 'aws': AWSPlugin}
    PluginManager_instance = PluginManager()

# Generated at 2022-06-12 00:23:20.635086
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.builtin import HTTPBasicAuth
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert HTTPBasicAuth in plugin_manager
    assert plugin_manager.get_auth_plugin_mapping()['basic'] == HTTPBasicAuth

# Generated at 2022-06-12 00:23:26.447039
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(TextFormatter, JsonFormatter, PythonFormatter, BashFormatter)
    ans = pm.get_formatters_grouped()
    assert ans['to_terminal'] == [TextFormatter, JsonFormatter, PythonFormatter, BashFormatter]


plugin_manager = PluginManager()

# Generated at 2022-06-12 00:23:28.138859
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert len(p) != 0

# Generated at 2022-06-12 00:23:32.880941
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    if "httpie-oauth1" in [ep.name for ep in pm.load_installed_plugins()]:
        assert pm.get_auth_plugin_mapping()['oauth1'] == \
            pm.get_auth_plugin('oauth1')


# Generated at 2022-06-12 00:23:40.088842
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class AuthPlugin1(AuthPlugin):
        auth_type = 'plugin1'

    class AuthPlugin2(AuthPlugin):
        auth_type = 'plugin2'

    plugins_manager = PluginManager()
    plugins_manager.register(AuthPlugin1,AuthPlugin2)
    assert AuthPlugin1 in plugins_manager.filter(AuthPlugin)
    assert AuthPlugin2 in plugins_manager.filter(AuthPlugin)
    assert AuthPlugin1 not in plugins_manager.filter(TransportPlugin)
    assert AuthPlugin2 not in plugins_manager.filter(TransportPlugin)

# Generated at 2022-06-12 00:23:51.742069
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = [
        FormatterPlugin(group_name='group1'),
        FormatterPlugin(group_name='group2'),
        FormatterPlugin(group_name='group3'),
        FormatterPlugin(group_name='group1'),
        FormatterPlugin(group_name='group2'),
        FormatterPlugin(group_name='group3'),
    ]
    mgr = PluginManager()
    mgr.register(*plugins)
    mgr_grouped = mgr.get_formatters_grouped()
    assert len(mgr) == len(plugins)
    expected_keys = ['group1', 'group2', 'group3']
    for key in expected_keys:
        assert key in mgr_grouped
    assert len(mgr_grouped['group1']) == 2

# Generated at 2022-06-12 00:24:15.925084
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    assert manager.get_formatters_grouped() == {}

    class A(FormatterPlugin):
        pass

    class B(FormatterPlugin):
        pass

    class C(FormatterPlugin):
        pass

    class D(FormatterPlugin):
        pass

    a, b, c, d = A(), B(), C(), D()
    a.group_name = 'a'
    b.group_name = 'b'
    c.group_name = 'a'
    d.group_name = 'a'
    manager.register(a, b, c, d)
    assert manager.get_formatters_grouped() == {
        'a': [a, c, d],
        'b': [b],
    }

# Generated at 2022-06-12 00:24:25.435360
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # 此方法可以测试插件管理器类的过滤插件方法
    plugin_manager = PluginManager()
    plugin_manager.register(auth_basic.BasicAuthPlugin,
                            auth_digest.DigestAuthPlugin,
                            auth_plugin_oauth1.OAuth1AuthPlugin,
                            auth_plugin_oauth2.OAuth2AuthPlugin,
                            stream.StreamFormatterPlugin)

    from httpie.plugins import auth
    print(plugin_manager.filter(by_type=auth.AuthPlugin))

# Generated at 2022-06-12 00:24:26.265472
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pass


# Generated at 2022-06-12 00:24:32.523443
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    a = [1, 2, 3]
    b = ["a", "b", "c"]
    c = [1, "a", 2, "b", 3, "c"]
    test_list = [a, b, c]
    test_type = list
    manager = PluginManager()
    manager.register(*test_list)
    assert manager.filter(by_type=test_type) == test_list


# Generated at 2022-06-12 00:24:40.296075
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()

    class FirstPlugin(FormatterPlugin):
        group_name = 'first'
    
    class SecondPlugin(FormatterPlugin):
        group_name = 'second'
    
    class ThirdPlugin(FormatterPlugin):
        group_name = 'first'

    pm.register(FirstPlugin, SecondPlugin, ThirdPlugin)


# Generated at 2022-06-12 00:24:44.428251
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

PLUGIN_MANAGER = PluginManager()
PLUGIN_MANAGER.load_installed_plugins()

# Generated at 2022-06-12 00:24:48.271221
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(httpie_bearer_auth.BearerAuthPlugin)
    assert manager.get_auth_plugin_mapping() == {'bearer': httpie_bearer_auth.BearerAuthPlugin}

# Generated at 2022-06-12 00:24:51.951854
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import MarkdownTableFormatter, URLEncodedFormatter

    pm = PluginManager()
    pm.register(MarkdownTableFormatter, URLEncodedFormatter)
    assert pm.get_formatters_grouped() == {
        'Group 1': [MarkdownTableFormatter],
        'Group 2': [URLEncodedFormatter],
    }

# Generated at 2022-06-12 00:24:55.288922
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    formatters = PluginManager.get_formatters_grouped(PluginManager())
    assert isinstance(formatters, dict)
    assert len(formatters)>0


# Generated at 2022-06-12 00:25:06.491351
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FoobarFormatter(FormatterPlugin):
        pass
    
    class FoobarFormatter2(FormatterPlugin):
        pass

    class FoobarFormatter3(FormatterPlugin):
        pass

    class FoobarFormatter4(FormatterPlugin):
        group_name = 'test'

    class FoobarFormatter5(FormatterPlugin):
        group_name = 'test'

    class FoobarFormatter6(FormatterPlugin):
        group_name = 'test'

    class FoobarFormatter7(FormatterPlugin):
        pass

    class FoobarFormatter8(FormatterPlugin):
        pass

    class FoobarFormatter9(FormatterPlugin):
        pass

    class FoobarFormatter10(FormatterPlugin):
        group_name = 'test'


# Generated at 2022-06-12 00:25:47.098602
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class BasePlugin(object):
        pass
    class A(BasePlugin): pass
    class B(BasePlugin): pass
    class C(B): pass
    class D(B): pass
    class E(C): pass

    plugin_manager = PluginManager()
    plugin_manager.register(A, C, E)
    assert E in plugin_manager.filter(C)
    assert C in plugin_manager.filter(B)
    assert A in plugin_manager.filter(BasePlugin)
    assert set(plugin_manager.filter(BasePlugin)) == {A, C, E}


# Generated at 2022-06-12 00:25:50.491857
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import HTTPieJSONFormatter

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPieJSONFormatter)
    result = plugin_manager.get_formatters_grouped()

    assert result == {"JSON": [HTTPieJSONFormatter]}

# Generated at 2022-06-12 00:25:59.449144
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

# Generated at 2022-06-12 00:26:11.173775
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin_1(BasePlugin):
        ...

    class Plugin_2(BasePlugin):
        ...

    class Plugin_3(FormatterPlugin):
        ...

    class Plugin_4(TransportPlugin):
        ...

    class Plugin_5(FormatterPlugin):
        ...

    class Plugin_6(ConverterPlugin):
        ...

    class Plugin_7(FormatterPlugin):
        ...

    class Plugin_8(FormatterPlugin):
        ...

    class Plugin_9(ConverterPlugin):
        ...

    pm = PluginManager()
    pm.register(Plugin_1, Plugin_2, Plugin_3, Plugin_4, Plugin_5, Plugin_6, Plugin_7, Plugin_8, Plugin_9)

    assert list(pm.filter(ConverterPlugin)) == [Plugin_6, Plugin_9]


# Generated at 2022-06-12 00:26:20.701700
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_man = PluginManager()
    plugin_man.load_installed_plugins()
    mapping = plugin_man.get_auth_plugin_mapping()
    assert mapping.__str__().__contains__('aws4')
    assert mapping.__str__().__contains__('gssnegotiate')
    assert mapping.__str__().__contains__('htpasswd')
    assert mapping.__str__().__contains__('jwt')
    assert mapping.__str__().__contains__('oauth1')
    assert mapping.__str__().__contains__('oauth2')
    assert mapping.__str__().__contains__('bearer')
    assert mapping.__str__().__contains__('crud')
    assert mapping.__str__().__contains__('hawk')
    assert mapping

# Generated at 2022-06-12 00:26:22.491944
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm.get_formatters()

# Generated at 2022-06-12 00:26:27.773958
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    #############################################
    # 1. Arrange
    pm = PluginManager()

    pm.register(FormatterPlugin)
    pm.register(FormatterPlugin)

    #############################################
    # 2. Act
    result = pm.get_formatters_grouped()
    print(f"result: {result}")

    #############################################
    # 3. Assert
    assert len(result) == 0



# Generated at 2022-06-12 00:26:34.259567
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    print(p)
    print(p.get_auth_plugin_mapping())
    print(p.get_formatters())
    print(p.get_formatters_grouped())
    print(p.get_converters())
    print(p.get_transport_plugins())


if __name__ == "__main__":
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:26:35.877422
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    assert plugins.get_auth_plugin_mapping() is not None


# Generated at 2022-06-12 00:26:40.907939
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # unit test
    plugins = PluginManager()
    plugins.load_installed_plugins() # call load_installed_plugins() of class PluginManager
    assert isinstance(plugins, list) # check whether the object is a list
    assert plugins # check whether the object is not empty


# Generated at 2022-06-12 00:27:54.227203
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(FormatterPlugin)
    assert not pm.get_formatters_grouped()



# Generated at 2022-06-12 00:27:57.959179
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugins()) >= 3
    assert len(pm.get_formatters()) >= 4
    assert len(pm.get_transport_plugins()) >= 4



# Generated at 2022-06-12 00:27:58.810650
# Unit test for method filter of class PluginManager

# Generated at 2022-06-12 00:28:00.920424
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) != 0

# Generated at 2022-06-12 00:28:07.816576
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = {
        'basic': 'basic.BasicAuthPlugin',
        'digest': 'digest.DigestAuthPlugin',
        'gssnegotiate': 'gssnegotiate.GSSNegotiateAuthPlugin',
        'hmac': 'hmac.HmacAuthPlugin',
        'ntlm': 'ntlm.NtlmAuthPlugin',
        'aws': 'aws.AWSClientAuthV1Plugin',
        'aws4': 'aws4.AWSClientAuthV4Plugin',
        'hawk': 'hawk.HawkAuthPlugin'
    }
    assert PluginManager().get_auth_plugin_mapping() == plugins


# Generated at 2022-06-12 00:28:09.974488
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert plugin_manager == []
    plugin_manager.load_installed_plugins()
    assert plugin_manager != []

# Generated at 2022-06-12 00:28:20.102569
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyJsonFormatterPlugin,FormFormatterPlugin,FormUrlencodedFormatterPlugin
    from httpie.plugins.builtin import JsonFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLEntityConverterPlugin
    from httpie.plugins.builtin import JSONConverterPlugin
    from httpie.plugins.builtin import HTMLEntityConverterPlugin
    from httpie.plugins.builtin import HTTPieHTTPAdapterPlugin
    from httpie.plugins.builtin import HTTPieTCPAdapterPlugin
    from httpie.plugins.builtin import HTTPieUDPAdapterPlugin
    from httpie.plugins.builtin import HTTPieUnixSocketAdapterPlugin

# Generated at 2022-06-12 00:28:26.597720
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin

    assert PluginManager.get_formatters_grouped([]) == {}

    class FooPlugin(FormatterPlugin):
        group_name = 'group-name'

        @staticmethod
        def add_options(parser):
            pass

        @staticmethod
        def emit_output(
                ctx,
                output_file,
                output_encoding,
                output_options,
                compressed_stream,
        ) -> None:
            pass

    plugins = [FooPlugin, FooPlugin, FooPlugin]
    expected = {'group-name': plugins}
    assert PluginManager.get_formatters_grouped(plugins) == expected

# Generated at 2022-06-12 00:28:29.873548
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    # 不存在的类型
    assert manager.filter(by_type=Type[int]) == []
    # 存在的类型
    assert manager.filter(by_type=Type[AuthPlugin]) == [AuthPlugin]



# Generated at 2022-06-12 00:28:35.801077
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(TestFormatterPlugin1)
    plugin_manager.register(TestFormatterPlugin2)
    plugin_manager.register(TestFormatterPlugin1)
    plugin_manager.register(TestFormatterPlugin3)
    plugin_manager.register(TestFormatterPlugin4)
    expected = {'group1': [TestFormatterPlugin1, TestFormatterPlugin2],\
                'group2': [TestFormatterPlugin3, TestFormatterPlugin4]}
    assert plugin_manager.get_formatters_grouped() == expected  
