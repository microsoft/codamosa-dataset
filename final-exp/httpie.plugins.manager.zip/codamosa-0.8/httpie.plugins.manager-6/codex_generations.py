

# Generated at 2022-06-12 00:19:40.065617
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    for ep in pm:
        assert ep.name in ENTRY_POINT_NAMES

# Generated at 2022-06-12 00:19:49.942617
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    PluginManager().load_installed_plugins()
    for item in PluginManager():
        if AuthPlugin in type.mro(item)[0:2]:
            assert(type(item) == item)
        elif ConverterPlugin in type.mro(item)[0:3]:
            assert(type(item) == item)
        elif FormatterPlugin in type.mro(item)[0:3]:
            assert(type(item) == item)
        elif TransportPlugin in type.mro(item)[0:2]:
            assert(type(item) == item)
        else:
            assert(BasePlugin in type.mro(item)[0:3])


# Generated at 2022-06-12 00:19:57.755115
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import FormatterPlugin, Argument

    class FormatterWithoutGroupName(FormatterPlugin):
        def format_body(self, body, mime, **kwargs): return body

    class FormatterWithGroupName(FormatterPlugin):
        group_name = 'group-name'

        def format_body(self, body, mime, **kwargs): return body

    class FormatterWithOtherGroupName(FormatterPlugin):
        group_name = 'other-group-name'

        def format_body(self, body, mime, **kwargs): return body

    pm = PluginManager()
    pm.register(FormatterWithoutGroupName, FormatterWithGroupName, FormatterWithOtherGroupName)

    formats_grouped = pm.get_formatters_grouped()
    assert 'default' in formats_grouped

# Generated at 2022-06-12 00:20:07.619029
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    class A(BasePlugin):
        pass

    class B(A):
        pass

    plugin_manager = PluginManager()

    plugin_manager.register(A)
    plugin_manager.register(B)

    assert plugin_manager.filter(A) == [A, B]
    assert plugin_manager.filter(B) == [B]

    plugin_manager.register(type('C', (BasePlugin,), {}))

    assert len(plugin_manager.filter()) == 3
    assert len(plugin_manager.filter(A)) == 2
    assert len(plugin_manager.filter(B)) == 1

# Generated at 2022-06-12 00:20:08.990060
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager.filter("auth") == ['v1', 'v2']

# Generated at 2022-06-12 00:20:11.608596
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    mgr = PluginManager()
    mgr.register(MockClass)
    assert mgr.get_formatters_grouped() == {'Mock': [MockClass]}


# Generated at 2022-06-12 00:20:15.470594
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)
test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:20:20.230575
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(formatters.JsonPlugin)
    manager.register(formatters.JsonLinesPlugin)

    assert manager.get_formatters_grouped() == {'json': [formatters.JsonPlugin, formatters.JsonLinesPlugin]}

# Generated at 2022-06-12 00:20:23.147807
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.load_installed_plugins()
    return plugin_manager

# Generated at 2022-06-12 00:20:27.550353
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(A,B,C)
    assert plugin_manager.get_formatters() == [B, C]


# Generated at 2022-06-12 00:20:32.035947
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager.get_formatters_grouped() == dict()


# Generated at 2022-06-12 00:20:42.590905
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import os
    import re
    import subprocess
    import sys
    import time

    if os.name == 'nt':
        import winreg as winreg
        import _winreg as _winreg


    """
    This unit test tests method load_installed_plugins of class PluginManager by testing
    whether the method accurately determines if a package is installed or not.

    Usage:
    python3 test_PluginManager_load_installed_plugins.py <package name>

    Example usage:
    python3 test_PluginManager_load_installed_plugins.py pandas
    """

    # Use the last argument given as the package name to run the unit test.
    try:
        package_name = sys.argv[-1]
    except:
        raise ValueError('Please enter a package name to run the unit test.')

    pm = PluginManager

# Generated at 2022-06-12 00:20:48.876094
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugin_manager = PluginManager()
            plugin_manager.register(plugin)


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-12 00:20:51.317685
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    test_obj = PluginManager()
    assert test_obj.filter() == [], "filter() did not return empty list when called with no input"

plugins = PluginManager()

# Generated at 2022-06-12 00:20:54.965761
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    from httpie.plugins.builtin import JSONFormatterPlugin, StreamFormatterPlugin, URLEncodedFormatterPlugin

    plugins = PluginManager()

    plugins.register(JSONFormatterPlugin)
    plugins.register(StreamFormatterPlugin)
    plugins.register(URLEncodedFormatterPlugin)

    print(plugins.get_formatters_grouped())


# Generated at 2022-06-12 00:20:58.181150
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0  # assert at least 1 entry_point found


# Generated at 2022-06-12 00:21:03.985786
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    class MyFormatterPlugin(FormatterPlugin):
        group_name = "MyGroup"
    class MyOtherFormatterPlugin(FormatterPlugin):
        group_name = "MyOtherGroup"

    plugin_manager.register(
        MyFormatterPlugin,
        MyFormatterPlugin,
        MyOtherFormatterPlugin,
        MyFormatterPlugin
    )
    formatters = plugin_manager.get_formatters_grouped()
    assert formatters["MyGroup"] == [MyFormatterPlugin, MyFormatterPlugin, MyFormatterPlugin]
    assert formatters["MyOtherGroup"] == [MyOtherFormatterPlugin]

# Generated at 2022-06-12 00:21:08.769877
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManagerInstance = PluginManager()
    PluginManagerInstance.register(DummyAuthPlugin1)
    PluginManagerInstance.register(DummyAuthPlugin2)
    PluginManagerInstance.register(DummyAuthPlugin3)
    PluginManagerInstance.register(DummyConverterPlugin1)
    assert len(PluginManagerInstance.filter(AuthPlugin)) == 3
    assert len(PluginManagerInstance.filter(ConverterPlugin)) == 1

# Generated at 2022-06-12 00:21:18.045078
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    get_formatters_grouped = plugins.get_formatters_grouped
    fmt1 = FormatterPlugin(
        __package__="my_package1",
        __name__="my_module1.my_class1",
        name='my_plugin1',
        group_name='my_group1',
        __file__="/Users/alex/ws-code/httpie-0.9.9.dev0/httpie/plugins/formatter/pretty.py")

# Generated at 2022-06-12 00:21:22.139111
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins= PluginManager()
    plugins.register(FormatterPlugin)
    plugins.register(FormatterPlugin)
    d = plugins.get_formatters_grouped()
    assert list(d.keys()) == ['default']
    assert type(d['default'][0]) == FormatterPlugin


# Generated at 2022-06-12 00:21:30.582678
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    assert (
        plugin_manager.get_formatters_grouped()
        == {'default': [FormatterPlugin]}
    )
    plugin_manager.register(FormatterPlugin)
    assert (
        plugin_manager.get_formatters_grouped()
        == {'default': [FormatterPlugin, FormatterPlugin]}
    )

# Generated at 2022-06-12 00:21:32.203774
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter(by_type=Type[BasePlugin]) == []


# Generated at 2022-06-12 00:21:38.073219
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # create instance of class PluginManager
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # Verify 3 auth plugins returned
    assert len(plugin_manager.get_auth_plugins()) == 3
    # Verify 6 formatters returned
    assert len(plugin_manager.get_formatters()) == 6
    # Verify 3 converters returned
    assert len(plugin_manager.get_converters()) == 3
    # Verify 2 transport plugins returned
    assert len(plugin_manager.get_transport_plugins()) == 2
    print('Test Passed!')

#Unit test for method get_auth_plugin of class PluginManager

# Generated at 2022-06-12 00:21:42.681007
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    tested_object = PluginManager()
    tested_object.load_installed_plugins()
    result = tested_object.filter(AuthPlugin)
    assert(len(result) == 0)
    result = tested_object.filter(FormatterPlugin)
    assert(len(result) == 3)
    result = tested_object.filter(TransportPlugin)
    assert(len(result) == 2)


# Generated at 2022-06-12 00:21:44.826398
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager, PluginManager)
    assert plugin_manager.get_formatters_grouped() == {}

# Generated at 2022-06-12 00:21:48.383630
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    pluginManager.register(FormatterPlugin)
    assert pluginManager.get_formatters_grouped() == {}



# Generated at 2022-06-12 00:21:57.807912
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_manager=PluginManager()
    m1=MagicMock()
    m1.group_name='test_group1'
    m2=MagicMock()
    m2.group_name='test_group2'
    m3=MagicMock()
    m3.group_name='test_group1'
    plugins_manager.register(m1,m2,m3)
    assert plugins_manager.get_formatters_grouped()=={'test_group1':[m1,m3],'test_group2':[m2]}
    plugins_manager.register(m1)
    assert plugins_manager.get_formatters_grouped()=={'test_group1':[m1,m3,m1],'test_group2':[m2]}, 'Testing adding same plugin'

# Unit

# Generated at 2022-06-12 00:22:04.031233
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(object):
        pass
    class Plugin4(object):
        pass

    plugin_manager = PluginManager()
    plugins = [Plugin1, Plugin2, Plugin3, Plugin4]
    plugin_manager.register(*plugins)

    filtered_plugins = plugin_manager.filter(BasePlugin)
    assert filtered_plugins == [Plugin1, Plugin2]

# Generated at 2022-06-12 00:22:10.021611
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    l = PluginManager()
    l.load_installed_plugins()
    auth_plugins = l.get_auth_plugins()
    assert (auth_plugins)
    formatter = l.get_formatters()
    assert (formatter)
    converter = l.get_converters()
    assert (converter)
    transport = l.get_transport_plugins()
    assert (transport)


# Generated at 2022-06-12 00:22:19.787169
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

    class _FakeFormatterPlugin1(FormatterPlugin):
        group_name = 'group_name_1'
    class _FakeFormatterPlugin11(FormatterPlugin):
        group_name = 'group_name_1'
    class _FakeFormatterPlugin2(FormatterPlugin):
        group_name = 'group_name_2'

    plugin_manager.register(_FakeFormatterPlugin1)
    plugin_manager.register(_FakeFormatterPlugin11)
    plugin_manager.register(_FakeFormatterPlugin2)

    assert set(plugin_manager.get_formatters_grouped().keys()) == {'group_name_1', 'group_name_2'}

# Generated at 2022-06-12 00:22:28.733779
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth import JWTAuthPlugin
    pm = PluginManager()
    JWTAuthPlugin.auth_type = 'jwt'
    pm.append(JWTAuthPlugin)
    assert pm.get_auth_plugin_mapping()['jwt'] ==  JWTAuthPlugin

# Generated at 2022-06-12 00:22:35.059464
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    cls = type('TestFormatter', (FormatterPlugin,), {
        'group_name': 'foo'
    })
    manager.register(cls)
    assert {
        'foo': [cls]
    } == manager.get_formatters_grouped()

# Generated at 2022-06-12 00:22:37.608569
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {'JSON': [], 'HTML': []}

# Generated at 2022-06-12 00:22:39.658665
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) == 14
    # print(manager)

# Generated at 2022-06-12 00:22:41.812658
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugins_loaded = len(plugin_manager)
    assert plugins_loaded > 0


# Generated at 2022-06-12 00:22:42.858560
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert 1==1


# Generated at 2022-06-12 00:22:45.091469
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    assert plugins is not None
    assert len(plugins) > 0


# Generated at 2022-06-12 00:22:55.709280
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import os
    import sys
    import unittest
    from httpie.plugins import FormatterPlugin

    class TestClass(unittest.TestCase):

        def setUp(self):
            self.plugin_manager = PluginManager()
    
        def test_PluginManager_get_formatters_grouped(self):
            #Register sample plugins
            class PluginA(FormatterPlugin):
                group_name = 'mygroup'

            class PluginB(FormatterPlugin):
                group_name = 'mygroup'

            class PluginC(FormatterPlugin):
                group_name = 'yourgroup'

            self.plugin_manager.register(PluginA, PluginB, PluginC)

            #Run the test

# Generated at 2022-06-12 00:23:02.292329
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginBase:
        pass

    class PluginOne(PluginBase):
        pass

    class PluginTwo(PluginBase):
        pass

    class PluginThree(PluginOne, PluginTwo):
        pass

    manager = PluginManager()
    manager.register(PluginOne, PluginThree, PluginTwo)

    assert manager.filter(PluginBase) == [PluginOne, PluginThree, PluginTwo]
    assert manager.filter(PluginOne) == [PluginOne, PluginThree]
    assert manager.filter(PluginTwo) == [PluginThree, PluginTwo]



# Generated at 2022-06-12 00:23:10.372952
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth, HTTPPasswordAuth
    from httpie.plugins.builtin import JSONFormatter, JSONLinesFormatter

    plugin_manager = PluginManager()

    plugin_manager.register(JSONFormatter, JSONLinesFormatter,
                            HTTPBasicAuth, HTTPDigestAuth, HTTPPasswordAuth)

    assert plugin_manager.__repr__() == '<PluginManager: [JSONFormatter, JSONLinesFormatter, HTTPBasicAuth, HTTPDigestAuth, HTTPPasswordAuth]>'

    assert plugin_manager.filter(FormatterPlugin) == [JSONFormatter, JSONLinesFormatter]
    assert plugin_manager.filter(AuthPlugin) == [HTTPBasicAuth, HTTPDigestAuth, HTTPPasswordAuth]

# Generated at 2022-06-12 00:23:17.045150
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    assert plugins.get_auth_plugin_mapping()



# Generated at 2022-06-12 00:23:21.310374
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(MockFormatterPlugin, MockFormatterPlugin2)
    assert pm.get_formatters_grouped() == {
        'Group Name': [MockFormatterPlugin],
        'Group Name2': [MockFormatterPlugin2]
    }



# Generated at 2022-06-12 00:23:27.470307
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    assert len(pm) > 5
    assert len(pm.get_auth_plugins()) > 2
    assert len(pm.get_formatters()) > 2
    assert len(pm.get_converters()) > 2
    assert len(pm.get_transport_plugins()) > 1


# Generated at 2022-06-12 00:23:33.611572
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    assert manager.get_formatters_grouped() == {}
    manager.register(PlainFormatter)
    manager.register(ColoredFormatter)
    manager.register(CircledFormatter)

    all_formatters = manager.get_formatters_grouped()
    all_formatter_names = [f.name for f in all_formatters['all']]
    assert 'plain' in all_formatter_names
    assert 'colored' in all_formatter_names
    assert 'circled' in all_formatter_names

    default_formatters = manager.get_formatters_grouped()
    default_formatter_names = [f.name for f in default_formatters['default']]
    assert 'json' in default_formatter_names

# Generated at 2022-06-12 00:23:36.358330
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    assert manager.get_formatters_grouped() == {}

manager = PluginManager()

# Generated at 2022-06-12 00:23:40.302670
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(1)
    plugins.register("string")
    plugins.register(["a", "list"])
    assert plugins.filter("string") == ["string"]
    assert plugins.filter(int) == [1]
    assert plugins.filter(("a", "list")) == [["a", "list"]]

# Generated at 2022-06-12 00:23:51.943464
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager: PluginManager = PluginManager()
    auth_plugins: List[Type[AuthPlugin]] = plugin_manager.get_auth_plugins()
    assert isinstance(auth_plugins, list)
    assert all(isinstance(plugin, AuthPlugin) for plugin in auth_plugins)
    auth_plugins_mapping: Dict[str, Type[AuthPlugin]] = plugin_manager.get_auth_plugin_mapping()
    assert isinstance(auth_plugins_mapping, dict)
    assert all(isinstance(plugin, AuthPlugin) for plugin in auth_plugins_mapping.values())
    auth_plugins_mapping_keys: List[str] = list(auth_plugins_mapping.keys())
    assert 'basic' in auth_plugins_mapping_keys
    assert 'digest' in auth_plugins_mapping_keys


# Generated at 2022-06-12 00:24:03.054614
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    '''
    Test output of method get_formatters_grouped
    :return:
    '''
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugins_grouped = plugin_manager.get_formatters_grouped()

# Generated at 2022-06-12 00:24:06.019162
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    formatters = PluginManager()
    formatters.register(FormatterPlugin)
    formatters.register(FormatterPlugin)
    assert formatters.get_formatters_grouped() == {'default': [FormatterPlugin, FormatterPlugin]}

# Generated at 2022-06-12 00:24:13.422926
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # 创建实例
    manager = PluginManager()
    # 测试是否为空
    assert not manager
    # 加载插件
    manager.load_installed_plugins()
    # 不为空
    assert manager
    # 查看单个插件类型
    assert isinstance(manager[0], BasePlugin)

test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:24:25.283906
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # no error is fine


# Generated at 2022-06-12 00:24:36.535695
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-12 00:24:39.795836
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    #check 'group_name' attribute is retrieved
    ActualOutput = PluginManager().get_formatters_grouped()

    assert ActualOutput['group_name'] == 'group_name'

# Generated at 2022-06-12 00:24:48.147973
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass

    class PluginB(BasePlugin):
        pass

    class PluginC(PluginA):
        pass

    pm = PluginManager()
    pm.register(PluginA, PluginB, PluginC)

    assert list(pm.filter()) == [PluginA, PluginB, PluginC]

    assert list(pm.filter(PluginA)) == [PluginA, PluginC]
    assert list(pm.filter(PluginB)) == [PluginB]
    assert list(pm.filter(PluginC)) == [PluginC]


# Generated at 2022-06-12 00:24:53.263876
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(type('a', (BasePlugin,), {}))
    manager.register(type('b', (AuthPlugin,), {}))
    manager.register(type('c', (TransportPlugin,), {}))
    manager.register(type('d', (ConverterPlugin,), {}))
    manager.register(type('e', (FormatterPlugin,), {}))
    assert isinstance(manager.filter(AuthPlugin), list)
    assert isinstance(manager.filter(TransportPlugin), list)
    assert isinstance(manager.filter(ConverterPlugin), list)
    assert isinstance(manager.filter(FormatterPlugin), list)
    assert isinstance(manager.filter(BasePlugin), list)

# Generated at 2022-06-12 00:24:56.073078
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-12 00:25:07.504399
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    from httpie.compat import is_windows
    from os import environ

    if is_windows:
        environ["HTTPIE_PLUGINS_DIR"] = 'E:\\Program Files\\httpie\\plugins\\pip-installed\\'
    else:
        environ["HTTPIE_PLUGINS_DIR"] = '/Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages/httpie/plugins/pip-installed/'

    pm = PluginManager()
    pm.load_installed_plugins()
    #print(pm)


# Generated at 2022-06-12 00:25:13.854233
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    from httpie.plugins import AuthPlugin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.plugins import TransportPlugin

    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_auth_plugins()) != 0
    assert len(pm.get_formatters()) != 0
    assert len(pm.get_converters()) != 0
    assert len(pm.get_transport_plugins()) != 0

# Generated at 2022-06-12 00:25:19.159748
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """
    Test for method of class PluginManager
    """
    p_mgr = PluginManager()
    p_mgr.load_installed_plugins()
    formatters_grouped = p_mgr.get_formatters_grouped()
    assert formatters_grouped
    assert formatters_grouped['Pretty']
    assert formatters_grouped['Syntax']

# End test for method get_formatters_grouped of class PluginManager


plugins = PluginManager()

# Generated at 2022-06-12 00:25:28.980086
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(
        Renderer,
        PrettyRenderer,
        PrettyJsonRenderer,
        PandasStyledRenderer,
        PandasBasicRenderer,
        TableRenderer,
        JsonRenderer,
        JsonLinesRenderer,
        CSVRenderer,
        TagsRenderer,
        URLEncodedRenderer,
        FormRenderer,
        RawRenderer,
        ImageRenderer,
        StreamRenderer,
        NullRenderer,
    )

    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert len(formatters_grouped) == 9

    assert PrettyRenderer in formatters_grouped['Tablular']
    assert TableR

# Generated at 2022-06-12 00:25:52.970566
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm.get_formatters_grouped())

if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:25:59.824933
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class BasePluginA(BasePlugin):
        pass

    class BasePluginB(BasePlugin):
        pass

    class PluginA(BasePluginA):
        pass

    class PluginB(BasePluginB):
        pass

    manager = PluginManager()
    manager.register(BasePluginA)
    manager.register(BasePluginB)
    manager.register(PluginA)
    manager.register(PluginB)
    assert len(manager) == 4
    assert len(manager.filter(BasePlugin)) == 4
    assert len(manager.filter(BasePluginA)) == 2
    assert len(manager.filter(BasePluginB)) == 2

# Generated at 2022-06-12 00:26:05.857282
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    p = PluginManager()
    p.load_installed_plugins()
    # Assert auth_type of plugin basic of class httpie.plugins.basic_auth.BasicAuthPlugin into dict
    assert p.get_auth_plugin_mapping()['basic'] == httpie.plugins.basic_auth.BasicAuthPlugin


# Generated at 2022-06-12 00:26:11.555227
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import builtin

    p = PluginManager()
    p.register(*builtin.__all__)
    formatters = p.get_formatters_grouped()

    print(formatters)

    assert len(formatters) == 4
    assert 'Group1' in formatters.keys()
    assert len(formatters['Group1']) == 3
    assert 'Group2' in formatters.keys()
    assert len(formatters['Group2']) == 0

# Generated at 2022-06-12 00:26:19.845490
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A(BasePlugin):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(A)
    plugin_manager.register(B)
    plugin_manager.register(C)
    plugin_manager.register(D)
    assert plugin_manager.filter(A) == [A, B, C, D]
    assert plugin_manager.filter(B) == [B, C, D]
    assert plugin_manager.filter(C) == [C]
    assert plugin_manager.filter(D) == [D]

# Generated at 2022-06-12 00:26:23.333955
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager_1 = PluginManager()
    PluginManager_1.load_installed_plugins()
    formatter_grouped = PluginManager_1.get_formatters_grouped()
    
    assert formatter_grouped is not None
    assert "formatters" in formatter_grouped

# Generated at 2022-06-12 00:26:29.624425
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    class X:
        pass
    class A:
        pass
    class AA(A):
        pass
    class B:
        pass
    class C:
        pass
    class Y(C):
        pass

    manager.register(X, A, AA, B, C, Y)
    assert manager.filter() == [X, A, AA, B, C, Y]
    assert manager.filter(A) == [A, AA]
    assert manager.filter(B) == [B]
    assert manager.filter(X) == [X]
    assert manager.filter(C) == [C, Y]


# Generated at 2022-06-12 00:26:31.855673
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm

# Generated at 2022-06-12 00:26:38.405680
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C:
        pass
    class D(C):
        pass
    class E(B, D):
        pass
    pm = PluginManager()
    pm.register(A, B, C, D, E)
    assert len(pm.filter(A))==2
    assert len(pm.filter(B))==1
    assert len(pm.filter(C))==2
    assert len(pm.filter(D))==1
    assert len(pm.filter(E))==1
    assert len(pm.filter(A))==2
    assert len(pm.filter(D))==1
    # 
    assert pm.filter(A) == [A, E]
    assert pm.filter(B) == [B]
    assert pm.filter

# Generated at 2022-06-12 00:26:41.146471
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) != 0

# Generated at 2022-06-12 00:27:32.916254
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Formatter1(FormatterPlugin):
        group_name = 'group_1'

    class Formatter2(FormatterPlugin):
        group_name = 'group_1'

    class Formatter3(FormatterPlugin):
        group_name = 'group_2'
    
    class Formatter4(FormatterPlugin):
        group_name = 'group_2'

    plugin_manager = PluginManager()
    plugin_manager.register(Formatter1, Formatter2, Formatter3, Formatter4)
    
    assert plugin_manager.get_formatters_grouped() == {'group_1': [Formatter1, Formatter2], 'group_2': [Formatter3, Formatter4]}


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-12 00:27:36.639053
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) >= 4
    assert any(plugin.auth_type == 'basic' for plugin in plugin_manager)



# Generated at 2022-06-12 00:27:38.902133
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert(len(plugin_manager.get_auth_plugin_mapping()) == 0)


PLUGIN_MANAGER = PluginManager()
PLUGIN_MANAGER.load_installed_plugins()

# Generated at 2022-06-12 00:27:42.912508
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert True


# Generated at 2022-06-12 00:27:51.094110
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    #for plugin in manager.get_transport_plugins():
    #    print(plugin)
    #for plugin in manager.get_formatters():
    #    print(plugin)
    #for plugin in manager.get_auth_plugins():
    #    print(plugin)

    assert len(manager.get_transport_plugins()) == 2
    assert len(manager.get_formatters()) == 4
    assert len(manager.get_auth_plugins()) == 2
    assert len(manager.get_converters()) == 2

    #for formatter in manager.get_formatters_grouped():
        #print(formatter)
        #for plugin in formatter:
        #    print(' ', plugin)
        #print()

# Generated at 2022-06-12 00:28:00.498601
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_plugin1 = type(
        'AuthPluginTest1',
        (),
        {
            'auth_type': 'test1',
            'auth_plugin_name': 'Test Plugin 1',
            'package_name': None,
        }
    )
    test_plugin2 = type(
        'AuthPluginTest2',
        (),
        {
            'auth_type': 'test2',
            'auth_plugin_name': 'Test Plugin 2',
            'package_name': None,
        }
    )
    assert PluginManager([test_plugin1, test_plugin2]).get_auth_plugin_mapping() == {
        'test1': test_plugin1,
        'test2': test_plugin2,
    }

# Generated at 2022-06-12 00:28:02.613442
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    formatters = plugin_manager.get_formatters_grouped()
    print(formatters)

# Unit test

# Generated at 2022-06-12 00:28:09.124058
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

# Generated at 2022-06-12 00:28:18.154773
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    class PluginA(AuthPlugin):
        auth_type = 'abc'

    class PluginB(AuthPlugin):
        auth_type = 'xyz'

    class PluginC(AuthPlugin):
        auth_type = 'xyz'

    plugin_manager = PluginManager()

    plugin_manager.register(PluginA, PluginB)
    assert plugin_manager.get_auth_plugin_mapping() == {'abc': PluginA, 'xyz': PluginB}

    plugin_manager.unregister(PluginB)
    assert plugin_manager.get_auth_plugin_mapping() == {'abc': PluginA}

    plugin_manager.register(PluginB)
    assert plugin_manager.get_auth_plugin_mapping() == {'abc': PluginA, 'xyz': PluginB}

    plugin_manager.register(PluginC)


# Generated at 2022-06-12 00:28:21.094439
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 43
