

# Generated at 2022-06-12 00:19:37.711665
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Arrange
    plugin_manager = PluginManager()
    plugin_manager.register()



# Generated at 2022-06-12 00:19:42.484112
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert len(pm.get_auth_plugin_mapping()) is 0
    pm.register(AuthPlugin)
    assert len(pm.get_auth_plugin_mapping()) is 1
    assert "httpie.plugins.auth.AuthPlugin" in pm.get_auth_plugin_mapping()



# Generated at 2022-06-12 00:19:51.094791
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie import __version__
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.compat import is_venv

    # Skip the unit test if not running within a virtualenv,
    # as this test would needlessly require a virtualenv on users machines.
    if not is_venv():
        return

    # GIVEN a manager
    manager = PluginManager()

    # WHEN installing the built-in plugins
    manager.load_installed_plugins()

    # THEN the installed plugins should be registered
    assert len(manager) > 0
    assert HTMLFormatter in manager

    # BUT packages installed outside of this virtualenv should not be registered
    for plugin in manager:
        assert plugin.package_name != __name__

# Generated at 2022-06-12 00:19:53.918960
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    assert pm == []
    pm.load_installed_plugins()
    assert pm.get_auth_plugin_mapping()


# Generated at 2022-06-12 00:19:55.407166
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert isinstance(pm, list)


# Generated at 2022-06-12 00:20:02.663997
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.unicode import UnicodeOutputPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    manager = PluginManager()
    manager.register(UnicodeOutputPlugin, HTTPBasicAuth)
    result = manager.filter(BasePlugin)
    expected = [UnicodeOutputPlugin, HTTPBasicAuth]
    assert result == expected

# Generated at 2022-06-12 00:20:05.059393
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 5

# Generated at 2022-06-12 00:20:10.401287
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class AFormatter(FormatterPlugin):
        group_name = 'A'

    class BFormatter(FormatterPlugin):
        group_name = 'B'

    class BFormatter2(FormatterPlugin):
        group_name = 'B'

    manager = PluginManager()
    manager.register(AFormatter, BFormatter, BFormatter2)

    assert manager.get_formatters_grouped() == {'A': [AFormatter], 'B': [BFormatter, BFormatter2]}

# Generated at 2022-06-12 00:20:16.741449
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    installed_plugins_count = len(plugin_manager)
    assert installed_plugins_count > 0

    # Repeat the same test, it should not change the number of installed plugins
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == installed_plugins_count

# Generated at 2022-06-12 00:20:24.169377
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A(BasePlugin):
        pass

    class B(A):
        pass

    class C(A):
        pass

    pm = PluginManager()
    pm.register(A, B, C)
    assert set(pm.filter()) == set([A, B, C])
    assert set(pm.filter(A)) == set([A, B, C])
    assert set(pm.filter(B)) == set([B])
    assert set(pm.filter(C)) == set([C])



# Generated at 2022-06-12 00:20:32.584182
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """
    Check the output of the method get_formatters_grouped
    """
    from httpie.plugins import FormatterPlugin
    from plugins.custom_formatter import CustomFormatterPlugin
    from plugins.custom_formatter_2 import CustomFormatterPlugin2
    from plugins.custom_formatter_3 import CustomFormatterPlugin3

    pluginManager = PluginManager()
    pluginManager.register(CustomFormatterPlugin, CustomFormatterPlugin2, CustomFormatterPlugin3)
    assert len(pluginManager.get_formatters_grouped()) == 3
    assert len(pluginManager.get_formatters_grouped()) == len(pluginManager.filter(FormatterPlugin))

# Generated at 2022-06-12 00:20:42.854471
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()

    import httpie.plugins as httpie_plugins
    plugins = [
        httpie_plugins.auth.BasicAuthPlugin,
        httpie_plugins.auth.DigestAuthPlugin,
        httpie_plugins.converter.JSONItemsConverterPlugin,
        httpie_plugins.converter.JSONLinesConverterPlugin,
        httpie_plugins.converter.MessagePackConverterPlugin,
        httpie_plugins.converter.PrettyFormatConverterPlugin
    ]

    plugin_manager.register(*plugins)

    assert plugin_manager.filter(AuthPlugin) == [
        httpie_plugins.auth.BasicAuthPlugin,
        httpie_plugins.auth.DigestAuthPlugin,
    ]


# Generated at 2022-06-12 00:20:46.062971
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    for plugin in plugin_manager:
        assert issubclass(plugin, BasePlugin)

# Generated at 2022-06-12 00:20:49.995024
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.base import BasePlugin

    print(isinstance(FormatterPlugin, BasePlugin))


if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:20:52.280503
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert len(p) > 0
    assert issubclass(p[0], BasePlugin)

# Generated at 2022-06-12 00:20:56.624848
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    This test is integration tested, cannot be unit tested.

    The reason is that it is too cumbersome to add all entry points in unittest
    and at the same time install all packages in the temp directory.
    """
    pass



# Generated at 2022-06-12 00:20:57.550859
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert not PluginManager().load_installed_plugins()

# Generated at 2022-06-12 00:21:00.190220
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert(plugin_manager.get_auth_plugin_mapping())


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-12 00:21:01.684089
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    assert len(pm.get_formatters_grouped()) > 0


# Generated at 2022-06-12 00:21:10.577577
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    from httpie.cli import http
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.formatter.v1 import FormatterPlugin

    class FormatterPlugin1(FormatterPlugin):
        group_name = 'Group1'
        format_name = 'format1'

    class FormatterPlugin2(FormatterPlugin):
        group_name = 'Group2'
        format_name = 'format2'

    class FormatterPlugin3(FormatterPlugin):
        group_name = 'Group1'
        format_name = 'format3'

    http.PluginManager.register(FormatterPlugin1, FormatterPlugin2, FormatterPlugin3, HTTPiePlugin)
    formatter_grouped = http.PluginManager.get_formatters_grouped()
    print

# Generated at 2022-06-12 00:21:14.771004
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    p = BasePlugin()
    plugins.register(p)
    assert plugins.filter(None) == [p]



# Generated at 2022-06-12 00:21:23.815435
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    print("Testing get_formatters_grouped")
    plugin_path = os.path.join(os.path.dirname(__file__), "test")
    pm = PluginManager()
    pm.load_installed_plugins()
    pm.register(plugin_info(plugin_path, "FormatterPlugin")[0])
    assert pm.get_formatters_grouped() == {
        'group1': [
            plugin_info(plugin_path, "FormatterPlugin")[0],
        ],
        'group2': [
            plugin_info(plugin_path, "FormatterPlugin")[1],
        ],
    }

if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:21:34.119369
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    l_fmt_plugins = [
        type('Plugin1', (FormatterPlugin,), {'group_name': 'group1'})(),
        type('Plugin2', (FormatterPlugin,), {'group_name': 'group2'})(),
        type('Plugin3', (FormatterPlugin,), {'group_name': 'group1'})(),
    ]
    plugin_manager = PluginManager()
    plugin_manager.register(*l_fmt_plugins)
    l_formatter_grouped = plugin_manager.get_formatters_grouped()
    assert len(l_formatter_grouped.keys()) == 2
    for group in l_formatter_grouped.values():
        assert len(group) == 2

# Generated at 2022-06-12 00:21:37.973516
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter(AuthPlugin) == []

    manager = PluginManager()
    manager.register(AuthPlugin, FormatterPlugin)
    assert manager.filter(AuthPlugin) == [AuthPlugin]



# Generated at 2022-06-12 00:21:47.917658
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Create a new instance of PluginManager
    PluginManager_object = PluginManager()
    # Create a mock BasePlugin
    class MockBasePlugin:
        def __init__(self):
            pass
    # Create a mock subclass of BasePlugin
    class MockSubclass1(MockBasePlugin):
        def __init__(self):
            pass
    # Create a mock subclass of BasePlugin
    class MockSubclass2(MockBasePlugin):
        def __init__(self):
            pass
    # Create a mock class that has no relation with BasePlugin
    class MockClass:
        def __init__(self):
            pass
    # Create a mock type that is not a class
    mock_type = type(None)
    # Register some plugins

# Generated at 2022-06-12 00:21:55.829048
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class HtmlPlugin1(FormatterPlugin):
        group_name = 'html'
        pass

    class HtmlPlugin2(FormatterPlugin):
        group_name = 'html'
        pass

    class TextPlugin(FormatterPlugin):
        group_name = 'text'
        pass

    plugins = PluginManager()
    plugins.register(HtmlPlugin1, HtmlPlugin2, TextPlugin)
    assert plugins.get_formatters_grouped() == {
        'html': [HtmlPlugin1, HtmlPlugin2],
        'text': [TextPlugin]
    }

# Generated at 2022-06-12 00:21:57.231847
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter() == list()
    


# Generated at 2022-06-12 00:22:00.187591
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # Test plugins exist in entry_point
    assert bool(hasattr(plugin_manager, "get_auth_plugins"))



# Generated at 2022-06-12 00:22:11.207633
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, PrettyOptionsPlugin

    class TestFormatterPlugin(FormatterPlugin):
        pass

    class TestPrettyOptionsPlugin(PrettyOptionsPlugin):
        pass

    class TestJSONFormatterPlugin(JSONFormatterPlugin):
        pass

    plugin_manager = PluginManager()

    plugin_manager.register(*[JSONFormatterPlugin, PrettyOptionsPlugin, TestFormatterPlugin, TestPrettyOptionsPlugin, TestJSONFormatterPlugin])
    assert len(plugin_manager.get_formatters()) == 5

    plugin_manager.get_formatters_grouped() == {
        'Pretty': [TestPrettyOptionsPlugin, PrettyOptionsPlugin],
        'JSON': [JSONFormatterPlugin, TestJSONFormatterPlugin],
        'Test': [TestPrettyOptionsPlugin, TestFormatterPlugin, TestJSONFormatterPlugin],
    }



# Generated at 2022-06-12 00:22:20.883049
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    type_A = type('TypeA', (object,), {})
    type_B = type('TypeB', (type_A,), {})
    type_C = type('TypeC', (type_A,), {})
    type_D = type('TypeD', (type_B, type_C), {})

    plugin_manager = PluginManager()

    plugin_manager.register(type_A)
    plugin_manager.register(type_B)
    plugin_manager.register(type_C)
    plugin_manager.register(type_D)

    assert plugin_manager.filter(type_A) == [type_A, type_B, type_C, type_D]
    assert plugin_manager.filter(type_B) == [type_B, type_D]

# Generated at 2022-06-12 00:22:29.820357
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Auth1(AuthPlugin):
        auth_type = 'auth1'
    class Auth2(AuthPlugin):
        auth_type = 'auth2'
    pm = PluginManager([Plugin1, Plugin2, Auth1, Auth2])
    assert pm.get_auth_plugin_mapping() == {'auth1': Auth1, 'auth2': Auth2}

# Generated at 2022-06-12 00:22:41.229920
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin
    from httpie.input import AuthCredentials
    class MockAuthPlugin(AuthPlugin):
        auth_type = 'mock_auth_type'
        auth_require = True
        def get_auth(self, username, password):
            return 'MOCK_AUTH'
    manager = PluginManager()
    manager.register(MockAuthPlugin)
    auth_plugin_mapping = manager.get_auth_plugin_mapping()
    credentials = auth_plugin_mapping['mock_auth_type'].get_auth('user','pass')
    assert(credentials == 'MOCK_AUTH')



# Generated at 2022-06-12 00:22:49.635333
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    #TODO: Make this test more automated
    plugins.load_installed_plugins()
    assert(any(isinstance(p, AuthPlugin) for p in plugins))
    assert(any(isinstance(p, FormatterPlugin) for p in plugins))
    assert(any(isinstance(p, ConverterPlugin) for p in plugins))
    assert(any(isinstance(p, TransportPlugin) for p in plugins))
    # assert(any(p.__class__.__name__ == 'DCPCookieAuth' for p in plugins))

# Generated at 2022-06-12 00:22:51.448311
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 10

# Generated at 2022-06-12 00:22:52.198737
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()

# Generated at 2022-06-12 00:22:55.574243
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.formatter.pretty import PrettyFormatter
    from httpie.plugins.formatter.colors import Formatter

    plugins = PluginManager()
    plugins.register(PrettyFormatter, Formatter)

    assert plugins.get_formatters_grouped() == {
        'pretty': [PrettyFormatter],
        'colors': [Formatter],
    }

# Generated at 2022-06-12 00:23:00.916316
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(
        JsonPlugin,
        JsonLinesPlugin,
        HtmlPlugin,
        OrgModePlugin,
        PrettyPlugin,
        PrintMinPPlugin,
        UrlencodedPlugin
    )
    print(manager.get_formatters_grouped())

test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:23:04.540855
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert len(plugin_manager.get_auth_plugin_mapping()) is 0


# Generated at 2022-06-12 00:23:07.514106
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginManager = PluginManager()
    if pluginManager.get_auth_plugin_mapping() == None:
        assert True
    else:
        assert False


# Generated at 2022-06-12 00:23:17.773356
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import sys
    import os
    import pkg_resources
    sys.path.append('./httpie_test_packages/entrypoints')
    reload(pkg_resources)
    PluginManager = type('PluginManager', (), {})()

    PluginManager.load_installed_plugins()
    print([(plugin.auth_type, plugin.package_name) for plugin in PluginManager.get_auth_plugins()])
    print([plugin.package_name for plugin in PluginManager.get_transport_plugins()])
    print([plugin.package_name for plugin in PluginManager.get_transport_plugins()])
    print([plugin.package_name for plugin in PluginManager.get_formatters()])
    print([(plugin.mimetype, plugin.package_name) for plugin in PluginManager.get_converters()])

# test

# Generated at 2022-06-12 00:23:25.879835
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pass

# Generated at 2022-06-12 00:23:33.029485
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # arrange
    from httpie.plugins import FormatterPlugin
    from httpie.output import BasicFormattersGroup
    from httpie.plugins.json import JsonFormatterPlugin

    json_plugin = JsonFormatterPlugin()

    class FormatterMock(FormatterPlugin):
        format_name = "mock"
        format_name_aliases = ["mock"]
        group_name = "mock_group"
        group_classes = [BasicFormattersGroup]

    formatter1 = FormatterMock()
    formatter2 = FormatterMock()
    formatter3 = JsonFormatterPlugin()

    plugin_manager = PluginManager()
    plugin_manager.register(formatter1, formatter2, formatter3)

    # act
    result = plugin_manager.get_formatters_grouped()
    # assert

# Generated at 2022-06-12 00:23:41.036102
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}

    assert PluginManager(AuthPlugin).get_auth_plugin_mapping() == {
        AuthPlugin.auth_type: AuthPlugin
    }

    class AuthPlugin1(AuthPlugin):
        auth_type = 'foo'
    class AuthPlugin2(AuthPlugin):
        auth_type = 'bar'
    assert PluginManager(AuthPlugin, AuthPlugin1, AuthPlugin2).get_auth_plugin_mapping() == {
        AuthPlugin.auth_type: AuthPlugin,
        AuthPlugin1.auth_type: AuthPlugin1,
        AuthPlugin2.auth_type: AuthPlugin2,
    }

# Generated at 2022-06-12 00:23:52.142803
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie import plugins
    from pkg_resources import iter_entry_points

    manager = plugins.manager
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            manager.register(entry_point.load())
    assert len(manager.filter(Type[BasePlugin])) == len(ENTRY_POINT_NAMES)
    assert len(manager.filter(Type[AuthPlugin])) == len(manager.get_auth_mapping())
    assert len(manager.filter(Type[FormatterPlugin])) == \
        len(manager.get_formatters())
    assert len(manager.filter(Type[ConverterPlugin])) == \
        len(manager.get_converters())

# Generated at 2022-06-12 00:24:03.281560
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPHeaders
    from httpie.plugins.builtin import JSONStreamFormatter, StreamFormatter
    from httpie.plugins.builtin import JSONStreamConverter, StreamConverter
    from httpie.plugins.builtin import HTTPieTransport
    # register
    pm = PluginManager()
    pm.register(HTTPBasicAuth, HTTPHeaders, StreamFormatter, JSONStreamFormatter, StreamConverter, JSONStreamConverter, HTTPieTransport)
    # filter
    auth_plugins = pm.filter(AuthPlugin)
    formatter_plugins = pm.filter(FormatterPlugin)
    converter_plugins = pm.filter(ConverterPlugin)
    transport_plugins = pm.filter(TransportPlugin)
    assert auth_plugins == [HTTPBasicAuth, HTTPHeaders]

# Generated at 2022-06-12 00:24:04.552480
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert not PluginManager().get_formatters_grouped()
    Plugi

# Generated at 2022-06-12 00:24:06.994774
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    output = PluginManager()
    output.register(FormatterPlugin)
    output.append(FormatterPlugin)
    assert output.get_formatters_grouped() == {'Group 1': [FormatterPlugin, FormatterPlugin]}

# Generated at 2022-06-12 00:24:07.524795
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert True

# Generated at 2022-06-12 00:24:11.374825
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # Check all the entry points are loaded
    assert len(plugin_manager) == len(ENTRY_POINT_NAMES)

# Generated at 2022-06-12 00:24:14.557526
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.builtin import HTTPBasicAuthPlugin, HTTPDigestAuthPlugin
    pm = PluginManager()
    pm.load_installed_plugins()
    assert HTTPBasicAuthPlugin in pm.get_auth_plugins()
    assert HTTPDigestAuthPlugin in pm.get_auth_plugins()

# Generated at 2022-06-12 00:24:25.132558
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert PluginManager().filter() == []
    assert PluginManager().load_installed_plugins() != []
    assert len(PluginManager().filter()) != 0



# Generated at 2022-06-12 00:24:36.375898
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager = plugin_manager.register(*[
        AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin
    ])
    list_BasePlugin = plugin_manager.filter(BasePlugin)
    assert len(list_BasePlugin) == 4
    list_AuthPlugin = plugin_manager.filter(AuthPlugin)
    assert len(list_AuthPlugin) == 1
    list_FormatterPlugin = plugin_manager.filter(FormatterPlugin)
    assert len(list_FormatterPlugin) == 1
    list_ConverterPlugin = plugin_manager.filter(ConverterPlugin)
    assert len(list_ConverterPlugin) == 1
    list_TransportPlugin = plugin_manager.filter(TransportPlugin)
    assert len(list_TransportPlugin) == 1


# Generated at 2022-06-12 00:24:42.937171
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(Plugin1):
        pass

    class Plugin3(Plugin1):
        pass

    plugins = PluginManager()
    plugins.register(Plugin1, Plugin2, Plugin3)

    assert plugins.filter() == [Plugin1, Plugin2, Plugin3]
    assert plugins.filter(Plugin1) == [Plugin1, Plugin2, Plugin3]
    assert plugins.filter(BasePlugin) == [Plugin1, Plugin2, Plugin3]
    assert plugins.filter(Plugin2) == [Plugin2]
    assert plugins.filter(Plugin3) == [Plugin3]



# Generated at 2022-06-12 00:24:46.785891
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager
    # print(plugin_manager)
    # print("the number of installed plugins: {}".format(len(plugin_manager)))

# Generated at 2022-06-12 00:24:50.394315
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    plugin_manager.register(FormatterPlugin)
    assert len(plugin_manager.get_formatters_grouped()) == 4


# Generated at 2022-06-12 00:24:58.786983
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class TestFormatterPlugin(FormatterPlugin):
        pass

    class TestFormatterPlugin_1(FormatterPlugin):
        group_name = 'foo'

    class TestFormatterPlugin_2(FormatterPlugin):
        group_name = 'bar'

    class TestFormatterPlugin_3(FormatterPlugin):
        group_name = 'bar'

    class TestFormatterPlugin_4(FormatterPlugin):
        group_name = 'baz'

    class TestFormatterPlugin_5(FormatterPlugin):
        group_name = 'baz'

    class TestFormatterPlugin_6(FormatterPlugin):
        group_name = 'baz'

    manager = PluginManager()

# Generated at 2022-06-12 00:25:09.293726
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()
    format = manager.get_formatters_grouped()

# Generated at 2022-06-12 00:25:14.937236
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httprunner.plugins.formatter import JsonFormatterPlugin, JUnitFormatterPlugin
    p = PluginManager()
    p.register(JsonFormatterPlugin, JUnitFormatterPlugin)
    assert p.get_formatters_grouped() == {
        'json': [JsonFormatterPlugin],
        'custom': [JUnitFormatterPlugin]
    }

manager = PluginManager()

# Generated at 2022-06-12 00:25:20.754880
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        pass
    class PluginB(BasePlugin):
        pass
    class PluginC(PluginB):
        pass
    plugins = PluginManager()
    plugins.register(PluginA, PluginB, PluginC)
    assert plugins.filter(PluginA) == [PluginA]
    assert plugins.filter(PluginA) != [PluginB]
    assert plugins.filter(PluginB) == [PluginB, PluginC]
    assert plugins.filter(PluginC) == []
    assert plugins.filter(PluginB) != [PluginA]

# Generated at 2022-06-12 00:25:22.395611
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter() == []


plugins = PluginManager()

# Generated at 2022-06-12 00:25:43.702696
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    test_plugin_manager = PluginManager()
    test_plugin_manager.register(FormatterPlugin)
    
    test_plugin_manager.register(FormatterPlugin)
    
    test_output = test_plugin_manager.get_formatters_grouped()
    assert test_output['test_group'] == [PluginManager.FormatterPlugin]

# Generated at 2022-06-12 00:25:54.383977
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class JsonPlugin:
        group_name = 'json'
    class JsonPrettyPlugin:
        group_name = 'json'
    class HtmlPlugin:
        group_name = 'html'
    class HtmlPrettyPlugin:
        group_name = 'html'
    class SimplePlugin:
        group_name = 'simple'
    plugins = PluginManager()
    plugins.register(JsonPlugin,JsonPrettyPlugin,HtmlPlugin,HtmlPrettyPlugin,SimplePlugin)
    print(plugins.get_formatters_grouped())

# Generated at 2022-06-12 00:25:57.926903
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)

if __name__ == "__main__":
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:26:02.491032
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # create a instance of PluginManager and load all installed plugins
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # test below code
    # if you have installed some plugins, the result should be more than 5
    if len(plugin_manager) < 1:
        raise Exception(plugin_manager)



# Generated at 2022-06-12 00:26:13.196140
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie.plugins.builtin
    from httpie.plugins.builtin import FormatterPlugin

    formatters_builtin = httpie.plugins.builtin.__formatters__
    pm = PluginManager()
    # load builtin formatters
    pm.register(*formatters_builtin)
    # load other formatters in other packages
    pm.load_installed_plugins()
    # test get_formatters_grouped method
    assert type(pm.get_formatters_grouped()) is dict
    for k, v in pm.get_formatters_grouped().items():
        assert type(k) is str
        for formatter in v:
            assert issubclass(formatter, FormatterPlugin)


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()



# Generated at 2022-06-12 00:26:14.374621
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()

# Generated at 2022-06-12 00:26:17.369778
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    print(plugins.get_transport_plugins())
    print(plugins.get_formatters_grouped())
    print(plugins.get_formatters())

# Generated at 2022-06-12 00:26:22.215063
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager.get_auth_plugin_mapping()) != 0
    assert len(pluginManager.get_formatters_grouped()) != 0
    assert len(pluginManager.get_converters()) != 0
    assert len(pluginManager.get_transport_plugins()) != 0


# Generated at 2022-06-12 00:26:26.141567
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm)
    assert all(issubclass(plugin, BasePlugin) for plugin in pm)
    assert all(hasattr(plugin, 'package_name') for plugin in pm)



# Generated at 2022-06-12 00:26:30.783745
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    my_plugin = mock.Mock()

    pm = PluginManager()
    pm.load_installed_plugins()
    pm.register(my_plugin)

    assert pm.get_auth_plugin('basic') is not None
    assert pm.get_auth_plugin('digest') is not None
    assert pm.get_auth_plugins() is not None
    assert pm.get_formatters() is not None
    assert pm.get_formatters_grouped() is not None
    assert pm.get_transport_plugins() is not None

if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:27:06.515172
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    """Test method filter of class PluginManager"""
    pass

# Generated at 2022-06-12 00:27:11.189209
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugins() != []
    assert plugins.get_formatters() != []
    assert plugins.get_converters() != []
    assert plugins.get_transport_plugins() != []

if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:27:14.975690
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2)

    assert plugin_manager.filter(by_type=Plugin1) == [Plugin1]
    assert plugin_manager.filter(by_type=Plugin2) == [Plugin2]



# Generated at 2022-06-12 00:27:24.950580
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import HTMLFormatter, JSONFormatter, URLEncodedFormatter
    from httpie.plugins.builtin import headers, pretty
    import pytest
    pm=PluginManager()
    pm.register(JSONFormatter, HTMLFormatter, URLEncodedFormatter, headers, pretty)

# Generated at 2022-06-12 00:27:28.880243
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(DemoFormatterPlugin, DemoFormatterPlugin2)

    groups = plugins.get_formatters_grouped()

    assert groups.keys() == {'demo_group'}
    assert groups['demo_group'] == [DemoFormatterPlugin, DemoFormatterPlugin2]


# Generated at 2022-06-12 00:27:31.108554
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # It tests if run successfully or not
    pluginManager = PluginManager()
    assert(pluginManager.load_installed_plugins() is None)

# Generated at 2022-06-12 00:27:37.324640
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    class Plugin1(BasePlugin):
        pass
    class Plugin2(BasePlugin):
        pass
    class Plugin3(BasePlugin):
        pass
    class SubPlugin1(Plugin1):
        pass

    plugins.register(Plugin1, Plugin2, Plugin3, SubPlugin1)

    assert plugins.filter(BasePlugin) == [Plugin1, Plugin2, Plugin3, SubPlugin1]
    assert plugins.filter(Plugin1) == [Plugin1, SubPlugin1]

# Generated at 2022-06-12 00:27:46.879486
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['basic'] == BasicAuthPlugin
    assert auth_plugin_mapping['digest'] == DigestAuthPlugin
    assert auth_plugin_mapping['jwt'] == JWTAuthPlugin
    assert auth_plugin_mapping['hawk'] == HawkAuthPlugin
    assert auth_plugin_mapping['aws4-hmac-sha256'] == AWS4HMACSHA256AuthPlugin


# Generated at 2022-06-12 00:27:53.416346
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """Unit test for method get_formatters_grouped of class PluginManager
    """
    class PluginManagerSubclass(PluginManager):
        """Subclass of PluginManager
        """
        def get_formatters(self):
            """Get formatters
            """
            return [
                FormatterPluginSubclass1('a', 'g1'),
                FormatterPluginSubclass2('b', 'g1'),
                FormatterPluginSubclass3('c', 'g2'),
                FormatterPluginSubclass4('d', 'g2'),
                FormatterPluginSubclass5('e', 'g1'),
                FormatterPluginSubclass6('f', 'g1'),
                FormatterPluginSubclass7('g', 'g2'),
                FormatterPluginSubclass8('h', 'g2'),
            ]

# Generated at 2022-06-12 00:27:57.004982
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin
    m = PluginManager()
    assert m.filter(AuthPlugin) == []
    from httpie.plugins.builtin import DigestAuthPlugin
    m.append(DigestAuthPlugin)
    assert m.filter(AuthPlugin) == [DigestAuthPlugin]

# Generated at 2022-06-12 00:29:18.683444
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(ColorfulHTTPResponsePlugin, DefaultJSONPlugin)
    assert pm.get_formatters_grouped() == \
        {'builtin': [ColorfulHTTPResponsePlugin], 'json': [DefaultJSONPlugin]}

# Generated at 2022-06-12 00:29:28.738761
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    import json

    m = PluginManager()

    class TestJSONFormatterPlugin(JSONFormatterPlugin):
        name = 'format1'
        group_name = 'group1'

    class TestJSONFormatterPlugin2(JSONFormatterPlugin):
        name = 'format2'
        group_name = 'group2'

    class TestJSONFormatterPlugin3(JSONFormatterPlugin):
        name = 'format3'
        group_name = 'group1'

    m.register(TestJSONFormatterPlugin)
    m.register(TestJSONFormatterPlugin2)
    m.register(TestJSONFormatterPlugin3)


# Generated at 2022-06-12 00:29:32.281568
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert plugin_manager.get_auth_plugin_mapping() == {}
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.get_auth_plugin_mapping() == {AuthPlugin.auth_type: AuthPlugin}