

# Generated at 2022-06-12 00:19:42.970714
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    dummy = False
    fail = False
    for p in pm:
        if 'dummy' in p.package_name:
            dummy = True
            if p.package_version != '0.0.1':
                fail = True
    if not dummy:
        fail = True
    assert not fail

# Generated at 2022-06-12 00:19:48.877358
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    d=PluginManager()
    d.register(PluginManager)
    d.register(TransportPlugin)
    d.register(List)
    assert issubclass(d.filter()[0],Type[List])
    assert issubclass(d.filter(TransportPlugin)[0],Type[TransportPlugin])
test_PluginManager_filter()


# Generated at 2022-06-12 00:19:57.234740
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSON
    from httpie.plugins.builtin import HTML
    from httpie.plugins.builtin import CSV
    from httpie.plugins.builtin import TerminalTable
    from httpie.plugins.builtin import Pretty
    from httpie.plugins.builtin import URLEncoded
    from httpie.plugins.builtin import RawJSON
    from httpie.plugins.builtin import RawURLEncoded

    pm = PluginManager()
    pm.register(JSON, HTML, CSV, TerminalTable, Pretty, URLEncoded, RawJSON, RawURLEncoded)


# Generated at 2022-06-12 00:20:09.316117
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    
    assert isinstance(plugin_manager.get_formatters_grouped(), dict)
    assert plugin_manager.get_formatters_grouped().get('json')
    assert plugin_manager.get_formatters_grouped().get('json')[0].__name__ == 'ParseJSON'
    assert plugin_manager.get_formatters_grouped().get('html')
    assert plugin_manager.get_formatters_grouped().get('html')[0].__name__ == 'ParseHTML'
    assert plugin_manager.get_formatters_grouped().get('xml')
    assert plugin_manager.get_formatters_grouped().get('xml')[0].__name__ == 'ParseXML'
    
# Unit test

# Generated at 2022-06-12 00:20:15.671164
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_auth_plugins()) > 0
    assert len(plugin_manager.get_formatters()) > 0
    assert len(plugin_manager.get_converters()) > 0
    assert len(plugin_manager.get_transport_plugins()) > 0



# Generated at 2022-06-12 00:20:17.452315
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager();
    pluginManager.load_installed_plugins();
    print(pluginManager)


# Generated at 2022-06-12 00:20:23.287126
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    real_plugins_names = set(['HTTPBasicAuth', 'HTTPDigestAuth', 'HTTPGSSAPI'])
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins_names = set(map(lambda x : x.__name__, plugins.get_auth_plugins()))
    assert real_plugins_names == plugins_names


# Generated at 2022-06-12 00:20:32.038078
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import CSVFormatterPlugin
    from httpie.plugins.builtin import URLEncodedFormatterPlugin
    from httpie.plugins.builtin import HTMLFormatterPlugin
    from httpie.plugins.builtin import ImageFormatterPlugin
    pm = PluginManager()
    pm.register(JSONFormatterPlugin, CSVFormatterPlugin, URLEncodedFormatterPlugin, HTMLFormatterPlugin, ImageFormatterPlugin)

# Generated at 2022-06-12 00:20:42.590573
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.__main__ import main
    from httpie.plugins import FormatterPlugin
    from httpie.output.streams import TTYOutputStream
    from httpie.formatter import JsonPointerFormat

    class Plugin(FormatterPlugin):

        group_name = 'test'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.__class__.group_name = 'test1'

        def format_body(self, body, **kwargs):
            return self.transform(body, **kwargs)

    class Plugin_TTY(FormatterPlugin):

        group_name = 'test'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.__class

# Generated at 2022-06-12 00:20:44.796786
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert plugin_manager != 0



# Generated at 2022-06-12 00:20:51.491164
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins_list = PluginManager()
    plugins_list.register(BoolConverter, IntegerConverter, JSONConverter)
    assert len(plugins_list.filter(ConverterPlugin)) == 3

# Generated at 2022-06-12 00:20:53.294967
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 4


# Generated at 2022-06-12 00:21:01.872678
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(Plugin)
    f1 = FormatterPlugin()
    f2 = FormatterPlugin()
    f3 = FormatterPlugin()
    f1.group_name = 'a'
    f2.group_name = 'a'
    f3.group_name = 'b'
    manager.register(f1)
    manager.register(f2)
    manager.register(f3)
    manager.get_formatters_grouped()
    assert f1 in manager.get_formatters_grouped()['a']
    assert f2 in manager.get_formatters_grouped()['a']
    assert f3 in manager.get_formatters_grouped()['b']

# Generated at 2022-06-12 00:21:05.555676
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():

    _PluginManager = PluginManager()

    _PluginManager.register(BasicAuthPlugin)

    assert _PluginManager.get_auth_plugin_mapping() == {'basic': BasicAuthPlugin}


# Generated at 2022-06-12 00:21:17.066972
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Test normal case: return dict of mapping between name of formatter and list of formatter
    # Create a PluginManager object
    plugin_manager = PluginManager()
    # Call method get_formatters_grouped
    result = plugin_manager.get_formatters_grouped()
    # Check result

# Generated at 2022-06-12 00:21:19.137521
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-12 00:21:20.959282
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-12 00:21:25.661564
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(ChromeFormatter, 
                FirefoxFormatter, 
                CurlFormatter, 
                JsonFormatter, 
                PlainFormatter,
                PygmentsFormatter
    )
    pm.load_installed_plugins()
    assert len(pm.get_formatters_grouped()) == 4
    assert pm.get_formatters_grouped()['Visual'] == \
    [ChromeFormatter, FirefoxFormatter, CurlFormatter]
    # end unit test


# Generated at 2022-06-12 00:21:37.522309
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin.formatters import HtmlFormatter, EchoFormatter, JsonFormatter, \
        JUnitXmlFormatter
    from httpie.plugins.builtin.formatters import JsonLinesFormatter, PrettyJsonFormatter, \
        RawJsonFormatter

    plugin_manager = PluginManager()
    plugin_manager.register(HtmlFormatter, EchoFormatter, JsonFormatter, JUnitXmlFormatter,
                            JsonLinesFormatter, PrettyJsonFormatter, RawJsonFormatter)
    formatter_mapping = plugin_manager.get_formatters_grouped()
    assert len(formatter_mapping) == 4
    assert sorted(list(formatter_mapping.keys())) == ['builtin', 'custom', 'json', 'other']


plugin_manager

# Generated at 2022-06-12 00:21:41.307450
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager1 = PluginManager()
    PluginManager1.register(FormatterPlugin)
    PluginManager1.register(FormatterPlugin1)
    PluginManager1.register(FormatterPlugin2)
    PluginManager1.register(FormatterPlugin3)
    PluginManager1.register(FormatterPlugin4)
    assert PluginManager1.get_formatters_grouped() == {"group0" : [FormatterPlugin],
                                                        "group1" : [FormatterPlugin1],
                                                        "group2" : [FormatterPlugin2],
                                                        "group3" : [FormatterPlugin3],
                                                        "group4" : [FormatterPlugin4]}

# Generated at 2022-06-12 00:21:47.000657
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}

# Generated at 2022-06-12 00:21:57.354153
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A(BasePlugin):
        pass

    class B(A):
        pass

    class C(BasePlugin):
        pass

    class D(A):
        pass

    class E(D):
        pass

    pm = PluginManager()
    pm.register(A, B, C, D, E)

    assert pm.filter() == [A, B, C, D, E]
    assert pm.filter(by_type=A) == [A, B, D, E]
    assert pm.filter(by_type=B) == [B]
    assert pm.filter(by_type=C) == [C]
    assert pm.filter(by_type=D) == [D, E]
    assert pm.filter(by_type=E) == [E]
    assert pm.filter(by_type=0)

# Generated at 2022-06-12 00:22:08.804980
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFORMAT, COLOR
    from httpie.plugins.builtin import JsonLinesFormatPlugin,  \
        JsonLinesTextFormatPlugin, JsonFormatPlugin,JsonTextFormatPlugin, \
        ColoredStreamWriter
    assert PluginManager().get_formatters_grouped() == \
           {'json': [JsonFormatPlugin, JsonTextFormatPlugin], 'jsonl': [JsonLinesFormatPlugin, JsonLinesTextFormatPlugin]}
    assert PluginManager([COLOR]).get_formatters_grouped() == {'color': [ColoredStreamWriter]}
    assert PluginManager([JSONFORMAT]).get_formatters_grouped() == {'json': [JsonFormatPlugin, JsonTextFormatPlugin]}
    assert PluginManager([JSONFORMAT, COLOR]).get_formatters_group

# Generated at 2022-06-12 00:22:19.315217
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie
    plugin_manager = httpie.plugins.manager
    plugin_manager.register(httpie.plugins.builtin.HTTPLibJSONFormatter)
    plugin_manager.register(httpie.plugins.builtin.HTTPLibTextFormatter)
    plugin_manager.register(httpie.plugins.builtin.PrettyFormatter)
    plugin_manager.register(httpie.plugins.builtin.JSONFormatter)
    plugin_manager.register(httpie.plugins.builtin.JSONCompactFormatter)
    plugin_manager.register(httpie.plugins.builtin.JSONLinesFormatter)
    plugin_manager.register(httpie.plugins.builtin.ColorsFormatter)
    plugin_manager.register(httpie.plugins.builtin.StreamFormatter)

# Generated at 2022-06-12 00:22:23.235667
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    plugin_manager.get_auth_plugin_mapping()
    assert plugin_manager.get_auth_plugin_mapping()['basic'] is not None

# Generated at 2022-06-12 00:22:30.920316
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import auth
    pm = PluginManager()
    assert len(pm.get_auth_plugin_mapping()) == 0
    names = [plugin.auth_type for plugin in auth.__all__]
    pm.register(*auth.__all__)
    mapping = pm.get_auth_plugin_mapping()
    assert len(mapping) == len(auth.__all__)
    assert set(mapping).issubset(names)
    pm.unregister(auth.DigestAuthPlugin)
    pm.get_auth_plugin_mapping()
    assert len(mapping) == len(auth.__all__) - 1
    assert 'digest' not in mapping


# Generated at 2022-06-12 00:22:38.491920
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass

    PluginManager.register(A, B, C)
    assert PluginManager.filter(A) == [A, B, C]
    assert PluginManager.filter(B) == [B, C]
    assert PluginManager.filter(C) == [C]

# Generated at 2022-06-12 00:22:40.082228
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager

# Generated at 2022-06-12 00:22:41.886281
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert issubclass(plugin_manager.filter(ConverterPlugin)[0], ConverterPlugin)



# Generated at 2022-06-12 00:22:43.225780
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter(Type[BasePlugin]) == [BasePlugin]

# Generated at 2022-06-12 00:22:52.710059
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    p.register(ConverterPlugin)
    print(p.filter(ConverterPlugin))

# Generated at 2022-06-12 00:22:56.904876
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_auth_plugin_mapping() == {'basic': httpie.plugins.auth.basic_auth.BasicAuthPlugin, 'digest': httpie.plugins.auth.digest_auth.DigestAuthPlugin, 'jwt': httpie.plugins.auth.jwt_auth.JWTAuthPlugin, 's3': httpie.plugins.auth.aws.AWSSignatureV4AuthPlugin}


# Generated at 2022-06-12 00:23:04.135569
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    assert manager.register(
        FormatterPlugin('hm', 'hm', 'hm', 'hm'),
        FormatterPlugin('geo', 'geo', 'geo', 'geo'),
        FormatterPlugin('user', 'user', 'user', 'user'),
    )

    assert manager.append(FormatterPlugin('geo1', 'geo1', 'geo1', 'geo1'))


# Generated at 2022-06-12 00:23:07.820911
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(AuthPluginTest1)
    plugins.register(AuthPluginTest2)
    mapping = plugins.get_auth_plugin_mapping()
    assert mapping['test'] == AuthPluginTest1
    assert mapping['test2'] == AuthPluginTest2


# Generated at 2022-06-12 00:23:08.610973
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager.filter() == Type[BasePlugin]

# Generated at 2022-06-12 00:23:10.892841
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager)


# Generated at 2022-06-12 00:23:13.146702
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm.get_formatters_grouped().keys()) >= 2

# Generated at 2022-06-12 00:23:15.653048
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter() == [], "失败"


# Generated at 2022-06-12 00:23:17.320101
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()



# Generated at 2022-06-12 00:23:18.245295
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin = PluginManager()
    prin

# Generated at 2022-06-12 00:23:41.890179
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(FormatterPlugin)

    # Mocking classes
    class a(FormatterPlugin):
        group_name = "a"

    class b(FormatterPlugin):
        group_name = "b"

    class c(FormatterPlugin):
        group_name = "a"

    pm.register(a, b, c)

    from pprint import pprint
    pprint(pm.get_formatters_grouped())

# Generated at 2022-06-12 00:23:44.817212
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """
    There should be more than 5 plugins
    """
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 5



# Generated at 2022-06-12 00:23:50.626984
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            plugin_manager.register(entry_point.load())
    plugin_manager.get_formatters_grouped()


plugin_manager = PluginManager()

# Generated at 2022-06-12 00:23:52.571965
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:24:01.304292
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin): pass
    class Plugin2(Plugin1): pass
    class Plugin3(Plugin1): pass
    class Plugin4(BasePlugin): pass

    class Foo1(BasePlugin): pass
    class Foo2(BasePlugin): pass
    class Foo3(BasePlugin): pass
    class Foo4(BasePlugin): pass

    manager = PluginManager()
    manager.register(Plugin1, Plugin2, Plugin3, Plugin4, Foo1, Foo2, Foo3, Foo4)

    assert len(manager.filter(Foo1)) == 4
    assert len(manager.filter(Plugin1)) == 3

# Generated at 2022-06-12 00:24:03.352179
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    test_PM = PluginManager()
    test_PM.load_installed_plugins()
    assert len(test_PM) > 0

# Generated at 2022-06-12 00:24:10.456608
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    def foo_test():
        pass

    def bar_test():
        pass
    
    def foobar_test():
        pass

    def foobarbar_test():
        pass
    
    class Foo(AuthenticatedPlugin):
        auth_type = 'foo'

    class Bar(AuthenticatedPlugin):
        auth_type = 'bar'
    
    class Foobar(AuthenticatedPlugin):
        auth_type = 'foobar'

    class Foobarbar(AuthenticatedPlugin):
        auth_type = 'foobarbar'

    plugins = PluginManager()

    plugins.register(Foo, Bar, Foobar, Foobarbar)
    plugins_list = plugins.filter(AuthenticatedPlugin)

# Generated at 2022-06-12 00:24:16.745684
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    class TestPlugin(BasePlugin):
        pass
    # Mock the function iter_entry_points
    def mock_iter_entry_points(entry_point_name):
        if entry_point_name=='httpie.plugins.formatter.v1':
            for entry_point in [MockEntryPoint(entry_point_name)]:
                yield entry_point
        else:
            for entry_point in []:
                yield entry_point
    manager = PluginManager()
    with mock.patch('pkg_resources.iter_entry_points') as mock_iter_entry_points_func:
        mock_iter_entry_points_func.side_effect = mock_iter_entry_points
        manager.load_installed_plugins()
        assert isinstance(manager[0], TestPlugin)

# Generated at 2022-06-12 00:24:22.478821
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(CommonAuthPlugin, DigestAuthPlugin)
    assert len(plugins.filter(AuthPlugin)) == 2
    assert len(plugins.filter(BasePlugin)) == 2
    assert len(plugins.filter(CommonAuthPlugin)) == 1
    assert len(plugins.filter(DigestAuthPlugin)) == 1

# Generated at 2022-06-12 00:24:27.824802
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert not plugin_manager.get_formatters()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_auth_plugins()
    assert plugin_manager.get_auth_plugin_mapping()
    assert plugin_manager.get_auth_plugin('basic')
    assert plugin_manager.get_formatters_grouped()
    assert plugin_manager.get_converters()
    assert plugin_manager.get_transport_plugins()

# Generated at 2022-06-12 00:25:01.752455
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    auth_plugins_mapping = {}
    manager = PluginManager()
    manager.register()

    assert manager.get_auth_plugin_mapping() == auth_plugins_mapping


# Generated at 2022-06-12 00:25:12.053386
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    def check(func, args, result):
        assert func(*args) == result

    plugin_manager = PluginManager()

    # load_installed_plugins
    plugin_manager.load_installed_plugins()
    check(len, [plugin_manager], 4)

    # get_auth_plugins
    plugin_manager.get_auth_plugins()
    check(len, [plugin_manager], 4)

    # get_auth_plugin_mapping
    plugin_manager.get_auth_plugin_mapping()
    check(len, [plugin_manager], 4)

    # get_auth_plugin
    plugin_manager.get_auth_plugin('basic')
    check(len, [plugin_manager], 4)

    # get_formatters
    plugin_manager.get_formatters()
    check(len, [plugin_manager], 4)

# Generated at 2022-06-12 00:25:16.000122
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Prepare
    httpie_plugin_manager = PluginManager()

    # Execute
    formatters_grouped = httpie_plugin_manager.get_formatters_grouped()

    # Verify
    assert formatters_grouped == {}
    # Return
    return formatters_grouped


# Generated at 2022-06-12 00:25:20.024872
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    test = PluginManager()
    def test_func(abc: BasePlugin):
        pass
    assert type(test.filter(by_type=BasePlugin)) == list
    assert len(test.filter(by_type=BasePlugin)) == 0
    test.register(test_func)
    assert len(test.filter(by_type=BasePlugin)) == 1


# Generated at 2022-06-12 00:25:24.042737
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(FormatterPlugin, AuthPlugin)

# Generated at 2022-06-12 00:25:29.620784
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONConverterPlugin
    from httpie.plugins.formatter.colors import ConsoleColorsFormatter
    from httpie.plugins.formatter.format import FormattingFormatter
    PluginManager.register(JSONConverterPlugin, FormattingFormatter, ConsoleColorsFormatter)
    result = PluginManager.get_formatters_grouped()
    assert result == {
        'Output processing': [FormattingFormatter, ConsoleColorsFormatter]
    }

# Generated at 2022-06-12 00:25:31.045408
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}



# Generated at 2022-06-12 00:25:33.510808
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()

    p.load_installed_plugins()

    assert len(p) == 4

# Generated at 2022-06-12 00:25:36.253410
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    print(manager[0].__name__)


# Generated at 2022-06-12 00:25:42.265951
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(BasePlugin)
    formatters = manager.get_formatters_grouped()
    assert(formatters['Basic'][0].name == 'json')
    assert(formatters['HTML'][0].name == 'html')
    assert(formatters['JSON'][0].name == 'json')
    assert(formatters['Table'][0].name == 'table')

# Generated at 2022-06-12 00:26:17.991043
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FirstFormatterPlugin(FormatterPlugin):
        group_name = 'first'

    class SecondFormatterPlugin(FormatterPlugin):
        group_name = 'second'
    
    class ThirdFormatterPlugin(FormatterPlugin):
        group_name = 'first'

    plugin_manager = PluginManager()
    plugin_manager.register(FirstFormatterPlugin, SecondFormatterPlugin, ThirdFormatterPlugin)
    print(plugin_manager.get_formatters_grouped())

# Generated at 2022-06-12 00:26:27.421832
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class PluginA(BasePlugin):
        def prepare_request(self):
            pass
    class PluginB(BasePlugin):
        def prepare_request(self):
            pass
    class PluginC(PluginA):
        def prepare_request(self):
            pass
    class PluginD(PluginA):
        def prepare_request(self):
            pass

    plugin_manager = PluginManager()        
    plugin_manager.register(PluginA, PluginB, PluginC, PluginD)

    assert PluginA in plugin_manager.filter()
    assert PluginB in plugin_manager.filter()
    assert PluginC in plugin_manager.filter()
    assert PluginD in plugin_manager.filter()

    assert PluginA in plugin_manager.filter(BasePlugin)
    assert PluginB in plugin_manager.filter(BasePlugin)
    assert PluginC in plugin_

# Generated at 2022-06-12 00:26:34.811940
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import RemoteRelativePathFormatterPlugin

    pm = PluginManager()
    pm.register(JSONFormatterPlugin, PrettyJsonFormatterPlugin, RemoteRelativePathFormatterPlugin)

    t = {'json': [JSONFormatterPlugin, PrettyJsonFormatterPlugin], 'remote': [RemoteRelativePathFormatterPlugin]}

    assert pm.get_formatters_grouped() == t

# Generated at 2022-06-12 00:26:36.900096
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}

# Generated at 2022-06-12 00:26:41.831251
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # create new PluginManager object
    plugin_manager = PluginManager()
    # load plugins
    plugin_manager.load_installed_plugins()
    # get name of second plugin
    plugin_name = plugin_manager[1].name
    assert plugin_name in ['json', 'json5', 'xml']
    assert len(plugin_manager) == 15

# Generated at 2022-06-12 00:26:43.634884
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager != []

# Generated at 2022-06-12 00:26:53.823006
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin

    def load_all_plugins():
        from pathlib import Path
        from pkg_resources import DistributionNotFound, get_distribution
        from importlib import import_module
        from pkgutil import walk_packages


        for entry_point_name in ENTRY_POINT_NAMES:
            # If the plugins are installed in a virtual environment,
            # then we need to use pkg_resources to find the installed plugins
            try:
                plugin_dist = get_distribution('httpie-jwt-auth')
            except DistributionNotFound:
                plugin_dist = None
            else:
                # Import the module to make the entry points available
                import_module(plugin_dist.key)


# Generated at 2022-06-12 00:27:01.388063
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    '''Test whether the filter method works well'''
    plugin_manager = PluginManager()
    plugin_manager.append(HTTPBasicAuthPlugin())
    plugin_manager.append(HTTPBasicAuthPlugin())
    plugin_manager.append(JsonBodyFormatter())
    plugin_manager.append(JsonBodyFormatter())
    plugin_manager.append(JsonBodyFormatter())
    actual = plugin_manager.filter(AuthPlugin)
    assert actual == [HTTPBasicAuthPlugin, HTTPBasicAuthPlugin]



# Generated at 2022-06-12 00:27:10.292788
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.load_installed_plugins()

# Generated at 2022-06-12 00:27:13.177262
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    assert len(manager) == 0,f'Failed to load plugins : {manager}'
    manager.load_installed_plugins()
    assert len(manager) > 0,f'Failed to load plugins : {manager}'

# Generated at 2022-06-12 00:28:25.883617
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    plugins_dir = temp_dir.name
    import os
    import shutil


# Generated at 2022-06-12 00:28:32.967200
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    sorted_list = sorted(p, key=lambda x:x.name)
    assert sorted_list[0].__name__ == 'BasicAuthPlugin'
    assert sorted_list[1].__name__ == 'DigestAuthPlugin'
    assert sorted_list[2].__name__ == 'FormatterPlugin'
    assert sorted_list[3].__name__ == 'FormatterPlugin'
    assert sorted_list[4].__name__ == 'FormatterPlugin'
    assert sorted_list[5].__name__ == 'FormatterPlugin'
    assert sorted_list[6].__name__ == 'FormatterPlugin'
    assert sorted_list[7].__name__ == 'FormatterPlugin'
    assert sorted_list[8].__name__ == 'FormatterPlugin'


# Generated at 2022-06-12 00:28:37.401382
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # test_PluginManager_load_installed_plugins
    from httpie.plugins import HTTPBasicAuthPlugin
    http_basic_auth = HTTPBasicAuthPlugin().auth_type
    #Create an object of class PluginManager
    manager = PluginManager()
    #Load installed plugins and get the plugins with type 'auth'
    manager.load_installed_plugins()
    auth_plugins = manager.get_auth_plugins()
    # assert length of list auth_plugins
    assert len(auth_plugins) == 2
    # assert HTTPBasicAuthPlugin plugin exists in auth_plugins
    assert http_basic_auth in auth_plugins

# Generated at 2022-06-12 00:28:43.350196
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(HttpiePlugin)
    manager.register(JSONPlugin)
    manager.register(YAMLPlugin)
    manager.register(TablePlugin)

    # Test with 3 formatters
    expected_output =  {'data': [HttpiePlugin, JSONPlugin, YAMLPlugin]}
    assert manager.get_formatters_grouped() == expected_output

    # Test no formatters
    manager = PluginManager()
    assert manager.get_formatters_grouped() == {}

# Generated at 2022-06-12 00:28:45.725449
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()

    assert manager.get_formatters_grouped()



# Generated at 2022-06-12 00:28:55.260788
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {}
    plugin_manager.register(JsonTestPlugin)
    assert plugin_manager.get_formatters_grouped() == {'json': [JsonTestPlugin]}
    plugin_manager.register(XmlTestPlugin)
    assert plugin_manager.get_formatters_grouped() == {
        'json': [JsonTestPlugin],
        'xml': [XmlTestPlugin],
    }
    plugin_manager.register(HtmlTestPlugin)
    assert plugin_manager.get_formatters_grouped() == {
        'json': [JsonTestPlugin],
        'xml': [XmlTestPlugin],
        'html': [HtmlTestPlugin]
    }
    plugin_manager.unregister(JsonTestPlugin)

# Generated at 2022-06-12 00:29:03.741866
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()

    # test entry point auth.v1
    plugins.register(OAuth1AuthPlugin)
    plugins.register(OAuth2AuthPlugin)
    plugins.register(DigestAuthPlugin)
    plugins.register(NetrcAuthPlugin)
    plugins.register(HawkAuthPlugin)

    assert len(plugins.get_auth_plugins()) == 5
    plugin_mapping = plugins.get_auth_plugin_mapping()
    assert 'oauth1' in plugin_mapping
    assert issubclass(plugin_mapping['oauth1'], OAuth1AuthPlugin)
    assert 'oauth2' in plugin_mapping
    assert issubclass(plugin_mapping['oauth2'], OAuth2AuthPlugin)
    assert 'hawk' in plugin_mapping

# Generated at 2022-06-12 00:29:04.951073
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()


# Generated at 2022-06-12 00:29:12.609123
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin
    from httpie import plugins
    class X(TransportPlugin):
        pass
    class Y(AuthPlugin):
        pass
    class Z(ConverterPlugin):
        pass
    class W(FormatterPlugin):
        pass
    plugins.manager.register(X, Y, Z, W)

    assert plugins.manager.filter(TransportPlugin) == [X]
    assert plugins.manager.filter(AuthPlugin) == [Y]
    assert plugins.manager.filter(ConverterPlugin) == [Z]
    assert plugins.manager.filter(FormatterPlugin) == [W]


manager = PluginManager()

# Generated at 2022-06-12 00:29:14.937297
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Preparation
    plugin_manager = PluginManager()
    # Test case
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0