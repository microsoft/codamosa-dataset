

# Generated at 2022-06-12 00:19:37.837803
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm.get_formatters()

# Generated at 2022-06-12 00:19:43.890435
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    # Formatter plugins
    assert len(pm.get_formatters_grouped()) == 1 # core plugins
    # Auth plugins
    assert len(pm.get_auth_plugins()) == 1
    # Converter plugins
    assert len(pm.get_converters()) == 8
    # Transport plugins
    assert len(pm.get_transport_plugins()) == 1



# Generated at 2022-06-12 00:19:53.573600
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Formatter0(FormatterPlugin):
        group_name = 'group0'
    class Formatter1(FormatterPlugin):
        group_name = 'group1'
    class Formatter2(FormatterPlugin):
        group_name = 'group1'
    class Formatter3(FormatterPlugin):
        group_name = 'group2'
    class Formatter4(FormatterPlugin):
        group_name = 'group3'

    plugins = PluginManager()
    plugins.register(Formatter0, Formatter1, Formatter2, Formatter3, Formatter4)

# Generated at 2022-06-12 00:19:56.610791
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import auth, formatter, converter, transport
    manager = PluginManager()
    manager.load_installed_plugins()
    for item in ENTRY_POINT_NAMES:
        assert item in manager.__str__()

# Generated at 2022-06-12 00:20:09.247213
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth
    from httpie.plugins.cookies import CookiesPlugin
    from httpie.plugins.gnupg import GnuPGPlugin
    from httpie.plugins.json import JSONLinesPrettyPrinter, JSONLinesTool
    from httpie.plugins.json import JSONLinesStreamTool, JSONStreamFormat
    from httpie.plugins.json import JSONTool
    from httpie.plugins.json import JSONPrettyPrinter
    from httpie.plugins.multipart import MultipartFormDataTool
    from httpie.plugins.pretty import PrettyPlugin
    from httpie.plugins.windows import WindowsApiAuthPlugin
    from httpie.plugins.windows import WindowsCredentialsAuthPlugin
    from httpie.plugins.windows import Windows

# Generated at 2022-06-12 00:20:18.185369
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
	from httpie.plugins import FormatterPlugin
	
	class Plugin1(FormatterPlugin):
		group_name = 'group_name_1'
		
	class Plugin2(FormatterPlugin):
		group_name = 'group_name_2'
	
	plugin_manager = PluginManager()
	plugin_manager.register(Plugin1, Plugin2)
	assert plugin_manager.get_formatters_grouped() == {'group_name_1': [Plugin1], 'group_name_2': [Plugin2]}

# Generated at 2022-06-12 00:20:23.031207
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import httpie.plugins as p
    pm = PluginManager()
    pm.register(p.HelloWorldPlugin, p.HelloWorld1Plugin, p.HelloWorld2Plugin)
    assert len(pm.filter()) == 3
    assert len(pm.filter(TransportPlugin)) == 1
    assert len(pm.filter(AuthPlugin)) == 0

# Generated at 2022-06-12 00:20:25.055576
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:20:27.644750
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert not isinstance(pm, PluginManager)


pm = PluginManager()



# Generated at 2022-06-12 00:20:35.458244
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from unittest import TestCase
    from httpie.plugins.builtin import HTTPCompressAuthPlugin

    class DummyPlugin(BasePlugin):
        pass

    pm = PluginManager()
    pm.register(HTTPCompressAuthPlugin)
    pm.register(DummyPlugin)

    assert pm.filter(AuthPlugin) == [HTTPCompressAuthPlugin]
    assert pm.filter(DummyPlugin) == [DummyPlugin]
    assert pm.filter() == [HTTPCompressAuthPlugin, DummyPlugin]

# Generated at 2022-06-12 00:20:40.299229
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import HTTPBasicAuth, HTTPiePlugin
    plugin = PluginManager()
    plugin.load_installed_plugins()
    # Check that HTTPBasicAuth loaded
    assert HTTPBasicAuth in plugin
    # Check that HTTPiePlugin loaded
    assert HTTPiePlugin in plugin


# Generated at 2022-06-12 00:20:49.617392
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    _plugins = [
        FormatterPlugin(group_name='1'), FormatterPlugin(group_name='2'),
        FormatterPlugin(group_name='1'), FormatterPlugin(group_name='3'),
        FormatterPlugin(group_name='1')
    ]
    plugins = PluginManager()
    plugins.register(*_plugins)
    plugin_map = plugins.get_formatters_grouped()
    assert plugin_map == {'1': _plugins[:3], '2': [_plugins[1]],
                          '3': [_plugins[3]]}

# Generated at 2022-06-12 00:20:53.547771
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(MockFormatPlugin)
    formatters = plugin_manager.get_formatters_grouped()
    assert len(formatters['Mock']) > 0
    assert len(formatters['Mock']) == len(formatters['Mock'])


# Generated at 2022-06-12 00:20:54.845322
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm != []

# Generated at 2022-06-12 00:21:03.622251
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(ConverterPlugin)
    plugins.register(AuthPlugin)
    
    assert type(plugins.filter(AuthPlugin)) == list
    assert type(plugins.filter()) == list
    
    assert len(plugins.filter()) == 2
    assert len(plugins.filter(AuthPlugin)) == 1
    assert len(plugins.filter(ConverterPlugin)) == 1
    assert type(plugins.filter(ConverterPlugin)[0]) == type(ConverterPlugin)
    assert type(plugins.filter(AuthPlugin)[0]) == type(AuthPlugin)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-12 00:21:10.180353
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = [PluginManager, AuthPlugin, ConverterPlugin, FormatterPlugin]
    plugins_manage = PluginManager()
    plugins_manage.register(plugins)
    assert plugins_manage.filter(BasePlugin) == [PluginManager, AuthPlugin, ConverterPlugin, FormatterPlugin]
    assert plugins_manage.filter(AuthPlugin) == [AuthPlugin]
    assert plugins_manage.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugins_manage.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugins_manage.filter(TransportPlugin) == []



# Generated at 2022-06-12 00:21:12.311423
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter(by_type=Type[BasePlugin]) == [], "Filter all base plugin"


# Generated at 2022-06-12 00:21:19.559244
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    # Test 1
    # input
    p1 = AuthPlugin()
    p2 = FormatterPlugin()
    pm = PluginManager()

    pm.register(p1, p2)
    # expectation
    expect = [p1]

    # action
    result = pm.filter(AuthPlugin)
    # assert
    assert result == expect

    # Test 2
    # input
    p1 = AuthPlugin()
    p2 = FormatterPlugin()
    pm = PluginManager()

    pm.register(p1, p2)
    # expectation
    expect = [p2]

    # action
    result = pm.filter(FormatterPlugin)
    # assert
    assert result == expect

test = PluginManager()
test.test_PluginManager_filter()

# Generated at 2022-06-12 00:21:26.355735
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()

    class Group1FormatterPlugin(FormatterPlugin):
        group_name = 'Group 1'

    class Group1FormatterPlugin2(FormatterPlugin):
        group_name = 'Group 1'

    class Group1FormatterPlugin3(FormatterPlugin):
        group_name = 'Group 2'

    pm.register(Group1FormatterPlugin, Group1FormatterPlugin2, Group1FormatterPlugin3)
    pg = pm.get_formatters_grouped()
    assert pg == {
        'Group 1': [Group1FormatterPlugin, Group1FormatterPlugin2],
        'Group 2': [Group1FormatterPlugin3]
    }



# Generated at 2022-06-12 00:21:29.911414
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped['web'] != []

# Generated at 2022-06-12 00:21:40.102135
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    class A(BasePlugin):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    p.register(B)
    p.register(C)
    p.register(D)
    assert p.filter(by_type=A) == [B, C, D]


# Generated at 2022-06-12 00:21:42.493913
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

# Generated at 2022-06-12 00:21:54.312237
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class NullFormatter(FormatterPlugin):
        group_name = 'test group'

    class NullFormatter1(FormatterPlugin):
        group_name = 'test group'

    class NullFormatter2(FormatterPlugin):
        group_name = 'test group'

    class NullFormatter3(FormatterPlugin):
        group_name = 'test group'

    class NullFormatter4(FormatterPlugin):
        group_name = 'test group 1'

    class NullFormatter5(FormatterPlugin):
        group_name = 'test group 1'

    class NullFormatter6(FormatterPlugin):
        group_name = 'test group 2'

    class NullFormatter7(FormatterPlugin):
        group_name = 'test group 3'


# Generated at 2022-06-12 00:21:56.161207
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
	plugins = PluginManager()
	plugins.register(AuthPlugin)
	assert plugins.filter() == [AuthPlugin]

# Generated at 2022-06-12 00:21:58.272723
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    # Only test the count of installed plugins
    assert len(plugins) == 17

# Generated at 2022-06-12 00:22:09.674348
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    x = PluginManager()
    x.load_installed_plugins()
    assert(x)
    assert(x.get_auth_plugin_mapping())
    x.unregister(ApiKeyAuthPlugin)
    assert(x.get_auth_plugin_mapping())
    x.unregister(BasicAuthPlugin)
    assert(x.get_auth_plugin_mapping())
    x.unregister(DigestAuthPlugin)
    assert(x.get_auth_plugin_mapping())
    x.unregister(HawkAuthPlugin)
    assert(x.get_auth_plugin_mapping())
    x.unregister(OAuth1AuthPlugin)
    assert(x.get_auth_plugin_mapping())
    x.unregister(OAuth2AuthPlugin)

# Generated at 2022-06-12 00:22:15.701936
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import builtin_plugins
    pm = PluginManager(builtin_plugins)
    assert len(pm) == 0
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert 'httpie-jira' in [plugin.package_name for plugin in pm]

# Generated at 2022-06-12 00:22:22.316606
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie import httpie_version
    from pkg_resources import load_entry_point
    from pkg_resources import Requirement

    """
    httpie --version
    httpie 2.0.0
    """
    assert httpie_version == '2.0.0'

    """
    for entry_point in iter_entry_points(ENTRY_POINT_NAMES[0]):
        plugin = entry_point.load()
        print(plugin)
    """
    version = httpie_version.split('.')[0]
    if version == '1':
        entry_point_name = 'httpie.plugins.auth.v1'
    else:
        entry_point_name = 'httpie.plugins.auth.v2'


# Generated at 2022-06-12 00:22:25.319331
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)

# Generated at 2022-06-12 00:22:28.210482
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    print("Unit test for method load_installed_plugins of class PluginManager is passed.")



# Generated at 2022-06-12 00:22:39.335276
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.load_installed_plugins()

    assert set(pm.get_formatters_grouped().keys()) == {'Default', 'Group1'}
    assert len(pm.get_formatters_grouped()['Default']) == 2
    assert len(pm.get_formatters_grouped()['Group1']) == 1

# Generated at 2022-06-12 00:22:42.103181
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie.plugins.builtin as builtin
    pm = PluginManager()
    pm.load_installed_plugins()
    pm.register(builtin.FormatterPlugin)
    print(pm.get_formatters_grouped())

# Generated at 2022-06-12 00:22:44.163514
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin = PluginManager()
    plugin.register(PluginManager)
    assert len(plugin.filter())==1


# Generated at 2022-06-12 00:22:48.028124
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, FormatterPlugin)
    assert plugin_manager.filter() == [AuthPlugin,FormatterPlugin]
    return


# Generated at 2022-06-12 00:22:52.618135
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    #assert isinstance(manager, list)
    assert manager.__class__.__name__ =='PluginManager'
    for plugin in manager:
        assert issubclass(plugin, BasePlugin)
    assert manager[0].__name__ == 'DigestAuthPlugin'


# Generated at 2022-06-12 00:22:58.263778
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    for key, value in auth_plugin_mapping.items():
        assert(key in auth_plugin_mapping.keys())
        assert(value in auth_plugin_mapping.values())


# Generated at 2022-06-12 00:23:03.209745
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import KeyValueJoinAuthPlugin, JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin, HTTPiePlugin


    pluginManager = PluginManager()
    pluginManager.register(KeyValueJoinAuthPlugin, JSONFormatterPlugin, PrettyJSONFormatterPlugin, HTTPiePlugin)
    print(pluginManager.filter(AuthPlugin))
    print(pluginManager.filter(FormatterPlugin))
    print(pluginManager.filter(ConverterPlugin))
    print(pluginManager.filter(TransportPlugin))


# Generated at 2022-06-12 00:23:09.092209
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    
    from httpie.plugins import auth
    assert pm.get_auth_plugin_mapping() == {
        'basic': auth.BasicAuthPlugin,
        'digest': auth.DigestAuthPlugin,
        'hawk': auth.HawkAuthPlugin,
        'ntlm': auth.NTLMAuthPlugin,
        'oauth1': auth.OAuth1AuthPlugin,
        'hawk': auth.HawkAuthPlugin,
        'netrc': auth.NetrcAuthPlugin,
    }


# Generated at 2022-06-12 00:23:15.229043
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C(A): pass
    pm = PluginManager()
    pm.register(A, B, C)
    assert pm.filter(A) == [A, B, C]
    assert pm.filter(B) == [B]
    assert pm.filter(C) == [C]


# Generated at 2022-06-12 00:23:21.124590
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """Test the code in registered plugins"""
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_auth_plugin('basic')
    assert plugin_manager.get_auth_plugin('digest')
    assert plugin_manager.get_auth_plugin('hmac')
    assert plugin_manager.get_auth_plugin('bearer')
    assert plugin_manager.get_auth_plugin('aws')

# Generated at 2022-06-12 00:23:47.741871
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # 定义一个类实现接口
    class AuthPluginImpl(AuthPlugin):
        auth_type = 'mock-auth'
        auth_type_aliases = []

        def get_auth(self, username, password):
            return []

    manager = PluginManager()
    manager.register(AuthPluginImpl)

    mapping = manager.get_auth_plugin_mapping()
    assert mapping['mock-auth'] == AuthPluginImpl
    assert 'mock-auth' in mapping

# Generated at 2022-06-12 00:23:49.877200
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager) != 0


# Generated at 2022-06-12 00:23:52.210161
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import FormatterPlugin
    formatter_list = [
        formatter for formatter in manager.get_formatters()
        if issubclass(formatter, FormatterPlugin)
    ]
    assert manager.filter(FormatterPlugin) is not False,\
           "Wrong filtering plugin from manager's list"


# Generated at 2022-06-12 00:23:55.118380
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager


# Unit testing for method get_auth_plugin_mapping of class PluginManager

# Generated at 2022-06-12 00:24:05.540265
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Arrange
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import JSONFormatPlugin
    from httpie.plugins.builtin import NetrcAuth
    from httpie.plugins.builtin import PrettyFormatPlugin
    from httpie.plugins.builtin import SQLiteCache
    from httpie.plugins.builtin import URLEncodedFormatPlugin
    from httpie.plugins.builtin import UnixSocketTransport
    PluginManager.register(BasePlugin, HTTPBasicAuth, HTTPiePlugin, JSONFormatPlugin, NetrcAuth, PrettyFormatPlugin, SQLiteCache, URLEncodedFormatPlugin, UnixSocketTransport)
    
    # Act
    result = PluginManager.filter()
    
    # Ass

# Generated at 2022-06-12 00:24:15.222083
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import BuiltinFormattersPlugin

    plugin_manager = PluginManager()
    plugin_manager.register(BuiltinFormattersPlugin)

# Generated at 2022-06-12 00:24:26.233448
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()

    # Test with no registered plugins
    assert (plugin_manager.get_auth_plugin_mapping() == {})

    # Test with a single plugin
    plugin_manager.register(AuthTestPlugin1)
    assert(plugin_manager.get_auth_plugin_mapping() == {'test1': AuthTestPlugin1})

    # Test with two plugins
    plugin_manager.register(AuthTestPlugin2)
    assert(plugin_manager.get_auth_plugin_mapping() == {'test1': AuthTestPlugin1,
                                                        'test2': AuthTestPlugin2})

    # Test with 2 plugins with same type
    plugin_manager.register(AuthTestPlugin1)

# Generated at 2022-06-12 00:24:28.713206
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(AuthPlugin)
    assert manager.get_auth_plugin_mapping() == {'AuthPlugin': AuthPlugin}

# Generated at 2022-06-12 00:24:40.054946
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A(BasePlugin):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(A):
        pass

    pm = PluginManager()
    pm.register(C, D, E)
    assert isinstance(pm.filter(by_type=C)[0], C)
    assert isinstance(pm.filter(by_type=B)[0], C)
    assert isinstance(pm.filter(by_type=A)[0], C)
    assert isinstance(pm.filter(by_type=A)[1], D)
    assert isinstance(pm.filter(by_type=A)[2], E)
    assert len(pm.filter(by_type=B)) == 1

# Generated at 2022-06-12 00:24:49.069918
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    d = {}
    d['key'] = 'value'
    p = PluginManager()
    p.load_installed_plugins()
    print(p.get_formatters_grouped())
    for i in p.get_formatters_grouped():
        print(i)
        print(p.get_formatters_grouped()[i])
    p.register(d)
    print(p.get_formatters_grouped())
    for i in p.get_formatters_grouped():
        print(i)
        print(p.get_formatters_grouped()[i])

# Generated at 2022-06-12 00:25:32.175736
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    entry_point_names = ['httpie.plugins.auth.v1', 'httpie.plugins.formatter.v1', 'httpie.plugins.converter.v1',
                         'httpie.plugins.transport.v1']
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    for entry_point_name in entry_point_names:
        for entry_point in iter_entry_points(entry_point_name):
            assert entry_point.load() == plugin_manager[0]

# Generated at 2022-06-12 00:25:34.892134
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 28



# Generated at 2022-06-12 00:25:40.893881
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import mock
    import httpie.plugins
    httpie.plugins.manager = PluginManager()
    iter_entry_points = mock.Mock()
    iter_entry_points.return_value = [
        mock.Mock(**{'load.return_value': 'Plugin1'}),
        mock.Mock(**{'load.return_value': 'Plugin2'}),
    ]
    with mock.patch('pkg_resources.iter_entry_points',
                    new=iter_entry_points):
        httpie.plugins.manager.load_installed_plugins()
        assert httpie.plugins.manager == ['Plugin1', 'Plugin2']
    iter_entry_points.assert_called_once_with(
        'httpie.plugins.transport.v1')

# Generated at 2022-06-12 00:25:51.280655
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert callable(PluginManager.get_formatters_grouped)
    plugins = PluginManager()
    plugins.register(TransportPlugin)
    plugins.register(FormatterPlugin)
    plugins.register(AuthPlugin)
    plugins.register(ConverterPlugin)
    plugins.load_installed_plugins()

# Generated at 2022-06-12 00:25:56.804920
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(AuthPlugin)
    manager.register(FormatterPlugin)
    manager.register(ConverterPlugin)
    manager.register(TransportPlugin)
    assert manager.filter(AuthPlugin) == [AuthPlugin]
    assert manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert manager.filter(TransportPlugin) == [TransportPlugin]

# Generated at 2022-06-12 00:26:02.947614
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    def test_sorted_value():
        """
        Compare the group name to determine whether the group name of the plugin is sorted.
        """
        for group_name, group in pl.get_formatters_grouped().items():
            for i in range(len(group)-1):
                assert group[i].group_name < group[i+1].group_name
    
    def test_group_name():
        """
        Compare the group name and the group_name of the plugin to determine whether the plugin and the group name correspond
        """
        for group_name, group in pl.get_formatters_grouped().items():
            for i in range(len(group)):
                assert group[i].group_name == group_name
    
    pl = PluginManager()
    pl.load_installed_plugins()

    test_s

# Generated at 2022-06-12 00:26:08.491421
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pmanager = PluginManager()
    pmanager.register(
        FormatterPlugin, FormatterPlugin, FormatterPlugin, FormatterPlugin
    )
    assert len(pmanager.get_formatters_grouped()) == 1
    assert len(pmanager.get_formatters_grouped()['Output Processing']) == 4

# Generated at 2022-06-12 00:26:11.518644
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    assert len(pm) == 0

    pm.load_installed_plugins()
    assert len(pm) > 0

    for plugin in pm:
        assert hasattr(plugin, 'package_name')



# Generated at 2022-06-12 00:26:20.821450
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class NumsPlugin(BasePlugin):
        value = 0
    class IntPlugin(NumsPlugin):
        value = 1
    class StrPlugin(NumsPlugin):
        value = 'a'
    class BoolPlugin(NumsPlugin):
        value = True
    class FloatPlugin(NumsPlugin):
        value = 1.0

    pm = PluginManager()
    p_list = [IntPlugin, StrPlugin, BoolPlugin, FloatPlugin]
    pm.register(*p_list)
    assert pm.filter(NumsPlugin) == p_list
    assert pm.filter(int) == [IntPlugin]
    assert pm.filter(float) == [FloatPlugin]
    assert pm.filter(str) == [StrPlugin]
    assert pm.filter(bool) == [BoolPlugin]

# Generated at 2022-06-12 00:26:29.291418
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import auth
    from httpie.plugins import formatter
    from httpie.plugins import converter
    from httpie.plugins import transport
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm)
    assert(auth.BasicAuth in pm)
    assert(auth.DigestAuth in pm)
    assert(auth.Plugin in pm)
    assert(auth.AuthPlugin in pm)
    assert(auth.KerberosAuth in pm)
    assert(auth.OAuth1Auth in pm)
    assert(auth.OAuth2Auth in pm)
    assert(auth.JWTAuth in pm)
    assert(auth.PGPAuth in pm)
    assert(formatter.Plugin in pm)
    assert(formatter.FormatterPlugin in pm)

# Generated at 2022-06-12 00:27:55.254905
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(FormatterPlugin)
    pm.get_formatters()[0].group_name = 'test'

# Generated at 2022-06-12 00:27:58.921017
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(AuthPlugin)
    plugins.register(AuthPlugin)
    assert(len(plugins.get_auth_plugins()) == 2)
    assert(len(plugins.get_auth_plugin_mapping()) == 1)


# Generated at 2022-06-12 00:28:00.730747
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager != []




# Generated at 2022-06-12 00:28:03.313308
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(CSVPlugin, JSONPlugin, JUnitXMLPlugin)
    assert plugins.get_formatters_grouped() == {
        'data': [CSVPlugin, JSONPlugin, JUnitXMLPlugin]
    }

# Generated at 2022-06-12 00:28:09.443441
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin
    assert plugin_manager.filter(AuthPlugin) == []
    assert plugin_manager.filter(FormatterPlugin) == []
    assert plugin_manager.filter(ConverterPlugin) == []
    assert plugin_manager.filter() == []

    plugin_manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin,
                            BasePlugin)
    assert plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert plugin_manager.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugin_manager.filter(ConverterPlugin) == [ConverterPlugin]
    assert plugin_manager.filter() == [AuthPlugin, FormatterPlugin,
                                       ConverterPlugin, BasePlugin]

    plugin_manager.un

# Generated at 2022-06-12 00:28:12.056096
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert plugins.get_auth_plugin_mapping() == plugins.get_auth_plugins()


# Generated at 2022-06-12 00:28:14.396988
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin
    manager = PluginManager()
    manager.append('auth')
    manager.append('format')
    assert manager.filter() == [AuthPlugin]

# Generated at 2022-06-12 00:28:24.128637
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Arrange
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONDumper
    from httpie.core import JSON_ACCEPT
    from httpie.output.streams import OutputCapture
    from httpie.core import Response
    import json


    class Dumper(FormatterPlugin):
        group_name = 'Dumper'
        name = 'Dumper'
        content_types = [JSON_ACCEPT]
        output_streams = [OutputCapture]

        def format_body(self, body: str, **_) -> str:
            print(body)
            return 'Test'

    # Act
    PluginManager.get_formatters_grouped() == {
        'Dumper': list[JSONDumper(), Dumper()]
    }

    # Assert

# Generated at 2022-06-12 00:28:31.300447
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    # Before we run the method load_installed_plugins, the items in the PluginManager should be empty
    assert len(plugin_manager) == 0
    plugin_manager.load_installed_plugins()
    # After we run the method load_installed_plugins, the items in the PluginManager should not be empty
    assert len(plugin_manager) != 0
    assert any(isinstance(item, TransportPlugin) for item in plugin_manager)
    assert any(isinstance(item, AuthPlugin) for item in plugin_manager)
    assert any(isinstance(item, FormatterPlugin) for item in plugin_manager)
    assert any(isinstance(item, ConverterPlugin) for item in plugin_manager)

plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-12 00:28:33.141272
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie import plugins
    manager = PluginManager(plugins.__all__)
    assert len(manager.get_formatters_grouped()) >= 1
