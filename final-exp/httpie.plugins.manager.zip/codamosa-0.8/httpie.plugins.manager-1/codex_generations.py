

# Generated at 2022-06-12 00:19:47.417961
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # GIVEN
    testing_plugins = [
        type('TestPlugin1', (), {'package_name': 'test_package1'}),
        type('TestPlugin2', (), {'package_name': 'test_package2'}),
        type('TestPlugin3', (), {'package_name': 'test_package3'}),
        type('TestPlugin4', (), {'package_name': 'test_package4'}),
        type('TestPlugin5', (), {'package_name': 'test_package5'}),
        type('TestPlugin6', (), {'package_name': 'test_package6'})
    ]

    plugin_manager = PluginManager()

    # WHEN
    plugin_manager.register(*testing_plugins)
    plugin_manager.load_installed_plugins()

    # THEN

# Generated at 2022-06-12 00:19:52.380354
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin, AuthPlugin)
    plugins.register(FormatterPlugin, FormatterPlugin)
    
    assert len(plugins.filter(AuthPlugin)) == 2
    assert len(plugins.filter(FormatterPlugin)) == 2
    assert len(plugins.filter(BasePlugin)) == 4

# Generated at 2022-06-12 00:20:02.066454
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(aws_sigv4_auth.AWSSIGV4AuthPlugin, basic_auth.BasicAuthPlugin, digest_auth.DigestAuthPlugin,
                            hawk_auth.HawkAuthPlugin, htpasswd_auth.HTPasswdAuthPlugin, oauth1.OAuth1Plugin,
                            netrc_auth.NetrcAuthPlugin, multipart_auth.MultipartAuthPlugin)
    plugin_manager.get_auth_plugin_mapping()
    assert plugin_manager != None

# Generated at 2022-06-12 00:20:04.935774
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
#    assert plugin_manager.get_formatters_grouped() == {
#        'group_name': list(group)
#        for group_name, group
#        in groupby(self.formatters, key=attrgetter('group_name'))
#    }


# Generated at 2022-06-12 00:20:07.575147
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert plugin_manager.filter()[0] == BasePlugin
    assert plugin_manager.filter(AuthPlugin)[0] == AuthPlugin

# Generated at 2022-06-12 00:20:13.877349
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
	manager = PluginManager()
	manager.register(BasePlugin, AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
	
	assert manager.get_auth_plugins() == [AuthPlugin]
	assert manager.get_converters() == [ConverterPlugin]
	assert manager.get_formatters() == [FormatterPlugin]
	assert manager.get_transport_plugins() == [TransportPlugin]



# Generated at 2022-06-12 00:20:21.278230
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()

    # Mock all the plugins needed in unit tests
    class MockPlugin1(BasePlugin):
        pass

    class MockPlugin2(MockPlugin1):
        pass

    class MockPlugin3(MockPlugin2):
        pass

    plugins.register(MockPlugin1)
    plugins.register(MockPlugin2)
    plugins.register(MockPlugin3)

    return plugins.filter(MockPlugin2)

# Generated at 2022-06-12 00:20:24.418246
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(TransportPlugin)
    plugin_manager.register(AuthPlugin)
    assert plugin_manager.filter(TransportPlugin) != plugin_manager.filter(AuthPlugin)


# Generated at 2022-06-12 00:20:31.387934
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import HTMLFormatter

    class CustomPluginManager(PluginManager):
        def __init__(self):
            super().__init__()
            self.register(HTMLFormatter)

    custom_plugin_manager = CustomPluginManager()

    assert isinstance(custom_plugin_manager, PluginManager)
    assert isinstance(custom_plugin_manager.get_formatters_grouped(), dict)
    assert list(custom_plugin_manager.get_formatters_grouped()) == ['HTTP']
    assert custom_plugin_manager.get_formatters_grouped()['HTTP'] == [HTMLFormatter]

# Generated at 2022-06-12 00:20:34.184991
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert len(PluginManager().filter( ... ) == 0)
    assert len(PluginManager().filter(Type[BasePlugin]) == 0)


# Generated at 2022-06-12 00:20:45.166987
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, KeyValue, JSON
    from httpie.plugins.builtin import Stream
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPBasicAuth, KeyValue
    from httpie.plugins.builtin import HTTPiePlugin
    auth_plugin_list = [HTTPBasicAuth, JSON]
    converter_plugin_list = [HTTPBasicAuth, KeyValue, JSON, Stream]
    formatter_plugin_list = [HTTPBasicAuth, KeyValue, JSON, Stream]
    transport_plugin_list = [HTTPBasicAuth, KeyValue, JSON, Stream]
    manager = PluginManager()
    manager.register(HTTPiePlugin)
    manager.register(*auth_plugin_list)
    manager.register(*converter_plugin_list)
    manager.register

# Generated at 2022-06-12 00:20:54.738716
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class TestPlugin(BasePlugin):
        pass

    class TestPlugin1(BasePlugin):
        pass

    from httpie.plugins.base import AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin

    pm = PluginManager()
    pm.register(TestPlugin(), TestPlugin1(), AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert pm == [TestPlugin, TestPlugin1, AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    assert pm.filter(by_type=Type[BasePlugin]) == [TestPlugin, TestPlugin1, AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]
    assert pm.filter(by_type=Type[AuthPlugin]) == [AuthPlugin]

# Generated at 2022-06-12 00:21:03.568865
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth
    from httpie.plugins.builtin import HTTPDigestAuth, HTTPNTLMAuth
    from httpie.plugins.builtin import HTTPDigestAuth, HTTPNTLMAuth, HTTPMultipartEncoder
    from httpie.plugins.builtin import HTTPPassDigestAuth, HTTPPassNTLMAuth
    from httpie.plugins.builtin import HTTPPassBasicAuth, HTTPPassBearerAuth
    from httpie.plugins.builtin import HTTPProxyDigestAuth, HTTPProxyNTLMAuth
    from httpie.plugins.builtin import HTTPProxyBasicAuth, HTTPProxyBearerAuth
    from httpie.plugins.builtin import JSONEncoder, URLEncodedEncoder
    from httpie.plugins.builtin import PrettyJSONFormatter, UrlForm

# Generated at 2022-06-12 00:21:11.685462
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()

    formatters_grouped_dict = pluginManager.get_formatters_grouped()
    formatters_grouped_dict_sorted = dict(sorted(formatters_grouped_dict.items()))
    
    print(formatters_grouped_dict_sorted)
    

# Generated at 2022-06-12 00:21:18.010824
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    assert pm.get_formatters_grouped() == {}

    from httpie.plugins import builtin

    pm.register(builtin.PrettyJsonFormatter)
    pm.register(builtin.UrlencodedFormatter)

    # Note 重写了 FormatterPlugin 的 group_name 方法
    assert pm.get_formatters_grouped() == {
        'JSON': [builtin.PrettyJsonFormatter],
        'Urlencoded': [builtin.UrlencodedFormatter],
    }

# Generated at 2022-06-12 00:21:26.193133
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    class MockFormatterA(FormatterPlugin):
        group_name = 'A'
    class MockFormatterB(FormatterPlugin):
        group_name = 'B'
    class MockFormatterC(FormatterPlugin):
        group_name = 'C'
    class MockFormatterD(FormatterPlugin):
        group_name = 'D'
    class MockFormatterE(FormatterPlugin):
        group_name = 'E'
    class MockFormatterF(FormatterPlugin):
        group_name = 'F'
    plugin_manager.register(
        MockFormatterA,
        MockFormatterB,
        MockFormatterC,
        MockFormatterD,
        MockFormatterE,
        MockFormatterF,
    )

# Generated at 2022-06-12 00:21:29.333314
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    
    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:21:39.729565
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    for name in ['A', 'B', 'C', 'D', 'E', 'F']:
        class FormatterPluginTest(FormatterPlugin):
            group_name = 'Test'
            name = name
            description = name
        plugin_manager.register(FormatterPluginTest)
    for name in ['X', 'Y', 'Z']:
        class FormatterPluginTest(FormatterPlugin):
            group_name = 'TestUnit'
            name = name
            description = name
        plugin_manager.register(FormatterPluginTest)
    result = plugin_manager.get_formatters_grouped()

# Generated at 2022-06-12 00:21:43.436248
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {}
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {}


# Generated at 2022-06-12 00:21:50.795419
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    import httpie.plugins
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin,TranSporPlugin
    import httpie.output
    from httpie.output import OutputOptions, ColorMode
    import random
    plugin = PluginManager()
    plugin.register(AuthPlugin)
    plugin.register(ConverterPlugin)
    plugin.register(FormatterPlugin)
    plugin.register(TranSporPlugin)
    print(plugin.filter())

# Generated at 2022-06-12 00:21:57.995170
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(JsonFormatter, HtmlFormatter)
    manager.register(JsonLinesFormatter, JsonFormatter)
    manager.register(JsonFormatter)
    manager.register(JsonLinesFormatter)

    assert manager.get_formatters_grouped() == {
        'json': [JsonFormatter, JsonFormatter],
        'json-lines': [JsonLinesFormatter, JsonLinesFormatter],
        'html': [HtmlFormatter]
    }


# Generated at 2022-06-12 00:22:01.431401
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    assert plugin_manager[0].__name__ == 'NetrcAuthPlugin'


# Generated at 2022-06-12 00:22:03.629246
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    p = PluginManager()
    assert isinstance(p.get_auth_plugin_mapping(), dict)

# Generated at 2022-06-12 00:22:12.762416
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPluginSub(FormatterPlugin):
        group_name = 'Sub'

    class FormatterPlugin1(FormatterPlugin):
        group_name = 'Sub'

    class FormatterPlugin2(FormatterPlugin):
        group_name = 'Sub'

    class FormatterPlugin3(FormatterPlugin):
        group_name = 'Sub1'

    manager = PluginManager()
    manager.register(FormatterPluginSub, FormatterPlugin1, FormatterPlugin2, FormatterPlugin3)

    assert manager.get_formatters_grouped() == {
        'Sub': [FormatterPluginSub, FormatterPlugin1, FormatterPlugin2],
        'Sub1': [FormatterPlugin3]
    }

# Generated at 2022-06-12 00:22:21.206940
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import httpie.plugins
    from pkg_resources import iter_entry_points
    from unittest.mock import patch
    import sys

    # Fixtures
    ENTRY_POINT_NAMES = [
        'httpie.plugins.auth.v1',
        'httpie.plugins.formatter.v1',
        'httpie.plugins.converter.v1',
        'httpie.plugins.transport.v1',
    ]

    # Mocking
    # Disable httpie.plugins.__init__.py
    sys.modules['httpie.plugins'] = None # type: ignore

    # Setup: Mocking iter_entry_points
    mocked_iter_entry_points = [] # type: ignore
    for entry_point_name in ENTRY_POINT_NAMES:
        mocked_iter_entry_

# Generated at 2022-06-12 00:22:25.319331
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    assert len(plugin_manager) == 0
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:22:29.613768
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    p1 = PluginManager()
    p1.register()
    assert p1.get_formatters_grouped() == {}

    class Foo(FormatterPlugin):
        group_name = 'group_name'

    p2 = PluginManager()
    p2.register(Foo)
    assert p2.get_formatters_grouped() == {'group_name': [Foo]}

# Generated at 2022-06-12 00:22:34.370805
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:22:42.459468
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.register(AuthPlugin, ConverterPlugin, FormatterPlugin, TransportPlugin)
    auth = plugin_manager.filter(by_type=AuthPlugin)
    formatter = plugin_manager.filter(by_type=FormatterPlugin)
    converter = plugin_manager.filter(by_type=ConverterPlugin)
    transport = plugin_manager.filter(by_type=TransportPlugin)
    assert(auth == [AuthPlugin])
    assert(formatter == [FormatterPlugin])
    assert(converter == [ConverterPlugin])
    assert(transport == [TransportPlugin])

# Generated at 2022-06-12 00:22:48.575672
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()
    grouped_formatters = manager.get_formatters_grouped()
    assert len(grouped_formatters) == 2
    assert grouped_formatters["group1"] == [HTTPieJSONFormatter(), JSONFormatter(), PrettyJSONFormatter()]
    assert grouped_formatters["group2"] == [JUnitFormatter(), XMLFormatter()]

# Generated at 2022-06-12 00:22:58.013462
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
	pm = PluginManager()
	pm.register(AuthPlugin)	
	pm.register(FormatterPlugin)	
	pm.register(ConverterPlugin)	
	pm.register(TransportPlugin)
	print(pm.filter(AuthPlugin))
	print(pm.filter(FormatterPlugin))
	print(pm.filter(ConverterPlugin))
	print(pm.filter(TransportPlugin))



# Generated at 2022-06-12 00:23:08.154503
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():

    import json

    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import DigestAuth
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import ConverterPlugin

    plugin_manager = PluginManager()

    plugin_manager.register(HTTPBasicAuth)
    plugin_manager.register(DigestAuth)
    assert plugin_manager.get_auth_plugins() == [HTTPBasicAuth, DigestAuth]
    assert (plugin_manager.get_auth_plugin_mapping() == {
        'basic': HTTPBasicAuth,
        'digest': DigestAuth
    })
    assert plugin_manager.get_auth_plugin('basic') == HTTPBasicAuth

    plugin

# Generated at 2022-06-12 00:23:17.322745
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    assert pm.filter(by_type=Type[BasePlugin]) == []
    pm.register(BasePlugin)
    assert pm.filter(by_type=Type[BasePlugin]) == [BasePlugin]
    pm.register(TransportPlugin)
    assert pm.filter(by_type=Type[TransportPlugin]) == [TransportPlugin]
    assert pm.filter(by_type=Type[BasePlugin]) == [BasePlugin, TransportPlugin]
    pm.unregister(BasePlugin)
    assert pm.filter(by_type=Type[BasePlugin]) == [TransportPlugin]
    assert pm.filter(by_type=Type[TransportPlugin]) == [TransportPlugin]

# Generated at 2022-06-12 00:23:28.652545
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.colors import (
        BasicAuthPlugin,
        GrepFormatter,
    )
    from httpie.plugins.builtin import HTTPFormatter
    from httpie.plugins.human import (
        ChunkedFormatter,
        HighlightPlugin,
        PrettyJsonFormatter,
        TableFormatter,
    )
    manager = PluginManager()
    manager.extend([
        BasicAuthPlugin,
        GrepFormatter,
        ChunkedFormatter,
        HighlightPlugin,
        PrettyJsonFormatter,
        TableFormatter,
        HTTPFormatter,
        JSONFormatter
    ])

# Generated at 2022-06-12 00:23:39.934039
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    mgr = PluginManager()
    for entry_point_name in ENTRY_POINT_NAMES:
        for entry_point in iter_entry_points(entry_point_name):
            plugin = entry_point.load()
            plugin.package_name = entry_point.dist.key
            mgr.register(plugin)

# Generated at 2022-06-12 00:23:43.735356
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-12 00:23:47.989671
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class AuthPluginSubclass(AuthPlugin):
        pass
    auth_plugin = AuthPluginSubclass
    pm = PluginManager()
    pm.register(auth_plugin)
    assert auth_plugin in pm.filter(AuthPlugin)
    assert auth_plugin not in pm.filter(Type[BasePlugin])


# Generated at 2022-06-12 00:23:52.906803
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin

    manager = PluginManager()
    manager.register(JSONFormatterPlugin, URLEncodedFormatterPlugin)
    assert manager.get_formatters_grouped() == {
        'builtin': [JSONFormatterPlugin, URLEncodedFormatterPlugin]
    }

# Generated at 2022-06-12 00:24:03.928364
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(JsonFormatterPlugin)
    plugin_manager.register(JsonLinesFormatterPlugin)
    plugin_manager.register(JsonLinesStdoutFormatterPlugin)
    plugin_manager.register(JsonStdoutFormatterPlugin)
    plugin_manager.register(JsonTruncatedFormatterPlugin)
    plugin_manager.register(JUnitXmlFormatterPlugin)
    plugin_manager.register(NullFormatterPlugin)
    plugin_manager.register(PrettyFormatterPlugin)
    plugin_manager.register(RawFormatterPlugin)
    plugin_manager.register(TarFormatterPlugin)
    plugin_manager.register(TeeFormatterPlugin)
    plugin_manager.register(ToFileFormatterPlugin)

# Generated at 2022-06-12 00:24:06.442893
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 2
    assert len(plugin_manager.get_auth_plugins()) == 2


# Generated at 2022-06-12 00:24:15.450440
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():

    manager = PluginManager()
    manager.register(*ENTRY_POINT_NAMES)

    from httpie.plugins import FormatterPlugin

    assert len(manager.filter(FormatterPlugin)) == 1

# Generated at 2022-06-12 00:24:21.699846
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONPathFormatter
    from httpie.plugins.builtin import JSONFormatter
    plugins = PluginManager()
    plugins.register(JSONPathFormatter, JSONFormatter)
    assert plugins.get_formatters_grouped() == {'gen': [JSONFormatter], 'path': [JSONPathFormatter]}


# Generated at 2022-06-12 00:24:27.000629
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-12 00:24:31.819312
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager)>=3
    assert len(pluginManager.filter(AuthPlugin))>=1
    assert len(pluginManager.filter(ConverterPlugin))>=1
    assert len(pluginManager.filter(TransportPlugin))>=1


# Generated at 2022-06-12 00:24:36.291557
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.append(BasePlugin)
    plugin_manager.register(AuthPlugin, FormatterPlugin)
    assert plugin_manager == [AuthPlugin, FormatterPlugin, BasePlugin]


# Generated at 2022-06-12 00:24:43.833010
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(mock.Mock(**{'group_name': 'alpha'}))
    plugins.register(mock.Mock(**{'group_name': 'alpha'}))
    plugins.register(mock.Mock(**{'group_name': 'beta'}))
    plugins.register(mock.Mock(**{'group_name': 'beta'}))
    plugins.register(mock.Mock(**{'group_name': 'beta'}))
    grouped_formatters = plugins.get_formatters_grouped()
    assert grouped_formatters['alpha'] == [mock.Mock(**{'group_name': 'alpha'}), mock.Mock(**{'group_name': 'alpha'})]

# Generated at 2022-06-12 00:24:48.989119
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    def test_type():
        obj = PluginManager()
        obj.register(TransportPlugin)
        assert obj.filter(TransportPlugin) == obj[0]

    def test_none_type():
        obj = PluginManager()
        obj.register(TransportPlugin)
        assert obj.filter(None) == []

# Unit test method get_auth_plugins of class PluginManager

# Generated at 2022-06-12 00:24:56.101106
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()

    mapping = pm.get_auth_plugin_mapping()
    assert "basic" in mapping
    assert "digest" in mapping
    assert "hawk" in mapping
    assert "ntlm" in mapping
    assert "aws4" in mapping
    assert "awsv4" in mapping
    assert "oauth1" in mapping
    assert "oauth2" in mapping
    assert "jwt" in mapping

# Generated at 2022-06-12 00:25:03.951993
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register(BashColors)
    pm.register(Colors)
    pm.register(Json)
    pm.register(Null)
    pm.register(ServerLog)
    pm.register(Table)
    assert len(pm.get_formatters_grouped()) == 4
    assert "Grouped" in pm.get_formatters_grouped()
    assert Colors in pm.get_formatters_grouped()["Grouped"]

# Generated at 2022-06-12 00:25:06.695023
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert (PluginManager().get_formatters_grouped()) == {
        "Converters": [],
        "Formats": [],
        "Help": []
    }


# Generated at 2022-06-12 00:25:23.011614
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert issubclass(plugin_manager[0], BasePlugin)

# Generated at 2022-06-12 00:25:25.597665
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    # TODO: create a dummy plugin
    # plugin_manager.register(DummyPlugin)
    assert plugin_manager.filter(DummyPlugin) == []

# Generated at 2022-06-12 00:25:35.471293
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_manager = PluginManager()
    plugins_manager.register(AuthPlugin, FormatterPlugin, ConverterPlugin,
                             TransportPlugin)
    assert len(plugins_manager.get_formatters_grouped()) == 0

    plugins_manager.register(ExampleFormatter)
    assert len(plugins_manager.get_formatters_grouped()) == 1

    plugins_manager.register(HelloFormatter)
    assert len(plugins_manager.get_formatters_grouped()) == 1

    plugins_manager.register(AnotherExampleFormatter)
    assert len(plugins_manager.get_formatters_grouped()) == 1

    plugins_manager.register(ZebraFormatter)
    assert len(plugins_manager.get_formatters_grouped()) == 2



# Generated at 2022-06-12 00:25:40.983526
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(CustomFormatter, CustomFormatter2)
    options = {}
    print("PluginManager is :", plugins)
    print("The formatters are :", plugins.get_formatters())
    print("The formatters grouped:", plugins.get_formatters_grouped())
    return plugins.get_formatters_grouped()

# Generated at 2022-06-12 00:25:51.718045
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    auth_plugins = plugin_manager.get_auth_plugins()
    # if not empty
    assert len(auth_plugins) != 0
    for plugin in auth_plugins:
        assert hasattr(plugin, 'auth_type')
    formatters = plugin_manager.get_formatters()
    assert len(formatters) != 0
    for plugin in formatters:
        assert hasattr(plugin, 'group_name')
        assert hasattr(plugin, 'output_type')
    converters = plugin_manager.get_converters()
    assert len(converters) != 0
    for plugin in converters:
        assert hasattr(plugin, 'content_type')
    transports = plugin_manager.get_transport_plugins()
    assert len

# Generated at 2022-06-12 00:25:53.685927
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-12 00:25:54.766392
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    assert manager == []
    manager.load_installed_plugins()
    assert manager != []

# Generated at 2022-06-12 00:25:59.393645
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, BuiltinFormatterPlugin
    pm = PluginManager()
    pm.register(JSONFormatterPlugin, BuiltinFormatterPlugin)
    assert pm.get_formatters_grouped() == {
        'json': [JSONFormatterPlugin],
        'other': [BuiltinFormatterPlugin],
    }

# Generated at 2022-06-12 00:26:10.159389
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    shell = PluginManager()
    assert isinstance(shell.filter(AuthPlugin), list)
    assert isinstance(shell.filter(FormatterPlugin), list)
    assert isinstance(shell.filter(ConverterPlugin), list)
    assert isinstance(shell.filter(TransportPlugin), list)

shell = PluginManager()
assert isinstance(shell.get_auth_plugins(), list)
assert isinstance(shell.get_auth_plugin_mapping(), dict)
assert isinstance(shell.get_formatters(), list)
assert isinstance(shell.get_converters(), list)
assert isinstance(shell.get_transport_plugins(), list)
assert isinstance(shell.get_formatters_grouped(), dict)

# Generated at 2022-06-12 00:26:13.023054
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    assert isinstance(pm, PluginManager)
    assert pm.filter() == []
    assert pm.filter(by_type = int) == []
    assert pm.filter(by_type = BasePlugin) == []
    assert pm.filter(by_type = PluginManager) == []



# Generated at 2022-06-12 00:26:43.554361
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert "PluginManager: []" not in repr(pm)

# Generated at 2022-06-12 00:26:53.743745
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-12 00:26:58.731179
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    assert pm.get_formatters_grouped() == {}
    pm.register(FormatterPlugin)
    assert pm.get_formatters_grouped() == {'FormatterPlugin': [FormatterPlugin]}
    pm.register(FormatterPlugin)
    assert pm.get_formatters_grouped() == {'FormatterPlugin': [FormatterPlugin, FormatterPlugin]}

# Generated at 2022-06-12 00:27:03.976810
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pluginmanager = PluginManager()
    for plugin in [BasicAuthPlugin, DigestAuthPlugin]:
        pluginmanager.register(plugin)
    print(pluginmanager.get_auth_plugin_mapping())
    assert pluginmanager.get_auth_plugin_mapping()['basic'] == BasicAuthPlugin


# Generated at 2022-06-12 00:27:09.454452
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    for i in range(4):
        pm = PluginManager()
        pm.register(SocksHTTPDefaultAdapter)
        p1 = pm.filter(by_type=SocksHTTPDefaultAdapter)
        p2 = pm.filter()
        print(p1, p2)


if __name__ == '__main__':
    test_PluginManager_filter()

# Generated at 2022-06-12 00:27:16.762288
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.auth.multipart import MultipartAuth
    from httpie.plugins.auth.ntlm import NTLMAuth
    from httpie.plugins.auth.jwt import JWTAuth
    from httpie.plugins.auth.spnego import SPNEGOAuth
    from httpie.plugins.auth.hawk import HawkAuth
    from httpie.plugins.auth.aws import AWSAuth
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    print(plugin_manager.get_auth_plugin_mapping())

# Generated at 2022-06-12 00:27:27.006418
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class Dummy_plugins(FormatterPlugin):
        def __init__(self, group_name):
            self.group_name = group_name
        def __repr__(self):
            return f'<Dummy_plugins: {self.group_name}>'
    #register plugins
    manager = PluginManager()
    manager.register(Dummy_plugins('default'))
    manager.register(Dummy_plugins('default'))
    manager.register(Dummy_plugins('another'))
    #test get_formatters_grouped
    result = manager.get_formatters_grouped()
    assert isinstance(result, dict)
    assert len(result) == 2
    assert 'default' in result
    assert isinstance(result['default'], list)
    assert len

# Generated at 2022-06-12 00:27:36.992443
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    from tests import httpie_plugins_sort_output as plugin_sort
    from tests import httpie_plugins_ansi as plugin_ansi
    from tests import httpie_plugins_highlight as plugin_highlight

    class OutputPlugin(FormatterPlugin): pass
    class DefaultOutputPlugin(OutputPlugin): pass
    class PipeOutputPlugin(OutputPlugin): pass
    class ColorizeOutputPlugin(OutputPlugin): pass
    class IndentOutputPlugin(OutputPlugin): pass

    pm = PluginManager()
    pm.register(
        OutputPlugin,
        DefaultOutputPlugin,
        PipeOutputPlugin,
        ColorizeOutputPlugin,
        IndentOutputPlugin,
        plugin_sort.SortOutputPlugin,
        plugin_ansi.AnsiPlugin,
        plugin_highlight.HighlightPlugin
    )


# Generated at 2022-06-12 00:27:48.657630
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(TestBASICAuthPlugin, TestAWSAuthPlugin)
    
    assert len(pm) == 2
    assert pm[0] == TestBASICAuthPlugin
    assert pm[1] == TestAWSAuthPlugin

    pm.unregister(TestBASICAuthPlugin)
    assert len(pm) == 1
    assert pm[0] == TestAWSAuthPlugin

    assert (pm.get_auth_plugin_mapping() ==
        {'basic': TestBASICAuthPlugin, 'aws': TestAWSAuthPlugin}
    )

    assert (pm.get_auth_plugin('basic') ==
        TestBASICAuthPlugin
    )

    assert (pm.get_auth_plugin('aws') ==
        TestAWSAuthPlugin
    )


# Generated at 2022-06-12 00:27:57.326452
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie.plugins.manager as manager
    mgr = manager.PluginManager()
    mgr.register(
        manager.Plugin,
        manager.GenericPlugin,
        manager.FormatterPlugin,
        manager.JSONFormatter,
        manager.URLEncodedFormatter,
        manager.JSONCompactFormatter,
        manager.JSONPointerFormatter,
        manager.XMLFormatter,
        manager.HTMLFormatter,
        manager.TerminalFormatter,
        manager.PipedTerminalFormatter,
        manager.ImageFormatter,
        manager.AutoJSONFormatter,
    )
    mgr.get_formatters_grouped()

# Generated at 2022-06-12 00:29:12.973806
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    test_plugin_manager = PluginManager()

    # register 向 plugins 中添加插件
    test_plugin_manager.register(TestFormatter, TestFormatter_2, TestFormatter_3)

    # get_formatters 获得 plugins 中格式化插件
    formatters = test_plugin_manager.get_formatters()

    # get_formatters_grouped 将格式化插件按组分类
    formatters_groups = test_plugin_manager.get_formatters_grouped()

    # 显示结果
    print("formatters:", formatters)
    print("formatters_gropus:", formatters_groups)



# Generated at 2022-06-12 00:29:16.746658
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    p = PluginManager()
    p.append(1)
    p.append(1)
    p.append(2)
    p.append(3)

    assert p.get_formatters_grouped() == {'1': [1, 1], '2': [2], '3': [3]}

# Generated at 2022-06-12 00:29:22.022017
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin,\
        PrettyJsonFormatterPlugin
    pm = PluginManager()
    pm.register(JSONFormatterPlugin)
    pm.register(PrettyJsonFormatterPlugin)
    result = pm.get_formatters_grouped()
    expected = {'JSON': [JSONFormatterPlugin, PrettyJsonFormatterPlugin]}
    assert result == expected

# Generated at 2022-06-12 00:29:29.265584
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.register(
        FormatterPlugin_GroupA_1,
        FormatterPlugin_GroupA_2,
        FormatterPlugin_GroupB_1,
        FormatterPlugin_GroupB_2,
        FormatterPlugin_GroupB_3,
    )
    group_a = list(manager.get_formatters_grouped().get('GroupA'))
    group_b = list(manager.get_formatters_grouped().get('GroupB'))
    assert len(group_a) == 2
    assert len(group_b) == 3



# Generated at 2022-06-12 00:29:38.166695
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_list = []
    plugins_list.extend([FormatterPlugin(), FormatterPlugin(), FormatterPlugin])

    class FormatterPlugin1(FormatterPlugin):
        group_name = 'group1'
    plugins_list.append(FormatterPlugin1)
    
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'group2'
    plugins_list.append(FormatterPlugin2)
    
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'group1'
    plugins_list.append(FormatterPlugin3)

    plugins = PluginManager()
    plugins.register(*plugins_list)
    assert plugins.get_formatters_grouped() == {'group1': [FormatterPlugin1, FormatterPlugin3], 'group2': [FormatterPlugin2]}
