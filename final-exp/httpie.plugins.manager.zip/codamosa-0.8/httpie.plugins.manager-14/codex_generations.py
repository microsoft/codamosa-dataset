

# Generated at 2022-06-12 00:19:40.571174
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    entry_point_name = 'httpie.plugins.auth.v1'
    for entry_point in iter_entry_points(entry_point_name):
        plugin = entry_point.load()
        pm = PluginManager()
        pm.append(plugin)
        pm.get_auth_plugin_mapping()
        print('success!')
    return 'test_get_auth_plugin_mapping'


# Generated at 2022-06-12 00:19:42.565735
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager



# Generated at 2022-06-12 00:19:51.613611
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    from httpie.plugins import auth
    pm.register(auth.BasicAuth)
    pm.register(auth.DigestAuth)
    pm.register(auth.HawkAuth)
    pm.register(auth.NegotiateAuth)
    pm.register(auth.OAuth1AuthPlugin)
    pm.register(auth.OAuth2AuthPlugin)
    pm.register(auth.AWSAuth)

# Generated at 2022-06-12 00:19:58.242150
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()

    # simulating the following plugins:
    # for httpie.plugins.formatter.v1
    plugins.register(HttpiePlugin) # from httpie
    plugins.register(HttpiePlugin) # from httpie
    # for httpie.pulgins.auth.v1
    plugins.register(HttpiePlugin2) # from httpie

    grouped_formatters = {
        "from httpie": [HttpiePlugin, HttpiePlugin],
    }
    # grouped_formatters = {
    #     "from httpie": [HttpiePlugin, HttpiePlugin],
    #     "from other": [OtherPlugin],
    # }

    assert plugins.get_formatters_grouped() == grouped_formatters


# Generated at 2022-06-12 00:20:05.694382
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Instance of PluginManager
    plugin_manager = PluginManager()

    import sys
    # To check whether the response is equal to expected or not
    if sys.version_info >= (3, 8):
        assert plugin_manager.get_auth_plugin_mapping() == {}
    else:
        assert eval(repr(plugin_manager.get_auth_plugin_mapping())) == {}


# Generated at 2022-06-12 00:20:07.604148
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert next(iter(manager.get_auth_plugins())).auth_type == 'basic'

# Generated at 2022-06-12 00:20:12.703334
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(BasePlugin)
    plugins.register(FormatterPlugin)
    plugins.register(TransportPlugin)

    assert plugins.filter(TransportPlugin) == [TransportPlugin]
    assert plugins.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugins.filter() == [BasePlugin, FormatterPlugin, TransportPlugin]



# Generated at 2022-06-12 00:20:16.737505
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager) > 0

if __name__ == "__main__":
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:20:24.128305
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Empty PluginManager
    plugin_manager = PluginManager()
    assert plugin_manager.filter(by_type=TransportPlugin) == []
    # PluginManager with plugins
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth
    plugin_manager.register(HTTPBasicAuth, HTTPDigestAuth)
    assert len(plugin_manager.filter(by_type=AuthPlugin)) == 2
    assert len(plugin_manager.filter(by_type=TransportPlugin)) == 0


# Generated at 2022-06-12 00:20:27.503234
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(1,2,3,4)
    assert plugins.filter(by_type=int) == [1,2,3,4]


# Generated at 2022-06-12 00:20:39.549614
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    #print(pm)
    print('\nFormatters:')
    print(pm.get_formatters())
    print('\nAuth:')
    print(pm.get_auth_plugin_mapping())
    print('\nTransport:')
    print(pm.get_transport_plugins())
    print('\nConverters:')
    print(pm.get_converters())
    print('\nFormatters Grouped:')
    print(pm.get_formatters_grouped())


if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:20:41.142225
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert PluginManager().load_installed_plugins() is not None



# Generated at 2022-06-12 00:20:43.446231
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    print(pm)

# Generated at 2022-06-12 00:20:44.340645
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    return


# Generated at 2022-06-12 00:20:50.938475
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    plugin_manager = PluginManager()
    plugin_manager.register(BasePlugin, HTTPDigestAuth, HTTPBasicAuth)
    plugin_manager.filter(AuthPlugin)

if __name__ == '__main__':
    test_PluginManager_filter()

# Generated at 2022-06-12 00:20:53.685971
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}
    assert PluginManager([None]).get_auth_plugin_mapping() == {}
    assert PluginManager([int()]).get_auth_plugin_mapping() == {}

# Generated at 2022-06-12 00:21:02.635040
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import pytest
    from httpie.plugins import FormatterPlugin

    class Test1(FormatterPlugin):
        group_name="Test"
        format_name="1"
        just="1"

    class Test2(FormatterPlugin):
        group_name="Test"
        format_name="2"
        just="2"

    class Test3(FormatterPlugin):
        group_name="Test2"
        format_name="3"
        just="3"

    plugin_manager = PluginManager()
    plugin_manager.register(Test1, Test2, Test3)

    assert plugin_manager.get_formatters_grouped() == {
        'Test': [Test1, Test2],
        'Test2': [Test3]
    }



# Generated at 2022-06-12 00:21:06.373409
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager=PluginManager()
    manager.register(manager)
    manager.load_installed_plugins()
    print(manager.get_converters())
    print(manager.get_formatters())


# Generated at 2022-06-12 00:21:14.283520
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    plugins_class_name = [type(plugin).__name__ for plugin in plugins]
    assert "Colorize" in plugins_class_name
    assert "Headers" in plugins_class_name
    assert "PrettyPlugin" in plugins_class_name
    assert "CurlConverter" in plugins_class_name
    assert "SessionRedirectMixin" in plugins_class_name


# Generated at 2022-06-12 00:21:22.826129
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()

# Generated at 2022-06-12 00:21:26.311622
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(BasePlugin)
    assert manager.filter() == [BasePlugin]

# Generated at 2022-06-12 00:21:34.119308
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.plugins.httpie.httpie_auth_plugin import HTTPBasicAuth, HTTPTokenAuth
    p = PluginManager()
    p.register(HTTPBasicAuth, HTTPTokenAuth)
    x = p.get_auth_plugin_mapping()

# Generated at 2022-06-12 00:21:39.242964
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FormatPluginA, FormatPluginB, FormatPluginC)
    assert plugin_manager.get_formatters_grouped() == {
        'First Group': [FormatPluginA],
        'First Group': [FormatPluginB],
        'First Group': [FormatPluginC]
    }


# Generated at 2022-06-12 00:21:41.550201
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_mapping = PluginManager().get_auth_plugin_mapping()

    # Check if there is only one HTTPBasicAuth plugin
    assert(len(plugin_mapping) == 1 and "HTTPBasicAuth" in plugin_mapping)


# Generated at 2022-06-12 00:21:45.609541
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    assert(pm)
    assert(pm.get_auth_plugins())
    assert(pm.get_formatters())
    assert(pm.get_converters())
    assert(pm.get_transport_plugins())

# Generated at 2022-06-12 00:21:52.155581
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Prepare
    manager = PluginManager()
    # Act
    manager.load_installed_plugins()

    # Assert
    assert len(manager) > 0
    assert len(manager.get_auth_plugins()) > 0
    assert len(manager.get_formatters()) > 0
    assert len(manager.get_converters()) > 0
    assert len(manager.get_transport_plugins()) > 0

# Generated at 2022-06-12 00:21:53.607607
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# Generated at 2022-06-12 00:21:58.036800
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class MyPlugin(BasePlugin):
        pass

    class MyPlugin2(MyPlugin):
        pass

    class MyPlugin3(MyPlugin):
        pass

    class MyPlugin4(BasePlugin):
        pass

    pm = PluginManager()
    pm.register(MyPlugin, MyPlugin2, MyPlugin3, MyPlugin4)
    matching_plugins = pm.filter(MyPlugin)
    assert (matching_plugins == [MyPlugin, MyPlugin2, MyPlugin3])

# Generated at 2022-06-12 00:21:59.443227
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()


plugin_manager = PluginManager()

# Generated at 2022-06-12 00:22:02.148726
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.objects = PluginManager()
    PluginManager.objects.load_installed_plugins()
    n = len(PluginManager.objects)
    print(n)


# Generated at 2022-06-12 00:22:07.489288
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert p


# Generated at 2022-06-12 00:22:13.528995
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie import plugins
    from httpie.plugins.core import AuthPlugin, FormatterPlugin, ConverterPlugin
    from httpie.plugins.core import TransportPlugin
    auth = plugins.manager.filter(AuthPlugin)
    assert isinstance(auth, list)
    formatter = plugins.manager.filter(FormatterPlugin)
    assert isinstance(formatter, list)
    converter = plugins.manager.filter(ConverterPlugin)
    assert isinstance(converter, list)
    transport = plugins.manager.filter(TransportPlugin)
    assert isinstance(transport, list)

# Generated at 2022-06-12 00:22:16.556993
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    # At least one plugin should be loaded successfully
    assert len(plugin_manager) > 0



# Generated at 2022-06-12 00:22:27.546097
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class formatter1(FormatterPlugin):
        group_name = 'basic'
    class formatter2(FormatterPlugin):
        group_name = 'basic'
    class formatter3(FormatterPlugin):
        group_name = 'pretty'
    class formatter4(FormatterPlugin):
        group_name = 'pretty'
    class formatter5(FormatterPlugin):
        group_name = 'pretty'
    pm = PluginManager()
    pm.register(formatter1, formatter2, formatter3, formatter4, formatter5)
    answer = {
        'basic': [formatter1, formatter2],
        'pretty': [formatter3, formatter4, formatter5],
    }
    assert pm.get_formatters_grouped() == answer

# Generated at 2022-06-12 00:22:35.614164
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin_1(BasePlugin):
        pass
    class Plugin_2(BasePlugin):
        pass
    class Plugin_3(BasePlugin):
        pass
    class Plugin_4(BasePlugin):
        pass

    suite = PluginManager()

    suite.register(Plugin_1, Plugin_2, Plugin_3, Plugin_4)
    # Plugin_2 and Plugin_3 are both children of Plugin_1
    assert suite.filter(Plugin_1) == [Plugin_1, Plugin_2, Plugin_3]

# Generated at 2022-06-12 00:22:44.235392
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    def mock_iter_entry_points(group=None):
        # group is group name of plugins
        # 3 groups: auth, formatter & converter
        return [
            Mock(group=group, load=lambda: PluginManager.auth_plugin()),
            Mock(group=group, load=lambda: PluginManager.auth_plugin()),
        ]

    def mock_filter(*args, **kwargs):
        class Plugin:
            group = list(args)[0]
        return [Plugin, Plugin]


# Generated at 2022-06-12 00:22:49.824811
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    
    # Arrange
    plugin_manager_mock = PluginManager()
    
    plugin_manager_mock.load_installed_plugins() #Execute SUT

    result = [plugin_manager_mock.append(plugin) for plugin in plugin_manager_mock]

    # Act
    expected = []

    # Assert
    assert result == expected

# Generated at 2022-06-12 00:22:52.011853
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    assert(len(plugins) == 0)
    plugins.load_installed_plugins()
    assert(len(plugins) > 0)

# Generated at 2022-06-12 00:22:58.013829
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import pytest
    from httpie.plugins import FormatterPlugin, ConverterPlugin
    from httpie.output.formatters.colors import Base16Formatter, ColorFormatter
    from httpie.compat import is_py36

    class TestFormatterPlugin(FormatterPlugin):
        group_name = 'test'

    class TestFormatterPlugin_1(FormatterPlugin):
        group_name = 'test_1'

    class TestFormatterPlugin_2(FormatterPlugin):
        group_name = 'test_2'

    class TestFormatterPlugin_2_1(FormatterPlugin):
        group_name = 'test_2'

    class TestConverterPlugin(ConverterPlugin):
        pass

    class TestConverterPlugin_1(ConverterPlugin):
        pass

    # formatter plugin have group_name


# Generated at 2022-06-12 00:23:01.851129
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager() == []
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager == PluginManager()  # Does the load_installed_plugins() method work?
    assert plugin_manager.get_formatters_grouped() != []  # The output should be non-empty

# Generated at 2022-06-12 00:23:09.518103
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    assert pm.load_installed_plugins()


# Generated at 2022-06-12 00:23:17.970017
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    available_auths = plugin_manager.get_auth_plugins()
    available_formatters = plugin_manager.get_formatters()
    available_converters = plugin_manager.get_converters()
    available_transports = plugin_manager.get_transport_plugins()
    assert len(available_auths)>0
    assert len(available_formatters)>0
    assert len(available_converters)>0
    assert len(available_transports)>0

test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:23:26.497330
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm_1 = PluginManager()
    pm_1.append(1)
    pm_1.append(2)
    pm_1.append(3)
    assert pm_1.get_formatters_grouped() == {'All': [1, 2, 3]}

    pm_2 = PluginManager()
    pm_2.append('a')
    pm_2.append('b')
    pm_2.append('c')
    assert pm_2.get_formatters_grouped() == {'All': ['a', 'b', 'c']}

# Generated at 2022-06-12 00:23:28.802045
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.append(AuthPlugin)
    pm.append(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {'basic': AuthPlugin}

# Generated at 2022-06-12 00:23:32.222236
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert PluginManager().__repr__() == manager.__repr__() == '<PluginManager: []>'

# Generated at 2022-06-12 00:23:37.419579
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()
    auth_plugin_mapping = {'basic': httpie.plugins.auth.BasicAuthPlugin, 'digest': httpie.plugins.auth.DigestAuthPlugin}
    assert pm.get_auth_plugin_mapping() == auth_plugin_mapping


# Generated at 2022-06-12 00:23:39.369899
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:23:50.946820
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    mgr = PluginManager()
    assert mgr.get_formatters_grouped() == {}
    mgr.register(
        BasePlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
    )

    class A(FormatterPlugin):
        group_name = 'Group A'
        group_title = 'Group Title A'

    class B(FormatterPlugin):
        group_name = 'Group B'
        group_title = 'Group Title B'

    class C(FormatterPlugin):
        group_name = 'Group C'
        group_title = 'Group Title C'

    class C2(FormatterPlugin):
        group_name = 'Group C'
        group_title = 'Group Title C2'


# Generated at 2022-06-12 00:23:53.915444
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugins()
    assert manager.get_formatters()
    assert manager.get_converters()
    assert manager.get_transport_plugins()

plugins = PluginManager()

# Generated at 2022-06-12 00:24:02.602705
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import httpie
    pm = httpie.plugins.manager.PluginManager()
    pm.load_installed_plugins()
    assert pm.get_formatters_grouped() == {
        'JSON': [httpie.plugins.formatter.json.JSONFormatter],
        'XML': [httpie.plugins.formatter.xml.XMLFormatter],
        'HTML': [httpie.plugins.formatter.html.HTMLFormatter],
        'Images': [httpie.plugins.formatter.image.ImageFormatter]
    }

plugins = PluginManager()

# Generated at 2022-06-12 00:24:26.710630
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    print('Method filter of class PluginManager')
    print('Input: <empty PluginManager>')
    plugins = PluginManager()
    print('Expected Output: []')
    print('Actually Output: ', plugins.filter())
    print('-----------------------------')

    print('Method filter of class PluginManager')
    print('Input: <PluginManager with one element>')
    plugins.register(AuthPlugin)
    print('Expected Output: [<class \'httpie.plugins.base.AuthPlugin\'>]')
    print('Actually Output: ', plugins.filter())
    print('-----------------------------')

    print('Method filter of class PluginManager')
    print('Input: <PluginManager with 3 elements>')
    plugins.register(AuthPlugin)
    plugins.register(ConverterPlugin)
    plugins.register(TransportPlugin)

# Generated at 2022-06-12 00:24:38.925152
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.compat import is_windows

    if is_windows:
        import subprocess
        subprocess.call("pip install --upgrade --force httpie-test-package", shell=True)
        subprocess.call("pip install --upgrade --force httpie-test-package-both-auth-and-input", shell=True)

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) == 2
    assert plugin_manager[0].package_name == "httpie-test-package"
    assert plugin_manager[1].package_name == "httpie-test-package-both-auth-and-input"

    if is_windows:
        subprocess.call("pip uninstall -y httpie-test-package", shell=True)
        subprocess

# Generated at 2022-06-12 00:24:44.687079
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager) == 5

    for plugin in pluginManager:
        if (plugin.name):
            if (plugin.name == "basic"):
                assert plugin.name == "basic"
                assert plugin.auth_type == "basic"
            if (plugin.name == "digest"):
                assert plugin.name == "digest"
                assert plugin.auth_type == "digest"
        if (plugin.aspect == "format"):
            if (plugin.name == "json"):
                assert plugin.name == "json"
                assert plugin.aspect == "format"
            if (plugin.name == "json-istty"):
                assert plugin.name == "json-istty"

# Generated at 2022-06-12 00:24:47.119203
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 4


# Generated at 2022-06-12 00:24:49.296240
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    pm.register()
    pm.load_installed_plugins()
    result = pm.get_formatters_grouped()




# Generated at 2022-06-12 00:24:52.014868
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-12 00:24:53.005610
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins(PluginManager())

# Generated at 2022-06-12 00:24:55.565572
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins.get_formatters_grouped()

# Generated at 2022-06-12 00:25:06.937798
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import ConverterPlugin
    from httpie.plugins.builtin import TransportPlugin
    from httpie.plugins.builtin import UnixSocketAuth

    plugin_manager = PluginManager()
    plugin_manager.register(HTTPBasicAuth, HTTPTokenAuth, UnixSocketAuth)

    result = plugin_manager.filter(by_type=AuthPlugin)
    assert result == [HTTPBasicAuth, HTTPTokenAuth, UnixSocketAuth]

    result = plugin_manager.filter(by_type=FormatterPlugin)
    assert result == []


# Generated at 2022-06-12 00:25:14.046206
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """Unit test for method get_formatters_grouped of class PluginManager"""

    # arrange
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    output_formatters_grouped = plugin_manager.get_formatters_grouped()
    expected_keys = ['format', 'colors', 'colors-light']

    # act
    actual_keys = [key for key in output_formatters_grouped]
    actual_keys.sort()

    # assert
    assert actual_keys == expected_keys

# Generated at 2022-06-12 00:25:44.632237
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(TransportPlugin, AuthPlugin)
    assert len(manager.filter()) == 2
    assert len(manager.filter(TransportPlugin)) == 1
    assert len(manager.filter(AuthPlugin)) == 1


# Generated at 2022-06-12 00:25:54.842657
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import auth
    from httpie.plugins import formatter
    from httpie.plugins import converter
    from httpie.plugins import transport
    from httpie.plugins.builtin import AuthBasicPlugin
    from httpie.plugins.builtin import AuthDigestPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyJSONFormatterPlugin
    from httpie.plugins.builtin import RawJSONFormatterPlugin
    from httpie.plugins.builtin import JSONLinesFormatterPlugin
    from httpie.plugins.builtin import JSONPointerConverterPlugin
    from httpie.plugins.builtin import URLEncodeConverterPlugin
    from httpie.plugins.builtin import NetrcAuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuthPlugin

# Generated at 2022-06-12 00:25:58.356589
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
	plugin_manager = PluginManager()
	plugin_manager.load_installed_plugins()
	groups_arr = plugin_manager.get_formatters_grouped()
	assert groups_arr['Unix pipes']


# Generated at 2022-06-12 00:26:00.966691
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 3


# Generated at 2022-06-12 00:26:06.354069
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin, TransportPlugin, FormatterPlugin)
    assert plugins.filter(AuthPlugin) is not None
    assert plugins.filter(TransportPlugin) is not None
    assert plugins.filter(FormatterPlugin) is not None
    

# Generated at 2022-06-12 00:26:14.451550
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from unittest import TestCase

    class FormatterPlugin1(FormatterPlugin):
        name = 'plugin1'
        media_types = ['*/*']
        group_name = 'group1'

    class FormatterPlugin2(FormatterPlugin):
        name = 'plugin2'
        media_types = ['*/*']
        group_name = 'group1'

    class FormatterPlugin3(FormatterPlugin):
        name = 'plugin3'
        media_types = ['*/*']
        group_name = 'group2'

    pm = PluginManager()
    pm.register(FormatterPlugin1, FormatterPlugin2, FormatterPlugin3)

    formatter_groups = pm.get_formatters_grouped()


# Generated at 2022-06-12 00:26:15.288658
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pass


# Generated at 2022-06-12 00:26:18.311544
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0
    assert all([isinstance(p, type) for p in pm])

# Generated at 2022-06-12 00:26:19.646351
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    a = PluginManager()
    assert len(a.filter()) == 0


# Generated at 2022-06-12 00:26:27.287148
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p_m = PluginManager()
    p_m.register(AuthPlugin)
    p_m.register(FormatterPlugin)
    p_m.register(ConverterPlugin)
    p_m.register(TransportPlugin)
    p_m.load_installed_plugins()
    assert len(p_m) == 4
    assert len(p_m.filter(AuthPlugin)) == 1
    assert len(p_m.filter(FormatterPlugin)) == 1
    assert len(p_m.filter(ConverterPlugin)) == 1
    assert len(p_m.filter(TransportPlugin)) == 1


# Generated at 2022-06-12 00:27:27.153146
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    lp = PluginManager()
    lp.load_installed_plugins()
    assert lp

# Generated at 2022-06-12 00:27:37.179370
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Test that all plugins are loaded
    assert len(plugs) == len(ENTRY_POINT_NAMES)

    # Test method filter
    assert len(plugs.filter(BasePlugin)) == len(ENTRY_POINT_NAMES)    
    assert plugs.filter(AuthPlugin) != plugs.filter(BasePlugin)


if __name__ == '__main__':
    # Create a new PluginManager instance.
    plugs = PluginManager()

    # Call method load installed plugins to load plugins.
    plugs.load_installed_plugins()

    # Call method filter to filter plugins by different types
    # and print the result
    print('All Plugins:')
    print('----------')
    for p in plugs.filter(BasePlugin):
        print(p)
    print()

    print('AuthPlugins:')

# Generated at 2022-06-12 00:27:42.401425
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Assert
    manager = PluginManager([
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin
    ])
    # Act
    result = manager.get_formatters_grouped()
    # Assert
    assert result == {}

# Generated at 2022-06-12 00:27:44.333515
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

# Generated at 2022-06-12 00:27:51.707013
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class FormatterPlugin1(FormatterPlugin):
        group_name = 'formatters_group_1'
    class FormatterPlugin2(FormatterPlugin):
        group_name = 'formatters_group_1'
    class FormatterPlugin3(FormatterPlugin):
        group_name = 'formatters_group_2'
    class FormatterPlugin4(FormatterPlugin):
        group_name = 'formatters_group_2'
    plugin_manager = PluginManager()
    plugin_manager.register(FormatterPlugin1, FormatterPlugin2,
                            FormatterPlugin3, FormatterPlugin4)

# Generated at 2022-06-12 00:27:54.984894
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # Ensure that load_installed_plugins() of PluginManager is always return list
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert isinstance(pluginManager, list)



# Generated at 2022-06-12 00:27:59.346009
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pluginManager = PluginManager()
    pluginManager.register(AuthPlugin, TransportPlugin)
    assert len(pluginManager) == 2
    assert len(pluginManager.filter(AuthPlugin)) == 1
    assert len(pluginManager.filter(TransportPlugin)) == 1
    assert pluginManager.filter(TransportPlugin)[0] == TransportPlugin


# Generated at 2022-06-12 00:28:00.845422
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginMan = PluginManager()
    pluginMan.load_installed_plugins()
    assert len(pluginMan) != 0

# Generated at 2022-06-12 00:28:02.452442
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert plugins != []


# Generated at 2022-06-12 00:28:06.348255
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    class Plugin1(AuthPlugin):
        auth_type = 'plugin1'

    class Plugin2(AuthPlugin):
        auth_type = 'plugin2'

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2)
    assert plugin_manager.get_auth_plugin_mapping() == {'plugin1': Plugin1, 'plugin2': Plugin2}