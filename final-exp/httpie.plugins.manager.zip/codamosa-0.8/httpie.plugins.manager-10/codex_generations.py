

# Generated at 2022-06-12 00:19:50.016465
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    python_plugin_manager = PluginManager()
    python_plugin_manager.load_installed_plugins()

    assert len(python_plugin_manager) > 0
    assert all(isinstance(plugin, type) for plugin in python_plugin_manager)
    assert all(isinstance(plugin, BasePlugin) for plugin in python_plugin_manager)

    # sort python_plugin_manager by name of package
    sorted_python_plugin_manager = sorted(python_plugin_manager, key=attrgetter('package_name'))

    # check that PluginManager is really sorted
    for i in range(len(sorted_python_plugin_manager) - 1):
        assert sorted_python_plugin_manager[i].package_name <= sorted_python_plugin_manager[i+1].package_name

# Generated at 2022-06-12 00:19:51.201574
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pluginManager = PluginManager()
    assert isinstance(pluginManager.filter(), list)

# Generated at 2022-06-12 00:19:54.329604
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    assert plugin_manager.get_formatters_grouped() == {
        'group1': [], 'group2': [], 'group3': []
    }



# Generated at 2022-06-12 00:20:03.772851
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager=PluginManager()
    plugin_manager.load_installed_plugins()
    assert set(plugin_manager.get_auth_plugin_mapping().keys())=={'basic', 'digest'}
    assert set(plugin_manager.get_formatters_grouped().keys())=={'format', 'output control'}
    assert set(plugin_manager.get_converters().keys())=={'json'}
    assert set(plugin_manager.get_transport_plugins().keys())=={'http', 'http2'}

# Generated at 2022-06-12 00:20:12.306361
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Plugin(FormatterPlugin):
        group_name='Group1'
        def format_body(self,body,mime):
            return body
    class Plugin1(FormatterPlugin):
        group_name='Group1'
        def format_body(self,body,mime):
            return body
    class Plugin2(FormatterPlugin):
        group_name='Group2'
        def format_body(self,body,mime):
            return body
    test_PluginManager=PluginManager()
    test_PluginManager.register(Plugin,Plugin1,Plugin2)
    assert test_PluginManager.get_formatters_grouped() == {'Group1': [Plugin, Plugin1], 'Group2': [Plugin2]}

    class Plugin3(FormatterPlugin):
        group_name='Group1'

# Generated at 2022-06-12 00:20:21.979062
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    sut = PluginManager()
    auth_plugin = AuthPlugin()
    formatter_plugin = FormatterPlugin()
    sut.register(auth_plugin)
    sut.register(formatter_plugin)
    assert len(sut.filter(AuthPlugin)) == 1
    assert sut.filter(AuthPlugin)[0] == auth_plugin
    assert len(sut.filter(FormatterPlugin)) == 1
    assert sut.filter(FormatterPlugin)[0] == formatter_plugin
    assert len(sut.filter(ConverterPlugin)) == 0


# Generated at 2022-06-12 00:20:29.486377
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.cli.config import Config

    class MockPlugin(AuthPlugin):

        auth_type= 'mock'

        def get_auth(self, username=None, password=None):
            return ''


    plugins = PluginManager()
    plugins.register(MockPlugin)
    plugins.register(HTTPBasicAuth)

    expected = {
        'mock': MockPlugin,
        'basic': HTTPBasicAuth
    }
    assert plugins.get_auth_plugin_mapping() == expected


# Generated at 2022-06-12 00:20:34.090549
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    prev_len = len(plugin_manager)
    plugin_manager.load_installed_plugins()
    new_len = len(plugin_manager)
    assert new_len > prev_len


plugin_manager = PluginManager()

# Generated at 2022-06-12 00:20:41.486346
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin1 = TransportPlugin()
    plugin2 = FormatterPlugin()
    plugin3 = TransportPlugin()
    pluginManager = PluginManager()
    pluginManager.append(plugin1)
    pluginManager.append(plugin2)
    pluginManager.append(plugin3)
    pluginManager.filter(FormatterPlugin)
    assert plugin1 not in pluginManager.filter(FormatterPlugin)
    assert plugin2 in pluginManager.filter(FormatterPlugin)
    assert plugin3 not in pluginManager.filter(FormatterPlugin)

test_PluginManager_filter()

# Generated at 2022-06-12 00:20:44.213118
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager=PluginManager()
    plugin_manager.load_installed_plugins()
    group_dict=plugin_manager.get_formatters_grouped()
    assert type(group_dict) is dict
    assert 'colors' in group_dict
    assert 'colors' in group_dict

# Generated at 2022-06-12 00:20:48.229462
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0


# Generated at 2022-06-12 00:20:50.464706
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins()

if __name__ == "__main__":
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:20:55.754562
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.base import BasePlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.formatter.colors import ColoredFormatter
    pm = PluginManager()
    # setup
    pm.register(HTTPBasicAuth, ColoredFormatter)
    assert pm.filter(BasePlugin) == pm.filter(BasePlugin)
    assert pm.filter(BasePlugin) == [HTTPBasicAuth, ColoredFormatter]

# Generated at 2022-06-12 00:21:03.887628
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # GIVEN: A PluginManager
    plugins = PluginManager()
    # GIVEN: The list [A, B, C, D, E, F] of formatters,
    #        where A, B, C belong to groups 'foo',
    #        and D, E, F belong to groups 'bar'.
    class A(FormatterPlugin): group_name = 'foo'
    class B(FormatterPlugin): group_name = 'foo'
    class C(FormatterPlugin): group_name = 'foo'
    class D(FormatterPlugin): group_name = 'bar'
    class E(FormatterPlugin): group_name = 'bar'
    class F(FormatterPlugin): group_name = 'bar'
    plugins.register(A, B, C, D, E, F)
    # WHEN:

# Generated at 2022-06-12 00:21:11.792300
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin

    class PluginA(BasePlugin):
        pass

    class PluginB(AuthPlugin):
        pass

    class PluginC(ConverterPlugin):
        pass

    class PluginD(FormatterPlugin):
        pass

    class PluginE(TransportPlugin):
        pass

    p = PluginManager()
    p.register(PluginA, PluginB, PluginC, PluginD, PluginE)
    assert p.filter(AuthPlugin) == [PluginB]
    assert p.filter(ConverterPlugin) == [PluginC]
    assert p.filter(FormatterPlugin) == [PluginD]
    assert p.filter(TransportPlugin) == [PluginE]

# Generated at 2022-06-12 00:21:13.473978
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) >= 1



# Generated at 2022-06-12 00:21:17.574075
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(Plugin1)
    plugins.register(Plugin2)
    plugins.register(Plugin3)
    plugins.register(Plugin4)

    assert plugins.get_formatters_grouped() == {
        "": [Plugin1, Plugin4],
        "group1": [Plugin2, Plugin3]
    }



# Generated at 2022-06-12 00:21:23.078137
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from pretty import PrettyPlugin
    from json import JsonPlugin
    from httpie.output.formatters.colors import ColorsPlugin
    plugin_manager = PluginManager()
    plugin_manager.register(PrettyPlugin, JsonPlugin, ColorsPlugin)
    assert \
        plugin_manager.get_formatters_grouped() == \
        {'json': [JsonPlugin], 'colors': [ColorsPlugin], 'pretty': [PrettyPlugin]}

# Generated at 2022-06-12 00:21:28.490134
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.core import CoreAuthPlugin, CoreFormatPlugin, CoreTransportPlugin
    plugin_manager = PluginManager()
    plugin_manager.register(CoreAuthPlugin, CoreFormatPlugin, CoreTransportPlugin)
    assert plugin_manager.filter(AuthPlugin) == [CoreAuthPlugin]


# Generated at 2022-06-12 00:21:32.797658
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager_list = PluginManager()
    class base():pass
    class a(base):pass
    class b(base):pass
    PluginManager_list.register(a, b, base)
    PluginManager_list.filter(base)
    assert len(PluginManager_list.filter(base)) == 3



# Generated at 2022-06-12 00:21:39.168913
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    test_plugin_manager = PluginManager()
    test_plugin_manager.register(AuthPlugin, FormatterPlugin)
    assert test_plugin_manager.filter(AuthPlugin) == [AuthPlugin]
    assert test_plugin_manager.filter(BasePlugin) == [AuthPlugin, FormatterPlugin]

# Generated at 2022-06-12 00:21:41.702598
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # Arrange
    pm = PluginManager()

    # Act
    pm.register(FormatterPlugin)
    pm.register(FormatterPlugin)
    pm.register(FormatterPlugin)

    # Assert
    assert len(pm.get_formatters_grouped()) == 1

# Generated at 2022-06-12 00:21:43.815743
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm


# Generated at 2022-06-12 00:21:49.041967
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert len(plugin_manager.filter()) == 0
    plugin_manager.register(AuthPlugin, ConverterPlugin)
    assert len(plugin_manager.filter(AuthPlugin)) == 1
    assert len(plugin_manager.filter(ConverterPlugin)) == 1



# Generated at 2022-06-12 00:21:58.016248
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    import sys

    pm = PluginManager()
    pm.register(JSONFormatter,
                JSONLinesFormatter,
                HTMLExportFormatter,
                HTMLFormatter,
                TableFormatter)
    if sys.version_info >= (3, 6):
        from httpie.plugins.formatter.colors import (
            ColorsFormatter,
            SolarizedColorsFormatter,
            NordicColorsFormatter
        )
        pm.register(ColorsFormatter,
                    SolarizedColorsFormatter,
                    NordicColorsFormatter)
    group_formatter = pm.get_formatters_grouped()
    assert group_formatter.get('colors') == [ColorsFormatter, SolarizedColorsFormatter, NordicColorsFormatter]

# Generated at 2022-06-12 00:22:08.305566
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()
    class FakeFormatterPlugin1(FormatterPlugin):
        """Fake FormatterPlugin1"""
        name = 'fake1'
        group_name = 'fake'
    class FakeFormatterPlugin2(FormatterPlugin):
        """Fake FormatterPlugin2"""
        name = 'fake2'
        group_name = 'fake'
    class FakeFormatterPlugin3(FormatterPlugin):
        """Fake FormatterPlugin3"""
        name = 'fake3'
        group_name = 'fake2'

    pm.register(FakeFormatterPlugin1, FakeFormatterPlugin2, FakeFormatterPlugin3)
    assert len(pm.get_formatters_grouped()["fake"]) == 2

# Generated at 2022-06-12 00:22:08.904319
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pass

# Generated at 2022-06-12 00:22:13.663541
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_loaded = PluginManager()
    plugins_loaded.load_installed_plugins()

    # Call method get_formatters_grouped
    dict_formatters_grouped = plugins_loaded.get_formatters_grouped()
    
    # Assert
    assert len(dict_formatters_grouped) == 2
    assert len(dict_formatters_grouped['Group 1']) == 2
    assert len(dict_formatters_grouped['Group 2']) == 1

# Generated at 2022-06-12 00:22:19.921646
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins import AuthPlugin

    pm = PluginManager()
    pm.register(HTTPBasicAuth)

    auth_plugins: List[AuthPlugin] = pm.filter(AuthPlugin)

    assert len(auth_plugins) == 1
    assert isinstance(auth_plugins[0], AuthPlugin)
    assert issubclass(auth_plugins[0], AuthPlugin)
    assert 'httpie.plugins.builtin.HTTPBasicAuth' == auth_plugins[0].__module__ + '.' + auth_plugins[0].__name__

# Generated at 2022-06-12 00:22:28.017139
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from .auth import AuthPlugin, BasicAuth
    from .converters import ConverterPlugin, JSONConverter
    from .formatters import FormatterPlugin, JsonFormatter
    from .transport import TransportPlugin, HTTPAdapter
    ma = PluginManager().register(AuthPlugin, BasicAuth, ConverterPlugin, JSONConverter, FormatterPlugin, JsonFormatter, TransportPlugin, HTTPAdapter)
    ma.filter(AuthPlugin)
    ma.filter(ConverterPlugin)
    ma.filter(FormatterPlugin)
    ma.filter(TransportPlugin)

# Generated at 2022-06-12 00:22:36.476581
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_mapping = PluginManager().get_auth_plugin_mapping()
    assert len(plugin_mapping) == 2
    assert plugin_mapping['basic'] == BasicAuthPlugin
    assert plugin_mapping['digest'] == DigestAuthPlugin


# Generated at 2022-06-12 00:22:44.398711
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert p
    from httpie.plugins import auth, transport, formatter, converter


# Generated at 2022-06-12 00:22:49.949188
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    def check_repr(expected, **kwargs):
        assert repr(PluginManager(**kwargs)) == expected
    check_repr("<PluginManager: []>")
    check_repr("<PluginManager: []>", [])
    check_repr("<PluginManager: [1, 2, 3]>", [1, 2, 3])

# Generated at 2022-06-12 00:22:58.305077
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = PluginManager()
    plugins.register(TestFormatterPlugin1)
    plugins.register(TestFormatterPlugin2)
    plugins.register(TestFormatterPlugin3)
    plugins.register(TestFormatterPlugin4)
    expected_formatters_grouped = {
        'Test Group 1': [TestFormatterPlugin1, TestFormatterPlugin2],
        'Test Group 2': [TestFormatterPlugin3],
        'Test Group 3': [TestFormatterPlugin4]
    }
    assert plugins.get_formatters_grouped() == expected_formatters_grouped

# Test subclass of FormatterPlugin

# Generated at 2022-06-12 00:23:01.840142
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert(plugin_manager.get_auth_plugins())
    assert(plugin_manager.get_formatters())
    assert(plugin_manager.get_converters())
    assert(plugin_manager.get_transport_plugins())


# Generated at 2022-06-12 00:23:08.338150
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert 'httpie-auth-jwt' in [plugin.package_name for plugin in pm]
    assert 'httpie-formatter-pretty' in [plugin.package_name for plugin in pm]
    assert 'httpie-converter-temp' in [plugin.package_name for plugin in pm]
    assert 'httpie-http2' in [plugin.package_name for plugin in pm]


# Generated at 2022-06-12 00:23:10.514634
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:23:12.897301
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-12 00:23:15.785656
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) != 0


# Generated at 2022-06-12 00:23:17.796295
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    # Test if the output is correct
    assert len(pm) != 0

# Generated at 2022-06-12 00:23:27.080853
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie import plugins

    plugins.manager = PluginManager()
    plugins.manager.register(TwitterAuthPlugin)
    plugins.manager.register(AwsAuthPlugin)

    assert plugins.manager.get_auth_plugin_mapping() == {'twitter': TwitterAuthPlugin, 'aws': AwsAuthPlugin}

# Generated at 2022-06-12 00:23:33.466458
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-12 00:23:41.962162
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()

# Generated at 2022-06-12 00:23:44.485750
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 8

# Generated at 2022-06-12 00:23:47.294184
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(plugin_manager)

test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:23:52.610915
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = [
        FormatterPlugin,
        FormatterPlugin,
        FormatterPlugin
    ]
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)
    assert plugin_manager.get_formatters_grouped() == {
        None: [
            FormatterPlugin,
            FormatterPlugin,
            FormatterPlugin
        ]
    }

test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:23:55.074950
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) > 0





# Generated at 2022-06-12 00:24:04.131845
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    def patched_entry_point_iter(group, name):
        entry_point = MagicMock()
        entry_point.name = 'plugin_name'
        entry_point.dist.key = 'plugin_package_name'
        entry_point.load = lambda: MagicMock()
        return [entry_point]

    with patch('pkg_resources.iter_entry_points', patched_entry_point_iter):
        plugin_manager = PluginManager()
        plugin_manager.load_installed_plugins()

        entry_point = plugin_manager[0]
        assert entry_point.name == 'plugin_name'
        assert entry_point.package_name == 'plugin_package_name'

# Generated at 2022-06-12 00:24:09.032263
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # PluginManager is a list, so it can't be instantiated.
    # However, it can be extended.
    class MockPlugin(FormatterPlugin):
        group_name = 'mock_group_name'

    mock_plugin_manager = PluginManager().append(MockPlugin)
    group_name_formatter_mapping = mock_plugin_manager.get_formatters_grouped()
    assert group_name_formatter_mapping['mock_group_name'] == [MockPlugin]

# Generated at 2022-06-12 00:24:12.891894
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0
    for plugin in plugin_manager:
        assert issubclass(plugin, BasePlugin)
        assert plugin.package_name is not None


# Generated at 2022-06-12 00:24:28.703521
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    """
    Test {PluginManager.get_formatters_grouped} for class {PluginManager}.
    """

    plugins = PluginManager()

    class FormatterPluginA(FormatterPlugin):
        """A class for formatter plugin A."""

        group_name = "group_A"

    class FormatterPluginB(FormatterPlugin):
        """A class for formatter plugin B."""

        group_name = "groub_B"

    class FormatterPluginC(FormatterPlugin):
        """A class for formatter plugin C."""

        group_name = "group_A"

    plugins.register(FormatterPluginA, FormatterPluginB, FormatterPluginC)


# Generated at 2022-06-12 00:24:39.447394
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    pManager = PluginManager()
    pManager.load_installed_plugins()
    assert isinstance(pManager.filter(by_type=FormatterPlugin), list)
    assert isinstance(pManager.filter(by_type=AuthPlugin), list)
    assert isinstance(pManager.filter(by_type=ConverterPlugin), list)
    assert isinstance(pManager.filter(by_type=TransportPlugin), list)
    assert isinstance(pManager.filter(by_type=BasePlugin), list)
    assert isinstance(pManager.filter(), list)


# Generated at 2022-06-12 00:24:50.202289
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie import exit_status
    from httpie.plugins import FormatterPlugin
    import json
    import httpie
    manager = PluginManager()
    manager.load_installed_plugins()
    format_list = json.loads(httpie.__version__)

    def monkeypatch(func):
        setattr(func, 'version', format_list)
        return func

    manager.register(monkeypatch(
        type(
            'MyFormat',
            (FormatterPlugin,),
            {
                'name': 'my', 'group_name': 'My Group', 'input_format': 'my',
                'transform_func': lambda x: x,
            }
        )
    ))

# Generated at 2022-06-12 00:24:55.245744
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()

    formatters_grouped = pluginManager.get_formatters_grouped()
    assert len(formatters_grouped) == 2
    assert len(formatters_grouped['Pretty']) == 3
    assert len(formatters_grouped['Syntax']) == 2

# Generated at 2022-06-12 00:25:00.710919
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.register(HTTPBasicAuth, DigestAuth, OAuth1Auth)

    get_auth_plugin_mapping = plugins.get_auth_plugin_mapping
    assert get_auth_plugin_mapping() == {
        'basic': HTTPBasicAuth,
        'digest': DigestAuth,
        'oauth1': OAuth1Auth,
    }


# Generated at 2022-06-12 00:25:04.560916
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    result = plugin_manager.filter(AuthPlugin)
    assert(len(result) > 0)

# Generated at 2022-06-12 00:25:06.857554
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager=PluginManager()
    manager.register(1,2,3,4,5,"afaf")
    print(manager.filter(by_type=int))

# Generated at 2022-06-12 00:25:15.409254
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(HttpAuthPlugin)
    plugins.register(WSAuthPlugin)
    plugins.register(Oauth2Plugin)
    plugins.register(DigestAuthPlugin)
    plugins.register(FormatterPlugin)
    # plugins.register(JsonPlugin)
    # plugins.register(JsonIndentPlugin)
    # plugins.register(JsonLinesPlugin)
    # plugins.register(JlPlugin)
    # plugins.register(TablePlugin)

    plugins.filter()
    # plugins.filter(FormatterPlugin)
    # plugins.filter(TransportPlugin)

if __name__ == '__main__':
    test_PluginManager_filter()

# Generated at 2022-06-12 00:25:17.633520
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager.register(BasePlugin)
    cached_list = [BasePlugin]
    assert PluginManager[0] == BasePlugin
    assert PluginManager.filter() == cached_list

# Generated at 2022-06-12 00:25:27.459148
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from json import dumps, loads
    from yaml import safe_load, dump

    class FormatterValueDump:
        name = 'value-dump'
        group_name = 'value'
        description = 'Dump the response value directly'
        file_extension = 'txt'
        accepts_positional_arg = False

        def __call__(self, val):
            return val

    class FormatterJsonDump:
        name = 'json-dump'
        group_name = 'json'
        description = 'Output the response as JSON'
        file_extension = 'json'
        accepts_positional_arg = False

        def __call__(self, val):
            return dumps(loads(val))


# Generated at 2022-06-12 00:25:46.651515
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin = PluginManager()
    plugin.load_installed_plugins()
    assert len(plugin) == 19

# Generated at 2022-06-12 00:25:49.502567
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    httpie_plugins = plugin_manager.filter(BasePlugin)
    assert len(httpie_plugins) != 0


# Generated at 2022-06-12 00:25:53.407058
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.compat import str
    pm = PluginManager()
    pm.load_installed_plugins()
    assert str(pm) == "<PluginManager: ['httpie.plugins.http.HttpPlugin']>"
    
    

# Generated at 2022-06-12 00:26:01.433023
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin
    plugins = PluginManager()
    plugins.load_installed_plugins()
    auth_plugins = plugins.get_auth_plugins()
    assert len(auth_plugins) > 0
    assert issubclass(auth_plugins[0], AuthPlugin)
    formatters = plugins.get_formatters()
    assert len(formatters) > 0
    assert issubclass(formatters[0], FormatterPlugin)
    converters = plugins.get_converters()
    assert len(converters) > 0
    assert issubclass(converters[0], ConverterPlugin)
    transport_plugins = plugins.get_transport_plugins()
    assert len(transport_plugins) > 0

# Generated at 2022-06-12 00:26:06.185744
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(list(plugin_manager)) > 0
    print("Unit test for class PluginManager is OK.")


# Generated at 2022-06-12 00:26:07.934699
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    assert isinstance(plugins.filter(), list)


# Generated at 2022-06-12 00:26:13.045329
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    # Given
    class a(BasePlugin):
        pass

    class b(a):
        pass
    class c(b):
        pass
    class d(b):
        pass
    class e(d):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(a(), b(), c(), d(), e())

    # When
    result = plugin_manager.filter(b)

    # Then
    assert result == [b, c, d, e]

# Generated at 2022-06-12 00:26:16.985170
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm  = PluginManager()
    pm.register(PluginOAuth1, PluginOAuth2)
    assert pm.get_auth_plugin_mapping() == {'oauth1': PluginOAuth1, 'oauth2': PluginOAuth2}


# Generated at 2022-06-12 00:26:26.871257
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import RAWFormatter
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSON_DEVFormatter
    from httpie.plugins.builtin import JSON_INDENTFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import PRETTYFormatter
    from httpie.plugins.builtin import LINESFormatter
    from httpie.plugins.builtin import TABLEFormatter
    from httpie.plugins.builtin import COLORFormatter
    list_test = [RAWFormatter, JSONFormatter, JSON_DEVFormatter, JSON_INDENTFormatter, HTMLFormatter,
             PRETTYFormatter, LINESFormatter, TABLEFormatter, COLORFormatter]

# Generated at 2022-06-12 00:26:29.365849
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

# Generated at 2022-06-12 00:27:08.488335
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_formatters()) == 10

# Generated at 2022-06-12 00:27:12.238566
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    assert len(pm.filter()) == 0
    pm.register(AuthPlugin)
    assert len(pm.filter()) == 1
    assert len(pm.filter(AuthPlugin)) == 1
    assert len(pm.filter(FormatterPlugin)) == 0

# Generated at 2022-06-12 00:27:13.935944
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    load_install = PluginManager()
    load_install.load_installed_plugins()
    assert (len(load_install) > 0)


# Generated at 2022-06-12 00:27:24.726894
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    class Tests(BasePlugin):pass
    class Tests1(BasePlugin):pass
    class Tests2(BasePlugin):pass
    class Tests3(BasePlugin):pass
    pm.register(Tests, Tests1, Tests2, Tests3)
    a = pm.filter(BasePlugin)
    assert len(a) == 4
    b = pm.filter(Type[BasePlugin])
    assert a == b
    c = pm.filter(Tests)
    assert len(c) == 1
    assert Tests in c
    d = pm.filter(Tests1)
    assert len(d) == 1
    assert Tests1 in d
    e = pm.filter(Tests2)
    assert len(e) == 1
    assert Tests2 in e
    f = pm.filter(Tests3)

# Generated at 2022-06-12 00:27:28.267539
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """Method load_installed_plugins of class PluginManager should
       load all installed plugins.
    """

    pm = PluginManager()
    pm.load_installed_plugins()

    assert set(pm) - {'prettyjson','session','httpbin','highlight','hanging-process','colors'} == set()

# Generated at 2022-06-12 00:27:33.382823
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    testGet_formatters_grouped = PluginManager()
    testGet_formatters_grouped.register(JsonFormat)
    result = testGet_formatters_grouped.get_formatters_grouped()
    assert(result.__class__ == dict)
    assert('JSON' in result.keys())
    assert(JsonFormat in result.values())
    assert(len(result) == 1)


# Generated at 2022-06-12 00:27:37.662957
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    auth_plugin_mapping = plugins.get_auth_plugin_mapping()
    assert isinstance(auth_plugin_mapping, dict)
    assert auth_plugin_mapping.get('basic') == 'BasicAuthPlugin'


# Generated at 2022-06-12 00:27:39.070195
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    assert plugins == []
    plugins.load_installed_plugins()
    assert plugins != []

# Generated at 2022-06-12 00:27:41.849989
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    pass

# Generated at 2022-06-12 00:27:46.967754
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    p.load_installed_plugins()
    assert len(p.filter(AuthPlugin)) == 6
    assert len(p.filter(TransportPlugin)) == 1
    assert len(p.filter(FormatterPlugin)) == 2
    assert len(p.filter(ConverterPlugin)) == 2

# Generated at 2022-06-12 00:29:18.685822
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import PythonHTTPiePlugin, JSONFormatterPlugin,\
        HTTPieColors, HTTPiePrettyColors, HTTPiePretty

    pm = PluginManager()
    pm.register(PythonHTTPiePlugin, JSONFormatterPlugin, HTTPieColors,
                HTTPiePrettyColors, HTTPiePretty)
    assert pm.get_formatters_grouped() == {
        None: [JSONFormatterPlugin],
        'color': [HTTPieColors, HTTPiePrettyColors],
        'pretty': [HTTPiePretty, HTTPiePrettyColors]
    }



# Generated at 2022-06-12 00:29:22.777503
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(FooFormatter, BarFormatter)

    assert plugin_manager.get_formatters_grouped() == {
        'Foo': [FooFormatter],
        'Bar': [BarFormatter],
    }



# Generated at 2022-06-12 00:29:25.691156
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) == 14, 'plugins number is 14'

# Generated at 2022-06-12 00:29:31.026993
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.register(DummyFormatterPlugin, DummyGroupNameFormatterPlugin)
    grouped = plugin_manager.get_formatters_grouped()
    assert tuple(grouped.keys()) == tuple(('dummy',))
    assert tuple(grouped.values())[0][1].group_name == 'dummy'
    assert tuple(grouped.values())[0][1].group_kind == 'formatter'


# Generated at 2022-06-12 00:29:39.490057
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()