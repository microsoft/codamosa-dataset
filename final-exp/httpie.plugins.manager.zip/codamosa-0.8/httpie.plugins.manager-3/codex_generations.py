

# Generated at 2022-06-12 00:19:45.991319
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}

    plugins = [
        FakeFormatterPlugin(group_name='group'),
        FakeFormatterPlugin(group_name='group'),
        FakeFormatterPlugin(group_name='other group'),
        FakeFormatterPlugin(group_name='other group'),
    ]

    # Another way to create a dict:
    output = dict()  # type: Dict[str, List[Type[FormatterPlugin]]]
    output['group'] = plugins[:2]
    output['other group'] = plugins[2:]

    assert PluginManager(plugins).get_formatters_grouped() == output



# Generated at 2022-06-12 00:19:51.042977
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm=PluginManager()
    pm.load_installed_plugins()
    #There are 4 types of plugins, the following line will test whether the load_installed_plugins method works.
    assert len(pm.get_auth_plugins())+len(pm.get_formatters())+len(pm.get_converters())+len(pm.get_transport_plugins())==len(pm)

# Generated at 2022-06-12 00:19:56.998888
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass

    class Plugin2(BasePlugin):
        pass

    class Plugin3(BasePlugin):
        pass

    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2, Plugin3)
    assert len(plugin_manager) == 3
    assert len(plugin_manager.filter(Plugin1)) == 1
    assert len(plugin_manager.filter(Plugin2)) == 1
    assert len(plugin_manager.filter(Plugin3)) == 1
    assert len(plugin_manager.filter(BasePlugin)) == 3

# Generated at 2022-06-12 00:20:00.730942
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    assert len(plugins) == 0
    plugins.load_installed_plugins()
    assert len(plugins) > 0

# Generated at 2022-06-12 00:20:10.880102
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    # Test if the auth plugin mapping is correctly formed
    auth_plugin_mapping = manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping.get('digest') == DigestAuthPlugin
    assert auth_plugin_mapping.get('bearer') == BearerTokenAuthPlugin
    assert auth_plugin_mapping.get('aws-s3-v4') == AWSv4AuthPlugin
    assert auth_plugin_mapping.get('negotiate') == NegotiateAuthPlugin
    assert auth_plugin_mapping.get('aws-s3-v2') == AWSv2AuthPlugin
    assert auth_plugin_mapping.get('http') == HTTPBasicAuthPlugin

# Generated at 2022-06-12 00:20:21.324984
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import BuiltinPlugin

    pm = PluginManager()
    pm.register(BuiltinPlugin)
    formatters_grouped = pm.get_formatters_grouped()
    assert formatters_grouped['builtin'] == [
        BuiltinPlugin.JSONFormatterPlugin,
        BuiltinPlugin.JSONPrettyFormatterPlugin,
        BuiltinPlugin.COLRFormatterPlugin,
        BuiltinPlugin.COLRPrettyFormatterPlugin,
        BuiltinPlugin.URLEncodedFormatterPlugin,
        BuiltinPlugin.HTMLFormatterPlugin,
        BuiltinPlugin.ImageFormatterPlugin,
    ]


# Generated at 2022-06-12 00:20:30.727313
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():

    setattr(BasePlugin, 'name', 'BasePlugin')
    setattr(BasePlugin, 'shortname', 'Base')
    setattr(BasePlugin, 'group_name', 'Base Group')

    setattr(AuthPlugin, 'name', 'AuthPlugin')
    setattr(AuthPlugin, 'shortname', 'Auth')

    setattr(TransportPlugin, 'name', 'TransportPlugin')
    setattr(TransportPlugin, 'shortname', 'Transport')

    setattr(ConverterPlugin, 'name', 'ConverterPlugin')
    setattr(ConverterPlugin, 'shortname', 'Converter')

    setattr(FormatterPlugin, 'name', 'FormatterPlugin')
    setattr(FormatterPlugin, 'shortname', 'Formatter')

# Generated at 2022-06-12 00:20:41.946298
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # setup
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    # exercise
    result = plugin_manager.get_formatters_grouped()
    # verify

# Generated at 2022-06-12 00:20:48.285062
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-12 00:20:50.512043
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) != 0

# Generated at 2022-06-12 00:20:55.112778
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    assert len(pluginManager) > 0
    assert type(pluginManager) == PluginManager



# Generated at 2022-06-12 00:20:58.184699
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    """
    Unit test for method get_auth_plugin_mapping of class PluginManager
    """
    assert PluginManager().get_auth_plugin_mapping() == {}


# Generated at 2022-06-12 00:21:00.102320
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager.get_formatters_grouped() == {'format': [HttpiePlugin, HttpiePlugin2]}


# Generated at 2022-06-12 00:21:02.169355
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_auth_plugin_mapping()['jwt'] == manager[0]



# Generated at 2022-06-12 00:21:06.618843
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.builtin import HTTPBasicAuth

    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert plugin_manager.get_auth_plugin_mapping() == {'basic': HTTPBasicAuth}


# Generated at 2022-06-12 00:21:08.913304
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# Generated at 2022-06-12 00:21:12.489536
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.register(TestPlugin)
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 1
    assert TestPlugin in plugin_manager


# Generated at 2022-06-12 00:21:13.974952
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    return manager

# Generated at 2022-06-12 00:21:14.847444
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()

# Generated at 2022-06-12 00:21:18.124380
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    print(len(plugin_manager))
    assert len(plugin_manager) > 0

test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:21:30.397803
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    installed_plugins = PluginManager()
    installed_plugins.load_installed_plugins()

    assert installed_plugins != []
    assert ENTRY_POINT_NAMES[0] in installed_plugins[0].package_name
    assert ENTRY_POINT_NAMES[1] in installed_plugins[0].package_name
    assert ENTRY_POINT_NAMES[2] in installed_plugins[0].package_name
    assert ENTRY_POINT_NAMES[3] in installed_plugins[0].package_name

# Generated at 2022-06-12 00:21:38.154240
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    def test_params(params_expected, params_actual):
        for param_key in params_expected:
            assert params_expected[param_key] == params_actual[param_key]

    test_formatter_plugins = plugin_manager.get_formatters()
    test_params(
        {'name': 'colors', 'group_name': 'Syntax Highlighting',
         'package_name': 'httpie'},
        test_formatter_plugins[0].__dict__
    )
    test_params(
        {'name': 'httpie', 'group_name': 'Other', 'package_name': 'httpie'},
        test_formatter_plugins[-1].__dict__
    )

# Generated at 2022-06-12 00:21:48.383601
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()

    # mock class used to test the result
    class MockFormatterPlugin(FormatterPlugin):
        group_name = 'group1'

    # mock class used to test the result
    class MockFormatterPlugin2(FormatterPlugin):
        group_name = 'group1'

    class MockFormatterPlugin3(FormatterPlugin):
        group_name = 'group2'

    plugin_manager.register(MockFormatterPlugin)
    plugin_manager.register(MockFormatterPlugin2)
    plugin_manager.register(MockFormatterPlugin3)

    result = plugin_manager.get_formatters_grouped()

    expected = {
        'group1': [MockFormatterPlugin, MockFormatterPlugin2],
        'group2': [MockFormatterPlugin3]
    }

   

# Generated at 2022-06-12 00:21:56.390177
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    class MyFormatterPlugin(FormatterPlugin):
        group_name = "test"
    class MyFormatterPlugin2(FormatterPlugin):
        group_name = "test"
    class MyFormatterPlugin3(FormatterPlugin):
        group_name = "test2"
    pm = PluginManager()
    pm.register(MyFormatterPlugin, MyFormatterPlugin2, MyFormatterPlugin3)
    assert pm.get_formatters_grouped() == {"test":[MyFormatterPlugin, MyFormatterPlugin2], "test2":[MyFormatterPlugin3]}



# Generated at 2022-06-12 00:21:59.340346
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    print(manager.get_transport_plugins())

if __name__ == "__main__":
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:22:03.971703
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    class TestPlugin(BasePlugin):
        pass
    plugin_manager.register(TestPlugin)
    assert TestPlugin in plugin_manager.filter()
    plugin_manager.unregister(TestPlugin)
    assert TestPlugin not in plugin_manager.filter()

# Generated at 2022-06-12 00:22:13.585181
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    # test get_auth_plugins()
    plugin_manager.register(MyAuthPlugin1, MyAuthPlugin2, MyTransportPlugin)
    assert plugin_manager.get_auth_plugins() == [MyAuthPlugin1, MyAuthPlugin2]
    # test get_formatters()
    plugin_manager.register(MyFormatterPlugin1, MyFormatterPlugin2, MyTransportPlugin)
    assert plugin_manager.get_formatters() == [MyFormatterPlugin1, MyFormatterPlugin2]
    # test get_converters()
    plugin_manager.register(MyConverterPlugin, MyTransportPlugin)
    assert plugin_manager.get_converters() == [MyConverterPlugin]
    # test get_transport_plugins()
    assert plugin_manager.get_transport_

# Generated at 2022-06-12 00:22:20.413585
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = [
        BasePlugin,
        AuthPlugin,
        ConverterPlugin,
        FormatterPlugin
    ]
    
    plugin_manager = PluginManager()
    plugin_manager.register(*plugins)

    assert plugin_manager.filter(
        by_type=AuthPlugin
    ) == [AuthPlugin]

    assert plugin_manager.filter(
        by_type=ConverterPlugin
    ) == [ConverterPlugin]

    assert plugin_manager.filter(
        by_type=FormatterPlugin
    ) == [FormatterPlugin]

    assert plugin_manager.filter(
        by_type=BasePlugin
    ) == []



# Generated at 2022-06-12 00:22:29.359859
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    # check if plugins are loaded
    assert len(pm) > 0
    assert len(pm.get_auth_plugins()) > 0
    assert len(pm.get_converters()) > 0
    assert len(pm.get_formatters()) > 0
    assert len(pm.get_transport_plugins()) > 0

    # check if default formatters are loaded
    assert 'json' in pm.get_formatters_grouped().keys()

    # check if default auth plugins are loaded
    assert 'basic' in pm.get_auth_plugin_mapping().keys()



# Generated at 2022-06-12 00:22:42.070629
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    class Unknown(FormatterPlugin):
        group_name = 'unknown'
        type_name = 'unknown'
        """Output unknown formatter."""
        def format_headers(self, headers):
            return 'unknown'
    class Group1(FormatterPlugin):
        group_name = 'test_group1'
        type_name = 'test_group1'
        """Output headers in Group1 formatter."""
        def format_headers(self, headers):
            return 'test_group1'
    class Group2(FormatterPlugin):
        group_name = 'test_group2'
        type_name = 'test_group2'
        """Output headers in Group2 formatter."""
        def format_headers(self, headers):
            return 'test_group2'
    
    #Define a new PluginManger object
   

# Generated at 2022-06-12 00:22:53.244715
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import JSONStreamFormatter

    plugin_manager = PluginManager()
    plugin_manager.register(JSONStreamFormatter, HTTPBasicAuth)

    assert len(plugin_manager.filter()) == 2
    assert len(plugin_manager.filter(ConverterPlugin)) == 1

# Generated at 2022-06-12 00:22:55.331619
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    print('Test PluginManager.get_formatters_grouped')
    pm = PluginManager()

# Generated at 2022-06-12 00:22:58.609877
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    assert isinstance(plugin_manager.get_auth_plugin_mapping(), dict)


# Generated at 2022-06-12 00:23:06.100493
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    # register plugins
    plugins = [
        MyPlugin1(),
        MyPlugin2(),
        MyPlugin3(),
        MyPlugin4(),
    ]
    manager.register(*plugins)
    # filter by base class
    assert manager.filter(MyPlugin1) == plugins
    # filter by derived class
    assert manager.filter(MyPlugin2) == [plugins[1]]
    # filter by subclass
    assert manager.filter(MyPlugin4) == [plugins[3]]


# Generated at 2022-06-12 00:23:08.842949
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    assert pm[0].__name__ == 'BasicAuthPlugin'
    assert pm[1].__name__ == 'DigestAuthPlugin'

# Generated at 2022-06-12 00:23:11.153139
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    _manager = PluginManager()
    _manager.load_installed_plugins()
    assert len(_manager) >= 4


# Generated at 2022-06-12 00:23:19.421798
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.auth import BasicAuth
    from httpie.plugins.converter import JSON
    from httpie.plugins.transport import HTTP10, HTTP11, HTTPSAdapter
    from httpie.plugins.formatter import ColoredFormatter, JsonFormatter

    class MockEntryPoint:
        def __init__(self, plugin):
            self.load = lambda: plugin
            plugin.package_name = 'Mocked'

    plugin_manager = PluginManager()
    plugin_manager.register()
    plugin_manager.register(BasicAuth, JSON, HTTP10, HTTP11, HTTPSAdapter)
    plugin_manager.register(ColoredFormatter, JsonFormatter)
    plugin_manager.load_installed_plugins()

    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'basic'

# Generated at 2022-06-12 00:23:23.688401
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert pm.get_auth_plugin_mapping()["aws4"] is pm[0]
    assert pm.get_auth_plugin_mapping()["basic"] is pm[1]


# Generated at 2022-06-12 00:23:28.014948
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(AuthPlugin)
    auth_plugin_mapping = manager.get_auth_plugin_mapping()
    assert (auth_plugin_mapping['auth_plugin'] == AuthPlugin)


# Generated at 2022-06-12 00:23:36.601888
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.plugins.auth.jwt import JWTAuthPlugin

    manager = PluginManager()
    manager.register(BasicAuthPlugin, DigestAuthPlugin, JWTAuthPlugin)

    plugin_mapping = manager.get_auth_plugin_mapping()

    assert plugin_mapping['basic'] == BasicAuthPlugin
    assert plugin_mapping['digest'] == DigestAuthPlugin
    assert plugin_mapping['jwt'] == JWTAuthPlugin



# Generated at 2022-06-12 00:23:54.077964
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    # Unit test for method get_auth_plugin_mapping of class PluginManager
    from httpie.plugins.auth.httpie.HTTPBasicAuth import HTTPBasicAuth

    plugins = PluginManager()
    plugins.register(HTTPBasicAuth)
    assert plugins.get_auth_plugin_mapping() == {'basic': HTTPBasicAuth}
    assert plugins.get_auth_plugin('basic') == HTTPBasicAuth


# Generated at 2022-06-12 00:23:57.466524
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
  plugin_manager = PluginManager()
  plugin_manager.load_installed_plugins()
  assert len(plugin_manager) > 1



# Generated at 2022-06-12 00:23:59.153378
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) != 0


# Generated at 2022-06-12 00:24:04.758979
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.load_installed_plugins() #Load Test plugins from project
    assert manager.filter(AuthPlugin) == [TestPluginAuth]
    assert manager.filter(FormatterPlugin) == [TestPluginFormatter]
    assert manager.filter(ConverterPlugin) == [TestPluginConverter]
    assert manager.filter(TransportPlugin) == [TestPluginTransport]


plugins = PluginManager()
plugins.load_installed_plugins()

# Generated at 2022-06-12 00:24:08.507790
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin, TransportPlugin, FormatterPlugin)
    assert plugins.filter(TransportPlugin) == [TransportPlugin]
    assert plugins.filter(FormatterPlugin) == [FormatterPlugin]
    assert plugins.filter(AuthPlugin) == [AuthPlugin]
    assert plugins.filter() == [AuthPlugin, TransportPlugin, FormatterPlugin]

# Generated at 2022-06-12 00:24:11.062850
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0



# Generated at 2022-06-12 00:24:12.611486
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_manager = PluginManager()
    assert plugin_manager.filter(1) == []



# Generated at 2022-06-12 00:24:23.392001
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_list = []
    plugin1 = Mock(group_name=None)
    plugin2 = Mock(group_name=None)
    plugin3 = Mock(group_name=None)
    plugin4 = Mock(group_name='Awesome')
    plugin5 = Mock(group_name='Awesome')
    plugins_list.append(plugin1)
    plugins_list.append(plugin2)
    plugins_list.append(plugin3)
    plugins_list.append(plugin4)
    plugins_list.append(plugin5)
    plugins = PluginManager(plugins_list)
    plugins_dict = plugins.get_formatters_grouped()
    assert list(plugins_dict.keys()) == [None, 'Awesome']
    assert list(plugins_dict[None]) == [plugin1, plugin2, plugin3]

# Generated at 2022-06-12 00:24:25.472915
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) > 0
    

# Generated at 2022-06-12 00:24:28.575255
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    for plugin in manager:
        assert plugin.name is not None
        assert plugin.package_name is not None


# Generated at 2022-06-12 00:24:57.611662
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    from httpie.plugins.base import AuthPlugin
    from dummy_plugins import DummyAuthPlugin

    pm = PluginManager()
    pm.register(DummyAuthPlugin)

    assert len(pm) == 1
    assert pm.get_auth_plugin_mapping()['dummy'] == DummyAuthPlugin


# Generated at 2022-06-12 00:25:02.642886
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager().get_auth_plugin_mapping() == {}
    assert PluginManager([
        DummyAuthPluginV1, DummyAuthPluginV2, DummyFormatterPlugin
    ]).get_auth_plugin_mapping() == {
        'dummy': DummyAuthPluginV2,
    }



# Generated at 2022-06-12 00:25:13.098165
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    installed_auth_plugins = plugin_manager.get_auth_plugins()
    assert len(installed_auth_plugins) > 0
    for plugin in installed_auth_plugins:
        assert plugin.name != None
        assert plugin.auth_type != None
        assert plugin.package_name != None

    installed_converters = plugin_manager.get_converters()
    assert len(installed_converters) > 0
    for converter in installed_converters:
        assert converter.name != None
        assert plugin.package_name != None

    installed_formatters = plugin_manager.get_formatters()
    assert len(installed_formatters) > 0
    for formatter in installed_formatters:
        assert formatter.name != None


# Generated at 2022-06-12 00:25:16.883695
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugin_list = PluginManager()
    class Bar(BasePlugin):
        ...
    class Foo(Bar):
        ...
    class Baz(Foo):
        ...
    plugin_list.register(Foo, Baz, Bar)
    assert plugin_list.filter(by_type=Foo) == [Foo, Baz]

# Generated at 2022-06-12 00:25:18.070475
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    assert len(PluginManager.load_installed_plugins(self)) == 0

# Generated at 2022-06-12 00:25:27.899427
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class BasePlugin_obj(BasePlugin):pass
    class BasePlugin_obj_1(BasePlugin):pass
    class AuthPlugin_obj(AuthPlugin):pass
    class FormatterPlugin_obj(FormatterPlugin):pass
    class ConverterPlugin_obj(ConverterPlugin):pass
    pm = PluginManager([BasePlugin_obj,BasePlugin_obj_1,AuthPlugin_obj,FormatterPlugin_obj,ConverterPlugin_obj])
    assert pm.filter(AuthPlugin) == [AuthPlugin_obj]
    assert pm.filter(FormatterPlugin) == [FormatterPlugin_obj]
    assert pm.filter(ConverterPlugin) == [ConverterPlugin_obj]
    assert pm.filter(TransportPlugin) == []

# Generated at 2022-06-12 00:25:29.287634
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-12 00:25:35.749615
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Foo:
        pass
    class Bar:
        pass
    class Baz(Bar):
        pass
    pm = PluginManager()
    pm.register(Foo, Bar, Baz)
    assert pm.filter(Foo) == [Foo]
    assert pm.filter(Bar) == [Bar]
    assert pm.filter(Baz) == [Bar, Baz]


# Generated at 2022-06-12 00:25:41.032467
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    plugins = PluginManager()
    plugins.register(AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin)
    assert plugins.filter(AuthPlugin) == [AuthPlugin]
    assert plugins.filter() == [AuthPlugin, FormatterPlugin, ConverterPlugin, TransportPlugin]

# Test for method get_formatters_grouped

# Generated at 2022-06-12 00:25:44.839877
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins import builtin
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager.get_auth_plugins()) == len(builtin.AUTH_PLUGINS)

# Generated at 2022-06-12 00:26:50.018170
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    from httpie.plugins.builtin import (KeyValue, JSONItems,
                                        FormattedJSONItems, JSONStream)

    from httpie.plugins.builtin import (AuthPlugin, FormatterPlugin,
                                        ConverterPlugin, TransportPlugin)

    assert PluginManager().get_auth_plugin_mapping() == {}
    assert PluginManager().get_formatters() == []
    assert PluginManager().get_converters() == []
    assert PluginManager().get_transport_plugins() == []

    PluginManager().load_installed_plugins()

    assert PluginManager().get_auth_plugin_mapping() != {}
    assert PluginManager().get_formatters() != []
    assert PluginManager().get_converters() != []
    assert PluginManager().get_transport_plugins() != []




# Generated at 2022-06-12 00:26:55.334368
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert PluginManager().filter(by_type=Type[BasePlugin]) == []

    class TestPlugin(BasePlugin):
        pass

    assert PluginManager().filter(by_type=Type[TestPlugin]) == []

    class TestPlugin(BasePlugin):
        pass

    assert PluginManager().filter(by_type=Type[TestPlugin]) == []

    PluginManager().register(TestPlugin)
    assert PluginManager().filter(by_type=Type[TestPlugin]) == [TestPlugin]


# Generated at 2022-06-12 00:26:57.226888
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    p = PluginManager()
    p.load_installed_plugins()
    assert isinstance(p, PluginManager)

# Generated at 2022-06-12 00:27:03.214569
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    list_plugin = [AuthPluginBase, AuthPluginBase1]
    pm.register(*list_plugin)
    auth_plugin_mapping = pm.get_auth_plugin_mapping()
    assert auth_plugin_mapping == {
        'basic': AuthPluginBase,
        'digest': AuthPluginBase1
    }



# Generated at 2022-06-12 00:27:13.361380
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyFormatterPlugin
    from httpie.plugins.builtin import RawFormatterPlugin
    from httpie.plugins.builtin import SolarizedFormatterPlugin
    from httpie.plugins.builtin import TableFormatterPlugin
    from httpie.plugins.builtin import UJSONFormatterPlugin

    pm = PluginManager()
    plugin_list = [JSONFormatterPlugin, PrettyFormatterPlugin, RawFormatterPlugin, SolarizedFormatterPlugin,
                   TableFormatterPlugin, UJSONFormatterPlugin]
    pm.register(*plugin_list)

    assert len(pm.get_formatters_grouped()) == 2
    assert len(pm.get_formatters_grouped()['fixed']) == 4

# Generated at 2022-06-12 00:27:17.826845
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins_manager = PluginManager()
    plugins_manager.load_installed_plugins()
    print(plugins_manager.get_formatters_grouped())

if __name__ == '__main__':
    test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:27:23.754397
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    pm = PluginManager()
    pm.register(TransportPlugin)
    # test filter method
    result = pm.filter(TransportPlugin)
    assert isinstance(result, list), "PluginManager.filter doesn't work as expected"
    assert len(result) == 1, "PluginManager.filter doesn't work as expected"
    assert isinstance(result[0], TransportPlugin), "PluginManager.filter doesn't work as expected"


# Generated at 2022-06-12 00:27:30.379363
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(
        BasicAuthPlugin, DigestAuthPlugin, OAuth1Plugin, OAuth2Plugin,
    )
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert auth_plugin_mapping['basic'] == BasicAuthPlugin
    assert auth_plugin_mapping['digest'] == DigestAuthPlugin
    assert auth_plugin_mapping['oauth1'] == OAuth1Plugin
    assert auth_plugin_mapping['oauth2'] == OAuth2Plugin


# Generated at 2022-06-12 00:27:31.915591
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert(len(pm.get_auth_plugin_mapping()) == 0)

# Generated at 2022-06-12 00:27:33.306603
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    assert isinstance(PluginManager(), PluginManager)
