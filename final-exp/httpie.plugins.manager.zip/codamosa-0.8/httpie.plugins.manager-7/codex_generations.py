

# Generated at 2022-06-12 00:19:38.601654
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    assert pm
    for p in pm:
        assert p.package_name


# Generated at 2022-06-12 00:19:47.722161
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = []
    plugin = type('plugin', (object, ), {'group_name': 'group'})
    plugins.append(plugin)
    plugin = type('plugin', (object, ), {'group_name': 'group'})
    plugins.append(plugin)
    plugin = type('plugin', (object, ), {'group_name': 'group'})
    plugins.append(plugin)
    plugin = type('plugin', (object, ), {'group_name': 'group2'})
    plugins.append(plugin)
    plugin = type('plugin', (object, ), {'group_name': 'group2'})
    plugins.append(plugin)
    plugin = type('plugin', (object, ), {'group_name': 'group3'})
    plugins.append(plugin)
    manager = PluginManager()
    manager.register

# Generated at 2022-06-12 00:19:49.143954
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pass


# Generated at 2022-06-12 00:19:54.716894
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()
    assert len(plugins)
    assert len(plugins.get_formatters())
    assert len(plugins.get_converters())
    assert len(plugins.get_transport_plugins())
    assert len(plugins.get_auth_plugins())
    assert plugins.get_auth_plugin('basic') is not None
    assert plugins.get_auth_plugin('digest') is not None

# Generated at 2022-06-12 00:19:57.933230
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {
        'basic': AuthPlugin
    }

# Generated at 2022-06-12 00:20:04.492137
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from pprint import pprint

    import httpie

    httpie._plugins = PluginManager()
    httpie._plugins.load_installed_plugins()

    # pprint(httpie._plugins.get_formatters_grouped())
    print(httpie._plugins.get_formatters_grouped())


test_PluginManager_get_formatters_grouped()

# Generated at 2022-06-12 00:20:08.617709
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugins = PluginManager()
    plugins.load_installed_plugins()

    assert len(plugins) > 0
    assert all([
        isinstance(plugin(), BasePlugin) and plugin().package_name
        for plugin in plugins
    ])


plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-12 00:20:16.410453
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()

    class Plugin1(FormatterPlugin):
        group_name = 'Group 1'

    class Plugin2(FormatterPlugin):
        group_name = 'Group 1'

    class Plugin3(FormatterPlugin):
        group_name = 'Group 2'

    manager.register(Plugin1, Plugin2, Plugin3)
    assert manager.get_formatters_grouped() == {
        'Group 1': [Plugin1, Plugin2],
        'Group 2': [Plugin3],
    }

# Generated at 2022-06-12 00:20:18.543455
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    assert PluginManager.get_auth_plugin_mapping.__doc__


# Generated at 2022-06-12 00:20:24.381901
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    assert PluginManager().get_formatters_grouped() == {}

    manager = PluginManager()
    manager.register(MyFormatter)
    
    assert manager.get_formatters_grouped() == {'group_name': [MyFormatter]}

    manager.register(MyFormatter2)
    assert manager.get_formatters_grouped() == {'group_name': [MyFormatter, MyFormatter2]}



# Generated at 2022-06-12 00:20:33.431682
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    config_dirname = os.path.expanduser('~/.config/httpie/plugins')
    if os.path.exists(config_dirname):
        shutil.rmtree(config_dirname)
    os.mkdir(config_dirname)

# Generated at 2022-06-12 00:20:41.561606
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins.base import BasePlugin
    class ParentPlugin(BasePlugin):
        pass
    class ChildPlugin(ParentPlugin):
        pass
    class NotChildPlugin(BasePlugin):
        pass
    manager = PluginManager()
    manager.register(ParentPlugin, ChildPlugin, NotChildPlugin)
    assert manager.filter(ParentPlugin) == [ParentPlugin, ChildPlugin]
    assert manager.filter(ChildPlugin) == [ChildPlugin]
    assert manager.filter(NotChildPlugin) == [NotChildPlugin]
    assert manager.filter(ParentPlugin) == [ParentPlugin, ChildPlugin]


# Generated at 2022-06-12 00:20:48.049860
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {}
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {}
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {}
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {}
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {}
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {}
    pm.register(AuthPlugin)
    assert pm.get_auth_plugin_mapping() == {}
    pm.register(AuthPlugin)
    assert pm.get_auth_

# Generated at 2022-06-12 00:20:49.900845
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert len(manager) == 9


# Generated at 2022-06-12 00:20:51.580497
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0

# Generated at 2022-06-12 00:20:57.375943
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    print("Unit test for method load_installed_plugins")
    import sys
    import os

    entry_point_names = [
    'httpie.plugins.auth.v1',
    'httpie.plugins.formatter.v1',
    'httpie.plugins.converter.v1',
    'httpie.plugins.transport.v1',
    
    ]


# Generated at 2022-06-12 00:21:02.623290
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    # Check if installed plugins are loaded
    assert pm
    assert len(pm.get_formatters()) == 5
    assert len(pm.get_auth_plugins()) == 2
    assert len(pm.get_converters()) == 3
    assert len(pm.get_transport_plugins()) == 1

    # Check if group by group_name works
    assert len(pm.get_formatters_grouped()) == 3


# Generated at 2022-06-12 00:21:11.281728
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class Plugin1(BasePlugin):
        pass
    class Plugin2(Plugin1):
        pass
    class Plugin3(Plugin1):
        pass
    class Plugin4(Plugin1):
        pass
    class Plugin5(Plugin2):
        pass
    class Plugin6(Plugin2):
        pass
    class Plugin7(Plugin3):
        pass
    plugin_manager = PluginManager()
    plugin_manager.register(Plugin1, Plugin2, Plugin3, Plugin4, Plugin5, Plugin6, Plugin7)
    assert plugin_manager.filter(Plugin1) == [Plugin1, Plugin2, Plugin3, Plugin4, Plugin5, Plugin6, Plugin7]
    assert plugin_manager.filter(Plugin2) == [Plugin2, Plugin5, Plugin6]
    assert plugin_manager.filter(Plugin3) == [Plugin3, Plugin7]

# Generated at 2022-06-12 00:21:12.381077
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginsManager = PluginManager()
    pluginsManager.load_installed_plugins()
    assert len(pluginsManager) > 0

# Generated at 2022-06-12 00:21:14.533793
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    plugins = manager.load_installed_plugins()
    assert plugins is not None
    assert len(plugins) != 0

# Generated at 2022-06-12 00:21:20.779612
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) == 4


# Generated at 2022-06-12 00:21:24.060263
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    """Test if number of loaded plugins is 5 (httpie + 4 installed plugins in tox env).
    """
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) == 5

# Generated at 2022-06-12 00:21:25.464462
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    pm = PluginManager()
    assert pm.get_auth_plugin_mapping() == {}

# Generated at 2022-06-12 00:21:37.266153
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    formatters_grouped = plugin_manager.get_formatters_grouped()

# Generated at 2022-06-12 00:21:40.640660
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins() # load plugins from entry_points
    print('\nAuth plugins:')
    for plugin in pm.get_auth_plugins():
        print(plugin)

if __name__ == '__main__':
    test_PluginManager_load_installed_plugins()

# Generated at 2022-06-12 00:21:43.766988
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_pm = PluginManager()
    test_pm.load_installed_plugins()
    print(test_pm.get_auth_plugin_mapping())


# Generated at 2022-06-12 00:21:55.422861
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
    from httpie.compat import Mock, is_py35

    # for instancemock, we use class_
    # for classmock, we use new_callable
    class_or_new_callable = class_ if is_py35 else new_callable

    TransportPluginMock = Mock(TransportPlugin)
    ConverterPluginMock = Mock(ConverterPlugin)
    FormatterPluginMock = Mock(FormatterPlugin)
    AuthPluginMock = Mock(AuthPlugin)

    class TestPluginManager(PluginManager):
        def __init__(self):
            self.register(TransportPluginMock,
                          ConverterPluginMock,
                          FormatterPluginMock,
                          AuthPluginMock)

    manager = TestPluginManager

# Generated at 2022-06-12 00:22:03.582481
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pluginmgr = PluginManager()
    pluginmgr.load_installed_plugins()
    # print(pluginmgr.get_auth_plugins())
    # print(pluginmgr.get_auth_plugin_mapping())
    # print(pluginmgr.get_auth_plugin('basic'))
    print(pluginmgr.get_formatters())
    print('\n'.join(pluginmgr.get_formatters_grouped().keys()))
    print('\n'.join(pluginmgr.get_converters()))
    print(pluginmgr.get_transport_plugins())

# Generated at 2022-06-12 00:22:12.619971
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import FormatterPlugin
    from pkg_resources import iter_entry_points
    from typing import Dict, List, Type

    class MyFormatterPlugin(FormatterPlugin):
        name = 'my_formatter_plugin'
        group_name = 'my_group'
        group_type = 'type'

    class MyOtherFormatterPlugin(FormatterPlugin):
        name = 'my_other_formatter_plugin'
        group_name = 'my_group'
        group_type = 'type'

    manager = PluginManager()
    manager.register(MyOtherFormatterPlugin, MyFormatterPlugin)
    assert manager.get_formatters_grouped()



# Generated at 2022-06-12 00:22:16.789700
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager)
    assert plugin_manager[0].package_name == 'httpie-core'

plugin_manager = PluginManager()
plugin_manager.load_installed_plugins()

# Generated at 2022-06-12 00:22:31.690265
# Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-12 00:22:39.832135
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, URLEncodedFormatterPlugin, ResponseHeaders
    plugins_manager = PluginManager()
    plugins_manager.register(JSONFormatterPlugin, URLEncodedFormatterPlugin, ResponseHeaders)
    plugins_manager.get_formatters_grouped() == {
        'Group 1': [JSONFormatterPlugin],
        'Group 2': [URLEncodedFormatterPlugin, ResponseHeaders]
    }


# Generated at 2022-06-12 00:22:44.857464
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    assert manager == []
    manager.load_installed_plugins()
    assert manager != []
    assert len(manager) > 0
    assert len(manager.get_formatters()) > 0
    assert len(manager.get_converters()) > 0
    assert len(manager.get_auth_plugin_mapping()) > 0

test_PluginManager_load_installed_plugins()



# Generated at 2022-06-12 00:22:55.286809
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    import sys
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPBearerAuth
    from httpie.plugins.builtin import ConverterJSON, ConverterFormURLEncoded
    from httpie.plugins.builtin import FormatterPretty, FormatterColored
    from httpie.plugins.builtin import TransportHTTPAdapter, TransportHTTPSAdapter

    PluginManager.register(PluginManager, HTTPBasicAuth, HTTPBearerAuth,
                           ConverterJSON, ConverterFormURLEncoded,
                           FormatterPretty, FormatterColored,
                           TransportHTTPAdapter, TransportHTTPSAdapter)
    pm = PluginManager()
    pm.register(HTTPBasicAuth, HTTPBearerAuth,
                ConverterJSON, ConverterFormURLEncoded,
                FormatterPretty, FormatterColored,
                TransportHTTPAdapter, TransportHTTPSAdapter)


# Generated at 2022-06-12 00:22:58.570226
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plg_mgr = PluginManager()
    plg_mgr.load_installed_plugins()
    assert plg_mgr

# Generated at 2022-06-12 00:23:01.579093
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    manager = PluginManager()
    manager.load_installed_plugins()
    assert manager.get_formatters_grouped()['head'] == [HEADFormatterPlugin]
    assert manager.get_formatters_grouped()['body'] == [JsonFormatterPlugin]

# Generated at 2022-06-12 00:23:04.443426
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    # print("The load_installed_plugins function is running...")
    assert (1==1)


# Generated at 2022-06-12 00:23:05.952725
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager().load_installed_plugins()



# Generated at 2022-06-12 00:23:10.725754
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins.builtin import JSONFormatterPlugin, HTMLFormatterPlugin, URLEncodedFormatterPlugin, PrettyJsonFormatterPlugin
    pm = PluginManager()
    pm.register(JSONFormatterPlugin, HTMLFormatterPlugin, URLEncodedFormatterPlugin, PrettyJsonFormatterPlugin)
    print(pm.get_formatters_grouped())
#


# Generated at 2022-06-12 00:23:13.050410
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()

    assert len(plugin_manager) > 0

# Generated at 2022-06-12 00:23:32.921987
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    manager = PluginManager()
    manager.register(AuthPlugin)
    manager.register(FormatterPlugin)
    assert issubclass(manager.filter(AuthPlugin)[0], AuthPlugin)
    assert issubclass(manager.filter(FormatterPlugin)[0], FormatterPlugin)



# Generated at 2022-06-12 00:23:39.866456
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    from httpie.plugins import builtin

    plugin_manager = PluginManager()
    plugin_manager.register(builtin.JSONFormatterPlugin, builtin.PrettyFormatterPlugin,
                            builtin.FormatDictFormatterPlugin)
    plugin_manager.get_formatters_grouped() == {
        'json': [builtin.JSONFormatterPlugin],
        'pretty': [builtin.PrettyFormatterPlugin],
        'formatdict': [builtin.FormatDictFormatterPlugin],
    }



# Generated at 2022-06-12 00:23:45.901190
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert plugin_manager.get_formatters() != []
    assert plugin_manager.get_converters() != []
    assert plugin_manager.get_transport_plugins() != []
    assert plugin_manager.get_auth_plugins() != []


# Generated at 2022-06-12 00:23:48.684630
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()

    assert len(pm) > 0

    assert AuthPlugin in [p for p in pm]


# Generated at 2022-06-12 00:23:56.063673
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    from httpie.plugins import AuthPlugin, FormatterPlugin, ConverterPlugin
    from httpie.plugins.base import BasePlugin, TransportPlugin
    from httpie.compat import is_windows
    from httpie.output.formatters import NetrcAuthFormatter, UrlencodedFormatter

    Plugins = PluginManager()
    plugins = [
        AuthPlugin,
        FormatterPlugin,
        ConverterPlugin,
        TransportPlugin,
        NetrcAuthFormatter,
        UrlencodedFormatter
    ]
    Plugins.register(*plugins)
    # print(type(Plugins.filter(AuthPlugin)))
    # print(type(Supporter.is_windows()))
    # print(type(Plugins.filter(FormatterPlugin)))
    # print(type(Plugins.filter(ConverterPlugin)))
    # print(type(Plug

# Generated at 2022-06-12 00:24:03.625279
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pm = PluginManager()

    class Formatter1(FormatterPlugin):
        group_name = 'Group1'

    class Formatter2(FormatterPlugin):
        group_name = 'Group2'

    class Formatter3(FormatterPlugin):
        group_name = 'Group1'

    pm.register(Formatter1, Formatter2, Formatter3)

    assertion_dict = {'Group1': [Formatter1, Formatter3], 'Group2': [Formatter2]}
    assert pm.get_formatters_grouped() == assertion_dict

# Generated at 2022-06-12 00:24:07.069501
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    PluginManager = PluginManager()
    PluginManager.register(AuthPlugin, ConverterPlugin, FormatterPlugin)
    assert len(PluginManager.filter(AuthPlugin)) == 1
    assert len(PluginManager.filter(ConverterPlugin)) == 1
    assert len(PluginManager.filter(FormatterPlugin)) == 1



# Generated at 2022-06-12 00:24:15.897960
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    manager = PluginManager()
    manager.load_installed_plugins()
    # Load all installed plugins
    assert len(manager.filter(AuthPlugin)) != 0
    assert len(manager.filter(FormatterPlugin)) != 0
    assert len(manager.filter(ConverterPlugin)) != 0
    assert len(manager.filter(TransportPlugin)) != 0
    # Load all plugins from ENTRY_POINT_NAMES
    assert 'httpie.plugins.auth.v1' in ENTRY_POINT_NAMES
    assert 'httpie.plugins.formatter.v1' in ENTRY_POINT_NAMES
    assert 'httpie.plugins.converter.v1' in ENTRY_POINT_NAMES
    assert 'httpie.plugins.transport.v1' in ENTRY_POINT_NAMES

# Unit test

# Generated at 2022-06-12 00:24:20.443910
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugin_manager.register(None, None)
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert {} == auth_plugin_mapping
    return auth_plugin_mapping



# Generated at 2022-06-12 00:24:24.624833
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    manager = PluginManager()
    manager.register(AuthPlugin)
    manager.register(AuthPlugin)
    print(manager.get_auth_plugin_mapping())
    assert manager.get_auth_plugin_mapping() == {}


# Generated at 2022-06-12 00:25:00.304540
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    formatters_grouped = plugin_manager.get_formatters_grouped()
    assert formatters_grouped['test'] == []
    assert formatters_grouped['json'] == [httpie.plugins.builtin.JSONLinesFormatPlugin]
    assert formatters_grouped['html'] == [httpie.plugins.builtin.HTMLFormatPlugin]
    assert formatters_grouped['colors'] == [httpie.plugins.builtin.ColorsFormatPlugin]
    assert formatters_grouped['colors.256'] == []
    assert formatters_grouped['colors.16'] == []
    assert formatters_grouped['colors.8'] == [httpie.plugins.builtin.Colors8FormatPlugin]
    assert formatters

# Generated at 2022-06-12 00:25:04.349931
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    def _get_installed_plugins():
        pm = PluginManager()
        pm.load_installed_plugins()
        return pm

    class_ = _get_installed_plugins
    
    assert class_()

# Generated at 2022-06-12 00:25:07.961949
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    test_plugin_manager = PluginManager()
    test_plugin_manager.load_installed_plugins()
    auth_plugin_mapping = test_plugin_manager.get_auth_plugin_mapping()
    assert len(auth_plugin_mapping) == 5
    assert auth_plugin_mapping['bearer'] == httpie.plugins.auth.bearer.BearerAuthPlugin



# Generated at 2022-06-12 00:25:12.766983
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    class A: pass
    class B(A): pass
    class C: pass
    pm = PluginManager()
    pm.register(A, B, C)
    assert set(pm.filter(A)) == {A, B}
    assert set(pm.filter(B)) == {B}
    assert set(pm.filter(C)) == {C}

# Generated at 2022-06-12 00:25:17.914081
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    tmpPluginManager = PluginManager()
    tmpPluginManager.register(
        DefaultFormatter,
        JSONFormatter,
        ExtendedJSONFormatter,
        PrettyJSONFormatter
    )
    assert tmpPluginManager.get_formatters_grouped() == {
        'Default': [DefaultFormatter],
        'JSON': [JSONFormatter, ExtendedJSONFormatter, PrettyJSONFormatter]
    }


plugin_manager = PluginManager()

# Generated at 2022-06-12 00:25:19.540772
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    p = PluginManager()
    p.register(p)
    assert len(p.get_formatters_grouped().keys()) > 0

# Generated at 2022-06-12 00:25:23.305195
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    pluginManager = PluginManager()
    pluginManager.load_installed_plugins()
    print(pluginManager.get_formatters())
    print(pluginManager.get_formatters_grouped())


# Generated at 2022-06-12 00:25:30.640799
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0

    # There are auth, formatter, output processing and adapter plugins installed
    plugins_by_type = {
        'Auth': set(plugin_manager.filter(AuthPlugin)),
        'Formatter': set(plugin_manager.filter(FormatterPlugin)),
        'Converter': set(plugin_manager.filter(ConverterPlugin)),
        'Transport': set(plugin_manager.filter(TransportPlugin))
        }

    for plugin_type in plugins_by_type:
        plugin_set = plugins_by_type[plugin_type]

# Generated at 2022-06-12 00:25:32.016130
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    PluginManager.get_formatters_grouped()

# Generated at 2022-06-12 00:25:40.217113
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    plugin_manager = PluginManager()
    plugins = plugin_manager.get_auth_plugin_mapping()
    loaded_plugins = []
    for plugin in plugins:
        loaded_plugins_tuple = (plugin, plugins[plugin].auth_type, plugins[plugin].package_name)
        loaded_plugins.append(loaded_plugins_tuple)


# Generated at 2022-06-12 00:26:45.981294
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0, \
        'No plugin has been loaded'



# Generated at 2022-06-12 00:26:53.209696
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugins = [
    FormatterPlugin('type1', 'JSON'),
    FormatterPlugin('type2', 'JSON'),
    FormatterPlugin('type3', 'HTML'),
    FormatterPlugin('type4', 'HTML'),
    FormatterPlugin('type5', 'HTML'),
    ]
    pm = PluginManager()
    pm.register(*plugins)
    mapping = pm.get_formatters_grouped()
    assert len(mapping) == 2
    assert len(mapping['JSON']) == 2
    assert len(mapping['HTML']) == 3



# Generated at 2022-06-12 00:26:55.058897
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    assert len(plugin_manager) > 0


# Generated at 2022-06-12 00:26:56.692536
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) > 0


# Generated at 2022-06-12 00:26:58.179934
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    PluginManager.load_installed_plugins(PluginManager)


# Generated at 2022-06-12 00:27:03.058441
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    plugin_manager = PluginManager()
    plugin_manager.load_installed_plugins()
    result = plugin_manager.get_formatters_grouped().keys()
    expect_result = ['color', 'format', 'other']
    assert expect_result == result


# Generated at 2022-06-12 00:27:04.877635
# Unit test for method get_auth_plugin_mapping of class PluginManager
def test_PluginManager_get_auth_plugin_mapping():
    PluginManager()

    #Unit test for method get_formatters_grouped of class PluginManager

# Generated at 2022-06-12 00:27:07.324161
# Unit test for method load_installed_plugins of class PluginManager
def test_PluginManager_load_installed_plugins():
    pm = PluginManager()
    pm.load_installed_plugins()
    assert len(pm) >= 5

# Generated at 2022-06-12 00:27:10.295701
# Unit test for method filter of class PluginManager
def test_PluginManager_filter():
    p = PluginManager()
    p.register(FormatterPlugin)
    p.register(AuthPlugin)

    filtered = p.filter(AuthPlugin)
    assert FormatterPlugin not in filtered

# Generated at 2022-06-12 00:27:16.994691
# Unit test for method get_formatters_grouped of class PluginManager
def test_PluginManager_get_formatters_grouped():
    # create a new plugin_manager
    plugin_manager = PluginManager()
    # create a class which inherits from FormatterPlugin
    class MockOne(FormatterPlugin):
        group_name = 'MockGroupOne'
        
    class MockTwo(FormatterPlugin):
        group_name = 'MockGroupOne'
        
    class MockThree(FormatterPlugin):
        group_name = 'MockGroupTwo'
    
    class MockFour(FormatterPlugin):
        group_name = 'MockGroupTwo'
        
    # Get all the formatters
    mock_list = [MockOne, MockTwo, MockThree, MockFour]
    # Get the grouped formatters
    grouped_formatters = plugin_manager.get_formatters_grouped(mock_list)
    # Check if the result is right
    assert grouped