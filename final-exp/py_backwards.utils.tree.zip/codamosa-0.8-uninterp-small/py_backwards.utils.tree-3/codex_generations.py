

# Generated at 2022-06-25 23:14:36.318214
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_cases = [
        (
            "test_case_0",
            # Input
            (),
            # Output
            ()
        ),
    ]

    passed = 0
    failed = 0

    for i, test_case in enumerate(test_cases):
        name, args, ret = test_case

        try:
            assert ret == test_case_0(*args)
            print(f"\033[0;32m[{i}] Test '{name}' passed\033[0m")
            passed += 1
        except AssertionError as e:
            print(f"\033[0;31m[{i}] Test '{name}' failed\033[0m")

# Generated at 2022-06-25 23:14:37.515834
# Unit test for function replace_at
def test_replace_at():
    module_0 = module_0
    assert(True)


# Generated at 2022-06-25 23:14:41.002443
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_2 = module_0.AST()
    t_0 = get_closest_parent_of(a_s_t_2, a_s_t_2, type)
    assert t_0 is a_s_t_2


# Generated at 2022-06-25 23:14:49.456177
# Unit test for function find
def test_find():
    # Testing all types that implement find
    a_s_t_6 = ast.Add()
    a_s_t_7 = ast.alias()
    a_s_t_8 = ast.alias()
    a_s_t_9 = ast.alias()
    a_s_t_10 = ast.alias()
    a_s_t_11 = ast.alias()
    a_s_t_12 = ast.alias()
    a_s_t_13 = ast.alias()
    a_s_t_14 = ast.alias()
    a_s_t_15 = ast.alias()

# Generated at 2022-06-25 23:14:57.224589
# Unit test for function find
def test_find():
    tree = ast.parse('def f():pass')

    func_defs = find(tree, ast.FunctionDef)
    assert len(list(func_defs)) == 1
    func_def = list(func_defs)[0]

    func_def_names = find(tree, ast.Name)
    assert len(list(func_def_names)) == 1
    func_def_name = list(func_def_names)[0]
    assert func_def_name.id == 'f'

    assert get_closest_parent_of(tree, func_def_name, ast.FunctionDef) == func_def

# Generated at 2022-06-25 23:14:58.529292
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module = ast.parse("answer = 42")
    body = get_non_exp_parent_and_index(module, module.body[0])
    pass


# Generated at 2022-06-25 23:15:02.200295
# Unit test for function insert_at
def test_insert_at():
    tree = module_0.AST()
    parent = module_0.AST()
    node = module_0.AST()
    num = 100
    insert_at(num, parent, node)
    insert_at(num, tree, [node, parent])
    insert_at(num, tree, parent)

# Generated at 2022-06-25 23:15:13.595282
# Unit test for function get_parent
def test_get_parent():
    # Tests
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_

# Generated at 2022-06-25 23:15:21.468134
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.Expression()
    a_s_t_1 = module_0.Call()
    a_s_t_0.body = [a_s_t_1]
    a_s_t_1.args = [a_s_t_0]
    a_s_t_2 = module_0.module.Module()
    a_s_t_2.body = [a_s_t_0]
    a_s_t_3 = module_0.AST()
    result_0 = get_closest_parent_of(a_s_t_2, a_s_t_3, module_0.Expression)


# Generated at 2022-06-25 23:15:25.605018
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    node_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    type__0 = None
    nodes_0 = find(node_0, type__0)


# Generated at 2022-06-25 23:15:33.897027
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = []
    a_s_t_0.body.append(ast.Expr(value=ast.Name(id='1', ctx=ast.Load())))
    a_s_t_0.body.append(ast.Expr(value=ast.Name(id='2', ctx=ast.Load())))
    assert len(list(find(a_s_t_0, ast.Expr))) == 2


# Generated at 2022-06-25 23:15:36.198671
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import get_non_exp_parent_and_index
    assert get_non_exp_parent_and_index


# Generated at 2022-06-25 23:15:38.904905
# Unit test for function find
def test_find():
    tree = ast.parse('b = 1')
    node = find(tree, ast.Module)
    assert next(node).body[0] == tree.body[0]


# Generated at 2022-06-25 23:15:43.320128
# Unit test for function find
def test_find():
    a_0 = ast.parse('a.b')
    a_1 = get_closest_parent_of(a_0, a_0.body[0].value, ast.Attribute)
    a_2 = find(a_0, ast.Attribute)
    assert next(a_2) is a_1



# Generated at 2022-06-25 23:15:45.524782
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    assert get_closest_parent_of() == a_s_t_0

# Generated at 2022-06-25 23:15:46.830813
# Unit test for function replace_at
def test_replace_at():
    assert replace_at(0, 0, 0) == None


# Generated at 2022-06-25 23:15:51.063735
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('import unittest')

    try:
        get_closest_parent_of(tree, tree, ast.FunctionDef)
    except NodeNotFound:
        pass
    else:
        assert False

    get_closest_parent_of(tree, tree.body[0], ast.Module)
    get_closest_parent_of(tree, tree.body[0], ast.AST)
    assert False


# Generated at 2022-06-25 23:15:55.674492
# Unit test for function get_parent
def test_get_parent():
    tree = module_0.AST()
    node = module_0.AST()
    rebuild = True
    get_parent(tree, node, rebuild)


# Generated at 2022-06-25 23:15:58.248366
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    assert get_non_exp_parent_and_index(a_s_t_0, a_s_t_0) is not None


# Generated at 2022-06-25 23:16:04.093354
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    try:
        a_s_t_0 = module_0.AST()
        get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.Module)
    except NodeNotFound:
        pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 23:16:18.549388
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_0_copy = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_5.body = [a_s_t_2, a_s_t_3, a_s_t_4]
    _parents[a_s_t_2] = a_s_t_5
    _parents[a_s_t_3] = a_s_t_5

# Generated at 2022-06-25 23:16:22.808911
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    try:
        tuple_0 = get_parent(a_s_t_0, a_s_t_0)
    except NodeNotFound as e_0:
        print(e_0)


# Generated at 2022-06-25 23:16:33.610114
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_2._fields = ['_fields', '_attributes', '_lineno', '_col_offset']
    a_s_t_3 = module_0.AST()
    a_s_t_3._fields = ['_fields', '_attributes', '_lineno', '_col_offset']
    a_s_t_4 = module_0.AST()
    a_s_t_4._fields = ['_fields', '_attributes', '_lineno', '_col_offset']
    a_s_t_5 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:16:36.139344
# Unit test for function find

# Generated at 2022-06-25 23:16:48.150568
# Unit test for function replace_at
def test_replace_at():
    # Test case 1:
    a_s_t_1 = module_0.AST()
    assert get_parent(a_s_t_1, a_s_t_1) == a_s_t_1
    assert isinstance(get_parent(a_s_t_1, a_s_t_1), module_0.AST)
    assert get_non_exp_parent_and_index(a_s_t_1, a_s_t_1) == (a_s_t_1, 0)
    assert isinstance(get_non_exp_parent_and_index(a_s_t_1, a_s_t_1), tuple)
    assert find(a_s_t_1, type(None)) == ()

# Generated at 2022-06-25 23:16:51.216364
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    insert_at(0, a_s_t_0, a_s_t_0)
    replace_at(0, a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:16:53.831838
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = list(find(a_s_t_0, type(a_s_t_0)))


# Generated at 2022-06-25 23:16:54.694661
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

# Generated at 2022-06-25 23:17:00.286813
# Unit test for function find
def test_find():
    # AssertionError: assert [] == <filter object at 0x7fa0e67f97d0>
    typed_ast.tests.assert_raises(AssertionError, find, ast.FunctionDef(), ast.AST)
    # AssertionError: assert [] == <filter object at 0x7fa0e67f9390>
    typed_ast.tests.assert_raises(AssertionError, find, ast.Expression(), ast.AST)


# Generated at 2022-06-25 23:17:03.170881
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    assert module_0.AST == get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:17:08.046757
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    test_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert test_0


import random


# Generated at 2022-06-25 23:17:09.059497
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert True == test_case_0()

# Generated at 2022-06-25 23:17:15.502322
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    result_0 = get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.AST)
    result_1 = get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.AST)

# Generated at 2022-06-25 23:17:17.997111
# Unit test for function find
def test_find():
    a_s_t_3 = module_0.AST()
    list_0 = find(a_s_t_3, ast.mod)



# Generated at 2022-06-25 23:17:23.423814
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    
    # Setup
    a_s_t_0 = module_0.AST()
    type_0 = module_0.Module
    
    # Call get_closest_parent_of
    get_closest_parent_of(a_s_t_0, a_s_t_0, type_0)



# Generated at 2022-06-25 23:17:27.707758
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    assert (get_non_exp_parent_and_index(a_s_t_0, a_s_t_0) == (a_s_t_0, 0))
    assert (get_non_exp_parent_and_index(a_s_t_0, a_s_t_0) == (a_s_t_0, 0))

# Generated at 2022-06-25 23:17:35.815422
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..utils import test_utils
    from ..utils import check_ast
    import ast

    # Create tree for test case
    a_s_t_0 = ast.AST()
    a_s_t_1 = ast.AST()
    setattr(a_s_t_0, 'a', a_s_t_1)

    # Run function
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)

    # Check result
    assert tuple_0 == (a_s_t_0, 'a')


# Generated at 2022-06-25 23:17:44.622807
# Unit test for function replace_at
def test_replace_at():
    # Case 1: list
    try:
        a_s_t_0 = module_0.AST()
        a_s_t_1 = module_0.AST()
        replace_at(a_s_t_0, a_s_t_1, [a_s_t_0, a_s_t_1])
    except NodeNotFound:
        pass

    # Case 2: ast
    try:
        a_s_t_0 = module_0.AST()
        a_s_t_1 = module_0.AST()
        replace_at(a_s_t_0, a_s_t_1, a_s_t_0)
    except NodeNotFound:
        pass


# Generated at 2022-06-25 23:17:47.332718
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Expr(module_0.Call(module_0.Name('foo', module_0.Load()), [], []))]
    assert(get_closest_parent_of(a_s_t_0, a_s_t_0.body[0].value, module_0.AST) == a_s_t_0.body[0])

# Generated at 2022-06-25 23:17:52.942618
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = ast.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_2 = ast.AST()
    a_s_t_3 = get_parent(a_s_t_2, a_s_t_2, rebuild=False)
    a_s_t_4 = ast.AST()
    a_s_t_5 = get_parent(a_s_t_4, a_s_t_4, rebuild=True)


# Generated at 2022-06-25 23:18:06.558821
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    source_code = "def foo():\n  bar()"
    tree = ast.parse(source_code)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert ast.dump(parent) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name(id='bar', ctx=Load()), args=[], keywords=[]))], decorator_list=[])])"
    assert index == 0

# Generated at 2022-06-25 23:18:17.894822
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.AST()
    tuple_1 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_2)
    assert tuple_1[0] == a_s_t_2
    assert tuple_1[1] == 0
    expr_0 = module_0.NameConstant()
    expr_0.value = "E"
    slice_0 = module_0.Slice()
    try:
        raise IndexError
    except IndexError:
        pass
    slice_0.value = expr_0
    expr_1 = module_0.Dict()
    expr_1.keys = [expr_0]
    expr_2 = module_0.Dict()
    expr_2.keys = [expr_1]
    slice

# Generated at 2022-06-25 23:18:22.954911
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    print("Test: start test_get_non_exp_parent_and_index")
    test_case_0()
    print("Test: finished test_get_non_exp_parent_and_index")

# Generated at 2022-06-25 23:18:25.628680
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    replace_at(0, a_s_t_0, a_s_t_0)
    return


# Generated at 2022-06-25 23:18:27.917093
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    find_0 = find(a_s_t_0, type(a_s_t_0))


# Generated at 2022-06-25 23:18:32.232138
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.Module()
    a_s_t_0 = ast.AST()
    ast.copy_location(a_s_t_0, module_0)
    assert module_0 is get_closest_parent_of(a_s_t_0, a_s_t_0, ast.Module)


# Generated at 2022-06-25 23:18:36.964093
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    replace_at(tuple_0[1], tuple_0[0], [a_s_t_0])


# Generated at 2022-06-25 23:18:39.867118
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("def f():\n    pass\n")
    f = tree.body[0]
    f.body[0].value.args[0].id  # type: ignore

    parent = get_parent(tree, f)
    assert parent is tree



# Generated at 2022-06-25 23:18:45.161376
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test case 1
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    # Assumption: We assume that functions raise exceptions when passed invalid arguments.
    # We also assume that exceptions are raised when expected.
    assert tuple_0 == (None, None)

# Generated at 2022-06-25 23:18:54.703890
# Unit test for function get_closest_parent_of

# Generated at 2022-06-25 23:19:05.866947
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Pass() for _ in range(8)]
    a_s_t_0.body.append(module_0.Expr(value=module_0.Name(id='module_0', ctx=module_0.Load())))
    replace_at(4, a_s_t_0, module_0.Pass())


# Generated at 2022-06-25 23:19:08.142020
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    get_closest_parent_of(a_s_t_0, a_s_t_0, type_=module_0.AST)

# Generated at 2022-06-25 23:19:09.726501
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:19:13.974838
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0 = typed_ast._ast3
    import typed_ast._ast3
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:19:16.419141
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    tuple_0 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:19:20.302875
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = list(find(a_s_t_0, module_0.AST))
    assert list_0 == [a_s_t_0]


# Generated at 2022-06-25 23:19:23.607575
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Raise Exception: NodeNotFound
    with pytest.raises(Exception) as e:
        test_case_0()
    assert str(e).find("Parent for <_ast3.AST object at") != -1, "unexpected error message"

# Generated at 2022-06-25 23:19:30.688368
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    
    a_s_t_0 = module_0.AST()
    assert get_non_exp_parent_and_index(a_s_t_0, a_s_t_0) \
            == (a_s_t_0, 0)
    a_s_t_1 = module_0.AST()
    a_s_t_0.body = [a_s_t_1]
    assert get_non_exp_parent_and_index(a_s_t_0, a_s_t_1) \
            == (a_s_t_0, 0)
    a_s_t_2 = module_0.AST()
    a_s_t_0.body[0] = a_s_t_2

# Generated at 2022-06-25 23:19:33.519584
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.Module()
    a_s_t_1 = module_0.Module()
    replace_at(0, a_s_t_0, a_s_t_1)

# Generated at 2022-06-25 23:19:37.977843
# Unit test for function get_parent
def test_get_parent():
    try:
        module_0 = ast.parse('def foo():\n    return 42\n')
        assert get_parent(module_0, module_0) == module_0
    except BaseException as e:
        print("test_get_parent caused exception %s" % str(e))

# Generated at 2022-06-25 23:19:49.022063
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = ast.fix_missing_locations(ast.parse('''
if True:
    print(True)
'''))
    get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:19:57.216547
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    # check that tuple is of type tuple
    _tuple_0_0 = isinstance(tuple_0, tuple)
    assert _tuple_0_0
    # check that tuple length is 2
    _tuple_0_1 = len(tuple_0)
    assert _tuple_0_1 == 2
    # check that tuple[0] is a_s_t_0
    _tuple_0_2 = tuple_0[0] == a_s_t_0
    assert _tuple_0_2
    # check that tuple[1] is 0

# Generated at 2022-06-25 23:20:00.968944
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    get_parent(a_s_t_0, a_s_t_1)

# Generated at 2022-06-25 23:20:10.196947
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Construct a sample ast
    module_1 = ast.Module([
        ast.ImportFrom(
            module='typed_ast._ast3',
            names=[ast.alias(
                name='AST',
                asname=None)],
            level=0)
    ])

# Generated at 2022-06-25 23:20:19.547820
# Unit test for function get_parent
def test_get_parent():
    from ._test_data import get_parents_data as data
    for node, parent in data:
        assert get_parent(node, parent) is parent
        assert get_parent(parent, parent) is parent
        assert get_parent(parent, node) is parent
        assert get_parent(node, parent, rebuild=True) is parent
        assert get_parent(parent, parent, rebuild=True) is parent
        assert get_parent(parent, node, rebuild=True) is parent



# Generated at 2022-06-25 23:20:28.826666
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    n = 1
    while n <= 1:
        test_case_0()
        n += 1


if __name__ == '__main__':
    import sys
    import logging
    logging.basicConfig(level=logging.DEBUG)
    # if len(sys.argv) > 1:
    #     input_file_name = sys.argv[1]
    #     output_file_name = sys.argv[2]
    # else:
    #     input_file_name = "tests/test_get_non_exp_parent_and_index.in"
    #     output_file_name = "tests/test_get_non_exp_parent_and_index.out"
    # inp = open(input_file_name, 'r')
    # outp = open(output_file_name,

# Generated at 2022-06-25 23:20:30.054873
# Unit test for function get_parent
def test_get_parent():
    pass


# Generated at 2022-06-25 23:20:34.321864
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test case 0
    a_s_t_0 = module_0.AST()
    i_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, type)

# Generated at 2022-06-25 23:20:40.828217
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    import typing
    import typed_ast.ast3 as ast3
    module_0 = ast3.parse("if True:\n\n    a = 5\n")
    stmt_0 = module_0.body[0]
    assign_0 = stmt_0.body[0]
    get_non_exp_parent_and_index(module_0, assign_0)

# Generated at 2022-06-25 23:20:45.096432
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    replace_at(0, a_s_t_0, a_s_t_0)

    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    replace_at(0, a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:21:04.691282
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index('', '') is None


# Generated at 2022-06-25 23:21:05.215557
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass


# Generated at 2022-06-25 23:21:07.249210
# Unit test for function get_parent
def test_get_parent():
    tree = []
    node = ()
    rebuild = test_get_parent.rebuild
    parent = get_parent(tree, node, rebuild)



# Generated at 2022-06-25 23:21:11.189495
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # setup
    a_s_t_0 = module_0.AST()

    # input arguments
    tree = a_s_t_0
    node = a_s_t_0

    # expected results
    expected_tuple = (a_s_t_0, 0)

    # function under test
    output_tuple = get_non_exp_parent_and_index(tree, node)

    # verify results
    assert expected_tuple == output_tuple

# Generated at 2022-06-25 23:21:15.987795
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tuple_0 = (module_0.AST(), 0)
    a_s_t_0 = module_0.AST()
    tuple_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert cmp(tuple_0, tuple_1) == 0

# Generated at 2022-06-25 23:21:25.910431
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
	module_0 = typed_ast.ast3.Module()
	function_0 = typed_ast.ast3.FunctionDef()
	module_0.body.append(function_0)
	if_0 = typed_ast.ast3.If()
	function_0.body.append(if_0)
	while_0 = typed_ast.ast3.While()
	if_0.body.append(while_0)
	try_0 = typed_ast.ast3.Try()
	while_0.body.append(try_0)
	with_0 = typed_ast.ast3.With()
	try_0.body.append(with_0)
	for_0 = typed_ast.ast3.For()
	with_0.body.append(for_0)
	assert get_closest_parent

# Generated at 2022-06-25 23:21:31.946241
# Unit test for function replace_at
def test_replace_at():
    path = 'tests/inputs/test_ast/test_replace_at.py'
    tree = ast.parse('\n'.join(open(path).readlines()))

    for node in ast.walk(tree):
        if isinstance(node, ast.Expr):
            replace_at(0, get_parent(tree, node), node.value)

    ast.fix_missing_locations(tree)

    code = compile(tree, path, "exec")
    exec(code)

    assert a == 5
    assert b == 7


# Generated at 2022-06-25 23:21:41.235340
# Unit test for function get_parent
def test_get_parent():
    # test_case_0
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.arg('a', None)]
    a_s_t_0.body.extend([module_0.arg('a', None), module_0.arg('a', None)])
    a_s_t_0.body.extend([module_0.arg('a', None), module_0.arg('a', None)])
    a_s_t_0.body.extend([module_0.arg('a', None), module_0.arg('a', None)])
    a_s_t_0.body.extend([module_0.arg('a', None), module_0.arg('a', None)])
    a_s_t_0

# Generated at 2022-06-25 23:21:44.221261
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, type(a_s_t_0))


# Generated at 2022-06-25 23:21:51.716260
# Unit test for function get_parent
def test_get_parent():
    # TODO: implement assertion

    # Test 1
    a_s_t_0 = module_0.AST()
    tuple_0 = get_parent(a_s_t_0, a_s_t_0)

    # Test 2
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body = [a_s_t_1]
    tuple_0 = get_parent(a_s_t_0, a_s_t_1)

    # Test 3
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body = [a_s_t_1]
    a

# Generated at 2022-06-25 23:22:16.623879
# Unit test for function get_parent
def test_get_parent():
    test_tree = {}
    a_s_t_0 = ast.Module()
    tup_0 = (a_s_t_0, a_s_t_0)
    _build_parents(test_tree)
    assert (get_parent(test_tree, a_s_t_0) == a_s_t_0), "Unable to resolve get_parent"


# Generated at 2022-06-25 23:22:28.251752
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_0 = module_0.AST()
    ast_1 = module_0.AST()
    ast_0.body = [ast_1]
    assert get_closest_parent_of(ast_0, ast_1, module_0.AST) is ast_0
    ast_2 = module_0.AST()
    ast_3 = module_0.AST()
    ast_4 = module_0.AST()
    ast_2.body = [ast_3, ast_4]
    assert get_closest_parent_of(ast_2, ast_4, module_0.AST) is ast_2
    ast_5 = module_0.AST()
    ast_6 = module_0.AST()
    ast_7 = module_0.AST()

# Generated at 2022-06-25 23:22:38.357528
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Assign()]
    a_s_t_0.body[0].targets = [module_0.Name()]
    a_s_t_0.body[0].targets[0].ctx = module_0.Store()
    a_s_t_0.body[0].targets[0].id = 'x'
    a_s_t_0.body[0].value = module_0.Num()
    a_s_t_0.body[0].value.n = 0
    a_s_t_0.body[0].value.n = 0

# Generated at 2022-06-25 23:22:44.645474
# Unit test for function get_parent
def test_get_parent():
    import ast
    import _ast
    import typed_ast._ast27 as typed_ast_module
    from typing import NoReturn, Union, List
    union_0 = None  # type: Union[ast.AST]
    ast_0 = module_0.AST()
    union_0 = ast_0
    get_parent(ast_0, union_0)
    get_parent(ast_0, union_0, True)
    list_0 = None  # type: List[ast.AST]
    module_0.AST()
    get_parent(ast_0, list_0)
    get_parent(ast_0, list_0, True)


# Generated at 2022-06-25 23:22:55.216789
# Unit test for function find

# Generated at 2022-06-25 23:22:59.083130
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(module_0.AST(), module_0.AST())


# Generated at 2022-06-25 23:23:03.215507
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Setup
    a_s_t_0 = module_0.AST()
    node_0 = a_s_t_0.body
    type_0 = module_0.FunctionDef

    # Testing
    result = get_closest_parent_of(a_s_t_0, node_0, type_0)

    # Verification
    assert result is a_s_t_0

# Generated at 2022-06-25 23:23:06.559832
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast.ast3 import Assign
    a_s_t_0 = Assign()
    assert get_closest_parent_of(a_s_t_0, a_s_t_0, (Assign,)) == a_s_t_0

# Generated at 2022-06-25 23:23:10.985355
# Unit test for function get_parent
def test_get_parent():
    # TODO: Add more tests
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Str('foo')]
    actual_ast_0 = get_parent(a_s_t_0, module_0.Str('foo'))
    expected_ast_0 = a_s_t_0
    assert actual_ast_0 == expected_ast_0


# Generated at 2022-06-25 23:23:12.838257
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Create objects
    module_0 = ast.Module()
    a_s_t_0 = get_closest_parent_of(module_0, module_0, ast.AST)

# Generated at 2022-06-25 23:24:19.173834
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = None
    tree = None
    get_closest_parent_of(tree, node, ast.AST)

# Generated at 2022-06-25 23:24:20.304172
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Setup

    # Exercise

    # Verify
    assert True # TODO: implement your own test here


# Generated at 2022-06-25 23:24:26.670048
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = ast.Module()
    statement_0 = a_s_t_0.body[0]
    statement_1 = a_s_t_0.body[1]
    statement_2 = a_s_t_0.body[2]
    result_0 = get_parent(a_s_t_0, statement_0)
    assert isinstance(result_0, ast.Module)
    result_1 = get_parent(a_s_t_0, statement_1)
    assert isinstance(result_1, ast.Module)
    result_2 = get_parent(a_s_t_0, statement_2)
    assert isinstance(result_2, ast.Module)
