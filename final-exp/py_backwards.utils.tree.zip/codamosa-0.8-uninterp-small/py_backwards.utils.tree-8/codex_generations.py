

# Generated at 2022-06-25 23:14:25.241982
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse("def foo():\n    pass")
    parent, index = get_non_exp_parent_and_index(node, node.body[0])
    assert isinstance(parent, ast.Module)
    assert index == 0


# Generated at 2022-06-25 23:14:31.332291
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    one = ast.Num(n=1)
    two = ast.Num(n=2)
    three = ast.Num(n=3)
    plus = ast.Add()
    assigns = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                         value=ast.BinOp(left=one, op=plus, right=two))

    tree = ast.Module(body=[assigns, three])

    one_parent = get_closest_parent_of(tree, one, ast.expr)
    two_parent = get_closest_parent_of(tree, two, ast.expr)
    three_parent = get_closest_parent_of(tree, three, ast.expr)

# Generated at 2022-06-25 23:14:32.692516
# Unit test for function find

# Generated at 2022-06-25 23:14:36.246229
# Unit test for function find
def test_find():
    # Test case 0
    assert all(True for _ in find(None, None))

    # Test case 1
    assert all(True for _ in find(None, ast.Str))

    # Test case 2
    assert all(True for _ in find(None, ast.ClassDef))


# Generated at 2022-06-25 23:14:37.115467
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-25 23:14:37.948534
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False



# Generated at 2022-06-25 23:14:41.761289
# Unit test for function find
def test_find():
    a_s_t_1 = ast.parse('def foo():\n\tpass').body[0]
    type_0 = ast.FunctionDef
    function_def_0 = find(a_s_t_1, type_0)
    assert function_def_0 is not None


# Generated at 2022-06-25 23:14:42.648383
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()



# Generated at 2022-06-25 23:14:45.054612
# Unit test for function find
def test_find():
    a_s_t = ast.parse('import os')
    assert list(find(a_s_t, ast.Import)) == a_s_t.body

# Generated at 2022-06-25 23:14:49.624160
# Unit test for function find
def test_find():
    tree = ast.parse('print(42)')
    find_tests = [
        (ast.Expr, True),
        (ast.Name, True),
        (ast.Num, True),
        (ast.Print, True),
        (ast.Str, False)
    ]

    for type_, expected_result in find_tests:
        found_nodes = find(tree, type_)
        nodes_found = next(found_nodes, False)
        assert nodes_found == expected_result



# Generated at 2022-06-25 23:14:54.896992
# Unit test for function find
def test_find():
    a_s_t_0 = ast.parse('a = b+c')
    list_0 = find(a_s_t_0, list)
    

# Generated at 2022-06-25 23:15:02.627712
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    # Case 0
    a_s_t_0 = ast.parse("while True: pass")
    a_s_t_1 = a_s_t_0.body[0]
    a_s_t_2 = a_s_t_1.body[0]
    a_s_t_3 = get_closest_parent_of(a_s_t_0, a_s_t_2, ast.While)
    assert a_s_t_1 == a_s_t_3

    # Case 1
    a_s_t_0 = ast.parse("while True: pass")
    a_s_t_1 = a_s_t_0.body[0]
    a_s_t_2 = a_s_t_1.body[0]
    a_s_

# Generated at 2022-06-25 23:15:03.655042
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False


# Generated at 2022-06-25 23:15:14.997335
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Case 0
    if True:
        # Test
        a_s_t_0 = ast.Module([], type_ignores=[])
        a_s_t_0.body = [ast.FunctionDef(name='test', args=None, body=[], decorator_list=[], returns=None)]
        a_s_t_0.body[0].body = [ast.Expr(value=ast.Attribute())]
        a_s_t_0.body[0].body[0].value.value = ast.Name('a', ctx=ast.Load())
        a_s_t_0.body[0].body[0].value.elts = [ast.Name('b', ctx=ast.Load())]
        a_s_t_0.body[0].decorator_list[0] = ast

# Generated at 2022-06-25 23:15:16.546389
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(test_case_0, None) == None



# Generated at 2022-06-25 23:15:25.656155
# Unit test for function find
def test_find():
    a = ast.parse('a = 1', mode='eval')
    a_s_t = ast.parse('a = 1', mode='eval')
    a_s_t_0 = a_s_t.body
    a_s_t_0_0 = a_s_t_0.value
    a_s_t_0_1 = a_s_t_0.targets[0]
    int_0 = ast.parse('1', mode='eval').body
    a_s_t_1 = a_s_t_0_1
    a_s_t_2 = a_s_t_0_0
    for _ in find(a_s_t, ast.Expression):
        a_s_t_0_0 = a_s_t_0_0

# Generated at 2022-06-25 23:15:33.973026
# Unit test for function get_parent
def test_get_parent():
    ast0 = None
    parent0 = get_parent(ast0, ast0, True)
    ast1 = ast.Module(body=[ast.Pass(), ast.Pass()])
    parent1 = get_parent(ast1, ast.Pass(), True)
    assert parent1 == ast1
    ast2 = ast.Module(
        body=[ast.FunctionDef(name='f', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Pass(), ast.Pass()], decorator_list=[])])
    parent2 = get_parent(ast2, ast.Pass(), True)
    assert parent2.name == 'f'

# Generated at 2022-06-25 23:15:38.347012
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source_code = ast.parse('print("hello")')
    parent_node, index = get_non_exp_parent_and_index(source_code, source_code.body[0].value)
    assert type(parent_node) == ast.Module  # does not crash
    assert index == 0



# Generated at 2022-06-25 23:15:48.039514
# Unit test for function get_parent
def test_get_parent():
    # Test 1
    a_s_t_0 = ast.parse("x = 2")
    a_s_t_1 = ast.parse("x = 2")
    a_s_t_2 = ast.parse("2")
    a_s_t_3 = ast.parse("x = 2")
    a_s_t_4 = ast.parse("2")
    a_s_t_5 = ast.parse("2")
    a_s_t_6 = ast.parse("2")
    a_s_t_7 = ast.parse("x = 2")
    a_s_t_8 = ast.parse("2")
    a_s_t_9 = ast.parse("2")
    a_s_t_10 = ast.parse("2")
    a_s_t_11 = ast

# Generated at 2022-06-25 23:15:50.379554
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    simple_code = "a = 2 + 3 * 2"
    tree = ast.parse(simple_code)
    assert (get_non_exp_parent_and_index(tree, tree.body[0].value.right) ==
            (tree, 0))

# Generated at 2022-06-25 23:15:58.248891
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = ast.parse('[1, 2, 3]')
    int_0 = a_s_t_0.body[0].value.elts[0]
    a_s_t_1 = get_closest_parent_of(a_s_t_0, int_0, ast.List)
    assert(str(a_s_t_1) == '[1, 2, 3]')

# Generated at 2022-06-25 23:16:00.026091
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:16:06.821413
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import maker

    tree = astor.parse_file('/Users/taylorswift/Downloads/SrcML-AST-Exporter/examples/test1.py')
    m = maker.Maker(tree)
    m.f_set_lineno(9)

    for node in ast.walk(tree):
        if isinstance(node, ast.Tuple):
            parent = get_closest_parent_of(tree, node, ast.ClassDef)

# Generated at 2022-06-25 23:16:18.445335
# Unit test for function find
def test_find():
    a_s_t_0 = None
    s_t_r_1 = ''
    i_n_t_2 = 0
    l_i_s_t_3 = []
    f_i_l_e_4 = None
    l_i_s_t_comp_5 = []
    l_i_s_t_comp_5.extend(find(a_s_t_0, ast.Module))
    l_i_s_t_comp_5.extend(find(a_s_t_0, ast.Interactive))
    l_i_s_t_comp_5.extend(find(a_s_t_0, ast.Expression))

# Generated at 2022-06-25 23:16:22.328941
# Unit test for function find
def test_find():
    """
    Tests the find function
    """

# Generated at 2022-06-25 23:16:33.144794
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a = ast.parse('def func(x): return x+1')
    func = a.body[0]
    ret = func.body[0]
    add = ret.value
    assert get_non_exp_parent_and_index(a, add) == (ret, 0)


if __name__ == "__main__":
    import sys
    import os
    import json
    import pytest
    file_path = os.path.abspath(__file__)
    sys.path.append(os.path.dirname(os.path.dirname(file_path)))

    if '--list' in sys.argv:
        result = pytest.main(['-s', file_path, '--collect-only'])

# Generated at 2022-06-25 23:16:34.030757
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass


# Generated at 2022-06-25 23:16:47.799985
# Unit test for function find
def test_find():
    a_s_t_0 = None
    iter_0 = find(a_s_t_0, None)
    #    assert test_find_0 in iter_0
    #    assert test_find_1 in iter_0
    #    assert test_find_2 in iter_0
    #    assert test_find_3 in iter_0
    #    assert test_find_4 in iter_0
    #    assert test_find_5 in iter_0
    #    assert test_find_6 in iter_0
    #    assert test_find_7 in iter_0
    #    assert test_find_8 in iter_0
    #    assert test_find_9 in iter_0
    #    assert test_find_10 in iter_0


# Generated at 2022-06-25 23:16:50.226002
# Unit test for function find
def test_find():
    a_s_t_0 = None
    a_s_t_1 = None
    iterable_0 = find(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:16:57.136198
# Unit test for function find
def test_find():
    ast_0 = ast.FunctionDef('f', None, [], [], [], None, None)
    str_0 = 'f'
    bool_0 = str_0 == 'f'
    if bool_0:
        bool_0 = bool_0
    else:
        bool_0 = not bool_0
    int_0 = 2 + 2
    str_1 = str(int_0)
    print(str_1)
    list_0 = list(find(ast_0, ast.FunctionDef))
    assert(list_0[0].name == 'f')


# Generated at 2022-06-25 23:17:08.224281
# Unit test for function find
def test_find():
    a_s_t_0 = None
    for each in find(a_s_t_0, ast.Tuple):
        pass


# Generated at 2022-06-25 23:17:09.229506
# Unit test for function replace_at
def test_replace_at():
    assert True


# Generated at 2022-06-25 23:17:20.231775
# Unit test for function find
def test_find():
    import sys
    import ast
    import inspect
    from typing import List
    lines = {}  # type: Dict[int, str]
    with open(inspect.getsourcefile(test_find)) as file:
        for (lineno, line) in enumerate(file.readlines()):
            lines[lineno] = line
    a_s_t_0 = ast.parse(lines[3] + lines[4] + lines[5] + lines[6])
    a_s_t_1 = ast.parse(lines[3] + lines[4] + lines[5] + lines[6])
    a_s_t_2 = ast.parse(lines[3] + lines[4] + lines[5] + lines[6])

# Generated at 2022-06-25 23:17:28.265754
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = ast.Call()
    a_s_t_1 = ast.Name('str', None)
    a_s_t_3 = ast.Num(23)
    a_s_t_4 = ast.Name('int', None)
    a_s_t_5 = ast.Call()
    a_s_t_6 = ast.Name('Number', None)
    a_s_t_7 = ast.NameConstant(False)
    a_s_t_8 = ast.Name('a', None)
    a_s_t_9 = ast.Name('x', None)
    a_s_t_10 = ast.Name('a', None)
    a_s_t_11 = ast.Assign()

# Generated at 2022-06-25 23:17:38.517710
# Unit test for function replace_at
def test_replace_at():
    # Initialization of a_s_t_0
    def_0 = ast.FunctionDef(
        name='foo',
        body=[
            ast.Pass(),
        ],
        decorator_list=[],
        args=ast.arguments(
            args=[
                ast.arg('x', None),
            ],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        )
    )
    a_s_t_0 = ast.Module(
        body=[
            def_0,
        ]
    )

    # Loop
    while True:
        a_s_t_1 = tuple_0[0]
        int_0 = tuple_0[1]

# Generated at 2022-06-25 23:17:43.370931
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    src = 'if True:\n    pass\nelif False:\n    pass'
    module = ast.parse(src)
    node = module.body[0].orelse[0]
    parent = get_closest_parent_of(module, node, ast.If)
    assert isinstance(parent, ast.If)
    assert node in parent.body



# Generated at 2022-06-25 23:17:46.526851
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test case 0
    a_s_t_0 = None
    print(get_closest_parent_of(a_s_t_0, a_s_t_0, ast.FunctionDef))



# Generated at 2022-06-25 23:17:52.296145
# Unit test for function replace_at
def test_replace_at():
    # Building Module
    a_s_t_0 = ast.parse('def f():\n    pass')
    # Buildin FunctionDef node
    a_s_t_1 = a_s_t_0.body[0]
    # Building Pass node
    a_s_t_2 = a_s_t_1.body[0]
    # Replace Pass node with 'return None'
    replace_at(0, a_s_t_1, ast.Return(value=ast.Name(id='None',
                                                     ctx=ast.Load())))



# Generated at 2022-06-25 23:17:54.475070
# Unit test for function find
def test_find():
    a_s_t_1 = None
    iter_0 = find(a_s_t_1, None)

    next(iter_0)

# Generated at 2022-06-25 23:17:56.634652
# Unit test for function find
def test_find():
    assert find(None, None) == iter(())

# Generated at 2022-06-25 23:18:20.949676
# Unit test for function find
def test_find():
    # ast with no attribute 'body'
    ast1 = ast.parse('1 + 2')

    # ast with attribute 'body'
    ast2 = ast.parse('pass')
    # ast with attribute 'body' and one node
    ast3 = ast.parse('pass; pass')
    # ast with attribute 'body' and more than one node
    ast4 = ast.parse('1 + 2; pass; a; ')

    assert len(list(find(ast1, ast.Module))) == 1
    assert len(list(find(ast2, ast.Module))) == 1
    assert len(list(find(ast3, ast.Module))) == 1
    assert len(list(find(ast4, ast.Module))) == 1

    assert len(list(find(ast1, ast.Module))) == 1

# Generated at 2022-06-25 23:18:27.207865
# Unit test for function replace_at
def test_replace_at():
    a_s_t_1 = ast.parse('print("foo")')
    function_definition_0 = get_closest_parent_of(a_s_t_1, a_s_t_1, ast.FunctionDef)
    a_s_t_2 = ast.parse('print("bar")')
    replace_at(0, function_definition_0, a_s_t_2)

# Generated at 2022-06-25 23:18:27.753133
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass


# Generated at 2022-06-25 23:18:30.770128
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    print(astor.to_source(test_case_0))


if __name__ == '__main__':
    test_get_closest_parent_of()

# Generated at 2022-06-25 23:18:31.301622
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert True



# Generated at 2022-06-25 23:18:33.473362
# Unit test for function find
def test_find():
    try:
        assert(list(find(ast.AST(), ast.AST)) == [])
    except:
        print("Failed test_find_0")


# Generated at 2022-06-25 23:18:35.073539
# Unit test for function replace_at

# Generated at 2022-06-25 23:18:38.674655
# Unit test for function find
def test_find():
    a_s_t_0 = None
    ast_list_0 = find(a_s_t_0, ast.FunctionDef)


# Generated at 2022-06-25 23:18:42.666543
# Unit test for function find
def test_find():
    a_s_t_0 = ast.parse('a=1')
    parser_1 = a_s_t_0
    iterable_0 = find(parser_1, ast.Tuple)
    assert (iterable_0 is not None)


# Generated at 2022-06-25 23:18:52.412883
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
        # Pseudo code
    #    a = 1
    #    b = 2
    #    c = a
    #    a = b
    from typed_ast import ast3 as ast
    from _ast import Store, Load, Name, Num

# Generated at 2022-06-25 23:19:33.363519
# Unit test for function replace_at
def test_replace_at():
    a_s_t_32 = None
    a_s_t_33 = None
    replace_at(0, a_s_t_32, a_s_t_33)


# Generated at 2022-06-25 23:19:36.834940
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = None
    result = get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:19:37.673950
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:19:46.751936
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class1 = ast.FunctionDef(name='class1', args=ast.arguments(args=[], vararg=None, \
        kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)
    class2 = ast.FunctionDef(name='class2', args=ast.arguments(args=[], vararg=None, \
        kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)

# Generated at 2022-06-25 23:19:48.982318
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = None
    ast_0 = get_parent(a_s_t_0, a_s_t_0)



# Generated at 2022-06-25 23:19:51.913369
# Unit test for function find
def test_find():
    import ast
    tree = ast.parse('print(1 + 2)')
    nodes = find(tree, ast.Call)
    assert next(nodes) == tree.body[0].value
    with pytest.raises(StopIteration):
        next(nodes)

# Generated at 2022-06-25 23:20:02.388450
# Unit test for function find
def test_find():
    a_s_t_0 = ast.AST()
    a_s_t_1 = ast.AnnAssign()
    a_s_t_2 = ast.AnnAssign()
    a_s_t_3 = ast.AnnAssign()
    a_s_t_4 = ast.AnnAssign()
    a_s_t_5 = ast.AnnAssign()
    a_s_t = [a_s_t_0, a_s_t_1, a_s_t_2, a_s_t_3, a_s_t_4, a_s_t_5]
    int_0 = find(a_s_t_0, int)
    int_1 = find(a_s_t_1, int)

# Generated at 2022-06-25 23:20:05.266887
# Unit test for function find
def test_find():
    a = ast.parse('def foo():\n  pass')
    b = list(find(a, ast.FunctionDef))[0]
    t = ast.parse('pass')
    assert b == t


# Generated at 2022-06-25 23:20:06.119014
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert 1 == 1

# Generated at 2022-06-25 23:20:07.203396
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_case_0()


# Generated at 2022-06-25 23:21:13.503900
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    import _ast
    from typed_ast import NodeVisitor, NodeTransformer
    import astunparse
    dn = ast.parse('class A:\ndef f(self):\n  pass')
    n = ast.parse('class A:\ndef f(self):\n  pass')
    new_stmt = ast.FunctionDef(name='g', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Pass()], decorator_list=[])
    visitor = NodeVisitor()
    class ClassDefVisitor(NodeVisitor):
        def visit_ClassDef(self, node):
            return node
    ac = ClassDefVisitor()

# Generated at 2022-06-25 23:21:15.443790
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Arrange

    # Act

    # Assert
    return

# Generated at 2022-06-25 23:21:15.999707
# Unit test for function get_parent
def test_get_parent():
    assert(True)

# Generated at 2022-06-25 23:21:25.908202
# Unit test for function replace_at
def test_replace_at():
    # Function test
    a_s_t_0 = ast.Expr(ast.Name('A', ast.Load()))
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    replace_at(1, tuple_0[0], ast.Expr(ast.Name('B', ast.Load())))

    assert tuple_0[0].body[1].value.id == 'B'

    # Type test
    a_s_t_0 = ast.Expr(ast.Name('A', ast.Load()))
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 23:21:26.746009
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_case_0()


# Generated at 2022-06-25 23:21:28.969893
# Unit test for function find
def test_find():
    a_s_t = None
    type__ = None
    assert find(a_s_t, type__) == None


# Generated at 2022-06-25 23:21:35.191321
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = ast.parse("10+20").body[0].value
    class_0 = get_closest_parent_of(None, a_s_t_0, ast.ClassDef)
    return_0 = get_closest_parent_of(None, a_s_t_0, ast.Return)
    module_0 = get_closest_parent_of(None, a_s_t_0, ast.Module)
    module_1 = get_closest_parent_of(None, module_0, ast.Module)
    parent_0 = get_parent(None, a_s_t_0)
    return_1 = get_closest_parent_of(None, a_s_t_0, ast.Return)

# Generated at 2022-06-25 23:21:38.830785
# Unit test for function find
def test_find():
    a_s_t_1 = None
    a_s_t_2 = None
    a_s_t_3 = find(a_s_t_2, a_s_t_1)


# Generated at 2022-06-25 23:21:41.179074
# Unit test for function find
def test_find():
    module_0 = ast.parse("def f(x):\n    return x + 1")
    for _ in find(module_0, ast.Return):
        pass


# Generated at 2022-06-25 23:21:50.074751
# Unit test for function find
def test_find():
    """
    Test for find() function
    """
    a = ast.ElementaryTypeName('string', [])
    b = ast.ElementaryTypeName('string', [])
    c = ast.ElementaryTypeName('uint32', [])
    d = ast.ElementaryTypeName('uint32', [])
    e = ast.ElementaryTypeName('int32', [])
    f = ast.ElementaryTypeName('int32', [])
    g = ast.ElementaryTypeName('int32', [])
    h = ast.ElementaryTypeName('int32', [])
    i = ast.ElementaryTypeName('string', [])
    j = ast.ElementaryTypeName('string', [])
    k = ast.ElementaryTypeName('string', [])
    l = ast.ElementaryTypeName('string', [])
