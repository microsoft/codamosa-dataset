

# Generated at 2022-06-25 23:14:33.687181
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    target_0 = find(a_s_t_0, type(a_s_t_0))

# Generated at 2022-06-25 23:14:36.690247
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module = None # TODO: implement this
    function_def = None # TODO: implement this
    return_ = None # TODO: implement this
    assert module == get_closest_parent_of(function_def, node=return_, type_=module)

# Generated at 2022-06-25 23:14:41.855575
# Unit test for function insert_at
def test_insert_at():
    # FE-TODO: Fix the test and enable it.
    a_s_t_0 = module_0.AST()
    insert_at(0, a_s_t_0, a_s_t_0)
    # FE-TODO: Fix the test and enable it.
    list_0 = []
    insert_at(0, a_s_t_0, list_0)


# Generated at 2022-06-25 23:14:42.419712
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-25 23:14:47.853245
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    # AssertionError: expected [<_ast.Module object at 0x000002DAFE9E0DD8>, 0] but got [<_ast.Module object at 0x000002DAFE9E0DD8>, 0]
    assert False

# Generated at 2022-06-25 23:14:50.984425
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, module_0.AST)
    bool_0 = iterable_0 is None
    bool_1 = bool_0
    return bool_1


# Generated at 2022-06-25 23:14:53.999713
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:14:56.493292
# Unit test for function replace_at
def test_replace_at():
    ast_1 = module_0.AST()
    list_0 = []
    replace_at(0, ast_1, list_0)


# Generated at 2022-06-25 23:15:01.543610
# Unit test for function replace_at
def test_replace_at():
    rename_to = "codesmell"
    tree = ast.parse('a = 3')
    class_node = cast(ast.AST, find_assign_target(tree, rename_to))
    parent_node, index = get_non_exp_parent_and_index(tree, class_node)
    print(class_node)
    print(parent_node)
    print(index)
    replace_at(index, parent_node, ast.Name(id='name'))
    print(tree)



# Generated at 2022-06-25 23:15:06.496253
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # AssertionError
    try:
        test_case_0()
    except AssertionError:
        pass
    else:
        raise Exception('AssertionError exception is not thrown')


if __name__ == '__main__':
    import sys
    import nose2
    nose2.main()

# Generated at 2022-06-25 23:15:14.714540
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert(tuple_0 == (a_s_t_0, 0))


# Generated at 2022-06-25 23:15:20.886795
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_0 = module_0.AST()
    a_s_t_0 = module_0.AST()
    a_s_t_0 = module_0.AST()
    a_s_t_0 = module_0.AST()
    a_s_t_0 = module_0.AST()
    assert(get_closest_parent_of(a_s_t_0, a_s_t_0, type(None)) == None)

# Generated at 2022-06-25 23:15:29.338883
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_0_0 = module_0.AST()
    a_s_t_0_0.body = [a_s_t_0_0]
    a_s_t_0_0.body[0] = a_s_t_0_0
    a_s_t_0_0.body[0] = a_s_t_0_0
    a_s_t_0.body = [a_s_t_0_0]
    a_s_t_0.body[0] = a_s_t_0_0
    a_s_t_0.body[0] = a_s_t_0_0
    a_s_t_0.body[0] = a_s

# Generated at 2022-06-25 23:15:32.275461
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    return tuple_0


# Generated at 2022-06-25 23:15:41.889795
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast.ast3 import AST
    from random import random
    from typing import List

    def func_0(arg_0: List[AST]):
        pass

    def new_AST():
        return AST()

    func_0([new_AST() for num_0 in [42] * (1)])
    if False:
        func_0([new_AST() for num_0 in [42] * (0 if random() else -1)])
        func_0([new_AST() for num_0 in [42] * (0 or -1)])
        func_0([new_AST() for num_0 in [42] * (0)])
        func_0([new_AST() for num_0 in [42] * (0)])

# Generated at 2022-06-25 23:15:45.272193
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, tuple)

# Generated at 2022-06-25 23:15:49.394374
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = get_closest_parent_of(a_s_t_1, a_s_t_2, ast.AST)

    return a_s_t_1, a_s_t_3


# Generated at 2022-06-25 23:15:54.275579
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    obj_0 = find(a_s_t_0, )


# Generated at 2022-06-25 23:15:57.878462
# Unit test for function find
def test_find():
    root = ast.parse("for i in range(10):\n    print(i)")
    f = ast.For()
    for_node = find(root, ast.For)
    for_node = next(for_node)
    assert isinstance(for_node, ast.For)



# Generated at 2022-06-25 23:16:06.699816
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_0_0 = module_0.AST()
    a_s_t_0.body = [a_s_t_0_0]
    a_s_t_0_0.body = []
    a_s_t_0_0_0 = module_0.AST()
    a_s_t_0_0.body = [a_s_t_0_0_0]
    assert(get_closest_parent_of(a_s_t_0, a_s_t_0_0_0, module_0.AST) == a_s_t_0_0)

if __name__ == "__main__":
    test_case_0()
    test_get_closest_

# Generated at 2022-06-25 23:16:10.773578
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()


# Generated at 2022-06-25 23:16:13.740856
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test Cases
    test_case_0()


import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2


# Generated at 2022-06-25 23:16:16.324853
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    #import pdb;pdb.set_trace()
    test_case_0()

# Generated at 2022-06-25 23:16:23.920774
# Unit test for function get_parent
def test_get_parent():
    # get_parent(tree: ast.AST, node: ast.AST, rebuild: bool = False) -> ast.AST
    # Parent function for get_non_exp_parent_and_index
    a_s_t_0 = module_0.AST()
    assert get_parent(a_s_t_0, a_s_t_0) == a_s_t_0


# Generated at 2022-06-25 23:16:28.942954
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as test_ast

    test_ast.ParentExpr = test_ast.BinOp

    binop = test_ast.BinOp(test_ast.BinOp, test_ast.BinOp)
    some_parent = get_closest_parent_of(binop, binop, test_ast.BinOp)

# Generated at 2022-06-25 23:16:30.717510
# Unit test for function get_parent
def test_get_parent():
    # Test 0 function get_parent
    test_case_0()


# Generated at 2022-06-25 23:16:39.707404
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..cst_passes import InsertVariableDeclarationPass
    a_s_t_0 = ast.parse("def func():\n    a = 1")
    a_s_t_1 = ast.parse("func()")
    func = a_s_t_0.body[0]
    func_body = func.body[0]
    pass_ = InsertVariableDeclarationPass()
    pass_.visit(a_s_t_1)
    assert pass_.replacements == [((func_body.lineno, func_body.col_offset), 'a')]
    assert pass_.added_declarations == [((func.lineno, func.col_offset), 'a = func()')]



# Generated at 2022-06-25 23:16:40.674669
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert 1 == 1

# Generated at 2022-06-25 23:16:50.299359
# Unit test for function replace_at
def test_replace_at():

    test_replace_at_object = get_closest_parent_of(module_0.Module(), module_0.Num(),
        module_0.AST)

    assert isinstance(test_replace_at_object, module_0.AST)
    assert isinstance(test_replace_at_object.body, list)

    test_replace_at_object = module_0.Num(n=3)

    assert isinstance(test_replace_at_object, module_0.Num)
    assert isinstance(test_replace_at_object.n, int)

    test_replace_at_object = module_0.Num(n=3)

    assert isinstance(test_replace_at_object, module_0.Num)
    assert isinstance(test_replace_at_object.n, int)

    test_replace_

# Generated at 2022-06-25 23:16:52.842981
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:17:09.059852
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body.append(a_s_t_1)
    a_s_t_2 = module_0.AST()
    a_s_t_1.body.append(a_s_t_2)
    a_s_t_3 = module_0.AST()
    a_s_t_2.body.append(a_s_t_3)
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_3)
    tuple_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_2)
   

# Generated at 2022-06-25 23:17:10.896590
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False, "TODO implement this test"

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:17:15.369813
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast._ast3 import parse, AST, FunctionDef
    from typed_ast._ast3 import BinOp, Add, Div, Num
    from typed_ast._ast3 import Pass, Assign

# Generated at 2022-06-25 23:17:25.083577
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body = [a_s_t_1]
    a_s_t_2 = module_0.AST()
    a_s_t_1.body = [a_s_t_2]
    a_s_t_3 = module_0.AST()
    a_s_t_2.body = [a_s_t_3]
    a_s_t_4 = module_0.AST()
    a_s_t_3.body = [a_s_t_4]

    assert a_s_t_1 == get_parent(a_s_t_0, a_s_t_2)
    assert a_

# Generated at 2022-06-25 23:17:30.620117
# Unit test for function find
def test_find():

    # Unit test for function find with arguments 'tree' of type 'AST'
    a_s_t_0 = module_0.AST()
    #nodes = find(tree = a_s_t_0)

    # Unit test for function find with arguments 'tree' of type 'AST'
    a_s_t_0 = module_0.AST()
    #nodes = find(type_ = a_s_t_0)

    # Unit test for function find with arguments 'tree' of type 'AST'
    a_s_t_0 = module_0.AST()
    #nodes = find()

    # Unit test for function find with arguments 'tree' of type 'AST'
    a_s_t_0 = module_0.AST()
    #nodes = find(a_s_t_0, a_s

# Generated at 2022-06-25 23:17:32.445978
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert True

import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2


# Generated at 2022-06-25 23:17:37.125348
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:17:42.375934
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_0_2 = module_0.AST()
    a_s_t_0.body = [a_s_t_0_2]
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0_2)

# Generated at 2022-06-25 23:17:43.945027
# Unit test for function find
def test_find():
    try:
        find()
        assert False
    except TypeError:
        pass


# Generated at 2022-06-25 23:17:47.639309
# Unit test for function find
def test_find():
    a_s_t_0 = ast.parse('a = 1')
    function_0 = find(a_s_t_0, ast.FunctionDef)
    tuple_0 = find(a_s_t_0, ast.Tuple)



# Generated at 2022-06-25 23:17:58.039419
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:18:01.634819
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    get_closest_parent_of(1, 2, 3)

# Generated at 2022-06-25 23:18:03.458175
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:18:09.520043
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    key_0 = module_0.keyword(arg='', value=a_s_t_0)
    int_0 = module_0.Num(n=1)
    int_1 = module_0.Num(n=1)
    int_2 = module_0.Num(n=1)
    int_3 = module_0.Num(n=1)
    int_4 = module_0.Num(n=1)
    int_5 = module_0.Num(n=1)
    int_6 = module_0.Num(n=1)
    int_7 = module_0.Num(n=1)
    int_8 = module_0.Num(n=1)

# Generated at 2022-06-25 23:18:13.090447
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    list_0 = []
    tuple_0 = (module_0.Assign, list_0)
    replace_at(0, a_s_t_0, tuple_0)


# Generated at 2022-06-25 23:18:13.975924
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:18:17.678420
# Unit test for function find
def test_find():
    result = find(module_0.AST(), ast.AST)
    assert next(result) is None


# Generated at 2022-06-25 23:18:23.739423
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    f = find
    i = insert_at
    r = replace_at
    p = get_non_exp_parent_and_index
    c = get_closest_parent_of
    t = module_0
    g = get_parent
    tree = t.Module([])
    assert c(tree, tree.body[0], t.Module) is tree
    i(0, tree, t.Import([t.alias(t.Name('a', t.Load()), t.Name('a', t.Load()))]))
    assert c(tree, tree.body[0], t.ImportFrom) is None
    assert c(tree, tree.body[0], t.Import) is tree.body[0]

# Generated at 2022-06-25 23:18:25.764739
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a = module_0.AST()
    assert get_closest_parent_of(a, a, ast.AST) == a


# Generated at 2022-06-25 23:18:35.681165
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    i_t_e_r_0 = find(a_s_t_0, module_0.AST)

    # Test first iteration of iterator
    try:
        a_s_t_1 = next(i_t_e_r_0)
    except StopIteration:
        assert False

    # Test second iteration of iterator
    try:
        a_s_t_2 = next(i_t_e_r_0)
    except StopIteration:
        assert False

    # Test third iteration of iterator
    try:
        next(i_t_e_r_0)
        assert False
    except StopIteration:
        pass

    # Test fourth iteration of iterator

# Generated at 2022-06-25 23:18:53.765852
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.AST)

# Generated at 2022-06-25 23:18:55.600548
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    try:
        test_case_0()
    except:
        print ('Exception in test case', 'test_case_0' )


# Generated at 2022-06-25 23:18:58.928541
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:59.970995
# Unit test for function get_parent
def test_get_parent():
    assert 1 == 1, test_case_0

# Generated at 2022-06-25 23:19:09.110870
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class _AST2(ast.AST):
        _fields = ()

    _a_s_t_0 = module_0.AST()
    _a_s_t_0 = _AST2()
    _a_s_t_1 = module_0.AST()
    _a_s_t_1 = _AST2()
    _a_s_t_2 = module_0.AST()
    _a_s_t_2 = _AST2()

    _a_s_t_0.body = [_a_s_t_1, _a_s_t_2]
    _tuple_0 = (_a_s_t_1)
    _tuple_1 = _a_s_t_0
    _tuple_0 = _a_s_t_0.body
    _a

# Generated at 2022-06-25 23:19:11.632458
# Unit test for function get_parent
def test_get_parent():
    print("Begin to test the get_parent function.")
    assert get_parent(module_0.AST(), module_0.AST()) == None
    print("get_parent function works well.")


# Generated at 2022-06-25 23:19:13.502756
# Unit test for function find
def test_find():
    # TODO: write this test
    assert False, "Function find undefined"


# Generated at 2022-06-25 23:19:23.947894
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:19:31.180833
# Unit test for function find
def test_find():
    # Test type is module_0.AST
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    list_0 = find(a_s_t_0, type(module_0.AST()))
    assert(list_0 == [a_s_t_0, a_s_t_1])
    # Test type is module_0.Expression
    a_s_t_2 = module_0.Expression()
    a_s_t_3 = module_0.Expression()
    list_1 = find(a_s_t_2, type(module_0.Expression()))
    assert(list_1 == [a_s_t_2, a_s_t_3])
    # Test type is module_0.

# Generated at 2022-06-25 23:19:38.263323
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

    assert(isinstance(a_s_t_0, module_0.AST))
    assert(type(tuple_0) is tuple)
    assert(len(tuple_0) == 2)
    assert(isinstance(tuple_0[0], module_0.AST))
    assert(type(tuple_0[1]) is int)

# Generated at 2022-06-25 23:20:07.820267
# Unit test for function get_parent
def test_get_parent():
    # Test #0
    test_case_0()

# Generated at 2022-06-25 23:20:09.579906
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, list)


# Generated at 2022-06-25 23:20:10.319797
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:20:17.111160
# Unit test for function find
def test_find():
    ast_0 = module_0.AST()
    list_0 = find(ast_0, type(module_0.Module))
    assert(list_0 == [])


# Generated at 2022-06-25 23:20:19.587402
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0.AST()
    typed_ast.ast3.AST()
    typed_ast.ast3.AST()

# Generated at 2022-06-25 23:20:20.759456
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass


# Generated at 2022-06-25 23:20:24.023816
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    type_0 = module_0.AST
    iterable_0 = find(a_s_t_0, type_0)


# Generated at 2022-06-25 23:20:28.135340
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    
    try:
        result = get_closest_parent_of(a_s_t_0, a_s_t_0, type(None))
    except NodeNotFound as e:
        print(e)
    

# Generated at 2022-06-25 23:20:40.953687
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    class_0 = module_0.ClassDef()
    module_0.ClassDef.body = []
    module_0.ClassDef.body.append(a_s_t_0)
    a_s_t_1 = module_0.AST()
    module_0.ClassDef.body.append(a_s_t_1)
    a_s_t_2 = module_0.AST()
    module_0.ClassDef.body.append(a_s_t_2)
    tuple_0 = get_non_exp_parent_and_index(class_0, a_s_t_1)
    tuple_1 = get_non_exp_parent_and_index(class_0, a_s_t_2)

# Unit

# Generated at 2022-06-25 23:20:47.446267
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_01 = module_0.Module([module_0.Assign([module_0.Name(id='y', ctx=module_0.Store())], module_0.Num(n=1))], lineno=0, col_offset=0)
    tuple_01 = get_non_exp_parent_and_index(a_s_t_01, module_0.Name(id='y', ctx=module_0.Store()))
    assert (tuple_01 == a_s_t_01, 0)
    tuple_02 = get_non_exp_parent_and_index(a_s_t_01, module_0.Num(n=1))
    assert (tuple_02 == a_s_t_01, 0)
    tuple_03 = get_non_exp_parent_and

# Generated at 2022-06-25 23:21:52.109109
# Unit test for function find
def test_find():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.parse('import random\n')
    test_0 = find(a_s_t_0, module_0.ImportFrom)
    assert test_0 is not None
    test_1 = find(a_s_t_0, module_0.Import)
    assert test_1 is not None


# Generated at 2022-06-25 23:21:53.918078
# Unit test for function find
def test_find():
    test_tree = ast.parse('a = 10')
    nodes = find(test_tree, ast.Name)
    assert len(list(nodes)) == 1


# Generated at 2022-06-25 23:21:56.073522
# Unit test for function find
def test_find():
    assert list(find(module_0.AST(), module_0.AST)) == []


# Generated at 2022-06-25 23:21:59.025732
# Unit test for function find
def test_find():
    x = module_0.Expr()
    y = module_0.Expr()
    z = module_0.Name()
    assert find(y, type(z)) == [y]


# Generated at 2022-06-25 23:22:00.512288
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    
    #
    module_0.Assign()

# Generated at 2022-06-25 23:22:02.392337
# Unit test for function get_parent
def test_get_parent():
    with pytest.raises(Exception):
        get_parent(module_0.AST(), module_0.AST())



# Generated at 2022-06-25 23:22:06.773822
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    # AssertionError: None != <class 'typed_ast._ast3.Module'>
    assert_equal(get_non_exp_parent_and_index(a_s_t_0, a_s_t_0), (module_0.Module, 0))

# Generated at 2022-06-25 23:22:11.738226
# Unit test for function replace_at
def test_replace_at():
    print("Testing replace_at...", end="")
    a_s_t_0 = module_0.AST()
    replace_at(0, a_s_t_0, module_0.AST())
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, module_0.AST())
    print("Passed!")


# Generated at 2022-06-25 23:22:18.031501
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False, "No tests for function get_non_exp_parent_and_index"

# Generated at 2022-06-25 23:22:19.010289
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass


# Generated at 2022-06-25 23:23:33.064084
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()

    a_s_t_2.body = [a_s_t_3, a_s_t_4, a_s_t_5]

    a_s_t_1.body = [a_s_t_2]

    a_s_t_0.body = [a_s_t_1]


# Generated at 2022-06-25 23:23:37.654083
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert isinstance(tuple_0, tuple)
    assert len(tuple_0) == 2
    assert isinstance(tuple_0[0], module_0.AST)
    assert isinstance(tuple_0[1], int)

# Generated at 2022-06-25 23:23:42.814068
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Do not print error message if test fails.
    import sys
    import os
    sys.stdout = open(os.devnull, 'w')

    try:
        test_case_0()
    except Exception as e:
        assert False, "Unhandled exception: " + str(e)
    else:
        assert True

    sys.stdout = sys.__stdout__

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:23:44.741549
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a = module_0.AST()
    b = get_closest_parent_of(a, a, Union[module_0.AST, module_0.AST])

# Generated at 2022-06-25 23:23:46.854645
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    try:
        test_case_0()
    except NodeNotFound:
        pass
    else:
        raise AssertionError('There should be an IndexError exception')

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 23:23:49.608119
# Unit test for function get_parent
def test_get_parent():
    assert get_parent(module_0.AST(), module_0.AST()) == module_0.AST()
    assert get_parent(module_0.AST(), module_0.AST()) == module_0.AST()


# Generated at 2022-06-25 23:23:50.784189
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 23:23:53.672329
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:23:57.198932
# Unit test for function find
def test_find():
    # Setup
    module = ast.Module()
    assert not list(find(module, ast.Module))

    module.body.append(ast.Pass())
    assert list(find(module, ast.Pass)) == [module.body[0]]



# Generated at 2022-06-25 23:24:04.681251
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.Module([module_0.Assign([module_0.Name('a', module_0.Load())], module_0.Num(1))])
    a_s_t_1 = module_0.Module([module_0.Assign([module_0.Name('b', module_0.Load())], module_0.Num(2))])
    a_s_t_2 = module_0.Module([module_0.Assign([module_0.Name('c', module_0.Load())], module_0.Num(3))])
    alternate_0 = find(a_s_t_2, module_0.Assign)
    str_0 = str(alternate_0)
