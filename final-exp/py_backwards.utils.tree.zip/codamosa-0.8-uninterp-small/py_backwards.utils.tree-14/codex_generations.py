

# Generated at 2022-06-25 23:14:36.890896
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test generation
    a_s_t_0 = ast.parse('import module_0\n')
    # Test setup
    arg_0_0 = 'module_0'
    # Function call
    result = get_closest_parent_of(a_s_t_0, a_s_t_0, str)
    # Test verification
    assert result == arg_0_0

# Generated at 2022-06-25 23:14:45.890264
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
  ###########################################################################
  # Test case 0
  ###########################################################################
  test_case_0()
  ###########################################################################
  # Test case 1
  ###########################################################################
  a_s_t_0 = ast.FunctionDef(
    name='foo',
    args=ast.arguments(
      args=[],
      vararg=None,
      kwarg=None,
      defaults=[]),
    body=[],
    decorator_list=[],
    returns=None)
  a_s_t_1 = ast.FunctionDef(
    name='foo',
    args=ast.arguments(
      args=[],
      vararg=None,
      kwarg=None,
      defaults=[]),
    body=[],
    decorator_list=[],
    returns=None)
 

# Generated at 2022-06-25 23:14:54.940924
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    f = open('test.py', 'r')
    code = f.read()
    a = ast.parse(code)
    offset = code.index('result = 0')
    line_number = code[:offset].count('\n') + 1
    column_number = offset - code.rfind('\n', 0, offset)

    c = a.body[0].body[0]
    assert get_closest_parent_of(a, c, ast.ClassDef) is None

    d = a.body[0].body[0].body[0]
    assert get_closest_parent_of(a, d, ast.ClassDef) is a.body[0]


# Generated at 2022-06-25 23:14:55.880912
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:14:56.799765
# Unit test for function find
def test_find():
    test_case_0()


# Generated at 2022-06-25 23:14:59.903484
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = None
    a_s_t_1 = None
    a_s_t_2 = get_closest_parent_of(a_s_t_0, a_s_t_1, ast.FunctionDef)


# Generated at 2022-06-25 23:15:03.901752
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Arrange
    tree = ast.parse("if True: print()")
    node = tree.body[0].body[0]

    # Act
    parent, index = get_non_exp_parent_and_index(tree, node)

    # Assert
    assert parent == tree.body[0]
    assert index == 0



# Generated at 2022-06-25 23:15:08.811198
# Unit test for function find
def test_find():
    # Initialize current AST
    ast_tuple = (ast.Str, ast.Name)
    ast_obj = ast.Str()

    # Call find
    result = find(ast_obj, ast_tuple)

    # Assert find result
    assert isinstance(result, Iterable)



# Generated at 2022-06-25 23:15:09.669607
# Unit test for function find
def test_find():
    pass



# Generated at 2022-06-25 23:15:19.948495
# Unit test for function replace_at
def test_replace_at():
    a1 = ast.Assign(
        targets=[ast.Name(id='b', ctx=ast.Store())],
        value=ast.Name(id='a', ctx=ast.Load()))
    a2 = ast.Assign(
        targets=[ast.Name(id='c', ctx=ast.Store())],
        value=ast.Name(id='a', ctx=ast.Load()))
    a3 = ast.Assign(
        targets=[ast.Name(id='d', ctx=ast.Store())],
        value=ast.Name(id='a', ctx=ast.Load()))
    a4 = ast.Assign(
        targets=[ast.Name(id='e', ctx=ast.Store())],
        value=ast.Name(id='a', ctx=ast.Load()))

# Generated at 2022-06-25 23:15:25.013154
# Unit test for function find
def test_find():
    a_s_t_0 = None
    list_0 = list(find(a_s_t_0, type(None)))

# Generated at 2022-06-25 23:15:28.934177
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_0 = ast.parse("a = 1")
    ast_1 = ast.parse("a = 1")
    parent, index = get_non_exp_parent_and_index(ast_0, ast_1.body[0])
    assert parent == ast_0
    assert index == 0


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 23:15:33.210177
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = ast.parse("""def func():\n    pass\n""")
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert isinstance(tuple_0[0], ast.Module)
    assert tuple_0[1] == 0


# Generated at 2022-06-25 23:15:42.828399
# Unit test for function get_parent
def test_get_parent():
    test_tree = ast.parse(
        textwrap.dedent("""
        def foo(a, b, e):
            c = a + b
            d = f
            if a < 0:
                e = 5
            for i in e:
                e += g[i]
            return c
        """)
    )
    _build_parents(test_tree)
    try:
        assert get_parent(test_tree, test_tree) == None
    except:
        print("Failed to get parent of tree")
    try:
        assert get_parent(test_tree, test_tree.body[0]) == test_tree
    except:
        print("Failed to get parent of function")

# Generated at 2022-06-25 23:15:45.141697
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    with pytest.raises(NodeNotFound):
        test_case_0()

# Generated at 2022-06-25 23:15:46.162686
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass


# Generated at 2022-06-25 23:15:48.304102
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = None
    type_ = None

    try:
        get_closest_parent_of(node, node, type_)
    except Exception:
        pass



# Generated at 2022-06-25 23:15:57.007779
# Unit test for function get_parent
def test_get_parent():
    # Get parrent of node in tree
    tree_0 = ast.parse("import collections\nasync def func():\n    pass\n")
    node_0 = find(tree_0, ast.FunctionDef).__next__()
    result_0 = get_parent(tree_0, node_0)
    assert isinstance(result_0, ast.Module)

    # Get parrent of node in tree
    tree_1 = ast.parse("import collections\nasync def func():\n    pass\n")
    result_1 = get_parent(tree_1, tree_1)
    assert isinstance(result_1, ast.AST)



# Generated at 2022-06-25 23:16:02.998939
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = None
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert isinstance(tuple_0, tuple)
    assert tuple_0[0] is None
    assert tuple_0[1] is None


# Generated at 2022-06-25 23:16:04.446642
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    return 0


# Generated at 2022-06-25 23:16:10.915044
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = None
    parent = None
    nodes = None
    replace_at(0, parent, nodes)
    return


# Generated at 2022-06-25 23:16:20.602370
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source0 = '''a = 1
b = 2'''
    source1 = '''a = 1
if a == 1:
    a += 2
elif a > 1:
    a += 1
b = 2'''
    source2 = '''def foo():
    a = 1
    b = 2'''
    source3 = '''class foo:
    a = 1
    b = 2
    def bar():
        c = 3'''
    source4 = '''a = 1 and 2'''
    source5 = '''a = 1 or 2'''
    source6 = '''[1, 2, 3]'''
    source7 = '''a = (1, 2, 3)'''
    source8 = '''x = 1 + 2 + 3'''

# Generated at 2022-06-25 23:16:24.781027
# Unit test for function find
def test_find():
    a_s_t_0 = ast.parse("import sys")
    i_0 = find(a_s_t_0, ast.Import)
    assert next(i_0).lineno == 1
    assert next(i_0, None) == None


# Generated at 2022-06-25 23:16:27.148177
# Unit test for function find
def test_find():
    a_s_t_0 = None
    type_0 = None
    a_s_t_0 = find(a_s_t_0, type_0)


# Generated at 2022-06-25 23:16:28.985919
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    with pytest.raises(NodeNotFound):
        test_case_0()

# Generated at 2022-06-25 23:16:36.730614
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def func_0():\n\tpass')
    pass_node = tree.body[0].body[0]

    assert isinstance(get_closest_parent_of(tree, pass_node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, pass_node, ast.Module),
                      ast.Module)



# Generated at 2022-06-25 23:16:48.164506
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """
        The function calculates the expected value and passes the
        test if and only if the value returned by the function matches
        the expected value
    """
    dct = {}
    a_s_t_0 = ast.Call()
    a_s_t_0.keywords = []
    a_s_t_0.args = []
    a_s_t_0.starargs = None
    a_s_t_0.kwargs = None
    a_s_t_0.func = ast.Name(id = 'True', ctx = ast.Load())
    dct['test'] = 0
    a_s_t_0.func.lineno = False
    a_s_t_0.func.col_offset = False
    dct['test'] = 0

# Generated at 2022-06-25 23:16:51.216254
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = None
    a_s_t_2 = None
    tuple_1 = get_closest_parent_of(a_s_t_1, a_s_t_2, type)
    return tuple_1


# Generated at 2022-06-25 23:16:57.551253
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    class_def = astor.code_to_ast.parse('class A():\n pass').body[0]
    function_def = astor.code_to_ast.parse('def x():\n pass').body[0]
    one = function_def.body[0]
    return_stmt = astor.code_to_ast.parse('def x():\n return 3').body[0].body[0]
    return get_closest_parent_of(one, return_stmt, ast.ClassDef)

# Generated at 2022-06-25 23:17:06.533190
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Assert function returns correct for tree 1
    a_s_t_1 = ast.parse("import y\nprint(x)")
    type_1 = ast.Expr
    result_1 = get_closest_parent_of(a_s_t_1, a_s_t_1.body[1], type_1)

    assert(result_1.__class__.__name__ == 'Expr')
    assert(result_1.lineno == 2)
    assert(result_1.col_offset == 0)
    assert(result_1.value.__class__.__name__ == 'Call')
    assert(result_1.value.lineno == 2)
    assert(result_1.value.col_offset == 0)

# Generated at 2022-06-25 23:17:15.634227
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Case 0: something
    test_case_0()



# Generated at 2022-06-25 23:17:21.891574
# Unit test for function replace_at
def test_replace_at():
    sourceCode = """
    def test():
        pass
    test()
    """
    root = ast.parse(sourceCode)
    funcDef = root.body[0]
    replace_at(0, funcDef, ast.Expr(value=ast.Name(id='a', ctx=ast.Load())))
    assert(str(root) == """\
if 1:
    def test():
        a
    test()
""")


# Generated at 2022-06-25 23:17:29.161167
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_node = ast.parse("x=1")
    expr = test_node.body[0].value
    assert( isinstance(get_closest_parent_of(test_node,
                                             expr,
                                             ast.Assign),
                        ast.Assign))
    assert( isinstance(get_closest_parent_of(test_node,
                                             expr,
                                             ast.Module),
                        ast.Module))
    assert( isinstance(get_closest_parent_of(test_node,
                                             expr,
                                             ast.Expr),
                        ast.Expr))
    assert( isinstance(get_closest_parent_of(test_node,
                                             expr,
                                             ast.AST),
                        ast.AST))

# Generated at 2022-06-25 23:17:30.455474
# Unit test for function replace_at
def test_replace_at():
    assert replace_at(0, None, None) is None


# Generated at 2022-06-25 23:17:30.983029
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-25 23:17:41.592292
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # get_non_exp_parent_and_index(tree, node)
    node_1 = ast.FunctionDef()
    tree_1 = ast.Module(body=[node_1])
    assert(get_non_exp_parent_and_index(tree_1, node_1) == (tree_1, 0))

    node_2 = ast.ImportFrom()
    tree_2 = ast.Module(body=[node_2])
    assert(get_non_exp_parent_and_index(tree_2, node_2) == (tree_2, 0))

    node_3 = ast.Import()
    tree_3 = ast.Module(body=[node_3])
    assert(get_non_exp_parent_and_index(tree_3, node_3) == (tree_3, 0))

# Unit test

# Generated at 2022-06-25 23:17:45.080745
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("for i in [1,2,3]:\n    print(i)")
    node = tree.body[0].body[0].value
    return_0 = get_closest_parent_of(tree, node, ast.For)


# Generated at 2022-06-25 23:17:47.224134
# Unit test for function find
def test_find():
    a_s_t_0 = None
    iter_0 = find(a_s_t_0, str)


# Generated at 2022-06-25 23:17:53.981535
# Unit test for function get_parent
def test_get_parent():
    # Tree structure:
    # Module(body=[Assign(targets=[Name(id='f', ctx=Store())],
    #                     value=FunctionDef(name='f',
    #                                       args=arguments(args=[],
    #                                                      vararg=None,
    #                                                      kwonlyargs=[],
    #                                                      kw_defaults=[],
    #                                                      kwarg=None,
    #                                                      defaults=[]),
    #                                       body=[Return(value=Num(n=1))],
    #                                       decorator_list=[]))])
    tree = ast.parse('f = lambda: 1', '<string>', 'exec')
    one = tree.body[0].value.body[0].value
    lambda_ = tree.body[0].value

   

# Generated at 2022-06-25 23:17:55.274713
# Unit test for function find
def test_find():
    assert find(None, list) == None


# Generated at 2022-06-25 23:18:15.075365
# Unit test for function find
def test_find():
    a_s_t_0 = None
    list_0 = find(a_s_t_0, ast.Call)


# Generated at 2022-06-25 23:18:19.607949
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:18:29.812351
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = ast.parse('if a > 1:\n    print(a, 1)\nelse:\n    print(a, 2)\n')
    assert get_non_exp_parent_and_index(a_s_t_0, a_s_t_0) == (a_s_t_0, 0)
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert isinstance(tuple_0[0], ast.Module) and isinstance(tuple_0[1], int)
    assert get_non_exp_parent_and_index(None, None) is None
    test_case_0()


# Generated at 2022-06-25 23:18:37.116659
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    import ast
    test_file = open('tests/testcases/testcase0.py_ast')
    ast0 = ast.parse(test_file.read())

    parent = ast0
    while not hasattr(parent, 'body'):
        parent = get_parent(ast0, parent)

    index = 0
    while parent.body[index].__class__.__name__ != 'Expr':
        index += 1
    assert(get_non_exp_parent_and_index(ast0, parent.body[index])[1] == index)

# Generated at 2022-06-25 23:18:42.708585
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import sys
    import random
    sys.setrecursionlimit(100000)
    test_list = ['random_string']
    for i in range(100000):
        test_list.append(random.randint(1,9999999))

    assert get_non_exp_parent_and_index(test_list, 'random_string') == (None, 0)



# Generated at 2022-06-25 23:18:45.019732
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    for i in range(10):
        try:
            test_case_0()
        except UnboundLocalError:
            pass



# Generated at 2022-06-25 23:18:50.828033
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = ast.Expr()
    a_s_t_1 = ast.Expr()
    a_s_t_2 = ast.Expr()
    a_s_t_3 = ast.Module(body=[a_s_t_0, a_s_t_1, a_s_t_2])
    replace_at(1, a_s_t_3, a_s_t_2)


# Generated at 2022-06-25 23:18:57.813156
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = ast.parse('import clingo as cl\ntest1 = 1\ntest2 = 2\n')

    assert get_non_exp_parent_and_index(
        a_s_t_0,
        a_s_t_0.body[1],
    ) == (a_s_t_0, 1)

    assert get_non_exp_parent_and_index(
        a_s_t_0,
        a_s_t_0.body[2].value,
    ) == (a_s_t_0, 2)

# Generated at 2022-06-25 23:19:02.926261
# Unit test for function find
def test_find():
    from ..examples.example01 import a_s_t_0
    expected = [ast.FunctionDef('func', ast.arguments(), [ast.Num(1)], [])]
    result = find(a_s_t_0, ast.FunctionDef)
    check_found = lambda: list(result) == expected
    assert check_found()


# Generated at 2022-06-25 23:19:04.446879
# Unit test for function get_parent
def test_get_parent():
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 23:19:24.935399
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass


# Generated at 2022-06-25 23:19:25.712960
# Unit test for function get_closest_parent_of

# Generated at 2022-06-25 23:19:28.547528
# Unit test for function find
def test_find():
    a_s_t_0 = None
    find(a_s_t_0, ast.Name)
    find(a_s_t_0, ast.Assign)
    find(a_s_t_0, ast.Empty)


# Generated at 2022-06-25 23:19:38.424572
# Unit test for function find
def test_find():
    """Test if find() works"""
    import ast
    import unittest
    class TestFind(unittest.TestCase):
        """class TestFind"""

        def test_find(self):
            """Test find()"""
            node = ast.Module(
                body=[
                    ast.Expr(
                        value=ast.Name(
                            id='x', lineno=1, col_offset=0))])
            result = list(find(node, ast.Name))
            self.assertEqual(result, [node.body[0].value])
            self.assertEqual(result[0].id, 'x')
            self.assertEqual(result[0].lineno, 1)
            self.assertEqual(result[0].col_offset, 0)
    unittest.main()



# Generated at 2022-06-25 23:19:46.519489
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = ast.Module(body=[ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load(),), args=[ast.Constant(value='hello world', kind=None,),], keywords=[],),),], type_ignores=[])
    a_s_t_2 = ast.Call(func=ast.Name(id='print', ctx=ast.Load(),), args=[ast.Constant(value='hello world', kind=None,),], keywords=[],)
    a_s_t_3 = get_closest_parent_of(a_s_t_1, a_s_t_2, ast.Module)


# Generated at 2022-06-25 23:19:47.397460
# Unit test for function find

# Generated at 2022-06-25 23:19:54.512026
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = ast.Name(id="abc", ctx=ast.Load())
    a_s_t_1 = ast.Name(id="qwe", ctx=ast.Load())
    a_s_t_2 = ast.Name(id="asd", ctx=ast.Load())
    a_s_t_3 = ast.Name(id="zxc", ctx=ast.Load())
    a_s_t_4 = ast.Name(id="rty", ctx=ast.Load())
    a_s_t_5 = ast.Name(id="fgh", ctx=ast.Load())

    a_s_t_6 = ast.BinOp(left=a_s_t_0, op=ast.Add(), right=a_s_t_1)
    a

# Generated at 2022-06-25 23:20:04.759828
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0: ast.Module = ast.parse("")
    a_s_t_1: ast.AST = a_s_t_0
    a_s_t_0_0: ast.AST = get_parent(a_s_t_0, a_s_t_1)
    assert(a_s_t_0_0 == a_s_t_0)
    a_s_t_0_1: ast.AST = ast.parse("")
    a_s_t_2: ast.AST = a_s_t_0_1
    a_s_t_0_2: ast.AST = get_parent(a_s_t_0, a_s_t_2)
    assert(a_s_t_0_2 == a_s_t_0)

# Generated at 2022-06-25 23:20:08.217513
# Unit test for function find
def test_find():
    # children = find(foo, ast.AST)
    # foo_children_types = [type(child) for child in children]
    # assert foo_children_types == [ast.Name, ast.Num]
    test_case_0()



# Generated at 2022-06-25 23:20:10.219539
# Unit test for function find
def test_find():
    test_ast = ast.parse('test')
    result = list(find(test_ast, ast.Expr))
    print(result)


# Generated at 2022-06-25 23:22:12.179889
# Unit test for function find
def test_find():
    """
    Runs a set of tests based on the unit tests outlined in the README.md file.
    """
    # Setup
    test_ast = ast.parse("class ExtendedClass(object):\n    def hello() -> int:\n    print('hello')")
    test_type = ast.ClassDef

    # Test
    result = next(find(test_ast, test_type))
    assert result.name == 'ExtendedClass'
    assert result.bases[0].id == 'object'
    assert result.body[0].name == 'hello'


# Generated at 2022-06-25 23:22:17.343598
# Unit test for function get_parent
def test_get_parent():
    root = ast.parse("def foo(num):\n\tx = num + 1\n\treturn x\n")

# Generated at 2022-06-25 23:22:20.046929
# Unit test for function get_parent
def test_get_parent():
    parse_tree = ast.parse("a = 2 + 4")
    assert(get_parent(parse_tree, parse_tree.body[0].value) == parse_tree.body[0])


# Generated at 2022-06-25 23:22:23.556515
# Unit test for function find
def test_find():
    a_s_t_0 = ast.parse('x=3')
    type__0 = ast.Expr
    i_t_e_r_0 = find(a_s_t_0, type__0)


# Generated at 2022-06-25 23:22:25.066637
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert True


# Generated at 2022-06-25 23:22:36.764323
# Unit test for function find
def test_find():
    module_0 = ast.parse(
        'def a(): pass\n'
        'def b(): pass'
    )
    for def_0 in find(module_0, ast.FunctionDef):
        str_0 = ast.Str(def_0.name)
        def_0.body.insert(0, ast.Expr(str_0))

    # Test with node of different type
    test_0 = ast.parse('class A: pass')
    for class_0 in find(test_0, ast.ClassDef):
        str_0 = ast.Str(class_0.name)
        class_0.body.insert(0, ast.Expr(str_0))

    # Test with empty class
    test_1 = ast.parse('class A: pass')

# Generated at 2022-06-25 23:22:44.602486
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Arrange
    # Build the example AST:
    # module.body[0].body[0].body[1] = test_function(3)
    # module.body[0].body[0].body[1].args[1] = 3
    # module.body[0].body[0].body[1].args[1].n = 3
    # module.body[0].body[0].body[1].args[1].n.n = 3
    module = ast.Module()
    assert isinstance(module, ast.Module)
    a_s_t_0 = ast.ClassDef()
    assert isinstance(a_s_t_0, ast.ClassDef)
    module.body.append(a_s_t_0)
    a_s_t_1 = ast.FunctionDef()
    assert isinstance

# Generated at 2022-06-25 23:22:54.903896
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast
    import copy
    from typeddfs.utils import replace_at

    test_ast = ast.parse("""
    def func():
        pass
    """)
    test_ast = copy.deepcopy(test_ast)
    replace_at(2, test_ast.body[0], ast.parse("""
    for i in range(1, 3):
        pass
    """))
    replace_at(2, test_ast.body[0], ast.parse("""
    for i in range(1, 3):
        print(i)
    """))

    assert(isinstance(get_closest_parent_of(test_ast, test_ast.body[0].body[1][1], ast.For), ast.For))



# Generated at 2022-06-25 23:23:01.979977
# Unit test for function find
def test_find():
    # Set up inputs and expected outputs
    nodes = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    type_ = ast.Assign
    expected_outputs = []

    # Create AST from input nodes
    tree = ast.Module(body=nodes)

    # Find nodes in tree and check output
    result = find(tree, type_)
    for r in result:
        assert(isinstance(r, type_))



# Generated at 2022-06-25 23:23:05.323546
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = ast.Module([])
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

