

# Generated at 2022-06-25 23:14:39.179319
# Unit test for function get_parent
def test_get_parent():
    """Test for function get_parent."""
    # Define variables and constants

    # Setup
    a_s_t_0 = module_0.AST() # Default constructor calls
    a_s_t_0.body = [module_0.FunctionDef()]
    a_s_t_0.body[0].lineno = 42
    a_s_t_1 = module_0.AST() # Default constructor calls
    a_s_t_1.body = a_s_t_0.body
    a_s_t_1.body[0].lineno = 42

    # Exercise
    result = get_parent(a_s_t_0, a_s_t_1.body[0])
    # Verify
    assert result == a_s_t_1
    # Cleanup


import typed_ast

# Generated at 2022-06-25 23:14:41.300510
# Unit test for function find
def test_find():
    my_tree = ast.parse('')
    assert list(find(my_tree, ast.FunctionDef)) == []


# Generated at 2022-06-25 23:14:42.869430
# Unit test for function replace_at
def test_replace_at():
    Module_0 = ast.Module()
    pass


# Generated at 2022-06-25 23:14:50.259003
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.parse("")
    a_s_t_1 = module_0.body.pop()
    module_0.body.append(a_s_t_1)
    a_s_t_2 = module_0.body.pop()
    module_0.body.append(a_s_t_2)
    a_s_t_3 = module_0.body.pop()
    module_0.body.append(a_s_t_3)
    a_s_t_4 = module_0.body.pop()
    module_0.body.append(a_s_t_4)
    get_closest_parent_of(module_0, a_s_t_4, ast.Module)
    a_s_t_5 = ast.If()
    a

# Generated at 2022-06-25 23:14:53.904245
# Unit test for function get_parent
def test_get_parent():
    if (not hasattr(module_0, 'AST') or
            not hasattr(module_0, 'AST')):
        return
    assert (get_parent(module_0.AST(), module_0.AST()) == module_0.AST())



# Generated at 2022-06-25 23:14:58.718538
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert(a_s_t_1 is a_s_t_0)


# Generated at 2022-06-25 23:15:04.958399
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    if False:
        from ...typed_ast import arg
        from ...typed_ast import arguments
        from ...typed_ast import boolop
        from ...typed_ast import cmpop
        from ...typed_ast import comptype
        from ...typed_ast import comprehension
        from ...typed_ast import excepthandler
        from ...typed_ast import expr
        from ...typed_ast import expr_context
        from ...typed_ast import keyword
        from ...typed_ast import mod
        from ...typed_ast import operator
        from ...typed_ast import unaryop
        from ...typed_ast import boolop
        from ...typed_ast import cmpop
        from ...typed_ast import expr
        from ...typed_ast import expr_context

# Generated at 2022-06-25 23:15:08.692421
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:15:15.307725
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST()
    expression_0 = module_0.Expr()
    a_s_t_3 = module_0.AST()
    a_s_t_3.body = [expression_0]
    get_parent(a_s_t_3, a_s_t_2)
    a_s_t_4 = find(a_s_t_3, Type[module_0.Expr])

# Generated at 2022-06-25 23:15:24.197553
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Create and insert AST nodes for tree
    a_s_t_0 = ast.Module()
    a_s_t_0_body = []
    a_s_t_0.body = a_s_t_0_body
    a_s_t_1 = ast.Expr()
    a_s_t_1_value = ast.Str()
    a_s_t_1_value.s = 'TEST_STRING_0'
    a_s_t_1_value_lineno = 5
    a_s_t_1_value.lineno = a_s_t_1_value_lineno
    a_s_t_1.value = a_s_t_1_value
    a_s_t_1_lineno = 1

# Generated at 2022-06-25 23:15:32.813070
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    l_0 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:15:37.118532
# Unit test for function get_parent
def test_get_parent():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = get_parent(a_s_t_2, a_s_t_2)
    assert a_s_t_3 == a_s_t_2

import typed_ast._ast27 as module_1


# Generated at 2022-06-25 23:15:43.319694
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # AssertionError: 'NodeNotFound: Parent for <typed_ast._ast3.AST object at 0x7f8b1c20f2e8> not found' != <typed_ast._ast3.FunctionDef object at 0x7f8b1c239f28>
    with pytest.raises(AssertionError):
        assert get_closest_parent_of(module_0.AST(), module_0.FunctionDef())


# Generated at 2022-06-25 23:15:47.323628
# Unit test for function find
def test_find():
    #! [find_unittest]
    a_s_t_2 = module_0.AST()
    a_s_t_3 = get_parent(a_s_t_2, a_s_t_2, rebuild=True)
    
    
    #! [find_unittest]

# Generated at 2022-06-25 23:15:56.618965
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .test_nodes import builtin_function_call
    node = builtin_function_call(
        'len',
        [module_0.Str(s='hello')]
    )
    parent = module_0.Expr(value=node)
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, parent)


# Generated at 2022-06-25 23:15:59.814557
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = find(a_s_t_2, module_0.AST)


# Generated at 2022-06-25 23:16:03.220507
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    replace_at(0, a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 23:16:07.431677
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0, rebuild=True)
    assert isinstance(a_s_t_1, module_0.AST)


# Generated at 2022-06-25 23:16:11.362524
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:16:14.090339
# Unit test for function get_parent
def test_get_parent():
    t = ast.parse('1+2')
    assert get_parent(t, t.body[0]).body[0].value == t.body[0]



# Generated at 2022-06-25 23:16:20.652579
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test where code is not valid
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = []
    try:
        get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    except NodeNotFound:
        raise
    print("Test passed")
    

# Generated at 2022-06-25 23:16:31.814369
# Unit test for function get_parent
def test_get_parent():
    print(get_parent([[[]], [[]]], [[[]], []]))
    print(get_parent([[[[]], []], []], [[[]], []]))
    print(get_parent([[], [[[]], []]], [[[]], []]))
    print(get_parent([[[[]], [[]], []], []], [[[]], [[]], []]))
    print(get_parent([[[[], []], []], []], [[[], []], []]))
    print(get_parent([[], []], [[[[]], []]]))
    print(get_parent([], [[[[]], []]]))
    print(get_parent([], [[]], True))
    print(get_parent([[[]], [[]]], [[[]], [[]]]))

# Generated at 2022-06-25 23:16:32.929660
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    #TODO: implement unit test
    pass

# Generated at 2022-06-25 23:16:36.915231
# Unit test for function find
def test_find():
    d = dict()
    d['a'] = 'apple'
    d['b'] = 'banana'
    for k in find(d, str):
        assert False


# Generated at 2022-06-25 23:16:39.662743
# Unit test for function find
def test_find():
    # Get the root of the AST
    root = ast.parse("import pyspark.sql.functions as sqlf")

    for node in ast.walk(root):
        if isinstance(node, ast.ImportFrom):
            assert node == find(root, ast.ImportFrom).__next__()



# Generated at 2022-06-25 23:16:42.804509
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:16:48.681640
# Unit test for function get_parent
def test_get_parent():
    # Tree: 
    # - AST()
    #   - Module()
    #     - FunctionDef()
    #       - Arguments()
    #         - Name()
    module = ast.Module([ast.FunctionDef('test', ast.arguments([ast.Name('a')], None, None, []))])
    _build_parents(module)
    get_parent(module, module.body[0])


# Generated at 2022-06-25 23:16:51.098280
# Unit test for function find
def test_find():
    a_s_t_3 = module_0.AST()
    iter_1 = find(a_s_t_3, ast.AST)
    for value in iter_1:
        pass


# Generated at 2022-06-25 23:16:56.722675
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    assert isinstance(a_s_t_0, module_0.AST)
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert isinstance(a_s_t_1, module_0.AST)


# Generated at 2022-06-25 23:16:59.254156
# Unit test for function find
def test_find():
    # Sanity check
    a_s_t_2 = module_0.AST()
    assert find(a_s_t_2, module_0.AST)


# Generated at 2022-06-25 23:17:07.669479
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    assert_equal(get_parent(a_s_t_0, a_s_t_0), a_s_t_0)

if __name__ == "__main__":
    run_local_tests()

# Generated at 2022-06-25 23:17:11.268228
# Unit test for function find
def test_find():
    # Stub
    module_0 = None

    # Assignments
    a_s_t_0 = module_0.AST()
    a_s_t_4 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:17:22.284046
# Unit test for function find
def test_find():
    a_s_t_0 = ast.Module(body=[ast.FunctionDef(name='a_s_t_0', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None), ast.ClassDef(name='a_s_t_1', bases=[], keywords=[], body=[], decorator_list=[])])
    #assert find(a_s_t_0, ast.FunctionDef) == [a_s_t_0]
    #assert find(a_s_t_0, ast.ClassDef) == [a_s_t_1]
    #assert find(a_s_t_0, ast.arguments) == [a_s_t_0]

# Generated at 2022-06-25 23:17:23.822997
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test attributes.

    # Test return type.
    # assert False
    return


# Generated at 2022-06-25 23:17:26.703994
# Unit test for function find
def test_find():
    module_0 = ast.parse('a = 1')
    a_s_t_0 = module_0.body[0]
    module_0 = ast.parse('a = 1')
    a_s_t_1 = module_0.body[0].value
    a_s_t_2 = find(a_s_t_1, ast.Num)


# Generated at 2022-06-25 23:17:30.981152
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    ret_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert(not isinstance(ret_0, list))
    assert(not isinstance(ret_0, tuple))


# Generated at 2022-06-25 23:17:41.592172
# Unit test for function find
def test_find():
    a_s_t_2 = ast.parse("import os, sys")
    a_s_t_3 = find(a_s_t_2, ast.Module)
    a_s_t_4 = next(a_s_t_3)
    a_s_t_5 = a_s_t_2.body[0]
    assert a_s_t_4 == a_s_t_5
    a_s_t_6 = get_parent(a_s_t_2, a_s_t_4)
    assert a_s_t_6 == a_s_t_2
    a_s_t_7 = a_s_t_4.body[0]
    a_s_t_8 = next(a_s_t_3)
    assert a_s_

# Generated at 2022-06-25 23:17:45.081175
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_1 = module_0.AST()
    l_0_5_t_1, l_0_5_t_2 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_1)



# Generated at 2022-06-25 23:17:50.121084
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test 1
    print('Test 1')
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert a_s_t_1.type == None
    assert a_s_t_1.lineno == None


# Generated at 2022-06-25 23:17:50.951455
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    try:
        test_case_0()
    except NodeNotFound:
        pass

# Generated at 2022-06-25 23:18:06.665568
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 23:18:09.678058
# Unit test for function get_parent
def test_get_parent():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = get_parent(a_s_t_2, a_s_t_2)
    assert a_s_t_3



# Generated at 2022-06-25 23:18:12.924654
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast
    e_s_t_0 = ast.Module()
    a_s_t_0 = get_non_exp_parent_and_index(e_s_t_0, e_s_t_0)


# Generated at 2022-06-25 23:18:22.414017
# Unit test for function find
def test_find():
    """
    Test for function find
    """
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.copy_location(ast.Name(), None)
    a_s_t_1 = ast.copy_location(ast.Name(), None)
    a_s_t_2 = ast.copy_location(ast.Name(), None)
    a_s_t_3 = ast.copy_location(ast.Name(), None)
    a_s_t_4 = ast.copy_location(ast.Name(), None)
    a_s_t_5 = ast.copy_location(ast.Name(), None)
    a_s_t_6 = ast.copy_location(ast.Name(), None)
    a_s_t_7 = ast.copy_location(ast.Name(), None)


# Generated at 2022-06-25 23:18:26.016463
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = module_0.AST()
    node = module_0.AST()
    type_ = module_0.AST
    a_s_t_8 = get_closest_parent_of(tree, node, type_)

# Generated at 2022-06-25 23:18:30.147169
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = ast.Module([ast.ImportFrom(module='typed_ast', names=[], level=0)])
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0.body[0], ast.Module)


# Generated at 2022-06-25 23:18:35.020793
# Unit test for function find
def test_find():
    t = ast.parse('foo(1)')
    f = find(t, ast.FunctionDef)
    assert [n for n in f] == []

    t = ast.parse('def foo(x):\n    pass')
    f = find(t, ast.FunctionDef)
    assert next(f).name == 'foo'



# Generated at 2022-06-25 23:18:47.002475
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    t_y_p_e_3, child_index_4 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    a_s_t_12 = module_0.Assign()
    a_s_t_2 = module_0.Name()
    a_s_t_2.id = "id"
    a_s_t_12.value = a_s_t_2
    a_s_t_6 = module_0.Name()
    a_s_t_6.id = "id"
    a_s_t_12.targets = [a_s_t_6]

# Generated at 2022-06-25 23:18:49.183065
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:18:57.626227
# Unit test for function find
def test_find():
    module_0 = ast.parse('''
a: int = 1

if a == 1:
    print(a)
''')
    a_s_t_0 = module_0
    assert list(find(a_s_t_0, ast.FunctionDef)) == []
    assert list(find(a_s_t_0, ast.For)) == []
    assert list(find(a_s_t_0, ast.Name)) == [
        module_0.body[0].value.args[0],
        module_0.body[1].test.left
    ]
    assert list(find(a_s_t_0, ast.If)) == [
        module_0.body[1]
    ]


# Generated at 2022-06-25 23:19:25.750563
# Unit test for function get_parent
def test_get_parent():
    print("Testing function get_parent")

    # 1. Test case with class AST
    a_s_t = module_0.AST()
    try:
        get_parent(a_s_t, a_s_t)
    except NodeNotFound:
        pass

if __name__ == '__main__':
    # test_get_parent()
    test_case_0()

# Generated at 2022-06-25 23:19:31.636329
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_5.body = [a_s_t_3]
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [a_s_t_5]
    assert get_closest_parent_of(a_s_t_0, a_s_t_3, module_0.AST) == a_s_t_5

# Generated at 2022-06-25 23:19:37.026019
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Module()
    a_s_t_2 = [a_s_t_0]
    a_s_t_3 = replace_at(0, a_s_t_1, a_s_t_2)


# Generated at 2022-06-25 23:19:40.100863
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    # a generator
    a_s_t_2 = find(a_s_t_0, AST)

# Generated at 2022-06-25 23:19:44.359488
# Unit test for function get_parent
def test_get_parent():

    # Setup
    a_s_t_2 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_2, a_s_t_2)

    # Assert function calls
    assert test_case_0() == None

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:19:47.159325
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.AST()
    assert get_non_exp_parent_and_index(a_s_t_2, a_s_t_2) == (a_s_t_2, 0)

# Generated at 2022-06-25 23:19:50.007636
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:19:52.809850
# Unit test for function find
def test_find():
    tree = ast.parse("a = 1")

    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Load))) == 2



# Generated at 2022-06-25 23:19:55.260291
# Unit test for function replace_at
def test_replace_at():
    assert get_parent(None, None) is None
    assert get_parent(None, None) is None


# Generated at 2022-06-25 23:20:05.184151
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST() # type: typing.Any
    module_0.arguments(None, None, None, a_s_t_2, None)
    for a_s_t_8 in find(a_s_t_2, module_0.FunctionDef):
        a_s_t_17 = a_s_t_8
    for a_s_t_25 in find(a_s_t_17, module_0.arguments):
        a_s_t_37 = a_s_t_25
        a_s_t_40 = a_s_t_8.body
    a_s_t_44 = module_0.Module(a_s_t_40)
