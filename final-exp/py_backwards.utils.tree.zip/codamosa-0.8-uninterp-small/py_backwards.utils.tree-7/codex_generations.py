

# Generated at 2022-06-25 23:14:43.550599
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from . import parse_source
    from .ast_print import pretty_print
    source = 'a: int = 1'
    tree = parse_source(source)
    target_node = tree._fields[-1]
    actual = get_closest_parent_of(tree, target_node, ast.AnnAssign)
    expected_source = 'AnnAssign(target=Name(id=\'a\', ctx=Store()), annotation=Name(id=\'int\', ctx=Load()), value=Num(n=1), simple=1)'
    expected = parse_source(expected_source)
    assert pretty_print(actual) == pretty_print(expected)


# Generated at 2022-06-25 23:14:44.435734
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False == True


# Generated at 2022-06-25 23:14:46.376577
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)



# Generated at 2022-06-25 23:14:49.136469
# Unit test for function find
def test_find():
    a_s_t_4 = module_0.AST()
    i_t_5 = find(a_s_t_4, type_=module_0.AST)
    assert isinstance(i_t_5, Iterable)


# Generated at 2022-06-25 23:14:54.546786
# Unit test for function find
def test_find():

    # module_0: TestCase
    a_s_t_0 = module_0.AST()
    iter_0 = find(a_s_t_0, module_0.AST)
    pass_0 = True

    for v_0 in iter_0:
        if type(v_0) != module_0.AST:
            pass_0 = False
            break

    assert pass_0


# Generated at 2022-06-25 23:14:56.713180
# Unit test for function get_parent
def test_get_parent():
    # Test code

    try:
        test_case_0()
    except:
        raise

# Test code for non exp parent

# Generated at 2022-06-25 23:15:00.418261
# Unit test for function find
def test_find():
    # Test 1
    a_s_t_2 = module_0.AST()
    a_s_t_3 = get_parent(a_s_t_2, a_s_t_2)
    a_s_t_4 = find(a_s_t_2, a_s_t_3)


# Generated at 2022-06-25 23:15:03.939018
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_0 = find(a_s_t_1, module_0.AST)


# Generated at 2022-06-25 23:15:09.142140
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, module_0.AST)
    assert_equal(next(iterable_0), a_s_t_0)
    assert_raises(StopIteration, next, iterable_0)


# Generated at 2022-06-25 23:15:18.242680
# Unit test for function replace_at
def test_replace_at():
    # Setup
    f_c = module_0.FunctionDef('f', module_0.arguments(
        args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(
        value=module_0.Num(n=1)), module_0.Return(value=module_0.Num(n=2))], decorator_list=[], returns=None)
    r = module_0.Return(value=module_0.Num(n=2))

    # Test body
    replace_at(0, f_c, r)
    assert f_c.body == [r, r]


# Generated at 2022-06-25 23:15:26.741907
# Unit test for function insert_at
def test_insert_at():
    a_s_t_0 = module_0.AST()
    insert_at(0, a_s_t_0, a_s_t_0)
    a_s_t_list_0 = [a_s_t_0]
    insert_at(0, a_s_t_0, a_s_t_list_0)


# Generated at 2022-06-25 23:15:28.503159
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index([4,3,2,1,3,4], 2) == (8, 1)

# Generated at 2022-06-25 23:15:36.450003
# Unit test for function find
def test_find():
    print('Testing find')
    a_s_t_0 = module_0.AST()
    l_s_t_2 = find(a_s_t_0, type_=module_0.AST)
    try:
        a_s_t_0_clone = module_0.AST()
        l_s_t_2_clone = find(a_s_t_0_clone, type_=module_0.AST)
        for item_0, item_1 in zip(l_s_t_2, l_s_t_2_clone):
            assert item_0 == item_1
        print('Passed!')
    except:
        print('Failed!')


# Generated at 2022-06-25 23:15:40.314958
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = find(a_s_t_0, ast.AST)
    a_s_t_2 = a_s_t_1.__name__


# Generated at 2022-06-25 23:15:49.564076
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast

    m = typed_ast.ast3.Module([typed_ast.ast3.Expr(typed_ast.ast3.Call(typed_ast.ast3.Name('f',
        typed_ast.ast3.Load()), [], []))])

    p, i = get_non_exp_parent_and_index(m, m.body[0].value)
    assert p is m
    assert i == 0

    typed_ast.ast3.FunctionDef('f', None, [], None, [typed_ast.ast3.Return(typed_ast.ast3.Num(1))])


# Generated at 2022-06-25 23:16:03.293028
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.FunctionDef('a', [], [], [], [])
    a_s_t_3 = module_0.arguments([], None, [], [], None, [])
    a_s_t_2.args = a_s_t_3
    assert (a_s_t_2, 0) == get_non_exp_parent_and_index(a_s_t_2, a_s_t_2)
    a_s_t_4 = module_0.Raise(None, None)
    assert (a_s_t_2.body, 0) == get_non_exp_parent_and_index(a_s_t_2, a_s_t_4)

# Generated at 2022-06-25 23:16:06.047071
# Unit test for function find
def test_find():
    a_s_t_0 = ast.Module([])
    result = find(a_s_t_0, ast.Pass)
    assert result == iter([])


# Generated at 2022-06-25 23:16:09.789660
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1, a_s_t_2 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:16:14.721978
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Unit tests.
    class A(ast.AST):
        body = []
    class B(A):
        pass
    a = A()
    b = B()
    a.body.append(b)
    assert get_non_exp_parent_and_index(a, b) == (a, 0)

# Generated at 2022-06-25 23:16:27.356974
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as module_0
    try:
        a_s_t_0 = module_0.AST()
    except NameError:
        import sys
        if sys.version_info < (3, 6):
            # Python < 3.6
            from .backport import module_0
        else:
            try:
                from .backport import module_0
            except ImportError:
                import _ast3 as module_0
        a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, ast.AST)


# Generated at 2022-06-25 23:16:40.472802
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Unit test for function get_non_exp_parent_and_index
    module_0 = ast.Module(body=[
            ast.ImportFrom(module='typed_ast._ast3', names=[
                    ast.alias(name='AST', asname=None)],
                    level=0),
            ast.Expr(value=ast.Call(func=ast.Name(id='test_case_0',
                    ctx=ast.Load()), args=[], keywords=[]),
                    lineno=1, col_offset=0)])

# Generated at 2022-06-25 23:16:43.506132
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    for a_s_t_1 in find(a_s_t_0, a_s_t_0):
        a_s_t_1


# Generated at 2022-06-25 23:16:48.073351
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    (a_s_t_1, int_0) = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:16:51.138948
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    print(a_s_t_1.body)

# Generated at 2022-06-25 23:17:00.408867
# Unit test for function find
def test_find():
    assert list(find(ast.parse('a = 1\nb = 3'), ast.Assign)) == [ast.parse('a = 1').body[0]]
    assert list(find(ast.parse('a = 1; b = 3'), ast.Assign)) == [ast.parse('a = 1; b = 3').body[0]]
    assert list(find(ast.parse('a = (1)'), ast.Assign)) == [ast.parse('a = (1)').body[0]]

# Generated at 2022-06-25 23:17:06.684409
# Unit test for function get_parent
def test_get_parent():
    a_s_t_2 = module_0.num()
    a_s_t_3 = get_parent(a_s_t_2, a_s_t_2)
    assert(isinstance(a_s_t_3, module_0.AST))

    a_s_t_4 = module_0.num()
    a_s_t_5 = get_parent(a_s_t_4, a_s_t_4)
    assert(isinstance(a_s_t_5, module_0.AST))


# Generated at 2022-06-25 23:17:13.046077
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0

    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    # Check that the return value is of the correct type
    assert isinstance(a_s_t_1, tuple)

    # Check that the return value is correct
    assert a_s_t_1 == ((), 0)


# Generated at 2022-06-25 23:17:18.376220
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

    # AssertionError: Assertion failed
    assert a_s_t_1 == a_s_t_0


# Generated at 2022-06-25 23:17:22.754954
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0

    a_s_t_0 = module_0.Str()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.Str)


# Generated at 2022-06-25 23:17:26.095258
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.Assign()
    a_s_t_1 = module_0.FunctionDef()
    a_s_t_1.body.append(a_s_t_0)
    a_s_t_2, a_s_t_3 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_0)
    assert a_s_t_2 is a_s_t_1
    assert a_s_t_3 == 0

# Generated at 2022-06-25 23:17:33.686533
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert(True)


# Generated at 2022-06-25 23:17:39.746116
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = ast.Assign()
    a_s_t_1 = ast.AST()
    a_s_t_2 = ast.Module()
    arg_0 = a_s_t_2
    arg_1 = a_s_t_0
    arg_2 = False
    ret_0 = get_parent(arg_0, arg_1, arg_2)
    assert(ret_0 == a_s_t_1)


# Generated at 2022-06-25 23:17:42.780616
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = ast.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:17:51.402922
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Analysis of a_s_t
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_2 = module_0.AST()
    a_s_t_3 = get_parent(a_s_t_0, a_s_t_2)
    a_s_t_4 = get_closest_parent_of(a_s_t_0, a_s_t_2, module_0.AST)
    a_s_t_5 = get_closest_parent_of(a_s_t_0, a_s_t_2, module_0.AST)
    a_s_t_6 = get_clos

# Generated at 2022-06-25 23:17:54.388472
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    replace_at(0, a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:18:01.251170
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test case 0
    a_s_t_0 = module_0.AST()  # type: module_0.AST
    try:
        get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    except NodeNotFound:
        pass

# Generated at 2022-06-25 23:18:04.232767
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:13.526289
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test that function get_non_exp_parent_and_index returns parent and index
    of a non-Exp AST node.
    """
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Str(s='')
    a_s_t_0.body = [a_s_t_1]
    a_s_t_2, a_s_t_3 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)
    assert a_s_t_2 == a_s_t_0
    assert a_s_t_3 == 0


# Generated at 2022-06-25 23:18:22.689825
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert 1 == 1

    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.alias()
    (a_s_t_3, int_4) = get_non_exp_parent_and_index(a_s_t_1, a_s_t_2)

    from typed_ast.ast3 import arg

    a_s_t_6 = arg()

    # Unit test for function insert_at
    def test_insert_at():
        assert 1 == 1

        a_s_t_7 = module_0.alias()

        insert_at(int_4, a_s_t_6, a_s_t_7)


# Generated at 2022-06-25 23:18:32.262108
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)

    # Test case #0 with expected type 'AST'
    try:
        assert isinstance(a_s_t_1, module_0.AST)
    except AssertionError as e:
        print(e)
    # Test case #1 with expected type 'AST'
    try:
        a_s_t_2 = module_0.Module()
        assert isinstance(a_s_t_2, module_0.AST)
    except AssertionError as e:
        print(e)
    # Test case #2 with expected type 'AST'

# Generated at 2022-06-25 23:18:45.019260
# Unit test for function replace_at
def test_replace_at():
    module_0 = typed_ast._ast3
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    l_i_s_t_0 = []
    replace_at(0, a_s_t_0, a_s_t_1)
    replace_at(0, a_s_t_0, l_i_s_t_0)


# Generated at 2022-06-25 23:18:46.094481
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass


# Generated at 2022-06-25 23:18:55.311488
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.With(module_0.Name(id='foo', ctx=module_0.Load()),
                    module_0.Store(),
                    [module_0.Raise(type_=module_0.Name(id='bar', ctx=module_0.Load()),
                      inst=None,
                      tback=None)],
                    [])]
    result = list(find(a_s_t_0, module_0.Name))
    assert len(result) == 2
    assert isinstance(result[0], module_0.Name)
    assert result[0].id == 'foo'
    assert result[0].ctx == module_0.Load()

# Generated at 2022-06-25 23:18:59.629840
# Unit test for function find
def test_find():
    test_cases = [
        {
            "name": "test_case_0",
            "tree": a_s_t_0,
            "type_": a_s_t_0,
            "expected": a_s_t_0,
        }
    ]

    for test_case in test_cases:
        yield _test_find, test_case


# Generated at 2022-06-25 23:19:06.377645
# Unit test for function get_parent
def test_get_parent():
    from typed_ast import ast3 as ast
    import _ast
    a_s_t_2 = ast.parse("1")
    a_s_t_3 = find(a_s_t_2, _ast.Num)
    a_s_t_4 = next(a_s_t_3)
    a_s_t_5 = get_parent(a_s_t_2, a_s_t_4)
    assert a_s_t_5.__class__ == ast.Expr


# Generated at 2022-06-25 23:19:08.793660
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    assert [a_s_t_0] == list(find(a_s_t_0, module_0.AST))


# Generated at 2022-06-25 23:19:18.170112
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iter = find(a_s_t_0, module_0.AST)
    _a_s_t_0 = next(iter)
    a_s_t_1 = _a_s_t_0
    if (not (a_s_t_1 == a_s_t_0)):
        raise Exception('Expected {}, got {}'.format(repr(a_s_t_0), repr(a_s_t_1)))
    try:
        _a_s_t_1 = next(iter)
    except StopIteration as e:
        _a_s_t_1 = e
    a_s_t_2 = _a_s_t_1


# Generated at 2022-06-25 23:19:21.303047
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST()
    i_t_3 = find(a_s_t_2, module_0.AST)


# Generated at 2022-06-25 23:19:29.115099
# Unit test for function find
def test_find():
    a_s_t_1 = module_0.Module()
    a_s_t_2 = module_0.Str('str')
    a_s_t_3 = ast.Expression()
    a_s_t_4 = ast.FunctionDef()
    a_s_t_5 = ast.FunctionDef()
    a_s_t_6 = ast.Str()
    a_s_t_7 = ast.Str()
    a_s_t_8 = ast.Name()
    a_s_t_9 = ast.Name()
    a_s_t_3.body = a_s_t_2
    a_s_t_1.body = [a_s_t_3, a_s_t_4, a_s_t_5]
    a_s_t_5

# Generated at 2022-06-25 23:19:31.542224
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = None
    r_e_s = replace_at(0, a_s_t_0, None)
    assert r_e_s is None

# Generated at 2022-06-25 23:19:52.419192
# Unit test for function find
def test_find():
    # Insert here the code to test
    # Test Case #0
    a_s_t_0 = module_0.AST(body=module_0.Module([module_0.Expr([module_0.Num(1)])]))
    a_s_t_1 = find(a_s_t_0, module_0.Num)
    assert isinstance(a_s_t_1, Iterable)

    # Test Case #1
    a_s_t_0 = module_0.AST(body=module_0.Module([module_0.Expr([module_0.Num(1)])]))
    a_s_t_1 = find(a_s_t_0, module_0.Num)
    assert isinstance(a_s_t_1, Iterable)


# Generated at 2022-06-25 23:20:03.422401
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    a_s_t_0 = module_0.AST()
    test_case_0()

    a_s_t_1 = module_0.Name()
    a_s_t_2 = module_0.Load()
    a_s_t_3 = module_0.FunctionDef()
    a_s_t_3.name = "color"
    a_s_t_3.args = module_0.arguments()
    a_s_t_3.args.args = [ module_0.arg( arg="self", annotation=None, type_comment=None ) ]
    a_s_t_4 = module_0.Return()
    a_s_t_4.value = module_0.Str()
    a_s_t_4.value.s = "green"
    a_s_

# Generated at 2022-06-25 23:20:06.960580
# Unit test for function find
def test_find():
    # Test case
    a_s_t_0 = module_0.AST()
    res_1 = find(a_s_t_0, type(None))

    # Assertion
    assert_equal(res_1, [])



# Generated at 2022-06-25 23:20:10.007461
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    (a_s_t_1, i_2) = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:20:13.198377
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import _ast
    import typed_ast._ast3 as module_1
    a_s_t_0 = _ast.AST()
    a_s_t_1 = module_1.AST()
    a_s_t_2 = get_closest_parent_of(a_s_t_0, a_s_t_1, type(_ast.AST))


# Generated at 2022-06-25 23:20:19.071385
# Unit test for function find
def test_find():
    # Test types
    root = module_0.AST()
    ast_list = find(root, module_0.AST)
    attr_0 = next(ast_list)
    bool_0 = isinstance(attr_0, module_0.AST)


# Generated at 2022-06-25 23:20:23.787125
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Tree
    a_s_t_0 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0,  a_s_t_0)


# Generated at 2022-06-25 23:20:30.794673
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Create a test tree.
    test_tree = ast.Module()
    test_tree.body = [
        ast.FunctionDef(name='f', args=ast.arguments(), body=[
            ast.Expr(
                ast.Call(
                    ast.Name(id='g', ctx=ast.Load()),
                    args=[ast.Num(n=0)],
                    keywords=[]
                )
            )
        ], decorator_list=[])
    ]

    # Find the call to g
    call_g = find(test_tree, ast.Call).__next__()

    # Obtain the FunctionDef and its index
    func_def, index = get_non_exp_parent_and_index(test_tree, call_g)

    assert isinstance(func_def, ast.FunctionDef)
    assert index

# Generated at 2022-06-25 23:20:38.995851
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # import ast

    # test_tree = ast.parse("if True:\n    pass")
    # node = list(ast.walk(test_tree))[3]
    # get_closest_parent_of(test_tree, node, ast.If)

    # import ast

    # test_tree = ast.parse("if True:\n    pass")
    # node = list(ast.walk(test_tree))[3]
    # get_closest_parent_of(test_tree, node, ast.If)
    pass


# Generated at 2022-06-25 23:20:46.529386
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST()
    find(a_s_t_2, module_0.AST)


# Generated at 2022-06-25 23:21:18.519013
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST()
    nodes_0 = find(a_s_t_2, module_0.astng._astng_base.ASTNG)
    a_s_t_3 = module_0.AST()
    nodes_1 = find(a_s_t_3, module_0.astng._astng_base.ASTNG)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:21:24.885391
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.FunctionDef('f', [], [], [], 0, [])
    a_s_t_2.body = [None]
    a_s_t_1.body = [a_s_t_2]
    a_s_t_0 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_2)


# Generated at 2022-06-25 23:21:25.986065
# Unit test for function find
def test_find():
    assert find is not None


# Generated at 2022-06-25 23:21:33.699679
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Module()
    a_s_t_2 = module_0.Expr()
    a_s_t_3 = module_0.Lambda()
    a_s_t_4 = module_0.Lambda()
    a_s_t_5 = module_0.Lambda()
    a_s_t_6 = module_0.arg()
    a_s_t_7 = module_0.arg()
    a_s_t_8 = module_0.arg()
    a_s_t_9 = module_0.arg()
    a_s_t_10 = module_0.arg()
    a_s_t_11 = module_0.arg()


# Generated at 2022-06-25 23:21:44.259218
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [a_s_t_0]
    a_s_t_0.parent = a_s_t_1
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()

    replace_at(0, a_s_t_1, a_s_t_2)
    assert a_s_t_1.body == [a_s_t_2, a_s_t_0] and a_s_t_2.parent == a_s_t_1


# Generated at 2022-06-25 23:21:50.836569
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class a_s_t_0(ast.AST):
        _attributes = ('a_s_t_0',)

    class a_s_t_1(ast.AST):
        _attributes = ('a_s_t_1',)

    a_s_t_2 = a_s_t_0(a_s_t_1())

    assert get_closest_parent_of(a_s_t_2, a_s_t_2.a_s_t_1, a_s_t_0) == a_s_t_2


import inspect
import sys
import typing
from typing import TYPE_CHECKING



# Generated at 2022-06-25 23:21:51.476639
# Unit test for function find
def test_find():
    find()


# Generated at 2022-06-25 23:22:00.356165
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast
    import astunparse
    import textwrap
    from . import get_non_exp_parent_and_index
    from . import insert_at
    from . import Module

    tree = ast.parse(textwrap.dedent('''
    def foo():
        if bar():
            pass
        elif baz():
            pass
        else:
            raise Exception()
    '''))

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    insert_at(index, parent, ast.Pass())
    module = Module(astunparse.unparse(tree))

# Generated at 2022-06-25 23:22:09.982439
# Unit test for function find
def test_find():
    import _ast
    import typed_ast._ast3 as typed_ast

    AST = typed_ast.AST

    a_s_t_0 = AST()
    a_s_t_1 = AST()
    a_s_t_2 = AST()
    a_s_t_3 = _ast.Expr()
    a_s_t_4 = _ast.Expression()
    a_s_t_5 = _ast.Expression()
    a_s_t_1.body.append(a_s_t_3)  # type: ignore
    a_s_t_2.body.append(a_s_t_4)  # type: ignore
    a_s_t_2.body.append(a_s_t_5)  # type: ignore
    a_s_t_

# Generated at 2022-06-25 23:22:10.375460
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert True

# Generated at 2022-06-25 23:23:05.750210
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    assert isinstance(a_s_t_1, module_0.AST)


# Generated at 2022-06-25 23:23:13.253725
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.Name()
    a_s_t_3 = module_0.Name()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.Assign()
    a_s_t_6 = module_0.Name()
    a_s_t_7 = module_0.Name()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.Assign()
    a_s_t_10 = module_0.Name()
    a_s_t_11 = module_0.Name()
    a_s_t_12 = module_0.Assign()
    a_s_t_13 = module_0.Name()
    a_s

# Generated at 2022-06-25 23:23:18.148274
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_1
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_1.Module()
    try:
        a_s_t_2 = get_closest_parent_of(a_s_t_0, a_s_t_1, type(a_s_t_1))
    except NodeNotFound as e:
        print('Exception caught: {}'.format(e))


# Generated at 2022-06-25 23:23:22.877666
# Unit test for function find
def test_find():
    """
    Tests find function.

    Arguments: None
    Returns: None

    """
    def test_case_0():
        """
        Tests funciton finds.

        Arguments: None
        Returns: None

        """
        def test_case_0():
            """
            Tests funciton finds.

            Arguments: None
            Returns: None

            """
            pass
        test_case_0()
    test_case_0()

# Generated at 2022-06-25 23:23:31.932187
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()

    _parents[a_s_t_1] = a_s_t_2
    _parents[a_s_t_2] = a_s_t_3
    _parents[a_s_t_3] = a_s_t_4
    _parents[a_s_t_4] = a_s_t_5
    _parents[a_s_t_5] = a_s_t_

# Generated at 2022-06-25 23:23:34.262277
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:23:43.046156
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0
    import typed_ast._ast3 as module_1
    # CASE 0
    a_s_t_0 = module_0.Module()
    a_s_t_1 = module_0.Expr()
    a_s_t_0.body = [a_s_t_1]
    a_s_t_2 = module_1.NameConstant()
    a_s_t_3 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_2)
    pass
    # CASE 1
    a_s_t_0 = module_0.Module()
    a_s_t_1 = module_0.Expr()
    a_s_t_2 = module_1.NameConstant()

# Generated at 2022-06-25 23:23:45.188009
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    case_0 = get_closest_parent_of(module_0.AST(),
                                   module_0.AST(),
                                   Type[ast.AST])
    assert case_0 == module_0.AST()

# Generated at 2022-06-25 23:23:50.614715
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = []
    list_0 = []
    a_l_0 = find(a_s_t_0, list)
    list_0.append(a_s_t_0)
    list_0.append(module_0)
    list_0.append(module_0.Name)
    list_0.append(module_0.FunctionDef)
    a_l_1 = list_0
    assert a_l_0 == a_l_1


# Generated at 2022-06-25 23:23:53.772941
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    test_find_0 = find(a_s_t_0, type(a_s_t_0))
    assert isinstance(test_find_0, Iterable)
