

# Generated at 2022-06-25 23:14:44.652215
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    exp_s_t_0 = module_0.Expression()
    a_s_t_0 = module_0.AST()
    exp_s_t_1 = module_0.Expression()
    a_s_t_1 = module_0.AST()
    exp_s_t_2 = module_0.Expression()
    a_s_t_2 = module_0.AST()
    exp_s_t_3 = module_0.Expression()
    a_s_t_3 = module_0.AST()

    assert get_non_exp_parent_and_index(a_s_t_0, exp_s_t_0) == (a_s_t_0, 0)

# Generated at 2022-06-25 23:14:45.323501
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:14:47.201572
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    s_t_r_0 = find(a_s_t_0, str)


# Generated at 2022-06-25 23:14:47.966299
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert test_case_0() is True

# Generated at 2022-06-25 23:14:57.551408
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    t_y_p_e_1 = find(a_s_t_3, module_0.AST)
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    t_y_p_e_2 = find(a_s_t_5, module_0.AST)
    t_y_p_e_3 = find(a_s_t_4, module_0.AST)
    a_

# Generated at 2022-06-25 23:14:59.288624
# Unit test for function get_parent
def test_get_parent():
    tree: ast.AST = ast.parse('print("123")', mode='exec')
    node = tree
    rebuild = False
    result = get_parent(tree, node, rebuild)
    assert result is tree


# Generated at 2022-06-25 23:15:01.177778
# Unit test for function get_parent
def test_get_parent():
    # Start test 1.
    # Simple test case
    try:
        test_case_0()
    except NodeNotFound:
        pass



# Generated at 2022-06-25 23:15:04.515958
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_0 = module_0.AST()
    parent_0 = get_closest_parent_of(ast_0, ast_0, ast.AST)
    parent_1 = get_closest_parent_of(parent_0, ast_0, ast.AST)

# Generated at 2022-06-25 23:15:14.344151
# Unit test for function replace_at
def test_replace_at():
    '''
    this is a test for the function replace_at
    '''
    print('test begin')
    module_0 = ast.Module()
    module_1 = ast.Body((module_0,))
    import_0 = ast.Import()
    module_2 = ast.Module((import_0,))
    import_1 = ast.ImportFrom()
    module_3 = ast.Module((import_1,))
    import_2 = ast.Import()
    module_4 = ast.Module((module_1,module_2,module_3,import_2,))
    replace_at(2,module_4,(import_1,))
    print('test end')

# Generated at 2022-06-25 23:15:23.319857
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.If()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = [a_s_t_4, a_s_t_5, a_s_t_6, a_s_t_7]
    a_s_t_5.body = a_s_t_8
    a_s_t_7.body = a_s_t_2
    a_s_t_5.orelse = a_s_t_3
   

# Generated at 2022-06-25 23:15:28.202437
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    typed_ast._ast3.parse()
    assert get_closest_parent_of(None, None, None)


# Generated at 2022-06-25 23:15:31.398529
# Unit test for function find
def test_find():

    # AssertionError - unexpected argument type
    with pytest.raises(Exception):
        find(1, Type[T])

    # AssertionError - unexpected argument type
    with pytest.raises(Exception):
        find(ast.AST(), None)


# Generated at 2022-06-25 23:15:34.968776
# Unit test for function get_parent
def test_get_parent():
    module_ast = ast.parse('print("Hello world")')
    module_ast.body[0].value.left = ast.Call()

    try:
        get_parent(module_ast, module_ast.body[0].value.left.func)
    except NodeNotFound:
        pass

# Generated at 2022-06-25 23:15:42.174892
# Unit test for function find

# Generated at 2022-06-25 23:15:50.846007
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast
    import astor
    node = """
        def a(x=1):
            b = 1
    """
    expected_index = 2
    t = ast.parse(node)
    i = ast.FunctionDef(
        name='a',
        args=ast.arguments(args=[ast.arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[ast.Num(n=1)]),
        body=[
            ast.Assign(
                targets=[ast.Name(id='b', ctx=ast.Store())],
                value=ast.Num(n=1))],
        decorator_list=[],
        returns=None)

# Generated at 2022-06-25 23:15:56.912928
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    t_y_p_e_0 = find(a_s_t_1, module_0.AST)
    t_y_p_e_1 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:16:03.606127
# Unit test for function find
def test_find():
    # We need to make sure that the parents dictionary is rebuilt
    # everytime, so we can do proper tests.
    _build_parents(ast.parse("1+1"))
    _find_0 = find(ast.parse("1+1"), ast.Module)
    for a_s_t_0 in _find_0:
        assert isinstance(a_s_t_0, ast.Module)



# Generated at 2022-06-25 23:16:12.650223
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    assert get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST) == a_s_t_0
    a_s_t_1 = module_0.Module()
    assert get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.AST) == a_s_t_1

print("test_case_0")
test_case_0()
print("test_get_closest_parent_of")
test_get_closest_parent_of()

# Generated at 2022-06-25 23:16:13.692518
# Unit test for function replace_at
def test_replace_at():
    assert False


# Generated at 2022-06-25 23:16:18.299255
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Test get_closest_parent_of."""
    assert get_closest_parent_of(a_s_t_0, a_s_t_0, type_=module_0.AST) == a_s_t_1



# Generated at 2022-06-25 23:16:27.397283
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0 

    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = a_s_t_1
    a_s_t_3 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:16:31.770075
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.arg()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, ast.Name)


# Generated at 2022-06-25 23:16:37.965875
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast
    m = ast.Module()
    f = ast.FunctionDef("add", ast.arguments(args=[]), [], [], ast.Add())
    m.body.append(f)
    parent, index = get_non_exp_parent_and_index(m, f)
    assert parent is m
    assert index == 0


# Generated at 2022-06-25 23:16:47.480479
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.Expr()
    a_s_t_3 = module_0.AST()
    a_s_t_3.body = [a_s_t_2]
    
    # Test case with match
    a_s_t_4 = find(a_s_t_3, type(None))
    assert(next(a_s_t_4) is a_s_t_2)
    
    # Test case with no match
    a_s_t_5 = find(a_s_t_3, type(a_s_t_4))
    assert(a_s_t_5 is None)


# Generated at 2022-06-25 23:16:56.269894
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.If()
    test_0 = module_0.AST
    test_1 = a_s_t_0
    test_2 = find(test_1, test_0)
    test_3 = type(a_s_t_0)
    test_4 = type(test_1)
    test_5 = isinstance(a_s_t_0, test_3)
    test_6 = isinstance(test_1, test_4)
    assert test_2 == ((a_s_t_0,),)
    assert test_5 is true
    assert test_6 is true

if __name__ == '__main__':
    print('Testing typed_ast._ast3')
    test_case_0()
    test_find()
    print('done')

# Generated at 2022-06-25 23:17:05.339860
# Unit test for function get_closest_parent_of

# Generated at 2022-06-25 23:17:07.721536
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    assert get_parent(a_s_t_0, a_s_t_0) == module_0.AST()


# Generated at 2022-06-25 23:17:10.129105
# Unit test for function get_parent

# Generated at 2022-06-25 23:17:21.094738
# Unit test for function find
def test_find():
    # Make an AST
    a_s_t_0 = module_0.AST()
    # Add a ClassDef node
    a_s_t_1 = module_0.ClassDef(
        name='Bar',
        bases=[],
        keywords=[],
        body=[],
        decorator_list=[],
        lineno=1,
        col_offset=0,
        end_lineno=1,
        end_col_offset=1)
    a_s_t_0.body.append(a_s_t_1)
    # Add a FunctionDef node

# Generated at 2022-06-25 23:17:24.212041
# Unit test for function find
def test_find():
    for i in range(2):
        a_s_t_0 = module_0.AST()
        assert find(a_s_t_0, module_0.AST) == iter([a_s_t_0])


# Generated at 2022-06-25 23:17:32.075951
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    assert a_s_t_1 is a_s_t_0


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:17:34.905952
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    mod = ast.Module()
    assert get_closest_parent_of(mod, mod, ast.Module) == mod

# Generated at 2022-06-25 23:17:44.429856
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Interactive()
    a_s_t_2 = get_parent(a_s_t_0, a_s_t_1, rebuild=bool())
    a_s_t_3 = module_0.Module()
    a_s_t_4 = module_0.Name("NodeNotFound", module_0.Load())
    a_s_t_5 = module_0.Call(a_s_t_4, [a_s_t_4], [], None, None)
    a_s_t_6 = module_0.Expr(a_s_t_5)
    a_s_t_7 = module_0.Raise(a_s_t_6, None)

# Generated at 2022-06-25 23:17:47.658917
# Unit test for function replace_at
def test_replace_at():
    from ...tests.fixtures.test_ast import test_ast
    from ...tests.helpers import replace_at_test_helper
    a_s_t_0 = test_ast.parse_expr()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_2 = module_0.AST()
    replace_at_test_helper(a_s_t_0, a_s_t_1,
                           1, a_s_t_2)


# Generated at 2022-06-25 23:17:54.209764
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    assert a_s_t_1.__class__.__name__ == 'AST'
    a_s_t_2 = module_0.Module()
    a_s_t_3 = module_0.Module()
    a_s_t_4 = module_0.Module()
    a_s_t_5 = module_0.Module()
    a_s_t_3.body.append(a_s_t_2)
    a_s_t_5.body.append(a_s_t_4)
    a_s_t_5.body.append(a_s_t_3)
   

# Generated at 2022-06-25 23:18:06.337520
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.Assign()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.Assign()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.Assign()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s

# Generated at 2022-06-25 23:18:09.992942
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.Assert()
    a_s_t_3 = module_0.Assign()
    a_s_t_4 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_3)


# Generated at 2022-06-25 23:18:15.075112
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    __tracebackhide__ = True
    __tracebackhide__ = True

    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, Type[typed_ast.ast3.AST])


# Generated at 2022-06-25 23:18:26.355728
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Create an example AST
    a_s_t_0 = module_0.AST()
    # Create a second example AST
    a_s_t_1 = module_0.AST()
    # Create a 'TypeError' exception to pass to test
    type_0 = TypeError()
    # Pass ASTs to find the closest parent of 'TypeError'
    a_s_t_2 = get_closest_parent_of(a_s_t_0, a_s_t_1, type_0)

# Generated at 2022-06-25 23:18:29.270745
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:40.690100
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    __tracebackhide__ = True
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, type(None))


# Generated at 2022-06-25 23:18:42.989686
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_0 = module_0.AST()
    a_1 = get_non_exp_parent_and_index(a_0, a_0)


# Generated at 2022-06-25 23:18:46.245745
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)

# Generated at 2022-06-25 23:18:49.209517
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert(get_non_exp_parent_and_index(__import__('typed_ast._ast3'), __import__('typed_ast._ast3')) == (__import__('typed_ast._ast3'), 0))


# Generated at 2022-06-25 23:18:50.661212
# Unit test for function get_parent
def test_get_parent():
    # Check that body is empty
    assert True


# Generated at 2022-06-25 23:18:59.680717
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test for int
    try:
        get_non_exp_parent_and_index(1, 1)
    except TypeError:
        pass
    except:
        raise RuntimeError('Should raise TypeError')
    # Test for AST
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    if (a_s_t_0, 0) != a_s_t_1:
        raise AssertionError('Should raise AssertionError')
    a_s_t_2 = module_0.AST()
    a_s_t_2.body = [module_0.Expr()]
    a_s_t_3 = get_non

# Generated at 2022-06-25 23:19:04.329080
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
  a_s_t_2 = module_0.AST()
  a_s_t_3 = get_closest_parent_of(a_s_t_2, a_s_t_2, a_s_t_2)
  assert isinstance(a_s_t_3, module_0.AST)


# Generated at 2022-06-25 23:19:07.168327
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:19:10.984542
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert a_s_t_1 == a_s_t_0


# Generated at 2022-06-25 23:19:14.156124
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)



# Generated at 2022-06-25 23:19:25.821551
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body.append(a_s_t_1)
    a_s_t_0_ = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)
    assert a_s_t_0_[0] == a_s_t_0
    assert a_s_t_0_[1] == 0


# Generated at 2022-06-25 23:19:27.498678
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    x = module_0.AST()
    y = get_closest_parent_of(x,x,module_0.AST)


# Generated at 2022-06-25 23:19:37.152128
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    py_3_6_0_0 = module_0.Module()
    py_3_6_0_1 = get_closest_parent_of(py_3_6_0_0, py_3_6_0_0, module_0.Name)
    py_3_6_0_2 = get_closest_parent_of(get_closest_parent_of(py_3_6_0_0, py_3_6_0_0, module_0.Name), py_3_6_0_0, module_0.Name)
    py_3_6_0_3 = get_closest_parent_of(py_3_6_0_2, py_3_6_0_2, module_0.Name)


# Generated at 2022-06-25 23:19:46.220940
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    #
    # Function that has no classes or for loops
    #
    a_s_t_0 = module_0.FunctionDef(
        'test_case_0',
        module_0.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ),
        body=[],
        decorator_list=[],
        returns=None,
    )
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert isinstance(a_s_t_1[1], int)
    assert isinstance(a_s_t_1[0], module_0.Module)
    #

# Generated at 2022-06-25 23:19:49.104612
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    (a_s_t_1, int_0) = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:19:53.495081
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        source = b"pass\n"
        filename = os.path.join(tmpdirname, 'file.py')
        with open(filename, 'wb') as f:
            f.write(source)
        tree = ast.parse(source)
        get_non_exp_parent_and_index(tree, tree)


# Generated at 2022-06-25 23:20:04.583110
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Return(module_0.Name(id='a', ctx=module_0.Load()))]
    a_s_t_1 = module_0.If()
    a_s_t_1.body = [module_0.If()]
    a_s_t_1.body[0].body = [module_0.Return(module_0.Name(id='a', ctx=module_0.Load()))]
    a_s_t_1.body[0].body[0].value.ctx.id = 'Return'

# Generated at 2022-06-25 23:20:05.144122
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass

# Generated at 2022-06-25 23:20:12.755841
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as ast

    class AAST(ast.AST):
        pass

    class C(ast.AST):
        def __init__(self, name, body=None, *, lineno=0, col_offset=0, **kwds):
            kwds.update(dict(lineno=lineno, col_offset=col_offset))
            self.name = name
            self.body = body
            super().__init__(**kwds)

        _fields = ('name', 'body')


    class B(ast.AST):
        def __init__(self, name, value, *, lineno=0, col_offset=0, **kwds):
            kwds.update(dict(lineno=lineno, col_offset=col_offset))
            self.name = name
            self

# Generated at 2022-06-25 23:20:21.083235
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = ast.AST()
    assert a_s_t_0 is get_parent(a_s_t_0, a_s_t_0)

import astor as module_1


# Generated at 2022-06-25 23:20:42.569056
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_2 = replace_at(0, a_s_t_1, [a_s_t_0])
    a_s_t_3 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    a_s_t_4 = get_closest_parent_of(a_s_t_0, a_s_t_0, type(a_s_t_0))
    a_s_t_5 = find(a_s_t_0, type(a_s_t_0))

# Generated at 2022-06-25 23:20:45.716813
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast
    a_s_t_0 = typed_ast.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, typed_ast.AST)
    assert type(a_s_t_1) == typed_ast.AST

# Generated at 2022-06-25 23:20:48.785970
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = get_parent(ast.AST(), ast.AST())
    replace_at(a_s_t_0, a_s_t_0, ast.AST())


# Generated at 2022-06-25 23:20:59.174136
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_12 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:21:04.844397
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.Expr()
    a_s_t_3 = module_0.Module()
    a_s_t_3.body = [a_s_t_2]
    assert (a_s_t_3, 0) == get_non_exp_parent_and_index(a_s_t_3, a_s_t_2)


# Generated at 2022-06-25 23:21:11.589057
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    class dummy():
        pass

    a = module_0.AST()
    b = module_0.AST()
    a_s_t_0 = dummy()
    a_s_t_1 = get_non_exp_parent_and_index(a, a_s_t_0)
    a_s_t_2 = get_parent(a, a_s_t_0)
    a_s_t_3 = get_non_exp_parent_and_index(b, a_s_t_0)
    a_s_t_4 = get_parent(b, a_s_t_0)
    a_s_t_5 = get_non_exp_parent_and_index(b, a_s_t_1)

# Generated at 2022-06-25 23:21:15.836680
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = {}
    node = {}
    type_ = {}
    # This will fail in Python 3.8 as None is not a valid type.
    # type: ignore
    result = get_closest_parent_of(tree, node, type_)
    assert result is None

# Generated at 2022-06-25 23:21:25.754112
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as ast

    test_mod = ast.parse('a = 1 + 2')
    test_stmt = test_mod.body[0]
    test_expr = test_stmt.value
    test_op = test_expr.op
    test_num1 = test_expr.left
    test_num2 = test_expr.right

    test_mod_parent_stmt = get_closest_parent_of(test_mod, test_mod, ast.AST)
    test_mod_parent_expr = get_closest_parent_of(test_mod, test_mod, ast.expr)
    test_mod_parent_num = get_closest_parent_of(test_mod, test_mod, ast.Num)
    test_mod_parent_op = get_clos

# Generated at 2022-06-25 23:21:26.269557
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert True

# Generated at 2022-06-25 23:21:30.333269
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test 0
    a_s_t_0 = ast.parse("")
    a_s_t_1 = a_s_t_0
    assert get_non_exp_parent_and_index(a_s_t_0, a_s_t_1) == (a_s_t_0, 0)


# Generated at 2022-06-25 23:21:49.408559
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.Str()
    a_s_t_0.s = "foo"
    a_s_t_1 = module_0.Assign()
    a_s_t_1.targets = [a_s_t_0]
    a_s_t_2 = module_0.Name()
    a_s_t_2.id = "x"
    a_s_t_3 = module_0.Assign()
    a_s_t_3.value = a_s_t_2
    a_s_t_4 = module_0.Name()
    a_s_t_4.id = "x"
    a_s_t_5 = module_0.Assign()

# Generated at 2022-06-25 23:21:52.837449
# Unit test for function replace_at
def test_replace_at():
  from typing import List

  class AST:
    def __init__(self) -> None:
      self.body = []

  class Expr:
    pass

  class Name:
    pass

  a_s_t_0 = AST()
  a_s_t_1 = Expr()
  a_s_t_2 = Name()
  replace_at(0, a_s_t_0, a_s_t_2)

# Generated at 2022-06-25 23:21:56.073393
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:21:59.024348
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)

# Generated at 2022-06-25 23:22:02.166206
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.AST()
    (a_s_t_3, a_s_t_4) = get_non_exp_parent_and_index(a_s_t_2, a_s_t_2)


# Generated at 2022-06-25 23:22:11.642107
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from dataclasses import dataclass
    from typing import List, TypeVar, Generic
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound

    _parents = WeakKeyDictionary()  # type: WeakKeyDictionary[ast.AST, ast.AST]

    def _build_parents(tree: ast.AST) -> None:
        for node in ast.walk(tree):
            for child in ast.iter_child_nodes(node):
                _parents[child] = node

    def get_parent(tree: ast.AST, node: ast.AST, rebuild: bool = False) -> ast.AST:
        """Get parrent of node in tree."""
        if node not in _parents or rebuild:
            _build_parents(tree)


# Generated at 2022-06-25 23:22:23.596836
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    print("In function: test_get_closest_parent_of")
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)


if __name__ == '__main__':
    try:
        test_case_0()
        test_get_closest_parent_of()
    except Exception as e:
        print('Caught exception: ' + repr(e))

# Generated at 2022-06-25 23:22:33.285715
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.parse('a = 1')
    a_s_t_0 = module_0.body[0]
    module_1 = ast.parse('a = 1')
    a_s_t_1 = module_1.body[0]
    module_2 = ast.parse('a = 1')
    a_s_t_2 = module_2.body[0]
    module_3 = ast.parse('a = 1')
    a_s_t_3 = module_3.body[0]
    module_4 = ast.parse('a = 1')
    a_s_t_4 = module_4.body[0]
    module_5 = ast.parse('a = 1')
    a_s_t_5 = module_5.body[0]

# Generated at 2022-06-25 23:22:36.326471
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import _ast
    a = _ast.Module()
    b = _ast.parse("1+1")
    i = get_non_exp_parent_and_index(a, b)
    assert not i

# Generated at 2022-06-25 23:22:38.051237
# Unit test for function get_parent
def test_get_parent():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:23:02.533321
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.AST()]
    replace_at(0, a_s_t_0, a_s_t_0)
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:23:09.780927
# Unit test for function get_parent
def test_get_parent():
    from silme.core.entity import Entity, EntityContainer
    from silme.core.package import Package
    from silme.core.structures import EntityList, Structure

    class SomeEntityContainer(EntityContainer):
        def add_entity(self, entity):
            entity.set_parent(self)

    class SomeStructure(Structure):
        pass

    p = Package('test')
    l10n = SomeStructure('test-l10n')
    l10n.set_parent(p)
    e = Entity('test.test', u'hello world', l10n)
    assert get_parent(p, e) == l10n

# Generated at 2022-06-25 23:23:11.289813
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False, 'Unimplemented'

import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2


# Generated at 2022-06-25 23:23:12.555600
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(None, None) == (None, None)


# Generated at 2022-06-25 23:23:14.256158
# Unit test for function get_parent
def test_get_parent():
    a_s_t_2 = module_0.AST()
    assert get_parent(a_s_t_2, a_s_t_2) is None


# Generated at 2022-06-25 23:23:21.600783
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.Module()
    a_s_t_1 = module_0.Load()
    a_s_t_2 = module_0.Load()
    a_s_t_1.context = a_s_t_2
    a_s_t_3 = module_0.Index()
    a_s_t_4 = module_0.Load()
    a_s_t_5 = module_0.Load()
    a_s_t_4.context = a_s_t_5
    a_s_t_0.body.append(a_s_t_1)
    a_s_t_1.value = a_s_t_3
    a_s_t_3.value = a_s_t_4
    r_0,

# Generated at 2022-06-25 23:23:30.750341
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    class MyAST(ast.AST):
        _fields = ('a',)

    node = MyAST(ast.Constant(3))

    # Not in tree
    assert get_non_exp_parent_and_index(node, node) == (node, 0)

    # In FunctionDef
    def test():
        node
    assert get_non_exp_parent_and_index(test.__code__, node) == (node, 0)

    node = MyAST(ast.Constant(3))
    node2 = MyAST(ast.Constant(3))
    node3 = MyAST(ast.Constant(3))

    def test():
        node
        node3
        node2

    parent, index = get_non_exp_parent_and_index(test.__code__, node3)
    assert parent.__

# Generated at 2022-06-25 23:23:33.251032
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1, int_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:23:41.979217
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class PEP8Node(ast.AST):
        _fields = ("id", "name")
        width = 0
        _attributes = ("id", "name")
        __annotations__ = {}

        def __eq__(self, other):
            if not isinstance(other, PEP8Node):
                return NotImplemented
            return super().__eq__(other)

        def __repr__(self):
            return "<PEP8Node id='%s' name='%s'>" % (self.id, self.name)

    class PEP8NodeWithChild(PEP8Node):
        _fields = ("id", "name", "child")
        width = 0
        _attributes = ("id", "name", "child")
        __annotations__ = {}


# Generated at 2022-06-25 23:23:44.501976
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
