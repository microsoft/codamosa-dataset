

# Generated at 2022-06-25 23:14:33.498659
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    assert a_s_t_1 is a_s_t_0

    a_s_t_2 = module_0.Str()
    a_s_t_3 = get_parent(a_s_t_2, a_s_t_2)
    assert a_s_t_3 is a_s_t_2


# Generated at 2022-06-25 23:14:35.994038
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """
    This case is automatically generated
    """

    # Call the function
    a_s_t_0 = get_closest_parent_of(None, None, type(None))



# Generated at 2022-06-25 23:14:39.385640
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Assign()
    a_s_t_2 = replace_at(0, a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:14:44.434982
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test for simple test case
    s_t_0 = get_non_exp_parent_and_index(1, 1)
    # Test for empty test case
    s_t_1 = get_non_exp_parent_and_index(1, '')
    # Test for type error test case
    s_t_2 = get_non_exp_parent_and_index(1, 1)


# Generated at 2022-06-25 23:14:46.130966
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass
    # assert_equal(a, b, msg=None)
    # self.assertEqual(a, b, msg=None)


# Generated at 2022-06-25 23:14:48.425503
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    t = Type
    print(test_find)
    assert isinstance(find(a_s_t_0, t), Iterable)


# Generated at 2022-06-25 23:14:55.658782
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Make sure the tree is safe to traverse
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(module_0.AST(), a_s_t_0)
    a_s_t_2 = a_s_t_1[0]
    a_s_t_3 = a_s_t_1[1]
    a_s_t_4 = a_s_t_2.body[a_s_t_3]


# Generated at 2022-06-25 23:14:57.917751
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = find(a_s_t_2, type(None))


# Generated at 2022-06-25 23:15:04.465244
# Unit test for function find
def test_find():
    a_s_t_2 = ast.AST()
    a_s_t_3 = ast.Str('str')
    a_s_t_4 = ast.Bytes('bytes')
    a_s_t_5 = ast.Num()
    a_s_t_6 = ast.Name()
    a_s_t_7 = ast.List(elts=[a_s_t_3, a_s_t_4], ctx=1)
    a_s_t_2.body = [a_s_t_3, a_s_t_4, a_s_t_5, a_s_t_6, a_s_t_7]
    a_s_t_8 = find(a_s_t_2, ast.AST)

# Generated at 2022-06-25 23:15:06.598107
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:15:20.368068
# Unit test for function replace_at
def test_replace_at():
    module_0.Assign()
    # Unit test for function insert_at
    def test_insert_at():
        module_0.Assign()
        # Unit test for function get_closest_parent_of
        def test_get_closest_parent_of():
            module_0.Assign()

    # Unit test for function get_non_exp_parent_and_index
    def test_get_non_exp_parent_and_index():
        module_0.Assign()

    # Unit test for function get_parent
    def test_get_parent():
        module_0.Assign()

    # Unit test for function find
    def test_find():
        module_0.Assign()

    # Unit test for function _build_parents
    def test__build_parents():
        module_0.Ass

# Generated at 2022-06-25 23:15:22.321707
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = get_non_exp_parent_and_index(module_0.AST(), module_0.AST())


# Generated at 2022-06-25 23:15:28.732571
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Reset global variable(s)
    global parents
    parents = WeakKeyDictionary();

    module_0 = ast.parse("[1, 2, 3, '4']")
    a_s_t_0 = module_0.body[0].value
    a_s_t_1 = module_0.body[0].value.elts[0]
    a_s_t_2 = get_closest_parent_of(module_0, a_s_t_1, ast.AST)
    assert(a_s_t_2 == a_s_t_0)

# Generated at 2022-06-25 23:15:32.588767
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound

    # Test case 1
    d_o_m_0 = ast.Module([], [])
    d_o_m_1 = get_non_exp_parent_and_index(d_o_m_0, d_o_m_0)


# Generated at 2022-06-25 23:15:33.459577
# Unit test for function insert_at
def test_insert_at():
    return None


# Generated at 2022-06-25 23:15:36.798311
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_2)


# Generated at 2022-06-25 23:15:38.857217
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    raise Exception(
        "Function get_non_exp_parent_and_index not realized"
    )


# Generated at 2022-06-25 23:15:48.161139
# Unit test for function find
def test_find():
    assert find((), list) == list()
    assert find(('s',), list) == list()
    assert find((1,), tuple) == list()
    assert find((), int) == list()
    assert find(1j, int) == list()
    assert find((), float) == list()
    assert find(1j, float) == list()
    assert find((), complex) == list()
    assert find(1j, complex) == list()
    assert find((), bool) == list()
    assert find(False, bool) == list()
    assert find((), type(None)) == list()
    assert find(None, type(None)) == list()
    assert find((), str) == list()
    assert find("", str) == list()

# Generated at 2022-06-25 23:15:55.608892
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert a_s_t_1 is a_s_t_0


# Generated at 2022-06-25 23:16:00.398554
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = typed_ast.ast3.Module()
    typed_ast.ast3.Module()
    typed_ast.ast3.Module()
    typed_ast.ast3.Module()
    module_0 = get_closest_parent_of(module_0, module_0, typed_ast.ast3.Module)


# Generated at 2022-06-25 23:16:14.258920
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    is_parent_found = False
    a_s_t_3 = ast.Expr(value=0)
    a_s_t_4 = ast.Load()
    a_s_t_5 = ast.Name(id='N', ctx=a_s_t_4)
    a_s_t_6 = ast.Name(id='a', ctx=a_s_t_4)
    a_s_t_7 = ast.Assign(targets=[a_s_t_5], value=a_s_t_6)
    a_s_t_2 = ast.Module(body=[a_s_t_3, a_s_t_7])

# Generated at 2022-06-25 23:16:22.078393
# Unit test for function replace_at
def test_replace_at():
    import ast
    import sys
    a_s_t_0 = ast.parse('if True:')
    def test_case_0():
        # assume t is a instance of ast.If
        t = a_s_t_0.body[0]
        assert (replace_at(0, t, []) is None)
        assert (t.body == [])
    def test_case_1():
        # assume t is a instance of ast.If
        t = a_s_t_0.body[0]
        assert (replace_at(0, t, []) is None)
        assert (t.body == [])
    def test_case_2():
        # assume t is a instance of ast.If
        t = a_s_t_0.body[0]

# Generated at 2022-06-25 23:16:23.967735
# Unit test for function get_parent
def test_get_parent():
    assert True, 'Expected True'  # Just to verify if the test case is running


# Generated at 2022-06-25 23:16:29.424181
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.Str('asdf')
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    a_s_t_2 = a_s_t_1[0]
    a_s_t_3 = a_s_t_1[1]


# Generated at 2022-06-25 23:16:38.280645
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(ast.parse('''if True:\n    pass'''), ast.parse('''\n    pass''').body[0]) == (ast.parse('''if True:\n    pass''').body[0], 0)
    assert get_non_exp_parent_and_index(ast.parse('''class Test:\n    pass'''), ast.parse('''\n    pass''').body[0]) == (ast.parse('''class Test:\n    pass''').body[0], 0)


# Generated at 2022-06-25 23:16:48.651828
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:16:57.468289
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-25 23:16:58.317595
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False, "Test not implemented"


# Generated at 2022-06-25 23:17:02.205688
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = find(a_s_t_0, type(a_s_t_0))
    a_s_t_2 = a_s_t_1



# Generated at 2022-06-25 23:17:04.989644
# Unit test for function replace_at
def test_replace_at():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    replace_at(0, a_s_t_2, a_s_t_3)


# Generated at 2022-06-25 23:17:22.283910
# Unit test for function find
def test_find():
    f = lambda x: x
    t = ast.parse(f.__code__.co_lnotab)
    assert len(list(find(t, ast.Num))) == 0
    assert len(list(find(t, ast.Str))) == 0
    assert len(list(find(t, ast.Name))) == 0
    assert len(list(find(t, ast.Store))) == 0
    assert len(list(find(t, ast.Load))) == 0
    assert len(list(find(t, ast.Module))) == 1
    assert len(list(find(t, ast.FunctionDef))) == 0
    assert len(list(find(t, ast.AsyncFunctionDef))) == 0
    assert len(list(find(t, ast.ClassDef))) == 0
    assert len(list(find(t, ast.Return)))

# Generated at 2022-06-25 23:17:22.746852
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False



# Generated at 2022-06-25 23:17:25.233897
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:17:35.289154
# Unit test for function find
def test_find():
    import ast
    tree = ast.parse(
        '''class A(B, C, D):
        def f(self):
            x = 2
            y = 3
'''.lstrip('\n'))
    module_ast = tree.body[0]
    classes = find(tree, ast.ClassDef)

    assert list(classes) == [module_ast]

    a = list(find(tree, ast.Name))


# Generated at 2022-06-25 23:17:36.628955
# Unit test for function find
def test_find():
    # TODO: Auto-generated.
    pass


# Generated at 2022-06-25 23:17:39.746291
# Unit test for function find
def test_find():
    a_s_t_149 = module_0.AST()
    a_s_t_150 = ast.parse('pass')
    find(a_s_t_149, type_=type(a_s_t_150))


# Generated at 2022-06-25 23:17:49.216986
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_1.body = [a_s_t_3, a_s_t_4, a_s_t_5]  # type: ignore
    a_s_t_0.body = [a_s_t_1, a_s_t_2]  # type: ignore
    a_s_t_6 = find(a_s_t_0, module_0.AST)
   

# Generated at 2022-06-25 23:17:58.038927
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_0.type_ignores = [None] * 1000
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    in_module_0_set_0 = set(a_s_t_0.type_ignores)
    in_module_0_len_0 = len(in_module_0_set_0)
    a_s_t_0 = module_0.AST()
    in_module_0_set_0 = set(a_s_t_0.type_ignores)
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 23:18:04.744583
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    assert a_s_t_1 is a_s_t_0

import typed_ast.ast3 as module_1


# Generated at 2022-06-25 23:18:10.476613
# Unit test for function get_parent
def test_get_parent():
    """Pass a simple AST."""
    from typing import Any

    a_s_t_0 = ast.parse("")

    try:
        get_parent(a_s_t_0, a_s_t_0)
    except NodeNotFound:
        pass
    except Exception as e:
        assert False, "Incorrect error thrown: " + str(e)
    else:
        assert True, "Exception was not thrown"



# Generated at 2022-06-25 23:18:18.503414
# Unit test for function find
def test_find():
    assert len(list(find(module_0.AST(), module_0.AST))) == 0


# Generated at 2022-06-25 23:18:28.927407
# Unit test for function get_parent
def test_get_parent():
    # Test case with and without rebuild
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_2 = get_parent(a_s_t_0, a_s_t_0)

    # Test case with and without rebuild
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_2 = get_parent(a_s_t_0, a_s_t_0, True)


# Generated at 2022-06-25 23:18:38.713947
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    import typed_ast._ast3 as module_1
    import typed_ast._ast3 as module_2
    import typed_ast._ast3 as module_3
    import typed_ast._ast3 as module_4
    import typed_ast._ast3 as module_5
    import typed_ast._ast3 as module_6
    import typed_ast._ast3 as module_7

    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_1.With()
    a_s_t_2 = module_2.ImportFrom()
    a_s_t_3 = module_3.Expr()
    a_s_t_4 = module_4.Load()

# Generated at 2022-06-25 23:18:42.370334
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert(get_parent(a_s_t_0, a_s_t_1[0]) == a_s_t_0)


# Generated at 2022-06-25 23:18:48.434319
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast

    body = ast.parse("""
        for i in range(10):
            for j in range(10):
                pass
    """).body[0]

    # noqa: E501
    parent, index = (get_non_exp_parent_and_index(body, body.body[0].body[0]))

    assert isinstance(parent, ast.For)
    assert index == 0


# Generated at 2022-06-25 23:18:51.146329
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:54.419246
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:19:01.279278
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.Module()
    a_s_t_3 = module_0.Expr()
    a_s_t_2.body.append(a_s_t_3)
    a_s_t_4 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_3)
    assert a_s_t_4[0] == a_s_t_2
    assert a_s_t_4[1] == 0


# Generated at 2022-06-25 23:19:09.614198
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.Assign(targets=[], value=module_0.Name(id='test', ctx=module_0.Load()))
    a_s_t_1 = module_0.Name(id='test', ctx=module_0.Load())
    a_s_t_2 = module_0.For(target=a_s_t_1, iter=a_s_t_1, body=[a_s_t_0], orelse=[])
    a_s_t_3 = module_0.Module(body=[a_s_t_2])
    a_s_t_4 = module_0.Name(id='test', ctx=module_0.Load())

# Generated at 2022-06-25 23:19:12.819460
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = find(a_s_t_0, module_0.AST)
    assert(isinstance(a_s_t_1, list))


# Generated at 2022-06-25 23:19:32.330904
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:19:33.164107
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert(True)


# Generated at 2022-06-25 23:19:38.587315
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    try:
        a_s_t_0 = module_0.AST()
        a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    except NodeNotFound:
        pass

from . import test_utils as utils
utils.generate_ast_tests()

# Generated at 2022-06-25 23:19:44.063159
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    b_s_t_0 = module_0.body()

    _parents[a_s_t_0] = b_s_t_0
    parent, index = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert a_s_t_0 is parent
    assert index == 0


# Generated at 2022-06-25 23:19:52.217165
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    # a_s_t is of type AST
    a_s_t = None

    # a_s_t_0 is of type AST
    a_s_t_0 = None

    # a_s_t_1 is of type AST
    a_s_t_1 = None

    # a_s_t_2 is of type AST
    a_s_t_2 = None

    # a_s_t_3 is of type AST
    a_s_t_3 = None

    # a_s_t_4 is of type AST
    a_s_t_4 = None

    # a_s_t_5 is of type AST
    a_s_t_5 = None

    # a_s_t_6 is of type AST
    a_s_t_6 = None

    # a

# Generated at 2022-06-25 23:20:03.107924
# Unit test for function replace_at
def test_replace_at():
    # Prepare test data
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
   

# Generated at 2022-06-25 23:20:10.251570
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.Module()
    a_s_t_3 = module_0.FunctionDef()
    a_s_t_2.body.append(a_s_t_3)
    a_s_t_3.body.append(module_0.Pass())
    a_s_t_4, a_s_t_5 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_3.body[0])
    assert a_s_t_4 == a_s_t_3
    assert a_s_t_5 == 0


# Generated at 2022-06-25 23:20:12.393913
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:20:27.495544
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_12 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:20:38.345685
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from .fixtures import tree_0, tree_1
    from .utils import equal_trees

    assert list(find(tree_0, type(ast.Str))) == [
        ast.Str(s='foo', lineno=-1, col_offset=-1),
        ast.Str(s='bar', lineno=-1, col_offset=-1),
    ]

    assert list(find(tree_1, type(ast.Str))) == [
        ast.Str(s='foo', lineno=-1, col_offset=-1),
        ast.Str(s='bar', lineno=-1, col_offset=-1),
    ]


# Generated at 2022-06-25 23:20:58.704497
# Unit test for function find
def test_find():
    test_case_0()

# Generated at 2022-06-25 23:21:07.151097
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as module_0
    a_s_t_0 = module_0.Expr(value=None)
    a_s_t_1 = module_0.Num(n=1)
    a_s_t_0.value = a_s_t_1
    a_s_t_2 = module_0.Module()
    a_s_t_2.body.append(a_s_t_0)
    a_s_t_3 = module_0.Module()
    [_, __] = get_non_exp_parent_and_index(a_s_t_2, a_s_t_0)


# Generated at 2022-06-25 23:21:09.464945
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    assert get_parent(a_s_t_0, a_s_t_0) is not None

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:21:14.097469
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from itertools import product

    from . import make_module

    from .. import patches

    # Test cases

# Generated at 2022-06-25 23:21:15.532783
# Unit test for function replace_at
def test_replace_at():
    pass


# Generated at 2022-06-25 23:21:25.157971
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = typed_ast.ast3.Expr(typed_ast.ast3.Num(1))
    a_s_t_1 = typed_ast.ast3.Expr(typed_ast.ast3.Num(2))
    a_s_t_2 = typed_ast.ast3.Module(body=[a_s_t_0, a_s_t_1])
    a_s_t_3 = typed_ast.ast3.BinOp(left=typed_ast.ast3.Name(id='a'), op=typed_ast.ast3.Add(), right=typed_ast.ast3.Name(id='b'))
    a_s_t_4 = typed_ast.ast3.Name(id='b')

# Generated at 2022-06-25 23:21:27.540934
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    try:
        test_case_0()
        assert True
    except NodeNotFound:
        assert False

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:21:33.039484
# Unit test for function get_parent
def test_get_parent():
    """Function 'get_parent' should return a ast.AST for each following inputs
    =======================================================================
    Input: <class 'typed_ast._ast3.AST'>
    Expected output: <class 'typed_ast._ast3.AST'>
    =======================================================================
    """
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:21:34.165812
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    parent=get_closest_parent_of(None, None, None)
    assert parent==None

# Generated at 2022-06-25 23:21:44.847612
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Module():
        class FunctionDef():
            class AsyncFunctionDef():
                pass
            class Arguments():
                pass
            class Expr():
                pass
            pass
        pass
    a_s_t_0 = Module()
    a_s_t_0.body = [Module.FunctionDef(), Module.FunctionDef()]
    a_s_t_0.body[0].body = [Module.FunctionDef.Arguments()]
    a_s_t_0.body[1].body = [Module.FunctionDef.Expr()]
    a_s_t_0.body[1].body.append(Module.FunctionDef.AsyncFunctionDef())

    output_0 = a_s_t_0

# Generated at 2022-06-25 23:22:09.408756
# Unit test for function find
def test_find():
    # TODO: Implement find test
    pass


# Generated at 2022-06-25 23:22:19.281993
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)

import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2
import typed_ast._ast3 as module_3
import typed_ast.ast3 as module_4
import typed_ast.ast3 as module_5


# Generated at 2022-06-25 23:22:23.634091
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, Type_0)
    __expected_list_0 = list()
    __expected_list_0.append(a_s_t_0)
    assert list_0 == __expected_list_0


# Generated at 2022-06-25 23:22:33.301878
# Unit test for function get_parent
def test_get_parent():
    try:
        get_parent(None, None)
        assert False
    except NodeNotFound:
        pass
    try:
        get_parent(None, None)
        assert False
    except NodeNotFound:
        pass
    try:
        get_parent(None, None)
        assert False
    except NodeNotFound:
        pass
    try:
        get_parent(None, None)
        assert False
    except NodeNotFound:
        pass
    try:
        get_parent(None, None)
        assert False
    except NodeNotFound:
        pass
    try:
        get_parent(None, None)
        assert False
    except NodeNotFound:
        pass
    try:
        get_parent(None, None)
        assert False
    except NodeNotFound:
        pass

# Generated at 2022-06-25 23:22:37.253726
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1, _int_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:22:38.847298
# Unit test for function get_parent
def test_get_parent():
    # Case 0
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:22:45.670357
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    # Case 0
    module_0 = None

    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)

    # Case 1
    module_0 = None

    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, None)
    
    # Case 2
    module_0 = None

    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 23:22:55.995123
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast27 as module_0
    import typed_ast._ast27 as module_1
    import typed_ast._ast27 as module_2

    # Case 1
    a_s_t_0 = module_0.Num(n=0)
    a_s_t_1 = module_1.AST()
    a_s_t_2 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_0)

    # Case 2
    a_s_t_3 = module_2.Num(n=0)
    a_s_t_4 = module_1.AST()
    a_s_t_5 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_3)

    #

# Generated at 2022-06-25 23:23:00.377417
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:23:03.199248
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.alias(
        name='str',
        asname=None
    )
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:24:11.377251
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = find(a_s_t_0, ast.AST)
    a_s_t_2 = find(a_s_t_0, ast.AST)


# Generated at 2022-06-25 23:24:15.961074
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert isinstance(a_s_t_1, module_0.AST)
    assert a_s_t_1 == a_s_t_0


# Generated at 2022-06-25 23:24:17.858375
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_list_0 = list(find(a_s_t_0, module_0.AST))
    assert True


# Generated at 2022-06-25 23:24:20.215796
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:24:27.018790
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.Name()
    _build_parents(a_s_t_2)
    a_s_t_4 = a_s_t_3
    a_s_t_4 = module_0.ClassDef()
    _build_parents(a_s_t_2)
    a_s_t_5 = module_0.Name()
    a_s_t_6 = module_0.FunctionDef()
    a_s_t_7 = module_0.Name()
    a_s_t_7.col_offset = 0
    a_s_t_7.lineno = 0
    a_s_t_7.ctx = module_0.Load()
    a_s_t_