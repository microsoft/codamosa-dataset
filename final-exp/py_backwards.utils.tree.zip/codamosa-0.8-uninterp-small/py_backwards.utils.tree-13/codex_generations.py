

# Generated at 2022-06-25 23:14:30.998339
# Unit test for function find
def test_find():
    # No body
    a_s_t_0 = ast.Module()
    a_s_t_1 = find(a_s_t_0, type(ast.Module()))


# Generated at 2022-06-25 23:14:33.443008
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    test_0 = find(a_s_t_0, type_=Module)


# Generated at 2022-06-25 23:14:39.338769
# Unit test for function find
def test_find():
    # Call function with empty tree
    a_s_t_0 = module_0.AST()
    for _ in find(a_s_t_0, Type):
        pass

    # Call function with non-empty tree
    a_s_t_0 = module_0.AST()
    for _ in find(a_s_t_0, Type):
        pass


# Generated at 2022-06-25 23:14:40.304932
# Unit test for function find
def test_find():
    assert True


# Generated at 2022-06-25 23:14:42.467482
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:14:45.230064
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_1 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_1)


# Generated at 2022-06-25 23:14:49.281225
# Unit test for function find
def test_find():
    # AssertionError: Expected iterable, got None
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert_equals(find(tuple_0, module_0.AST), iterable())

if __name__ == '__main__':
    test_find()

# Generated at 2022-06-25 23:14:54.030517
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    list_0 = [a_s_t_0]
    int_0 = find(a_s_t_1, list)
    type_0 = type(a_s_t_0)


# Generated at 2022-06-25 23:14:58.199148
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    assert get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.AST) == a_s_t_1


# Generated at 2022-06-25 23:15:04.633006
# Unit test for function get_parent
def test_get_parent():
    # Populates _parents
    a_s_t_0 = module_0.AST()
    get_parent(a_s_t_0, a_s_t_0)

    # ValueError: get_parent(): incompatible function arguments. The following argument types are supported:
    #     1. (_typed_ast.ast3.AST,)
    #     2. (_typed_ast.ast3.AST, bool)
    # get_parent(a_s_t_0, a_s_t_0, str_0)

    # ValueError: get_parent(): incompatible function arguments. The following argument types are supported:
    #     1. (_typed_ast.ast3.AST,)
    #     2. (_typed_ast.ast3.AST, bool)
    # get_parent(a_s_t_0

# Generated at 2022-06-25 23:15:11.316820
# Unit test for function find
def test_find():
    module_1 = module_0
    a_s_t_1 = module_1.AST()
    tuple_1 = find(a_s_t_1, module_1.AST)

# Generated at 2022-06-25 23:15:17.088675
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    print('Testing get_closest_parent_of()... ', end='')

    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    assert get_closest_parent_of(a_s_t_0, a_s_t_0, type_=type(a_s_t_0)) is a_s_t_0

    print('Passed.')



# Generated at 2022-06-25 23:15:17.993886
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:15:21.091574
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    _build_parents(a_s_t_0)
    assert _parents[a_s_t_0] == a_s_t_0


# Generated at 2022-06-25 23:15:25.209002
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    test_case_0()
    assert get_closest_parent_of(a_s_t_0, a_s_t_0, type) == None, 'Should be False'

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:15:30.253692
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    filename = 'python/typed_ast/tests/input_data/simple_file.py'
    ast_tree = ast.parse(open(filename).read())

    closest_parent = get_closest_parent_of(ast_tree, ast_tree.body[1].body[0].body[0], ast.FunctionDef)
    assert closest_parent == ast_tree.body[1]

# Unit testing for function get_non_exp_parent_and_index

# Generated at 2022-06-25 23:15:39.817867
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # setup
    module_0 = importlib.import_module('typed_ast._ast3')
    
    
    
    
    
    
    
    
    
    
    
    
    # unit test
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    
    # assertion
    assert_1 = typed_astunparse.unparse(tuple_0[0])
    assert_2 = "AST()"
    assert assert_1 == assert_2
    assert_3 = tuple_0[1]
    assert assert_3 == 0
    
    # unit test
    int_0 = 1

# Generated at 2022-06-25 23:15:47.362427
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    parent_a_s_t_2 = get_closest_parent_of(a_s_t_1, a_s_t_1, ast.AST)
    parent_a_s_t_2 = get_closest_parent_of(a_s_t_1, a_s_t_1, ast.Expression)
    parent_a_s_t_3 = get_closest_parent_of(a_s_t_1, a_s_t_1, ast.Expression)


# Generated at 2022-06-25 23:16:01.998071
# Unit test for function find
def test_find():
    class A_s_t_0(object):
        def __init__(self, value, body):
            self.value = value
            self.body = body
    class A_s_t_1(object):
        def __init__(self, value, body):
            self.value = value
            self.body = body
    class A_s_t_2(object):
        def __init__(self, value, body):
            self.value = value
            self.body = body
    class A_s_t_3(object):
        def __init__(self, value, body):
            self.value = value
            self.body = body

# Generated at 2022-06-25 23:16:07.389296
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module = typed_ast.ast3.parse("""
    def foo():
        pass
    """)

    func_def = module.body[0]
    parent_func_def = get_closest_parent_of(module, func_def, ast.Module)

    assert parent_func_def == module

# Generated at 2022-06-25 23:16:15.765480
# Unit test for function replace_at
def test_replace_at():
    pass

# Generated at 2022-06-25 23:16:19.028986
# Unit test for function get_parent
def test_get_parent():
    test_case_0()


# Generated at 2022-06-25 23:16:28.423776
# Unit test for function get_parent
def test_get_parent():
    # Test case when checking if node is a child of a tree
    # Expected Result: NodeNotFound
    try:
        a_s_t_0 = module_0.AST()
        get_parent(a_s_t_0, a_s_t_0)
    except NodeNotFound:
        pass

    # Test case when checking if node is a child of a tree
    # Expected Result: NodeNotFound
    try:
        a_s_t_0 = module_0.AST()
        get_parent(a_s_t_0, a_s_t_0)
    except NodeNotFound:
        pass

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:16:30.663798
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Multiple cases can be passed for get_non_exp_parent_and_index
    # See line above for examples
    pass

# Generated at 2022-06-25 23:16:37.508426
# Unit test for function find
def test_find():
    assert [and_test.body, or_test.body, not_test] == find(root, ast.Compare)
    assert [is_not_test] == find(root, ast.UnaryOp)
    assert [x.value] == find(root, ast.Name)
    assert [2] == find(root, ast.Num)
    assert [] == find(root, ast.Subscript)


# Generated at 2022-06-25 23:16:45.952660
# Unit test for function find
def test_find():
    t1 = module_0.Expr()
    t2 = module_0.Expr()
    t3 = module_0.Assign()
    a_s_t_0 = module_0.Module(body=[t1, t2, t3])
    s_t_0 = list(find(a_s_t_0, type(t3)))
    s_t_1 = list(find(a_s_t_0, type(t1)))
    s_t_2 = list(find(a_s_t_0, type(t2)))


# Generated at 2022-06-25 23:16:54.654020
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    T_0 = test_case_0()
    T_1 = get_closest_parent_of(a_s_t_0, a_s_t_1, T_0)
    T_2 = find(a_s_t_0, T_1)
    T_3 = find(a_s_t_1, T_0)
    T_4 = find(a_s_t_2, T_2)
    T_5 = find(a_s_t_3, T_3)

# Generated at 2022-06-25 23:17:03.892666
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    import typed_ast._ast3 as module_1
    # Call function get_closest_parent_of with arguments
    # (a_s_t_0, a_s_t_0, module_1.AST)
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    assert a_s_t_1 == get_closest_parent_of(a_s_t_0, a_s_t_1, module_1.AST)

if __name__ == '__main__':
    import _ast
    import typed_ast
    import sys
    import astor
    # Unit tests
    import _ast
    import typed_ast
    import sys
    import astor

# Generated at 2022-06-25 23:17:05.284239
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # The following line raises an exception
    try:
        test_case_0()
    except NodeNotFound:
        assert True

import typed_ast._ast3 as module_0
import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:17:07.684493
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, ast.AST)

    assert(iterable_0 is not None)



# Generated at 2022-06-25 23:17:17.112824
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # assert False # TODO: implement your test here
    
    assert True # TODO: implement your test here


# Generated at 2022-06-25 23:17:22.669153
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Load AST module
    import typed_ast._ast3 as module_0

    # Create AST object
    a_s_t_0 = module_0.AST()

    # Call function
    try:
        tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    except NodeNotFound:
        pass



# Generated at 2022-06-25 23:17:29.491815
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST(names=[module_0.Name(id='a', ctx=module_0.Load())])
    a_s_t_2 = module_0.AST(names=[module_0.Name(id='a', ctx=module_0.Load()), module_0.Name(id='b', ctx=module_0.Load())])
    a_s_t_3 = module_0.AST(names=[module_0.Name(id='a', ctx=module_0.Load()), module_0.Name(id='b', ctx=module_0.Load()), module_0.Name(id='c', ctx=module_0.Load())])

# Generated at 2022-06-25 23:17:31.714487
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    find(a_s_t_0, type(a_s_t_0))

# Generated at 2022-06-25 23:17:32.574392
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()


# Generated at 2022-06-25 23:17:40.439079
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, module_0.AST)
    iterable_1 = find(a_s_t_0, ast.AST)
    iterable_2 = find(a_s_t_0, ast.Module)
    iterable_3 = find(a_s_t_0, ast.AST)
    iterable_4 = find(a_s_t_0, ast.AST)


# Generated at 2022-06-25 23:17:43.524936
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    node_type_0 = ast.Module
    a_s_t_1 = find(a_s_t_0, node_type_0)
    return


# Generated at 2022-06-25 23:17:46.365927
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    list_0 = [a_s_t_0]
    replace_at(0, a_s_t_0, list_0)


# Generated at 2022-06-25 23:17:47.760762
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # @TODO: Should not take too much time to run.
    pass


# Generated at 2022-06-25 23:17:52.778834
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    my_file = open("data_input_get_non_exp_parent_and_index.txt", "r")
    lines = my_file.readlines()
    n = int(lines[0])

    for i in range(n):
        a_s_t_0, node_1 = ast.parse(lines[i + 1]), ast.parse(lines[i + 2])
        tuple_0 = get_non_exp_parent_and_index(a_s_t_0, node_1)


# Generated at 2022-06-25 23:18:18.580031
# Unit test for function find
def test_find():
    e_m_p_t_y_list_0 = []
    e_m_p_t_y_list_1 = []
    for _ in find(get_non_exp_parent_and_index(3, 3), list):
        e_m_p_t_y_list_1.append(_)
    assert len(e_m_p_t_y_list_1) == len(e_m_p_t_y_list_0)
    for _ in find(get_parent(get_closest_parent_of(get_closest_parent_of(4, 4, list), get_closest_parent_of(4, 4, list), list), get_closest_parent_of(4, 4, list), list), bool):
        e_m_p_t_y

# Generated at 2022-06-25 23:18:19.905577
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    # Insert your own assertions here


# Generated at 2022-06-25 23:18:24.260060
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:30.159385
# Unit test for function get_parent
def test_get_parent():
    # Case 1
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    _build_parents(a_s_t_0)
    a_s_t_0.body = [a_s_t_1]
    a_s_t_2 = get_parent(a_s_t_0, a_s_t_1)
    assert hasattr(a_s_t_2, 'body')



# Generated at 2022-06-25 23:18:32.911136
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.BinOp()
    module_0.BinOp = find(a_s_t_0, module_0.BinOp)


# Generated at 2022-06-25 23:18:39.270369
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.Module()
    a_s_t_0.body.append(module_0.Expr())
    a_s_t_0.body.append(module_0.Expr())
    a_s_t_0.body.append(module_0.Expr())

    result = get_parent(a_s_t_0, a_s_t_0.body[0])
    assert result == a_s_t_0


# Generated at 2022-06-25 23:18:43.281267
# Unit test for function get_parent
def test_get_parent():
    a_s_t_1 = ast.AST()
    parent_0 = get_parent(a_s_t_1, a_s_t_1)

    # Verify that parent is a_s_t_1
    assert parent_0 == a_s_t_1


# Generated at 2022-06-25 23:18:46.572125
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:55.719159
# Unit test for function find
def test_find():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_12 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:18:58.396297
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # NodeNotFound exception is expected because parent is not found in
    # function get_parent
    try:
        test_case_0()
    except NodeNotFound as exc:
        assert type(exc) == NodeNotFound

# Generated at 2022-06-25 23:19:32.127764
# Unit test for function get_parent
def test_get_parent():
    import types
    import ast
    import typed_ast
    assert types.ModuleType('test-get-parent') == get_parent(ast.Module(body=[ast.Expr(value=ast.Name(id='test-get-parent', ctx=typed_ast.Store()))]), ast.Name(id='test-get-parent', ctx=typed_ast.Store()))


# Generated at 2022-06-25 23:19:36.583491
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.AST)

# Generated at 2022-06-25 23:19:42.793541
# Unit test for function find
def test_find():
    # type: () -> None
    import os.path
    import sys
    root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    sys.path.insert(0, root)
    from typed_ast.ast3 import Str, Expr
    a_s_t_0 = Expr(Str(s='foo'))
    expect_0 = list(find(a_s_t_0, type(Expr)))
    assert expect_0 == [a_s_t_0]

# Generated at 2022-06-25 23:19:51.361814
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class AST3(module_0.AST):
        def __init__(self, body=None):
            self.body = body
            pass

    class Attribute(module_0.Attribute):
        def __init__(self, body=None):
            self.body = body
            pass

    class Name(module_0.Name):
        def __init__(self, body=None):
            self.body = body
            pass

    a_s_t_2 = AST3()
    a_t_t_r_i_b_u_t_e_0 = Attribute()
    a_s_t_2.body = a_t_t_r_i_b_u_t_e_0
    n_a_m_e_0 = Name()
    a_t_t_r_i_b

# Generated at 2022-06-25 23:19:54.712161
# Unit test for function find
def test_find():
    with pytest.raises(NodeNotFound):
        a_s_t_0 = module_0.AST()
        tuple_0 = find(a_s_t_0, module_0.Tuple)


# Generated at 2022-06-25 23:19:56.871329
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = list(find(a_s_t_0, ast.AST))


# Generated at 2022-06-25 23:20:00.097670
# Unit test for function find
def test_find():
    a_s_t_0 = ast.AST()
    type_ = ast.AST
    module_0 = find(a_s_t_0, type_)


# Generated at 2022-06-25 23:20:09.581436
# Unit test for function find
def test_find():
    # Function case
    def func():
        return 10

    func_ast = ast.parse(inspect.getsource(func))
    func_def = next(find(func_ast, ast.FunctionDef))
    assert func_def.name == 'func'

    # Class case
    class Test():
        pass

    class_ast = ast.parse(inspect.getsource(Test))
    class_def = next(find(class_ast, ast.ClassDef))
    assert class_def.name == 'Test'

    # Lambda case
    lambda_ast = ast.parse('(lambda x: x + 1)(2)')
    lambda_def = next(find(lambda_ast, ast.Lambda))
    assert isinstance(lambda_def, ast.Lambda)

    # Import case
    import astunparse


# Generated at 2022-06-25 23:20:19.757096
# Unit test for function replace_at
def test_replace_at():
    predicate = (lambda a_s_t_0, a_s_t_1: isinstance(a_s_t_1, a_s_t_0), [module_0.AST])
    for a_s_t_0 in arguments_for(predicate):
        for a_s_t_1 in arguments_for(predicate):
            for a_s_t_2 in arguments_for(predicate):
                replace_at(a_s_t_0, a_s_t_1, a_s_t_2)



# Generated at 2022-06-25 23:20:23.984817
# Unit test for function replace_at
def test_replace_at():
    _index_0 = 10
    _parent_0 = module_0.NodeTransformer()
    _nodes_0 = module_0.NodeTransformer()
    _result_0 = replace_at(_index_0, _parent_0, _nodes_0)



# Generated at 2022-06-25 23:21:25.869953
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index"""
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    pass


# Generated at 2022-06-25 23:21:30.835375
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    i_t_0 = find(a_s_t_0, ast.AST)
    i_t_1 = find(a_s_t_0, ast.AST)
    i_t_2 = find(a_s_t_0, ast.AST)
    i_t_3 = find(a_s_t_0, ast.AST)


# Generated at 2022-06-25 23:21:33.984760
# Unit test for function find
def test_find():
    def case():
        a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 23:21:44.594138
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, Union[module_0.Module, module_0.Interactive, module_0.Expression, module_0.FunctionDef, module_0.ClassDef, module_0.Return, module_0.Delete, module_0.Assign, module_0.AugAssign, module_0.For, module_0.While, module_0.If, module_0.With, module_0.Raise, module_0.Try, module_0.Assert, module_0.Import, module_0.ImportFrom, module_0.Global, module_0.Nonlocal, module_0.Expr, module_0.Pass, module_0.Break, module_0.Continue])


# Generated at 2022-06-25 23:21:50.642151
# Unit test for function get_parent
def test_get_parent():
    results_0 = []
    results_1 = []
    a_s_t_0 = module_0.AST()
    result_0 = get_parent(a_s_t_0, a_s_t_0)
    results_0.append(result_0)
    a_s_t_1 = module_0.Add()
    result_1 = get_parent(a_s_t_1, a_s_t_1)
    results_1.append(result_1)
    assert(results_0 == [None])
    assert(results_1 == [None])


# Generated at 2022-06-25 23:21:59.225178
# Unit test for function replace_at
def test_replace_at():
    import typed_ast._ast3 as module_0
    import typed_ast.ast3 as module_1
    from typed_ast._ast3 import Str
    from typed_ast.ast3 import ClassDef
    from typed_ast._ast3 import AST
    from typed_ast.ast3 import AST
    from typed_ast._ast3 import Str
    from typed_ast.ast3 import ClassDef
    from typed_ast._ast3 import AST
    from typed_ast.ast3 import AST
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_

# Generated at 2022-06-25 23:22:08.902588
# Unit test for function find
def test_find():
    a_s_t_1 = module_0.AST()
    list_0 = find(a_s_t_1, Union[None])
    assert len(list_0) == 0
    a_s_t_2 = module_0.AST()
    list_1 = find(a_s_t_2, Union[None])
    assert len(list_1) == 0
    a_s_t_3 = module_0.AST()
    list_2 = find(a_s_t_3, Union[None])
    assert len(list_2) == 0
    a_s_t_4 = module_0.AST()
    list_3 = find(a_s_t_4, Union[None])
    assert len(list_3) == 0
    a_s_t_5 = module_

# Generated at 2022-06-25 23:22:11.842279
# Unit test for function get_parent
def test_get_parent():
    assert callable(get_parent)

    a_s_t_0 = module_0.AST()
    assert get_parent(a_s_t_0, a_s_t_0) == a_s_t_0
    pass  # TODO


# Generated at 2022-06-25 23:22:21.448929
# Unit test for function get_parent
def test_get_parent():
    print('start test get_parent')
    import typed_ast.ast3 as ast3
    tree = ast3.parse('x = 1')
    parent = get_parent(tree, tree.body[0].value)
    assert isinstance(parent, ast3.Assign)
    # Body of function test_case_0 is not reachable
    # print( 'end test get_parent' )


# Generated at 2022-06-25 23:22:23.749693
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, type)


# Generated at 2022-06-25 23:23:26.587195
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    result_0 = find(a_s_t_0, ast.AST)


# Generated at 2022-06-25 23:23:29.252385
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    with pytest.raises(NodeNotFound):
        test_case_0()

# Generated at 2022-06-25 23:23:32.036799
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    # TODO: add test case
    raise NotImplementedError()

if __name__ == '__main__':
    test_get_closest_parent_of()

# Generated at 2022-06-25 23:23:33.866682
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iter_0 = find(a_s_t_0, type(a_s_t_0))


# Generated at 2022-06-25 23:23:34.547031
# Unit test for function find
def test_find():
    assert True


# Generated at 2022-06-25 23:23:43.472832
# Unit test for function get_parent
def test_get_parent():
    # AST from typed_ast.tests.test_ast3.test_pickle

    # Set up program
    a_s_t_0 = module_0.AST()
    list_0 = module_0.List([], module_0.Load())
    a_s_t_1 = module_0.AST(body=[list_0])
    a_s_t_2 = module_0.AST()
    list_1 = module_0.List([], module_0.Load())
    a_s_t_3 = module_0.AST(body=[list_1])
    ast_4 = module_0.FunctionDef(name='f', args=a_s_t_2, body=a_s_t_3, decorator_list=list_0)

# Generated at 2022-06-25 23:23:50.732565
# Unit test for function find

# Generated at 2022-06-25 23:23:54.464853
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    generator_0 = find(a_s_t_0, module_0.AST)
    assert isinstance(generator_0, Iterable)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:23:55.770524
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    try:
        test_case_0()
    except NodeNotFound:
        assert False


# Generated at 2022-06-25 23:24:00.884307
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert a_s_t_0 == module_0.AST()
    assert tuple_0 == (a_s_t_0, 0)

import typed_ast._ast3 as module_1
