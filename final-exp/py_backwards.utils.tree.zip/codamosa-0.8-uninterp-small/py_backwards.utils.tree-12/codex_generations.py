

# Generated at 2022-06-25 23:14:36.890893
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body.append(a_s_t_1)
    assert get_parent(a_s_t_0, a_s_t_1, True) == a_s_t_0


# Generated at 2022-06-25 23:14:43.089449
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()

    # all nodes with type AST, including AST_0.
    empty_0 = find(a_s_t_0, module_0.AST)
    assert type(empty_0) == "<class 'typing.Generator'>"

    # none nodes with type Expr.
    empty_1 = find(a_s_t_0, module_0.Expr)
    assert type(empty_1) == "<class 'typing.Generator'>"


# Generated at 2022-06-25 23:14:46.410536
# Unit test for function find
def test_find():
    a_s_t_1 = module_0.AST()
    s_t_0 = find(a_s_t_1, module_0.AST)
    i_t_0 = find(a_s_t_1, int)


# Generated at 2022-06-25 23:14:51.854610
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0
    import typed_ast._ast3 as module_1
    import typed_ast._ast3 as module_2
    # Try to get parent node of an AST
    a_s_t_0 = module_0.AST()
    assert_equal(get_non_exp_parent_and_index(a_s_t_0, a_s_t_0), (a_s_t_0, 0))
    # Try to get parent node of a Module
    a_s_t_1 = module_0.Module()
    assert_equal(get_non_exp_parent_and_index(a_s_t_0, a_s_t_1), (a_s_t_0, 0))


# Generated at 2022-06-25 23:14:53.036634
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

# Generated at 2022-06-25 23:14:56.926374
# Unit test for function replace_at
def test_replace_at():
    # From test_case_0
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    replace_at(*tuple_0)


# Generated at 2022-06-25 23:14:59.064375
# Unit test for function find
def test_find():
    a_s_t_9 = module_0.AST()
    list_0 = find(a_s_t_9, module_0.AST)


# Generated at 2022-06-25 23:15:02.048212
# Unit test for function find
def test_find():
    """Test the functionality of find."""
    a_s_t_0 = ast.parse('0')
    a_s_t_1 = find(a_s_t_0, ast.Expr)

# Generated at 2022-06-25 23:15:08.731247
# Unit test for function find
def test_find():
    from .type_inference_programs.stmts import fun_with_all_stmts
    tree = ast.parse(fun_with_all_stmts)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.AugAssign))) == 1
    assert len(list(find(tree, ast.Call))) == 1
    assert len(list(find(tree, ast.Name))) == 1


# Generated at 2022-06-25 23:15:12.874076
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    print("Testing get_non_exp_parent_and_index")
    module_0 = ast.Module()
    tuple_0 = get_non_exp_parent_and_index(module_0, module_0)
    print("Test complete")

# Generated at 2022-06-25 23:15:17.468047
# Unit test for function get_parent
def test_get_parent():
    assert True


# Generated at 2022-06-25 23:15:22.440322
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = a_s_t_0
    node = a_s_t_0
    type_ = module_0.AST
    type_returned = get_closest_parent_of(tree, node, type_)

    if type_returned == module_0.AST:
        assert True
    else:
        assert False

import typed_ast.ast3 as module_1


# Generated at 2022-06-25 23:15:26.072896
# Unit test for function get_parent
def test_get_parent():
    # Input arguments for this test case
    ast_0 = module_0.AST()
    ast_1 = module_0.AST()
    rebuild = None

    # Explosion
    try:
        get_parent(ast_0, ast_1, rebuild)
    except NodeNotFound:
        pass


# Generated at 2022-06-25 23:15:33.140676
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Set up
    a_s_t_0 = module_0.AST()
    b_s_t_1 = module_0.Body()
    b_s_t_2 = module_0.Body()

    a_s_t_0.body = b_s_t_1
    a_s_t_0.body = b_s_t_2
    # Test action
    g_p_i_0 = get_non_exp_parent_and_index(a_s_t_0, b_s_t_1)
    # Test condition
    assert g_p_i_0 == (b_s_t_2, 1)



# Generated at 2022-06-25 23:15:39.680263
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    x = module_0.AST()
    y = module_0.AST()
    _builtins_0 = module_0.AST() # Comprehension
    x.body = [_builtins_0]
    y.body = [x,x]
    a_s_t_0.body = [y,y]
    
    find(a_s_t_0, module_0.AST)
    
    

# Generated at 2022-06-25 23:15:40.933854
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass  # TODO: implement your test here



# Generated at 2022-06-25 23:15:50.040516
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.Module()
    n1 = ast.ClassDef(name='A')
    tree.body.append(n1)
    n2 = ast.FunctionDef(name='f')
    n1.body.append(n2)
    n3 = ast.AnnAssign(target=ast.Name(id='a', ctx=ast.Store()))
    n2.body.append(n3)
    
    # The parent of n4 is the module
    n4 = ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())])
    tree.body.append(n4)
    
    parent = get_closest_parent_of(tree, node=n4, type_=ast.Module)
    assert parent == tree


# Generated at 2022-06-25 23:16:03.744694
# Unit test for function find
def test_find():
    # Test 1
    a_s_t_0 = ast.Module()
    a_s_t_1 = ast.Str('Hello, world!')
    a_s_t_0.body.append(a_s_t_1)
    a_s_t_2 = ast.Expr()
    a_s_t_2.value = a_s_t_1
    a_s_t_0.body.append(a_s_t_2)

    str_list = list(find(a_s_t_0, ast.Str))
    assert str_list == [a_s_t_1]

    expr_list = list(find(a_s_t_0, ast.Expr))
    assert expr_list == [a_s_t_2]


# Generated at 2022-06-25 23:16:04.911189
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:16:06.446864
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 23:16:18.715791
# Unit test for function insert_at
def test_insert_at():
    a_s_t_0 = module_0.AST()
    t_u_p_l_e_0 = ("tuple", )
    insert_at(0, a_s_t_0, t_u_p_l_e_0)


if __name__ == '__main__':
    import __main__
    class _:
        def __call__(self, *args, **kwargs):
            f = getattr(__main__, 'test_{}'.format(args[0]))
            f(*args[1:])
    _()

# Generated at 2022-06-25 23:16:29.479266
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Enum
    e1 = ast.ExceptHandler(name=None)
    e2 = ast.ExceptHandler(name=None)
    try_node = ast.Try(handlers=[e1, e2])
    assert get_non_exp_parent_and_index(try_node, e2) == (try_node, 1)

    # If
    if_node = ast.If(test=ast.Name(), body=[ast.Pass()])
    assert get_non_exp_parent_and_index(if_node, if_node.body[0]) == (if_node, 0)

    # While
    while_node = ast.While(test=ast.Name(), body=[ast.Pass()])

# Generated at 2022-06-25 23:16:35.983990
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as _ast3
    a_s_t_0 = _ast3.AST()
    # Call function get_non_exp_parent_and_index
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:16:41.431399
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    replace_at(0, a_s_t_0, [a_s_t_1])


# Generated at 2022-06-25 23:16:42.980907
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    test_case_0()

# Generated at 2022-06-25 23:16:52.761986
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0 = ast.parse("""# a comment""")
    module_1 = ast.parse("""a = 1""")
    module_2 = ast.parse("""if a:\n\tb = 2""")
    module_3 = ast.parse("""if a:\n\tb = 2\nelse:\n\tc = 3""")
    module_4 = ast.parse("""try:\n\ta = 1\nexcept Exception:\n\tb = 2""")

    # test simple statements
    assert (get_non_exp_parent_and_index(module_0, module_0.body[0])
            == (module_0, 0))
    assert (get_non_exp_parent_and_index(module_1, module_1.body[0])
            == (module_1, 0))
   

# Generated at 2022-06-25 23:17:01.986677
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    # assert get_closest_parent_of(a_s_t_1, a_s_t_1, module_0.AST)  # TODO: implement
    # assert get_closest_parent_of(a_s_t_2, a_s_t_2, module_0.AST)  # TODO: implement
    # assert get_closest_parent_of(a_s_t_3, a_s_t_3, module_0.AST)  # TODO: implement
    # assert get_closest_parent_of(a_s_t_4, a_

# Generated at 2022-06-25 23:17:03.852418
# Unit test for function find
def test_find():
    a_s_t_0 = ast.AST()
    i_t_e_r_0 = find(a_s_t_0, str)

# Generated at 2022-06-25 23:17:06.533249
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, module_0.AST)
    assert list_0 == [a_s_t_0]


# Generated at 2022-06-25 23:17:16.671423
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = ast.AST()
    a_s_t_1 = ast.Name()
    a_s_t_0.body = [a_s_t_1]
    assert get_parent(a_s_t_0, a_s_t_1) == a_s_t_0
    a_s_t_2 = ast.Str()
    a_s_t_3 = ast.Module()
    a_s_t_3.body = [a_s_t_2]
    a_s_t_4 = ast.Name()
    a_s_t_4 = ast.Name()
    a_s_t_4 = ast.Name()
    a_s_t_4 = ast.Name()
    a_s_t_4 = ast.Name()


# Generated at 2022-06-25 23:17:28.493306
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0.AST()
    module_0.Add()
    module_0.alias()
    module_0.arguments()
    module_0.Assert()
    module_0.Assign()
    module_0.Attribute()
    module_0.AugAssign()
    module_0.BinOp()
    module_0.BoolOp()
    module_0.Call()
    module_0.ClassDef()
    module_0.Compare()
    module_0.comprehension()
    module_0.Constant()
    module_0.Delete()
    module_0.Dict()
    module_0.DictComp()
    module_0.Ellipsis()
    module_0.Eq()
    module_0.ExceptHandler()
    module_0.Exec()
    module

# Generated at 2022-06-25 23:17:38.758245
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Create an instance of a class using the named argument
    a_s_t_0 = module_0.AST(type_ignores=[module_0.AST])
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    a_s_t_2 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    a_s_t_3 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    int_0 = a_s_t_1 == a_s_t_0
    int_1 = a_s_t_2

# Generated at 2022-06-25 23:17:41.821342
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)



# Generated at 2022-06-25 23:17:42.425750
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass



# Generated at 2022-06-25 23:17:51.137649
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    import typed_ast.ast3 as module_1

    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_1.AST()
    a_s_t_0.body.append(a_s_t_1)
    a_s_t_2 = module_1.AST()
    a_s_t_1.body.append(a_s_t_2)
    a_s_t_3 = module_1.AST()
    a_s_t_2.body.append(a_s_t_3)
    tuple_0 = get_closest_parent_of(a_s_t_0, a_s_t_3, module_1.AST)

# Generated at 2022-06-25 23:18:00.971456
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Assign()]
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0.body[0])
    try:
        tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0.body[0])
    except NodeNotFound as exception_0:
        parent = exception_0.args[0]


# Generated at 2022-06-25 23:18:08.537523
# Unit test for function find

# Generated at 2022-06-25 23:18:09.114698
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass



# Generated at 2022-06-25 23:18:11.784221
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_1 = module_0.AST()
    tuple_1 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_1)


# Generated at 2022-06-25 23:18:16.187890
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    function_0 = find(a_s_t_0, module_0.FunctionDef)


# Generated at 2022-06-25 23:18:27.669138
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [a_s_t_0, a_s_t_0]

    parent_0 = get_parent(a_s_t_1, a_s_t_0)
    assert isinstance(parent_0, module_0.AST)


# Generated at 2022-06-25 23:18:28.564737
# Unit test for function replace_at
def test_replace_at():
    assert True


# Generated at 2022-06-25 23:18:35.335018
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as ast
    module = ast.Module([
        ast.FunctionDef(
            "foo",
            ast.arguments([], [], None, []),
            [
                ast.Pass(),
            ],
            [],
            None,
        ),
    ])

    def_node = module.body[0]

    parent_node, index = get_non_exp_parent_and_index(module, def_node)

    assert parent_node == module
    assert index == 0

# Generated at 2022-06-25 23:18:47.002983
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [a_s_t_0]
    a_s_t_1 = module_0.AST()
    a_s_t_1.context = a_s_t_0
    a_s_t_0.body.append(a_s_t_1)
    a_s_t_2 = module_0.AST()
    a_s_t_2.body = []
    a_s_t_1.body.append(a_s_t_2)
    a_s_t_3 = module_0.AST()
    a_s_t_3.value = a_s_t_0

# Generated at 2022-06-25 23:18:51.107783
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    _parents[a_s_t_0] = a_s_t_1
    get_parent(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:52.709060
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    # Case 0
    test_case_0()



# Generated at 2022-06-25 23:19:02.242461
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [a_s_t_0]
    tuple_0 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_0)
    assert(isinstance(tuple_0, tuple))
    assert(len(tuple_0) == 2)
    assert(isinstance(tuple_0[0], module_0.AST))
    assert(isinstance(tuple_0[1], int))
    assert(tuple_0[0] == a_s_t_1)
    assert(tuple_0[1] == 0)

import sys

# Generated at 2022-06-25 23:19:04.091319
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST()
    iterable_0 = find(a_s_t_2, ast.AST)

# Generated at 2022-06-25 23:19:12.150217
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    # assert tuple_0 == (a_s_t_0, 0)
    # assert type(get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)) == tuple
    # assert type(get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)[0]) == module_0.AST
    # assert type(get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)[1]) == int


# Generated at 2022-06-25 23:19:14.360331
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:19:26.188856
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body = [a_s_t_1]
    assert_equal(get_parent(a_s_t_0, a_s_t_1), a_s_t_0)


# Generated at 2022-06-25 23:19:29.012659
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    parent = 42

    class TestAST(ast.AST):

        def __init__(self):
            self.parent = parent

    node = TestAST()

    tree = TestAST()

    test = get_closest_parent_of(tree, node, TestAST)

    assert test == tree



# Generated at 2022-06-25 23:19:30.373630
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Case 0:
    test_case_0()


# Generated at 2022-06-25 23:19:34.565728
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body = [a_s_t_1]
    a_s_t_2 = get_parent(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:19:36.904937
# Unit test for function get_parent
def test_get_parent():
    # Make sure that each output is equal to the expected output.
    test_case_0()


# Generated at 2022-06-25 23:19:37.768533
# Unit test for function find

# Generated at 2022-06-25 23:19:42.626860
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    test_case_0()


import typed_ast._ast3 as module_0
import collections as module_1
import copy as module_2
import re as module_3
import textwrap as module_4
import typed_ast._ast3 as module_5
import types as module_6
import typing as module_7
import warnings as module_8


# Generated at 2022-06-25 23:19:46.711719
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert tuple_0 == (a_s_t_0, 0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:19:54.132358
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:20:04.689216
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.Module()
    function_def_0 = ast.FunctionDef()
    module_0.body.append(function_def_0)
    assertion_0 = get_closest_parent_of(module_0, function_def_0, ast.Module)
    assert(assertion_0 == module_0)
    module_1 = ast.Module()
    function_def_0 = ast.FunctionDef()
    module_1.body.append(function_def_0)
    assertion_0 = get_closest_parent_of(module_1, function_def_0, ast.Module)
    assert(assertion_0 == module_1)
    module_2 = ast.Module()
    function_def_0 = ast.FunctionDef()

# Generated at 2022-06-25 23:20:24.714014
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert tuple_0[0] == a_s_t_0

# Generated at 2022-06-25 23:20:31.130782
# Unit test for function find
def test_find():
    # Test case 1
    a_s_t_0 = module_0.AST()
    iter_0 = find(a_s_t_0, module_0.AST)
    next(iter_0)
    # Test case 2
    a_s_t_1 = module_0.AST()
    iter_0 = find(a_s_t_1, module_0.AST)
    next(iter_0)
    # Test case 3
    a_s_t_2 = module_0.AST()
    iter_0 = find(a_s_t_2, module_0.AST)
    next(iter_0)
    # Test case 4
    a_s_t_3 = module_0.AST()
    iter_0 = find(a_s_t_3, module_0.AST)

# Generated at 2022-06-25 23:20:42.860669
# Unit test for function find
def test_find():
    i_node_0 = module_0.ImportFrom(module='name_0', names=[], level=None)
    m_node_0 = module_0.Module(body=[])
    insert_at(0, m_node_0, i_node_0)
    gen_node_0 = module_0.GeneratorExp(elt=i_node_0, generators=[])
    i_node_1 = module_0.ImportFrom(module='name_0', names=[], level=None)
    m_node_1 = module_0.Module(body=[])
    insert_at(0, m_node_1, i_node_1)
    gen_node_1 = module_0.GeneratorExp(elt=i_node_1, generators=[])

# Generated at 2022-06-25 23:20:45.894890
# Unit test for function find
def test_find():
    module_0 = ast.Module(
        body=[ast.Name(id='Annotation')]
    )
    # TODO: doesn't work: should yield ast.Name
    expected = [ast.Name(id='Annotation')]
    result = list(find(module_0, ast.Name))
    assert result == expected



# Generated at 2022-06-25 23:20:50.389058
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Case: Test Case
    assert test_case_0()

import typed_ast._ast3 as module_0
import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2
import typed_ast._ast3 as module_3
import typed_ast._ast3 as module_4


# Generated at 2022-06-25 23:21:00.533202
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Pass()]
    a_s_t_0.body.insert(0, module_0.Pass())
    a_s_t_0.body.insert(1, module_0.Pass())
    a_s_t_0.body.insert(2, module_0.Pass())
    a_s_t_0.body[0] = module_0.Pass()
    a_s_t_0.body[1] = module_0.Pass()
    a_s_t_0.body[2] = module_0.Pass()
    find(a_s_t_0, module_0.Pass)


# Generated at 2022-06-25 23:21:04.921592
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    
    # Test 1:
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, type(a_s_t_0))


# Generated at 2022-06-25 23:21:06.456046
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    with pytest.raises(NodeNotFound):
        test_case_0()


# Generated at 2022-06-25 23:21:14.890203
# Unit test for function replace_at
def test_replace_at():
    list_0 = []
    tuple_0 = (list_0, 2)
    module_0.list_0 = list_0
    module_0.tuple_0 = tuple_0
    a_s_t_0 = module_0.AST()
    replace_at(2, a_s_t_0, a_s_t_0)
    replace_at(int(), a_s_t_0, module_0.tuple_0)
    replace_at(int(), a_s_t_0, module_0.list_0)
    replace_at(2, a_s_t_0, tuple_0)
    replace_at(2, a_s_t_0, module_0.list_0)

# Generated at 2022-06-25 23:21:20.840598
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    failed = []
    passed = []
    try:
        test_case_0()
        passed.append("test_case_0")
    except:
        failed.append("test_case_0")
    assert len(failed) == 0 and len(passed) > 0, '\nFailed: {}\nPassed: {}'.format(failed, passed)

import unittest
if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 23:22:02.852035
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    retype_0 = tuple_0.__repr__()
    retype_1 = tuple_0.__str__()
    retype_2 = tuple_0

# Generated at 2022-06-25 23:22:12.147321
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:22:13.532973
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    replace_at(a_s_t_0.TYPE_COMMENT, a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:22:15.681461
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test when none of the while conditions are true
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:22:17.862579
# Unit test for function find
def test_find():
    t1 = ast.parse('x = 1\nx')
    for n in find(t1, ast.Expr):
        assert n.value.n == 1
    for n in find(t1, ast.Num):
        assert n.n == 1


# Generated at 2022-06-25 23:22:22.447173
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Tests for get_non_exp_parent_and_index
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert True



# Generated at 2022-06-25 23:22:29.464987
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Set up test environment
    import typed_ast._ast3 as module_1
    a_s_t_1 = module_1.AST()
    # Test function
    result = get_closest_parent_of(a_s_t_1, a_s_t_1, module_1.AST)
    # Check result
    assert isinstance(result, module_1.AST,
                      "Result is not an AST node!")

# Generated at 2022-06-25 23:22:33.444593
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    class_0 = find(a_s_t_0, module_0.ClassDef)
    function_0 = find(a_s_t_0, module_0.FunctionDef)


# Generated at 2022-06-25 23:22:36.166863
# Unit test for function find
def test_find():
    a_s_t_1 = module_0.AST()
    iterable_0 = find(a_s_t_1, type)


# Generated at 2022-06-25 23:22:40.051254
# Unit test for function find
def test_find():
    """Find without error."""
    a_s_t_0 = module_0.AST()
    tuple_0 = find(a_s_t_0, a_s_t_0)
    tuple_0 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:23:58.573057
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    node_0 = module_0.AST()
    assert get_parent(a_s_t_0, node_0) == a_s_t_0


# Generated at 2022-06-25 23:24:02.899786
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    _build_parents(a_s_t_0)
    _build_parents(a_s_t_1)
    ast_2 = get_parent(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:24:05.732525
# Unit test for function find
def test_find():
    from .find import find
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, type(None))
    for item_0 in iterable_0:
        assert(item_0 == module_0.AST())


# Generated at 2022-06-25 23:24:14.441283
# Unit test for function find
def test_find():
    find(module_0.AST(), module_0.AST)
    find(module_0.AST(), module_0.arguments)
    find(module_0.AST(), module_0.alias)
    find(module_0.AST(), module_0.arg)
    find(module_0.AST(), module_0.Assert)
    find(module_0.AST(), module_0.Assign)
    find(module_0.AST(), module_0.Attribute)
    find(module_0.AST(), module_0.AugAssign)
    find(module_0.AST(), module_0.BinOp)
    find(module_0.AST(), module_0.BoolOp)
    find(module_0.AST(), module_0.Break)

# Generated at 2022-06-25 23:24:16.909507
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0 = ast.parse('1')
    a_s_t_0 = module_0.body[0]
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 23:24:19.294470
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    print(list(find(a_s_t_0, module_0.AST)))


# Generated at 2022-06-25 23:24:26.155220
# Unit test for function find

# Generated at 2022-06-25 23:24:29.863434
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()


import typed_ast._ast3 as module_1
