

# Generated at 2022-06-25 23:14:37.631404
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # From line number to function name.
    test_case_to_function = {
        0: test_case_0,
    }

    # Run tests.
    for case, func in test_case_to_function.items():
        func()

# Generated at 2022-06-25 23:14:44.394102
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
  # Fail case
  try:
    test_case_0()
  except NodeNotFound:
    pass
  # Pass case
  a_s_t_0 = module_0.Module([])
  a_s_t_1 = module_0.Expr(None)
  a_s_t_0.body = [a_s_t_1]
  tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:14:45.260076
# Unit test for function replace_at
def test_replace_at():
    assert 1 ==1
test_replace_at()

# Generated at 2022-06-25 23:14:47.131333
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    Type = type(None)
    iterable_0 = find(a_s_t_0, Type)

# Generated at 2022-06-25 23:14:50.484591
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    x_0 = find(a_s_t_0, module_0)
    assert x_0 == (a_s_t_0, )

if __name__ == '__main__':
    test_case_0()
    test_find()

# Generated at 2022-06-25 23:14:55.389128
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_1.body = [a_s_t_2]
    tuple_1 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_2)

# Generated at 2022-06-25 23:14:59.602072
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    index = tuple_0[1]
    parent = tuple_0[0]
    replace_at(index, parent, a_s_t_0)


# Generated at 2022-06-25 23:15:02.999867
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    result = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert isinstance(result, module_0.AST)


# Generated at 2022-06-25 23:15:05.520787
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0 = ''
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 23:15:08.451568
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Testing branch in which node is not an Exp node
    # Testing branch where node is an exp node
    assert True

import typing as module_1

import typed_ast.ast3 as module_2


# Generated at 2022-06-25 23:15:15.888722
# Unit test for function find
def test_find():
    tree = ast.parse('import os\nimport sys\nx = 1 + 2')
    assert find(tree, ast.Import) is not None


# Generated at 2022-06-25 23:15:19.750110
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    ast_0 = _build_parents(a_s_t_0)
    list_0 = find(a_s_t_1, module_0.AST)


# Generated at 2022-06-25 23:15:20.609300
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Task 0
    assert True

# Generated at 2022-06-25 23:15:23.843986
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

    assert isinstance(tuple_0, tuple)


# Generated at 2022-06-25 23:15:26.482415
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 23:15:27.527049
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 =  find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:15:32.971903
# Unit test for function find
def test_find():
    a_s_t_0 = ast.AST()
    a_s_t_1 = ast.AnnAssign(target=a_s_t_0, annotation=a_s_t_0, value=a_s_t_0, simple=1)
    a_s_t_2 = ast.Assign(targets=[a_s_t_0], value=a_s_t_1)
    find(a_s_t_2, type(None))


# Generated at 2022-06-25 23:15:34.126984
# Unit test for function find
def test_find():
    str_0 = find(a_s_t_0, str)


# Generated at 2022-06-25 23:15:44.571417
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as module_0
    import typed_ast.ast3 as module_1
    class_0 = module_1.AST(body = [
        module_0.Return(
            value = module_1.AST(body = [
                module_0.Expr(
                    value = module_1.AST(body = [
                        module_0.BinOp(
                            left = module_0.Name(id = "a"),
                            op = module_0.Add(),
                            right = module_0.Name(id = "b"))]))]))])
    assert (get_non_exp_parent_and_index(class_0, class_0) == (class_0.body[0], 0))

# Generated at 2022-06-25 23:15:45.958681
# Unit test for function get_parent
def test_get_parent():
    # Get parrent of node in tree.
    pass


# Generated at 2022-06-25 23:15:54.436359
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, type(None))

# Generated at 2022-06-25 23:15:56.479080
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    assert find(a_s_t_0, type(module_0.AST)) == [module_0.AST()]


# Generated at 2022-06-25 23:16:06.030726
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    class_def_0 = module_0.ClassDef('cls')
    function_def_0 = module_0.FunctionDef('func')
    _build_parents(a_s_t_0)
    _parents[class_def_0] = a_s_t_0
    _parents[function_def_0] = class_def_0
    name_0 = module_0.Name(id='a')
    _parents[name_0] = function_def_0
    _build_parents(a_s_t_0)
    actual_return = get_closest_parent_of(a_s_t_0, name_0,
                                          module_0.FunctionDef)
    expected_return = function_def_0
   

# Generated at 2022-06-25 23:16:17.399430
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # This test is just a sanity check since we cannot reach the exception
    # node.NodeNotFound in this test.
    a_s_t_1 = module_0.AST()
    tuple_1 = test_case_0()
    assert tuple_0 == tuple_1

    tuple_0 = get_non_exp_parent_and_index(module_0.AST(), module_0.AST())

    # This test is just a sanity check since we cannot reach the exception
    # node.NodeNotFound in this test.
    a_s_t_2 = module_0.AST()
    tuple_2 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_2)
    assert tuple_0 == tuple_2

# Generated at 2022-06-25 23:16:22.976681
# Unit test for function replace_at
def test_replace_at():
    from typed_ast import ast3 as ast
    from typed_ast import c_ast3 as c_ast

    a_s_t_0 = ast.parse('''while True: pass''')
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0.body[0])
    replace_at(0, tuple_0[0], ast.Return())
    tuple_1 = get_non_exp_parent_and_index(a_s_t_0, tuple_0[0].body[0])

# Generated at 2022-06-25 23:16:25.454059
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, ast.AST)


# Generated at 2022-06-25 23:16:32.201280
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = ast.Module()
    a_s_t_1 = ast.FunctionDef()
    a_s_t_0.body.append(a_s_t_1)
    _build_parents(a_s_t_0)
    a_s_t_2 = get_closest_parent_of(a_s_t_0, a_s_t_1, ast.FunctionDef)

# Generated at 2022-06-25 23:16:38.406613
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    # TODO: not sure how to test it
    # Calling find(type_=type_, tree=a_s_t_0)
    if __name__ == '__main__':
        a_s_t_0.body = [a_s_t_0.body, a_s_t_0.body]


# Generated at 2022-06-25 23:16:41.337890
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    tuple_0 = find(a_s_t_0, ast.AST)


# Generated at 2022-06-25 23:16:42.911735
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert(get_non_exp_parent_and_index(None, None) == (None, None))

# Generated at 2022-06-25 23:16:58.494428
# Unit test for function find
def test_find():

    import typed_ast._ast3 as module_0

    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module

# Generated at 2022-06-25 23:17:07.463097
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()

    a_s_t_0.body = [a_s_t_1]
    a_s_t_1.body = [a_s_t_2]
    a_s_t_2.body = [a_s_t_3]

# Generated at 2022-06-25 23:17:11.736783
# Unit test for function get_parent
def test_get_parent():

    # Test case where node exists in tree
    test_case_0()
    # Test case where node does not exist
    # TODO:

    # Test case where parents were rebuild

    # Test case where there is a cycle

    # Test case where parents are not built

    # Test case where node is not set in parents


# Generated at 2022-06-25 23:17:16.058724
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    assert(get_parent(a_s_t_1, a_s_t_0) is None)


# Generated at 2022-06-25 23:17:23.784120
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module = None # type: ast.AST
    func = None # type: ast.FunctionDef
    cls = None # type: ast.ClassDef
    method = None # type: ast.FunctionDef
    module = module or get_closest_parent_of(module, module, ast.AST)
    func = func or get_closest_parent_of(module, func, ast.AST)
    cls = cls or get_closest_parent_of(module, cls, ast.AST)
    method = method or get_closest_parent_of(module, method, ast.AST)

# Generated at 2022-06-25 23:17:27.739287
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [a_s_t_0]
    result = get_parent(a_s_t_1, a_s_t_0)
    assert(result == a_s_t_1)


# Generated at 2022-06-25 23:17:37.856785
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_1
    # Setup
    a_s_t_0 = module_1.AST()
    # test_0
    a_s_t_1 = module_1.AST()
    a_s_t_0.body = [a_s_t_1]
    expected = a_s_t_0
    actual = get_closest_parent_of(a_s_t_0, a_s_t_1, module_1.AST)
    assert actual == expected
    # test_1
    a_s_t_2 = module_1.AST()
    a_s_t_1.body = [a_s_t_2]
    expected = a_s_t_1

# Generated at 2022-06-25 23:17:39.617016
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # No assertion. If this function raises, the unittest will fail
    test_case_0()

# Generated at 2022-06-25 23:17:49.086784
# Unit test for function get_parent
def test_get_parent():

    # Pass 1 Check if node is the root
    # module_0.AST()
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef(
        name='f', body=(), args=module_0.arguments(args=(), vararg=None, kwonlyargs=(), kw_defaults=(), kwarg=None, defaults=()), decorator_list=(), returns=None
    )
    a_s_t_0.body.append(function_def_0)
    test_node = function_def_0
    root_node = a_s_t_0
    if get_parent(root_node, test_node, False) != root_node:
        raise Exception('Failed to get root node !')

    # Pass 2 Check if node is

# Generated at 2022-06-25 23:17:54.887679
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    s_tmt_0 = module_0.stmt()

    try:
        get_closest_parent_of(a_s_t_0, s_tmt_0, module_0.AST)
    except:
        pass  # TODO
    try:
        get_closest_parent_of(a_s_t_0, s_tmt_0, module_0.expr)
    except:
        pass  # TODO

# Generated at 2022-06-25 23:18:03.621178
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    assert() == get_closest_parent_of(a_s_t_0, a_s_t_0)

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        print("Usage: python %s <function_name>" % sys.argv[0])
        sys.exit(0)
    function_name = sys.argv[1]
    if function_name in globals():
        globals()[function_name]()
    else:
        print("Function %s not found" % function_name)

# Generated at 2022-06-25 23:18:04.235634
# Unit test for function replace_at
def test_replace_at():
    assert False

# Generated at 2022-06-25 23:18:11.694710
# Unit test for function find
def test_find():
    import ast
    _ast = ast.parse("""
    if foo:
        bar()
    elif baz:
        qux
    else:
        quux()

    def spam():
        eggs()
    """)
    assert list(find(_ast, ast.If)) == [_ast.body[0]]
    assert list(find(_ast, ast.Call)) == [_ast.body[0].body[0],
                                          _ast.body[1].body[0],
                                          _ast.body[2].body[0]]


# Generated at 2022-06-25 23:18:17.538417
# Unit test for function replace_at
def test_replace_at():
    for a_s_t_1 in find(module_0.AST(), module_0.AST):
        for child in ast.iter_child_nodes(a_s_t_1):
            replace_at(1, a_s_t_1, child)


# Generated at 2022-06-25 23:18:19.040157
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # No assertion.
    # test_case_0()

    assert True # TODO: implement your test here


# Generated at 2022-06-25 23:18:24.462170
# Unit test for function find
def test_find():
    # AST 0

    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Expr(value=module_0.Num(n=1))]
    a_s_t_0.orelse = []

    # Ensures that find returns a iterable
    find_0 = find(a_s_t_0, module_0.Expr)
    assert (iter(find_0) == find_0), ('Invalid value %s'.format(find_0))

    # Ensures that find returns the correct value
    find_0 = find(a_s_t_0, module_0.Expr)
    find_0 = list(find_0)

# Generated at 2022-06-25 23:18:26.714948
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Successively call this function with the most typical
    # arguments/values.
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:18:27.667875
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:18:37.460128
# Unit test for function get_parent
def test_get_parent():
    # Test empty tree
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

    # Test tree with one node
    a_s_t_1 = module_0.Num()
    parent_0 = get_parent(a_s_t_0, a_s_t_1)

    # Test tree with multiple nodes
    a_s_t_2 = module_0.operator()
    a_s_t_3 = module_0.Num()
    parent_1 = get_parent(a_s_t_1, a_s_t_3)

    # Test correct parent
    a_s_t_4 = module_0.Num()

# Generated at 2022-06-25 23:18:41.567927
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # No error should be thrown.
    test_case_0()

import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2
import typed_ast._ast3 as module_3


# Generated at 2022-06-25 23:18:48.021422
# Unit test for function find
def test_find():
    test_case_0()

# Generated at 2022-06-25 23:18:57.065147
# Unit test for function find
def test_find():
    # Test Case 1
    a_s_t_0 = module_0.AST()
    for tp_0 in find(a_s_t_0, module_0.Str):
        pass
    # Test Case 2
    a_s_t_1 = module_0.AST()
    for tp_0 in find(a_s_t_1, module_0.Stmt):
        pass
    # Test Case 3
    a_s_t_2 = module_0.AST()
    for tp_0 in find(a_s_t_2, module_0.List):
        pass
    # Test Case 4
    a_s_t_3 = module_0.AST()
    for tp_0 in find(a_s_t_3, module_0.Str):
        pass
    #

# Generated at 2022-06-25 23:18:58.772962
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0
    module_0.TestCase()


# Generated at 2022-06-25 23:19:00.129475
# Unit test for function find

# Generated at 2022-06-25 23:19:03.687909
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    result_0 = get_parent(a_s_t_0, a_s_t_0)
    assert result_0 == result_0


# Generated at 2022-06-25 23:19:05.290671
# Unit test for function get_parent
def test_get_parent():
    import _ast
    expr = _ast.Expr()

# Generated at 2022-06-25 23:19:07.643218
# Unit test for function find
def test_find():
    # Input parameters
    tree_0 = module_0.AST()
    type__0 = module_0.AST

    # Call function
    find(tree=tree_0, type_=type__0)


# Generated at 2022-06-25 23:19:12.061158
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = ast.Module()
    name_0 = a_s_t_0.body.append(ast.Import())
    test_case_0()
    a_s_t_0.body.append(ast.ImportFrom())
    a_s_t_0.body.append(ast.FunctionDef())
    a_s_t_0.body.append(ast.ClassDef())
    a_s_t_0.body.append(ast.Return())
    a_s_t_0.body.append(ast.Delete())
    a_s_t_0.body.append(ast.Assign())
    a_s_t_0.body.append(ast.AugAssign())
    a_s_t_0.body.append(ast.AnnAssign())
    a_

# Generated at 2022-06-25 23:19:22.925920
# Unit test for function get_parent
def test_get_parent():
    module_ast = ast.parse("module_ast = ast.parse('module_ast')")
    module_ast_parent = get_parent(module_ast, module_ast)
    # parent for module is None
    assert module_ast_parent is None

    function_ast = ast.FunctionDef(
        name='function_ast',
        args=ast.arguments(args=[ast.arg('arg1')], defaults=[]),
        body=[ast.Pass()],
        decorator_list=[],
        returns=None,
    )
    # insert module ast as body member to get parent
    module_ast.body.append(function_ast)

    arg1_parent = get_parent(module_ast, function_ast.args.args[0])
    assert arg1_parent is function_ast

    # get parent of module_ast

# Generated at 2022-06-25 23:19:29.286538
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    cont_0 = find(a_s_t_0, bool)
    a_s_t_1 = module_0.AST()
    cont_1 = find(a_s_t_1, bool)
    a_s_t_2 = module_0.AST()
    cont_2 = find(a_s_t_2, bool)
    a_s_t_3 = module_0.AST()
    cont_3 = find(a_s_t_3, bool)
    a_s_t_4 = module_0.AST()
    cont_4 = find(a_s_t_4, bool)
    a_s_t_5 = module_0.AST()

# Generated at 2022-06-25 23:19:49.735700
# Unit test for function get_parent
def test_get_parent():
    # Check if it returns the expected result
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    
    a_s_t_0.body = [a_s_t_1]
    
    assert get_parent(a_s_t_0, a_s_t_1) == a_s_t_0
    
    # Check if it raises the correct exception in a given case
    pytest.raises(NodeNotFound, get_parent, a_s_t_1, a_s_t_0)


# Generated at 2022-06-25 23:19:51.869149
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)



# Generated at 2022-06-25 23:19:55.416903
# Unit test for function find
def test_find():
    print('Testing find...')
    assert sum(1 for _ in find(a_s_t_0, Tuple)) == 0
    assert sum(1 for _ in find(a_s_t_0, ast.AST)) == 1


# Generated at 2022-06-25 23:19:56.301407
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass


# Generated at 2022-06-25 23:20:00.963617
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0 = typed_ast._ast3
    class_0 = module_0.AST
    a_s_t_1 = class_0()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_1)


# Generated at 2022-06-25 23:20:10.184965
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.parse('def a():\n    return 0')
    module_1 = ast.parse('def b():\n    return 1')
    try:
        tuple_0 = get_closest_parent_of(module_0, module_1, ast.FunctionDef)
    except NodeNotFound:
        pass
    except:
        import traceback
        traceback.print_exc()

    module_2 = ast.parse('if True:\n    a = 0')
    try:
        tuple_1 = get_closest_parent_of(module_2, module_2, ast.FunctionDef)
    except NodeNotFound:
        pass
    except:
        import traceback
        traceback.print_exc()

    module_3 = ast.parse('a = 0\nb = 0')

# Generated at 2022-06-25 23:20:17.718851
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    actual = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    return actual


# Generated at 2022-06-25 23:20:19.148975
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

# Generated at 2022-06-25 23:20:28.600069
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    n_s_t_0 = module_0.FunctionDef('f', module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [module_0.Expr(value=module_0.BinOp(left=module_0.BinOp(left=module_0.Num(n=1), op=module_0.Add(), right=module_0.Num(n=1)), op=module_0.Add(), right=module_0.Add()))], [], None, None)
    assert get_non_exp_parent_and_index(n_s_t_0, n_s_t_0.body[0].value.right) == (n_s_t_0.body[0].value, 2)

# Generated at 2022-06-25 23:20:34.322571
# Unit test for function find
def test_find():
    a_s_t_0 = ast.parse('def f():\n   1')
    sequence_0 = find(a_s_t_0, ast.FunctionDef)
    a_s_t_0 = ast.parse('x = 1')
    sequence_1 = find(a_s_t_0, ast.FunctionDef)


# Generated at 2022-06-25 23:21:13.259579
# Unit test for function find
def test_find():
    # Create AST
    module_node = ast.Module()
    body_0 = []
    body_0.append(ast.Expr(value=ast.Num(n=1)))
    body_0.append(ast.Expr(value=ast.Num(n=2)))
    module_node.body = body_0
    # Find all Num nodes in the AST
    found = find(module_node, ast.Num)
    # Assert that the two Num nodes were found
    assert len(found) == 2
    # Assert that the correct nodes were found
    assert isinstance(found[0], ast.Num)
    assert found[0].n == 1
    assert isinstance(found[1], ast.Num)
    assert found[1].n == 2


# Generated at 2022-06-25 23:21:15.484624
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:21:19.761609
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_0_2 = a_s_t_0
    assert get_closest_parent_of(a_s_t_0, a_s_t_0_2, ast.AST) == a_s_t_0


# Generated at 2022-06-25 23:21:22.208145
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    assert get_parent(a_s_t_0, a_s_t_0) == None


# Generated at 2022-06-25 23:21:24.452713
# Unit test for function find
def test_find():
    # Setup environment.
    pass
    # Call function to be tested.
    find()


from unittest import TestCase


# Generated at 2022-06-25 23:21:26.901069
# Unit test for function find
def test_find():
    """Test for find."""
    a_s_t_0 = module_0.AST()
    int_0 = find(a_s_t_0, int)


# Generated at 2022-06-25 23:21:30.905827
# Unit test for function find
def test_find():
    # Setup
    a_s_t_2 = module_0.AST()

    # Testing
    list_0 = list(find(a_s_t_2, module_0.AST))

    # Verification
    assert len(list_0) == 1
    assert list_0[0] == a_s_t_2


# Generated at 2022-06-25 23:21:33.183089
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iter_0 = find(a_s_t_0, module_0.AST)
    assert iter_0.__next__() == a_s_t_0


# Generated at 2022-06-25 23:21:33.594641
# Unit test for function find

# Generated at 2022-06-25 23:21:38.239438
# Unit test for function find
def test_find():
    import typed_ast._ast3 as module_0
    import typed_ast.ast3 as module_1
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, type(a_s_t_0))


# Generated at 2022-06-25 23:23:25.333518
# Unit test for function find
def test_find():
    a_s_t_0 = ast. AST()
    assert isinstance(find(a_s_t_0, ast.AST), typing.Generator)


# Generated at 2022-06-25 23:23:26.077076
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

# Generated at 2022-06-25 23:23:33.155579
# Unit test for function find
def test_find():
    # Create AST
    module = ast.Module()

    # Add some expressions
    expr1 = ast.Expr(ast.Str('Hello world!'))
    module.body.append(expr1)
    expr2 = ast.Expr(ast.Str('Hello world 2!'))
    module.body.append(expr2)

    # Check expressions are found
    assert list(find(module, ast.Expr)) == [expr1, expr2]
    assert list(find(module, ast.Str)) == [expr1.value, expr2.value]



# Generated at 2022-06-25 23:23:41.869983
# Unit test for function get_parent

# Generated at 2022-06-25 23:23:45.810011
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    _parents[a_s_t_0] = a_s_t_1
    tree = a_s_t_1
    node = a_s_t_0
    rebuild = False
    result = get_parent(tree, node, rebuild)
    assert result == a_s_t_1



# Generated at 2022-06-25 23:23:48.230533
# Unit test for function get_parent
def test_get_parent():
    ast_0 = ast.parse('if True: a = 1\nif False: b = 2')
    if_node = ast_0.body[1]
    assert get_parent(ast_0, if_node) == ast_0



# Generated at 2022-06-25 23:23:50.864517
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    class_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.ClassDef)




# Generated at 2022-06-25 23:23:54.326898
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    _build_parents(a_s_t_0)
    get_parent(a_s_t_0, a_s_t_0)
    assert True


# Generated at 2022-06-25 23:23:55.900471
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    tuple_0 = find(a_s_t_0, type)


# Generated at 2022-06-25 23:23:59.027398
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, tuple)
