

# Generated at 2022-06-25 23:14:38.173814
# Unit test for function find
def test_find():
    # Case 1
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, list)
    # Case 2
    a_s_t_1 = module_0.AST()
    list_1 = find(a_s_t_1, int)
    # Case 3
    a_s_t_2 = module_0.AST()
    list_2 = find(a_s_t_2, str)


# Generated at 2022-06-25 23:14:46.518638
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    program = ast.parse('''\
print("Hello world!")
if __name__ == '__main__':
    run()
''')
    # The program is a Module() instance.
    assert isinstance(program, ast.Module)

    # The first statement of the program is an Expr() instance.
    print_stmt = program.body[0]
    assert isinstance(print_stmt, ast.Expr)

    # The Expr() instance contains a Call() instance.
    call = print_stmt.value
    assert isinstance(call, ast.Call)

    # The Call() instance contains a Name() instance.
    name = call.func
    assert isinstance(name, ast.Name)
    assert name.id == 'print'

# Generated at 2022-06-25 23:14:56.015019
# Unit test for function find
def test_find():
    a_s_t_0 = ast.AST()
    a_s_t_1 = ast.AST()
    a_s_t_2 = ast.AST()
    a_s_t_3 = ast.AST()
    a_s_t_4 = ast.AST()
    a_s_t_5 = ast.AST()
    a_s_t_6 = ast.AST()
    a_s_t_7 = ast.AST()
    a_s_t_8 = ast.AST()
    a_s_t_9 = ast.AST()
    a_s_t_10 = ast.AST()
    a_s_t_11 = ast.AST()
    a_s_t_12 = ast.AST()
    a_s_t_13 = ast.AST()
    a_

# Generated at 2022-06-25 23:15:03.302189
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # _ast.Module
    module_0 = ast.Module()
    # _ast.Assign
    assign_0 = ast.Assign()
    # _ast.Name
    name_0 = ast.Name()
    name_0.id = "f"
    # _ast.List
    list_0 = ast.List()
    # _ast.Assign
    assign_1 = ast.Assign()
    # _ast.Name
    name_1 = ast.Name()
    name_1.id = "g"
    # _ast.List
    list_1 = ast.List()
    # _ast.Subscript
    subscript_0 = ast.Subscript()
    # _ast.Name
    name_2 = ast.Name()
    name_2.id = "h"
    # _ast.Load


# Generated at 2022-06-25 23:15:14.670757
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    print("testing build")

    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert (isinstance(tuple_0, tuple))
    assert (len(tuple_0) == 2)
    assert (tuple_0[0] is a_s_t_0)
    assert (isinstance(tuple_0[1], int))
    
#    print "testing set_context"
#    set_context(module_0.Module([]))
#
#    test_case_0()
#
#    #TODO: add more tests
#
## Uncomment for detailed output
#    print("Testing get_non_exp_parent_and_index")


# Generated at 2022-06-25 23:15:23.551227
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    n0_0 = module_0.Name()
    n0_0._fields = ('id', 'ctx', 'lineno', 'col_offset')
    n0_0._attributes = ('id', 'ctx')
    n0_0.id = 'abc'
    n0_0.ctx = module_0.Store()
    n0_0._ctx = module_0.Store()
    n0_0.lineno = 1
    n0_0.col_offset = 1
    a_s_t_1 = module_0.AST()
    a_s_t_1._fields = ('lineno', 'col_offset', 'body')
    a_s_t_1._attributes = ('lineno', 'col_offset', 'body')


# Generated at 2022-06-25 23:15:26.815436
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    get_parent(a_s_t_0, a_s_t_1, rebuild=False) # ! <body>


# Generated at 2022-06-25 23:15:29.151024
# Unit test for function insert_at
def test_insert_at():
    a = 1
    b = 2
    c = 3
    l = [a, b, c]
    insert_at(0, l, c)
    assert l == [c, a, b, c]
    insert_at(1, l, b)
    assert l == [c, b, a, b, c]
    insert_at(4, l, a)
    assert l == [c, b, a, b, a, c]



# Generated at 2022-06-25 23:15:38.198330
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, ast.AST)
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    tuple_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_0)
    a_s_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, ast.AST)
    tuple_2 = get_non_exp_parent_and_index(a_s_t_0, a_s_0)

# Generated at 2022-06-25 23:15:45.530200
# Unit test for function insert_at
def test_insert_at():
    arg_0 = 0
    arg_1 = module_0.AST()
    arg_2 = module_0.AST()
    insert_at(arg_0, arg_1, arg_2)

    module_0.AST()
    arg_2 = module_0.AST()
    insert_at(arg_0, arg_1, arg_2)
    module_0.AST()
    arg_2 = [module_0.AST(), module_0.AST()]
    insert_at(arg_0, arg_1, arg_2)


# Generated at 2022-06-25 23:15:54.056854
# Unit test for function get_parent
def test_get_parent():
    assert False


# Generated at 2022-06-25 23:15:56.066580
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, type(a_s_t_0))


# Generated at 2022-06-25 23:16:03.136248
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [a_s_t_0]
    a_s_t_0.body[0].type = 6
    find(a_s_t_0, a_s_t_0.body[0].type)
    find(a_s_t_0, a_s_t_0.body[0].type)

# Generated at 2022-06-25 23:16:14.008116
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tuple_0 = get_non_exp_parent_and_index(module_0.AST(), module_0.AST())
    list_0 = find(module_0.AST(), ast.AST)
    tuple_1 = get_non_exp_parent_and_index(module_0.AST(), module_0.AST())
    tuple_2 = get_non_exp_parent_and_index(module_0.AST(), module_0.AST())
    tuple_3 = get_non_exp_parent_and_index(module_0.AST(), module_0.AST())
    tuple_4 = get_non_exp_parent_and_index(module_0.AST(), module_0.AST())
    tuple_5 = get_non_exp_parent_and_index(module_0.AST(), module_0.AST())
   

# Generated at 2022-06-25 23:16:17.369119
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    tuple_0 = find(a_s_t_0, ast.AST)


# Generated at 2022-06-25 23:16:20.587071
# Unit test for function find
def test_find():
    # Setup
    a_s_t_0 = module_0.AST()
    expected_0 = module_0.iter_fields(a_s_t_0)

    # Execution
    result_0 = find(a_s_t_0, expected_0)

    # Verification
    module_0.AssertIsInstance(result_0, expected_0)


# Generated at 2022-06-25 23:16:31.782214
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:16:37.693826
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    type_0 = type(a_s_t_0)
    list_0 = find(a_s_t_0, type_0)
    assert len(list_0) == 1
    assert list_0[0] == a_s_t_0


# Generated at 2022-06-25 23:16:38.936073
# Unit test for function find
def test_find():
    assert 1 == 1


# Generated at 2022-06-25 23:16:40.896932
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(None, None) is None


# Generated at 2022-06-25 23:16:50.299707
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from ..utils import find


    class A(ast.AST):
        _fields = ('a',)


    class B(A):
        _fields = ('b',)

    node = ast.Module([A(a='aaaa'), B(a='aaaa', b='bbbbbb')])

    ns = list(find(node, A))
    assert len(ns) == 2
    assert isinstance(ns[0], A)
    assert isinstance(ns[1], B)

# Generated at 2022-06-25 23:16:53.184706
# Unit test for function find
def test_find():
    import typed_ast._ast3 as module_0
    __0, __1 = find(module_0.AST(), tuple)
    assert type(__0) == type(__1)


# Generated at 2022-06-25 23:16:58.736062
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = ast.Assign(
        [ast.Name('c', ast.Store())],
        ast.Num(0),
    )
    a_s_t_1 = ast.While(
        [ast.Num(2)],
        [a_s_t_0]
    )
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    None



# Generated at 2022-06-25 23:17:02.842690
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    some_node = ast.While(test=ast.Name(id='test', ctx=ast.Load()), body=[],
                          orelse=[])
    assert get_non_exp_parent_and_index(some_node, some_node) == (some_node, 0)

# Generated at 2022-06-25 23:17:10.758780
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    func_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, type_=ast.FunctionDef)

    return (
        func_0,
        a_s_t_0
    )

Case = namedtuple('Case', 'test_name func expected')
cases = [
    Case(test_name="test_case_0", func=test_case_0, expected=()),
    Case(test_name="test_get_closest_parent_of", func=test_get_closest_parent_of, expected=(
        None,
        module_0.AST()
    )),
]



# Generated at 2022-06-25 23:17:13.490314
# Unit test for function find
def test_find():
    ast_1 = module_0.AST()
    find(ast_1, module_0.stmt)
    find(ast_1, module_0.expr)


# Generated at 2022-06-25 23:17:22.711700
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import _ast
    a_s_t_0 = _ast.AST()
    a_s_t_0 = _ast.AST()
    a_s_t_0 = _ast.AST()
    _ast.Return()
    _ast.AST()
    _ast.Expr()
    _ast.AST()
    a_s_t_0 = _ast.Expr()
    get_closest_parent_of(a_s_t_0, a_s_t_0, _ast.Expr)
    get_closest_parent_of(a_s_t_0, a_s_t_0, _ast.Return)


# Generated at 2022-06-25 23:17:24.256383
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:17:26.288313
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:17:36.671856
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = ast.Module(body=[])
    a_s_t_1 = ast.Assert(test=ast.Constant(value=None), msg=None)
    a_s_t_0.body = [a_s_t_1]
    a_s_t_2 = get_parent(a_s_t_0, a_s_t_1)
    assert isinstance(a_s_t_2, ast.Module)
    a_s_t_3 = ast.Assign(targets=[ast.Name(id="a", ctx=ast.Store())], value=ast.Name(id="b", ctx=ast.Load()))

# Generated at 2022-06-25 23:17:43.647730
# Unit test for function get_parent
def test_get_parent():
    assert get_parent(None, None) == None
    assert True


# Generated at 2022-06-25 23:17:48.969065
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Create Input Arguments
    module_0 = ast.Module()
    a_s_t_0 = ast.Expr(value=ast.Str(s='hello'))
    ast.fix_missing_locations(a_s_t_0)
    module_0.body.append(a_s_t_0)
    return get_non_exp_parent_and_index(module_0, a_s_t_0)

# Generated at 2022-06-25 23:17:50.088476
# Unit test for function replace_at
def test_replace_at():
    # TODO: Implement unit test
    pass


# Generated at 2022-06-25 23:17:51.912409
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    x = find(a_s_t_0, type(None))
    assert x is not None


# Generated at 2022-06-25 23:17:56.113041
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = importlib.import_module('typed_ast._ast3')
    a_s_t_0 = module_0.AST()
    closest_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)

# Generated at 2022-06-25 23:17:57.328902
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

# Generated at 2022-06-25 23:18:03.376675
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.Name()
    tuple_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert isinstance(tuple_0, module_0.AST)

# Generated at 2022-06-25 23:18:04.743932
# Unit test for function get_parent
def test_get_parent():
    # OK
    test_case_0()


# Generated at 2022-06-25 23:18:07.922627
# Unit test for function find
def test_find():
    mod = ast.parse('a = 1')
    assert list(find(mod, ast.Name)) == [ast.Name(id='a', ctx=ast.Load())]


# Generated at 2022-06-25 23:18:10.683209
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    r = find(a_s_t_0, module_0.AST)
    assert isinstance(r, Iterable)


# Generated at 2022-06-25 23:18:23.329808
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    i_f_0 = module_0.If()
    _build_parents(a_s_t_0)
    _build_parents(i_f_0)
    assert get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.AST) is a_s_t_0
    assert get_closest_parent_of(i_f_0, i_f_0, module_0.If) is i_f_0
    # get_closest_parent_of(i_f_0, i_f_0, module_0.AST) is i_f_0
    # get_closest_

# Generated at 2022-06-25 23:18:27.410818
# Unit test for function find
def test_find():
    f_0 = module_0.FunctionDef(args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(value=module_0.Num(n=1))], decorator_list=[], returns=None, name='f', type_comment=None)
    assert(list(find(f_0, ast.FunctionDef))[0] == f_0)
    i_0 = module_0.If(test=module_0.Num(n=1), body=[module_0.Return(value=module_0.Num(n=1))], orelse=[])
    f_0.body.insert(0, i_0)

# Generated at 2022-06-25 23:18:31.420054
# Unit test for function find
def test_find():
    a_s_t_1 = module_0.AST()
    arg_0 = [a_s_t_1]
    result_1 = list(find(a_s_t_1, type(a_s_t_1)))
    assert_1 = arg_0 == result_1


# Generated at 2022-06-25 23:18:40.305897
# Unit test for function find
def test_find():
    import ast
    import typed_ast.ast3 as typed_ast
    def assertEqual(expected, returned):
        assert expected == returned, "{} != {}".format(
            expected, returned)
    assertEqual({'expected': set([typed_ast.Name,
                    typed_ast.Attribute,
                    typed_ast.Call,
                    typed_ast.BinOp,
                    typed_ast.Str,
                    typed_ast.Expr,
                    typed_ast.If,
                    typed_ast.Compare]),
 'returned': set(find(ast.parse("""if name:
    print('hello', name)"""), typed_ast.AST))}, {})

# Generated at 2022-06-25 23:18:50.090412
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0 = ast.Module()
    module_0.body = [ast.Import(), ast.Import(), ast.Import(), ast.Import(), ast.ImportFrom()] # type: ignore
    module_0.body[0].names = [ast.alias() for _ in range(10)] # type: ignore
    module_0.body[0].names[0].asname = '123'
    module_0.body[0].names[0].name = '123'
    module_0.body[0].names[1].asname = '123'
    module_0.body[0].names[1].name = '123'
    module_0.body[0].names[2].asname = '123'
    module_0.body[0].names[2].name = '123'

# Generated at 2022-06-25 23:18:53.371144
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:18:54.907032
# Unit test for function replace_at
def test_replace_at():
    # No asserts.
    try:
        test_case_0()
    except:
        pass




# Generated at 2022-06-25 23:19:04.408138
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test case where node is also the parent
    module_0 = ast.Module()
    statement_0 = ast.Expr(ast.Name())
    module_0.body.append(statement_0)
    result_0 = get_closest_parent_of(module_0, statement_0, ast.AST)
    assert(result_0 == module_0)

    # Test case where node is not the parent
    module_1 = ast.Module()
    statement_0 = ast.Expr(ast.Name())
    statement_1 = ast.BinOp(left=statement_0, op=ast.Add(), right=statement_0)
    module_1.body.append(statement_1)
    result_0 = get_closest_parent_of(module_1, statement_0, ast.Module)
   

# Generated at 2022-06-25 23:19:06.948380
# Unit test for function find
def test_find():
    two_tuple_0 = (1, 1)
    two_tuple_1 = (2, 3)
    int_0 = find(two_tuple_0, int)



# Generated at 2022-06-25 23:19:08.004419
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # unit test for get_non_exp_parent_and_index
    assert False

# Generated at 2022-06-25 23:19:15.528648
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Because of set of random values, uncomment the next two lines to run
    # a specific test case
    # case_number = 0
    # print(f'Case #{case_number}:')

    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise(e)


if __name__ == '__main__':
    test_get_non_exp_parent_and_index()

# Generated at 2022-06-25 23:19:18.817811
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 23:19:19.675415
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass



# Generated at 2022-06-25 23:19:22.926818
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:19:29.292298
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Set up context.
    some_ast_node = ast.Module()
    some_ast_node.body = [ast.ClassDef()]
    some_ast_node.body[0].body = [ast.FunctionDef()]
    some_ast_node.body[0].body[0].body = [ast.Expr()]

    target = some_ast_node.body[0].body[0].body[0].value

    result = get_closest_parent_of(some_ast_node, target, ast.FunctionDef)
    assert result == some_ast_node.body[0].body[0]

    result = get_closest_parent_of(some_ast_node, target, ast.ClassDef)
    assert result == some_ast_node.body[0]


# Generated at 2022-06-25 23:19:33.600270
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_ast = ast.parse('module')
    get_non_exp_parent_and_index(module_ast, module_ast)

    body = ast.parse('module').body[0]
    module, index = get_non_exp_parent_and_index(module_ast, body)

    assert index == 0
    assert isinstance(module, ast.Module)



# Generated at 2022-06-25 23:19:43.982328
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [a_s_t_0]
    a_s_t_1.body = [a_s_t_1]
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert isinstance(tuple_0[0], type(a_s_t_1))
    assert isinstance(tuple_0[1], int)
    tuple_0 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_1)

# Generated at 2022-06-25 23:19:52.148055
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    tuple_0 = (a_s_t_0, 0)
    tuple_1 = (tuple_0, module_0.Num())
    replace_at(tuple_1[0][1], tuple_1[0][0], tuple_1[1])
    a_s_t_1 = module_0.AST()
    tuple_2 = (a_s_t_1, 0)
    tuple_3 = (tuple_2, module_0.Num())
    replace_at(tuple_3[0][1], tuple_3[0][0], tuple_3[1])
    a_s_t_2 = module_0.AST()
    tuple_4 = (a_s_t_2, 0)

# Generated at 2022-06-25 23:19:52.857746
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

# Generated at 2022-06-25 23:20:01.866346
# Unit test for function get_parent
def test_get_parent():
    import typed_ast._ast3 as module_0
    # Prepare
    Mod_1 = module_0.Mod
    AST_2 = module_0.AST
    tuple_3 = (Mod_1, AST_2, AST_2)

    # Define target
    def target_function(tree, node):
        # Call the function
        return get_parent(tree, node)

    # Call the function
    result = target_function(tuple_3, tuple_3)

    # Verify
    assert result == tuple_3

    # Template
    def template(tree, node):
        pass

    assert func_template(template, ())



# Generated at 2022-06-25 23:20:09.160059
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass
    a_s_t_0 = module_0.AST()
    module_0.Module(body = [a_s_t_0])
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:20:19.287750
# Unit test for function replace_at
def test_replace_at():
    # insert_at(index, parent, nodes)
    # replace_at(index, parent, nodes)
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    print(tuple_0)
    index = tuple_0[1]
    parent = tuple_0[0]
    replace_at(index, parent, a_s_t_0)
    print(parent)


# Generated at 2022-06-25 23:20:22.589122
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_cases = [
        # TODO: add tests here.
    ]
    for test_case in test_cases:
        assert test_case() == "expected result"

# Generated at 2022-06-25 23:20:24.161339
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert find(test_case_0(), ast.AST) == [(a_s_t_0, 0)]

# Generated at 2022-06-25 23:20:27.114940
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    list_0 = [a_s_t_0]
    replace_at(0, a_s_t_0, list_0)



# Generated at 2022-06-25 23:20:36.730505
# Unit test for function get_parent
def test_get_parent():
    '''Tests if get_parent returns correct value.'''
    class_0 = module_0.ClassDef()
    function_0 = module_0.FunctionDef()
    module_0.Module().body.append(class_0)
    class_0.body.append(function_0)
    assert get_parent(module_0.Module(), function_0) == class_0
    class_1 = module_0.ClassDef()
    module_0.Module().body.append(class_1)
    assert get_parent(module_0.Module(), class_1) == module_0.Module()


# Generated at 2022-06-25 23:20:46.044911
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body = [a_s_t_1]
    a_s_t_2 = module_0.AST()
    a_s_t_0.targets = [a_s_t_2]
    a_s_t_3 = module_0.AST()
    a_s_t_2.elts = [a_s_t_3]
    a_s_t_4 = module_0.AST()
    a_s_t_4.ctx = module_0.Load()
    a_s_t_4.id = "A"

# Generated at 2022-06-25 23:20:50.500921
# Unit test for function replace_at
def test_replace_at():
    class TestModule(unittest.TestCase):
        def test_replace_at_0(self):
            test_case_0()
            assert True
    suite = unittest.TestLoader().loadTestsFromTestCase(TestModule)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-25 23:21:00.911178
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Build two trees
    # Test tree 1
    import typed_ast._ast3 as module_1
    a_s_t_1 = module_1.AST()
    a_s_t_1.body = [module_1.Expr(value=module_1.Name(id='x', ctx=module_1.Load()))]

# Generated at 2022-06-25 23:21:06.316926
# Unit test for function replace_at
def test_replace_at():
    import random
    test_pass = True
    for i in range(0,10):
        node = random.randint(0,3)
        parent = random.randint(0,3)
        nodes = random.randint(0,3)
        replace_at(node, parent, nodes)
    if test_pass:
        print('Test Pass')
    else:
        print('Test Fail')


# Generated at 2022-06-25 23:21:13.641307
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    assert get_parent(a_s_t_0, a_s_t_0) == a_s_t_0
    assert get_parent(module_0.AST(), module_0.AST()) == module_0.AST()


# Generated at 2022-06-25 23:21:15.240640
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0.AST()


# Generated at 2022-06-25 23:21:24.897855
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_ast_0 = get_closest_parent_of(module_0.AST(), module_0.AST(), module_0.AST)
    module_int_0 = find(module_0.AST(), module_0.AST)
    module_str_0 = get_parent(module_0.AST(), module_0.AST())
    module_str_1 = get_parent(module_0.AST(), module_0.AST(), False)
    find(module_0.AST(), module_0.AST)
    replace_at(module_ast_0, module_ast_0, module_ast_0)
    insert_at(module_int_0, module_ast_0, module_ast_0)
    get_non_exp_parent_and_index(module_ast_0, module_ast_0)
   

# Generated at 2022-06-25 23:21:33.154483
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    # Tests for function get_non_exp_parent_and_index
    module_0 = ast.Module([ast.FunctionDef('a', ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [], [], None, None)])
    tuple_0 = get_non_exp_parent_and_index(module_0, ast.FunctionDef('a', ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [], [], None, None))
    assert(isinstance(tuple_0[0], ast.Module))
    assert(isinstance(tuple_0[1], int))

    # Tests for function get_non_exp_parent_

# Generated at 2022-06-25 23:21:36.152932
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    result = get_closest_parent_of(a_s_t_0, a_s_t_0, _ast.FunctionDef)
    assert result == a_s_t_0

# Generated at 2022-06-25 23:21:39.347770
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Imports
    import typed_ast._ast3 as module_0

    # Unit tests
    test_case_0()  # test_case_0



# Generated at 2022-06-25 23:21:40.125419
# Unit test for function get_parent
def test_get_parent():
    assert(0)


# Generated at 2022-06-25 23:21:45.250828
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    tuple_1 = (a_s_t_0, 0)
    assert tuple_0 == tuple_1

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:21:52.448602
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    # a_s_t_0_0 is an AST node of type AST
    a_s_t_0_0 = module_0.AST()

    # a_s_t_0_1 is an AST node of type AST
    a_s_t_0_1 = module_0.AST()

    # a_s_t_0_2 is an AST node of type AST
    a_s_t_0_2 = module_0.AST()

    a_s_t_0_3 = module_0.AST()

    a_s_t_0_0.body = [a_s_t_0_1, a_s_t_0_2]
    a_s_t_0_1.body = [a_s_t_0_3]
    tuple_0 = get_non_exp

# Generated at 2022-06-25 23:21:55.929658
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    a_s_t_1 = module_0.Module()



# Generated at 2022-06-25 23:22:08.409629
# Unit test for function get_parent
def test_get_parent():
    """Test for function get_parent"""

    # Case 0: test for when 'parent' is an Attribute class
    test_case_0()

    # Case 1: test for when 'parent' is a Call class
    test_case_1()


import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:22:14.405314
# Unit test for function replace_at
def test_replace_at():
    a_s_t_1 = ast.Expression(ast.BinOp(ast.Constant(42), ast.Add(), ast.Constant(43)))
    a_s_t_2 = ast.Expression(ast.BinOp(ast.Constant(42), ast.Mult(), ast.Constant(43)))
    a_s_t_3 = get_parent(a_s_t_1, a_s_t_1)
    replace_at(0, a_s_t_3, a_s_t_2)


if __name__ == "__main__":
    test_case_0()
    test_replace_at()

# Generated at 2022-06-25 23:22:16.187886
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.Module()
    a_s_t_0 = module_0.body[0]
    ast.Module
    get_closest_parent_of(module_0, a_s_t_0, ast.AST)

# Generated at 2022-06-25 23:22:22.447304
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    get_parent(a_s_t_0, a_s_t_1)
    get_closest_parent_of(a_s_t_0, None, type)
    get_closest_parent_of(a_s_t_0, a_s_t_1, type)


# Generated at 2022-06-25 23:22:24.326511
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Ensure correct exception is raised
    with pytest.raises(NodeNotFound):
        test_case_0()

# Generated at 2022-06-25 23:22:28.791117
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # FIXME: better test
    a = ast.Module([])
    get_non_exp_parent_and_index(a, a)



# Generated at 2022-06-25 23:22:31.465914
# Unit test for function get_parent
def test_get_parent():
    ast_node = ast.parse('True').body[0]
    assert get_parent(ast_node, ast_node) == ast.parse('True')

# Generated at 2022-06-25 23:22:34.681424
# Unit test for function get_parent
def test_get_parent():
    print("Testing function get_parent")
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    get_parent(a_s_t_0, a_s_t_1, False)


# Generated at 2022-06-25 23:22:38.541289
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.parse('import sys')
    module_1 = ast.parse('import sys')
    a_s_t_0 = get_closest_parent_of(module_0, module_1, ast.Assign)


# Generated at 2022-06-25 23:22:43.555241
# Unit test for function get_parent
def test_get_parent():
    # input
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_1.attr = a_s_t_0
    # expected output
    a_s_t_2 = module_0.AST()
    # test call
    get_parent(a_s_t_1, a_s_t_0, False)
    assert a_s_t_1 == a_s_t_2

# Generated at 2022-06-25 23:23:02.085206
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    try:
        test_case_0()
    except NodeNotFound:
        pass

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:23:10.926158
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    # Apply the function to argument 'a_s_t_0'
    try:
        ret_0 = get_closest_parent_of(module_0.AST(), module_0.AST(), type_=ast.Module)
    except AssertionError as e:
        stk_0 = traceback.extract_tb(sys.exc_info()[2])
        file_0, line_0, func_0, text_0 = stk_0[-1]
        msg_0 = ('AssertionError: %s: file %s, line %s, in %s: %s' %
                 (type_0.__name__, file_0, line_0, func_0, text_0))
        raise AssertionError(msg_0)

# Generated at 2022-06-25 23:23:13.283446
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.BinOp()
    module_0.replace_at(1, [1, 2, 3], a_s_t_0)
    assert len([1, 2, 3]) == 3


# Generated at 2022-06-25 23:23:20.254634
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_0.body = (a_s_t_1,)
    a_s_t_2 = module_0.AST()
    a_s_t_1.body = (a_s_t_2,)
    a_s_t_3 = module_0.AST()
    a_s_t_2.body = (a_s_t_3,)
    a_s_t_4 = module_0.AST()
    a_s_t_3.body = (a_s_t_4,)
    a_s_t_5 = module_0.AST()

# Generated at 2022-06-25 23:23:29.251454
# Unit test for function get_parent
def test_get_parent():
    from hoplang.parser import parse
    from . import refactor

    code = '''
for i in range(10):
    print(i)
    print(i)
    if i > 10:
        break

for i in range(10):
    print(i)
    print(i)
    if i > 10:
        break
    '''
    tree = parse(code)

    for node in ast.walk(tree):
        if isinstance(node, ast.Print):
            parent = get_parent(tree, node)
            assert isinstance(parent, ast.While), 'Parent is not While'

            parent = get_parent(tree, node, rebuild=True)
            assert isinstance(parent, ast.While), 'Parent is not While'

    assert get_parent(tree, tree) == None
    assert get_

# Generated at 2022-06-25 23:23:37.272389
# Unit test for function get_closest_parent_of

# Generated at 2022-06-25 23:23:45.430045
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = list([a_s_t_0])
    a_s_t_2 = module_0.AST()
    a_s_t_2.body = list([a_s_t_1])
    a_s_t_3 = module_0.AST()
    a_s_t_3.body = list([a_s_t_2])
    a_s_t_4 = module_0.AST()
    a_s_t_4.body = list([a_s_t_3])
    a_s_t_5 = module_0.AST()

# Generated at 2022-06-25 23:23:53.608347
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-25 23:23:57.117203
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_parent(a_s_t_0, a_s_t_0, True)
    assert tuple_0 == a_s_t_0


# Generated at 2022-06-25 23:24:04.046283
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    test_case_0()
    a_s_t_1 = module_0.AST()
    tuple_1 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_1)
    a_s_t_2 = module_0.AST()
    tuple_2 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_2)

