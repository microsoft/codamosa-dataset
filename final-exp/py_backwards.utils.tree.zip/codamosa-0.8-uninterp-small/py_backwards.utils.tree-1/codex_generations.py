

# Generated at 2022-06-25 23:14:36.063476
# Unit test for function replace_at

# Generated at 2022-06-25 23:14:39.024338
# Unit test for function find
def test_find():
    # Define AST as simple assignment
    ast = ast.parse("x = 5")

    # Define type as assignment statement
    typ = ast.Assign
    
    # Verify results
    assert find(ast, typ) == (ast.body[0],)

# Generated at 2022-06-25 23:14:47.818719
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as ast
    import logging

    module = ast.parse(""" 
    def foo(x: int, y: str) -> int:
        z = x // 2
        z = z + 1
        z = z / y
    """)

    def test_get_non_exp_parent_and_index(node, parent, index):
        non_exp_parent, non_exp_index = get_non_exp_parent_and_index(module, node)
        assert parent, non_exp_parent
        assert index == non_exp_index

    test_get_non_exp_parent_and_index(module.body[0].body[0].value, module.body[0].body, 0)

# Generated at 2022-06-25 23:14:48.913422
# Unit test for function find
def test_find():
    assert list(find(test_case_0, int)) == [int_0]

# Generated at 2022-06-25 23:14:58.602105
# Unit test for function find
def test_find():
    tree = None
    tree_0 = None
    tree_1 = None
    ast_0 = None
    ast_1 = None
    ast_2 = None
    ast_3 = None
    ast_4 = None
    ast_5 = None
    ast_6 = None
    ast_7 = None
    ast_8 = None
    ast_9 = None
    ast_10 = None
    ast_11 = None
    ast_12 = None
    ast_13 = None
    ast_14 = None
    ast_15 = None
    ast_16 = None
    ast_17 = None
    ast_18 = None
    ast_19 = None
    ast_20 = None
    ast_21 = None
    ast_22 = None
    ast_23 = None
    ast_24 = None

# Generated at 2022-06-25 23:15:01.329987
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    int_0 = 1
    a_s_t_0 = None
    get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:15:09.344185
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class CallSample(ast.AST):
        pass

    class CallTuple(ast.AST):
        pass

    class Call(ast.AST):
        pass

    class Attribute(ast.AST):
        pass

    a = Attribute()
    c = Call()
    a.value = c
    c.func = a
    c.args = CallTuple()
    t = CallTuple()
    t.elts = [CallSample()]
    c.args = t
    d = get_non_exp_parent_and_index(c, a)
    assert callable(d)

# Generated at 2022-06-25 23:15:10.237879
# Unit test for function get_closest_parent_of

# Generated at 2022-06-25 23:15:20.028915
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..models.ast import *

    a = Assign.from_parsed(str_to_ast("""
    a = 0
    """))
    b = Assign.from_parsed(str_to_ast("""
    b = 45
    """))
    c = Assign.from_parsed(str_to_ast("""
    c = 12
    """))
    print(get_non_exp_parent_and_index(a, b.ast))
    d = Add.from_parsed(str_to_ast("""
    c + d
    """))
    print(get_non_exp_parent_and_index(d, d.ast))
    e = Add.from_parsed(ast_to_str(d.ast))

# Generated at 2022-06-25 23:15:23.923866
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("while(True): print(0)")
    while_node = tree.body[0]
    print_node = while_node.body[0]
    node, index = get_non_exp_parent_and_index(tree, print_node)
    assert type(node) is ast.While
    assert index == 0

# Generated at 2022-06-25 23:15:27.674248
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-25 23:15:31.481591
# Unit test for function find
def test_find():
    test_case_0()
    test_ast = ast.parse(inspect.getsource(test_case_0))
    result = find(test_ast, ast.Store)
    assert isinstance(result, Iterable)
    result = next(result)
    assert isinstance(result, ast.Store)


# Generated at 2022-06-25 23:15:33.660695
# Unit test for function find
def test_find():
    mod = ast.parse(test_case_0.__doc__)
    for node in find(mod, ast.FunctionDef):
        print(node.name)


# Generated at 2022-06-25 23:15:36.953104
# Unit test for function find
def test_find():
    ast_tree = ast.parse(test_case_0.__doc__)
    ast_int_0 = find(ast_tree, ast.Num).__next__()
    assert ast_int_0.n == 0


# Generated at 2022-06-25 23:15:41.143927
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("import sys")
    expected_parent = ast.Module(body=[ast.Import(names=[ast.alias(
        name='sys', asname=None)])])
    assert get_parent(tree, ast.alias(name='sys', asname=None), True) == expected_parent


# Generated at 2022-06-25 23:15:41.684948
# Unit test for function get_parent

# Generated at 2022-06-25 23:15:47.852184
# Unit test for function get_parent
def test_get_parent():
    # Testing case 0
    source_code = inspect.getsource(test_case_0)
    module = ast.parse(source_code)
    try:
        nodes = find(module, ast.Assign)
        get_parent(module, [])
    except:
        traceback.print_exc()
        print('pass test_case_0')
    else:
        assert False, 'fail test_case_0'
    # End of testing case 0



# Generated at 2022-06-25 23:15:50.464680
# Unit test for function find
def test_find():
    a = "a"
    b = "b"
    c = "c"

    tuple_0 = (a, b, c)
    test_list = [tuple_0]
    func = test_case_0

    print(find(func, tuple))


# Generated at 2022-06-25 23:16:03.889415
# Unit test for function get_parent
def test_get_parent():
    # For a typical test case, first use ast.parse to turn the python source
    # code into ast, then use get_parent to get the parent of the passed node
    # ast.parse will return an ast Module. for a normal program, the first
    # node at the top level of the Module is a ast.FunctionDef node.
    # get_parent will return the FunctionDef node for any node within the function

    tree = ast.parse(test_case_0.__doc__)
    test_int_0 = ast.copy_location(ast.Num(0), ast.parse('int_0 = 0').body[0].value)
    parent = get_parent(tree, test_int_0)
    assert isinstance(parent, ast.Assign)
    assert isinstance(parent.targets[0], ast.Name)
    assert parent

# Generated at 2022-06-25 23:16:14.051831
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert(test_case_0.__code__.co_varnames[0] == 'int_0')
    assert(ast.dump(test_case_0.__code__) == '<code object test_case_0 at 0x7f9bcd9e69d0, file "<disassembly>", line 1>')
    assert(ast.dump(ast.parse(open(r'../../test.py').read())) == 'Module(body=[FunctionDef(name="test_case_0", args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Num(n=0)), Return(value=None)], decorator_list=[], returns=None)])')

# Generated at 2022-06-25 23:16:23.355964
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(textwrap.dedent(inspect.getsource(test_case_0)))
    node = find(tree, ast.Assign).__next__()
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert(isinstance(parent, ast.Module))
    assert(index == 0)


# Generated at 2022-06-25 23:16:25.492801
# Unit test for function get_parent
def test_get_parent():
    # TODO:
    # Test if there is a non-Exp parent
    # Test if the child is indeed in the body of the parent
    pass

# Generated at 2022-06-25 23:16:37.105932
# Unit test for function find
def test_find():
    # Creation of a test.py file
    test_file = open("test.py", "w+")
    test_file.write("int_0 = 0\n")
    test_file.close()
    # Opening of the file test.py
    with open("test.py", "r") as file:
        # Parsing of the file test.py
        test_parse_file = ast.parse(file.read())
        correct_result = [ast.Expression(body=ast.NameConstant(value=0)), ast.Name(id='int_0', ctx=ast.Store())]
        test_result = list(find(test_parse_file, ast.Num))
        assert(test_result == correct_result)


# Generated at 2022-06-25 23:16:45.215015
# Unit test for function find
def test_find():
    with open(os.path.join(os.path.dirname(os.path.dirname(
            os.path.realpath(__file__))), 'examples', 'factorial.py')) as f:
        tree = ast.parse(f.read(), filename='factorial.py')
    assert list(find(tree, ast.Assign)) == [ast.Assign(targets=[ast.Name(id='n', ctx=ast.Store())], value=ast.Num(n=5))]


# Generated at 2022-06-25 23:16:47.954331
# Unit test for function find
def test_find():
    tree = ast.parse('int_0 = 5')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1


# Generated at 2022-06-25 23:16:53.097013
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert MATCHER.match('test_case_0', ast.parse(inspect.getsource(test_case_0))) == True
    tree = ast.parse(inspect.getsource(test_case_0))
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0] and index == 0


# Generated at 2022-06-25 23:16:53.943358
# Unit test for function get_parent
def test_get_parent():
    import astor


# Generated at 2022-06-25 23:17:01.846543
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test with a simple function definition
    test_ast = ast.parse("""def test_case_0():\n    int_0 = 0""")
    assert(get_non_exp_parent_and_index(test_ast, test_ast.body[0]) ==
           (test_ast, 0))

    test_ast = ast.parse("""def test_case_0():\n    int_0 = 0\n def test_case_1():\n   print(int_0)""")
    assert(get_non_exp_parent_and_index(test_ast, test_ast.body[1]) ==
           (test_ast, 1))


# Generated at 2022-06-25 23:17:06.532629
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('x = "hello world"')
    node = tree.body[0].value
    type_ = type(node)
    print('type_ = ', str(type_))
    node = get_closest_parent_of(tree, node, type_)
    print('parent_node = ', ast.dump(node))

if __name__ == '__main__':
    test_get_closest_parent_of()

# Generated at 2022-06-25 23:17:09.898170
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('int_0 = 0').body[0]
    body = get_non_exp_parent_and_index(tree, tree.value)[0]
    # print(body)
    assert isinstance(body, ast.Module)


# Generated at 2022-06-25 23:17:16.463982
# Unit test for function replace_at
def test_replace_at():
    from ..transformations import ConditionalExpressionTransformer
    from ..transformations import AssignmentTransformer
    from ..transformations import FunctionTransformer
    cet = ConditionalExpressionTransformer()
    cet.visit(ast.parse("b if a else c", mode="eval"))


# Generated at 2022-06-25 23:17:26.058908
# Unit test for function find
def test_find():
    class Test(object):
        def __init__(self, test_attr: int):
            self.test_attr = test_attr

    var_0 = None
    var_1 = []
    var_2 = {1:3, 2:4}
    var_3 = Test(100)
    var_4 = ast.parse('a = 1')
    var_5 = ast.parse('def test(a):\n    print(a)\n    return a')
    assert find(var_0, int) != None
    assert find(var_1, int) != None
    assert find(var_2, int) != None
    assert find(var_3, int) != None
    assert find(var_4, ast.AST) != None
    assert find(var_5, ast.AST) != None

# Generated at 2022-06-25 23:17:31.954156
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    var_0 = ast.parse('a = 0')
    a: ast.Module = get_non_exp_parent_and_index(var_0, var_0)[0]
    assert type(a) == ast.Module

    var_0 = ast.parse('a = 0').body[0]
    a: ast.Assign = get_non_exp_parent_and_index(var_0, var_0)[0]
    assert type(a) == ast.Assign


# Generated at 2022-06-25 23:17:39.883664
# Unit test for function find
def test_find():
    class_1 = ast.ClassDef(
        name='AstTest',
        bases=[],
        body=[ast.AnnAssign(
            target=ast.Name(id='a', ctx=ast.Load()),
            annotation=ast.Name(id='int', ctx=ast.Load()),
            value=ast.Num(n=10),
            simple=2
        )],
        decorator_list=[],
        keywords=[]
    )

    assert(len(list(find(class_1, ast.AnnAssign))) == 1)


# Generated at 2022-06-25 23:17:49.331424
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    var_1 = None
    var_2 = ast.Name(id='var_1', ctx=ast.Load())
    var_3 = ast.BinOp(left=var_2, op=ast.Add(), right=ast.Name(id='var_2', ctx=ast.Load()))
    var_4 = ast.Store()
    var_5 = ast.Name(id='var_2', ctx=ast.Store())
    var_6 = ast.Assign(targets=[var_5], value=var_3)
    var_7 = ast.Print(dest=None, values=[var_3], nl=True)
    var_8 = ast.Module(body=[var_1, var_6, var_7])

# Generated at 2022-06-25 23:17:58.204834
# Unit test for function find
def test_find():
    # Test case 0
    def test_case0():
        var_0 = None
        var_1 = var_0 = find(var_0, list)
        return var_1

    # Test case 1
    def test_case1():
        var_0 = None
        var_1 = var_0 = find(var_0, list)
        return var_1

    # Test case 2
    def test_case2():
        var_0 = None
        var_1 = var_0 = find(var_0, list)
        return var_1

    # Test case 3
    def test_case3():
        var_0 = None
        var_1 = var_0 = find(var_0, list)
        return var_1

    # Test case 4

# Generated at 2022-06-25 23:18:02.796904
# Unit test for function find
def test_find():
    class_0 = ast.ClassDef('SampleClass')
    assert find(class_0, ast.ClassDef) is not None


# Generated at 2022-06-25 23:18:09.227912
# Unit test for function find
def test_find():
    import types
    import ast
    #Function definition
    ADD = 0

    #Class to represent add instruction
    class AddInst:
        def __init__(self, lhs, rhs, op):
            self.type = 'Inst'
            self.lhs = lhs
            self.rhs = rhs
            self.op = op

    #Class to represent var
    class Var:
        def __init__(self, name, val):
            self.type = 'Var'
            self.name = name
            self.val = val

    #Class to represent register
    class Reg:
        def __init__(self, name):
            self.type = 'Reg'
            self.name = name

    #Class to represent constant

# Generated at 2022-06-25 23:18:10.205221
# Unit test for function find
def test_find():
    find('', None)


# Generated at 2022-06-25 23:18:16.744852
# Unit test for function find
def test_find():
    print('############### TESTING FUNCTION: FIND ###############')
    node = ast.parse('def foo():\n    a=a+b\n\nprint(a)')
    funcs = find(node, ast.FunctionDef)
    print([func.name for func in funcs])
    print('################### END OF TEST ################')

# Generated at 2022-06-25 23:18:24.884717
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module = ast.parse('x = 1')
    function = get_closest_parent_of(module, module.body[0].value, ast.FunctionDef)
    assert function is None

# Generated at 2022-06-25 23:18:28.881465
# Unit test for function find
def test_find():
    root = ast.parse("y=x+1")
    assign = find(root, ast.Assign).__next__()
    assert(isinstance(assign, ast.Assign))
    value = find(assign, ast.BinOp).__next__()
    assert(isinstance(value, ast.BinOp))


# Generated at 2022-06-25 23:18:31.540910
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_case_0()
    try:
        test_case_1()
    except NodeNotFound:
        pass
    test_case_2()


# Generated at 2022-06-25 23:18:37.542912
# Unit test for function find

# Generated at 2022-06-25 23:18:44.439483
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("a = 1;a = a;")
    node_list = tree.body
    node_1 = tree.body[1]
    node_0 = tree.body[0]
    res = get_non_exp_parent_and_index(tree, node_1)
    assert(res == (node_list, 1))
    res = get_non_exp_parent_and_index(tree, node_0)
    assert(res == (node_list, 0))


# Generated at 2022-06-25 23:18:48.563113
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code_str = """
    a = 3
    b = 5
    """
    tree = ast.parse(code_str)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent is tree
    assert index == 0


# Generated at 2022-06-25 23:18:49.532504
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

# Generated at 2022-06-25 23:18:58.600273
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test case 1
    source = ast.parse("a = 1")
    node = source.body[0]
    parent, index = get_non_exp_parent_and_index(source, node)
    # Parent is a Module
    assert isinstance(parent, ast.Module)
    # index is 0
    assert index == 0

    # Test case 2
    source = ast.parse("a = 1\nb = 2")
    node = source.body[1]
    parent, index = get_non_exp_parent_and_index(source, node)
    # Parent is a Module
    assert isinstance(parent, ast.Module)
    # index is 1
    assert index == 1

    # Test case 3
    source = ast.parse("a = 1\nif a == 1:\n    b = 2\ne = 3")

# Generated at 2022-06-25 23:18:59.960466
# Unit test for function get_parent

# Generated at 2022-06-25 23:19:05.300267
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class_0 = ast.ClassDef(
        name= 'Class0',
        body=[
            ast.Pass()
        ],
        decorator_list=[],
    )
    body_0 = get_non_exp_parent_and_index(class_0, class_0.body[0])
    assert body_0 == (class_0, 0)
    test_case_0()


# Generated at 2022-06-25 23:19:14.146280
# Unit test for function find
def test_find():
    if __name__ == '__main__':
        import pytest
        pytest.main(['/project/home/pycharm/PycharmProjects/gumtree/src/units.py'])
    return [pytest.main, pytest.main]


# Generated at 2022-06-25 23:19:24.323936
# Unit test for function find
def test_find():

    # Test case 1: Check that the ast.arguments node is the only one matching
    # the ast.arguments type.
    var_0 = ast.parse('def f(): pass')
    var_1 = find(var_0, ast.arguments)

    try:
        assert(len(list(var_1)) == 1)
    except AssertionError:
        print("AssertionError: assert(len(list(var_1)) == 1)")
    try:
        assert(isinstance(list(var_1)[0], ast.arguments))
    except AssertionError:
        print("AssertionError: assert(isinstance(list(var_1)[0], ast.arguments))")

    # Test case 2: Check that there are two ast.Name nodes in the function.

# Generated at 2022-06-25 23:19:31.116702
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Add unit test here
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    try:
        tuple_0 = get_non_exp_parent_and_index(var_0, var_1)
    except NodeNotFound:
        var_2 = NodeNotFound
    else:
        var_4 = tuple_0
        var_5 = var_4[0]
        var_6 = var_5.body
        var_7 = var_6[0]


# Generated at 2022-06-25 23:19:32.036155
# Unit test for function find

# Generated at 2022-06-25 23:19:41.846828
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    var_1 = ast.Module([ast.Expr(ast.parse('t = 0')),
                        ast.Assign([ast.Name('t', ast.Store())],
                                   ast.parse('a = 0'))],
                       type_ignores=[])
    var_2 = ast.Module([ast.Expr(ast.parse('t = 0')),
                        ast.Assign([ast.Name('t', ast.Store())],
                                   ast.parse('a = 0'))],
                       type_ignores=[])
    var_3 = ast.Module([ast.Expr(ast.parse('t = 0')),
                        ast.Assign([ast.Name('t', ast.Store())],
                                   ast.parse('a = 0'))],
                       type_ignores=[])

# Generated at 2022-06-25 23:19:50.623309
# Unit test for function get_parent
def test_get_parent():
    var_0 = ast.Module(body= [ ast.Expr(value= ast.Name(id= 'a', ctx= ast.Load())) ])
    var_1 = ast.Load()
    var_1.parent = var_0.body[0].value
    var_0.body[0].value.parent = var_0.body[0]
    var_0.body[0].parent = var_0
    var_0.parent = None
    var_2 = ast.Load()
    var_2.parent = var_0.body[0].value
    var_3 = ast.Module()
    var_3.parent = None
    var_4 = ast.Module()
    var_4.parent = None

# Generated at 2022-06-25 23:19:51.876740
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-25 23:20:02.343439
# Unit test for function find
def test_find():
    """Test find function"""
    tree = ast.parse("""
for i in range(10):
    print(i)
    a = abs(i)
    b = 0

    if a > 5:
        print(a)

    a = 0
    if b == 0:
        print(b)

    else:
        print(a)

    if i == 5:
        break

    continue

while i != 0:
    print(i)
    i -= 1
""")

    # Test find for FunctionDef
    for funcdef_0 in find(tree, ast.FunctionDef):
        pass

    # Test find for For
    for for_0 in find(tree, ast.For):
        pass

    # Test find for If
    for if_0 in find(tree, ast.If):
        pass

    # Test

# Generated at 2022-06-25 23:20:04.582943
# Unit test for function find
def test_find():
    assert find(get_parent(None, None), ast.AST)
    assert find(get_parent(None, None), ast.AST)


# Generated at 2022-06-25 23:20:08.059482
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    x = ast.parse("""\
while True:
    pass
""")
    body = x.body[0]
    (parent, index) = get_non_exp_parent_and_index(x, body)
    assert parent == x
    assert index == 0

# Generated at 2022-06-25 23:20:25.958954
# Unit test for function find

# Generated at 2022-06-25 23:20:33.496240
# Unit test for function find
def test_find():
    """
    def foo(x):
        y = x**2
        return y
        print(y)
    """
    tree: ast.AST = ast.fix_missing_locations(ast.parse((
        'def foo(x):\n'
        '    y = x ** 2\n'
        '    return y\n'
        '    print(y)\n'
        )))

    node_tuple = get_closest_parent_of(tree, tree.body[0].body[2],
                                       ast.FunctionDef)
    assert isinstance(node_tuple, ast.FunctionDef)

    node = get_parent(tree, tree.body[0].body[2])
    assert isinstance(node, ast.FunctionDef)


# Generated at 2022-06-25 23:20:38.950000
# Unit test for function get_parent
def test_get_parent():
    a = ast.parse('x = x + 1')
    # Get the parent of 'x + 1'
    assert isinstance(get_parent(a, a.body[0].value), ast.Assign)
    # Get the parent of 'x = x + 1'
    assert isinstance(get_parent(a, a.body[0]), ast.Module)


# Generated at 2022-06-25 23:20:46.530173
# Unit test for function find
def test_find():
    with pytest.raises(NodeNotFound):
        raise NodeNotFound('Parent for {} not found'.format('node'))


# Generated at 2022-06-25 23:20:57.399815
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import asttokens
    from astor import to_source
    from fissix.pytree import Node
    from fissix import fixer_base, fixer_util
    atok = asttokens.ASTTokens(test_case_0, parse=True)
    var0 = atok.tree.body[0].value.elts[0]
    assert isinstance(var0, Node)

    # No parent
    var0_parent = get_parent(atok.tree, var0)
    assert var0_parent is None

    # Expected tuple
    tuple_0 = get_non_exp_parent_and_index(atok.tree, var0)
    assert isinstance(tuple_0, tuple)

    # Expected tuple with (parent, index)
    _parent, index = get_non_exp

# Generated at 2022-06-25 23:20:57.960427
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-25 23:21:02.589566
# Unit test for function find
def test_find():
    import ast
    ast_tree = ast.parse("\n# In[1]:\n1 + 1")
    for node in find(ast_tree, ast.Num):
        assert(node.n == 1)

# Test case for function get_non_exp_parent_and_index

# Generated at 2022-06-25 23:21:05.690599
# Unit test for function find
def test_find():
    node = ast.parse('a = 1\nb = f(1)\n').body
    assert [node[0]] == find(node, ast.Assign)
    assert node == find(node, ast.Module)
    assert node == find(node, ast.AST)

# Generated at 2022-06-25 23:21:08.207429
# Unit test for function find
def test_find():
    tree = ast.parse('''a = 10\n''')
    result = list(find(tree, ast.Assign))
    assert len(result) == 1 and result[0].targets[0].id == 'a'



# Generated at 2022-06-25 23:21:12.079759
# Unit test for function find
def test_find():
    import ast_builder as ab
    import typed_ast.ast3 as ast

    code = '''
    a = [1, 2]
    '''

    tree = ab.ast_parse(code)

    results = find(tree, ast.ListComp)

    assert len(list(results)) == 0

    results = find(tree, ast.List)

    assert len(list(results)) == 1

    results = find(tree, ast.Str)

    assert len(list(results)) == 0

# Generated at 2022-06-25 23:21:36.406992
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-25 23:21:39.571528
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

if __name__ == '__main__':
    test_get_non_exp_parent_and_index()
    print('passed.')

# Generated at 2022-06-25 23:21:43.848058
# Unit test for function find
def test_find():
    tree = ast.parse("x = 1 + 1")
    result = find(tree, ast.Assign)
    result = list(result)
    for e in result:
        if not isinstance(e, ast.Assign):
            return False
    return True



# Generated at 2022-06-25 23:21:46.377411
# Unit test for function get_parent
def test_get_parent():
    test = ast.parse("def foo():\n    x = 1")
    assert get_parent(test, test.body[0].body[0]).name == "FunctionDef"


# Generated at 2022-06-25 23:21:47.073725
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-25 23:21:53.325633
# Unit test for function find
def test_find():
    var = None
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None

# Generated at 2022-06-25 23:21:56.694571
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse(
        """
if a:
  b
"""
    )
    test_node = tree.body[0]

    assert get_parent(tree, test_node) is tree



# Generated at 2022-06-25 23:21:59.470924
# Unit test for function get_parent
def test_get_parent():
    test_tree = ast.parse("data = 3 + 1")
    test_node = test_tree.body[0]
    assert get_parent(test_tree, test_node) == test_tree


# Generated at 2022-06-25 23:22:09.101874
# Unit test for function find
def test_find():
    var_1 = ast.parse("1")
    var_2 = ast.parse("def foo():\n    pass")
    var_3 = ast.parse("def foo():\n    def bar():\n        pass")
    var_4 = ast.parse("import numpy as np")
    var_5 = ast.parse("def foo():\n    def bar():\n        def baz():\n            pass")

    var_6 = ast.parse("def foo():\n    pass")
    var_7 = ast.parse("def foo():\n    def bar():\n        pass")
    var_8 = ast.parse("import numpy as np")
    var_9 = ast.parse("def foo():\n    def bar():\n        def baz():\n            pass")

    var_10 = None

    var

# Generated at 2022-06-25 23:22:21.684017
# Unit test for function get_parent
def test_get_parent():

    # Unit test for function get_parent, case 0
    def case_0():
        var_0 = ast.parse("import pandas as pd")
        var_1 = var_0.body[0]
        tuple_0 = get_parent(var_0, var_1)
        # AssertionError
        assert_equal(tuple_0, None);
    
    # Unit test for function get_parent, case 1
    def case_1():
        var_0 = ast.parse("import pandas as pd")
        var_1 = var_0.body[0]
        tuple_0 = get_parent(var_0, var_1, True)
        # AssertionError
        assert_equal(tuple_0, var_0);
    
    case_0()
    case_1()



# Generated at 2022-06-25 23:24:17.197255
# Unit test for function get_parent
def test_get_parent():
    # Test case 0
    var_0 = ast.parse("""
        def foo():
            pass
        """)
    var_1 = ast.FunctionDef()
    var_2 = get_parent(var_0, var_1)
    var_3 = ast.Module()
    var_4 = ast.parse("""
        def foo():
            pass
        """)
    var_5 = ast.FunctionDef()
    var_6 = get_parent(var_4, var_5)
    assert var_2 == var_6


# Generated at 2022-06-25 23:24:20.215945
# Unit test for function find
def test_find():
    t = ast.parse('a = 1; b = 3; c = 5; d = 7; print(a+b*c)')
    var_0 = find(t, ast.Num)
    while (True):
        if (var_0 == None):
            break
        var_0 = var_0.__next__()


# Generated at 2022-06-25 23:24:20.670519
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False

# Generated at 2022-06-25 23:24:21.324819
# Unit test for function find
def test_find():
    return


# Generated at 2022-06-25 23:24:28.005684
# Unit test for function find
def test_find():
    # Recursive function call
    def f(a, b):
        return f(a-1, b) * b

    # Global variable assign
    var_0 = True

    # Local variable assign
    var_1 = False

    # Function definition
    func_0 = lambda a: a

    # Function call
    func_0(var_0)

    # Class definition
    class A:
        pass

    # Dictionary
    var_2 = {
        'A': A,
        'B': 1,
        'C': False,
        'D': lambda x: x,
        'E': lambda x, y: x*y,
        'F': lambda: var_0,
        'G': lambda a, b=1, c=0: a*b
    }

    # List comprehension