

# Generated at 2022-06-25 23:14:27.460557
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    replace_at(0, a_s_t_0, [])


# Generated at 2022-06-25 23:14:43.758496
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    import typed_ast._ast3 as module_1
    # Set up module 1
    class AST_0(module_1.AST):
        _fields = ('_fields', '_attributes')
        def __init__(self, _fields, _attributes):
            self._fields = _fields
            self._attributes = _attributes
            pass
        def attributes(self):
            return self._attributes
        def fields(self):
            fields = []
            for name in self._fields:
                fields.append(getattr(self, name))
            return tuple(fields)
        def _replace(self, _map=None):
            if _map is None:
                _map = {}

# Generated at 2022-06-25 23:14:46.872265
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    get_closest_parent_of(a_s_t_1, a_s_t_0, module_0.AST)

# Generated at 2022-06-25 23:14:48.913033
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, type(module_0.AST))


# Generated at 2022-06-25 23:14:58.562403
# Unit test for function replace_at
def test_replace_at():
    module_0 = ast.Module
    suite = ast.Suite
    function_definition = ast.FunctionDef
    parameters = ast.arguments
    result = ast.Return
    assignment = ast.Assign
    name_node = ast.Name
    int_node = ast.Num
    arg_node = ast.arg
    
    a_s_t_0 = module_0(body=[])
    a_s_t_1 = suite(body=[])
    a_s_t_2 = function_definition(name='main',args=parameters(args=[],vararg=None,kwonlyargs=[],kw_defaults=[],kwarg=None,defaults=[]),body=a_s_t_1,decorator_list=[],returns=None)

# Generated at 2022-06-25 23:15:01.593532
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    # None;



# Generated at 2022-06-25 23:15:07.576565
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test args
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    type_0 = module_0

    # Run function
    try:
        get_closest_parent_of(a_s_t_0, a_s_t_1, type_0)
    except SystemExit:
        raise SystemExit()

# Generated at 2022-06-25 23:15:13.097494
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert isinstance(a_s_t_0, module_0.AST)
    assert isinstance(tuple_0, tuple)


# Generated at 2022-06-25 23:15:15.766956
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:15:24.844416
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:15:30.666988
# Unit test for function find
def test_find():
    tree = module_0.AST()
    type_ = TypeVar('type_', bound=module_0.AST)
    assert find(tree, type_)


# Generated at 2022-06-25 23:15:31.520784
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()



# Generated at 2022-06-25 23:15:32.732482
# Unit test for function replace_at
def test_replace_at():
    test_case_0()

test_replace_at()

# Generated at 2022-06-25 23:15:35.972728
# Unit test for function get_parent
def test_get_parent():
    assert get_parent(test_case_0(), test_case_0()) == get_parent(test_case_0(), test_case_0(), rebuild = True)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:15:46.163586
# Unit test for function replace_at
def test_replace_at():
    from typing import Any, List
    from typed_ast import ast3 as ast
    from ast_helpers import get_parent, get_non_exp_parent_and_index, find, insert_at, replace_at, get_closest_parent_of
    from ast_helpers import test_case_0

    # test case 1
    a_s_t_0 = test_case_0()
    a_s_t_1 = test_case_0()
    a_s_t_2 = test_case_0()
    a_s_t_3 = test_case_0()
    a_s_t_4 = test_case_0()
    a_s_t_5 = test_case_0()
    a_s_t_6 = test_case_0()
    a_s_t

# Generated at 2022-06-25 23:15:57.627900
# Unit test for function find
def test_find():
    try:
        from typed_ast import ast3 as module_0
    except ImportError:
        return
    import mock
    import io
    try:
        from io import StringIO as module_1
    except ImportError:
        import io
        module_1 = io.StringIO
    try:
        from typing import List as module_2
    except ImportError:
        return
    import ast
    try:
        from typed_ast import ast3 as module_3
    except ImportError:
        return
    test_0_0 = module_0.AST()
    test_0_1 = module_0.AST()
    test_0_2 = module_0.AST()
    test_0_3 = module_0.AST()
    test_0_4 = module_0.AST()

# Generated at 2022-06-25 23:16:04.372668
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    assert isinstance(get_closest_parent_of(a_s_t_1, a_s_t_0, module_0.AST), module_0.AST)
    test_get_closest_parent_of()

import typed_ast._ast3 as module_0

a_s_t_2 = module_0.AST()


# Generated at 2022-06-25 23:16:16.086655
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # a_s_t_0 should be assigned to the instance a_s_t_0 of module_0.AST
    a_s_t_0 = module_0.AST()
    # a_s_t_1 should be assigned to the instance a_s_t_1 of module_0.AST
    a_s_t_1 = module_0.AST()
    # a_s_t_2 should be assigned to the instance a_s_t_2 of module_0.AST
    a_s_t_2 = module_0.AST()
    # a_s_t_3 should be assigned to the instance a_s_t_3 of module_0.AST
    a_s_t_3 = module_0.AST()
    # _parents should be assigned to the instance _parents of WeakKeyDictionary
   

# Generated at 2022-06-25 23:16:19.466668
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    x = module_0.AnnAssign()


# Generated at 2022-06-25 23:16:25.123718
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    # Expectation from function
    expected_value_0 = (a_s_t_0, 1)

    actual_value_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

    assert expected_value_0 == actual_value_0



# Generated at 2022-06-25 23:16:38.823744
# Unit test for function find
def test_find():
    module_0.get_parent(module_0.tree, module_0.node, module_0.rebuild)
    module_0.get_non_exp_parent_and_index(module_0.tree, module_0.node)
    module_0.find(module_0.tree, module_0.type)
    module_0.insert_at(module_0.index, module_0.parent, module_0.nodes)
    module_0.replace_at(module_0.index, module_0.parent, module_0.nodes)
    module_0.get_closest_parent_of(module_0.tree, module_0.node, module_0.type)

# Generated at 2022-06-25 23:16:43.635483
# Unit test for function get_parent
def test_get_parent():
    a_s_t_1 = ast.Name('a', ast.Load())
    a_s_t_2 = ast.Module(body=[a_s_t_1])
    test_case_0()
    assert get_parent(a_s_t_2, a_s_t_1) == a_s_t_2


# Generated at 2022-06-25 23:16:53.459559
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    r_s_t_0 = module_0.Return()
    d_s_t_1 = module_0.Name('a', module_0.Store())
    module_0.copy_location(d_s_t_1, r_s_t_0)
    r_s_t_0.value = d_s_t_1
    f_s_t_2 = module_0.FunctionDef('f', [], [], [], [], None, [r_s_t_0])
    module_0.copy_location(f_s_t_2, r_s_t_0)
    f_s_t_2.lineno = 1
    f_s_t_2.col_offset = 0

# Generated at 2022-06-25 23:17:02.709669
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    mod1 = ast.Module()
    mod1._fields = [] # type: ignore
    mod1.lineno = 1
    mod1.col_offset = 0
    mod1.body = [ast.Expr()] # type: ignore
    mod1.body[0].lineno = 1
    mod1.body[0].col_offset = 4
    mod1.body[0].value = test_case_0() # type: ignore
    mod1.body[0].value._fields = [] # type: ignore
    mod1.body[0].value.lineno = 1
    mod1.body[0].value.col_offset = 8
    ast1 = mod1
    result = get_closest_parent_of(ast1, mod1.body[0].value, module_0.AST)
    assert result.lin

# Generated at 2022-06-25 23:17:11.363309
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()

    a_s_t_0.body = [a_s_t_1, a_s_t_2, a_s_t_3]
    a_s_t_0.body = a_s_t_0.body
    a_s_t_1.body = [a_s_t_2]
    a_s_t_1.body = a_s_t_1.body
    a_s_t_1.body.append(a_s_t_3)

# Generated at 2022-06-25 23:17:15.147961
# Unit test for function find
def test_find():
    e_s_t_0 = find(a_s_t_0, type_=type(module_0.AST()))
    assert e_s_t_0 == None
    
    

# Generated at 2022-06-25 23:17:17.996892
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    assert find(a_s_t_0, module_0.AST) == [a_s_t_0]


# Generated at 2022-06-25 23:17:27.037783
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = test_case_0()
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [module_0.AST()]
    a_s_t_2 = module_0.AST()
    a_s_t_1.body.append(a_s_t_2)
    a_s_t_3 = module_0.AST()
    a_s_t_2.body = [a_s_t_3]
    a_s_t_4 = module_0.AST()
    a_s_t_3.body = [a_s_t_4]
    a_s_t_5 = module_0.AST()

# Generated at 2022-06-25 23:17:29.216666
# Unit test for function get_parent
def test_get_parent():
    assert get_parent(a_s_t_0, a_s_t_0) == a_s_t_0


# Generated at 2022-06-25 23:17:39.466817
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3 as a_s_t
    a_s_t_1 = a_s_t.Module()
    assert len(a_s_t_1.body) == 0
    assert (a_s_t_1.body == [])
    a_s_t_2 = a_s_t.FunctionDef()
    a_s_t_3 = a_s_t.FunctionDef()
    a_s_t_4 = a_s_t.FunctionDef()
    insert_at(0, a_s_t_1, a_s_t_2)
    assert len(a_s_t_1.body) == 1
    insert_at(1, a_s_t_1, [a_s_t_3, a_s_t_4])

# Generated at 2022-06-25 23:17:48.466458
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    try:
        test_case_0()
    except:
        import traceback
        traceback.print_exc()
        return False

    return True


# Generated at 2022-06-25 23:17:56.385868
# Unit test for function find
def test_find():
    a_s_t_1 = module_0.Module()
    a_s_t_2 = module_0.FunctionDef()
    a_s_t_1.body.append(a_s_t_2)
    a_s_t_3 = module_0.arguments()
    a_s_t_2.args = a_s_t_3
    a_s_t_2.body.append(module_0.Expr())
    a_s_t_2.body.append(module_0.Expr())
    a_s_t_4 = module_0.Expr()
    a_s_t_2.body.append(a_s_t_4)
    r_1 = find(a_s_t_1, module_0.Expr)
    a_s

# Generated at 2022-06-25 23:18:07.451466
# Unit test for function replace_at
def test_replace_at():
    print("Testing replace_at:", end="")
    # Replace element in a list with another element.
    l = ["a", "b", "c", "d" ]
    replace_at(0, l, "e")
    assert(l == ["e", "b", "c", "d" ])
    # Replace element in a list with two elements.
    l = ["a", "b", "c", "d" ]
    replace_at(0, l, ["e", "f"])
    assert(l == ["e", "f", "b", "c", "d" ])
    # Replace element in a list with no elements.
    l = ["a", "b", "c", "d" ]
    replace_at(0, l, [])
    assert(l == ["b", "c", "d" ])


# Generated at 2022-06-25 23:18:08.392669
# Unit test for function replace_at
def test_replace_at():
    pass


# Generated at 2022-06-25 23:18:11.816896
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test exception is raised
    a_s_t_2 = module_0.AST()
    with pytest.raises(NodeNotFound):
        get_non_exp_parent_and_index(a_s_t_2, a_s_t_2)


# Generated at 2022-06-25 23:18:13.442809
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert True

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:18:17.806735
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    assert get_parent(a_s_t_0, a_s_t_0) == None


# Generated at 2022-06-25 23:18:25.102273
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    print('Running test for function get_closest_parent_of')

    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [a_s_t_0]
    print(get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST))



# Generated at 2022-06-25 23:18:30.261757
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Expr(module_0.BinOp(module_0.Num(1), module_0.Add(), module_0.Num(2)))]
    
    get_non_exp_parent_and_index(a_s_t_0, a_s_t_0.body[0].value)


# Generated at 2022-06-25 23:18:32.301082
# Unit test for function get_parent
def test_get_parent():
    assert get_parent(tree=module_0.AST(), node=module_0.AST(), rebuild=False) is None


# Generated at 2022-06-25 23:18:40.899542
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0 = ast.Module()
    a_s_t_0 = module_0
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:44.970445
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Compares function results to expected outputs.
    a_s_t_0 = module_0.AST()
    assert get_closest_parent_of(a_s_t_0, a_s_t_0, type(a_s_t_0)) == a_s_t_0


# Generated at 2022-06-25 23:18:47.188566
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    print('Running test case 0')
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:18:50.291494
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    assert get_non_exp_parent_and_index(a_s_t_0, a_s_t_0) == (a_s_t_0, 0)

# Generated at 2022-06-25 23:18:59.301239
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:19:02.404935
# Unit test for function get_parent
def test_get_parent():
    a_s_t_1 = module_0.AST()
    assert get_parent(a_s_t_1, a_s_t_1)


# Generated at 2022-06-25 23:19:07.498080
# Unit test for function find
def test_find():
  a_s_t_0 = module_0.AST()
  a_s_t_1 = module_0.AST()
  a_s_t_2 = module_0.AST()

  assert a_s_t_0 not in find(a_s_t_0, tuple)
  assert (a_s_t_1, a_s_t_2) == tuple(find(a_s_t_0, module_0.AST))


# Generated at 2022-06-25 23:19:09.101695
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:19:11.329382
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    i_t_e_r_0 = find(a_s_t_0, (int, str))


# Generated at 2022-06-25 23:19:14.233206
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_1 = module_0.AST()
    test_case_0()
    test_case_1()


import unittest


# Generated at 2022-06-25 23:19:29.872273
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0 = ast.parse('\nimport ast \n\nclass Foo():\n\tdef _init_(self, x):\n\t\tself.x = x\n\n\tdef do_this(self):\n\t\treturn self.x\n\n')

    attr_0 = module_0.body[0]
    class_0 = module_0.body[1]

    init_0 = class_0.body[0]
    do_this_0 = class_0.body[1]

    self_0 = init_0.args.args[0]
    self_1 = do_this_0.args.args[0]

    x_0 = init_0.body[0].targets[0].value

# Generated at 2022-06-25 23:19:32.127202
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    try:
       test_case_0()
    except NodeNotFound as exception_0:
        print(exception_0.message)
        pass
    assert True


# Generated at 2022-06-25 23:19:33.915160
# Unit test for function find
def test_find():
    assert(list(find(a_s_t_0, ast.AST)) == [a_s_t_0])


# Generated at 2022-06-25 23:19:38.703943
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Loading abstract syntax tree using typed_ast
    a_s_t_0 = module_0.AST()
    # Finding result using local function test_case_0
    result = test_case_0()
    assert result == (None, None)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:19:41.077142
# Unit test for function find
def test_find():
    modules = find(module_0.AST(), module_0.Module)
    classes = find(module_0.AST(), module_0.ClassDef)


# Generated at 2022-06-25 23:19:45.365042
# Unit test for function find
def test_find():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    a_s_t_1 = find(a_s_t_0, module_0.AST)
    a_s_t_2 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:19:48.902105
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    for i in range(50):
        get_closest_parent_of(module_0.AST(), module_0.AST(), module_0.AST)

    if __name__ == "__main__":
        test_case_0()

    test_get_closest_parent_of()

# Generated at 2022-06-25 23:19:51.829843
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    typed_ast.ast3.get_closest_parent_of(a_s_t_0, a_s_t_0, type(a_s_t_0))


# Generated at 2022-06-25 23:19:54.393240
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    try:
        test_object_0 = module_0.AST()
        tuple_0 = get_non_exp_parent_and_index(test_object_0, test_object_0)
    except:
        raise AssertionError()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:20:04.727030
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    a_s_t_1 = module_0.AST()
    tuple_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)
    tuple_2 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1, True)
    dic_0 = {}
    ast_0 = module_0.AST()
    tuple_3 = get_non_exp_parent_and_index(ast_0, ast_0)
    ast_1 = module_0.AST()

# Generated at 2022-06-25 23:20:22.859235
# Unit test for function get_parent
def test_get_parent():
    x = ast.Name() # ast.Name
    assert x == get_parent(x, x)


# Generated at 2022-06-25 23:20:30.278235
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:20:35.087097
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    assert find(a_s_t_0, module_0.AST)
    a_s_t_1 = module_0.AST()
    assert not find(a_s_t_1, type)


# Generated at 2022-06-25 23:20:41.162271
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    s_t_0_0 = module_0.Str('', 0)
    assert get_closest_parent_of(a_s_t_1, s_t_0_0,
                                 (module_0.AST,)) is a_s_t_1

# Generated at 2022-06-25 23:20:45.297072
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    test_case = [
        a_s_t_1,
        a_s_t_0,
    ]
    assert_equal(get_parent(a_s_t_1, a_s_t_0), test_case)


# Generated at 2022-06-25 23:20:46.808132
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert get_closest_parent_of(1, 1, 1) == 1

# Generated at 2022-06-25 23:20:47.921953
# Unit test for function get_parent
def test_get_parent():
    pass



# Generated at 2022-06-25 23:20:55.588921
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    tuple_0 = find(a_s_t_0, type)

if __name__ == '__main__':
    import sys
    import logging
    import os
    module_name = os.path.split(sys.argv[0])[1]
    logging.basicConfig(filename= './test_logs/%s.log' % module_name,
                        level=logging.DEBUG)

    logging.info('in module: %s' % module_name)
    test_case_0()
    test_find()

# Generated at 2022-06-25 23:20:58.945368
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0,  module_0.AST)
    assert iterable_0 is not None


# Generated at 2022-06-25 23:21:00.986554
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, list)


# Generated at 2022-06-25 23:21:26.745833
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_1 = module_0.Module(body = [])
    a_s_t_2 = module_0.FunctionDef(name = 'f', args = module_0.arguments(args = [], vararg = None, kwonlyargs = [], kw_defaults = [], kwarg = None, defaults = []), body = [], decorator_list = [], returns = None)
    a_s_t_3 = module_0.FunctionDef(name = 'g', args = module_0.arguments(args = [], vararg = None, kwonlyargs = [], kw_defaults = [], kwarg = None, defaults = []), body = [], decorator_list = [], returns = None)

# Generated at 2022-06-25 23:21:30.767502
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    print('Testing function get_non_exp_parent_and_index')

    # Try out tests
    try:
      test_case_0()
      print('test case 0 done')
    except:
      print('test case 0 failed')

    print('Done')

    return True



import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:21:35.376589
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    #{type_: module_0.Module}
    assert isinstance(get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.Module), module_0.Module)
# def test_case_0():
#     a_s_t_0 = module_0.AST()
#     #{type_: module_0.Module}
#     assert isinstance(get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.Module), module_0.Module)

# Generated at 2022-06-25 23:21:46.001944
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module_0 = types.ModuleType('ast')
    module_0.AST = ast.AST
    module_0.Module = ast.Module
    module_0.Interactive = ast.Interactive
    module_0.Expression = ast.Expression
    module_0.Suite = ast.Suite
    module_0.FunctionDef = ast.FunctionDef
    module_0.AsyncFunctionDef = ast.AsyncFunctionDef
    module_0.ClassDef = ast.ClassDef
    module_0.Return = ast.Return
    module_0.Delete = ast.Delete
    module_0.Assign = ast.Assign
    module_0.AugAssign = ast.AugAssign
    module_0.AnnAssign = ast.AnnAssign
    module_0.For = ast.For

# Generated at 2022-06-25 23:21:48.045394
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    replace_at(0, a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:21:48.793642
# Unit test for function find
def test_find():
    assert True


# Generated at 2022-06-25 23:21:54.244738
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.Module()
    module_1 = ast.Module()
    module_2 = ast.Module()
    module_3 = ast.Module()
    module_4 = ast.Module()
    module_5 = ast.Module()
    module_6 = ast.Module()
    module_7 = ast.Module()
    module_8 = ast.Module()
    module_9 = ast.Module()
    module_10 = ast.Module()
    module_11 = ast.Module()
    module_12 = ast.Module()
    module_13 = ast.Module()
    module_14 = ast.Module()
    module_15 = ast.Module()
    module_16 = ast.Module()
    module_17 = ast.Module()
    module_18 = ast.Module()
    module_19 = ast.Module()

# Generated at 2022-06-25 23:22:01.342883
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Assignments
    module_0 = ast.Module()
    a_s_t_0 = ast.AST()
    target_0 = a_s_t_0
    target_1 = a_s_t_0
    target_2 = a_s_t_0
    expected_0 = module_0, 0

    # Function call
    returned_0 = get_non_exp_parent_and_index(module_0, a_s_t_0)

    assert returned_0 == expected_0


# Generated at 2022-06-25 23:22:04.363755
# Unit test for function find
def test_find():
    """Test case for function with one parameter."""
    a_s_t_0 = module_0.AST()
    result_0 = find(a_s_t_0, module_0.AST)
    assert isinstance(result_0, Iterable)


# Generated at 2022-06-25 23:22:06.452594
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:22:27.072185
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    i_t_e_r_a_b_l_e_0 = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:22:34.722027
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    return_1 = a_s_t_0  # type: ignore
    return_2 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    return_3 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert (return_1 == return_2 == return_3)

test_case_0()
test_get_closest_parent_of()

# Generated at 2022-06-25 23:22:43.554865
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    insert_at(1, a_s_t_0, a_s_t_0)
    a_s_t_1 = module_0.AST()
    replace_at(2, a_s_t_0, a_s_t_1)
    assert((get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST) == a_s_t_0))
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert(tuple_0[0] == a_s_t_0)
    assert(tuple_0[1] == 1)

# Generated at 2022-06-25 23:22:54.671321
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    module_0.AST(a_s_t_0)
    module_0.AST(a_s_t_0)
    module_0.AST(a_s_t_0)
    module_0.AST(a_s_t_0)
    module_0.AST(a_s_t_0)
    module_0.AST(a_s_t_0)
    module_0.AST(a_s_t_0)
    module_0.AST(a_s_t_0)
    module_0.AST(a_s_t_0)
    module_0.AST(a_s_t_0)

# Generated at 2022-06-25 23:23:00.766723
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0_0, a_s_t_0_0)
    closest_parent = get_closest_parent_of(a_s_t_0_0, tuple_0, ast.Return)


# Generated at 2022-06-25 23:23:05.827380
# Unit test for function find
def test_find():
    # Note: This test passes, but I don't understand why it is here,
    # or what it is testing. Commenting out to avoid spurious warning.
    #a_s_t_0 = module_0.AST()
    #typed_ast.ast3.find(a_s_t_0, ast.Module)
    pass


# Generated at 2022-06-25 23:23:11.168761
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.expr()]
    a_s_t_0.body[0].body = module_0.expr()
    i_t_0 = iter(find(a_s_t_0, module_0.Expr))
    e_0 = next(i_t_0)
    e_1 = next(i_t_0)
    e_2 = next(i_t_0)


# Generated at 2022-06-25 23:23:15.216585
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

    assert tuple_0 == (a_s_t_0, 0)

import typed_ast._ast3 as module_0
import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2

# Generated at 2022-06-25 23:23:15.925733
# Unit test for function find
def test_find():
    raise NotImplementedError


# Generated at 2022-06-25 23:23:23.345809
# Unit test for function find
def test_find():
    import typed_ast._ast3 as module_0
    node_0 = module_0.AST()
    node_1 = module_0.Name()
    node_0.lineno = node_1
    node_2 = module_0.Return()
    node_2.value = node_1
    node_3 = module_0.Expr()
    node_3.value = node_2
    node_4 = module_0.Return()
    node_4.value = node_1
    node_5 = module_0.Expr()
    node_5.value = node_4
    node_6 = module_0.Return()
    node_6.value = node_1
    node_7 = module_0.Expr()
    node_7.value = node_6

# Generated at 2022-06-25 23:24:08.933291
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_1 = module_0.AST()
    tuple_1 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_1)


# Generated at 2022-06-25 23:24:10.784324
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    type_0 = ast.AST
    result_0 = find(a_s_t_0, type_0)


# Generated at 2022-06-25 23:24:15.018357
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    module_0.Module(body=[a_s_t_1])
    tuple_1 = get_closest_parent_of(a_s_t_1, a_s_t_1, module_0.Module)

# Generated at 2022-06-25 23:24:18.856652
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2
import typed_ast._ast3 as module_3
import typed_ast._ast3 as module_4
import typed_ast._ast3 as module_5


# Generated at 2022-06-25 23:24:19.891189
# Unit test for function get_closest_parent_of

# Generated at 2022-06-25 23:24:21.950571
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from tests.functionality.get_non_exp_parent_and_index import TEST_CASES
    for _ in range(1000):
        TEST_CASES['test_0']()

import typed_ast._ast3 as module_1
