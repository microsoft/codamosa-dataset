

# Generated at 2022-06-25 23:14:24.249083
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert callable(get_non_exp_parent_and_index)
    assert isinstance(get_non_exp_parent_and_index(None, None), tuple)


# Generated at 2022-06-25 23:14:25.583288
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # See if the exception is raised
    try:
        test_case_0()
    except NodeNotFound:
        pass
    else:
        assert False

# Generated at 2022-06-25 23:14:27.534354
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    get_parent(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:14:43.757445
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test case 0
    # Create AST
    a_s_t_0 = typed_ast.ast3.Module(
        body=[typed_ast.ast3.Expr(typed_ast.ast3.Name(id='a'))]
    )
    node_0 = a_s_t_0
    type_0 = typed_ast.ast3.Name
    expected_0 = typed_ast.ast3.Module(
        body=[typed_ast.ast3.Expr(typed_ast.ast3.Name(id='a'))]
    )
    # Call function
    result_0 = get_closest_parent_of(a_s_t_0, node_0, type_0)
    # Checks
    assert(expected_0 == result_0)

    # Test case 1


# Generated at 2022-06-25 23:14:51.267521
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Set up test inputs.
    a_s_t_0 = ast.Module()
    a_s_t_1 = ast.FunctionDef()
    a_s_t_0.body.append(a_s_t_1)
    a_s_t_2 = ast.Expr()
    a_s_t_1.body.append(a_s_t_2)

    # Run function and verify expected outputs.
    assert get_non_exp_parent_and_index(a_s_t_0, a_s_t_2) == (a_s_t_1, 0)
    assert get_non_exp_parent_and_index(a_s_t_0, a_s_t_1) == (a_s_t_0, 0)

# Generated at 2022-06-25 23:14:54.289162
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, list)
    return list_0


# Generated at 2022-06-25 23:15:00.301130
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Case 0
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert tuple_0 is not None
    assert isinstance(tuple_0, tuple)
    assert len(tuple_0) == 2
    assert isinstance(tuple_0[0], module_0.AST)
    assert isinstance(tuple_0[1], int)
    assert tuple_0[1] == 0

# Generated at 2022-06-25 23:15:01.704893
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # REPLACE THIS EXPRESSION WITH THE ONE FROM EXAMPLE
    raise NotImplementedError

# Generated at 2022-06-25 23:15:12.998373
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    module_0.body.append(a_s_t_0)
    a_s_t_0 = module_0.AST()
    tuple_0 = get_closest_parent_of(module_0, a_s_t_0, tuple_0)


if __name__ == '__main__':
    import __main__ as main
    assert getattr(main, '__file__', None) or getattr(main, '__loader__', None)
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    a_s_t_0 = module_0.AST()
    module_

# Generated at 2022-06-25 23:15:17.994135
# Unit test for function find
def test_find():
    a_s_t_0 = ast.AST()
    i_t_e_r_0 = find(a_s_t_0, ast.AST)
    i_t_e_r_1 = iter(i_t_e_r_0)
    a_s_t_1 = next(i_t_e_r_1)

    assert(a_s_t_1 is a_s_t_0)


# Generated at 2022-06-25 23:15:23.512282
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    type_0 = module_0.AST
    a_s_t_1 = find(a_s_t_0, type_0)


# Generated at 2022-06-25 23:15:32.053230
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # int
    a_s_t_0 = module_0.AST()
    # int
    a_s_t_1 = module_0.AST()
    # int
    a_s_t_2 = module_0.AST()
    a_s_t_0.body = [
        a_s_t_1, 
        a_s_t_2, 
    ]
    a_s_t_0.lineno = 3
    a_s_t_0.col_offset = 3
    a_s_t_1.lineno = 4
    a_s_t_1.col_offset = 4
    a_s_t_2.lineno = 5
    a_s_t_2.col_offset = 5


# Generated at 2022-06-25 23:15:33.295691
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_get_non_exp_parent_and_index_0()


# Generated at 2022-06-25 23:15:34.126947
# Unit test for function replace_at
def test_replace_at():
    pass


# Generated at 2022-06-25 23:15:37.550665
# Unit test for function get_parent
def test_get_parent():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    test_case_0(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:15:44.030903
# Unit test for function get_parent
def test_get_parent():
    listcomp_0 = ast.ListComp(
        elt=ast.Name(id='a', ctx=ast.Load()),
        generators=[ast.comprehension(target=ast.Name(id='b', ctx=ast.Store()),
                                      iter=ast.Name(id='range', ctx=ast.Load()),
                                      ifs=[])])
    assert get_parent(listcomp_0, listcomp_0) == listcomp_0


# Generated at 2022-06-25 23:15:47.118202
# Unit test for function find
def test_find():
    a_s_t = ast.parse('a = 22')
    result = find(a_s_t, ast.Assign)
    assert next(result) is a_s_t.body[0]


# Generated at 2022-06-25 23:16:01.950354
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.ASTFunctionDef()
    a_s_t_arg_0 = a_s_t_0.args.args
    a_s_t_arg_0 = a_s_t_0.args.vararg
    a_s_t_arg_0 = a_s_t_0.args.kwarg
    a_s_t_0 = a_s_t_0.args.defaults
    a_s_t_0 = a_s_t_0.args.kw_defaults
    a_s_t_0 = a_s_t_0.body
    a_s_t_0 = a_s_t_0.decorator_list
    a_s_t_0 = a_s_t_0.name
    a

# Generated at 2022-06-25 23:16:06.612944
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.Module)



# Generated at 2022-06-25 23:16:18.260776
# Unit test for function replace_at
def test_replace_at():
    # Test with a_s_t_0 as tree, a_s_t_1 as parent and a_s_t_2 as nodes.
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    tuple_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)
    tuple_2 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_2)

# Generated at 2022-06-25 23:16:30.554388
# Unit test for function find
def test_find():
    _dict = {'a': 1, 'b': 2, 'c': 3}
    
    # Test if 'a' in _dict would be True
    if find(_dict, 'a') == True:
        print("Test passed")
    else:
        print("Test failed")
        
    # Test if 'd' in _dict would be False
    if find(_dict, 'd') == False:
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-25 23:16:40.223891
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:16:49.898582
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    print('Test get_closest_parent_of():')

    import typed_ast._ast3 as module_0

    class Class_0(module_0.AST):
        fields = []

    class Class_1(Class_0):
        fields = []

    class Class_2(Class_1):
        fields = []

    a_s_t_0 = Class_0()
    a_s_t_0_0 = Class_0()
    a_s_t_0_1 = Class_2()

    a_s_t_0.body = [a_s_t_0_0, a_s_t_0_1]

    _build_parents(a_s_t_0)

    # Test 1

# Generated at 2022-06-25 23:16:53.418714
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Call function to get the index of the child in parent
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert(tuple_0[1] == 0)


# Generated at 2022-06-25 23:16:59.340573
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import os
    import sys

    current_path = os.path.dirname(__file__)
    sys.path.insert(0, os.path.join(current_path, '../../') )
    from python_parser.ast_parser import get_ast
    import typed_ast._ast3 as module_0
    test_case_0()


if __name__ == '__main__':
    import random
    import timeit

    test_get_non_exp_parent_and_index()

# Generated at 2022-06-25 23:17:04.833516
# Unit test for function find
def test_find():
    # type: () -> None
    node_0 = module_0.AST()
    node_1 = module_0.AST()
    test_tree_0 = module_0.AST(body=[node_0, node_1])
    result_iterable = find(test_tree_0, module_0.AST)
    assert result_iterable == (node_0, 
                               node_1, 
                               test_tree_0)


# Generated at 2022-06-25 23:17:07.230908
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)

# Generated at 2022-06-25 23:17:17.576377
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    ast.copy_location(a_s_t_1, a_s_t_2)
    ast.fix_missing_locations(a_s_t_1)
    ast.copy_location(a_s_t_3, a_s_t_4)
    ast.fix_missing_locations(a_s_t_3)
   

# Generated at 2022-06-25 23:17:18.695756
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

# Generated at 2022-06-25 23:17:27.466544
# Unit test for function find
def test_find():
    _ast_0 = module_0.AST()
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    module_0.walk(_ast_0, None)
    tuple_0 = get_parent(_ast_0, a_s_t_0, None)
    tuple_1 = get_parent(_ast_0, a_s_t_1, True)
    tuple_2 = get_non_exp_parent_and_index(_ast_0, a_s_t_0)
    tuple_3 = get_non_exp_parent_and_index(_ast_0, a_s_t_1)
    insert_at(None, a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 23:17:42.046300
# Unit test for function find
def test_find():
    import typed_ast as ast3
    tree = ast3.parse("""name = 'o_O'\n""")
    o_O_s = find(tree, ast3.Name)
    [o_O] = o_O_s
    assert o_O.id == 'o_O'


# Generated at 2022-06-25 23:17:47.801704
# Unit test for function replace_at
def test_replace_at():
    ast_0 = module_0.AST()
    module_0.AST._fields = ['lineno', 'col_offset', 'end_lineno', 'end_col_offset']
    module_0.AST.__init__ = lambda self: None
    module_0.AST(lineno=1, col_offset=1, end_lineno=1, end_col_offset=1)
    replace_at(0, ast_0, ast_0)


# Generated at 2022-06-25 23:17:50.193562
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    tuple_1 = get_closest_parent_of(a_s_t_1, a_s_t_1, None)

# Generated at 2022-06-25 23:17:50.818203
# Unit test for function find
def test_find():
    pass

# Test function replacement

# Generated at 2022-06-25 23:17:52.211133
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert test_case_0() == None


import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:17:55.145044
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    print("Running test")
    test_case_0()

if __name__ == '__main__':
    test_get_non_exp_parent_and_index()
    print("Test finished")

# Generated at 2022-06-25 23:18:00.800139
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:04.935365
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

import typing as module_1

from typing import Dict as Dict_2

# Generated at 2022-06-25 23:18:07.198155
# Unit test for function replace_at
def test_replace_at():
    module_0.replace_at(0, a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:18:10.682805
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    testcase_0 = module_0.AST()
    module_0.Module(body=[testcase_0], type_ignores=[])
    assert testcase_0 is get_closest_parent_of(testcase_0, testcase_0, module_0.AST)

# Generated at 2022-06-25 23:18:38.434387
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    # Tests for function find
    # Tests for function find
    a_s_t_1 = module_0.AST()
    tuple_1 = find(a_s_t_0, type(a_s_t_1))
    a_s_t_2 = module_0.AST()
    tuple_2 = find(a_s_t_0, type(a_s_t_2))
    module_0.AST()
    find(a_s_t_0, type(a_s_t_2))

# Generated at 2022-06-25 23:18:43.201726
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.Module([module_0.Expr(module_0.Name('a', module_0.Load()))])
    module_0.Module([module_0.Assign([module_0.Name('a', module_0.Store())], module_0.Constant(1, None))])
    

# Generated at 2022-06-25 23:18:50.129368
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_1.body = [a_s_t_2]
    function_0 = get_closest_parent_of(a_s_t_1, a_s_t_2, 'function_def')
    function_1 = get_closest_parent_of(a_s_t_1, a_s_t_1, 'function_def')


# Generated at 2022-06-25 23:18:59.138004
# Unit test for function find
def test_find():
    global config
    config = {}
    config['ast_map'] = {}
    config['ast_map']['<map>'] = {}
    config['ast_map']['<map>']['call_arg'] = {
        'type': 'Call',
        'field': 'args',
        'index': 0,
        'empty': False
    }
    config['ast_map']['<map>']['expr_data'] = {
        'type': 'Expr',
        'field': 'value',
        'index': None,
        'empty': False
    }
    config['ast_map']['<map>']['funcdef_body'] = {
        'type': 'FunctionDef',
        'field': 'body',
        'index': None,
        'empty': False
    }

# Generated at 2022-06-25 23:19:02.885297
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    assert get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST) == a_s_t_0

# Generated at 2022-06-25 23:19:11.279166
# Unit test for function find
def test_find():
    pas = ast.parse('code')
    result = list(find(pas, ast.Expr))
    expected = []
    assert result == expected

    pas = ast.parse('x + y')
    result = list(find(pas, ast.Expr))
    expected = [ast.BinOp(ast.Name('x', ast.Load()), ast.Add(), ast.Name('y', ast.Load()))]
    assert result == expected

    pas = ast.parse('x + y')
    result = list(find(pas, ast.Tuple))
    expected = []
    assert result == expected

    pas = ast.parse('x + y')
    result = list(find(pas, ast.Name))
    expected = [ast.Name('x', ast.Load()), ast.Name('y', ast.Load())]
   

# Generated at 2022-06-25 23:19:14.496420
# Unit test for function find
def test_find():

    a_s_t_0 = module_0.AST()
    # Find nodes with type AST
    nodes = find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:19:16.957927
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, module_0.IfExp)


# Generated at 2022-06-25 23:19:23.260914
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    import typed_ast.ast3 as module_1
    a_s_t_0 = module_0.AST()
    try:
        module_1.get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    except NodeNotFound:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-25 23:19:24.668668
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, type(None))


# Generated at 2022-06-25 23:20:09.045073
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    type_0 = ast.Module
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, type_0)



# Generated at 2022-06-25 23:20:11.660738
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    type_0 = None
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, type_0)


# Generated at 2022-06-25 23:20:17.293452
# Unit test for function find
def test_find():
    ast_0 = ast.AST()
    tuple_0 = find(ast_0, ast.AST)


# Generated at 2022-06-25 23:20:20.993072
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_1 = module_0.AST()
    tuple_1 = get_non_exp_parent_and_index(a_s_t_1, a_s_t_1)


# Generated at 2022-06-25 23:20:24.270898
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    tuple_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 23:20:27.966314
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    set_0 = set()
    iter_0 = find(a_s_t_0, set_0.__class__)
    list_0 = list()
    iter_0 = find(list_0, list_0.__class__)


# Generated at 2022-06-25 23:20:33.468370
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Case 1:
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Attribute()
    attribute = get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.Attribute)

# Generated at 2022-06-25 23:20:36.808651
# Unit test for function find
def test_find():
    module_0 = ast.Module(body=[])
    name_0 = ast.Name()
    assert find(module_0, ast.Name) == [name_0], 'find failed'


# Generated at 2022-06-25 23:20:41.278777
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    replace_at(0 , a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:20:47.578841
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_0_0 = module_0.AST()
    a_s_t_0.body.append(a_s_t_0_0)
    a_s_t_0_0_0 = module_0.AST()
    a_s_t_0_0.body.append(a_s_t_0_0_0)
    a_s_t_0_1 = module_0.AST()
    a_s_t_0.body.append(a_s_t_0_1)
    a_s_t_0_1_0 = module_0.AST()
    a_s_t_0_1.body.append(a_s_t_0_1_0)

    _build

# Generated at 2022-06-25 23:22:16.957249
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    iterable_0 = find(a_s_t_0, module_0.AST)
    iterable_1 = find(iterable_0, module_0.AST)
    iterable_2 = find(iterable_1, module_0.AST)


# Generated at 2022-06-25 23:22:18.550924
# Unit test for function replace_at
def test_replace_at():
    assert not hasattr(replace_at, "__annotations__")


# Generated at 2022-06-25 23:22:19.426823
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case_0()

# Generated at 2022-06-25 23:22:20.184243
# Unit test for function get_parent
def test_get_parent():
    pass


# Generated at 2022-06-25 23:22:31.766827
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # init statements
    module_0 = ast.parse("import ast\n\n")
    a_s_t_0 = module_0.body[1].value
    tuple_0 = get_non_exp_parent_and_index(module_0, a_s_t_0)
    # check statements
    try:
        assert isinstance(tuple_0, tuple)
    except AssertionError:
        print("AssertionError: Expected: <class 'tuple'>")
        print("Received:", tuple_0, type(tuple_0))
    try:
        assert len(tuple_0) == 2
    except AssertionError:
        print("AssertionError: Expected: <class 'int'>")

# Generated at 2022-06-25 23:22:32.321321
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False

# Generated at 2022-06-25 23:22:41.553770
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.Module()
    assert get_closest_parent_of(module_0, module_0, ast.Module) == module_0
    
    func_def_0 = ast.FunctionDef()
    module_0.body = [func_def_0]
    assert get_closest_parent_of(module_0, func_def_0, ast.Module) == module_0

    func_def_1 = ast.FunctionDef()
    func_def_0.body = [func_def_1]
    assert get_closest_parent_of(module_0, func_def_1, ast.FunctionDef) == func_def_0

    class_def_0 = ast.ClassDef()
    func_def_0.body.append(class_def_0)
    assert get_

# Generated at 2022-06-25 23:22:46.348468
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Raise error on non existanct argument identifier
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    module_0.test_case_0()


# Generated at 2022-06-25 23:22:57.459237
# Unit test for function get_parent
def test_get_parent():
    import typed_ast._ast3 as module_0
    import random
    try:
        random.seed(0)
    except ValueError:
        pass

    for i_0 in range(100):
        a_s_t_0 = module_0.AST()
        try:
            get_parent(a_s_t_0, None)
        except NodeNotFound:
            pass
        else:
            assert False

        try:
            get_parent(a_s_t_0, None)
        except NodeNotFound:
            pass
        else:
            assert False

        try:
            get_parent(a_s_t_0, None)
        except NodeNotFound:
            pass
        else:
            assert False


# Generated at 2022-06-25 23:23:07.464753
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    list_0 = find(a_s_t_0, ast.Module)
    try:
        a_s_t_1 = ast.Module([])
        list_1 = find(a_s_t_1, ast.Module)
    except:
        pass

    # Test for raising exception
    try:
        a_s_t_2 = ast.Module([])
        list_2 = find(a_s_t_2, ast.Module)
    except:
        pass
