

# Generated at 2022-06-25 23:14:37.729423
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module_0 = ast.Module()
    a_s_t_0 = module_0
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, ast.AST)
    a_s_t_2 = ast.Module()
    a_s_t_2.body = [a_s_t_0]
    a_s_t_3 = get_closest_parent_of(a_s_t_2, a_s_t_0, ast.Module)
    a_s_t_4 = ast.Module()
    a_s_t_4.body = [a_s_t_3]

# Generated at 2022-06-25 23:14:46.748411
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Positive case
    module_0 = ModuleType()
    a_s_t_0 = FunctionType()
    a_s_t_0.args = arguments(args=[arg(arg='a_s_t_0', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    a_s_t_0.body = [Pass()]
    a_s_t_0.decorator_list = []
    a_s_t_0.returns = None
    module_0.body = [a_s_t_0]
    a_s_t_1 = get_non_exp_parent_and_index(module_0, a_s_t_0)

# Generated at 2022-06-25 23:14:52.286132
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    _build_parents(a_s_t_0)
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    test_assert_instance(a_s_t_1, module_0.AST)
    test_assert_notequal(a_s_t_1, a_s_t_0)


# Generated at 2022-06-25 23:15:00.917510
# Unit test for function find
def test_find():
    def make_tree(k: int, v: int) -> ast.AST:
        tree = ast.Module([
            ast.Assign([ast.Name(id='k', ctx=ast.Store())], ast.Num(k)),
            ast.Assign([ast.Name(id='v', ctx=ast.Store())], ast.Num(v)),
            ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                     args=[ast.BinOp(left=ast.Name(id='k', ctx=ast.Load()),
                                     op=ast.Sub(),
                                     right=ast.Name(id='v', ctx=ast.Load()))],
                     keywords=[])
        ])

        return tree

    # test for Module
    tree = make_tree(1, 2)


# Generated at 2022-06-25 23:15:02.009202
# Unit test for function find
def test_find():
    assert find(1, 1) == None


# Generated at 2022-06-25 23:15:13.378771
# Unit test for function find
def test_find():
    ast_tree = module_0.AST()
    assert list(find(ast_tree, ast.Expr)) == []

    expr = ast.Expr(value=ast.Num(n=12))
    expr2 = ast.Expr(value=ast.Num(n=14))
    expr3 = ast.Expr(value=ast.Num(n=15))
    expr4 = ast.Expr(value=ast.Num(n=16))
    ast_tree.body.append(expr)
    ast_tree.body.append(expr2)
    ast_tree.body.append(expr3)
    ast_tree.body.append(expr4)

    global _parents
    _parents = WeakKeyDictionary()

    found_nodes = list(find(ast_tree, ast.Expr))
    assert found_

# Generated at 2022-06-25 23:15:17.004675
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    # No assertion
    try:
        get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 23:15:22.283058
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.arguments()
    a_s_t_3 = module_0.Call(a_s_t_2)
    a_s_t_4 = module_0.parse("a = 1", mode='eval')
    a_s_t_5 = get_non_exp_parent_and_index(a_s_t_4, a_s_t_3)


# Generated at 2022-06-25 23:15:30.761904
# Unit test for function find
def test_find():
    for test in [
        {
            "name": "Test 1",
            "input": {
                "tree": module_0.AST(),
                "type_": module_0.AST
            },
            "want": [module_0.AST()]
        },
        {
            "name": "Test 2",
            "input": {
                "tree": module_0.AST(),
                "type_": module_0.Add
            },
            "want": []
        }
    ]:
        print("=== {} ===".format(test["name"]))
        got = list(find(test["input"]["tree"], test["input"]["type_"]))
        if got != test["want"]:
            print("[FAIL] got: {} wanted: {}".format(got, test["want"]))

# Generated at 2022-06-25 23:15:40.315980
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.Module()
    a_s_t_4 = module_0.Name()
    a_s_t_5 = module_0.Load()
    a_s_t_6 = module_0.Print()
    a_s_t_7 = module_0.Load()
    a_s_t_8 = module_0.Print()
    a_s_t_9 = module_0.Load()
    a_s_t_10 = module_0.Print()
    a_s_t_11 = module_0.Load()
    a_s_t_12 = module_0.Print()
    a_s_t_13 = module_0.Load()
    a_s_t_

# Generated at 2022-06-25 23:15:51.283456
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_cases = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    for test_case in test_cases:
        if test_case == 0:
            a_s_t_0 = module_0.AST()
            get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

        if test_case == 1:
            a_s_t_0 = module_0.AST()
            get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

        if test_case == 2:
            a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 23:15:54.387182
# Unit test for function find
def test_find():
    find(None, Type[T])


# Generated at 2022-06-25 23:15:57.542205
# Unit test for function get_parent
def test_get_parent():

    class node:
        def __init__(self, parent):
            self.parent = parent

    node_0 = node(None)
    node_1 = node(node_0)
    node_2 = node(node_1)

    assert get_parent(node_0, node_1) == node_0
    assert get_parent(node_0, node_2) == node_1


# Generated at 2022-06-25 23:16:06.199511
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    _parents = WeakKeyDictionary()  # type: WeakKeyDictionary[ast.AST, ast.AST]
    def _build_parents(tree: ast.AST) -> None:
        for node in ast.walk(tree):
            for child in ast.iter_child_nodes(node):
                _parents[child] = node
    def get_parent(tree: ast.AST, node: ast.AST, rebuild: bool = False) -> ast.AST:
        if node not in _parents or rebuild:
            _build_parents(tree)
        try:
            return _parents[node]
        except IndexError:
            raise NodeNotFound('Parent for {} not found'.format(node))
    test_case_0()


# Generated at 2022-06-25 23:16:11.105246
# Unit test for function insert_at
def test_insert_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    l_s_t_2 = [ a_s_t_1 ]
    insert_at(10, a_s_t_0, l_s_t_2)



# Generated at 2022-06-25 23:16:12.749986
# Unit test for function replace_at
def test_replace_at():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 23:16:17.230986
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()

    try:
        test_case_0()
    except Exception as e:
        print("Exception: ", e)

# Unit tests for function replace_at

# Generated at 2022-06-25 23:16:20.244260
# Unit test for function replace_at
def test_replace_at():
    a_s_t_0 = module_0.AST()
    replace_at(0, a_s_t_0, None)


# Generated at 2022-06-25 23:16:24.144449
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    test_case_1 = find(a_s_t_0, type_=module_0.AST)
    assert test_case_1 is not None


# Generated at 2022-06-25 23:16:28.771239
# Unit test for function get_parent
def test_get_parent():
    if get_parent(module_0.AST(), module_0.AST(), False) != module_0.AST():
        print("Function get_parent is not correct")
    elif get_parent(module_0.AST(), module_0.AST(), True) != module_0.AST():
        print("Function get_parent is not correct")


# Generated at 2022-06-25 23:16:40.126167
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert isinstance(a_s_t_1, module_0.AST)

if __name__ == '__main__':
    import sys
    import os
    path, _ = os.path.split(os.path.abspath(__file__))
    sys.path.append(os.path.join(path, '..'))
    import test_util
    test_util.run_tests(__file__)

# Generated at 2022-06-25 23:16:49.822602
# Unit test for function get_parent
def test_get_parent():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = get_parent(a_s_t_2, a_s_t_2)
    assert isinstance(a_s_t_3, module_0.AST)
    a_s_t_4 = module_0.AST()
    a_s_t_5 = get_parent(a_s_t_4, a_s_t_4)
    assert isinstance(a_s_t_5, module_0.AST)
    a_s_t_6 = module_0.AST()
    a_s_t_7 = get_parent(a_s_t_6, a_s_t_6)
    assert isinstance(a_s_t_7, module_0.AST)



# Generated at 2022-06-25 23:16:58.687627
# Unit test for function replace_at
def test_replace_at():

    # Test case for index 0
    print('replace_at now testing index 0')
    a_s_t_0 = module_0.AST()
    i__0 = 0
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_2_var = [a_s_t_1, a_s_t_2]
    replace_at(i__0, a_s_t_1, a_s_t_2_var)

    print('replace_at index 0 passed')

    # Test case for index 1
    print('replace_at now testing index 1')
    a_s_t_0 = module_0.AST()
    i__0 = 1

# Generated at 2022-06-25 23:17:07.575332
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = ast.Module(body=[
        ast.Expr(value=ast.Num(n=1)),
        ast.Expr(value=ast.Str(s='string'))])
    body_0 = a_s_t_0.body
    a_s_t_1 = body_0[0]
    a_s_t_2 = body_0[1]
    assert(get_non_exp_parent_and_index(a_s_t_0, a_s_t_1) is (a_s_t_0, 0))
    assert(get_non_exp_parent_and_index(a_s_t_0, a_s_t_2) is (a_s_t_0, 1))


# Generated at 2022-06-25 23:17:18.094311
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t = module_0.AST()
    a_s_t_0 = module_0.AST()
    a_s_t.body = [a_s_t_0]
    t_0, t_1 = get_non_exp_parent_and_index(a_s_t, a_s_t_0)
    if t_0 != a_s_t:
        raise AssertionError()
    if t_1 != 0:
        raise AssertionError()

    module_0.interactive = True
    t_2 = find(a_s_t, ast.AST)
    t_3 = module_0.Break()
    insert_at(0, a_s_t, t_3)
    t_4 = module_0.Break()

# Generated at 2022-06-25 23:17:21.691718
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1, a_s_t_2, a_s_t_3 = find(a_s_t_0, module_0.AST)

# Generated at 2022-06-25 23:17:24.382091
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0, True)


# Generated at 2022-06-25 23:17:28.559552
# Unit test for function insert_at
def test_insert_at():
    a_s_t_2 = module_0.AST()
    # Function wanted
    a_s_t_3 = module_0.FunctionDef()
    # Function on which the wanted function is nested
    a_s_t_4 = module_0.FunctionDef()
    a_s_t_4.body.append(a_s_t_3)
    insert_at(0, a_s_t_4, a_s_t_3)



# Generated at 2022-06-25 23:17:32.865729
# Unit test for function replace_at
def test_replace_at():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.Module()
    tup_0 = (a_s_t_2, 0)
    a_s_t_4 = module_0.arg()
    replace_at(tup_0[1], tup_0[0], a_s_t_4)

# Generated at 2022-06-25 23:17:39.275730
# Unit test for function find
def test_find():
    # Test case for find without expected result passed
    a_s_t_0 = module_0.AST()
    x = find(a_s_t_0, ast.Module)
    pass

    # Test case for find with expected result passed
    a_s_t_0 = module_0.AST()
    x = find(a_s_t_0, ast.Module)
    assert x == None



# Generated at 2022-06-25 23:17:44.439611
# Unit test for function find
def test_find():
    a_s_t_0 = find(module_0.AST(), module_0.AST)


# Generated at 2022-06-25 23:17:52.584413
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_12 = module_0.AST()
    a_s_t_13 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:17:56.818623
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    answer = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST) == a_s_t_0
    return answer


# Generated at 2022-06-25 23:18:07.632887
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
	a_s_t_0 = ast.Expr()
	a_s_t_1 = ast.Assign()
	a_s_t_1.value = a_s_t_0
	a_s_t_2 = ast.Module()
	a_s_t_2.body = [a_s_t_1]
	a_s_t_3 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_0)
	# TODO: a_s_t_4 = get_closest_parent_of(a_s_t_2, a_s_t_0, ast.Assign)
	# TODO: a_s_t_5 = get_closest_parent_of(a_s_t_2, a

# Generated at 2022-06-25 23:18:16.286031
# Unit test for function insert_at
def test_insert_at():
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.Name()
    insert_at(0, a_s_t_2, a_s_t_3)
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.Name()
    a_s_t_6 = module_0.Name()
    insert_at(0, a_s_t_4, [a_s_t_5, a_s_t_6])


# Generated at 2022-06-25 23:18:26.385256
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import ast_builder
    a_s_t_0 = ast_builder.build_ast(
        'def foo():\n'
        '    pass')
    a_s_t_1 = a_s_t_0.body[0]
    (parent, child_index) = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)
    assert parent == a_s_t_0
    assert child_index == 0

# Generated at 2022-06-25 23:18:28.361594
# Unit test for function find
def test_find():
    a_s_t_3 = module_0.AST()
    find(a_s_t_3, module_0.AST)


# Generated at 2022-06-25 23:18:31.338773
# Unit test for function find
def test_find():
    """
    Unit test for function find
    """
    a_s_t_0 = module_0.AST()
    assert find(a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:18:34.915239
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    assert [a_s_t_0] == list(find(a_s_t_0, type(a_s_t_0)))


# Generated at 2022-06-25 23:18:39.363716
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = find(a_s_t_0, ast.Name)


# Generated at 2022-06-25 23:18:52.039855
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test cases for Type 'AST'
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    a_s_t_3 = get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.AST)
    a_s_t_4 = get_closest_parent_of(a_s_t_1, a_s_t_0, module_0.AST)
    a_s_t_5 = get_closest_parent_of(a_s_t_1, a_s_t_1, module_0.AST)
    a_s_

# Generated at 2022-06-25 23:18:55.308606
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    input = {'tree': module_0.AST(), 'node': module_0.AST(), 'type_': type}
    output = get_closest_parent_of(**input)


test_get_closest_parent_of()

# Generated at 2022-06-25 23:19:04.804404
# Unit test for function find
def test_find():
    a_s_t_0 = module_0.AST()
    l_0 = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
    l_1 = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
    l_2 = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
    l_3 = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)

# Generated at 2022-06-25 23:19:05.680862
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-25 23:19:14.679568
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast
    import typed_ast.ast3
    ast1 = typed_ast.ast3.AST()
    ast2 = typed_ast.ast3.AST()
    ast3 = typed_ast.ast3.AST()
    ast4 = typed_ast.ast3.AST()
    ast2.body = [ast3]
    ast1.body = [ast2]
    ast4.body = [ast1]
    ast5 = get_closest_parent_of(ast4, ast1, typed_ast.ast3.AST)
    ast5 = get_closest_parent_of(ast4, ast2, typed_ast.ast3.AST)
    ast5 = get_closest_parent_of(ast4, ast3, typed_ast.ast3.AST)
    ast5 = get_cl

# Generated at 2022-06-25 23:19:24.790981
# Unit test for function find
def test_find():
    a_s_t_0 = ast.parse('import os')
    a_s_t_1 = find(a_s_t_0, ast.Import)
    assert isinstance(a_s_t_1, Iterator)
    a_s_t_1 = list(a_s_t_1)
    a_s_t_2 = ast.parse('import sys')
    a_s_t_3 = find(a_s_t_2, ast.Import)
    assert isinstance(a_s_t_3, Iterator)
    a_s_t_3 = list(a_s_t_3)
    a_s_t_4 = ast.parse('import typing')
    a_s_t_5 = find(a_s_t_4, ast.Import)

# Generated at 2022-06-25 23:19:29.841820
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    insert_at(1, a_s_t_0, a_s_t_1)
    for a_s_t_2 in ast.walk(a_s_t_0):
        if isinstance(a_s_t_2, module_0.AST):
            a_s_t_3 = get_parent(a_s_t_0, a_s_t_2)


# Generated at 2022-06-25 23:19:32.727769
# Unit test for function insert_at
def test_insert_at():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    insert_at(0, a_s_t_0, [a_s_t_1])



# Generated at 2022-06-25 23:19:35.648803
# Unit test for function find
def test_find():
    a_s_t_2 = module_0.AST()
    assert find(a_s_t_2, module_0.AST) == (a_s_t_2, )

# Generated at 2022-06-25 23:19:39.591198
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)
    assert a_s_t_1 == a_s_t_0

# Generated at 2022-06-25 23:19:47.279922
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.AST(body=module_0.Module(bodies=[module_0.Str(s='hello world')]))
    a_s_t_3 = module_0.Str(s='hello world')
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_3)


# Generated at 2022-06-25 23:19:54.512511
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast

    x = ast.parse('[1, 2, 3]')
    assert x == list(ast.walk(x))[0]
    parent = [item for item in ast.walk(x) if item.__class__ == ast.List][0]
    assert parent == get_closest_parent_of(x, list(ast.walk(x))[0], ast.List)

    x = ast.parse('1\n2\n3')
    assert x == list(ast.walk(x))[0]
    parent = [item for item in ast.walk(x) if item.__class__ == ast.Module][0]
    assert parent == get_closest_parent_of(x, list(ast.walk(x))[0], ast.Module)

    x = ast

# Generated at 2022-06-25 23:20:04.759396
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    # Create an instance of AST
    a_s_t_1 = module_0.AST()

    # Create an instance of AST
    a_s_t_2 = module_0.AST()

    # Create an instance of AST
    a_s_t_3 = module_0.AST()

    # Create an instance of AST
    a_s_t_4 = module_0.AST()

    # Create an instance of Module
    a_s_t_5 = module_0.Module(body=[a_s_t_4])

    # Set 'body' node attribute for AST a_s_t_4
    a_s_t_4.body = [a_s_t_1]

    # Create an instance of ListComp

# Generated at 2022-06-25 23:20:07.899076
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 23:20:10.219009
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    # test case
    try:
        get_non_exp_parent_and_index(1, 2)
    except TypeError as exception:
        assert isinstance(exception, TypeError)


# Generated at 2022-06-25 23:20:21.262723
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast
    
    # a_s_t_0 => 'If' AST node.
    a_s_t_0 = ast.If(test=ast.Name(id='test1', ctx=ast.Load()), body=[ast.Expr(value=ast.Call(func=ast.Name(id='test4', ctx=ast.Load()), args=[], keywords=[]))], orelse=[])
    
    # a_s_t_1 => 'If' AST node.

# Generated at 2022-06-25 23:20:29.741101
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast
    import ast
    import typing
    import astor
    import sys
    import _ast
    import textwrap
    import itertools
    import inspect
    import re
    import os
    import timeit
    import random
    import tempfile
    import string
    import os
    import re
    import sys
    import builtins
    import textwrap
    import keyword
    import random
    import astor
    import ast
    import astunparse
    import difflib
    import io
    import itertools
    import functools
    import collections
    import typing
    import unittest
    import unittest.mock
    import weakref
    import _ast
    import astor
    import astunparse
    import difflib
    import io
    import itertools
    import functools

# Generated at 2022-06-25 23:20:41.753933
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.FunctionDef('g', [], [], [], [], None, a_s_t_.Load())
    a_s_t_1 = module_0.Name('a', a_s_t_.Load())
    a_s_t_2 = module_0.FunctionDef('g', [], [], [], [], None, a_s_t_.Load())
    x_a_s_t_3, x_a_s_t_4 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_1)
    assert a_s_t_0 == x_a_s_t_3 
    assert 0 == x_a_s_t_4


# Generated at 2022-06-25 23:20:47.177628
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # - Initialize variables here
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Eq()]
    a_s_t_1 = a_s_t_0.body[0]
    a_s_t_2 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)

    assert a_s_t_2[0] == a_s_t_0, 'a_s_t_0'
    assert a_s_t_2[1] == 0, '0'


# Generated at 2022-06-25 23:20:51.642112
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:20:56.079906
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-25 23:21:00.718577
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_1
    a = module_1.AST()
    get_closest_parent_of(a, a, module_1.AST)


if __name__ == '__main__':
    test_case_0()
    test_get_closest_parent_of()

# Generated at 2022-06-25 23:21:01.224454
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-25 23:21:07.081817
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as target_module
    a_s_t_0 = target_module.AST()
    a_s_t_1 = target_module.Module(body=[a_s_t_0])
    a_s_t_2 = get_closest_parent_of(a_s_t_1, a_s_t_0, target_module.Module)

    assert a_s_t_1 == a_s_t_2

# Generated at 2022-06-25 23:21:10.178100
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()

    # Test case 0:
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)


# Generated at 2022-06-25 23:21:10.915116
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass


# Generated at 2022-06-25 23:21:13.954496
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    import random
    tree = ast.body
    node = tree.body
    type_ = ast.body

    result = get_closest_parent_of(tree, node, type_)
    assert type(result) is ast.AST


# Generated at 2022-06-25 23:21:17.838869
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:21:22.390908
# Unit test for function find
def test_find():
    text = """
    class A:
        pass
    """
    tree = ast.parse(text)
    module = tree.body[0]
    class_def = tree.body[0].body[0]

    assert list(find(tree, ast.Module)) == [module]
    assert list(find(tree, ast.ClassDef)) == [class_def]



# Generated at 2022-06-25 23:21:31.516221
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Tree with one node
    a_s_t_0 = module_0.AST()
    t_u_p_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert t_u_p_0[0] == a_s_t_0
    assert t_u_p_0[1] == 0

    # Tree with two nodes
    a_s_t_1 = module_0.AST()
    a_s_t_0.body = [a_s_t_1]
    t_u_p_0 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)
    assert t_u_p_0[0] == a_s_t_0

# Generated at 2022-06-25 23:21:39.644895
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, module_0.AST)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:21:45.060698
# Unit test for function get_parent
def test_get_parent():
    import typing as tp
    import ast
    import typed_ast.ast3 as typed_ast
    a_s_t_0 = ast.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)

    print(a_s_t_0)
    print(a_s_t_1)


# Generated at 2022-06-25 23:21:46.450297
# Unit test for function get_parent
def test_get_parent():
    with pytest.raises(NodeNotFound):
        test_case_0()

# Generated at 2022-06-25 23:21:50.319532
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3
    a_s_t_0 = ast3.AST()
    a_s_t_1 = ast3.AST()
    a_s_t_0.body = []
    a_s_t_0.body.append(a_s_t_1)
    index_0 = 0
    index_1 = 0
    assert (a_s_t_0, index_0) == get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:21:52.351112
# Unit test for function insert_at
def test_insert_at():
    a_s_t_1 = module_0.AST()
    parent_0 = a_s_t_1
    nodes_0 = module_0.AST()
    insert_at(0, parent_0, nodes_0)


# Generated at 2022-06-25 23:21:54.468325
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('x + 1')
    expr = tree.body[0].value
    binary_expr = expr.left
    
    assert get_parent(tree, binary_expr) == expr


# Generated at 2022-06-25 23:22:03.996841
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_4.body = [a_s_t_3]
    a_s_t_2.body = [a_s_t_4]
    a_s_t_1.body = [a_s_t_2]
    a_s_t_0.body = [a_s_t_1]
    a_s_t_0_copy = copy.deepcopy(a_s_t_0)

    a_s_t_1, a

# Generated at 2022-06-25 23:22:13.096864
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast
    a_s_t_2 = ast.AST()
    a_s_t_3 = ast.AST()
    a_s_t_4 = ast.AST()
    a_s_t_5 = ast.AST()
    a_s_t_6 = ast.AST()
    a_s_t_7 = ast.AST()
    a_s_t_8 = ast.AST()
    a_s_t_9 = ast.AST()
    a_s_t_10 = ast.AST()
    a_s_t_11 = ast.AST()
    a_s_t_12 = ast.AST()
    a_s_t_13 = ast.AST()
    a_s_t_14 = ast.AST()
    a_s_t_15 = ast.AST()

# Generated at 2022-06-25 23:22:18.553444
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast
    import astunparse
    import string
    import random
    import collections
    import subprocess
    import time

    import typed_ast.ast3 as ast3

    a_s_t_0 = ast.Str()
    typed_ast.ast3.Str.lineno = lambda x: random.randint(0, 2147483647)
    typed_ast.ast3.Str.col_offset = lambda x: random.randint(0, 2147483647)
    a_s_t_0.s = str(random.random())
    a_s_t_1 = ast.Str()
    typed_ast.ast3.Str.lineno = lambda x: random.randint(0, 2147483647)

# Generated at 2022-06-25 23:22:27.579963
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
   #  a_s_t_1 = module_0.dump(a_s_t_0)
    a_s_t_2 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_3, a_s_t_4 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_2)
    print(a_s_t_3)
    print(a_s_t_4)

# Generated at 2022-06-25 23:22:31.769038
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert get_closest_parent_of is not None


# Generated at 2022-06-25 23:22:34.957091
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Case 0
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)


# Generated at 2022-06-25 23:22:36.367307
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass


# Generated at 2022-06-25 23:22:40.253428
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_closest_parent_of(a_s_t_0, a_s_t_0, type(a_s_t_0))


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:22:48.205995
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    module_0.String(s='test_string')

    module_0.Module(body=[a_s_t_0])

    module_0.Module(body=[module_0.body])
    module_0.Module(body=[module_0.body])


# Generated at 2022-06-25 23:22:54.373049
# Unit test for function insert_at
def test_insert_at():
    import typed_ast._ast3 as module_1
    a_s_t_0 = module_1.AST()
    int_0 = 1
    a_s_t_1 = a_s_t_0
    typed_ast_0 = module_1.ast3()
    a_s_t_2 = typed_ast_0
    insert_at(int_0, a_s_t_1, a_s_t_2)


# Generated at 2022-06-25 23:23:00.093633
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Expr()
    a_s_t_2, a_s_t_3 = get_non_exp_parent_and_index(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:23:04.973740
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_2 = module_0.Module(body=[])
    a_s_t_3 = module_0.Expr()
    a_s_t_2.body.append(a_s_t_3)
    a_s_t_4 = get_non_exp_parent_and_index(a_s_t_2, a_s_t_3)
    assert isinstance(a_s_t_4[0], module_0.Module)
    assert a_s_t_4[1] == 0


# Generated at 2022-06-25 23:23:09.940404
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast._ast3 as module_0

    # ast.AST, module_0.AST, module_0.AST
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = get_closest_parent_of(a_s_t_0, a_s_t_1, module_0.AST)


import ast as module_1


# Generated at 2022-06-25 23:23:17.050313
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    assert get_parent(a_s_t_0, a_s_t_0)
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0, rebuild=True)

if __name__ == '__main__':
    import __main__
    import inspect
    print('Running tests for ' + __main__.__file__)
    for _, _test_func in inspect.getmembers(inspect.getmodule(__main__), predicate=inspect.isfunction):
        if _test_func.__name__.startswith('test_'):
            print('Running test for ' + _test_func.__name__)

# Generated at 2022-06-25 23:23:22.540448
# Unit test for function get_parent
def test_get_parent():
    # FIXME: Implement this function
    pass

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:23:31.501621
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    global _index, _parent
    _index = 0
    _parent = 0
    def check_get_non_exp_parent_and_index(a_s_t_0, node_0):
        global _index, _parent
        value_0, count_0 = get_non_exp_parent_and_index(a_s_t_0, node_0)
        if value_0 == _parent and count_0 == _index:
            return 1
        else:
            return 0

    # Test 1
    a_s_t_1 = module_0.For
    a_s_t_2 = ast.Call()
    a_s_t_3 = ast.For(ast.Name("a", ast.Store()), ast.Num(1), [a_s_t_2])
    a_s_

# Generated at 2022-06-25 23:23:33.967769
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree_0 = ast.Module()
    node_0 = ast.Name()
    a_s_t_0 = get_closest_parent_of(tree_0, node_0, ast.AST)



# Generated at 2022-06-25 23:23:37.238587
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_s_t_0 = module_0.AST()
    a_s_t_1, index = get_non_exp_parent_and_index(a_s_t_0, a_s_t_0)
    assert index == 0


# Generated at 2022-06-25 23:23:43.174676
# Unit test for function get_parent
def test_get_parent():
    # Setup of environment for get_parent
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    # Execution of get_parent
    a_s_t_2 = get_parent(a_s_t_0, a_s_t_0)
    # Validation of environment for get_parent
    assert a_s_t_2 == a_s_t_1


# Generated at 2022-06-25 23:23:50.548858
# Unit test for function get_parent
def test_get_parent():
    import unittest
    import ast_helper as helper

    class TestGetParent(unittest.TestCase):

        def test_0(self):
            """Test 0"""
            s = '''#comment0
a = 1
a = 2
#comment1
b = 1
b = 2
'''
            tree = helper.parse(s)
            comment = helper.get_nodes_of_type(tree, ast.Comment)[0]
            self.assertEqual(helper.get_parent(tree, comment), tree)

        def test_1(self):
            """Test 1"""
            s = '''#comment0
#comment1
a = 1
a = 2
#comment2
b = 1
b = 2
'''
            tree = helper.parse(s)
            comment = helper.get_n

# Generated at 2022-06-25 23:23:55.932766
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Create an AST to work with
    root = ast.Module([])
    root.body.append(ast.Expr(ast.Name('None', ast.Load())))
    # Get the parent of the newly created node, and the index of that node
    # in the node's body
    parent, index = get_non_exp_parent_and_index(root, root.body[-1])

    assert parent is root
    assert index == 0



# Generated at 2022-06-25 23:24:04.797324
# Unit test for function get_parent
def test_get_parent():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_2 = module_0.AST()
    a_s_t_2.body = [a_s_t_1]
    a_s_t_3 = a_s_t_2.body[0]
    a_s_t_4 = get_parent(a_s_t_2, a_s_t_3)
    a_s_t_5 = a_s_t_2.body[0]
    a_s_t_6 = get_parent(a_s_t_2, a_s_t_5)
    a_s_t_6.body = None

# Generated at 2022-06-25 23:24:09.379322
# Unit test for function get_parent
def test_get_parent():
    # a_s_t_0 = module_0.AST()
    # a_s_t_1 = get_parent(a_s_t_0, a_s_t_0)

    a_s_t_0 = module_0.Module([])
    a_s_t_1 = module_0.Name('name', module_0.Load())
    a_s_t_2 = module_0.Store()
    a_s_t_3 = get_parent(a_s_t_0, a_s_t_0)
    a_s_t_4 = get_parent(a_s_t_1, a_s_t_0)
    a_s_t_5 = get_parent(a_s_t_0, a_s_t_1)
    a_s

# Generated at 2022-06-25 23:24:15.019216
# Unit test for function get_parent
def test_get_parent():
    from ..utils import get_correct_code, get_node_for_test

    # Test for type of __name__ == '__main__'
    code = get_correct_code()

    node = get_node_for_test(code, 'If')
    parent = get_parent(ast.parse(code), node)

    assert isinstance(parent, ast.Module), "Parent is not Module"
    assert parent.body[0] == node, "Parent.body[0] is wrong"



# Generated at 2022-06-25 23:24:25.379166
# Unit test for function get_parent
def test_get_parent():
    # Test case for valid inputs:
    case1 = ast.parse('def foo():\n    pass')
    assert isinstance(get_parent(case1, case1.body[0]), ast.FunctionDef)
    assert isinstance(get_parent(case1, case1.body[0].body[0]), ast.FunctionDef)

    case2 = ast.parse('class Foo():\n    pass')
    assert isinstance(get_parent(case2, case2.body[0]), ast.Module)
    assert isinstance(get_parent(case2, case2.body[0].body[0]), ast.ClassDef)

    case3 = ast.parse('foo = Foo("bar")')
    assert isinstance(get_parent(case3, case3.body[0]), ast.Module)