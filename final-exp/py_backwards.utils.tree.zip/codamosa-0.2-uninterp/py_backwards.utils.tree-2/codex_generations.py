

# Generated at 2022-06-18 01:14:24.975773
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty


# Generated at 2022-06-18 01:14:35.950717
# Unit test for function get_parent
def test_get_parent():
    import astor
    import astunparse

    tree = ast.parse('''
    def foo():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
    ''')

    _build_parents(tree)

    assert astor.to_source(get_parent(tree, tree.body[0].body[0])) == 'foo()'
    assert astor.to_source(get_parent(tree, tree.body[0].body[1])) == 'foo()'
    assert astor.to_source(get_parent(tree, tree.body[0].body[2])) == 'foo()'
    assert astor.to_source(get_parent(tree, tree.body[0].body[3])) == 'foo()'
    assert astor.to

# Generated at 2022-06-18 01:14:41.795253
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def foo():\n    pass')
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0].value) == tree.body[0].body[0]



# Generated at 2022-06-18 01:14:46.049464
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (tree.body[0], 0)

# Generated at 2022-06-18 01:14:53.430121
# Unit test for function find
def test_find():
    import astor
    tree = astor.parse_file('../../tests/test_files/test_find.py')
    assert len(list(find(tree, ast.FunctionDef))) == 2
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Call))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-18 01:14:59.383704
# Unit test for function get_parent
def test_get_parent():
    import astor
    import ast
    from ..exceptions import NodeNotFound

    tree = astor.parse_file('../../tests/test_files/test_get_parent.py')
    _build_parents(tree)
    parent = get_parent(tree, tree.body[0].body[0].body[0].body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'f'
    parent = get_parent(tree, tree.body[0].body[0].body[0].body[0].body[0],
                        rebuild=True)
    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'f'

# Generated at 2022-06-18 01:15:09.970485
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import _build_parents
    from ..utils import _parents
    from ..utils import find
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_non_exp_parent_and_index

    # Test for function get_parent
    def test_get_parent():
        tree = ast.parse("""
        def foo(x):
            return x + 1
        """)
        _build_parents(tree)
        assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]

# Generated at 2022-06-18 01:15:16.350310
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.FunctionDef))) == 0


# Generated at 2022-06-18 01:15:20.890856
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:15:25.017342
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:22:16.303739
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:22:19.827787
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:22:28.187267
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find

    test_code = """
    def test_function(a, b):
        if a == b:
            print(a)
        else:
            print(b)
    """
    tree = ast.parse(test_code)
    node = tree.body[0].body[0].body[0].body[0]
    assert(isinstance(node, ast.Expr))
    parent = get_parent(tree, node)
    assert(isinstance(parent, ast.If))
   

# Generated at 2022-06-18 01:22:37.144076
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # test case 1
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0
    # test case 2
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    node = tree.body[0].body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1
    # test case 3

# Generated at 2022-06-18 01:22:40.723481
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..utils import get_closest_parent_of


# Generated at 2022-06-18 01:22:48.352140
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Expr))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 3
    assert len(list(find(tree, ast.Store))) == 3
    assert len(list(find(tree, ast.FunctionDef))) == 0
    assert len(list(find(tree, ast.ClassDef))) == 0

# Generated at 2022-06-18 01:22:52.853398
# Unit test for function find
def test_find():
    tree = ast.parse("""
        def foo():
            pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1



# Generated at 2022-06-18 01:22:57.226594
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:22:59.566704
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:23:07.974193
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
        def foo():
            if True:
                return 1
            else:
                return 2
    """)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[1])
    assert isinstance(parent, ast.If)
    assert index == 1

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[1].body[0])
    assert isinstance(parent, ast.If)
    assert index == 1

    parent, index