

# Generated at 2022-06-18 01:14:29.479537
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:14:34.075927
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-18 01:14:43.608343
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)

    if_node = tree.body[0].body[0]
    assert isinstance(if_node, ast.If)

    try:
        get_closest_parent_of(tree, if_node, ast.FunctionDef)
    except NodeNotFound:
        assert False

    try:
        get_closest_parent_of(tree, if_node, ast.If)
    except NodeNotFound:
        assert False

    try:
        get_closest_parent_of(tree, if_node, ast.Module)
    except NodeNotFound:
        assert True

   

# Generated at 2022-06-18 01:14:52.394203
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
        def foo():
            a = 1
            b = 2
            c = 3
    ''')

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[2])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 2


# Generated at 2022-06-18 01:14:59.322558
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]
    assert list(find(tree, ast.Module)) == [tree]
    assert list(find(tree, ast.AST)) == [tree, tree.body[0],
                                         tree.body[0].targets[0],
                                         tree.body[0].value]
    assert list(find(tree, ast.Load)) == [tree.body[0].targets[0].ctx]
    assert list(find(tree, ast.Store)) == []

# Generated at 2022-06-18 01:15:00.799371
# Unit test for function replace_at

# Generated at 2022-06-18 01:15:05.676030
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:15:08.534502
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:15:11.312272
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:15:16.494978
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    node = tree.body[0].body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

# Generated at 2022-06-18 01:15:29.553145
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..utils import get_source_from_ast
    from ..exceptions import NodeNotFound
    from ..ast_utils import get_closest_parent_of

    source = """
    def foo():
        if True:
            return 1
    """

    tree = ast.parse(source)
    node = get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.FunctionDef)
    assert get_source_from_ast(node) == 'def foo():'

    node = get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.If)
    assert get_source_from_ast(node) == 'if True:'


# Generated at 2022-06-18 01:15:32.613809
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    assert len(list(find(tree, ast.If))) == 1

# Generated at 2022-06-18 01:15:35.157218
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:15:38.786974
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2



# Generated at 2022-06-18 01:15:45.325997
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.NameConstant))) == 1

# Generated at 2022-06-18 01:15:48.688724
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    assign = tree.body[0]
    replace_at(0, tree, assign)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=1))])'

# Generated at 2022-06-18 01:15:56.605109
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound
    from ..utils import find
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_closest_parent_of

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1


# Generated at 2022-06-18 01:16:07.330234
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value.left
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value.right
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0



# Generated at 2022-06-18 01:16:08.620474
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse


# Generated at 2022-06-18 01:16:10.155037
# Unit test for function get_parent
def test_get_parent():
    import astor

# Generated at 2022-06-18 01:16:17.198553
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 0

# Generated at 2022-06-18 01:16:20.609015
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def func():\n    pass')
    func_def = tree.body[0]
    pass_stmt = func_def.body[0]
    assert get_non_exp_parent_and_index(tree, pass_stmt) == (func_def, 0)

# Generated at 2022-06-18 01:16:24.048295
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    node = tree.body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 1
    assert parent.body[index] == node

# Generated at 2022-06-18 01:16:32.614596
# Unit test for function get_parent
def test_get_parent():
    import astor
    code = """
    def func():
        a = 1
        b = 2
        c = 3
    """
    tree = astor.parse_file(code)
    a = tree.body[0].body[0]
    b = tree.body[0].body[1]
    c = tree.body[0].body[2]
    assert get_parent(tree, a) == tree.body[0]
    assert get_parent(tree, b) == tree.body[0]
    assert get_parent(tree, c) == tree.body[0]



# Generated at 2022-06-18 01:16:38.891924
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1



# Generated at 2022-06-18 01:16:47.640494
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse(
        """
        def foo():
            if True:
                pass
        """
    )

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.If),
                      ast.If)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.Module),
                      ast.Module)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of

# Generated at 2022-06-18 01:16:53.991193
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value.n) == tree.body[0].value
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:16:54.770354
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:59.836619
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Print))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.FunctionDef))) == 0


# Generated at 2022-06-18 01:17:05.497098
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert index == 0
    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'foo'
    assert parent.body[0] == node

# Generated at 2022-06-18 01:17:19.121466
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 8
    assert len(list(find(tree, ast.AST))) == 8
    assert len(list(find(tree, ast.AST))) == 8

# Generated at 2022-06-18 01:17:27.806865
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            x = 1
            y = 2
            z = 3
    """)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0]) == (tree.body[0].body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[1]) == (tree.body[0].body[0], 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[2]) == (tree.body[0].body[0], 2)

# Generated at 2022-06-18 01:17:28.509943
# Unit test for function get_parent

# Generated at 2022-06-18 01:17:38.831507
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = get_ast('''
    def foo():
        a = 1
        b = 2
        c = 3
    ''')

    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.Module) == tree

    try:
        get_closest_parent_of(tree, tree.body[0].body[0], ast.Name)
    except NodeNotFound:
        pass
    else:
        assert False

# Generated at 2022-06-18 01:17:42.488543
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
        def foo():
            pass
    """)

    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]



# Generated at 2022-06-18 01:17:47.795448
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].value) == tree.body[0]



# Generated at 2022-06-18 01:17:50.798050
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:17:53.664251
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    node = tree.body[0]
    parent = get_parent(tree, node)
    assert isinstance(parent, ast.Module)



# Generated at 2022-06-18 01:17:54.383871
# Unit test for function get_parent

# Generated at 2022-06-18 01:17:58.755389
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:18:08.285222
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def foo():\n    pass')
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None



# Generated at 2022-06-18 01:18:16.064197
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_non_exp_parent_and_index

    tree = ast.parse('''
    def foo():
        pass
    ''')

    try:
        get_non_exp_parent_and_index(tree, tree)
        assert False
    except NodeNotFound:
        pass

    try:
        get_non_exp_parent_and_index(tree, tree.body[0])
        assert False
    except NodeNotFound:
        pass

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert astor.to_source(parent) == 'def foo():\n    pass'
    assert index == 0

# Generated at 2022-06-18 01:18:20.591182
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2


# Generated at 2022-06-18 01:18:27.999364
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            print('foo')
        else:
            print('bar')
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:18:31.830205
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3\n')
    node = tree.body[0].body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

# Generated at 2022-06-18 01:18:36.857456
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 5

# Generated at 2022-06-18 01:18:39.951457
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import parse
    from ..exceptions import NodeNotFound

    tree = parse("""
    def foo():
        if True:
            pass
    """)
    if_node = tree.body[0].body[0]
    pass_node = if_node.body[0]

    assert get_closest_parent_of(tree, pass_node, ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, pass_node, ast.If) == if_node

    try:
        get_closest_parent_of(tree, pass_node, ast.Name)
    except NodeNotFound:
        pass
    else:
        assert False, "NodeNotFound should be raised"

# Generated at 2022-06-18 01:18:45.201541
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nprint(a)')
    node = tree.body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 1

# Generated at 2022-06-18 01:18:45.702644
# Unit test for function get_parent

# Generated at 2022-06-18 01:18:46.765846
# Unit test for function find

# Generated at 2022-06-18 01:18:58.883111
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module),
                      ast.Module)
    assert get_closest_parent_of(tree, node, ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, node, ast.Module) == tree

# Generated at 2022-06-18 01:19:01.602243
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:19:02.293754
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:19:04.801756
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2

# Generated at 2022-06-18 01:19:13.702210
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import ast
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import _build_parents
    from ..utils import _parents
    from ..utils import find
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_non_exp_parent_and_index
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import _build_parents
    from ..utils import _parents
    from ..utils import find
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_non_exp_parent_and_index
    from ..utils import get_closest_parent

# Generated at 2022-06-18 01:19:14.562633
# Unit test for function find

# Generated at 2022-06-18 01:19:24.081941
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty

    tree = ast.parse('''
    def foo(a, b):
        if a:
            if b:
                print(a)
            else:
                print(b)
        else:
            print(a)
    ''')

    # astpretty.pprint(tree)

    node = get_closest_parent_of(tree, tree.body[0].body[0].body[0].body[0],
                                 ast.If)
    assert astor.to_source(node).strip() == 'if b:'

    node = get_closest_parent_of(tree, tree.body[0].body[0].body[0].body[0],
                                 ast.FunctionDef)

# Generated at 2022-06-18 01:19:27.011127
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find, get_non_exp_parent_and_index, \
        insert_at, replace_at, get_closest_parent_of


# Generated at 2022-06-18 01:19:30.134219
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def f(x):
        return x
    """)

    assert get_parent(tree, tree.body[0].body[0].value) == tree.body[0]



# Generated at 2022-06-18 01:19:38.551417
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1 + 2')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value.left) == tree.body[0].value
    assert get_parent(tree, tree.body[0].value.right) == tree.body[0].value
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None



# Generated at 2022-06-18 01:19:52.973766
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            a = 1
            b = 2
        else:
            a = 3
            b = 4
    """)

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(parent) == 'if True:\n    a = 1\n    b = 2\n'

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source

# Generated at 2022-06-18 01:19:59.109834
# Unit test for function get_parent
def test_get_parent():
    # Test for get_parent
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:19:59.817112
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-18 01:20:01.961631
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Print))) == 1

# Generated at 2022-06-18 01:20:06.991692
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:20:10.654128
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    func = tree.body[0]
    pass_ = func.body[0]
    parent, index = get_non_exp_parent_and_index(tree, pass_)
    assert parent == func
    assert index == 0

# Generated at 2022-06-18 01:20:11.846524
# Unit test for function find
def test_find():
    tree = ast.parse('x = 1')
    assert list(find(tree, ast.Name)) == [ast.Name(id='x', ctx=ast.Store())]


# Generated at 2022-06-18 01:20:14.497211
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3

# Generated at 2022-06-18 01:20:15.697332
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:20:24.183382
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import textwrap
    from ..exceptions import NodeNotFound

    code = textwrap.dedent('''
    def foo():
        if True:
            pass
    ''')

    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)

    assert astor.to_source(parent) == 'def foo():'
    assert astunparse.unparse(parent) == 'def foo():\n'

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, node, ast.Module)

# Generated at 2022-06-18 01:20:52.483777
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3')
    node = tree.body[0].body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

# Generated at 2022-06-18 01:20:56.918562
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]



# Generated at 2022-06-18 01:20:58.859400
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of


# Generated at 2022-06-18 01:21:02.187925
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1

# Generated at 2022-06-18 01:21:02.869437
# Unit test for function get_closest_parent_of

# Generated at 2022-06-18 01:21:06.470917
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:21:14.110952
# Unit test for function find
def test_find():
    from ..parser import parse
    from ..utils import get_source
    from ..exceptions import NodeNotFound

    tree = parse(get_source(find))
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Call))) == 1
    assert len(list(find(tree, ast.Attribute))) == 1
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Str))) == 1
    assert len(list(find(tree, ast.List))) == 1

# Generated at 2022-06-18 01:21:15.248506
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty


# Generated at 2022-06-18 01:21:25.115233
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 9


# Generated at 2022-06-18 01:21:33.638404
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.NameConstant))) == 0
    assert len(list(find(tree, ast.Num))) == 0
    assert len(list(find(tree, ast.Str))) == 0
    assert len(list(find(tree, ast.Bytes))) == 0
    assert len(list(find(tree, ast.List))) == 0

# Generated at 2022-06-18 01:23:07.899579
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from . import ast_utils
    from . import ast_transformer
    from . import ast_visitor

    class TestVisitor(ast_visitor.ASTNodeVisitor):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            # Find the closest parent of type ast.Module
            parent = ast_utils.get_closest_parent_of(self.tree, node, ast.Module)
            assert isinstance(parent, ast.Module)

            # Find the closest parent of type ast.FunctionDef
            parent = ast_utils.get_closest_parent_of(self.tree, node,
                                                     ast.FunctionDef)
            assert isinstance(parent, ast.FunctionDef)


# Generated at 2022-06-18 01:23:10.243607
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3')
    node = tree.body[0].body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

# Generated at 2022-06-18 01:23:18.507917
# Unit test for function find
def test_find():
    from ..ast_utils import parse_ast
    from ..exceptions import NodeNotFound

    tree = parse_ast('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

    tree = parse_ast('def foo():\n    pass\ndef bar():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 2
    assert len(list(find(tree, ast.Pass))) == 2

    tree = parse_ast('def foo():\n    pass\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 2


# Generated at 2022-06-18 01:23:19.184030
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:23:21.202255
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:23:27.360456
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    code = """
    def foo():
        if True:
            pass
    """
    tree = ast.parse(code)
    node = tree.body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    code = """
    def foo():
        if True:
            pass
    """
    tree = ast.parse(code)
    node = tree.body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(parent) == 'if True:'

# Generated at 2022-06-18 01:23:30.725941
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        '''
        def foo():
            a = 1
            b = 2
            c = 3
        '''
    )
    node = tree.body[0].body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

# Generated at 2022-06-18 01:23:34.086475
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2


# Generated at 2022-06-18 01:23:38.423245
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            if True:
                if True:
                    pass
    """)
    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    node = tree.body[0].body[0].body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)


# Generated at 2022-06-18 01:23:40.093291
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1

