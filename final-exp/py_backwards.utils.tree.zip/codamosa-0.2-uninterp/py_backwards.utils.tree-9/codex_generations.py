

# Generated at 2022-06-18 01:14:23.421147
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)



# Generated at 2022-06-18 01:14:27.790730
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:14:32.477277
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    if_node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, if_node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:14:37.803869
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:14:41.460127
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:14:42.421338
# Unit test for function get_closest_parent_of

# Generated at 2022-06-18 01:14:43.450249
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:14:48.866133
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3')
    node = tree.body[0].body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert index == 1
    assert isinstance(parent, ast.FunctionDef)

# Generated at 2022-06-18 01:14:53.250706
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:14:59.995586
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound
    from ..utils import find
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_closest_parent_of

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1

    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name)))

# Generated at 2022-06-18 01:15:08.730339
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree) is None



# Generated at 2022-06-18 01:15:14.558340
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find

    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Add))) == 1

    tree = ast.parse('a = 1 + 2\nb = 3 + 4')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 4
    assert len(list(find(tree, ast.Num))) == 4
    assert len(list(find(tree, ast.Add))) == 2

   

# Generated at 2022-06-18 01:15:15.577188
# Unit test for function get_parent

# Generated at 2022-06-18 01:15:26.131158
# Unit test for function replace_at
def test_replace_at():
    import astor
    from ..utils import get_ast_from_source
    from ..visitors import FunctionVisitor
    from ..visitors import ClassVisitor
    from ..visitors import ModuleVisitor
    from ..visitors import Visitor
    from ..visitors import VisitorFactory
    from ..visitors import VisitorType
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
    from ..visitors import VisitorTypeFactory
   

# Generated at 2022-06-18 01:15:30.917965
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1 + 2')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value.left) == tree.body[0].value
    assert get_parent(tree, tree.body[0].value.right) == tree.body[0].value
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]



# Generated at 2022-06-18 01:15:35.902063
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    if_node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, if_node)
    assert parent == tree.body[0].body
    assert index == 0

# Generated at 2022-06-18 01:15:37.627995
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Num))) == 2

# Generated at 2022-06-18 01:15:39.397436
# Unit test for function find
def test_find():
    import astor
    import astunparse
    import astpretty


# Generated at 2022-06-18 01:15:42.142029
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:46.385972
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:15:58.984766
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
    def foo():
        print('hello')
    """)

    print_node = tree.body[0].body[0]
    assert isinstance(print_node, ast.Expr)

    func_node = get_closest_parent_of(tree, print_node, ast.FunctionDef)
    assert isinstance(func_node, ast.FunctionDef)
    assert astor.to_source(func_node) == astunparse.unparse(func_node)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, print_node, ast.Module)

# Generated at 2022-06-18 01:16:02.676844
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1



# Generated at 2022-06-18 01:16:05.950526
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:16:08.482217
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1

# Generated at 2022-06-18 01:16:11.183487
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-18 01:16:19.940134
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound
    from . import find

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1

    try:
        list(find(tree, ast.Load))
    except NodeNotFound:
        pass
    else:
        assert False, 'NodeNotFound not raised'



# Generated at 2022-06-18 01:16:25.446641
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 7

# Generated at 2022-06-18 01:16:29.591689
# Unit test for function find
def test_find():
    from .. import parse
    tree = parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:16:37.175373
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
        def foo():
            if True:
                pass
            else:
                pass
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

    parent, index = get_non_

# Generated at 2022-06-18 01:16:39.743163
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 1



# Generated at 2022-06-18 01:16:44.301271
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2



# Generated at 2022-06-18 01:16:49.854246
# Unit test for function find
def test_find():
    import astor
    import ast
    import astunparse
    import astpretty
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import astpretty
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import astpretty
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import astpretty
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import astpretty
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import astpretty
    import sys
    import os
    import inspect
    import astor

# Generated at 2022-06-18 01:16:52.838782
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert list(find(tree, ast.Assign)) == tree.body[:2]



# Generated at 2022-06-18 01:16:59.554885
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
        def foo():
            pass
    ''')
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.Module),
                      ast.Module)

    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.AST),
                      ast.AST)


# Generated at 2022-06-18 01:17:02.133488
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1

# Generated at 2022-06-18 01:17:04.147162
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 01:17:12.294456
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def func(a):
        if a:
            return a
    """)
    assert get_parent(tree, tree.body[0].body[0].body[0].value) == tree.body[0].body[0]
    assert get_parent(tree, tree.body[0].body[0].body[0]) == tree.body[0].body[0]
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None


# Generated at 2022-06-18 01:17:15.356595
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Module))) == 1



# Generated at 2022-06-18 01:17:16.245791
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:17:26.643843
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
    def foo():
        pass
    ''')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Expr))) == 0

    tree = ast.parse('''
    def foo():
        pass
    ''')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Expr))) == 0



# Generated at 2022-06-18 01:17:35.606612
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1

# Generated at 2022-06-18 01:17:41.357572
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\n'
                     'b = 2\n'
                     'c = 3\n'
                     'd = 4\n'
                     'e = 5\n'
                     'f = 6\n')

    assert get_non_exp_parent_and_index(tree, tree.body[3]) == (tree, 3)
    assert get_non_exp_parent_and_index(tree, tree.body[3].value) == (tree, 3)
    assert get_non_exp_parent_and_index(tree, tree.body[3].value.left) == (tree, 3)
    assert get_non_exp_parent_and_index(tree, tree.body[3].value.right) == (tree, 3)



# Generated at 2022-06-18 01:17:47.119635
# Unit test for function find
def test_find():
    tree = ast.parse('x = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1


# Generated at 2022-06-18 01:17:51.413001
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        print(1)
        print(2)
        print(3)
    """)
    node = tree.body[0].body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

# Generated at 2022-06-18 01:17:55.215581
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:18:00.058537
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1



# Generated at 2022-06-18 01:18:02.945685
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1


# Generated at 2022-06-18 01:18:13.197112
# Unit test for function find
def test_find():
    import astor
    import ast
    import astunparse
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor
    import astunparse
    import ast
    import astor

# Generated at 2022-06-18 01:18:18.618433
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find

    tree = ast.parse('a = 1')
    assert astor.to_source(next(find(tree, ast.Assign))) == 'a = 1'

    tree = ast.parse('a = 1\nb = 2')
    assert astor.to_source(next(find(tree, ast.Assign))) == 'a = 1'

    tree = ast.parse('a = 1\nb = 2')
    assert astor.to_source(next(find(tree, ast.Assign), None)) == 'a = 1'

    tree = ast.parse('a = 1\nb = 2')
    assert astor.to_source(next(find(tree, ast.Assign), None)) == 'a = 1'


# Generated at 2022-06-18 01:18:19.560519
# Unit test for function get_parent

# Generated at 2022-06-18 01:18:25.000020
# Unit test for function find

# Generated at 2022-06-18 01:18:29.939210
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:18:36.843403
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ast import parse
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import find
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_

# Generated at 2022-06-18 01:18:39.726510
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
    def foo():
        if True:
            print('hello')
    """)

    print_node = tree.body[0].body[0].body[0]
    if_node = get_closest_parent_of(tree, print_node, ast.If)
    assert if_node.test.value.s == 'True'

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, print_node, ast.FunctionDef)

# Generated at 2022-06-18 01:18:48.742381
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            print(1)
        else:
            print(2)
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:18:54.662392
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import parse
    from . import get_closest_parent_of
    from . import get_parent
    from . import get_non_exp_parent_and_index
    from . import find
    from . import insert_at
    from . import replace_at
    from . import get_closest_parent_of

    tree = parse('''
    def foo():
        return 1
    ''')

    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.Module) == tree

    tree = parse('''
    def foo():
        return 1
    ''')

    assert get_clos

# Generated at 2022-06-18 01:19:00.922934
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test 1
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    node = tree.body[0].body[1]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    # Test 2
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    node = tree.body[0].body[1]
    assert isinstance(get_closest_parent_of(tree, node, ast.Module),
                      ast.Module)

    # Test 3

# Generated at 2022-06-18 01:19:09.609633
# Unit test for function find
def test_find():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound
    from ..utils import find
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import get_closest_parent_of
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import _build_parents
    from ..utils import _parents

    tree = ast.parse('''
    def foo():
        a = 1
        b = 2
        c = 3
        return a + b + c
    ''')
    _build_parents(tree)

    # Test find
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Assign))) == 3
   

# Generated at 2022-06-18 01:19:11.045100
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert find(tree, ast.Assign)


# Generated at 2022-06-18 01:19:15.121880
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\n')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:19:27.400829
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent

    tree = ast.parse("""
    def foo(a, b):
        return a + b
    """)

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Return))) == 1

    try:
        get_parent(tree, ast.Name(id='a', ctx=ast.Load()))
    except NodeNotFound:
        pass
    else:
        raise AssertionError('NodeNotFound not raised')

    _build_parents(tree)


# Generated at 2022-06-18 01:19:28.708467
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert list(find(tree, ast.FunctionDef)) == [tree.body[0]]



# Generated at 2022-06-18 01:19:31.221258
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            if True:
                pass
    """)
    node = tree.body[0].body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert parent.name == 'foo'

# Generated at 2022-06-18 01:19:32.936952
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:19:35.856365
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import ast
    import astunparse
    import astpretty
    import astor


# Generated at 2022-06-18 01:19:44.792166
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor

# Generated at 2022-06-18 01:19:52.644750
# Unit test for function find
def test_find():
    from ..parser import parse
    from ..utils import get_source
    from ..exceptions import NodeNotFound

    tree = parse(get_source('test_find.py'))
    nodes = list(find(tree, ast.FunctionDef))
    assert len(nodes) == 2
    assert nodes[0].name == 'foo'
    assert nodes[1].name == 'bar'

    nodes = list(find(tree, ast.Name))
    assert len(nodes) == 3
    assert nodes[0].id == 'foo'
    assert nodes[1].id == 'bar'
    assert nodes[2].id == 'baz'

    with pytest.raises(NodeNotFound):
        get_parent(tree, ast.Name(id='foo', ctx=ast.Load()))


# Generated at 2022-06-18 01:19:54.957499
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1

# Generated at 2022-06-18 01:19:58.625579
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
    def foo():
        pass
    """)

    func_def = tree.body[0]
    pass_stmt = func_def.body[0]

    assert isinstance(get_closest_parent_of(tree, pass_stmt, ast.FunctionDef),
                      ast.FunctionDef)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, pass_stmt, ast.ClassDef)

# Generated at 2022-06-18 01:20:03.894913
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)

    if_node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, if_node, ast.FunctionDef),
                      ast.FunctionDef)

    pass_node = if_node.body[0]
    assert isinstance(get_closest_parent_of(tree, pass_node, ast.FunctionDef),
                      ast.FunctionDef)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, pass_node, ast.ClassDef)


# Generated at 2022-06-18 01:20:29.224513
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)

    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (
        tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1]) == (
        tree.body[0], 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[2]) == (
        tree.body[0], 2)

# Generated at 2022-06-18 01:20:35.944471
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astor.code_gen
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find
    from ..utils import _build_parents
    from ..utils import _parents

    # Unit test for function get_parent
    def test_get_parent():
        tree = ast.parse("""
        def foo():
            if True:
                return True
        """)
        _build_parents(tree)
        assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
        assert get_

# Generated at 2022-06-18 01:20:37.492430
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Name)) == [ast.Name(id='a', ctx=ast.Store())]



# Generated at 2022-06-18 01:20:39.340072
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:20:43.652575
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    code = '''
    def foo():
        if True:
            return True
    '''
    tree = ast.parse(code)
    func = tree.body[0]
    if_ = func.body[0]
    ret = if_.body[0]
    assert isinstance(get_closest_parent_of(tree, ret, ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, ret, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, ret, ast.Return), ast.Return)
    assert isinstance(get_closest_parent_of(tree, ret, ast.Module), ast.Module)

# Generated at 2022-06-18 01:20:44.217495
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:20:47.437164
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Expr))) == 3



# Generated at 2022-06-18 01:20:51.167172
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1


# Generated at 2022-06-18 01:20:58.973629
# Unit test for function find

# Generated at 2022-06-18 01:21:07.857258
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            if True:
                return 1
    """)
    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, node, ast.Return), ast.Return)
    assert isinstance(get_closest_parent_of(tree, node, ast.Name), ast.Name)

# Generated at 2022-06-18 01:21:52.120053
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-18 01:21:59.252572
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    code = """
    def foo(x):
        if x == 1:
            return 1
        elif x == 2:
            return 2
        else:
            return 3
    """
    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(node, ast.Return)
    assert astor.to_source(node) == 'return 1'
    parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(parent) == 'if x == 1:\n    return 1'

# Generated at 2022-06-18 01:22:02.922969
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]

# Generated at 2022-06-18 01:22:04.851017
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]


# Generated at 2022-06-18 01:22:09.600994
# Unit test for function get_parent
def test_get_parent():
    import astor
    tree = ast.parse('def foo():\n    pass')
    _build_parents(tree)
    assert astor.to_source(get_parent(tree, tree.body[0])) == '<Module>'
    assert astor.to_source(get_parent(tree, tree.body[0].body[0])) == '<FunctionDef>'
    assert astor.to_source(get_parent(tree, tree.body[0].body[0].body[0])) == '<FunctionDef>'
    assert astor.to_source(get_parent(tree, tree.body[0].body[0].body[0].body[0])) == '<Pass>'

# Generated at 2022-06-18 01:22:18.338461
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            if True:
                if True:
                    pass
    """)

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                            ast.FunctionDef), ast.FunctionDef)

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                            ast.If), ast.If)

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                            ast.Module), ast.Module)

# Generated at 2022-06-18 01:22:26.558190
# Unit test for function find
def test_find():
    import astor
    code = """
    def foo():
        pass
    """
    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Name)))

# Generated at 2022-06-18 01:22:30.944597
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:22:34.594669
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:22:39.749831
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == "def foo():\n    if True:\n        pass"

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(parent) == "if True:\n    pass"

    node = tree.body[0].body[0].body[0]
