

# Generated at 2022-06-18 01:14:29.478808
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import parse
    from ..printer import print_ast
    from ..transformer import transform

    tree = parse('''
    def foo():
        pass
    ''')

    tree = transform(tree)
    node = tree.body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)

    assert print_ast(parent) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:14:34.121180
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2


# Generated at 2022-06-18 01:14:38.039174
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:14:41.665829
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:14:43.729903
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2

# Generated at 2022-06-18 01:14:45.734489
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:14:50.088579
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]


# Generated at 2022-06-18 01:14:57.871908
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
        def foo():
            if True:
                if True:
                    return 1
            return 2
    ''')

    assert astor.to_source(get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.FunctionDef)) == 'def foo():'
    assert astor.to_source(get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.If)) == 'if True:'
    assert astor.to_source(get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.Return))

# Generated at 2022-06-18 01:15:07.337404
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    _build_parents(tree)
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[1]) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[2]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None


# Generated at 2022-06-18 01:15:13.959143
# Unit test for function find
def test_find():
    import astor
    from ast_tools.passes.unused_import import UnusedImport
    from ast_tools.passes.unused_import import UnusedImportVisitor
    from ast_tools.passes.unused_import import UnusedImportTransformer
    from ast_tools.passes.unused_import import UnusedImportPass
    from ast_tools.passes.unused_import import UnusedImportPassManager
    from ast_tools.passes.unused_import import UnusedImportPassManager
    from ast_tools.passes.unused_import import UnusedImportPassManager
    from ast_tools.passes.unused_import import UnusedImportPassManager
    from ast_tools.passes.unused_import import UnusedImportPassManager
    from ast_tools.passes.unused_import import UnusedImport

# Generated at 2022-06-18 01:15:17.885170
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:18.900261
# Unit test for function find

# Generated at 2022-06-18 01:15:23.178583
# Unit test for function find
def test_find():
    """Test function find."""
    tree = ast.parse('a = 1')
    nodes = find(tree, ast.Assign)
    assert len(list(nodes)) == 1
    assert isinstance(list(nodes)[0], ast.Assign)


# Generated at 2022-06-18 01:15:31.035558
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def f():
        if True:
            print(1)
        else:
            print(2)
    """)

    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)

    node = tree.body[0].body[0].body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)

    node = tree.body[0].body[0].body[0].body[0].body[0].value
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)

   

# Generated at 2022-06-18 01:15:41.430654
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from . import ast_utils
    from . import ast_transformer
    from . import ast_visitor

    class TestVisitor(ast_visitor.ASTNodeVisitor):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            self.visit(node.body[0])

        def visit_Expr(self, node: ast.Expr) -> None:
            self.visit(node.value)

        def visit_Call(self, node: ast.Call) -> None:
            self.visit(node.func)

        def visit_Name(self, node: ast.Name) -> None:
            if node.id == 'foo':
                raise NodeNotFound


# Generated at 2022-06-18 01:15:45.205341
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
        def foo():
            pass
    """)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:15:46.039136
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:48.632836
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:15:52.477745
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
        def foo():
            if True:
                pass
            else:
                pass
    """)

    assert get_parent(tree, tree.body[0].body[0].body[0]) == tree.body[0].body[0]
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:15:59.046014
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.AST))) == 7
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:16:10.047318
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass\n')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:16:10.999782
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:15.129352
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 0

# Generated at 2022-06-18 01:16:16.747300
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 01:16:20.510402
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    parent = tree.body[0]
    replace_at(0, parent, ast.parse('b = 2').body[0])
    assert ast.dump(tree) == 'Assign(targets=[Name(id=\'b\', ctx=Store())], value=Num(n=2))'

# Generated at 2022-06-18 01:16:30.494132
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def func():
        if True:
            pass
        else:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, node, ast.AST), ast.AST)
    assert isinstance(get_closest_parent_of(tree, node, ast.AST), ast.AST)

# Generated at 2022-06-18 01:16:35.233104
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
    def foo():
        if True:
            pass
        else:
            pass
    ''')
    if_node = get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.If)
    parent, index = get_non_exp_parent_and_index(tree, if_node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:16:35.816068
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:36.674360
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:37.416846
# Unit test for function get_parent

# Generated at 2022-06-18 01:16:54.361169
# Unit test for function find
def test_find():
    tree = ast.parse("""
        def f():
            pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:16:58.533822
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
        def foo():
            if True:
                pass
            else:
                pass
    """)
    if_node = tree.body[0].body[0]
    else_node = tree.body[0].body[1]
    assert get_non_exp_parent_and_index(tree, if_node) == (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, else_node) == (tree.body[0], 1)

# Generated at 2022-06-18 01:17:05.767413
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def foo():\n    pass')
    parent = get_parent(tree, tree.body[0])
    replace_at(0, parent, ast.parse('def bar():\n    pass'))
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=\'bar\', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])'

# Generated at 2022-06-18 01:17:11.867216
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1 + 2')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value.left) == tree.body[0].value
    assert get_parent(tree, tree.body[0].value.right) == tree.body[0].value
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]



# Generated at 2022-06-18 01:17:19.079795
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2')
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, node, ast.Assign), ast.Assign)

# Generated at 2022-06-18 01:17:25.340547
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo(a):\n    a = 1\n    b = 2\n    c = 3\n    d = 4')
    node = tree.body[0].body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1
    assert parent.body[index] is node

# Generated at 2022-06-18 01:17:27.908023
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    node = tree.body[0].value
    parent = get_parent(tree, node)
    assert isinstance(parent, ast.Assign)
    assert parent.value == node



# Generated at 2022-06-18 01:17:30.483143
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:17:32.158233
# Unit test for function replace_at

# Generated at 2022-06-18 01:17:32.960402
# Unit test for function get_parent

# Generated at 2022-06-18 01:18:01.736194
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Print))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.FunctionDef))) == 0
    assert len(list(find(tree, ast.ClassDef))) == 0

# Generated at 2022-06-18 01:18:06.076633
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def f():\n    a = 1\n    b = 2\n    c = 3\n')
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (
        tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1]) == (
        tree.body[0], 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[2]) == (
        tree.body[0], 2)

# Generated at 2022-06-18 01:18:15.655036
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find
    from ..utils import _build_parents
    from ..utils import _parents

    # Test case 1
    tree = ast.parse('''
    def f(x):
        return x
    ''')
    _build_parents(tree)
    node = tree.body[0].body[0].value
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)

    # Test case 2

# Generated at 2022-06-18 01:18:25.829367
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..utils import parse_code
    from ..exceptions import NodeNotFound

    code = '''
    def foo():
        if True:
            return True
    '''
    tree = parse_code(code)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, node, ast.Name)

# Generated at 2022-06-18 01:18:32.730936
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\n')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7



# Generated at 2022-06-18 01:18:36.276884
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def foo():\n    pass')
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0].value) == tree.body[0].body[0]



# Generated at 2022-06-18 01:18:37.870794
# Unit test for function get_parent

# Generated at 2022-06-18 01:18:42.586330
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo(a, b):
        a = a + b
        return a
    """)
    assert len(list(find(tree, ast.Name))) == 4
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Call))) == 0


# Generated at 2022-06-18 01:18:51.406082
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1

    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2

    tree = ast.parse('a = 1\nif a == 1:\n    b = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 3


# Generated at 2022-06-18 01:18:54.295305
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]


# Generated at 2022-06-18 01:20:08.881861
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass\n')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1

# Generated at 2022-06-18 01:20:17.594301
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find

    code = """
    def foo(a, b):
        return a + b
    """

    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Name))) == 2

    # Test get_parent
    func = list(find(tree, ast.FunctionDef))[0]
    assert get_parent(tree, func) == tree
    assert get_parent(tree, func.body[0]) == func
    assert get_parent(tree, func.body[0].value) == func.body[0]

    # Test get_parent with rebuild


# Generated at 2022-06-18 01:20:23.200950
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo(a, b):
        c = a + b
        return c
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Return))) == 1

# Generated at 2022-06-18 01:20:28.740143
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1


# Generated at 2022-06-18 01:20:35.536613
# Unit test for function get_parent
def test_get_parent():
    import astor
    from astor.code_gen import to_source
    from ..exceptions import NodeNotFound
    from ..utils import get_parent

    tree = ast.parse("""
    def foo():
        pass
    """)

    assert to_source(get_parent(tree, tree.body[0])) == to_source(tree)

    try:
        get_parent(tree, tree.body[0].body[0])
    except NodeNotFound:
        pass
    else:
        raise AssertionError('NodeNotFound not raised')

    tree = ast.parse("""
    def foo():
        pass
    """)

    assert to_source(get_parent(tree, tree.body[0])) == to_source(tree)


# Generated at 2022-06-18 01:20:40.363965
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from . import ast_utils
    from . import ast_visitor
    from . import ast_transformer
    from . import ast_rewriter
    from . import ast_checker

    class TestTransformer(ast_transformer.ASTTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            if node.id == 'a':
                return ast.Name(id='b', ctx=node.ctx)
            return node

    class TestVisitor(ast_visitor.ASTVisitor):
        def visit_Name(self, node: ast.Name) -> None:
            if node.id == 'b':
                node.id = 'c'


# Generated at 2022-06-18 01:20:43.755482
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:20:51.529081
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..utils import get_source
    from ..exceptions import NodeNotFound

    tree = ast.parse(get_source('test_get_closest_parent_of.py'))
    node = tree.body[0].body[0].body[0].body[0].body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == astunparse.unparse(parent)

    node = tree.body[0].body[0].body[0].body[0].body[0].body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)

# Generated at 2022-06-18 01:20:53.244512
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:20:57.112854
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
        def foo():
            return 1
    ''')

    node = tree.body[0].body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.FunctionDef)
    assert index == 0