

# Generated at 2022-06-18 01:14:28.232255
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    assert get_non_exp_parent_and_index(tree, tree.body[0].value) == (tree, 0)

# Generated at 2022-06-18 01:14:38.812886
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent

    tree = ast.parse('''
    def foo():
        if True:
            pass
    ''')

    # Test if function works as expected
    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef) == tree.body[0]

    # Test if function raises NodeNotFound exception
    try:
        get_closest_parent_of(tree, tree.body[0].body[0], ast.Module)
    except NodeNotFound:
        pass
    else:
        assert False, 'NodeNotFound exception not raised'

    # Test if function raises NodeNotFound exception

# Generated at 2022-06-18 01:14:43.371743
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]



# Generated at 2022-06-18 01:14:46.942883
# Unit test for function find
def test_find():
    tree = ast.parse('''
    def foo():
        pass
    ''')

    assert len(list(find(tree, ast.FunctionDef))) == 1

# Generated at 2022-06-18 01:14:54.245729
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import ast
    import astunparse
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def test():
        if True:
            return 1
    """)

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Return)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)

    node = tree.body[0].body[0]
    assert isinstance(node, ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)

    node = tree.body[0]

# Generated at 2022-06-18 01:14:56.734625
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        pass
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:14:57.485458
# Unit test for function get_closest_parent_of

# Generated at 2022-06-18 01:14:59.495118
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index


# Generated at 2022-06-18 01:15:04.403060
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1')
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree
    assert index == 0

# Generated at 2022-06-18 01:15:08.961461
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            print(1)
        else:
            print(2)
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:15:24.293196
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find
    from ..utils import _build_parents

    tree = ast.parse("""
    def foo():
        if True:
            pass
        else:
            pass
    """)
    _build_parents(tree)
    assert get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.If) == tree.body[0].body[0]

# Generated at 2022-06-18 01:15:28.580232
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0],
                                          tree.body[1].targets[0]]

# Generated at 2022-06-18 01:15:34.901752
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1


# Generated at 2022-06-18 01:15:35.902051
# Unit test for function get_parent

# Generated at 2022-06-18 01:15:40.960958
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Expr))) == 3



# Generated at 2022-06-18 01:15:47.420126
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1\nb = 2\n')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1])
    replace_at(index, parent, ast.parse('c = 3\n').body)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id="c", ctx=Store())], value=Num(n=3)), Assign(targets=[Name(id="b", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-18 01:15:55.368905
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    # Test case 1:
    #   def foo():
    #       return 1
    #   foo()
    #
    #   def bar():
    #       return 2
    #   bar()
    #
    #   def baz():
    #       return 3
    #   baz()
    #
    #   def qux():
    #       return 4
    #   qux()
    #
    #   def quux():
    #       return 5
    #   quux()
    #
    #   def corge():
    #       return 6
    #   corge()
    #
    #   def grault():
    #       return 7
    #

# Generated at 2022-06-18 01:16:06.249272
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def f():\n    a = 1\n    b = 2\n    c = 3')
    parent = get_parent(tree, tree.body[0].body[1])
    replace_at(1, parent, ast.parse('b = 2\n    c = 3\n    d = 4').body[0])

# Generated at 2022-06-18 01:16:16.444126
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse

    tree = ast.parse(
        """
        def foo():
            if True:
                return 1
        """
    )

    node = tree.body[0].body[0].body[0]

    parent = get_closest_parent_of(tree, node, ast.FunctionDef)

    assert astor.to_source(parent) == astunparse.unparse(parent) == \
        """
        def foo():
            if True:
                return 1
        """

    parent = get_closest_parent_of(tree, node, ast.If)

    assert astor.to_source(parent) == astunparse.unparse(parent) == \
        """
        if True:
            return 1
        """

    parent = get_closest_parent_

# Generated at 2022-06-18 01:16:21.709773
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_source_code
    from ..utils import get_ast_tree

    source = get_source_code(__file__)
    tree = get_ast_tree(source)

    for node in find(tree, ast.FunctionDef):
        if node.name == 'test_find':
            break
    else:
        raise NodeNotFound('Node not found')

    assert astor.to_source(node) == get_source_code(__file__, 'test_find')

# Generated at 2022-06-18 01:16:31.182954
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass\n')
    assert len(list(find(tree, ast.FunctionDef))) == 1



# Generated at 2022-06-18 01:16:38.259560
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..utils import get_closest_parent_of
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
    def foo():
        if True:
            pass
        else:
            pass
    """)

    if_node = tree.body[0].body[0]
    else_node = tree.body[0].body[1]
    func_node = tree.body[0]

    assert get_closest_parent_of(tree, if_node, ast.FunctionDef) == func_node
    assert get_closest_parent_of(tree, else_node, ast.FunctionDef) == func_node

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, tree, ast.FunctionDef)

# Generated at 2022-06-18 01:16:39.568358
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:16:47.828868
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]
    assert list(find(tree, ast.Expr)) == [tree.body[0]]
    assert list(find(tree, ast.Module)) == [tree]
    assert list(find(tree, ast.Load)) == [tree.body[0].value.ctx]
    assert list(find(tree, ast.Store)) == [tree.body[0].targets[0].ctx]


# Generated at 2022-06-18 01:16:55.607512
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:17:00.709816
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    import astor
    tree = ast.parse('a = 1')
    nodes = list(find(tree, ast.Assign))
    assert len(nodes) == 1
    assert astor.to_source(nodes[0]) == 'a = 1'



# Generated at 2022-06-18 01:17:10.689062
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find, get_closest_parent_of

    tree = ast.parse('def foo():\n\tpass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

    tree = ast.parse('def foo():\n\tpass\n\tpass')
    assert len(list(find(tree, ast.Pass))) == 2

    tree = ast.parse('def foo():\n\tpass\n\tpass\n\tpass')
    assert len(list(find(tree, ast.Pass))) == 3

    tree = ast.parse('def foo():\n\tpass\n\tpass\n\tpass')
   

# Generated at 2022-06-18 01:17:14.647770
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:17:19.677974
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value.n) == tree.body[0].value
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]

# Generated at 2022-06-18 01:17:26.757968
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            return True
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Return), ast.Return)

# Generated at 2022-06-18 01:18:02.119352
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    parent = get_closest_parent_of(tree, tree.body[1], ast.Module)
    replace_at(1, parent, ast.parse('d = 4\ne = 5').body)

# Generated at 2022-06-18 01:18:05.970866
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2

# Generated at 2022-06-18 01:18:15.031182
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
        def foo():
            pass
    """)
    _build_parents(tree)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0]),
                      ast.FunctionDef)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0].value),
                      ast.Pass)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0].value.value),
                      ast.Pass)

# Generated at 2022-06-18 01:18:23.791812
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound

    def test_func():
        a = 1
        b = 2
        c = 3

    tree = ast.parse(astor.to_source(test_func))
    node = tree.body[0].body[2]

    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, node, ast.Name)

# Generated at 2022-06-18 01:18:32.587300
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Expression))) == 1

# Generated at 2022-06-18 01:18:35.931827
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Assign))) == 1



# Generated at 2022-06-18 01:18:40.438289
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1

# Generated at 2022-06-18 01:18:46.983891
# Unit test for function find
def test_find():
    import astor
    import astunparse
    tree = ast.parse('a = 1 + 2')
    nodes = find(tree, ast.BinOp)
    assert len(nodes) == 1
    assert astor.to_source(nodes[0]) == '1 + 2'
    assert astunparse.unparse(nodes[0]) == '1 + 2'

# Generated at 2022-06-18 01:18:56.311312
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find

    code = """
    def foo():
        pass
    """

    tree = ast.parse(code)
    parent = get_parent(tree, tree.body[0])
    assert isinstance(parent, ast.Module)

    for node in find(tree, ast.FunctionDef):
        assert isinstance(node, ast.FunctionDef)

    try:
        get_parent(tree, ast.Module(body=[]))
    except NodeNotFound:
        pass

    code = """
    def foo():
        pass
    """

    tree = ast.parse(code)
    parent = get_parent(tree, tree.body[0])
    assert isinstance(parent, ast.Module)


# Generated at 2022-06-18 01:19:01.596759
# Unit test for function replace_at
def test_replace_at():
    import astor
    import ast
    from ast_tools.passes.rename import Rename
    from ast_tools.passes.inline import Inline
    from ast_tools.passes.unused import Unused
    from ast_tools.passes.unreachable import Unreachable
    from ast_tools.passes.deadcode import DeadCode
    from ast_tools.passes.constant import Constant
    from ast_tools.passes.simplify import Simplify
    from ast_tools.passes.flatten import Flatten
    from ast_tools.passes.inline import Inline
    from ast_tools.passes.unused import Unused
    from ast_tools.passes.unreachable import Unreachable
    from ast_tools.passes.deadcode import DeadCode

# Generated at 2022-06-18 01:20:36.244728
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("""
    def foo():
        pass
    """)

    parent = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    replace_at(0, parent, ast.Pass())

    assert ast.dump(tree) == """
    Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])
    """.strip()

# Generated at 2022-06-18 01:20:43.203848
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:20:50.790487
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_closest_parent_of

    tree = ast.parse('def foo():\n    pass')
    print(astor.to_source(tree))
    print(find(tree, ast.FunctionDef))
    print(find(tree, ast.Pass))
    print(find(tree, ast.Name))
    print(find(tree, ast.Load))
    print(find(tree, ast.Store))
    print(find(tree, ast.Del))
    print(find(tree, ast.AugLoad))

# Generated at 2022-06-18 01:20:52.593796
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:20:57.319966
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree) is None



# Generated at 2022-06-18 01:21:06.569906
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    code = '''
    def foo():
        if True:
            return 1
        else:
            return 2
    '''
    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'
    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(parent) == 'if True:'

# Generated at 2022-06-18 01:21:12.012468
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1\nb = 2')
    parent = get_closest_parent_of(tree, tree.body[0], ast.Module)
    replace_at(0, parent, ast.parse('c = 3').body[0])
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="c", ctx=Store())], value=Num(n=3)), Assign(targets=[Name(id="b", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-18 01:21:14.200144
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2



# Generated at 2022-06-18 01:21:15.543865
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1

# Generated at 2022-06-18 01:21:16.954839
# Unit test for function find
def test_find():
    import astor