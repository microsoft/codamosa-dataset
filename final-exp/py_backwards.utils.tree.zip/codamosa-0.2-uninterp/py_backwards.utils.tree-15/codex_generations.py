

# Generated at 2022-06-18 01:14:29.855708
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
        def foo():
            if True:
                pass
    """)
    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert parent.name == 'foo'

# Generated at 2022-06-18 01:14:40.782762
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def foo():
        if True:
            pass
        else:
            pass
    ''')

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(parent) == 'if True:\n            pass'

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():\n        if True:\n            pass\n        else:\n            pass'

    node = tree.body

# Generated at 2022-06-18 01:14:45.799332
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0
    assert parent.body[index] == node

# Generated at 2022-06-18 01:14:46.810607
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:14:50.325173
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:14:54.773932
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
        else:
            pass
    """)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[1])
    assert isinstance(parent, ast.If)
    assert index == 1

# Generated at 2022-06-18 01:14:58.250344
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1

# Generated at 2022-06-18 01:15:01.816417
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-18 01:15:11.876267
# Unit test for function replace_at
def test_replace_at():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent
    from ..utils import replace_at
    from ..utils import get_non_exp_parent_and_index
    from ..utils import get_closest_parent_of

    # Test for replace_at
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    replace_at(index, parent, ast.parse('a = 1\n    b = 2\n    c = 3'))
    assert astor.to_source(tree) == 'def foo():\n    a = 1\n    b = 2\n    c = 3'

# Generated at 2022-06-18 01:15:15.774005
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:15:27.904779
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1])
    replace_at(index, parent, ast.parse('d = 4').body)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'d\', ctx=Store())], value=Num(n=4)), Assign(targets=[Name(id=\'c\', ctx=Store())], value=Num(n=3))])'

# Generated at 2022-06-18 01:15:32.818891
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:15:42.386239
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 3
    assert len(list(find(tree, ast.Store))) == 3
    assert len(list(find(tree, ast.Load))) == 3
    assert len(list(find(tree, ast.Expression))) == 1
    assert len(list(find(tree, ast.AST))) == 12
    assert len(list(find(tree, ast.AST))) == 12

# Generated at 2022-06-18 01:15:48.092711
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find

    tree = ast.parse("""
    def foo():
        pass
    """)

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

    try:
        list(find(tree, ast.Name))
    except NodeNotFound:
        pass
    else:
        raise AssertionError('NodeNotFound not raised')



# Generated at 2022-06-18 01:15:53.502181
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            if True:
                pass
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:15:54.317884
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:00.506292
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value.n) == tree.body[0].value
    assert get_parent(tree, tree.body[0].value.n) == tree.body[0].value
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].targets[0].id) == tree.body[0].targets[0]
    assert get_parent(tree, tree.body[0].targets[0].id) == tree.body[0].targets[0]

# Generated at 2022-06-18 01:16:09.093804
# Unit test for function find
def test_find():
    import astor
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Call))) == 1
    assert len(list(find(tree, ast.NameConstant))) == 1
    assert len(list(find(tree, ast.arguments))) == 1

# Generated at 2022-06-18 01:16:09.714009
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:19.624218
# Unit test for function replace_at
def test_replace_at():
    import astor
    import astunparse
    import astpretty
    import ast
    import sys
    import os
    import inspect
    import copy
    from astmonkey import transformers
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
    from astmonkey import visitors
   

# Generated at 2022-06-18 01:17:02.128806
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1')
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:17:06.134687
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1


# Generated at 2022-06-18 01:17:12.466889
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
    def foo():
        if True:
            pass
    ''')
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:17:15.605163
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
        else:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:17:16.760578
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:17:20.595775
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:17:29.502596
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def foo():
        if True:
            pass
        else:
            pass
    ''')

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(parent) == 'if True:\n    pass'

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():\n    if True:\n        pass\n    else:\n        pass'

    node = tree.body

# Generated at 2022-06-18 01:17:39.006732
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test case 1
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

    # Test case 2
    tree = ast.parse("""
    def foo():
        if True:
            pass
        else:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

    # Test case 3
    tree = ast.parse

# Generated at 2022-06-18 01:17:44.099359
# Unit test for function find
def test_find():
    tree = ast.parse('import a\nimport b\nimport c')
    assert len(list(find(tree, ast.Import))) == 3
    assert len(list(find(tree, ast.ImportFrom))) == 0
    assert len(list(find(tree, ast.Module))) == 1



# Generated at 2022-06-18 01:17:54.004917
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find
    from ..utils import _build_parents
    from ..utils import _parents
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find
    from ..utils import _build_parents
    from ..utils import _parents
    from ..utils import get_closest_parent_of
   

# Generated at 2022-06-18 01:19:12.472073
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0
    assert isinstance(parent.body[index], ast.If)

# Generated at 2022-06-18 01:19:21.536704
# Unit test for function find
def test_find():
    code = '''
    def foo():
        pass
    '''
    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.arguments))) == 1
    assert len(list(find(tree, ast.arg))) == 0

# Generated at 2022-06-18 01:19:26.648215
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
    def foo():
        if True:
            return 1
    ''')
    node = tree.body[0].body[0].body[0].value
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-18 01:19:29.560092
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:19:39.829831
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty

    tree = ast.parse('''
    def foo():
        if True:
            return 1
    ''')

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    node = tree.body[0].body[0].body[0].value

# Generated at 2022-06-18 01:19:48.726024
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from . import get_closest_parent_of
    from . import get_parent

    tree = ast.parse("""
    def foo():
        pass
    """)

    node = tree.body[0].body[0]
    assert isinstance(node, ast.Pass)

    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert astor.to_source(parent) == "def foo():\n    pass"

    parent = get_closest_parent_of(tree, node, ast.Module)
    assert isinstance(parent, ast.Module)
    assert astor.to_source(parent) == "def foo():\n    pass"

   

# Generated at 2022-06-18 01:19:51.014855
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1


# Generated at 2022-06-18 01:19:52.746320
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert list(find(tree, ast.FunctionDef)) == [tree.body[0]]


# Generated at 2022-06-18 01:19:55.253885
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-18 01:20:01.123577
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1