

# Generated at 2022-06-18 01:14:36.359084
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:14:37.942998
# Unit test for function replace_at
def test_replace_at():
    import astor
    import ast

# Generated at 2022-06-18 01:14:40.100663
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 01:14:43.581165
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0],
                                          tree.body[1].targets[0]]

# Generated at 2022-06-18 01:14:49.859098
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\n'
                     'b = 2\n'
                     'c = 3\n'
                     'd = 4\n')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1])
    assert isinstance(parent, ast.Module)
    assert index == 1
    assert isinstance(parent.body[index], ast.Assign)



# Generated at 2022-06-18 01:14:57.835002
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            print('foo')
    """)

    # Test for function
    func = tree.body[0]
    assert get_closest_parent_of(tree, func, ast.FunctionDef) == func

    # Test for if
    if_ = func.body[0]
    assert get_closest_parent_of(tree, if_, ast.If) == if_

    # Test for print
    print_ = if_.body[0]
    assert get_closest_parent_of(tree, print_, ast.Print) == print_

    # Test for str
    str_ = print_.values[0]

# Generated at 2022-06-18 01:15:08.886850
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from . import get_closest_parent_of
    from . import get_parent
    from . import find
    from . import insert_at
    from . import replace_at
    from . import get_non_exp_parent_and_index

    tree = ast.parse('''
    def foo(x):
        if x:
            return x
        else:
            return 0
    ''')
    print(astor.to_source(tree))
    print(get_closest_parent_of(tree, find(tree, ast.Return).__next__(), ast.FunctionDef))
    print(get_parent(tree, find(tree, ast.Return).__next__()))

# Generated at 2022-06-18 01:15:19.645652
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find

    tree = astor.parse_file('test.py')
    node = find(tree, ast.FunctionDef).__next__()
    parent = get_parent(tree, node)
    parent, index = get_non_exp_parent_and_index(tree, node)
    insert_at(index, parent, node)
    replace_at(index, parent, node)
    get_closest_parent_of(tree, node, ast.FunctionDef)

# Generated at 2022-06-18 01:15:29.338373
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test case 1
    code = """
    def foo():
        a = 1
        b = 2
        c = 3
    """
    tree = ast.parse(code)
    node = tree.body[0].body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

    # Test case 2
    code = """
    def foo():
        a = 1
        b = 2
        c = 3
    """
    tree = ast.parse(code)
    node = tree.body[0].body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1



# Generated at 2022-06-18 01:15:38.558094
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7

# Generated at 2022-06-18 01:15:49.577013
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        return 1
    """)

    node = tree.body[0].body[0].value
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    node = tree.body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:15:53.161880
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]



# Generated at 2022-06-18 01:15:59.937999
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.AST))) == 9

# Generated at 2022-06-18 01:16:08.727601
# Unit test for function get_parent
def test_get_parent():
    import astor
    import ast
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from ..utils import get_parent
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def f(x):
        return x + 1
    ''')
    assert get_parent(tree, tree.body[0].body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0].value, rebuild=True) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0].value.left) == tree.body[0].body[0].value

# Generated at 2022-06-18 01:16:12.537704
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:16:14.846064
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1

# Generated at 2022-06-18 01:16:23.739077
# Unit test for function replace_at
def test_replace_at():
    import astor
    import ast
    import copy
    import random
    import string
    import sys
    import unittest


# Generated at 2022-06-18 01:16:29.385214
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            if True:
                pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:16:32.451980
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0]
    parent = get_parent(tree, node)
    assert parent == tree



# Generated at 2022-06-18 01:16:35.735404
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert list(find(tree, ast.Assign)) == tree.body
    assert list(find(tree, ast.Name)) == tree.body[0].targets + [tree.body[1].value]
    assert list(find(tree, ast.Num)) == [tree.body[0].value, tree.body[1].value]

# Generated at 2022-06-18 01:16:40.180259
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:44.273250
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1


# Generated at 2022-06-18 01:16:45.126781
# Unit test for function get_closest_parent_of

# Generated at 2022-06-18 01:16:48.019047
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:16:50.060310
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:16:58.272535
# Unit test for function get_parent
def test_get_parent():
    import astor
    from ..exceptions import NodeNotFound

    code = '''
    def foo():
        pass
    '''
    tree = ast.parse(code)
    func = tree.body[0]
    pass_ = func.body[0]
    assert get_parent(tree, pass_) == func
    assert get_parent(tree, func) == tree
    assert get_parent(tree, tree) is None
    assert get_parent(tree, ast.parse('pass')) is None
    assert get_parent(tree, ast.parse('pass').body[0]) is None
    assert get_parent(tree, ast.parse('pass').body[0]) is None

    try:
        get_parent(tree, ast.parse('pass').body[0], rebuild=True)
    except NodeNotFound:
        pass

# Generated at 2022-06-18 01:17:02.787836
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]

# Generated at 2022-06-18 01:17:11.063552
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\n'
                     'b = 2\n'
                     'c = 3\n')
    assert list(find(tree, ast.Assign)) == tree.body
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0],
                                          tree.body[1].targets[0],
                                          tree.body[2].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value,
                                         tree.body[1].value,
                                         tree.body[2].value]

# Generated at 2022-06-18 01:17:12.299387
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:17:22.052031
# Unit test for function find
def test_find():
    import astor
    import astunparse
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert astunparse.unparse(find(tree, ast.Assign).__next__()) == 'a = 1'
    assert astunparse.unparse(find(tree, ast.Assign).__next__()) == 'b = 2'
    assert astunparse.unparse(find(tree, ast.Assign).__next__()) == 'c = 3'
    assert astunparse.unparse(find(tree, ast.Assign).__next__()) == 'c = 3'
    assert astunparse.unparse(find(tree, ast.Assign).__next__()) == 'c = 3'

# Generated at 2022-06-18 01:17:30.551741
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:17:40.222071
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    from astor.code_gen import to_source
    from astor.codegen import to_source
    from astor.codegen import to_source
    from astor.code_gen import to_source
    from astor.codegen import to_source
    from astor.code_gen import to_source
    from astor.codegen import to_source
    from astor.code_gen import to_source
    from astor.codegen import to_source
    from astor.code_gen import to_source
    from astor.codegen import to_source
    from astor.code_gen import to_source
    from astor.codegen import to_source
    from astor.code_gen import to_source
    from astor.codegen import to_source

# Generated at 2022-06-18 01:17:48.717496
# Unit test for function replace_at
def test_replace_at():
    import astor
    import astunparse
    import astpretty

    tree = ast.parse('a = 1\nb = 2\nc = 3')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1])
    replace_at(index, parent, ast.parse('d = 4\ne = 5'))
    print(astor.to_source(tree))
    print(astunparse.unparse(tree))
    print(astpretty.pprint(tree))


if __name__ == '__main__':
    test_replace_at()

# Generated at 2022-06-18 01:17:51.370040
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nb = 2\n')
    node = tree.body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree
    assert index == 1

# Generated at 2022-06-18 01:17:59.228602
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert list(find(tree, ast.Assign)) == [tree.body[0], tree.body[1], tree.body[2]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0], tree.body[1].targets[0], tree.body[2].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value, tree.body[1].value, tree.body[2].value]


# Generated at 2022-06-18 01:17:59.695865
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:18:02.879911
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1

# Generated at 2022-06-18 01:18:06.146158
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:18:12.166145
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    parent = get_parent(tree, tree.body[0].value)
    replace_at(0, parent, ast.parse('2').body[0].value)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-18 01:18:17.341876
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def f():\n    a = 1\n    b = 2\n    c = 3\n')
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (
        tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1]) == (
        tree.body[0], 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[2]) == (
        tree.body[0], 2)

# Generated at 2022-06-18 01:18:31.640923
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find
    from ..utils import _build_parents
    from ..utils import _parents

    # Test for get_closest_parent_of

# Generated at 2022-06-18 01:18:34.119506
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:18:38.509442
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-18 01:18:41.306295
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef), ast.FunctionDef)

# Generated at 2022-06-18 01:18:48.720075
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0],
                                          tree.body[1].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value, tree.body[1].value]

# Generated at 2022-06-18 01:18:54.639441
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast
    from ..utils import get_closest_parent_of
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
        def foo():
            if True:
                pass
    """)

    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)

    node = tree.body[0].body[0].body[0].body[0].body[0]

# Generated at 2022-06-18 01:18:57.948810
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-18 01:19:01.030254
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.AST))) == 6

# Generated at 2022-06-18 01:19:02.671221
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:19:11.500865
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
        def foo():
            pass
    ''')

    node = tree.body[0].body[0]
    assert get_closest_parent_of(tree, node, ast.FunctionDef) == tree.body[0]

    node = tree.body[0].body[0]
    assert get_closest_parent_of(tree, node, ast.Module) == tree

    node = tree.body[0].body[0]
    assert get_closest_parent_of(tree, node, ast.ClassDef) is None

    node = tree.body[0].body[0]

# Generated at 2022-06-18 01:19:47.587205
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            return 1
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-18 01:19:52.943062
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (
        tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1]) == (
        tree.body[0], 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[2]) == (
        tree.body[0], 2)

# Generated at 2022-06-18 01:19:55.188320
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:20:00.778424
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value.left
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:20:08.169176
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("""
    def foo():
        pass
    """)
    parent = get_closest_parent_of(tree, tree.body[0], ast.FunctionDef)
    replace_at(0, parent, ast.parse("""
    def bar():
        pass
    """))
    assert ast.dump(tree) == ast.dump(ast.parse("""
    def bar():
        pass
    """))

# Generated at 2022-06-18 01:20:09.052809
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:20:13.373685
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    parent = tree.body[0]
    replace_at(0, parent, ast.parse('b = 2').body[0])
    assert ast.dump(tree) == 'Assign(targets=[Name(id="b", ctx=Store())], ' \
                             'value=Num(n=2))'

# Generated at 2022-06-18 01:20:18.469349
# Unit test for function find
def test_find():
    from ..parser import parse
    from ..exceptions import NodeNotFound

    tree = parse('a = 1')

    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

    with pytest.raises(NodeNotFound):
        get_parent(tree, ast.Num())

    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:20:20.862033
# Unit test for function get_parent

# Generated at 2022-06-18 01:20:24.365972
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    parent = tree.body[0]
    replace_at(0, parent, ast.parse('a = 2').body[0])
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-18 01:22:57.139315
# Unit test for function find

# Generated at 2022-06-18 01:23:03.667707
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            return 1
    """)

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'foo'

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.If)
    assert isinstance(parent, ast.If)
    assert parent.test.value.value is True

# Generated at 2022-06-18 01:23:06.541327
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:23:09.709740
# Unit test for function replace_at
def test_replace_at():
    import astor
    tree = ast.parse("""
    def f():
        pass
    """)
    parent = get_closest_parent_of(tree, tree.body[0], ast.FunctionDef)
    replace_at(0, parent, ast.parse("""
    def g():
        pass
    """).body[0])
    print(astor.to_source(tree))

# Generated at 2022-06-18 01:23:17.697452
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..utils import get_closest_parent_of
    from ..exceptions import NodeNotFound

    code = """
    def foo():
        if True:
            return 1
    """

    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Return)

    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, node, ast.ClassDef)

# Generated at 2022-06-18 01:23:21.867244
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:23:23.530179
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1



# Generated at 2022-06-18 01:23:29.073701
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:23:31.855253
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:23:35.592559
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo():\n    pass\n')
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module),
                      ast.Module)