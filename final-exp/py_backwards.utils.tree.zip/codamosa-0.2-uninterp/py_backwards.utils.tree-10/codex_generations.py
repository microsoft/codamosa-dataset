

# Generated at 2022-06-18 01:14:24.357785
# Unit test for function get_parent

# Generated at 2022-06-18 01:14:29.320306
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0
    assert parent.body[index] is node

# Generated at 2022-06-18 01:14:40.336228
# Unit test for function get_parent
def test_get_parent():
    import astor
    import astunparse
    import textwrap

    code = textwrap.dedent('''
    def foo():
        if True:
            return 1
    ''')

    tree = ast.parse(code)
    _build_parents(tree)

    assert astor.to_source(get_parent(tree, tree.body[0].body[0].body[0])) == \
        astor.to_source(tree.body[0])

    assert astor.to_source(get_parent(tree, tree.body[0].body[0].body[0],
                                      rebuild=True)) == \
        astor.to_source(tree.body[0])


# Generated at 2022-06-18 01:14:44.061284
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:14:48.734037
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None



# Generated at 2022-06-18 01:14:53.471183
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:15:00.135039
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast

# Generated at 2022-06-18 01:15:01.588947
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:10.891442
# Unit test for function replace_at
def test_replace_at():
    import astor
    from ast_tools.passes.base import BasePass
    from ast_tools.passes.base import TransformerPass

    class TestPass(TransformerPass):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            parent, index = get_non_exp_parent_and_index(self.tree, node)
            replace_at(index, parent, [node, node])
            return node

    class TestPass2(BasePass):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            parent, index = get_non_exp_parent_and_index(self.tree, node)
            replace_at(index, parent, [node, node])


# Generated at 2022-06-18 01:15:21.748214
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
    def f(x):
        if x > 0:
            return x
        else:
            return -x
    ''')

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def f(x):'

    node = tree.body[0].body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def f(x):'

   

# Generated at 2022-06-18 01:16:54.386705
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:57.559269
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:17:07.961010
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 8


# Generated at 2022-06-18 01:17:11.807963
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:17:15.812246
# Unit test for function find
def test_find():
    code = """
    def foo():
        pass
    """
    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1


# Generated at 2022-06-18 01:17:22.714041
# Unit test for function find
def test_find():
    from ..parser import parse
    from . import get_source
    from . import get_ast

    source = get_source('find')
    tree = get_ast(source)
    nodes = find(tree, ast.FunctionDef)

    assert len(list(nodes)) == 2

    source = get_source('find2')
    tree = get_ast(source)
    nodes = find(tree, ast.FunctionDef)

    assert len(list(nodes)) == 1



# Generated at 2022-06-18 01:17:27.447597
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nb = 2\n')
    node = tree.body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 1

# Generated at 2022-06-18 01:17:32.708119
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2

# Generated at 2022-06-18 01:17:34.322430
# Unit test for function find

# Generated at 2022-06-18 01:17:35.667054
# Unit test for function find

# Generated at 2022-06-18 01:21:59.001938
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    # Test case 1
    tree = astor.parse_file('test_files/test_get_closest_parent_of.py')
    node = tree.body[0].body[0].body[0].body[0].body[0].body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    # Test case 2
    tree = astor.parse_file('test_files/test_get_closest_parent_of.py')

# Generated at 2022-06-18 01:22:03.940069
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1



# Generated at 2022-06-18 01:22:05.443855
# Unit test for function find
def test_find():
    import astor
    import astunparse

# Generated at 2022-06-18 01:22:07.155096
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:22:08.619729
# Unit test for function find

# Generated at 2022-06-18 01:22:13.855698
# Unit test for function find
def test_find():
    code = '''
    def foo():
        pass
    '''
    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-18 01:22:17.345085
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1


# Generated at 2022-06-18 01:22:21.036249
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:22:23.846975
# Unit test for function find
def test_find():
    tree = ast.parse('def f():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:22:30.055620
# Unit test for function get_parent
def test_get_parent():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_closest_parent_of

    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]

    tree = ast.parse('a = 1\nb = 2')
    assert get_parent(tree, tree.body[0]) == tree