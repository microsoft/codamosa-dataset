

# Generated at 2022-06-18 01:14:35.354162
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert parent == tree.body[0]
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])
    assert parent == tree.body[0]
    assert index == 1

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[2])
    assert parent == tree.body[0]
    assert index == 2

# Generated at 2022-06-18 01:14:37.804351
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:14:42.593431
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    parent = tree.body[0]
    replace_at(0, parent, ast.parse('b = 2').body[0])
    assert ast.dump(tree) == 'Assign(targets=[Name(id="b", ctx=Store())], value=Num(n=2))'



# Generated at 2022-06-18 01:14:43.647950
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:14:50.415707
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def foo():\n    pass')
    parent = tree.body[0]
    replace_at(0, parent, ast.parse('pass').body[0])
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=\'foo\', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])'

# Generated at 2022-06-18 01:14:52.089510
# Unit test for function get_parent

# Generated at 2022-06-18 01:14:52.977852
# Unit test for function get_parent

# Generated at 2022-06-18 01:14:53.682151
# Unit test for function get_parent

# Generated at 2022-06-18 01:14:54.661005
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    import astunparse

# Generated at 2022-06-18 01:15:01.223129
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3

# Generated at 2022-06-18 01:15:07.258149
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:15:14.348135
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2


# Generated at 2022-06-18 01:15:21.584134
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:15:26.276634
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:15:32.470014
# Unit test for function find
def test_find():
    import astor
    import ast
    tree = astor.parse_file('test.py')
    print(astor.dump_tree(tree))
    for node in find(tree, ast.FunctionDef):
        print(astor.dump_tree(node))


# Generated at 2022-06-18 01:15:42.215965
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from . import get_closest_parent_of

    tree = ast.parse('''
    def foo():
        a = 1
        b = 2
        c = 3
        return a + b + c
    ''')

    node = tree.body[0].body[3].value
    assert isinstance(node, ast.BinOp)
    assert astor.to_source(node) == 'a + b + c'

    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)

# Generated at 2022-06-18 01:15:48.275428
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
        def foo():
            if True:
                pass
    ''')
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:15:50.387760
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    nodes = list(find(tree, ast.Name))
    assert len(nodes) == 1
    assert nodes[0].id == 'a'



# Generated at 2022-06-18 01:15:54.752740
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Store))) == 3
    assert len(list(find(tree, ast.Load))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 3
    assert len(list(find(tree, ast.FunctionDef))) == 0


# Generated at 2022-06-18 01:16:05.795941
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent
    from ..utils import find
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_closest_parent_of
    from ..utils import _build_parents
    from ..utils import _parents

    tree = ast.parse("""
    def foo():
        pass
    """)

    # Test find
    assert len(list(find(tree, ast.FunctionDef))) == 1

    # Test get_parent
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)

    # Test get_non_exp_parent_and_index
    assert get_non_exp_parent_and_

# Generated at 2022-06-18 01:16:12.902707
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:14.006974
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-18 01:16:14.986305
# Unit test for function get_parent

# Generated at 2022-06-18 01:16:15.930002
# Unit test for function find

# Generated at 2022-06-18 01:16:24.065273
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find

    tree = ast.parse("""
    def foo():
        if True:
            if True:
                pass
    """)

    # Test get_closest_parent_of
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    # Test get_parent
    node = tree.body[0].body[0].body[0]

# Generated at 2022-06-18 01:16:26.109474
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..visitors import FunctionVisitor


# Generated at 2022-06-18 01:16:31.900388
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value.n) == tree.body[0].value
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]



# Generated at 2022-06-18 01:16:35.334242
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module),
                      ast.Module)

# Generated at 2022-06-18 01:16:38.264478
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    node = tree.body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 1


# Generated at 2022-06-18 01:16:41.301161
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3\n')
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0].value) == \
        (tree.body[0], 0)

# Generated at 2022-06-18 01:16:55.121537
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)



# Generated at 2022-06-18 01:17:00.593954
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            return 1
    """)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0]) == (tree.body[0].body[0], 0)

# Generated at 2022-06-18 01:17:03.544178
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass\n')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:17:12.870707
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 7
    assert len(list(find(tree, ast.AST))) == 7
    assert len(list(find(tree, ast.AST))) == 7

# Generated at 2022-06-18 01:17:23.116615
# Unit test for function get_parent
def test_get_parent():
    # Test for function get_parent
    tree = ast.parse("""
    def foo():
        pass
    """)
    _build_parents(tree)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0]),
                      ast.FunctionDef)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0].value),
                      ast.Pass)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0].value.value),
                      ast.Pass)

# Generated at 2022-06-18 01:17:28.808216
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from typed_ast import ast3 as ast
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            print('hello')
    """)
    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(parent) == "if True:\n    print('hello')"

# Generated at 2022-06-18 01:17:33.223627
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def f():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:17:34.295574
# Unit test for function get_closest_parent_of

# Generated at 2022-06-18 01:17:37.847519
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find, get_non_exp_parent_and_index, \
        insert_at, replace_at, get_closest_parent_of


# Generated at 2022-06-18 01:17:42.199558
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 6



# Generated at 2022-06-18 01:18:31.313222
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def f():\n\tpass')
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]

# Generated at 2022-06-18 01:18:40.908371
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find
    from ..utils import _build_parents
    from ..utils import _parents
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest_parent_of
    from ..utils import get_closest

# Generated at 2022-06-18 01:18:47.769019
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]



# Generated at 2022-06-18 01:18:53.806175
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Expr))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 3
    assert len(list(find(tree, ast.Store))) == 3
    assert len(list(find(tree, ast.FunctionDef))) == 0
    assert len(list(find(tree, ast.ClassDef))) == 0
    assert len(list(find(tree, ast.Return))) == 0

# Generated at 2022-06-18 01:18:56.786771
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 0

# Generated at 2022-06-18 01:19:00.899602
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Print))) == 1
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:19:08.225482
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:19:13.993842
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0],
                                          tree.body[1].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value, tree.body[1].value]

# Generated at 2022-06-18 01:19:19.782832
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1 + 2')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value.left) == tree.body[0].value
    assert get_parent(tree, tree.body[0].value.right) == tree.body[0].value
    assert get_parent(tree, tree.body[0].value.op) == tree.body[0].value



# Generated at 2022-06-18 01:19:21.141338
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty


# Generated at 2022-06-18 01:23:36.544206
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Module))) == 1



# Generated at 2022-06-18 01:23:46.087463
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse

    tree = ast.parse('''
    def foo():
        if True:
            return 1
        else:
            return 2
    ''')

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    node = tree.body[0].body[0].body[0].value

# Generated at 2022-06-18 01:23:46.905280
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]

# Generated at 2022-06-18 01:23:47.891390
# Unit test for function find
def test_find():
    tree = ast.parse('x = 1')
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]

# Generated at 2022-06-18 01:23:54.215114
# Unit test for function find
def test_find():
    tree = ast.parse('''
    def foo():
        pass
    ''')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.NameConstant))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.Del))) == 0
    assert len(list(find(tree, ast.AugLoad))) == 0
    assert len(list(find(tree, ast.AugStore))) == 0
    assert len(list(find(tree, ast.Param))) == 0
   

# Generated at 2022-06-18 01:24:04.431829
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo(x):
        if x:
            return x
        else:
            return x
    """)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[1].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[1].body[1])
    assert isinstance(parent, ast.If)
    assert index

# Generated at 2022-06-18 01:24:09.456050
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]
    assert list(find(tree, ast.Expr)) == []
    assert list(find(tree, ast.Module)) == [tree]



# Generated at 2022-06-18 01:24:12.706067
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]

    assert get_closest_parent_of(tree, node, ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, node, ast.Module) == tree

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, node, ast.ClassDef)

# Generated at 2022-06-18 01:24:22.891271
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent
    from ..utils import find

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1

    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2

    tree = ast.parse('a = 1\n\n\nb = 2')