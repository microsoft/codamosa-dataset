

# Generated at 2022-06-18 01:14:19.344250
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None



# Generated at 2022-06-18 01:14:26.351152
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Store))) == 1

# Generated at 2022-06-18 01:14:27.254208
# Unit test for function find

# Generated at 2022-06-18 01:14:31.211936
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def f():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:14:41.785263
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
    def foo():
        pass
    ''')

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0],
                                            ast.FunctionDef),
                      ast.FunctionDef)

    try:
        get_closest_parent_of(tree, tree.body[0].body[0], ast.ClassDef)
    except NodeNotFound:
        pass
    else:
        assert False, 'Should raise NodeNotFound'

    tree = ast.parse('''
    def foo():
        def bar():
            pass
    ''')


# Generated at 2022-06-18 01:14:42.643801
# Unit test for function replace_at

# Generated at 2022-06-18 01:14:48.553086
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    node = tree.body[0].body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert index == 1
    assert isinstance(parent, ast.FunctionDef)

# Generated at 2022-06-18 01:14:54.040245
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
        else:
            pass
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:14:55.485354
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1



# Generated at 2022-06-18 01:14:57.561548
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:10.927079
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import parse_string
    from ..exceptions import NodeNotFound

    tree = parse_string('''
    def foo():
        pass
    ''')

    # Test for function definition
    func_def = tree.body[0]
    func_def_parent = get_closest_parent_of(tree, func_def, ast.Module)
    assert func_def_parent == tree

    # Test for function body
    func_body = func_def.body[0]
    func_body_parent = get_closest_parent_of(tree, func_body, ast.FunctionDef)
    assert func_body_parent == func_def

    # Test for function body
    func_body_parent = get_closest_parent_of(tree, func_body, ast.Module)
    assert func

# Generated at 2022-06-18 01:15:13.911539
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert list(find(tree, ast.FunctionDef)) == [tree.body[0]]



# Generated at 2022-06-18 01:15:24.860617
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import textwrap
    from ..exceptions import NodeNotFound

    code = textwrap.dedent('''
    def foo():
        if True:
            if True:
                if True:
                    pass
    ''')

    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(node, ast.Pass)

    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():\n'

    parent = get_closest_parent_of(tree, node, ast.If)
    assert isinstance(parent, ast.If)

# Generated at 2022-06-18 01:15:28.992517
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]

# Generated at 2022-06-18 01:15:37.844087
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:15:43.328175
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:15:47.456879
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass\n')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:15:51.140750
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    if_node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, if_node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:15:58.607535
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            if True:
                pass
    """)

    node = tree.body[0].body[0].body[0]
    closest_parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(closest_parent) == 'if True:\n    pass'

    node = tree.body[0].body[0]
    closest_parent = get_closest_parent_of(tree, node, ast.FunctionDef)

# Generated at 2022-06-18 01:16:08.406376
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.AST))) == 9
    assert len(list(find(tree, ast.AST))) == 9
    assert len(list(find(tree, ast.AST))) == 9

# Generated at 2022-06-18 01:16:15.741662
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:16:17.314149
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 01:16:20.475866
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:16:24.841116
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            return 1
    """)
    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'foo'

# Generated at 2022-06-18 01:16:28.534770
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        pass
    """)

    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (
        tree.body[0], 0)

# Generated at 2022-06-18 01:16:36.535117
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo(x):
        if x == 1:
            return 1
        else:
            return 2
    """)

    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(node, ast.Return)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)

    node = tree.body[0].body[0].body[0].body[0].value
    assert isinstance(node, ast.Num)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)

   

# Generated at 2022-06-18 01:16:39.411752
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nprint(a)')
    node = tree.body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 1

# Generated at 2022-06-18 01:16:40.071912
# Unit test for function get_closest_parent_of

# Generated at 2022-06-18 01:16:48.562085
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def foo(a, b):
        if a > b:
            return a
        else:
            return b
    ''')

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo(a, b):'

    node = tree.body[0].body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo(a, b):'


# Generated at 2022-06-18 01:16:49.659509
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-18 01:17:04.021777
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.AST))) == 7



# Generated at 2022-06-18 01:17:11.707141
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1]) == (tree.body[0], 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[2]) == (tree.body[0], 2)


# Generated at 2022-06-18 01:17:15.593541
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:17:16.687067
# Unit test for function find

# Generated at 2022-06-18 01:17:20.432917
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:17:22.898737
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:17:27.585176
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert find(tree, ast.Assign) == [tree.body[0]]
    assert find(tree, ast.Name) == [tree.body[0].targets[0]]
    assert find(tree, ast.Num) == [tree.body[0].value]
    assert find(tree, ast.Expr) == []

# Generated at 2022-06-18 01:17:37.881950
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    assert get_parent(tree, tree.body[0].body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[1].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[2].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[1]) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[2]) == tree.body[0]
    assert get_

# Generated at 2022-06-18 01:17:41.312784
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    tree = astor.parse_file('tests/test_files/test_get_closest_parent_of.py')
    node = tree.body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astunparse.unparse(parent) == 'def foo():\n    pass'

# Generated at 2022-06-18 01:17:51.288156
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    import astunparse
    from ast import parse

    code = '''
    def foo():
        if True:
            pass
        else:
            pass
    '''
    tree = parse(code)
    _build_parents(tree)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert astor.to_source(parent) == 'if True:\n            pass\n        else:\n            pass'
    assert index == 0

    code = '''
    def foo():
        if True:
            pass
        else:
            pass
    '''
    tree = parse(code)
    _build_parents(tree)

# Generated at 2022-06-18 01:18:05.197024
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    import ast

# Generated at 2022-06-18 01:18:08.161335
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from . import ast_utils


# Generated at 2022-06-18 01:18:09.110572
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:18:16.703220
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ast import parse
    from ..exceptions import NodeNotFound

    tree = parse('''
    def foo():
        if True:
            if True:
                pass
    ''')
    node = tree.body[0].body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'
    assert astunparse.unparse(parent) == 'def foo():'

    tree = parse('''
    def foo():
        if True:
            if True:
                pass
    ''')
    node = tree.body[0].body[0].body[0].body[0]
    parent = get_clos

# Generated at 2022-06-18 01:18:18.099790
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:18:27.290436
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..utils import get_closest_parent_of
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def foo():
        if True:
            return 1
    ''')

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Return)

    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    parent = get_closest_parent_of(tree, node, ast.If)
    assert isinstance(parent, ast.If)
    assert astor.to_source(parent) == 'if True:'


# Generated at 2022-06-18 01:18:31.313487
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3\n')
    node = tree.body[0].body[1].targets[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

# Generated at 2022-06-18 01:18:34.602970
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            return 1
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:18:35.383252
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:18:41.409755
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)

    if_node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, if_node, ast.FunctionDef),
                      ast.FunctionDef)

    pass_node = if_node.body[0]
    assert isinstance(get_closest_parent_of(tree, pass_node, ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-18 01:19:22.086217
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:19:30.637471
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.FunctionDef))) == 0
    assert len(list(find(tree, ast.ClassDef))) == 0


# Generated at 2022-06-18 01:19:36.011489
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Assign))) == 1


# Generated at 2022-06-18 01:19:39.655564
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:19:40.607240
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:19:43.288812
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0


# Generated at 2022-06-18 01:19:47.890819
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:19:48.676136
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:19:53.854976
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            if True:
                pass
    """)
    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)



# Generated at 2022-06-18 01:19:54.893606
# Unit test for function find
def test_find():
    import astor
    import ast

# Generated at 2022-06-18 01:22:13.785353
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:22:20.131281
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils.ast_helpers import get_closest_parent_of

    tree = ast.parse('''
        def foo():
            if True:
                pass
    ''')

    if_node = tree.body[0].body[0]
    assert isinstance(if_node, ast.If)

    func_node = get_closest_parent_of(tree, if_node, ast.FunctionDef)
    assert isinstance(func_node, ast.FunctionDef)
    assert astor.to_source(func_node) == 'def foo():'

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, if_node, ast.Module)

# Generated at 2022-06-18 01:22:27.634199
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import ast
    import astunparse
    import sys

    # Test 1
    tree = ast.parse('''
    def f():
        def g():
            pass
    ''')
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)

    # Test 2
    tree = ast.parse('''
    def f():
        def g():
            pass
    ''')
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)

    # Test 3

# Generated at 2022-06-18 01:22:29.792376
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 01:22:30.559149
# Unit test for function get_parent

# Generated at 2022-06-18 01:22:31.840105
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find


# Generated at 2022-06-18 01:22:35.167904
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Print))) == 1

# Generated at 2022-06-18 01:22:36.260610
# Unit test for function find

# Generated at 2022-06-18 01:22:41.004086
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            return 1
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:22:48.197145
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent
    from ..utils import find
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import get_closest_parent_of
    from ..utils import _build_parents
    from ..utils import _parents

    tree = ast.parse('a = 1')
    _build_parents(tree)
    assert _parents[tree.body[0].value] == tree.body[0]
    assert _parents[tree.body[0]] == tree.body
    assert _parents[tree.body] == tree
    assert _parents[tree] is None
    assert get_parent(tree, tree.body[0].value) == tree.body