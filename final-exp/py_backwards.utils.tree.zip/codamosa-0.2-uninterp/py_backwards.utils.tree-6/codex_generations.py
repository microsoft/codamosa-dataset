

# Generated at 2022-06-18 01:14:20.799197
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a + b')
    parent = tree.body[0].value
    replace_at(0, parent, ast.Name(id='c'))
    assert ast.dump(tree) == 'Module(body=[Expr(value=BinOp(left=Name(id=\'c\', ctx=Load()), op=Add(), right=Name(id=\'b\', ctx=Load())))])'

# Generated at 2022-06-18 01:14:24.120834
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3\n')
    node = tree.body[0].body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 1

# Generated at 2022-06-18 01:14:27.100465
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Name)) == [ast.Name(id='a', ctx=ast.Store())]

# Generated at 2022-06-18 01:14:28.163552
# Unit test for function get_parent

# Generated at 2022-06-18 01:14:30.437646
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]

# Generated at 2022-06-18 01:14:33.443842
# Unit test for function find
def test_find():
    """Unit test for function find."""
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1



# Generated at 2022-06-18 01:14:37.712370
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('x = 1')
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None



# Generated at 2022-06-18 01:14:45.416803
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import parse
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = parse('def foo(a, b):\n    return a + b')
    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.Module) == tree
    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.Return) == tree.body[0].body[0]

# Generated at 2022-06-18 01:14:52.609176
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]
    assert list(find(tree, ast.Expr)) == [tree.body[0]]
    assert list(find(tree, ast.Module)) == [tree]
    assert list(find(tree, ast.AST)) == [tree, tree.body[0],
                                         tree.body[0].targets[0],
                                         tree.body[0].value]


# Generated at 2022-06-18 01:14:55.147004
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None



# Generated at 2022-06-18 01:15:40.126682
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty
    import astor.code_gen
    import astor.code_to_ast
    import astor.ast_to_source
    import astor.source_to_ast
    import astor.dump
    import astor.parsefile
    import astor.to_source
    import astor.to_source_code
    import astor.to_source_code_for_ast
    import astor.to_source_code_for_node
    import astor.to_source_code_for_tree
    import astor.to_source_code_for_tuple
    import astor.to_source_code_for_list
    import astor.to_source_code_for_dict
    import astor.to_source_code_for_set


# Generated at 2022-06-18 01:15:49.864483
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def f(x):
        if x:
            return x
        else:
            return x + 1
    """)
    astpretty.pprint(tree)
    print(astor.to_source(tree))
    print(astunparse.unparse(tree))

    node = tree.body[0].body[0].body[1].body[0].value
    print(node)
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    print(parent)
    print(astor.to_source(parent))
    print(astunparse.unparse(parent))

# Generated at 2022-06-18 01:15:55.195468
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def f():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Call))) == 1
    assert len(list(find(tree, ast.keyword))) == 0
    assert len(list(find(tree, ast.arguments))) == 1
    assert len(list(find(tree, ast.arg))) == 0

# Generated at 2022-06-18 01:16:06.213717
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from . import get_closest_parent_of

    tree = ast.parse('''
    def foo():
        if True:
            pass
        else:
            pass
    ''')

    node = tree.body[0].body[0].body[0]

    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)


# Generated at 2022-06-18 01:16:10.705693
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2



# Generated at 2022-06-18 01:16:17.298994
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0], tree.body[1].value.args[0]]
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Print)) == [tree.body[1]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]


# Generated at 2022-06-18 01:16:26.221924
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('def f(x):\n    return x + 1')
    node = tree.body[0].body[0].value.right
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def f(x):\n    return x + 1'

    node = tree.body[0].body[0].value.right
    parent = get_closest_parent_of(tree, node, ast.Module)
    assert astor.to_source(parent) == 'def f(x):\n    return x + 1'


# Generated at 2022-06-18 01:16:35.415841
# Unit test for function find
def test_find():
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast
    from ..exceptions import NodeNotFound
    from ..utils import get_ast


# Generated at 2022-06-18 01:16:36.554725
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-18 01:16:37.680174
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-18 01:17:08.171431
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
        def foo():
            if True:
                pass
            else:
                pass
    ''')
    if_node = tree.body[0].body[0]
    else_node = tree.body[0].body[1]
    assert get_closest_parent_of(tree, if_node, ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, else_node, ast.FunctionDef) == tree.body[0]
    try:
        get_closest_parent_of(tree, tree, ast.FunctionDef)
    except NodeNotFound:
        pass

# Generated at 2022-06-18 01:17:12.780137
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find
    from ..utils import _build_parents


# Generated at 2022-06-18 01:17:21.605115
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 7
    assert len(list(find(tree, ast.AST))) == 7



# Generated at 2022-06-18 01:17:30.057972
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo(a, b):
        if a == b:
            return a + b
        else:
            return a - b
    """)

    node = get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.FunctionDef)
    assert astor.to_source(node) == 'def foo(a, b):'

    node = get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.If)
    assert astor.to_source(node) == 'if a == b:'


# Generated at 2022-06-18 01:17:39.453371
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Print))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Call))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.FunctionDef))) == 0

# Generated at 2022-06-18 01:17:45.075276
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    if_node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, if_node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0


# Generated at 2022-06-18 01:17:46.117315
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:17:48.179526
# Unit test for function find

# Generated at 2022-06-18 01:17:50.980719
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def f():
        pass
    """)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (tree.body[0], 0)

# Generated at 2022-06-18 01:17:58.947100
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    assert get_non_exp_parent_and_index(tree, tree.body[0].value) == (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].value.left) == (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].value.right) == (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].value.op) == (tree, 0)

# Generated at 2022-06-18 01:18:26.339831
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import parse
    from ..utils import get_source
    from ..exceptions import NodeNotFound
    from ..utils.ast import get_closest_parent_of

    tree = parse(get_source(__file__))
    node = find(tree, ast.FunctionDef).__next__()
    parent = get_closest_parent_of(tree, node, ast.Module)

    assert isinstance(parent, ast.Module)

    try:
        get_closest_parent_of(tree, node, ast.FunctionDef)
    except NodeNotFound:
        pass
    else:
        assert False, 'Should raise NodeNotFound'

# Generated at 2022-06-18 01:18:28.422559
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1

# Generated at 2022-06-18 01:18:35.792316
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-18 01:18:40.406144
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)

    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:18:51.123254
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def f():
        if True:
            return 1
    ''')

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def f():'

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def f():'

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_

# Generated at 2022-06-18 01:18:59.824678
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
        def foo():
            if True:
                pass
            else:
                pass
    ''')

    if_node = tree.body[0].body[0]
    else_node = tree.body[0].body[1]

    assert get_closest_parent_of(tree, if_node, ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, else_node, ast.FunctionDef) == tree.body[0]

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, if_node, ast.If)


# Generated at 2022-06-18 01:19:09.207816
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.FunctionDef))) == 0
    assert len(list(find(tree, ast.ClassDef))) == 0
    assert len(list(find(tree, ast.Return))) == 0

# Generated at 2022-06-18 01:19:19.102990
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Store))) == 2

# Generated at 2022-06-18 01:19:19.845909
# Unit test for function get_parent

# Generated at 2022-06-18 01:19:29.951381
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)
    _build_parents(tree)
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].body) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0].value) == tree.body[0].body[0]
    assert get_parent(tree, tree.body[0].body[0].value.value) == tree.body[0].body[0].value

# Generated at 2022-06-18 01:20:16.577807
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Name)) == [ast.Name(id='a', ctx=ast.Store())]



# Generated at 2022-06-18 01:20:19.138247
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:20:27.606591
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent

    tree = ast.parse('''
    def foo():
        pass
    ''')

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

    try:
        get_parent(tree, ast.Pass())
        assert False
    except NodeNotFound:
        pass

    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]

    assert get_non_exp_parent_and_index(tree, tree.body[0]) == (tree, 0)

# Generated at 2022-06-18 01:20:35.094203
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import parse_string
    from ..utils import get_closest_parent_of

    tree = parse_string('def foo():\n    return 1')
    node = tree.body[0].body[0].value
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    tree = parse_string('def foo():\n    return 1')
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    tree = parse_string('def foo():\n    return 1')
    node = tree.body[0]

# Generated at 2022-06-18 01:20:35.784607
# Unit test for function find

# Generated at 2022-06-18 01:20:37.749282
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2

# Generated at 2022-06-18 01:20:45.096867
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    _build_parents(tree)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0]),
                      ast.FunctionDef)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0].body[0]),
                      ast.If)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0].body[0].body[0]),
                      ast.If)

# Generated at 2022-06-18 01:20:47.530120
# Unit test for function find
def test_find():
    import astor
    tree = ast.parse('a = 1')
    assert astor.to_source(list(find(tree, ast.Assign))[0]) == 'a = 1'



# Generated at 2022-06-18 01:20:54.282032
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def test():
        if True:
            return 1
    """)

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Return)

    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert astor.to_source(parent) == "def test():\n    if True:\n        return 1"

    parent = get_closest_parent_of(tree, node, ast.If)
    assert isinstance(parent, ast.If)

# Generated at 2022-06-18 01:20:55.477725
# Unit test for function get_parent

# Generated at 2022-06-18 01:23:52.615989
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
        def foo():
            if True:
                pass
    """)
    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'foo'


# Generated at 2022-06-18 01:23:53.438018
# Unit test for function find

# Generated at 2022-06-18 01:24:03.426798
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty
    from ast import parse
    from ast import FunctionDef, ClassDef, Module
    from ast import Assign, Name, Load, Store, Str, Num, Add, Sub, Mult, Div
    from ast import Call, keyword, arg, keyword, arguments, Attribute, List
    from ast import Expr, Return, If, Compare, Eq, Lt, Gt, LtE, GtE, NotEq
    from ast import BoolOp, And, Or, UnaryOp, Not, USub, UAdd, Invert, NotIn
    from ast import BinOp, Add, Sub, Mult, Div, Mod, Pow, LShift, RShift, BitOr
    from ast import BitXor, BitAnd, FloorDiv, BoolOp, And, Or, UnaryOp, Not

# Generated at 2022-06-18 01:24:11.312751
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound

    tree = ast.parse(
        '''
        def foo():
            if True:
                pass
        '''
    )

    if_node = tree.body[0].body[0]

    assert isinstance(get_closest_parent_of(tree, if_node, ast.FunctionDef),
                      ast.FunctionDef)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, if_node, ast.Module)

    tree = ast.parse(
        '''
        def foo():
            if True:
                pass
        '''
    )

    if_node = tree.body[0].body[0]


# Generated at 2022-06-18 01:24:16.720794
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1

    tree = ast.parse('a = 1\na = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2

    tree = ast.parse('a = 1\na = 2\nprint(a)')
    assert len(list(find(tree, ast.Assign))) == 2