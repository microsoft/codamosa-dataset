

# Generated at 2022-06-18 01:14:27.183170
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Print))) == 1
    assert len(list(find(tree, ast.Call))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.FunctionDef))) == 0

# Generated at 2022-06-18 01:14:37.851442
# Unit test for function get_parent

# Generated at 2022-06-18 01:14:39.551479
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse


# Generated at 2022-06-18 01:14:46.053325
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo(a, b):
        a = a + b
        return a
    """)
    assert get_parent(tree, tree.body[0].body[0].value) == tree.body[0].body[0]
    assert get_parent(tree, tree.body[0].body[0].value.left) == tree.body[0].body[0].value
    assert get_parent(tree, tree.body[0].body[0].value.right) == tree.body[0].body[0].value
    assert get_parent(tree, tree.body[0].body[0].value.left.id) == tree.body[0].body[0].value.left

# Generated at 2022-06-18 01:14:53.430657
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test 1
    tree = ast.parse("""
    def func():
        if True:
            print('Hello')
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

    # Test 2
    tree = ast.parse("""
    def func():
        if True:
            print('Hello')
        else:
            print('World')
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

    # Test 3


# Generated at 2022-06-18 01:14:55.424543
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\n'
                     'b = 2\n'
                     'c = 3\n')
    assert len(list(find(tree, ast.Assign))) == 3



# Generated at 2022-06-18 01:15:07.630675
# Unit test for function find
def test_find():
    tree = ast.parse('def f():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.NameConstant))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.Del))) == 0
    assert len(list(find(tree, ast.AugLoad))) == 0
    assert len(list(find(tree, ast.AugStore))) == 0
    assert len(list(find(tree, ast.Param))) == 0

# Generated at 2022-06-18 01:15:17.885060
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7
    assert len(list(find(tree, ast.Call))) == 0
    assert len(list(find(tree, ast.FunctionDef))) == 0

# Generated at 2022-06-18 01:15:21.666091
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''
        def foo():
            pass
    ''')

    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:15:23.262498
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:30.370521
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def f():
        if True:
            a = 1
        else:
            a = 2
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:15:33.532664
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (
        tree.body[0], 0)

# Generated at 2022-06-18 01:15:39.399372
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-18 01:15:49.159897
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.AST))) == 7
    assert len(list(find(tree, ast.Str))) == 0


# Generated at 2022-06-18 01:15:56.878956
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    code = """
    def foo(a):
        if a == 1:
            return 1
        elif a == 2:
            return 2
        else:
            return 3
    """

    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(node, ast.Return)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.If)

# Generated at 2022-06-18 01:15:58.011601
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:01.631497
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1

# Generated at 2022-06-18 01:16:05.754963
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3')
    node = tree.body[0].body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

# Generated at 2022-06-18 01:16:10.585779
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    print(1)')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:16:20.350058
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert list(find(tree, ast.BinOp)) == [tree.body[0].value]
    assert list(find(tree, ast.Add)) == [tree.body[0].value.op]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value.left,
                                         tree.body[0].value.right]
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Expr)) == [tree.body[0]]
    assert list(find(tree, ast.Module)) == [tree]



# Generated at 2022-06-18 01:16:34.782696
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
    def foo():
        if True:
            return 1
    """)

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    node = tree.body[0].body[0].body[0].value

# Generated at 2022-06-18 01:16:36.895956
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (tree.body[0], 0)

# Generated at 2022-06-18 01:16:39.738851
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:16:41.484382
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)
    parent = get_parent(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)



# Generated at 2022-06-18 01:16:48.380452
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:16:49.265127
# Unit test for function find

# Generated at 2022-06-18 01:16:52.338005
# Unit test for function find
def test_find():
    import astor
    tree = ast.parse('a = 1')
    assert astor.to_source(list(find(tree, ast.Assign))[0]) == 'a = 1'



# Generated at 2022-06-18 01:16:54.104061
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1

# Generated at 2022-06-18 01:17:00.157729
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1

# Generated at 2022-06-18 01:17:10.344734
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import astpretty
    import astor.code_gen
    import astor.misc
    import astor.source_repr
    import astor.store
    import astor.to_source
    import astor.walk
    import astor.visitor
    import astor.codegen
    import astor.codegen.for_stmt
    import astor.codegen.if_stmt
    import astor.codegen.misc
    import astor.codegen.try_stmt
    import astor.codegen.while_stmt
    import astor.codegen.with_stmt
    import astor.codegen.arguments
    import astor.codegen.arg
    import astor.codegen.arguments
    import astor.codegen.arg
   

# Generated at 2022-06-18 01:17:20.607560
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value).__class__ == ast.Assign


# Generated at 2022-06-18 01:17:21.973789
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-18 01:17:28.157298
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Expr))) == 3
    assert len(list(find(tree, ast.Module))) == 1



# Generated at 2022-06-18 01:17:29.862423
# Unit test for function find

# Generated at 2022-06-18 01:17:30.654059
# Unit test for function replace_at

# Generated at 2022-06-18 01:17:33.186800
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1



# Generated at 2022-06-18 01:17:43.159815
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find

    tree = ast.parse('''
    def foo():
        pass
    ''')

    assert len(list(find(tree, ast.FunctionDef))) == 1

    tree = ast.parse('''
    def foo():
        pass
    def bar():
        pass
    ''')

    assert len(list(find(tree, ast.FunctionDef))) == 2

    tree = ast.parse('''
    def foo():
        pass
    def bar():
        pass
    ''')

    assert len(list(find(tree, ast.FunctionDef))) == 2

    tree = ast.parse('''
    def foo():
        pass
    def bar():
        pass
    ''')


# Generated at 2022-06-18 01:17:47.719963
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:17:50.425685
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:17:52.498538
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:18:12.092030
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    parent = tree.body[0]
    replace_at(0, parent, ast.parse('b = 2').body[0])
    assert ast.dump(tree) == 'Assign(targets=[Name(id="b", ctx=Store())], ' \
                             'value=Num(n=2))'

# Generated at 2022-06-18 01:18:18.126414
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            return 1
        else:
            return 2
    """)

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Return)

    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert astor.to_source(parent) == "def foo():"

    node = tree.body[0].body[0].body[1]
    assert isinstance(node, ast.Return)


# Generated at 2022-06-18 01:18:27.291167
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test case 1
    node = ast.parse('a = 1')
    parent, index = get_non_exp_parent_and_index(node, node.body[0])
    assert isinstance(parent, ast.Module)
    assert index == 0

    # Test case 2
    node = ast.parse('def f():\n    a = 1')
    parent, index = get_non_exp_parent_and_index(node, node.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    # Test case 3
    node = ast.parse('def f():\n    a = 1')
    parent, index = get_non_exp_parent_and_index(node, node.body[0])
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-18 01:18:34.444482
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.FunctionDef))) == 0
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:18:35.287727
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:18:41.168881
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def f(x):
        return x + 1
    """)
    assert get_parent(tree, tree.body[0].body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None


# Generated at 2022-06-18 01:18:49.841194
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        return 1
    """)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)
    assert isinstance(get_parent(tree, tree.body[0].body[0].value), ast.Return)
    assert isinstance(get_parent(tree, tree.body[0].body[0].value.value), ast.Num)
    assert isinstance(get_parent(tree, tree.body[0].body[0].value.value.n), ast.Num)


# Generated at 2022-06-18 01:18:51.350812
# Unit test for function get_parent

# Generated at 2022-06-18 01:18:59.823584
# Unit test for function find
def test_find():
    import astor
    import astunparse
    import astpretty
    import astor.code_gen
    import astor.misc
    import astor.codegen
    import astor.to_source
    import astor.code_gen
    import astor.misc
    import astor.codegen
    import astor.to_source
    import astor.code_gen
    import astor.misc
    import astor.codegen
    import astor.to_source
    import astor.code_gen
    import astor.misc
    import astor.codegen
    import astor.to_source
    import astor.code_gen
    import astor.misc
    import astor.codegen
    import astor.to_source
    import astor.code_gen
    import astor.misc

# Generated at 2022-06-18 01:19:01.168796
# Unit test for function find

# Generated at 2022-06-18 01:19:25.416258
# Unit test for function get_parent
def test_get_parent():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent


# Generated at 2022-06-18 01:19:28.055670
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-18 01:19:30.038715
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def f():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1


# Generated at 2022-06-18 01:19:35.295588
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]

    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)



# Generated at 2022-06-18 01:19:38.630678
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:19:39.510110
# Unit test for function find

# Generated at 2022-06-18 01:19:48.240722
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nprint(a)')
    node = tree.body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 1

    tree = ast.parse('def f():\n    a = 1\n    print(a)')
    node = tree.body[0].body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

    tree = ast.parse('def f():\n    a = 1\n    print(a)')
    node = tree.body[0].body[1].value
    parent, index = get_non_

# Generated at 2022-06-18 01:19:49.879254
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1



# Generated at 2022-06-18 01:19:50.636831
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:19:52.665451
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2



# Generated at 2022-06-18 01:21:15.713726
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find

    tree = ast.parse('''
    def foo():
        pass

    def bar():
        pass
    ''')

    assert len(list(find(tree, ast.FunctionDef))) == 2

    foo = find(tree, ast.FunctionDef).__next__()
    assert foo.name == 'foo'

    bar = find(tree, ast.FunctionDef).__next__()
    assert bar.name == 'bar'

    assert astor.to_source(foo) == 'def foo():\n    pass'
    assert astor.to_source(bar) == 'def bar():\n    pass'

    assert get_parent(tree, foo) == tree
    assert get_parent(tree, bar) == tree



# Generated at 2022-06-18 01:21:24.329839
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\n'
                     'b = 2\n'
                     'c = 3\n')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Expr))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Store))) == 3
    assert len(list(find(tree, ast.Load))) == 3
    assert len(list(find(tree, ast.Str))) == 0



# Generated at 2022-06-18 01:21:27.548392
# Unit test for function find
def test_find():
    tree = ast.parse('''
        def foo():
            pass
    ''')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:21:34.096546
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1 + 2')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0].value.left) == tree.body[0].value
    assert get_parent(tree, tree.body[0].value.right) == tree.body[0].value
    assert get_parent(tree, tree.body[0].value.op) == tree.body[0].value
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]



# Generated at 2022-06-18 01:21:36.485004
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:21:41.121633
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3')
    node = tree.body[0].body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 1



# Generated at 2022-06-18 01:21:47.230552
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1])
    replace_at(index, parent, ast.parse('d = 4\ne = 5').body)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id="d", ctx=Store())], value=Num(n=4)), Assign(targets=[Name(id="e", ctx=Store())], value=Num(n=5)), Assign(targets=[Name(id="c", ctx=Store())], value=Num(n=3))])'

# Generated at 2022-06-18 01:21:52.565037
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            return 1
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:21:55.727082
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:22:00.141685
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def foo():
        a = 1
        b = 2
    ''')

    a = tree.body[0].body[0]
    b = tree.body[0].body[1]

    assert get_closest_parent_of(tree, a, ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, b, ast.FunctionDef) == tree.body[0]

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, a, ast.Module)