

# Generated at 2022-06-18 01:14:36.134149
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent

    tree = ast.parse('''
    def foo():
        if True:
            return 1
    ''')

    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'


# Generated at 2022-06-18 01:14:41.623936
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    parent = tree.body[0]
    replace_at(0, parent, ast.parse('b = 2').body[0])
    assert ast.dump(tree) == 'Assign(targets=[Name(id="b", ctx=Store())], ' \
                             'value=Num(n=2))'

# Generated at 2022-06-18 01:14:42.532465
# Unit test for function get_parent

# Generated at 2022-06-18 01:14:43.574301
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-18 01:14:48.645369
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-18 01:14:57.677961
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
    def foo():
        if True:
            pass
        else:
            pass
    ''')

    if_node = tree.body[0].body[0]
    else_node = tree.body[0].body[1]

    assert isinstance(get_closest_parent_of(tree, if_node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, else_node, ast.FunctionDef),
                      ast.FunctionDef)


# Generated at 2022-06-18 01:14:59.292347
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2



# Generated at 2022-06-18 01:15:05.147525
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)
    _build_parents(tree)
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:15:14.635169
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent

    code = '''
    def foo():
        pass
    '''

    tree = ast.parse(code)
    func_def = find(tree, ast.FunctionDef).__next__()
    assert func_def.name == 'foo'

    # Test if NodeNotFound is raised
    try:
        get_parent(tree, func_def)
    except NodeNotFound:
        pass
    else:
        raise AssertionError('NodeNotFound not raised')

    # Test if NodeNotFound is raised
    try:
        get_parent(tree, func_def, rebuild=True)
    except NodeNotFound:
        raise AssertionError('NodeNotFound raised')

    # Test if NodeNotFound is raised

# Generated at 2022-06-18 01:15:20.182667
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    parent = get_parent(tree, tree.body[0])
    replace_at(0, parent, ast.parse('b = 2').body)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="b", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-18 01:15:30.917478
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound
    from . import find
    from . import get_parent
    from . import get_non_exp_parent_and_index
    from . import insert_at
    from . import replace_at
    from . import get_closest_parent_of
    import astor
    import astunparse

    def test_find():
        tree = ast.parse('a = 1')
        assert len(list(find(tree, ast.Name))) == 1
        assert len(list(find(tree, ast.Assign))) == 1
        assert len(list(find(tree, ast.Num))) == 1

    def test_get_parent():
        tree = ast.parse('a = 1')

# Generated at 2022-06-18 01:15:34.548370
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 0

# Generated at 2022-06-18 01:15:43.081012
# Unit test for function find
def test_find():
    import astunparse
    import astor
    import ast
    import os
    import sys
    import inspect
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)
    import py2to3
    import py2to3.fixes.fix_print
    import py2to3.fixes.fix_input
    import py2to3.fixes.fix_raw_input
    import py2to3.fixes.fix_map
    import py2to3.fixes.fix_filter
    import py2to3.fixes.fix_reduce
    import py2to3.fixes.fix_xrange

# Generated at 2022-06-18 01:15:51.172411
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test case 1
    tree = ast.parse("""
    def f():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    # Test case 2
    tree = ast.parse("""
    def f():
        if True:
            pass
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    # Test case 3

# Generated at 2022-06-18 01:15:52.456471
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:56.027087
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2')
    node = tree.body[0].body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:15:57.342986
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:04.139287
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def func():
        if True:
            if True:
                pass
            else:
                pass
        else:
            pass
    """)
    node = tree.body[0].body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:16:11.230159
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..ast_utils import find
    from ..ast_utils import get_parent
    from ..ast_utils import get_non_exp_parent_and_index
    from ..ast_utils import insert_at
    from ..ast_utils import replace_at
    from ..ast_utils import get_closest_parent_of

    tree = ast.parse('''
    def foo(a, b):
        if a:
            return a
        else:
            return b
    ''')

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.If))) == 1
    assert len(list(find(tree, ast.Return))) == 2


# Generated at 2022-06-18 01:16:18.140929
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import textwrap

    code = textwrap.dedent('''
    def foo():
        if True:
            return 1
        else:
            return 2
    ''')

    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo():'
    assert astunparse.unparse(parent) == 'def foo():'



# Generated at 2022-06-18 01:17:19.658797
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 7



# Generated at 2022-06-18 01:17:22.056384
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass\n')
    assert list(find(tree, ast.FunctionDef)) == [tree.body[0]]



# Generated at 2022-06-18 01:17:23.522067
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:17:25.461813
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1


# Generated at 2022-06-18 01:17:27.609604
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    assert get_non_exp_parent_and_index(tree, tree.body[0].value) == (tree, 0)

# Generated at 2022-06-18 01:17:38.047456
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Expr))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 3
    assert len(list(find(tree, ast.Store))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-18 01:17:42.997631
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def f(x):\n    if x:\n        return x')
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:17:52.611509
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound
    import astor
    import astunparse
    import textwrap

    source = textwrap.dedent('''
    def foo():
        x = 1
        y = 2
        return x + y
    ''')
    tree = ast.parse(source)
    assert len(list(find(tree, ast.Name))) == 4
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Load))) == 4

# Generated at 2022-06-18 01:17:56.871699
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
    def foo():
        pass
    ''')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    tree = ast.parse('''
    def foo():
        if True:
            pass
    ''')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    tree = ast.parse('''
    def foo():
        if True:
            pass
    ''')

# Generated at 2022-06-18 01:18:01.457214
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]



# Generated at 2022-06-18 01:19:21.664780
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
    def foo():
        if True:
            return 1
    ''')

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef), ast.FunctionDef)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, tree.body[0].body[0], ast.Module)


# Generated at 2022-06-18 01:19:26.392672
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert parent.name == 'foo'

# Generated at 2022-06-18 01:19:31.200601
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            if False:
                pass
    """)
    node = tree.body[0].body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert parent.name == 'foo'
    parent = get_closest_parent_of(tree, node, ast.If)
    assert parent.test.value.value == False

# Generated at 2022-06-18 01:19:32.421509
# Unit test for function find
def test_find():
    import astor
    import ast

# Generated at 2022-06-18 01:19:42.315227
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

    try:
        get_closest_parent_of(tree, node, ast.ClassDef)
        assert False
    except NodeNotFound:
        pass

    tree = ast.parse("""
    class Foo:
        def bar():
            pass
    """)

# Generated at 2022-06-18 01:19:50.978331
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-18 01:19:54.711364
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 1')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Num))) == 2

# Generated at 2022-06-18 01:20:00.675615
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find, get_non_exp_parent_and_index
    from ..utils import insert_at, replace_at, get_closest_parent_of


# Generated at 2022-06-18 01:20:11.676855
# Unit test for function find
def test_find():
    from ..parser import parse
    from ..utils import dump_ast
    from ..exceptions import NodeNotFound

    tree = parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1

    tree = parse('a = 1\na = 2')
    assert len(list(find(tree, ast.Assign))) == 2

    tree = parse('a = 1\na = 2')
    assert len(list(find(tree, ast.Assign))) == 2

    tree = parse('a = 1\na = 2')
    assert len(list(find(tree, ast.Assign))) == 2

    tree = parse('a = 1\na = 2')
    assert len(list(find(tree, ast.Assign))) == 2

    tree = parse('a = 1\na = 2')
    assert len

# Generated at 2022-06-18 01:20:15.482995
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2



# Generated at 2022-06-18 01:22:10.723619
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]

# Generated at 2022-06-18 01:22:15.054265
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1

# Generated at 2022-06-18 01:22:19.197296
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert find(tree, ast.Assign) == [tree.body[0]]
    assert find(tree, ast.Name) == [tree.body[0].targets[0]]
    assert find(tree, ast.Num) == [tree.body[0].value]
    assert find(tree, ast.Expr) == []
    assert find(tree, ast.Module) == [tree]



# Generated at 2022-06-18 01:22:25.655802
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)

# Generated at 2022-06-18 01:22:29.199763
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-18 01:22:36.753953
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 8


# Generated at 2022-06-18 01:22:45.250415
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 3
    assert len(list(find(tree, ast.Load))) == 3
    assert len(list(find(tree, ast.Store))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-18 01:22:50.664820
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
    def f(x):
        if x > 0:
            return x
        else:
            return -x
    ''')
    node = tree.body[0].body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, node, ast.Return), ast.Return)

# Generated at 2022-06-18 01:22:59.153896
# Unit test for function find
def test_find():
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast

# Generated at 2022-06-18 01:23:02.655235
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            return 1
        else:
            return 2
    """)
    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert parent.name == 'foo'