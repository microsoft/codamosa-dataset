

# Generated at 2022-06-18 01:14:28.349029
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:14:37.804770
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('def foo():\n    pass')
    parent = tree.body[0]
    insert_at(0, parent, ast.parse('print("Hello")'))
    assert ast.dump(tree) == '''
Module(body=[
    FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[
        Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Str(s='Hello')], keywords=[])),
        Pass()
    ], decorator_list=[], returns=None)
])
'''



# Generated at 2022-06-18 01:14:41.746023
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:14:42.606397
# Unit test for function get_parent

# Generated at 2022-06-18 01:14:51.333428
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.Expr))) == 0
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.AST))) == 7
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:14:52.738245
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def foo():\n    pass')
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:14:55.755417
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:15:00.180114
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:15:05.468610
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    replace_at(0, tree, ast.parse('b = 2'))
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="b", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-18 01:15:07.671061
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]

# Generated at 2022-06-18 01:15:21.868698
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def f(x):
        return x + 1
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.Param))) == 1
    assert len(list(find(tree, ast.arguments))) == 1
    assert len(list(find(tree, ast.arg))) == 1
   

# Generated at 2022-06-18 01:15:25.626838
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:15:29.552966
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    print(1)\n    print(2)')
    print_node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, print_node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:15:32.152322
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2

# Generated at 2022-06-18 01:15:37.738482
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:15:41.747188
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent
    from . import find
    from . import get_non_exp_parent_and_index
    from . import insert_at
    from . import replace_at
    from . import get_closest_parent_of


# Generated at 2022-06-18 01:15:46.082111
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\n'
                     'b = 2\n'
                     'c = 3\n')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3

# Generated at 2022-06-18 01:15:46.884698
# Unit test for function get_closest_parent_of

# Generated at 2022-06-18 01:15:54.661957
# Unit test for function find
def test_find():
    import astor
    code = """
    def foo(x):
        return x
    """
    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.arguments))) == 1
    assert len(list(find(tree, ast.arg))) == 1
    assert len(list(find(tree, ast.NameConstant))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-18 01:15:58.121752
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find, get_non_exp_parent_and_index, \
        get_closest_parent_of


# Generated at 2022-06-18 01:16:05.559347
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1



# Generated at 2022-06-18 01:16:10.154927
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 0

# Generated at 2022-06-18 01:16:13.820777
# Unit test for function get_parent
def test_get_parent():
    """Test get_parent function."""
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:16:22.173627
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test case 1
    tree = ast.parse('def foo():\n    pass\n')
    node = tree.body[0].body[0]
    type_ = ast.FunctionDef
    assert get_closest_parent_of(tree, node, type_) == tree.body[0]

    # Test case 2
    tree = ast.parse('def foo():\n    pass\n')
    node = tree.body[0].body[0]
    type_ = ast.Module
    assert get_closest_parent_of(tree, node, type_) == tree

    # Test case 3
    tree = ast.parse('def foo():\n    pass\n')
    node = tree.body[0].body[0]
    type_ = ast.Pass
    assert get_closest_parent_of

# Generated at 2022-06-18 01:16:27.605917
# Unit test for function find
def test_find():
    tree = ast.parse('def f():\n\tpass')
    assert list(find(tree, ast.FunctionDef)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].name]
    assert list(find(tree, ast.Pass)) == [tree.body[0].body[0]]



# Generated at 2022-06-18 01:16:35.152236
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0
    assert isinstance(parent.body[index], ast.Assign)
    assert isinstance(parent.body[index].value, ast.BinOp)
    assert isinstance(parent.body[index].value.left, ast.Num)
    assert isinstance(parent.body[index].value.op, ast.Add)
    assert isinstance(parent.body[index].value.right, ast.Num)

# Generated at 2022-06-18 01:16:39.533230
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..utils import get_closest_parent_of
    code = """
    def foo():
        if True:
            return 1
    """
    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == "def foo():"

# Generated at 2022-06-18 01:16:41.505092
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nprint(a)')
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Print))) == 1

# Generated at 2022-06-18 01:16:46.173831
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:16:51.189432
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2\n    c = 3\n')
    node = tree.body[0].body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:17:04.362044
# Unit test for function find
def test_find():
    # pylint: disable=import-outside-toplevel
    from . import ast_utils
    from . import ast_visitor
    from . import ast_transformer

    tree = ast_utils.parse_code('''
        def foo():
            pass
    ''')

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

    tree = ast_transformer.transform(tree, ast_visitor.Visitor())
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:17:05.766694
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:17:09.777385
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 0

# Generated at 2022-06-18 01:17:16.174228
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse

    tree = ast.parse('''
    def f(a, b):
        if a:
            return b
        else:
            return a
    ''')

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def f(a, b):'

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.If)
    assert astor.to_source(parent) == 'if a:'

    node = tree.body[0].body[0].body[0].value
    parent = get_cl

# Generated at 2022-06-18 01:17:17.354934
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:17:21.973831
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]



# Generated at 2022-06-18 01:17:24.326516
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse


# Generated at 2022-06-18 01:17:29.767689
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1]) == (tree.body[0], 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[2]) == (tree.body[0], 2)

# Generated at 2022-06-18 01:17:33.784864
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nb = 2')
    node = tree.body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 1

# Generated at 2022-06-18 01:17:43.532863
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
        def foo():
            if True:
                pass
            else:
                pass
    ''')

    if_node = tree.body[0].body[0]
    else_node = tree.body[0].body[1]

    assert isinstance(get_closest_parent_of(tree, if_node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, else_node, ast.FunctionDef),
                      ast.FunctionDef)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, if_node, ast.Module)


# Generated at 2022-06-18 01:18:02.331905
# Unit test for function find
def test_find():
    tree = ast.parse('def f():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1



# Generated at 2022-06-18 01:18:03.704812
# Unit test for function find

# Generated at 2022-06-18 01:18:12.204067
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.AST))) == 7


# Generated at 2022-06-18 01:18:15.601257
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
        else:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:18:17.925346
# Unit test for function find

# Generated at 2022-06-18 01:18:21.446124
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            if True:
                pass
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:18:28.648327
# Unit test for function find
def test_find():
    import astor
    from ..examples import example_ast
    from ..examples import example_ast_2
    from ..examples import example_ast_3
    from ..examples import example_ast_4

    for example in [example_ast, example_ast_2, example_ast_3, example_ast_4]:
        for node in find(example, ast.FunctionDef):
            print(astor.to_source(node))


# Generated at 2022-06-18 01:18:30.676059
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert list(find(tree, ast.FunctionDef)) == [tree.body[0]]



# Generated at 2022-06-18 01:18:34.570622
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def f(a):
        if a:
            return a
        else:
            return 0
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0


# Generated at 2022-06-18 01:18:41.449103
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def test():
        a = 1
        b = 2
        c = 3
    """)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1]) == (tree.body[0], 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[2]) == (tree.body[0], 2)

# Generated at 2022-06-18 01:18:59.418381
# Unit test for function get_parent

# Generated at 2022-06-18 01:18:59.912766
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:19:04.802018
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            print('foo')
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:19:07.917312
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 0

# Generated at 2022-06-18 01:19:16.707320
# Unit test for function find
def test_find():
    import astor
    import ast
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import ast
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import ast
   

# Generated at 2022-06-18 01:19:21.025201
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert list(find(tree, ast.FunctionDef)) == [tree.body[0]]
    assert list(find(tree, ast.Pass)) == [tree.body[0].body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].name]



# Generated at 2022-06-18 01:19:24.618226
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3



# Generated at 2022-06-18 01:19:29.420343
# Unit test for function get_parent
def test_get_parent():
    code = """
    def foo():
        pass
    """
    tree = ast.parse(code)
    func_def = tree.body[0]
    pass_ = func_def.body[0]
    assert get_parent(tree, pass_) == func_def
    assert get_parent(tree, func_def) == tree
    assert get_parent(tree, tree) is None


# Generated at 2022-06-18 01:19:39.363500
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            pass
        else:
            pass
    """)

    if_node = tree.body[0].body[0]
    else_node = tree.body[0].body[1]

    assert isinstance(get_closest_parent_of(tree, if_node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, else_node, ast.FunctionDef),
                      ast.FunctionDef)

    try:
        get_closest_parent_of(tree, tree, ast.FunctionDef)
    except NodeNotFound:
        pass
   

# Generated at 2022-06-18 01:19:44.240594
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find

    tree = ast.parse("""
    def foo():
        pass
    """)

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

    with pytest.raises(NodeNotFound):
        list(find(tree, ast.Name))



# Generated at 2022-06-18 01:22:20.503711
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo(a, b):
        if a:
            return b
        else:
            return a
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1].body[1])
    assert isinstance(parent, ast.If)
    assert index == 1

# Generated at 2022-06-18 01:22:24.023814
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    print(1)')
    node = tree.body[0].body[0]

    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:22:26.858812
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)



# Generated at 2022-06-18 01:22:36.206733
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test case 1
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

    # Test case 2
    tree = ast.parse("""
    def foo():
        if True:
            pass
        else:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0

    # Test case 3
    tree = ast.parse

# Generated at 2022-06-18 01:22:41.042147
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]

# Generated at 2022-06-18 01:22:43.711320
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (
        tree.body[0], 0)

# Generated at 2022-06-18 01:22:47.557065
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            a = 1
        else:
            a = 2
    """)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:22:57.098860
# Unit test for function get_parent
def test_get_parent():
    import astor
    import ast
    import astunparse
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def test():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
    ''')


# Generated at 2022-06-18 01:22:58.170201
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-18 01:23:00.828992
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1