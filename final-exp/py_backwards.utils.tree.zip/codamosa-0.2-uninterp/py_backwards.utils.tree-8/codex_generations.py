

# Generated at 2022-06-18 01:14:29.797120
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)

    if_node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, if_node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:14:34.386478
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo(a):
        return a + 1
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Name))) == 1

# Generated at 2022-06-18 01:14:35.307854
# Unit test for function insert_at

# Generated at 2022-06-18 01:14:36.383171
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 01:14:42.570435
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound

    tree = ast.parse("""
    def foo():
        pass
    """)

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef), ast.FunctionDef)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, tree.body[0].body[0], ast.ClassDef)

# Generated at 2022-06-18 01:14:47.388155
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:14:53.522732
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0],
                                          tree.body[1].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value,
                                         tree.body[1].value]
    assert list(find(tree, ast.Expr)) == [tree.body[0].value,
                                          tree.body[1].value]
    assert list(find(tree, ast.Module)) == [tree]



# Generated at 2022-06-18 01:14:55.985676
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:15:00.558038
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nb = 2\n')
    node = tree.body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 1

# Generated at 2022-06-18 01:15:10.654774
# Unit test for function insert_at
def test_insert_at():
    import astor
    import ast
    from ast import Assign, Name, Load, Num, Add
    from ast import Module, FunctionDef, arguments, Expr, Return
    from ast import Call, keyword, arg, NameConstant, Store, Subscript
    from ast import Index, List, Tuple, Attribute, Str, Sub, Div, Mult
    from ast import USub, UAdd, BitXor, BitOr, BitAnd, Invert, Not, In, Is
    from ast import IsNot, NotIn, Eq, NotEq, Lt, LtE, Gt, GtE, And, Or, Add
    from ast import ListComp, SetComp, DictComp, GeneratorExp, IfExp, Compare
    from ast import BoolOp, BinOp, UnaryOp, Lambda, If, With, Raise, Try
    from ast import Assert

# Generated at 2022-06-18 01:15:25.058194
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    parent = get_closest_parent_of(tree, tree.body[1], ast.Module)
    replace_at(1, parent, ast.parse('d = 4\ne = 5').body)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id="d", ctx=Store())], value=Num(n=4)), Assign(targets=[Name(id="e", ctx=Store())], value=Num(n=5)), Assign(targets=[Name(id="c", ctx=Store())], value=Num(n=3))])'

# Generated at 2022-06-18 01:15:32.722128
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    from astor.code_gen import to_source
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def foo():
        if True:
            if True:
                pass
            else:
                pass
        else:
            pass
    ''')

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[1])
    assert isinstance(parent, ast.If)
    assert index == 1


# Generated at 2022-06-18 01:15:33.741505
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:39.231581
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    if_node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, if_node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:15:45.728524
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a = 1\n    b = 2')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0
    assert parent.body[index] == node

# Generated at 2022-06-18 01:15:46.548469
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:47.381087
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:48.167245
# Unit test for function find

# Generated at 2022-06-18 01:15:54.130037
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1]) == (tree.body[0], 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[2]) == (tree.body[0], 2)


# Generated at 2022-06-18 01:16:00.286696
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of

    tree = ast.parse('''
    def foo():
        if True:
            pass
        else:
            pass
    ''')

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Pass)

    parent = get_closest_parent_of(tree, node, ast.If)
    assert isinstance(parent, ast.If)
    assert astor.to_source(parent) == 'if True:\n    pass\nelse:\n    pass'

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, node, ast.FunctionDef)

# Generated at 2022-06-18 01:16:07.330642
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3



# Generated at 2022-06-18 01:16:08.249224
# Unit test for function get_parent

# Generated at 2022-06-18 01:16:09.434773
# Unit test for function get_parent

# Generated at 2022-06-18 01:16:13.464017
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def foo():\n    pass')
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree) is None



# Generated at 2022-06-18 01:16:22.822052
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.NameConstant))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 0
    assert len(list(find(tree, ast.Del))) == 0
    assert len(list(find(tree, ast.AugLoad))) == 0
    assert len(list(find(tree, ast.AugStore))) == 0
    assert len(list(find(tree, ast.Param))) == 0

# Generated at 2022-06-18 01:16:24.065613
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:16:27.701070
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1



# Generated at 2022-06-18 01:16:35.581207
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.FunctionDef))) == 0
    assert len(list(find(tree, ast.ClassDef))) == 0


# Generated at 2022-06-18 01:16:39.315993
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        """
        def foo():
            if True:
                print(1)
            else:
                print(2)
        """
    )
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-18 01:16:41.672936
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if True:
            if True:
                pass
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0