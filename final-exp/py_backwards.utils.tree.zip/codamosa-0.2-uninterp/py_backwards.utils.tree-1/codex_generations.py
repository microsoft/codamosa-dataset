

# Generated at 2022-06-18 01:14:33.392524
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-18 01:14:37.056278
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:14:45.222948
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, get_non_exp_parent_and_index, find, insert_at, replace_at, get_closest_parent_of
    tree = ast.parse("""
    def f(x):
        return x + 1
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.BinOp))) == 1

# Generated at 2022-06-18 01:14:48.145479
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]

# Generated at 2022-06-18 01:14:50.641571
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-18 01:14:56.789796
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.AST))) == 5



# Generated at 2022-06-18 01:15:04.831828
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..exceptions import NodeNotFound
    from ..parser import parse_string
    from ..utils import get_closest_parent_of

    tree = parse_string('def foo():\n    pass')

    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef) \
        == tree.body[0]

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, tree.body[0].body[0], ast.ClassDef)

# Generated at 2022-06-18 01:15:06.768909
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]



# Generated at 2022-06-18 01:15:13.066130
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ast_tools.passes.base import TransformerPass
    from ast_tools.passes.unused import UnusedImportPass

    class TestPass(TransformerPass):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            parent = get_closest_parent_of(self.tree, node, ast.Module)
            assert isinstance(parent, ast.Module)
            return node

    code = """
    import os

    def foo():
        pass
    """
    tree = ast.parse(code)
    UnusedImportPass().visit(tree)
    TestPass().visit(tree)
    assert astor.to_source(tree) == """
    def foo():
        pass
    """

# Generated at 2022-06-18 01:15:14.182832
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:15:53.543547
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Store))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.AST))) == 8


# Generated at 2022-06-18 01:15:55.399893
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1

# Generated at 2022-06-18 01:16:01.924406
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    node = tree.body[0].body[1].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

# Generated at 2022-06-18 01:16:05.429778
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:16:07.388819
# Unit test for function find

# Generated at 2022-06-18 01:16:12.413997
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2


# Generated at 2022-06-18 01:16:22.165942
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    assert len(list(find(tree, ast.Assign))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Num))) == 3
    assert len(list(find(tree, ast.Expr))) == 3
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Store))) == 3
    assert len(list(find(tree, ast.Load))) == 3
    assert len(list(find(tree, ast.AST))) == 10
    assert len(list(find(tree, ast.alias))) == 0
    assert len(list(find(tree, ast.arguments))) == 0

# Generated at 2022-06-18 01:16:26.170938
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def foo():\n    pass')
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]

# Generated at 2022-06-18 01:16:34.473506
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\n')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.AST))) == 8


# Generated at 2022-06-18 01:16:41.808824
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound

    code = """
    def foo():
        if True:
            return 1
    """

    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == astor.to_source(tree.body[0])

    node = tree.body[0].body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(parent) == astor.to_source(tree.body[0])


# Generated at 2022-06-18 01:17:08.164704
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]


# Generated at 2022-06-18 01:17:14.484927
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.AST))) == 9


# Generated at 2022-06-18 01:17:25.249675
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    from ..exceptions import NodeNotFound
    from ..utils import get_closest_parent_of
    from ..utils import get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at
    from ..utils import replace_at
    from ..utils import find
    from ..utils import _build_parents

    # test get_parent
    tree = ast.parse("""
    def foo():
        pass
    """)
    _build_parents(tree)
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]

    # test get_non_exp_parent_and_index
    tree = ast.parse("""
    def foo():
        pass
    """)
    _build

# Generated at 2022-06-18 01:17:29.969826
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.Name)) == [tree.body[0].targets[0]]
    assert list(find(tree, ast.Num)) == [tree.body[0].value]



# Generated at 2022-06-18 01:17:35.493285
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        """
        def foo():
            a = 1
            b = 2
            c = 3
            return a + b + c
        """
    )
    node = tree.body[0].body[2].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 2

# Generated at 2022-06-18 01:17:38.786382
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 0

# Generated at 2022-06-18 01:17:42.618742
# Unit test for function find
def test_find():
    tree = ast.parse('def f():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:17:52.311576
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import get_parent, find

    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2

    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 4

    tree = ast.parse('a = 1\nif a == 1:\n    b = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 5


# Generated at 2022-06-18 01:17:54.316216
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 01:18:03.499697
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound

    code = """
    def foo():
        if True:
            pass
        else:
            pass
    """
    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Pass)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, node, ast.AST), ast.Module)



# Generated at 2022-06-18 01:18:29.462826
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1



# Generated at 2022-06-18 01:18:36.563864
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find

    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Load))) == 1

    tree = ast.parse('def foo():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

# Generated at 2022-06-18 01:18:38.070406
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:18:41.314213
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:18:43.680591
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-18 01:18:50.854686
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert len(list(find(tree, ast.BinOp))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Add))) == 1
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Store))) == 1



# Generated at 2022-06-18 01:18:59.817689
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..exceptions import NodeNotFound
    from ..ast_utils import get_closest_parent_of

    tree = ast.parse("""
    def foo():
        if True:
            return 1
    """)

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Return)

    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert astor.to_source(parent) == "def foo():\n    if True:\n        return 1"

    parent = get_closest_parent_of(tree, node, ast.If)
    assert isinstance(parent, ast.If)

# Generated at 2022-06-18 01:19:02.739280
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert find(tree, ast.Assign)
    assert not find(tree, ast.Name)
    assert not find(tree, ast.Num)



# Generated at 2022-06-18 01:19:07.274143
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
        def foo():
            pass
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-18 01:19:10.018236
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-18 01:20:15.978981
# Unit test for function find
def test_find():
    from ..parser import parse
    from ..exceptions import NodeNotFound

    tree = parse('def foo():\n    pass')

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Pass))) == 1

    with pytest.raises(NodeNotFound):
        get_parent(tree, ast.FunctionDef())

    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0],
                                            ast.FunctionDef), ast.FunctionDef)


# Generated at 2022-06-18 01:20:25.237859
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def f():\n    a = 1\n    b = 2\n')
    node = tree.body[0].body[0].value
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, node, ast.Assign), ast.Assign)
    assert isinstance(get_closest_parent_of(tree, node, ast.Expr), ast.Expr)
    assert isinstance(get_closest_parent_of(tree, node, ast.Name), ast.Name)

# Generated at 2022-06-18 01:20:28.225963
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 1

# Generated at 2022-06-18 01:20:32.886845
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def foo():\n    pass')
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0].body[0]) == tree.body[0].body[0]



# Generated at 2022-06-18 01:20:34.514617
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert list(find(tree, ast.Name)) == [ast.Name(id='a', ctx=ast.Store())]

# Generated at 2022-06-18 01:20:37.713598
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree.body[0]
    assert index == 0
    assert isinstance(parent, ast.FunctionDef)
    assert isinstance(node, ast.Assign)

# Generated at 2022-06-18 01:20:43.797359
# Unit test for function find
def test_find():
    import astor
    from ..exceptions import NodeNotFound
    from ..utils import find, get_parent
    from ..utils import get_non_exp_parent_and_index
    from ..utils import insert_at, replace_at, get_closest_parent_of

    tree = ast.parse('''
    def foo():
        a = 1
        b = 2
        c = 3
    ''')

    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Assign))) == 3

    try:
        get_parent(tree, ast.parse('1'))
    except NodeNotFound:
        pass
    else:
        assert False


# Generated at 2022-06-18 01:20:49.438791
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test case 1
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    type_ = ast.FunctionDef
    assert get_closest_parent_of(tree, node, type_) == tree.body[0]

    # Test case 2
    tree = ast.parse("""
    def foo():
        pass
    """)
    node = tree.body[0].body[0]
    type_ = ast.Module
    assert get_closest_parent_of(tree, node, type_) == tree

# Generated at 2022-06-18 01:20:54.146621
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2')
    assert len(list(find(tree, ast.Assign))) == 2
    assert len(list(find(tree, ast.Name))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Load))) == 2
    assert len(list(find(tree, ast.Store))) == 2
    assert len(list(find(tree, ast.Str))) == 0


# Generated at 2022-06-18 01:21:00.515199
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo():
        if True:
            pass
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)