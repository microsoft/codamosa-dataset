

# Generated at 2022-06-23 23:42:59.982807
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from astmonkey import transformers
    text = """
    if True:
        if 3 == 3:
            print('foo')
    """
    tree = transformers.ParentInserter().visit(ast.parse(text))
    print(ast.dump(tree))
    print(get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0]))

# Generated at 2022-06-23 23:43:03.307223
# Unit test for function find
def test_find():
    tree = ast.parse("x = 1\ny = 2\nx += 2\ny -= 1")
    names = list(find(tree, ast.Name))
    assert len(names) == 3 and all(isinstance(name, ast.Name) for name in names)


# Generated at 2022-06-23 23:43:09.086663
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("x = 2 + 1")

    assert get_non_exp_parent_and_index(
        tree, tree.body[0].value ) == (tree, 0)
    assert get_non_exp_parent_and_index(
        tree, tree.body[0].value.right ) == (tree.body[0].value, 2)

# Generated at 2022-06-23 23:43:18.040418
# Unit test for function get_parent
def test_get_parent():
    from ..parser.parser import parse
    from ..utils.validation import validate
    from ..constants import Source, PLATFORM
    source = Source('/tmp/test', """
a = 1
b = 2
print(a, b)
""")
    tree = parse(source)
    validate(tree, PLATFORM)

    assert isinstance(get_parent(tree, tree.body[1]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[1].targets[0]), ast.Assign)


if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-23 23:43:29.138559
# Unit test for function get_parent
def test_get_parent():
    # 2 + 2
    simple_expr = ast.Expression(ast.BinOp(ast.Num(2), ast.Add(), ast.Num(2)))
    # x = 2 + 2
    simple_assign = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                               value=simple_expr)
    # x = 1 + 2
    # y = x + 2
    longer_assign = ast.Module(body=[
        simple_assign,
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.BinOp(ast.Name(id='x', ctx=ast.Load()),
                                   ast.Add(), ast.Num(2)))
    ])

    # For all ast nodes

# Generated at 2022-06-23 23:43:30.518974
# Unit test for function replace_at

# Generated at 2022-06-23 23:43:39.284356
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    code = """
    class Foo:
        def __init__(self, x: int) -> None:
            self.x = x

        def add(self, y: int) -> int:
            return self.x + y
    """
    tree = ast.parse(code)
    func = get_closest_parent_of(tree, tree.body[0].body[1].body[1].value.value,
                                 ast.FunctionDef)
    assert astor.to_source(func) == '    def add(self, y: int) -> int:\n'


# Generated at 2022-06-23 23:43:47.591730
# Unit test for function insert_at
def test_insert_at():
    outer = ast.Module([
        ast.FunctionDef(
            'test',
            ast.arguments([], [], [], [], None, []),
            [ast.Pass()],
            []
        )
    ])

    inner = ast.Module([
        ast.FunctionDef(
            'test2',
            ast.arguments([], [], [], [], None, []),
            [ast.Pass()],
            []
        )
    ])

    insert_at(0, outer.body[0].body, [inner])

    assert isinstance(outer.body[0].body[0], ast.Module)


# Generated at 2022-06-23 23:43:56.987266
# Unit test for function insert_at
def test_insert_at():
    # Create ast for try-except-finally
    parent = ast.Try(body=[ast.parse('x = 1').body[0]],
                     handlers=[ast.ExceptHandler(body=[ast.parse(
                         'print("This does not depend on how x is " + "initialized")').body[0]])],
                     finalbody=[ast.parse('print("Finally!")').body[0]])
    nodes = ast.parse('print("In the middle")').body[0]
    index = 1
    # Insert new node in the middle
    insert_at(index, parent, nodes)
    # Check if the code is correct

# Generated at 2022-06-23 23:44:01.363722
# Unit test for function find
def test_find():
    from astpretty import pprint
    from typed_ast import ast3 as ast
    class_ = ast.ClassDef(name='Test', body=[])

    pprint(class_)
    import pdb; pdb.set_trace()
    # find(class_, ast.Pass)

# Generated at 2022-06-23 23:44:02.712362
# Unit test for function insert_at

# Generated at 2022-06-23 23:44:09.933538
# Unit test for function replace_at
def test_replace_at():
    import sys
    import os
    import astunparse
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, os.path.join(cur_dir, '..'))
    from ..utils import get_source

    tree = get_source(os.path.join(cur_dir, '../examples/example1.py'))
    target_node = [
        n for n in ast.walk(tree) if isinstance(n, ast.BinOp) and
        isinstance(n.left, ast.Name) and n.left.id == 'i'
    ][0]
    target_node_index, target_node_parent = get_non_exp_parent_and_index(tree, target_node)

# Generated at 2022-06-23 23:44:16.935723
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.parse(
        """
        def foo():
            if True:
                return 1

        def bar():
            pass
        """, mode='exec')
    try:
        get_closest_parent_of(node, node.body[1].body[0], ast.FunctionDef)
    except NodeNotFound as e:
        assert str(e) == 'Parent for Return(value=Num(n=1)) not found'

# Generated at 2022-06-23 23:44:18.418948
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:44:23.714533
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .nodes import Name, NameConstant, Module
    x = Name('x')
    node = NameConstant(value=False)
    module = Module(body=[x, x, node])

    new_parent, index = get_non_exp_parent_and_index(module, node)
    assert isinstance(new_parent, Module)
    assert index == 2

# Generated at 2022-06-23 23:44:28.896257
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('[some for some in some if some if some]')
    assert get_non_exp_parent_and_index(tree, tree.body[0].value.comprehensions[0].ifs[0]) == (
               tree.body[0].value.comprehensions[0], 2)



# Generated at 2022-06-23 23:44:35.906623
# Unit test for function find
def test_find():
    module = ast.parse('asdf = 2\nfdsa = 3\nasdf = 2 if asdf == 2 else 3\n'
                       'assert asdf == 2 and fdsa == 3')

    for node in find(module, ast.Assign):
        node.targets[0].id = 'scream'
        node.value = ast.Name('hey', ast.Load())

    for node in find(module, ast.Assert):
        node.args[0].left.id = 'scream'


# Generated at 2022-06-23 23:44:43.019942
# Unit test for function get_parent

# Generated at 2022-06-23 23:44:50.106755
# Unit test for function insert_at
def test_insert_at():
    node_to_insert = ast.Pass()
    node_list = [ast.Assign(), ast.If(), ast.Assign()]
    expected_list = [ast.Assign(), node_to_insert, ast.If(), ast.Assign()]

    insert_at(1, ast.Module(), node_to_insert)
    insert_at(1, ast.Module(body=node_list), node_to_insert)

    assert ast.Module(body=expected_list).body == node_list



# Generated at 2022-06-23 23:44:57.718759
# Unit test for function find
def test_find():
    stmts = [ast.parse(s) for s in [
        'print(2 + 2)',
        'a = 2 + 2',
        'a = b = "2+2"',
        'def f(x: int): pass',
        'print(2)',
        'a = "2+2"',
        'def f(): pass',
        'print()',
    ]]
    for stmt in stmts:
        for expr in find(stmt, ast.arguments):
            assert expr
        if stmt.body[0].value.op.__class__ == ast.Add:
            for expr in find(stmt, ast.Add):
                assert expr

# Generated at 2022-06-23 23:45:01.015339
# Unit test for function find
def test_find():
    tree = ast.parse("a = 0")
    for node in find(tree, ast.Name):
        assert node.id == 'a'



# Generated at 2022-06-23 23:45:07.092314
# Unit test for function insert_at
def test_insert_at():
    def func(a: int, b: int) -> int:
        c = a + b
        return c

    tree = ast.parse(inspect.getsource(func))
    insert_at(1, tree.body[0], ast.Pass())

    assert ast.dump(tree) == textwrap.dedent("""\
    def func(a: int, b: int) -> int:
        pass
        c = a + b
        return c
    """)



# Generated at 2022-06-23 23:45:16.244585
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1 + 2')
    if isinstance(get_parent(tree, tree.body[0].value), ast.BinOp) is False:
        raise AssertionError
    if isinstance(get_parent(tree, tree.body[0].value.right), ast.BinOp) is False:
        raise AssertionError
    if isinstance(get_parent(tree, tree.body[0].value.left), ast.BinOp) is False:
        raise AssertionError
    if isinstance(get_parent(tree, tree.body[0]), ast.Module) is False:
        raise AssertionError

# Generated at 2022-06-23 23:45:20.573866
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def sum(n):\n    return n\n')
    sum_def = tree.body[0]
    sum_def.body = [
        ast.Return()
    ]
    node = sum_def.body[0]
    replace_at(0, sum_def, ast.Num(1))
    assert get_parent(tree, node) == sum_def
    assert sum_def.body[0].n == 1



# Generated at 2022-06-23 23:45:26.686645
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.parse("""def find_me():
    if True:
        print('print me')
    else:
        pass
""").body[0]

    assert isinstance(get_closest_parent_of(node, node.body[0], ast.If), ast.If)
    assert isinstance(get_closest_parent_of(node, node.body[0], ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-23 23:45:30.377791
# Unit test for function get_parent
def test_get_parent():
    # '3 + 4 + 5'
    node = ast.parse('3 + 4 + 5').body[0].value
    # (3 + 4)
    parent = get_parent(node, node.left)

    assert isinstance(parent, ast.BinOp)



# Generated at 2022-06-23 23:45:42.128890
# Unit test for function insert_at
def test_insert_at():
    """ Inserts three nodes in the ast at a specific position and
    checks whether the resulting ast is as expected.
    """
    from typed_ast import ast3 as ast
    from .tester import dumps
    import astor

    ast_ = ast.parse('''
        def test_func(a, b): 
            c = None
            return a + c 
    ''')

    parent, index = get_non_exp_parent_and_index(ast_,
                                                 ast_.body[0].body[1].value)
    insert_at(index + 1, parent, ast.parse('d = None\nprint(d)\n'))


# Generated at 2022-06-23 23:45:43.888387
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse('a = 1')
    assert get_parent(node, node.body[0].targets[0]) == node.body[0]



# Generated at 2022-06-23 23:45:48.269076
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nt = [1, 2]\nl = []', mode='exec')
    assert get_non_exp_parent_and_index(tree, tree) == (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[1].value.elts[0]) == (tree.body[1], 0)

# Generated at 2022-06-23 23:45:52.665362
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .nodes import FunctionDef

    tree = ast.parse('''
    def foo():
        pass
    ''')
    node = tree.body[0].body[0]

    assert isinstance(get_closest_parent_of(tree, node, FunctionDef), FunctionDef)

# Generated at 2022-06-23 23:45:57.435694
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("x = 1\nx + x")
    assign = tree.body[0]
    name = assign.targets[0]
    assert get_parent(tree, name) == assign
    try:
        get_parent(tree, ast.Module([]))
        raise AssertionError("NodeNotFound should be raised")
    except NodeNotFound as e:
        assert "not found" in str(e)


# Generated at 2022-06-23 23:46:01.261334
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('[1,2]')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].elts[1])
    assert parent is tree
    assert index == 0

# Generated at 2022-06-23 23:46:06.629091
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a = b + c')
    node = tree.body[0].value

    insert_at(1, node, ast.Num(42))
    assert str(node.elts[1]) == '42'

    insert_at(0, node, ast.Num(42))
    assert str(node.elts[0]) == '42'



# Generated at 2022-06-23 23:46:14.350720
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """
    Test that get_non_exp_parent_and_index works as expected.
    """
    import inspect
    import astor

    # Test case:
    #
    #   # Comment
    #   if cond:
    #       pass
    #   else:
    #       pass

    module = ast.parse(inspect.getsource(test_get_non_exp_parent_and_index))

    if_parent, _ = get_non_exp_parent_and_index(module, module.body[1])

    assert isinstance(if_parent, ast.Module)
    assert astor.to_source(if_parent) == inspect.getsource(
        test_get_non_exp_parent_and_index
    )

    # Test case:
    #
    #   # Comment
    #   if

# Generated at 2022-06-23 23:46:14.910123
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:46:25.141978
# Unit test for function replace_at

# Generated at 2022-06-23 23:46:31.050673
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    x = ast.Name(id='x', ctx=ast.Load())
    comp = ast.comprehension(target=x, iter=x, ifs=[])
    list_comp = ast.ListComp(elt=x, generators=[comp])
    parent = get_closest_parent_of(list_comp, x, type(comp))
    assert parent == comp

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(list_comp, x, type(x))

# Generated at 2022-06-23 23:46:37.772273
# Unit test for function find
def test_find():
    source = '''
    def foo():
        pass

    baz = None
    '''
    module = ast.parse(source)

    defs = list(find(module, ast.FunctionDef))
    assert len(defs) == 1

    baz = next(find(module, ast.Name), None)
    assert baz.id == "baz"

    try:
        next(find(module, ast.Call))
    except StopIteration:
        pass
    else:
        assert False

# Generated at 2022-06-23 23:46:41.366992
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('if True: print(2)')
    node = ast.Name(id='print', ctx=ast.Load())
    assert get_closest_parent_of(tree, node, ast.FunctionDef)

# Generated at 2022-06-23 23:46:47.723075
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def test_function():  # pylint: disable=missing-docstring
        def test_function_2():  # pylint: disable=missing-docstring
            pass

    test_tree = ast.parse(inspect.getsource(test_function))
    node = get_closest_parent_of(test_tree, test_tree.body[0].body[0],
                                 ast.FunctionDef)
    assert node.name == 'test_function'  # type: ignore

    node = get_closest_parent_of(test_tree, test_tree.body[0].body[0],
                                 ast.ClassDef)
    assert node is None

# Generated at 2022-06-23 23:46:51.847294
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert str(get_closest_parent_of(
        ast.parse('1 + 1'),
        find(ast.parse('1+1'), ast.Num).next(),
        ast.Num
    )) == '1'



# Generated at 2022-06-23 23:46:52.482223
# Unit test for function get_parent
def test_get_parent():
    assert False

# Generated at 2022-06-23 23:46:56.425577
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import numpy as np
    import astor
    from ..gen import create_module
    from ..testing import assert_same_ast
    module = create_module(['test'])
    body = set(find(module, ast.Assign))
    src = astor.to_source(module)
    # print('\n', src)
    module2 = ast.parse(src)
    body2 = set(find(module2, ast.Assign))
    body_diff = (body2 - body).pop()
    parent = get_closest_parent_of(module2, body_diff, ast.FunctionDef)
    assert parent.name == 'test'


# Generated at 2022-06-23 23:47:02.496332
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('''
    def fn():
        pass

    def fn1():
        pass
    ''')

    expected = ast.parse('''
    def fn():
        pass

    def fn2():
        pass

    def fn1():
        pass
    ''')

    new_function = ast.FunctionDef(
        name='fn2',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ),
        body=[],
        decorator_list=[],
        returns=None,
    )

    insert_at(1, tree, new_function)

    assert ast.dump(tree) == ast.dump(expected)


#

# Generated at 2022-06-23 23:47:08.558716
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def function():  # noqa: F811
        with open("file") as f:  # noqa: F841
            f.seek(10)

    result = get_closest_parent_of(function, function.body[0].body[0].body[0],
                                   ast.FunctionDef)

    assert(result == function)



# Generated at 2022-06-23 23:47:16.370127
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .ast_utils import p
    from .ast_utils import parse


# Generated at 2022-06-23 23:47:23.831033
# Unit test for function replace_at
def test_replace_at():
    a = ast.parse("""def func():
        if True:
            a = 1
        else:
            a = 2
        """)
    _build_parents(a)

    if_ = get_closest_parent_of(a, a.body[0].body[0].body[0], ast.If)
    replace_at(1, if_,
               ast.parse("""def func2():
    if True:
        a = 1
    else:
        b = 2
""").body[0].body[0])



# Generated at 2022-06-23 23:47:30.447096
# Unit test for function replace_at
def test_replace_at():
    test_tree = ast.parse('for i in range(0):\n    pass')
    parent = test_tree.body[0]
    assert len(parent.body) == 1
    replace_at(0, parent, ast.Expr(ast.Num(1)))
    assert len(parent.body) == 1
    replace_at(0, parent, [ast.Expr(ast.Num(1)), ast.Expr(ast.Num(2))])
    assert len(parent.body) == 2

# Generated at 2022-06-23 23:47:40.092448
# Unit test for function replace_at
def test_replace_at():
    import unittest
    from ..transformer import Transformer
    from .test_utils import ast_eq
    from typed_ast.ast3 import Module, Assign

    # Function for preparing ast for testing
    def prepare(code):
        return ast.parse(code)

    # Private method used in unit test
    def _replace_at(code: str, index: int, nodes: Union[ast.AST, List[ast.AST]]):
        tree = prepare(code)
        parent, index = get_non_exp_parent_and_index(tree, nodes)
        replace_at(index, parent, nodes)
        return tree

    class Tester(unittest.TestCase):

        def test_001(self):
            code = 'a = 1\nb = 2'

# Generated at 2022-06-23 23:47:45.738042
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = f(x=1)')
    node = tree.body[0].value.keywords[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Assign)
    assert isinstance(node, ast.Num)
    assert index == 0


# Generated at 2022-06-23 23:47:50.761961
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("def f(x): return x + (1, 2, 3)")
    function = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    replace_at(0, function, ast.parse("x + (1, 2, 3)").body[0])
    print(ast.dump(tree))

# Generated at 2022-06-23 23:47:57.539761
# Unit test for function insert_at
def test_insert_at():
    parent = ast.Module(body=[
        ast.Expr(value=ast.Name(id='x', ctx=ast.Load())),
        ast.Expr(value=ast.Name(id='y', ctx=ast.Load())),
        ast.Expr(value=ast.Name(id='z', ctx=ast.Load())),
    ])

    insert_at(1, parent, ast.Expr(value=ast.Name(id='a', ctx=ast.Load())))


# Generated at 2022-06-23 23:48:02.243409
# Unit test for function find
def test_find():
    import astunparse

    code = astunparse.unparse(ast.parse('1 + 1'))
    tree = ast.parse(code)
    for node in find(tree, ast.Expr):
        print(astunparse.unparse(node))



# Generated at 2022-06-23 23:48:06.136706
# Unit test for function find
def test_find():
    tree = ast.parse('x = 1')
    result = find(tree, ast.Name)
    assert list(repr(i) for i in result) == ["Name(id='x', ctx=Store())"]


# Generated at 2022-06-23 23:48:11.122204
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import typed_ast.ast3 as ast

    root = ast.parse(
        '''
        def foo():
            if a > 1:
                return "a"
        ''')
    parent = get_closest_parent_of(root, root.body[0].body[0], ast.FunctionDef)
    assert astor.to_source(parent).strip() == 'def foo():'



# Generated at 2022-06-23 23:48:19.292635
# Unit test for function replace_at
def test_replace_at():
    import textwrap
    import astunparse
    src = textwrap.dedent("""
        def foo():
            print('')
            print('')
            return 'c'
    """)

    tree = ast.parse(src)
    print(astunparse.unparse(tree))
    return_ = find(tree, ast.Return).next()
    parent, _ = get_non_exp_parent_and_index(tree, return_)
    replace_at(1, parent, return_)
    print(astunparse.unparse(tree))



# Generated at 2022-06-23 23:48:27.000604
# Unit test for function insert_at
def test_insert_at():
    code = '''
    def fun():
        a = 1
        b = 2

        return a + b
    '''
    tree = ast.parse(code)
    function = tree.body[0]
    return_node = function.body[-1]
    parent, index = get_non_exp_parent_and_index(tree, return_node)
    insert_at(index, parent, ast.Expr(ast.Subscript(value=ast.Name(id='a', ctx=ast.Load()), slice=ast.Index(ast.Num(n=0)), ctx=ast.Load())))
    print(ast.dump(tree))



# Generated at 2022-06-23 23:48:36.496403
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('x = 1; x = 2;')
    exp = ast.Expression(ast.Name(id='x'))
    insert_at(2, tree, exp)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2)), Expression(body=Name(id=\'x\', ctx=Load()))])'



# Generated at 2022-06-23 23:48:39.877817
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse("""
    a = 1
    b = a
    c = b
    d = c
    e = d
    """).body[-1]
    parent, index = get_non_exp_parent_and_index(node.root, node)
    assert node in parent.body
    assert index == len(parent.body) - 1
    assert parent is node.root


if __name__ == "__main__":
    test_get_non_exp_parent_and_index()

# Generated at 2022-06-23 23:48:47.635485
# Unit test for function insert_at
def test_insert_at():
    print("Testing insert_at function...")

    tree = ast.parse('a=1\nb=2\nc=3')
    parent = tree.body[1]
    new_nodes = ast.parse('d=4\ne=5')

    insert_at(1, parent, new_nodes)

    assert ast.dump(tree) == '<_ast.Module object at 0x7f1e278e0be0>'

    print("OK")

# Generated at 2022-06-23 23:48:57.246657
# Unit test for function replace_at
def test_replace_at():
    from typed_ast.ast3 import Module, Name, Load, Store, FunctionDef, Str, \
        NameConstant, Expr, NumericConstant, Num, Print, Assign, \
        Call, Tuple as Tuple_, List as List_, Assign


# Generated at 2022-06-23 23:49:02.471487
# Unit test for function replace_at
def test_replace_at():
    test_ast = ast.parse('def f():\n    a = 5')
    define = test_ast.body[0]
    node = define.body[0].value
    replace_at(0, define, ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Load())],
        value=ast.Num(n=2)
    ))
    assert node != define.body[0].value
    assert ast.dump(node) == ast.dump(define.body[0].value)

# Generated at 2022-06-23 23:49:10.544860
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('a=1;b=2;c=3')
    expr = tree.body[1].value
    assert isinstance(get_closest_parent_of(tree, expr, ast.Assign), ast.Assign)
    assert isinstance(get_closest_parent_of(tree, expr, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, expr, ast.FunctionDef), ast.Module)


# Generated at 2022-06-23 23:49:19.450449
# Unit test for function insert_at
def test_insert_at():
    """Test insert_at function."""
    mod = ast.parse("def func1(a):\n"
                    "    print('Hello')")
    func1 = mod.body[0]
    insert_at(1, func1, ast.Expr(ast.Str("Hi!")))
    assert len(func1.body) == 2
    assert isinstance(func1.body[1], ast.Expr)
    assert isinstance(func1.body[1].value, ast.Str)
    assert func1.body[1].value.s == "Hi!"


# Generated at 2022-06-23 23:49:25.852598
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_code_1 = '''
    def f(x):
        if x > 10:
            return 0
        elif x < 10:
            return 1
        else:
            return 2
    '''
    tree_1 = ast.parse(test_code_1)
    test_node_1 = get_closest_parent_of(tree_1, tree_1.body[0].body[1], ast.AST)
    assert get_non_exp_parent_and_index(tree_1, test_node_1) == (
            tree_1.body[0].body[1], 0)
    assert get_non_exp_parent_and_index(tree_1, tree_1.body[0].body[3]) == (
            tree_1.body[0].body[1], 1)

   

# Generated at 2022-06-23 23:49:27.703418
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

# Generated at 2022-06-23 23:49:32.198832
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('x = 1')
    inserted_node = ast.parse('y = 2')
    insert_at(0, tree.body[0], inserted_node)

    assert ast.dump(tree) == ast.dump(
        ast.parse('y = 2\nx = 1'))  # type: ignore

# Generated at 2022-06-23 23:49:37.106400
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = b.c + 1')

    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].value.left) == tree.body[0].value


if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-23 23:49:43.059904
# Unit test for function find
def test_find():
    node = ast.parse('sum([1,2,3])').body[0].value
    assert len(list(find(node, ast.Call))) == 1
    assert len(list(find(node, ast.List))) == 1



# Generated at 2022-06-23 23:49:53.814214
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import_node = ast.Import(names=[ast.alias(name='datetime', asname='d')])
    assign1_node = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                              value=ast.Num(n=1))
    assign2_node = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                              value=ast.Num(n=2))
    funcdef_node = ast.FunctionDef(name='foo', args=ast.arguments(
        args=[], vararg=None, kwonlyargs=[], kw_defaults=[],
        kwarg=None, defaults=[]), body=[assign1_node, assign2_node],
        decorator_list=[], returns=None)

# Generated at 2022-06-23 23:49:59.292776
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse("a = 1\nb = 2\ndef f(x):\n    return x + 1",
                     mode='func')

# Generated at 2022-06-23 23:50:05.786450
# Unit test for function get_parent
def test_get_parent():
    test_code3 = '''def test():
        def test2():
            pass
        '''

    parsed = ast.parse(test_code3)
    parent = get_parent(parsed, parsed.body[0].body[0])
    assert parent == parsed.body[0]



# Generated at 2022-06-23 23:50:14.695796
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def helper(body: List[ast.AST], node: ast.AST,
               type_: Type[T]) -> ast.AST:
        mod = ast.Module([ast.FunctionDef('', ast.arguments([]), body, [], None)])
        return get_closest_parent_of(mod, node, type_)

    assert isinstance(helper([ast.Expr(ast.Name('foo', ast.Load()))],
                             ast.Name('foo', ast.Load()),
                             ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-23 23:50:20.978500
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_str = "def foo():\n    a=0\n    b=0"
    tree = ast.parse(test_str)
    node = find(tree, type(tree.body[0])).__next__()
    node = node.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == node.parent
    assert index == 0


# Generated at 2022-06-23 23:50:25.440729
# Unit test for function replace_at
def test_replace_at():
    class Child(ast.AST):
        _fields = ('value',)
    class Parent(ast.AST):
        _fields = ('body',)

    parent = Parent()
    parent.body = [Child()]

    node = Child()

    replace_at(0, parent, node)

    assert parent.body[0] == node

# Generated at 2022-06-23 23:50:31.264489
# Unit test for function find
def test_find():
    # Given
    f = ast.FunctionDef(name='f', args=ast.arguments(), body=[],
                        decorator_list=[], returns=None)
    g = ast.FunctionDef(name='g', args=ast.arguments(), body=[f],
                        decorator_list=[], returns=None)

    # When
    funcs = list(find(g, ast.FunctionDef))

    # Then
    assert len(funcs) == 2



# Generated at 2022-06-23 23:50:38.518530
# Unit test for function find
def test_find():
    from .ast_builder import build_ast

    code = '''
    import sys

    if isinstance(sys, list):
        pass
    '''
    tree = build_ast(code)
    import_node = find(tree, ast.Import).__next__()
    assert isinstance(import_node, ast.Import)

    if_node = find(tree, ast.If).__next__()
    assert isinstance(if_node, ast.If)



# Generated at 2022-06-23 23:50:39.310985
# Unit test for function replace_at
def test_replace_at():
    """Unit test for function replace_at."""
    pass

# Generated at 2022-06-23 23:50:47.471074
# Unit test for function find
def test_find():
    from ..parser import parse
    from ..parser.nodes import Call, Name, Load
    tree = parse('''
    a = []
    a.append(1)
    a.append(2)
    a.append(3)
    ''')

    for i, node in enumerate(find(tree, Call)):
        assert node.func.id == 'append'
        assert node.func.ctx == Load
        assert node.args[0].n == i + 1



# Generated at 2022-06-23 23:50:50.074981
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-23 23:50:53.888640
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
        def function():
            if True:
                if True:
                    statement1
                    statement2
    ''')

    result = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])

    assert ast.dump(result[0]) == ast.dump(tree.body[0].body[0].body)
    assert result[1] == 0



# Generated at 2022-06-23 23:51:02.987708
# Unit test for function find
def test_find():
    import astor

    test_node = ast.parse('print(1)')
    assert len(list(find(test_node, ast.Print))) == 1
    assert len(list(find(test_node, ast.Call))) == 1
    assert len(list(find(test_node, ast.Name))) == 1
    assert len(list(find(test_node, ast.Module))) == 1
    assert len(list(find(test_node, ast.Statement))) == 1
    assert astor.dump_tree(test_node) == '''Module(body=[Print(dest=None, values=[Num(n=1)], nl=True)])\n'''



# Generated at 2022-06-23 23:51:07.916064
# Unit test for function insert_at
def test_insert_at():
    import astor
    src = """if True:
        if True:
            pass"""
    assert astor.to_source(insert_at(1, ast.parse(src), ast.parse("10").body[0])).strip() == """if True:
        10
        if True:
            pass"""


# Generated at 2022-06-23 23:51:08.814115
# Unit test for function find

# Generated at 2022-06-23 23:51:17.916544
# Unit test for function find
def test_find():  # pylint: disable=too-many-locals
    """
    'for i in list1:\n'
    '    print(i)\n'
    '    if i > 6:\n'
    '        print(\'OK\')\n'
    """
    # pylint: disable=too-many-locals
    list_for = ast.For(  # pylint: disable=invalid-name
        target=ast.Name('i', ast.Store()),
        iter=ast.Name('list1', ast.Load()),
        body=[ast.Print(values=[ast.Name('i', ast.Load())],
                         nl=False, dest=None, lineno=0, col_offset=0)],
        orelse=[], lineno=0, col_offset=0)

    print_i

# Generated at 2022-06-23 23:51:21.965231
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('True')
    replace_at(0, tree, ast.Expr(value=ast.Name(id='True', ctx=ast.Load())))
    assert ast.dump(tree) == 'Module(body=[Expr(value=Name(id=\'True\', ctx=Load()))])'

# Generated at 2022-06-23 23:51:27.389024
# Unit test for function replace_at
def test_replace_at():
    node = ast.Num(n=1)
    parent = ast.Expression(body=ast.Name(id='name'))
    replace_at(0, parent, node)
    assert parent.body[0] == node

# Generated at 2022-06-23 23:51:31.699020
# Unit test for function find
def test_find():
    c = ast.parse('a=0; if a: a=1')
    assert len(list(find(c, ast.Assign))) == 2
    assert len(list(find(c, ast.If))) == 1
    assert len(list(find(c, ast.Module))) == 1
    assert len(list(find(c, ast.Name))) == 3



# Generated at 2022-06-23 23:51:34.688859
# Unit test for function replace_at
def test_replace_at():
    """Dummy function to inject new_node."""
    pass


# Generated at 2022-06-23 23:51:38.940742
# Unit test for function get_parent
def test_get_parent():
    """Get the parent of a node in a tree."""
    code = """
    def add(a, b):
        return a + b
    """
    tree = ast.parse(code)
    node = tree.body[0].body[0]
    assert get_parent(tree, node) == tree.body[0]



# Generated at 2022-06-23 23:51:40.018611
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:51:48.319199
# Unit test for function replace_at
def test_replace_at():
    import unittest

    class TestReplaceAt(unittest.TestCase):
        def test_replace_node(self):
            tree = ast.parse('1 + 1')
            parent = tree.body[0]
            assert hasattr(parent, 'body')
            assert find_node(tree.body[0], ast.Add) is not None
            assert find_node(tree.body[0], ast.Mult) is None

            replace_at(1, parent, make_node(ast.Mult))

            assert find_node(tree.body[0], ast.Add) is None
            assert find_node(tree.body[0], ast.Mult) is not None

        def test_replace_node_with_two_nodes(self):
            tree = ast.parse('1 + 1')

# Generated at 2022-06-23 23:51:52.468262
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():    
    code = """
            if True:
                n = 1
            elif True:
                n = 2
            else:
                n = 3
        """
    tree = ast.parse(code)
    node = find(tree, ast.Name).__next__()
    non_exp_parent, index = get_non_exp_parent_and_index(tree, node)
    (expected_non_exp_parent, expected_index) = (tree.body[0].body[0], 0)
    assert non_exp_parent == expected_non_exp_parent, "Wrong non-Exp parent!"
    assert index == expected_index, "Wrong index!"


# Generated at 2022-06-23 23:51:55.172605
# Unit test for function get_parent

# Generated at 2022-06-23 23:51:57.002822
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index."""

# Generated at 2022-06-23 23:52:02.367291
# Unit test for function insert_at
def test_insert_at():
    def test():
        a = 1
        b = 2

    test_node = ast.parse(inspect.getsource(test)).body[0]
    insert_at(0, test_node.body, ast.Expr(value=ast.Constant(value=3)))

    assert ast.dump(test_node) == "def test():\n    3\n    a = 1\n    b = 2\n"



# Generated at 2022-06-23 23:52:05.453578
# Unit test for function get_parent
def test_get_parent():
    source = 'a = b + 1\n'
    tree = ast.parse(source)
    assigment = tree.body[0]
    a = assigment.targets[0]

    assert(get_parent(tree, a) == assigment)

# Generated at 2022-06-23 23:52:06.243565
# Unit test for function get_parent

# Generated at 2022-06-23 23:52:12.602071
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class A:
        pass

    class B:
        pass

    class C:
        pass

    class D:
        pass

    A.__bases__ = (B,)
    C.__bases__ = (D,)
    B.__bases__ = (C,)

    assert get_closest_parent_of(None, A, D) == C

# Generated at 2022-06-23 23:52:14.232700
# Unit test for function get_parent
def test_get_parent():
    """Test function get_parent"""

# Generated at 2022-06-23 23:52:26.083123
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # example:
    #   from module1 import *
    #   from module2 import *
    #
    #   def bard(a):
    #     print(a)

    tree = ast.parse('from module1 import *; from module2 import *\ndef bard(a):\n  print(a)')
    node = get_closest_parent_of(tree, tree.body[2].body[0], ast.FunctionDef)
    assert node == tree.body[2]

    # example:
    #   if foo:
    #     value = 1
    #   elif foo2:
    #     value = 2
    #   else:
    #     value = 3


# Generated at 2022-06-23 23:52:29.687500
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    expr = ast.parse('a = 1')
    node = expr.body[0]
    parent = get_non_exp_parent_and_index(expr, node)[0]
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-23 23:52:39.769133
# Unit test for function find
def test_find():
    import ast as _ast
    from typed_ast import ast3 as _ast3
    from . import alias

    tree = _ast.parse('a = 1')
    assert len(list(find(tree, _ast.Assign))) == 1
    assert len(list(find(tree, _ast3.Assign))) == 1
    assert len(list(find(tree, alias.Assign))) == 1
    assert len(list(find(tree, _ast.Name))) == 1
    assert len(list(find(tree, _ast3.Name))) == 1
    assert len(list(find(tree, alias.Name))) == 1
    assert len(list(find(tree, _ast.Constant))) == 1
    assert len(list(find(tree, _ast3.Constant))) == 1

# Generated at 2022-06-23 23:52:43.623236
# Unit test for function replace_at
def test_replace_at():
    i = ast.Import([ast.alias('a', None)])
    m = ast.Module(body=[i])
    replace_at(0, m, ast.Import([ast.alias('b', None)]))
    print(ast.dump(m))

# Generated at 2022-06-23 23:52:48.134741
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_node = ast.parse('import ast; a = 5')
    node = ast_node.body[0].body[0].value
    parent = get_parent(ast_node, node)
    parent, index = get_non_exp_parent_and_index(ast_node, node)
    assert parent == ast_node.body[0].body
    assert index == 0

# Generated at 2022-06-23 23:52:53.855014
# Unit test for function replace_at
def test_replace_at():
    """Unit test for function replace_at."""
    import unittest
    module = ast.parse('for x in range(100):\n    pass')
    replace_at(0, module,
               ast.parse('for x in range(100):\n    print("hello")'))

    class Test(unittest.TestCase):
        """Test Case class for testing replace_at()."""

        def test_replace_at(self):
            """Unit test for function replace_at."""

# Generated at 2022-06-23 23:52:56.762693
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass
