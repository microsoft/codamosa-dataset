

# Generated at 2022-06-23 23:42:58.222083
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a = 1 + 2')
    parent = get_parent(tree, tree.body[0])
    insert_at(0, parent, ast.parse('print(1)'))
    assert "print(1)" in get_parent(tree, parent).body
    assert "a = 1 + 2" in get_parent(tree, parent).body
    assert "a = 1 + 2" in get_parent(tree, tree.body[0]).body

# function insert_at

# Generated at 2022-06-23 23:43:03.423793
# Unit test for function insert_at
def test_insert_at():
    program = ast.parse('a = 1\nd = 2')
    insert_at(1, program.body[0], ast.parse('b = 3').body[0])
    insert_at(1, program.body[1], ast.parse('c = 4').body[0])
    inserted_program = ast.parse('a = 1\nb = 3\nd = 2\nc = 4')

    assert program == inserted_program



# Generated at 2022-06-23 23:43:07.254367
# Unit test for function replace_at
def test_replace_at():
    stmt = ast.parse('i = 1; print(2)')
    parent = get_non_exp_parent_and_index(stmt, stmt.body[0])[0]
    replace_at(0, parent, ast.parse('i = 2'))



# Generated at 2022-06-23 23:43:13.390965
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
    def f():
        if True:
            return 1
    ''')

    parent, index = get_non_exp_parent_and_index(
        tree, tree.body[0].body[0].body[0]
    )

    assert index == 0
    assert isinstance(parent, ast.FunctionDef)
    assert parent == tree.body[0]

# Generated at 2022-06-23 23:43:18.040587
# Unit test for function get_parent
def test_get_parent():
    simple_tree = ast.parse("def foo():\n    bar = 'lol'\n    return bar")
    node = simple_tree.body[0].body[1].value
    assert node == ast.Str('lol')
    assert get_parent(simple_tree, node) == simple_tree.body[0]


# Generated at 2022-06-23 23:43:28.723099
# Unit test for function insert_at
def test_insert_at():
    import typed_ast.ast3 as ast
    parent = ast.Module(body=[ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                         value=ast.Num(n=1))])
    insert_at(0, parent, ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                    value=ast.Num(n=0)))
    assert ast.dump(parent) == """\
Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=0)), Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1))])\
"""



# Generated at 2022-06-23 23:43:35.058239
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class TreeImpl:
        def __init__(self, other, children = []):
            #self.other = other
            self.children = children

    class OtherModifierImpl:
        def __init__(self, tree):
            self.tree = tree

    class ReturnImpl:
        def __init__(self, other):
            self.other = other

    def func():
        return 0
    #TreeImpl -> OtherModifierImple -> ReturnImpl
    tree = TreeImpl(OtherModifierImpl(ReturnImpl(func)))
    x, y = get_non_exp_parent_and_index(tree, ReturnImpl)
    assert (x == OtherModifierImpl) and (y == 0)

# Generated at 2022-06-23 23:43:46.041457
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def func(arg):
        if arg:
            def a():
                pass
            class b():
                pass
                def c():
                    pass
            def d():
                pass
        else:
            pass
    """)

    assert get_non_exp_parent_and_index(tree, tree.body[0]) == \
        (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == \
        (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1].body[0]) == \
        (tree.body[0].body[1], 0)

# Generated at 2022-06-23 23:43:53.065886
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""x = 1\nx = 2\ny = 1\ny = 2""")
    node = tree.body[2]
    assert isinstance(node, ast.Assign)

    parent, index = get_non_exp_parent_and_index(tree, node)
    insert_at(index, parent, ast.parse("""x = 3\nx = 4\ny = 3\ny = 4"""))

    assert ast.dump(tree) == ast.dump(ast.parse("""x = 1\nx = 2\nx = 3\n"
        "x = 4\ny = 1\ny = 2\ny = 3\ny = 4"""))  # noqa



# Generated at 2022-06-23 23:44:02.112217
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_tree = ast.parse("""\
    for i in range(1):
        print(i)
    """)

    # Test 1
    node = find(ast_tree, ast.Print).__next__()
    parent, index = get_non_exp_parent_and_index(ast_tree, node)

    assert isinstance(parent, ast.For)
    assert index == 0

    # Test 2
    node = find(ast_tree, ast.Name).__next__()
    parent, index = get_non_exp_parent_and_index(ast_tree, node)

    assert isinstance(parent, ast.Call)
    assert index == 0

# Generated at 2022-06-23 23:44:04.022083
# Unit test for function replace_at
def test_replace_at():  # pylint: disable=R0914
    # pylint: disable=C0123, W0201
    from ..transform import tree_to_code
    from ..nodes import PythonConstant


# Generated at 2022-06-23 23:44:09.450690
# Unit test for function insert_at
def test_insert_at():
    _tree = ast.parse('a = 1')
    _parent = _tree.body[0]

    insert_at(0, _parent, ast.parse('b = 2'))

    assert ast.dump(_tree) == '''
Module(body=[
   Assign(targets=[Name(id='b', ctx=Store())], value=Num(n=2)),
   Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1))
])
'''



# Generated at 2022-06-23 23:44:10.904555
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    print(ast.parse("def foo(x): return x + 42").body[0].body[0].value.func)

# Generated at 2022-06-23 23:44:12.991145
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:44:23.969259
# Unit test for function find
def test_find():
    test = ast.parse('''if True:
    x = 100
    if False:
        y = 'y'
    else:
        try:
            y = 'try'
        except:
            raise
    while True:
        z = 'z'
    pass''')
    ifs = find(test, ast.If)
    for if_ in ifs:
        assert isinstance(if_, ast.If)
        print(if_)
        assert if_.test.value or isinstance(if_.test, ast.Attribute)
    whiles = find(test, ast.While)
    assert len(whiles) == 1
    wh = whiles.__next__()
    assert isinstance(wh, ast.While)
    assert wh.test.value
    excepts = find(test, ast.ExceptHandler)


# Generated at 2022-06-23 23:44:31.568164
# Unit test for function insert_at
def test_insert_at():
    class Test:
        def test():
            print(1)

    ast_tree = ast.parse(Test.test.__doc__)
    ast_tree.body[0] = ast.Suite()

    parent = get_closest_parent_of(ast_tree, ast_tree, ast.Suite)
    insert_at(0, parent, ast.Expr(ast.Num(1)))

    assert ast.dump(ast_tree) == "Suite([Expr(value=Num(n=1)), Expr(value=Num(n=1))])"

# Generated at 2022-06-23 23:44:32.158174
# Unit test for function find

# Generated at 2022-06-23 23:44:41.988148
# Unit test for function get_parent
def test_get_parent():
    print("Testing get_parent")
    assert get_parent(ast.parse("x[1]"), ast.parse("x[1]").body[0].value.value) == ast.parse("x[1]").body[0]
    assert get_parent(ast.parse("x[1]"), ast.parse("x[1]").body[0]) == ast.parse("x[1]")

    assert get_parent(ast.parse("x[1]"), ast.parse("x[1]").body[0].value.value, True) == ast.parse("x[1]").body[0]
    assert get_parent(ast.parse("x[1]"), ast.parse("x[1]").body[0], True) == ast.parse("x[1]")


# Generated at 2022-06-23 23:44:43.019030
# Unit test for function get_parent

# Generated at 2022-06-23 23:44:44.652416
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:44:54.059550
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a*a+a')
    tree.body[0].value.left.n = 3

    try:
        lambda_node = ast.parse('lambda a: a').body[0]
    except AttributeError:
        lambda_node = ast.Lambda(args=ast.arguments(args=[ast.arg(arg='a')]),
                                 body=ast.Name(id='a', ctx=ast.Load()))

    insert_at(0, tree.body[0].value.left, lambda_node)

    expected_tree = ast.parse('lambda a: a*a+a')
    expected_tree.body[0].value.left.args.args[0].n = 3

    assert ast.dump(tree) == ast.dump(expected_tree)



# Generated at 2022-06-23 23:44:58.770072
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_str = '''
    def f():
      x += 1
    '''
    tree = ast.parse(ast_str)
    for_node = tree.body[0].body[0]
    assert(isinstance(get_closest_parent_of(tree, for_node, ast.FunctionDef),
                      ast.FunctionDef))



# Generated at 2022-06-23 23:44:59.835324
# Unit test for function find

# Generated at 2022-06-23 23:45:07.983123
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_data = ast.parse("""\
        def func(a, b, c=None):
            var = 1
            if var > 0:
                var = 1
                var2 = 2
            else:
                var2 = 3
                var3 = 4
            var4 = a
            var5 = [1, 2, 3, 4]""")
    parent, index = get_non_exp_parent_and_index(ast_data, ast_data.body[0].body[1])
    assert isinstance(parent, ast.FunctionDef), "Parent should be a FunctionDef"
    assert index == 1, "index should be 1"

# Generated at 2022-06-23 23:45:16.243893
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.Try()
    tree = ast.Module([ast.ExceptHandler(None, None, [node])])
    assert isinstance(get_closest_parent_of(tree, node, ast.Try), ast.Try)

    node = ast.If()
    tree = ast.Module([
        ast.ExceptHandler(None, None, [
            ast.Try(body=[node], handlers=[], orelse=[], finalbody=[])
        ])
    ])
    assert isinstance(get_closest_parent_of(tree, node, ast.Try), ast.Try)

# Generated at 2022-06-23 23:45:22.730603
# Unit test for function insert_at
def test_insert_at():
    class TestAstNode(ast.AST):
        pass

    n1 = TestAstNode()
    n2 = TestAstNode()
    n3 = TestAstNode()
    n4 = TestAstNode()
    tree = ast.Module(body=[n1, n2, n3, n4])

    _build_parents(tree)

    new_nodes = [TestAstNode(), TestAstNode()]
    insert_at(2, tree, new_nodes)
    assert tree.body == [n1, n2, new_nodes[0], new_nodes[1], n3, n4]

    insert_at(0, tree, TestAstNode())

# Generated at 2022-06-23 23:45:25.579076
# Unit test for function get_parent
def test_get_parent():
    """
    Get parent node test.
    """
    tree = ast.parse('import ast\nx = 1\n')
    parent_node = get_parent(tree, tree.body[1].value)
    assert isinstance(parent_node, ast.Assign)
    assert parent_node.value.n == 1
    assert parent_node.targets[0].id == 'x'

# Generated at 2022-06-23 23:45:32.932020
# Unit test for function replace_at

# Generated at 2022-06-23 23:45:40.706033
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    node = astor.parse_file('example/fibonacci.py')
    node = node.body[0]
    node = node.body[0]  # if
    node = node.body[1]  # elif
    node = node.body[0]
    node = node.body[0]  # return
    parent, index = get_non_exp_parent_and_index(node, node)
    assert index == 9
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-23 23:45:47.538379
# Unit test for function insert_at
def test_insert_at():
    import astor
    module = ast.parse('''\
        def test():
            return True
        ''')

    def_node = module.body[0]
    ret_node = def_node.body[0].value
    new_stmt = ast.Assign(targets=[ast.Name(id='x')], value=ret_node)
    insert_at(0, def_node.body, new_stmt)

    expected = '''\
        def test():
            x = True
            return True
        '''
    assert astor.to_source(module) == expected



# Generated at 2022-06-23 23:45:53.768191
# Unit test for function replace_at
def test_replace_at():
    root = ast.parse('for x in range(5):\n    pass\ndef dummy():\n    pass')
    ast.fix_missing_locations(root)
    parent, index = get_non_exp_parent_and_index(root, root.body[0].body[0])
    assert type(parent) == ast.For
    replace_at(index, parent, ast.Pass())
    assert type(parent.body[0]) == ast.Pass

# Generated at 2022-06-23 23:46:04.908765
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
        if condition:
            if condition_2:
                def func():
                    pass
                func()
            else:
                def func_2():
                    pass
                func_2()
        
        @decorator
        def func_3():
            pass
        """)
    target = tree.body[1].body[0].body[2].value
    closest_if = get_closest_parent_of(tree, target, ast.If)
    assert isinstance(closest_if, ast.If)
    closest_call = get_closest_parent_of(tree, target, ast.Call)
    assert isinstance(closest_call, ast.Call)
    closest_func = get_closest_parent_of(tree, target, ast.FunctionDef)


# Generated at 2022-06-23 23:46:13.476504
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # test setup

    def myfunction(param1):
        if param1:
            return param1
        else:
            return param1
    tree = ast.parse(myfunction.__code__.co_code,
                     'myfunction.py', 'exec')
    # finding correct parent
    found_parent = get_closest_parent_of(tree, tree.body[0].body[0].targets[0],
                                         ast.FunctionDef)
    assert found_parent == tree.body[0]
    # finding parent of wrong type and raising exception
    with pytest.raises(NodeNotFound):
        found_parent = get_closest_parent_of(tree,
                                             tree.body[0].body[0].targets[0],
                                             ast.FunctionDef)

# Generated at 2022-06-23 23:46:23.684667
# Unit test for function get_parent
def test_get_parent():
    import itertools as it
    import astor

    left = ast.Name(id='left')
    right = ast.Name(id='right')
    tree = ast.BinOp(left, ast.Add(), right)

    parent_list = [get_parent(tree, node) for node in ast.walk(tree)]

    for left_node, right_node in it.combinations_with_replacement(
        parent_list, 2
    ):
        assert left_node not in parent_list
        assert left_node.__repr__() == right_node.__repr__()

    parent_list.append(tree)

    for node in ast.walk(tree):
        assert node in parent_list


if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-23 23:46:26.641006
# Unit test for function find
def test_find():
    src = """def test():
            x = 4
            y = 6
            """
    tree = ast.parse(src)
    assert set(find(tree, ast.FunctionDef)) == set(tree.body)
    assert set(find(tree, ast.Assign)) == set(tree.body[0].body)
    assert set(
        find(tree.body[0].body[0] + tree.body[0].body[1], ast.Name)) == set(
        find(tree, ast.Name))


# Generated at 2022-06-23 23:46:32.637173
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # TODO: can't create new tree, so use fake one
    def f():  # pylint: disable=unused-variable
        a = b = c = 1

    tree = f.__code__.co_consts[0]  # type: ast.Module

    assert get_non_exp_parent_and_index(tree,
                                        tree.body[0].body[0].value.left) == \
        (tree, 0)



# Generated at 2022-06-23 23:46:42.977538
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test get_non_exp_parent_and_index function."""
    tree = ast.parse("""
        a = 3
        if a > 3:
            b = 0
            while a > 5:
                b += 1
                if b < 10:
                    break
        else:
            a = 7
        a = 3
    """)

    assert get_non_exp_parent_and_index(tree, tree.body[2]) == (tree, 2)
    assert get_non_exp_parent_and_index(tree, tree.body[2].body[0]) == (
        tree.body[2], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[2].body[1]) == (
        tree.body[2], 1)
    assert get_non_exp_

# Generated at 2022-06-23 23:46:49.975435
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # pragma: no cover
    parent = get_closest_parent_of(ast.parse("module.attr"),
                                   ast.Name("attr", ast.Load()),
                                   ast.Expression)
    child = get_closest_parent_of(ast.parse("module.attr"),
                                  ast.Name("attr", ast.Load()),
                                  ast.Attribute)
    assert get_non_exp_parent_and_index(parent, child) == (parent, 0)


# Generated at 2022-06-23 23:46:55.401389
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = """
    def foo():
        a = True
        if b:
            c = 3
    """

    result = ast.parse(source)
    node = result.body[0].body[0].value.elts[0].elts[0]

    assert get_non_exp_parent_and_index(result, node) == (
        result.body[0],
        0
    )



# Generated at 2022-06-23 23:46:58.117671
# Unit test for function replace_at
def test_replace_at():
    source = '''print("Hello, world!")'''
    tree = ast.parse(source)

    target_node = tree.body[0]
    replace_at(0, tree, [])

    assert source == ast.unparse(tree)



# Generated at 2022-06-23 23:47:09.489021
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.Expr(value=ast.Name(id='foo')) # type: ast.Expr
    tree = ast.Module(body=[
        ast.FunctionDef(name='foo', body=[
            ast.If(test=ast.Name(id='foo'), body=[
                ast.Expr(value=ast.BinOp(left=ast.Name(id='foo'),
                    op=ast.Add(), right=ast.Name(id='foo'))),
                ast.Expr(value=ast.BinOp(left=ast.Name(id='foo'),
                    op=ast.Add(), right=ast.Name(id='foo')))
            ])
        ])
    ])
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)

# Generated at 2022-06-23 23:47:16.732264
# Unit test for function replace_at
def test_replace_at():
    import ast
    import astunparse
    my_tree = ast.parse("""
    def fac(n):
        if n == 0:
            return 1
        else:
            return n * fac(n - 1)
    """, mode='exec')
    #    print(ast.dump(my_tree))
    my_tree2 = ast.parse("""
    def fac2(n):
        if n == 0:
            return 1
        else:
            return 4
    """, mode='exec')
    #    print(ast.dump(my_tree2))
    # Tricky part

# Generated at 2022-06-23 23:47:17.918939
# Unit test for function replace_at

# Generated at 2022-06-23 23:47:22.726955
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo(x):\n    if between_zero_and_ten(x):\n        return x + 2')
    node = get_closest_parent_of(tree, tree.body[0].body[0].test, ast.FunctionDef)
    assert node.name == 'foo'


# Generated at 2022-06-23 23:47:27.139697
# Unit test for function get_parent
def test_get_parent():
    code = '''
if True:\n pass\nelse:\n pass\n'''
    tree = ast.parse(code)
    if_node = tree.body[0]
    if_body_node = if_node.body[0]

    assert get_parent(tree, if_body_node) == if_node

# Generated at 2022-06-23 23:47:30.732902
# Unit test for function find
def test_find():
    code = '''
    def foo():
        a = 1 + 2
        a = bar()
    '''
    tree = ast.parse(code)
    print(find(tree, ast.FunctionDef))
    print(find(tree, ast.BinOp))

# Generated at 2022-06-23 23:47:31.889698
# Unit test for function find
def test_find():
    import ast
    import astunparse
    import textwrap

# Generated at 2022-06-23 23:47:32.694610
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:47:38.069090
# Unit test for function replace_at
def test_replace_at():
    test_ast = ast.parse('a = 7 + 5')
    test1 = ast.Expression(body=ast.BinOp(left=ast.Name(id='a'), op=ast.Add(),
                                          right=ast.Num(n=3)))
    replace_at(1, test_ast, test1)
    assert type(test_ast.body[1]).__name__ == 'Expr'

# Generated at 2022-06-23 23:47:45.240056
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    body = [
        ast.Expr(value=ast.Call(func=ast.Name(id="test", ctx=ast.Load()),
                                args=[], keywords=[])),
        ast.Expr(value=ast.Call(func=ast.Name(id="test", ctx=ast.Load()),
                                args=[], keywords=[])),
    ]
    mod = ast.Module(body=body)
    print(get_closest_parent_of(mod, body[0], ast.FunctionDef))

# Generated at 2022-06-23 23:47:48.829784
# Unit test for function find
def test_find():
    tree = ast.parse("""
        def test_func():
            pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Name))) == 3



# Generated at 2022-06-23 23:47:53.069029
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """
        def foo(x: int) -> int:
            x = 10
            return x
    """

    tree = ast.parse(code)
    print(get_closest_parent_of(tree, tree.body[0].body[0].targets[0], ast.FunctionDef))



test_get_closest_parent_of()

# Generated at 2022-06-23 23:47:59.310524
# Unit test for function insert_at
def test_insert_at():
    code = """
    def func(arg):
        print(arg)
    """
    tree = ast.parse(code, mode='exec')
    func = find(tree, ast.FunctionDef).__next__()
    print(func)
    new_node = ast.parse("print('test')", mode='exec').body[0]
    insert_at(0, func, new_node)
    print(ast.dump(tree))



# Generated at 2022-06-23 23:48:10.269861
# Unit test for function insert_at
def test_insert_at():
    source = """
        def foo():
            if x == 5:
                var = 3
    """

    module = ast.parse(source)
    func = find(module, ast.FunctionDef).__next__()
    if_st = find(func, ast.If).__next__()
    assert_equal(if_st.body[0].lineno, 3)

    insert_at(0, if_st, ast.Expr(value=ast.Num(n=4)))
    assert_equal(if_st.body[0].lineno, 4)

    insert_at(1, if_st, [
        ast.Expr(value=ast.Num(n=3)),
        ast.Expr(value=ast.Num(n=2)),
    ])

# Generated at 2022-06-23 23:48:17.917959
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    #Tests to get index of an expression
    tree = ast.parse('''
            def f():
                a = 1 + 1
                a = 3
                b = 3 + 3
                c = 4 + 4
    ''')

    first_assign = next(find(tree, ast.Assign))
    parent, index = get_non_exp_parent_and_index(tree, first_assign)

    assert isinstance(parent, ast.FunctionDef)
    assert index == 1



# Generated at 2022-06-23 23:48:21.080444
# Unit test for function find
def test_find():
    tree = compile('a = 1', '<string>', 'exec')
    assert next(find(tree, ast.Name)) == tree.body[0].targets[0]



# Generated at 2022-06-23 23:48:24.206534
# Unit test for function find
def test_find():
    def ret():
        return 10
    tree = ast.parse(ret.__code__.co_code)
    node = next(find(tree, ast.Return))
    assert isinstance(node, ast.Return)
    assert node.value.n == 10

# Generated at 2022-06-23 23:48:24.750963
# Unit test for function replace_at
def test_replace_at():
    pass

# Generated at 2022-06-23 23:48:31.614481
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # pylint: disable=missing-docstring
    # Declaration of variable str1
    var_decl = ast.Assign(targets=[ast.Name(id='var_decl', ctx=ast.Store())],
                          value=ast.Str(s='var_decl'))

    # Declaration of variable str2
    var_decl2 = ast.Assign(targets=[ast.Name(id='var_decl2', ctx=ast.Store())],
                           value=ast.Str(s='var_decl2'))

    # Call to str1
    call_str1 = ast.Expr(value=ast.Call(func=ast.Name(id='var_decl',
                                                      ctx=ast.Load()),
                                        args=[], keywords=[]))

    # Call to str2
    call_str

# Generated at 2022-06-23 23:48:36.889380
# Unit test for function find
def test_find():
    node = ast.parse('a')
    tree = ast.parse('def f():\n    return a')
    found_node = next(find(tree, ast.Name))
    assert node == found_node



# Generated at 2022-06-23 23:48:42.954029
# Unit test for function find
def test_find():
    tree = ast.parse("""
    for i in range(10):
        print("hello")
        continue
    print("hello")
    break
    print("hello")
    """)
    nodes = find(tree, ast.Print)
    assert len(list(nodes)) == 4


# Generated at 2022-06-23 23:48:52.787841
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    single_guard = ast.parse("""
    if test:
        x = 1
    else:
        x = 2
    """)

    assert isinstance(get_closest_parent_of(single_guard,
                                            single_guard.body[0].orelse[0],
                                            ast.If),
                      ast.If)

    assert isinstance(get_closest_parent_of(single_guard,
                                            single_guard.body[0].orelse[0],
                                            ast.Module),
                      ast.Module)

    assert isinstance(get_closest_parent_of(single_guard,
                                            single_guard.body[0].orelse[0],
                                            ast.While),
                      ast.Module)

# Generated at 2022-06-23 23:48:58.452116
# Unit test for function insert_at
def test_insert_at():
    import ast

    class Parent(ast.AST):
        body = []
        _fields = ['body']

    class Node1(ast.AST):
        pass

    class Node2(ast.AST):
        pass

    tree = Parent()
    insert_at(0, tree, Node1())
    insert_at(0, tree, Node2())
    assert isinstance(tree.body[0], Node2)
    assert isinstance(tree.body[1], Node1)



# Generated at 2022-06-23 23:49:02.037593
# Unit test for function get_parent
def test_get_parent():
    root = ast.parse('a = 1\nb = 2\n')

    assert get_parent(root, root.body[0]) == root
    assert get_parent(root, root.body[0].targets[0]) == root.body[0]
    assert get_parent(root, root.body[0].value) == root.body[0]
    assert get_parent(root, root.body[0].value.n) == root.body[0].value

# Generated at 2022-06-23 23:49:09.216184
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
        def add(a, b):
            if a > b:
                return a
            else:
                return b
    """)

    node = find(tree, ast.Name).__next__()
    assert isinstance(get_closest_parent_of(tree, node, ast.If), ast.If)



# Generated at 2022-06-23 23:49:19.283795
# Unit test for function insert_at
def test_insert_at():
    class Test(ast.AST):
        _fields = ('body',)

    def assert_body(ast_, exp):
        assert len(ast_.body) == len(exp)

        for i, x in enumerate(exp):
            assert ast_.body[i] is x

    ast_ = Test(body=[a, b, d])
    insert_at(0, ast_, c)
    assert_body(ast_, [c, a, b, d])
    insert_at(0, ast_, e)
    assert_body(ast_, [e, c, a, b, d])
    insert_at(1, ast_, [b, c])
    assert_body(ast_, [e, b, c, a, b, d])
    insert_at(2, ast_, b)

# Generated at 2022-06-23 23:49:25.780832
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('x = 1 + 1')

    closest_module = get_closest_parent_of(tree, tree.body[0].value.right, ast.Module)
    assert isinstance(closest_module, ast.Module)
    assert tree.body[0].value.right.__parent__ == closest_module

    closest_add = get_closest_parent_of(tree, tree.body[0].value.right, ast.Add)
    assert isinstance(closest_add, ast.Add)
    assert tree.body[0].value.right.__parent__ == closest_add

    try:
        get_closest_parent_of(tree, tree.body[0].value.right, ast.Num)
    except NodeNotFound:
        pass



# Generated at 2022-06-23 23:49:34.294842
# Unit test for function insert_at
def test_insert_at():
    program = ast.parse('def f(): a = 0')
    f = program.body[0]
    assert_equals(f.body[0].value.id, '0')
    insert_at(0, f.body, ast.parse('a = 1').body[0])
    assert_equals(f.body[0].value.id, '1')
    insert_at(2, f.body, ast.parse('a = 2').body[0])
    assert_equals(f.body[1].value.id, '0')
    assert_equals(f.body[2].value.id, '2')

# Generated at 2022-06-23 23:49:45.524012
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import unittest


# Generated at 2022-06-23 23:49:51.533297
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import parse
    tree = parse('x = 3 if C else 4')
    if_stmt = tree.body[0].value
    body = if_stmt.body
    expect((if_stmt, 0), get_non_exp_parent_and_index(tree, body[0]))
    expect((if_stmt, 1), get_non_exp_parent_and_index(tree, body[1]))


# Generated at 2022-06-23 23:49:56.503537
# Unit test for function replace_at
def test_replace_at():
    from typed_ast import ast3 as ast
    from .tester import compare_ast

    a = ast.parse('x=5')
    b = ast.parse('x=5')

    module_a = a.body.pop()
    module_b = b.body.pop()

    assert type(module_a) is type(module_b)

    replace_at(0, a, module_a)
    replace_at(0, b, module_b)

    compare_ast(a, b)



# Generated at 2022-06-23 23:50:07.313602
# Unit test for function replace_at
def test_replace_at():
    code = "def my_function():\n\tpass\nprint('my_string')"
    tree = ast.parse(code)
    print('Test data: before')
    print(ast.dump(tree))
    print('')

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])

    print('Test data: parent, index')
    print(ast.dump(parent))
    print(index)
    print('')

    node = ast.parse('\nprint(\'additional string\')\nprint(\'additional2\')')
    replace_at(index, parent, node.body)

    print('Test data: after')
    print(ast.dump(tree))
    print('')



# Generated at 2022-06-23 23:50:11.562300
# Unit test for function find
def test_find():
    from ..exceptions import NodeNotFound
    from ..ast import parse_ast, get_parent
    from ..ast import Module, Assign, Name


# Generated at 2022-06-23 23:50:17.810865
# Unit test for function find
def test_find():
    tree = ast.parse('def f():\n    # hello\n    x = 1')
    assert list(find(tree, ast.Name)) == [ast.Name(id='f', ctx=ast.Load()),
                                          ast.Name(id='x', ctx=ast.Store())]



# Generated at 2022-06-23 23:50:27.022452
# Unit test for function get_parent
def test_get_parent():
    """Test get parent functionality."""
    # pylint: disable=C0103
    from ..types import Context, Module

    tree = """
    class B:
        def foo(self):
            pass

    def bar():
        pass

    def main():
        pass
    """
    ctx = Context()
    module = Module(ctx, tree)
    assert isinstance(get_parent(module.ast, module.ast.body[1].body[0]), ast.FunctionDef)  # type: ignore
    assert isinstance(get_parent(module.ast, module.ast.body[2]), ast.ClassDef)  # type: ignore

# Generated at 2022-06-23 23:50:33.322692
# Unit test for function insert_at
def test_insert_at():
    import typed_astunparse
    root = ast.parse("def foo(): pass")
    insert_at(0, root.body[0], ast.Name("foo", ast.Load()))
    print(typed_astunparse.unparse(root))



# Generated at 2022-06-23 23:50:39.379526
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def some_function():
        pass

    assert type(get_closest_parent_of(ast.parse(some_function.__doc__),
                                      ast.parse(some_function.__doc__).body[0],
                                      ast.Module)) is ast.Module


# Generated at 2022-06-23 23:50:39.843588
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-23 23:50:48.388489
# Unit test for function replace_at
def test_replace_at():
    from typed_ast.ast3 import parse
    from typed_ast import ast3
    string = parse("for i in range(5): print(i)")
    expected_string = "for i in range(5): print(i); print(i)"
    parent = get_parent(string, string.body[0])
    replace_at(0, parent, [string.body[0], ast3.Expr(value=string.body[0].body[0])])
    assert ast.dump(string) == ast.dump(parse(expected_string))



# Generated at 2022-06-23 23:50:52.689083
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent."""
    x = ast.parse('y = 5, y')
    y = x.body[0].value.elts[1]
    assert get_parent(x, y) == x.body[0].value  # type: ignore



# Generated at 2022-06-23 23:50:57.110893
# Unit test for function find
def test_find():
    example = ast.parse("example = 1")
    assert len(list(find(example, ast.Assign))) == 1
    assert len(list(find(example, ast.Name))) == 2


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-23 23:51:05.679471
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("""
    def func(a):
        a = a + 1
    """)
    funcdef = tree.body[0]
    assign = funcdef.body[0]
    addition = assign.value
    binop = addition.left
    target = binop.right
    # target has the following structure:
    # -- target
    # ---- Name(); id="a"
    # -- Assign(); value=Name(); id="a"
    # ---- name=<class '_ast.Name'>
    # ---- op=<class '_ast.Add'>
    # ---- cmpop=None
    # ---- excepthandler=None
    # ---- orelse=[]
    # ---- body=[]
    # ---- test=None
    # ---- iter=None
    # ---- args=[]
    # ----

# Generated at 2022-06-23 23:51:14.843435
# Unit test for function get_parent
def test_get_parent():
    def f():  # pylint:disable=unused-variable
        pass

    tree: ast.AST = ast.parse('a = 2')
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].value) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree

    assert get_parent(ast.parse(inspect.getsource(f)),
                      ast.parse(inspect.getsource(f)).body[0]) == \
           ast.parse(inspect.getsource(f))

    # Test node which is not in a tree
    node = ast.Name(id='a')
    assert get_parent(tree, node) is None



# Generated at 2022-06-23 23:51:22.822572
# Unit test for function get_parent
def test_get_parent():
    # Test imports
    imp = ast.parse('import foo')
    imp_alias = ast.parse('import foo as bar')
    imp_from = ast.parse('from foo import bar')
    imp_from_alias = ast.parse('from foo import bar as baz')

    foos = [imp, imp_alias, imp_from, imp_from_alias]

    for foo in foos:
        assert get_parent(foo, foo.body[0]).__class__ is ast.Module

    # Test functions
    func = ast.parse('def foo(): pass')
    func_args = ast.parse('def foo(bar): pass')
    func_args_defaults = ast.parse('def foo(bar=1): pass')

# Generated at 2022-06-23 23:51:33.870818
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse(
        """if a:
               if b:
                   pass
           if c:
               pass""")

    if_a = tree.body[0]  # type: ast.If
    if_b = if_a.body[0].body[0]  # type: ast.If
    if_c = tree.body[1]  # type: ast.If

    insert_at(0, if_a, ast.parse('pass').body[0])
    insert_at(1, if_b, ast.parse('pass').body[0])
    insert_at(1, if_c, ast.parse('pass').body[0])


# Generated at 2022-06-23 23:51:39.861433
# Unit test for function replace_at
def test_replace_at():
    method = ast.FunctionDef('test', ast.arguments([], None, None, []), [], [],
                             None)
    body = method.body = []

    test1 = ast.Expr(ast.Str('Test'))
    body.append(test1)

    replace_at(0, method, ast.Expr(ast.Str('Test2')))
    assert len(method.body) == 1
    assert method.body[0].value.s == 'Test2'

# Generated at 2022-06-23 23:51:40.788647
# Unit test for function get_parent

# Generated at 2022-06-23 23:51:48.888023
# Unit test for function insert_at
def test_insert_at():
    prog = ast.parse("""x = 0
for i in range(10):
    x = x + i""")

    insert_at(0, prog, ast.parse("y = 0").body[0])


# Generated at 2022-06-23 23:51:52.034400
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('def f():\n    pass')
    parent = tree.body[0]
    insert_at(0, parent, ast.Pass())
    new_tree = ast.parse('def f():\n    pass\n    pass')
    assert ast.dump(tree) == ast.dump(new_tree)


# Generated at 2022-06-23 23:52:00.557095
# Unit test for function get_parent
def test_get_parent():
    program = ast.parse('x = 0\nx = 1')
    assign_1 = program.body[0]
    assign_2 = program.body[1]

    assert get_parent(program, assign_1) == program
    assert get_parent(program, assign_1.value) == assign_1
    assert get_parent(program, assign_2) == program
    assert get_parent(program, assign_2.value) == assign_2
    assert get_parent(program, assign_2.value.n) == assign_2.value



# Generated at 2022-06-23 23:52:06.593344
# Unit test for function replace_at

# Generated at 2022-06-23 23:52:15.656867
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = """
        (defn foo (bar)
            (baz)
            (quux)
        )
    """
    parsed = ast.parse(code)
    function_def = get_closest_parent_of(parsed, parsed.body[0].body[1], ast.FunctionDef)
    parent, index = get_non_exp_parent_and_index(parsed, function_def)
    expected_parent = parsed.body[0]
    expected_index = 0
    assert parent == expected_parent
    assert index == expected_index

# Generated at 2022-06-23 23:52:24.420035
# Unit test for function insert_at
def test_insert_at():
    import ast

    @ast.wrap_subclass()
    class A(ast.AST):
        _fields = ("a",)

    @ast.wrap_subclass()
    class B(ast.AST):
        _fields = ("b",)
    class C(ast.AST):
        _fields = ("body",)

    a = A(a=1)
    b = B(b=2)
    c = C(body=[])
    c.body.append(a)

    index = c.body.index(a)
    insert_at(index, c, b)

    assert c.body[index] == b



# Generated at 2022-06-23 23:52:26.396722
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .test_helper import parse_str, assert_equal


# Generated at 2022-06-23 23:52:32.740378
# Unit test for function insert_at
def test_insert_at():
    with open('test.py', 'r') as f:
        test = f.read()

    test_ast = ast.parse(test)
    tree = ast.parse('def test(a, b):\n\tpass')

    x = find(test_ast, ast.FunctionDef)
    y = list(x)[0]

    tree.body.insert(0, y)

    print(ast.dump(tree))

    # tree.body.pop(0)

# Generated at 2022-06-23 23:52:36.124601
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def test_fn():\n\treturn 1')
    assert(get_non_exp_parent_and_index(tree, tree.body[0].body[0])
           == (tree.body[0], 1))


# Generated at 2022-06-23 23:52:38.897683
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
        def f():
            def f1():
                def f2():
                    pass
                pass
            pass
        ''')
    _build_parents(tree)
    f2 = tree.body[0].body[0].body[0]
    assert get_closest_parent_of(tree, f2, ast.FunctionDef) == f2.parent.parent.parent

# Generated at 2022-06-23 23:52:48.722978
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('[a, b, c]')
    insert_at(1, list(tree.body)[0], ast.parse('e, f'))
    assert ast.dump(tree) == "Expr(value=List(elts=[Name(id='a', ctx=Load()), \
Name(id='e', ctx=Load()), Name(id='f', ctx=Load()), Name(id='b', ctx=Load()), \
Name(id='c', ctx=Load())]))"
    replace_at(2, list(tree.body)[0], ast.parse('g, h'))

# Generated at 2022-06-23 23:52:58.764345
# Unit test for function replace_at
def test_replace_at():
    class TestAST(ast.AST):
        def __init__(self, val: str) -> None:
            self.val = val

        def __str__(self) -> str:
            return self.val

    tree = ast.Module([
        TestAST('a'),
        TestAST('b'),
        TestAST('c'),
        TestAST('d'),
    ])

    replace_at(2, tree, [
        TestAST('e'),
        TestAST('f'),
    ])
