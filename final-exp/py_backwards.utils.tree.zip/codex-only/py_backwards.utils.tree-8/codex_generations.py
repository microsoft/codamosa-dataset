

# Generated at 2022-06-23 23:42:58.738832
# Unit test for function get_parent
def test_get_parent():
    test_tree = ast.parse('if a: print(a)', '', 'single')
    assert isinstance(get_parent(test_tree, test_tree.body[0].body[0]), ast.Module)
    assert isinstance(get_parent(test_tree, test_tree.body[0]), ast.Module)
    assert isinstance(get_parent(test_tree, test_tree.body[0].body), ast.If)
    generated_code = ast.parse('a = b + c', '', 'single')
    assert isinstance(get_parent(generated_code, generated_code.body[0].value), ast.Module)
    assert isinstance(get_parent(generated_code, generated_code.body[0].value.right), ast.BinOp)


# Generated at 2022-06-23 23:43:05.977875
# Unit test for function find
def test_find():
    tree = ast.parse('a = a + b')
    assert list(find(tree, ast.Name)) == [ast.Name(id='a', ctx=ast.Store()),
                                          ast.Name(id='a', ctx=ast.Load()),
                                          ast.Name(id='b', ctx=ast.Load())]
    assert list(find(tree, ast.Add)) == [ast.BinOp(
        left=ast.Name(id='a', ctx=ast.Load()), op=ast.Add(),
        right=ast.Name(id='b', ctx=ast.Load()))]
    assert find(tree, ast.BinOp) is not None



# Generated at 2022-06-23 23:43:11.261654
# Unit test for function find
def test_find():
    # Finds first use of variable
    tree = ast.parse('''
for _ in range(1, 10):
    pass
assert x == 3''')

    node = list(find(tree, ast.Name))[0]

    assert node == ast.parse('''assert x == 3''').body[0]


# Generated at 2022-06-23 23:43:21.788922
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:43:29.877367
# Unit test for function get_parent
def test_get_parent():
    test_src = "def fun(a, b, c):\n    return a if a and b or c*a"
    module = ast.parse(test_src)

    # Test for the module node 
    assert get_parent(module, module) == module
    # Test for function node
    func = find(module, ast.FunctionDef).__next__()
    assert get_parent(module, func) == module
    # Test for return node
    assert get_parent(module, find(func, ast.Return).__next__()) == func


# Generated at 2022-06-23 23:43:41.321177
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node1 = ast.While(test=None, body=[], orelse=[])
    node2 = ast.If(test=None, body=[], orelse=[])
    node3 = ast.While(test=None, body=[], orelse=[])
    node4 = ast.With(items=[], body=[])
    node5 = ast.AsyncWith(items=[], body=[])
    node6 = ast.FunctionDef(name='', args=ast.arguments(args=[], vararg=None,
                                                        kwonlyargs=[],
                                                        kw_defaults=[],
                                                        kwarg=None,
                                                        defaults=[]),
                            body=[], decorator_list=[], returns=None)
    node6.body = [node1, node2, node3, node4, node5]

# Generated at 2022-06-23 23:43:46.938324
# Unit test for function get_parent
def test_get_parent():
    class_node = ast.ClassDef(
        name='TestClass',
        body=[ast.Pass()],
        decorator_list=[],
        bases=[],
        keywords=[]
    )

    tree = ast.Module(body=[class_node])

    assert get_parent(tree, class_node.body[0]) == class_node
    assert get_parent(tree, class_node) == tree



# Generated at 2022-06-23 23:43:47.574472
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-23 23:43:52.831809
# Unit test for function insert_at
def test_insert_at():
    t = ast.parse("1 + 2 + 3")
    good_t = ast.parse("1 + 2 + 3 + 4")
    f = find(t, ast.BinOp)
    tup = get_non_exp_parent_and_index(t, next(f))
    insert_at(tup[1], tup[0], ast.BinOp(ast.Num(3), ast.Add(), ast.Num(4)))
    assert ast.dump(t) == ast.dump(good_t)


# Generated at 2022-06-23 23:43:59.050443
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor

    # TODO: add unittest.
    def main():
        def foo():
            pass
        def foo2():
            pass
    code = astor.to_source(main)
    tree = ast.parse(code)  # type: ignore
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent == tree
    assert index == 0



# Generated at 2022-06-23 23:44:06.213702
# Unit test for function find
def test_find():
    import astor
    source = """
    def foo(self, arg0):
        a = 0
        b = 1
        c = 2
        return a * b * c
    """
    tree = ast.parse(source)
    nodes = list(find(tree, ast.Num))
    assert astor.dump(nodes[0]) == "0"
    assert astor.dump(nodes[1]) == "1"
    assert astor.dump(nodes[2]) == "2"
    assert astor.dump(nodes[3]) == "a * b * c"


# Generated at 2022-06-23 23:44:10.824875
# Unit test for function replace_at
def test_replace_at():
    parent = ast.Module([ast.Name(id="a", ctx=ast.Load()), ast.Name(id="b", ctx=ast.Load()), ast.Name(id="c", ctx=ast.Load())])
    nodes = [ast.Name(id="d", ctx=ast.Load())]
    replace_at(1, parent, nodes)
    print(parent.body)
    print(nodes)


# Generated at 2022-06-23 23:44:22.878568
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # calling function with a tree that is not an ast.AST, should return a
    # value error
    not_a_ast = 42
    with pytest.raises(ValueError):
        get_non_exp_parent_and_index(not_a_ast, not_a_ast)

    # calling function with a node that is not an ast.AST, should return a
    # value error
    ast_there_is_no_child = ast.Module()
    with pytest.raises(ValueError):
        get_non_exp_parent_and_index(ast_there_is_no_child, not_a_ast)

    # calling function with a valid tree, but an unexisting node, should return
    # a value error
    unexisting_node = ast.Num()
    ast_tree = ast.Module()
   

# Generated at 2022-06-23 23:44:28.482809
# Unit test for function get_parent
def test_get_parent():
    """get_parent() test."""
    program = ast.parse("if a == b: pass")
    assert isinstance(get_parent(program, program), ast.Module)
    assert isinstance(get_parent(program, program.body[0]), ast.Module)
    assert isinstance(get_parent(program, program.body[0].test), ast.If)

# Generated at 2022-06-23 23:44:35.526445
# Unit test for function get_parent
def test_get_parent():
    import ast
    # test ast: Assign | Call
    #     test ast: Name | num
    #     test ast: Num
    test_ast = ast.parse("test = test(1)")

    # first test
    parent = get_parent(test_ast, test_ast.body[0].value)
    assert(isinstance(parent, ast.Assign))

    # second test
    parent = get_parent(test_ast, test_ast.body[0].value.args[0])
    assert(isinstance(parent, ast.Call))

    # first test
    parent = get_parent(test_ast, test_ast.body[0].value.args[0].n)
    assert(isinstance(parent, ast.Num))

    # second test

# Generated at 2022-06-23 23:44:40.464784
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert(isinstance(get_closest_parent_of(ast.parse("x = [1,2,3,4,5]"),
                                            ast.parse("x = [1,2,3,4,5]").body[0].value,
                                            ast.List), ast.List))



# Generated at 2022-06-23 23:44:41.667834
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:44:51.919722
# Unit test for function find
def test_find():
    import builtins
    import antlr4
    from ..parser import PyteParser

    code = """
    def foo(a):
        for i in range(10):
            for j in range(10):
                if a < 2:
                    break
        return 2
    """

    parser = PyteParser(code)
    tree = parser.root
    _, parent, index = next(find(tree, ast.For))
    assert isinstance(parent, ast.FunctionDef)
    assert get_parent(tree, parent) is tree
    assert tree.body[0] is parent
    assert parent.body[0] is _
    assert parent.body[0].body[0] is _
    assert parent.body[0].body[0].body[0].body[0] is _
    assert index == 0
    assert parent.body

# Generated at 2022-06-23 23:44:58.885309
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    program = ast.parse('''
    class Node:
        def __init__(self):
            self.expression_list = []
            self.node_type = 'Node'

    class Integer(Node):
        def __init__(self, value):
            super().__init__()
            self.value = value
            self.node_type = 'Integer'
    ''')

    target_node = program.body[1].body[0]
    parent, index = get_non_exp_parent_and_index(program, target_node)
    assert index == 0
    assert isinstance(parent, ast.ClassDef)

# Generated at 2022-06-23 23:45:08.917240
# Unit test for function replace_at
def test_replace_at():
    class P:
        pass
    p = P()
    p.body = [1, 2, 3, 4]
    replace_at(2, p, [5, 6, 7])
    assert p.body == [1, 2, 5, 6, 7, 4]
    replace_at(1, p, 8)
    assert p.body == [1, 8, 2, 5, 6, 7, 4]
    replace_at(5, p, [9, 10])
    assert p.body == [1, 8, 2, 5, 6, 9, 10, 7, 4]
    replace_at(2, p, [11, 12, 13, 14, 15])
    assert p.body == [1, 8, 11, 12, 13, 14, 15, 5, 6, 9, 10, 7, 4]
    replace_

# Generated at 2022-06-23 23:45:19.947389
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast.ast3 import parse
    parsed = parse('a = b + c')
    ast.fix_missing_locations(parsed)
    parent = get_closest_parent_of(parsed, parsed.body[0].value.left, ast.Module)
    assert isinstance(parent, ast.Module)
    parent = get_closest_parent_of(parsed, parsed.body[0].value.left, ast.Expr)
    assert isinstance(parent, ast.Expr)
    parent = get_closest_parent_of(parsed, parsed.body[0].value.left, ast.BinOp)
    assert isinstance(parent, ast.BinOp)

# Generated at 2022-06-23 23:45:23.544965
# Unit test for function find
def test_find():
    code = '''
    import os
    import sys
    import math
    '''

    root = ast.parse(code)
    nodes = list(find(root, ast.Import))

    assert len(nodes) == 3

# Generated at 2022-06-23 23:45:30.084649
# Unit test for function insert_at
def test_insert_at():
    # Test definition of a class
    test_tree = ast.parse("class A(object):\n" +
                          "    def __init__(self):\n" +
                          "        self.a = 1\n" +
                          "        self.b = 2\n" +
                          "    def test(self):\n" +
                          "        self.c = 3\n")
    insert_at(0, test_tree, ast.parse("def test2(self):\n" +
                                      "    self.c = 3\n").body[0])

# Generated at 2022-06-23 23:45:32.120470
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse('a = 0')
    assert get_parent(node, node.body[0].targets[0]) == node.body[0]

# Generated at 2022-06-23 23:45:43.460040
# Unit test for function get_parent
def test_get_parent():
    from typed_ast.ast3 import Module, FunctionDef, Name, Pass, Expr

    # Function definition
    t = FunctionDef(name='hello',
                    args=FunctionDef.args(),
                    body=[Pass()],
                    decorator_list=[])
    get_parent(Module(body=[t]), t)
    assert isinstance(get_parent(Module(body=[t]), t), Module)

    # Function call
    f = FunctionDef(name='hello',
                    args=FunctionDef.args(),
                    body=[Pass()],
                    decorator_list=[])
    e = Expr(value=Name(id='hello', ctx=Name.Load()))
    get_parent(Module(body=[e]), e)
    assert isinstance(get_parent(Module(body=[e]), e), Module)



# Generated at 2022-06-23 23:45:53.092919
# Unit test for function get_parent

# Generated at 2022-06-23 23:46:03.977252
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""\
    def f(a, b, c):
        print(b)
        print(c)
        return a
        """)
    _build_parents(tree)
    parent = get_parent(tree, tree.body[0], rebuild=False)
    assert parent == tree

    parent = get_parent(tree, tree.body[0].body[0], rebuild=False)
    assert parent == tree.body[0]

    parent = get_parent(tree, tree.body[0].body[1], rebuild=False)
    assert parent == tree.body[0]

    parent = get_parent(tree, tree.body[0].body[2], rebuild=False)
    assert parent == tree.body[0]


# Generated at 2022-06-23 23:46:12.997190
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import typed_astunparse
    import astunparse
    class ModuleVisitor(ast.NodeVisitor):
        def __init__(self):
            self.count = 0

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            print(astor.to_source(node))
            print(typed_astunparse.unparse(node))
            print(astunparse.unparse(node))
            self.count += 1

    def create_tree():
        a1 = ast.AnnAssign(
            target=ast.Name(id='a', ctx=ast.Store()),
            annotation=ast.Name(id='int', ctx=ast.Load()),
            value=ast.Num(n=1),
            simple=1
        )


# Generated at 2022-06-23 23:46:18.183985
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse("""
        def foo():
            pass
    """)

    def_node = node.body[0]
    pass_node = def_node.body[0]

    test_node = get_parent(node, pass_node)
    assert test_node == def_node

    with pytest.raises(NodeNotFound):
        get_parent(node, ast.Pass())



# Generated at 2022-06-23 23:46:19.371840
# Unit test for function insert_at

# Generated at 2022-06-23 23:46:23.991409
# Unit test for function find
def test_find():
    import astor, astunparse
    t = """def foo(a):\n  return a"""
    tree = ast.parse(t)
    module_node = ast.Module(body=list(find(tree, ast.FunctionDef)))
    result = astunparse.unparse(module_node)

# Generated at 2022-06-23 23:46:30.095007
# Unit test for function replace_at
def test_replace_at():
    """ Test the function replace_at."""
    node = ast.parse('x = 1')
    node2 = ast.parse('y = 2')
    parent = ast.parse('x = 1')
    parent2 = ast.parse('y = 2')
    # Test one node
    replace_at(0, parent, node2)
    assert 'x = 1' not in ast.dump(parent)
    assert 'y = 2' in ast.dump(parent)
    # Test multiple nodes
    replace_at(0, parent, [node, node2])
    assert 'y = 2' not in ast.dump(parent)
    assert 'x = 1' in ast.dump(parent)


# Generated at 2022-06-23 23:46:35.691977
# Unit test for function find
def test_find():
    code = """
    def foo(arg1):
        a = 1
        b = 2
        c = 3
    """
    tree = ast.parse(code)
    assert list(map(type, find(tree, ast.FunctionDef))) \
        == [ast.FunctionDef]
    for node in find(tree, ast.FunctionDef):
        node.name = 'bar'
    assert tree.body[0].name == 'bar'



# Generated at 2022-06-23 23:46:41.602469
# Unit test for function insert_at
def test_insert_at():
    class Node(ast.AST):
        _fields = ('body', )

    root = Node()
    root.body = []

    insert_at(0, root, 3)
    assert root.body[0] == 3

    insert_at(0, root, [3, 2])
    assert root.body[0] == 3
    assert root.body[1] == 2



# Generated at 2022-06-23 23:46:48.755458
# Unit test for function get_parent
def test_get_parent():
    """Test function get_parent."""

    class_node = ast.ClassDef(name='MyClass',
                              bases=[],
                              body=[],
                              decorator_list=[],
                              keywords=[])

    def test_func():
        """Test function."""
        class_node.body.append(ast.FunctionDef(name='test_func',
                                               args=ast.arguments(args=[],
                                                                  vararg=None,
                                                                  kwonlyargs=[],
                                                                  kw_defaults=[],
                                                                  kwarg=None,
                                                                  defaults=[]),
                                               body=[],
                                               decorator_list=[],
                                               returns=None))

    test_func()


# Generated at 2022-06-23 23:46:52.019045
# Unit test for function insert_at
def test_insert_at():
    src = 'a = 1 + 5'
    tree = ast.parse(src)
    assignment = find(tree, ast.Assign).__next__()
    constant = find(tree, ast.Constant).__next__()
    new_node = ast.Constant(5)
    insert_at(1, assignment, new_node)
    new_tree = ast.parse("a = 1 + 5 + 5")
    assert ast.dump(tree) == ast.dump(new_tree)

# Generated at 2022-06-23 23:46:56.427956
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Node:
        pass

    tree = Node()
    node = Node()
    parent = Node()
    grandpa = Node()
    setattr(node, 'parent', parent)
    setattr(parent, 'parent', grandpa)

    assert get_closest_parent_of(tree, node, Node) is node.parent

# Generated at 2022-06-23 23:46:57.164906
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:46:57.790895
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:47:05.643508
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('a = 0 + 1 + 2')
    assert isinstance(get_closest_parent_of(tree, tree.body[0].value, ast.Expr),
                      ast.Expr)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].value, ast.Num),
                      ast.Num)
    assert isinstance(get_closest_parent_of(tree.body[0].value,
                                            tree.body[0].value.left, ast.Num),
                      ast.Num)



# Generated at 2022-06-23 23:47:09.907541
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a = 1')
    output = ast.parse('a = 1')
    insert_at(0, output, ast.parse('x = 2'))
    assert ast.dump(tree) == ast.dump(output)


# Generated at 2022-06-23 23:47:15.378968
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('for a in range(1): pass')
    target = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, parent=target)

    assert parent.body[index].value.func.id == 'range'
    insert_at(index, parent, [ast.Expr(ast.Num(1))])
    assert parent.body[index].value.n == 1
    assert parent.body[index + 1].value.func.id == 'range'

# Generated at 2022-06-23 23:47:26.236384
# Unit test for function get_parent
def test_get_parent():
    program = ast.parse("""
    program = LexicalParsing()
    program.parse_sequence(["(", ")", ")"])
    program.parse_sequence(["(", "{", "{", "{", "{", "}", "}", "}", "}", ")"])
    program.parse_sequence(["{", "{", "{", "{", "{", "}", "}", "}", "}", "}"])
    program.parse_sequence(["{", "{", "{", "{", "{", "(", ")", "}", "}", "}", "}", "}"])
    """)

    while type(program) is ast.Module:
        program = program.body[0]

    call1 = program.body[0].value
    call2 = program.body[1].value

    assert call1

# Generated at 2022-06-23 23:47:27.642677
# Unit test for function replace_at
def test_replace_at():
    import astor  # type: ignore
    

# Generated at 2022-06-23 23:47:32.373676
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(ast.parse('a + b'), ast.parse('a + b').body[0]) == (ast.parse('a + b'), 0)
    assert get_non_exp_parent_and_index(ast.parse('f(a + b)'), ast.parse('a + b').body[0]) == (ast.parse('a + b'), 0)


# Generated at 2022-06-23 23:47:33.178551
# Unit test for function get_parent

# Generated at 2022-06-23 23:47:44.038062
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    import io
    import astor

    class Test(unittest.TestCase):
        def test_function_def(self):
            c = ast.parse("""
            def test():
                pass
                """)  # type: ignore

            t = c.body[0]
            self.assertEqual(get_closest_parent_of(c, t.body[0], ast.FunctionDef), t)

        def test_if_stmt(self):
            c = ast.parse("""
            def test():
                if True:
                    pass
                """)  # type: ignore
            t = c.body[0]
            self.assertEqual(get_closest_parent_of(c, t.body[0].body[0], ast.If), t.body[0])

# Generated at 2022-06-23 23:47:48.881825
# Unit test for function get_parent
def test_get_parent():
    t = ast.parse('class A{B}')
    c = t.body[0]
    v = c.body[0]
    assert get_parent(t, v) == c
    assert get_parent(t, c) == t

if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-23 23:47:51.982944
# Unit test for function find
def test_find():
    assert list(find(test_tree, ast.Module)) == [test_tree]
    assert list(find(test_tree, ast.If)) == [test_tree.body[2]]
    assert list(find(test_tree, ast.Name)) == [
        test_tree.body[0].value,
        test_tree.body[1].value,
        test_tree.body[2].test.left
    ]



# Generated at 2022-06-23 23:47:57.134122
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = 'def foo():\n\tpass\ndef bar():\n\tpass'
    tree = ast.parse(code)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1].body[0])
    assert parent == tree.body[1]  # type: ignore
    assert index == 0

# Generated at 2022-06-23 23:48:08.808444
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    from ..exceptions import NodeNotFound
    from typed_ast.ast3 import Load, FunctionDef, arguments
    from typed_ast.ast3 import Assign, Name, Store

    class TestGetClosestParentOf(unittest.TestCase):
        def test_return_closest_parent_of_given_type(self):
            node = Name(id='foo', ctx=Load())
            parent_node = Assign(targets=[node], value=Name(id='bar', ctx=Load()))

# Generated at 2022-06-23 23:48:09.703501
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor

# Generated at 2022-06-23 23:48:11.773458
# Unit test for function find
def test_find():
    from astor import dump_tree


# Generated at 2022-06-23 23:48:22.381922
# Unit test for function replace_at
def test_replace_at():
    from astor import codegen
    tree = ast.parse('def f():\n'
                     '    print("hello")\n'
                     '    print("world")\n')
    parent = tree.body[0].body
    print('Before modification:\n%s' % codegen.to_source(tree))
    replace_at(0, parent, ast.parse('print("hi")').body[0].body[0])
    print('After modification:\n%s' % codegen.to_source(tree))
    # The output is shown below:
    # Before modification:
    # def f():
    #     print("hello")
    #     print("world")
    # After modification:
    # def f():
    #     print("hi")
    #     print("world")

# Generated at 2022-06-23 23:48:25.544983
# Unit test for function get_parent
def test_get_parent():
    # Given
    import inspect
    import functools

    def wrap():
        return 1

    tree = ast.parse(inspect.getsource(functools))
    node = find(tree, ast.FunctionDef).__next__()

    # When
    parent = get_parent(tree, node)

    # Then
    assert isinstance(parent, ast.Module)



# Generated at 2022-06-23 23:48:36.496686
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test1 = ast.parse(
        """
        if var == 3:
            body
        else:
            body2
        """
    )
    if_node, _ = test1.body
    _parent, index = get_non_exp_parent_and_index(test1, if_node)
    assert index == 0

    test2 = ast.parse(
        """
        if var == 3:
            body
        if var2 == 1:
            body2
        """
    )
    if_node, _ = test2.body[1]
    _parent, index = get_non_exp_parent_and_index(test2, if_node)
    assert index == 1



# Generated at 2022-06-23 23:48:41.799439
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class SomeClass(ast.AST):
        fields = ()

    class SomeOtherClass(SomeClass):
        fields = ()

    tree = SomeClass()
    tree.body = [
        SomeOtherClass(),
        SomeClass(),
        SomeOtherClass()
    ]  # type: ignore

    _build_parents(tree)

    assert get_closest_parent_of(tree, tree.body[0], SomeClass) == tree

# Generated at 2022-06-23 23:48:52.005878
# Unit test for function replace_at
def test_replace_at():

    import typed_ast
    from typed_ast import ast3 as ast

    # 1,2,3,4
    node = ast.BinOp(left=ast.Literal(1, lineno=1, col_offset=0),
                     op=ast.Add(),
                     right=ast.Literal(2, lineno=1, col_offset=0),
                     lineno=1,
                     col_offset=0)

    parent = ast.Expr(value=node, lineno=1, col_offset=0)
    listNode = ast.Literal(value=1, lineno=1, col_offset=0)
    listNode2 = ast.Literal(value=2, lineno=1, col_offset=0)
    replace_at(0, parent, [listNode, listNode2])


# Generated at 2022-06-23 23:49:00.760280
# Unit test for function get_parent
def test_get_parent():
    # tree = ast.parse('1+1')
    # tree = ast.parse('print("Hello world")')
    tree = ast.parse('print(1+1)')
    _build_parents(tree)

    parent = get_parent(tree, tree.body[0])
    assert isinstance(parent, ast.Module), parent.__class__.__name__
    assert parent is tree, parent

    parent = get_parent(tree, tree.body[0].value)
    assert isinstance(parent, ast.Expr), parent.__class__.__name__
    assert parent is tree.body[0], parent

    parent = get_parent(tree, tree.body[0].value.args[0])
    assert isinstance(parent, ast.Call), parent.__class__.__name__
    assert parent is tree.body

# Generated at 2022-06-23 23:49:06.652662
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert isinstance(get_closest_parent_of(ast.parse(""), ast.Module()), ast.Module)


# Generated at 2022-06-23 23:49:12.417882
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Unit test for function get_closest_parent_of."""
    node = ast.parse('while True: a = b = 1')
    tree = ast.parse('while True: a = b = 1')
    assert isinstance(get_closest_parent_of(tree, node.body[0].body[0],
                                            ast.While),
                      ast.While)
    assert get_closest_parent_of(tree, node.body[0].body[0], ast.While) \
           == node



# Generated at 2022-06-23 23:49:13.656630
# Unit test for function replace_at

# Generated at 2022-06-23 23:49:19.282565
# Unit test for function replace_at
def test_replace_at():
    import astor
    program = \
        """def func():
            'hello'
        """

    tree = ast.parse(program)
    parent, index = get_non_exp_parent_and_index(tree,
                                                 tree.body[0].body[0])  # type: ignore
    replace_at(index, parent, ast.Str("world"))

    assert astor.to_source(tree) == \
        """def func():
            'world'
        """

# Generated at 2022-06-23 23:49:23.144407
# Unit test for function replace_at
def test_replace_at():
    class MockExp:
        body = []

    mock_parent = MockExp()
    insert_at(0, mock_parent, ast.parse('a = 1').body[0])
    replace_at(0, mock_parent, ast.parse('a = 2').body[0])
    assert mock_parent.body[0].value.n == 2

# Generated at 2022-06-23 23:49:29.146176
# Unit test for function find
def test_find():
    import unittest
    import typed_ast.ast3 as ast

    class FindTestCase(unittest.TestCase):

        def test_find(self):
            find_result = list(find(ast.parse('a'), ast.Name))
            self.assertEqual(find_result, [ast.parse('a').body[0].value])

    unittest.main()


# Generated at 2022-06-23 23:49:34.719944
# Unit test for function replace_at
def test_replace_at():
    node = ast.parse('def test():\n'
                     '    pass\n'
                     '    pass\n')
    replace_at(0, node.body[0], ast.Expr(ast.Name(id='test')))
    print(ast.dump(node))

    assert node.body[0].body[0].value.id == 'test'
    assert len(node.body[0].body) == 1



# Generated at 2022-06-23 23:49:45.788422
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Make a class
    my_class = ast.ClassDef(name='MyClass',
        bases=[],
        keywords=[],
        body=[
            ast.FunctionDef(
                name='my_func',
                args=ast.arguments(
                    args=[],
                    vararg=None,
                    kwonlyargs=[],
                    kw_defaults=[],
                    kwarg=None,
                    defaults=[]),
                body=[
                    ast.Return(value=ast.Name(id='x', ctx=ast.Load())),
                ],
                decorator_list=[],
                returns=None,
            )
        ],
        decorator_list=[],
    )

    # Gives right answer

# Generated at 2022-06-23 23:49:55.401055
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def f():\n  x = 1\nx = 2\ndel x\n')
    f = tree.body[0]

    # Check that replacement works
    x1 = f.body[0].targets[0]
    x2 = tree.body[2].targets[0]
    assert x1.id == 'x'
    assert x1 is not x2
    assert x2.id == 'x'

    del_stmt = tree.body.pop(2)
    replace_at(1, f, [del_stmt])
    assert f.body[1] is del_stmt
    assert tree.body == [f, ast.Expr(x1)]

    # Check that replacement is possible after pop
    replace_at(1, f, [x2])
   

# Generated at 2022-06-23 23:50:06.026343
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_tree = ast.parse('''
if a:
    if b:
        pass
    for c in c:
        pass

while a:
    pass
''')
    pass_node = next(find(test_tree, ast.Pass))

    assert pass_node.name == 'test_get_closest_parent_of.<locals>.<lambda>'

    assert get_closest_parent_of(test_tree, pass_node, ast.If) \
        is test_tree.body[0].body[0]
    assert get_closest_parent_of(test_tree, pass_node, ast.For) \
        is test_tree.body[0].body[1]

# Generated at 2022-06-23 23:50:06.970618
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-23 23:50:15.081758
# Unit test for function insert_at
def test_insert_at():
    class_node = ast.ClassDef()
    class_node.body = []
    class_node.decorator_list()
    list_of_nodes = [ast.Expr(), ast.Expr(), ast.Expr()]
    insert_at(1, class_node, list_of_nodes)
    assert class_node.body[1] == list_of_nodes[0]
    assert class_node.body[2] == list_of_nodes[1]
    assert class_node.body[3] == list_of_nodes[2]

# Generated at 2022-06-23 23:50:15.883311
# Unit test for function insert_at
def test_insert_at():
    pass


# Generated at 2022-06-23 23:50:26.876855
# Unit test for function insert_at
def test_insert_at():
    import inspect
    import typed_ast.ast3 as ast
    source = inspect.getsource(test_insert_at).replace('\n', '')
    source = source.replace(';', '\n')
    source = source.split('\n')
    source = '\n'.join(source[1:-1])
    tree = ast.parse(source)
    parent = get_closest_parent_of(tree, ast.literal_eval(source.split('=')[0]), ast.Assign)
    target = ast.parse('print("abc")').body[0]
    insert_at(0, parent, target)
    assert ast.dump(tree) == ast.dump(ast.parse("""
a = 'b'
print("abc")
a = 'c'"""))


# Generated at 2022-06-23 23:50:36.171386
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Set up the tree
    module = ast.Module()
    func_def = ast.FunctionDef(name='test', args=ast.arguments(args=[], defaults=[],
                                                               vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None,
                                                               kwargannotation=None, varargannotation=None))
    func_body = ast.Expr(value=ast.Num(n=1))
    func_def.body.append(func_body)
    module.body.append(func_def)

    # Test
    assert get_closest_parent_of(module, func_body, ast.FunctionDef) == func_def



# Generated at 2022-06-23 23:50:39.743371
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('1 + 1')
    parent = get_parent(tree, tree.body[0])
    insert_at(1, parent, ast.parse('1 + 1').body[0])

    assert len(parent.body) == 3
    assert isinstance(parent.body[1], ast.Expr)
    assert str(parent.body[1]) == '1 + 1'


# Generated at 2022-06-23 23:50:45.536038
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test1
    t1 = ast.parse('d=1\nprint(d)')
    n1 = get_non_exp_parent_and_index(t1, t1.body[1].value)
    assert n1[0] == t1.body[0]
    assert n1[1] == 1

    # Test2
    t2 = ast.parse('if True: \n print(1) \n elif False:\n print(2) \n '\
                   'else: print(3)')
    n2 = get_non_exp_parent_and_index(t2, t2.body[0].body[0].value)
    assert n2[0] == t2.body[0].body[0]
    assert n2[1] == 0

    # Test3

# Generated at 2022-06-23 23:50:52.997554
# Unit test for function replace_at
def test_replace_at():
    import astor
    class Module(ast.AST):
        _fields = ('body',)
        body = ()

    n1 = ast.Num(n=1)
    n2 = ast.Num(n=2)
    n3 = ast.Num(n=3)
    n4 = ast.Num(n=4)
    n5 = ast.Num(n=5)
    n6 = ast.Num(n=6)
    n7 = ast.Num(n=7)

    module = Module(body = (n1, n2, n3, n4, n5))
    assert(astor.to_source(module) == '1\n2\n3\n4\n5\n')


    replace_at(1, module, (n6, n7))

# Generated at 2022-06-23 23:50:53.850418
# Unit test for function get_parent

# Generated at 2022-06-23 23:50:58.461945
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    parent = ast.parse("if x == 1:\n    print('a')").body[0]
    stmt = parent.body[0]
    test_parent, test_index = get_non_exp_parent_and_index(parent, stmt)
    assert test_parent == parent
    assert test_index == 0

# Generated at 2022-06-23 23:51:04.727547
# Unit test for function replace_at
def test_replace_at():
    string_node = ast.Str("Test string")
    number_node = ast.Num(1)
    expression_node = ast.Expr(value=number_node)
    statement_node = ast.Assign()
    list_node = ast.List(elts=[string_node])

    root = ast.Module(body=[statement_node])

    assert root.body[0] is statement_node
    assert isinstance(statement_node, ast.Assign)

    replace_at(0, root, expression_node)
    assert root.body[0] is expression_node
    assert isinstance(expression_node, ast.Expr)
    assert isinstance(expression_node.value, ast.Num)
    assert expression_node.value.n == 1

    replace_at(0, root, list_node)
    assert root

# Generated at 2022-06-23 23:51:13.787091
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code_string = """if True:
        a = 4
        if True:
            pass
    """
    tree = ast.parse(code_string)

    if_body = None
    for node in tree.body:
        if type(node) is ast.If:
            if_body = node.body
            break

    if_node = tree.body[0]

    closest_parent = get_closest_parent_of(tree, if_body[0], ast.Module)
    assert type(closest_parent) is ast.Module

    closest_parent = get_closest_parent_of(tree, if_body[0], ast.If)
    assert type(closest_parent) is ast.If

    if_body_1 = if_body[1].body
    closest_parent = get_cl

# Generated at 2022-06-23 23:51:19.316287
# Unit test for function insert_at
def test_insert_at():
    node = ast.FunctionDef(name='test',
                           body=[ast.Pass()],
                           args=ast.arguments(args=[], vararg=None,
                                              kwonlyargs=[], kw_defaults=[], kwarg=None,
                                              defaults=[]))
    node2 = ast.Print('hello')
    node3 = ast.Print('hello2')
    insert_at(0, node, node2)
    insert_at(1, node, node3)
    assert node.body[0] == node2
    assert node.body[1] == node3


# Generated at 2022-06-23 23:51:27.835146
# Unit test for function replace_at
def test_replace_at():
    import sys
    from . import parser

    source = '''
    def f():
        a = 3
        b = 4
        c = a + b
        return c
    '''
    module = parser.parse(source, filename='<string>', mode='exec')
    tree = module.body[0]
    replace_at(1, tree, parser.parse('pass', mode='exec') )  # type: ignore
    #print(module)
    print(ast.dump(module))

# Generated at 2022-06-23 23:51:28.620439
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:51:31.233551
# Unit test for function find
def test_find():
    tree = ast.parse("""
    x = 42
    y = 'answer'
    """)
    nodes = find(tree, ast.Assign)
    assert len(nodes) == 2



# Generated at 2022-06-23 23:51:38.687031
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """
    Testing for get_non_exp_parent_and_index function.
    """
    code = "list[0] + 1"
    tree = ast.parse(code)
    #Build parents
    _build_parents(tree)
    parent_node, index = get_non_exp_parent_and_index(tree, tree.body[0].value)
    assert isinstance(parent_node, ast.Module) and index == 0

# Generated at 2022-06-23 23:51:39.236850
# Unit test for function insert_at
def test_insert_at():
    pass

# Generated at 2022-06-23 23:51:47.838274
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('[a for b in c]')

    parent_1, index_1 = get_non_exp_parent_and_index(tree, tree.body[0])
    assert isinstance(parent_1, ast.Module)
    assert index_1 == 0

    parent_2, index_2 = get_non_exp_parent_and_index(tree, tree.body[0].value)
    assert isinstance(parent_2, ast.Module)
    assert index_2 == 0

    parent_3, index_3 = get_non_exp_parent_and_index(tree,
                                                     tree.body[0].value.generators[0])
    assert isinstance(parent_3, ast.Module)
    assert index_3 == 0

    parent_4, index_4 = get_non_exp

# Generated at 2022-06-23 23:51:53.854158
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test for function get_non_exp_parent_and_index."""
    ast_node = ast.parse("""
    if True:
        if True:
            print(2)
    """)
    assert get_non_exp_parent_and_index(ast_node, ast_node.body[0])[0] \
        == ast_node
    assert get_non_exp_parent_and_index(ast_node, ast_node.body[0].body[0])[0] \
        == ast_node.body[0]



# Generated at 2022-06-23 23:52:01.656225
# Unit test for function replace_at
def test_replace_at():
    """
    Test function replace_at
    """
    class BodyStub(ast.AST):
        body = []

    ast_node = ast.Name(id='test', ctx=ast.Load())
    ast_nodes = [ast_node]
    body_stub = BodyStub()
    replace_at(0, body_stub, ast_nodes)
    assert len(body_stub.body) == 1
    assert body_stub.body[0] == ast_node

# Generated at 2022-06-23 23:52:06.977566
# Unit test for function insert_at
def test_insert_at():
    node_insert = ast.parse('print(2+3)').body[0]
    node_parent = ast.Module([])
    insert_at(0, node_parent, node_insert)
    assert ast.dump(node_parent) == ast.dump(ast.parse('print(2+3)'))

# Generated at 2022-06-23 23:52:12.655975
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('(1 + 2) * (3 + 4)')
    target = ast.Add(ast.Num(1), ast.Num(2))
    parent, index = get_non_exp_parent_and_index(tree, target)

    assert(isinstance(parent, ast.BinOp) and index == 0)



# Generated at 2022-06-23 23:52:21.903479
# Unit test for function insert_at
def test_insert_at():
    import unittest
    from typed_ast import ast3 as ast

    class TestFunctions(unittest.TestCase):
        def test_insert_at(self):
            tree = ast.parse('a = 5\nb = 10')
            exp = ast.Expression(ast.Name(id='a', ctx=ast.Load()))
            exp2 = ast.Expression(ast.Name(id='b', ctx=ast.Load()))
            exp3 = ast.Expression(ast.Name(id='c', ctx=ast.Load()))
            exp4 = ast.Expression(ast.Name(id='d', ctx=ast.Load()))
            exp5 = ast.Expression(ast.Name(id='e', ctx=ast.Load()))


# Generated at 2022-06-23 23:52:32.358942
# Unit test for function replace_at
def test_replace_at():
    class TestClass(object):
        def __init__(self):
            self.body = []
            self.body.append(1)
            self.body.append(2)
            self.body.append(3)

    class TestReplace(object):
        def __init__(self):
            pass

    test_class = TestClass()
    test_replace = TestReplace()
    test_replace.test = 5
    replace_at(1, test_class, test_replace)
    assert test_class.body == [1, test_replace, 3]
    test_replace.test = 6
    replace_at(1, test_class, test_replace)
    assert test_class.body == [1, test_replace, 3]

# Generated at 2022-06-23 23:52:40.009525
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_tree = ast.parse("""if True:
                            x = 1 + 2
                            y = [1, 2]
                            """)
    assert get_non_exp_parent_and_index(ast_tree, ast_tree.body[0]) == \
        (ast_tree, 0)
    assert get_non_exp_parent_and_index(ast_tree, ast_tree.body[0].body[0]) == \
        (ast_tree.body[0], 0)
    assert get_non_exp_parent_and_index(ast_tree, ast_tree.body[0].body[1]) == \
        (ast_tree.body[0], 1)

# Generated at 2022-06-23 23:52:41.131020
# Unit test for function insert_at

# Generated at 2022-06-23 23:52:43.788453
# Unit test for function find
def test_find():
    assert list(find(ast.parse('x + 2'), ast.Name)) == [ast.parse('x').body[0].value]



# Generated at 2022-06-23 23:52:46.546781
# Unit test for function get_parent
def test_get_parent():
    assert get_parent(
        ast.parse('a = 1'),
        ast.parse('a = 1').body[0].value
    ) == ast.parse('a = 1').body[0]



# Generated at 2022-06-23 23:52:55.820533
# Unit test for function find
def test_find():
    """Unit test for function find"""
    from ..visitors import finder_visitor
    from .generator import generate
    from .compare import compare
    import os

    for dir_name, subdir_list, file_list in os.walk("./tests/output/ast"):
        for file in file_list:
            with open(dir_name + "/" + file) as f:
                out_tree = ast.parse(f.read())
                f.close()

            with open(dir_name + '/' + file, 'r') as f:
                in_tree = ast.parse(f.read())
                f.close()

            # Test all decorators
            for deco in find(in_tree, ast.Decorator):
                if isinstance(deco.func, ast.FunctionDef):
                    type