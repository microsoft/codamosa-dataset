

# Generated at 2022-06-23 23:43:01.349394
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse(
        "import a\n"
        "a=1\n"
        "a=2\n"
    )
    parent = get_parent(tree, tree.body[1])
    assert len(parent.body) == 2
    insert_at(0, parent, ast.parse("a = 3\n").body[0])
    assert len(parent.body) == 3
    assert parent.body[0].value.n == 3
    assert parent.body[2].value.n == 2
    insert_at(2, parent, ast.parse("a = 4\n").body[0])
    assert parent.body[3].value.n == 4

# Generated at 2022-06-23 23:43:05.856133
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    class C:
        def f(self):
            print('hello')
    """)
    print_node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, print_node)
    assert index == 0
    assert isinstance(parent, ast.FunctionDef)


# Generated at 2022-06-23 23:43:09.187163
# Unit test for function find
def test_find():
    exp = ast.parse('exp1 = a + b')
    v1 = find(exp, ast.Tuple)
    print(list(v1))



# Generated at 2022-06-23 23:43:15.972593
# Unit test for function insert_at
def test_insert_at():
    import astor

    p = ast.parse("""\
a = 3
b = 4
c = 5

""")

    for n in find(p, ast.Assign):
        insert_at(0, get_parent(p, n),
                  ast.parse("""
print(1)
print(2)
print(3)
""").body)

    print(astor.to_source(p))



# Generated at 2022-06-23 23:43:21.250633
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('x = 1')
    body_node = tree.body[0]
    ass_node = body_node.value
    expr_node = ass_node.value
    number_node = expr_node.n
    assert get_non_exp_parent_and_index(tree, number_node) == (tree, 0)


# Generated at 2022-06-23 23:43:26.575294
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_ast = ast.parse("""
        import sys

        def test():
            print(sys.argv)
    """)

    assert isinstance(
        get_closest_parent_of(test_ast, test_ast.body[1].body[0].value, ast.FunctionDef),
        ast.FunctionDef
    )

# Generated at 2022-06-23 23:43:30.922242
# Unit test for function insert_at
def test_insert_at():
    root = ast.parse('a=1')  # type: ignore
    node = ast.parse('b=2')  # type: ignore
    insert_at(1, root.body[0], node)  # type: ignore
    assert root == ast.parse('a=1\nb=2')  # type: ignore



# Generated at 2022-06-23 23:43:37.764294
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    exp = ast.parse('a = 1').body[0]
    module = exp.value  # type: ignore
    parent, index = get_non_exp_parent_and_index(module, exp)
    assert module is parent
    assert index == 0
    with pytest.raises(NodeNotFound):
        get_non_exp_parent_and_index(ast.parse('a = 1'), ast.parse('a = 1'))


# Generated at 2022-06-23 23:43:38.364704
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-23 23:43:45.943970
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

    code = """
    def foo(arg_b, arg_c=None):
      if not arg_b:
        print('b')
        return

      if arg_c:
        print('c')
        return
    """

    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0]

    if_ = get_closest_parent_of(tree, node, ast.If)
    assert if_.test.id == 'not arg_b', astor.to_source(if_)

# Generated at 2022-06-23 23:43:53.672194
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:44:01.508323
# Unit test for function get_parent
def test_get_parent():
    example_code = '''a = 1\ndef b():\n    1'''

    # Build AST of code
    tree = ast.parse(example_code, mode='exec')
    # List all nodes in AST
    nodes = list(ast.walk(tree))
    # Get all parent nodes
    parent_nodes = [get_parent(tree, node) for node in nodes]
    # Expected results
    expected = [None, tree, tree, nodes[1], nodes[1], nodes[2]]
    # Check if test passed
    assert parent_nodes == expected


# Generated at 2022-06-23 23:44:02.475853
# Unit test for function insert_at
def test_insert_at():
    import astor


# Generated at 2022-06-23 23:44:06.686018
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module = ast.parse('def fun():\n    a')
    module.body[0].body[0].value.args[0].id = "b"
    parent = get_closest_parent_of(module, module.body[0].body[0].value.args[0], ast.FunctionDef)
    assert parent.name == "fun"


# Generated at 2022-06-23 23:44:09.216465
# Unit test for function find
def test_find():
    import inspect
    frame = inspect.currentframe()
    func_tree = ast.parse(inspect.getsource(frame))
    nodes = find(func_tree, ast.Name)
    print(nodes)

# Generated at 2022-06-23 23:44:20.581273
# Unit test for function insert_at
def test_insert_at():
    test_assign = ast.Assign()
    test_assign.targets = [ast.Name('c', ast.Store())]
    test_assign.value = ast.Num(1)

    example = ast.parse(
        'def foo():\n'
        '    a = 1\n'
        '    return a\n'
        '\n'
        'b = foo()\n'
        'd = 2'
    ).body

    def_func = example[0]
    call_to_foo = example[1].value
    num_2 = example[2].value

    # Inserting at the end
    insert_at(3, def_func, test_assign)
    assert def_func.body[3].targets[0].id == 'c'

    # Inserting at

# Generated at 2022-06-23 23:44:26.060121
# Unit test for function find
def test_find():
    code = '''
    def a():
        print(1 + 1)
    '''
    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 1

    # Check that it doesn't break with empty tree
    assert len(list(find(ast.Module([]), ast.FunctionDef))) == 0

# Generated at 2022-06-23 23:44:32.780682
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a+b+c')
    assert tree.body[0].value.right.value == 'b'
    replace_at(1, tree.body[0].value, ast.parse('d').body[0].value)
    assert tree.body[0].value.right.value == 'd'
    assert tree.body[0].value.left.value == 'a'
    assert isinstance(tree.body[0].value.right, ast.Name)
    assert isinstance(tree.body[0].value.left, ast.Name)



# Generated at 2022-06-23 23:44:33.975846
# Unit test for function get_parent
def test_get_parent():
    """Test get_parent."""
    global _parents

# Generated at 2022-06-23 23:44:40.952703
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('if True: 1 + 2')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    replace_at(index, parent, ast.Expr(ast.Num(2)))
    assert ast.dump(tree) == 'Module(body=[If(test=Name(id=\'True\', ctx=Load()), body=[Expr(value=Num(n=2))], orelse=[])])'



# Generated at 2022-06-23 23:44:49.349647
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
if True:
    if True:
        x = 1
''')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert(isinstance(parent, ast.If))
    assert(index == 0)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert(isinstance(parent, ast.If))
    assert(index == 0)

test_get_non_exp_parent_and_index()

# Generated at 2022-06-23 23:44:51.268048
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Setup
    parent = ast.Module([])
    assert get_closest_parent_of(parent, parent, type(parent)) == parent

# Generated at 2022-06-23 23:44:57.958174
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:45:04.968014
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    if __name__ == '__main__':
        def myfun():
            return 5
    """)
    assert isinstance(get_closest_parent_of(tree, list(find(tree, ast.FunctionDef))[0], ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, list(find(tree, ast.Name))[0], ast.If), ast.If)


# Generated at 2022-06-23 23:45:10.668462
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    tree = ast.parse('if (a):\n  a.b()\n  a.c()')
    if_ast = tree.body[0]
    b_ast = if_ast.body[0]
    assert get_non_exp_parent_and_index(tree, b_ast) == (if_ast, 0)
    c_ast = if_ast.body[1]
    assert get_non_exp_parent_and_index(tree, c_ast) == (if_ast, 1)



# Generated at 2022-06-23 23:45:20.856342
# Unit test for function get_parent
def test_get_parent():
    class A(ast.AST):
        pass
    class B(ast.AST):
        pass
    class C(ast.AST):
        pass
    class D(ast.AST):
        pass
    class E(ast.AST):
        pass

    a = A()
    b = B()
    c = C()
    d = D()
    e = E()

    a.children = [b, c]
    b.children = [d]
    c.children = [e]

    _build_parents(a)

    assert(_parents[b] == a)
    assert(_parents[c] == a)
    assert(_parents[d] == b)
    assert(_parents[e] == c)


# Generated at 2022-06-23 23:45:23.774382
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Unit test for function get_closest_parent_of"""
    import inspect
    frame = inspect.currentframe()
    tree = ast.parse(inspect.getsource(frame.f_code))
    parent = frame.f_locals.get('tree')
    node = frame.f_locals.get('parent')
    assert get_closest_parent_of(tree, node, ast.Module) == tree

# Generated at 2022-06-23 23:45:24.350641
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:45:28.762170
# Unit test for function get_parent
def test_get_parent():
    """Test the get_parent function."""
    def _test(root: ast.AST, child: ast.AST,
              expected_parent: ast.AST):
        got_parent = get_parent(root, child)
        assert got_parent is expected_parent

    def _test_exception(root: ast.AST, child: ast.AST):
        try:
            get_parent(root, child)
            assert False
        except NodeNotFound:
            pass

    # simple test

# Generated at 2022-06-23 23:45:35.404113
# Unit test for function get_parent
def test_get_parent():
    # Create a simple ast tree
    node_child = ast.Expr(ast.BinOp(ast.Name('a', ast.Load()),
                                    ast.Add(),
                                    ast.Name('b', ast.Load())))
    node_parent = ast.Expr(node_child)
    node_grandparent = ast.FunctionDef(name='add',
                                       args=ast.arguments(),
                                       body=[node_parent],
                                       decorator_list=[])
    node_root = ast.Module([node_grandparent])

    # Testing get_parent
    print(get_parent(node_root, node_child) is node_parent)
    print(get_parent(node_root, node_parent) is node_grandparent)

# Generated at 2022-06-23 23:45:43.501828
# Unit test for function replace_at
def test_replace_at():
    function_def_node = ast.parse("def a():\n    b\nb\n").body[0]
    ast.fix_missing_locations(function_def_node)
    const_node = ast.parse("c").body[0]
    replace_at(0, function_def_node, const_node)
    assert ast.dump(function_def_node) == "FunctionDef(body=[Expr(value=Name(id='c', ctx=Load()))], decorator_list=[]," \
                                         "name='a', returns=None, type_comment=None)"

# Generated at 2022-06-23 23:45:47.843554
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    code = """
    def func():
        for i in range(4):
            i+=1
    """
    tree = ast.parse(code)
    node = tree.body[0] # function def
    parent = get_closest_parent_of(tree, node, ast.Module)
    assert isinstance(parent, ast.Module)
    assert parent == tree

# Generated at 2022-06-23 23:45:51.798274
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.Name("x")
    parent = ast.Assign(targets=[node])
    tree = ast.Module(body=[parent])
    finded_parent = get_closest_parent_of(tree, node, ast.Assign)



# Generated at 2022-06-23 23:45:56.516696
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('x = input()')
    print('-' * 32)
    print(astor.dump(tree))
    print('-' * 32)
    parent = get_parent(tree, tree.body[0].value)
    print(astor.dump(parent))
    print('-' * 32)
    print(type(parent))
    print(isinstance(parent, ast.Module))


# Generated at 2022-06-23 23:46:07.791333
# Unit test for function insert_at
def test_insert_at():
    parent = ast.Module()
    nodes = [ast.Expr(ast.Num(1)), ast.Expr(ast.Num(2))]
    insert_at(0, parent, nodes)

    assert parent == ast.Module(
        body=[
            ast.Expr(ast.Num(1)),
            ast.Expr(ast.Num(2))
        ]
    )

    insert_at(0, parent, ast.Expr(ast.Num(3)))

    assert parent == ast.Module(
        body=[
            ast.Expr(ast.Num(3)),
            ast.Expr(ast.Num(1)),
            ast.Expr(ast.Num(2))
        ]
    )


# Generated at 2022-06-23 23:46:08.444808
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:46:12.323218
# Unit test for function replace_at
def test_replace_at():
    # TODO: Assertions and test cases
    root = ast.parse('def test(x):\n    x + 1\n    print(x)')
    get_parent(root, root.body[0].body[0])
    print(find(root, ast.BinOp))
    replace_at(1, root.body[0],
               ast.parse('def test(x):\n    x + 1\n    print(x)').body[0].body[1])
    print(ast.dump(root))

# Generated at 2022-06-23 23:46:22.571321
# Unit test for function get_parent
def test_get_parent():
    """
    Test whether function get_parent gets the
    parent of a node in a tree correctly
    """
    tree = ast.parse('''
    def my_func(arg1, arg2):
        # This is a comment
        if arg1 > arg2:
            print(arg1)
        else:
            print(arg2)
''')

    # print(ast.dump(tree, include_attributes=True))
    assert get_parent(tree, tree).__class__ == ast.Module  # type: ignore
    assert get_parent(tree, tree.body[0]).__class__ == ast.Module  # type: ignore
    assert get_parent(tree, tree.body[0].body[0].value) \
           .__class__ == ast.IfExp  # type: ignore

# Generated at 2022-06-23 23:46:30.695338
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast
    test1 = ast.parse(
        """
        def outer():
            for i in ['x', 'y']:
                print(i)
        """
    )

    for_node = test1.body[0].body[0]

    function_def = get_closest_parent_of(test1, for_node, ast.FunctionDef)
    # Type: ast.FunctionDef

    assert function_def.name == 'outer'

    # Test for to see if TypeError is raised when no matching type is found
    with pytest.raises(AttributeError):
        get_closest_parent_of(test1, for_node, ast.If)

test_get_closest_parent_of()

# Generated at 2022-06-23 23:46:31.984895
# Unit test for function insert_at

# Generated at 2022-06-23 23:46:37.622657
# Unit test for function replace_at
def test_replace_at():
    ast_module = ast.parse('pass')
    body = ast_module.body
    assert(len(body) == 1)
    assert(isinstance(body[0], ast.Pass))

    replace_at(0, ast_module, [ast.Expr(value=ast.Constant(1))])
    assert(len(body) == 1)
    assert(isinstance(body[0], ast.Expr))

# Generated at 2022-06-23 23:46:43.914738
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = 'if True:\n    pass\n\nif True:\n    pass\nelse:\n    pass'
    tree = ast.parse(code)
    index = 1

# Generated at 2022-06-23 23:46:44.951167
# Unit test for function find

# Generated at 2022-06-23 23:46:53.305549
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """
    Test for the function get_non_exp_parent_and_index.
    It takes a module ast as input and tries to find the parent
    and index of ast.Expr node.
    """
    import astunparse

    module = astunparse.unparse(ast.parse("my_str = 'str'"))
    module = ast.parse(module)
    test_node = module.body[0].value
    
    # Since this is the only Expr node, the index should be 0
    parent, index = get_non_exp_parent_and_index(module, test_node)
    assert index == 0

# Generated at 2022-06-23 23:46:53.876748
# Unit test for function insert_at
def test_insert_at():
    pass

# Generated at 2022-06-23 23:46:55.295547
# Unit test for function insert_at
def test_insert_at():
    # Test empty list
    insert_at(0, ast.parse('[]'), ast.parse('[1]'))


# Generated at 2022-06-23 23:47:01.685271
# Unit test for function get_parent
def test_get_parent():
    # make tree
    msg = ast.Expr(
        value=ast.Constant(
            value="Hello, world!",
            kind=None
        )
    )
    prt = ast.Print(
        dest=None,
        values=[msg],
        nl=True
    )

    fun = ast.FunctionDef(
        name="printer",
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[prt],
        decorator_list=[],
        returns=None
    )
    mod = ast.Module(body=[fun])

    # Tests
    assert get_parent(mod, mod) == None
    assert get_parent

# Generated at 2022-06-23 23:47:03.826237
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index."""

# Generated at 2022-06-23 23:47:11.891594
# Unit test for function get_parent
def test_get_parent():
    assert ast.parse('a = 1').body[0] == get_parent(ast.parse('a = 1'),
                                                    ast.parse('a = 1').body[0].targets[0])
    assert ast.parse('a = 1').body[0] == get_parent(ast.parse('a = 1'),
                                                    ast.parse('a = 1').body[0].value)
    assert ast.parse('a = 1') == get_parent(ast.parse('a = 1'),
                                                    ast.parse('a = 1').body[0])

# Generated at 2022-06-23 23:47:13.466683
# Unit test for function get_parent
def test_get_parent():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:47:23.927026
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import sys
    module = ast.parse(
        """def test():
            if True:
                a = 2
                return 1
            else:
                b = 3
            return 2
        """)
    _build_parents(module)
    assert(get_closest_parent_of(module, module.body[0].body[0], ast.FunctionDef) == module.body[0])
    assert(get_closest_parent_of(module, module.body[0].body[0], ast.If) == module.body[0].body[0])

    fake_node = ast.If(
        test=ast.Num(1),
        body=[ast.Return(value=ast.Num(1))],
        orelse=[])
    module.body.append(fake_node)

# Generated at 2022-06-23 23:47:33.280992
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse( "import os\nfrom urllib.request import urlopen" )
    import_from = tree.body[1]
    import_os = tree.body[0]
    module_name = import_from.names[0]
    urlopen_name = import_from.names[1]
    parent, index = get_non_exp_parent_and_index(tree, import_os)
    assert type(parent).__name__ == 'Module'
    assert index == 0
    parent, index = get_non_exp_parent_and_index(tree, import_from)
    assert type(parent).__name__ == 'Module'
    assert index == 1
    parent, index = get_non_exp_parent_and_index(tree, module_name)

# Generated at 2022-06-23 23:47:34.430862
# Unit test for function replace_at
def test_replace_at():
    import astor

# Generated at 2022-06-23 23:47:36.230317
# Unit test for function find

# Generated at 2022-06-23 23:47:40.529803
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # noqa
    tree = ast.parse('x = 3\nx * y * z * x * y * w')

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].value)

    assert parent == tree.body[1]
    assert index == 2



# Generated at 2022-06-23 23:47:44.368309
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("from a import b\n")
    node = tree.body[0]
    assert get_parent(tree, node) == tree


if __name__ == "__main__":
    test_get_parent()

# Generated at 2022-06-23 23:47:51.616459
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('from something.here import you')
    assert isinstance(get_closest_parent_of(tree, tree.body[0].targets[0], ast.ImportFrom), ast.ImportFrom)
    assert hasattr(get_closest_parent_of(tree, tree.body[0].targets[0], ast.ImportFrom), 'module')
    assert not hasattr(get_closest_parent_of(tree, tree.body[0].targets[0], ast.ImportFrom), 'body')



# Generated at 2022-06-23 23:47:57.091697
# Unit test for function find
def test_find():
    assert list(find(ast.parse('var = 1\nvar2 = 2', '<>'), ast.Assign)) \
        == [ast.parse('var = 1', '<>').body[0]]
    assert list(find(ast.parse('1\n2', '<>'), ast.Name)) \
        == [ast.parse('1', '<>').body[0]]
    assert list(find(ast.parse('1\n2', '<>'), ast.Expression)) \
        == [ast.parse('1', '<>').body[0],
            ast.parse('2', '<>').body[0]]



# Generated at 2022-06-23 23:48:02.562907
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    global _parents
    _parents = WeakKeyDictionary()
    source = """
    def hi():
        return 12
    """
    tree = ast.parse(source)
    obj = tree.body[0]
    assert(obj == get_closest_parent_of(tree, obj.returns, ast.FunctionDef))

# Generated at 2022-06-23 23:48:08.625037
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('''
    def f(a):
        b = a
    ''')

    def_ = tree.body[0]
    assign = def_.body[0]

    assert assign.value.id == 'a'
    insert_at(0, def_.body,
              ast.parse('''a = 3''').body[0])
    assert assign.value.value.n == 3

# Generated at 2022-06-23 23:48:19.639806
# Unit test for function find
def test_find():
    node = ast.parse('@generator\ndef spam(a, b):\n    a * b * (a + b)')
    func = get_closest_parent_of(node, node.body[0].body[0], ast.FunctionDef)

    assert func == node.body[0]
    assert list(find(node, ast.Name)) == [func.args.args[0],
                                          func.args.args[1],
                                          node.body[0].body[0].value.left,
                                          node.body[0].body[0].value.right,
                                          node.body[0].body[0].value.right.left,
                                          node.body[0].body[0].value.right.right]

# Generated at 2022-06-23 23:48:25.901784
# Unit test for function replace_at
def test_replace_at():
    import unittest
    import astor

    class TestCase(unittest.TestCase):
        def test_replace_at(self):
            code = astor.parse_file(__file__, mode="exec")
            body = code.body
            test_cases = body[body.index(self) + 1].body[1:]
            for i, test in enumerate(test_cases):
                if i % 2 == 0:
                    continue
                parent = get_closest_parent_of(code, test, ast.Module)
                # Replace printed string with printed number
                replace_at(i, parent, ast.Print(dest=None, values=[ast.Num(n=0)],
                                                nl=True))

# Generated at 2022-06-23 23:48:37.869643
# Unit test for function find
def test_find():
    from typing import List
    from pike.tests import test_ast as asttest
    from pike.tests import test_ast_builder as builder

    for test in asttest.test_list:
        m = builder.build_module(test.func_code)

        for type_, value in test.expected_nodes_types.items():
            if isinstance(value, List):
                nodes = list(find(m, type_))
                assert type(nodes) is list, 'Expected list'
                assert nodes == value, 'Expected {} instead {}'.format(value, nodes)
            else:
                nodes = list(find(m, type_))
                assert len(nodes) == 1, 'Expected 1 node with type {} instead {}'.format(type_, len(nodes))

# Generated at 2022-06-23 23:48:48.336416
# Unit test for function insert_at
def test_insert_at():
    import sys
    import unittest
    source = \
        """
        def foobar():
            a = 6
            a += 3
        """
    def check_insert(source, index, insert, expected):
        tree = ast.parse(source)
        parent = get_parent(tree, get_closest_parent_of(tree, tree, ast.FunctionDef))
        insert_at(index, parent, insert)
        self = unittest.TestCase('__init__')
        self.assertEqual(ast.dump(tree, False), expected)

    insert_node = ast.parse('''
        def hooray():
            pass
    ''').body[0]

# Generated at 2022-06-23 23:48:55.205674
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('def f(): if False: pass; return 1')
    func = get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                 ast.FunctionDef)
    ifs = func.body[0]
    insert_at(0, ifs, ast.Expr(value=ast.Str('hello')))
    assert tree_to_src(tree) == 'def f():\n    if False:\n        pass;\n    return 1'


# Generated at 2022-06-23 23:49:04.573060
# Unit test for function find
def test_find():
    example_code = '''
    for x in [1,2,3]:
        for y in [1,2]:
            x = 5
            print(x)
    '''

    tree = ast.parse(example_code)
    assert list(find(tree, ast.FunctionDef)) == []
    assert list(find(tree, ast.Name)) == [ast.Name(id='x', ctx=ast.Store()),
                                          ast.Name(id='y', ctx=ast.Store()),
                                          ast.Name(id='x', ctx=ast.Load()),
                                          ast.Name(id='print', ctx=ast.Load())]
    assert [n.value.value for n in find(tree, ast.Num)] == [1, 2, 3, 1, 2]

# Unit

# Generated at 2022-06-23 23:49:05.758155
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + 2')
    assert 1 == len(list(find(tree, ast.BinOp)))


# Generated at 2022-06-23 23:49:13.955566
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""\
    def func(a):
        b = a + 1
        return b
    """)

    # test that built in functions works
    assert ast.walk(tree) == ast.walk(tree)

    # test that _build_parents works
    assert _parents[ast.parse("a")] == ast.parse("a")

    # test that parents works
    assert get_parent(tree, ast.parse("a")) == ast.parse("a")

    # test the function multiple times with different trees and nodes
    tree_one, node_one = ast.parse("2 + 3"), ast.parse("3")
    assert get_parent(tree_one, node_one) == tree_one

    tree_two, node_two = ast.parse("4 + 5"), ast.parse("5")
    assert get

# Generated at 2022-06-23 23:49:23.645971
# Unit test for function get_parent
def test_get_parent():
    s = ast.parse('a = 1')
    s.body[0].value.n = 2

    assert isinstance(get_parent(s, s.body[0]), ast.Module)
    assert get_parent(s, s.body[0]).body.index(s.body[0]) == 0
    assert get_parent(s, s.body[0].value) is s.body[0]
    assert get_non_exp_parent_and_index(s, s.body[0]) == (s, 0)
    assert get_non_exp_parent_and_index(s, s.body[0].value) == (s, 0)

# Generated at 2022-06-23 23:49:35.397051
# Unit test for function replace_at
def test_replace_at():
    import unittest

    class ReplaceAtTest(unittest.TestCase):
        """Test case for replace_at function."""

        def test_replace_at_add_stmt(self):
            """Test if replaces element in body and adds statement"""
            from typed_ast import ast3 as ast

            p = ast.parse('def func():\n  pass\n  pass\n')
            func = p.body[0]
            replace_at(0, func, ast.Pass())
            self.assertEqual('def func():\n  pass\n  pass\n  pass\n',
                             ast.unparse(p).strip())

        def test_replace_at_modify_stmt(self):
            """Test if replaces element in body and modifies statement"""
            from typed_ast import ast3 as ast

           

# Generated at 2022-06-23 23:49:41.741369
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def f(x, y):\n   print(x, y)')
    node = tree.body[0]
    assert get_parent(tree, node, rebuild=False) == tree
    _parents.pop(node)
    assert get_parent(tree, node, rebuild=True) == tree
    assert get_parent(tree, node) == tree
    try:
        get_parent(tree, None)
    except NodeNotFound:
        pass
    else:
        assert 1 == 0



# Generated at 2022-06-23 23:49:52.857613
# Unit test for function insert_at
def test_insert_at():
    # type: () -> None
    import astor
    tree = ast.parse('print("Hello, World!")')
    print(astor.to_source(tree))
    print(get_closest_parent_of(tree, tree.body[0].value, ast.Module))
    tree = ast.parse('a = 1; b = 2; c = 3')
    print(astor.to_source(tree))
    expr = ast.parse('a = 1; b = 2; c = 3').body[-1]
    print(expr)
    print(expr.value)
    print(expr.value.body)
    assert expr.value.body[0].value.n == 2
    insert_at(1, expr.value, ast.parse('b = 4').body[0])
    assert expr.value.body

# Generated at 2022-06-23 23:49:53.696060
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:49:56.741578
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:50:03.713606
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1 + 2 + 3')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].value)
    a = ast.parse('a+3').body[0].value
    b = ast.parse('1+2+2').body[0].value
    replace_at(index, parent, a)
    replace_at(index, parent, b)
    print(ast.dump(tree))

# Generated at 2022-06-23 23:50:12.400439
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(ast.parse('a + b'), ast.parse('a').body[0])\
        == (ast.parse('a + b'), 0)
    assert get_non_exp_parent_and_index(ast.parse('[a, b, (a + b)]'), ast.parse('(a + b)').body[0])\
        == (ast.parse('[a, b, (a + b)]'), 2)
    assert get_non_exp_parent_and_index(ast.parse('[(0, 1)]'), ast.parse('(0, 1)').body[0])\
        == (ast.parse('[(0, 1)]'), 0)


# Generated at 2022-06-23 23:50:17.617125
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def x(y): return y')
    assert get_non_exp_parent_and_index(tree, tree.body[0].returns) == (tree, 0)

# Generated at 2022-06-23 23:50:28.545566
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # pragma: no cover
    import astor  # type: ignore

    # parent: module
    # index: 0
    tree = ast.parse('def foo(x):\n    return x + x')
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.Module)
    assert index == 0

    # parent: FunctionDef
    # index: 1
    tree = ast.parse('def foo(x):\n    return x + x')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

    # parent: Assign
    # index

# Generated at 2022-06-23 23:50:36.107978
# Unit test for function insert_at
def test_insert_at():
    add_node = ast.parse("a + b", mode="eval")
    string_node = ast.parse("'string'", mode="eval")
    concat_node = ast.parse("str(a) + str(b)", mode="eval")
    insert_at(1, concat_node, string_node)
    assert len(concat_node.body.args) == 3
    assert len(concat_node.body.args[1].args) == 1
    assert concat_node.body.args[1].func.id == "str"
    assert concat_node.body.args[1].args[0].s == "string"


# Generated at 2022-06-23 23:50:40.395971
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(
        ast.parse('def a(b, c):\n\tfor x in b:\n\t\ty = c\n\t\tz = x\n'),
        ast.parse('def a(b, c):\n\tfor x in b:\n\t\ty = c\n\t\tz = x\n').body[0].body[0].body[1]
    ) == (
        ast.parse('def a(b, c):\n\tfor x in b:\n\t\ty = c\n\t\tz = x\n'),
        2
    )

# Generated at 2022-06-23 23:50:51.226140
# Unit test for function replace_at

# Generated at 2022-06-23 23:50:58.705256
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('1 + 2 - 3')
    replace_at(0, get_parent(tree, tree.body[0]), ast.parse('1').body[0])
    replace_at(1, get_parent(tree, tree.body[0]), ast.parse('2').body[0])
    replace_at(2, get_parent(tree, tree.body[0]), ast.parse('3').body[0])
    assert ast.dump(tree) == 'Module(body=[Expr(value=BinOp(left=Num(n=1), op=Add(), right=Num(n=2)))])'

# Generated at 2022-06-23 23:51:03.846330
# Unit test for function get_parent
def test_get_parent():
    """Unit test case for get_parent function."""
    tree_str = """
    class A():
        def __init__(self):
            global a
            a = 1
            global b
            b = 2
            global c
            c = 3
    """

    class_node = ast.parse(tree_str)

    node = class_node.body[0].body[0]  # class A
    parent = get_parent(class_node, node)
    assert(class_node == parent)

    node = class_node.body[0].body[0].body[0]  # global a
    parent = get_parent(class_node, node)
    assert(class_node.body[0] == parent)


# Generated at 2022-06-23 23:51:10.842111
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('for i in range(3): print(i)')
    loop = list(find(tree, ast.For))[0]
    print(loop)
    print(ast.dump(loop))

    i = ast.Name(id='i', ctx=ast.Store())
    new_loop = ast.For(i, ast.Call(func=ast.Name(id='foo', ctx=ast.Load()),
                                   args=[], keywords=[]), [], [])
    replace_at(0, loop, new_loop)
    print(loop)
    print(ast.dump(loop))


if __name__ == '__main__':
    test_replace_at()

# Generated at 2022-06-23 23:51:19.748278
# Unit test for function replace_at
def test_replace_at():
    import astor
    src = """
    def func():
        print(1)
        print(2)
    """

    tree = ast.parse(src)
    print(astor.dump_tree(tree))

    func_node = get_non_exp_parent_and_index(tree, tree.body[0].body[-1])[0]
    print(func_node)

    print(astor.dump_tree(func_node))

    print('\n')
    print('--- test_replace_at ---')
    print('\n')
    src = """
    def func():
        print(1)
        print(2)
    """

    tree = ast.parse(src)


# Generated at 2022-06-23 23:51:22.888500
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("print(5)")
    tree.body[0].value = ast.Num(n=4)
    replace_at(0, tree, tree.body[0].value)
    assert tree.body[0].value.n == 4

# Generated at 2022-06-23 23:51:29.888216
# Unit test for function find
def test_find():  # pylint: disable=invalid-name
    tree = ast.parse("""
    def func():
        var = 5
        return var

    for i in func():
        print(i)
    """)
    f_nodes = [node for node in find(tree, ast.FunctionDef)]
    print(f_nodes)


# Generated at 2022-06-23 23:51:42.206461
# Unit test for function replace_at
def test_replace_at():  # pragma: no cover
    from pprint import pprint

    tree = ast.parse('a = b\nc = d\n')
    pprint(tree)
    replace_at(1, tree, ast.Expr(ast.BinOp(ast.Name('a', ast.Load()),
                                           ast.Name('b', ast.Load()),
                                           ast.Add())))
    pprint(tree)

    tree = ast.parse('a = b\n')
    pprint(tree)
    replace_at(0, tree, ast.Expr(ast.BinOp(ast.Name('a', ast.Load()),
                                           ast.Name('b', ast.Load()),
                                           ast.Add())))
    pprint(tree)

# Generated at 2022-06-23 23:51:45.483495
# Unit test for function get_parent
def test_get_parent():
    root = ast.parse('def func():\n    pass')
    global _parents
    _parents = WeakKeyDictionary()
    parent = get_parent(root, root.body[0].body[0])
    assert parent == root.body[0]



# Generated at 2022-06-23 23:51:54.288271
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    target_code = """
    fn = lambda: print(
        'The quick brown fox jumps over the lazy dog.'
    )
    """

    tree = ast.parse(target_code)

    str_node = find(tree, ast.Str).__next__()
    while True:
        parent, index = get_non_exp_parent_and_index(tree, str_node)
        assert isinstance(parent, ast.Expr)
        if hasattr(parent, 'lineno'):
            break
        else:
            str_node = parent

    # There should be only one Expr node in the tree
    assert parent.lineno == 3
    assert index == 0



# Generated at 2022-06-23 23:52:04.308991
# Unit test for function insert_at
def test_insert_at():
    import _ast as libast  # type: ignore
    module = libast.parse("""def foo():
        a = 5
        b = 7
        a += 6""")
    fun = module.body[0]
    ins_node_after = fun.body[1]
    expected_result = libast.parse("""def foo():
        a = 5
        b = 7
        a += 6
        c = 3
        d = 4""")
    c = libast.Assign(targets=[libast.Name(id='c', ctx=libast.Store())],
                      value=libast.Num(n=3))
    d = libast.Assign(targets=[libast.Name(id='d', ctx=libast.Store())],
                      value=libast.Num(n=4))


# Generated at 2022-06-23 23:52:08.012846
# Unit test for function insert_at
def test_insert_at():
    import astor
    module = ast.parse(textwrap.dedent('''\
    def foo():
        pass
    '''))

    parent = module.body[0]
    insert_at(0, parent, ast.Name('x', ast.Store()))

# Generated at 2022-06-23 23:52:18.924038
# Unit test for function find
def test_find():
    # Test find for a standard case
    class TestFindTreeAlreadyBuilt(ast.AST):
        _fields = ('body',)
        _parent = 'body'
        _nodes = ['body']
        _attributes = ('body',)

    class TestFindNodeAlreadyBuilt(ast.AST):
        _fields = ()
        _parent = 'body'
        _nodes = ()
        _attributes = ()

    tree = TestFindTreeAlreadyBuilt(
        [TestFindNodeAlreadyBuilt() for _ in range(10)]
    )

    _build_parents(tree)

    assert len(list(find(tree, TestFindTreeAlreadyBuilt))) == 1
    assert len(list(find(tree, TestFindNodeAlreadyBuilt))) == 10

# Generated at 2022-06-23 23:52:19.802860
# Unit test for function find

# Generated at 2022-06-23 23:52:24.894359
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        """for i in range(10):
                pass"""
    )
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert index == 0
    assert isinstance(parent, ast.For)

# Generated at 2022-06-23 23:52:29.588981
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    root = ast.parse('def a():\n  aa = 1 + 1')
    func = root.body[0]
    expr = func.body[0].value
    assert get_non_exp_parent_and_index(root, expr)[0] == func
    assert get_non_exp_parent_and_index(root, expr)[1] == 0

    try:
        get_non_exp_parent_and_index(root, root)
        return False
    except NodeNotFound:
        return True


# Generated at 2022-06-23 23:52:37.341642
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # type: () -> None
    code = """
print(1)
print(2)
print(3)
"""
    tree = ast.parse(code)
    node = tree.body[2]

    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 2



# Generated at 2022-06-23 23:52:41.392717
# Unit test for function get_parent
def test_get_parent():
    source = """
    def test(a):
        b = a
        return b
    """
    tree = ast.parse(source)
    _build_parents(tree)
    assert get_parent(tree, tree.body[0]).body is tree.body
    assert get_parent(tree, tree.body[0].body[0]).body is tree.body[0].body
    assert get_parent(tree, tree.body[0].body[1]).body is tree.body[0].body
    assert get_parent(tree, tree.body[0].body[0].value.args[0]) is tree.body[0]

# Generated at 2022-06-23 23:52:45.779859
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('def foo(x):\n  y = x * x\n  y * x')
    if_node = get_closest_parent_of(tree,
                                    find(tree, ast.Name).__next__(),
                                    ast.If)

    # assert 1 == 1

# Generated at 2022-06-23 23:52:49.947274
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:52:59.142306
# Unit test for function replace_at
def test_replace_at():
    parent = ast.Module([ast.Expr(ast.Call(
        ast.Name('func'), [ast.Name('x')], [], None, None))])
    replace_at(0, parent, [ast.Expr(ast.Call(
        ast.Name('func2'), [ast.Name('x')], [], None, None)),
        ast.Expr(ast.Call(
        ast.Name('func3'), [ast.Name('x')], [], None, None))])
    lines = ast.dump(parent).split('\n')
    assert lines[2] == "func2(x),"
    assert lines[3] == "func3(x)]"

test_replace_at()