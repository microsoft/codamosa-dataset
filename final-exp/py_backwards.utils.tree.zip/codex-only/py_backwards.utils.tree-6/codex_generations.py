

# Generated at 2022-06-23 23:42:54.343236
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:43:03.462065
# Unit test for function insert_at
def test_insert_at():
    import astor

    class TestNode(ast.AST):
        _fields = ()

    parent = TestNode()
    parent.body = [None]
    
    insert_at(0, parent, TestNode())
    assert astor.to_source(parent) == 'TestNode()' or astor.to_source(parent) == 'test_ast_tools.TestNode()'

    insert_at(0, parent, [TestNode(), TestNode()])
    assert astor.to_source(parent) == 'TestNode(TestNode(), TestNode())' or astor.to_source(parent) == 'test_ast_tools.TestNode(test_ast_tools.TestNode(), test_ast_tools.TestNode())'

    insert_at(2, parent, TestNode())

# Generated at 2022-06-23 23:43:06.011735
# Unit test for function find
def test_find():
    ast_node = ast.parse('a = 0', '', 'exec')
    result = list(find(ast_node, ast.Assign))
    assert len(result) == 1

# Generated at 2022-06-23 23:43:07.058180
# Unit test for function find

# Generated at 2022-06-23 23:43:11.469502
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.parse("if True:\n  print('hello')\n  a = 1\n  print(a)")
    parent = get_closest_parent_of(node, node.body[0].body[0], ast.Module)
    assert parent == node

# Generated at 2022-06-23 23:43:20.419332
# Unit test for function find
def test_find():
    def func():
        a = 1
        b = 2
        c = 3
        c = 4
        c += 5

    compiled = ast.parse(func.__code__)
    c_var_decl = list(find(compiled, ast.AnnAssign))[0]
    c_var_assign = get_parent(compiled, c_var_decl)  # type: ignore
    assert c_var_decl.target.id == 'c'
    assert isinstance(c_var_assign, ast.AnnAssign)
    assert c_var_assign.target.id == 'c'
    assert c_var_assign.value.n == 4

# Generated at 2022-06-23 23:43:24.860831
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    x = ast.parse('class A: def b(): return 1').body[0]
    x = get_non_exp_parent_and_index(x, x.body[0].body[0].value)
    assert(x[1] == 0)


# Generated at 2022-06-23 23:43:30.921587
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('x = 1\nx = 2\n')
    replace_at(1, tree, ast.parse('x = 3').body)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=3))])'


# Generated at 2022-06-23 23:43:40.900366
# Unit test for function get_parent
def test_get_parent():
    ast_nodes = ast.parse(
        "def foo():\n"
        "    bar = 1\n"
        "    baz = 2\n"
        "return baz + bar\n"
    )
    ret = ast_nodes.body[-1]
    assert get_parent(ast_nodes, ret) == ast_nodes

    baz = ast_nodes.body[0].body[-1]
    assert get_parent(ast_nodes, baz) == ast_nodes.body[0]

    bar = ast_nodes.body[0].body[-2]
    assert get_parent(ast_nodes, bar) == ast_nodes.body[0]

# Generated at 2022-06-23 23:43:45.793580
# Unit test for function insert_at
def test_insert_at():
    node = ast.parse(test_code)
    parent = get_non_exp_parent_and_index(node, node.body[2].body[0])[0]
    insert_at(-1, parent, [ast.Pass()])
    assert str(node) == test_code.replace('pass', 'pass\npass')


# Generated at 2022-06-23 23:43:50.255779
# Unit test for function replace_at
def test_replace_at():
    import astor
    class myClass:
        pass
    myClass.name = "myClass"
    tree = ast.parse("myClass.name")
    parent = get_non_exp_parent_and_index(tree, tree.body[0])[0]
    replace_at(0, parent, ast.Str("foo"))
    assert astor.to_source(tree) == "foo"


if __name__ == "__main__":
    test_replace_at()

# Generated at 2022-06-23 23:44:01.042809
# Unit test for function insert_at
def test_insert_at():
    a = ast.parse('def my_function(x): return x', filename='', mode='exec')
    insert_at(0, a, ast.AnnAssign(target=ast.Name('y', ast.Store()), annotation=ast.Name('int', ast.Load())))

# Generated at 2022-06-23 23:44:02.064531
# Unit test for function insert_at

# Generated at 2022-06-23 23:44:08.265868
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''class Test:
    def __init__(self, a):
        self.a = a
        self.lst = list((1, 2, 3))''')

    print(get_non_exp_parent_and_index(tree, tree.body[0]))
    print(get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0]))
    print(get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0].
                                       value.args[0]))

# Generated at 2022-06-23 23:44:19.333641
# Unit test for function get_parent
def test_get_parent():
    # This is a case where the parent has a statement
    node_a = ast.FunctionDef(name='a', args=ast.arguments(), body=[ast.Pass()],
                             decorator_list=[])
    # This is a case where the parent doesn't have a statement (has an
    # expression instead)
    node_b = ast.BinOp(left=ast.Num(), op=ast.Add(), right=ast.Num())
    node_c = ast.stmt(node_b)
    node_d = ast.Module(body=[node_a, node_c])
    # Test for a statement
    assert get_parent(node_d, node_a.body[0]) == node_a
    # Test wheter non-statement parent is found

# Generated at 2022-06-23 23:44:26.424302
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """
    class Test(object):
        def test(self, a):
            if a:
                print(a)
    test = Test()
    test.test(1)
    """

    tree = ast.parse(code)
    test_statement = find(tree, ast.Call).__next__()
    method_definition = get_closest_parent_of(tree, test_statement, ast.FunctionDef)
    assert method_definition.name == 'test'

# Generated at 2022-06-23 23:44:35.072448
# Unit test for function insert_at
def test_insert_at():
    # Unit test for function insert_at
    a = ast.parse("[1,2,3,4]")
    b = ast.parse("[4,5,6,7]")
    c = ast.parse("[7,8,9,10]")
    aa = a.body[0].value.elts  # type: ignore
    assert len(aa) == 4
    insert_at(1, a, b)
    assert len(aa) == 8
    insert_at(0, a, c)
    assert len(aa) == 12
    assert isinstance(aa[0], ast.List)
    assert isinstance(aa[1], ast.List)
    assert isinstance(aa[2], ast.Tuple)
    insert_at(1, a, list(aa[2].elts))

# Generated at 2022-06-23 23:44:43.260337
# Unit test for function insert_at
def test_insert_at():
    ast_ = ast.parse('a = 1\nb = 2')
    insert_at(1, ast_.body[0], ast.parse('c = 3'))
    assert ast.dump(ast_) == 'Module(body=[Assign(targets=[Name(id=a, ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=c, ctx=Store())], value=Num(n=3)), Assign(targets=[Name(id=b, ctx=Store())], value=Num(n=2))])'



# Generated at 2022-06-23 23:44:52.549830
# Unit test for function find
def test_find():
    node = ast.parse("def fun(a, b):\n    pass\nprint(a)\ndef fun2():\n    pass")
    func_defs = find(node, ast.FunctionDef)
    assert len(list(func_defs)) == 2
    assert isinstance(next(func_defs), ast.FunctionDef)
    assert isinstance(next(func_defs), ast.FunctionDef)
    assert next(func_defs, None) is None

    loads = find(node, ast.Load)
    assert len(list(loads)) == 2
    assert isinstance(next(loads), ast.Load)
    assert isinstance(next(loads), ast.Load)
    assert next(loads, None) is None

# Generated at 2022-06-23 23:44:57.941231
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    body = tree.body
    assign = body[0]
    value = assign.value
    assert isinstance(value, ast.Num)
    assert value.n == 1

    replace_at(0, body, ast.parse('a = 1 + 2').body[0])
    assert isinstance(value, ast.BinOp)
    assert value.left.n == 1
    assert value.op.__class__ == ast.Add
    assert value.right.n == 2

# Generated at 2022-06-23 23:44:59.337339
# Unit test for function replace_at

# Generated at 2022-06-23 23:45:05.167171
# Unit test for function replace_at
def test_replace_at():
    # 6.0
    tree = ast.parse('x.x')
    replace_at(0, tree, ast.Name(id='print', ctx=ast.Load()))
    assert ast.dump(tree) == 'Print( value=Attribute( value=Name( id=\'x\', ctx=Load() ), attr=\'x\', ctx=Load() ), dest=None, nl=False)'

# Generated at 2022-06-23 23:45:08.802285
# Unit test for function find
def test_find():
    test_tree = ast.parse('x = 1', mode='exec')  # type: ast.AST
    nodes: List[ast.AST] = list(find(test_tree, ast.Assign))

    assert len(nodes) == 1
    assert isinstance(nodes[0], ast.Assign)

# Generated at 2022-06-23 23:45:19.387339
# Unit test for function insert_at
def test_insert_at():
    # Create a tree
    tree = ast.parse('for i in range(5):\n    if i < 3:\n        print(i)')

    # Create a new node
    new_stmt = ast.Import(names=[ast.alias(name='funcy', asname='f')])

    # Insert the new node at the beginning of the tree
    insert_at(0, tree, new_stmt)

    # Validate the new tree
    assert ast.dump(tree) == \
        "Import(names=[alias(name='funcy', asname='f')])\nfor i in range(5):\n    if i < 3:\n        print(i)\n"

    # Perform cleanup
    del tree
    del new_stmt


# Generated at 2022-06-23 23:45:29.896207
# Unit test for function find
def test_find():
    assert list(find(ast.parse("""
        a = 1
        def b():
            pass
    """), ast.FunctionDef)) == [ast.FunctionDef(name='b', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[], posonlyargs=[]), body=[ast.Pass()], decorator_list=[], returns=None, type_comment=None)]
    assert list(find(ast.parse("""
        a = 1
        def b():
            pass
    """), ast.Assign)) == [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                         value=ast.Num(n=1))]

# Generated at 2022-06-23 23:45:34.619229
# Unit test for function find
def test_find():
    code = "a = 0\nb = 1\nc = 2"
    tree = ast.parse(code)
    name_const_names = [node.name for node in find(tree, ast.NameConstant)]

    assert name_const_names == ['None']



# Generated at 2022-06-23 23:45:45.428320
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:45:46.290647
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:45:55.402758
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("some_code")

    # insert some node at the end of the tree
    expr = ast.Expr(ast.Str("test"))
    insert_at(len(tree.body), tree, expr)
    assert tree.body[-1] == expr  # type: ignore

    # insert to the middle of the tree
    expr = ast.Expr(ast.Str("test"))
    insert_at(1, tree, expr)
    assert tree.body[1] == expr  # type: ignore

    # insert to the beginning of the tree
    expr = ast.Expr(ast.Str("test"))
    insert_at(0, tree, expr)
    assert tree.body[0] == expr  # type: ignore



# Generated at 2022-06-23 23:46:06.675593
# Unit test for function get_parent
def test_get_parent():
    # Test for for_loop
    test_tree = ast.parse("for i in range(10):\n      print(i)")
    print_node = test_tree.body[0].body[0].value
    print_parent = get_parent(test_tree, print_node)
    assert isinstance(print_parent, ast.For)
    assert print_parent.body == [ast.Expr(value=print_node)]

    # Test for if_stmt
    test_tree = ast.parse("if True:\n      pass")
    if_node = test_tree.body[0]
    parent_of_if = get_parent(test_tree, if_node)
    assert isinstance(parent_of_if, ast.Module)

    # Test for function_def

# Generated at 2022-06-23 23:46:10.342809
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 2')
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]

    tree = ast.parse('a = 2')
    assert get_parent(tree, tree.body[0]) == tree



# Generated at 2022-06-23 23:46:11.143856
# Unit test for function get_parent
def test_get_parent():
    import ast_visitors

# Generated at 2022-06-23 23:46:14.593934
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def test_func():
        import os
    module_ast = ast.parse(test_func.__code__)
    function_node = module_ast.body[0]
    module_node = get_closest_parent_of(module_ast, function_node, ast.Module)

    assert isinstance(module_node, ast.Module)
    assert function_node in module_node.body

# Generated at 2022-06-23 23:46:24.526305
# Unit test for function replace_at
def test_replace_at():
    a = ast.parse("def f():\n  if True:\n    "
                  "print('a')\n    print('b')")
    _build_parents(a)
    f = a.body[0]
    i = f.body[0]
    print(i)

    n = ast.parse("print('c')\nprint('d')")
    assert n.body[0].s == "print('c')"
    assert n.body[1].s == "print('d')"

    replace_at(1, f, n)

    assert f.body[1].s == "print('c')"
    assert f.body[2].s == "print('d')"
    print("test_replace_at OK")



# Generated at 2022-06-23 23:46:28.926461
# Unit test for function replace_at
def test_replace_at():
    def sample():
        def inner():
            pass

    tree = ast.parse(dedent(sample.__doc__))
    function_def = tree.body[0]
    replace_at(0, function_def, ast.Pass())

    assert ast.dump(tree) == \
        textwrap.dedent('''\
        def sample():
            pass''')

# Generated at 2022-06-23 23:46:29.891576
# Unit test for function insert_at

# Generated at 2022-06-23 23:46:35.145861
# Unit test for function insert_at
def test_insert_at():
    for i in range(1, 9):
        value = 'x' + str(i)
        replace_at(0, tree, ast.Name(id=value, ctx=ast.Store()))
    assert(codegen.to_source(tree) == 'x1\nx2\nx3\nx4\nx5\nx6\nx7\nx8\n')


# Generated at 2022-06-23 23:46:36.156853
# Unit test for function insert_at

# Generated at 2022-06-23 23:46:43.295608
# Unit test for function get_parent
def test_get_parent():
    import astor
    code = '''
        class Test:
            abc = 1
            def test(self):
                a = 1
                b = 2
                print(a)
                print(b)
    '''
    tree = ast.parse(code)
    node = tree.body[0].body[0].targets[0]
    print("node:", astor.to_source(node))
    print("node parent:", astor.to_source(get_parent(tree, node)))



# Generated at 2022-06-23 23:46:44.339416
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:46:50.614064
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ast import parse
    from .exceptions import NodeNotFound

    tree = parse('\n'.join([
        "def foo():",
        "    bar()",
        "    baz()",
    ]))

    func = tree.body[0]
    bar = func.body[0]
    baz = func.body[1]

    parent1, index1 = get_non_exp_parent_and_index(tree, bar)
    parent2, index2 = get_non_exp_parent_and_index(tree, baz)

    assert(isinstance(parent1, ast.FunctionDef))
    assert(isinstance(parent2, ast.FunctionDef))
    assert(index1 == 0)
    assert(index2 == 1)


# Generated at 2022-06-23 23:46:57.065691
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""
a = 1
b = 2
c = 3
a = 3""")
    with open("insert_at.py", "w") as f:
        f.write(ast.dump(tree))

    insert_at(2, tree.body[3], ast.parse("c = 4").body[0])
    with open("inset_at.py", "w") as f:
        f.write(ast.dump(tree))

    # test: pass


# Generated at 2022-06-23 23:46:57.739546
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:47:01.846554
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def test():
        a = 1
        b = 1
        c = 1
        d = 1

    tree = ast.parse(dedent(test.__code__.co_consts[0]))
    body = tree.body[0].body

    assert get_closest_parent_of(tree, body[0].targets[0], ast.FunctionDef) is \
        tree.body[0]

    assert get_closest_parent_of(tree, body[0].targets[0], ast.Module) is tree



# Generated at 2022-06-23 23:47:09.113589
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .ast_generation import get_ast, generate_raw_nodes, generate_large_ast

    tree = get_ast(generate_raw_nodes(generate_large_ast(5)))
    node = get_closest_parent_of(tree, tree.body[2].body[0].body[0].body[0],
                                 ast.FunctionDef)
    assert get_non_exp_parent_and_index(tree, node)[0] == tree



# Generated at 2022-06-23 23:47:16.624355
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent."""
    ast_ = ast.parse('def x(a): return a')
    # body node
    assert get_parent(ast_, ast_.body[0]) == ast_
    assert get_parent(ast_, ast_.body[0], rebuild=True) == ast_
    # name node
    assert get_parent(ast_, ast_.body[0].name) == ast_.body[0]
    assert get_parent(ast_, ast_.body[0].name, rebuild=True) == ast_.body[0]
    # arg node
    assert get_parent(ast_, ast_.body[0].args.args[0]) == ast_.body[0].args

# Generated at 2022-06-23 23:47:17.285480
# Unit test for function get_parent

# Generated at 2022-06-23 23:47:28.139637
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast.ast3 import \
        parse, FunctionDef, Assign, Name, NameConstant, ImportFrom, \
        Num, List, Str, alias, Load

    tree = parse('''
    def a():
        def c():
            import pickle
        b = 1
    ''')

    parents = list(map(
        lambda x: get_non_exp_parent_and_index(tree, x),
        find(tree, FunctionDef)))

    assert parents == [
        (tree, 0),
        (find(tree, FunctionDef).__next__(), 0),
    ]

    parents = list(map(
        lambda x: get_non_exp_parent_and_index(tree, x),  # type: ignore
        find(tree, Name)))


# Generated at 2022-06-23 23:47:30.815248
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('print(1)'), ast.Expr))) == 1
    assert len(list(find(ast.parse('print(1)'), ast.Name))) == 1


# Generated at 2022-06-23 23:47:31.658881
# Unit test for function replace_at

# Generated at 2022-06-23 23:47:37.441317
# Unit test for function insert_at
def test_insert_at():
    import astor

    a = ast.parse('''def f():
    a = 1
    b = 2
    c = 3''')

    b = ast.parse('d = 4')

    insert_at(2, a, b)

    print(astor.to_source(a))

    assert astor.to_source(a) == '''def f():
    a = 1
    b = 2
    d = 4
    c = 3'''

# Generated at 2022-06-23 23:47:43.776597
# Unit test for function get_parent
def test_get_parent():
    """Check if the get_parent function returns the correct parent."""
    tree = ast.parse('''
    def test():
        for i in range(1):
            a = 1
    ''')

    assign = tree.body[0].body[0].body[0].body[0]
    for_ = tree.body[0].body[0]

    assert for_ is get_parent(tree, assign)



# Generated at 2022-06-23 23:47:50.503451
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    parent = ast.parse("def foo():\n    x = 1").body[0]
    node = parent.body[0].body[0]
    _build_parents(parent)
    assert get_closest_parent_of(parent, node, ast.Module) == parent
    assert get_closest_parent_of(parent, node, ast.FunctionDef) == parent
    assert get_closest_parent_of(parent, node, ast.Assign) == node


# Generated at 2022-06-23 23:47:57.404273
# Unit test for function get_parent
def test_get_parent():
    class ExpectedResults:
        def __init__(self, tree: ast.AST, nodelist: ast.AST, index: ast.AST,
                     elt: ast.AST, listcomp: ast.AST, comp: ast.AST,
                     arg: ast.AST, value: ast.AST, generator: ast.AST):
            self.tree = tree
            self.nodelist = nodelist
            self.index = index
            self.elt = elt
            self.listcomp = listcomp
            self.comp = comp
            self.arg = arg
            self.value = value
            self.generator = generator

    tree = ast.parse("[i for i in range(2)]")

# Generated at 2022-06-23 23:48:09.015491
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..testsuite import parse_testcase
    from .helper import get_dict_value
    test = parse_testcase('''
    def baz():
        pass


    def bar():
        baz()
        print(123)


    def foo():
        bar()
        print(1)


    foo()''')

    assert get_closest_parent_of(test, get_dict_value(test, 'Call', 'baz'),
                                 ast.FunctionDef) == get_dict_value(test,
                                                                    'FunctionDef',
                                                                    'baz')

# Generated at 2022-06-23 23:48:18.366390
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test if get_non_exp_parent_and_index returns right parent and index."""
    class_node = ast.ClassDef(name='Foo',
                              body=[ast.FunctionDef(name='__init__',
                                                    body=[ast.Pass()],
                                                    args=ast.arguments(
                                                        args=[
                                                            ast.arg(arg='self')
                                                        ]
                                                    ))])

    assert get_non_exp_parent_and_index(class_node,
                                        class_node.body[0].body[0]) == \
        (class_node.body[0], 0)

# Generated at 2022-06-23 23:48:23.704754
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Create an ast.Ast object, then find a closest parent of the node with type
    # ast.FunctionDef.
    tree = ast.parse('def f():\n\tx = 1\n\ty = 2')
    a = ast.Name(id='x')
    b = get_closest_parent_of(tree, a, ast.FunctionDef)
    assert b.name == 'f'

# Generated at 2022-06-23 23:48:34.646814
# Unit test for function replace_at
def test_replace_at():
    """
    This function replaces a node at certain index in a parent body
    with a node or a list of nodes
    """

    class ExampleClass(ast.AST):
        _fields = ('lst',)

    class MainClass(ast.AST):
        _fields = ('lst',)

    class OtherClass(ast.AST):
        _fields = ('lst',)

    class NewClass(ast.AST):
        _fields = ('lst',)

    class NewClass1(ast.AST):
        _fields = ('lst',)

    class NewClass2(ast.AST):
        _fields = ('lst',)

    main = MainClass()
    main.lst = [ExampleClass(), OtherClass(), ExampleClass()]
    example = main.lst[0]


# Generated at 2022-06-23 23:48:38.710506
# Unit test for function insert_at
def test_insert_at():

    l = ast.List()
    assert l.elts == []
    l.elts.append(1)
    l.elts.append(ast.Str(s=', '))
    insert_at(1, l, 2)
    assert l.elts == [1, 2, ast.Str(s=', ')]



# Generated at 2022-06-23 23:48:46.241042
# Unit test for function replace_at
def test_replace_at():
    expr1 = ast.parse('2+2').body[0]
    expr2 = ast.parse('3+3').body[0]
    expr3 = ast.parse('4+4').body[0]
    expected_result = ast.parse('x = 4+4').body[0]
    assignment = ast.parse('x = 2+2').body[0]
    ast.copy_location(expr3, assignment)
    replace_at(1, assignment, [expr3])
    assert ast.dump(assignment) == ast.dump(expected_result)

# Generated at 2022-06-23 23:48:53.256692
# Unit test for function replace_at
def test_replace_at():
    body = [
        ast.Expr(value=ast.Name(id='x', ctx=ast.Load())),
        ast.Return(value=ast.Name(id='y', ctx=ast.Load()))
    ]
    parent = ast.FunctionDef(name='test', body=body, decorator_list=[])

    replace_at(0, parent, ast.Name(id='z', ctx=ast.Load()))

    assert list(map(type, parent.body)) == [ast.Name, ast.Return]  # type: ignore

# Generated at 2022-06-23 23:49:01.729573
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def f1(a):\n\tdef f2(b):\n\t\t1+2')
    # List of nodes:
    # f1(a): FunctionDef(name='f1', args=arguments(args=[arg(arg='a', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[FunctionDef(name='f2', args=arguments(args=[arg(arg='b', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])), Expr(value=BinOp(left=Num(n=1), op=Add(), right=Num(n=2)))])
    # f2(b): FunctionDef(

# Generated at 2022-06-23 23:49:13.240741
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .ast_builder import ASTBuilder
    builder = ASTBuilder()
    ast_ = builder.module(
        builder.function_def(
            'test_function',
            builder.arguments(),
            builder.return_(builder.number(1))
        )
    )
    func = ast_.body[0]
    func_parent, func_index = get_non_exp_parent_and_index(ast_, func)
    assert (func_parent == ast_ and func_index == 0)

    return_ = func.body[0]
    return_parent, return_index = get_non_exp_parent_and_index(ast_, return_)
    assert (return_parent == func and return_index == 0)

    number = return_.value
    number_parent, number_index = get_non_exp_parent_

# Generated at 2022-06-23 23:49:15.489543
# Unit test for function find
def test_find():
    import astor
    tree = ast.parse("def f(a,b):\n    c = a + b\n    return c")
    nodes = find(tree, ast.PythonFile)
    print(list(nodes))
    print(astor.dump_tree(list(nodes)[0]))

# Generated at 2022-06-23 23:49:20.778883
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    tree = ast.parse("def test():\n    a = 1")
    a = list(tree.body[0].body)[0].value
    assert get_non_exp_parent_and_index(tree, a) == ((tree.body[0]), 1)

# Generated at 2022-06-23 23:49:24.980171
# Unit test for function get_parent
def test_get_parent():
    from tests.helpers.test_data import SOURCE
    from ..parser import safe_parse

    tree = safe_parse(SOURCE)
    parent = get_parent(tree, tree.body[1].body[1])

    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'foo'



# Generated at 2022-06-23 23:49:28.425905
# Unit test for function insert_at
def test_insert_at():
    x = ast.parse('print(1)')
    insert_at(0, x, ast.Expr(value=ast.Num(2)))
    assert ast.dump(x) == "Module(body=[Expr(value=Num(2)), Print(dest=None, values=[Num(1)], nl=True)])"


# Generated at 2022-06-23 23:49:39.511843
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""
    def f():
        print("Hello,", end="")
        print("World!")
        pass
    """)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])
    insert_at(0, parent, ast.parse('pass')).body[0]


# Generated at 2022-06-23 23:49:41.142932
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert not get_closest_parent_of(None, None, type(None))



# Generated at 2022-06-23 23:49:50.394307
# Unit test for function insert_at
def test_insert_at():
    """
    Test if insert_at properly inserts new node at the specified
    index.
    """
    node = ast.Name(id='foo', ctx=ast.Load())
    node.lineno = 1
    node.col_offset = 2
    node.ctx.lineno = 1
    node.ctx.col_offset = 2

    parent = ast.Expr(value=None)
    parent.lineno = 1
    parent.col_offset = 2
    insert_at(0, parent, node)
    assert parent.body[0] == node  # type: ignore


# Generated at 2022-06-23 23:49:50.963779
# Unit test for function get_parent
def test_get_parent():
    pass

# Generated at 2022-06-23 23:49:56.832988
# Unit test for function insert_at
def test_insert_at():
    def pytest_func():
        if True:
            pass

    tree = ast.parse(inspect.getsource(pytest_func))
    parent = get_closest_parent_of(tree, tree.body[0].body[0].test, ast.If)
    insert_at(0, parent, ast.Pass())
    assert ast.dump(tree) == inspect.getsource(pytest_func) + '\n'


# Generated at 2022-06-23 23:49:57.862697
# Unit test for function find

# Generated at 2022-06-23 23:50:08.481358
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as typed_ast
    import ast_factory.ast_factory as ast_factory
    myAst = typed_ast.parse("""
    def myFunc1(l):
        l.append(5)
        l.append(6)
        l.append(7)
        return l
    """)
    for call in ast_factory.find(myAst, typed_ast.Call):
        parent = ast_factory.get_closest_parent_of(myAst, call, typed_ast.FunctionDef)
        assert parent.name == 'myFunc1'
        assert ast_factory.has_child_of_type(parent, typed_ast.Call)
        assert not ast_factory.has_child_of_type(parent, typed_ast.ClassDef)


# Generated at 2022-06-23 23:50:09.543093
# Unit test for function get_parent

# Generated at 2022-06-23 23:50:13.204136
# Unit test for function get_parent
def test_get_parent():
    program = ast.parse("l = [1,2,3] # comment")
    lst = program.body[0].value
    comment = program.body[-1]
    assert get_parent(program, comment) == program
    assert get_parent(program, lst) == program.body[0]

# Generated at 2022-06-23 23:50:19.545707
# Unit test for function get_parent
def test_get_parent():
    A = ast.Expression(ast.Constant(1))
    B = ast.Expression(ast.Constant(2))
    C = ast.Expression(ast.Constant(3))
    D = ast.Compare(A, [ast.Eq()], [B])
    E = ast.If(D, [ast.Expr(C)], [])
    tree = ast.Module([E])

    get_parent(tree, C) == E
    get_parent(tree, D) == E

# Generated at 2022-06-23 23:50:28.474041
# Unit test for function replace_at
def test_replace_at():
    import itertools

    class FakeNode(ast.AST):
        _fields = ['body']

    # Setup
    parent = FakeNode()
    parent.body = list(itertools.repeat('', 10))

    # Test
    # Replace nothing
    replace_at(0, parent, None)
    assert parent.body == [''] + list(itertools.repeat('', 9))
    replace_at(9, parent, None)
    assert parent.body == [''] + list(itertools.repeat('', 9))
    # Replace with node
    replace_at(0, parent, 'a')
    assert parent.body == ['a'] + list(itertools.repeat('', 9))
    replace_at(9, parent, 'z')

# Generated at 2022-06-23 23:50:30.723922
# Unit test for function insert_at
def test_insert_at():
    mod = ast.parse("def test(): pass")
    class_def = ast.ClassDef("TestClass", [], [], [], [])
    insert_at(0, mod, class_def)
    assert mod.body[0] == class_def


# Generated at 2022-06-23 23:50:34.513025
# Unit test for function find
def test_find():
    x = ast.parse('a = 1\nb = 2').body[0]
    assert len(list(find(x, ast.Assign))) == 1
    assert isinstance(list(find(x, ast.Name))[0], ast.Name)
    assert isinstance(list(find(x, ast.Num))[0], ast.Num)



# Generated at 2022-06-23 23:50:39.200287
# Unit test for function insert_at
def test_insert_at():
    parent = ast.parse('for a in b: pass')
    insert_at(0, parent.body[0], ast.parse('c = a').body)
    assert(ast.dump(parent) == 'Module(body=[For(target=Name(id=\'a\', '
                             'ctx=Store()), iter=Name(id=\'b\', ctx=Load()), '
                             'body=[Assign(targets=[Name(id=\'c\', '
                             'ctx=Store())], value=Name(id=\'a\', '
                             'ctx=Load()))], orelse=[])])')

# Generated at 2022-06-23 23:50:40.142554
# Unit test for function replace_at
def test_replace_at():
    import astor


# Generated at 2022-06-23 23:50:46.204956
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a = ast.parse('a = 1\n')
    expr = a.body[0].value
    print(expr)
    assert expr in _parents
    assert get_non_exp_parent_and_index(a, expr) == (a.body[0], 0)

# Generated at 2022-06-23 23:50:49.821986
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Get non-Exp parent and index of child."""
    tree = ast.parse('def test(): pass')
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0



# Generated at 2022-06-23 23:50:55.595424
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    program = ast.parse('if True:\n    a = 1\n    b = 2\nb = 3')
    parent, index = get_non_exp_parent_and_index(program, program.body[1].body[0])
    assert parent.body[index] == program.body[1].body[0] and index == 1
    assert parent == program.body[1]
    program = ast.parse('if True:\n    a = 1\n    b = 2')
    parent, index = get_non_exp_parent_and_index(program, program.body[0].body[0].body[0])
    assert parent.body[index] == program.body[0].body[0].body[0]
    assert parent == program.body[0].body[0] and index == 0

# Generated at 2022-06-23 23:50:56.460641
# Unit test for function replace_at

# Generated at 2022-06-23 23:51:00.097030
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .test_utils import test_ast_3_6

    tree = test_ast_3_6()

    func_def = get_closest_parent_of(tree, tree.body[0].body[0].targets[0],
                                     ast.FunctionDef)

    assert func_def.name == 'func'



# Generated at 2022-06-23 23:51:07.487323
# Unit test for function replace_at
def test_replace_at():
    test_ast = ast.parse("def f():\n    a = 1")
    tmp_ast = ast.parse("b = 2")
    parent_node, index = get_non_exp_parent_and_index(test_ast, test_ast.body[0])
    assert len(parent_node.body) == 1
    assert index == 0
    replace_at(index, parent_node, tmp_ast)
    assert len(parent_node.body) == 2
    assert type(parent_node.body[0]) == ast.Assign
    assert parent_node.body[0].targets[0].id == 'b'
    assert parent_node.body[1].name == 'f'

# Generated at 2022-06-23 23:51:09.860492
# Unit test for function get_parent
def test_get_parent():
    """
    Checks working of get_parent function
    """
    # mocking ast.parse

# Generated at 2022-06-23 23:51:14.646298
# Unit test for function replace_at
def test_replace_at():
    from ..test_utils import parse_test_code

# Generated at 2022-06-23 23:51:18.594329
# Unit test for function get_parent
def test_get_parent():
    '''
    Tests get_parent
    '''
    def f(s):
        pass
    assert get_parent(f, f.args.args[0]) is f.args

# Generated at 2022-06-23 23:51:30.548897
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # test_function
    tree = ast.parse('x = a + b\nc = d + e')
    node = ast.parse('c = d + e').body[0]
    non_exp_parent, index = get_non_exp_parent_and_index(tree, node)
    assert non_exp_parent.body == tree.body  # type: ignore
    assert index == 1

    # test_if
    tree = ast.parse('x = a + b\nif x > 10:\n    c = d + e')
    node = ast.parse('c = d + e').body[0]
    non_exp_parent, index = get_non_exp_parent_and_index(tree, node)
    assert non_exp_parent.body[1].body == tree.body[1].body  # type: ignore

# Generated at 2022-06-23 23:51:36.767921
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    source = "def foo(): pass"

    tree = ast.parse(source)
    _build_parents(tree)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert(parent == tree)
    assert(index == 0)

# Generated at 2022-06-23 23:51:45.868449
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .testing import mock_node, mock_tree
    from . import nodes
    from . import NON_EXP_NODES

    # Test every non-exp node type
    for typ in NON_EXP_NODES:
        tree = mock_tree(typ, mock_node('x'))
        x = tree['body'][0]['targets'][0]
        y = tree['body'][0].parent
        x_abs = typ.__name__ + '.body.0.targets.0'
        y_abs = typ.__name__

        assert get_closest_parent_of(tree, x, nodes.Module) == tree
        assert get_closest_parent_of(tree, x, typ) == tree

# Generated at 2022-06-23 23:51:49.589574
# Unit test for function insert_at

# Generated at 2022-06-23 23:52:00.686600
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('if True: pass')
    node = tree.body[0].body[0]
    assert get_non_exp_parent_and_index(tree, node) == (tree.body[0], 0)

    tree = ast.parse('if True: pass')
    node = tree.body[0]
    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)

    tree = ast.parse('if True: pass')
    node = tree.body[0]
    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)

    tree = ast.parse('if True: pass')
    node = tree.body[0]
    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)

# Generated at 2022-06-23 23:52:08.534756
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_astunparse
    ast_tree = ast.parse('''
    def add(a, b):
        return a + b
    x = add(1, 2)
    ''')
    x = ast_tree.body[1].value
    add = get_closest_parent_of(ast_tree, x, ast.FunctionDef)
    assert add.name == "add"


# Generated at 2022-06-23 23:52:11.620910
# Unit test for function find
def test_find():
    tree = ast.parse('import re\n')
    found = find(tree, ast.Import)
    assert list(found) == [tree.body[0]]



# Generated at 2022-06-23 23:52:23.626835
# Unit test for function find
def test_find():
    import sys
    import inspect
    import ast as pyast
    import ast as pyast
    from ast import Tuple, Name, Call, Return, Expr, Module, Load, Store, Assign, Import, Name, Store, Load, FunctionDef, NameConstant, Arguments, Compare, Lt, If, While, For, AugAssign, Subscript, Index, List, Str, Sub, Add, USub, Mod, Mult, Div, BitOr, BitAnd, BitXor, RShift, LShift, Invert, UAdd, USub, In, NotIn, Is, IsNot, Eq, NotEq, LtE, Lt, Gt, GtE, NotEq, Not, Invert, UAdd, USub, AST, And, Or, Add, Sub, Mult, Div, Mod, Pow, LShift, RShift, BitOr, BitX

# Generated at 2022-06-23 23:52:34.319966
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor  # type: ignore
    import astunparse

    # here we write the code we want to transform
    code = '''if a > b:\n    a = 0\nelif a < b:\n    a = 1\n'''
    ast_tree = ast.parse(code)

    # we find node we want to transform
    node = None

    for n in ast.walk(ast_tree):
        if isinstance(n, ast.Compare) and n.left_child is None:
            node = n

    if not node:
        raise Exception('Node not found')

    # get parent of node and the index in its body
    node_index = None
    parent = node

    while not hasattr(parent, 'body'):
        node = parent
        parent = get_parent(ast_tree, parent)

   

# Generated at 2022-06-23 23:52:38.600526
# Unit test for function find
def test_find():
    expr = ast.parse("def foo():\n    a = 1\n    b = 10\n    return a + b\n")

    nodes = ast.iter_child_nodes(expr)
    found_nodes = list(find(expr, ast.FunctionDef))

    assert list(nodes)[0] == found_nodes[0]

# Generated at 2022-06-23 23:52:42.039633
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def a():\n    x, (b, c) = 4, (4, 4)')
    node = tree.body[0].body[0].targets[1]
    expected_parent = tree.body[0].body[0]
    assert get_non_exp_parent_and_index(tree, node)[0] == expected_parent, \
        'Parent is not the tuple'
    assert get_non_exp_parent_and_index(tree, node)[1] == 1, 'Index is not 1'

# Generated at 2022-06-23 23:52:48.350155
# Unit test for function insert_at
def test_insert_at():
    """Unit test for function insert_at"""

    tree = ast.parse("""
    def foo():
        pass
    """)

    new_assign = ast.parse("""
    x = y
    """)

    insert_at(0, tree.body[0], new_assign.body[0])

    assert ast.dump(tree) == ast.dump(ast.parse("""
    def foo():
        x = y
        pass
    """))

    return True


# Generated at 2022-06-23 23:52:55.922580
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class TopLevelClass:
        pass

    class ModuleClass:
        pass

    class FunctionClass:
        pass

    class SubscriptClass:
        pass

    class NameClass:
        pass

    # test that non-Exp AST node is returned
    ast_tree = ast.parse('''
    class TopLevelClass:
        def __init__(self, module_class, function_class):
            self.module_class = module_class
            self.function_class = function_class
    ''')
    parent, index = get_non_exp_parent_and_index(
        ast_tree, ast_tree.body[0].body[0])
    assert isinstance(parent, ast.ClassDef)
    assert index == 0