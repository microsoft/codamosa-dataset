

# Generated at 2022-06-23 23:43:01.522483
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast
    from .utils import get_non_exp_parent_and_index
    from .context_utils import get_context_for_node

    def test_function():
        pass

    tree = ast.parse(dedent(inspect.getsource(test_function)))
    body = tree.body[0].body
    func_def = tree.body[0]
    func_def_context = get_context_for_node(tree, func_def)
    func_def_parent_context, func_def_index = get_non_exp_parent_and_index(
        tree, func_def)
    assert func_def_context == func_def_parent_context
    assert func_def_index == 0

    pass_node = body[0]
    pass_context = get_context

# Generated at 2022-06-23 23:43:08.443016
# Unit test for function insert_at
def test_insert_at():
    # Create a simple function def
    tree = ast.parse('def foo():\n  i = 1')

    # Find the function and the body
    f = find(tree, ast.FunctionDef).__next__()
    body = find(f, ast.Suite).__next__()

    # Insert a new line with just 2 on the last line
    insert_at(len(body.body), body, ast.parse('2').body[0])
    assert tree.body[0].body[1].value.n == 2



# Generated at 2022-06-23 23:43:20.673460
# Unit test for function get_parent
def test_get_parent():
    from ..ast_utils import dump
    from .assertion import dump_equal
    source = """
    if True:
        if False:
            ast.parse('print("hello")')
    """
    expected = """
    Module(body=[
        If(test=NameConstant(value=True), body=[If(test=NameConstant(value=False), body=[Expr(value=Call(func=Name(id='ast', ctx=Load()), args=[Str(s='print("hello")')], keywords=[])), orelse=[])], orelse=[])], orelse=[])
    ])
    """
    tree = ast.parse(source)
    node = tree.body[0].body[0].body[0].value
    parent = get_parent(tree, node)
    assert dump(parent) == dump_

# Generated at 2022-06-23 23:43:25.573202
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1 + 2')
    a = find(tree, ast.Name).next()
    assert get_parent(tree, a) is tree.body[0].value.left
    assert get_parent(tree, a, True) is tree.body[0].value.left

# Generated at 2022-06-23 23:43:34.218588
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Name(id='test_name', ctx=ast.Load())
    parent = ast.Expr(value=node)
    parent2 = ast.Expr(value=parent)
    parent3 = ast.Module(body=[parent2])
    parent4 = ast.Module(body=[parent3])
    parent5 = ast.Module(body=[parent4])
    parent6 = ast.Module(body=[parent5])

    result, index = get_non_exp_parent_and_index(parent6, node)
    assert result == parent3
    assert index == 0

    result, index = get_non_exp_parent_and_index(parent6, parent)
    assert result == parent3
    assert index == 0

    result, index = get_non_exp_parent_and_index(parent6, parent2)

# Generated at 2022-06-23 23:43:38.757342
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""x = 0.5
x
x + x""")
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1].value)
    assert index == 0
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-23 23:43:48.554036
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..ast import py_to_ast

    ast_ = py_to_ast('foo = 1')
    assert ast_.body[0] == ast.Assign(targets=[ast.Name(id='foo', ctx=ast.Store())],
                                      value=ast.Num(n=1))  # noqa
    (parent, index) = get_non_exp_parent_and_index(ast_, ast_.body[0])
    assert parent == ast_
    assert index == 0
    ast_ = py_to_ast('{foo = 1}')
    (parent, index) = get_non_exp_parent_and_index(ast_, ast_.body[0].value)
    assert parent == ast_
    assert index == 0



# Generated at 2022-06-23 23:43:52.312886
# Unit test for function replace_at
def test_replace_at():
    def a():
        pass

    def b():
        pass

    body = ast.parse(inspect.getsource(a)).body
    replace_at(0, body, ast.parse(inspect.getsource(b)).body)

    assert ast.dump(body) == ast.dump(ast.parse(inspect.getsource(b)).body)



# Generated at 2022-06-23 23:43:59.852747
# Unit test for function get_parent
def test_get_parent():
    import ast
    import astor
    from textwrap import dedent

    before = astor.to_source(ast.parse(dedent('''\
        def foo():
            x = 1 + 2
            return x + 1
    ''')))

    subtree = ast.fix_missing_locations(ast.parse(dedent('''\
        x = 1 + 2
        return x + 1
    ''')))

    _build_parents(subtree)

    after = astor.to_source(subtree)

    assert before == after

# Generated at 2022-06-23 23:44:03.571131
# Unit test for function replace_at
def test_replace_at():
    root = ast.parse('a = 1')
    node = root.body[0]
    replace_at(0, root, ast.parse('c = 3'))
    assert root.body[0].value.n == 3
    assert node not in ast.walk(root)



# Generated at 2022-06-23 23:44:07.992383
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module = ast.parse("""
    if True:
        while True:
            foo()
    """)
    while_node = get_closest_parent_of(module, module.body[0].body[0].body[0], ast.While)
    parent, index = get_non_exp_parent_and_index(module, while_node)
    assert parent == module.body[0]
    assert index == 0

# Generated at 2022-06-23 23:44:18.871871
# Unit test for function get_parent
def test_get_parent():
    from astunparse import unparse
    from ast import Module, Name, Load, FunctionDef, Store, Add, Num, Assign, \
        Return

    # Addition
    mod = Module(body=[
        FunctionDef(
            name='add',
            args=None,
            body=[
                Assign(
                    targets=[Name(id='a', ctx=Store())],
                    value=Add(left=Num(n=1), right=Num(n=2))
                ),
                Return(value=Name(id='a', ctx=Load()))
            ],
            decorator_list=[],
            returns=None
        )
    ])

    # The function should return the function object
    assert get_parent(mod, mod.body[0].body[1]) == mod.body[0]
    # The function should return the

# Generated at 2022-06-23 23:44:24.005185
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    # src = '''
    # def func(num):
    #     print(num)
    # '''
    # tree = ast.parse(src)
    # print(ast.dump(tree))
    # print(astor.to_source(tree))

    # num = tree.body[0].args.args[0]
    # print('num * 2')
    # print(astor.to_source(node))
    # parent = get_closest_parent_of(tree, num, ast.FunctionDef)
    # print('parent')
    # print(astor.to_source(parent))
    # print('names')
    # print(astor.to_source(parent.args.args))
    # print('call')
    # print(astor.to_source(parent.

# Generated at 2022-06-23 23:44:33.873267
# Unit test for function get_parent
def test_get_parent():
    import astor
    tree = ast.parse('''
        class A:
            def func1(self):
                a = A()
                return a

            def func2(self):
                a = A()
                return a.func1()
        ''')

    result_1 = 'Return(Call(Call(Attribute(Name(\'a\', Load())' \
              ', \'func1\', Load()), [], []), \'__call__\', Load()), [])'
    parent_1 = get_parent(tree, find(tree, ast.Return).next())
    assert astor.to_source(parent_1).strip() == result_1


# Generated at 2022-06-23 23:44:38.775160
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("""def foo():\n    x = 5\n    y = 2""")

    body = tree.body[0].body

    for index in range(len(body)):
        replace_at(index, body, ast.Return(body[index].value))

    assert "return 5\n    return 2" in ast.dump(tree)

# Generated at 2022-06-23 23:44:44.016648
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        '''
        def foo():
            print(1)
            print(2)
        '''
    )
    node = tree.body[0].body[0]
    foo_body, index = get_non_exp_parent_and_index(tree, node)
    assert(index == 0)

# Generated at 2022-06-23 23:44:49.756661
# Unit test for function get_parent
def test_get_parent():
    from textwrap import dedent
    from ..extractor import extract

    code = dedent(
        """
        func1(func2())
        """
    )

    tree = extract(code)
    expected = ast.Call()
    expected.func = ast.Name(
        id='func1', ctx=ast.Load())

    assert get_parent(tree, expected.func) is expected



# Generated at 2022-06-23 23:44:57.055728
# Unit test for function replace_at

# Generated at 2022-06-23 23:45:01.963404
# Unit test for function find
def test_find():
    from ..import rewriter
    from . import mocks

    new_body = list(find(mocks.tree, ast.Return))

    assert new_body[0] == ast.Return(value=ast.Num(n=11))


test_find.__test__ = False


# Generated at 2022-06-23 23:45:10.493449
# Unit test for function insert_at
def test_insert_at():
    node1 = ast.parse('a = 1').body[0]
    node2 = ast.parse('b = 2').body[0]

    node1_parent = ast.Module(body=[node1])
    node2_parent = ast.Module(body=[node2])

    insert_at(1, node1_parent, node2_parent)

    assert ast.dump(node1_parent, include_attributes=True) == \
        "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], " \
        "value=Num(n=1)), Module(body=[Assign(targets=[Name(id='b', " \
        "ctx=Store())], value=Num(n=2))])])"



# Generated at 2022-06-23 23:45:21.537028
# Unit test for function replace_at
def test_replace_at():
    import astor

    class Tmp(ast.AST):
        def __init__(self, name: str):
            self.name = name

    tree = ast.parse('a = 1\nb = 2\nc = 3')
    insert_at(1, tree, Tmp('xyz'))

    assert tree.body[1].name == 'xyz'  # type: ignore
    assert astor.to_source(tree, indent_with=' '*4).strip() == '''a = 1
b = 2
xyz
c = 3'''

    parent, index = get_non_exp_parent_and_index(tree, Tmp('xyz'))
    replace_at(index, parent, ast.parse('d = 4').body)

    assert isinstance(tree.body[2], ast.Assign)  # type

# Generated at 2022-06-23 23:45:27.598475
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('x = 2')
    module = tree.body[0]
    assign = module.value
    number = assign.value
    test_cases = (
        (tree, module),
        (tree, assign),
        (tree, number),
    )
    for tree_, node in test_cases:
        parent = get_parent(tree_, node)
        assert parent == node.parent


# Generated at 2022-06-23 23:45:30.640704
# Unit test for function find
def test_find():
    import pprint
    import typing

    _module = ast.parse('''
        def foo(a: str, b: str) -> str:
            return 'Hello'
    ''')
    pprint.pprint(list(find(_module, typing.List)))

# Generated at 2022-06-23 23:45:33.586177
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_astunparse
    unparse = typed_astunparse.Unparser()
    # tree to search

# Generated at 2022-06-23 23:45:44.817710
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    code = """
    def test_get_non_exp_parent_and_index():
        import astor
        code = "for i in range(10): i = 1"
        tree = astor.parse_file(code)
        node = tree.body[0].body[0].target
        parent, index = get_non_exp_parent_and_index(tree, node)
        assert index == 0
        assert isinstance(parent, ast.For)
        """

    tree = astor.parse_file(code)
    node = tree.body[0].body[0].target
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert index == 0
    assert isinstance(parent, ast.For)



# Generated at 2022-06-23 23:45:51.222981
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def f():
        x = 4
        while (x > 2): x -= 1
    """)
    x = [n for n in ast.walk(tree) if isinstance(n, ast.Name) and n.id == 'x'][0]
    parent = get_parent(tree, x)
    assert isinstance(parent, ast.Assign)

    parent = get_parent(tree, parent)
    assert isinstance(parent, ast.FunctionDef)

# Generated at 2022-06-23 23:45:52.111017
# Unit test for function replace_at

# Generated at 2022-06-23 23:45:57.372527
# Unit test for function get_parent
def test_get_parent():
    source = 'x = y + 1'
    tree = ast.parse(source)

    parent = get_parent(tree, tree.body[0].value.right)
    assert isinstance(parent, ast.BinOp)

    parent = get_parent(tree, tree.body[0].value.right.right)
    assert isinstance(parent, ast.Num)



# Generated at 2022-06-23 23:46:05.422597
# Unit test for function replace_at
def test_replace_at():
    T = TypeVar('T', bound=ast.AST)
    from typed_ast.ast3 import FunctionDef, Load, Arg
    function_def = FunctionDef(
        name='test',
        args=ast.arguments(
            args=[Arg(arg='test_arg', annotation=None)]
        ),
        body=[
            ast.Expr(value=Load()),
            ast.Expr(value=Load())
        ]
    )

    replace_at(0, function_def, ast.Load())

    assert isinstance(function_def.body[0], ast.Load)

# Generated at 2022-06-23 23:46:13.559883
# Unit test for function insert_at
def test_insert_at():
    mod = ast.parse("def f():\n    pass\na = 1")
    new_nodes = ast.parse("b = 2")

    insert_at(1, mod, new_nodes)

    assert(ast.dump(mod) == "Module(body=[FunctionDef(name='f', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Pass()],Decorator(body=), Decorator(body=)], Decorator(body=)),Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='b', ctx=Store())], value=Num(n=2))])")


# Generated at 2022-06-23 23:46:23.767878
# Unit test for function replace_at
def test_replace_at():
    """Test."""
    tree = ast.parse("""
        def __premain__():
            pass

        def main():
            pass
    """)

    replace_at(1, tree.body[0], [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],  # noqa
                                            value=ast.Num(n=1))])
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=\'__premain__\', args=arguments(), body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1))], decorator_list=[]), FunctionDef(name=\'main\', args=arguments(), body=[Pass()], decorator_list=[])])'  # noqa

# Generated at 2022-06-23 23:46:32.068117
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast
    tree = ast.parse('def f():\n    pass')
    pass_ = tree.body[0].body[0]
    body = tree.body[0]
    f = tree.body[0]
    func = tree.body[0]
    assert(get_closest_parent_of(tree, pass_, ast.FunctionDef) is func)
    assert(get_closest_parent_of(tree, body, ast.FunctionDef) is func)
    assert(get_closest_parent_of(tree, f, ast.FunctionDef) is func)
    assert(get_closest_parent_of(tree, func, ast.Module) is tree)

# Generated at 2022-06-23 23:46:33.134876
# Unit test for function get_parent

# Generated at 2022-06-23 23:46:43.412783
# Unit test for function insert_at
def test_insert_at():
    def a():
        b()
        c()

    def d():
        '''d'''

    def e():
        '''e'''

    def f():
        '''f'''

    root_node = ast.parse(inspect.getsource(a))  # type: ignore

    # There is three function in our root node
    assert len(find(root_node, ast.FunctionDef)) == 3

    # Get root function
    function_def = next(find(root_node, ast.FunctionDef))
    insert_at(0, function_def, ast.parse(inspect.getsource(d)))  # type: ignore
    insert_at(1, function_def, ast.parse(inspect.getsource(e)))  # type: ignore

# Generated at 2022-06-23 23:46:54.155371
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Example:
    # <ClassDef lineno="1" col_offset="0">
    #   <name lineno="1" col_offset="6">ClassName</name>
    #   <keywords lineno="1" col_offset="17">[]</keywords>
    #   <body lineno="1" col_offset="19">[<Pass lineno="1" col_offset="23" type="Pass" />]</body>
    #   <decorator_list lineno="1" col_offset="0">[]</decorator_list>
    # </ClassDef>

    class ClassDef(ast.AST):
        _fields = ('name', 'body', 'decorator_list')

    class Pass(ast.AST):
        _fields = ()


# Generated at 2022-06-23 23:47:02.151077
# Unit test for function replace_at
def test_replace_at():
    # Create AST Node
    funcdef = ast.FunctionDef(
        name='f',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwarg=None,
            defaults=[]
        ),
        body=[
            ast.Pass(),
            ast.Pass(),
            ast.Pass(),
            ast.Pass()
        ],
        decorator_list=[],
        returns=None
    )

    def check():
        assert len(funcdef.body) is 2
        assert type(funcdef.body[0]) is ast.Pass
        assert type(funcdef.body[1]) is ast.Pass

    replace_at(1, funcdef, ast.Pass())
    check()
    replace_at(3, funcdef, ast.Pass())
    check()

# Generated at 2022-06-23 23:47:07.370619
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a = 1\n')
    Insert(2, tree)

    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1)), Num(n=2)])"  # noqa



# Generated at 2022-06-23 23:47:13.934669
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # test for normal case
    source = ast.parse('if True: pass')
    closest_parent_of = get_closest_parent_of(source, source.body[0].body[0],
                                              ast.If)
    assert isinstance(closest_parent_of, ast.If)
    assert source == closest_parent_of

    # test for exception
    with pytest.raises(NodeNotFound):
        get_closest_parent_of(source, source.body[0].body[0], ast.Expr)



# Generated at 2022-06-23 23:47:17.808239
# Unit test for function replace_at
def test_replace_at():
    f = ast.parse('a = 1').body[0]  # type: ignore
    assert f.value.n == 1
    replace_at(1, f, ast.Num(3))
    assert f.value.n == 3

test_replace_at()

# Generated at 2022-06-23 23:47:28.588879
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        """if a:
            a = 1
        elif b:
            b = 2
        else:
            c = 3

        d = a + b + c
        """
    )

    parent, _ = get_non_exp_parent_and_index(tree, tree.body[0])

    assert parent is tree

    parent, _ = get_non_exp_parent_and_index(tree, tree.body[1])

    assert isinstance(parent, ast.If)

    parent, _ = get_non_exp_parent_and_index(tree, tree.body[1].body[0].value)

    assert isinstance(parent, ast.Assign)


# Generated at 2022-06-23 23:47:33.697637
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        _fields = ('body',)

    tree = A(body=[])

    class B(ast.AST):
        _fields = ('a',)

    class C(ast.AST):
        _fields = ('a',)

    class D(ast.AST):
        _fields = ('a',)

    insert_at(0, tree, B(a=3))
    insert_at(0, tree, C(a='test'))
    insert_at(0, tree, D(a=True))

    assert tree == A(body=[D(a=True), C(a='test'), B(a=3)])

# Generated at 2022-06-23 23:47:34.570523
# Unit test for function get_parent

# Generated at 2022-06-23 23:47:39.280397
# Unit test for function replace_at
def test_replace_at():
    t = ast.parse('def f(): pass')
    parent, index = get_non_exp_parent_and_index(t, t.body[0].body[0])
    replace_at(index, parent, ast.Pass())

    assert isinstance(parent.body[0], ast.Pass)

# Generated at 2022-06-23 23:47:45.688053
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Case 1
    assert isinstance(get_closest_parent_of(None, None, None), ast.Module)
    # Case 2
    assert isinstance(get_closest_parent_of(None, None, ast.Module), ast.Module)
    # Case 3
    node = get_closest_parent_of(None, None, ast.Module)
    assert isinstance(node, ast.Module)



# Generated at 2022-06-23 23:47:49.638264
# Unit test for function find
def test_find():
    from ..examples.function_pass import get_example_ast
    node_list = [
        node for node in find(get_example_ast(), ast.Call)
        if 'math' in node.func.id
    ]
    assert len(node_list) == 3

# Generated at 2022-06-23 23:47:53.734532
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def test():\n  x = 1\n  y = 2\n  x+y')
    parents = []
    for child in tree.body[0].body:
        parents.append(get_parent(tree, child))

    assert parents[0] == parents[1] == tree.body[0]
    assert parents[2] == tree



# Generated at 2022-06-23 23:47:59.658093
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Arrange
    tree = ast.parse('for i in range(10):\n    print(i)\nprint(10)')

    # Act
    parent, index = get_non_exp_parent_and_index(tree,
                                                 tree.body[0].body[0].value)

    # Assert
    assert isinstance(parent, ast.For)
    assert index == 0

# Generated at 2022-06-23 23:48:00.691710
# Unit test for function find

# Generated at 2022-06-23 23:48:01.991579
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-23 23:48:07.003114
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''class Example:
    x = 0
    y = 1''')

    node = tree.body[0].body[0].value

    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.ClassDef)
    assert index == 0


# Generated at 2022-06-23 23:48:09.885149
# Unit test for function find
def test_find():
    tree = ast.parse('help()')
    funcs = list(find(tree, ast.Call))
    assert len(funcs) == 1
    assert funcs[0].func.id == 'help'

# Generated at 2022-06-23 23:48:21.614056
# Unit test for function replace_at
def test_replace_at():
    # Example tree
    tree = ast.parse('a = 1\nb = 2\na = 3\n')
    
    # Replace first statement in body of module
    # with a variable definition
    replace_at(0, tree, ast.Assign(targets=[ast.Name(id='c', ctx=ast.Store())],
                                   value=ast.Num(n=4)))
    assert ast.dump(tree) == '''Module(body=[Assign(targets=[Name(id='c', ctx=Store())], value=Num(n=4)), Assign(targets=[Name(id='b', ctx=Store())], value=Num(n=2)), Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=3))])'''

# Generated at 2022-06-23 23:48:29.598178
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""
if test:
    if test2:
        x = 1
    else:
        x = 2
    y = 1
    x = 5
else:
    x = 5
    y = 1
    x = 5""")
    insert_at(2, get_parent(tree, tree.body[0].body[0]), ast.parse("""
        print(1)
    """).body[0])

    assert ast.dump(tree) == ast.dump(ast.parse("""
if test:
    if test2:
        x = 1
    else:
        x = 2
    print(1)
    y = 1
    x = 5
else:
    x = 5
    y = 1
    x = 5""")), ast.dump(tree)

# Generated at 2022-06-23 23:48:30.572395
# Unit test for function insert_at

# Generated at 2022-06-23 23:48:39.604081
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""def f(x):
    print(x)
    if x>1:
        print(x)
    else:
        return x
""") # yapf: disable
    code_tree_object = ast.walk(tree)
    code_node_1 = next(code_tree_object)
    code_node_2 = next(code_tree_object)
    x = ast.Name("x", ast.Load())
    node_store = [x, x, x]
    assert get_closest_parent_of(tree, node_store[0], ast.FunctionDef) is code_node_1
    assert get_closest_parent_of(tree, node_store[1], ast.FunctionDef) is code_node_1

# Generated at 2022-06-23 23:48:47.941743
# Unit test for function insert_at
def test_insert_at():
    import astor
    import inspect
    ast_tree = astor.code_to_ast.code_to_ast(inspect.getsource(test_insert_at))

    def_node = list(find(ast_tree, ast.FunctionDef))[0]
    imp_node = list(find(ast_tree, ast.Import))[0]

    insert_at(0, def_node, imp_node)

    assert astor.to_source(ast_tree).splitlines()[0] == 'import astor'



# Generated at 2022-06-23 23:48:54.686593
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = 'def foo(a, b, c): pass'
    tree = ast.parse(source)
    node = tree.body[0].body[0]

    parent, index_ = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index_ == 0



# Generated at 2022-06-23 23:49:02.351887
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_tree = ast.parse('if a:\n  print("a")\n  print("b")')
    if_node = test_tree.body[0]
    node_to_insert = test_tree.body[0].body[0]

    non_exp_parent, index = get_non_exp_parent_and_index(test_tree,
                                                         node_to_insert)

    assert non_exp_parent == if_node
    assert index == 0

# Generated at 2022-06-23 23:49:06.706738
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test get_non_exp_parent_and_index function."""
    import astor, inspect

    code = inspect.getsource(get_non_exp_parent_and_index)
    print(code)
    cu = ast.parse(code)
    print(astor.dump(cu))

    for node in ast.walk(cu):
        if hasattr(node, 'body') and len(node.body) > 0:
            print(node.body)
            for child in node.body:
                parent, index = get_non_exp_parent_and_index(cu, child)
                print(index, parent)
            print()

# Generated at 2022-06-23 23:49:13.955858
# Unit test for function insert_at
def test_insert_at():
    from .test_nodes import fake_node_list
    from .test_nodes import fake_body

    insert_at(0, fake_body, fake_node_list[0])
    insert_at(1, fake_body, fake_node_list[1])
    insert_at(10, fake_body, fake_node_list[2])

    # make sure that it works even if index is greater than the
    # number of elements
    assert fake_body.body[0] == fake_node_list[0]
    assert fake_body.body[1] == fake_node_list[1]
    assert fake_body.body[2] == fake_node_list[2]



# Generated at 2022-06-23 23:49:24.677293
# Unit test for function get_parent
def test_get_parent():
    # Creating tree
    tree = ast.parse("def get_parent(tree, node):\n    for child in ast.walk(tree):\n\treturn child")
    # Parent of the whole tree should be None
    test = get_parent(tree, tree)
    assert test is None
    # Child 1 is the FunctionDef node
    child1 = get_parent(tree, tree.body[0])
    assert child1 == tree
    # Child 2 is the Return node
    child2 = get_parent(tree, tree.body[0].body[1])
    assert child2 == tree.body[0]
    # Child 4 is the Name node
    child4 = get_parent(tree, tree.body[0].body[1].value)
    assert child4 == tree.body[0].body[1]
    # Child 5 is

# Generated at 2022-06-23 23:49:33.923143
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class Test(ast.AST):
        _fields = ('a', 'body')
    class Exp(ast.AST):
        _fields = ('a',)
    class Call(ast.AST):
        _fields = ('a',)

    # Test tree
    node = Call(a=3)
    node2 = Test(a=1, body=[Call(a=4), node])
    tree = Test(a=1, body=[node2])
    parent, index = get_non_exp_parent_and_index(tree, node)
    print(parent, parent.body, index)



# Generated at 2022-06-23 23:49:40.801507
# Unit test for function find
def test_find():
    import astor

    tree = ast.parse("""def test():
        a = 1
        b = 2
        c = 3""")
    assert list(find(tree, ast.Name)) == ast.get_names(tree)
    assert list(find(tree, ast.Assign)) == ast.get_assignments(tree)
    assert list(find(tree, ast.FunctionDef)) == ast.get_function_definitions(tree)
    assert list(find(tree, ast.Expr)) == ast.get_expressions(tree)



# Generated at 2022-06-23 23:49:48.529201
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('if True:\n\tcall()\n\tresult = 1+1')
    node = list(find(tree, ast.Name))[0]
    assert get_closest_parent_of(tree, node, ast.If) == tree.body[0]
    assert get_closest_parent_of(tree, node, ast.Module) == tree
    assert get_closest_parent_of(tree, node, ast.FunctionDef) == None


# Generated at 2022-06-23 23:49:54.161575
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast_parse("""for i in range(1):
        if i > 2:
            print('test')""") # test

    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == \
        (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1]) == \
        (tree.body[0], 1)

# Generated at 2022-06-23 23:49:56.853159
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('cmist()')
    node = tree.body[0].value.args[0].func
    parent_node, index = get_non_exp_parent_and_index(tree, node)
    assert(parent_node == tree.body[0].value)
    assert(index == 0)


# Generated at 2022-06-23 23:50:01.466845
# Unit test for function find
def test_find():
    tree = ast.parse('x = 1 + 1')

    assert list(find(tree, ast.BinOp))[0].__class__ == ast.BinOp
    assert list(find(tree, ast.Name))[0].__class__ == ast.Name



# Generated at 2022-06-23 23:50:08.801041
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

    class TestNode(ast.AST):
        _fields = ('test',)

    tree = ast.Module(body=[
        ast.FunctionDef(name='test', body=[
            ast.Return(value=TestNode(test=123))
        ])
    ])
    module = astor.Module(tree=tree)

    tree = astor.parse_file(module.file)
    node = find(tree, TestNode).__next__()
    parent = get_closest_parent_of(tree, node, ast.Module)
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-23 23:50:17.167431
# Unit test for function insert_at
def test_insert_at():
    # TEST1: insert a node into empty body
    tree = ast.parse("def foo():\n    pass")
    def_stmt = tree.body[0]
    pass_stmt = def_stmt.body[0]
    new_stmt = ast.Name(id="bar")
    insert_at(0, pass_stmt, new_stmt)
    assert(ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwarg=None, kwonlyargs=[], defaults=[], kw_defaults=[]), body=[Name(id='bar'), Pass()], decorator_list=[], returns=None)])")

    # TEST2: insert node at the beginning

# Generated at 2022-06-23 23:50:27.451159
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a, _ = 10, 20')
    _build_parents(tree)

    # get the parent for the first assignment
    parent = get_parent(tree, tree.body[0].targets[0])
    # parent should be the ast.Assign node
    assert isinstance(parent, ast.Assign)

    # get the parent for the second assignment
    parent = get_parent(tree, tree.body[0].targets[1])
    # parent should be the ast.Assign node
    assert isinstance(parent, ast.Assign)

    # get the parent for the module
    parent = get_parent(tree, tree)
    # parent should be the 'None'
    assert parent is None

# Generated at 2022-06-23 23:50:36.674242
# Unit test for function replace_at
def test_replace_at():
    root = ast.parse("""def f():
    def g():
        return
        print(0)
    def h():
        return
        print(0)
    return""")
    func_call = ast.parse("print(1)").body[0]  # type: ignore
    index_in_parent = root.body[0].body[1].body.index(
        root.body[0].body[1].body[0])
    assert index_in_parent == 0
    replace_at(index_in_parent, root.body[0].body[1], func_call)
    # print(ast.dump(root))

# Generated at 2022-06-23 23:50:37.770157
# Unit test for function get_parent
def test_get_parent():
    # TODO: Add unit test for this function
    pass


# Generated at 2022-06-23 23:50:48.313536
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('commands.Client.command()')
    node_1 = tree.body[0].value.func  # .command()
    node_2 = node_1.value  # Client
    node_3 = node_2.value  # commands
    expected_1 = (tree.body[0], 0)  # command = commands.Client.command()
    assert get_non_exp_parent_and_index(tree, node_1) == expected_1
    expected_2 = (node_1, 0)  # Client.command()
    assert get_non_exp_parent_and_index(tree, node_2) == expected_2
    expected_3 = (node_2, 0)  # commands.Client()
    assert get_non_exp_parent_and_index(tree, node_3) == expected

# Generated at 2022-06-23 23:50:52.975489
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    src = """
    def foo():
    """

    src_ast = ast.parse(src)
    node = src_ast.body[0]

    parent, index = get_non_exp_parent_and_index(src_ast, node)
    assert parent == src_ast
    assert index == 0

# Generated at 2022-06-23 23:50:57.957927
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert isinstance(get_non_exp_parent_and_index(
        ast.parse(
            '''
if True:
    x = 1
    if False:
        pass
    x = 2
    x = 3
            '''),
        ast.parse('x = 2').body[0]).left,
        ast.Name)

# Generated at 2022-06-23 23:51:02.987415
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('0 + 1')
    node = tree.body[0].value.left
    tree.body[0].value.left = ast.Num(n=2)
    assert tree.body[0].value.left.n == 2

    replace_at(0, tree.body[0].value, node)
    assert tree.body[0].value.left.n == 0

# Generated at 2022-06-23 23:51:13.819443
# Unit test for function replace_at
def test_replace_at():
    # Create AST and parent node
    tree = ast.parse('def test(): pass')
    parent = tree.body[0]

    # Ensure parent body is empty
    assert parent.body == []

    # Add some body items
    parent.body.append(ast.parse('a = 1').body[0])
    parent.body.append(ast.parse('b = 2').body[0])
    parent.body.append(ast.parse('c = 2').body[0])

    # Ensure parent body has 3 items
    assert len(parent.body) == 3

    # Replace first item with a single node
    node = ast.parse('d = 3').body[0]
    replace_at(0, parent, node)

    # Ensure we have now 3 items
    assert len(parent.body) == 3

    # Ensure first item is node

# Generated at 2022-06-23 23:51:17.434861
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("b(a(0))")
    node = tree.body[0].func
    parent, index = get_non_exp_parent_and_index(tree, node)
    expected_parent = tree
    expected_index = 0
    assert(parent == expected_parent)
    assert(index == expected_index)

# Generated at 2022-06-23 23:51:22.627152
# Unit test for function get_parent
def test_get_parent():
    """Ensure that get_parent works properly."""
    tree = ast.parse('def foo():\n  return 1 + 1')
    parent = get_parent(tree, tree.body[0].body[0])
    assert parent is tree.body[0].body



# Generated at 2022-06-23 23:51:33.725897
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import ast_builder

    tree = ast_builder.build('''
            def func():
                a = 2 + 3

                def func2():
                    pass

                    def func3():
                        b = a
                        pass
                ''')
    func3 = get_closest_parent_of(tree, tree.body[0].body[2].body[2],
                                   ast.FunctionDef)

    a = tree.body[0].body[1].value.right  # type: ast.AST
    a_parent, a_index = get_non_exp_parent_and_index(tree, a)

    assert a_parent == tree.body[0].body[1]
    assert a_index == 1

    b = func3.body[1].value  # type: ast.AST
    b_parent, b

# Generated at 2022-06-23 23:51:36.674438
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("1 + 2")
    node = tree.body[0].value.left
    assert get_parent(tree, node) == tree.body[0].value


# Generated at 2022-06-23 23:51:44.830403
# Unit test for function insert_at
def test_insert_at():
    a = ast.parse("""
    for i in range(10):
        print(i)
    """)
    u = ast.parse("print('a')")

    assert len(a.body) == 1
    assert len(a.body[0].body) == 1
    assert type(a.body[0].body[0]) == ast.Expr

    insert_at(0, a.body[0], u)

    assert len(a.body) == 1
    assert len(a.body[0].body) == 2
    assert type(a.body[0].body[0]) == ast.Expr
    assert type(a.body[0].body[1]) == ast.Expr


# Generated at 2022-06-23 23:51:50.064418
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('''
    class A():
        def f():
            pass
    ''')
    insert_at(1, tree, ast.Expr(value=ast.Num()))

    s = ast.Module(body=[
        ast.ClassDef(name='A',
                     body=[ast.Pass(),
                           ast.Expr(value=ast.Num())],
                     decorator_list=[]),
        ast.Expr(value=ast.Num()),
    ])

    assert ast.dump(tree) == ast.dump(s)



# Generated at 2022-06-23 23:51:58.010731
# Unit test for function get_parent
def test_get_parent():
    # Setup
    a = ast.Module()
    b = ast.Expr()
    c = ast.Name()
    d = ast.Expr()
    a.body.append(b)
    b.value = c
    a.body.append(d)
    c.id = 'test_get_parent'

    # Test
    assert(get_parent(a, b) == a)
    assert(get_parent(a, c) == b)
    assert(get_parent(a, d) == a)

# Generated at 2022-06-23 23:52:04.780926
# Unit test for function find
def test_find():
    tree = ast.parse('a, b, c')
    a, b, c = [node.id for node in find(tree, ast.Name)]
    assert all(var == var.id for var in (a, b, c))

    with pytest.raises(NodeNotFound):
        get_parent(tree, 1)

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, 1, ast.Name)

    with pytest.raises(NodeNotFound):
        get_non_exp_parent_and_index(tree, 1)

# Generated at 2022-06-23 23:52:07.897056
# Unit test for function get_parent
def test_get_parent():
    class TestClass:
        def test_method(self):
            pass

    test_method_node = ast.parse('def test_method(self): pass').body[0]
    get_parent(test_method_node, test_method_node.body[0])
    assert True

# Generated at 2022-06-23 23:52:09.533194
# Unit test for function insert_at
def test_insert_at():
    # TODO: create unit tests
    pass

# Generated at 2022-06-23 23:52:20.742911
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    root = ast.parse("""
[
    {
        'a': 'hello',
        'b': [1, 2, 3]
    },
    [
        {
            'foo': 'bar'
        }
    ]
]
""")
    assert isinstance(get_closest_parent_of(root, root.body[0].value.values[0],
                                            ast.List), ast.List)
    assert isinstance(get_closest_parent_of(root, root.body[0].value.values[0],
                                            ast.Dict), ast.Dict)
    assert isinstance(get_closest_parent_of(root, root.body[0].value.values[0],
                                            ast.Module), ast.Module)

# Generated at 2022-06-23 23:52:32.167436
# Unit test for function insert_at
def test_insert_at():
    def test_one():
        def foo():
            pass

        tree = ast.parse(dedent(foo.__doc__))
        node = ast.FunctionDef('bar', ast.Name('foo', ast.Load()), [], [], None,
                               [])
        insert_at(1, tree.body[1], node)
        print('\n'.join(ast.dump(tree).split('\n')[1:]))

    def test_two():
        def foo():
            pass

        tree = ast.parse(dedent(foo.__doc__))
        node = ast.FunctionDef('bar', ast.Name('foo', ast.Load()), [], [], None,
                               [])
        insert_at(1, tree.body[0], node)

# Generated at 2022-06-23 23:52:35.171266
# Unit test for function find
def test_find():
    tree = ast.parse("""
    a = 0
    a += 1
    a += 2
    a -= 1
    """)
    result = list(find(tree, ast.Assign))
    assert len(result) == 1
    result = list(find(tree, ast.AugAssign))
    assert len(result) == 3
    result = list(find(tree, ast.Add))
    assert len(result) == 2
    result = list(find(tree, ast.Sub))
    assert len(result) == 1


# Generated at 2022-06-23 23:52:38.255524
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .code_gen import parse_string
    from .contexts import IfContext, AssignContext
    from .literals import LocalVar, IntegerLiteral
    from .nodes import IfNode, AssignNode


# Generated at 2022-06-23 23:52:48.164106
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a = ast.parse("""if 1:
        if 2:
            if 2:
                a = 3
            else:
                pass
        else:
            pass""")
    as1 = a.body[0]
    as2 = as1.body[0]
    as3 = as2.body[0]
    as4 = a.body[1]
    assert get_closest_parent_of(a, as4.body[0], ast.FunctionDef) == a
    assert get_closest_parent_of(a, as4.body[0], ast.If) == as4
    assert get_closest_parent_of(a, as4.body[0], ast.Body) == as4

# Generated at 2022-06-23 23:52:55.207225
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import sys
    sys.path.insert(0, "./tests")
    from test_utils import get_ast_from_source

    tree = get_ast_from_source('class A: "a"')
    closest_class = get_closest_parent_of(tree, tree.body[0].bases[0], ast.ClassDef)
    assert isinstance(closest_class, ast.ClassDef)

