

# Generated at 2022-06-23 23:43:03.833923
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # tests if vars are correct
    if not get_closest_parent_of.__code__.co_varnames == ('tree', 'node',
                                                          'type_'):
        raise ValueError('vars are not correct')
    # tests if function works with normal value
    try:
        tree = ast.parse('''
                        def a():
                            pass
                        ''')
        node = get_closest_parent_of(tree, tree.body[0], ast.FunctionDef)
        assert isinstance(node, ast.FunctionDef)
    except:
        raise ValueError('Functions does not work with normal inputs')
    # tests if function works with normal value

# Generated at 2022-06-23 23:43:06.613785
# Unit test for function insert_at
def test_insert_at():
    import random
    x = 2
    y = random.randint(0, 4)
    if x == y:
        print(x)
    else:
        print(y)


# Generated at 2022-06-23 23:43:09.088122
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Unit test for get_closest_parent_of."""

# Generated at 2022-06-23 23:43:12.459219
# Unit test for function replace_at
def test_replace_at():
    l = [1, 2, 3]
    replace_at(0, l, 5)
    assert l == [5, 2, 3]

# Generated at 2022-06-23 23:43:14.561412
# Unit test for function find
def test_find():
    tree = ast.parse('def test():\n    pass')
    assert len(list(find(tree, ast.FunctionDef))) == 1


# Generated at 2022-06-23 23:43:25.771772
# Unit test for function replace_at
def test_replace_at():
    with open('tests/fixme_test.py') as f:
        python_file = f.read()
        tree = ast.parse(python_file)
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == 'my_function':
            parent = node
            break
    else:
        assert False
    for node in ast.walk(tree):
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Name):
            expr_node = node
            break
    else:
        assert False
    replace_at(0, parent, [expr_node])
    assert parent.body[0] is expr_node
    replace_at(0, parent, [ast.parse('print("hi")').body[0]])
    assert parent

# Generated at 2022-06-23 23:43:31.875194
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def a():\n    pass')

    # First node of a tree is module, so it fails to get parent
    assert get_non_exp_parent_and_index(tree, tree.body[0]) == (
        tree, 0,
    )

    # Get non exp parents for inner node
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (
        tree.body[0], 0
    )



# Generated at 2022-06-23 23:43:33.320355
# Unit test for function get_parent
def test_get_parent():
    import ast
    import astunparse

# Generated at 2022-06-23 23:43:44.730959
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('if True:\n    pass', '<test>')
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent is tree
    assert index == 0

    tree = ast.parse('if True: pass', '<test>')
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent is tree
    assert index == 0

    tree = ast.parse('if True: pass', '<test>')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent is node
    assert index == 0

# Generated at 2022-06-23 23:43:47.639501
# Unit test for function find
def test_find():
    tree = ast.parse('abc = 1; x = abc')
    nodes = find(tree, ast.Store)
    assert all(isinstance(node, ast.Store) for node in nodes)

# Generated at 2022-06-23 23:43:51.077317
# Unit test for function replace_at
def test_replace_at():
    """Test replace_at."""
    tree = ast.parse("if x == 2: pass")
    if_body = tree.body[0].body
    replace_at(0, if_body, ast.parse("pass").body)
    assert isinstance(if_body.body[0], ast.Pass)

# Generated at 2022-06-23 23:43:56.055010
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('1 + 2')
    num = tree.body[0].value.right
    op = tree.body[0].value.op
    assert get_parent(tree, num) == tree.body[0].value
    assert get_parent(tree, op) == tree.body[0].value


# Generated at 2022-06-23 23:44:05.871304
# Unit test for function insert_at
def test_insert_at():
    # Insert at beginning of list
    tree = ast.parse("a_list = []")
    index = 0
    parent = tree.body[0]
    node1 = ast.parse("x = 2").body[0]
    node2 = ast.parse("y = 3").body[0]

    insert_at(index, parent, node1)
    insert_at(index, parent, node2)

    expected_list = [node2, node1, ast.parse("a_list = []").body[0]]

    assert parent.body == expected_list

    # Insert in middle of list
    tree = ast.parse("a_list = [1, 2, 3, 4]")
    index = 2
    parent = tree.body[0]
    node1 = ast.parse("x = 2").body[0]
    node2

# Generated at 2022-06-23 23:44:11.643405
# Unit test for function insert_at
def test_insert_at():
    import astunparse
    tree = ast.parse('class Test: pass')
    test_class = tree.body[0]
    insert_at(0, test_class, ast.Pass())
    insert_at(1, test_class, ast.Pass())
    insert_at(2, test_class, ast.Pass())
    insert_at(3, test_class, ast.Pass())
    assert astunparse.unparse(tree) == \
        '''class Test:
    pass
    pass
    pass
    pass
    pass
'''



# Generated at 2022-06-23 23:44:12.993332
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:44:23.575543
# Unit test for function replace_at
def test_replace_at():
    import unittest

    class TestReplaceAt(unittest.TestCase):
        def test_replace_node(self):
            mod = ast.parse('1')
            replace_at(0, mod, ast.Num(4))
            self.assertEqual(
                ast.dump(mod),
                'Module(body=[Num(n=4)])'
            )

        def test_replace_with_multiple_nodes(self):
            mod = ast.parse('1')
            replace_at(0, mod, [ast.Num(4), ast.Num(5)])
            self.assertEqual(
                ast.dump(mod),
                'Module(body=[Num(n=4), Num(n=5)])'
            )

    unittest.main()

# Generated at 2022-06-23 23:44:25.476087
# Unit test for function find

# Generated at 2022-06-23 23:44:29.142729
# Unit test for function get_parent
def test_get_parent():
    input_code = '''
    def func(a, b):
        b = a + b
        return b
    '''
    tree = ast.parse(input_code)
    # Find b node
    node = [node for node in ast.walk(tree) if node.id == 'b'][0]

    # Find parent of b node
    parent = get_parent(tree, node)
    # Check that parent node is BinOp
    assert isinstance(parent, ast.BinOp)

# Generated at 2022-06-23 23:44:32.906574
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""
        from typing import List

        def test() -> List[int]:
            pass
    """)
    imports = tree.body[:1]
    function = tree.body[1]

    insert_at(0, function.body, imports)

    assert ast.dump(function.body) == \
        "['from typing import List\\n', 'pass\\n']"



# Generated at 2022-06-23 23:44:34.123122
# Unit test for function get_parent

# Generated at 2022-06-23 23:44:45.071168
# Unit test for function insert_at
def test_insert_at():
    import typed_ast.ast3 as ast

    parent = ast.Module(
        body=[
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=1)
            ),
            ast.Assign(
                targets=[ast.Name(id='b', ctx=ast.Store())],
                value=ast.Num(n=2)
            )
        ]
    )    

    insert_at(0, parent, ast.Assign(
                targets=[ast.Name(id='c', ctx=ast.Store())],
                value=ast.Num(n=3)
            ))
    assert parent.body[0].targets[0].id == 'c'
    assert parent.body[1].targets[0].id

# Generated at 2022-06-23 23:44:47.136191
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def f():\n    x = 1')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent == tree
    assert index == 0



# Generated at 2022-06-23 23:44:48.521585
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''{}''')
    _build_parents(tree)
    assert _parents[tree.body[0]] == tree


# Generated at 2022-06-23 23:44:54.531805
# Unit test for function find
def test_find():
    import unittest

    class Test(unittest.TestCase):
        def test_find_method(self):
            tree = ast.parse('''
                class Test(object):
                    def __init__(self):
                        pass

                    def test(self):
                        pass
            ''')
            methods = list(find(tree, ast.FunctionDef))
            self.assertTrue(len(methods) > 0)

            for method in methods:
                self.assertEqual('FunctionDef', method.__class__.__name__)

    unittest.main(Test)

# Generated at 2022-06-23 23:45:03.509216
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class A(ast.AST): pass
    class B(ast.AST): pass
    class C(ast.AST): pass

    a = A()
    b = B()
    c = C()
    c2 = C()
    c3 = C()
    b.node = a
    a.node = c
    c.node = c2
    c2.node = c3

    assert get_closest_parent_of(c3, c3, A) == a
    assert get_closest_parent_of(c3, c3, B) == b
    assert get_closest_parent_of(c3, c3, C) == c

# Generated at 2022-06-23 23:45:11.187434
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from sys import argv
    with open(__file__) as f:
        tree = ast.parse(f.read())

    # It should be possible to find an index of an argument
    # in a function call
    assert get_non_exp_parent_and_index(tree, argv) == (
        tree.body[0].value, 0)

    # It should be possible to find an index of a function definition
    # in a module body
    assert get_non_exp_parent_and_index(tree, test_get_non_exp_parent_and_index) \
        == (tree.body, 1)

if __name__ == "__main__":
    test_get_non_exp_parent_and_index()

# Generated at 2022-06-23 23:45:13.651035
# Unit test for function find
def test_find():
    assert isinstance(next(find(ast.parse(text='1 + 1'), ast.BinOp)),
                      ast.BinOp)

# Generated at 2022-06-23 23:45:15.370366
# Unit test for function find
def test_find():  # pragma: no cover
    """Unit test for find."""
    from typed_ast import convert


# Generated at 2022-06-23 23:45:24.789433
# Unit test for function get_parent
def test_get_parent():
    """Function: test_get_parent()."""
    # TODO: использовать предложенный выше биндинг

    # tree = parse("for i in range(10):\n\tprint(i)").body[0]
    tree = ast.parse("for i in range(10):\n\tprint(i)").body[0]

    assert(get_parent(tree, tree) == None)
    assert(get_parent(tree, tree.orelse[0]) == tree)
    assert(get_parent(tree, tree.body[0]) == tree)

# Generated at 2022-06-23 23:45:25.414235
# Unit test for function insert_at
def test_insert_at():
    import astor

# Generated at 2022-06-23 23:45:32.782426
# Unit test for function get_parent
def test_get_parent():
    ast_tree = ast.parse('def a():\n\tpass')
    assert get_parent(ast_tree, ast_tree.body[0]).__class__ == ast.Module
    assert ast_tree.body[0] == ast.FunctionDef(name='a',
                                               args=ast.arguments(
                                                   args=[],
                                                   vararg=None,
                                                   kwonlyargs=[],
                                                   kw_defaults=[],
                                                   kwarg=None,
                                                   defaults=[]),
                                               body=[ast.Pass()],
                                               decorator_list=[])
    assert get_parent(ast_tree, ast_tree.body[0].body[0]).__class__ == \
        ast.FunctionDef

# Generated at 2022-06-23 23:45:33.780076
# Unit test for function replace_at
def test_replace_at():
    # TODO
    pass

# Generated at 2022-06-23 23:45:36.409329
# Unit test for function get_parent
def test_get_parent():
    assert 1 == 1
    # FIXME: Add unit test for function get_parent
    pass


# Generated at 2022-06-23 23:45:43.048870
# Unit test for function find
def test_find():
    """ Test case for function find. """
    node = ast.parse('if 1 == 1: pass')
    node = find(node, lambda x: True).__next__()
    assert type(node) == ast.If
    assert node.test.left.n == 1
    assert node.test.ops[0].__class__ == ast.Eq
    assert node.test.comparators[0].n == 1
    print("find() pass")


# Generated at 2022-06-23 23:45:44.065837
# Unit test for function insert_at
def test_insert_at():
    from .utils import count_empty_lines

# Generated at 2022-06-23 23:45:48.485314
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = '''
    if a and b:
        print(c)
    '''

    tree = ast.parse(code, mode='exec')
    print_node = get_closest_parent_of(tree, tree.body[0].body[0], ast.Print)
    assert isinstance(print_node, ast.Print)



# Generated at 2022-06-23 23:45:49.417987
# Unit test for function replace_at
def test_replace_at():
    import astor


# Generated at 2022-06-23 23:45:54.405474
# Unit test for function find
def test_find():
    from ..ast_util import create_ast
    from .util import assert_contains_all
    from .types import for_
    code = """
    for i in range(10):
        pass
    """
    tree = create_ast(code)
    found_nodes = find(tree, for_)
    assert_contains_all(tree, found_nodes)

# Generated at 2022-06-23 23:46:01.783154
# Unit test for function replace_at
def test_replace_at():
    """Unit test for function replace_at."""
    module = ast.parse('a=1; def f(): return 2')

    def_parent = get_parent(module, module.body[1])

    replace_at(0, def_parent, ast.Return(ast.Num(2)))

    assert ast.dump(module) == '''
Module(body=[Assign(targets=[Name(id='a', ctx=Store())],
                    value=Num(n=1)),
              FunctionDef(name='f',
                          args=arguments(args=[],
                                         vararg=None,
                                         kwonlyargs=[],
                                         kw_defaults=[],
                                         kwarg=None,
                                         defaults=[]),
                          body=[Return(value=Num(n=2))])])
''' 

# Generated at 2022-06-23 23:46:03.290273
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:46:04.257235
# Unit test for function replace_at

# Generated at 2022-06-23 23:46:11.486195
# Unit test for function replace_at
def test_replace_at():
    class A:
        def __init__(self):
            self.body = []
    
    a = A()
    a.body = [1, 2, 3]
    replace_at(1, a, [4, 5, 6])
    assert a.body == [1, 4, 5, 6, 3]
    replace_at(1, a, [7, 8])
    assert a.body == [1, 7, 8, 6, 3]
    replace_at(4, a, [9])
    assert a.body == [1, 7, 8, 6, 9]


# Generated at 2022-06-23 23:46:21.326709
# Unit test for function get_parent
def test_get_parent():
    # Unit test for function get_parent
    # Given
    class Tower(ast.AST):
        _fields = ('body', 'type_args')
        body = [("Module", ast.Module)]
        type_args = None

    class Module(ast.AST):
        _fields = ('body',)
        body = [("ClassDef", ast.ClassDef)]

    class ClassDef(ast.AST):
        _fields = ("name", "bases", "keywords", "starargs", "kwargs", "body")
        name = "MyClass"
        bases = []
        keywords = []
        starargs = None
        kwargs = None
        body = []

    # When
    class_def = ClassDef(body=[])
    module = Module(body=[class_def])
    tower = Tower(body=[module])

   

# Generated at 2022-06-23 23:46:24.599512
# Unit test for function find
def test_find():
    import astor
    nodes = []
    tree = ast.parse("1 + 2")
    for node in find(tree, ast.Name):
        nodes.append(astor.to_source(node))

    assert nodes == ["2"]


# Generated at 2022-06-23 23:46:25.450357
# Unit test for function find

# Generated at 2022-06-23 23:46:26.222048
# Unit test for function replace_at

# Generated at 2022-06-23 23:46:29.793667
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    function_def = ast.parse('def foo(x):a = x').body[0]
    assert get_non_exp_parent_and_index(function_def,
                                        ast.parse('a = x').body[0]) == \
        (function_def, 0)

# Generated at 2022-06-23 23:46:40.281637
# Unit test for function insert_at
def test_insert_at():
    dummy_parent = ast.Module(
        body=[ast.Expr(value=ast.Str(s='test_body_item_0')),
              ast.Expr(value=ast.Str(s='test_body_item_1')),
              ast.Expr(value=ast.Str(s='test_body_item_2'))])
    dummy_child = ast.Expr(value=ast.Str(s='test_child'))
    insert_at(1, dummy_parent, dummy_child)
    assert dummy_parent.body[1].value.s == 'test_child'
    assert dummy_parent.body[2].value.s == 'test_body_item_1'
    assert dummy_parent.body[3].value.s == 'test_body_item_2'



# Generated at 2022-06-23 23:46:45.993290
# Unit test for function find
def test_find():
    class A: pass
    class B: pass
    class C(A): pass
    class D(A): pass
    class E(B): pass
    class F(C): pass

    assert set(find([
        A(),
        B(),
        C(),
        D(),
        E(),
        F()
    ], type(A))) == set([
        A(),
        C(),
        D()
    ])

# Generated at 2022-06-23 23:46:56.601696
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    Program = ast.Module
    ExpressionStmt = ast.Expr
    ClassDef = ast.ClassDef
    FunctionDef = ast.FunctionDef
    Return = ast.Return
    Attribute = ast.Attribute
    Name = ast.Name

    tree = Program([
        ClassDef(
            'A', [], [], [], [],
            [FunctionDef(
                'f', [], [],
                [Return(Attribute(Name('x', Load()), 'y', Load()))],
                [], None, None
            )], [], None
        ),
        ExpressionStmt(Name('x', Load()))
    ])

    parent, index = get_non_exp_parent_and_index(tree,
                                                 tree.body[0].body[0].body[0])

    assert isinstance(parent, ClassDef)


# Generated at 2022-06-23 23:46:58.013105
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Arrange
    import astor  # noqa: F401

# Generated at 2022-06-23 23:47:05.704168
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse('(a+b)*(c+d)')
    node = ast.Expression(node.body)
    _build_parents(node)

    assert isinstance(get_parent(node, node.body), ast.Expression)
    assert isinstance(get_parent(node, node.body.left), ast.BinOp)
    assert isinstance(get_parent(node, node.body.right), ast.BinOp)
    assert isinstance(get_parent(node, node.body.right.left), ast.Name)

# Generated at 2022-06-23 23:47:12.381390
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .helpers import parse, build
    code = """
    class Klass:
        def methood(self):
            return 42
    """
    tree = parse(code)
    func = find(tree, ast.FunctionDef).__next__()
    node = func.body[0]
    cls = get_closest_parent_of(tree, node, ast.ClassDef)
    assert code.strip() == build(tree).strip()
    assert cls.name == 'Klass'

# Generated at 2022-06-23 23:47:16.328323
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
        def test():
            x = 1 + 2
    """)
    node = tree.body[0].body[0]
    assert(get_closest_parent_of(tree, node, ast.FunctionDef) == tree.body[0])


# Generated at 2022-06-23 23:47:17.419122
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:47:23.277414
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
        def m():
            def foo():
                a, b = c, d
                if True:
                    a
            foo, a = b, c
            for i in range(4):
                a, b = b, c
            return a
    """)
    _build_parents(tree)
    assert _parents[tree.body[0].body[0].body[0].targets[1]] == tree.body[0].body[0]
    assert _parents[tree.body[0].body[0].body[0]] == tree.body[0].body[0]
    assert _parents[tree.body[0].body[0].body[1]] == tree.body[0].body[0]

# Generated at 2022-06-23 23:47:30.406136
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """
            def f():
                if True:
                    pass
                z = 1
                return z
            """
    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0]

    assert isinstance(node, ast.Pass)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.If),
                      ast.If)

# Generated at 2022-06-23 23:47:35.963778
# Unit test for function find
def test_find():
    import unittest
    from ..testdata.ast_tree import node_tree
    from .test_utils import get_test_tree

    tree = get_test_tree()

    class FindTest(unittest.TestCase):
        def test_find(self):
            for n in find(tree, node_tree.HttpsConnection):
                self.assertIsInstance(n, node_tree.HttpsConnection)

    unittest.main(exit=False)

# Generated at 2022-06-23 23:47:40.887024
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def func():
        return 1
    tree = ast.parse(func.__code__)
    node = tree.body[0].body[0]
    assert isinstance(node, ast.Return)
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)



# Generated at 2022-06-23 23:47:49.952661
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    x = ast.Name(id="x", ctx=ast.Load())
    assign = ast.Assign(
        targets=[ast.Name(id="y", ctx=ast.Store())],
        value=x
    )
    expr = ast.Expr(value=ast.Call(
        func=ast.Name(id="f", ctx=ast.Load()),
        args=[x],
        keywords=[],
        starargs=None,
        kwargs=None
    ))
    body = [assign, expr]
    module = ast.Module(body=body)
    assert get_closest_parent_of(module, assign, ast.Module) == module

# Generated at 2022-06-23 23:47:55.566360
# Unit test for function replace_at
def test_replace_at():
    class Module(ast.AST):
        _fields = ['body']
        _attributes = ['body']
        body = None

    class Name(ast.AST):
        _fields = ['id']
        _attributes = ['id']
        id = 'a'

    class BinOp(ast.AST):
        _fields = ['left', 'op', 'right']
        _attributes = ['left', 'op', 'right']
        left = None
        op = None
        right = None

    class Add(ast.AST):
        _fields = []
        _attributes = []

    class Store(ast.AST):
        _fields = []
        _attributes = []

    class Assign(ast.AST):
        _fields = ['targets', 'value']
        _attributes = ['targets', 'value']


# Generated at 2022-06-23 23:48:00.598890
# Unit test for function find
def test_find():
    """Unit test for function find."""
    ast_tree = ast.parse('print("hello")')
    print_node = list(find(ast_tree, ast.Print))[0]
    assert len(list(find(ast_tree, ast.Print))) == 1
    assert isinstance(print_node, ast.Print)



# Generated at 2022-06-23 23:48:09.175030
# Unit test for function find
def test_find():
    from typed_ast import ast3
    import ast
    filename = 'test.py'
    source = '''
x = 1
if x > 2:
    print('hello')

y = 2
'''
    tree = ast.parse(source)
    tree = ast3.fix_missing_locations(tree)
    tree_a = find(tree, ast3.Name)
    assert next(tree_a).id == 'x'
    assert next(tree_a).id == 'print'
    assert next(tree_a).id == 'y'



# Generated at 2022-06-23 23:48:13.113041
# Unit test for function insert_at
def test_insert_at():
    import typed_astunparse as astunparse
    module = ast.parse('a')
    insert_at(0, module, ast.parse('b'))

    assert astunparse.unparse(module) == 'b\na'

# Generated at 2022-06-23 23:48:23.875020
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # node.name here is a str
    node = ast.Name('NodeName')
    # List[node]
    body = [node]
    # Module(body=[node])
    tree = ast.Module(body=body)
    # There must be no parent, so we assume Module == parent
    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)

    # Add a parent, FunctionDef(name='NodeName')
    # body should look like [FunctionDef(name='NodeName', body=[node])]
    fdef = ast.FunctionDef(name='NodeName', body=body)
    body = [fdef]

    # Module(body=[FunctionDef(name='NodeName', body=[node])
    tree = ast.Module(body=body)
    # Node is still at index 0,

# Generated at 2022-06-23 23:48:30.284601
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..parser import parse
    from ..node import Return

    # Given
    code = '''
    def func(self):
        return self.field

    func(self)
    '''

    tree = parse(code)
    node = find_node(tree, Return)
    parent = get_non_exp_parent_and_index(tree, node)

    # Then
    assert parent == (find_node(tree, ast.FunctionDef), 0)



# Generated at 2022-06-23 23:48:36.014199
# Unit test for function insert_at
def test_insert_at():
    test_str = """
        def test():
            return 1
    """

    test_ast = ast.parse(test_str)

    insert_at(0, test_ast.body[0], ast.Import(names=[ast.alias(name='os', asname=None)]))

    assert test_ast.body[0].body[0].names[0].name == 'os'

# Generated at 2022-06-23 23:48:45.986987
# Unit test for function get_parent
def test_get_parent():
    class First(ast.AST):
        _fields = ('x', 'y')

    class Second(ast.AST):
        _fields = ('z',)

    class Third(ast.AST):
        _fields = ('a',)

    first1 = First(x=1, y=Second(z=Third(a=True)))
    first2 = First(x=2, y=Second(z=True))
    first3 = First(x=3, y=True)

    f1_x_parent = get_parent(first1, first1.x)
    f1_y_parent = get_parent(first1, first1.y)
    f1_z_parent = get_parent(first1, first1.y.z)

# Generated at 2022-06-23 23:48:54.943989
# Unit test for function insert_at
def test_insert_at():
    from .utils import build_ast
    import unittest

    class InsertAtTestCase(unittest.TestCase):
        def test_simple(self):
            ast_node = build_ast('''
                def foo(bar, baz):
                    print(bar)
                    print(baz)
                ''')

            insert_at(0, ast_node.body[0], ast_node.body[0].body[0])

            self.assertEqual(str(ast_node), '''
                def foo(bar, baz):
                    print(bar)
                    print(bar)
                    print(baz)
                ''')

    unittest.main()



# Generated at 2022-06-23 23:49:00.087687
# Unit test for function get_parent
def test_get_parent():
    import typed_ast.ast3 as typed_ast
    # Given
    tree = typed_ast.parse('def a(b, c):\n    d = b + c')

    # When
    scope = tree.body[0]
    body = scope.body[0]
    target = body.targets[0]

    # Then
    assert get_parent(tree, body) == scope
    assert get_parent(tree, target) == body
    assert get_parent(tree, scope) == tree


# Generated at 2022-06-23 23:49:05.375172
# Unit test for function replace_at
def test_replace_at():
    def run_test_case(input_code: str, node_index: int,
                      replacement_code: str, expeced_code: str) -> None:
        """Runs a test case."""
        node = ast.parse(input_code)
        replacement = ast.parse(replacement_code).body[0]
        replace_at(node_index, node, replacement)
        assert ast.dump(node) == expeced_code

    # Test case 1
    run_test_case(
        'def foo():\n    pass\n',
        0, 'if True:\n    a = "a"',
        'def foo():\n    if True:\n        a = "a"\n'
    )

    # Test case 2

# Generated at 2022-06-23 23:49:07.264230
# Unit test for function insert_at
def test_insert_at():
    import ast
    import inspect
    import random

    source = inspect.getsource(random)
    tree = ast.parse(source)
    target = find(tree, ast.FunctionDef).__next__()
    insert_at(0, target, ast.Print())
    exec(compile(tree, '<string>', 'exec'))

# Generated at 2022-06-23 23:49:18.437393
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    s = ast.parse('''
    class B(object):

        def f(self):
            a = 1
            a = 2
            a = 3
            a = 4
            a = 5
            a = 6
            a = 7
            a = 8
    ''')

    assert get_non_exp_parent_and_index(s, s.body[0].body[1].body[0].body[0]) \
         == (s.body[0].body[1].body[0], 0)
    assert get_non_exp_parent_and_index(s, s.body[0].body[1].body[0].body[-1]) \
         == (s.body[0].body[1].body[0], -1)


# Generated at 2022-06-23 23:49:27.930674
# Unit test for function replace_at
def test_replace_at():
    import astor
    from astor.codegen import to_source
    func_def = ast.FunctionDef(name='foo',
                               args=ast.arguments(args=[], vararg=None,
                                                  kwarg=None,
                                                  kwonlyargs=[],
                                                  defaults=[],
                                                  kw_defaults=[]),
                               body=[ast.Pass()], decorator_list=[])

    suite = ast.Module(body=[func_def])
    print(to_source(suite))

    replace_at(0, suite, [
            ast.ClassDef(name='bar', bases=[],
                         keywords=[], body=[], decorator_list=[])])

    print(to_source(suite))



# Generated at 2022-06-23 23:49:28.847885
# Unit test for function find

# Generated at 2022-06-23 23:49:30.569258
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:49:33.266995
# Unit test for function insert_at

# Generated at 2022-06-23 23:49:34.054810
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-23 23:49:45.828476
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # test node is expression
    tree = ast.parse('a+b')
    print(tree.body[0])
    assert get_non_exp_parent_and_index(tree, tree.body[0]) == (tree, 0)

    # test node is not expression, and has only one parent
    tree = ast.parse('a+b if c else d')
    assert get_non_exp_parent_and_index(tree, tree.body[0].test) == (tree, 0)

    # test node is not expression, but has multiple parents
    tree = ast.parse('a+b if c else d if e else f')
    assert get_non_exp_parent_and_index(tree, tree.body[0].test) == (tree, 0)

# Generated at 2022-06-23 23:49:51.262457
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3 as ast
    import astor
    ast_tree = ast.parse("""def add(a, b):
    return a + b

if __name__ == "__main__":
    add(1, 2)""")
    node = ast_tree.body[0]
    parent = ast_tree
    insert_at(0, parent, node)

# Generated at 2022-06-23 23:49:58.873601
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor, inspect

    code = inspect.getsourcelines(test_get_closest_parent_of)
    tree = ast.parse(code[0])
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            break
    parent_function = get_closest_parent_of(tree, node, ast.ClassDef)
    assert parent_function
    print(astor.to_source(parent_function))

# Generated at 2022-06-23 23:50:06.103279
# Unit test for function replace_at
def test_replace_at():
    import pytest
    parent = ast.parse('def test_func():\n    pass')
    new_body = ast.parse('def test_func():\n    x = 2\n    pass')
    replace_at(0, parent, new_body.body[0])
    assert(str(parent) == 'def test_func():\n    x = 2\n    pass')

# Generated at 2022-06-23 23:50:13.582183
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index"""
    from resources.test_data.get_non_exp_parent_and_index \
        import code_before, code_after, expected_result
    code_before = ast.parse(code_before).body[0]
    code_after = ast.parse(code_after).body[0]
    code_after.body = code_before.body
    _build_parents(code_after)
    node = code_before.body[0].body[0].body[0]
    result = get_non_exp_parent_and_index(code_after, node)
    assert result == expected_result

# Generated at 2022-06-23 23:50:19.985008
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from astunparse import dumps
    ast1 = ast.parse("""if True:
    if True:
        pass
    elif True:
        pass
    else:
        pass""")
    ast2 = ast.parse("""if True:
    if True:
        pass
    elif True:
        pass
    else:
        pass
    pass""")

    node1 = ast1.body[0].body[0]
    node2 = ast2.body[0].body[0]
    assert dumps(ast.If) == dumps(get_closest_parent_of(ast1, node1, ast.If))
    assert dumps(ast.If) == dumps(get_closest_parent_of(ast2, node1, ast.If))

# Generated at 2022-06-23 23:50:26.739703
# Unit test for function insert_at
def test_insert_at():
    with open('tests/test_files/insert_at.py', 'r') as f:
        tree = ast.parse(f.read())
    func_def = find(tree, ast.FunctionDef).__next__()
    insert_at(2, func_def, get_parent(tree, func_def).body.pop(0))
    assert ast.dump(tree) == ast.dump(ast.parse('''
    def func():
        pass
    def func2():
        pass
    '''))



# Generated at 2022-06-23 23:50:36.639873
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    x = ast.parse("""if True:
    x = 1
    print(x)
    y = 2
    print(y)
else:
    p = True
    print(p)
    q = False
    print(q)
z = 3
print(z)""")
    _build_parents(x)

    # Test for the first print statement
    parent, index = get_non_exp_parent_and_index(x, x.body[0].body[1])
    assert astor.to_source(parent) == "if True:\n    x = 1\n    print(x)\n    y = 2\n    print(y)\nelse:\n    p = True\n    print(p)\n    q = False\n    print(q)\nz = 3\nprint(z)"

# Generated at 2022-06-23 23:50:47.152381
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3 as ast
    from io import StringIO

    source = ast.parse('def f():\n'
                       '    for element in iter:\n'
                       '        pass\n'
                       '    print(element)')

    # Insert if ... else ...
    for_index = 0
    for_node = source.body[for_index]

# Generated at 2022-06-23 23:50:56.800976
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("a + b * c")
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].value)
    replace_at(index, parent, ast.parse("a + a * c").body[0].value)
    assert ast.dump(tree) == "Module(body=[Expr(value=BinOp(left=Name(id='a', ctx=Load()), op=Add(), right=BinOp(left=Name(id='a', ctx=Load()), op=Mult(), right=Name(id='c', ctx=Load()))))])"

# Generated at 2022-06-23 23:51:00.546400
# Unit test for function replace_at
def test_replace_at():
    import astor
    # test inputs
    a = ast.parse('a = 1+3')
    a1 = ast.parse('2')
    a2 = [ast.parse('2'),ast.parse('3')]
    a3 = ast.parse('pop()')
    # expected outputs
    a_exp = ast.parse('a = 2')
    a2_exp = ast.parse('a = [2, 3]') # test for TypeError
    a3_exp = ast.parse('a = pop()')
    # unit tests
    a_ast = a.body[0]
    a2_ast = a2
    a3_ast = a3.body[0]
    replace_at(1,a_ast,a1)

# Generated at 2022-06-23 23:51:06.908922
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    from .parser import Parser

    code = '''def test():
        foo = [
            1,
            2
        ]'''

    tree = ast.parse(code)
    parser = Parser(code)
    tree = parser.parse()
    node = tree.body[0].body[0]
    parent = get_non_exp_parent_and_index(tree, node)
    assert astor.to_source(parent[0]) == '''[
        1,
        2
    ]''', 'Node was not found.'
    assert parent[1] == 0, 'The index of the node was not found.'

# Generated at 2022-06-23 23:51:11.137877
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def a():\n    if foo:\n        1\n')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent is tree.body[0]
    assert index == 0

# Generated at 2022-06-23 23:51:20.077760
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast

    tree = ast.parse(
        "def _():\n"
        "    x = min([1, 2, 3])\n"
        "    y = max([4, 5, 6])\n")

    parent1, index1 = get_non_exp_parent_and_index(tree,
                                                   tree.body[0].body[0].value)
    assert isinstance(parent1, ast.FunctionDef)
    assert index1 == 0

    parent2, index2 = get_non_exp_parent_and_index(tree,
                                                   tree.body[0].body[1].value)
    assert isinstance(parent2, ast.FunctionDef)
    assert index2 == 1



# Generated at 2022-06-23 23:51:31.844392
# Unit test for function insert_at
def test_insert_at():
    # create simple ast
    global ast_example

    ast_example = ast.parse(textwrap.dedent('''
    import os
    import ast
    import textwrap

    a = 1
    b = 2
    c = 3
    '''))

    index = ast_example.body[3].body.index(ast_example.body[3].body[2])

    c = ast.parse(textwrap.dedent('''
    c = 4
    '''))

    d = ast.parse(textwrap.dedent('''
    d = 5
    '''))

    insert_at(index, ast_example.body[3], c)
    insert_at(index, ast_example.body[3], d)


# Generated at 2022-06-23 23:51:35.173934
# Unit test for function get_parent
def test_get_parent():
    module = ast.parse('''
    class Test(object):
        def foo(self):
            return True
    ''')

    body = get_parent(module, module.body[0])
    assert isinstance(body, ast.ClassDef)

    for node in ast.walk(body):
        pass


if __name__ == "__main__":
    test_get_parent()

# Generated at 2022-06-23 23:51:36.140010
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:51:45.326045
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    imp_module = ast.Import()
    imp_module.names = [ast.alias('unit_test', None)]
    imp_module.lineno = 1
    imp_module.col_offset = 0
    imp_module.end_lineno = 1
    imp_module.end_col_offset = 1

    fun_def = ast.FunctionDef()
    fun_def.name = 'test_fun'
    fun_def.args = ast.arguments()
    fun_def.decorator_list = []
    fun_def.lineno = 2
    fun_def.col_offset = 0
    fun_def.end_lineno = 2
    fun_def.end_col_offset = 1

    module = ast.Module()
    module.body = [imp_module, fun_def]


# Generated at 2022-06-23 23:51:51.327607
# Unit test for function replace_at
def test_replace_at():
    program = ast.parse(u"""
    for i in range(10):
        print(i)
    """)

    node = ast.If(ast.Num(10), [], [])
    replace_at(0, program, node)
    assert isinstance(program.body[0], ast.If)

# Generated at 2022-06-23 23:52:02.690370
# Unit test for function insert_at
def test_insert_at():
    test_parent = ast.Module(body=[
        ast.FunctionDef(name='f1', args=ast.arguments(
            args=[ast.arg(arg='n', annotation=None)],
            vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None,
            defaults=[]), body=[
        ], decorator_list=[], returns=None),
        ast.Return(value=ast.Str(s='return')),
    ])  # type: ast.Module
    target = test_parent.body[0]  # type: ast.FunctionDef
    # Insert at the end
    insert_at(len(target.body), target, ast.Pass())
    assert len(target.body) == 1
    assert target.body[0].__class__ == ast.Pass

    # Insert in the

# Generated at 2022-06-23 23:52:07.104204
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('def test():\n    pass')
    parent = tree.body[0]
    nodes = [ast.Expr(ast.parse('1').body[0])]
    insert_at(0, parent, nodes)
    assert parent.body[0].value.n == 1
    insert_at(1, parent, nodes)
    assert parent.body[1].value.n == 1



# Generated at 2022-06-23 23:52:08.119207
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:52:13.495074
# Unit test for function insert_at
def test_insert_at():
    ast_tree = ast.parse("for i in range(0, 10):\n    print('hi')")
    code = compile(ast_tree, 'file', 'exec')
    exec(code)
    print(ast_tree)


if __name__ == '__main__':
    test_insert_at()

# Generated at 2022-06-23 23:52:23.970707
# Unit test for function replace_at
def test_replace_at():
    # Same result as expected
    tree = ast.parse('def square(x):\n  return x**2')
    parent = get_closest_parent_of(tree, tree.body[0].body[0].value.args[0],
                                   ast.FunctionDef)
    replace_at(2, parent,
               ast.parse('return x**2').body[0].body[0].value.args[0])

# Generated at 2022-06-23 23:52:26.420806
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a + b', mode='eval')
    assert get_parent(tree, tree.body) is tree



# Generated at 2022-06-23 23:52:33.556101
# Unit test for function find
def test_find():
    import inspect
    import astunparse

    def test_function(a: int, b: str, c: bool) -> str:
        return a + b + c

    test_doc = inspect.getdoc(test_function)
    tree = ast.parse(test_function.__code__)
    for node in find(tree, ast.FunctionDef):
        node.body.extend(ast.parse(test_doc).body)

    ast.fix_missing_locations(tree)


# Generated at 2022-06-23 23:52:34.387030
# Unit test for function replace_at

# Generated at 2022-06-23 23:52:42.202701
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("\n"
                     "def foo():\n"
                     "    a = 5\n"
                     "    a = 6\n")
    node = tree.body[0]
    func_def = node
    ass_node = func_def.body[1].value
    parent = get_parent(tree, ass_node)
    _replace_body(parent, ass_node, ast.parse("a = 5").body[0])
    assert tree == ast.parse("\n"
                             "def foo():\n"
                             "    a = 6\n"
                             "    a = 5\n")



# Generated at 2022-06-23 23:52:51.482939
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = '''
    f = lambda x: x + 1
    def g(x):
        return x + 1
    while True:
        pass
    '''
    tree = ast.parse(source)
    node_f = find(tree, ast.Lambda).__next__()  # type: ignore
    parent_f = get_closest_parent_of(tree, node_f, ast.FunctionDef)
    assert isinstance(parent_f, ast.FunctionDef)  # type: ignore
    node_g = find(tree, ast.Return).__next__()  # type: ignore
    parent_g = get_closest_parent_of(tree, node_g, ast.FunctionDef)
    assert isinstance(parent_g, ast.FunctionDef)  # type: ignore
    node_w = find

# Generated at 2022-06-23 23:52:58.280330
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as ast

    code = """
    def foo(a):
        if a > 1 or a < -1:
            print(a)
    """
    node = ast.parse(code)
    closest_parent = get_closest_parent_of(node, node.body[0].body[0],
                                           type_=ast.FunctionDef)
    assert closest_parent.name == "foo"