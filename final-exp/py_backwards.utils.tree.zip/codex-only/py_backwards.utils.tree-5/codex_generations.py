

# Generated at 2022-06-23 23:42:53.440806
# Unit test for function find
def test_find():
    tree = ast.parse('func(a) + 3')
    for node in find(tree, ast.Call):
        print(node)

# Generated at 2022-06-23 23:42:56.578880
# Unit test for function insert_at
def test_insert_at():
    import astor

    expr = ast.parse('i + 1')
    insert_at(1, expr, ast.parse('2'))
    assert astor.to_source(expr) == 'i + 2'



# Generated at 2022-06-23 23:43:00.828755
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    tree = ast.parse("""
    def f(a):
        return a + 1
    """)
    parent = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.FunctionDef)
    assert astor.to_source(parent).strip() == 'def f(a):'

# Generated at 2022-06-23 23:43:01.735886
# Unit test for function find

# Generated at 2022-06-23 23:43:04.736651
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("a = 1\na = 1\n")

    expr = ast.Expr(value=ast.Num(n=2))
    insert_at(1, tree, expr)

    print(ast.dump(tree))


# Generated at 2022-06-23 23:43:15.628466
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    sample_ast = ast.parse('''
    def f1():
        f2()

    def f2():
        f3()

    def f3():
        pass
    ''')
    _f1, _f2, _f3 = sample_ast.body  # type: ignore

    # Check correct value for body statements
    assert get_non_exp_parent_and_index(sample_ast, _f1) == (sample_ast, 0)
    assert get_non_exp_parent_and_index(sample_ast, _f2) == (sample_ast, 1)
    assert get_non_exp_parent_and_index(sample_ast, _f3) == (sample_ast, 2)

    # Check correct value for children of body statements

# Generated at 2022-06-23 23:43:26.828523
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def test1():
        pass

    def test2():
        pass

    tree = ast.parse('def test1():\n    def test2(): pass')
    func_def2 = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    func_def_name2 = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef).name
    assert func_def2 == test2, "Failed to get the closest parent of test2 with the type FunctionDef"
    assert func_def_name2 == 'test2', "Failed to get the closest parent of the name of test2 with the type FunctionDef"


# Generated at 2022-06-23 23:43:30.161359
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import tempfile
    import os

    fn = tempfile.NamedTemporaryFile(mode='w+t', suffix='.py', delete=False)

# Generated at 2022-06-23 23:43:39.372263
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

    node = ast.parse("""
    def foo(x, y):
        if x < y:
            x = x + y
            y = x - y
            x = x - y
        return x < y
    """).body[0]

    tree = ast.Module([node])
    _build_parents(tree)
    try:
        assert get_closest_parent_of(tree, node.body[0].body[0].value,
                                     ast.FunctionDef) == node
    except AssertionError:
        print('AssertionError in test_get_closest_parent_of')



# Generated at 2022-06-23 23:43:46.936975
# Unit test for function find
def test_find():
    tree = ast.parse("def f():\n\tx = 56\n\ty = 12\n\treturn x + y")
    assert list(find(tree, ast.Name)) == [
        ast.Name(id='f', ctx=ast.Load()),
        ast.Name(id='x', ctx=ast.Store()),
        ast.Name(id='y', ctx=ast.Store()),
        ast.Name(id='x', ctx=ast.Load()),
        ast.Name(id='y', ctx=ast.Load()),
    ]

# Generated at 2022-06-23 23:43:51.902858
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("x = 1\ny = 2")
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    replace_at(index, parent, ast.parse("x = 3").body[0])
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=3)), Name(id='y', ctx=Load())])"

# Generated at 2022-06-23 23:43:58.400468
# Unit test for function find
def test_find():
    test_tree = ast.parse('a=5', '<string>')
    test_tree.body[0].left = ast.Name('bob', None)
    test_tree.body[0].right = ast.Num(5)
    res = list(find(test_tree, ast.Name))
    res.sort(key=lambda x: x.id)
    assert res == [ast.Name('a', None), ast.Name('bob', None)]

# Generated at 2022-06-23 23:44:02.702556
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
    def func():
        return 1
    ''')
    node = find(tree, ast.Num).__next__()
    type_ = ast.FunctionDef
    assert isinstance(get_closest_parent_of(tree, node, type_), type_)

# Generated at 2022-06-23 23:44:10.240520
# Unit test for function insert_at
def test_insert_at():
    class Test:
        def __init__(self) -> None:
            pass
    class Test1:
        def __init__(self) -> None:
            pass
    class Test2:
        def __init__(self) -> None:
            pass
    class Test3:
        def __init__(self) -> None:
            pass

    test = Test()
    test1 = Test1()
    test2 = Test2()
    test3 = Test3()

    test.body = [test1, test2, test3]

    insert_at(0, test, test1)
    assert test.body == [test1, test1, test2, test3]

    insert_at(1, test, test2)
    assert test.body == [test1, test2, test1, test2, test3]

   

# Generated at 2022-06-23 23:44:21.084164
# Unit test for function replace_at
def test_replace_at():

    def _test_replace_at_case(old_node, new_nodes):
        parent = ast.Module(body=[old_node])
        replace_at(0, parent, new_nodes)
        body = parent.body

        if isinstance(new_nodes, ast.AST):
            new_nodes = [new_nodes]

        assert body == new_nodes, body

    _test_replace_at_case(ast.Expr(value='1'), ast.Expr(value='2'))
    _test_replace_at_case(ast.Expr(value='1'), [ast.Expr(value='2'),
                                                ast.Expr(value='3')])


test_replace_at()

# Generated at 2022-06-23 23:44:25.795513
# Unit test for function replace_at
def test_replace_at():
    import astor

# Generated at 2022-06-23 23:44:31.227211
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def f(x, y):\n    print(x + y)')
    func_def = tree.body[0]
    assert(type(func_def.body[0]) is ast.Expr)
    replace_at(0, func_def, ast.parse('    print(x+y)').body[0])
    assert(type(func_def.body[0]) is ast.Print)


# Generated at 2022-06-23 23:44:33.782086
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""print('''\n
                    Hello\n
                    World\n
                    \n''');""")
    node = get_closest_parent_of(tree, tree.body[0].value, ast.Expr)
    assert isinstance(node, ast.Expr)

# Generated at 2022-06-23 23:44:44.505521
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a_body = []
    a = ast.Module(body=a_body)

    b = ast.Expr(value=ast.Num(n=42))
    b_body = [b]
    b = ast.Module(body=b_body)

    c = ast.Expr(value=ast.Num(n=43))
    c_body = [c]
    c = ast.Module(body=c_body)

    d = ast.Expr(value=ast.Num(n=44))
    d_body = [d]
    d = ast.Module(body=d_body)

    e = ast.Expr(value=ast.Num(n=45))
    e_body = [e]
    e = ast.Module(body=e_body)


# Generated at 2022-06-23 23:44:49.076930
# Unit test for function find
def test_find():
    node = ast.parse(
        '''def foo(a):
            if True:
                b
                if True:
                    c
        '''
    )

    ifnodes = find(node, ast.If)

    assert len(list(ifnodes)) == 2



# Generated at 2022-06-23 23:44:54.708405
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    from ..exceptions import NodeNotFound

    """Tests get_non_exp_parent_and_index function."""
    for node in find(astor.parse_file('test_files/assign_test.py'), ast.Assign):
        try:
            get_non_exp_parent_and_index(astor.parse_file('test_files/assign_test.py'), node)
        except NodeNotFound:
            assert node._fields == ('targets', 'value', 'type_comment')

# Generated at 2022-06-23 23:44:55.709352
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

# Generated at 2022-06-23 23:45:04.777846
# Unit test for function get_parent
def test_get_parent():
    root = ast.parse('a + b', '', 'eval').body
    parent = get_parent(root, root.left)
    assert isinstance(parent, ast.BinOp)
    parent = get_parent(root, root.right)
    assert isinstance(parent, ast.BinOp)
    parent = get_parent(root, parent.right)
    assert isinstance(parent, ast.Expr)
    # Calling get_parent() with not valid type
    try:  # pragma: no cover
        get_parent(root, object())
        assert False, 'Wrong type should raise exception'
    except NodeNotFound:
        pass



# Generated at 2022-06-23 23:45:10.548691
# Unit test for function get_parent
def test_get_parent():
    fn1_ast = ast.parse("""def fn1():
    def fn2():
        def fn3():
            return [1]
        return fn3()
    return fn2()""")
    _build_parents(fn1_ast)
    parent = get_parent(fn1_ast, _parents[fn1_ast.body[0].body[0].body[0].value.elts[0]])
    assert(parent == fn1_ast.body[0].body[0].body[0].value)


# Generated at 2022-06-23 23:45:21.588761
# Unit test for function get_parent
def test_get_parent():
    body = [
        ast.Expr(value=ast.Num(1)),
        ast.Return(value=ast.Num(2)),
        ast.Return(value=ast.Num(3)),
    ]
    ast1 = ast.FunctionDef('test', ast.arguments(
        args=[],
        defaults=[],
        vararg=None,
        kwonlyargs=[],
        kw_defaults=[],
        kwarg=None),
                           body=body)
    assert(get_parent(ast1, ast1) is None)
    assert(get_parent(ast1, body[0]) is ast1)
    assert(get_parent(ast1, body[1]) is ast1)
    assert(get_parent(ast1, body[2]) is ast1)

# Generated at 2022-06-23 23:45:24.740378
# Unit test for function find
def test_find():
    tree = ast.parse("class a: pass")
    for node in find(tree, ast.ClassDef):
        assert node.name == "a"


if __name__ == "__main__":
    test_find()

# Generated at 2022-06-23 23:45:32.233281
# Unit test for function replace_at
def test_replace_at():
    def f():
        while True:
            try:
                pass
            except:
                pass
    tree = ast.parse(f"""
    def f():
        while True:
            try:
                pass
            except:
                pass
    """)
    for node in ast.walk(tree):
        if isinstance(node, ast.While):
            break
    assert isinstance(node, ast.While)
    parent = ast.Module(body=[ast.Expr(value=ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Str(s='test passed', kind='double')],
        keywords=[]))])
    replace_at(0, tree.body[0], parent)

# Generated at 2022-06-23 23:45:33.206930
# Unit test for function get_parent

# Generated at 2022-06-23 23:45:34.890336
# Unit test for function replace_at

# Generated at 2022-06-23 23:45:37.250878
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('1 + 2'), ast.Num))) == 2


# Generated at 2022-06-23 23:45:39.723172
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Test for function get_closest_parent_of"""
    func = ast.parse("""def foo():
                            a = 1
                            b = 2
                            c = 3
                        """).body[0]
    assert get_closest_parent_of(func, func.body[1].targets[0], ast.FunctionDef)
    assert not get_closest_parent_of(func, func.body[0], ast.ClassDef)

# Generated at 2022-06-23 23:45:46.083998
# Unit test for function get_parent
def test_get_parent():
    import datetime

    code = '''
    def my_func():
        return 12
    '''
    tree = ast.parse(code)
    parent = get_parent(tree, tree.body[0].body[0].value)
    assert len(ast.dump(parent.body[0])) > 0 # test for sys.getrefcount

    # TODO: check memory leaks
    start = datetime.datetime.now()
    while datetime.datetime.now() - start < datetime.timedelta(seconds = 120):
        _ = get_parent(tree, tree.body[0].body[0].value)

# Generated at 2022-06-23 23:45:54.869024
# Unit test for function insert_at
def test_insert_at():
    expr = ast.parse('a + b')
    expr.body[0].body.insert(0, ast.Expr(ast.Name('x', ast.Load())))
    expr.body[0].body.insert(1, ast.Expr(ast.Name('y', ast.Load())))
    # Check that previous line is equivalent to insert_at(1, expr, ast.Expr(ast.Name('x', ast.Load())))
    insert_at(1, expr, ast.Expr(ast.Name('x', ast.Load())))
    insert_at(2, expr, ast.Expr(ast.Name('y', ast.Load())))
    assert ast.dump(expr) == ast.dump(expr)

# Generated at 2022-06-23 23:45:58.683438
# Unit test for function find
def test_find():
    node = ast.parse("def main(x):\n    for i in range(5):\n        x += i")
    result = [node for node in find(node, ast.For)]
    assert result == [node.body[0]]

# Generated at 2022-06-23 23:46:08.631998
# Unit test for function replace_at
def test_replace_at():
    funcdef = ast.parse('def f():\n pass').body[0]
    assert(isinstance(funcdef, ast.FunctionDef))
    assert(len(funcdef.body) == 1)
    assert(isinstance(funcdef.body[0], ast.Pass))

    add_node = ast.parse('x = 1 + 2').body[0]
    replace_at(0, funcdef, add_node)
    assert(len(funcdef.body) == 1)
    assert(isinstance(funcdef.body[0], ast.Assign))
    assert(isinstance(funcdef.body[0].value, ast.BinOp))

    print('test_replace_at passed')

# Generated at 2022-06-23 23:46:16.036701
# Unit test for function replace_at
def test_replace_at():

    def assert_equal(a, b):
        assert a == b

    def f():
        return 1

    tree = ast.parse('''
    def f():
        return 1''')

    # Replace a return expression with a number
    replace_at(0, f().body, ast.Num(n=2))
    assert_equal(ast.dump(tree), '''
    Module(body=[FunctionDef(args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Num(n=2))], decorator_list=[], returns=None, name='f', lineno=2, col_offset=0)])
    ''')

    # Replace a function name with a string

# Generated at 2022-06-23 23:46:17.804709
# Unit test for function find

# Generated at 2022-06-23 23:46:25.062614
# Unit test for function replace_at
def test_replace_at():
    code = '1 + 2 + 1'
    tree = ast.parse(code)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].value)
    new_node = ast.parse('foo')
    replace_at(index, parent, new_node.body[0].value)
    new_code = ast.dump(tree)
    assert new_code == 'Module([Expr(foo)])',\
        'New node: {}, code: {}'.format(new_node, new_code)


# Generated at 2022-06-23 23:46:34.354566
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..functional import functions
    from .analyzer import get_function_definitions, get_non_local_vars_used
    from .transformer import TransformerContext, Transformer

    class VarUsedTransformer(Transformer):
        context: TransformerContext
        node: ast.AST
        var_name: str

        def __init__(self, context: TransformerContext, node: ast.AST,
                     var_name: str) -> None:
            super().__init__(context)
            self.node = node
            self.var_name = var_name


# Generated at 2022-06-23 23:46:39.125163
# Unit test for function find
def test_find():
    """Test find method."""
    tree = ast.parse('[1, 2, 3]')

    found = []
    for elt in find(tree, ast.List):
        found.append(elt)
    assert len(found) == 1
    assert isinstance(found[0].elts[0], ast.Num)

# Generated at 2022-06-23 23:46:47.348844
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Expr(ast.Name(id='test'))
    parent = ast.Expr(ast.Name(id='test_test'))
    parent.body = [node]  # type: ignore

    non_exp_parent = ast.FunctionDef(name='test_test',
                                     args=ast.arguments(args=[],
                                                        vararg=None,
                                                        kwonlyargs=[],
                                                        kw_defaults=[],
                                                        kwarg=None,
                                                        defaults=[]),
                                     body=[parent],
                                     decorator_list=[])

    non_exp_parent_, index = get_non_exp_parent_and_index(non_exp_parent, node)

    assert non_exp_parent is non_exp_parent_
    assert index == 0

# Generated at 2022-06-23 23:46:49.836789
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test get_non_exp_parent_and_index function."""

# Generated at 2022-06-23 23:46:55.640784
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():  # pragma: no cover
    from typing import List

    tree = ast.parse("""
    [1, 2, 3][0]
    x: List[int] = y
    """)
    closest_parent = get_closest_parent_of(tree, tree.body[0].value.elts[0],
                                           ast.Module)
    assert isinstance(closest_parent, ast.Module)
    assert tree == closest_parent

# Generated at 2022-06-23 23:46:59.739743
# Unit test for function get_parent
def test_get_parent():
    """
    Check that function get_parent works properly
    """
    tree = ast.parse('if 1 == 0:\n\tprint(True)')

    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.If)



# Generated at 2022-06-23 23:47:03.998899
# Unit test for function replace_at
def test_replace_at():
    x = ast.parse('x = 3')
    d = ast.parse('def x(): pass')
    d_pos = get_non_exp_parent_and_index(x, x.body[0].value)
    print(d_pos)
    replace_at(*d_pos, d)

# Generated at 2022-06-23 23:47:13.901216
# Unit test for function replace_at
def test_replace_at():
    code = '''class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.c = a
            self.c = b
            self.c = c
            self.d = d
            self.d = b
    '''

    tree = ast.parse(code)
    last_assign = tree.body[0].body[0].body[2]  # type: ignore
    assert isinstance(last_assign, ast.Assign)
    assign_statement = ast.parse('self.c = c + 1', mode='eval').body
    parent, index = get_non_exp_parent_and_index(tree, last_assign)
    replace_at(index, parent, assign_statement)
    print(last_assign)
   

# Generated at 2022-06-23 23:47:20.766677
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class A(ast.AST):
        _fields = ()

    class B(ast.AST):
        _fields = ()

    class C(ast.AST):
        _fields = ()

    class D(ast.AST):
        _fields = ()

    a = A()
    b = B()
    c = C()
    d = D()

    a.c = b
    b.c = c
    c.c = d

    assert get_closest_parent_of(a, d, A) == b

# Generated at 2022-06-23 23:47:28.139360
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    string = """
    a = 1
    if a == 1:
        b = 1
    else:
        b = 2
    """
    tree = ast.parse(string)
    a = tree.body[0].targets[0]
    b = tree.body[1].body[0].targets[0]
    parent = get_closest_parent_of(tree, b, ast.If)
    assert isinstance(parent, ast.If)
    assert parent.body[0].targets[0].id == a.id

# Generated at 2022-06-23 23:47:31.074502
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("def func():\n    i = 0\n    j = 0")

    parent, index = get_non_exp_parent_and_index(tree,
                                                 tree.body[0].body[0].value)

    assert parent is tree.body[0].body
    assert index == 0


# Generated at 2022-06-23 23:47:34.860960
# Unit test for function get_parent
def test_get_parent():
    astnode = ast.parse("""
    if False:
        pass
    if True:
        pass
    """)

    child = ast.If(test=ast.Name(id='False', ctx=ast.Load()), body=[ast.Pass()],
                   orelse=[])

    parent = get_parent(astnode, child)
    assert isinstance(parent, ast.If)



# Generated at 2022-06-23 23:47:46.137809
# Unit test for function replace_at
def test_replace_at():
    # creating ast tree
    id = ast.Name(id='x', ctx=ast.Load())
    bin_op = ast.BinOp(left=id, op=ast.Add(), right=id)
    assign = ast.Assign(targets=[ast.Name(id='res', ctx=ast.Store())],
                        value=bin_op)
    expr = ast.Expr(value=assign)
    stmt = ast.Module(body=[expr, expr, bin_op])

    expr_tree = ast.parse('x + x')
    expr_body = expr_tree.body[0].value

    # finding and getting parent
    node = list(find(stmt, ast.BinOp))[1]
    parent = get_parent(stmt, node)
    assert parent == expr


# Generated at 2022-06-23 23:47:54.952342
# Unit test for function replace_at
def test_replace_at():
    source = "def foo():\n    print('foo')\n    print('bar')"
    tree = ast.parse(source)

    assert ast.dump(tree) == ast.dump(
        ast.parse(source)
    )

    to_replace = tree.body[0].body[0]

    assert ast.dump(tree) == ast.dump(
        ast.parse(source)
    )

    replace_at(0, tree.body[0],
               ast.parse('_ = 1 + 2').body[0].value)

    assert ast.dump(tree) == ast.dump(
        ast.parse('def foo():\n    _ = 1 + 2\n    print(\'bar\')')
    )


# Generated at 2022-06-23 23:48:06.766277
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:48:12.925742
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .. import ast_tools
    import ast
    import unittest.mock
    test_tree = ast.parse("""\
    def foo():
        pass
    a = 1
    """)
    case_1 = test_tree.body[1]
    test_node = case_1.value

    with unittest.mock.patch.object(ast_tools, 'get_parent') as mock_get_parent:
        ast_tools.get_closest_parent_of(test_tree, test_node, ast.Module)
        mock_get_parent.assert_called_with(test_tree, test_node)

# Generated at 2022-06-23 23:48:17.701263
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('A=5')
    ass_node = tree.body[0]
    name_node = ass_node.targets[0]
    parent, index = get_non_exp_parent_and_index(tree, name_node)
    assert parent == tree
    assert index == 0

# Generated at 2022-06-23 23:48:27.075133
# Unit test for function replace_at
def test_replace_at():
    print('Testing replace_at')

    # Functions
    def r():
        def foo(x):
            return x

        return foo(1)

    def r1_1():
        def foo(x):
            if x:
                return x + 1
            else:
                return 1
        return foo(1)

    def r1_2():
        def foo(x):
            if x:
                return x + 1
            else:
                return 1
        return foo(2)

    def r3_1():
        def foo(x):
            if x:
                return x + 1
            else:
                return 1
        return foo(1) + 1

    def r3_2():
        def foo(x):
            if x:
                return x + 1
            else:
                return 1

# Generated at 2022-06-23 23:48:38.504891
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = """if True:
      def foo(y):
        z = 0
        z += 1
        return z + y
      def bar(x):
        return x + y
    """
    tree = ast.parse(source)
    node = get_closest_parent_of(tree, tree.body[0].body[1].body[0].target,
                                 ast.FunctionDef)
    assert inspect.getsource(node) == 'def foo(y):\n    z = 0\n    z += 1\n    return z + y\n'
    node = get_closest_parent_of(tree, tree.body[0].body[2].body[0].value,
                                 ast.FunctionDef)

# Generated at 2022-06-23 23:48:46.605025
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse(
        """
    def func1(x, y):
        if x is y:
            return x + y
        else:
            pass
    """
    )

    # Find else
    node = tree.body[0].body[0].orelse[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    insert_at(index, parent, ast.Pass())

    assert ast.dump(tree) == \
        \
        """
    <_ast.Module object at 0x7f5e5b5d5e80>
    """

# Generated at 2022-06-23 23:48:47.251264
# Unit test for function find

# Generated at 2022-06-23 23:48:54.943695
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = ast.parse("if a: f()")
    if_node = code.body[0]
    f_node = if_node.body[0].value
    parent, index = get_non_exp_parent_and_index(code, f_node)

    assert isinstance(parent, ast.If)
    assert isinstance(index, int)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(code, if_node)

    assert isinstance(parent, ast.Module)
    assert isinstance(index, int)
    assert index == 0

# Generated at 2022-06-23 23:49:00.994799
# Unit test for function find
def test_find():
    node = ast.parse('x = 1 + 1', mode='eval')
    nodes = list(find(node, ast.Num))
    assert len(nodes) == 2
    assert isinstance(nodes[0], ast.Num)
    assert isinstance(nodes[1], ast.Num)

# Generated at 2022-06-23 23:49:13.169604
# Unit test for function insert_at
def test_insert_at():
    imp = ast.Import()
    imp_body = [ast.alias(name='os', asname=None)]
    imp.body = imp_body
    stmts = ast.parse('i = 1').body
    assert stmts[0].lineno == 1
    insert_at(0, stmts[0], imp)
    assert stmts[0].lineno == 1
    assert stmts[1].lineno == 1
    insert_at(1, stmts[0], imp)
    assert stmts[0].lineno == 1
    assert stmts[1].lineno == 1
    assert stmts[2].lineno == 1
    assert stmts[3].lineno == 1
    insert_at(2, stmts[0], imp)

# Generated at 2022-06-23 23:49:18.866009
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Test function get_closest_parent_of"""
    tree = ast.parse(
        """
        def foo():
            return a()
    """
    )
    node = tree.body[0].body[0].value.args[0]
    parent1 = get_parent(tree, node)
    assert isinstance(parent1, ast.Call)

    parent2 = get_closest_parent_of(tree, node, ast.Call)
    assert parent1 == parent2

    parent3 = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert parent3 == tree.body[0]

# Generated at 2022-06-23 23:49:21.206033
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

# Generated at 2022-06-23 23:49:25.411969
# Unit test for function find
def test_find():
    tree = ast.parse("""if True:
        print("Hello World!")
        print("Hello World!")
        print("Hello World!")
        print("Hello World!")
        print("Hello World!")
    """)

    nodes = list(find(tree, ast.Expr))
    assert len(nodes) == 5

# Generated at 2022-06-23 23:49:35.491251
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse

    def f():
        pass

    source = astunparse.unparse(ast.dump(ast.parse(astor.to_source(f)))[0])

    def _test(line_number, col_number):
        for node in ast.walk(ast.parse(source)):
            if node.lineno == line_number and node.col_offset == col_number:
                if 'lineno' in dir(node.parent) and node.parent.lineno == line_number and node.parent.col_offset <= col_number:
                    assert ast.FunctionDef == get_closest_parent_of(
                        ast.parse(source), node, type_=ast.FunctionDef).__class__

# Generated at 2022-06-23 23:49:35.844627
# Unit test for function get_parent

# Generated at 2022-06-23 23:49:38.483684
# Unit test for function find
def test_find():
    # Create an AST
    t = ast.parse("""a = 2; b = 3; c = 2;""", '', 'single')

    # Find all assignments
    list(find(t, ast.Assign))

# Generated at 2022-06-23 23:49:42.894367
# Unit test for function get_parent
def test_get_parent():
    import astor
    tree = astor.parse_file("example.txt")
    node = astor.parse_file("example.txt").body[0]
    get_parent(tree, node)


# Generated at 2022-06-23 23:49:49.717970
# Unit test for function find
def test_find():
    # Given
    node1 = ast.Name(id='a', ctx=ast.Store())
    node2 = ast.Name(id='a', ctx=ast.Store())

    # When
    res = list(find(node1, ast.Name))

    # Then
    assert len(res) == 2
    assert res[0] is node1
    assert res[1] is node2

# Generated at 2022-06-23 23:49:55.865412
# Unit test for function get_parent
def test_get_parent():
    """Test case for function get_parent"""
    code = """
    for i in range(a, b): 
        f(i)
    """
    tree = ast.parse(code)
    _build_parents(tree)
    assert isinstance(get_parent(tree, tree.body[0].body[0].value.args[0]),
                      ast.Name)
    assert isinstance(get_parent(tree, tree.body[0].body[0].value),
                      ast.Call)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)



# Generated at 2022-06-23 23:49:57.863277
# Unit test for function find
def test_find():
    for _ in find(ast.parse('a = 1'), ast.Assign):
        return True
    return False



# Generated at 2022-06-23 23:50:08.481182
# Unit test for function insert_at
def test_insert_at():
    import inspect
    from . import ast_builder
    from . import ast_compare
    from . import ast_dump
    from . import ast_walker


    def test():
        if True:
            x = 1

        pass

    # 1. Build AST
    code = inspect.getsource(test)
    tree = ast.parse(code)

    # 2. Build expected AST
    if True:
        y = 2
        x = 1

    pass

    code = inspect.getsource(test)
    expected_tree = ast.parse(code)

    # 3. Insert to the pattern
    insert = ast_builder.build('y = 2')

    node = ast_walker.find_single_node(tree, ast.Module)
    parent = get_non_exp_parent_and_index(tree, node)

# Generated at 2022-06-23 23:50:09.863088
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astunparse

# Generated at 2022-06-23 23:50:17.671156
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    d = D()
    d.body = [B(), C()]

    insert_at(0, d, B())

    assert len(d.body) == 3
    assert isinstance(d.body[0], B)
    assert isinstance(d.body[1], B)
    assert isinstance(d.body[2], C)

    insert_at(1, d, C())

    assert len(d.body) == 4
    assert isinstance(d.body[0], B)
    assert isinstance(d.body[1], C)
    assert isinstance(d.body[2], B)

# Generated at 2022-06-23 23:50:22.191887
# Unit test for function find
def test_find():
    tree = ast.parse('x = "test"\nprint(z)')
    found = False
    for node in find(tree, ast.Expr):
        assert isinstance(node, ast.Expr)
        found = True
    assert found

# Generated at 2022-06-23 23:50:31.695039
# Unit test for function get_parent
def test_get_parent():
    code = "if 1:\n    if 2:\n        3"
    parsed = ast.parse(code)
    assert isinstance(parsed, ast.Module)
    assert isinstance(parsed.body[0], ast.If)
    assert isinstance(parsed.body[0].body[0], ast.If)
    assert isinstance(parsed.body[0].body[0].body[0], ast.Expr)

    parent = get_parent(parsed, parsed.body[0].body[0].body[0])
    assert isinstance(parent, ast.If)
    parent = get_parent(parsed, parsed.body[0].body[0])
    assert isinstance(parent, ast.If)
    parent = get_parent(parsed, parsed.body[0])
   

# Generated at 2022-06-23 23:50:32.329945
# Unit test for function get_parent

# Generated at 2022-06-23 23:50:42.337922
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
if True:
    pass
else:
    if True:
        pass
    else:
        pass
""")
    parents_indexes = []
    for node in ast.walk(tree):
        if isinstance(node, ast.If):
            parent, index = get_non_exp_parent_and_index(tree, node)
            parents_indexes.append((parent, index))
    assert len(parents_indexes) == 3
    assert parents_indexes[0][0] == tree
    assert parents_indexes[1][0] == tree.body[0].body[2]
    assert parents_indexes[2][0] == tree.body[0].body[2].orelse[0]
    assert parents_indexes[0][1] == 0
    assert parents_

# Generated at 2022-06-23 23:50:47.988859
# Unit test for function replace_at
def test_replace_at():
    class Parent(ast.AST):
        _fields = ['body']
        body = None  # type: List[ast.AST]

    class Child(ast.AST):
        _fields = ['value']
        value = None  # type: str

    class ReplaceWith(ast.AST):
        _fields = ['value']
        value = None  # type: str

    parent = Parent()
    parent.body = [Child(value='some')]
    replace_at(0, parent, [ReplaceWith(value='some other')])

    assert parent.body[0].__class__.__name__ == 'ReplaceWith'

# Generated at 2022-06-23 23:50:56.576370
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert (ast.parse('if 1:\n    pass').body[0].body, 0) ==\
        get_non_exp_parent_and_index(ast.parse('if 1:\n    pass'),
                                     ast.parse('pass').body[0])

    assert (ast.parse('for i in range(10):\n    pass').body[0].orelse, 0) ==\
        get_non_exp_parent_and_index(ast.parse('for i in range(10):\n    pass'),
                                     ast.parse('pass').body[0])



# Generated at 2022-06-23 23:51:01.804832
# Unit test for function get_parent
def test_get_parent():
    root = ast.parse('''
    def a():
        if True:
            return 2
        else:
            return 3
    ''')
    assert isinstance(root, ast.Module)
    func_def = root.body[0]
    assert func_def.name == 'a'
    assert isinstance(func_def, ast.FunctionDef)
    assert isinstance(get_parent(root, func_def), ast.Module)
    if_body = func_def.body.body[0].body.body[0]
    assert isinstance(if_body, ast.Return)
    assert isinstance(get_parent(root, if_body), ast.If)
    assert isinstance(get_nested_parent(root, if_body), ast.FunctionDef)

# Generated at 2022-06-23 23:51:06.500609
# Unit test for function get_parent

# Generated at 2022-06-23 23:51:07.301632
# Unit test for function insert_at

# Generated at 2022-06-23 23:51:15.370562
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse(textwrap.dedent('''\
        def foo():
            foo()
        '''))
    parent = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    assert len(parent.body) == 1
    replace_at(0, parent, [ast.parse(textwrap.dedent('''\
        bar()
        baz()
        '''))])
    assert parent.body[0].dumps() == 'bar()\n'
    assert parent.body[1].dumps() == 'baz()\n'
    assert len(parent.body) == 2

# Generated at 2022-06-23 23:51:21.471686
# Unit test for function find
def test_find():
    tree = ast.parse('a + 1')
    assert isinstance(tree.body[0], ast.Expr)
    node_expr = tree.body[0]
    bin_op_node = node_expr.value
    assert isinstance(bin_op_node, ast.BinOp)
    assert isinstance(bin_op_node.left, ast.Name)
    assert isinstance(bin_op_node.right, ast.Num)
    name_node = bin_op_node.left
    num_node = bin_op_node.right

    nodes = find(tree, ast.BinOp)
    assert isinstance(nodes, list)
    assert len(nodes) == 1
    assert nodes[0] == bin_op_node

    nodes = find(tree, ast.Name)

# Generated at 2022-06-23 23:51:30.590519
# Unit test for function insert_at
def test_insert_at():
    import ast

    import astor
    code = '''def f():
    pass
    '''
    tree = ast.parse(text=code)
    top = tree.body[0]
    nodes = [ast.parse(text='print(0)'), ast.parse(text='print(1)')]

    print('Before insert:')
    print(astor.to_source(tree))

    insert_at(0, top, nodes)

    print('After insert:')
    print(astor.to_source(tree))


# Generated at 2022-06-23 23:51:36.767871
# Unit test for function get_parent
def test_get_parent():
    code = 'def foo():\n    pass'
    tree = ast.parse(code)
    _build_parents(tree)
    parent = get_parent(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)


# Generated at 2022-06-23 23:51:44.577517
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('def foo(): pass')
    function = tree.body[0]
    a = ast.parse('print(1)')
    insert_at(2, function, a)
    assert str(tree) == 'def foo():\n\n    print(1)\n    pass'

    tree = ast.parse('def foo():\n    pass')
    function = tree.body[0]
    a = ast.parse('print(1)')
    insert_at(2, function, [a, a])
    assert str(tree) == 'def foo():\n\n    print(1)\n\n    print(1)\n    pass'

# Generated at 2022-06-23 23:51:45.443891
# Unit test for function insert_at

# Generated at 2022-06-23 23:51:55.076474
# Unit test for function replace_at
def test_replace_at():
    """Function test for replace_at"""
    code = """
    def test(a, b):
        if a == b:
            return True
        else:
            return False
    """
    tree = ast.parse(code)
    # replace `==` with `>=`
    replace_at(1, tree.body[0],
               ast.Compare(left=tree.body[0].body[0].test.left,
                           ops=[ast.GtE()],
                           comparators=[tree.body[0].body[0].test.comparators[0]]))
    generated_code = ast.unparse(tree)
    assert generated_code == """
    def test(a, b):
        if a >= b:
            return True
        else:
            return False
    """



# Generated at 2022-06-23 23:52:00.423914
# Unit test for function get_parent
def test_get_parent():
    node3 = ast.BinOp()
    node2 = ast.BinOp()
    node1 = ast.BinOp()
    a = ast.Module(body=[node1])
    a.body[0] = node1
    node1.left = node2
    node2.left = node3
    get_parent(a, node3)
    assert _parents[node3] == node2


# Generated at 2022-06-23 23:52:05.515667
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:52:11.518717
# Unit test for function get_parent
def test_get_parent():

    print("1. Testing get_parent")

    node1 = ast.parse("for i in range(0,10): pass").body[0]
    node2 = node1.body[0]
    node3 = node2.body[0]
    node4 = node3.value
    node5 = node4.args[1]
    node6 = node5.value

    assert get_parent(node1, node4) == node3
    assert get_parent(node1, node5) == node4
    assert get_parent(node1, node6) == node5
    assert get_parent(node1, node1) == ast.parse("for i in range(0,10): pass")


# Generated at 2022-06-23 23:52:23.532518
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    input_node = ast.FunctionDef(
        name='foo',
        body=[
            ast.While(
                test=ast.Name(id='condition'),
                body=[
                    ast.Expr(
                        value=ast.Call(
                            func=ast.Name(id='bar'),
                            args=[],
                        )
                    ),
                ]
            ),
        ]
    )
    node = input_node.body[0].body[0].value
    tree = ast.Module(body=[input_node])
    if_parent = astor.to_source(ast.If(
        test=ast.Num(n=1),
        body=[input_node],
        orelse=[]
    ))


# Generated at 2022-06-23 23:52:31.015609
# Unit test for function insert_at
def test_insert_at():
    code = 'def foo():\n    foo(bar)\n    pass'
    root = ast.parse(code)

    # Find the `foo(bar)` node
    call = next(find(root, ast.Call))

    # Find `foo` parent
    func_def = get_parent(root, call)

    # Create an assignment node
    assign = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                        value=ast.Num(n=15))

    # Insert the assignment node before the call node
    insert_at(func_def.body.index(call), func_def, assign)

    # Assert that AST is correct

# Generated at 2022-06-23 23:52:35.925823
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # TODO: Test with more examples
    from . import AstObjects as AO


# Generated at 2022-06-23 23:52:40.374273
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse("""
        def func():
            if True:
                return 1
            elif False:
                return 2
            else:
                return 3
    """)

    result = get_non_exp_parent_and_index(node, node.body[0].body[0].body[0])
    assert result == (node.body[0].body[0], 0)

# Generated at 2022-06-23 23:52:45.013033
# Unit test for function replace_at
def test_replace_at():
    import astor
    parent = ast.parse('def f():\n    print(1)')
    child = parent.body[0]
    child.body[0] = ast.parse('print(1 + 2)').body[0]
    astor.to_source(parent)

# Generated at 2022-06-23 23:52:49.614260
# Unit test for function find

# Generated at 2022-06-23 23:53:00.283594
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def foo():\n  a = 0\n')
    funcdef = tree.body[0]
    assert len(funcdef.body) == 1
    assert isinstance(funcdef.body[0], ast.Assign)

    replace_at(0, funcdef, ast.parse('\n  b = 1\n').body[0])
    assert len(funcdef.body) == 2
    assert isinstance(funcdef.body[0], ast.Assign)
    assert isinstance(funcdef.body[1], ast.Assign)

    replace_at(0, funcdef, ast.parse('\n  c = 2\n').body)
    assert len(funcdef.body) == 3
    assert isinstance(funcdef.body[0], ast.Assign)