

# Generated at 2022-06-23 23:42:52.761032
# Unit test for function find
def test_find():
    testnode = ast.parse('import test').body[0]
    node = list(find(testnode, ast.Import))[0]
    assert node == testnode


# Generated at 2022-06-23 23:42:56.987220
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.parse('x = 1 + 2').body[0]
    node = get_closest_parent_of(node, node, ast.Module)
    assert isinstance(node, ast.Module)
    node = get_closest_parent_of(node, node, ast.FunctionDef)
    assert node is None

# Generated at 2022-06-23 23:43:00.917269
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.parse('def f():\n    if True:\n        1 + 2\n').body[0]
    closest_parent = get_closest_parent_of(node, node.body[0].body[0], ast.If)
    assert isinstance(closest_parent, ast.If)



# Generated at 2022-06-23 23:43:03.453073
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def a():
        pass
    def b():
        pass
    """)
    assert isinstance(get_parent(tree, tree.body[0].body[0]),
                      type(tree.body[0]))



# Generated at 2022-06-23 23:43:04.208073
# Unit test for function find

# Generated at 2022-06-23 23:43:07.105078
# Unit test for function find
def test_find():
    tree = ast.parse('def f(): pass')
    for item in find(tree, ast.FunctionDef):
        assert item.name == 'f'
        break
    else:
        assert False



# Generated at 2022-06-23 23:43:18.041269
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # pylint: disable=unused-variable

    # Test case 1
    module = ast.parse("""
        if a:
            print('A')
        else:
            print('B')
        print('C')
    """)

    assert(get_non_exp_parent_and_index(module, module.body[0].body[0]) ==
           (module.body[0], 0))

    assert(get_non_exp_parent_and_index(module, module.body[0].body[1]) ==
           (module.body, 0))

    assert(get_non_exp_parent_and_index(module, module.body[1]) ==
           (module.body, 1))

    # Test case 2

# Generated at 2022-06-23 23:43:26.372701
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astunparse

    raw_code = """\
    def f():
        if True:
            a = None
    """

    tree = ast.parse(raw_code)
    test_node = find(tree, ast.Assign).__next__()

    parent, index = get_non_exp_parent_and_index(tree, test_node)
    assert isinstance(parent, ast.If)
    assert index == 0

    result_code = astunparse.unparse(tree)
    assert raw_code == result_code.strip()



# Generated at 2022-06-23 23:43:34.622936
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import ast_builder
    from . import get_non_exp_parent_and_index

    class_ = ast_builder.Class(name='test', body=[
            ast_builder.Assign(targets=[ast_builder.Name(id='a')],
                               op='=',
                               value=ast_builder.Const(value=1)),
            ast_builder.Assign(targets=[ast_builder.Name(id='b')],
                               op='=',
                               value=ast_builder.Const(value=2)),
    ])

    _, index = get_non_exp_parent_and_index(class_, class_.body[0])
    if index != 0:
        raise Exception("Expected index 0, got {}".format(index))

    _, index = get_non_exp_parent

# Generated at 2022-06-23 23:43:41.740799
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    expr = ast.parse('a + b + c', '<string>', 'eval')
    class t(ast.AST):
        pass
    expr.body.left = t()
    expr.body.right.left = t()
    assert(get_closest_parent_of(expr, expr.body.right, ast.BinOp) is expr.body)
    assert(get_closest_parent_of(expr, expr.body.right.left, ast.BinOp) is expr.body)


# Generated at 2022-06-23 23:43:51.301603
# Unit test for function replace_at
def test_replace_at():
    import ast as st
    import sys

    # build test tree

# Generated at 2022-06-23 23:43:57.590697
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Given
    tree = ast.parse('''\
            if a:
                if b:
                    pass
    ''')

    # When
    b_parent = get_closest_parent_of(tree, tree.body[0].body[0], ast.If)

    # Then
    assert isinstance(b_parent, ast.If)  # type: ignore
    assert b_parent.test.id == 'a'

# Generated at 2022-06-23 23:44:02.665943
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    root = ast.parse('''
    if a:
        if b:
            c
            d
        e
        f
    ''')
    node = root.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(root, node)
    assert index == 0
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-23 23:44:03.360232
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass

# Generated at 2022-06-23 23:44:06.713839
# Unit test for function insert_at
def test_insert_at():
    a = ast.parse("def foo(): pass")
    b = ast.parse("def bar(): pass")

    insert_at(1, a.body[0], b.body[0])
    insert_at(0, a.body[0], ast.Expr(ast.Name("xxx", ast.Load())))

    print(ast.dump(a))



# Generated at 2022-06-23 23:44:07.569313
# Unit test for function get_parent
def test_get_parent():
    pass



# Generated at 2022-06-23 23:44:08.298782
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:44:17.692695
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """get_non_exp_parent_and_index should find first non-Exp parent in tree."""
    # pylint: disable=redefined-outer-name
    tree = ast.parse('a')
    body = tree.body
    expr = body[0].value
    print(expr.id)
    assert get_non_exp_parent_and_index(tree, expr) == (body[0], 0)

    tree = ast.parse('(1)')
    body = tree.body
    expr = body[0].value
    assert get_non_exp_parent_and_index(tree, expr) == (body[0], 0)



# Generated at 2022-06-23 23:44:28.816812
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = b = c = 1')
    parent = get_non_exp_parent_and_index(tree, tree.body[0].value)[0]
    assert isinstance(parent, ast.Module)

    assert isinstance(tree.body[0].value, ast.Tuple)
    replace_at(0, parent, tree.body[0].value)
    assert isinstance(tree.body[0].value, ast.BinOp)
    replace_at(0, parent, ast.Tuple(tree.body[0].value.values))

    tree = ast.parse('a = 1 + b')
    parent = get_non_exp_parent_and_index(tree, tree.body[0].value)[0]
    assert isinstance(parent, ast.Module)


# Generated at 2022-06-23 23:44:34.071113
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test get_non_exp_parent_and_index function."""
    from .helpers import get_node

    AST = ast.parse('''
    def test():
        x = 1
    ''')
    node = get_node(AST, 'Assign')
    parent, index = get_non_exp_parent_and_index(AST, node)

    assert parent.__class__.__name__ == 'FunctionDef'
    assert index == 1

# Generated at 2022-06-23 23:44:44.974308
# Unit test for function replace_at
def test_replace_at():
    import typed_ast.ast3 as ast
    tree = ast.Module(
        body=[
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=3),
            ),
            ast.Assign(
                targets=[ast.Name(id='y', ctx=ast.Store())],
                value=ast.Num(n=3),
            ),
            ast.Assign(
                targets=[ast.Name(id='z', ctx=ast.Store())],
                value=ast.Num(n=3),
            ),
        ],
    )
    replace_at(1, tree, tree.body[1].targets[0])
    assert(tree.body[1].targets[0].id == 'y')

# Generated at 2022-06-23 23:44:51.474121
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    s = "def foo():\n    x = 1\n    x = 2\n    y = 3\n    return 2/2\n"
    t = ast.parse(s)
    node = ast.parse(s.splitlines()[2].strip())
    _build_parents(t)
    assert node in t.body[0].body  # node should be in function foo
    assert get_non_exp_parent_and_index(t, node) == (t.body[0], 3)



# Generated at 2022-06-23 23:44:52.320143
# Unit test for function insert_at

# Generated at 2022-06-23 23:44:57.410580
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse(
        '''if True:
            if True:
                pass
        ''')

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0],
                                            ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0],
                                            ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0],
                                            ast.FunctionDef), ast.Module)

# Generated at 2022-06-23 23:45:06.291449
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_ast = ast.parse(
        """
        def test_func():
            with tf.Session() as sess:
                tf.global_variables_initializer()
        """
    )
    with_block = test_ast.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(
        test_ast, with_block, ast.With), ast.With)
    with_block = test_ast.body[0].body[0]
    assert isinstance(get_closest_parent_of(
        test_ast, with_block, ast.FunctionDef), ast.FunctionDef)

# Generated at 2022-06-23 23:45:12.263961
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def f(a, b):
        return a + b
    def g():
        print(f(3, 4))

    if 1 == 1:
        g()
    """)
    node = list(find(tree, ast.Call))[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)

# Generated at 2022-06-23 23:45:21.068642
# Unit test for function insert_at
def test_insert_at():
    import astor
    import random

    tree = ast.parse(
        """
for i in range(10):
    print(i)
"""
    )
    func = ast.parse('print(i)')

    insert_at(0, tree, func)
    insert_at(1, tree, func)
    insert_at(random.randint(0, len(tree.body)), tree, func)
    insert_at(random.randint(0, len(tree.body)), tree, func)
    insert_at(random.randint(0, len(tree.body)), tree, func)

    print(astor.to_source(tree))

# Generated at 2022-06-23 23:45:30.956373
# Unit test for function find
def test_find():
    class FakeNode(ast.AST):
        body = None
        _fields = ('body',)
        _attributes = ()

    class FakeNestedNode(ast.AST):
        body = None
        _fields = ('body',)
        _attributes = ()

    first_leaf = FakeNestedNode()
    second_leaf = FakeNestedNode()
    middle_node = FakeNode()
    middle_node.body = [first_leaf, second_leaf]  # type: ignore

    parent = FakeNode()
    parent.body = [middle_node]  # type: ignore

    assert list(find(parent, FakeNestedNode)) == [first_leaf, second_leaf]
    assert list(find(parent, FakeNode)) == [middle_node, parent]

# Generated at 2022-06-23 23:45:42.764985
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test 1:
    class DummyNode(ast.AST):
        name = 'Dummy'

    root = DummyNode()

    class A(ast.AST):
        name = 'A'

    a_nodes = [
        A(lineno=1, col_offset=2),
        A(lineno=3, col_offset=4),
    ]

    root.body = [
        ast.Expr(a_nodes[0], lineno=5),
        ast.Expr(a_nodes[1], lineno=6),
    ]

    assert get_closest_parent_of(root, a_nodes[0], DummyNode) == root

    # Test 2:
    class B(ast.AST):
        name = 'B'


# Generated at 2022-06-23 23:45:47.256198
# Unit test for function get_parent
def test_get_parent():
    code = \
    """
    def foo(self, a=9, *b, **c):
        x = 9
        y = x + 9
    """
    tree = ast.parse(code)
    _build_parents(tree)
    assert isinstance(get_parent(tree, tree.body[0].body[1].value.left),
                      ast.Name)


# Generated at 2022-06-23 23:45:56.776566
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Parent(ast.AST):
        _fields = ()

        def __init__(self, child):
            self.child = child

    class Child1(ast.AST):
        _fields = ()

    class Child2(ast.AST):
        _fields = ()

    class GrandParent(ast.AST):
        _fields = ()

        def __init__(self, parent, test_case):
            self.parent = parent
            self.test_case = test_case

    class Test1(ast.AST):
        _fields = ()

    class Test2(ast.AST):
        _fields = ()

    class Test3(ast.AST):
        _fields = ()

    # Test 1
    child1 = Child1()
    child2 = Child2()
    parent = Parent(child1)
    grand_parent = GrandParent

# Generated at 2022-06-23 23:45:58.258145
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

# Generated at 2022-06-23 23:46:02.754882
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a = 1 + (3 + 4)')
    node = tree.body[0].value
    insert_at(1, node, ast.Pass())
    assert astor.to_source(tree) == "a = 1 + (3 + 4)"


# Generated at 2022-06-23 23:46:10.016374
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        _fields = ()
        _attributes = ()
        body = ['content', 'content']

    class B(ast.AST):
        _fields = ()
        _attributes = ()


    A.body._type_ = B

    tree = A()
    insert_at(0, tree, B())
    insert_at(1, tree, B())
    insert_at(2, tree, B())

    assert len(tree.body) == 4


if __name__ == '__main__':
    test_insert_at()

# Generated at 2022-06-23 23:46:11.143751
# Unit test for function get_parent

# Generated at 2022-06-23 23:46:15.571178
# Unit test for function get_parent
def test_get_parent():
    parent = ast.parse("""
    def foo(a, b):
        c = a + b
        d = a * b
        return c * d
    """)

    _build_parents(parent)

    got = get_parent(parent, parent.body[0].body[1].value.args[1]).lineno
    expect = 3

    assert got == expect, (got, expect)

# Generated at 2022-06-23 23:46:24.474927
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast
    import utils

    tree = ast.parse('''if test:
        if test:
            print()
        print()''')

    node = tree.body[0].body[0].body[0]

    parent = utils.get_closest_parent_of(tree, node, ast.Module)
    assert parent is tree

    parent = utils.get_closest_parent_of(tree, node, ast.If)
    assert parent is tree.body[0].body[0]

    parent = utils.get_closest_parent_of(tree, node, ast.FunctionDef)
    assert parent is None


# Generated at 2022-06-23 23:46:25.154318
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert True

# Generated at 2022-06-23 23:46:25.911703
# Unit test for function replace_at

# Generated at 2022-06-23 23:46:29.411974
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('x = 5')
    replace_at(0, tree, ast.parse('x=5;y=10'))
    assert(ast.dump(tree) == ast.dump(ast.parse('x=5;y=10')))


# Generated at 2022-06-23 23:46:36.658996
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def foo():
        def bar():
            pass
        pass
    ast_foo = ast.parse(inspect.getsource(foo)).body[0]
    ast_bar = ast_foo.body[0]
    ast_name = ast.Name(
        id='bar', ctx=ast.Store()
    )
    ast_body = ast_bar.body[0]
    ast_body.body.insert(0, ast_name)
    assert get_closest_parent_of(ast_foo, ast_name, ast.FunctionDef).name == 'bar'

# Generated at 2022-06-23 23:46:46.149959
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ###########################################
    # Test 1:
    # Node is in body
    # Body is the expected parent
    ###########################################
    test_tree = ast.parse('''
        for i in range(10):
            if i == 0:
                break
            # Comment
            print(i)
        ''')

    test_for = _find_node(test_tree, ast.For)
    test_body = test_for.body

    test_print = _find_node(test_for, ast.Print)
    test_parent = get_closest_parent_of(test_tree, test_print, ast.Body)

    assert test_parent == test_body

    ###########################################
    # Test 2:
    # Node is in body, but body is not the expected parent
    # The first If node

# Generated at 2022-06-23 23:46:56.732733
# Unit test for function replace_at
def test_replace_at():
    # local variable
    def test1():  # test1
        x = 99  # x = 99
        return True  # return True
    mod = ast.parse(inspect.getsource(test1)).body[0]  # get function
    x_index = mod.body.index(get_closest_parent_of(mod,
                                                   get_closest_parent_of(
                                                       mod,
                                                       find(mod, ast.Name).next(),
                                                       ast.Assign),
                                                   ast.Assign))
    replace_at(x_index, mod, ast.parse('x = 100'))
    exec(compile(ast.Module([mod]),
                 '<ast>', 'exec'), locals())
    assert locals()['x'] == 100  # x == 100
    # global variable

# Generated at 2022-06-23 23:46:57.557277
# Unit test for function find

# Generated at 2022-06-23 23:46:58.306629
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:47:09.065714
# Unit test for function replace_at
def test_replace_at():
    class A:
        def __init__(self):
            self.body = [1, 2, 3]

    class B:
        def __init__(self):
            pass

    a = A()
    b = B()

    replace_at(0, a, b)
    assert a.body[0] == b
    assert a.body[1] == 2
    assert a.body[2] == 3

    replace_at(1, a, b)
    assert a.body[0] == b
    assert a.body[1] == b
    assert a.body[2] == 3

    replace_at(2, a, b)
    assert a.body[0] == b
    assert a.body[1] == b
    assert a.body[2] == b

# Generated at 2022-06-23 23:47:10.609916
# Unit test for function insert_at
def test_insert_at():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 23:47:21.320780
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    input = """
    if True:
        return 1
    else:
        foo = 3 if True else 2
        bar = 4 if True else 3
        return 2
    """

    # Test if the non-Exp parent is the if node.
    tree = ast.parse(input)
    node = tree.body[0].body[0]
    parent = get_non_exp_parent_and_index(tree, node)
    assert parent[0].test.value.s == 'True'
    assert parent[1] == 2

    # Test if the non-Exp parent is the else node.
    tree = ast.parse(input)
    node = tree.body[0].orelse[1]
    parent = get_non_exp_parent_and_index(tree, node)
    assert parent[0].test.value.s

# Generated at 2022-06-23 23:47:24.428323
# Unit test for function get_parent
def test_get_parent():
    import astor
    parent = ast.parse('a + (b)')
    node = parent.body[0].value

    assert parent == get_parent(parent, node)



# Generated at 2022-06-23 23:47:33.663662
# Unit test for function get_parent

# Generated at 2022-06-23 23:47:42.443859
# Unit test for function insert_at
def test_insert_at():
    module = ast.parse('a = 1')
    insert_at(0, module, ast.Assign(targets=[ast.Name(id='a',
                                                     ctx=ast.Store(),
                                                     annotation=None)],
                                    value=ast.Constant(value='hello'),
                                    type_comment=None))
    assert ast.dump(module) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value='hello')), Assign(targets=[Name(id='a', ctx=Store())], value=Constant(value=1))])"

# Generated at 2022-06-23 23:47:43.043872
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-23 23:47:45.729679
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = """
    def my_func(a, b):
        c = a + b
        return c
    """

    tree = ast.parse(source)
    node = get_closest_parent_of(tree, tree.body[0].body[0].value.right,
                                 ast.FunctionDef)
    assert isinstance(node, ast.FunctionDef)
    assert node.name == 'my_func'

# Generated at 2022-06-23 23:47:49.313104
# Unit test for function find
def test_find():
    with open('tests/test_files/utils_find.py') as f:
        tree = ast.parse(f.read())
        contains = list(find(tree, ast.Compare))
        assert len(contains) == 1



# Generated at 2022-06-23 23:47:50.624192
# Unit test for function insert_at
def test_insert_at():
    import astor

# Generated at 2022-06-23 23:47:58.626567
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    mod1 = ast.parse('if 1: pass')  # type: ignore
    mod2 = ast.parse('def f(): pass')  # type: ignore

    p, i = get_non_exp_parent_and_index(mod1, mod1.body[0].body[0])
    assert isinstance(p, ast.Module)
    assert i == 0

    p, i = get_non_exp_parent_and_index(mod2, mod2.body[0].body[0])
    assert isinstance(p, ast.Module)
    assert i == 0

# Generated at 2022-06-23 23:48:06.323410
# Unit test for function replace_at
def test_replace_at():
    func = ast.parse('def f(x):\n'
                     '    x = x + 1\n'
                     '    return x\n')

    parent, index = get_non_exp_parent_and_index(func, func.body[1].body[0])
    replace_at(index, parent, [])
    assert func.body[1].body == []
    assert isinstance(func.body[2], ast.Return)
    assert len(func.body) == 3



# Generated at 2022-06-23 23:48:13.585035
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = "def foo():\n    baz(0)\n"
    tree = ast.parse(source)

    funcdef_name = "foo"
    call_name = "baz"
    funcdef_node = tree.body[0]

    if (funcdef_name != funcdef_node.name):
        raise NodeNotFound("Function node not found")

    call_node = tree.body[0].body[0].value  # type: ignore

    if (call_name != call_node.func.id):
        raise NodeNotFound("Call node not found")

    parent, index = get_non_exp_parent_and_index(tree, call_node)

    if (parent is not funcdef_node.body):
        raise NodeNotFound("Parent node not found")

    if (index != 0):
        raise

# Generated at 2022-06-23 23:48:14.778889
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:48:19.890067
# Unit test for function replace_at
def test_replace_at():
    class _Dummy(ast.AST):
        body = [1, 2, 3, 4]

    assert _Dummy.body == [1, 2, 3, 4]
    replace_at(0, _Dummy, [2, 3])
    assert _Dummy.body == [2, 3, 2, 3, 4]



# Generated at 2022-06-23 23:48:21.272461
# Unit test for function get_parent

# Generated at 2022-06-23 23:48:25.040273
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    for x in range(10):
        print(x)
    """)

    _build_parents(tree)

    node = tree.body[0].body[0]
    assert get_parent(tree, node) == tree.body[0].body



# Generated at 2022-06-23 23:48:32.471955
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    # Get a class A
    code = 'class A(B): pass'
    tree = ast.parse(code)
    funcdef = list(find(tree, ast.ClassDef))[0]
    classdef = list(find(tree, ast.ClassDef))[0]

    # Get a closest parent of function definition
    assert get_closest_parent_of(tree, funcdef, ast.ClassDef) == classdef



# Generated at 2022-06-23 23:48:33.656351
# Unit test for function insert_at

# Generated at 2022-06-23 23:48:42.635235
# Unit test for function insert_at
def test_insert_at():
    # Add a class with a function
    class_ = ast.ClassDef(name='MyClass', body=[ast.FunctionDef(name='fun')])
    class_.lineno = 0
    class_.col_offset = 0

    assert class_.body == [ast.FunctionDef(name='fun')]

    # Add a function as param and keyword to the function
    param = ast.arg(arg='param1')
    keyword = ast.arg(arg='keyword1')
    insert_at(0, class_.body[0], [param])
    insert_at(1, class_.body[0], [keyword])

    assert class_.body[0].args.args[0].arg == 'param1'
    assert class_.body[0].args.args[1].arg == 'keyword1'

    # Test that the keyword has been inserted and

# Generated at 2022-06-23 23:48:50.164520
# Unit test for function insert_at
def test_insert_at():
    # Create an assign AST and insert an new AST to it
    tree = ast.parse('a = 1')
    assign = tree.body[0]
    tree.body.pop()
    tree.body.pop()
    assert len(tree.body) == 0
    exp = ast.Expr(value=ast.Num(n=1))
    insert_at(0, assign, exp)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.Assign)
    assert tree.body[0].value.n == 1

# Generated at 2022-06-23 23:48:54.646898
# Unit test for function find
def test_find():
    test_file = 'test_file.py'

    with open(test_file) as source:
        test_tree = ast.parse(source.read())

    print(find(test_tree, ast.Expr))

if __name__ == '__main__':
    test_find()

# Generated at 2022-06-23 23:49:04.530557
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Get a closest parent of passed type"""
    # pylint: disable=unreachable,import-error
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 23:49:06.282754
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse("1")
    parent = ast.Module(body=[node])
    index = get_non_exp_parent_and_index(parent, node)
    assert parent == index[0] and 0 == index[1]

# Generated at 2022-06-23 23:49:11.762262
# Unit test for function find
def test_find():
    from typed_ast import ast3
    # Simple case
    s = ast3.parse('a = 1 + 2')
    assert len(list(find(s, ast3.BinOp))) == 1

    # Complex case
    s = ast3.parse('a = 1 + 2; if a == 5: print(a)')
    assert len(list(find(s, ast3.BinOp))) == 1
    assert len(list(find(s, ast3.Name))) == 2



# Generated at 2022-06-23 23:49:17.926203
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code_str = '''
    def foo():
        pass
    '''
    parsed_code = ast.parse(code_str)
    first_node = parsed_code.body[0]
    pass_node = first_node.body[0]
    assert isinstance(get_closest_parent_of(parsed_code, pass_node, ast.Body), ast.Body)
    assert isinstance(get_closest_parent_of(parsed_code, pass_node, ast.Module), ast.Module)

# Generated at 2022-06-23 23:49:24.353221
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert_equals(
        'a is a <class \'_ast.Module\'>',
        'a is %s' % str(get_closest_parent_of(
            ast.parse('def a(i):\n  b = i\n  return b + i', mode='exec'),
            ast.parse('i', mode='eval'),
            ast.Module
        ))
    )



# Generated at 2022-06-23 23:49:35.455344
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    #    fp = FindParent()
    #    fp.visit(ast.parse("""
    #  class Main:
    #     def __init__(self):
    #       pass
    #     def foo():
    #       pass
    #     def bar():
    #       pass
    #    """))
    #    node = fp.node
    #    parent = get_closest_parent_of(node, ast.Module)
    #    assert(parent.body[0].name == "Main")
    contents = ast.parse("""
  class Main:
     def __init__(self):
       pass
     def foo():
       pass
     def bar():
       pass
    """)

# Generated at 2022-06-23 23:49:41.011285
# Unit test for function insert_at
def test_insert_at():
    code = '''
    def func():
        pass
    pass
    '''

    tree = ast.parse(code)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])

    assert index == 0
    assert parent.body[0].name == 'func'

    insert_at(index, parent, ast.parse('def other(): pass'))

    assert parent.body[0].name == 'other'



# Generated at 2022-06-23 23:49:52.299120
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # An example of a tree with 5 nodes, where node 3 is within a
    # conditional expression node 2 and node 2 is within a function node 1
    # Parent of node 3: 3 -> 2 -> 1
    # 1, 2 and 3 are expression nodes

    # Tree node 1
    class FunctionDef(ast.AST):
        _fields = ['name', 'args', 'body', 'decorator_list', 'returns']

    name = ast.Name("name", ast.Load())
    args = ast.arguments([], None, [], [])
    node1 = ast.FunctionDef(name, args, [], [])  # type: ignore
    node1 = FunctionDef(name, args, [], [], None)  # type: ignore

    # Tree node 2
    class Compare(ast.AST):
        _fields = []

    node2

# Generated at 2022-06-23 23:49:56.581240
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        _fields = ('body',)

    a = A()
    a.body = []

    insert_at(0, a, 10)
    assert a.body[0] == 10

    insert_at(1, a, 20)
    assert a.body[1] == 20

    insert_at(0, a, (30, 40))
    assert a.body[0] == 30
    assert a.body[1] == 40



# Generated at 2022-06-23 23:50:01.071170
# Unit test for function find
def test_find():
    source = dedent('''
        def a(b):
            pass
    ''')
    tree = ast.parse(source)
    nodes = list(find(tree, ast.FunctionDef))

    assert len(nodes) == 1
    assert nodes[0].name == 'a'

# Generated at 2022-06-23 23:50:06.528189
# Unit test for function insert_at
def test_insert_at():
    node1 = ast.parse('print("Hello world!")')
    node2 = ast.parse('print("Hello world!")')
    parent = ast.parse('code_block')
    parent.body.append(node1)
    parent.body.append(node2)
    insert_at(1, parent, node2)

    assert parent.body[1].func.id == 'print'


# Generated at 2022-06-23 23:50:14.291184
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def f(x: int, y: int) -> int:
        if x > 0:
            return x + y
        else:
            return y - x

    ast_tree = ast.parse(source=inspect.getsource(f))
    assert isinstance(get_closest_parent_of(ast_tree,
            ast_tree.body[0].body[0].body[1], ast.FunctionDef), ast.FunctionDef)

# Generated at 2022-06-23 23:50:24.868628
# Unit test for function insert_at
def test_insert_at():
    nodes = [ast.Expr(value=ast.Num(n=5))]
    module = ast.parse('x = 5')
    parent = get_parent(module, module.body[0])

    insert_at(0, parent, nodes)
    assert len(parent.body) == 3
    # The number one looks like an I (i)
    assert parent.body[0].value.n == 1
    assert parent.body[1].value.n == 5
    assert parent.body[2].value.n == 5

    insert_at(1, parent, nodes)
    assert len(parent.body) == 4
    assert parent.body[0].value.n == 1
    assert parent.body[1].value.n == 5
    assert parent.body[2].value.n == 5

# Generated at 2022-06-23 23:50:32.000744
# Unit test for function get_parent
def test_get_parent():
    """
    Test for function get_parent.
    """
    tree = ast.parse("""
        def func():
            if True:
                pass
            else:
                pass
    """)
    ast.fix_missing_locations(tree)

    if_node = tree.body[0].body[0]
    if_body_node = if_node.body[0]
    else_node = if_node.orelse[0]
    else_body_node = else_node.body[0]

    assert get_parent(tree, else_node) == if_node
    assert get_parent(tree, else_body_node) == else_node
    assert get_parent(tree, if_node) == tree.body[0]
    assert get_parent(tree, if_body_node) == if_node

# Generated at 2022-06-23 23:50:41.994676
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3
    from collections import OrderedDict

    example = ast3.parse("""def a(b):
        for x in range(4):
            range(2)
            pass

        range(2)
        pass
        """)

    # Example to verify if insert_at works
    parent = example.body[0].body[0]
    insert_at(1, parent, ast3.Call(ast3.Name('print', ast3.Load()), [
        ast3.Str('hello world!')], [], None, None))

    # Asserts if the example is right
    assert example.body[0].body[0].body[1].func.id == 'print'
    assert example.body[0].body[0].body[1].args[0].s == 'hello world!'



# Generated at 2022-06-23 23:50:47.590466
# Unit test for function find
def test_find():
    program = ast.parse("""
import ast
import sys
print("Hello world!")
""")

    print("All Strings")
    print(list(find(program, ast.Str)))

    print("All Calls")
    print(list(find(program, ast.Call)))



# Generated at 2022-06-23 23:50:50.368606
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:50:54.876362
# Unit test for function insert_at
def test_insert_at():
    u = ast.parse('def f(): pass').body[0]
    body = u.body
    new_node1 = ast.parse('x = 1').body[0]
    new_node2 = ast.parse('x = 2').body[0]
    index = 0
    func_body = body[index]
    insert_at(index, func_body, new_node1)
    assert(str(body[index]) == 'x = 1')
    insert_at(index, func_body, new_node2)
    assert(str(body[index]) == 'x = 2')
    insert_at(index, func_body, new_node1)
    assert(str(body[index]) == 'x = 1')


# Generated at 2022-06-23 23:51:02.507607
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = 'def fun(arg1, arg2):\n    return arg1 + arg2'
    tree = ast.parse(code)
    _build_parents(tree)
    node = find(tree, ast.Return).__next__()

    assert get_non_exp_parent_and_index(tree, node) == (
        tree.body[0], tree.body[0].body.index(node))

# Generated at 2022-06-23 23:51:09.529409
# Unit test for function insert_at
def test_insert_at():
    root = ast.Module(body=[
        ast.Expr(value=ast.Num(n=1)),
        ast.Expr(value=ast.Num(n=2)),
    ])

    insert_at(1, root,
              ast.Expr(value=ast.Num(n=1.5)))

    assert root.body[1].value.n == 1.5  # type: ignore
    assert root.body[2].value.n == 2  # type: ignore



# Generated at 2022-06-23 23:51:14.830167
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        '''\
if True:
    if False:
        pass
'''
    )
    _, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert index == 0

# Generated at 2022-06-23 23:51:20.686853
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    root = ast.parse("""
        def a ():
            def b ():
                return 1
            return b() + 1
        """)
    assert isinstance(get_closest_parent_of(root, root.body[0].body[0], ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(root, root.body[0].body[0], ast.Module), ast.Module)

# Generated at 2022-06-23 23:51:32.344506
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a + b')
    root_parent = tree
    a_parent = get_parent(tree, tree.body[0].value)
    b_parent = get_parent(tree, tree.body[0].targets[0])
    assert a_parent.body[0].value == tree.body[0].value
    assert b_parent.body[0].targets[0] == tree.body[0].targets[0]
    replace_at(0, a_parent, ast.Name(id='c', ctx=ast.Load()))
    replace_at(0, b_parent, ast.Name(id='d', ctx=ast.Store()))
    assert root_parent.body[0].value.id == 'c'
    assert root_parent.body[0].targ

# Generated at 2022-06-23 23:51:36.563092
# Unit test for function get_parent
def test_get_parent():
    expr = ast.parse('1 + 2')
    assert len(_parents) == 0

    get_parent(expr, expr.body[0].value)
    assert len(_parents) == 1

    get_parent(expr, expr.body[0].value)
    assert len(_parents) == 1

    _build_parents(expr)
    assert len(_parents) == 3

    assert get_parent(expr, expr.body[0].value.left) == expr.body[0].value
    assert get_parent(expr, expr.body[0].value) == expr.body[0]
    assert get_parent(expr, expr.body[0]) == expr.body



# Generated at 2022-06-23 23:51:37.144617
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass

# Generated at 2022-06-23 23:51:44.834302
# Unit test for function find

# Generated at 2022-06-23 23:51:48.770541
# Unit test for function find
def test_find():
    import inspect
    import astor

    tree = ast.parse(inspect.getsource(find))

    for cls in find(tree, ast.ClassDef):
        for cls2 in find(tree, ast.ClassDef):
            assert cls != cls2, "find_class() fails to find both classes"

    for fnc in find(tree, ast.FunctionDef):
        found = False
        for fnc2 in find(tree, ast.FunctionDef):
            if fnc != fnc2:
                found = True
        assert found, "find_function() fails to find 2 functions"

# Generated at 2022-06-23 23:51:54.395341
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as ast
    parent = ast.parse('a = b + c', mode='eval').body
    assert get_closest_parent_of(parent, parent.value, ast.Name) == parent.value.left
    assert get_closest_parent_of(parent, parent.value, ast.Expr) == parent
    assert get_closest_parent_of(parent, parent.value, ast.Module) == parent
    assert get_closest_parent_of(ast.parse('a = b + c'), ast.parse('b + c').body[0], ast.Expr) is None

# Generated at 2022-06-23 23:52:02.170141
# Unit test for function get_parent
def test_get_parent():
    node_to_test = ast.parse(
        '''(
        a := 3
        b := 1
        return a + b
    )'''
    ).body[0].value  # type: ignore

    parent_to_test = ast.parse(
        '''(
        a := 3
        b := 1
        return a + b
    )'''
    ).body[0]

    assert get_parent(ast.parse(
        '''(
        a := 3
        b := 1
        return a + b
    )'''
    ), node_to_test) == parent_to_test

# Generated at 2022-06-23 23:52:08.396343
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
        def a(a, b, c):
            d = b - c
            e = a + d
        f = a(1, 2, 3)
        """)
    node = tree.body[0]
    assert isinstance(node, ast.FunctionDef)
    assert get_closest_parent_of(tree, node, ast.Module) == tree

    node = tree.body[0].body[1].targets[0]
    assert isinstance(node, ast.Name)
    assert get_closest_parent_of(tree, node, ast.FunctionDef) == tree.body[0]

# Generated at 2022-06-23 23:52:20.400498
# Unit test for function insert_at
def test_insert_at():
    import random
    import _ast
    from typed_ast.ast3 import parse
    module = parse("x = 3 + y\nz = y + 1\nt = x + z")
    successors = list(module.body)
    random.shuffle(successors)
    insert_at(0, module, successors)
    assert len(module.body) == 6, "invalid number of body"
    assert module.body[0]._fields == ('target', 'value', '_ctx'), "invalid body[0]._fields"
    assert module.body[0].value.left.id == 'y', "invalid body[0].value.left.id"
    assert module.body[1]._fields == ('target', 'value', '_ctx'), "invalid body[1]._fields"
    assert module.body[1].value

# Generated at 2022-06-23 23:52:21.044580
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass

# Generated at 2022-06-23 23:52:29.014610
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_case = ast.parse("""\
    def add(a,b):
        return a+b
    if 3 < 5:
        r = add(2, 4)
    else:
        r = add(2, 5)
    """)

    test_node = test_case.body[0].body[0].value.left
    parent, index = get_non_exp_parent_and_index(test_case, test_node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0



# Generated at 2022-06-23 23:52:36.986601
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    _source = '''
        def test(param):
            param = 2 + 3
            def inner_func(param2):
                print(param2)
            inner_func(param)
    '''
    _tree = ast.parse(_source)
    _func_def = _tree.body[0]
    _inner_func = _func_def.body[1]
    _param2_function_def = get_parent(
        _tree, _tree.body[0].body[1].body[0].value.args[0]
    )
    _param2_assignment = get_non_exp_parent_and_index(
        _tree, _tree.body[0].body[0].value.args[0])

# Generated at 2022-06-23 23:52:46.841251
# Unit test for function get_parent
def test_get_parent():
    import unittest
    import astor

    tree = ast.parse("\n".join(['if x:', '    pass', 'else:', '    pass']))
    _build_parents(tree)

    class TestGetParent(unittest.TestCase):
        def test_if_parent(self):
            ifnode = tree.body[0]
            passnode = ifnode.body[0]
            elsenode = ifnode.orelse[0]

            self.assertEqual(astor.to_source(get_parent(tree, ifnode)),
                             'if x:')
            self.assertEqual(astor.to_source(get_parent(tree, passnode)),
                             'if x:')

# Generated at 2022-06-23 23:52:55.842876
# Unit test for function insert_at
def test_insert_at():
    import astor
    import astunparse
    import inspect
    import re

    def compare(code, tree):
        code = re.sub(r'\s', '', code)
        tree = astor.to_source(tree)
        tree = re.sub(r'\s', '', tree)
        assert code == tree

    def test(code):
        tree = ast.parse(code)
        parent_fnc = get_parent(tree, tree.body[0])
        insert_at(0, parent_fnc, ast.parse('''a = 10''').body[0])
        compare(code, tree)

        parent_fnc = get_parent(tree, tree.body[0])
        insert_at(1, parent_fnc, ast.parse('''a = 10''').body[0])