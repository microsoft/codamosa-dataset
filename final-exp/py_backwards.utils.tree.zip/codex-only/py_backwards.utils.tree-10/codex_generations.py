

# Generated at 2022-06-23 23:42:56.181933
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse(
        'def f():\n'
        '  a = "a"\n'
        '  b = "b"\n'
        '  c = "c"\n'
        '  d = "d"\n'
        '  e = "e"\n'
    ).body[0]
    assert isinstance(get_parent(node, node.body[0]), ast.FunctionDef)  # noqa
    assert isinstance(get_parent(node, node.body[0].value), ast.Assign)  # noqa
    assert isinstance(get_parent(node, node.body[0].value.s), ast.Assign)  # noqa



# Generated at 2022-06-23 23:42:56.756026
# Unit test for function find

# Generated at 2022-06-23 23:42:59.422778
# Unit test for function find
def test_find():
    tree = ast.parse("for i in range(10):\n    print(i)")
    assert list(find(tree, ast.For)) == [tree.body[0]]



# Generated at 2022-06-23 23:43:05.490499
# Unit test for function get_parent
def test_get_parent():
    class_node = ast.ClassDef(name='TestClass', body=[], decorator_list=[])
    function_node = ast.FunctionDef(name='func_1', body=[], args=[], returns=None)
    class_node.body += [function_node]

    parent = get_parent(class_node, function_node)
    assert parent == class_node

    with pytest.raises(NodeNotFound) as e:
        get_parent(class_node, None)
    assert str(e.value) == 'Parent for None not found'



# Generated at 2022-06-23 23:43:06.512608
# Unit test for function find

# Generated at 2022-06-23 23:43:10.526371
# Unit test for function find
def test_find():
    source = """
    def f():
        return 'hi'
    """

    tree = ast.parse(source)
    first_return = next(find(tree, ast.Return))

    assert first_return.value.s == 'hi'

# Generated at 2022-06-23 23:43:16.885283
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('x = 1')
    parent = get_parent(tree, tree.body[0].targets[0])
    insert_at(0, parent, ast.parse('y = 1').body[0])
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='y', ctx=Store()), Name(id='x', ctx=Store())], value=Num(n=1))])"



# Generated at 2022-06-23 23:43:28.039502
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    @adds()
    def foo():
        return 2 + 2

    from .structure import FunctionDef
    from .visitor import TransformationVisitor
    test_transformation_visitor = TransformationVisitor()
    function_def = FunctionDef(lineno=1, col_offset=0, name='foo',
                               args=foo.args,
                               body=[
                                   ast.Return(lineno=3, col_offset=4,
                                              value=foo.body.value)],
                               decorator_list=[],
                               returns=None)
    test_transformation_visitor.visit(function_def)
    test_transformation_visitor.visit(function_def.body[0])
    test_transformation_visitor.visit(function_def.body[0].value.left)

   

# Generated at 2022-06-23 23:43:33.502288
# Unit test for function get_parent
def test_get_parent():
    from .tests_helper_ast import build_ast
    from .tests_helper_nodes import find_all_nodes

    tree = build_ast()
    nodes = find_all_nodes(tree)

    for node in nodes:
        if node != tree:
            assert get_parent(tree, node) in nodes
            assert get_parent(tree, node, rebuild=True) in nodes

        else:
            with pytest.raises(NodeNotFound):
                get_parent(tree, node)

# Generated at 2022-06-23 23:43:36.277591
# Unit test for function replace_at
def test_replace_at():
    m = ast.parse('x = 1; y = 2')
    one = m.body[0]
    two = m.body[1]
    # replace first expression with second
    replace_at(0, m, two)
    assert m.body[0] == two
    replace_at(0, m, one)
    assert_raises(NodeNotFound, get_non_exp_parent_and_index, m, one)


# Generated at 2022-06-23 23:43:39.511466
# Unit test for function find
def test_find():
    ast_node = ast.parse("a = 1 + 1")
    nodes = find(ast_node, ast.Assign)
    assert next(nodes).targets[0].id == "a"

# Generated at 2022-06-23 23:43:46.732605
# Unit test for function get_parent
def test_get_parent():
    """Test for function get_parent."""
    ast_tree = ast.parse(
        'from math import pi as PI; def foo(x, y): return PI + x if x <= y else x')

    # pi
    pi = ast_tree.body[0].names[0]

    # PI
    pi_alias = ast_tree.body[0].names[1]

    # foo
    foo = ast_tree.body[1]

    # pi
    pi_name = foo.body[0].value.left

    # PI
    pi_alias_name = foo.body[0].value.right

    # x
    x_arg = foo.args.args[0]

    # x
    x_name = foo.body[0].value.comparators[0]

    # y
    y_arg = foo

# Generated at 2022-06-23 23:43:53.102390
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    root = ast.parse("a()\nb()")
    assert get_non_exp_parent_and_index(root, root.body[0]) == (root, 0)
    assert get_non_exp_parent_and_index(root, root.body[0].value) == (root, 0)

    root = ast.parse("a(1)\nb(2)")
    assert get_non_exp_parent_and_index(root, root.body[0]) == (root, 0)
    assert get_non_exp_parent_and_index(root, root.body[1]) == (root, 1)
    assert get_non_exp_parent_and_index(root, root.body[0].value) == (root, 0)

# Generated at 2022-06-23 23:44:00.995541
# Unit test for function insert_at
def test_insert_at():
    import ast
    import astor

    node = ast.parse("1 + 2").body[0]
    parent = ast.Module(body=[node])
    # assert len(parent.body) == 1

    if_node = ast.parse("if True:\n pass").body[0]
    assert len(parent.body) == 1
    insert_at(0, parent, if_node)
    # assert len(parent.body) == 1
    print(astor.dump(parent))


if __name__ == '__main__':
    test_insert_at()

# Generated at 2022-06-23 23:44:06.137464
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    compare_tree = ast.parse('a = [1, 2, 3]').body[0].value
    inner_tree = compare_tree.elts[0]

    exp_parent = ast.Expr(value=ast.Num(n=1))
    exp_parent_index = 0
    assert get_non_exp_parent_and_index(compare_tree, inner_tree) == \
           (exp_parent, exp_parent_index)

# Generated at 2022-06-23 23:44:13.453169
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def get_parent_and_index(tree, node):
        non_exp_par_and_index = get_non_exp_parent_and_index(tree, node)
        return non_exp_par_and_index[0], non_exp_par_and_index[1]

    tree = ast.parse('if test1: print("if"); elif test2: print("elif")')
    node = tree.body[0].body[0].value.args[0]
    assert get_parent_and_index(tree, node) == (tree.body[0], 0)

    tree = ast.parse('if test1: print("if"); elif test2: print("elif")')
    node = tree.body[0].body[0].value.args[0]

# Generated at 2022-06-23 23:44:14.586150
# Unit test for function find

# Generated at 2022-06-23 23:44:18.317938
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Test get_closest_parent_of function."""
    a = ast.parse('def func():\n\tpass\n')
    print(get_closest_parent_of(a, a, ast.FunctionDef))



# Generated at 2022-06-23 23:44:20.989025
# Unit test for function find
def test_find():
    test_node = find(ast.parse('x = 3 + y'), ast.Num)
    assert(isinstance(next(test_node), ast.Num))


# Generated at 2022-06-23 23:44:31.653719
# Unit test for function replace_at
def test_replace_at():
    def f():
        pass

    tree = ast.parse(textwrap.dedent(inspect.getsource(f)))
    print(ast.dump(tree))
    parent = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    print(ast.dump(parent))
    assert parent.name == 'f'

    # test simple replacement
    new_node = ast.if_()
    replace_at(0, parent, new_node)
    assert tree.body[0].body[0] == new_node

    # test new node is in right place
    replace_at(0, parent, ast.Expr())
    assert isinstance(parent.body[0], ast.Expr)

    # test new node is in right place

# Generated at 2022-06-23 23:44:32.235131
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:44:33.816554
# Unit test for function find
def test_find():
    """Tests the find function."""
    import unittest
    from typed_ast.ast3 import parse


# Generated at 2022-06-23 23:44:44.555434
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class Test(ast.AST):
        def __init__(self, body: ast.AST):
            self.body = [body]

        _fields = ('body',)

    a, b, c, d, e, f, g = ast.parse(
        '''a = 10
        if b:
            c = 20
            for d in e:
                f = 30
                g = 40'''
    ).body

    g.value = Test(g.value)
    e.value = Test(e.value)
    b.body = Test(b.body)
    a = Test(a)

    assert get_non_exp_parent_and_index(a, g) == (a, 2)
    assert get_non_exp_parent_and_index(a, b) == (a, 1)
    assert get

# Generated at 2022-06-23 23:44:54.013957
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 23:44:57.985471
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as ast

    tree = ast.parse('def f():\n\treturn 1')
    node = tree.body[0].body[0]

    assert get_non_exp_parent_and_index(tree, node) == (tree.body[0], 0)


# Unit test functions

# Generated at 2022-06-23 23:45:04.590208
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import pandas as pd

    coded_string = """data = pd.DataFrame([1, 2])
    value = data.loc[0]
    """
    tree = ast.parse(coded_string)
    node = get_closest_parent_of(tree, tree.body[1].value, ast.Call)
    assert(isinstance(node.func, ast.Name))
    assert(node.func.id == 'pd')



# Generated at 2022-06-23 23:45:11.577291
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse(
        '''
        def test(x):
            y = x
            return y
        '''
    )
    name1 = tree.body[0].body[0].body[0].value
    name2 = tree.body[0].body[0].body[1].value.value
    assert name1 is name2
    replace_at(0, tree.body[0].body[0], [ast.parse('y = x+1').body[0]])
    name1 = tree.body[0].body[0].body[0].value
    name2 = tree.body[0].body[0].body[1].value.value
    assert name1 is not name2

# Generated at 2022-06-23 23:45:18.768615
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3 as ast

    module = ast.Module(body=[ast.Assign(targets=[ast.Name(id='a')],
                                         value=ast.Num(n=1))])
    parent = get_parent(module, module.body[0])
    assert parent == module
    assert module.body[0].value.n == 1
    insert_at(0, module, ast.Num(n=9))
    assert module.body[0].value.n == 9



# Generated at 2022-06-23 23:45:27.795545
# Unit test for function find
def test_find():
    from ..parsing import parse_code
    from . import get_used_names, get_assignment_nodes
    tree = parse_code('a = 1\nb = 2\nprint(a, b)')
    assignments = list(find(tree, ast.Assign))
    assert len(assignments) == 2
    assert tree.body[0] in assignments
    assert tree.body[1] in assignments
    assert not list(find(tree, ast.Name))
    names = list(find(tree, ast.Name))
    assert tree.body[2].value.args[0] in assignments
    get_assignment_nodes(get_used_names(tree))

# Generated at 2022-06-23 23:45:33.271359
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_node = ast.parse(
        "def foo(x):\n" +
        "    if x > 3:\n" +
        "        return x + 1\n" +
        "    else:\n" +
        "        return x\n").body[0].body[1]
    assert ast.If is type(get_closest_parent_of(
        test_node, test_node, ast.If))
    assert ast.FunctionDef is type(get_closest_parent_of(
        test_node, test_node, ast.FunctionDef))

# Generated at 2022-06-23 23:45:39.725436
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def b():
        pass

    def a():
        b()

    a_node = ast.parse(inspect.getsource(a)).body[0]
    b_node = a_node.body[0]
    test_node = b_node.body[0]
    assert get_closest_parent_of(a_node, test_node, ast.FunctionDef) is b_node



# Generated at 2022-06-23 23:45:43.048462
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = "if(True):\n    a = b"
    tree = ast.parse(source)
    node = tree.body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.If)
    assert parent.test.value.id == 'True'

# Generated at 2022-06-23 23:45:50.569754
# Unit test for function get_parent
def test_get_parent():
    # Create tree
    # Class
    class_def = ast.ClassDef(name='ExampleClass', bases=[], keywords=[],
                             starargs=None, kwargs=None, body=[], decorator_list=[],
                             lineno=1, col_offset=0)
        # Function
    class_func = ast.FunctionDef(name='test_func', args=ast.arguments(args=[], vararg=None,
                                                                      kwonlyargs=[], kw_defaults=[],
                                                                      kwarg=None, defaults=[]),
                                 body=[], decorator_list=[], returns=None)  # type: ignore
        # Statement
    function_stmt = ast.Expr(value=ast.Name(id='value', ctx=ast.Load()))
    # Append nodes
   

# Generated at 2022-06-23 23:45:59.375503
# Unit test for function get_parent
def test_get_parent():
    # Test valid parent
    ast_node1 = ast.Name()
    ast_node2 = ast.Name()
    ast_node1.lineno = None
    ast_node1.col_offset = None
    ast_node2.lineno = None
    ast_node2.col_offset = None
    ast_node1.id = "test"
    ast_node2.id = "test"
    ast_node1.ctx = ast.Store()
    ast_node2.ctx = ast.Load()

    ast_parent = ast.Assign()
    ast_parent.lineno = None
    ast_parent.col_offset = None
    ast_parent.targets = [ast_node1]
    ast_parent.value = ast_node2

    _build_parents(ast_parent)

    assert ast_

# Generated at 2022-06-23 23:46:00.459578
# Unit test for function insert_at

# Generated at 2022-06-23 23:46:10.646476
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # type: () -> None
    from typing import Optional

    class DummyClass(object):
        pass

    class DummyParentClass(DummyClass):
        pass

    class DummyChildClass(DummyClass):
        pass

    def search_parent_of(node):
        # type: (DummyChildClass) -> Optional[DummyClass]
        parent = get_parent(node, node)
        while parent is not None:
            if isinstance(parent, DummyClass):
                return parent
            parent = get_parent(node, parent)
        return None

    node = DummyChildClass()
    assert search_parent_of(node) is None
    assert get_closest_parent_of(node, node, DummyClass) is None

    node.parent = DummyParentClass()
    assert get_clos

# Generated at 2022-06-23 23:46:11.559256
# Unit test for function find
def test_find():
    assert [] == list(find(ast.parse('def a(): pass'), ast.FunctionDef))

# Generated at 2022-06-23 23:46:15.823804
# Unit test for function replace_at
def test_replace_at():
    assert ast.parse('x = 0', mode='eval').body.value.n == 0

    tree = ast.parse('y = 0')

    node = tree.body[0].value
    parent = tree.body[0]

    node.n = 2

    replace_at(0, parent, node)

    assert tree.body[0].value.n == 2

# Generated at 2022-06-23 23:46:25.974749
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..compat import string_types

    def get_ast(node: string_types) -> ast.AST:
        return astor.parse_file(node)

    expr = """if 1 + 1:
    foo()
    if True:
        bar(foo())
        if False:
            baz()"""
    tree = get_ast(expr)

    def check_closest(node: str, type_: Type[ast.AST]) -> None:
        node = tree.body[0].body[1].body[1].body[1]
        parent = get_closest_parent_of(tree, node, type_)

        assert parent is not None
        assert isinstance(parent, type_)

    check_closest("if False", ast.If)

# Generated at 2022-06-23 23:46:32.544391
# Unit test for function replace_at
def test_replace_at():
    program = ast.parse('''def f():
                              a = 1
                              b = 2
                           ''')
    assert_equals = inspect.cleandoc('''def f():
                                          a = 1
                                          c = 3
                                          d = 4
                                          b = 2
                                       ''')

    replace_at(2, program.body[0], [ast.parse('c = 3\nd = 4').body[0]])
    assert ast.dump(program) == assert_equals

# Generated at 2022-06-23 23:46:42.897629
# Unit test for function replace_at
def test_replace_at():
    ast_node = ast.parse('a + (b + c)')
    node = ast_node.body[0].value.right
    parent = get_non_exp_parent_and_index(ast_node, node)[0]
    replace_at(0, parent, ast.BinOp(left=ast.Name(id='b', ctx=ast.Load()),
                                    op=ast.Add(), right=ast.Name(id='c',
                                                                 ctx=ast.Load())))
    assert ast.dump(ast_node) == 'Module(body=[Expr(value=BinOp(left=Name(id=\'a\', ctx=Load()), op=Add(), right=BinOp(left=Num(n=1), op=Add(), right=Num(n=2))))])\n'


# Generated at 2022-06-23 23:46:45.768448
# Unit test for function find
def test_find():
    tree = ast.parse("a + b")
    assert list(find(tree, ast.Tuple)) == []
    assert list(find(tree, ast.BinOp)) == [tree.body[0].value]

# Generated at 2022-06-23 23:46:56.384773
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    from ast import parse
    tree = parse("""
    def foo():
       j = (1 if True else 2, 4, 9)
       for i in range(10):
           pass
    """)
    print(astor.dump(tree))
    print(get_non_exp_parent_and_index(tree, tree.body[0].body[0]))
    print(get_non_exp_parent_and_index(tree, tree.body[0].body[1]))

    tree = parse("""
    def foo():
       j = (1 if True else 2) + 4 * 9
       for i in range(10):
           pass
    """)
    print(astor.dump(tree))

# Generated at 2022-06-23 23:47:02.712762
# Unit test for function insert_at
def test_insert_at():
    class Parent(ast.AST):
        _fields = ('body',)

    class ChildA(ast.AST):
        _fields = ()

    class ChildB(ast.AST):
        _fields = ()

    parent = Parent()

    # insert first element
    insert_at(0, parent, ChildA())
    assert isinstance(parent.body[0], ChildA)

    # insert middle element
    insert_at(1, parent, ChildB())
    assert isinstance(parent.body[1], ChildB)

    # insert last element
    insert_at(3, parent, ChildA())
    assert isinstance(parent.body[3], ChildA)


# Generated at 2022-06-23 23:47:03.477566
# Unit test for function get_parent

# Generated at 2022-06-23 23:47:07.965741
# Unit test for function find
def test_find():
    code = """
    def x():
        pass
    """
    tree = ast.parse(code)
    assert len([i for i in find(tree, ast.FunctionDef)]) == 1
    assert len([i for i in find(tree, ast.Pass)]) == 1

# Generated at 2022-06-23 23:47:16.129830
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Cls1(object):
        pass

    class Cls2(object):
        pass

    class Cls3(Cls1):
        pass

    class Cls4(Cls1):
        def __init__(self, cls3: Cls3):
            self.cls3 = cls3

    class Cls5(Cls2):
        def __init__(self, cls4: Cls4):
            self.cls4 = cls4

    class Cls6(Cls2):
        def __init__(self, cls2: Cls2):
            self.cls2 = cls2

    class Cls7(Cls1):
        def __init__(self, cls6: Cls6 = None):
            self.cls6 = cls6


# Generated at 2022-06-23 23:47:19.428914
# Unit test for function find
def test_find():
    tree = ast.parse('print(123)\nprint(456)\nprint(789)')
    print_nodes = find(tree, ast.Print)

    assert len(list(print_nodes)) == 3

# Generated at 2022-06-23 23:47:29.882119
# Unit test for function insert_at
def test_insert_at():
    import astor

    from .nodes import If
    from .bases import Scope, Expression

    class Test1(ast.AST):
        _fields = ('body', )

        body: ast.AST

    class Test2(ast.AST):
        body: ast.AST
        _fields = ('body', )

    class Test3(ast.AST):
        body: ast.AST
        _fields = ('body', )

    class Test4(ast.AST):
        value: ast.AST
        _fields = ('value', )

    class Test5(ast.AST):
        _fields = ('body', )

    class Test6(ast.AST):
        body: ast.AST
        _fields = ('body', )

    class Test7(ast.AST):
        _fields = ('body', )

    t1 = Test1()


# Generated at 2022-06-23 23:47:33.842857
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('i = 5')

    assert get_parent(tree, tree.body[0]) == tree

    i = tree.body[0].value.left
    assert get_parent(tree, i) == tree.body[0].value

    assert get_parent(tree, tree.body[0].value.right) == tree.body[0]



# Generated at 2022-06-23 23:47:44.970193
# Unit test for function insert_at
def test_insert_at():
    import astor
    # Test insert_at with simple FunctionDef
    test_body = [ast.Expr(ast.Str('a')), ast.Expr(ast.Str('b')),
                 ast.Expr(ast.Str('c')), ast.Expr(ast.Str('d'))]
    test_func_src = astor.to_source(ast.FunctionDef('test', None,
        ast.arguments(args=[], vararg=None, kwarg=None, kwonlyargs=[],
                      kw_defaults=[], defaults=[]), test_body, []))

    test_func = astor.parse_file(test_func_src).body[0]
    insert_at(1, test_func, ast.Expr(ast.Str('e')))
    assert astor.to_source

# Generated at 2022-06-23 23:47:54.218672
# Unit test for function find
def test_find():
    from ..bricks.visitor import Visitor
    from ..exceptions import NodeNotFound
    import astor
    from astor.code_gen import to_source

    class Finder(Visitor):
        def visit_Assign(self, node: ast.Assign) -> None:
            self.visit(node.value)
            self.visit(node.targets[0])

        def visit_Str(self, node: ast.Str) -> None:
            if node.s == 'def':
                raise NodeNotFound(node)

    visitor = Finder()

    tree = astor.parse('def a():\n    b = "def"')
    node = next(find(tree, ast.FunctionDef))
    visitor.visit(node)


_parents = WeakKeyDictionary()  # type: WeakKeyDictionary

# Generated at 2022-06-23 23:47:55.415257
# Unit test for function insert_at
def test_insert_at():
    # TODO: Implement
    pass



# Generated at 2022-06-23 23:47:59.298861
# Unit test for function find
def test_find():
    tree = ast.parse('x = 1')
    result = list(find(tree, ast.Name))
    assert len(result) == 1
    assert result[0].id == 'x'
    assert result[0].ctx.__class__ == ast.Store

# Generated at 2022-06-23 23:48:00.374430
# Unit test for function find

# Generated at 2022-06-23 23:48:10.950154
# Unit test for function insert_at
def test_insert_at():
    import ast
    from astor.code_gen import to_source
    a = ast.parse('x = 1')
    insert_at(0, a, ast.Num(2))
    insert_at(1, a, ast.Num(3))
    insert_at(1, a, ast.Num(4))
    insert_at(3, a, ast.Num(5))
    insert_at(4, a, ast.Num(6))
    insert_at(4, a, ast.Num(7))
    insert_at(4, a, ast.Num(8))
    insert_at(4, a, ast.Num(9))
    insert_at(4, a, ast.Num(10))
    insert_at(len(a.body), a, ast.Num(11))

# Generated at 2022-06-23 23:48:16.815159
# Unit test for function insert_at
def test_insert_at():
    import astor
    a = ast.parse("def foo(a):\n    print(a)")
    insert_at(0, a.body[0], ast.Expr(value=ast.Name(id='foo', ctx=ast.Load())))
    assert astor.to_source(a) == "def foo(a):\n    foo\n    print(a)"



# Generated at 2022-06-23 23:48:23.276732
# Unit test for function get_parent
def test_get_parent():
    node = ast.Module(body=[
        ast.Import(names=[
            ast.alias(name='x', asname='y')
        ])
    ])
    _build_parents(node)
    assert get_parent(node, ast.alias(name='x', asname='y')) == ast.Import
    assert get_parent(node, ast.Import(names=[ast.alias(name='x', asname='y')]))\
        == ast.Module



# Generated at 2022-06-23 23:48:23.900855
# Unit test for function get_parent

# Generated at 2022-06-23 23:48:25.268478
# Unit test for function find
def test_find():
    test_ast = ast.parse("def foo():\n  print()")
    assert len(list(find(test_ast, ast.FunctionDef))) == 1

# Generated at 2022-06-23 23:48:26.116239
# Unit test for function replace_at
def test_replace_at():
    pass


# Generated at 2022-06-23 23:48:38.059012
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    # Simple test
    test_code = '''
    def f():
        x = 1
        return x
    '''
    tree = ast.parse(test_code)
    x = list(find(tree, ast.Name))[0]
    f = get_closest_parent_of(tree, x, ast.FunctionDef)
    assert astor.to_source(f) == 'def f():\n    x = 1\n    return x'

    # Harder test
    test_code = '''
    def f():
        with open('file', 'r') as f:
            for x in f:
                x
    '''
    tree = ast.parse(test_code)
    x = list(find(tree, ast.Name))[0]
    f = get_clos

# Generated at 2022-06-23 23:48:45.381584
# Unit test for function get_parent
def test_get_parent():
    _parents.clear()

    class _Node(ast.AST):
        body = []
        _attributes = ('body',)

    class _Child(ast.AST):
        pass

    node = _Node()
    child = _Child()
    node.body.append(child)

    assert get_parent(node, child) is node
    assert get_parent(node, child, rebuild=True) is node



# Generated at 2022-06-23 23:48:51.669400
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('for i in range(10):\n  print(i)\n')
    assign_node = ast.Assign(targets=[ast.Name(id='i', ctx=ast.Store())], value=ast.Num(n=1))

    insert_at(0, tree.body[0].body, assign_node)

    assert str(tree) == 'for i in range(10):\n  i = 1\n  print(i)\n'



# Generated at 2022-06-23 23:48:56.174174
# Unit test for function replace_at
def test_replace_at():
    class TestParent:
        def __init__(self, lst):
            self.body = lst

    tp = TestParent([1, 2, 3, 4, 5])
    replace_at(2, tp, [8, 8])
    assert tp.body == [1, 2, 8, 8, 4, 5]



# Generated at 2022-06-23 23:49:01.453707
# Unit test for function get_parent
def test_get_parent():
    """Test for the get_parent functionality."""
    module = ast.parse("""
        def abc(d):
            d = 5
            e = 7
            return d+e
    """)
    function = module.body[0]
    assert module is function.parent
    assert function.body[2].value.n == 5
    assert function.body[2].lineno == 2
    assert get_nonexp_parent_and_index(module, module.body[2].value) == (module.body[2], 0)


# Generated at 2022-06-23 23:49:05.921551
# Unit test for function insert_at

# Generated at 2022-06-23 23:49:08.122335
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n print(foo)')
    assert list(find(tree, ast.Call))[0].func.id == 'print'

# Generated at 2022-06-23 23:49:16.602457
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = """if (True):
    abc = 'lol'
"""
    tree = ast.parse(source)
    assign = tree.body[0].body[0]

    non_exp = get_non_exp_parent_and_index(tree, assign)
    assert isinstance(non_exp[0], ast.FunctionDef)
    assert non_exp[1] == 0



# Generated at 2022-06-23 23:49:20.960494
# Unit test for function replace_at
def test_replace_at():  # pragma: no cover
    import astunparse

# Generated at 2022-06-23 23:49:28.397462
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert get_closest_parent_of(
        ast.Module([
            ast.FunctionDef('f', ast.arguments([], [], [], [], None, []), [
                ast.ClassDef('C', [], [], [], []),
            ], [], None, None),
        ]),
        ast.Assign([ast.Name('a', ast.Store(), None, None)],
                   ast.Num(1, None), None, None),
        ast.FunctionDef
    ) == ast.FunctionDef('f', ast.arguments([], [], [], [], None, []), [
        ast.ClassDef('C', [], [], [], []),
    ], [], None, None)

# Generated at 2022-06-23 23:49:32.923163
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('foo(a, b)', 'test_get_closest_parent_of')
    assert isinstance(get_closest_parent_of(tree, tree.body[0].value.args[0],
                     ast.arguments), ast.arguments)



# Generated at 2022-06-23 23:49:33.420598
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass



# Generated at 2022-06-23 23:49:38.646399
# Unit test for function insert_at
def test_insert_at():
    import astor
    E = ast.Expr
    I = ast.Import
    M = ast.Module
    B = ast.Alias
    m = M(body=[I(names=[B(name='sys')])])

    insert_at(0, m, E(value=ast.Constant(1)))
    assert astor.to_source(m) == 'import sys\n1\n'

# Generated at 2022-06-23 23:49:50.126415
# Unit test for function insert_at
def test_insert_at():
    body = [ast.Expr(ast.Call(ast.Name(id='f', ctx=ast.Load()), [],
                              [], [], None)),
            ast.Expr(ast.Call(ast.Name(id='g', ctx=ast.Load()),
                              [ast.Name(id='a', ctx=ast.Load())], [],
                              [], None)),
            ast.Expr(ast.Call(ast.Name(id='f', ctx=ast.Load()), [],
                              [], [], None))]

# Generated at 2022-06-23 23:49:55.082849
# Unit test for function insert_at
def test_insert_at():
    node = ast.parse("class test: pass\n")
    parent = get_closest_parent_of(node, node.body[0], ast.Module)
    insert_at(0, parent, ast.parse("i=4\n"))
    assert ast.dump(parent) == 'Module(body=[<_ast.Assign object at 0x10a93a898>, <_ast.ClassDef object at 0x10a93a9e8>])'

# Generated at 2022-06-23 23:49:58.302344
# Unit test for function find
def test_find():
    assert list(find(
        ast.parse('''def test():\n    a = 1\n    b = 2\n    c = 3'''),
        ast.Name)) == [ast.Name(id='test', ctx=ast.Load())]



# Generated at 2022-06-23 23:50:02.958362
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('if True: a = 5')

    parent, child_index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    assert parent == tree.body[0]
    assert child_index == 0

# Generated at 2022-06-23 23:50:06.436256
# Unit test for function find
def test_find():
    tree = ast.parse("""{2 if True else 3}""")
    ifelses = find(tree, ast.If)
    assert len(list(ifelses)) == 1
    assert isinstance(list(ifelses)[0], ast.If)

# Generated at 2022-06-23 23:50:15.057877
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = 'def add(a, b):\n    return a + b\n'
    top, = ast.parse(code).body

    def_, = top.body

    defclause, _ = def_.body  # type: ignore
    return_, = _.body  # type: ignore
    binop, = return_.value.ops  # type: ignore
    add, = binop.values  # type: ignore
    name = add.left.id  # type: ignore

    assert get_non_exp_parent_and_index(top, name) == (def_, 0)

# Generated at 2022-06-23 23:50:20.830991
# Unit test for function find
def test_find():
    import astor
    module = astor.parse_file("code_samples/sample_5.py")
    for node in find(module, ast.Expr):
        print("Expr: ", astor.to_source(node))
    for node in find(module, ast.Assign):
        print("Assign: ", astor.to_source(node))



# Generated at 2022-06-23 23:50:29.302305
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('''
x = [1, 2, 3, 4]
for a in x:
    print(a)
print(a)
    ''')
    from typed_ast import _ast3

    def func(x: _ast3.Module) -> _ast3.Module:
        t = x
        t.body[0].value.elts[1].n = 7
        return t

    func(tree)

    i = 1
    parent = tree
    nodes = [ast.Num(n=10)]
    replace_at(i, parent, [ast.Num(n=10)])
    assert tree.body[0].value.elts[1].n == 10



# Generated at 2022-06-23 23:50:34.829575
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = "def foo():\n"\
           "   a = 10\n"\
           "   b = 20\n"\
           "   print(a + b)"

    tree = ast.parse(code)
    node_of_type_functiondef = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    assert node_of_type_functiondef.name == 'foo'

# Generated at 2022-06-23 23:50:37.736662
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse(
        'def foo():\n'
        '    return 1\n')
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)

# Generated at 2022-06-23 23:50:40.103462
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1\nb = 2')
    func, arg = list(find(tree, ast.FunctionDef))
    insert_at(3, tree.body[0], [ast.Expr(ast.Pass())])

# Generated at 2022-06-23 23:50:47.151053
# Unit test for function replace_at
def test_replace_at():
    import ast

    new_nodes = [
        ast.parse("a = a + 2")
    ]

    tree = ast.parse("a = a + 1")

    new_nodes[0].body[0].value.value.left = tree.body[0].value.value
    replace_at(0, tree, new_nodes)

    print(tree)

# Generated at 2022-06-23 23:50:53.422868
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import inspect

    x = ast.parse(inspect.getsource(get_closest_parent_of))
    fn = x.body[0]

    cls = get_closest_parent_of(x, fn.args.defaults[0], ast.ClassDef)

    assert cls.name == 'TestClass'



# Generated at 2022-06-23 23:50:57.772590
# Unit test for function insert_at
def test_insert_at():
    class Parent(ast.AST):
        body = []

    node = ast.parse('a = 3')

    parent = Parent()
    insert_at(0, parent, node)

    assert parent.body[0].__class__.__name__ == 'Assign'

# Generated at 2022-06-23 23:51:02.690874
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .test_code_samples import test_code_2
    _build_parents(ast.parse(test_code_2))
    node = find(ast.parse(test_code_2), ast.Name).next()
    assert isinstance(get_closest_parent_of(ast.parse(test_code_2), node,
                                            ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-23 23:51:05.356692
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:51:12.036595
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_astunparse
    import ast
    import astor
    code = "my_func(my_other_func(my_arg), my_third_func(my_third_arg))"
    parsed = ast.parse(code)
    ast_node = parsed.body[0].value
    result = get_closest_parent_of(ast_node, ast_node.keywords[0].value, ast.Call)
    assert typed_astunparse.unparse(result) == "my_other_func(my_arg)"



# Generated at 2022-06-23 23:51:20.248011
# Unit test for function insert_at
def test_insert_at():
    """Tests insert_at funciton."""
    func = ast.FunctionDef(name='foo',
                           args=ast.arguments(args=[ast.arg(arg='bar')],
                                              vararg=None,
                                              kwonlyargs=[],
                                              kw_defaults=[],
                                              kwarg=None,
                                              defaults=[]),
                           body=[ast.Pass()],
                           decorator_list=[],
                           returns=None)
    insert_at(0, func, [ast.Import('foo')])
    assert func.body == [ast.Import('foo'), ast.Pass()]



# Generated at 2022-06-23 23:51:28.355342
# Unit test for function insert_at
def test_insert_at():
    from ..parser import AstParser
    from . import NodeUtils

    parser = AstParser('def f(): return 1')
    function = NodeUtils.get_closest_parent_of(parser.tree, parser.tree.body[0].body[0], ast.FunctionDef)
    insert_at(0, function, parser.tree.body[0].body[0])
    assert parser.tree.body[0].body[0].value.n == 1

# Generated at 2022-06-23 23:51:35.409520
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from astunparse import unparse
    from ast import parse

    code = '''def foo():
        print('asd')
        for i in range(5):
            print('asd')
    '''
    tree = parse(code)

    print(unparse(tree))

    call_node = get_closest_parent_of(tree, get_closest_parent_of(tree,
                                                                  tree.body[0].body[0].value,
                                                                  ast.Call),
                                      ast.For)

    parent, index = get_non_exp_parent_and_index(tree, call_node)


# Generated at 2022-06-23 23:51:42.938104
# Unit test for function get_parent
def test_get_parent():
    root = ast.parse("""
    if True:
        for i in [1]:
            pass
    if False:
        pass
    def f():
        pass
    """)  # type: ast.Module

    parents = [None, root, root.body[0], root.body[0].body[0],
               root.body[1], root.body[1].body[0], root.body[2],
               root.body[2].body[0]]

    for node, expected in zip(ast.walk(root), parents):
        parent = get_parent(root, node)
        assert parent == expected



# Generated at 2022-06-23 23:51:50.213846
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("def foo():\n\treturn 1\nx = 5\n")
    parent = get_closest_parent_of(tree, tree.body[0].body[0], ast.AST)
    replace_at(0, parent, ast.Return(value=ast.Num(2)))
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Num(n=2))], decorator_list=[]), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=5))])"

# Generated at 2022-06-23 23:52:01.430235
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert get_closest_parent_of(ast.parse("a + b + c"),
                                 ast.parse("b + c").body[0],
                                 ast.Module) == ast.parse("a + b + c")
    assert get_closest_parent_of(ast.parse("a + b + c"),
                                 ast.parse("a + b").body[0].value,
                                 ast.BinOp) == ast.parse("a + b").body[0]
    assert get_closest_parent_of(ast.parse("a + b + c"),
                                 ast.parse("b + c").body[0].value,
                                 ast.BinOp) == ast.parse("b + c").body[0]

# Generated at 2022-06-23 23:52:09.793886
# Unit test for function insert_at
def test_insert_at():
    """ Test for function insert_at. """
    parent = ast.parse("def a():\n    pass")

    body_len = len(parent.body)

    insert_at(0, parent, [ast.Pass()])

    assert len(parent.body) == body_len + 1

    insert_at(1, parent, [ast.Assign(), ast.AugAssign()])

    assert len(parent.body) == body_len + 3



# Generated at 2022-06-23 23:52:17.880666
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('if True: [1, 2, 3]')
    node = tree.body[0].body
    insert_at(1, node, ast.Constant(0))
    assert ast.dump(tree) == 'Module(body=[If(test=NameConstant(value=True), ' \
                            'body=[List(elts=[Constant(value=1), Constant(' \
                            'value=0), Constant(value=2), Constant(value=3)])], ' \
                            'orelse=[])])'



# Generated at 2022-06-23 23:52:19.136654
# Unit test for function replace_at

# Generated at 2022-06-23 23:52:20.151425
# Unit test for function find

# Generated at 2022-06-23 23:52:26.137700
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = '''
    if True:
        pass
    '''
    tree = ast.parse(source)
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.If)
    assert index == 0
    assert parent == node.parent


# Generated at 2022-06-23 23:52:35.679967
# Unit test for function find
def test_find():
    class TestClass1(ast.AST):
        _fields = 'a', 'b', 'c'

    class TestClass2(ast.AST):
        _fields = 'a', 'b', 'c'

    class TestClass3(ast.AST):
        _fields = 'a', 'b', 'c'

    node = ast.parse(
        '''
        class A:
            pass
        class B:
            pass
        class C:
            pass
    ''')
    found = find(node, TestClass1)
    assert len(found) == 3
    assert all([isinstance(node, TestClass1) for node in found])

    found = find(node, TestClass2)
    assert len(found) == 0

    found = find(node, TestClass3)
    assert len(found) == 0




# Generated at 2022-06-23 23:52:40.144962
# Unit test for function replace_at
def test_replace_at():
    testAST = ast.parse('a = 1\nb = 2\nc = 3', mode='exec')
    replace_at(0, get_parent(testAST, testAST.body[0]), ast.parse('a = 2', mode='exec').body[0])
    assert ast.dump(testAST) == '<_ast.Module object at 0x7fbff0d5ab00>'

# Generated at 2022-06-23 23:52:42.200499
# Unit test for function insert_at
def test_insert_at():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-23 23:52:45.997393
# Unit test for function get_parent
def test_get_parent():
    code = '''
    def foo():
        pass 
    '''
    tree = ast.parse(code)
    node = tree.body[0].body[0]
    parent = get_parent(tree, node)
    assert parent == tree.body[0]



# Generated at 2022-06-23 23:52:52.903196
# Unit test for function replace_at
def test_replace_at():
    from ..replacer import replace_assign_target
    from .utils import make_tree

    tree = make_tree("""
    {
        a = a1
    }
    """)

    replace_assign_target(tree)

    assert str(tree) == """
    {
        a1 = a1
    }
    """