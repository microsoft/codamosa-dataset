

# Generated at 2022-06-23 23:42:56.932772
# Unit test for function get_parent
def test_get_parent():
    node1 = ast.parse('a = 1\nb = 2', mode='exec').body[0]
    node2 = ast.parse('a = 1\nb = 2', mode='exec').body[1]
    node3 = ast.parse('a = 1\nb = 2', mode='exec').body

    assert get_parent(node1, node1.targets[0]) == node1
    assert isinstance(get_parent(node1, node1.value), ast.Module)
    assert get_parent(node2, node2.targets[0]) == node2
    assert isinstance(get_parent(node2, node2.value), ast.Module)
    assert get_parent(node3, node2.targets[0]) == node2

# Generated at 2022-06-23 23:43:01.522184
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_str = """
    def f():
        print(a)
    """
    ast_tree = ast.parse(ast_str)
    stmt = find(ast_tree, ast.Expr).__next__()
    assert isinstance(get_closest_parent_of(ast_tree, stmt, ast.FunctionDef), ast.FunctionDef)

# Generated at 2022-06-23 23:43:02.227977
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass


# Generated at 2022-06-23 23:43:05.201580
# Unit test for function insert_at
def test_insert_at():
    class ClassDef(ast.AST):
        _fields = ['body']

    tree = ClassDef()
    tree.body = [ast.Pass()]
    insert_at(0, tree, ast.Pass())
    assert len(tree.body) == 2

# Generated at 2022-06-23 23:43:16.152475
# Unit test for function find
def test_find():
    import unittest

    _tree = ast.parse("""if True:
    a = 1
    a = 2
    a = 3
    """)
    _nodes = find(_tree, ast.Assign)
    _nodes = list(_nodes)
    _a = _tree.body[0].body[0]
    _b = _tree.body[0].body[1]
    _c = _tree.body[0].body[2]

    class TestFind(unittest.TestCase):
        def test_find(self):
            self.assertEqual(len(_nodes), 3)
            self.assertEqual(_nodes[0], _a)
            self.assertEqual(_nodes[1], _b)
            self.assertEqual(_nodes[2], _c)

    return

# Generated at 2022-06-23 23:43:27.363272
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = 'for i in range(1):\n    print(1)'
    tree = ast.parse(code)

    print_ = tree.body[0].body[0]
    for_ = tree.body[0]

    parent, index = get_non_exp_parent_and_index(tree, print_)

    assert parent == for_
    assert index == 0

    code = 'for i in range(1):\n    print(1)\n    print(2)'
    tree = ast.parse(code)

    print_ = tree.body[0].body[1]
    for_ = tree.body[0]

    parent, index = get_non_exp_parent_and_index(tree, print_)

    assert parent == for_
    assert index == 1


# Generated at 2022-06-23 23:43:28.310251
# Unit test for function replace_at

# Generated at 2022-06-23 23:43:35.562170
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast

    import astunparse
    tree = ast.parse('x = 0')
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    print(parent)
    print(index)
    assert astunparse.unparse(parent) == 'x = 0'
    assert index == 0

    tree = ast.parse('x = 1\ny = 2')
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    print(parent)
    print(index)
    assert astunparse.unparse(parent) == 'x = 1\ny = 2'
    assert index == 0


# Generated at 2022-06-23 23:43:46.228822
# Unit test for function get_parent
def test_get_parent():
    a_stmt = ast.parse('a = 1; a').body[0]
    a_assign = a_stmt.value
    a_name = a_assign.targets[0]

    _parents.clear()
    _build_parents(a_stmt)
    assert get_parent(a_stmt, a_stmt) == a_stmt
    assert get_parent(a_stmt, a_assign) == a_stmt
    assert get_parent(a_stmt, a_name) == a_assign

    b_stmt = ast.parse('b = 2; b').body[0]
    b_assign = b_stmt.value
    b_name = b_assign.targets[0]

    _parents.clear()

# Generated at 2022-06-23 23:43:52.824674
# Unit test for function insert_at
def test_insert_at():
    """Test function 'insert_at'."""
    tree = ast.parse('''
        def foo():
            pass
        def bar():
            import foo
            if True:
                pass
            if True:
                pass
    ''')

    # check if multiple nodes can be inserted
    insert_at(0, tree.body[1], [ast.Import(names=ast.alias(name='foo', asname='a')),
                                ast.Import(names=ast.alias(name='bar', asname='b'))])

    # import foo
    # import bar
    # def foo():
    #     pass
    assert(tree.body[0].names[0].name == 'foo')
    assert(tree.body[0].names[1].name == 'bar')
    # check if single node can be inserted
    insert

# Generated at 2022-06-23 23:43:58.159563
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    child = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                       value=ast.Num(n=5))
    tree = ast.Module(body=[child])

    parent, index = get_non_exp_parent_and_index(tree, child)

    assert parent is tree
    assert index == 0



# Generated at 2022-06-23 23:44:00.946758
# Unit test for function find
def test_find():
    source = 'if x == 5:\n    print(5)'
    tree = ast.parse(source)
    assert len(list(find(tree, ast.If))) == 1

# Generated at 2022-06-23 23:44:04.159533
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def f(): pass')
    node = tree.body[0]
    a = get_closest_parent_of(tree, node, ast.Module)
    assert a == tree


# Generated at 2022-06-23 23:44:06.632733
# Unit test for function insert_at
def test_insert_at():
    node = ast.parse("def a():\n    pass").body[0]
    insert_at(0, node, ast.Pass())

    assert node.body[0].body[0].body[0].value is None



# Generated at 2022-06-23 23:44:10.324945
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.FunctionDef('test', ast.arguments([]))
    node = ast.Return(node)
    node = ast.Module([node])
    parent = get_closest_parent_of(node, node.body[0].value, ast.FunctionDef)
    assert isinstance(node, ast.Module)


# Generated at 2022-06-23 23:44:14.792220
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('if True: pass')
    node = tree.body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.If)
    assert isinstance(parent, ast.If)

# Generated at 2022-06-23 23:44:24.984135
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    # import astor.ast_to_source
    # import astor.source_to_ast
    import peft.frontend
    import peft.ast_utils
    import peft.transformations

    code = '''
        for i in range(10):
            a = i
        '''

    tree = ast.parse(code)
    peft.frontend.visit(tree)
    peft.transformations.visit(tree)
    assert isinstance(peft.ast_utils.get_closest_parent_of(tree, tree.body[0].body[0].value, (ast.For)), peft.For)
    # print(astor.ast_to_source(tree))

# Generated at 2022-06-23 23:44:30.448758
# Unit test for function insert_at
def test_insert_at():
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            class A(ast.AST):
                _fields = ('body',)

                def __init__(self, body):
                    self.body = body

            a = A([])
            insert_at(0, a, 1)
            self.assertEqual(a.body, [1])

            insert_at(1, a, 2)
            self.assertEqual(a.body, [1, 2])

            insert_at(2, a, 3)
            insert_at(0, a, 4)
            self.assertEqual(a.body, [4, 1, 2, 3])

            insert_at(0, a, [5, 6])
            insert_at(4, a, 7)
            self

# Generated at 2022-06-23 23:44:37.020049
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # pylint: disable=unused-variable
    """Test for function get_closest_parent_of."""
    import astor  # pylint: disable=wrong-import-order,wrong-import-position
    import test.generator as generate  # pylint: disable=wrong-import-order,wrong-import-position,wrong-import-positio

    def __test_func(code: str, exp_type: type) -> None:
        """Test function."""
        tree = ast.parse(code)
        # pylint: disable=protected-access
        min_node = min(find(tree, ast.AST), key=lambda x: x._start_pos)
        parent = get_closest_parent_of(tree, min_node, exp_type)


# Generated at 2022-06-23 23:44:43.919455
# Unit test for function insert_at
def test_insert_at():
    class_node = ast.ClassDef(name='Class', body=[], decorator_list=[])
    assert class_node.body == []
    insert_at(0, class_node, ast.Pass())
    assert class_node.body == [ast.Pass()]
    insert_at(0, class_node, ast.Pass())
    assert class_node.body == [ast.Pass(), ast.Pass()]


# Generated at 2022-06-23 23:44:53.583006
# Unit test for function insert_at
def test_insert_at():
    # This can fail if the pytest unit test is not run from the
    # root folder.
    from . import ast_typing_test
    from . import ast_imports_test

    test_ast = ast.parse(ast_typing_test.ast_typing_test)
    test_tree: ast.Module = test_ast
    tree_str = ast.dump(test_tree)
    tree_lines = tree_str.splitlines()

    assert len(tree_lines[1].replace(' ', '')) == 1
    assert len(tree_lines[2].replace(' ', '')) == 2

    # Node of index 1 comes 'after' so it should be inserted after
    # the node at index 2, which means it will be accessed as index 3

# Generated at 2022-06-23 23:44:56.420283
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('a(1)\n', mode='exec')
    parent, index = get_non_exp_parent_and_index(node, node.body[0])
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-23 23:44:59.982967
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    src = ast.parse("""
        def foo():
            pass

        def bar():
            pass
    """)
    assert get_non_exp_parent_and_index(src, src.body[0]) ==\
        (src, 0)

# Generated at 2022-06-23 23:45:01.327800
# Unit test for function replace_at

# Generated at 2022-06-23 23:45:10.382170
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a=1\nprint(a)')
    func_def = ast.FunctionDef(name='fun',
                               args=ast.arguments(args=[],
                                                  vararg=None,
                                                  kwonlyargs=[],
                                                  kw_defaults=[],
                                                  kwarg=None,
                                                  defaults=[]),
                               body=[ast.Expr(value=ast.Name(id='None',
                                                             ctx=ast.Load()))],
                               decorator_list=[],
                               returns=None)
    insert_at(0, tree.body[1], func_def)
    expected = "a=1\ndef fun():\n    None\nprint(a)"
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 23:45:12.872109
# Unit test for function insert_at
def test_insert_at():
    import astor
    # import astor.parser.parser3
    import astor.codegen

# Generated at 2022-06-23 23:45:16.359023
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = """
    def f(x):
        def g(y):
            return x
    """
    m = ast.parse(source)
    _build_parents(m)
    print(m.body[0].body[0].returns)

if __name__ == '__main__':
    test_get_non_exp_parent_and_index()

# Generated at 2022-06-23 23:45:21.783215
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_code = """
    if a:
        if b:
            c
        else:
            d
    else:
        if b:
            f
        else:
            g
    """
    tree = ast.parse(ast_code)
    code_node = tree.body[0].body[1].body[0].orelse[1].body[1]
    assert isinstance(code_node, ast.Name)
    result = (tree.body[0].orelse[1].body[1], 1)

    assert result == get_non_exp_parent_and_index(tree, code_node)


# Generated at 2022-06-23 23:45:28.613458
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_node1 = ast.Num(n=42)
    test_node2 = ast.Num(n=666)
    test_node3 = ast.Num(n=123)
    parent = ast.Expr(value=test_node1)
    parent.body = [parent.value, test_node3]
    result = get_non_exp_parent_and_index(parent, test_node2)
    assert (result[1] == 2)
    assert (result[0] is parent)


# Generated at 2022-06-23 23:45:32.782091
# Unit test for function replace_at
def test_replace_at():
    exp = ast.parse('x = 1 + y').body[0]
    y = ast.parse('y').body[0]

    replace_at(1, exp, y)

    assert ast.dump(exp) == 'Expression(body=BinOp(left=Constant(value=1, kind=None), op=Add(), right=Name(id="y", ctx=Load())))'



# Generated at 2022-06-23 23:45:40.172009
# Unit test for function replace_at
def test_replace_at():
    classParent = ast.ClassDef(name='Test',  # type: ignore
                               body=[ast.Return(value=ast.Num(1.))])
    assert isinstance(classParent.body[0], ast.Return)
    replace_at(0, classParent, ast.Return(value=ast.Num(2.)))
    assert isinstance(classParent.body[0], ast.Return)
    assert classParent.body[0].value.n == 2.



# Generated at 2022-06-23 23:45:48.609805
# Unit test for function get_parent
def test_get_parent():
    from . import make_ast
    import unittest

    class GetParentTestCase(unittest.TestCase):
        def do_test(self, tree: ast.AST, node: ast.AST, expected_result: ast.AST):
            parent = get_parent(tree, node)

            self.assertEqual(expected_result, parent)

        def test_parent(self):
            tree = make_ast.parse_dummy_tree()
            node = make_ast.dummy_for()
            expected_result = tree

            self.do_test(tree, node, expected_result)

        def test_invalid_node(self):
            class _Node(ast.AST):
                pass

            tree = make_ast.parse_dummy_tree()
            node = _Node()


# Generated at 2022-06-23 23:45:56.088811
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    test_ast = ast.parse('def foo(): return 1 + 2')
    test_node = test_ast.body[0].body[0].value.left

    parent = get_closest_parent_of(test_ast, test_node, ast.FunctionDef)
    assert astor.to_source(parent) == 'def foo(): return 1 + 2'

    parent = get_closest_parent_of(test_ast, test_node, ast.stmt)
    assert astor.to_source(parent) == 'return 1 + 2'


# Generated at 2022-06-23 23:45:58.413895
# Unit test for function find
def test_find():
    pass
    #assert find(ast.parse("a = b + 2"), ast.Name).__next__().id == 'b'


# Generated at 2022-06-23 23:46:07.276458
# Unit test for function replace_at
def test_replace_at():
    root = ast.parse("def f():\n    a = 0")
    node_to_replace = root.body[0].body[0]
    new_node = ast.parse("a = 1").body[0]
    assert(node_to_replace == root.body[0].body[0])
    assert(new_node != root.body[0].body[0])

    replace_at(0, root.body[0], new_node)
    assert(new_node == root.body[0].body[0])


if __name__ == "__main__":
    test_replace_at()

# Generated at 2022-06-23 23:46:11.017987
# Unit test for function find
def test_find():
    import typed_astunparse
    test_node = typed_astunparse.astunparse(ast.parse('print("foo")').body[0])
    test_tree = ast.parse('[{print("foo"), print("bar")}]')
    result = [node for node in find(test_tree, ast.Expr)]
    assert typed_astunparse.astunparse(result[0]) == test_node
    assert typed_astunparse.astunparse(result[1]) == test_node


# Generated at 2022-06-23 23:46:16.087944
# Unit test for function find
def test_find():
    n = ast.parse('1').body[0]  # type: ast.AST
    n2 = ast.parse('1').body[0]  # type: ast.AST
    n3 = ast.parse('1').body[0]  # type: ast.AST
    n.body = [n2, n3]
    assert n2 in _util.find(n, ast.AST)
    assert n2 in _util.find(n, ast.Expr)

# Generated at 2022-06-23 23:46:21.135349
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
        while True:
            x = 5
    """)
    node = tree.body[0].body[0].value

    # We expect to get this
    parent = tree.body[0]
    index = 0

    assert get_non_exp_parent_and_index(tree, node) == (parent, index)

# Generated at 2022-06-23 23:46:22.313009
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:46:22.865336
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:46:31.767333
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class A(ast.AST):
        """AST class for test."""

    class B(ast.AST):
        """AST class for test."""

    class C(ast.AST):
        """AST class for test."""

    # pylint: disable=no-member
    node = A(body=[
        A(body=[
            A(body=[
                B()
            ]),
            A(body=[]),
        ]),
        A(body=[
            A(body=[
                C()
            ]),
            A(body=[]),
        ]),
    ])

    result = get_closest_parent_of(node, node.body[0].body[0].body[0], A)
    assert result.body == [B()]


# Generated at 2022-06-23 23:46:35.513957
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit tests for get_non_exp_parent_and_index function.

    The tests not only tests the function but also the get_parent function.
    """
    from ..node_utils import build_ast

    # a very simple module

# Generated at 2022-06-23 23:46:44.361309
# Unit test for function insert_at
def test_insert_at():
    stmt = ast.parse('a = b')
    asdl = ast.parse('a = b')
    module = ast.Module(
        body=[ast.Expr(value=asdl.body[0].value, lineno=1, col_offset=0)])
    insert_at(0, stmt, module)
    insert_at(0, stmt, ast.Assign(targets=[ast.Name(id='c',
                                                   lineno=1,
                                                   col_offset=0)],
                                  value=stmt,
                                  lineno=1,
                                  col_offset=0))
    assert ast.dump(stmt) == ast.dump(asdl)



# Generated at 2022-06-23 23:46:50.638971
# Unit test for function insert_at
def test_insert_at():
    class o(ast.AST):
        _fields = ('body',)
        body = [1, 2, 3]

    class o2(ast.AST):
        _fields = ('body',)
        body = [4, 5, 6]

    parent = o()
    assert parent.body == [1, 2, 3]

    insert_at(2, parent, 10)
    assert parent.body == [1, 2, 10, 3]

    insert_at(2, parent, [11, 12])
    assert parent.body == [1, 2, 11, 12, 10, 3]


# Generated at 2022-06-23 23:46:55.676989
# Unit test for function find
def test_find():
    import astor
    node = """def func(a, b):
    return b"""

    parsed = ast.parse(node)
    nodes = list(find(parsed, type=ast.FunctionDef))

    assert len(nodes) == 1, "No FunctionDef found"
    assert astor.to_source(nodes[0]) == node


# Generated at 2022-06-23 23:47:03.200886
# Unit test for function get_parent
def test_get_parent():
    import astor
    # Create AST that looks like this:
    #
    # def a():
    #     def b():
    #         b1 = 1
    #         b2 = 2
    #     b2 = 3
    #     b1 = 4
    #     b3 = 4
    #     b4 = 4
    #     return b4
    #
    # a1 = 5
    # a2 = 6
    # return a1


# Generated at 2022-06-23 23:47:11.088251
# Unit test for function get_parent
def test_get_parent():
    for _ in range(4):
        _build_parents(ast.parse('''
            for i in range(10):
                print('ahahah')
        '''))
        assert get_parent(ast.parse('''
        for i in range(10):
            print('ahahah')
        '''), ast.parse('''
        print('ahahah')
        ''').body[0]).body[0] == ast.parse('''
        print('ahahah')
        ''').body[0]



# Generated at 2022-06-23 23:47:12.472708
# Unit test for function get_parent

# Generated at 2022-06-23 23:47:17.801010
# Unit test for function get_parent
def test_get_parent():
    def test_tree(a=5, b=5):
        if a > b:
            a = a + b
        else:
            b = a + b
        return a, b

    funcNode = ast.parse(test_tree.__code__.co_code).body[0]
    ifs = find(funcNode, ast.If)
    get_parent(funcNode, ifs)



# Generated at 2022-06-23 23:47:26.033313
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as ast
    from nave.utils.ast import get_non_exp_parent_and_index

    code = "def foo():\n    pass"
    tree = ast.parse(code)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent == tree
    assert index == 0

    code = "foo\nbar"
    tree = ast.parse(code)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent == tree
    assert index == 0

# Generated at 2022-06-23 23:47:30.154066
# Unit test for function get_parent
def test_get_parent():
    root = ast.parse('a=1\nb=2')
    _build_parents(root)
    assert get_parent(root, root) == None
    for node in ast.walk(root):
        for child in ast.iter_child_nodes(node):
            assert get_parent(root, child) == node

# Generated at 2022-06-23 23:47:32.616959
# Unit test for function find
def test_find():
    assert list(find(ast.parse("""
        def f():
            pass
        """), ast.FunctionDef)) == [ast.parse("def f(): pass").body[0]]


# Generated at 2022-06-23 23:47:35.047367
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a + b')

    assert isinstance(get_parent(tree, tree.body[0].value), ast.Module)

test_get_parent()


# Generated at 2022-06-23 23:47:40.137965
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        body = []
    class B(ast.AST):
        pass
    a = A()
    b = B()
    a.body.append(b)
    insert_at(0, a, [B()])
    assert isinstance(a.body[0], B)



# Generated at 2022-06-23 23:47:50.973097
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index."""
    code = textwrap.dedent('''
    def foo():
        print(1)
        try:
            print(2)
            return 2
        except ZeroDivisionError:
            print(3)
            return 3
        finally:
            print(4)
            return 4
    ''')

    ret_tree = ast.parse(code)
    index = 0
    parent = get_non_exp_parent_and_index(ret_tree, ret_tree.body[0].body[1])
    assert (parent[0].body[parent[1]] is ret_tree.body[0].body[1])
    assert (parent[1] == 1)
    # print(parent[0].body[1])


# Generated at 2022-06-23 23:47:57.269499
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def fun():
        for i in range(5):
            pass

    tree = ast.parse(inspect.getsource(fun))

    for_node = get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                     ast.For)
    assert(inspect.getsource(for_node.iter).strip() == 'range(5)')



# Generated at 2022-06-23 23:48:02.710623
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def test():\n    a = 1\n    b = 2\n')
    call = tree.body[0].body[1]
    replace_at(1, tree.body[0], [ast.parse('c=3\n').body[0]])
    assert call != tree.body[0].body[1]

# Generated at 2022-06-23 23:48:08.625280
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    body = ast.parse("x = 2 * (1 + 0)").body
    expected_parent = body[0]
    expected_parent_index = body.index(expected_parent)

    parent, parent_index = get_non_exp_parent_and_index(body,
                                                        expected_parent.value)
    assert parent == expected_parent
    assert parent_index == expected_parent_index

# Generated at 2022-06-23 23:48:09.594420
# Unit test for function find

# Generated at 2022-06-23 23:48:13.672694
# Unit test for function insert_at
def test_insert_at():
    # Given
    node = ast.Assign()

    # When
    insert_at(1, ast.Suite([ast.Expr()]), node)

    # Then
    assert node in ast.Suite([ast.Expr(), node])

# Generated at 2022-06-23 23:48:14.881923
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:48:19.593977
# Unit test for function get_parent
def test_get_parent():
    a = ast.parse('a + b')
    b = ast.parse('a + b')
    _build_parents(a)

    for node in ast.walk(a):
        for child in node.children:
            assert get_parent(b, child) == get_parent(a, child)

# Generated at 2022-06-23 23:48:22.008944
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as ast
    funcdef = ast.parse("def func(): pass").body[0]
    assert get_closest_parent_of(funcdef, funcdef.body[0], ast.FunctionDef) == funcdef

# Generated at 2022-06-23 23:48:25.576642
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def f():
        return True

    tree = ast.parse(inspect.getsource(f))
    assert get_non_exp_parent_and_index(tree, tree.body[0]) == (
        tree, 0)  # type: ignore
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0].value) == (
        tree, 0)  # type: ignore



# Generated at 2022-06-23 23:48:36.192515
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    top = ast.Module([
        ast.Assign(
            [ast.Name('x', ast.Store())],
            ast.Name('a', ast.Load())
        ),
        ast.Expr(
            ast.Call(
                ast.Name('b', ast.Load()),
                [],
                []
            )
        )
    ])

    assert get_non_exp_parent_and_index(top, ast.Name('b', ast.Load())) == (
        top, 1
    )

    assert get_non_exp_parent_and_index(top, ast.Name('x', ast.Store())) == (
        top, 0
    )



# Generated at 2022-06-23 23:48:38.953615
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse(dedent(
        '''
        def test():
            return 1
        '''
    ))
    parent = get_parent(tree, tree.body[0])
    insert_at(0, parent, ast.parse('1 + 2').body[0])

    assert ast.dump(tree) == ast.dump(ast.parse(dedent(
        '''
        def test():
            1 + 2
            return 1
        '''
    )))


# Generated at 2022-06-23 23:48:48.863111
# Unit test for function replace_at
def test_replace_at():
    def test_func(a, b, c):
        return a + b + c

    tree = ast.parse(inspect.getsource(test_func))

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].value)

    assert isinstance(parent, ast.Module)
    assert parent.body[index].value.args[0].s == 'a'
    assert parent.body[index].value.args[1].s == 'b'
    assert parent.body[index].value.args[2].s == 'c'

    replace_at(index, parent, ast.parse('return a + b - c').body[0])

    assert isinstance(parent, ast.Module)
    assert parent.body[index].value.args[0].s == 'a'

# Generated at 2022-06-23 23:48:56.645005
# Unit test for function insert_at
def test_insert_at():

    def foo():
        return 1

    # make AST of foo function
    ast_tree = ast.parse(foo.__doc__, '', 'exec')

    # find module
    module = list(find(ast_tree, ast.Module))[0]

    # find function
    foo_function = list(find(ast_tree, ast.FunctionDef))[0]

    # insert expression after foo function
    insert_at(module.body.index(foo_function) + 1, module, ast.Expr(
        ast.Num(1)))

    # check if new expression is added
    assert len(module.body) == 2

    # check if new expression is after function
    assert isinstance(module.body[module.body.index(ast.Expr(ast.Num(1)))],
                      ast.Expr)

# Generated at 2022-06-23 23:49:03.610175
# Unit test for function find
def test_find():
    import astor
    test_str = """
    def a():
        pass
    """
    tree = ast.parse(test_str)

    parent = get_parent(tree, list(find(tree, ast.FunctionDef))[0])
    assert isinstance(parent, ast.Module)

    parent, index = get_non_exp_parent_and_index(tree, list(find(tree, ast.FunctionDef))[0])
    assert isinstance(parent, ast.Module)
    assert index == 0

    assert isinstance(get_closest_parent_of(tree, list(find(tree, ast.FunctionDef))[0], ast.Module), ast.Module)

# Generated at 2022-06-23 23:49:12.533685
# Unit test for function replace_at
def test_replace_at():
    import astor
    # a = 1; 2; 3; 4
    func_node = ast.parse('''a = 1; 2; 3; 4''')
    # 2
    two_node = func_node.body[0].body[1]

    # converting 4 to an expression
    four_node = func_node.body[0].body[3]  # type: ignore
    four_node.value = ast.Num(4)

    # replace 2 by 4
    replace_at(1, func_node.body[0], four_node)

    print(astor.to_source(func_node))

if __name__ == '__main__':
    test_replace_at()

# Generated at 2022-06-23 23:49:16.993547
# Unit test for function find
def test_find():
    # type: (ast.AST) -> None
    import ast
    import astunparse

    tree_code = ast.parse("""
    def func(x):
        a = 1
        b = 2
        c = 3
        return a + b + c
    """)

    nodes = find(tree_code, ast.Name)

    assert len(list(nodes)) == 4



# Generated at 2022-06-23 23:49:23.909402
# Unit test for function find
def test_find():
    import astor
    import astunparse
    def foo():
        pass

    src = inspect.getsource(foo)
    tree = ast.parse(src)
    assert find(tree, ast.FunctionDef)
    try:
        assert not find(tree, ast.ClassDef)
    except AssertionError:
        print("The function is finding something which doesn't exist")

# Generated at 2022-06-23 23:49:32.198419
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''
        if True:
            a = 10
    ''')

    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.If)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0]), ast.Suite)


# Generated at 2022-06-23 23:49:42.131710
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test case 1, find parent and index
    module = ast.parse("for i in range(10, 20):\n    print(i)")
    assert get_non_exp_parent_and_index(module, module.body[0].body[0]) == (
        module.body[0], 0)

    # Test case 2, find parent and index
    module = ast.parse("if True:\n    for i in range(10, 20):\n        print(i)")
    assert get_non_exp_parent_and_index(module, module.body[0].body[0]) == (
        module.body[0], 0)

    # Test case 3, parent not found
    module = ast.parse("if True:\n    for i in range(10, 20):\n        print(i)")

# Generated at 2022-06-23 23:49:46.635742
# Unit test for function get_parent
def test_get_parent():
    import astor
    tree = astor.parse_file('../../tests/python_files/nested.py')
    load = tree.body[0]
    assert type(get_parent(tree, load)) is ast.Module



# Generated at 2022-06-23 23:49:49.352632
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Lambda()
    node.body = ast.AnnAssign(target=ast.Name(id='f'), annotation=ast.Name(id='int'))

    assert get_non_exp_parent_and_index(node, node.body) == (node, 0)

# Generated at 2022-06-23 23:49:52.299149
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = b + c')
    node = tree.body[0].value

    parent_node = get_parent(tree, node)

    assert id(parent_node) == id(tree.body[0])


# Generated at 2022-06-23 23:50:00.593319
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("def add(a,b):\n"
                     "    return a + b")
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    replace_at(index, parent,
               ast.parse("def test(): pass\n"
                         "def test2(): pass").body)
    assert len(parent.body) == 4
    assert isinstance(parent.body[1], ast.FunctionDef)
    assert isinstance(parent.body[2], ast.FunctionDef)
    assert isinstance(parent.body[3], ast.Return)
    assert parent.body[3].value.op.__class__.__name__ == "Add"

# Generated at 2022-06-23 23:50:10.536671
# Unit test for function get_parent
def test_get_parent():
    class Test(ast.AST):

        _fields = ('a', 'b', 'c')

    class Test2(ast.AST):

        _fields = ('a', 'b')

    def test(): pass
    module = ast.parse('def test(): pass')
    # module = ast.parse('''
    # def test():
    #     pass
    # ''')
    node_e = module.body[0]
    node_a = Test(a=1, b=2, c=3)
    node_b = Test(a=1, b=2, c=3)
    node_c = Test2(a=1, b=2)
    node_d = Test(a=1, b=2, c=3)

    node_a.a = node_b
    node_b.a = node

# Generated at 2022-06-23 23:50:12.724778
# Unit test for function find
def test_find():
    test_tree = ast.parse('if True:\n    print(1)')
    for node in find(test_tree, ast.If):
        assert isinstance(node, ast.If)

# Generated at 2022-06-23 23:50:17.861770
# Unit test for function get_parent
def test_get_parent():
    code = "def foo(): pass"
    tree = ast.parse(code)
    parent = get_parent(tree, tree.body[0], True)
    assert parent == tree
    assert len(_parents) == 3


# Generated at 2022-06-23 23:50:20.131426
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:50:27.626224
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""
        def func(x):
            print x
    """)
    func = tree.body[0]
    body = func.body
    assert(len(body) == 1)
    insert_at(0, body, ast.Expr(ast.Call(func=ast.Name('print'),
                                         args=[ast.Num(1)],
                                         keywords=[])))
    assert(len(body) == 2)
    assert(isinstance(body[0], ast.Expr))
    assert(isinstance(body[1].value, ast.Call))


# Generated at 2022-06-23 23:50:32.461767
# Unit test for function replace_at
def test_replace_at():
    """
    >>> program = ast.parse("a = 'foo' + 'bar'")
    >>> replace_at(1, program, ast.Str('qux'))
    >>> print(astor.to_source(program))
    a = 'foo' + 'qux'
    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:50:33.259759
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:50:40.361884
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        "class A:\n"
        "    def b():\n"
        "        pass\n"
        "    def c():\n"
        "        pass")
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.ClassDef)
    assert index == 0



# Generated at 2022-06-23 23:50:50.974400
# Unit test for function get_parent
def test_get_parent():
    program = ast.parse('def f(): pass')
    assert get_parent(program, program.body[0]) == program
    assert get_parent(program, program.body[0].args) == program.body[
        0]  # type: ignore
    assert get_parent(program, program.body[0].args.args[0]) == program.body[
        0].args  # type: ignore
    assert get_parent(
        program, program.body[0].args.args[0].annotation) == program.body[
            0].args.args[0]  # type: ignore
    try:
        get_parent(program, ast.parse('foo'))
    except NodeNotFound:
        assert True
    else:
        assert False


# Generated at 2022-06-23 23:50:53.116315
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    mod = ast.parse('foo(1)').body[0]
    call_obj = mod.value
    arg = mod.value.args[0]
    parent, index = get_non_exp_parent_and_index(mod, arg)

    assert parent == call_obj
    assert index == 0

# Generated at 2022-06-23 23:50:57.176220
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('for i in range(4): print(i)')
    node = tree.body[0].body[0]
    parent = get_parent(tree, node)
    assert isinstance(parent, ast.For)



# Generated at 2022-06-23 23:51:03.347151
# Unit test for function replace_at
def test_replace_at():
    test = ast.parse('def foo(a, b, c):\n    d = a + b + c')
    old_node = test.body[0].body[0]
    new_node = ast.parse('    e = a * b * c').body[0]
    replace_at(0, test.body[0], new_node)

    assert test.body[0].body[0] == new_node
    assert old_node.body[0].n not in ast.walk(test)

# Generated at 2022-06-23 23:51:05.986819
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('x + y'), ast.BinOp))) == 1

# Generated at 2022-06-23 23:51:11.427226
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # We need this to test by a stand-alone program without importing from
    # other modules
    from ..python_to_pythonjs import py_to_js
    from .ast_testing import get_body, get_node_at_line
    from .test_helpers import patch_location
    from ..compiler_stages import ast_builder


# Generated at 2022-06-23 23:51:14.616474
# Unit test for function insert_at
def test_insert_at():
    insert_at(0, [], [1])
    insert_at(0, [1], [])
    insert_at(0, [], [])

    a = []
    insert_at(0, a, [1])
    assert a == [1]
    insert_at(0, a, [2])
    assert a == [2, 1]
    insert_at(0, a, [3])
    assert a == [3, 2, 1]
    insert_at(1, a, [4])
    assert a == [3, 4, 2, 1]
    insert_at(4, a, [5])
    assert a == [3, 4, 2, 1, 5]



# Generated at 2022-06-23 23:51:21.547980
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    parent = ast.parse("class Foo(object):\n"
                       "  def bar(self):\n"
                       "    pass\n")
    node = parent.body[0].body[0].body[0]
    assert type(get_closest_parent_of(parent, node, ast.FunctionDef)) \
        is ast.FunctionDef
    assert type(get_closest_parent_of(parent, node, ast.ClassDef)) \
        is ast.ClassDef
    assert type(get_closest_parent_of(parent, node, ast.Module)) \
        is ast.Module



# Generated at 2022-06-23 23:51:28.909228
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''class A:
    def a(self):
        if a:
            def b(self):
                pass
        else:
            def c(self):
                pass
''')
    assert hasattr(get_parent(tree, tree.body[0]), 'body')

# Generated at 2022-06-23 23:51:37.135723
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import random
    import string
    import astor
    from .helper import unparse
    from .helper import astor_to_ast
    from .helper import astor_to_ast_safe

    # Variables
    NUMBER_OF_TESTS = 100
    NUMBER_OF_NODES = 20

    def generate_random_function():
        def_node = ast.FunctionDef(random_name(),
                                   ast.arguments(args=[],
                                                 vararg=None,
                                                 kwonlyargs=[],
                                                 kw_defaults=[],
                                                 kwarg=None,
                                                 defaults=[]),
                                   [ast.Return(ast.Num(random.randint(0, 100)))],
                                   [],
                                   '')
        return ast.Module

# Generated at 2022-06-23 23:51:47.504434
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module = ast.parse('''
        def demo_func():
            x = 2 + 3
            y = x ** 3
            z = y - 2
            print(z)
    ''')
    _build_parents(module)

    # test for exp node
    exp_node = module.body[0].body[0].value
    assert get_non_exp_parent_and_index(module, exp_node) == \
           (module.body[0].body[0], 0)

    # test for statement node
    stmt_node = module.body[0].body[1]
    assert get_non_exp_parent_and_index(module, stmt_node) == \
           (module.body[0], 1)

    # test for func node
    func_node = module.body[0]
   

# Generated at 2022-06-23 23:51:49.548630
# Unit test for function find
def test_find():
    assert find(ast.parse("a = 3"), ast.Num).__next__().n == 3
    assert list(find(ast.parse("a = [3]"), ast.Num))[0].n == 3

# Generated at 2022-06-23 23:52:00.644945
# Unit test for function replace_at
def test_replace_at():
    """Test function replace_at"""
    tree = ast.parse('''
        def foo(x):
          print(x)
          x = x + 1
          print(x)
          x = x + 2
          print(x)
    ''')

    first_assign = tree.body[0].body[0].value
    _, index = get_non_exp_parent_and_index(tree, first_assign)
    parent = get_closest_parent_of(tree, first_assign, ast.FunctionDef)
    replace_at(index, parent, ast.parse('return 1').body[0].value)


# Generated at 2022-06-23 23:52:07.564644
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    funcdefnode = ast.parse('def foo():\n  return 1 + 1\n  return').body[0]
    assert get_non_exp_parent_and_index(funcdefnode, funcdefnode.body[1]) == (
            funcdefnode, 1)



# Generated at 2022-06-23 23:52:13.273900
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    if True:
        print("hello")
        print("world")
    """)
    _build_parents(tree)
    found = next(find(tree, ast.Print))
    assert get_non_exp_parent_and_index(tree, found) == (tree.body[0], 1)

# Generated at 2022-06-23 23:52:25.225849
# Unit test for function insert_at
def test_insert_at():
    import astunparse
    # Create ast tree
    t = ast.parse("import sys")
    # Check the created ast tree, debug purpose
    assert(astunparse.unparse(t))
    # Assert ast tree has body
    assert(hasattr(t, 'body'))
    # Assert ast tree has body of type list
    assert(isinstance(t.body, list))
    # Append new element to ast tree body
    insert_at(1, t, ast.parse("print('Hello')"))
    # Check the created ast tree, debug purpose
    assert(astunparse.unparse(t))
    # Assert ast tree body contains 2 elements
    assert(len(t.body) == 2)
    # Assert body element[1] is of type ast.Expr

# Generated at 2022-06-23 23:52:32.450933
# Unit test for function find
def test_find():
    test_ast = ast.parse("""
        if 1:
            pass
        if a:
            pass
        if a:
            hello
        if 1:
            pass
        if a:
            pass
    """)

    if_stmts = list(find(test_ast, ast.If))
    assert len(if_stmts) == 5

    only_hello_if = find(test_ast, ast.If).__next__()
    assert only_hello_if.body[0].s == 'hello'



# Generated at 2022-06-23 23:52:36.342762
# Unit test for function get_parent
def test_get_parent():
    lines = "def foo():\n    bar()\n    baz()\n"
    tree = ast.parse(lines)

    foo = tree.body[0]
    bar = foo.body[0]
    baz = foo.body[1]

    assert get_parent(tree, foo) is tree
    assert get_parent(tree, bar) is foo
    assert get_parent(tree, baz) is foo

# Generated at 2022-06-23 23:52:38.983042
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('a = 1').body[0]
    _, index = get_non_exp_parent_and_index(node.value, node.value)
    assert index == 0


# Generated at 2022-06-23 23:52:44.316704
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('x = 10')
    expr_parent, index = get_non_exp_parent_and_index(tree, tree.body[0].targets[0])
    assert isinstance(expr_parent, ast.Module)
    assert isinstance(index, int)
    assert tree.body[0] == expr_parent.body[index]


# Generated at 2022-06-23 23:52:51.203815
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = '''
    def a():
        def b():
            def c():
                return 3
            return 6
        return 9
    '''

    parsed = ast.parse(code)

    body = list(parsed.body)
    assert len(body) == 1

    body = list(body[0].body)
    assert len(body) == 1

    body = list(body[0].body)
    assert len(body) == 2

    body = list(body[0].body)
    assert len(body) == 1

    assert get_closest_parent_of(parsed, list(body[0].body)[0], ast.FunctionDef) == body[0]

