

# Generated at 2022-06-23 23:42:58.782005
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert find(
        ast.parse('if a: b += 1').body[0].body[0], ast.AugAssign)
    assert get_closest_parent_of(
        ast.parse('if a: b += 1'),
        ast.parse('if a: b += 1').body[0].body[0],
        ast.AugAssign)

    assert find(
        ast.parse('def f():\n    abc = (1,)\n    if a: b += 1').body[0].body[1],
        ast.AugAssign)

# Generated at 2022-06-23 23:43:06.705903
# Unit test for function insert_at
def test_insert_at():
    source = """
    print("hello")
    """

    tree = ast.parse(source)
    insert_at(1, tree, ast.parse("print('world')"))
    assert ast.dump(tree) == """Module(body=[Expr(value=Str(s='hello')), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Str(s='world')], keywords=[]))])"""

    insert_at(2, tree, ast.parse("print('that')"))

# Generated at 2022-06-23 23:43:07.305147
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-23 23:43:18.367950
# Unit test for function insert_at
def test_insert_at():
    import astor


# Generated at 2022-06-23 23:43:22.102251
# Unit test for function find
def test_find():
    t = ast.parse("for x in range(10): print(x)")
    assert len(list(find(t, ast.For))) == 1
    assert len(list(find(t, ast.Name))) == 1



# Generated at 2022-06-23 23:43:27.611331
# Unit test for function get_parent
def test_get_parent():
    node_example = ast.parse(
        """
    def main():
        if True:
            pass
        else:
            while False:
                print(x)
    """
    )

    parent = get_parent(node_example, node_example.body[0].body[1])

    assert parent == node_example.body[0]



# Generated at 2022-06-23 23:43:35.251866
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module = ast.parse("""
        def func1(i):
            pass
        def func2(i, j):
            pass
        class C:
            pass
        class C2:
            pass
        c = C()
    """)
    body = module.body
    assert get_non_exp_parent_and_index(module, body[0]) == (module, 0)
    assert get_non_exp_parent_and_index(module, body[1]) == (module, 1)
    assert get_non_exp_parent_and_index(module, body[2]) == (module, 2)
    assert get_non_exp_parent_and_index(module, body[3]) == (module, 3)

# Generated at 2022-06-23 23:43:45.250367
# Unit test for function replace_at
def test_replace_at():
    module = ast.parse('def foo():\n x = 1')
    replace_at(0, module, [ast.parse('def bar():\n x = 2').body[0]])
    assert ast.dump(module) == 'Module(body=[FunctionDef(name=\'bar\', ' \
                             'args=arguments(args=[], vararg=None, ' \
                             'kwonlyargs=[], kw_defaults=[], ' \
                             'kwarg=None, defaults=[]), body=[Assign(targets' \
                             '=[Name(id=\'x\', ctx=Store())], value=Num(' \
                             'n=2))], decorator_list=[], returns=None)])'

# Generated at 2022-06-23 23:43:47.971987
# Unit test for function find
def test_find():
    code = """
        def foo():
            pass
    """
    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 1


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-23 23:43:54.380857
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = '''
    def foo():
      a = 1
      
    def bar():
      b = a
    '''
    tree = ast.parse(source)
    func_def = find(tree, ast.FunctionDef)

    a = find(tree, ast.Name).__next__()
    b = find(tree, ast.Name).__next__()
    if_root = get_non_exp_parent_and_index(tree, a.ctx.__next__().value)
    func = get_non_exp_parent_and_index(tree, b.ctx.__next__().value)

    assert(if_root[0] == tree)
    assert(func[0] == func_def.__next__())

# Generated at 2022-06-23 23:44:01.092802
# Unit test for function find
def test_find():
    code = """
        def hello(name):
            print('Hello, %s!' % name)
            return 'test'

        hi = hello(input('Who are you?'))
    """
    module = ast.parse(code)
    names = list(find(module, ast.Name))
    assert len(names) == 3
    assert names[0].id == 'hello'
    assert names[1].id == 'name'
    assert names[2].id == 'input'

# Generated at 2022-06-23 23:44:03.655289
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Friend():
        name = None

    class Person():
        friend = Friend()
        friend.name = "Andy"

    p = Person()
    print(p.friend.name)

# Generated at 2022-06-23 23:44:10.772848
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse(
        """# comment
        i = 1
        if i == 10:
            print(i)
        j = 2
        while i < 10:
            i += 1
            print(i)
        """)

    parent, index = get_non_exp_parent_and_index(tree, list(find(tree, ast.While))[0])
    statement = ast.Assign(targets=[ast.Name(id='k', ctx=ast.Store())],
                           value=ast.Num(n=1))

    replace_at(index, parent, statement)


# Generated at 2022-06-23 23:44:15.828171
# Unit test for function find
def test_find():
    # Setup
    tree = ast.parse('a = 1\nb = 2')

    # Run
    res = find(tree, ast.Assign)
    a, b = res

    # Assert
    assert a.value.n == 1
    assert b.value.n == 2

# Generated at 2022-06-23 23:44:27.269855
# Unit test for function replace_at
def test_replace_at():
    body = ast.parse('a = 1').body
    body.append(ast.Expr(value=ast.BinOp(left=ast.Name(id='a'), op=ast.Add(),
                                         right=ast.Num(n=1))))
    body.append(ast.Expr(value=ast.BinOp(left=ast.Name(id='a'), op=ast.Add(),
                                         right=ast.Num(n=2))))

# Generated at 2022-06-23 23:44:28.670137
# Unit test for function replace_at

# Generated at 2022-06-23 23:44:32.370797
# Unit test for function get_parent
def test_get_parent():
    import ast
    parent = ast.Module(body=[])
    child = ast.Expr(value=ast.Constant(value=1))
    parent.body.append(child)
    result = get_parent(parent, child)
    assert isinstance (result, ast.Module)


# Generated at 2022-06-23 23:44:33.221011
# Unit test for function find

# Generated at 2022-06-23 23:44:38.366264
# Unit test for function replace_at
def test_replace_at():
    t = ast.parse('''
        def f():
            pass
    ''')

    f = get_closest_parent_of(t, t.body[0], ast.FunctionDef)
    f.body[0] = ast.Pass()  # type: ignore
    replace_at(0, f, ast.Pass())
    replace_at(0, f, ast.Pass())
    replace_at(0, f, [ast.Pass(), ast.Pass()])
    replace_at(2, f, ast.Pass())
    insert_at(2, f, ast.Pass())
    replace_at(2, f, [ast.Pass(), ast.Pass()])

# Generated at 2022-06-23 23:44:44.918409
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1 + 2')
    module = tree.body[0]
    assign = tree.body[0].value  # type: ast.Assign
    replace_at(1, assign, ast.Name(id='a', ctx=ast.Load()))
    assert len(assign.targets) == 1
    assert assign.targets[0].id == 'a'
    assert assign.value.id == 'a'

# Generated at 2022-06-23 23:44:49.031826
# Unit test for function find
def test_find():
    tree = ast.parse('def foo(): a.bar()')
    for node in find(tree, ast.Attribute):
        assert isinstance(node, ast.Attribute)
    for node in find(tree, ast.Name):
        assert isinstance(node, ast.Name)



# Generated at 2022-06-23 23:44:56.620770
# Unit test for function get_parent
def test_get_parent():
    # Sample AST for the following code:
    #
    # def hello(x, y):
    #     return x * y
    tree = ast.parse(textwrap.dedent('''
    def hello(x, y):
        return x * y
    '''))

    # Test parent of body of hello.
    # Expected parent of body is FunctionDef.
    parent = get_parent(tree, tree.body[0].body)
    assert isinstance(parent, ast.FunctionDef)
    assert parent == tree.body[0]

    # Test parent of node expr.
    # Expected parent of expr is Return. And Return is a child of body.
    parent = get_parent(tree, tree.body[0].body[0].value)
    assert isinstance(parent, ast.Return)

# Generated at 2022-06-23 23:45:00.515680
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.parse("""
    def test():
        print('test')
    """).body[0]

    assert get_closest_parent_of(node, node.body[0], ast.FunctionDef) == node

# Generated at 2022-06-23 23:45:06.728866
# Unit test for function replace_at
def test_replace_at():
    """Some function docstring."""
    import ast
    node_1 = ast.parse("x = 1 + 2")
    node_1.body[0].value.left = ast.Num(n=1)
    node_1.body[0].value.right = ast.Num(n=2)
    print(ast.dump(node_1))
    node_1.body[0].value.right = ast.Num(n=3)
    print(ast.dump(node_1))

# Generated at 2022-06-23 23:45:15.415695
# Unit test for function get_parent
def test_get_parent():
    parent_node = ast.Module([
        ast.Assign([ast.Name('a', ast.Store())], ast.Num(1), lineno=1, col_offset=0),
        ast.Expr(ast.Call(ast.Name('foo', ast.Load()), [], [], None, None),
                 lineno=2, col_offset=0),
    ], lineno=1, col_offset=0)

    child_node = ast.Num(1)
    print(parent_node)
    print(child_node)
    print(get_parent(parent_node, child_node))

# Generated at 2022-06-23 23:45:17.623020
# Unit test for function get_parent
def test_get_parent():
    parent = ast.AST()
    child = ast.AST()
    parent.body = [child]
    assert get_parent(parent, child) is parent


# Generated at 2022-06-23 23:45:22.908299
# Unit test for function insert_at
def test_insert_at():
    import astor
    new_node = ast.Expr(ast.Call(ast.Name('a', ast.Load()), [], []))
    tree = ast.parse('call(1)')
    print(astor.to_source(tree))
    insert_at(0, tree.body[0], new_node)
    print(astor.to_source(tree))

# Generated at 2022-06-23 23:45:23.961954
# Unit test for function get_parent

# Generated at 2022-06-23 23:45:30.809093
# Unit test for function insert_at
def test_insert_at():
    # Test simple and more complex scenarios of inserting nodes
    # into nested parents of type ast.Module, ast.FunctionDef, ast.If and
    # ast.IfExp
    l = ast.parse('if True:\n'
                  '    x = 1\n'
                  'else:\n'
                  '    print(2)\n'
                  'x = 3 if True else 4\n').body

    insert_at(0, l[0].body[1], ast.Num(n=2))
    assert ast.dump(l) == 'Module(body=[If(test=Name(id=\'True\', ' \
                           'ctx=Load()), body=[Expr(value=Num(n=2)), ' \
                           'Assign(targets=[Name(id=\'x\', ctx=Store())], ' \
                

# Generated at 2022-06-23 23:45:33.017808
# Unit test for function find
def test_find():
    assert list(find(ast.parse("a = 1"), ast.Assign)) == [ast.parse("a = 1")]

# Generated at 2022-06-23 23:45:40.809252
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typing
    import astor
    tree = astor.parse_file('test/test_files/test_for.py')
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            if node.id == 'y':
                parent, index = get_non_exp_parent_and_index(tree, node)
                assert isinstance(parent, ast.For) and index == 2, \
                    'Wrong result of get_non_exp_parent_and_index'
                break

# Generated at 2022-06-23 23:45:49.152881
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""
    for i in range(10):
        i = 1
        i += 1
        print(i)
    """)
    _build_parents(tree)
    parent, index = get_non_exp_parent_and_index(tree,
                                                 tree.body[0].body[1].value)
    assert isinstance(parent, ast.For)
    assert index == 0

    insert_at(index, parent, [ast.Assign(targets=[
            ast.Name(id="dummy", ctx=ast.Store())],
            value=ast.Num(n=0))])
    assert isinstance(parent.body[index], ast.Assign)
    print(ast.dump(parent))

# Generated at 2022-06-23 23:45:56.555028
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def f():\n    pass')
    parent = get_parent(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    replace_at(0, parent, ast.Pass())
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=\'f\', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])'



# Generated at 2022-06-23 23:46:00.647691
# Unit test for function insert_at
def test_insert_at():
    """Tests that insert_at() works correctly."""
    class Parent:
        def __init__(self):
            self.body = []

    class Node:
        pass

    p = Parent()
    n = Node()
    insert_at(0, p, n)

    assert p.body == [n]

    insert_at(1, p, n)
    assert p.body == [n, n]

# Generated at 2022-06-23 23:46:10.683541
# Unit test for function replace_at
def test_replace_at():
    # replace_at(index: int, parent: ast.AST,
    # nodes: Union[ast.AST, List[ast.AST]]) -> None:
    parent = ast.Module([ast.FunctionDef(
        name='test',
        args=ast.arguments([], None, [], None, None, [], []),
        body=[ast.Expr(value=ast.Num(n=1))],
        decorator_list=[],
    )])
    node = ast.FunctionDef(
        name='test',
        args=ast.arguments([], None, [], None, None, [], []),
        body=[],
        decorator_list=[],
    )
    node.body = [ast.Expr(value=ast.Num(n=1))]
    parent.body[0] = node
    replace

# Generated at 2022-06-23 23:46:15.911490
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    global _parents

    tree = ast.parse('if some_condition:\n    pass')
    if_type = type(tree.body[0])

    # Build internal `_parents` dictionary
    _build_parents(tree)

    # First call should build parents
    get_closest_parent_of(tree, tree.body[0], if_type)

    assert not _parents

    # Next call should use already built parents
    get_closest_parent_of(tree, tree.body[0], if_type)

# Generated at 2022-06-23 23:46:21.035835
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_tree = ast.parse('')
    test_tree.body = [ast.Expr(value=ast.Num(n=1))]
    test_parent, _ = get_non_exp_parent_and_index(test_tree, test_tree.body[0])
    assert isinstance(test_parent, ast.Module)

# Generated at 2022-06-23 23:46:29.164061
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class_def = ast.ClassDef(
        name='class',
        bases=[],
        keywords=[],
        body=[
            ast.Pass(),
            ast.Pass(None, None, None, None, None, None, 'pass')
        ],
        decorator_list=[])

    function_def = ast.FunctionDef(
        name='function',
        args=ast.arguments(args=[],
                           default=[],
                           kwonlyargs=[],
                           kw_defaults=[],
                           vararg=None,
                           kwarg=None,
                           kwargannotation=None,
                           posonlyargs=[],
                           posonlyargannotation=None),
        body=[],
        decorator_list=[],
        returns=None,
        type_comment=None)


# Generated at 2022-06-23 23:46:39.602599
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = r"""
        def test(a):
            pass

        def func(x, y):
            x = 1
    """
    tree = ast.parse(code)
    parent_and_index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert isinstance(parent_and_index[0], ast.Module)
    assert parent_and_index[1] == 0
    parent_and_index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent_and_index[0], ast.FunctionDef)
    assert parent_and_index[1] == 0
    parent_and_index = get_non_exp_parent_and_index(tree, tree.body[1].body[0])
   

# Generated at 2022-06-23 23:46:44.324021
# Unit test for function insert_at
def test_insert_at():
    class A:
        def __init__(self):
            self.body = []

    class B:
        pass

    class C:
        pass

    a = A()
    b = B()
    c = C()

    insert_at(0, a, b)

    assert a.body[0] == b
    insert_at(0, a, c)
    assert a.body[0] == c

# Generated at 2022-06-23 23:46:47.526130
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('''
from . import foo
'''), ast.Import))) == 1
    assert len(list(find(ast.parse('''
from . import foo
from . import bar
'''), ast.Import))) == 2

# Generated at 2022-06-23 23:46:51.659498
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    c = ast.parse("if True:\n\tprint('Hello!')")
    n = c.body[0].body[0]
    assert get_closest_parent_of(c, n, ast.Module).body[0] is n

# Generated at 2022-06-23 23:46:57.814289
# Unit test for function replace_at
def test_replace_at():
    new_node = ast.parse('x = 5', mode='exec').body[0]  # type: ignore
    tree = ast.parse('x = 5 + 6', mode='exec')  # type: ignore
    body = tree.body  # type: ignore
    replace_at(0, body, new_node)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=5))])'

# Generated at 2022-06-23 23:46:59.499245
# Unit test for function find
def test_find():
    tree = ast.parse('if True: pass\n')
    assert list(find(tree, ast.If)) == [tree.body[0]]



# Generated at 2022-06-23 23:47:01.142109
# Unit test for function get_parent
def test_get_parent():
    """Tests that get_parent works as expected."""

# Generated at 2022-06-23 23:47:06.957115
# Unit test for function replace_at
def test_replace_at():
    def f():
        pass

    tree = ast.parse(inspect.getsource(f))

    pass_stmt = find(tree, ast.Pass).__next__()
    func_def = get_parent(tree, pass_stmt)

    replace_at(1, func_def, ast.Pass())

    assert isinstance(func_def.body[1], ast.Pass)

# Generated at 2022-06-23 23:47:09.359738
# Unit test for function replace_at
def test_replace_at():
    import astor
    from strparse import strparse
    from typing import List


# Generated at 2022-06-23 23:47:10.794294
# Unit test for function replace_at
def test_replace_at():
    """Test for function replace_ast."""

# Generated at 2022-06-23 23:47:15.756816
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a + \n b + c')
    assert get_non_exp_parent_and_index(tree, tree.body[0].value) == \
           (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].value.right) == \
           (tree.body[0], 1)

# Generated at 2022-06-23 23:47:26.686400
# Unit test for function insert_at
def test_insert_at():
    import inspect
    import astor
    import antlr4
    import os

    from transformer.lib.grammar.LangParser import LangParser
    from transformer.lib.grammar.LangLexer import LangLexer
    from transformer.lib.antlr_parser import AstBuilder, create_node

    file_name = os.path.dirname(__file__) + "/../../tests/cases/example.py"
    with open(file_name, 'r') as f:
        code = f.read()

    input_stream = antlr4.InputStream(code)
    lexer = LangLexer(input_stream)
    token_stream = antlr4.CommonTokenStream(lexer)
    parser = LangParser(token_stream)
    tree = parser.program()
    tree = AstBuilder.visit(tree)



# Generated at 2022-06-23 23:47:31.339549
# Unit test for function replace_at
def test_replace_at():
    # Set up testing.
    import doctest
    import sys
    suite = doctest.DocTestSuite(sys.modules[__name__])
    res = doctest.testmod(sys.modules[__name__])
    runner = unittest.TextTestRunner()
    runner.run(suite)

if __name__ == "__main__":
    test_replace_at()

# Generated at 2022-06-23 23:47:33.250637
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3 as ast

    insert_at(2, ast.Module([]), ast.Pass())


# Generated at 2022-06-23 23:47:33.781056
# Unit test for function get_parent

# Generated at 2022-06-23 23:47:37.969786
# Unit test for function find
def test_find():
    import astunparse
    tree = ast.parse('x = lambda y: y + 1')
    nodes = find(tree, ast.Name)
    assert set(map(lambda x: astunparse.unparse(x), nodes)) == {'y'}


# Generated at 2022-06-23 23:47:48.144741
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast
    import _ast
    from ..ast_transformer import ForTransformer
    from ..ast_transformer import Transformer
    # import astunparse

    tree = ast.parse("""
    for i in range(10):
        for j in range(10):
            print(i)
    """)

    # tree = ast.parse("""
    # print(3)
    # def foo():
    #     print(3)
    # """)

    ancestor = get_closest_parent_of(tree, tree.body[0].body[0].body[0].value, ast.FunctionDef)
    assert isinstance(ancestor, ast.FunctionDef)
    assert ancestor.name == 'foo'



# Generated at 2022-06-23 23:47:53.725388
# Unit test for function replace_at
def test_replace_at():
    def f(a, b):
        print(a, b)
    tree = ast.parse('f(1,2)')
    parent = tree.body[0].value
    node = parent.args[0]
    node2 = parent.args[1]
    f(node, node2)
    replace_at(0, parent, node2)
    replace_at(1, parent, node)
    assert parent.args[0] == node2
    assert parent.args[1] == node

# Generated at 2022-06-23 23:48:05.534682
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    class module(ast.Module):
        def __init__(self, body: List[ast.AST]):
            self.body = body

    class class_def(ast.ClassDef):
        def __init__(self, name: str):
            self.name = name
            self.body = []

    class while_(ast.While):
        def __init__(self):
            self.body = []

    class if_(ast.If):
        def __init__(self):
            self.body = []

    class function_def(ast.FunctionDef):
        def __init__(self, name: str):
            self.name = name
            self.body = []

    class for_(ast.For):
        def __init__(self):
            self.body = []

    assert get_non_exp_parent_and_

# Generated at 2022-06-23 23:48:13.266832
# Unit test for function insert_at
def test_insert_at():
    # type: () -> None
    tree = ast.parse('''
        def f():
            pass
        def g():
            pass
        def h():
            pass
    ''')
    insert_at(1, tree.body, ast.parse('f()').body[0].value)
    result = ast.dump(tree)


# Generated at 2022-06-23 23:48:17.592685
# Unit test for function get_parent
def test_get_parent():
    def func():
        a = 1
        b = 1

    ast_ = ast.parse(func.__doc__).body[0]
    assert get_parent(ast_, ast_.body[0].body[1]) == ast_.body[0]



# Generated at 2022-06-23 23:48:22.046983
# Unit test for function get_parent
def test_get_parent():
    src = """
        def main():
            pass
    """
    tree = ast.parse(src)
    node = tree.body[0]
    assert get_parent(tree, node) == tree
    print("Test passed successfully")

if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-23 23:48:25.433818
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
        for _ in [1, 2, 3]:
            pass
    """)

    for_node = find(tree, ast.For).__next__()
    non_exp_parent, index = get_non_exp_parent_and_index(tree, for_node)

    assert isinstance(non_exp_parent, ast.Module)
    assert index == 0



# Generated at 2022-06-23 23:48:31.894782
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    t = ast.parse('def foo():\n    bar()')
    call = t.body[0].body[0].value
    parent = get_non_exp_parent_and_index(t, call)
    assert isinstance(parent[0], ast.FunctionDef)
    assert isinstance(parent[1], int)


# Generated at 2022-06-23 23:48:38.465142
# Unit test for function insert_at
def test_insert_at():
    """Test insertion at index."""
    tree = ast.parse('if a:pass')
    if_node = tree.body[0]

    assert len(if_node.body) == 1

    insert_at(0, if_node, ast.parse('b=c'))
    insert_at(1, if_node, ast.parse('d=e'))

    assert if_node.body[0].targets[0].id == 'b'
    assert if_node.body[1].targets[0].id == 'd'

# Generated at 2022-06-23 23:48:47.605508
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Test for getting the nearest parent of a particular type."""
    sample_tree = ast.parse('def foo(): print("")')
    sample_function = sample_tree.body[0]
    sample_variable = ast.arguments(args=[ast.Name("name")], vararg=None,
                                    kwonlyargs=[], kwarg=None, defaults=[],
                                    kw_defaults=[])

    sample_function.body.append(ast.Return(value=sample_variable))
    assert get_closest_parent_of(sample_tree, sample_variable,
                                 ast.stmt.FunctionDef) == sample_function

# Generated at 2022-06-23 23:48:52.294440
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_astunparse

    node = ast.parse('x')
    parent, index = get_non_exp_parent_and_index(node, node.body[0].value)

    assert isinstance(parent, ast.Module)
    assert typed_astunparse.unparse(parent) == 'x'
    assert index == 0

# Generated at 2022-06-23 23:48:56.173427
# Unit test for function find
def test_find():

    tree = ast.parse('a=5')
    nodes = list(find(tree, ast.Assign))

    assert len(nodes) == 1
    assert nodes[0].lineno == 1
    assert nodes[0].col_offset == 0



# Generated at 2022-06-23 23:49:00.492418
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast
    import unittest

    class GetClosestParentOfTest(unittest.TestCase):
        def test(self):
            node = ast.parse('a = 1 + 2')
            parent = get_closest_parent_of(node, node.body[0].value, ast.Module)
            self.assertIsInstance(parent, ast.Module)

    unittest.main()



# Generated at 2022-06-23 23:49:05.716822
# Unit test for function replace_at
def test_replace_at():
    funcdef = ast.FunctionDef(
        name='func',
        args=ast.arguments(
            args=[ast.arg(arg='x', annotation=None)],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            ast.Expr(
                value=ast.Call(
                    func=ast.Name(id='print', ctx=ast.Load()),
                    args=[ast.Str(s='Hello world!')],
                    keywords=[]
                )
            )
        ],
        decorator_list=[],
        returns=None
    )
    arg = ast.arg(arg='y', annotation=None)
    replace_at(0, funcdef.args, arg)

# Generated at 2022-06-23 23:49:13.926781
# Unit test for function insert_at
def test_insert_at():
    def test_func():
        pass

    tree = ast.parse('''
        def test_func(): 
            pass
    ''')
    test_func_node = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)

    insert_at(0, test_func_node, ast.Expr(
            ast.Call(
                    func=ast.Attribute(value=ast.Name(
                        id='test_func'), attr='foo', ctx=ast.Load()),
                    args=[ast.Str(s='bar')], keywords=[]
            ))
    )


# Generated at 2022-06-23 23:49:19.410566
# Unit test for function find
def test_find():
    from ..trees import PythonFile
    from ..utils import parse

    tree = PythonFile(parse('a = 1\nreturn a'))

    assert len(list(find(tree, ast.Return))) == 1

# Generated at 2022-06-23 23:49:23.466820
# Unit test for function replace_at
def test_replace_at():
    # Check all non-Exp type nodes
    nodes = [node for node in ast.walk(ast.parse('foo'))
             if not isinstance(node, ast.Exp)]

    for node in nodes:
        parent = get_parent(ast.parse('foo'), node)
        index = parent.body.index(node)  # type: ignore

        replace_at(index, parent, node)

# Generated at 2022-06-23 23:49:28.520067
# Unit test for function find
def test_find():
    block = ast.parse('0\n1\n2').body

    for i, line in enumerate(find(block, ast.Num)):
        assert i == line.n

# Generated at 2022-06-23 23:49:29.540250
# Unit test for function replace_at

# Generated at 2022-06-23 23:49:36.193534
# Unit test for function insert_at
def test_insert_at():
    node = ast.parse('def foo():\n    pass\n')
    insert_at(1, node, ast.parse('def bar():\n    pass\n'))
    assert(ast.dump(node).split('\n') == ['def foo():', '    pass', '',
                                          'def bar():', '    pass', ''])


# Generated at 2022-06-23 23:49:43.576908
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class DummyExp(ast.AST):
        pass

    module = ast.Module([
        ast.Assign(
            targets=[ast.Name('a', ast.Store())],
            value=ast.Num(n=42)
        ),
        DummyExp(body=ast.Num(n=42))
    ])

    node = module.body[1].body
    expected_parent = module.body[1]
    expected_index = 0

    assert get_non_exp_parent_and_index(module, node) \
        == (expected_parent, expected_index)



# Generated at 2022-06-23 23:49:54.199098
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_node = ast.parse("""
    a = 1
    b = 2
    if a:
        c = 3
        if b:
            d = 4
            print(a)
            if False:
                e = 6
                print(e)""")
    a = list(ast.walk(ast_node))[9]    # variable a
    b = list(ast.walk(ast_node))[10]   # variable b
    c = list(ast.walk(ast_node))[13]   # variable c
    d = list(ast.walk(ast_node))[15]   # variable d
    e = list(ast.walk(ast_node))[17]   # variable e
    print(id(get_closest_parent_of(ast_node, a, ast.Module)))

# Generated at 2022-06-23 23:50:00.592920
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    A = ast.Name(id='a', ctx=ast.Load())
    B = ast.Name(id='b', ctx=ast.Load())
    func = ast.FunctionDef(name='foo', args=ast.arguments(), body=[A, B],
                           decorator_list=[])
    exp = ast.Expr(value=func)

    assert get_non_exp_parent_and_index(exp, B) == (exp, 1)

# Generated at 2022-06-23 23:50:05.373079
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('def a(): pass')
    parent = tree.body[0]
    module_node = find(tree, ast.Module)

    insert_at(0, parent, module_node)

    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.Module)

# Generated at 2022-06-23 23:50:14.366322
# Unit test for function replace_at
def test_replace_at():
    test_tree = ast.parse('x = 1\ny = 2\n')
    node_to_replace = test_tree.body[0]
    replacement = ast.parse('a = 3\n').body[0]
    replacement_parent, replacement_index = \
        get_non_exp_parent_and_index(test_tree, node_to_replace)
    replace_at(replacement_index, replacement_parent, replacement)

    assert ast.dump(test_tree) == 'Module(body=[Assign(targets=[Name(id="a", ' \
                                 'ctx=Store())], value=Num(n=3)), Assign(targets=' \
                                 '[Name(id="y", ctx=Store())], value=Num(n=2))])'


# Generated at 2022-06-23 23:50:20.231496
# Unit test for function find
def test_find():
    import astor

    source = '''
for i in range(10):
    continue
    '''

    tree = ast.parse(source)

    for_node = list(find(tree, ast.For))[0]

    assert for_node.body[0].s == 'continue'
    assert astor.to_source(for_node) == 'for i in range(10):\n    continue'

# Generated at 2022-06-23 23:50:25.147130
# Unit test for function insert_at
def test_insert_at():
    t = ast.parse('x = 2')
    # insert number in assignment
    insert_at(1, t.body[0], ast.Num(1))  # type: ignore
    assert print_node(t) == 'x = 1 2'
    # insert number before assignment
    insert_at(0, t.body[0], ast.Num(2))  # type: ignore
    assert print_node(t) == 'x = 2 1 2'
    # insert number before and after assignment
    insert_at(1, t.body[0], ast.Num(2))  # type: ignore
    assert print_node(t) == 'x = 2 2 1 2'
    # insert 2 numbers before assignment
    insert_at(1, t.body[0], [ast.Num(2), ast.Num(7)])  # type

# Generated at 2022-06-23 23:50:28.945232
# Unit test for function find
def test_find():
    source = 'def foo():\n    pass'
    test_ast = ast.parse(source)
    obj_list = [node for node in find(test_ast, ast.FunctionDef)]
    assert len(obj_list) == 1
    assert obj_list[0].name == 'foo'


# Generated at 2022-06-23 23:50:35.498105
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    from . import ast_factory

    class TestGetClosestParentOf(unittest.TestCase):
        def setUp(self):
            self.tree = ast_factory.generate_tree()

        def test_get_closest_parent_of_get_correct_parent(self):
            node = get_closest_parent_of(self.tree, self.tree.body[0].body[0],
                                         ast.FunctionDef)

            self.assertIsInstance(node, ast.FunctionDef)
            self.assertEqual(node.name, 'bar')

    unittest.main()

# Generated at 2022-06-23 23:50:43.703742
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    exp_1 = ast.Expr(value=ast.Num(n=1))
    exp_2 = ast.Expr(value=ast.Num(n=2)) 
    exp_3 = ast.Expr(value=ast.Num(n=3))
    exp_4 = ast.Expr(value=ast.Num(n=4))
    mod = ast.Module(body=[exp_1, exp_2, exp_3, exp_4])
    result_1 = get_non_exp_parent_and_index(mod, exp_1)
    result_2 = get_non_exp_parent_and_index(mod, exp_2)
    result_3 = get_non_exp_parent_and_index(mod, exp_3)
    result_4 = get_non_exp_parent_and_index

# Generated at 2022-06-23 23:50:46.165522
# Unit test for function replace_at
def test_replace_at():
    x = ast.parse('for x in range(100): pass')
    print(x)
    ls = x.body[0]
    print(ls)
    parent = get_parent(x, ls)
    print(parent)
    for y in ast.walk(x):
        print(y)

# Generated at 2022-06-23 23:50:50.323236
# Unit test for function get_parent
def test_get_parent():
    """Test for function get_parent."""
    tree = ast.parse("def foo():\n    a = 1\n    b = 2")
    assert(isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef))
    assert(isinstance(get_parent(tree, tree.body[0].body[1]), ast.FunctionDef))



# Generated at 2022-06-23 23:50:53.052554
# Unit test for function replace_at
def test_replace_at():
    parent = ast.Module(body=[ast.Expr(value=ast.NameConstant(value=None))])
    node = ast.Expr(value=ast.NameConstant(value=True))
    replace_at(0, parent, node)
    assert parent.body[0] is node


# Generated at 2022-06-23 23:51:03.417825
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_ = ast.parse('def f(a):\n    if a > 10:\n        a = 10\n    else:\n        return a/0\n    print(a)')

    print(get_non_exp_parent_and_index(ast_, ast_.body[0].body[0].body[0])[0] == ast_.body[0])
    print(get_non_exp_parent_and_index(ast_, ast_.body[0].body[0].body[0])[1] == 0)

    print(get_non_exp_parent_and_index(ast_, ast_.body[0].body[0])[0] == ast_.body[0].body[0])

# Generated at 2022-06-23 23:51:10.238889
# Unit test for function insert_at
def test_insert_at():
    class Foo():
        body = []

    a = Foo()

    insert_at(0, a, [1, 2, 3])
    assert len(a.body) == 3
    assert a.body[0] == 1
    assert a.body[1] == 2
    assert a.body[2] == 3

    insert_at(0, a, [1])
    assert len(a.body) == 4
    assert a.body[0] == 1
    assert a.body[1] == 1
    assert a.body[2] == 2
    assert a.body[3] == 3



# Generated at 2022-06-23 23:51:17.980860
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class1 = ast.ImportFrom(module='package_name',
                            names=[ast.alias(name='ClassName',
                                             asname='ClassName')])
    class2 = ast.ClassDef(name='ClassName', bases=[])
    func1 = ast.FunctionDef(name='func',
                            args=ast.arguments(args=[ast.arg(arg='arg1')]))
    func2 = ast.FunctionDef(name='func2',
                            args=ast.arguments(args=[ast.arg(arg='arg1')]),
                            decorator_list=[ast.Name(id='wraps')])
    test_tree = ast.Module(body=[class1, func2, class2, func1])

# Generated at 2022-06-23 23:51:22.609835
# Unit test for function find
def test_find():
    assert 1 == len(list(find(ast.parse('1'), ast.Num)))
    assert 1 == len(list(find(ast.parse('1 + 1'), ast.Num)))
    assert 2 == len(list(find(ast.parse('1 + 1'), ast.BinOp)))
    assert 1 == len(list(find(ast.parse('1 + 1'), ast.Add)))

# Generated at 2022-06-23 23:51:23.813719
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:51:30.632742
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    parent = ast.parse('for x in range(10): x = x + 1')
    print(astor.to_source(parent))
    target = next(find(parent, ast.Name))
    found = get_closest_parent_of(parent, target, ast.For)
    print(astor.to_source(found))

# Generated at 2022-06-23 23:51:34.952534
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

    class Dummy(Exception):
        pass


# Generated at 2022-06-23 23:51:35.902187
# Unit test for function get_parent

# Generated at 2022-06-23 23:51:45.081542
# Unit test for function find
def test_find():
    func = ast.Expression(
        ast.Call(
            ast.Name('foo', ast.Load()),
            [
                ast.Num(1),
                ast.Num(2),
                ast.Num(3),
            ],
            [],
            None,
            None,
        )
    )
    assert list(find(func, ast.Name)) == [ast.Name('foo', ast.Load())]
    assert list(find(func, ast.Num)) == [ast.Num(1), ast.Num(2), ast.Num(3)]

# Generated at 2022-06-23 23:51:47.654437
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import jedi

    tree = jedi.Script('if x == 1: y = 1').goto_definitions()[0].tree

    result_parent, result_index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert result_parent == tree
    assert result_index == 0

# Generated at 2022-06-23 23:51:56.971343
# Unit test for function insert_at
def test_insert_at():
    def test():
        var1 = ast.Name("var1", ast.Store())
        var2 = ast.Name("var2", ast.Store())
        operator = ast.Mult()

        body = [var1, operator, var2]

        assign = ast.Assign(
            targets=[ast.Name("var3", ast.Store())],
            value=body
        )

        parent = ast.Module(body=[assign])

        new_node = ast.Name("new", ast.Load())

        for index, node in enumerate(body):
            insert_at(index, assign, new_node)

        assert isinstance(assign.value[index], ast.Name)

        code = ("var3 = new var1 * new var2")
        assert ast.dump(parent) == code

    test()

# Generated at 2022-06-23 23:51:58.057748
# Unit test for function find

# Generated at 2022-06-23 23:52:01.145296
# Unit test for function replace_at
def test_replace_at():
    test_ast = ast.parse('if True: None')
    replace_at(0, test_ast, [ast.Pass()])
    assert ast.dump(test_ast) == 'Module(body=[Pass()])'



# Generated at 2022-06-23 23:52:06.429273
# Unit test for function find
def test_find():
    from .test_tree import tree
    nodes = list(find(tree, ast.If))
    assert len(nodes) == 2

# Generated at 2022-06-23 23:52:14.062132
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("c = 4")
    node = ast.parse("d = 5")
    insert_at(0, tree, node)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='d', ctx=Store())], value=Num(n=5)), Assign(targets=[Name(id='c', ctx=Store())], value=Num(n=4))])"


# Generated at 2022-06-23 23:52:25.923658
# Unit test for function find
def test_find():
    import unittest  # type: ignore

    class TestFind(unittest.TestCase):
        def test_single(self):
            program = '''
            print('test')
            '''
            tree = ast.parse(program)

            length = len(list(find(tree, ast.Expr)))
            self.assertEqual(length, 1)

        def test_multiple(self):
            program = '''
            print('test')
            print('test')
            '''
            tree = ast.parse(program)

            length = len(list(find(tree, ast.Expr)))
            self.assertEqual(length, 2)

        def test_none(self):
            program = '''
            pass
            '''
            tree = ast.parse(program)


# Generated at 2022-06-23 23:52:35.571920
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import absinthe.ast_compat as ast
    # ast.parse('for i in range(10):\n\tprint(i)\n')
    tree = ast.parse('for i in range(10):\n\tprint(i)\n')
    body = tree.body
    print(tree._fields)
    print(tree.body)
    print(tree.body[0]._fields)
    print(tree.body[0].body)
    print(tree.body[0].body[0]._fields)
    print(tree.body[0].body[0].value._fields)
    print(tree.body[0].body[0].value.args[0]._fields)
    print(tree.body[0].body[0].value.args[0].n)

# Generated at 2022-06-23 23:52:40.050110
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index."""
    tree = ast.parse('a = 1')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.Module)
    assert index == 0
    assert parent.body[index].value == node

# Generated at 2022-06-23 23:52:45.825740
# Unit test for function get_parent
def test_get_parent():
    code = """
if True:
    print "Hello"
    """
    tree = ast.parse(code)
    parent_if = get_parent(tree, tree.body[0].body[0])
    assert isinstance(parent_if, ast.If)

    parent_if = get_parent(tree, tree.body[0].body[1])
    assert isinstance(parent_if, ast.If)



# Generated at 2022-06-23 23:52:55.773648
# Unit test for function insert_at
def test_insert_at():
    """Unittest for function insert_at."""
    from utils import modify_node

    bstmts = ast.Module(body=[ast.Assign(targets=[ast.Name(
        id='a',
        ctx=ast.Store(),
    )],
        value=ast.Num(n=0),
    ),
        ast.Assign(targets=[ast.Name(
            id='b',
            ctx=ast.Store(),
        )],
            value=ast.Num(n=1),
        )],
    ).body

    index = 1
    parent = bstmts[0]
    child = bstmts[1]
    node = ast.Num(n=2)