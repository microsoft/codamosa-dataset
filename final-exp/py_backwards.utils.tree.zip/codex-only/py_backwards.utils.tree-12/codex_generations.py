

# Generated at 2022-06-23 23:43:00.408402
# Unit test for function get_parent
def test_get_parent():
    # type: () -> None
    code = """
    class C:
        def f(self):
            print("Foo")
            pass
    """
    tree = ast.parse(code)
    func_node = find(tree, ast.FunctionDef).next()
    class_node = find(tree, ast.ClassDef).next()
    assert get_parent(tree, func_node) == class_node

# Generated at 2022-06-23 23:43:09.511039
# Unit test for function insert_at
def test_insert_at():
    class FuncDef(ast.AST):
        _fields = ('body',)

        def __init__(self):
            self.body = []

    class Test1(ast.AST):
        pass

    class Test2(ast.AST):
        pass

    class Test3(ast.AST):
        pass

    f = FuncDef()
    t1 = Test1()
    t2 = Test2()
    t3 = Test3()

    f.body.append(t1)
    f.body.append(t2)

    insert_at(0, f, t3)
    assert(f.body[0] is t3)
    assert(f.body[1] is t1)
    assert(f.body[2] is t2)

# Generated at 2022-06-23 23:43:19.340449
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = "def f():\n    a = 2 + 3\n    b = 2 + 3\n    d = 2 + 3\n"
    node = ast.parse(code).body[0]
    stmt1 = node.body[0]
    stmt2 = node.body[1]
    stmt3 = node.body[2]
    parent = get_non_exp_parent_and_index(node, stmt1)[0]
    parent1 = get_non_exp_parent_and_index(node, stmt2)[0]
    parent2 = get_non_exp_parent_and_index(node, stmt3)[0]
    assert parent == parent1
    assert parent1 == parent2

# Generated at 2022-06-23 23:43:23.870681
# Unit test for function find
def test_find():
    code = '''
    def f(x):
        pass
    '''
    tree = ast.parse(code)

    # Find all function definitions
    res = list(find(tree, ast.FunctionDef))
    assert len(res) == 1



# Generated at 2022-06-23 23:43:30.764323
# Unit test for function get_parent
def test_get_parent():
    import typing
    import astor
    module = astor.parse_file('testdata/test_get_parent.py')
    tree = module.body[0]

    result_parent = get_parent(tree,
                               tree.body[0].body[0].body.body[0].body.body[0])
    result_ast = astor.to_source(result_parent)
    assert 'def f(x: int) -> int:' in result_ast


if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-23 23:43:38.059496
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # pylint: disable=unused-variable
    tree = ast.parse("""
        from sys import stdin
        stdin.read(1)
    """)
    read = tree.body[1].value.func
    non_exp_parent, index = get_non_exp_parent_and_index(tree, read)
    assert index == 1
    assert isinstance(non_exp_parent, ast.Module)
    # pylint: enable=unused-variable

# Generated at 2022-06-23 23:43:46.087055
# Unit test for function replace_at
def test_replace_at():
    def func_with_stmt():
        pass

    # The parent for the function is the module, therefore the module
    # must be the AST
    module = ast.parse(inspect.getsource(func_with_stmt))
    module_node = module.body[0]
    return_stmt = module_node.body[0]
    assign_node = ast.Assign(targets=[ast.Name('x', ast.Store())],
                             value=ast.Num(42))
    replace_at(0, module_node, assign_node)

    assert module_node.body[0] == assign_node

# Generated at 2022-06-23 23:43:50.013455
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    a\n    return a')
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0])\
        == (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[2])\
        == (tree.body[0], 1)

# Generated at 2022-06-23 23:44:00.859324
# Unit test for function find
def test_find():
    import astor

    class TestClass:

        def test_find_function():
            node = ast.FunctionDef(name='foo')
            tree = ast.Module(body=[node])
            f = find(tree, ast.FunctionDef)
            assert next(f) is node

        def test_find_all():
            node = ast.FunctionDef(name='foo')
            node_1 = ast.FunctionDef(name='bar')
            tree = ast.Module(body=[node, node_1])
            f = find(tree, ast.FunctionDef)
            assert next(f) is node
            assert next(f) is node_1

        def test_find_multiple():
            node = ast.FunctionDef(name='foo')
            node_1 = ast.FunctionDef(name='bar')

# Generated at 2022-06-23 23:44:04.118560
# Unit test for function find
def test_find():
    def func(param: int = 1, *args: str, **kwds: float) -> None:
        pass

    assert len(list(find(ast.parse(func.__text_signature__), ast.Name))) == 3

# Generated at 2022-06-23 23:44:09.714016
# Unit test for function insert_at
def test_insert_at():
    node = ast.Module(body=[])
    funcdef = ast.FunctionDef(name='funcdef')
    node.body.append(funcdef)  # type: ignore

    insert_at(-1, node, ast.Print(dest=None, values=[], nl=True))
    assert node.body[-1].values[0].s == 'funcdef'

    insert_at(0, funcdef, ast.Print(dest=None, values=[], nl=True))
    assert funcdef.body[0].values[0].s == 'funcdef'
    assert len(funcdef.body) == 1

# Generated at 2022-06-23 23:44:10.512956
# Unit test for function get_parent

# Generated at 2022-06-23 23:44:15.879575
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    replace_at(0, tree.body[0], [ast.Expr(ast.Num(1)), ast.Expr(ast.Num(2))])
    import astor  # lazy import
    print(astor.to_source(tree))


# Generated at 2022-06-23 23:44:19.639825
# Unit test for function replace_at
def test_replace_at():
    test_tree = ast.parse('for i in range(10): pass')
    parent = test_tree.body[0]
    index = 0

    replace_at(index, parent, ast.parse('pass'))



# Generated at 2022-06-23 23:44:22.877156
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.AST()
    tree = ast.AST()
    tree.body = [node]
    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)

# Generated at 2022-06-23 23:44:32.987828
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        _fields = ("a", "b", "c")

    class B(ast.AST):
        _fields = ("body",)

    tree = A(a=1, b=2, c=3)

    assert tree.a == 1
    assert tree.b == 2
    assert tree.c == 3

    insert_at(0, tree, 10)

    assert tree.a == 1
    assert tree.b == 10
    assert tree.c == 2
    assert tree.c.c == 3

    insert_at(0, tree, 20)

    assert tree.a == 1
    assert tree.b == 20
    assert tree.b.b == 10
    assert tree.b.b.b == 2
    assert tree.b.b.b.c == 3


# Generated at 2022-06-23 23:44:34.184420
# Unit test for function replace_at
def test_replace_at():
    import astor

# Generated at 2022-06-23 23:44:45.118523
# Unit test for function replace_at
def test_replace_at():
    from typed_ast import (
        ast3 as ast,
    )
    from typing import (
        Callable,
    )

    exp = ast.Expr(ast.Call(ast.Name('a', True), [], [], [], None, None))
    func = ast.FunctionDef(name='func', args=ast.arguments(args=[],
                                                            defaults=[],
                                                            kwonlyargs=[],
                                                            kw_defaults=[],
                                                            kwarg=None,
                                                            vararg=None),
                           body=[exp], decorator_list=[])
    exp2 = ast.Expr(ast.Call(ast.Name('b', True), [], [], [], None, None))
    func.body[0] = exp2
    assert func.body

# Generated at 2022-06-23 23:44:49.463855
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import re
    #from astpretty import pprint
    #from astpretty.graph import Graph
    from astor.codegen import to_source
    from . import common_nodes


# Generated at 2022-06-23 23:44:52.941952
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3 as ast
    list_ = ast.List(ctx=ast.Load())
    insert_at(0, list_, ast.Name(id="a", ctx=ast.Load()))
    assert isinstance(list_.elts[0], ast.Name) # noqa


# Generated at 2022-06-23 23:44:55.865164
# Unit test for function get_parent
def test_get_parent():
    code = '''
    def func():
        a = 'b'
        print(a)
'''

    tree = ast.parse(code)

    parent = get_parent(tree, tree.body[0].body[0].body[0])

    assert isinstance(parent, ast.FunctionDef)



# Generated at 2022-06-23 23:45:02.602713
# Unit test for function replace_at
def test_replace_at():
    """Test for replace_at function."""
    tree = ast.parse('''
        func()
        func()
        func()
        func()
        ''')

    parent = tree.body[0]
    index = 1
    tree = ast.parse('''
        call()
    ''')

    replace_at(parent.body.index(tree.body[0]), parent, tree.body)
    assert parent.body[index].value.func.id == "call"

# Generated at 2022-06-23 23:45:10.657597
# Unit test for function insert_at
def test_insert_at():
    from astunparse import dump
    import textwrap
    from ..visitor import Visitor
    module = ast.parse(textwrap.dedent(
        """
        class A:
            def __init__(self):
                self.a = 2
                self.b = 3
            def a_func(self):
                self.a = 4
                self.b = 5
        def b_func():
            return 3
        """
    ))

    def_node = [node for node in ast.walk(module)
                if isinstance(node, ast.FunctionDef)][1]

    insert_at(0, def_node, ast.parse('self.a = 2').body[0])
    print(dump(module))



# Generated at 2022-06-23 23:45:21.700002
# Unit test for function insert_at
def test_insert_at():
    code = '''
    def foo():
        a = 1
        b = 2 + a
        return None
    '''

    tree = ast.parse(code)
    func_node = tree.body[0]
    assignment_node = func_node.body[1]
    return_node = func_node.body[2]

    insert_at(1, func_node, ast.parse('c = 5').body[0])

    assert len(func_node.body) == 4
    assert func_node.body[1].value.n == 5

    insert_at(1, func_node, ast.parse('d = 6').body[0])

    assert len(func_node.body) == 5
    assert func_node.body[1].value.n == 6


# Generated at 2022-06-23 23:45:22.395039
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:45:32.118257
# Unit test for function find
def test_find():
    from pickle import loads
    from astor import to_source
    from .. import util
    # foo.bar.xyz(1)
    node = loads(b'c__main__\nName\np0\n(g1\nVbar\np2\ntp3\nRp4\n(g5\nVxyz\np6\ntp7\nRp8\n(g9\nVfoo\np10\ntp11\nRp12\n(g13\nV__main__\nNtRp14\n.')
    print(to_source(node))
    # x = foo.bar.xyz(1)

# Generated at 2022-06-23 23:45:43.079469
# Unit test for function replace_at
def test_replace_at():
    x = ast.parse("for x in range(0,10): pass")
    x = ast.fix_missing_locations(x)
    assert isinstance(x, ast.Module)
    assert len(x.body) == 1
    for_node = x.body[0]
    assert isinstance(for_node, ast.For) # type: ignore
    assert len(for_node.body) == 1
    assert isinstance(for_node.body[0], ast.Pass) # type: ignore
    replace_at(0,for_node, [ast.Expr(value=ast.Num(n=1))])
    assert len(for_node.body) == 1
    assert isinstance(for_node.body[0], ast.Expr) # type: ignore

# Generated at 2022-06-23 23:45:50.587403
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Test get_closest_parent_of function from typed_ast_tools.utils."""
    from .test_utils import input_, output_
    ast_input = ast.parse(input_('tests/fixtures/for_loop_with_else.py'))
    ast_output = ast.parse(output_('tests/fixtures/for_loop_with_else.py'))

    assert get_closest_parent_of(ast_input,  # NOQA
                                 ast_input.body[0].body[0].body[0],
                                 ast.For) == ast_input.body[0]
    assert get_closest_parent_of(ast_output,  # NOQA
                                 ast_output.body[0].body[0].body[0],
                                 ast.For)

# Generated at 2022-06-23 23:45:59.416585
# Unit test for function replace_at
def test_replace_at():
    class FakeParent(ast.AST):
        _fields = ('body',)

    class FakeNode(ast.AST):
        _fields = ('name',)

    class FakeNode2(ast.AST):
        _fields = ('name',)

    fake_parent = FakeParent()
    fake_parent.body = []  # type: ignore

    fake_parent.body.append(FakeNode())
    fake_parent.body.append(FakeNode())  # type: ignore
    fake_parent.body.append(FakeNode())  # type: ignore
    fake_parent.body.append(FakeNode())  # type: ignore

    replace_at(2, fake_parent, FakeNode2())
    replace_at(2, fake_parent, [FakeNode2(), FakeNode2()])


# Generated at 2022-06-23 23:46:00.507326
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:46:01.756456
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:46:06.734930
# Unit test for function find
def test_find():
    tree = ast.parse("""
    a = 5
    b = func()
    """)
    nodes = list(find(tree, ast.Assign))

    assert len(nodes) == 2
    assert isinstance(nodes[0], ast.Assign)
    assert isinstance(nodes[1], ast.Assign)



# Generated at 2022-06-23 23:46:14.401696
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    from ..exceptions import NodeNotFound
    from .fixtures import example_node, example2_node
    from ..utils import node_utils
    from .decorators import remove_whitespace

    class TestGetClosestParentOf(unittest.TestCase):
        def test_get_parent_of_funcdef(self):
            example = example_node()
            example2 = example2_node()
            func = node_utils.find_first(example, ast.FunctionDef)
            func2 = node_utils.find_first(example2, ast.FunctionDef)
            self.assertEqual(get_closest_parent_of(example, func, ast.FunctionDef), func)

# Generated at 2022-06-23 23:46:21.621337
# Unit test for function replace_at
def test_replace_at():
    _tree = ast.parse('\n'.join([
        'def Test():',
        '    Test()',
        '    Test2()',
        '    Test3()',
        '    Test4()'
    ]))
    _func = _tree.body[0]
    _parent = _func.body[0]

    _tree = replace_at(2, _parent, [ast.Expr(ast.Name('Test', ast.Load()))])
    assert _parent.body[2].value.id == 'Test'



# Generated at 2022-06-23 23:46:22.075065
# Unit test for function get_parent

# Generated at 2022-06-23 23:46:23.751591
# Unit test for function find
def test_find():
    code = 'class A:\n    def b():\n        pass\n'
    tree = ast.parse(code)
    node = find(tree, ast.FunctionDef).__next__()
    assert node.name == 'b'



# Generated at 2022-06-23 23:46:32.544128
# Unit test for function get_parent
def test_get_parent():
    global _parents

    _parents = WeakKeyDictionary()
    prg = ast.parse('4')
    two = prg.body[0].value
    four = two.operand

    assert get_parent(prg, two) == prg.body[0]
    assert get_parent(prg, two) is prg.body[0]
    assert get_parent(prg, four) == prg.body[0].value

    get_parent(prg, two, rebuild=True)
    assert get_parent(prg, two) == prg.body[0]
    assert get_parent(prg, two) is prg.body[0]
    assert get_parent(prg, four) == prg.body[0].value



# Generated at 2022-06-23 23:46:34.262608
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from .typed_ast_hack import ast3 as ast


# Generated at 2022-06-23 23:46:35.691928
# Unit test for function find

# Generated at 2022-06-23 23:46:45.547206
# Unit test for function insert_at
def test_insert_at():
    import unittest
    import astunparse

    # Test submodule
    class TestInsertAt(unittest.TestCase):
        def setUp(self):
            self.ast = ast.parse('''\
            def f():
                pass''')

            self.ast_print = astunparse.unparse(self.ast)

        def _check(self, indices: List[int]):
            # Check if ast_list is same as original
            ast_list = astunparse.unparse(self.ast).splitlines()
            ast_list_orig = self.ast_print.splitlines()
            self.assertListEqual(ast_list, ast_list_orig)


# Generated at 2022-06-23 23:46:56.164202
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('''
        def foo():
            if 0:
                return
            if 1:
                print()
                return
            print()
    ''')
    parent = get_closest_parent_of(tree, tree.body[0].body[2],
                                   ast.stmt)

    new_node = ast.Expr(value=ast.Call(func=ast.Name(id='print'),
                                       args=[ast.Str(s='foo')],
                                       keywords=[]))
    insert_at(1, parent, new_node)

    expected_tree = ast.parse('''
        def foo():
            if 0:
                return
            if 1:
                print()
                print('foo')
                return
            print()
    ''')


# Generated at 2022-06-23 23:46:58.617201
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""def id(x): \n return x""")
    index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])[1]
    assert index == 0

# Generated at 2022-06-23 23:47:08.277614
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def test():
        if True:
            print("Hello")
    """)

    node = get_closest_parent_of(tree.body[0].body[0], tree.body[0].body[0].value, ast.FunctionDef)
    assert isinstance(node, ast.FunctionDef)

    node = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.If)
    assert isinstance(node, ast.If)

    node = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.FixFloorDiv)
    assert node is None

# Generated at 2022-06-23 23:47:10.306885
# Unit test for function replace_at
def test_replace_at():
    import astor
    from .copy import deepcopy


# Generated at 2022-06-23 23:47:11.471915
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:47:15.378477
# Unit test for function replace_at
def test_replace_at():
    import astunparse
    import inspect
    tree = ast.parse("a = 1")
    replace_at(0, tree, ast.parse("b = 1"))
    assert astunparse.unparse(tree) == inspect.cleandoc("""
        b = 1
        """)

# Generated at 2022-06-23 23:47:19.165475
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nprint(a)')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1])

    assert parent is tree
    assert index == 1


# Generated at 2022-06-23 23:47:23.490503
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = b', '<string>', 'exec')
    node = tree.body[0].value
    assert get_parent(tree, node) is tree.body[0]
    assert get_parent(tree, tree.body[0]) is tree.body



# Generated at 2022-06-23 23:47:28.388168
# Unit test for function find
def test_find():
    program = ast.parse('x = 1; y = 2; z = 3; z + z; z * z')

    for node in find(program, ast.Num):
        assert isinstance(node, ast.Num)

    for node in find(program, ast.BinOp):
        assert isinstance(node, ast.BinOp)



# Generated at 2022-06-23 23:47:32.300260
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    find_code = "find(tree, type_)"
    find_ast = ast.parse(find_code)
    find_clause = find_ast.body[0]
    assert get_non_exp_parent_and_index(find_ast, find_clause.value) == \
        (find_ast, 0)



# Generated at 2022-06-23 23:47:38.356117
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    from ast_processor.transformation import get_non_exp_parent_and_index

    source = """
if True:
    x = 3
    y = 2
    x + y"""

    tree = astor.parse_file(source)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[2])
    assert parent == tree.body[0]
    assert index == 1



# Generated at 2022-06-23 23:47:48.144218
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1\nb = 1\nc = 1\nd = 1')
    should_apply = False
    sequence_to_insert = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and \
                isinstance(node.ctx, ast.Store):
            if node.id == 'b':
                should_apply = True

            if should_apply:
                sequence_to_insert.append(node)

    target = tree.body[1]
    target_parent = get_parent(tree, target)
    replace_at(target_parent.body.index(target), target_parent,
               sequence_to_insert)



# Generated at 2022-06-23 23:47:51.345721
# Unit test for function replace_at
def test_replace_at():
    import inspect
    import astor
    d = ast.parse("""x = 1
x = 3
x = 3""")

    replace_at(0, d.body, ast.parse("""x = 1
x = 2
x = 3
"""))
    replace_at(0, d.body[0].body, ast.parse("x = 1 if False else None"))
    print(astor.to_source(d))



# Generated at 2022-06-23 23:47:55.323310
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    for node in find(ast.parse('''class Example:
    def f(self):
        if 1:
            return 1
        else:
            1 + 1
        '''), ast.AST):
        print(get_closest_parent_of(node, node, ast.FunctionDef).name)

if __name__ == '__main__':
    test_get_closest_parent_of()

# Generated at 2022-06-23 23:48:01.941247
# Unit test for function find
def test_find():
    import astor
    source = 'x = "string"\nprint("a")\nprint("b")'
    tree = ast.parse(source)
    print(astor.to_source(tree))
    print("")
    l = list(find(tree, ast.Expr))
    for x in l:
        print("Found", x)
        print("")
    return l


# Generated at 2022-06-23 23:48:06.176877
# Unit test for function find
def test_find():
    # This test is only to make sure the library typed_ast works
    # and is not a part of our testing process
    assert list(find(ast.parse("a = 1"), ast.Assign)) == \
        [ast.parse('a = 1').body[0]]


# Generated at 2022-06-23 23:48:11.334854
# Unit test for function insert_at
def test_insert_at():
    def _find_index(index, parent, nodes):
        insert_at(index, parent, nodes)
        return parent.body.index(nodes[0])

    assert _find_index(0, ast.Module(body=[]), None) == 0
    assert _find_index(1, ast.Module(body=[None]), None) == 1
    assert _find_index(0, ast.Module(body=[None, None]), None) == 0



# Generated at 2022-06-23 23:48:18.260650
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a = 1')
    fn_def = tree.body[0]
    assig = fn_def.body[0]
    test = ast.parse('b = 2')
    insert_at(0, fn_def, test)
    assert len(fn_def.body) == 2
    assert fn_def.body[0] == test.body[0]
    assert fn_def.body[1] == assig



# Generated at 2022-06-23 23:48:27.415941
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a=1;b=2;c=3;d=4;e=5;')
    index = 0
    parent = tree.body
    node = ast.parse('f=6;')

    insert_at(index,parent,node)


# Generated at 2022-06-23 23:48:28.451003
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass



# Generated at 2022-06-23 23:48:36.794734
# Unit test for function replace_at
def test_replace_at():
    r = ast.parse('test(test2)')
    replace_at(0, r, [ast.parse('test3'), ast.parse('test4')])
    assert ast.dump(r) == "Module(body=[Expr(value=Call(func=Name(id='test3', ctx=Load()), args=[Call(func=Name(id='test4', ctx=Load()), args=[Name(id='test2', ctx=Load())], keywords=[], starargs=None, kwargs=None)], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-23 23:48:38.587212
# Unit test for function find
def test_find():
    tree = ast.parse('1+1')
    nodes = list(find(tree, ast.Num))
    assert len(nodes) == 2

# Generated at 2022-06-23 23:48:48.726482
# Unit test for function insert_at
def test_insert_at():
    print("\n")
    print("*** NodeManager.insert_at ***")
    import astor
    from .typed_ast_extra import Module

    module = Module(
        body=[
            ast.Expr(
                value=ast.Call(
                    func=ast.Name(id='print', ctx=ast.Load()),
                    args=[ast.Str(s='Hello, World!')],
                    keywords=[])),
            ast.Expr(
                value=ast.Call(
                    func=ast.Name(id='print', ctx=ast.Load()),
                    args=[ast.Str(s='This is the second line.')],
                    keywords=[])),
        ],
        type_ignores=[])
    print("Before:\n{}".format(astor.to_source(module)))

# Generated at 2022-06-23 23:48:53.572332
# Unit test for function insert_at
def test_insert_at():
    import typed_ast.ast3 as ast
    import astor
    x = ast.parse("""def foo():\n    x = 1""")
    y = ast.parse("""x = 2\n""")
    insert_at(1, x.body[0], y.body[0])
    print(astor.to_source(x))


if __name__ == '__main__':
    test_insert_at()

# Generated at 2022-06-23 23:49:04.301226
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = """
        func1()
        func2()
        if True:
            stmt = 1
        func3()
    """

    node = ast.parse(code)

    parent, index = get_non_exp_parent_and_index(node, node.body[-1])
    assert parent is node
    assert index == 4

    parent, index = get_non_exp_parent_and_index(node, node.body[-1].body[0])
    assert parent is node.body[-1]
    assert index == 0

    parent, index = get_non_exp_parent_and_index(node, node.body[-1].body[0].value)
    assert parent is node.body[-1].body[0]
    assert index == 0

# Generated at 2022-06-23 23:49:09.748311
# Unit test for function get_parent
def test_get_parent():
    import astor
    source = \
    """
    if (1 + 2 - 3 * 4 < 5 / 6) or (7 >= 8 <= 9):
        if True:
            print("test")
    """
    tree = ast.parse(source)
    parent = get_parent(tree, tree.body[0].body[0].body[0])
    assert hasattr(parent, 'body')


# Generated at 2022-06-23 23:49:19.538878
# Unit test for function insert_at
def test_insert_at():
    import unittest
    import typed_ast.ast3 as ast3

    class TestInsertAt(unittest.TestCase):
        def test_insert_at(self):

            class Test:
                def __init__(self, a, b=1, *args, **kwargs):
                    self.a = a
                    self.b = b
                    self.args = args
                    self.kwargs = kwargs

            class Test2:
                def __init__(self, a, b=1, *args, **kwargs):
                    self.a = a
                    self.b = b
                    self.args = args
                    self.kwargs = kwargs

            tree = ast3.parse('foo = Test(1, 2, c=3, d=4)')
            func_def = tree.body[0]
           

# Generated at 2022-06-23 23:49:22.316478
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("a = 1")
    print(get_parent(tree, tree.body[0].targets[0]))
    get_parent(tree, 1)


# Generated at 2022-06-23 23:49:28.670711
# Unit test for function replace_at
def test_replace_at():
    n = ast.parse('func()')
    n.body[0] = ast.Expr(value=ast.Call(func=ast.Name(id='func2'), args=[], keywords=[]))
    assert ast.dump(n) == '<Module [<Expr <Call func=func2 () []>>>]'

# Generated at 2022-06-23 23:49:39.632756
# Unit test for function get_parent
def test_get_parent():
    expected_result = ast.Module(body=[ast.FunctionDef(name='f', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=10))], decorator_list=[], returns=None)])
    parsed_result = ast.parse('''
            def f():
                x = 10
            ''')
    _build_parents(parsed_result)
    parent = get_parent(parsed_result, parsed_result.body[0].body[0])
    assert type(parent) == type(expected_result.body[0].body[0])

# Generated at 2022-06-23 23:49:50.919747
# Unit test for function replace_at
def test_replace_at():
    import typed_ast.ast3
    replace_at_module = typed_ast.ast3.parse(
        "import requests\n"
        "import unittest\n"
        "def request_get(url, timeout=1):\n"
        "    return requests.get(url, timeout=timeout)\n"
        "def test_success_get():\n"
        "    assert request_get('http://example.com')\n"
        "def test_timeout():\n" 
        "    assert request_get('http://example.com', timeout=0)\n")
    test_success_get = typed_ast.ast3.parse(
        "def test_success_get():\n"
        "    assert requests.get('http://example.com')\n")
    timed_out_node = replace_

# Generated at 2022-06-23 23:49:55.993297
# Unit test for function find
def test_find():
    data = ast.parse('''
    def foo():
        pass

    class Bar:
        @staticmethod
        def baz():
            pass
    ''')

    assert len(list(find(data, ast.FunctionDef))) == 2
    assert len(list(find(data, ast.Name))) == 4

# Generated at 2022-06-23 23:50:02.804915
# Unit test for function get_parent
def test_get_parent():
    source = """
    def foo():
        if a:
            return b + c
    """
    tree = ast.parse(source)
    if_node = tree.body[0].body[0]
    if_parent = get_parent(tree, if_node)
    if_parent_is_def_node = isinstance(if_parent, ast.FunctionDef)
    assert if_parent_is_def_node, 'get_parent didn\'t work properly'


# Generated at 2022-06-23 23:50:04.948489
# Unit test for function find
def test_find():
    b = ast.parse('a = 3')
    for st in find(b, ast.Store):
        print(st)


# Generated at 2022-06-23 23:50:10.779502
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3 as ast
    from ..types import Path

    root = ast.parse('print(path)')
    print_statement = root.body[0]
    insert_at(0, print_statement, Path())

    assert ast.dump(root) == '''
<_ast.Module object at 0x7f58f1d1f828>'''

if __name__ == '__main__':
    test_insert_at()

# Generated at 2022-06-23 23:50:11.992471
# Unit test for function replace_at
def test_replace_at():
    import astor

# Generated at 2022-06-23 23:50:12.863535
# Unit test for function insert_at
def test_insert_at():
    pass

# Generated at 2022-06-23 23:50:15.805136
# Unit test for function insert_at

# Generated at 2022-06-23 23:50:23.328864
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module = ast.parse("""if True:
                             if True:
                                 if True:
                                     pass
                             pass
                         pass""")
    if_node = module.body[0].body[0].body[0]
    expected_parent = module.body[0].body[0]
    expected_index = 0

    parent, index = get_non_exp_parent_and_index(module, if_node)

    assert parent == expected_parent
    assert index == expected_index

# Generated at 2022-06-23 23:50:28.410986
# Unit test for function insert_at
def test_insert_at():
    tree_copy = copy.deepcopy(tree)
    ast.fix_missing_locations(tree_copy)
    insert_at(1, tree_copy.body[0].body, ast.parse("f()").body[0])
    assert get_parent(tree_copy, tree_copy.body[0].body[1]).body[0].value.func.id == "f"  # type: ignore



# Generated at 2022-06-23 23:50:30.024696
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast

# Generated at 2022-06-23 23:50:37.137610
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor  # type: ignore
    from .. import _expatimpl  # type: ignore
    from ..expat_ast import parse  # type: ignore

    for path in ["setup.py", "expat/__init__.py"]:
        tree = parse(path)
        parent = get_closest_parent_of(tree, tree.body[0], ast.Try)
        assert astor.to_source(parent) == 'try:\n    pass\nexcept:\n    pass\n'

        parent = get_closest_parent_of(tree, tree.body[0], ast.FunctionDef)
        assert astor.to_source(parent) == 'def setup(setuptools_kwargs=None):\n    pass\n'


# Generated at 2022-06-23 23:50:40.442059
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Assign)
    assert index == 0


if __name__ == '__main__':
    test_get_non_exp_parent_and_index()

# Generated at 2022-06-23 23:50:49.002317
# Unit test for function replace_at
def test_replace_at():
    REPLACE = ['a', 'b', 'c']
    tree = ast.parse('"do" "not" "replace"')
    func_def = tree.body[0]  # type: ast.FunctionDef
    node_stmt = func_def.body[0]  # type: ast.Expr
    replace_at(1, node_stmt, REPLACE)
    assert node_stmt.value.s == REPLACE[0]
    assert len(node_stmt.value.values) == 2


# Generated at 2022-06-23 23:50:49.756549
# Unit test for function replace_at

# Generated at 2022-06-23 23:50:53.667213
# Unit test for function replace_at
def test_replace_at():
    module = ast.parse('def foo():\n'
                       '    pass')
    function = module.body[0]

    replace_at(0, function, ast.Expr(ast.Str('Hello'), lineno=2, col_offset=4))

    assert len(function.body) == 1
    assert isinstance(function.body[0], ast.Expr)
    assert ast.dump(function.body[0]) == "Expr(value=Str(s='Hello'))"

# Generated at 2022-06-23 23:51:00.850539
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    class_node = astor.parse('def f():\n    print(1)\n    '
                         'x=1\n    return x').body[0]
    iter(class_node.body).__next__()
    test_node = iter(class_node.body).__next__()
    parent_node = get_closest_parent_of(astor.parse('def f():\n    print(1)\n    '
                         'x=1\n    return x'), test_node, ast.FunctionDef)
    assert parent_node == class_node

# Generated at 2022-06-23 23:51:06.907920
# Unit test for function find
def test_find():
    import unittest
    import typed_ast.ast3 as ast

    class FindTest(unittest.TestCase):
        def test_find_nodes_of_type(self):
            src = '''
                def test():
                    a = 1
                    a += 2
                    return a
                '''

            root = ast.parse(src)
            nodes = list(find(root, ast.FunctionDef))

            self.assertEqual(len(nodes), 1)
            self.assertEqual(nodes[0].name, 'test')

    unittest.main()


# Generated at 2022-06-23 23:51:13.816468
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    from ..refactor import RefactoringTool
    nodes_to_replace = [ast.Print]
    tree = astor.parse(
        'print("Hello World!")')
    tool = RefactoringTool(tree, nodes_to_replace)
    parent, index = get_non_exp_parent_and_index(tool.tree, tool.tree.body[0])

    # The function should return the top level parent node and its index
    assert isinstance(parent, ast.Module)
    assert index == 0



# Generated at 2022-06-23 23:51:14.316279
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-23 23:51:17.807690
# Unit test for function insert_at
def test_insert_at():
    def _test_insert_at(tree, type_, index, insert_tree, result):
        parent = get_closest_parent_of(tree, insert_tree, type_)
        insert_at(index, parent, insert_tree)
        assert ast.dump(tree) == ast.dump(result)


# Generated at 2022-06-23 23:51:18.880803
# Unit test for function get_parent

# Generated at 2022-06-23 23:51:30.837203
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        _fields = ('a', 'b')
        _attributes = ('c', 'd')

    class B(ast.AST):
        _fields = ('list',)
        _attributes = ()

    a1 = A(a='a1', b='b1', c='c1', d='d1')
    a2 = A(a='a2', b='b2', c='c2', d='d2')
    a3 = A(a='a3', b='b3', c='c3', d='d3')
    b1 = B(list=[a1, a2, a3])
    assert b1.list == [a1, a2, a3]

# Generated at 2022-06-23 23:51:42.630662
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def func(a, b):
        a + 5
        a + b
        5 + b
        b + 5
    """, mode='exec')
    _, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])
    assert index == 0
    _, index = get_non_exp_parent_and_index(tree, tree.body[0].body[2])
    assert index == 1
    _, index = get_non_exp_parent_and_index(tree, tree.body[0].body[3])
    assert index == 2
    _, index = get_non_exp_parent_and_index(tree, tree.body[0].body[4])
    assert index == 3

# Generated at 2022-06-23 23:51:43.478803
# Unit test for function insert_at
def test_insert_at():
    # TODO
    pass



# Generated at 2022-06-23 23:51:46.940887
# Unit test for function replace_at
def test_replace_at():
    tree1 = ast.parse("a = 1")
    tree2 = ast.parse("b = 2")
    parent = tree1.body[0]
    replace_at(0, parent, tree2)
    assert str(tree1.body[0]) == "b = 2"


# Generated at 2022-06-23 23:51:52.925378
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('[1, 2, 3][2]').body[0].value.ctx
    body = ast.parse('[1, 2, 3]')
    parent = get_non_exp_parent_and_index(body, node)
    assert parent[1] == 0
    assert isinstance(parent[0], ast.Module)


# Generated at 2022-06-23 23:51:59.669032
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        '''
a = 1
a = 1
'''
    )
    non_exp_parent, index = get_non_exp_parent_and_index(tree, tree.body[1].value)
    assert index == 0
    assert isinstance(non_exp_parent, ast.Module)


# Generated at 2022-06-23 23:52:00.600037
# Unit test for function replace_at

# Generated at 2022-06-23 23:52:10.266067
# Unit test for function replace_at
def test_replace_at():
    print('test_replace_at')
    clazz = ast.ClassDef()
    clazz.body = [ast.Name()]

    replace_at(0, clazz, ast.FunctionDef())

    assert len(clazz.body) == 1
    assert isinstance(clazz.body[0], ast.FunctionDef)

    replace_at(0, clazz, [ast.FunctionDef(), ast.FunctionDef()])

    assert len(clazz.body) == 3
    assert isinstance(clazz.body[0], ast.FunctionDef)



# Generated at 2022-06-23 23:52:10.867558
# Unit test for function insert_at

# Generated at 2022-06-23 23:52:20.842027
# Unit test for function insert_at
def test_insert_at():
    node1 = ast.AST()
    node2 = ast.AST()
    node3 = ast.AST()
    nodes = [node1, node2, node3]
    parent = ast.AST()
    parent.body = [node1]
    insert_at(0, parent, node3)
    assert parent.body == nodes

    parent.body = [node1, node2]
    insert_at(1, parent, node3)
    assert parent.body == nodes

    parent.body = [node1]
    insert_at(0, parent, [node3, node2])
    assert parent.body == [node3, node2, node1]



# Generated at 2022-06-23 23:52:32.121341
# Unit test for function get_parent
def test_get_parent():
    import unittest

    from ..obj import *
    from ..utils import to_ast

    class TestNode(unittest.TestCase):
        def test_node(self):
            tree = to_ast('''
                a = 1
                b = 2
                c = 3''')

            a = tree.body[0].targets[0]
            b = tree.body[1].targets[0]
            c = tree.body[2].targets[0]

            self.assertIs(get_parent(tree, a), tree.body[0],
                          'Expected to be first assignment')
            self.assertIs(get_parent(tree, b), tree.body[1],
                          'Expected to be second assignment')

# Generated at 2022-06-23 23:52:35.987839
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    # Test case inputs
    tree = ast.parse("""
    if True:
        print('hello python')
    """)

    node = tree.body[0]
    type_ = ast.If

    # Test case expected outputs
    expected_output = """
    if True:
        print('hello python')
    """

    # Function under test
    actual_output = get_closest_parent_of(tree, node, type_)

    # Unit test assertions
    assert ast.dump(actual_output) == ast.dump(ast.parse(expected_output).body[0])

# Generated at 2022-06-23 23:52:37.000523
# Unit test for function insert_at

# Generated at 2022-06-23 23:52:42.821097
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('''
    def fn():
        a = 1
        a = 3
        a = 4
    ''')

    print(ast.dump(tree))
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])
    replace_at(index, parent, ast.parse('a = 2').body)
    print(ast.dump(tree))



# Generated at 2022-06-23 23:52:49.878667
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    from compiler.ast import Module
    from compiler.ast import Stmt
    from compiler.ast import Discard

    mod = Module([
        Stmt([Discard(Const(10))]),
        Stmt([Discard(Const(10))]),
        Stmt([Discard(Const(10))]),
    ])
    _build_parents(mod)
    assert get_closest_parent_of(mod, mod.node.nodes[0].nodes[0], Stmt) == mod.node.nodes[0]
    assert get_closest_parent_of(mod, mod.node.nodes[0].nodes[0], Module) == mod

# Generated at 2022-06-23 23:53:00.515779
# Unit test for function insert_at
def test_insert_at():
    def f(a, b):
        return a + b

    tree = ast.parse('def f(a, b): return a + b')

    ast.increment_lineno(tree, n=1)

    fdef = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.FunctionDef)
    insert_at(0, fdef.body, ast.Print(dest=None, values=[ast.Num(n=10)],
                                      nl=True,
                                      start_pos=None, end_pos=None,
                                      type_comment=None))

    assert ast.dump(tree) == textwrap.dedent('''
    def f(a, b):
        print(10)
        return a + b
    ''').lstrip()

# Unit