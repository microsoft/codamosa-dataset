

# Generated at 2022-06-23 23:42:56.840197
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class funcdef(ast.AST):
        def __init__(self, name, args=None, body=None):
            self.name = name
            self.args = args
            self.body = body

    class classDef(ast.AST):
        def __init__(self, name, body=None):
            self.name = name
            self.body = body

    class return_stmt(ast.AST):
        def __init__(self, value):
            self.value = value

    class Name(ast.AST):
        def __init__(self, id, ctx):
            self.id = id
            self.ctx = ctx

    class Call(ast.AST):
        def __init__(self, func, args=None, keywords = None):
            self.func = func

# Generated at 2022-06-23 23:43:05.395109
# Unit test for function insert_at
def test_insert_at():
    import copy
    import ast
    from typed_ast import ast3 as ast
    from ..ast_utils import insert_at, get_parent, get_non_exp_parent_and_index

    add = ast.BinOp(ast.Num(1), ast.Add(), ast.Num(2))
    sub = ast.BinOp(ast.Num(3), ast.Sub(), ast.Num(4))
    module = ast.Module([ast.Expr(add), ast.Expr(sub)])

    # Test insert_at
    result = copy.deepcopy(add)
    insert_at(0, get_parent(module, add), ast.Num(0))
    assert ast.dump(get_parent(module, add)) == ast.dump(result)
    assert ast.dump(module) == ast.dump(result)



# Generated at 2022-06-23 23:43:11.470390
# Unit test for function find
def test_find():
    import astor

    code = """
    def add(x: int, y: int):
        return x + y
    """

    tree = ast.parse(code)
    for node in find(tree, ast.FunctionDef):
        assert node.name == 'add'

    for node in find(tree, ast.Name):
        assert node.id in ('x', 'y', 'int')



# Generated at 2022-06-23 23:43:14.882982
# Unit test for function find
def test_find():
    """test function
    """
    code = compile('[42, 10 + 1]', 'test', 'exec')
    found = list(find(code, ast.Call))
    assert len(found) == 1
    assert found[0].func.value == 10

# Generated at 2022-06-23 23:43:20.035203
# Unit test for function get_parent

# Generated at 2022-06-23 23:43:20.771075
# Unit test for function insert_at
def test_insert_at():
    pass

# Generated at 2022-06-23 23:43:29.360949
# Unit test for function insert_at
def test_insert_at():
    t = ast.parse('a.b + c')
    insert_at(2, t.body[0].test, ast.parse('d').body[0])
    assert ast.dump(t) == 'Module(body=[Expr(value=BinOp(left=Attribute(value=Name(id=\'a\', ctx=Load()), attr=\'b\', ctx=Load()), op=Add(), right=BinOp(left=Name(id=\'c\', ctx=Load()), op=Add(), right=Name(id=\'d\', ctx=Load()))))])'

# Generated at 2022-06-23 23:43:35.616030
# Unit test for function insert_at
def test_insert_at():
    test_function_def = ast.FunctionDef(name = 'test_function', body = [],
                                        args = ast.arguments(args = []))
    test_return = ast.Return(value = ast.Name(id = 'test_value'))
    insert_at(0, test_function_def, test_return)
    assert test_function_def.body[0] == test_return
    test_return2 = ast.Return(value = ast.Str(s = 'test_value2'))
    insert_at(1, test_function_def, test_return2)
    assert test_function_def.body[1] == test_return2

if __name__ == '__main__':
    test_insert_at()

# Generated at 2022-06-23 23:43:40.853250
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = "def foo(x):\n  return x + 1"
    tree = ast.parse(source, mode="exec")
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert index == 0
    assert (isinstance(parent, ast.Module)) or (isinstance(parent, ast.FunctionDef))

# Generated at 2022-06-23 23:43:44.542938
# Unit test for function find
def test_find():
    exp = ast.Expression(value=ast.Num(n=1))
    tree = ast.Module(body=[ast.Expr(value=exp)])
    found = find(tree, ast.Expression)
    assert exp in found



# Generated at 2022-06-23 23:43:45.155844
# Unit test for function replace_at

# Generated at 2022-06-23 23:43:45.989743
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:43:47.686384
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    unittest.main(__file__, argv=[''], verbosity=2, exit=False)

# Generated at 2022-06-23 23:43:51.113344
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert (ast.parse('def a:\n    pass').body[0] ==
            get_closest_parent_of(ast.parse('def a:\n    pass'),
                                  ast.parse('def a:\n    pass').body[0].body[0],
                                  ast.FunctionDef))

# Generated at 2022-06-23 23:43:54.227459
# Unit test for function find
def test_find():
    tree = ast.parse('''
    func1()
    func2()
    ''')
    funcs = find(tree, ast.Expr)
    assert len(list(funcs)) == 2

# Generated at 2022-06-23 23:43:58.816825
# Unit test for function find
def test_find():
    tree = ast.parse("""if a:
        pass
    else:
        return 1""")
    assert list(find(tree, ast.If)) == [tree.body[0]]
    assert list(find(tree, ast.Return)) == [tree.body[1].body[0]]



# Generated at 2022-06-23 23:44:07.753584
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("def f(a):\n\tb = a \n\tc = b")
    parent, index = get_non_exp_parent_and_index(
        tree, tree.body[0].body[0].value)
    new_node = ast.Name("a")
    replace_at(index, parent, new_node)
    print(ast.dump(tree))

# Generated at 2022-06-23 23:44:11.104589
# Unit test for function get_parent
def test_get_parent():
    source = '''
        def fn(a):
            if a:
                return
    '''

    tree = ast.parse(source)
    function_def = get_parent(tree, list(find(tree, ast.Return))[0])

    assert isinstance(function_def, ast.FunctionDef)

# Generated at 2022-06-23 23:44:14.994373
# Unit test for function get_parent
def test_get_parent():
    parent = ast.parse('''
        a = b + c
    ''')
    node = parent.body[0].value
    assert get_parent(parent, node) == parent

# Generated at 2022-06-23 23:44:23.443917
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('[1, 2, 3][2]')
    assert _parents == {}

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].value.values[1].value)

    assert isinstance(parent, ast.List)
    assert isinstance(tree.body[0].value.values[1].value, ast.Num)
    assert index == 1
    assert _parents == {
        tree.body[0].value.values[1].value: tree.body[0].value,
        tree.body[0].value: tree,
    }



# Generated at 2022-06-23 23:44:33.451811
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test for function get_non_exp_parent_and_index"""

# Generated at 2022-06-23 23:44:41.673227
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    
    code = """
for i in range(5):
    print(i)
    if i == 3:
        print('three')
    """
    node = ast.parse(code)
    target_func = node.body[0].body[0].value
    parent, index = get_non_exp_parent_and_index(node, target_func)

    assert parent is node.body[0]
    assert index == 0
    assert astor.to_source(parent) == 'print(i)'
    assert astor.to_source(node) == code


# Generated at 2022-06-23 23:44:45.766933
# Unit test for function insert_at
def test_insert_at():
    """Create simple parent and insert some nodes at the beginning."""
    parent = ast.Module()
    nodes = ast.Num(n=0)
    assert parent.body == []

    insert_at(0, parent, nodes)

    assert parent.body == [nodes]



# Generated at 2022-06-23 23:44:54.815425
# Unit test for function replace_at
def test_replace_at():
    # Python 3.7
    import ast
    import sys

    class CallVisitor(ast.NodeVisitor):
        def visit_Call(self, node):
            self.get_Call_node = node
            self.found_Call = True

    tree = ast.parse('call()')
    visitor = CallVisitor()
    visitor.visit(tree)

    # test node replacement with same type of node
    call_node = visitor.get_Call_node
    end_marker_node = ast.Expr(ast.Str(s="END"))
    parent = get_parent(tree, call_node)
    replace_at(1, parent, end_marker_node)
    assert(str(tree) == 'call();str("END")')

    # test node replacement with a list of nodes

# Generated at 2022-06-23 23:45:03.459384
# Unit test for function insert_at
def test_insert_at():
    class Parent():
        body = []
        def insert(self, index, child):
            Parent.body.insert(index, child)

    parent = Parent()
    insert_at(0, parent, [1,2,3])
    assert(Parent.body == [1,2,3])
    insert_at(1, parent, [1,2,3])
    assert(Parent.body == [1,1,2,3,2,3])
    insert_at(0, parent, [1,2,3])
    assert(Parent.body == [1,1,2,3,2,3,1,2,3])


# Generated at 2022-06-23 23:45:06.721048
# Unit test for function find
def test_find():
    """Test function find"""
    tree = ast.parse("""
        for _ in range(0):
            pass
    """)
    for_ = next(find(tree, ast.For))
    assert for_ is not None



# Generated at 2022-06-23 23:45:17.908634
# Unit test for function get_parent
def test_get_parent():
    """
    Test for get_parent
    """
    import astor

    source = "a + b * c"

    node = astor.to_ast(source)
    _build_parents(node)

    assert get_parent(node, node, rebuild=True) == node

    assert isinstance(get_parent(node, node.body[0], rebuild=True), ast.Module)

    assert isinstance(get_parent(node, node.body[0].value.left, rebuild=True),
                      ast.BinOp)

    assert isinstance(get_parent(node, node.body[0].value.left.n, rebuild=True),
                      ast.Name)


# Generated at 2022-06-23 23:45:26.951343
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code_string = '''
    import sys
    a=sys.argv'''
    tree = ast.parse(code_string)
    imp = find(tree, ast.Import).__next__()
    imp_parent, imp_index = get_non_exp_parent_and_index(tree, imp)
    print(imp_parent, imp_index)

    def_a = find(tree, ast.Assign).__next__()
    def_a_parent, def_a_index = get_non_exp_parent_and_index(tree, def_a)
    print(def_a_parent, def_a_index)


# unit test for function get_parent

# Generated at 2022-06-23 23:45:34.157903
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Function without return type
    function_def_node = ast.parse('def foo(): pass', mode='exec').body[0]
    parent, index = get_non_exp_parent_and_index(function_def_node,
                                                 function_def_node.body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    # Function with return type
    function_def_node = ast.parse('def foo() -> str: pass', mode='exec').body[0]
    parent, index = get_non_exp_parent_and_index(function_def_node,
                                                 function_def_node.body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    # Class

# Generated at 2022-06-23 23:45:45.107770
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    # Test nothing found
    tree = ast.parse('fun()')
    node = tree.body[0].value
    assert get_closest_parent_of(tree, node, ast.arguments) == None

    # Test nothing found with type mismatch
    tree = ast.parse('a = fun()')
    node = tree.body[0].value
    assert get_closest_parent_of(tree, node, ast.arguments) == None

    # Test found
    tree = ast.parse('a = fun()')
    node = tree.body[0].value
    assert get_closest_parent_of(tree, node, ast.Assign) == tree.body[0]

    # Test more complex
    tree = ast.parse('a = fun(); b = fun(); c = fun()')

# Generated at 2022-06-23 23:45:51.171317
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3 as ast
    import astor
    from .ast_helpers import insert_at


    parent = ast.parse('''
    def foo():
        x = 1
        y = 2
        z = 3
        return z
    ''')

    insert_at(2, parent.body[0], [ast.parse('x = 4').body[0]])
    print(astor.to_source(parent))


# Generated at 2022-06-23 23:45:57.018953
# Unit test for function insert_at
def test_insert_at():
    # Using While as an example
    while_node = ast.While(
        test=ast.Name(id='True', ctx=ast.Load()),
        body=[
            ast.Pass(),
        ],
        orelse=[])
    insert_at(0, while_node, ast.Name(id='True', ctx=ast.Load()))
    assert len(while_node.body) == 2


# Generated at 2022-06-23 23:46:07.935201
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Class_:
        def __init__(self, name, parent):
            self.name = name
            self.parent = parent

    parent = Class_('parent', None)
    level1 = Class_('level1', parent)
    level2 = Class_('level2', level1)
    level3 = Class_('level3', level2)
    class_ = Class_(None, level3)

    print('test_get_closest_parent_of')
    print(get_closest_parent_of(parent, level1, Class_))
    print(get_closest_parent_of(parent, level2, Class_))
    print(get_closest_parent_of(parent, level3, Class_))

# Generated at 2022-06-23 23:46:10.162068
# Unit test for function insert_at
def test_insert_at():
    class DummyExp:
        def __init__(self, body):
            self.body = body
    dl = DummyExp(list())
    insert_at(0, dl, 1)
    assert dl.body == [1]



# Generated at 2022-06-23 23:46:10.799711
# Unit test for function find
def test_find():
    pass



# Generated at 2022-06-23 23:46:17.277363
# Unit test for function replace_at
def test_replace_at():
    import ast
    import astor
    parent = ast.Module(body=[ast.If(test=ast.Name(id='a', ctx=ast.Load()), body=[
        ast.Pass(), ast.Pass(), ast.Pass()], orelse=[])])
    node = ast.If()
    nodes = ast.If(test=ast.Name(id='b', ctx=ast.Load()))
    replace_at(0, parent, nodes)
    print(astor.to_source(parent))

if __name__ == "__main__":
    test_replace_at()

# Generated at 2022-06-23 23:46:20.039523
# Unit test for function find
def test_find():
    node = ast.parse('class A:\n    def a(self):\n        a=3')
    assert find(node, ast.Assign)


# Generated at 2022-06-23 23:46:26.852370
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Should find the first parent
    assert get_non_exp_parent_and_index(ast.parse('for x in range(5): x=5'),
                                        ast.parse('x=5').body[0]) == \
           (ast.parse('for x in range(5): x=5'), 0)
    # Should find the second parent
    assert get_non_exp_parent_and_index(ast.parse('for x in range(5): x=5'),
                                        ast.parse('range(5)')) == \
           (ast.parse('for x in range(5): x=5').body[0], 1)

# Generated at 2022-06-23 23:46:29.223279
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('x = [1, 2, 3]')
    list_node = tree.body[0].value
    assert get_parent(tree, list_node) == tree.body[0]



# Generated at 2022-06-23 23:46:39.652844
# Unit test for function insert_at
def test_insert_at():
    item = ast.FunctionDef(
        name='my_func',
        args=ast.arguments(args=[], defaults=[], vararg=None, kwonlyargs=[],
                           kw_defaults=[], kwarg=None,
                           posonlyargs=[]),  # type: ignore
        body=[ast.Expr(value=ast.Call(func=ast.Name(id='print'), args=[],
                                      keywords=[]))],
        decorator_list=[], returns=None)

    insert_at(0, item, ast.Expr(value=ast.Call(func=ast.Name(id='print'),
                                               args=[], keywords=[])))
    assert len(item.body) == 2
    assert isinstance(item.body[0], ast.Expr)  # type: ignore

# Generated at 2022-06-23 23:46:41.022575
# Unit test for function find
def test_find():
    assert isinstance(find(ast.parse('1'), ast.Num), Iterable)

# Generated at 2022-06-23 23:46:47.753663
# Unit test for function replace_at
def test_replace_at():
    """Test for function test_replace_at."""
    tree = ast.parse('a = (1 + 2) - 3;')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].value)
    replace_at(index, parent, tree.body[0].value)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'a\', '\
        'ctx=Store())], value=BinOp(left=BinOp(left=Num(n=1), op=Add(), '\
        'right=Num(n=2)), op=Sub(), right=Num(n=3)))])'

# Generated at 2022-06-23 23:46:53.592067
# Unit test for function replace_at
def test_replace_at():
    ast_tree = ast.parse('a = 1')
    parent, index = get_non_exp_parent_and_index(ast_tree, ast_tree.body[0])
    replace_at(index, parent, ast.parse('b = 1'))
    assert ast_tree.body[0].targets[0].id == 'b'



# Generated at 2022-06-23 23:46:59.349652
# Unit test for function replace_at
def test_replace_at():
    import astor
    from .parser import parse_string

    code = '''
    def f(x):
        return x
    '''

    tree = parse_string('def f(x):\n\treturn x')
    func = tree.body[0]
    index = 0
    parent = func.body

    stmt = ast.parse('a = 1').body[0]

    replace_at(index, parent, stmt)
    print(astor.to_source(tree))

    assert astor.to_source(tree) == 'def f(x):\n    a = 1\n    return x\n'

# Generated at 2022-06-23 23:47:00.134213
# Unit test for function find

# Generated at 2022-06-23 23:47:02.409045
# Unit test for function insert_at
def test_insert_at():
    parent = ast.Module([])
    node = ast.FunctionDef(name='test', body=[ast.Pass()])

    insert_at(0, parent, node)
    assert parent.body[0] == node


# Generated at 2022-06-23 23:47:12.085794
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('''
        def a():
            print(1)
            print(2)
            print(3)

        def b():
            pass
    ''')

    call = find(tree, ast.Call).__next__()
    parent, index = get_non_exp_parent_and_index(tree, call)
    replace_at(index, parent, ast.parse('print(4)'))

    result = ast.dump(tree)
    expected = ast.dump('''
            def a():
                print(4)
                print(2)
                print(3)

            def b():
                pass
        ''')

    assert result == expected

# Generated at 2022-06-23 23:47:17.859515
# Unit test for function get_parent
def test_get_parent():
    test_tree: ast.Module = ast.parse(r'''
        def foo():
            def bar():
                pass
            pass
        ''')
    _build_parents(test_tree)
    bar_node = test_tree.body[0].body[0]
    foo_node = test_tree.body[0]
    assert get_parent(test_tree, bar_node) == foo_node



# Generated at 2022-06-23 23:47:25.672900
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""if a == b:
    c = a + b
    d = a - b""")

    b = tree.body[0].test.ops[0]
    c = tree.body[0].body[0]
    d = tree.body[0].body[1]

    assert get_parent(tree, b) == tree.body[0].test
    assert get_parent(tree, c) == tree.body[0].body
    assert get_parent(tree, d) == tree.body[0].body


# Generated at 2022-06-23 23:47:29.838274
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("def func():\n    pass\nprint(0)")
    _build_parents(tree)
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree

# Generated at 2022-06-23 23:47:34.689133
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test function get_non_exp_parent_and_index."""
    exp_for = ast.parse(
        """
        def A():
            pass
        
        def B():
            pass
        """
    ).body[1].body[0]

    non_exp_parent, index = get_non_exp_parent_and_index(exp_for, exp_for.body[0])

    assert isinstance(non_exp_parent, ast.FunctionDef)
    assert index == 0


# Generated at 2022-06-23 23:47:36.123860
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:47:44.141431
# Unit test for function insert_at
def test_insert_at():
    import astunparse
    code = "a = 5"
    tree = ast.parse(code)
    stmt_node = tree.body[0]
    test_node = ast.copy_location(ast.Assign(
        targets=[ast.Name(id="b", ctx=ast.Store())],
        value=ast.Num(n=5)
    ), stmt_node)
    insert_at(0, tree, test_node)
    result = astunparse.unparse(tree)
    assert result == "b = 5\na = 5"


# Generated at 2022-06-23 23:47:45.135887
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    func_name = 'test'

    # A function that calls another function

# Generated at 2022-06-23 23:47:48.737535
# Unit test for function find
def test_find():
    def fun(a) -> int:
        pass

    tree = ast.parse(fun.__annotations__['return'])
    assert(isinstance(next(find(tree, ast.AnnAssign)), ast.AnnAssign))



# Generated at 2022-06-23 23:47:56.416660
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse(
        '\n'
        'def foo():'
        '    pass'
    )

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    insert_at(index, parent, [ast.parse('pass').body[0]])

    assert ast.dump(tree) == ast.dump(ast.parse(
        '\n'
        'def foo():'
        '    pass\n'
        '    pass'
    ))

    tree = ast.parse(
        '\n'
        'def foo():'
        '    bar()'
    )

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

# Generated at 2022-06-23 23:48:02.282210
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
        for a in range(3):
            b = 0
            b = 1
            b = 2
    ''')

    target = tree.body[0].body[1].body[0]

    parent, index = get_non_exp_parent_and_index(tree, target)

    assert parent.body[index] is target

# Generated at 2022-06-23 23:48:11.640853
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import unittest
    import unittest.mock
    from typed_ast import ast3 as ast

    class TestCase(unittest.TestCase):
        def setUp(self):
            reload(ast)
            self.tree = ast.parse('1\nx\n3')

        def test_function_parent(self):
            node = self.tree.body[2]
            non_exp_parent, index = get_non_exp_parent_and_index(self.tree,
                                                                 node)
            self.assertEqual(non_exp_parent, self.tree)
            self.assertEqual(index, 2)

        def test_module_parent(self):
            node = self.tree.body[0]
            non_exp_parent, index = get_non_exp_parent_and_

# Generated at 2022-06-23 23:48:12.711667
# Unit test for function get_parent

# Generated at 2022-06-23 23:48:23.535078
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .our_ast import Module
    from .our_ast import normalize_ast
    from .our_ast import NodeTransformer
    from .our_ast import Visitor
    from .our_ast import Context
    from .our_ast import ParseContext
    from .our_ast import Name
    from .our_ast import NameTransformer
    from .our_ast import Str
    from .our_ast import Num
    from .our_ast import Load
    from .our_ast import Store
    from .our_ast import LoadTransformer
    from .our_ast import List
    from .our_ast import ListTransformer

    def _get_closest_parent_of(tree, node, type_):
        nonlocal get_closest_parent_of

# Generated at 2022-06-23 23:48:30.848341
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import copy
    import sys
    import unittest
    import astor.codegen

    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    from ..minifier import minify
    from ..optimizer import optimize
    from ..remover import remove_statements
    from ..transformer import transform

    # Original code to minify
    original_code = '''
    foo = False

    if foo:
        print('foo was true')
    elif True:
        print('foo was false')
    else:
        pass

    if True:
        pass
    else:
        pass
    '''

    # Expected code

# Generated at 2022-06-23 23:48:36.668256
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast.ast3 import parse as ast_parse
    from ..exceptions import NodeNotFound
    from astunparse import unparse

# Generated at 2022-06-23 23:48:37.178189
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:48:37.717012
# Unit test for function find

# Generated at 2022-06-23 23:48:48.264657
# Unit test for function insert_at
def test_insert_at():
    """Unit test for function insert_at."""
    node = ast.parse('def func(): return 1')

    insert_at(0, node.body[0], ast.parse('return 2'))
    insert_at(1, node.body[0], [ast.parse('return 3'), ast.parse('return 4')])

    assert ast.dump(node) == \
        'Module(body=[FunctionDef(name=\'func\', args=arguments(args=[], '\
        'vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), '\
        'body=[Return(value=Constant(value=2)), '\
        'Return(value=Constant(value=3)), '\
        'Return(value=Constant(value=4)), '\
       

# Generated at 2022-06-23 23:48:57.767899
# Unit test for function replace_at
def test_replace_at():
    import astunparse
    import re

    # pylint: disable=C0103, E1103
    def test_func(a, b, c):  # type: (int, int, int) -> None
        x = a + b
        y = b * c
        w = x + y
        return w  # type: ignore

    node = ast.parse(test_func.__doc__)
    node = ast.fix_missing_locations(node)
    node = ast.Module(body=[node])

    func_def = node.body[0].body[0]
    assert len(func_def.body) == 3

    index = 1
    parent = get_non_exp_parent_and_index(node, func_def.body[index])[0]

# Generated at 2022-06-23 23:49:03.535268
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.FunctionDef(name='some_function',
                           args=ast.arguments(args=[], vararg=None,
                                              kwonlyargs=[],
                                              kw_defaults=[],
                                              kwarg=None,
                                              defaults=[]),
                           body=[ast.Pass()],
                           decorator_list=[],
                           returns=None)

    body_index = 0

    parent, index = get_non_exp_parent_and_index(node, node.body[body_index])

    assert parent is node
    assert index == body_index

# Generated at 2022-06-23 23:49:13.378382
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast
    import sys
    import pickle
    from io import BytesIO
    from ast_compare.equiv import compare_trees

    tree = ast.parse('a=1\nif a==1:\n    a=2')
    tree.body[1].body[0].value.n = 4
    # Assert that the the function returned the correct parent
    # and index of the node
    assert get_non_exp_parent_and_index(tree, tree.body[1].body[0]) == (
        tree.body[1], 0)
    # Assert that the node is the same as what is returned
    # by making a copy of the parent block, picking the value and
    # comparing the trees
    # Create a new tree

# Generated at 2022-06-23 23:49:15.701219
# Unit test for function find
def test_find():
    sample = ast.parse('a = 1')
    list(find(sample, ast.Name))
    list(find(sample, ast.Assign))
    list(find(sample, ast.Num))



# Generated at 2022-06-23 23:49:24.115203
# Unit test for function find
def test_find():
    code = """
    def func():
        if i == 3:
            return i

    """
    tree = ast.parse(code)
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Compare))) == 1
    assert len(list(find(tree, ast.Return))) == 1

# Generated at 2022-06-23 23:49:30.857839
# Unit test for function get_parent
def test_get_parent():
    def func():
        a = 1 + 2


    tree = ast.parse(inspect.getsource(func))
    _build_parents(tree)
    parent = get_parent(tree, tree.body[0].body[0].value)
    assert isinstance(parent, ast.Assign)

# Generated at 2022-06-23 23:49:40.211269
# Unit test for function insert_at
def test_insert_at():
    t = ast.parse("if a:\n    print('a')\n    print(1)")

    assert (t.body[0].body[0].value.s == "a")
    assert (t.body[0].body[1].value.n == 1)

    insert_at(0, t.body[0], ast.Expr(ast.Str("a1")))

    assert (t.body[0].body[0].value.s == "a1")
    assert (t.body[0].body[1].value.s == "a")
    assert (t.body[0].body[2].value.n == 1)

# Generated at 2022-06-23 23:49:50.125293
# Unit test for function replace_at
def test_replace_at():
    tree1 = ast.parse('''
    if a:
        print(a)
    else:
        print(b)
    ''')
    tree2 = ast.parse('''
    if a:
        print(a)
    ''')

    parent, index = get_non_exp_parent_and_index(tree1, tree1.body[0])

    assert parent.body[index] is tree1.body[0]
    assert index == 0

    replace_at(index, parent, tree2.body[0])

    assert parent.body[index] is tree2.body[0]

# Generated at 2022-06-23 23:49:57.553182
# Unit test for function insert_at
def test_insert_at():
    from .example_trees import EXAMPLE_TREE, EXAMPLE_FUNC
    tree = EXAMPLE_TREE

    func = get_closest_parent_of(tree, node=EXAMPLE_FUNC,
                                 type_=ast.FunctionDef)
    assert func.body[0].body[0].value.args[0].id == 'a'
    insert_at(0, func.body[0].body[0].value.args, ast.arg(arg='b'))
    assert func.body[0].body[0].value.args[0].id == 'b'



# Generated at 2022-06-23 23:50:02.665731
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert_equals = ast.parse('assert_equals')
    mod = ast.Module([ast.Expr(assert_equals)])
    expected = (mod.body[0], 0)
    actual = get_non_exp_parent_and_index(mod, assert_equals)
    assert expected == actual

# Generated at 2022-06-23 23:50:04.494046
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert ast.parse('a[1]').body[0].value.slice.value.n == 1

# Generated at 2022-06-23 23:50:05.594323
# Unit test for function replace_at

# Generated at 2022-06-23 23:50:08.554909
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('if True:\n    pass')
    ifclause = tree.body[0]
    assert isinstance(get_closest_parent_of(tree, ifclause.body[0], ast.If), ast.If)

# Generated at 2022-06-23 23:50:14.402626
# Unit test for function insert_at
def test_insert_at():
    parent = ast.Module([])
    child1 = ast.Pass()
    child2 = ast.Pass()
    child3 = ast.Pass()
    insert_at(0, parent, child1)
    insert_at(0, parent, child2)
    insert_at(0, parent, child3)
    assert len(parent.body) == 3
    assert parent.body[0] == child3
    assert parent.body[1] == child2
    assert parent.body[2] == child1


# Generated at 2022-06-23 23:50:19.846157
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = """if True:
        if False:
            print(1)
        1 + 2"""
    tree = ast.parse(source)
    node = find(tree, ast.Num).__next__()
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert type(parent) == ast.If
    assert index == 2

# Generated at 2022-06-23 23:50:20.881219
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest


# Generated at 2022-06-23 23:50:22.729553
# Unit test for function find
def test_find():
    source = textwrap.dedent("""
    def foo():
        pass
        pass
        pass
    """)
    tree = ast.parse(source)
    n_pass = 2

    assert n_pass == len(list(find(tree, ast.Pass)))



# Generated at 2022-06-23 23:50:27.450244
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    mod = ast.parse('')
    funcdef = ast.FunctionDef()
    mod.body.append(funcdef)
    name = ast.Name(id='test', ctx=ast.Load())
    funcdef.body.append(name)
    assert get_closest_parent_of(mod, name, ast.FunctionDef) == funcdef



# Generated at 2022-06-23 23:50:32.131903
# Unit test for function replace_at

# Generated at 2022-06-23 23:50:39.315952
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """
        a = [1, 2]

        def f():
            return 0

        def g():
            return 1
    """
    tree = ast.parse(code)

    return_node = find(tree, ast.Return).next()
    function_node = get_closest_parent_of(tree, return_node, ast.FunctionDef)
    assert isinstance(function_node, ast.FunctionDef)


# Generated at 2022-06-23 23:50:42.537708
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    filename = '../examples/example.py'
    position = 7, 6

    tree = ast3.parse(open(filename).read())
    node = find_node_by_position(tree, position)

    parent, index = get_non_exp_parent_and_index(tree, node)

    assert parent is tree.body[0]
    assert index == 0

# Generated at 2022-06-23 23:50:50.772455
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Function definition
    func = ast.FunctionDef()
    stmt = ast.Expr()
    func.body = [stmt]
    # Function call
    f_call = ast.Call()
    stmt.value = f_call
    # Dummy arguments
    args = [ast.Name(), ast.Name()]
    f_call.args = args
    # Keyword arguments
    kwargs = [ast.keyword(), ast.keyword()]
    f_call.keywords = kwargs
    # Test get_closest_parent_of
    assert get_closest_parent_of(func, args[1], ast.Call) == f_call
    assert get_closest_parent_of(func, kwargs[1], ast.Call) == f_call

# Generated at 2022-06-23 23:50:53.060383
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('print("hello")')
    node = find(tree, ast.Str).__next__()
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-23 23:50:58.877472
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('a + b')
    node = tree.body[0].value.ops[0]

    assert get_closest_parent_of(tree, node, ast.BinOp) == node

    node = tree.body[0].value
    parent_node = tree.body[0].value.right
    assert get_closest_parent_of(tree, node, ast.BinOp) == parent_node

# Generated at 2022-06-23 23:51:03.348069
# Unit test for function get_parent
def test_get_parent():
    input = '''if True:\n    print("a")'''
    node = ast.parse(input)
    if_stmt = node.body[0]  # type: ignore

    assert get_parent(node, if_stmt) is node, \
        'Parent for if statement is not correct.'



# Generated at 2022-06-23 23:51:07.954723
# Unit test for function replace_at
def test_replace_at():
    class A:
        def __init__(self):
            self.body = [1, 2, 3]

    a = A()
    replace_at(1, a, [4, 5, 6])
    assert a.body == [1, 4, 5, 6, 3]


# Generated at 2022-06-23 23:51:12.089809
# Unit test for function get_parent
def test_get_parent():
    a = ast.parse("1 + 1")
    b = a.body[0].value

# Generated at 2022-06-23 23:51:21.110133
# Unit test for function find
def test_find():
    class Module(ast.AST):
        body = []
    class FunctionDef(ast.AST):
        pass
    class Name(ast.AST):
        name = ""
    class Assign(ast.AST):
        pass
    class Pass(ast.AST):
        pass
    class NameConstant(ast.AST):
        pass
    class Arg(ast.AST):
        pass
    class Call(ast.AST):
        pass
    class Param(ast.AST):
        pass
    class Attribute(ast.AST):
        pass


# Generated at 2022-06-23 23:51:28.867966
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('x = 3')
    replace_at(0, tree, ast.parse('print(3)'))
    assert ast.dump(tree) == "Module(body=[Print(dest=None, values=[Num(n=3)], nl=True), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=3))])"



# Generated at 2022-06-23 23:51:30.965087
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = "for i in range(0, 10):"
    mod = ast.parse(code)

    for_stmt = mod.body[0]
    parent, index = get_non_exp_parent_and_index(mod, for_stmt)

    assert parent is mod
    assert index == 0

# Generated at 2022-06-23 23:51:34.040585
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(ast.parse("a = 1\nb = 10"), ast.Name()) == (
        ast.parse("a = 1\nb = 10"), 0)
    assert get_non_exp_parent_and_index(
        ast.parse("a = 1\nb = 10"), ast.Name(id=1, ctx=ast.Store())) == (
            ast.parse("a = 1\nb = 10"), 0)



# Generated at 2022-06-23 23:51:35.701103
# Unit test for function get_parent
def test_get_parent():
    """
    Test get_parent function.
    """

# Generated at 2022-06-23 23:51:40.056548
# Unit test for function replace_at
def test_replace_at():
    root = ast.parse('a = 1 + 2 * 3')
    replace_at(1, root.body, ast.parse('a = 0').body[0])
    assert ast.dump(root) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=0))])"

# Generated at 2022-06-23 23:51:45.063846
# Unit test for function find

# Generated at 2022-06-23 23:51:45.954344
# Unit test for function replace_at
def test_replace_at():
    pass  # see tests/test_builder.py

# Generated at 2022-06-23 23:51:50.920771
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('if True:\n    pass')
    _build_parents(tree)
    if_node = tree.body[0]
    parent = _parents[tree.body[0].body[0]]
    assert if_node == parent

# Generated at 2022-06-23 23:51:51.441946
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-23 23:52:02.773448
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def func_to_test(arg: int):
        pass

    tree = ast.parse(func_to_test.__code__)
    str_name = get_closest_parent_of(tree, tree.body[0], ast.Str)
    assert str_name.s == func_to_test.__code__.co_name

    # This function puts all nodes in tree from bottom to top.
    # Order of nodes:
    # arg_name (Name)
    # arg_annotation (AnnAssign)
    # arg_type (Name)
    # parameters (arguments)
    # function (FunctionDef)
    # tree
    #
    # get_closest_parent_of(tree, tree.body[0], ast.arguments)
    # It should return tree.body[0].args
   

# Generated at 2022-06-23 23:52:03.453525
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:52:10.639144
# Unit test for function replace_at
def test_replace_at():
    class A(ast.AST):
        pass
    class B(ast.AST):
        pass
    class C(ast.AST):
        pass
    class D(ast.AST):
        pass
    class E(ast.AST):
        pass
    class F(ast.AST):
        pass
    class G(ast.AST):
        pass
    class H(ast.AST):
        pass

    a = A(body=[B(body=[C(), D(), E()]), F(body=[G()]), H(body=[])])
    replace_at(0, a, [B(body=[C()]), B(body=[D(), E()])])

    assert len(a.body) == 3
    assert isinstance(a.body[0], B)
    assert len(a.body[0].body) == 1

# Generated at 2022-06-23 23:52:15.371422
# Unit test for function find
def test_find():
    node = ast.parse('''
for i in range(1, 2):
    continue
    ''')
    for_stmt = find(node, ast.For).__next__()
    assert for_stmt.__class__.__name__ == 'For'


# Generated at 2022-06-23 23:52:19.590184
# Unit test for function insert_at
def test_insert_at():
    exec('a = 1\nb = 2')
    assert find(ast.parse('a = 1\nb = 2'), ast.Name)
    print('test_insert_at success')


if __name__ == '__main__':
    test_insert_at()

# Generated at 2022-06-23 23:52:26.775194
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('x = 1\n'
                     'y = x\n'
                     'z = 2')
    parent = get_closest_parent_of(tree, tree.body[1], ast.Module)
    replace_at(1, parent, tree.body[0])

    assert ast.dump(tree) == ast.dump(ast.parse('x = 1\n'
                                                'x = 1\n'
                                                'z = 2'))

# Generated at 2022-06-23 23:52:32.682341
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("""a = 0
a = 1
a = 2
""")
    body = tree.body
    replace_at(2, tree, ast.parse("a = 3\na = 4"))
    assert len(body) == 5, len(body)
    assert body[2].value.n == 3
    assert body[3].value.n == 4



# Generated at 2022-06-23 23:52:33.256846
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:52:36.731372
# Unit test for function insert_at
def test_insert_at():
    import astor
    root = ast.parse("""pass""")
    parent = root.body[0]
    insert_at(0, parent, ast.Num(1))
    assert astor.to_source(root) == "1\n"


# Generated at 2022-06-23 23:52:39.024810
# Unit test for function insert_at
def test_insert_at():
    from .util import to_ast
    from .presentation import ast_to_dot, dot_to_svg

# Generated at 2022-06-23 23:52:39.877910
# Unit test for function find
def test_find():
    """Unit test for function find"""
    import astor


# Generated at 2022-06-23 23:52:47.008573
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Build test AST
    tree = ast.parse(b'''
    def foo(arg1, arg2):
        stmt1
        stmt2
    ''')
    nodes = ast.walk(tree)
    stmt2_node = next(nodes)  # stmt2
    parent_node, index = get_non_exp_parent_and_index(tree, stmt2_node)
    assert isinstance(parent_node, ast.FunctionDef)
    assert isinstance(index, int)
    assert index == 2