

# Generated at 2022-06-23 23:42:54.841799
# Unit test for function get_parent

# Generated at 2022-06-23 23:43:01.605217
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test simple case of get_non_exp_parent_and_index."""
    code = \
    """
    def my_function():
        foo(a=1)
        foo(b=2)
        foo(c=3)
    """
    tree = ast.parse(code)
    foo_call = find(tree, ast.Call).__next__()
    parent, index = get_non_exp_parent_and_index(tree, foo_call)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1



# Generated at 2022-06-23 23:43:02.355991
# Unit test for function insert_at

# Generated at 2022-06-23 23:43:07.451560
# Unit test for function replace_at
def test_replace_at():
    code = """
    def foo():
        a = 1
    """

    tree = ast.parse(code)
    foo = tree.body[0]
    a = foo.body[0]

    replacement = ast.stmt(value=ast.Pass())
    replace_at(0, foo, replacement)

    assert a not in foo.body
    assert replacement in foo.body



# Generated at 2022-06-23 23:43:18.465038
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.Call(
        func=ast.Attribute(
            value=ast.Call(
                func=ast.Name(id='SomeBakingFunctions', ctx=ast.Load()),
                args=[],
                keywords=[]),
            attr='do_something',
            ctx=ast.Load()
        ),
        args=[],
        keywords=[]
    )

    # Test for node first level in tree
    parent, index = get_non_exp_parent_and_index(tree, tree)
    assert index == 0
    assert parent == tree

    # Test for node not in tree
    with pytest.raises(NodeNotFound):
        get_non_exp_parent_and_index(tree, ast.Name(id='g', ctx=ast.Load()))

    # Test for node who have Exp

# Generated at 2022-06-23 23:43:29.549559
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(textwrap.dedent('''
    x = 1
    if x == 1:
        y = 2
        if x == 2:
            def fun():
                pass
    '''))

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent == tree
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[1])
    assert parent.body[0] == tree.body[1]
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[1].body[0])
    assert parent == tree.body[1]
    assert index == 0

    parent, index = get_non_exp_parent_

# Generated at 2022-06-23 23:43:40.949145
# Unit test for function insert_at
def test_insert_at():
    root = ast.Module([])
    fun = ast.FunctionDef(
        name='fun',
        args=ast.arguments([], [], None, []),
        body=[],
        decorator_list=[],
        returns=None,
    )
    root.body.append(fun)

    insert_at(0, root, ast.Expr(value=ast.Str('a')))
    insert_at(1, root, ast.Expr(value=ast.Str('b')))

    assert isinstance(root.body[0], ast.Expr)
    assert root.body[0].value.s == 'a'
    assert isinstance(root.body[1], ast.FunctionDef)
    assert root.body[1].name == 'fun'

# Generated at 2022-06-23 23:43:45.450061
# Unit test for function insert_at
def test_insert_at():
    from ..grammar.attitude import PythonGrammar

    tree = PythonGrammar.from_string('x = 1', 0, 0).parse()
    insert_at(0, tree, ast.Name('a'))
    assert str(tree.body[0]) == 'a'



# Generated at 2022-06-23 23:43:49.897117
# Unit test for function insert_at
def test_insert_at():
    # Given
    ast_tree = ast.parse('def do_nothing():\n    pass')
    parent = ast_tree
    child = ast.parse('print("hello")')

    # When
    insert_at(0, parent, child)

    # Then
    assert(str(ast_tree) == 'def do_nothing():\n    print("hello")')



# Generated at 2022-06-23 23:44:00.756479
# Unit test for function replace_at
def test_replace_at():
    target_index = 2

    # We will test this function with a fake node.
    class FakeParentNode(ast.AST):
        _fields = ('body',)

        def __init__(self):
            self.body = []

        def __repr__(self, indent: int = 0):
            return '{0}(\n{1}{2},\n{1})'.format(
                type(self).__name__, ' ' * indent,
                ',\n'.join([repr(c) for c in self.body]))

    parent_node = FakeParentNode()
    for i in range(5):
        parent_node.body.append(i)

    # First we test replacing one node.
    replace_at(target_index, parent_node, 'replacement')

# Generated at 2022-06-23 23:44:09.006408
# Unit test for function get_parent
def test_get_parent():
    import astor
    tree = ast.parse("""
    a = 1
    b = 2
    """)

    _build_parents(tree)

    assert astor.to_source(get_parent(tree, tree.body[0])) == 'Module(body=[Assign(targets=[Name(id=a, ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=b, ctx=Store())], value=Num(n=2))])'
    assert astor.to_source(get_parent(tree, tree.body[0].value)) == 'Assign(targets=[Name(id=a, ctx=Store())], value=Num(n=1))'

# Generated at 2022-06-23 23:44:14.691340
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    file = "for i in range(10):\n    print(i)\nprint(i)"
    tree = ast.parse(file)
    i = tree.body[0].body[0].value.args[0]
    closest_parent = get_closest_parent_of(tree, i, ast.For)
    assert(isinstance(closest_parent, ast.For))

# Generated at 2022-06-23 23:44:19.279937
# Unit test for function replace_at
def test_replace_at():
    class CE(ast.expr):
        x = 4
    
    class CS(ast.stmt):
        x = 4

    class A(ast.AST):
        body = [CS]
    
    replace_at(0, A(),CE())
    replace_at(0, A(), [CE(), CS()])

# Generated at 2022-06-23 23:44:27.178818
# Unit test for function find
def test_find():
    import unittest
    from ..parser import parse

    class DummyTestCase(unittest.TestCase):
        def test_find(self):
            tree = parse('''
            def func(arg: bool = True) -> int:
                if arg:
                    return 3
                else:
                    return 5
            ''')
            self.assertTrue(isinstance(find(tree, ast.Return).__next__(),
                                       ast.Return))

    unittest.main(module=__name__, exit=False)

# Generated at 2022-06-23 23:44:35.564417
# Unit test for function get_parent
def test_get_parent():
    class Foo:
        pass

    tree = ast.Module([
        ast.FunctionDef('foo', ast.arguments([ast.arg('bar', None)], None,
                                             None, []),
                        [ast.Return(ast.Num(1))], [], None)
    ])

    def_ = tree.body[0]
    func_args = def_.args
    arg = func_args.args[0]
    ret = def_.body[0]
    num = ret.value

    assert id(get_parent(tree, def_)) == id(tree)
    assert id(get_parent(tree, func_args)) == id(def_)
    assert id(get_parent(tree, arg)) == id(func_args)
    assert id(get_parent(tree, ret)) == id(def_.body) 

# Generated at 2022-06-23 23:44:47.128450
# Unit test for function replace_at
def test_replace_at():
    class Dummy:
        def __init__(self):
            self.a = 5
            self.b = 10
            self.c = 15
            self.d = 20
            self.e = 25
            self.f = 30

        def get_body(self):
            return [self.a, self.b, self.c, self.d, self.e, self.f]

        def get_body_as_ast(self):
            return ast.parse(str(self.get_body())).body  # type: ignore

    dummy = Dummy()
    replace_at(2, dummy, [30, 35])
    assert dummy.get_body() == [5, 10, 30, 35, 20, 25, 30]

    replace_at(3, dummy, [40, 45, 50, 55])

# Generated at 2022-06-23 23:44:47.710029
# Unit test for function get_parent

# Generated at 2022-06-23 23:44:49.461769
# Unit test for function get_parent
def test_get_parent():
    test_node = ast.Name("test")
    test_tree = ast.Module(body=[test_node])

    assert test_node in _parents
    assert get_parent(test_tree, test_node) == test_tree


# Generated at 2022-06-23 23:44:51.962895
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = 'a += 5'

    tree = ast.parse(code)
    expr = tree.body[0]

    parent, index = get_non_exp_parent_and_index(tree, expr)

    assert isinstance(parent, ast.Module)
    assert index == 0



# Generated at 2022-06-23 23:45:01.379488
# Unit test for function insert_at
def test_insert_at():
    test = ast.parse("""
    def func():
        pass
    """)
    parent, index = get_non_exp_parent_and_index(test, 0)
    new_node = ast.parse("""
    def new():
        pass
    """).body[0]
    insert_at(index, parent, new_node)

# Generated at 2022-06-23 23:45:09.551211
# Unit test for function insert_at
def test_insert_at():
    code = """
        a = b + c
        if a > b:
            print('a > b')
        else:
            print('a < b')
        """
    tree = ast.parse(code)

    for node in find(tree, ast.If):
        parent = get_parent(tree, node)
        insert_at(parent.body.index(node), parent, ast.Print(dest='a'))

    code = ast.unparse(tree)

    assert code == \
        """\
        a = b + c
        print(dest='a')
        if a > b:
            print('a > b')
        else:
            print('a < b')
        """



# Generated at 2022-06-23 23:45:19.283627
# Unit test for function insert_at
def test_insert_at():
    parent = ast.parse('print(1 + 2)')
    insert_at(1, parent, ast.parse('print(3)'))

    assert ast.dump(parent) == \
        "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), " \
        "args=[Num(n=1)], keywords=[])), Expr(value=Call(func=Name(id='print', " \
        "ctx=Load()), args=[Num(n=3)], keywords=[])), Expr(value=BinOp(left=Num(n=1), " \
        "op=Add(), right=Num(n=2)))])"  # NOQA



# Generated at 2022-06-23 23:45:23.752018
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    parent = ast.parse('def foo():\n    pass', mode='exec')
    child = parent.body[0]
    assert get_closest_parent_of(parent, child, ast.Module) == parent
    assert get_closest_parent_of(parent, child, ast.FunctionDef) == child

# Generated at 2022-06-23 23:45:29.993065
# Unit test for function get_parent
def test_get_parent():
    """Get parent."""
    tree = ast.parse('def func():\n'
                     '  pass\n')

    class_def = tree.body[0]
    func_def = class_def.body[0]
    pass_ = func_def.body[0]

    assert get_parent(tree, class_def) == tree
    assert get_parent(tree, func_def) == class_def
    assert get_parent(tree, pass_) == func_def

# Generated at 2022-06-23 23:45:35.699383
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_string = 'def f():\n  pass\n  pass\n'
    tree = ast.parse(ast_string)
    node_to_test = get_closest_parent_of(tree, tree.body[0], ast.Module)
    expected_result = tree
    assert node_to_test == expected_result

# Generated at 2022-06-23 23:45:36.986904
# Unit test for function replace_at

# Generated at 2022-06-23 23:45:43.572014
# Unit test for function replace_at
def test_replace_at():
    def foo():
        # test
        pass

    tree = ast.parse(inspect.getsource(foo))
    node = tree.body[0].body[0]
    parent, child_index = get_non_exp_parent_and_index(tree, node)
    replace_at(child_index, parent, ast.parse('pass').body[0])
    assert inspect.getsource(foo) == 'def foo():\n    pass'



# Generated at 2022-06-23 23:45:48.650755
# Unit test for function get_parent
def test_get_parent():
    mod_ast = ast.parse('var1 = 1 + 2')  # type: ast.Module
    assign_ast = mod_ast.body[0]  # type: ast.Assign
    binop_ast = assign_ast.value  # type: ast.BinOp

    assert get_parent(mod_ast, binop_ast) is assign_ast
    assert get_parent(mod_ast, mod_ast) is None



# Generated at 2022-06-23 23:45:57.035006
# Unit test for function get_parent
def test_get_parent():
    code = ast.parse('a = 1\nb = 2\nc = 3')
    _build_parents(code)
    assert get_parent(code, code.body[0]) == code
    assert get_parent(code, code.body[1]) == code
    assert get_parent(code, code.body[2]) == code
    assert get_parent(code, code.body[0].targets[0]) == code.body[0]
    assert get_parent(code, code.body[1].targets[0]) == code.body[1]
    assert get_parent(code, code.body[2].targets[0]) == code.body[2]



# Generated at 2022-06-23 23:45:58.911718
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # pragma: no cover
    from .parsing import get_tree
    from astpretty import pprint as print


# Generated at 2022-06-23 23:46:03.047142
# Unit test for function find
def test_find():
    import typed_astunparse
    node = typed_astunparse.ast_parse('a = 1')
    nodes = list(find(node, ast.Assign))
    assert(len(nodes) == 1)



# Generated at 2022-06-23 23:46:09.896653
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("a = int(a.x)")
    
    assert hasattr(tree, 'body')
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[0].value, ast.Call)
    
    replace_at(1, tree, ast.parse("int(a.x) - 1"))
    
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[0].value, ast.BinOp)

# Generated at 2022-06-23 23:46:18.048277
# Unit test for function insert_at
def test_insert_at():
    def f():
        if False:
            1
        if True:
            2
        if True:
            3

    tree = ast.parse(inspect.getsource(f))
    if_one, if_two, if_three = find(tree, ast.If)
    index_two = get_non_exp_parent_and_index(tree, if_two)[1]
    insert_at(index_two, get_parent(tree, if_two), if_one)

    def g():
        if False:
            1
        if False:
            1
        if True:
            2
        if True:
            3

    tree_two = ast.parse(inspect.getsource(g))
    assert ast.dump(tree) == ast.dump(tree_two)

# Generated at 2022-06-23 23:46:26.190177
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('''
        if True:
            pass
        if False:
            pass
        if True:
            pass
    ''')
    ast.fix_missing_locations(tree)

    if_node = tree.body[0]  # type: ast.If

    assert len(if_node.body) == 1

    body = ast.parse('''
        print('x')
        print('y')
        print('z')
    ''').body  # type: List[ast.AST]

    replace_at(0, if_node, body)

    assert len(if_node.body) == 3  # type: ignore



# Generated at 2022-06-23 23:46:27.293627
# Unit test for function find
def test_find():
    # todo: how to write test?
    pass



# Generated at 2022-06-23 23:46:27.794567
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:46:34.045824
# Unit test for function replace_at
def test_replace_at():
    n = ast.parse('a = 1').body[0]
    parent = ast.parse('a = 1;' 'b = 2')

    replace_at(0, parent, n)

    assert ast.dump(parent) == 'Assign(targets=[Name(id="a", ctx=Store())], ' \
        'value=Num(n=1))\nAssign(targets=[Name(id="b", ctx=Store())], value=Num(n=2))'

# Generated at 2022-06-23 23:46:44.141187
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # create a tree:
    # tree = ast.parse("if i < 0: foo()")
    i = ast.Name(id='i')
    n = ast.Load()
    comp_i = ast.Compare(left=i, ops=[ast.Lt()], comparators=[ast.Num(n=0)])
    func_foo = ast.Name(id='foo')
    call_foo = ast.Call(func=func_foo, args=[], keywords=[])
    if_ = ast.If(test=comp_i, body=[call_foo], orelse=[])
    tree = ast.Module(body=[if_])

    # get parent, index of node i
    parent, index = get_non_exp_parent_and_index(tree, i)
    assert isinstance(parent, ast.Module)
    assert index

# Generated at 2022-06-23 23:46:49.316671
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""def
    func():
    pass""")
    node = ast.parse("""f = 10""")

    insert_at(2, tree.body[0], node)

    expected = ast.parse("""def
    func():
    f = 10
    pass""")
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-23 23:46:54.347736
# Unit test for function insert_at
def test_insert_at():
    import copy
    import ast
    import sys
    import unittest

    # Create an ast tree with one function with one expression
    tree = ast.parse("""
    def test_func(a):
        a = 'test'
        b = 3
        return a + b
    """)

    # Insert an expression at the beginning of the function body
    node = ast.Expr(value=ast.Str(s='Test'))
    func = tree.body[0]
    insert_at(0, func, node)
    # Check that the expression is added
    assert len(func.body) == 4

    # Insert a list of expressions

# Generated at 2022-06-23 23:47:01.017592
# Unit test for function replace_at
def test_replace_at():
    import ast
    from pprint import pprint

    class FuncDefExample(ast.AST):
        _fields = ('annotation', 'name', 'args', 'body', 'decorator_list')

    class AnnAssignExample(ast.AST):
        _fields = ('annotation', 'value', 'simple')

    annotation = AnnAssignExample()
    f_node = FuncDefExample(annotation, 'f', 'args', 'body',
                            'decorator_list')
    f_node.body.insert(0, f_node.annotation)

    del f_node.annotation
    pprint(ast.dump(f_node))

    annotation = AnnAssignExample()

# Generated at 2022-06-23 23:47:12.048901
# Unit test for function replace_at
def test_replace_at():
    class Foo:
        def __init__(self, name: str) -> None:
            self.name = name

        @property
        def body(self) -> List[str]:
            return ['a', 'b', 'c', 'd']

    foo = Foo('foo')  # type: ignore
    assert foo.body == ['a', 'b', 'c', 'd']

    replace_at(0, foo, ['v', 'g'])
    assert foo.body == ['v', 'g', 'b', 'c', 'd']

    replace_at(2, foo, ['t'])
    assert foo.body == ['v', 'g', 't', 'c', 'd']

    replace_at(4, foo, ['1', '2'])

# Generated at 2022-06-23 23:47:16.934067
# Unit test for function find
def test_find():
    import astor
    from . import find, _function_source

    source = _function_source()
    tree = ast.parse(source)
    nodes = find(tree, ast.FunctionDef)
    for node in nodes:
        node_source = astor.to_source(node)
        assert 'def' in node_source, 'FunctionDef not found'



# Generated at 2022-06-23 23:47:18.122460
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:47:22.535528
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent."""
    def_node = ast.parse('def add(a, b):\n  return a + b')  # type: ast.Module
    parent = get_parent(def_node, def_node.body[0])
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-23 23:47:26.999845
# Unit test for function replace_at
def test_replace_at():
    funcdef = ast.FunctionDef('foo', ast.arguments([]), [], [], None)
    pass_stmt = ast.Pass()
    assert funcdef.body == []
    replace_at(0, funcdef, pass_stmt)
    assert funcdef.body == [pass_stmt]

# Generated at 2022-06-23 23:47:33.886074
# Unit test for function find
def test_find():
    import sys
    import os
    import unittest
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

    from tests.fixture import code as test_code

    class TestFind(unittest.TestCase):
        def setUp(self):
            self.tree = ast.parse(test_code)

        def test_find(self):
            nodes = find(self.tree, ast.FunctionDef)
            for node in nodes:
                self.assertEqual(type(node), ast.FunctionDef)

    unittest.main()

# Generated at 2022-06-23 23:47:38.448826
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('1+1')
    assert get_non_exp_parent_and_index(tree, tree) == (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].value) == (
        tree.body[0], 0)



# Generated at 2022-06-23 23:47:43.120267
# Unit test for function find
def test_find():
    import astor
    code = """def fun():
    print('hello')"""
    tree = ast.parse(code)

    results = list(find(tree, ast.Name))
    assert 1 == len(results)
    assert astor.to_source(results[0]) == 'print'



# Generated at 2022-06-23 23:47:46.237805
# Unit test for function replace_at
def test_replace_at():
    def assert_body(body, expected):
        statements = [x.s for x in find(body, ast.AnnAssign)]
        assert statements == expected


# Generated at 2022-06-23 23:47:51.140068
# Unit test for function replace_at
def test_replace_at():

    node = ast.parse("""
    @foo
    def f():
        pass
    """).body[0]

    assert len(node.body) == 1

    replace_at(0, node, [ast.parse("@bar")])

    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.Decorator)

# Generated at 2022-06-23 23:47:55.434092
# Unit test for function find
def test_find():
    source = '''
        def func1 ():
            a = 1
            return a + 1
        def func2():
            a = 2
            return a + 2
        '''

    tree = ast.parse(source)
    func_defs = list(find(tree, ast.FunctionDef))

    assert len(func_defs) == 2
    assert func_defs[0].name == 'func1'



# Generated at 2022-06-23 23:47:56.729967
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:48:02.186970
# Unit test for function find
def test_find():
    source = """
    class Foo:
        pass
    """
    tree = ast.parse(source)
    target = list(find(tree, ast.ClassDef))
    assert len(target) == 1
    assert isinstance(target[0], ast.ClassDef)
    assert target[0].name == 'Foo'


# Generated at 2022-06-23 23:48:11.568700
# Unit test for function find
def test_find():
    import inspect
    import typed_ast.ast3 as ast
    from os.path import dirname, join, realpath

    from . import find

    filename = realpath(join(dirname(__file__), '..', '..', 'tests', 'test_ast.py'))
    with open(filename, 'r') as f:
        source = f.read()

    tree = ast.parse(source, filename)

# Generated at 2022-06-23 23:48:22.568683
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.FunctionDef(name='func', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Str(s='Hello World!')], keywords=[])), ast.Return(value=ast.Name(id='None', ctx=ast.Load()))], decorator_list=[], returns=None)
    parent = ast.Module(body=[node])
    tree = ast.parse('def func():\n print("Hello_World")')
    _build_parents(tree)
    assert get_non_exp_parent_and_index(tree, node) == (parent, 0)




# Generated at 2022-06-23 23:48:27.307169
# Unit test for function get_parent
def test_get_parent():
    exp1 = ast.parse('a = 5 + 2')
    exp2 = (ast.parse('a = 5 + 2')).body[0]
    exp3 = ((ast.parse('a = 5 + 2')).body[0]).value
    exp4 = (((ast.parse('a = 5 + 2')).body[0]).value).right

    # TODO: Check why this node is not correct.
    assert (get_parent(exp1, exp2) == exp1.body[0])
    assert (get_parent(exp1, exp3) == exp1)
    assert (get_parent(exp1, exp4) == exp1)


# Generated at 2022-06-23 23:48:35.969903
# Unit test for function insert_at
def test_insert_at():
    from ..parser import Parser
    from .test_parser import sample_code_tree
    from .test_parser import sample_code
    from .test_parser import insert_at as test_insert_at

    parser = Parser()
    tree = parser.parse(sample_code)

    for parent, index in test_insert_at:
        real_parent, real_index = get_non_exp_parent_and_index(
            tree, sample_code_tree[index])
        assert real_parent == parent
        assert real_index == index

# Generated at 2022-06-23 23:48:39.010030
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    t = ast.parse('def f():\n    pass')
    p, i = get_non_exp_parent_and_index(t, t.body[0].body[0])

    assert p.body[i] is t.body[0].body[0]

# Generated at 2022-06-23 23:48:48.880902
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = 'if a: return 4'
    tree = ast.parse(code)
    ret_node = find(tree, ast.Return).__next__()
    test_case = get_non_exp_parent_and_index(tree, ret_node)
    assert test_case[0].__class__.__name__ == 'If'
    assert test_case[1] == 0

    code = '''if a:
            if b:
                print('It works')
            '''
    tree = ast.parse(code)
    print_node = find(tree, ast.Expr).__next__()
    test_case = get_non_exp_parent_and_index(tree, print_node)

    assert test_case[0].__class__.__name__ == 'If'

# Generated at 2022-06-23 23:48:52.404108
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    parent = get_closest_parent_of(ast.parse("x='a'"),ast.parse("x='a'").body[0].value, ast.Module)
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-23 23:48:54.726864
# Unit test for function find
def test_find():
    # Normal case
    program = """a = 42\na = 10\n"""


# Generated at 2022-06-23 23:49:03.986902
# Unit test for function find
def test_find():
    tree = ast.parse("x = 1 + 2\nprint(x)")
    assert sum(1 for _ in find(tree, ast.Num)) == 2

    # Find all statements
    assert sum(1 for _ in find(tree, ast.stmt)) == 2

    # Find all expressions
    assert sum(1 for _ in find(tree, ast.expr)) == 4

    # Check for a custom type
    class CustomNode(ast.AST): pass

    node = CustomNode()
    tree = ast.parse("x = 1 + 2\nprint(x)",
                     additional_classes={"CustomNode": CustomNode})
    assert sum(1 for _ in find(tree, CustomNode)) == 1



# Generated at 2022-06-23 23:49:10.393245
# Unit test for function replace_at
def test_replace_at():
    def function_def(x):
        y = x + 1
        return y

    tree = ast.parse(inspect.getsource(function_def))
    #targets the second statement (y = x + 1)
    parent, i = get_non_exp_parent_and_index(tree,
            tree.body[0].body[1])
    replace_at(i, parent,
               ast.copy_location(ast.parse("z = 2").body[0],
                                 tree.body[0].body[1]))
    ast.fix_missing_locations(tree)
    code = compile(tree, '', 'exec')
    exec(code)
    assert function_def(0) == 2

# Generated at 2022-06-23 23:49:13.955973
# Unit test for function find
def test_find():
    assert list(find(ast.parse(''), ast.Expr)) == []
    assert list(find(ast.parse('1'), ast.Expr)) == [ast.Expr(value=ast.Num(n=1))]
    assert list(find(ast.parse('1'), ast.Num)) == [ast.Num(n=1)]

# Generated at 2022-06-23 23:49:21.108003
# Unit test for function replace_at
def test_replace_at():
    def replace_at(parent, index, new_elements):
        old_element = parent.body[index]
        parent.body = parent.body[:index] + new_elements + parent.body[index+1:]
        return old_element
    # test
    tree = ast.parse("""
    while True:
        value = 1
    """)
    while_node = tree.body[0]
    assignment_node = while_node.body[0]
    old_node = replace_at(while_node, 0, [])
    assert(old_node is assignment_node)
    assert(len(while_node.body) == 0)

    old_node = replace_at(tree, 0, [])
    assert(old_node is while_node)
    assert(len(tree.body) == 0)

# Generated at 2022-06-23 23:49:24.619617
# Unit test for function insert_at
def test_insert_at():
    n = ast.parse("[1, 2, 3]")
    insert_at(0, n.body[0].value, [ast.Num(4), ast.Num(5)])
    assert ast.dump(n) == "[1, 4, 5, 2, 3]"



# Generated at 2022-06-23 23:49:29.333001
# Unit test for function replace_at
def test_replace_at():
    suite_ast = ast.parse('def f(x): return x + 1', mode='exec')
    func_ast = suite_ast.body[0]
    call_ast = func_ast.body.body[0]
    old_ast = call_ast.value
    new_ast = ast.Str('new_string')
    replace_at(0, call_ast, new_ast)
    assert get_parent(suite_ast, new_ast) == call_ast
    assert old_ast not in ast.walk(suite_ast)

# Generated at 2022-06-23 23:49:39.874979
# Unit test for function get_parent
def test_get_parent():
    import unittest

    class GetParentTestCase(unittest.TestCase):
        def test_body(self):
            """Test parent for node in body"""
            f_def = ast.parse('def fun():\n    var = "some string"\n').body[0]
            self.assertEqual(f_def, get_parent(f_def, f_def.body[0]))

        def test_body_multiple(self):
            """Test parent for node in body with multiple lines"""

# Generated at 2022-06-23 23:49:45.697842
# Unit test for function get_parent
def test_get_parent():
    code = _parse('def a():\n pass')
    parent = get_parent(code, code.body[0])
    assert isinstance(parent, ast.Module)

    code = _parse('def a():\n pass')
    parent = get_parent(code, code.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)



# Generated at 2022-06-23 23:49:54.241586
# Unit test for function replace_at
def test_replace_at():
    sample_module = ast.parse('x = "foo"')
    sample_module_strify = ast.dump(sample_module)
    sample_module_strify_replace = ast.dump(ast.parse(
        'a = "foo"'))
    sample_module_body = sample_module.body[0]
    sample_module_target = sample_module.body[0]
    parent = get_parent(sample_module, sample_module_body)
    replace_at(sample_module.body.index(sample_module_target), parent, ast.parse(
        'x = "foo"'))
    assert sample_module_strify == sample_module_strify_replace



# Generated at 2022-06-23 23:50:04.993087
# Unit test for function replace_at
def test_replace_at():
    import astor
    tree = ast.parse('def test():\n    if True:\n        a = 1\n')
    replace_at(2, tree.body[0].body[0], ast.parse('b = 1').body[0])
    assert astor.to_source(tree) == 'def test():\n    if True:\n        a = 1\n        b = 1\n'
    tree = ast.parse('def test():\n    if True:\n        a = 1\n')
    replace_at(2, tree.body[0].body[0], ast.parse('b = 1\nc = 2').body)
    assert astor.to_source(tree) == 'def test():\n    if True:\n        a = 1\n        b = 1\n        c = 2\n'
    tree

# Generated at 2022-06-23 23:50:15.355821
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        "class A: def __init__(self):\n\tself.x = 1\n"
        "\tself.y = 2\n\tself.z = 3\n\tdef test(self):\n\t\tself.x = 5")
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.ClassDef)
    assert index == 0
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])
    assert index == 1
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[2])
    assert index == 2
    parent, index = get

# Generated at 2022-06-23 23:50:26.233325
# Unit test for function get_parent
def test_get_parent():
    def foo(a):
        return a

    def bar():
        return foo(1)

    tree = ast.parse('''
    def foo(a):
        return a

    def bar():
        return foo(1)
    ''')

    # Test the function on a function definition that is a child
    child = ast.parse('a').body[0]
    parent = get_parent(tree, child)
    assert isinstance(parent, ast.FunctionDef)

    # Test the function on a function definition that is a parent
    parent = ast.parse('''def foo(a):\n    return a\n''').body[0]
    child = parent.body[0]
    parent2 = get_parent(tree, child)
    assert parent2 is parent

    # Test the function on a function definition with a name


# Generated at 2022-06-23 23:50:32.538530
# Unit test for function replace_at
def test_replace_at():
    def f():
        a = 1
        b = 2
        return

    tree = ast.parse(inspect.getsource(f))
    node = tree.body[0].body[2]
    first_parent, _ = get_non_exp_parent_and_index(tree, node)
    replace_at(0, first_parent, ast.Constant('hi'))
    assert tree.body[0].body[2].value == 'hi'


if __name__ == "__main__":
    print(test_replace_at())

# Generated at 2022-06-23 23:50:42.538517
# Unit test for function replace_at
def test_replace_at():
    class DummyClass(ast.AST):
        _fields = ('body',)
        body = []

    dummy_list = [ast.Name(id='test1', ctx=ast.Load()),
                  ast.Name(id='test2', ctx=ast.Load()),
                  ast.Name(id='test3', ctx=ast.Load())]
    dummy_node = DummyClass()
    dummy_node.body = dummy_list
    dummy_replacement = ast.Name(id='replacement', ctx=ast.Load())
    replace_at(1, dummy_node, dummy_replacement)
    assert dummy_node.body[0].id == 'test1'
    assert dummy_node.body[1].id == 'replacement'
    assert dummy_node.body[2].id == 'test3'



# Generated at 2022-06-23 23:50:46.397368
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('from __future__ import print_function\n' +
                     'def foo(a, b):\n' +
                     '    print(a)\n' +
                     '    print(b)\n' +
                     '    return a + b\n')
    module = tree.body[0]

    print('Original body of module')
    for child in module.body:
        print(child)

    insert_at(1, module, [ast.Expr(ast.Str('my insert'))])

    print('Modified body of module')
    for child in module.body:
        print(child)

    assert module.body[1].value.s == 'my insert'



# Generated at 2022-06-23 23:50:50.255491
# Unit test for function find
def test_find():
    # test function find
    tree = ast.parse("aa = 'a'\n"
                     "print(aa)")
    ass = find(tree, ast.Assign)
    assert isinstance(next(ass), ast.Assign)
    exp = find(tree, ast.Expr)
    assert isinstance(next(exp), ast.Expr)



# Generated at 2022-06-23 23:50:53.435518
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
    def test():
        if True:
            a = b
        return
    ''')
    _build_parents(tree)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert parent is tree.body[0]
    assert index == 0



# Generated at 2022-06-23 23:51:03.717434
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    with open("correct_code/function_with_insider_function.py", "r") as f:
        func_tree = ast.parse(f.read())

    # Type of func_tree is Module(body=[FunctionDef(name='data', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Assign(targets=[Name(id='i', ctx=Store())], value=Num(n=1)), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Name(id='i', ctx=Load())], keywords=[])), Assign(targets=[Name(id='i', ctx=Store())], value=Num(n=2)), Expr(value=Call(func=

# Generated at 2022-06-23 23:51:09.808838
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        """
        for x in range(1, 2):
            def f(y, z):
                print(y + z)
        """
    )

    item = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, item)

    assert(isinstance(parent, ast.For))
    assert(index == 0)

# Generated at 2022-06-23 23:51:19.672912
# Unit test for function insert_at
def test_insert_at():
    tree: ast.AST = ast.parse('x + 1')
    replace_node: ast.AST = find(tree, ast.Expr).__next__()  # type: ignore
    replace_index: int = tree.body.index(replace_node)
    old_bin_op: ast.AST = replace_node.value  # type: ignore
    new_bin_op: ast.BinOp = ast.BinOp(left=ast.Num(n=2),
                                      op=ast.Add(),
                                      right=old_bin_op)

    # Replace x with x + 2
    replace_at(replace_index, tree.body, new_bin_op)

    # Insert 2 between + and x
    insert_at(1, new_bin_op, ast.Num(n=2))

    assert ast.dump

# Generated at 2022-06-23 23:51:21.580062
# Unit test for function get_parent
def test_get_parent():
    stmt = ast.parse('x=10; if(x):x=2;').body[1]
    assert isinstance(stmt, ast.If)
    assert get_parent(stmt, stmt.body[0]) == stmt


# Generated at 2022-06-23 23:51:27.827445
# Unit test for function insert_at
def test_insert_at():
    pass
#    stmts = ast.parse("a and b or c").body
#    insert_at(1, stmts, ast.parse("d"))
#    assert len(stmts) == 5
#    assert stmts[1].value.id == "d"

# Generated at 2022-06-23 23:51:31.732621
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    inp = ast.parse('def fn():\n    print("Hello!")')
    parent = get_closest_parent_of(inp, inp.body[0].body[0],
                                   ast.FunctionDef)
    assert (parent == inp.body[0])
    assert (parent.name == 'fn')

# Generated at 2022-06-23 23:51:42.711322
# Unit test for function find
def test_find():
    import astor
    # This test case should print 2 times:
    #     func(a, b, c, ddddd=eeeee, ffffff=gggggg)
    #     func(a, b, c, ddddd=eeeee, ffffff=gggggg)
    # instead, it prints:
    #     func(a, b, c, ddddd=eeeee, ffffff=gggggg)
    #     func(a, b, c, ddddd=eeeee, ffffff=gggggg)
    #     func(a, b, c, ddddd=eeeee, ffffff=gggggg)
    #     func(a, b, c, ddddd=eeeee, ffffff=gggggg)
    #     func(a, b, c, ddd

# Generated at 2022-06-23 23:51:46.242901
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    t = ast.parse('async def f():\n    print(42)')
    a = t.body[0].body[0].value
    p, i = get_non_exp_parent_and_index(t, a)
    assert p == t.body[0].body[0]
    assert i == 2

# Generated at 2022-06-23 23:51:51.968375
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    parent = ast.parse('foo')
    node = ast.parse('foo')
    assert get_non_exp_parent_and_index(parent, node) == (parent, 0)


# Generated at 2022-06-23 23:51:55.808618
# Unit test for function find
def test_find():
    import astor
    tree = astor.parse_file("test.py")
    for node in find(tree, ast.Call):
        print(node)

# Generated at 2022-06-23 23:52:04.065720
# Unit test for function insert_at
def test_insert_at():
    import astor
    import astunparse

    tree = ast.parse('a = 1')
    tree_copy = ast.parse('a = 1')

    insert_at(0, tree_copy, ast.parse('b = 2'))

    # using astor's dump() because astunparse has a bug
    # that breaks the unit test
    assert astor.dump(tree_copy) == \
        "Module(body=[Assign(targets=[Name(id='b', ctx=Store())], " +\
        "value=Num(n=2)), Assign(targets=[Name(id='a', ctx=Store())], " +\
        "value=Num(n=1))])"

# Generated at 2022-06-23 23:52:07.550155
# Unit test for function replace_at
def test_replace_at():
    t = ast.parse("if True: x = 1")
    f, = find(t, ast.FunctionDef)
    replace_at(0, f, [ast.Expr(ast.Str("Hello"))])
    assert ast.dump(t) == "def foo():\n    'Hello'"

# Generated at 2022-06-23 23:52:12.419395
# Unit test for function find
def test_find():
    """Unit test for function find."""
    from . import parse

    ast_ = parse(
        """
        def foo():
            pass

        def bar():
            pass
        """
    )

    assert len(list(find(ast_, ast.FunctionDef))) == 2

# Generated at 2022-06-23 23:52:18.719426
# Unit test for function replace_at
def test_replace_at():
    import astor
    func_def = ast.parse('def foo():\n    while True:\n        pass')
    parent = get_parent(func_def, func_def.body[0])
    replace_at(0, parent, ast.parse('x = 1'))
    assert astor.to_source(func_def) == 'def foo():\n    x = 1\n    while True:\n        pass'

# Generated at 2022-06-23 23:52:21.046883
# Unit test for function get_parent
def test_get_parent():
    from typed_ast import ast3
    from ..exceptions import NodeNotFound


# Generated at 2022-06-23 23:52:28.209206
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class MyType(ast.AST):
        pass

    class IAmNotMyType(ast.AST):
        pass
    my_type = MyType()
    not_my_type = IAmNotMyType()
    my_type.body = [not_my_type]
    not_my_type.body = [MyType()]
    assert get_closest_parent_of(my_type, not_my_type, MyType) == my_type

# Generated at 2022-06-23 23:52:32.121299
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def x(): pass\n')
    node = list(find(tree, ast.FunctionDef))[0]
    result = get_closest_parent_of(tree, node, ast.Module)

    assert isinstance(result, ast.Module)

# Generated at 2022-06-23 23:52:35.370868
# Unit test for function find
def test_find():
    """
    Find's 'c' and 'd' in this tree.

    class A:
        def __init__() -> None:
            a = 1
            b = 3
            c = 5
            d = 7
    """

# Generated at 2022-06-23 23:52:45.383273
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

    test_code = '''
        def foo():
            while True:
                if True:
                    continue
                else:
                    break
        '''
    tree = astor.parse_file(test_code)
    if_statement = tree.body[0].body.body[1].body[0]
    closest_if_statement = get_closest_parent_of(tree, if_statement, ast.If)
    assert(astor.to_source(closest_if_statement) == 'if True:')

    foo = tree.body[0]
    closest_if_statement = get_closest_parent_of(tree, foo, ast.If)
    assert(closest_if_statement is None)

    while_statement = tree.body[0].body.body[0]

# Generated at 2022-06-23 23:52:50.146099
# Unit test for function insert_at
def test_insert_at():
    import astpretty

# Generated at 2022-06-23 23:52:50.954679
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-23 23:52:56.912146
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("test_func(1)")
    parent, idx = get_non_exp_parent_and_index(tree, tree.body[0].value)
    # parent is the function definition and the argument is on index 0
    assert isinstance(parent, ast.FunctionDef)
    assert idx == 0