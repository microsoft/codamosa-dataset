

# Generated at 2022-06-23 23:42:56.666569
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():  # noqa: D103
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module, FunctionDef
    from .test_utilities import compare_node_trees

    tree = ast.parse('def foo():\n\tpass\ndef bar():\n\tpass')

    pass_node = tree.body[0].body[0]
    module = get_closest_parent_of(tree, pass_node, Module)
    assert isinstance(module, Module)

    module = get_closest_parent_of(tree, pass_node, FunctionDef)
    assert isinstance(module, FunctionDef)
    assert module.name == 'foo'

# Generated at 2022-06-23 23:43:00.160741
# Unit test for function find
def test_find():
    from .loads import loads

    tree = loads('if True: pass')
    assert find(tree, ast.If) is not None
    assert find(tree, ast.FunctionDef) is None
    assert find(tree, ast.If) is not None



# Generated at 2022-06-23 23:43:06.818573
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("x = 1")
    a = ast.parse("print(1)")

    t = get_non_exp_parent_and_index(tree, tree.body[0])
    insert_at(t[1], t[0], a)

    assert(ast.dump(tree) == "Module(body=[Expr(value=Name(id='x', ctx=Load())), Print(dest=None, values=[Num(n=1)], nl=True), Expr(value=Num(n=1))])")
    assert(ast.dump(a) == "Print(dest=None, values=[Num(n=1)], nl=True)")


# Generated at 2022-06-23 23:43:13.008411
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = """
    def add(x, y):
        return x + y
    """
    tree = ast.parse(code)

    func_def = tree.body[0]
    return_stmt = func_def.body[0]
    bin_op = return_stmt.value

    assert get_non_exp_parent_and_index(tree, bin_op) == (func_def, 0)

# Generated at 2022-06-23 23:43:15.574606
# Unit test for function insert_at
def test_insert_at():
    from .. import parse
    from ..transform import Transformer
    from . import _fix_indents
    from .utils import PySource


# Generated at 2022-06-23 23:43:16.598978
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert 0 == 0

# Generated at 2022-06-23 23:43:27.816464
# Unit test for function insert_at
def test_insert_at():
    input_tree = ast.parse('a = b')  # type: ignore
    test_tree = ast.parse('a = b = c')  # type: ignore

    insert_at(1, input_tree.body[0], ast.Assign(
              targets=[ast.Name(id='b', ctx=ast.Store())],
              value=ast.Name(id='c', ctx=ast.Load()),
              type_comment=None))

    assert len(input_tree.body) == len(test_tree.body)

    for node in input_tree.body:
        assert node.targets[0].id == test_tree.body[0].targets[0].id
        assert node.value.id == test_tree.body[0].value.id

    assert input_tree.body[0].t

# Generated at 2022-06-23 23:43:31.912037
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    return
    code = """
    with open("file", "r") as f:
        for line in f:
            print(line)
    """

    tree = ast.parse(code)
    _build_parents(tree)
    print(get_non_exp_parent_and_index(tree, tree.body[0].body[0]))

# Generated at 2022-06-23 23:43:34.535241
# Unit test for function find
def test_find():
    top = ast.parse('a = 1\na = 2')
    assert 2 == len(list(find(top, ast.Assign)))



# Generated at 2022-06-23 23:43:42.520125
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    for x in range(10):
        x += 1
    """)

    node = tree.body[0].body[0].value

    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.For)
    assert index == 0

    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert index == 0


# Unit tests for function find

# Generated at 2022-06-23 23:43:45.451370
# Unit test for function find
def test_find():
    tree = ast.parse('a = b')
    found = find(tree, ast.Name)
    name = next(found)
    assert name.id == 'b'



# Generated at 2022-06-23 23:43:52.273897
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Tests get_non_exp_parent_and_index with example tree."""
    # pylint: disable=no-member
    tree = ast.parse(dedent('''\
    def func():
        if cond1:
            if cond2:
                pass
        elif cond3:
            pass
    '''))

    f_def = tree.body[0]
    if_stmt = f_def.body[0]
    if_elif = f_def.body[1]

    assert (if_stmt, 1) == get_non_exp_parent_and_index(tree, if_elif)
    assert (f_def, 0) == get_non_exp_parent_and_index(tree, if_stmt)

    # pylint: disable=attribute-defined-outside-

# Generated at 2022-06-23 23:43:57.997444
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert ast.dump(get_non_exp_parent_and_index(
        ast.parse('class Foo:\n    def foo(self): pass'),
        ast.FunctionDef('foo', ast.arguments(), [ast.Pass()], [], None)
    )[0]) == ast.dump(
        ast.parse('class Foo:\n    def foo(self): pass').body[0]
    )

# Generated at 2022-06-23 23:43:59.991155
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_astunparse as unparser
    import astor

# Generated at 2022-06-23 23:44:04.687802
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from . import MockTree

    tree = MockTree.func_with_for()
    assert isinstance(get_closest_parent_of(tree, tree.func.body[1], ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, tree.func.body[1], ast.For), ast.For)



# Generated at 2022-06-23 23:44:08.108086
# Unit test for function replace_at
def test_replace_at():
    body = [ast.Pass(), ast.Pass(), ast.Pass()]
    parent = ast.Module(body=body, type_ignores=[])

    replace_at(1, parent, ast.Return(ast.Num(1)))

    assert isinstance(parent.body[1], ast.Return)

# Generated at 2022-06-23 23:44:14.691712
# Unit test for function get_parent
def test_get_parent():
    source = inspect.getsource(get_parent)

    inner_node = ast.parse(source).body[0].body[0].value.args[0]

    parent = get_parent(ast.parse(source), inner_node, rebuild=True)
    assert parent == ast.parse(source).body[0].body[0]
    
    with pytest.raises(NodeNotFound):
        get_parent(ast.parse('1'), inner_node)



# Generated at 2022-06-23 23:44:26.164438
# Unit test for function get_parent
def test_get_parent():
    # Test with a tree containing a single node
    tree = ast.parse('x=1')
    assert get_parent(tree, tree) is None
    assert get_parent(tree, tree.body[0]) is tree
    assert get_parent(tree, tree.body[0].targets[0]) is tree.body[0]
    assert get_parent(tree, tree.body[0].value) is tree.body[0]
    # Test with a more complex tree
    tree = ast.parse('if x: x=1')
    assert get_parent(tree, tree) is None
    assert get_parent(tree, tree.body[0]) is tree
    assert get_parent(tree, tree.body[0].test) is tree.body[0]

# Generated at 2022-06-23 23:44:29.252354
# Unit test for function get_parent
def test_get_parent():
    class A(ast.AST):
        pass

    class B(ast.AST):
        pass

    class C(ast.AST):
        pass

    a = A()
    b = B()
    c = C()

    b.a = a
    c.b = b

    assert get_parent(c, a) == b
    assert get_parent(b, a) == b



# Generated at 2022-06-23 23:44:36.083199
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from . import parse
    tree = parse('''
        def foo(bar):
            if bar:
                for b in bar:
                    try:
                        baz = b
                    except:
                        continue
    ''')
    assert isinstance(get_closest_parent_of(tree, get_parent(tree, tree.body[0].body[0].body[0]), ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, get_parent(tree, tree.body[0].body[0].body[0]), ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, get_parent(tree, tree.body[0].body[0].body[0]), ast.For), ast.For)
    assert isinstance

# Generated at 2022-06-23 23:44:42.280764
# Unit test for function find
def test_find():
    test_ast = ast.parse(u'a = 1 + 1\n'
                         u'b = 2 + 2')

    a = next(find(test_ast, ast.Name))
    assert a.id == 'a'

    # Additive operator
    add = next(find(test_ast, ast.BinOp))
    assert isinstance(add.op, ast.Add)



# Generated at 2022-06-23 23:44:49.801591
# Unit test for function replace_at
def test_replace_at():
    class DummyNodeParent(ast.AST):
        _fields = ('body',)
        body = None

    class DummyNode(ast.AST):
        _fields = ()

    parent = DummyNodeParent()
    parent.body = [DummyNode()]
    assert len(parent.body) == 1

    insert_at(0, parent, DummyNode())
    assert len(parent.body) == 2

    replace_at(0, parent, DummyNode())
    assert len(parent.body) == 1



# Generated at 2022-06-23 23:44:53.869653
# Unit test for function find
def test_find():
    tree = ast.parse("a = 1; b = 2; a + b")
    nodes = list(find(tree, ast.Name))
    assert len(nodes) == 4
    assert nodes[0].id == 'a'
    assert nodes[1].id == 'b'
    assert nodes[2].id == 'a'
    assert nodes[3].id == 'b'

# Generated at 2022-06-23 23:44:54.704311
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import inspect

# Generated at 2022-06-23 23:45:05.261015
# Unit test for function get_parent
def test_get_parent():
    """Test unit for function get_parent."""

# Generated at 2022-06-23 23:45:08.568849
# Unit test for function get_parent
def test_get_parent():
    _tree = ast.parse('a = 2')
    _node = _tree.body[0].value
    _parent = get_parent(_tree, _node)
    assert isinstance(_parent, ast.Assign)
    assert _parent == _tree.body[0]



# Generated at 2022-06-23 23:45:17.134712
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse("1 + 1").body[0]
    node2 = ast.parse("1 + 1").body[0].value
    assert(get_parent(node, node2) == node)
    node = ast.parse("1 + 1")
    node2 = ast.parse("1 + 1").body[0].value
    assert(get_parent(node, node2) is None)
    node = ast.parse("1 + 1").body[0]
    node2 = ast.parse("1 + 1").body[0]
    assert(get_parent(node, node2) is None)

# Generated at 2022-06-23 23:45:23.065207
# Unit test for function find
def test_find():
    assert [].equal(list(find(ast.parse('def foo(): bar()'), ast.FunctionDef)))
    assert [].equal(list(find(ast.parse('def foo(): bar()'), ast.AsyncFunctionDef)))
    assert [].equal(list(find(ast.parse('def foo(): bar()'), ast.arguments)))
    assert [ast.Load()].equal(
        list(find(ast.parse('def foo(): a = 1'), ast.Load)))
    assert [
        ast.Add()
    ].equal(list(find(ast.parse('def foo(): a = 1 + 2'), ast.Add)))

# Generated at 2022-06-23 23:45:24.529086
# Unit test for function replace_at

# Generated at 2022-06-23 23:45:33.112841
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """
    Creating a tree of nodes as follows:

    FunctionDef(name='f', args=arguments(args=[arg(arg='a')]), body=[Expr(value=BinOp(left=Num(n=1), op=Add(), right=Num(n=2))), Return(value=Num(n=3)), Return(value=Num(n=4))])
    |-FunctionDef
    | |-arguments
    | | `-arg
    | |   `-Name
    | |-Expr
    | | `-BinOp
    | |   |-Num
    | |   `-Num
    | `-Return
    |   `-Num
    `-Return
        `-Num
    """

# Generated at 2022-06-23 23:45:42.128633
# Unit test for function insert_at
def test_insert_at():
    class TestClass:
        def __init__(self):
            self.body = [1, 2, 3]

    a = ast.Module([])

    insert_at(3, a, 4)
    assert a.body[3] == 4

    b = TestClass()

    insert_at(0, b, [4, 5, 6])
    assert b.body == [4, 5, 6, 1, 2, 3]

    insert_at(2, b, [7, 8, 9])
    assert b.body == [4, 5, 7, 8, 9, 6, 1, 2, 3]

# Generated at 2022-06-23 23:45:49.183566
# Unit test for function insert_at
def test_insert_at():
    def f():
        pass
    parent = ast.parse('def f():\n    pass').body[0]
    insert_at(1, parent, ast.Expr(value=ast.Constant(value=0)))
    insert_at(1, parent, ast.Expr(value=ast.Constant(value=1)))
    insert_at(1, parent, ast.Expr(value=ast.Constant(value=2)))
    assert ast.dump(ast.parse('def f():\n    pass\n    2\n    1\n    0'),
                    include_attributes=True) == ast.dump(parent,
                                                         include_attributes=True)


# Generated at 2022-06-23 23:45:55.967790
# Unit test for function insert_at
def test_insert_at():
    def function(x: int, y: int) -> int:
        pass

    tree = ast.parse(inspect.getsource(function))
    function_def = tree.body[0]
    arg_def = function_def.args.args[0]

    insert_at(0, arg_def, ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Load()),
                                        annotation=ast.Name(id='int',
                                                            ctx=ast.Load())))

    print(ast.dump(tree))

# Generated at 2022-06-23 23:46:07.225474
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("a + b")
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.BinOp)
    assert isinstance(tree.body[0].value.left, ast.Name)
    assert isinstance(tree.body[0].value.op, ast.Add)
    assert isinstance(tree.body[0].value.right, ast.Name)

    replace_at(0, tree, ast.parse("c + d"))
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.BinOp)

# Generated at 2022-06-23 23:46:14.036039
# Unit test for function replace_at
def test_replace_at():
    # Given
    tree = ast.parse("""
    def foo(x):
        return x + 1

    def bar():
        return 2
    """)
    func_def = get_closest_parent_of(tree, get_non_exp_parent_and_index(
        tree, tree.body[0].body[0].value)[0], ast.FunctionDef)
    # When
    replace_at(0, func_def, [ast.Expr(ast.Num(2))])
    # Then
    assert ast.dump(tree) == ast.dump(ast.parse("""
    def foo(x):
        2
        return x + 1

    def bar():
        return 2
    """))

# Generated at 2022-06-23 23:46:21.182159
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('test = 0\nprint(test)')
    parent_ = get_non_exp_parent_and_index(tree, tree.body[0])[0]
    replace_at(0, parent_, [ast.Expr(ast.Num(100))])

    assert_equals(ast.dump(tree), 'Module(body=[Expr(value=Num(n=100)), Print(dest=None, values=[Name(id=\'test\', ctx=Load())], nl=True)])')



# Generated at 2022-06-23 23:46:21.766571
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-23 23:46:22.825501
# Unit test for function get_closest_parent_of

# Generated at 2022-06-23 23:46:23.193354
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-23 23:46:25.888673
# Unit test for function get_parent
def test_get_parent():
    p = ast.parse('a = 1\n1 + 2')
    assert get_parent(p, p.body[1]) == p
    assert get_parent(p, p.body[0].value) == p.body[0].value

# Generated at 2022-06-23 23:46:35.513377
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test to see if we can get the parents of something that is an expression
    mod = ast.parse("a+b")
    funcdef = mod.body[0]
    assert get_non_exp_parent_and_index(mod, funcdef) == (mod, 0)
    exp = funcdef.body.body[0]
    assert get_non_exp_parent_and_index(mod, exp) == (funcdef.body, 0)
    # Test to see if we can get the parents of something that is not an expression
    mod = ast.parse("if a:\n    b\nelse:\n    c")
    funcdef = mod.body[0]
    assert get_non_exp_parent_and_index(mod, funcdef) == (mod, 0)

# Generated at 2022-06-23 23:46:41.023397
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("def f():\n    return 4 + 3 + 2")
    print(type(tree))
    first_int = find(tree, ast.Num).__next__()
    print(type(first_int))
    parent, index = get_non_exp_parent_and_index(tree, first_int)
    print(parent, index)

# Generated at 2022-06-23 23:46:47.885916
# Unit test for function replace_at
def test_replace_at():
    import astor
    from ..utils.ast_helpers import get_exp

    root = ast.parse('a = 2 + 3\n'
                     'b = 4 + 5\n'
                     'c = 6 + 7')
    body = root.body
    node = body[1]
    parent, index = get_non_exp_parent_and_index(root, node)
    replace_at(index, parent, body[2])
    print(astor.to_source(root))

# Generated at 2022-06-23 23:46:58.253841
# Unit test for function replace_at
def test_replace_at():
    from typed_ast.ast3 import Assign, Expr, Load, Tuple, Name
    module = ast.parse('x = (0, 1, y)')
    body = module.body
    expr = body[0].value

    # node to replace
    # Assign(
    #    targets=[Tuple(
    #        elts=[
    #            Num(n=0),
    #            Num(n=1)
    #        ],
    #        ctx=Load())],
    #    value=Load()
    # )
    #
    # node to insert
    # Expr(
    #    value=Tuple(
    #        elts=[
    #            Name(id='x', ctx=Load()),
    #            Name(id='y', ctx=Load()),
    #        ],


# Generated at 2022-06-23 23:47:00.980845
# Unit test for function replace_at
def test_replace_at():
    """
    Replace expr at index.

    class A:
        def a(self):
            pass
    """

# Generated at 2022-06-23 23:47:07.601136
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(ast.parse("""
    def g():
        a = 1

        def f():
            a = 2
            return a
    """), ast.parse("""
    def f():
        a = 2
        return a
    """).body[0]).body.index(ast.parse("""
    def f():
        a = 2
        return a
    """).body[0]) == 1

# Generated at 2022-06-23 23:47:14.057909
# Unit test for function get_parent
def test_get_parent():
    class MyAst(ast.AST):
        body: List[ast.AST] = []

    a = MyAst()
    b = MyAst()
    c = MyAst()
    a.body.append(b)
    b.body.append(c)

    assert get_parent(a, b) == a
    assert get_parent(a, c) == b
    assert get_parent(a, a) == a

    try:
        get_parent(a, MyAst())
        assert False
    except NodeNotFound:
        assert True


# Generated at 2022-06-23 23:47:16.169853
# Unit test for function replace_at
def test_replace_at():
    import typed_astunparse
    from astunparse import unparse


# Generated at 2022-06-23 23:47:17.668108
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # TODO: test that function works when node is the tree
    assert True

# Generated at 2022-06-23 23:47:28.436020
# Unit test for function replace_at
def test_replace_at():
    """test_replace_at."""
    # Test case:
    # def foo():
    #   return 1
    #   pass
    #   pass
    #   pass
    #   pass
    #   pass

    attr_type = ast.Attribute(value=ast.Name(id='foo', ctx=ast.Load()),
                              attr='__doc__', ctx=ast.Load())


# Generated at 2022-06-23 23:47:35.775329
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    # build tree
    x = ast.Name("x", ast.Store, lineno=1, col_offset=0)
    y = ast.Name("y", ast.Store, lineno=1, col_offset=0)
    op = ast.Add()
    expr = ast.BinOp(left=x, op=op, right=y, lineno=1, col_offset=0)
    body = ast.Expr(value=expr, lineno=1, col_offset=0)

# Generated at 2022-06-23 23:47:39.719576
# Unit test for function find
def test_find():
    nodes = find(ast.parse('1+1'), ast.Name)
    assert len(list(nodes)) == 2
    nodes = find(ast.parse('a.b+1'), ast.Name)
    assert len(list(nodes)) == 2


# Generated at 2022-06-23 23:47:50.537226
# Unit test for function replace_at
def test_replace_at():
    #Test for the case where you replace the first node
    first_node = ast.Expr(value=ast.Call(ast.Name('f', ast.Load()),
                                         [ast.Name('x', ast.Load())],
                                         [], None, None))
    second_node = ast.Index(ast.Num(4))
    parent = ast.Expr(value=ast.Call(ast.Name('f', ast.Load()),
                                         [ast.Name('x', ast.Load())],
                                         [], None, None))
    parent.body.insert(1, second_node)
    replace_at(0, parent, first_node)
    assert isinstance(parent.body[0], ast.Expr)
    assert len(parent.body) == 1

    #Test for the case where you replace the second node

# Generated at 2022-06-23 23:47:51.419132
# Unit test for function insert_at

# Generated at 2022-06-23 23:47:57.484746
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("x = f(3)")

    Call = get_closest_parent_of(tree, tree.body[0].value, ast.Call)
    Assign = get_closest_parent_of(tree, tree.body[0], ast.Assign)
    Module = get_closest_parent_of(tree, tree.body[0], ast.Module)

    assert Module is tree

# Generated at 2022-06-23 23:48:06.569263
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert_context = {'called': False}

    class Foo(ast.NodeVisitor):
        def visit_FunctionDef(self, node: ast.FunctionDef):
            assert_context['called'] = True
            assert_context['closest'] = \
                get_closest_parent_of(self.tree, node, ast.Module)

            self.generic_visit(node)

    foo = Foo()
    foo.visit(ast.parse('def foo(): pass'))

    assert assert_context['called']
    assert isinstance(assert_context['closest'], ast.Module)

# Generated at 2022-06-23 23:48:11.122001
# Unit test for function replace_at
def test_replace_at():
    import ast
    parent = AST()
    n1 = AST()
    n2 = AST()
    n3 = AST()
    n4 = AST()
    parent.body = [n1, n2, n3, n4]
    replace_at(parent=parent, index=1, nodes=[AST(), AST(), AST(), AST()])
    assert len(parent.body) == 7


# Generated at 2022-06-23 23:48:22.194260
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def f():
        try:
            pass
        except:
            pass
        else:
            print(3)
    """)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0]), ast.Try)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0].type), ast.ExceptHandler)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[2].value), ast.Print)
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[2].value.dest), ast.Name)

# Generated at 2022-06-23 23:48:29.964183
# Unit test for function find
def test_find():

    import astor

    tree = astor.parse_file('./tests/examples/test.py')
    list_ = list(find(tree, ast.FunctionDef))

    if len(list_) != 2:
        print('Number of FunctionDefs found is incorrect: {}.'.format(len(list_)))
    if not hasattr(list_[0], 'body'):
        print('First node has no body')
    if not isinstance(list_[0], ast.FunctionDef):
        print('First node is not a ast.FunctionDef')
    if list_[0].name != 'f':
        print('Function is not named "f"')
    if not isinstance(list_[1], ast.FunctionDef):
        print('Second node is not a ast.FunctionDef')

# Generated at 2022-06-23 23:48:37.590673
# Unit test for function find
def test_find():
    testcode = """class Test():
        def __init__(self):
            pass
    """
    testtree = ast.parse(testcode)
    # ast.dump(testtree)
    # print(ast.dump(testtree))
    # print(dir(ast.dump(testtree)))
    assert len(list(find(testtree, ast.ClassDef))) == 1
    assert len(list(find(testtree, ast.FunctionDef))) == 1
    assert len(list(find(testtree, ast.Pass))) == 1

# Generated at 2022-06-23 23:48:44.757220
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def test(): pass')

    defs = find(tree, ast.FunctionDef)
    function = next(defs)
    del_node = function.body[0]

    parent = get_parent(tree, del_node)
    replace_at(parent.body.index(del_node), parent, ast.Pass())

    assert ast.dump(tree) == ast.parse('def test(): pass').dump()

# Generated at 2022-06-23 23:48:49.450216
# Unit test for function replace_at
def test_replace_at():
    not_tree = ast.parse("a = 1\nb = 2\npass\n")
    # Replace When `pass` with `pass\nc = 1`
    replace_at(3, not_tree, ast.parse("pass\nc = 1"))
    assert "c = 1\n" in ast.dump(not_tree)


# Generated at 2022-06-23 23:48:51.144070
# Unit test for function get_parent
def test_get_parent():
    import astor


# Generated at 2022-06-23 23:48:58.761569
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = """
        def foo():
            a = 1
            b = 2
            a = b + 1
            return a
        """
    result = """
        def foo():
            a = 1
            b = 2
            a = b + 1
            return a
            return a
        """
    result = ast.parse(result)

    tree = ast.parse(code)
    node = find(tree, ast.Return).__next__()

    parent, index = get_non_exp_parent_and_index(tree, node)
    insert_at(index+1, parent, node)

    assert ast.dump(tree, True) == ast.dump(result, True)

# Generated at 2022-06-23 23:49:01.705189
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('''def foo(a, b):
        bar()
        foo()''') # code from exercise 2
    insert_at(1, tree.body[0], [ast.parse('boo()').body[0]])
    import astunparse
    print(astunparse.unparse(tree))
    
#test_insert_at()

# Generated at 2022-06-23 23:49:05.537881
# Unit test for function insert_at
def test_insert_at():
    pass

# Generated at 2022-06-23 23:49:06.726765
# Unit test for function find
def test_find():
    tree = ast.parse('import numpy as np')
    imp = find(tree, ast.Import).__next__()
    assert isinstance(imp, ast.Import)

# Generated at 2022-06-23 23:49:15.886675
# Unit test for function find
def test_find():
    import json
    import inspect
    import collections

    class NodeEncoder(json.JSONEncoder):
        def default(self, o):
            if isinstance(o, ast.AST):
                fields = collections.OrderedDict()
                for field in fields:
                    value = getattr(o, field, None)
                    if isinstance(value, ast.AST):
                        fields[field] = value.__class__.__name__
                    elif isinstance(value, list):
                        fields[field] = [i.__class__.__name__ for i in value]
                    elif value is None:
                        fields[field] = None
                    else:
                        fields[field] = str(value)
                return fields
            else:
                return json.JSONEncoder.default(self, o)

    s = inspect.cleand

# Generated at 2022-06-23 23:49:23.826142
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo(x, y=3):
        z = x + y
        print(z)
        _ = print(z)
    """)
    node = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.FunctionDef)
    assert node.name == 'foo'



# Generated at 2022-06-23 23:49:35.396808
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_ = ast.parse('def f(): pass')
    assert get_non_exp_parent_and_index(ast_, ast_) == (ast_, 0)

    ast_ = ast.parse('def f(): pass\ndef g(): pass')
    assert get_non_exp_parent_and_index(ast_, ast_) == (ast_, 1)

    ast_ = ast.parse('def f(): pass\n\n\ndef g(): pass')
    assert get_non_exp_parent_and_index(ast_, ast_) == (ast_, 1)

    ast_ = ast.parse('def f(): pass\ndef g(): pass')
    ast_2 = ast_.body[1]  # type: ignore

# Generated at 2022-06-23 23:49:41.311363
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("def f(a, b): return a + b")
    assert get_parent(tree, tree.body[0].body[0].value.args[0]) == tree.body[0].body[0]
    assert get_parent(tree, ast.Name(id='a', ctx=ast.Load())) == tree.body[0].body[0].value
    assert get_parent(tree, tree.body[0].body[0].value) == tree.body[0]

# Generated at 2022-06-23 23:49:47.871135
# Unit test for function get_parent
def test_get_parent():
    from ..utils import get_body_from_string
    from .test_utils import get_ast_from_str

    tree = get_body_from_string("""
        for i in range(10):
            print(i)
    """)

    for_node = get_ast_from_str('for i in range(10):')

    assert get_parent(tree, for_node) == tree

# Generated at 2022-06-23 23:49:55.335514
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo(bar):
        if bar:
            return bar
        else:
            return
    """)
    test_ast = tree.body[0].body[0].test
    test_parent_ast = tree.body[0].body[0]
    test_grandparent_ast = tree.body[0]
    assert get_parent(tree, test_ast) == test_parent_ast
    assert get_parent(tree, test_parent_ast) == test_grandparent_ast
    assert get_non_exp_parent_and_index(tree, test_ast) == (test_grandparent_ast, 0)



# Generated at 2022-06-23 23:50:05.876297
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Expr(ast.expr):
        _attributes = ('value',)

    class Assign(ast.stmt):
        _attributes = ('targets', 'value')

    class Module(ast.mod):
        _attributes = ('body',)

    expr = Expr(None)
    assign = Assign([expr], None)
    mod = Module([assign])
    tree = ast.fix_missing_locations(mod)
    assert (get_closest_parent_of(tree, expr, ast.stmt) is assign)

    class FunctionDef(ast.stmt):
        _attributes = ('name', 'args', 'body', 'decorator_list', 'returns')

    def_ = FunctionDef(None, None, None, None, None)

# Generated at 2022-06-23 23:50:10.453711
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.parse("""
    a = 1
    b = 2
    if a > b:
        print(a)
    elif a < b:
        print(b)
    else:
        print("equal")
    """).body[2]
    assert get_closest_parent_of(node, node, ast.If) == node



# Generated at 2022-06-23 23:50:17.947314
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from astor.source_repr import unparse
    from ..tests.utils import generate_example_code_1, code_examples_9, code_examples_10

    # Example of code with tree
    test_code = \
        generate_example_code_1()

    # We obtain the tree of ast
    tree = ast.parse(test_code)

    # We take a node: in this case we take the next one
    node = tree.body[0].body[0][-1]

    # We obtain the non-Exp parent and the index of the child
    non_exp_parent, index = get_non_exp_parent_and_index(tree, node)

    # We obtain the AST of the non-Exp parent
    ast_non_exp_parent = ast.dump(non_exp_parent)

    # We

# Generated at 2022-06-23 23:50:22.505288
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse('''def test():
        print('test')
    test()''')
    assert(get_parent(node, node.body[0].body[0]) == node.body[0])



# Generated at 2022-06-23 23:50:28.322837
# Unit test for function replace_at
def test_replace_at():
    import inspect
    import astor

    test_code = """
    def test_function(x):
      return x + 1
    """
    test_ast = ast.parse(test_code)
    replace_at(0, test_ast, ast.parse('def test_function(x):\n  return x * 2').body[0])
    assert astor.to_source(test_ast) == """
    def test_function(x):
      return x * 2
    """

# Generated at 2022-06-23 23:50:36.706070
# Unit test for function insert_at
def test_insert_at():
    source_code = """def test():
        for i in range(1):
            var = 2
    """
    tree = ast.parse(source_code)
    func_node = tree.body[0]
    assert(func_node.body[0].value.args[0].n==1)
    insert_at(0, func_node.body[0], ast.Num(2))
    assert(func_node.body[0].value.args[0].n==2)
    assert(func_node.body[0].value.args[1].n==1)
    insert_at(1, func_node.body[0], ast.Num(3))
    assert(func_node.body[0].value.args[1].n==3)
    print(ast.dump(tree))

# Generated at 2022-06-23 23:50:39.556329
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_node = ast.parse("""
        def foo(): pass
    """)
    test_node = test_node.body[0]

    assert(
        get_closest_parent_of(test_node, test_node.body[-1], ast.FunctionDef) ==
        test_node)

# Generated at 2022-06-23 23:50:50.426814
# Unit test for function get_parent
def test_get_parent():
    import astor
    # Trivial parent get test
    prog = ast.parse('print(1)')
    _build_parents(prog)
    assert isinstance(get_parent(prog, prog.body[0]), ast.Module)
    # Trivial parent get test
    prog = ast.parse('print(1)')
    _build_parents(prog)
    assert isinstance(get_parent(prog, prog.body[0], rebuild=True), ast.Module)
    # Parent get test with code rewrite
    prog = ast.parse('print(1)')
    _build_parents(prog)
    assert isinstance(get_parent(prog, prog.body[0]), ast.Module)
    prog = ast.parse('print(1)')

# Generated at 2022-06-23 23:50:51.086670
# Unit test for function get_parent

# Generated at 2022-06-23 23:50:57.661651
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as ast
    tree = ast.parse("""
        def test(x):
            pass
    """)
    
    module = tree.body[0]
    func = module.body[0]
    ast.fix_missing_locations(tree)

    assert (get_closest_parent_of(tree, func, ast.Module) == module)
    assert (get_closest_parent_of(tree, func, ast.FunctionDef) == func)

# Generated at 2022-06-23 23:51:05.404805
# Unit test for function replace_at
def test_replace_at():
    foo = ast.parse('''
    def foo():
        a = 1
        b = 2
        c = 3
    ''').body[0]
    body = foo.body
    replace_at(1, foo, ast.parse('a = 4').body[0])
    assert len(body) == 3
    assert body[0].targets[0].id == 'a'
    assert body[0].value.n == 4
    assert body[1].targets[0].id == 'b'
    assert body[1].value.n == 2
    assert body[2].targets[0].id == 'c'
    assert body[2].value.n == 3



# Generated at 2022-06-23 23:51:14.570723
# Unit test for function insert_at
def test_insert_at():
    parent = ast.parse('for i in range(10):\n    pass\n')
    insert_at(-1, parent, ast.parse('print(i)'))
    assert ast.dump(ast.parse('for i in range(10):\n    print(i)\n    pass\n')) == ast.dump(parent)

    parent = ast.parse('for i in range(10):\n    pass\n')
    insert_at(1, parent, ast.parse('print(i)'))
    assert ast.dump(ast.parse('for i in range(10):\n    pass\nprint(i)\n')) == ast.dump(parent)

    parent = ast.parse('for i in range(10):\n    pass\n')
    insert_at(2, parent, ast.parse('print(i)'))

# Generated at 2022-06-23 23:51:15.444430
# Unit test for function insert_at

# Generated at 2022-06-23 23:51:23.120931
# Unit test for function replace_at
def test_replace_at():
    program = ast.parse("""if True:\n\tprint(1)""")
    _build_parents(program)
    func_def = program.body[0]
    if_stmt = func_def.body[0]
    print_stmt = if_stmt.body[0]
    assert print_stmt == get_parent(program, print_stmt)
    assert if_stmt == get_parent(program, print_stmt, rebuild=True)
    assert func_def == get_parent(program, if_stmt)
    assert get_parent(program, print_stmt) == if_stmt
    assert get_parent(program, if_stmt) == func_def


# Generated at 2022-06-23 23:51:34.110732
# Unit test for function replace_at
def test_replace_at():
    t = ast.parse('for i in xrange(10): pass')
    f = t.body[0]
    n = ast.Call(func=ast.Name(id='foo', ctx=ast.Load()),
                 args=[], keywords=[])
    insert_at(0, f.body, n)
    assert ast.dump(t) == \
        'Module(body=[For(target=Name(id=\'i\', ctx=Store()), iter=Call(func=Name(id=\'xrange\', ctx=Load()), args=[Num(n=10)], keywords=[]), body=[Pass()], orelse=[])])'
    replace_at(0, f.body, ast.Break())

# Generated at 2022-06-23 23:51:40.101003
# Unit test for function replace_at
def test_replace_at():
    node = ast.parse("""
    def function_name(arg1, arg2, arg3):
        def in_function():
            print("Test")
        return [1, 2]
    """).body[0]
    parent, index = get_non_exp_parent_and_index(node, node.body[0])
    _build_parents(node)
    replace_at(index, parent, [])
    assert not hasattr(parent, "body")



# Generated at 2022-06-23 23:51:48.388571
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast as ast_lib
    from . import VARIABLES as VAR
    from . import STMTS as STMT

    assert type(get_closest_parent_of(
        tree=VAR.x, node=STMT.print(VAR.x),
        type_=ast_lib.Module)
    ) is ast_lib.Module
    assert type(get_closest_parent_of(
        tree=VAR.x, node=STMT.print(VAR.x),
        type_=ast_lib.Expr)
    ) is ast_lib.Expr

# Generated at 2022-06-23 23:51:55.653229
# Unit test for function get_parent
def test_get_parent():
    """Test get_parent function."""
    test_object = ast.Str('test line')  # type: ast.AST
    test_obj_parent = ast.Expr(value=test_object)
    test_obj_parent_parent = ast.Module(body=[test_obj_parent])

    _build_parents(test_obj_parent_parent)
    assert get_parent(test_obj_parent_parent, test_object) == test_obj_parent
    assert get_parent(test_obj_parent_parent, test_obj_parent) == test_obj_parent_parent



# Generated at 2022-06-23 23:52:01.366066
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('for i in range(10):\n  print(i)\n  print(i)\n')
    replace_at(1, tree.body[0], ast.parse('i + 1').body[0])
    expected = 'for i in range(10):\n  print(i)\n  print(i + 1)\n'
    assert ast.dump(tree) == ast.dump(ast.parse(expected))



# Generated at 2022-06-23 23:52:07.759576
# Unit test for function find
def test_find():
    root = ast.parse(
        'class Foo:\n'
        '    def bar():\n'
        '        pass\n'
        '\n'
        'class Baz:\n'
        '    def fuz():\n'
        '        pass\n'
    )
    results = list(find(root, ast.FunctionDef))
    assert len(results) == 2
    assert results[0].name == 'bar'
    assert results[1].name == 'fuz'

# Generated at 2022-06-23 23:52:15.087831
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = textwrap.dedent("""
        for i in a:
            if a:
                print(1)
            else:
                print(2)
    """)
    tree = ast.parse(code)
    node = get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.For)
    assert isinstance(node, ast.For)


# Generated at 2022-06-23 23:52:21.401079
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1 + 1')
    node = get_closest_parent_of(tree, tree.body[0].value.right, ast.AST)
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert tree.body[0].value.right == node
    assert tree.body[0] == parent.body[index]

# Generated at 2022-06-23 23:52:26.308178
# Unit test for function insert_at
def test_insert_at():
    def f(a):
        b = a
        print(b)

    node = find(ast.parse(f.__code__.co_consts[1]).body[0],
                ast.Assign).__next__()
    tree = ast.parse(f.__code__.co_consts[1])
    insert_at(1, tree.body[0], node)


# Generated at 2022-06-23 23:52:31.156482
# Unit test for function replace_at
def test_replace_at():
    """Test replace_at function."""
    import astunparse

    expr = ast.parse('a + 1')
    body = expr.body[0]
    assert get_parent(expr, body) == expr

    replace_at(0, expr, ast.Num(n=0))
    assert astunparse.dump(expr) == '0'

# Generated at 2022-06-23 23:52:40.466280
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        _fields = ('par1', 'par2', 'body')

    class B(ast.AST):
        _fields = ('par1', 'par2', 'body')

    class C(ast.AST):
        _fields = ('par1', 'par2', 'body')

    class D(ast.AST):
        _fields = ('par1', 'par2', 'body')

    a = A()
    b = B()
    c = C()
    d = D()

    a.body = [b, c]
    assert a.body == [b, c]

    insert_at(1, a, d)
    assert a.body == [b, d, c]



# Generated at 2022-06-23 23:52:49.866288
# Unit test for function find
def test_find():
    class TestClass(ast.AST):
        _fields = ('a',)
        a = None

    class OtherClass(ast.AST):
        _fields = ('a',)
        a = None

    # create a graph of nodes to test find
    a = TestClass()
    b = TestClass()
    c = TestClass()
    d = OtherClass()
    e = TestClass()
    f = TestClass()
    g = TestClass()

    a.a = b
    b.a = c
    c.a = d
    d.a = e
    e.a = f
    f.a = g

    # test find
    assert list(find(a, TestClass)) == [a, b, c, e, f, g]
    assert list(find(g, OtherClass)) == [d]