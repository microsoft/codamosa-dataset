

# Generated at 2022-06-21 18:41:58.875493
# Unit test for function find
def test_find():
    import sys
    import io
    from ..TestVisitor import testvisitor
    from ..TestVisitor import parse
    if len(sys.argv) > 2:
        input_file_name = sys.argv[1]
        myvisitor = testvisitor.MyVisitor()
        with io.open(input_file_name, 'r', encoding='utf-8') as input_file:
            content = input_file.read()
            tree = parse.parse(content, input_file_name)
        
        print("Source tree")
        print(ast.dump(tree, include_attributes=True))
        
        from .InstrumentVisitor import InstrumentVisitor
        from .PrintInstrumentVisitor import PrintInstrumentVisitor
        from .ExpressionVisitor import ExpressionVisitor

# Generated at 2022-06-21 18:42:07.876524
# Unit test for function replace_at
def test_replace_at():
    import astor
    class Modify(ast.NodeVisitor):
        def __init__(self):
            self.root = ast.Module(body=[ast.Expr(value=ast.Name(id='c'))])

        def visit_Module(self, node):
            print('visit_module')
            return self.generic_visit(node)

        def visit_Expr(self, node):
            print('visit_expr')
            return self.generic_visit(node)

        def visit_Name(self, node):
            print(astor.dump_tree(self.root))
            replace_at(0, self.root, ast.Expr(value=ast.Name(id='a')))
            print(astor.dump_tree(self.root))

# Generated at 2022-06-21 18:42:19.729200
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class TestObj(ast.AST):
        _fields = ()

    class Exp(ast.AST):
        _fields = ()

    class Exp1(Exp):
        _fields = ()

    class Exp2(Exp):
        _fields = ()

    class ParentExp(Exp):
        _fields = ('body',)  # type: ignore

    class ParentExp1(ParentExp):
        _fields = ()

    parent_exp1 = ParentExp1()
    exp1 = Exp1()
    exp2 = Exp2()

    parent_exp1.body = [exp1, exp2, TestObj()]

    assert get_non_exp_parent_and_index(parent_exp1, exp1) \
        == (parent_exp1, 0)

# Generated at 2022-06-21 18:42:25.743871
# Unit test for function replace_at
def test_replace_at():
    root_node = ast.parse('a = 1')
    replace_at(0, root_node, ast.parse('b = 1'))
    assert ast.dump(root_node) == textwrap.dedent("""
    Module(body=[Assign(targets=[Name(id='b', ctx=Store())], value=Num(n=1))])
    """)



# Generated at 2022-06-21 18:42:34.316611
# Unit test for function get_parent
def test_get_parent():
    from ..exceptions import NodeNotFound
    from typed_ast import ast3 as ast
    import os
    import inspect

    def get_path(name):
        return os.path.join(os.path.dirname(
            os.path.abspath(inspect.stack()[-1][1])), 'data', name)

    with open(get_path('simple_function_body.py'), 'r') as f:
        func_body = ast.parse(f.read()).body[0].body
        assert len(func_body) == 2
        assert func_body[1].name == 'print'

        get_parent(func_body, func_body[0])

# Generated at 2022-06-21 18:42:35.456034
# Unit test for function get_parent

# Generated at 2022-06-21 18:42:40.489619
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("def func():\n    a = 1")
    insert_at(1, tree.body[0], ast.parse("b = 2").body[0])
    assert str(tree) == "def func():\n    a = 1\n    b = 2"



# Generated at 2022-06-21 18:42:41.662127
# Unit test for function replace_at

# Generated at 2022-06-21 18:42:53.176205
# Unit test for function replace_at
def test_replace_at():
    # Test replacing the first item in a list
    test_list = ast.List(elts=['a', 'b', 'c', 'd'])
    test_list2 = ast.List(elts=['b', 'c', 'd'])
    test_item = ast.Name(id='z')

    replace_at(0, test_list, test_item)
    assert test_list.elts == test_list2.elts + [test_item]

    # Test replacing the last item in a list
    test_list = ast.List(elts=['a', 'b', 'c', 'd'])
    test_list2 = ast.List(elts=['a', 'b', 'c'])
    test_item = ast.Name(id='z')


# Generated at 2022-06-21 18:42:57.298539
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('(1 + 2) + (3 + 4)')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Expression)
    assert index == 0

# Generated at 2022-06-21 18:43:12.181295
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    class_tree = astor.code_to_ast.parse_string("class A:\n    @attr.s\n    def test(self) -> int:\n        return 1\n    def test2(self):\n        self.test()\n        return 2")
    def_tree = astor.code_to_ast.parse_string("def test() -> int:\n    return 1\n    def test2(self):\n        self.test()\n        return 2")
    assert get_non_exp_parent_and_index(class_tree, class_tree.body[0].body[0]) == (class_tree.body[0], 0)

# Generated at 2022-06-21 18:43:23.606737
# Unit test for function find
def test_find():
    def find_stmts(tree: ast.AST, stmts: ast.stmt) -> Iterable[ast.stmt]:
        return find(tree, stmts)

    tree = ast.parse('x=1; y=1\nfoo()')
    assert list(find_stmts(tree, ast.AST)) == []
    assert list(find_stmts(tree, ast.Assign)) == list(tree.body)
    assert list(find_stmts(tree, ast.FunctionDef)) == []
    assert list(find_stmts(tree, ast.Name)) == tree.body[0].targets + \
        tree.body[1].args
    assert list(find_stmts(tree, ast.Call)) == [tree.body[1].value]

# Generated at 2022-06-21 18:43:24.294598
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass

# Generated at 2022-06-21 18:43:30.322839
# Unit test for function insert_at
def test_insert_at():
    """a = 1"""
    a = ast.parse('a = 1').body[0]
    parent = a.targets[0]
    nodes = [ast.parse('b = 2').body[0], ast.parse('c = 3').body[0]]
    """a = b = c = 2"""
    insert_at(0, parent, nodes)
    assert ast.dump(a) == 'a = b = c = 2'



# Generated at 2022-06-21 18:43:41.611054
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            node = ast.Name(id='name', ctx=ast.Load())
            const = ast.Constant(value=True)
            comp = ast.Compare(left=const, ops=[ast.Eq()], comparators=[const])
            assign = ast.Assign(targets=[ast.Name(id='name', ctx=ast.Store())],
                                value=comp)
            func = ast.FunctionDef(name='func', body=[assign], args=ast.arguments())
            file = ast.Module(body=[func])
            self.assertEqual(get_closest_parent_of(file, node, ast.FunctionDef), func)

    unitt

# Generated at 2022-06-21 18:43:45.312829
# Unit test for function insert_at
def test_insert_at():
    index = 1
    parent = ast.FunctionDef(name=None, args=None, body=[], decorator_list=[])
    nodes = ast.Expr(value=None)

    insert_at(index, parent, nodes)

    assert parent.body[index] is nodes



# Generated at 2022-06-21 18:43:53.884121
# Unit test for function find
def test_find():
    class B(ast.AST):
        _fields = ()

    class N(B):
        _fields = ()

    class C(ast.AST):
        _fields = ()

    class M(C):
        _fields = ()

    class D(C):
        _fields = ()

    tree = N()
    tree.body = [M(), D(), N()]  # type: ignore

    assert list(find(tree, N)) == [tree, tree.body[2]]
    assert list(find(tree, C)) == [tree.body[0], tree.body[1]]



# Generated at 2022-06-21 18:43:59.015947
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = """
if foo():
    bar()
    if fuu():
        baz()
"""
    tree = ast.parse(source)  # type: ignore
    closest_parent_of_baz = get_closest_parent_of(tree, tree.body[0].body[2],
                                                  ast.If)  # type: ignore
    assert(isinstance(closest_parent_of_baz, ast.If))
    assert(closest_parent_of_baz.test.id == 'fuu')

# Generated at 2022-06-21 18:44:08.743953
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test = ast.parse('''
    a = 1
    b = 2
    def f(x):
        a
        b
        c
    ''')
    f = test.body[2]
    _, a_index = get_non_exp_parent_and_index(test, f.body[0])
    _, b_index = get_non_exp_parent_and_index(test, f.body[1])
    _, c_index = get_non_exp_parent_and_index(test, f.body[2])
    assert a_index == 1
    assert b_index == 2
    assert c_index == 3

# Generated at 2022-06-21 18:44:12.885023
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse("a = 1 + 2")

    parent = get_parent(node, node.body[0].value)

    assert isinstance(parent, ast.BinOp)



# Generated at 2022-06-21 18:44:23.335805
# Unit test for function replace_at
def test_replace_at():
    # type: () -> None
    """Unit test for function replace_at."""
    import astor

    class_def = ast.ClassDef(name='test', body=[], decorator_list=[])
    parent = ast.Module(body=[class_def])
    replace_at(index=0, parent=parent, nodes=[
        ast.FunctionDef(name='test', body=[], decorator_list=[]),
        ast.FunctionDef(name='test2', body=[], decorator_list=[]),
    ])
    assert astor.to_source(parent) == 'class test:\n    def test(): pass\n    def test2(): pass'

# Generated at 2022-06-21 18:44:29.185992
# Unit test for function get_parent
def test_get_parent():
    example = ast.parse('''
        def foo(a, b):
            c = a + b
            return c
    ''')

    a_plus_b = example.body[0].body[0].value
    function_def = get_parent(example, a_plus_b)
    assert isinstance(function_def, ast.FunctionDef)



# Generated at 2022-06-21 18:44:37.187619
# Unit test for function get_parent
def test_get_parent():
    # test case 1
    program = ast.parse('''
        def func(x):
            a = 1

            if x:
                b = x
            else:
                b = 2

            return a+b

        func(0)
    ''')

    function_declaration = program.body[0]
    function_body = function_declaration.body
    function_body_0 = function_body[0]

    assert get_parent(program, function_body_0) is function_body

    # test case 2
    program = ast.parse('''
        def func(x):
            a = 1

            if x:
                b = x
            else:
                b = 2

            return a+b

        func(0)
    ''')

    function_call = program.body[1]
   

# Generated at 2022-06-21 18:44:48.172365
# Unit test for function replace_at
def test_replace_at():
    def fn():
        x = 0
        return x  # replace this comment
    parse_ast = ast.parse(fn)
    assert parse_ast
    block = parse_ast.body[0]
    assert len(block.body) == 2
    assert block.body[1].col_offset == 7
    assert block.body[1].lineno == 2
    # Replace the return value with
    # the output from another function
    from_fn = ast.parse(fn + '\n').body[0].body[-1]
    replace_at(1, block, from_fn)
    print(ast.dump(parse_ast))
    # The output of the above function call
    # will be like this
    # FunctionDef(
    #    name='fn',
    #    args=arguments(args=[], vararg=

# Generated at 2022-06-21 18:44:56.136317
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast
    example = """#!/usr/bin/env python3
    import sys
    import random
    def main(argv):
        if random.randint(0, 1):
            print('yes')
        else:
            print('no')
    if __name__=='__main__':
        sys.exit(main(sys.argv))
    """
    tree = ast.parse(example)
    node = list(find(tree, ast.If))[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef) and index == 4



# Generated at 2022-06-21 18:44:57.132607
# Unit test for function replace_at
def test_replace_at():
    pass


# Generated at 2022-06-21 18:45:02.598424
# Unit test for function replace_at
def test_replace_at():
    mod = ast.parse("x = 1")  # type: ignore
    mod = ast.fix_missing_locations(mod)

    body = mod.body
    assignment = body[0]

    # replace the first item with 2 other items
    replace_at(0, body, ["y = 2", "y = 3"])

    # only one item should remain.
    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)
    assert body[0].value.n == 3


# Generated at 2022-06-21 18:45:14.235464
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astunparse
    import sys
    import asttools.ast2source as ast2source
    ast3 = ast.parse(astunparse.unparse(sys.modules['__main__'].__file__))
    for name_node in ast.walk(ast3):
        if isinstance(name_node, ast.Name):
            if(str(name_node.id) == 'sys'):
                import asttools.visitors.rename_import as rename_import
                rename_import.function_get_import(name_node)
                import_node = get_parent(ast3, name_node)
                parent_node, idx = get_non_exp_parent_and_index(ast3, import_node)
                print(str(ast2source.source2ast(astunparse.unparse(import_node))))

# Generated at 2022-06-21 18:45:25.031416
# Unit test for function insert_at
def test_insert_at():
    import astor

    class TestClass():
        def __init__(self):
            self.body = [1]

    t = TestClass()

    insert_at(0, t, 2)

    assert t.body == [2, 1]

    insert_at(0, t, 3)

    assert t.body == [3, 2, 1]

    insert_at(1, t, [4, 5])

    assert t.body == [3, 4, 5, 2, 1]

    tree = ast.parse("1 + y")
    insert_at(1, tree, ast.parse("x").body[0])

    assert astor.to_source(tree) == "1 + x + y"


# Generated at 2022-06-21 18:45:25.899932
# Unit test for function replace_at

# Generated at 2022-06-21 18:45:38.253997
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a()\na()\na()')
    print(tree)
    parent = tree
    index = 0
    node = ast.parse('b()')
    nodes = [ast.parse('1'), ast.parse('2')]
    insert_at(index, parent, nodes)
    print(tree)

if __name__ == "__main__":
    test_insert_at()

# Generated at 2022-06-21 18:45:44.542288
# Unit test for function find
def test_find():
    parse_tree = ast.parse("a = 1")
    assert find(parse_tree, ast.Assign) is not None
    assert find(parse_tree, ast.Expr) is not None
    assert find(parse_tree, ast.Store) is not None
    assert find(parse_tree, ast.Load) is not None
    assert find(parse_tree, ast.Name) is not None
    assert find(parse_tree, ast.Num) is not None


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-21 18:45:51.183635
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module = ast.parse("""\
        def foo():
            for i in range(10):
                print(i)
    """)

    for_node = get_closest_parent_of(module, module.body[0].body[0],
                                     ast.For)
    result = get_non_exp_parent_and_index(module, for_node)
    assert result[0] == module.body[0]
    assert resu

# Generated at 2022-06-21 18:45:53.313962
# Unit test for function insert_at
def test_insert_at():
    import astunparse

    from ..utils import parse, unparse


# Generated at 2022-06-21 18:46:03.859693
# Unit test for function replace_at
def test_replace_at():
    a = ast.Module(
        [ast.FunctionDef('f',
                         ast.arguments(
                             []
                         ),
        [ast.Assign([ast.Name('a')], ast.Num(1)),
        ast.Assign([ast.Name('b')], ast.Num(2))], [], None, None)]
    )

    b = ast.Module(
        [ast.FunctionDef('f',
                         ast.arguments(
                             []
                         ),
        [ast.Assign([ast.Name('a')], ast.Num(1)),
         ast.Assign([ast.Name('c')], ast.Num(3))], [], None, None)]
    )
    replace_at(1, a, b.body[0].body[1])

# Generated at 2022-06-21 18:46:10.865491
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse(
        """
        def foo(arg1, arg2):
            if bar(arg1):
                print('hello world')
            else:
                print(arg1)
        """
    )

    node = tree.body[0].body[0].body[0]

    parent = get_parent(tree, node)
    assert isinstance(parent, ast.If)



# Generated at 2022-06-21 18:46:14.222744
# Unit test for function replace_at
def test_replace_at():
    import astor
    node = ast.parse('def a(): pass')
    assert node.body[0].name == 'a'
    replace_at(0, node, ast.parse('def b(): pass'))
    assert node.body[0].name == 'b'

# Generated at 2022-06-21 18:46:17.245259
# Unit test for function find
def test_find():
    import pprint
    source = '''
    def test(b):
        c = 3
        return c + b
    '''
    node = ast.parse(source)
    pprint.pprint(find(node, ast.FunctionDef))
    pprint.pprint(find(node, ast.Name))


# Generated at 2022-06-21 18:46:18.680985
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:46:19.322859
# Unit test for function insert_at

# Generated at 2022-06-21 18:46:42.448109
# Unit test for function get_parent
def test_get_parent():
    # Testing simple case: get parent of argument passed in function
    def func():
        print('test print')
        print('second test print')

    tree = ast.parse(inspect.getsource(func))
    second_print = tree.body[0].body[1]
    parent = get_parent(tree, second_print)
    assert isinstance(parent, ast.FunctionDef)

    # Testing case where node is under multiple levels of nesting
    second_print = tree.body[0].body[0]
    parent = get_parent(tree, second_print)
    assert isinstance(parent, ast.FunctionDef)

    # Testing case where parent is the top-level tree node
    parent = get_parent(tree, parent)
    assert parent == tree



# Generated at 2022-06-21 18:46:48.639113
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = """
    a = 1
    b = 2
    if (a == 1):
        while b == 2:
            if True:
                a = 3
                b = 4
    """
    root_node = ast.parse(source)
    a_assign_node = find(root_node, ast.Assign).__next__()
    assert get_closest_parent_of(root_node, a_assign_node, ast.Assign) == a_assign_node
    while_node = find(root_node, ast.While).__next__()
    assert get_closest_parent_of(root_node, while_node, ast.If) == find(root_node, ast.If).__next__()

# Generated at 2022-06-21 18:46:53.397823
# Unit test for function find
def test_find():
    from textwrap import dedent
    from ..parsers import python_parser

    tree = python_parser.parse(dedent("""\
    def foo(x, y):
        return x + y
    print(1 + 2)"""))
    nodes = list(find(tree, ast.FunctionDef))
    assert nodes[0].name == 'foo'

# Generated at 2022-06-21 18:47:03.437276
# Unit test for function insert_at
def test_insert_at():
    """Test for function insert_at."""
    def foo():
        """Test for function insert_at."""
        print('test')
        return

    func_def = find(ast.parse(foo.__doc__), ast.FunctionDef).__next__()
    insert_at(0, func_def, ast.Expr(ast.Call(func=ast.Name(id='print',
                                                           ctx=ast.Load()),
                                             args=[ast.Str(s='test')],
                                             keywords=[])))

    assert func_def.body[0].value.func.id == 'print'
    assert func_def.body[0].value.args[0].s == 'test'



# Generated at 2022-06-21 18:47:11.717333
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

    test_node = ast.parse('for i in range(0, 10): def func(): pass')
    assert astor.to_source(
        get_closest_parent_of(test_node, test_node.body[0].body[0], ast.For)) \
        == 'for i in range(0, 10):'
    assert astor.to_source(
        get_closest_parent_of(test_node, test_node.body[0].body[0], ast.FunctionDef)) \
        == 'def func():'



# Generated at 2022-06-21 18:47:23.237234
# Unit test for function get_parent
def test_get_parent():
    import unittest

    class GetParentTestCase(unittest.TestCase):

        def test_get_parent(self):
            # pylint: disable=W0201
            self.tree = ast.parse("""
                def f(self, x):
                    def g(y):
                        if x == 0:
                            if y == 1:
                                pass
                        return x / y
                    return g(0)
                """)

            self.node = self.tree.body[0].body[0].body[0]

            self.assertIsInstance(
                get_parent(self.tree, self.node), ast.FunctionDef)

            self.assertIsInstance(
                get_parent(self.tree, self.node).body[0], ast.If)


# Generated at 2022-06-21 18:47:34.871942
# Unit test for function find
def test_find():
    from . import parse
    tree = parse("""
        import os
        def func():
            print('Hello world')
        if __name__ == '__main__':
            func()
        """)
    for func_def in find(tree, ast.FunctionDef):
        print(func_def.name)

    for import_from in find(tree, ast.ImportFrom):
        print("from ... {} import {}".format(
            import_from.module, ", ".join(import_from.names)
        ))

    for if_stmt in find(tree, ast.If):
        print("If true:")
        for body_stmt in if_stmt.body:
            print("  {}".format(body_stmt))

        print("If false:")

# Generated at 2022-06-21 18:47:38.401259
# Unit test for function find
def test_find():
    node = ast.parse('a = b')
    assert(list(find(node, ast.Assign))[0].value == node.body[0].value)


# Generated at 2022-06-21 18:47:46.233601
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    expr = tree.body[0]
    expr_s = expr.value
    expr_v = expr_s.n
    assert get_parent(tree, expr) == tree
    assert get_parent(tree, expr_s) == expr
    assert get_parent(tree, expr_v) == expr_s
    # print(get_parent(tree, expr_v))



# Generated at 2022-06-21 18:47:51.770225
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    string = """
    def foo():
        a = 1
        b = a + 2
    """

    tree = ast.parse(string)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])

    assert isinstance(parent, ast.Module)
    assert index == 0