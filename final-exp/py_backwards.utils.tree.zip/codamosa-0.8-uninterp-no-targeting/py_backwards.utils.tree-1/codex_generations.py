

# Generated at 2022-06-21 18:41:56.792797
# Unit test for function insert_at
def test_insert_at():
    # Example code with comment
    code = '''
    a = 1
    # comment
    b = 2
    '''
    tree = ast.parse(code)

    # Node to insert
    node_to_insert = ast.Expr(value=ast.Num(n=42))

    # Parent of b
    parent = get_closest_parent_of(tree, tree.body[-1], ast.Module)

    # Inserting
    insert_at(2, parent, node_to_insert)

    # Checking
    assert isinstance(parent.body[1], ast.Expr)
    assert parent.body[1].value.n == 42



# Generated at 2022-06-21 18:42:02.774060
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def foo(h: object, d: object) -> object:
        pass

    tree = ast.parse(inspect.getsource(foo).strip())

    node = get_closest_parent_of(tree, tree.body[0].args[0], ast.Name)
    assert node is tree.body[0].args[0]

    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert isinstance(index, int)

# Generated at 2022-06-21 18:42:08.034367
# Unit test for function get_parent
def test_get_parent():
    class A(ast.AST):
        pass

    root = A()
    node1 = A()
    node2 = A()

    root.a = node1
    node1.a = node2

    assert get_parent(root, node2) == node1
    assert get_parent(root, node1) == root

# Generated at 2022-06-21 18:42:19.858699
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import json
    import astor
    from typed_ast.ast3 import parse
    from . import get_closest_parent_of
    from . import get_body_of_func

    code = """
    def test(a, b):
        bb = a + b
        print(bb)
    """

    tree = parse(code)

    body = get_body_of_func(tree, 'test')[1]

    assert isinstance(get_closest_parent_of(tree, body, ast.FunctionDef),
                      ast.FunctionDef)

    assert not isinstance(get_closest_parent_of(tree, body, ast.Call),
                          ast.Call)


# Generated at 2022-06-21 18:42:27.899846
# Unit test for function replace_at
def test_replace_at():
    from . import tests
    from ..finalize import Finalizer
    from .._compiler import compile_ast
    from .. import compile

    def _assert_ast(source: str, nodes: List[ast.AST]) -> str:
        tree = compile_ast(source)
        parent, index = get_non_exp_parent_and_index(tree, nodes[0])
        replace_at(index, parent, nodes)
        return compile(tree, source)

    tests.run(_assert_ast, Finalizer(), 'replace-at')

# Generated at 2022-06-21 18:42:29.656652
# Unit test for function insert_at
def test_insert_at():
    import typed_ast.ast3 as ast3
    import astor

# Generated at 2022-06-21 18:42:35.302597
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.AST()
    tree = ast.Module(body=[
        node,
        ast.FunctionDef(
            name='test_func', body=[
                ast.Return(value=ast.Name(id='test_name', ctx=ast.Load()))
            ],
            args=ast.arguments(args=[], vararg=None, kwonlyargs=[],
                               kw_defaults=[], kwarg=None,
                               defaults=[]),
            decorator_list=[], returns=None
        )
    ])

    assert get_closest_parent_of(tree, node, ast.FunctionDef)

# Generated at 2022-06-21 18:42:39.595998
# Unit test for function insert_at
def test_insert_at():
    import inspect
    import astor
    function_ast = ast.parse(inspect.getsource(insert_at)).body[0]
    assert inspect.getsource(insert_at) == astor.to_source(function_ast)
    # No assert statements so test passes


# Generated at 2022-06-21 18:42:44.075918
# Unit test for function find
def test_find():
    class Foo(ast.AST):
        _fields = ('hello',)

    class Bar(ast.AST):
        _fields = ('world',)

    assert sorted(find(ast.Module([Foo(), Bar()]), Foo),
                  key=lambda node: node.hello) == [Foo(), Foo()]

# Generated at 2022-06-21 18:42:45.030772
# Unit test for function get_parent

# Generated at 2022-06-21 18:42:50.424899
# Unit test for function insert_at
def test_insert_at():
    import astor
    # Source: (https://gist.github.com/869791)

# Generated at 2022-06-21 18:43:00.621715
# Unit test for function insert_at
def test_insert_at():
    parent = ast.Module([ast.Assign([], ast.Name('a', ast.Store()))])
    new_child = ast.Assign([], ast.Name('c', ast.Store()))

    # Test insertion at the end
    insert_at(1, parent, new_child)
    assert(len(parent.body) == 2)
    assert(parent.body[1] == new_child)

    # Test insertion at the begining
    insert_at(0, parent, new_child)
    assert(len(parent.body) == 3)
    assert(parent.body[0] == new_child)

    # Test insertion in the middle
    insert_at(1, parent, new_child)
    assert(len(parent.body) == 4)
    assert(parent.body[1] == new_child)

# Generated at 2022-06-21 18:43:03.345479
# Unit test for function find

# Generated at 2022-06-21 18:43:04.482199
# Unit test for function get_parent

# Generated at 2022-06-21 18:43:15.853228
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .ast_utils import ast_print
    import ast

    tree = ast.parse("""
    for i in range(10):
        if i > 5:
            if i > -1:
                if i > -3:
                    if i > 0.0:
                        if i >= 0:
                            if i == 0:
                                if i >= 0:
                                    if i <= 0:
                                        if i & 0 != 0:
                                            print(i)
    """)


# Generated at 2022-06-21 18:43:25.388649
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Expr(ast.Call(ast.Call(ast.Call(ast.Name('foo', ast.Load()),
                                               [], [], None, None),
                                      [], [], None, None),
                             [], [], None, None))
    parents = [ast.Expr, ast.Module]
    indices = [0]

    for parent, index in zip(parents, indices):
        assert isinstance(get_non_exp_parent_and_index(node, node)[0], parent)
        assert get_non_exp_parent_and_index(node, node)[1] == index
        node = get_non_exp_parent_and_index(node, node)[0]


# Generated at 2022-06-21 18:43:26.670474
# Unit test for function get_parent
def test_get_parent():
    assert type(_parents[ast.parse('1')]) == ast.Module


if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-21 18:43:30.941386
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo():\n    bar()')
    node = tree.body[0].body[0]

    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module),
                      ast.Module)

# Generated at 2022-06-21 18:43:38.244390
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    actual_source = """
    def foo():
        print('baz')
    """
    compiled_source = compile(actual_source, '', 'exec')
    tree = ast.parse(actual_source)
    actual_node = find(tree, ast.Name).__next__()
    parent = get_closest_parent_of(tree, actual_node, ast.functionDef)
    assert actual_node in parent.body  # type: ignore

# Generated at 2022-06-21 18:43:44.128186
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_tree = ast.parse(
        '''
        class C:
            def func(self):
                print('Hello, world!')
        '''
    )

    print_node = get_closest_parent_of(ast_tree, ast_tree.body[0].body[0].body[0],
                                       ast.FunctionDef)
    assert isinstance(print_node, ast.FunctionDef)
    assert print_node.name == 'func'

# Generated at 2022-06-21 18:43:52.022203
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:43:59.665526
# Unit test for function get_parent

# Generated at 2022-06-21 18:44:00.445796
# Unit test for function replace_at
def test_replace_at():
    pass

# Generated at 2022-06-21 18:44:10.853539
# Unit test for function insert_at
def test_insert_at():
    class EmptyNode(ast.AST):
        pass

    class ExampleNode(ast.AST):
        _fields = ('body',)

    node = ExampleNode()
    node.body = []

    insert_at(0, node, EmptyNode())
    assert len(node.body) == 1
    assert isinstance(node.body[0], EmptyNode)
    insert_at(0, node, [EmptyNode(), EmptyNode()])
    assert len(node.body) == 3
    assert all(isinstance(node, EmptyNode) for node in node.body)

    node = ExampleNode()
    node.body = [EmptyNode()]

    insert_at(0, node, EmptyNode())
    assert len(node.body) == 2
    assert all(isinstance(node, EmptyNode) for node in node.body)


# Generated at 2022-06-21 18:44:14.961899
# Unit test for function get_parent
def test_get_parent():
    source = """
    a = 1
    b = 2
    c = 3
    """

    parsed = ast.parse(source)

    for node in ast.walk(parsed):
        if isinstance(node, ast.Name):
            print(get_parent(parsed, node))

# Generated at 2022-06-21 18:44:23.872399
# Unit test for function replace_at
def test_replace_at():
    def test():
        def foo():
            pass

    tree = ast.parse(inspect.getsource(test))
    funcdef = get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                    ast.FunctionDef)
    pass_node = funcdef.body[0]
    body_index = get_non_exp_parent_and_index(tree, pass_node)[1]
    new_body = [ast.Pass(), ast.Pass()]

    # The function definitions body contains only one node (the `pass`).
    # Since we're replacing the node at index=0 with two new nodes,
    # the function definitions body = [new_node, new_node] and thus length = 2
    replace_at(body_index, funcdef, new_body)

# Generated at 2022-06-21 18:44:25.302924
# Unit test for function get_parent

# Generated at 2022-06-21 18:44:34.425905
# Unit test for function replace_at
def test_replace_at():
    import astor

    tree = ast.parse('''
    def foo(x):
        x = 3
        return x + 1
    ''')

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    replace_at(index, parent, ast.parse('x = 3').body)

    assert astor.to_source(tree) == astor.to_source(ast.parse('''
    def foo(x):
        x = 3
        return x + 1
    '''))

    #  def foo(x):
    #      x = 3
    #      x = 3
    #      return x + 1
    #  '''))

# Generated at 2022-06-21 18:44:40.573310
# Unit test for function replace_at
def test_replace_at():
    def _test_replace_at():
        a = 1
        b = 2

        def c():
            pass

    tree = ast.parse(_test_replace_at.__code__.co_code)
    replace_at(0, tree.body[1], [ast.Pass()])
    assert ast.fix_missing_locations(tree).as_string() == 'def a():\n    pass\n'

# Generated at 2022-06-21 18:44:46.110792
# Unit test for function get_parent
def test_get_parent():
    import unittest
    from ..exceptions import NodeNotFound

    class GetParentTest(unittest.TestCase):
        def test_get_parent_ReturnParent(self):
            tree = ast.parse('a = 1')
            assign = tree.body[0]
            self.assertEqual(get_parent(tree, assign), tree)

        def test_get_parent_RaiseNodeNotFoundIfNodeNotFound(self):
            tree = ast.parse('a = 1')
            with self.assertRaises(NodeNotFound):
                get_parent(tree, ast.Name('a', ast.Load()))

        def test_get_parent_GetParentWithBodies(self):
            tree = ast.parse('def func():\n    pass')
            func = tree.body[0]
            pass_stmt = func

# Generated at 2022-06-21 18:44:56.552964
# Unit test for function get_closest_parent_of

# Generated at 2022-06-21 18:45:02.913851
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_ast = ast.parse("a = 5 + 2*b if a > 5 else 2*b if b > 5 else 2*a")
    node = test_ast.body[0].value
    node2 = test_ast.body[0].value.orelse
    node3 = node2.orelse
    assert get_non_exp_parent_and_index(
        test_ast, node)[1] == 0
    assert get_non_exp_parent_and_index(
        test_ast, node2)[1] == 0
    assert get_non_exp_parent_and_index(
        test_ast, node3)[1] == 0

# Generated at 2022-06-21 18:45:14.573352
# Unit test for function replace_at
def test_replace_at():
    import unittest
    import sys
    import astor

    class TestReplace_at(unittest.TestCase):
        def test_replace_at(self):
            code = '''
a = 20
'''
            node = ast.parse(code)
            print(node)
            # def_ = node.body[0]
            # if_ = node.body[1]
            # new_def = ast.FunctionDef(name="fizzbuzz",
            #                           args=ast.arguments(
            #                               args=[], vararg=None, kwonlyargs=[],
            #                               kw_defaults=[], kwarg=None, defaults=[])
            #                           )
            # replace_at(0, node, new_def)
            # print(ast.dump(node))
           

# Generated at 2022-06-21 18:45:26.020915
# Unit test for function find

# Generated at 2022-06-21 18:45:31.912147
# Unit test for function replace_at
def test_replace_at():
    def f(a: int) -> int:
        a += 1

        if a > 5:
            a += 2
        else:
            a += 3

        return a

    tree = ast.parse("""
    def f(a: int) -> int:
        a += 1

        if a > 5:
            a += 2
        else:
            a += 3

        return a""")

    tree_copy = ast.parse("""
    def f(a: int) -> int:
        a += 1

        if a > 5:
            a += 2
        else:
            a += 3

        return a""")

    cond = find(tree, ast.Compare).__next__()
    body = get_parent(tree, cond)

    replace_at(1, body, cond)

# Generated at 2022-06-21 18:45:40.294598
# Unit test for function insert_at
def test_insert_at():
    ast_tree = ast.parse("""class Foo:
    def bar(self):
        print('bar')

    def test(self):
        pass""")

    class_def = find(ast_tree, ast.ClassDef).__next__()

    print("1")

    insert_at(1, class_def, ast.Pass())

    print("2")

    assert str(ast_tree) == """class Foo:
    def bar(self):
        print('bar')

    pass

    def test(self):
        pass"""

if __name__ == '__main__':
    test_insert_at()

# Generated at 2022-06-21 18:45:44.500098
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def func():
        a = 2
        b = 3
        c = 3 + 2
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[2])
    assert index == 2
    assert parent == tree.body[0]

# Generated at 2022-06-21 18:45:48.070546
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def test():
        a = 1
        b = 2
        c = 3
    tree = ast.parse(test.__code__).body[0]
    node = tree.body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1
    assert not hasattr(parent, 'body')

# Generated at 2022-06-21 18:45:48.976175
# Unit test for function get_closest_parent_of

# Generated at 2022-06-21 18:45:52.059227
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast.ast3 import parse
    from ..visitors import VisitFind


# Generated at 2022-06-21 18:46:06.814926
# Unit test for function replace_at
def test_replace_at():
    import unittest
    class MyTestCase(unittest.TestCase):
        def test_something(self):
            import typed_ast.ast3

# Generated at 2022-06-21 18:46:15.033238
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
    def func():
        def foo():
            def bar():
                pass
    ''')

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.ClassDef), ast.ClassDef)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.Module), ast.Module)

if __name__ == '__main__':
    test_get_closest_parent_of()

# Generated at 2022-06-21 18:46:27.021399
# Unit test for function replace_at
def test_replace_at():
    sample_script = """
        a = 1
        b = 2
        c = 3
        d = 4
        return 11
    """

    sample_tree = ast.parse(sample_script)
    func_def = find(sample_tree, ast.FunctionDef).__next__()
    return_expr = find(func_def, ast.Return).__next__()

    replace_at(4, func_def, ast.parse('''
        return 11
        return 22
    '''))

    assert func_def.body[4] is not return_expr

    sample_tree = ast.parse(sample_script)
    func_def = find(sample_tree, ast.FunctionDef).__next__()
    replace_at(4, func_def, ast.Return(value=ast.Num(n=22)))


# Generated at 2022-06-21 18:46:36.169911
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    python_code = 'x = 10\nprint(x)'
    tree = ast.parse(text=python_code)

    try:
        parent = get_closest_parent_of(tree, node=tree.body[1].value, type_=ast.Module)
    except AttributeError:
        parent = None

    assert parent is not None and isinstance(parent, ast.Module)

    parent = get_closest_parent_of(tree, node=tree.body[1].value, type_=ast.Expr)

    assert parent is not None and isinstance(parent, ast.Expr)

# Generated at 2022-06-21 18:46:40.730872
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    class Foo():
        def __init__(self):
            self.attr = 1
        def bar(self):
            print(self.attr)
    """)

    node = list(ast.walk(tree))[-2]  # get assignment node
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)  # type: ignore



# Generated at 2022-06-21 18:46:51.764039
# Unit test for function replace_at
def test_replace_at():
    class MockedBody:
        def __init__(self):
            self.data = []

        def insert(self, index, node):
            self.data.insert(index, node)

        def pop(self, index):
            self.data.pop(index)

    class MockedExp:
        body = MockedBody()

    class MockedFuncDef:
        body = MockedBody()

    body = MockedExp()
    func = MockedFuncDef()
    expr = MockedExp()

    func.body.insert(0, expr)
    body.body.insert(0, func)

    class MockedAExpr:
        pass

    a_expr = MockedAExpr()

    replace_at(0, body, a_expr)

# Generated at 2022-06-21 18:47:02.791025
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    def a():
        pass

    def b():
        pass

    moduleTree = ast.parse(inspect.getsource(a))
    bTree = ast.parse(inspect.getsource(b))

    moduleTree.body.append(bTree.body[0])

    assert get_non_exp_parent_and_index(moduleTree, bTree.body[0]) == \
        (moduleTree, 1)
    assert get_non_exp_parent_and_index(moduleTree, bTree.body[0].body[0]) == \
        (bTree.body[0], 0)
    assert get_non_exp_parent_and_index(moduleTree,
                                        bTree.body[0].body[0].body[0]) == \
        (bTree.body[0].body[0], 0)

# Generated at 2022-06-21 18:47:13.247882
# Unit test for function find
def test_find():
    import astor
    from collections import namedtuple
    from typing import Iterable
    from typed_ast import ast3 as ast

    class Const:
        def __init__(self, value: str) -> None:
            self.value = value
            self.elts = []

        def __repr__(self) -> str:
            return 'Const(' + self.value + ')'

    class ConstInt(Const):
        pass

    class ConstStr(Const):
        pass

    class ConstList(Const):
        def __init__(self, value: str) -> None:
            super().__init__(value)
            self.elts = [ConstStr('a'), ConstInt('1'), Const('c')]


# Generated at 2022-06-21 18:47:21.519001
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..langs import PythonParser

    source = 'from test import *; z = c'
    tree = PythonParser.parse(source)
    imp = tree.body[0]
    assign = tree.body[1].value
    var = assign.left

    _build_parents(tree)

    assert get_closest_parent_of(tree, imp, ast.Module) == tree
    assert get_closest_parent_of(tree, var, ast.Assign) == assign
    assert get_closest_parent_of(tree, var, ast.Module) == tree

# Generated at 2022-06-21 18:47:26.846257
# Unit test for function find
def test_find():
    source = textwrap.dedent('''
        def factorial(n):
            """
            Calculate factorial of n.
            """
            if n == 0:
                return 1
            return n * factorial(n - 1)

        print(factorial(5))
    ''')
    tree = ast.parse(source)

    assert tuple(find(tree, ast.Str)) == (
        ast.Str(
            s="\n            Calculate factorial of n.\n            ",
            lineno=2,
            col_offset=12,
        ),
    )



# Generated at 2022-06-21 18:47:42.128999
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

# Generated at 2022-06-21 18:47:48.581246
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as ast
    tree = ast.parse('for i in range(10):\n    print(10)')
    for_parent = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert(isinstance(for_parent[0], ast.Module))
    assert(for_parent[1] == 0)
    

# Generated at 2022-06-21 18:47:55.551677
# Unit test for function insert_at
def test_insert_at():
    code = """
    def foo():
        pass
    """
    tree = ast.parse(code)

    expression = ast.Expr(value=ast.Str('Test'))
    insert_at(0, tree.body[0], expression)

    assert ast.dump(tree) == """
    Module(body=[
        FunctionDef(
            name='foo',
            args=arguments(
                args=[],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]),
            body=[Expr(value=Str(s='Test')), Pass()],
            decorator_list=[],
            returns=None)])
    """.lstrip()



# Generated at 2022-06-21 18:48:00.289138
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo(): pass')
    first_child = tree.body[0]
    funcdef = get_closest_parent_of(tree, first_child, ast.FunctionDef)
    assert funcdef.name == 'foo'



# Generated at 2022-06-21 18:48:03.285238
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Return type of node."""
    import sys
    import unittest
    import astor


# Generated at 2022-06-21 18:48:09.147406
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')

    assert tree == get_parent(tree, tree)
    assert tree == get_parent(tree, tree.body[0])
    assert tree.body[0] == get_parent(tree, tree.body[0].value)
    assert tree.body[0] == get_parent(tree, tree.body[0].targets[0])


# Generated at 2022-06-21 18:48:14.702037
# Unit test for function find
def test_find():
    tree = ast.parse("""
        def fun(a, b):
            pass
    """)

    functions = find(tree, ast.FunctionDef)
    function = next(functions)
    assert function.name == 'fun'

    functions = find(tree, ast.Name)
    function = next(functions)
    assert function.id == 'fun'

    assert list(find(tree, ast.Return)) == []



# Generated at 2022-06-21 18:48:26.291271
# Unit test for function get_parent
def test_get_parent():
    import astor
    import io
    class CodeSnippet(ast.AST):
        _fields = ('code',)

        def __init__(self, code: ast.AST) -> None:
            self.code = code

    code = "if True:\n\tprint('Hello world!')\n\t"
    module = ast.parse(code)

    for func in find(module, ast.FunctionDef):
        print(func)
        parent = get_parent(module, func)
        print(parent)
        print(type(parent))

        parent = get_parent(module, func.name)
        print(parent)
        print(type(parent))

        parent = get_parent(module, func.args)
        print(parent)
        print(type(parent))


# Generated at 2022-06-21 18:48:33.649897
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('if a: b')
    if_node = tree.body[0]
    module_node = tree
    b_node = if_node.body[0]

    if_parent = get_non_exp_parent_and_index(tree, if_node)[0]
    assert module_node == if_parent

    b_parent = get_non_exp_parent_and_index(tree, b_node)[0]
    assert if_node == b_parent


# Generated at 2022-06-21 18:48:34.659466
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert False

# Generated at 2022-06-21 18:48:47.219092
# Unit test for function insert_at

# Generated at 2022-06-21 18:48:55.465793
# Unit test for function replace_at
def test_replace_at():
    node_class_name = ast.Name(id='ClassName', ctx=ast.Load())
    node_class_definition = ast.ClassDef(
        name='ClassName',
        bases=[],
        keywords=[],
        starargs=None,
        kwargs=None,
        body=[
            ast.FunctionDef(
                name='func_in_class',
                args=ast.arguments(
                    args=[
                        ast.arg(arg='self', annotation=None)
                    ],
                    vararg=None,
                    kwonlyargs=[],
                    kw_defaults=[],
                    kwarg=None,
                    defaults=[]
                ),
                decorator_list=[],
                returns=None
            )
        ],
        decorator_list=[]
    )
    node_assign_class = ast

# Generated at 2022-06-21 18:49:04.091707
# Unit test for function find
def test_find():
    """Unit test for function find."""
    tree = ast.parse('for x in range(10): pass')
    for_loop = tree.body[0]
    assert len(list(find(tree, ast.For))) == 1
    assert next(find(tree, ast.For)) == for_loop
    assert next(find(tree, ast.expr)) == for_loop.iter
    assert len(list(find(tree, ast.expr))) == 3
    assert len(list(find(tree, ast.Call))) == 2
    assert len(list(find(tree, ast.Compare))) == 1


# Generated at 2022-06-21 18:49:12.064477
# Unit test for function get_parent
def test_get_parent():
    import inspect
    import astor

    a = 50
    b = 100

    source = inspect.getsource(a + b)
    tree = ast.parse(source)

    _build_parents(tree)
    assert _parents[tree.body[0].value.right] == tree.body[0]

    _build_parents(tree)

    assert _parents[get_parent(tree, tree.body[0].value.right)] == tree



# Generated at 2022-06-21 18:49:22.490860
# Unit test for function insert_at
def test_insert_at():
    """Unit test for function insert_at."""
    import astor
    tree1 = ast.parse("""def foo():
        x = 1
        print("")
        return 3
    """)
    tree2 = ast.parse("""def foo():
        x = 1
        print("")
        return 3
    """)
    insert_at(2, tree1.body[0], ast.parse("y = 2").body[0])  # type: ignore
    insert_at(2, tree2.body[0], ast.parse("y = 2").body[0])  # type: ignore
    insert_at(2, tree2.body[0], ast.parse("y = 2").body[0])  # type: ignore
    assert astor.to_source(tree1) == astor.to_source(tree2)


# Generated at 2022-06-21 18:49:30.094550
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def f():
        with open(__file__) as f:
            pass

    tree = ast.parse(inspect.getsource(f))
    with_node = get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                      ast.With)
    assert isinstance(with_node, ast.With)
    assert len(with_node.items) == 1
    assert isinstance(with_node.items[0], ast.withitem)
    assert len(with_node.items[0].context_expr.args) == 1
    assert with_node.items[0].context_expr.args[0].s == __file__



# Generated at 2022-06-21 18:49:33.643053
# Unit test for function find
def test_find():
    tree = ast.parse("""
        def f():
            return 1 + 2 * 3
    """)
    assert [node.left.n for node in find(tree, ast.BinOp)] == [1, 2]



# Generated at 2022-06-21 18:49:42.639726
# Unit test for function get_parent
def test_get_parent():
    
    import astor
    with open('../../tests/get_parent_test.py') as f:
        tree = ast.parse(f.read())

    # The test file contains five function call expressions.
    # For the three function call expressions that are not called
    # within the body of a function, the 'get_parent' function
    # should return a Module node.
    calls = find(tree, ast.Call)

    for call in calls:
        if get_parent(tree, call).__class__.__name__ == 'Module':
            continue
        else:
            raise AssertionError(
                "Test case failed. Node {0} should have parent node of type Module".format(astor.to_source(call, indent_with = ' ' * 4))
            )

    # Similarly, get_parent should return the correct

# Generated at 2022-06-21 18:49:47.228938
# Unit test for function insert_at
def test_insert_at():
    test_tree = ast.parse('from __future__ import print_function')
    insert_at(0, test_tree.body, ast.parse('import os'))
    assert test_tree.body[0].name == 'os' # type: ignore



# Generated at 2022-06-21 18:49:57.727236
# Unit test for function get_parent
def test_get_parent():
    assert(_parents == WeakKeyDictionary())
    tree = ast.parse('x = 1')
    assert(get_parent(tree, tree) is None)
    assert(_parents == WeakKeyDictionary())
    assert(get_parent(tree, tree) is None)
    assert(_parents != WeakKeyDictionary())
    assert(_parents[tree.body[0].value] is tree.body[0])
    assert(_parents[tree.body[0]] is tree.body)
    assert(_parents[tree] is None)
    _parents.clear()
    assert(_parents == WeakKeyDictionary())
    assert(get_parent(tree, tree) is None)
    assert(_parents != WeakKeyDictionary())