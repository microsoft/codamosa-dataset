

# Generated at 2022-06-21 18:41:58.946822
# Unit test for function insert_at
def test_insert_at():
    import astor
    # create a AST for a for loop
    for_stmt = ast.For(target=ast.Name(id='t', ctx=ast.Store()),  # type: ignore
                       iter=ast.Name(id='range', ctx=ast.Load()),
                       body=[ast.Pass()])
    body = [ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                    args=[ast.Str(s='Hello')], keywords=[])),
            for_stmt]
    module = ast.Module(body=body)
    print(astor.to_source(module))


# Generated at 2022-06-21 18:42:08.034897
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    code = """
if True:
    foo = True
    if True:
        bar = True
        if True:
            baz = True
    baz = True
"""
    foo_tree = ast.parse(code)
    bar_tree = foo_tree.body[0].body[1]
    baz_tree = bar_tree.body[1]
    baz_tree_baz = baz_tree.body[1]

    assert get_closest_parent_of(foo_tree, baz_tree, ast.If) == bar_tree
    assert get_closest_parent_of(foo_tree, baz_tree, ast.Module) == foo_tree

# Generated at 2022-06-21 18:42:15.541132
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """
        def foo():
            def bar(a):
                return a
            return bar(1)
        """

    module = ast.parse(code)
    bar_funcdef = module.body[0].body[0]

    assert get_closest_parent_of(module, bar_funcdef, ast.FunctionDef) == bar_funcdef
    assert get_closest_parent_of(module, bar_funcdef, ast.Module) == module

# Generated at 2022-06-21 18:42:16.274843
# Unit test for function replace_at

# Generated at 2022-06-21 18:42:23.614713
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class test_class_A:
        pass
    class test_class_B:
        pass
    class test_class_C:
        pass
    class test_class_D:
        pass
    class test_class_E:
        pass

    node = test_class_A()
    node.parent = test_class_B()
    node.parent.parent = test_class_C()
    node.parent.parent.parent = test_class_D()
    node.parent.parent.parent.parent = test_class_E()

    closest = get_closest_parent_of(node, node, test_class_C)
    assert(closest is node.parent.parent)


# Generated at 2022-06-21 18:42:28.167115
# Unit test for function insert_at
def test_insert_at():
    class Test(ast.AST):
        body = []

    tree = Test()
    tree.body.append(1)
    tree.body.append(2)

    insert_at(1, tree, 3)

    assert tree.body == [1, 3, 2]



# Generated at 2022-06-21 18:42:40.534059
# Unit test for function replace_at
def test_replace_at():
    import unittest
    import astor

    class TestReplaceAt(unittest.TestCase):

        def test_replace_at_1(self):
            inp = 'def f(): return 1'
            tree = ast.parse(inp)
            f = tree.body[0]
            r = ast.parse('return 2').body[0]

            replace_at(0, f, r)

            self.assertEqual('def f(): return 2', astor.to_source(tree))

        def test_replace_at_2(self):
            inp = 'def f(): return 1'
            tree = ast.parse(inp)
            f = tree.body[0]
            r = ast.parse('return 2').body[0]

# Generated at 2022-06-21 18:42:44.992596
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    root = ast.parse('''
    def foo(x):
         return x[5]
    ''')
    node = ast.parse('''
    x[5]
    ''')
    assert get_closest_parent_of(root, node, ast.Call) == root.body[0].body[0]

# Generated at 2022-06-21 18:42:56.083021
# Unit test for function replace_at
def test_replace_at():
    import astor
    def test_replace_at_same_level():
        root = ast.parse('[1, 2, 3]')
        # replace
        index, parent = get_non_exp_parent_and_index(root, root.body[0].elts[1])
        replace_at(index, parent, [ast.parse('print()').body[0]])
        assert astor.to_source(root) == '[\n    1,\n    print(),\n    3\n]'
        # insert
        index, parent = get_non_exp_parent_and_index(root, root.body[0].elts[1])
        insert_at(index, parent, [ast.parse('print()').body[0]])

# Generated at 2022-06-21 18:42:59.426848
# Unit test for function find
def test_find():
    assert list(find(ast.parse('''
    for i in range(10):
        pass
    '''), ast.For)) == [ast.parse('''
    for i in range(10):
        pass
    ''').body[0]]



# Generated at 2022-06-21 18:43:14.246337
# Unit test for function get_parent
def test_get_parent():
    ast_tree = ast.parse(textwrap.dedent("""
    def f(a, b):
        if a:
            return 1
        return 2
    """))

    _build_parents(ast_tree)
    assert isinstance(get_parent(ast_tree, ast_tree), type(None))
    assert isinstance(get_parent(ast_tree, ast.Module(body=[])), ast.Module)
    assert isinstance(get_parent(ast_tree,
                                 ast_tree.body[0].body[0].body[0].value.args[1]),
                      ast.Call)
    assert isinstance(get_parent(ast_tree,
                                 ast_tree.body[0].body[0].body[1].value.args[0]),
                      ast.Call)

# Generated at 2022-06-21 18:43:22.062007
# Unit test for function find
def test_find():
    import unittest

    class FindTest(unittest.TestCase):
        def test(self):
            tree1 = ast.parse('a = 1\nb = "2"\nc = list()')
            tree2 = ast.parse('if 1: pass\nif "1": break\nif list(): continue')

            self.assertEqual(len(list(find(tree1, ast.Name))), 3)
            self.assertEqual(len(list(find(tree2, ast.If))), 3)

    unittest.main()


# Generated at 2022-06-21 18:43:29.885568
# Unit test for function insert_at
def test_insert_at():
    mod = ast.parse("a=1")
    insert_at(0, mod, ast.Assign(targets=[ast.Name(id="b")], value=ast.Num(n=2)))
    assert ast.dump(mod) == "Module(body=[Assign(targets=[Name(id='b', ctx=Store())], value=Num(n=2)), Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1))])"



# Generated at 2022-06-21 18:43:31.948170
# Unit test for function get_parent

# Generated at 2022-06-21 18:43:38.299292
# Unit test for function find
def test_find():
    code = """
for i in range(3):
    print(i)
    """

    tree = ast.parse(code)
    names = list(find(tree, ast.Name))
    assert len(names) == 2
    assert names[0].id == "print"
    assert names[1].id == "range"



# Generated at 2022-06-21 18:43:42.011009
# Unit test for function get_parent
def test_get_parent():
    source = '''
a = 3
a
    '''

    tree = ast.parse(source)
    _build_parents(tree)

    assert get_parent(tree, tree.body[1].value) == tree.body[1].value



# Generated at 2022-06-21 18:43:50.196468
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("if True:\n    1 + 1\n    4 + 3")
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    replace_at(index, parent, ast.Expr(value=ast.Num(n=13)))

    assert ast.dump(tree) == \
'''Module(body=[If(test=NameConstant(value=True), body=[Expr(value=Num(n=13))], orelse=[])])'''  # noqa

# Generated at 2022-06-21 18:43:51.147769
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:43:52.111881
# Unit test for function get_parent

# Generated at 2022-06-21 18:43:59.714199
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .test_cases import get_test_tree_1
    tree = get_test_tree_1()
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert index == 0, "index should be 0"
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert index == 0, "index should be 0"
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])
    assert index == 1, "index should be 1"
    parent, index = get_non_exp_parent_and_index(
        tree, tree.body[0].body[2].body[0])

# Generated at 2022-06-21 18:44:08.703988
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('[a, b, c]')
    _build_parents(tree)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].value), ast.Expr)
    assert isinstance(get_parent(tree, tree.body[0].value.elts[0]),
                      ast.List)


# Generated at 2022-06-21 18:44:11.357841
# Unit test for function replace_at

# Generated at 2022-06-21 18:44:17.105153
# Unit test for function insert_at
def test_insert_at(): # type: ignore
    import astor
    from astor import codegen

    c = ast.parse("for i in l: print i")
    insert_at(0, c.body, ast.Expr(ast.Num(0)))
    # for i in l:
    #     0
    #     print i
    assert astor.to_source(c) == 'for i in l:\n    0\n    print i'



# Generated at 2022-06-21 18:44:23.985373
# Unit test for function find
def test_find():
    from .testing import run_test
    from .types import FunctionDef, Assign, Name, Num

    function_node = FunctionDef("f", [], [
        Assign([Name("a")], [Num(1)])
    ])

    final_tree = run_test("f = 1", function_node)

    assert len(list(find(final_tree, FunctionDef))) == 1
    assert len(list(find(final_tree, Assign))) == 1
    assert len(list(find(final_tree, Name))) == 2
    assert len(list(find(final_tree, Num))) == 1

# Generated at 2022-06-21 18:44:25.432113
# Unit test for function get_parent

# Generated at 2022-06-21 18:44:31.702849
# Unit test for function find
def test_find():
    """test_find."""
    tree = ast.parse('a = 1 + 2 + 3')
    fns = find(tree, ast.FunctionDef)
    assert len(list(fns)) == 0
    adds = find(tree, ast.AugAssign)
    assert len(list(adds)) == 0
    assign = find(tree, ast.Assign)
    assert len(list(assign)) == 1



# Generated at 2022-06-21 18:44:37.686722
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("[1, 2, 3]")
    node = next(find(tree, ast.Num))
    parent, index = get_non_exp_parent_and_index(tree, node)
    replace_at(index, parent, ast.List([ast.Num(0)]))
    assert ast.dump(tree) == "[0, 2, 3]"

# Generated at 2022-06-21 18:44:40.708432
# Unit test for function get_parent
def test_get_parent():
    from typed_ast import parse
    node = parse("2 + 3")
    parent = get_parent(node, node.body[0])
    assert (repr(parent) == repr(node))

# Generated at 2022-06-21 18:44:44.147726
# Unit test for function find
def test_find():
    src = """
if False:
    pass

if True:
    pass
"""
    tree = ast.parse(src)
    assert src.count('if') == len([*find(tree, ast.If)])



# Generated at 2022-06-21 18:44:54.651270
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # type: () -> None
    """Testing get_non_exp_parent_and_index function"""
    tree = ast.parse("""
        def foo():
            pass
        foo()
        foo()
        def bar():
            pass
    """)
    foo = tree.body[0]
    foo_exp = tree.body[1]
    foo_exp2 = tree.body[2]
    bar = tree.body[3]
    func_defs = tree.body[1:]

    assert get_non_exp_parent_and_index(tree, foo) == (tree, 0)
    assert get_non_exp_parent_and_index(tree, foo_exp) == (tree, 1)
    assert get_non_exp_parent_and_index(tree, foo_exp2) == (tree, 2)

# Generated at 2022-06-21 18:45:18.911585
# Unit test for function insert_at
def test_insert_at():
    insert_at(1, 0, [])

# Generated at 2022-06-21 18:45:21.881719
# Unit test for function find
def test_find():
    # find()

    # try:
    #     ast.parse("s = 12")
    # except:
    #     pass
    pass


# Generated at 2022-06-21 18:45:26.723384
# Unit test for function find
def test_find():
    """Check if find works as expected."""
    import typed_astunparse
    tree = typed_astunparse.ast3.parse('def x():\n    pass').body[0]
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.arguments))) == 1

# Generated at 2022-06-21 18:45:32.539412
# Unit test for function find
def test_find():
    from astor import codegen
    with open('test_files/test_find.py', 'r') as f:
        source = f.read()
    tree = ast.parse(source)
    result = []
    for node in find(tree, ast.Name):
        result.append(node.id)
    assert result == ['Num', 'num']


# Generated at 2022-06-21 18:45:40.586903
# Unit test for function find
def test_find():
    tree = ast.parse("""
    if True:
        a = 5
    elif False:
        if True:
            a = 5
        elif False:
            if True:
                a = 5
            elif False:
                if True:
                    a = 5
                elif False:
                    a =2
    """)
    result = find(tree, ast.If)
    cnt = 0
    for node in result:
        if(type(node) == ast.If):
            cnt +=1
    assert cnt == 5


# Generated at 2022-06-21 18:45:46.323101
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('f = lambda x: x').body[0].value.args[0]
    parent, index = get_non_exp_parent_and_index(node.parent, node)
    assert index == 2
    assert parent.body[2] == node
    node = ast.parse('f = lambda x: x').body[0]
    parent, index = get_non_exp_parent_and_index(node.parent, node)
    assert index == 0
    assert parent.body[0] == node

# Generated at 2022-06-21 18:45:56.056807
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("if a: b\nelif c: d\nelse: e")

    node = tree.body[0]
    parent = get_parent(tree, node, rebuild=True)

    assert parent is tree
    assert node is parent.body[0]

    node = node.orelse[0].body[0]
    parent = get_parent(tree, node)

    assert parent is tree
    assert node is parent.body[0].orelse[0].body[0]

    node = node.body[0]
    parent = get_parent(tree, node)

    assert parent is node.body[0].body[0]
    assert node is parent.body[0]



# Generated at 2022-06-21 18:46:05.647379
# Unit test for function find
def test_find():
    from .ast_generators import fake_source
    import unittest
    import inspect

    class TestFind(unittest.TestCase):
        def setUp(self):
            self.tree = ast.parse(fake_source)

        def test_find(self):
            is_error_class_visited = False
            is_error_function_visited = False

            for n in find(self.tree, ast.ClassDef):
                if n.name == 'Error':
                    is_error_class_visited = True

            for n in find(self.tree, ast.FunctionDef):
                if n.name == 'error':
                    is_error_function_visited = True

            self.assertTrue(is_error_class_visited)
            self.assertTrue(is_error_function_visited)

   

# Generated at 2022-06-21 18:46:14.171077
# Unit test for function get_parent
def test_get_parent():
    # tree = """
    #     def func():
    #         with open('file') as f:
    #             return f.read()
    # """
    # tree_ast = ast.parse(tree)
    # read = find(tree_ast, ast.Call).next()
    # Read parent: 'return f.read()'
    # print(ast.dump(get_parent(tree_ast, read)))
    tree = """
        def func():
            with open('file') as f:
                x = f.read()
    """
    tree_ast = ast.parse(tree)
    read = find(tree_ast, ast.Call).next()
    x = find(tree_ast, ast.Name).next()
    # Read parent: 'x = f.read'

# Generated at 2022-06-21 18:46:20.945480
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test = ast.parse("""
                    if True:
                        a = 3.0
                    """)
    # Get the expression '3.0'
    expr_3 = test.body[0].body[0].value

    # Get the parent and it's index
    parent, index = get_non_exp_parent_and_index(test, expr_3)

    assert type(parent) == ast.If
    assert index == 0


# Generated at 2022-06-21 18:47:53.070105
# Unit test for function get_parent
def test_get_parent():

    class A(ast.AST):
        def __init__(self, path_elements):
            self.path_elements = path_elements


    class B(ast.AST):
        def __init__(self, element):
            self.element = element


    class E(ast.AST):
        def __init__(self, path_elements, element):
            self.path_elements = path_elements
            self.element = element

    a = A([ast.Name(id='a', ctx=ast.Load()), ast.Name(id='b', ctx=ast.Load())])
    b = B(ast.Name(id='c', ctx=ast.Load()))

# Generated at 2022-06-21 18:48:06.003025
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.Module()

# Generated at 2022-06-21 18:48:07.695985
# Unit test for function find
def test_find():
    tree = ast.parse('import abc', mode='exec')
    for node in find(tree, ast.Import):
        assert type(node) is ast.Import

# Generated at 2022-06-21 18:48:17.316995
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_module = ast.parse("""
    def hello():
        print('hello')
        if True:
            return 'hello'
        print('hello')
    """)
    assert 'Module' == get_closest_parent_of(test_module,
                                             test_module.body[0],
                                             ast.Module).__class__.__name__
    assert 'FunctionDef' == get_closest_parent_of(
        test_module, test_module.body[0], ast.FunctionDef).__class__.__name__
    assert 'FunctionDef' == get_closest_parent_of(
        test_module, test_module.body[0].body[0], ast.FunctionDef).__class__.__name__

# Generated at 2022-06-21 18:48:27.537134
# Unit test for function insert_at
def test_insert_at():
    class Foo:
        pass
    class Bar:
        pass
    tree = ast.Module(body=[
        Foo(),
        Foo(),
        Foo(),
        Foo(),
        Bar(),
        ])
    insert_at(2, tree, Bar())
    assert isinstance(tree.body[3], Bar)
    insert_at(3, tree, Bar())
    assert isinstance(tree.body[4], Bar)
    insert_at(4, tree, Bar())
    assert isinstance(tree.body[5], Bar)
    insert_at(1, tree, Bar())
    assert isinstance(tree.body[2], Bar)
    # TODO: Fix this
    #with pytest.raises(IndexError):
    #    insert_at(10, tree, Bar())


# Generated at 2022-06-21 18:48:39.008113
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    def test_function():
        a = 10
        b = a + 2
        c = a * 2
        if a > b:
            d = a - b
        return d

    module = ast.parse(test_function.__code__.co_code)

    func_def = next(find(module, ast.FunctionDef))
    assert func_def is get_closest_parent_of(module, func_def.body[1], ast.FunctionDef)
    assert func_def is get_closest_parent_of(module, func_def.body[4], ast.FunctionDef)

    if_body = next(find(func_def, ast.If))

# Generated at 2022-06-21 18:48:45.853332
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ...test_utils import ExecutionResult
    from . import node_utils as nu

    tree = ExecutionResult('def func():\n    a = 2 + 3\n    b = 4').get_tree()
    nodes = find(tree, ast.Name)
    names = sorted(nodes, key=lambda n: n.id)
    assert names[0].id == 'a'
    assert names[1].id == 'b'
    assert names[2].id == 'func'
    assert names[3].id == 'nu'

    parent, index = nu.get_non_exp_parent_and_index(tree, names[0])
    assert nu.get_node_text(parent) == 'def func():\n    a = 2 + 3\n    b = 4'
    assert index == 1


# Generated at 2022-06-21 18:48:50.260664
# Unit test for function find
def test_find():
    source = '''
            def foo():
                pass

            def bar():
                pass
            '''

    tree = ast.parse(source)
    node = find(tree, ast.FunctionDef).next()
    assert node.name == 'foo'



# Generated at 2022-06-21 18:48:55.080139
# Unit test for function insert_at
def test_insert_at():
    import typed_ast
    from typed_ast import ast3 as ast

    tree = typed_ast.parse("""
    def test():
        if True:
            print("hello")
    """, parse_method='single')
    insert_at(1, tree.body[0], ast.Expr(value=ast.Num(n=5)))
    insert_at(1, tree.body[0], ast.Expr(value=ast.Num(n=5)))

# Generated at 2022-06-21 18:48:58.391318
# Unit test for function find
def test_find():
    source = "print('Hello World')"
    tree = ast.parse(source)
    nodes = list(find(tree, type_=ast.Str))

    assert len(nodes) == 1
    assert nodes[0].s == 'Hello World'

    nodes = list(find(tree, type_=ast.Name))

    assert len(nodes) == 1
    assert nodes[0].id == 'print'

