

# Generated at 2022-06-21 18:41:41.689126
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        body = []
    class B(ast.AST):
        pass

    a = A()
    a.body.append(B())
    a.body.append(B())
    a.body.append(B())
    a.body.append(B())
    insert_at(1, a, B())
    print(1, len(a.body))


# Generated at 2022-06-21 18:41:42.969019
# Unit test for function get_parent
def test_get_parent():
    import astunparse

# Generated at 2022-06-21 18:41:54.862381
# Unit test for function replace_at
def test_replace_at():
    parent = ast.FunctionDef(name='func', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]), body=[
        ast.Return(value=ast.BinOp(left=ast.Num(n=1), op=ast.Add(), right=ast.Num(n=2))),
        ast.Return(value=ast.BinOp(left=ast.Num(n=2), op=ast.Add(), right=ast.Num(n=1)))
    ], decorator_list=[])
    assert parent.body[0].value.right.n == 2
    assert parent.body[1].value.left.n == 2

# Generated at 2022-06-21 18:41:59.262734
# Unit test for function insert_at
def test_insert_at():
    def foo(): pass
    tree = ast.parse(inspect.getsource(foo))
    insert_at(0, tree.body[0], [ast.Assign([ast.Name('x', ast.Store())],
                                           ast.Num(10))])
    assert ast.dump(tree) == 'def foo():\n  x = 10\n  pass'

# Generated at 2022-06-21 18:42:02.349781
# Unit test for function insert_at
def test_insert_at():
    # insert_at(index: int, parent: ast.AST,
    #           nodes: Union[ast.AST, List[ast.AST]])
    # TODO: Unit test for insert_at
    assert True

# Generated at 2022-06-21 18:42:03.281734
# Unit test for function get_parent

# Generated at 2022-06-21 18:42:08.945650
# Unit test for function replace_at
def test_replace_at():
    parent = ast.FunctionDef('f', ast.arguments(args=[], vararg=None,
                                                kwonlyargs=[], kw_defaults=[],
                                                kwarg=None, defaults=[]), [], [],
                             None)
    node = ast.Return(value=ast.Num(n=1))

    parent.body = [node]

    assert parent.body[0] == node

    replace_at(0, parent, ast.Num(n=2))

    assert isinstance(parent.body[0], ast.Num)

# Generated at 2022-06-21 18:42:20.481479
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Assign(
        targets=[ast.Name("a", ast.Store())], value=ast.Num(n=2))   # type: ast.AST # noqa
    module = ast.Module(body=[node])
    _, index = get_non_exp_parent_and_index(module, node)
    assert index == 0

    node = ast.ImportFrom(module="a", names=[ast.alias(name="b", asname="c")])   # noqa
    module = ast.Module(body=[node])
    _, index = get_non_exp_parent_and_index(module, node)
    assert index == 0

    node = ast.Return(value=ast.Num(n=2))
    func = ast.FunctionDef("f", body=[node])

# Generated at 2022-06-21 18:42:25.048866
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert ast.parse('a = 1').body[0] == get_non_exp_parent_and_index(
        ast.parse('a = 1'),
        ast.parse('a = 1').body[0].value  # type: ignore
    )[0].body[0]

# Generated at 2022-06-21 18:42:30.587033
# Unit test for function replace_at
def test_replace_at():
    ast_tree = ast.parse("a = 1")
    funcdef = get_closest_parent_of(ast_tree, ast_tree.body[0], ast.FunctionDef)
    replace_at(0, funcdef, ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
               value=ast.Constant(value=1, kind=None)))

# Generated at 2022-06-21 18:42:37.859481
# Unit test for function find
def test_find():
    find(ast.parse("def foo(): pass"), ast.FunctionDef)



# Generated at 2022-06-21 18:42:45.942600
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Test get closest parent of."""
    tree = ast.parse("""
        def foo():
            if x > 0:
                x = 1
            else:
                x = 2
    """)
    if_stmt = tree.body[0].body[0]
    else_stmt = if_stmt.orelse[0]
    assert get_closest_parent_of(tree, if_stmt.test, ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, else_stmt.body[0].value, ast.FunctionDef) == tree.body[0]



# Generated at 2022-06-21 18:42:46.969550
# Unit test for function replace_at

# Generated at 2022-06-21 18:42:47.973673
# Unit test for function replace_at
def test_replace_at():
    # TODO: add unit tests
    pass

# Generated at 2022-06-21 18:42:58.629549
# Unit test for function replace_at
def test_replace_at():
    def f(x):
        if x == 1:
            return 2
        else:
            return 3
    tree = ast.parse(inspect.getsource(f))
    print(ast.dump(tree))
    if_node = get_closest_parent_of(tree, tree.body[0], ast.If)
    print(ast.dump(if_node))
    replace_at(1, if_node, [ast.parse('return 4').body[0]])
    print(ast.dump(tree))
    print(ast.dump(if_node))
    print(ast.dump(get_non_exp_parent_and_index(tree, if_node)))
    print(ast.dump(ast.Return()))


if __name__ == '__main__':
    test_replace_at()

# Generated at 2022-06-21 18:42:59.508866
# Unit test for function get_parent

# Generated at 2022-06-21 18:43:03.528757
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = '''
            def test_func(a):
                return a
            '''
    tree = ast.parse(code)
    node = next(find(tree, ast.Num))

    non_exp_parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(non_exp_parent, ast.FunctionDef)
    assert index == 2



# Generated at 2022-06-21 18:43:08.889050
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
        class A:
            class B(object):
                c = B()
                def d():
                    pass
    """, mode='exec')
    _build_parents(tree)
    b = get_parent(tree, _parents[tree.body[0].body[1].value], False)
    assert isinstance(b, ast.ClassDef)

# Generated at 2022-06-21 18:43:14.349281
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_tree = ast.parse("def foo():\n    a = 1\n    b = 2\n")
    assert get_non_exp_parent_and_index(test_tree,
                                        test_tree.body[0].body[0].targets[0]) == (
        test_tree.body[0], 1)

# Generated at 2022-06-21 18:43:15.800911
# Unit test for function insert_at
def test_insert_at():
    import astor

# Generated at 2022-06-21 18:43:23.446706
# Unit test for function get_parent
def test_get_parent():
    """To test get_parent() function."""
    import astor

# Generated at 2022-06-21 18:43:29.133438
# Unit test for function replace_at
def test_replace_at():
    import astor
    test_tree = ast.parse("a = 1 + 1")
    test_parent = test_tree.body[0]
    test_body = test_parent.value
    test_nodes = ast.parse("b").body
    replace_at(1, test_body, test_nodes)
    print(astor.to_source(test_tree))

# Generated at 2022-06-21 18:43:40.397177
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('a + 2')
    two = tree.body[0].value.right
    a = tree.body[0].value.left
    plus = tree.body[0].value
    binop_expr = tree.body[0].value
    add_stmt  = tree.body[0]
    mod = tree.body[0]
    module = tree
    assert(get_closest_parent_of(tree, two, ast.Module) == module)
    assert(get_closest_parent_of(tree, plus, ast.Module) == module)
    assert(get_closest_parent_of(tree, binop_expr, ast.Module) == module)
    assert(get_closest_parent_of(tree, add_stmt, ast.Module) == module)
   

# Generated at 2022-06-21 18:43:51.662975
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:43:55.834687
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astunparse
    my_ast = ast.parse('a + b * c / d')

    if (type(get_closest_parent_of(my_ast, my_ast.body[0].value.left, ast.BinOp))
            != ast.BinOp):
        raise Exception('BinOp not found')

# Generated at 2022-06-21 18:44:08.498735
# Unit test for function find
def test_find():
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                print("Error in " + func.__name__ + ": " + str(e))

        return wrapper

    @decorator
    def test_find_exact_match():
        node = ast.parse("a + 2 + b", mode='eval').body
        a_node = find(node, ast.Name).__next__()
        assert a_node.id == 'a'

    @decorator
    def test_find_more_results():
        node = ast.parse("a + 2 + b", mode='eval').body
        assert len(list(find(node, ast.Num))) == 2


# Generated at 2022-06-21 18:44:14.036808
# Unit test for function get_parent
def test_get_parent():
    sample_tree = ast.parse("""
if True:
    print("test")
    """)

    node = sample_tree.body[0].body[0]

    parent = get_parent(sample_tree, node)

    assert isinstance(parent, ast.If)



# Generated at 2022-06-21 18:44:18.781045
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Name("x_test", ast.Load())
    upper = ast.Expr(node)
    lower = ast.Name("x_test_lower", ast.Load())
    parent, index = get_non_exp_parent_and_index(upper, node)
    assert(isinstance(parent, ast.Expr))
    assert(index == 0)


# Generated at 2022-06-21 18:44:26.781002
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:44:27.944668
# Unit test for function get_parent

# Generated at 2022-06-21 18:44:45.550100
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    mod = ast.parse("""
        def f(x):
            if x == 0:
                for y in range(0):
                    pass
            elif x == 1:
                for y in range(1):
                    pass
            else:
                pass
        """)
    lst = list(ast.walk(mod))
    for node in lst:
        if isinstance(node, ast.If):
            nearest_if = get_closest_parent_of(mod, node, ast.If)
            print(node, nearest_if)
            assert node == nearest_if

test_get_closest_parent_of()

# Generated at 2022-06-21 18:44:51.102395
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def test_func():\n\ta = 1\n\tb = a +3\n')
    node = tree.body[0].body[1].value.left
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)



# Generated at 2022-06-21 18:44:59.079664
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    s = """def foo():
        for i in range(10):
            for j in range(10):
                pass
    """
    tree = ast.parse(s)
    astor.to_source(tree)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0].body[0], ast.For), ast.For), \
        'Failed to get the parent'

# Generated at 2022-06-21 18:45:04.835196
# Unit test for function find
def test_find():
    node = ast.parse(
        '''def f():
        if True:
            print('a')
        elif True:
            print('b')
        else:
            print('c')
        '''
    )
    ifs = list(find(node, ast.If))
    assert len(ifs) == 2



# Generated at 2022-06-21 18:45:10.683472
# Unit test for function get_parent
def test_get_parent():
    ast.parse('def func(a: int):\n    a =  1\n    b = 2\n    print(a)')
    ast.parse('def func(a: int):\n    a =  1\n    b = 2\n    print(a)')
    ast.parse('def func(a: int):\n    a =  1\n    b = 2\n    print(a)')


# Generated at 2022-06-21 18:45:19.401130
# Unit test for function insert_at
def test_insert_at():
    import typed_astunparse
    import astunparse

    code_str = '''
import os
str = "str"
'''
    tree = typed_astunparse.ast3.parse(code_str)
    f = tree.body[0]
    assign = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                        value=ast.Name(id='str', ctx=ast.Load()))
    insert_at(0, f.body, assign)
    print(astunparse.unparse(tree))


# Generated at 2022-06-21 18:45:24.263577
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor

    program = '''
    def foo():
        if 1 == 0:
            print('foo')
        elif 1 == 0:
            print('foo')
        else:
            print('foo')
    '''
    tree = ast.parse(program)
    _build_parents(tree)

    first_elif = tree.body[0].body.body[1]
    parent, index = get_non_exp_parent_and_index(tree, first_elif)
    print(astor.to_source(parent))

    # expecting to replace first elif with print
    replace_at(index, parent, ast.parse('print("Hi")').body[0])
    print(astor.to_source(tree))


test_get_non_exp_parent_and_index()

# Generated at 2022-06-21 18:45:29.371445
# Unit test for function replace_at
def test_replace_at():
    mod = ast.parse('a = 0')
    a_assign = mod.body[0]
    assert isinstance(a_assign, ast.Assign)
    mod.body.pop(0)
    new_assign = ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())],
                            value=ast.Num(n=0))
    insert_at(0, mod, new_assign)
    assert mod.body[0].targets[0].id == 'b'

# Generated at 2022-06-21 18:45:39.869611
# Unit test for function find
def test_find():
    from typed_ast import ast3

    tree = ast3.parse("""
        a = 'asd'
        b = a
    """)

    nodes = find(tree, ast3.Assign)
    assert len(list(nodes)) == 2

    assert list(nodes)[0].targets == [ast3.Name(id='a',
                                                ctx=ast3.Store())]
    assert list(nodes)[0].value == ast3.Str(s='asd')
    assert list(nodes)[1].targets == [ast3.Name(id='b',
                                                ctx=ast3.Store())]
    assert list(nodes)[1].value == ast3.Name(id='a',
                                             ctx=ast3.Load())

# Generated at 2022-06-21 18:45:43.526395
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def fun(x): pass
    func_node = ast.parse(fun.__code__.co_code).body[0]
    assert isinstance(get_closest_parent_of(func_node, func_node, ast.Module), ast.Module)

# Generated at 2022-06-21 18:46:17.438662
# Unit test for function get_parent
def test_get_parent():
    from ..coconut import CoconutTransformer
    from astunparse import unparse
    tree = ast.parse('''
    def a():
        def b():
            return
            d()
        c = 1
    ''')
    trans = CoconutTransformer()
    trans.visit(tree)
    assert unparse(get_parent(tree, tree.body[0].body[0].body[0])) == 'def b():'
    assert unparse(get_parent(tree, tree.body[0].body[1].value)) == 'c = 1'



# Generated at 2022-06-21 18:46:27.102382
# Unit test for function replace_at
def test_replace_at():
    original = ast.parse('1\n2\n3\n4\na')
    modified = ast.parse('1\n2\n4\na')

    replace_at(2, original, [ast.parse('3\n')])
    assert ast.dump(modified) == ast.dump(original)

    replace_at(1, original, [ast.parse('2\nb\n')])
    assert ast.dump(modified) != ast.dump(original)

    original = ast.parse('1\n2\n3\n4\na')
    replace_at(2, original, [ast.parse('1')])
    print(ast.dump(original))

# Generated at 2022-06-21 18:46:28.504783
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Unit test function for get_closest_parent_of"""
    pass


# Generated at 2022-06-21 18:46:40.323351
# Unit test for function insert_at
def test_insert_at():
    # import ast
    root = ast.parse("""
    i = 0 if True else 1
    j = i
    """)

    # Replace if statement with assignment
    stmt = root.body[0]  # type: ignore
    insert_ast = ast.Assign(targets=[stmt.target], value=stmt.value.body)
    insert_at(index=0, parent=root, nodes=insert_ast)

    assert ast.dump(root) == "Module(body=[Assign(targets=[Name(id='i', ctx=Store())], value=Num(n=0)), Assign(targets=[Name(id='j', ctx=Store())], value=Name(id='i', ctx=Load()))])"



# Generated at 2022-06-21 18:46:46.840714
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
        def foo():
            pass

        def bar():
            pass
    ''')
    # Tree contains two function definitions.
    # First function definition is the parent of second function definition.
    # First function definition is the child of the module.
    # Second function definition is the child of the module.
    # The target node is the second function definition.
    target_node = find(tree, ast.FunctionDef).__next__()
    non_exp_parent, index = get_non_exp_parent_and_index(tree, target_node)
    assert isinstance(non_exp_parent, ast.Module)
    assert index == 1

# Generated at 2022-06-21 18:46:48.508624
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:46:58.990232
# Unit test for function replace_at
def test_replace_at():
    class Test(ast.AST):
        def __init__(self, num: int):
            self.num = num

    tree = Test(0)
    insert_at(0, tree, [Test(1), Test(2), Test(3), Test(4), Test(5)])
    insert_at(0, tree, [Test(10), Test(20), Test(30), Test(40)])
    insert_at(1, tree, [Test(100), Test(200), Test(300)])
    assert tree.num == 0
    assert tree.body[0].num == 10
    assert tree.body[1].num == 100
    assert tree.body[2].num == 200
    assert tree.body[3].num == 300
    assert tree.body[4].num == 20

# Generated at 2022-06-21 18:47:02.237025
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('while True: pass')
    assert type(get_closest_parent_of(tree, tree.body[0].body[0], ast.While)) == ast.While

# Generated at 2022-06-21 18:47:07.949987
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent."""
    node = ast.parse('x + y')
    assert get_parent(node, node.body[0].value) == node.body[0]

    node = ast.parse('if True:\n    x + y')
    assert get_parent(node, node.body[0][0].value) == node.body[0][0]

    node = ast.parse('if True:\n    x + y')
    assert get_parent(node, node.body[0][0]) == node.body[0]

    node = ast.parse('class Foo(Bar):\n    x + y')
    assert get_parent(node, node.body[0][0].value) == node.body[0][0]


# Generated at 2022-06-21 18:47:15.723475
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    check_non_exp_parent_and_index(None, None)
    check_non_exp_parent_and_index(
        ast.If(test=ast.Num(1),
               body=[ast.Expr(ast.Num(2))],
               orelse=[ast.Expr(ast.Num(3)), ast.Expr(ast.Num(4))]),
        (ast.If(test=ast.Num(1),
                body=[ast.Expr(ast.Num(2))],
                orelse=[ast.Expr(ast.Num(3)), ast.Expr(ast.Num(4))]),
         0))

# Generated at 2022-06-21 18:48:16.216738
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class TestClass(ast.AST):
        _fields = ('body',)  # type: Tuple[str, ...]

        def __init__(self) -> None:
            self.body = []

    class TestClass2(ast.AST):
        _fields = ('test',)  # type: Tuple[str, ...]

        def __init__(self) -> None:
            self.test = None

    class TestClass3(ast.AST):
        _fields = ('test',)  # type: Tuple[str, ...]

        def __init__(self) -> None:
            self.test = None

    class TestClass4(ast.AST):
        _fields = ('test',)  # type: Tuple[str, ...]

        def __init__(self) -> None:
            self.test = None



# Generated at 2022-06-21 18:48:27.030960
# Unit test for function get_parent
def test_get_parent():
    assert not _parents

    tree = ast.parse('def fun(a, b):\n    c = a + b')
    child = tree.body[0].args.args[0]
    expected = tree.body[0]
    actual = get_parent(tree, child)

    assert actual == expected
    assert _parents[child] == expected

    # Delete from global dictionary to prevent from side effects
    del _parents[child]

    tree = ast.parse('class A: pass')
    child = tree.body[0]
    expected = tree
    actual = get_parent(tree, child)

    assert actual == expected
    assert _parents[child] == expected

    # Delete from global dictionary to prevent from side effects
    del _parents[child]


# Generated at 2022-06-21 18:48:35.882589
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Foo:
        def __init__(self, a: int):
            self.a = a + 3


    class Bar:
        def __init__(self, a: str):
            self.a = a + " bar"

    s = ast.parse(inspect.getsource(Foo) + inspect.getsource(Bar))
    class_def = list(ast.walk(s))[1]
    parent_of_class_def = get_closest_parent_of(s, class_def, ast.FunctionDef)
    assert isinstance(parent_of_class_def, ast.FunctionDef)

# Generated at 2022-06-21 18:48:40.745736
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import textwrap

    s = textwrap.dedent('''
    def func():
        a = list(b, c)
    ''')
    tree = ast.parse(s)
    _build_parents(tree)
    a = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.Call)
    assert a.func.id == 'list'



# Generated at 2022-06-21 18:48:51.240329
# Unit test for function replace_at
def test_replace_at():
    code = '''
while True:
    pass
else:
    pass
    '''
    tree = ast.parse(code)
    func_def = tree.body[0]  # type: ignore
    body = func_def.body  # type: ignore
    pass_stmnt = body.pop()
    body.append(pass_stmnt)
    assert(ast.dump(tree) == ast.dump(ast.parse(code)))
    pass_stmnt = find(tree, ast.Pass).__next__()
    parent, index = get_non_exp_parent_and_index(tree, pass_stmnt)
    replace_at(index, parent, 5)
    assert(ast.dump(tree) == ast.dump(ast.parse(code)))



# Generated at 2022-06-21 18:48:54.830744
# Unit test for function replace_at
def test_replace_at():
    class MyClass(ast.AST):
        line_info = None

    node = MyClass(lineno=0, col_offset=0)
    parent = MyClass(lineno=1, col_offset=0, body=[node])

    replace_at(0, parent, MyClass(lineno=2, col_offset=0))

    assert parent.body[0].lineno == 2

# Generated at 2022-06-21 18:49:04.991523
# Unit test for function replace_at
def test_replace_at():

    tree = ast.parse(
        '''
        class A:
            def a(self):
                pass
            def b(self):
                pass
        '''
    )

    nodes = [ast.parse(
        '''
        def a(self):
            pass

        def b(self):
            pass
        '''
    ).body]

    replace_at(0, tree.body[0], nodes)

    assert ast.dump(tree) == ast.dump(ast.parse(
        '''
        class A:
            def a(self):
                pass

            def b(self):
                pass

            def a(self):
                pass

            def b(self):
                pass
        '''
    ))

# Generated at 2022-06-21 18:49:15.614157
# Unit test for function insert_at
def test_insert_at():
    class A(ast.AST):
        num = 123
        _fields = ('num',)

    class B(ast.AST):
        num = 789
        _fields = ('num',)

    class C(ast.AST):
        body = [A(), B(), A()]
        _fields = ('body',)

    c = C()
    insert_at(1, c, [A(), B()])
    assert c.body[0].num == 123
    assert c.body[1].num == 123
    assert c.body[2].num == 789
    assert c.body[3].num == 789
    assert c.body[4].num == 123

# Generated at 2022-06-21 18:49:24.302292
# Unit test for function replace_at
def test_replace_at():
    # Create tree
    tree = ast.parse("""
foo = 1
bar = "baz"
qux = [1, 2, 3]
func(
    val=1,
    kwd=2
)
""")

    # Replace foo with bar
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    replace_at(index, parent, tree.body[1])

    # Assert bar is at first index
    assert "bar = \"baz\"" in ast.dump(tree, include_attributes=False)

    # Add qux
    parent, index = get_non_exp_parent_and_index(tree, tree.body[2])
    insert_at(index, parent, tree.body[1])

    # Assert bar and qux are at first

# Generated at 2022-06-21 18:49:31.734364
# Unit test for function get_parent
def test_get_parent():
    import astor

    with open('test/test_code.py') as test_code:
        code = test_code.read()

    tree = ast.parse(code)

    parent = get_parent(tree, tree.body[1])
    assert astor.to_source(parent) == 'def function():\n\n'

    parent = get_parent(tree, tree.body[1].body[0])
    assert astor.to_source(parent) == 'def function():\n\n'

    parent = get_parent(tree, tree.body[1].body[0].value)
    assert astor.to_source(parent) == 'def function():\n\n'

    parent = get_parent(tree, tree.body[1].body[0].value.elts[0])