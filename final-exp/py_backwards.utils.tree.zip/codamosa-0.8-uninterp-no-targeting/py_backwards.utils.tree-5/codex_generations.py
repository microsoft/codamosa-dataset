

# Generated at 2022-06-21 18:41:51.676718
# Unit test for function replace_at
def test_replace_at():
    code = '''if 1:
    a = 3
    b = 4
'''
    tree = ast.parse(code)
    if_node = tree.body[0]
    asgn_node_1 = if_node.body[0]
    asgn_node_2 = if_node.body[1]

    # replace first assignment with other
    replace_at(0, if_node, asgn_node_2)
    assert ast.dump(if_node) == 'If(None, [Assign([Name(a, Load())], Num(4)), Num(4)], [])'

    # replace second assignment with sum of all assignments
    replace_at(0, if_node, ast.parse('a = 3 + 4').body[0])

# Generated at 2022-06-21 18:41:54.721548
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse("a = 1 + 3")
    parent = get_parent(node, node.body[0].value)
    assert parent == node.body[0]



# Generated at 2022-06-21 18:42:00.750293
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module = ast.parse('def f():\n    for a in [1, 2]:\n        print(a)')
    stmt_for = module.body[0].body[0]
    stmt_for.lineno = 3

    parent = get_closest_parent_of(module, stmt_for, ast.For)
    assert parent is stmt_for
    assert parent.lineno == 3

    parent = get_closest_parent_of(module, stmt_for, ast.FunctionDef)
    assert parent is module.body[0]

# Generated at 2022-06-21 18:42:08.034677
# Unit test for function get_parent
def test_get_parent():
    from typed_ast import ast3 as ast
    from .utils import parse_source
    from .types import FuncBody, Node
    from .utils import trace

    tree = parse_source('foo()')
    tree.body[0].value.func.id = 'bar'
    bar_id_node = ast.parse('foo()').body[0].value.func
    assert get_parent(tree, bar_id_node) == tree.body[0].value

    tree = parse_source('def foo():\n  pass')
    get_parent(tree, tree.body[0].body.body[0]) == tree.body[0].body



# Generated at 2022-06-21 18:42:17.647549
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class Node(ast.AST):
        pass

    class NodeLevel1(ast.AST):
        _fields = ()

    class NodeLevel2(ast.AST):
        _fields = ()

    class Root(ast.AST):
        _fields = ()

    tree = Root()
    level1 = NodeLevel1()
    level2 = NodeLevel2()
    node = Node()
    tree.body = [level1]
    level1.body = [level2]
    level2.body = [node]

    res = get_non_exp_parent_and_index(tree, node)
    exp = (level1, 0)
    assert res == exp

# Generated at 2022-06-21 18:42:24.452442
# Unit test for function replace_at
def test_replace_at():
    import astor
    from parser import parse
    from fixer.exceptions import NodeNotFound
    code = """
    a = 2
    b = 3
    c = 4
    """

    tree = parse(code)
    parent, idx = get_non_exp_parent_and_index(tree,
                                               get_parent(tree,
                                                          find(tree,
                                                               ast.Name).__next__()))
    node = ast.Name(id='y')
    replace_at(idx, parent, node)

    assert astor.to_source(tree) == """
    a = 2
    y
    c = 4
    """

    node = ast.Module(body=[])
    replace_at(0, parent, node)


# Generated at 2022-06-21 18:42:33.700815
# Unit test for function insert_at
def test_insert_at():
    """Test function insert_at."""
    import unittest
    import subprocess
    test = unittest.TestCase()

    class parent:
        """Dummy parent."""
        body = []

        def __init__(self):
            """Init."""
            self.body = []

    class child:
        """Dummy child."""
        def __init__(self, a: int, b: int) -> None:
            """Init."""
            self.a = a
            self.b = b

    p = parent()
    p.body = [child(1, 2)]
    insert_at(0, p, [child(3, 4)])
    test.assertEqual(p.body[0].a, 3)
    test.assertEqual(p.body[1].b, 2)

   

# Generated at 2022-06-21 18:42:39.443119
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import parser
    s = parser.parse("""(
    (SomeType)SomeFunction(1, (
        (SomeType)SomeFunction(2)
    ))
)""", mode='eval')

    # Get index of node
    index = get_non_exp_parent_and_index(s, s.body)[1]

    assert index == 3


# Generated at 2022-06-21 18:42:47.747423
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import astunparse
    import unittest
    import pprint

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.statement1 = ast.parse('if a == b:').body[0]
            self.statement2 = ast.parse('if a == b: print(\'test\')').body[0]
            self.statement3 = ast.parse('if a == b: print(\'test\'); self.test()').body[0]
            self.statement4 = ast.parse('if a == b: print(\'test\'); self.test()\n').body[0]
            tree = ast.parse('if a == b: print(\'test\')\nelse: print(\'test2\')\n')

# Generated at 2022-06-21 18:42:48.385092
# Unit test for function insert_at
def test_insert_at():
    assert True

# Generated at 2022-06-21 18:42:55.610443
# Unit test for function get_parent
def test_get_parent():
    source = ast.parse("def add(a, b): return a + b")
    body = source.body[0]
    assert get_parent(source, body) is source
    assert get_parent(source, body.body[0]) is body



# Generated at 2022-06-21 18:42:56.511463
# Unit test for function get_parent

# Generated at 2022-06-21 18:43:03.637762
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = parse("a = 10 + 2 * (1 + 2)")

    assert isinstance(get_closest_parent_of(tree, tree.body[0].value, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].value.right, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].value.right, ast.Expr), ast.Expr)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].value.right.left, ast.BinOp), ast.BinOp)


# Generated at 2022-06-21 18:43:04.285233
# Unit test for function find

# Generated at 2022-06-21 18:43:07.926848
# Unit test for function find
def test_find():
    source = """if 5 > 4:
                    print('5 > 4')
                """
    tree = ast.parse(source)
    nodes = find(tree, ast.Print)

    assert len(nodes) == 1  # type: ignore


# Generated at 2022-06-21 18:43:08.935789
# Unit test for function insert_at

# Generated at 2022-06-21 18:43:13.503290
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Name()
    parent = ast.ClassDef(body=[node])
    tree = ast.Module(body=[parent])
    assert get_non_exp_parent_and_index(tree, node) == (parent, 0)


# Unit tests for function find

# Generated at 2022-06-21 18:43:20.904877
# Unit test for function insert_at
def test_insert_at():
    from pprint import pprint
    parent = ast.parse(u'''
        if True and True:
            return 0

        return 1''').body[0]  # type: ignore

    pprint(parent)
    call = ast.parse(u'''
        call()''').body[0]  # type: ignore
    insert_at(1, parent, call)
    pprint(parent)
    assert parent.body[1].value.func.id == 'call'  # type: ignore



# Generated at 2022-06-21 18:43:26.966317
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Name(id='n', ctx=ast.Load())
    parent = ast.Module(body=[ast.Call(func=node)])

    assert get_non_exp_parent_and_index(parent, node) == (parent, 0)



# Generated at 2022-06-21 18:43:32.854642
# Unit test for function insert_at
def test_insert_at():
    """Test for function insert_at."""
    import typing
    import astor  # noqa
    from astunparse import unparse  # noqa
    from pprint import pprint

    tree: typing.Union[ast.AST, None] = None
    with open("tests/samples/scripts/unittest_insert_at.pys", "r") as f:
        tree = ast.parse(f.read())

    found = next(find(tree, ast.FunctionDef))
    found.body.append(ast.parse("print('test')").body[0])
    print(unparse(tree))