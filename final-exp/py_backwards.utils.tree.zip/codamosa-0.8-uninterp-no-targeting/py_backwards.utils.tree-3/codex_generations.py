

# Generated at 2022-06-21 18:41:44.840350
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("1+1+1")
    ast.fix_missing_locations(tree)
    bin_op = tree.body[0].value
    assert(isinstance(bin_op, ast.BinOp))
    replace_at(1, bin_op, ast.Num(n=2))
    assert(bin_op.right.n == 2)

# Generated at 2022-06-21 18:41:47.522381
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    parent = tree.body[0]

    assert parent is get_parent(tree, tree.body[0].value)



# Generated at 2022-06-21 18:41:58.603285
# Unit test for function replace_at
def test_replace_at():
    prog = ast.parse('x = 9 + 3\ny = [3, 4, 5]\n')
    print(ast.dump(prog))
    print(ast.dump(get_parent(prog, prog.body[0])))
    print(ast.dump(get_parent(prog, prog.body[1])))
    print(ast.dump(prog.body[1]))
    print(prog.body[1].body)
    print(ast.dump(prog.body[1].body[2]))
    print(get_parent(prog, prog.body[1].body[2]))
    assert get_parent(prog, prog.body[1].body[2]) == prog.body[1]

# Generated at 2022-06-21 18:42:06.398280
# Unit test for function replace_at
def test_replace_at():
    class_node = ast.ClassDef(name='A', bases=[], body=[])
    function_node = ast.FunctionDef(name='function', args=None, body=[])

    class_node.body.append(function_node)
    assert len(class_node.body) == 1

    replace_at(index=0, parent=class_node, nodes=[])
    assert len(class_node.body) == 0

    replace_at(index=0, parent=class_node,
               nodes=ast.FunctionDef(name='function', args=None, body=[]))
    assert len(class_node.body) == 1
    assert class_node.body[0] != function_node

# Generated at 2022-06-21 18:42:13.813225
# Unit test for function replace_at
def test_replace_at():
    def run():
        a = ast.Num(1)
        b = ast.Num(2)
        c = ast.Num(3)
        tree = ast.Expr(value=a)
        tree.body.append(b)
        tree.body.append(c)
        replace_at(1, tree, 42)
        assert tree.body[0].value == 42
        assert tree.body[1].value == 3
        assert tree.body[2].value == 3

    run()



# Generated at 2022-06-21 18:42:17.450199
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, ast.Assign))) == 1
    assert len(list(find(tree, ast.Str))) == 0



# Generated at 2022-06-21 18:42:23.332105
# Unit test for function find
def test_find():
    """Test the implementation of find function."""
    class T(ast.AST):
        """Class which is used for testing the implementation of find function."""

    class R(ast.AST):
        """Class which is used for testing the implementation of find function."""

    node = ast.Module()
    a = T()
    b = T()
    c = R()
    d = T()

    node.body = [a, b, c, d]

    result = find(node, T)
    result_list = list(result)

    assert result_list == [a, b, d]

# Generated at 2022-06-21 18:42:25.216895
# Unit test for function get_parent

# Generated at 2022-06-21 18:42:32.970458
# Unit test for function replace_at
def test_replace_at():
    import astor
    mod = ast.parse("var1 = var2")
    node = mod.body[0]
    parent = get_parent(mod, node)
    parent_index = mod.body.index(node)
    replace_at(parent_index, parent, [ast.parse("var3 = var4").body[0]])
    assert astor.to_source(mod) == "var3 = var4"
    print(astor.to_source(mod))


# Generated at 2022-06-21 18:42:34.077007
# Unit test for function get_non_exp_parent_and_index