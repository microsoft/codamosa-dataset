

# Generated at 2022-06-21 18:41:55.326256
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def fun(arg):\n    pass\n')
    fun = tree.body[0]
    assert get_parent(tree, fun) == tree
    assert get_parent(tree, fun.name) == fun
    assert get_parent(tree, fun.args) == fun


test_nodes = [
    ast.Pass(),
    ast.Expr(ast.Name(id='fun', ctx=ast.Load()))
]



# Generated at 2022-06-21 18:42:02.365962
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor

    tree = ast.parse('''
    def func1(a, b=2):
        c = 1
        return a*b
    ''')

    global_ = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.Module)
    func = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.FunctionDef)
    suite = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.Suite)
    assign = get_closest_parent_of(tree, tree.body[0].body[0].value, ast.Assign)

# Generated at 2022-06-21 18:42:13.105510
# Unit test for function get_parent
def test_get_parent():
    s = ast.parse('print("Test")')
    assert isinstance(get_parent(s, s.body[0]), ast.Module)
    assert isinstance(get_parent(s, s.body[0].body[1]), ast.Expr)
    assert isinstance(get_parent(s, s.body[0].body[1].value), ast.Str)
    assert get_parent(s, s.body[0].body[1].value) == s.body[0].body[1]
    assert get_parent(s, s.body[0].body[1]) == s.body[0]
    assert get_parent(s, s.body[0]) == s



# Generated at 2022-06-21 18:42:18.633670
# Unit test for function find
def test_find():
    code = '\n'.join([
        'def a():',
        '    pass',
        'def b():',
        '    pass',
    ])
    tree = ast.parse(code)

    for node in find(tree, ast.FunctionDef):  # type: ignore
        assert isinstance(node.name, str)



# Generated at 2022-06-21 18:42:24.937873
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def add(a, b=3):
        if a and b:
            c = a + b
            return c
        return 0

    tree = parse(dedent(add.__doc__))
    node = tree.body[0]
    
    # Assertion
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)

# Generated at 2022-06-21 18:42:33.928746
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""a = b or c""")

    assert get_non_exp_parent_and_index(tree, tree.body[0].value.left) == \
           (tree.body[0].value, 0)
    assert get_non_exp_parent_and_index(tree,  # type: ignore
                                        tree.body[0].value.ops[0]) == \
        (tree.body[0].value, 1)
    assert get_non_exp_parent_and_index(tree, tree.body[0].value.comparators[0]) == \
        (tree.body[0].value, 2)

# Generated at 2022-06-21 18:42:39.503341
# Unit test for function insert_at
def test_insert_at():
    import unittest
    import typed_ast.ast3

    class TestInsertAt(unittest.TestCase):
        def test_insert_at(self):
            func = typed_ast.ast3.parse('def foo(): pass')

            foo = typed_ast.ast3.FunctionDef(
                name='foo',
                args=typed_ast.ast3.arguments(
                    args=[],
                    vararg=None,
                    kwonlyargs=[],
                    kwarg=None,
                    defaults=[],
                    kw_defaults=[],
                ),
                body=[
                    typed_ast.ast3.Pass()
                ],
                decorator_list=[],
                returns=None,
            )

            return_val = typed_ast.ast3.parse('return a')

# Generated at 2022-06-21 18:42:44.791700
# Unit test for function insert_at
def test_insert_at():
    class_ast = ast.parse('class Test:\n    def test(self):\n        pass')
    test_module = ast.Module(body=[class_ast])
    replace_at(0, test_module, class_ast.body)
    insert_at(0, test_module, class_ast)
    insert_at(0, test_module, class_ast.body)

# Generated at 2022-06-21 18:42:46.195569
# Unit test for function get_parent
def test_get_parent():
    import astor


# Generated at 2022-06-21 18:42:52.310992
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = '''
            def test():
                for i in range(10):
                    if i == 5:
                        a = i
                    else:
                        a = i*2

            '''

    tree = ast.parse(code)
    for_node = get_closest_parent_of(tree, tree.body[0].body[1], ast.For)
    print(for_node)

