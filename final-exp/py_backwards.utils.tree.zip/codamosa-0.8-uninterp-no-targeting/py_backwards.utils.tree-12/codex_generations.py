

# Generated at 2022-06-21 18:41:56.792144
# Unit test for function find
def test_find():
    class Node(ast.AST):
        pass

    class Node2(ast.AST):
        pass

    node = Node()
    node2 = Node2()

    assert not find(node, Node)
    assert not find(node2, Node)
    assert not find(node, Node2)
    assert not find(node2, Node2)

    root = ast.Module([node, node2])
    assert list(find(root, Node)) == [node]
    assert list(find(root, Node2)) == [node2]
    assert not find(root, ast.Module)



# Generated at 2022-06-21 18:41:57.988050
# Unit test for function find
def test_find():
    assert len(find(ast.parse('print("hello")'), ast.Print)) == 1

# Generated at 2022-06-21 18:42:06.939464
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert isinstance(get_closest_parent_of(ast.parse('a + b * c'),
                                            ast.parse('b * c').body[0].value,
                                            ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(ast.parse('a + b * c'),
                                            ast.parse('b * c').body[0].value,
                                            ast.BinOp), ast.BinOp)
    assert isinstance(get_closest_parent_of(ast.parse('a + b * c'),
                                            ast.parse('b * c').body[0].value,
                                            ast.BinOp), ast.BinOp)

# Generated at 2022-06-21 18:42:10.069144
# Unit test for function find
def test_find():
    assert list(find(ast.parse('a = 2'), ast.Assign)) == [ast.parse('a = 2').body[0]]



# Generated at 2022-06-21 18:42:16.629585
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    A = ast.parse('A = 1 + 2')
    B = ast.parse('if A == 0: B = 1')
    C = ast.parse('def C(): B = 0')
    D = ast.parse('D = 0')

    tree = ast.Module(body=[A, B, C, D])

    parent = get_closest_parent_of(tree, B.body[0].test.left, ast.Module)
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-21 18:42:21.509330
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""
    a = (1 + 2) * 3
    """)

    print(ast.dump(tree))

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].value)
    insert_at(index, parent, ast.parse('print(1)'))

    print(ast.dump(tree))



# Generated at 2022-06-21 18:42:25.803465
# Unit test for function find
def test_find():
    tree = ast.parse('for i in x: print(i)')
    for_node = None
    for node in find(tree, ast.For):
        for_node = node

    assert for_node is not None



# Generated at 2022-06-21 18:42:30.422365
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    mod = ast.parse("""
    def foo():
        a = 1
        if a:
            b = 2
    """)

    index = mod.body[0].body[1].body[0]
    parent, index = get_non_exp_parent_and_index(mod, index)
    assert parent.body[0] == index

# Generated at 2022-06-21 18:42:31.291242
# Unit test for function get_parent

# Generated at 2022-06-21 18:42:42.315353
# Unit test for function insert_at
def test_insert_at():
    import typed_ast.ast3 as ast

    def insert_at_test():
        my_var = 0
        my_var += 1

    tree = ast.parse('def insert_at_test():\n'
                     '    my_var = 0\n'
                     '    my_var += 1\n')

    insert_at(1, get_parent(tree, tree.body[0]),
              ast.parse('my_var += 2').body[0])

    assert ast.dump(tree).strip() == ast.dump(
        ast.parse('def insert_at_test():\n'
                  '    my_var = 0\n'
                  '    my_var += 2\n'
                  '    my_var += 1\n')).strip()



# Generated at 2022-06-21 18:48:35.965670
# Unit test for function get_parent
def test_get_parent():
    # Statement AST tree
    stmt_tree = ast.parse('def test_func():\n  if True:\n    p=1\n')

    # Function Def Node
    func_def_node = stmt_tree.body[0]
    assert get_parent(stmt_tree, func_def_node) == stmt_tree

    # If Node
    if_node = func_def_node.body[0]
    assert get_parent(stmt_tree, if_node) == func_def_node

    # Assignment Node
    assign_node = if_node.body[0]
    assert get_parent(stmt_tree, assign_node) == if_node

    # Expression AST tree
    exp_tree = ast.parse('def test_func():\n  a = 1+1\n')

    # Function

# Generated at 2022-06-21 18:48:39.744188
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor


# Generated at 2022-06-21 18:48:51.449823
# Unit test for function insert_at
def test_insert_at():
    parent = ast.Module([ast.FunctionDef(
        'test',
        args=ast.arguments(
            args=[ast.arg(arg='var1', annotation=None)],
            defaults=[],
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            vararg=None),
        body=[],
        decorator_list=[],
        returns=None
    )])

    ast.fix_missing_locations(parent)


# Generated at 2022-06-21 18:48:53.213786
# Unit test for function get_parent

# Generated at 2022-06-21 18:48:57.404721
# Unit test for function find
def test_find():
    # pylint: disable=import-outside-toplevel
    from typed_ast import ast27 as ast
    from .tree_builder import TreeBuilder
    from . import tree_utils as utils


# Generated at 2022-06-21 18:48:59.001990
# Unit test for function get_parent

# Generated at 2022-06-21 18:49:05.164536
# Unit test for function insert_at
def test_insert_at():
    node = ast.parse('1 + 3')
    parent = get_closest_parent_of(node, node.body[0], ast.Expression)
    parent.body.insert(0, ast.Num(n=4))
    assert(ast.dump(node) == '(4 + 1 + 3)')


# Generated at 2022-06-21 18:49:17.952620
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class A(ast.AST):
        _fields = ('a1', 'a2')
        a1 = None
        a2 = None

    class B(A):
        _fields = ('b1',)
        b1 = None

    class C(B):
        _fields = ('c1', 'c2')
        c1 = None
        c2 = None

    class D(ast.AST):
        _fields = ('d1', 'd2')
        d1 = None
        d2 = None

    class E(ast.AST):
        _fields = ('e1',)
        e1 = None

    d = D()
    c = C()
    a = A()
    c.c1 = d
    c.c2 = d
    c.b1 = B()
    c.b1.b1

# Generated at 2022-06-21 18:49:28.869549
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    # test that if there's no matching closest parent, None is returned
    assert get_closest_parent_of(None, None, None) is None

    # test that if the passed node is of the same type as type_,
    # then the passed node is returned
    class_node = ast.ClassDef('MyClass', [], [], [])
    assert get_closest_parent_of(None, class_node, ast.ClassDef) == class_node

    # test that if a node's parent is of the same type as type_,
    # then the parent is returned
    tree = ast.parse('class MyClass: pass')
    assert get_closest_parent_of(tree.body[0], tree.body[0].body[0],
                                 ast.ClassDef) == tree.body[0]

# Generated at 2022-06-21 18:49:35.015007
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # TODO: Add meaningful test
    source = """def foo():
        pass
        pass
    """
    tree = ast.parse(source)
    node = tree.body[0].body[0]
    assert(get_closest_parent_of(tree, node, ast.FunctionDef) == tree.body[0])