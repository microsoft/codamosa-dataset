

# Generated at 2022-06-21 18:41:45.098185
# Unit test for function replace_at

# Generated at 2022-06-21 18:41:49.790933
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('1 + 2')

    ret = get_non_exp_parent_and_index(tree, tree.body[0].value)

    assert isinstance(ret[0], ast.Module)
    assert ret[1] == 0

# Generated at 2022-06-21 18:41:56.421207
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def f() -> int:
        return 3

    assert get_closest_parent_of(ast.parse(inspect.getsource(f)),
                                 ast.parse(inspect.getsource(f)).body[0].body[0],
                                 ast.FunctionDef)
    assert get_closest_parent_of(ast.parse(inspect.getsource(f)),
                                 ast.parse(inspect.getsource(f)).body[0].body[0],
                                 ast.Return) is None

# Generated at 2022-06-21 18:42:05.348691
# Unit test for function find
def test_find():
    import astor


    def inplace_test(test_func):
        """Decorator for testing functions."""
        def wrapper(*args):
            """Pass passed arguments to test function."""
            if test_func(*args):
                raise Exception("Test failed on: " + str(args))
            else:
                print("Test passed on: " + str(args) +
                      ". Output string is equal Python code")
        wrapper._inplace_test_ = True
        wrapper.__name__ = test_func.__name__
        return wrapper


    @inplace_test
    def test_find_eq(module_str: str, node_type: str,
                     nodes_num: int) -> bool:
        """Test find function."""
        tree = ast.parse(module_str)
        ast_nodes_num = len

# Generated at 2022-06-21 18:42:11.533402
# Unit test for function find
def test_find():
    assert (
        find(ast.parse('a + b + c', mode='eval'), ast.BinOp) ==
        [ast.BinOp(left=ast.Name(id='a', ctx=ast.Load()), op=ast.Add(),
                   right=ast.Name(id='b', ctx=ast.Load()))]
    )



# Generated at 2022-06-21 18:42:20.316871
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast

    def myfunc(x):
        a = x * 2
        b = x * 3

        # for loop
        for i in range(10):
            c = a + b

        return c

    func_body = ast.parse(myfunc.__doc__).body[0].body
    node = func_body[1].value
    closest_func_def = get_closest_parent_of(ast.parse(myfunc.__doc__), node, ast.FunctionDef)

    assert closest_func_def is not None
    assert closest_func_def.name == "myfunc"



# Generated at 2022-06-21 18:42:31.215681
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    import ast
    from darglint.util import SourceLocation, get_closest_parent_of

    class TestGetClosestParentOf(unittest.TestCase):

        """Tests for get_closest_parent_of."""

        def test_module(self):
            """Make sure the closest parent is the module."""
            source_location = SourceLocation(1, 1, 'test.py')
            module_obj = ast.parse(
                'def f():\n'
                '    pass\n'
            )
            for func in module_obj.body:
                if isinstance(func, ast.FunctionDef):
                    assert get_closest_parent_of(
                        module_obj, func.args.defaults[0], ast.Module) is\
                        module_obj

# Generated at 2022-06-21 18:42:33.648908
# Unit test for function find
def test_find():
    foo = ast.parse("""
    
    '''test docstring'''

    def foo():
        return 10
    """)
    f = find(foo, ast.FunctionDef)
    assert next(f).name == 'foo'



# Generated at 2022-06-21 18:42:39.921372
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    t = ast.parse('''
    def a():
        if True:
            b = 3
        else:
            b = 4
    ''')
    parent, index = get_non_exp_parent_and_index(t, t.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert isinstance(parent.body[index], ast.If)

# Generated at 2022-06-21 18:42:47.860217
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    global_node = ast.Global([ast.Name('a', ast.Store())])
    tree = ast.Module([global_node])
    assert get_non_exp_parent_and_index(tree, global_node) == (tree, 0)

    func_decl = ast.FunctionDef('func', ast.arguments(
        [], None, None, []), [], [], None, None)
    func_args = func_decl.args
    assert get_non_exp_parent_and_index(tree, func_args.kwarg) == (
        func_args, 5)

    func_body = func_decl.body
    assert get_non_exp_parent_and_index(tree, func_body[0]) == (
        func_decl, 0)

    tree = ast.Module([func_decl])
    tree

# Generated at 2022-06-21 18:43:02.367282
# Unit test for function insert_at
def test_insert_at():
    # type: () -> None
    test_code = ast.parse(
        """
        a = 1

        b = {
            a
        }
        """
    )

    # Find parent
    parent = get_closest_parent_of(test_code, test_code.body[1].body[0],
                                   ast.Dict)

    # Insert at index 0
    insert_at(0, parent, ast.parse("'key': 'value'").body[0].value)


# Generated at 2022-06-21 18:43:11.026014
# Unit test for function get_parent
def test_get_parent():
    code = """\
    def main():
        if True:
            print("hello")
        else:
            pass
    """
    tree = ast.parse(code)
    node = tree.body[0].body[1].body[1]

    if_node = get_parent(tree, node)
    assert str(if_node) == "If(test=Name(id='True', ctx=Load()), body=[Print(dest=None, values=[Str(s='hello')], nl=True, ctx=Load())], orelse=[Pass()])"



# Generated at 2022-06-21 18:43:13.817065
# Unit test for function replace_at
def test_replace_at():
    # import astor
    # import ast
    #
    # tree = ast.parse('''
    # def foo():
    #     a = [1, 2, 3]
    #     b = a[0]
    #     c = a[1]
    # ''')
    #
    # replace_at(1, tree.body[0], ast.Expr(value=ast.Num(0)))
    #
    # print(astor.to_source(tree))
    pass

# Generated at 2022-06-21 18:43:19.695082
# Unit test for function find
def test_find():
    source = dedent('''\
    def foo():
        a = 'hi'
        b = 'hi'
        a == b
        c = 'hi'
        d = 'hi'
        c == d
    ''')
    module = ast.parse(source)
    assert len(list(find(module, ast.Str))) == 4



# Generated at 2022-06-21 18:43:21.264014
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:43:32.201767
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = "def func(x):\n    return x * 5"
    tree = ast.parse(source)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.FunctionDef)

    # Test case 0
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    # Test case 1
    node = tree.body[0].body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Return)
    assert index == 0

    # Test case 2
    node = tree.body[0].body[0].value

# Generated at 2022-06-21 18:43:41.260795
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..exceptions import NodeNotFound
    import ast
    a = ast.Module(body=[ast.Expr(value=ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Str(s='Hello World')], keywords=[]))])
    _build_parents(a)
    mod = a.body[0]
    call = mod.value.func
    try:
        _ = get_non_exp_parent_and_index(a, call)
    except NodeNotFound:
        pass


# Generated at 2022-06-21 18:43:44.127995
# Unit test for function find
def test_find():
    assert "ast.Expression" in str(find(ast.parse('a'), ast.Expression))
    assert "ast.Load" in str(find(ast.parse('a'), ast.Load))

# Generated at 2022-06-21 18:43:54.509769
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
        for i in range(n):
            for j in range(n):
                print('Hello')
    """)
    assert (isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                             ast.Module), ast.Module)
            and
            isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                             ast.For), ast.For) and
            isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                             ast.FunctionDef), ast.For))



# Generated at 2022-06-21 18:44:02.452630
# Unit test for function insert_at
def test_insert_at():
    node1 = ast.parse("node1")
    node2 = ast.parse("node2")
    parent = ast.FunctionDef(name="test", args=ast.arguments(),
                             body=[ast.Expr(value=node1)])
    insert_at(0, parent, [node2])
    assert parent.body[1].value.s == "node2"
    assert parent.body[0].value.s == "node1"



# Generated at 2022-06-21 18:44:08.542580
# Unit test for function insert_at
def test_insert_at():
    import copy
    orig = ast.parse("foo = 1\n")
    new = copy.deepcopy(orig)
    insert_at(0, new.body[0], ast.Num(2))
    assert new == ast.parse("foo = 1\nfoo = 2\n")
    new = copy.deepcopy(orig)
    insert_at(1, new.body[0], ast.Num(2))
    assert new == ast.parse("foo = 2\nfoo = 1\n")


# Generated at 2022-06-21 18:44:17.586973
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
    gui.main_win.show()
    gui.main_win.show()
    gui.main_win.show()
    gui.main_win.show()
    gui.main_win.show()
    ''')
    child = tree.body[0].value
    parent = get_parent(tree, child)
    assert isinstance(parent, ast.Expr)
    non_exp_parent, index = get_non_exp_parent_and_index(tree, child)
    assert isinstance(non_exp_parent, ast.Module)
    assert index == 0

# Generated at 2022-06-21 18:44:25.850519
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..grammar import parse

    tree = parse('''
    p = True
    q = True
    if True:
        print('abc')
    elif p:
        print('def')
    else:
        print(q)
    ''')
    print('Here is the tree generated:')
    print(ast.dump(tree))
    print('Here is the parent of q:')
    print(ast.dump(get_parent(tree, tree.body[2].orelse[0].body[0].value)))
    print('Here is the non-Exp parent of q:')
    print(ast.dump(get_non_exp_parent_and_index(tree, tree.body[2].orelse[0].body[0].value)[0]))
    print('Here is the index of q:')


# Generated at 2022-06-21 18:44:35.560260
# Unit test for function insert_at
def test_insert_at():
    test_tree_parent = ast.Module([], [], [
        ast.FunctionDef(name='test_function', args=ast.arguments(), body=[
            ast.Return(value=ast.Num(n=1))
        ])
    ])
    test_tree_nodes = [
        ast.Return(value=ast.Num(n=2)),
        ast.Return(value=ast.Num(n=3))
    ]
    test_tree_result = ast.Module([], [], [
        ast.FunctionDef(name='test_function', args=ast.arguments(), body=[
            ast.Return(value=ast.Num(n=2)),
            ast.Return(value=ast.Num(n=3)),
            ast.Return(value=ast.Num(n=1))
        ])
    ])
    _

# Generated at 2022-06-21 18:44:42.927095
# Unit test for function insert_at
def test_insert_at():
    expected = ast.parse("(1, 2, 3, 4, 5)")
    expected = expected.body[0].value  # type: ignore

    parent = ast.parse("(1, 2, 3, 5)")
    parent = parent.body[0].value  # type: ignore

    node = ast.parse("4")
    node = node.body[0].value  # type: ignore

    insert_at(3, parent, node)
    assert ast.dump(parent) == ast.dump(expected)

# Generated at 2022-06-21 18:44:45.411889
# Unit test for function insert_at
def test_insert_at():
    node = ast.If()
    parent = ast.Module(body=[node])
    insert_at(0, parent, node)



# Generated at 2022-06-21 18:44:52.741458
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .test_ast import sample_program
    from .test_ast import sample_program_statement_body

    assert get_closest_parent_of(sample_program, sample_program_statement_body, ast.Module) == sample_program
    assert get_closest_parent_of(sample_program, sample_program_statement_body, ast.FunctionDef) == sample_program.body[0]


if __name__ == '__main__':
    test_get_closest_parent_of()

# Generated at 2022-06-21 18:44:59.392004
# Unit test for function insert_at
def test_insert_at():
    import astor
    def f():
        a
        b
        c

    tree = ast.parse(astor.to_source(f))
    p = get_parent(tree, tree.body[2])
    insert_at(1, p, ast.parse('d').body[0])
    assert astor.to_source(tree).strip() == 'def f():\n    a\n    d\n    b\n    c'

# Generated at 2022-06-21 18:45:05.604285
# Unit test for function replace_at
def test_replace_at():
    import sys
    tree = ast.parse(sys.modules[__name__].__doc__)
    node = find(tree, ast.FunctionDef).next()
    nodes = ast.copy_location(ast.parse('# this is a comment'), node)
    replace_at(0, node, nodes)
    assert node.body[0].value.s == ' this is a comment'

# Generated at 2022-06-21 18:45:08.056542
# Unit test for function find
def test_find():
    test = ast.parse('print(1+3)')
    assert len(list(find(test, ast.Name))) == 3



# Generated at 2022-06-21 18:45:26.261998
# Unit test for function find
def test_find():
    from . import test_utils as tu
    from . import ast_utils as au
    meta_suite = tu.MetaTestSuite(
        (('tests/suite/test_programs/k-nucleotide.py', 'k_nucleotide_test'),)
    )
    for file, _ in meta_suite.test_programs:
        tree = au.parse_file(file)
        m = None
        while m is None:
            m = find(tree, ast.FunctionDef).__next__()
        assert isinstance(m, ast.FunctionDef)
        assert m.name == 'k_nucleotide'

# Generated at 2022-06-21 18:45:30.628668
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse(
        '''def foo():
            bar = 1
            bar += 2
           ''')
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)
    assert isinstance(get_parent(tree, tree.body[0].body[0].value), ast.Assign)
    assert isinstance(get_parent(tree, get_parent(tree,
                                                  tree.body[0].body[0])),
                      ast.Module)



# Generated at 2022-06-21 18:45:31.460405
# Unit test for function get_parent
def test_get_parent():
    pass

# Generated at 2022-06-21 18:45:42.280176
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:45:49.069307
# Unit test for function replace_at
def test_replace_at():
    def f():
        i = 1
        j = i
        k = 2

    tree = ast.parse(f.__code__.co_code).body[0]
    index = 1
    ast.fix_missing_locations(tree)
    parent = get_parent(tree, tree.body[index])

    # Replace the second node with a new node
    replace_at(index, parent, ast.Assign(targets=[ast.Name(id='i', ctx=ast.Store())],
                                         value=ast.Str(s='test')))

    print(ast.dump(tree))
    re = ast.parse('def f():\n    i = 1\n    i = \'test\'\n    k = 2\n')
    assert ast.dump(tree) == ast.dump(re)

# Generated at 2022-06-21 18:46:01.313640
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.fix_missing_locations(ast.parse('''
if True:
    pass
else:
    x = 1
    if True:
        pass
    else:
        call()
'''))
    assert get_non_exp_parent_and_index(tree, tree.body[0]) == \
        (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == \
        (tree.body[0], 0)
    assert get_non_exp_parent_and_index(tree, tree.body[1].body[1].body[0]) == \
        (tree.body[1].body[1], 0)

# Generated at 2022-06-21 18:46:10.537816
# Unit test for function replace_at
def test_replace_at():
    import os
    import sys
    import astor

    sys.path.insert(0, os.path.dirname(__file__))

    from tests.resources.ast_files.ast_replace_at import *

    save_ast = ast.dump(ast_replace_at)

    parent, index = get_non_exp_parent_and_index(ast_replace_at, replace_at_node)

    replace_at(index, parent, replace_at_node_return_expr)

    assert ast.dump(ast_replace_at) == ast.dump(ast_replace_at_result)

# Generated at 2022-06-21 18:46:16.410056
# Unit test for function find
def test_find():
    nodes = [
        ast.Constant(value=1, kind=None),
        ast.Constant(value=1, kind=None),
        ast.Constant(value=1, kind=None),
    ]

    assert list(find(nodes, ast.Constant)) == nodes

    with pytest.raises(Exception):
        nodes = [
            ast.Constant(value=1, kind=None),
            ast.Constant(value=1, kind=None),
            1,
        ]

        next(find(nodes, ast.Constant))



# Generated at 2022-06-21 18:46:24.659150
# Unit test for function insert_at
def test_insert_at():
    i_node = ast.parse("x = 1")
    i = i_node.body[0]
    p = ast.Module(body=[ast.Assign(targets=[ast.Name(id='y')],
                                    value=ast.Num(n=2))])
    insert_at(0, p, i)
    expected = ast.Module(body=[
        i,
        ast.Assign(targets=[ast.Name(id='y')],
                   value=ast.Num(n=2))])
    assert (ast.dump(p) == ast.dump(expected))



# Generated at 2022-06-21 18:46:31.042345
# Unit test for function insert_at
def test_insert_at():
    class_name = ast.Str('TestClass')
    class_node = ast.ClassDef('TestClass', [], [], [], [])

    module_node = ast.Module([])
    module_node.body = [class_node]

    insert_at(0, module_node, class_name)

    assert module_node.body[0] == class_name
    assert module_node.body[1] == class_node

    func_name = ast.Str('test_func')
    func_node = ast.FunctionDef('test_func', ast.arguments([], None, None, []), [], [])

    insert_at(1, module_node, func_node)

    assert module_node.body[2] == func_node

# Generated at 2022-06-21 18:47:04.913270
# Unit test for function replace_at
def test_replace_at():
    import astor
    node_list = []
    node1 = ast.parse('if True:\n    p = 2\n    print(p)').body[0]
    node_list.append(node1)
    node2 = ast.parse('p = 5\nprint(p)').body[0]
    node_list.append(node2)
    parent = ast.parse('def foo():\n    p = 2\n    print(p)\n    p = 5\n    print(p)').body[0]
    parent_old = ast.parse('def foo():\n    p = 2\n    print(p)\n    p = 5\n    print(p)').body[0]
    print("Replace")
    replace_at(1, parent, node_list)

# Generated at 2022-06-21 18:47:12.022815
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    ((1+1)*2) + 4*(10 - 4)
    """)

    node = tree.body[0].value.right
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.Expr)
    assert index == 1

    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-21 18:47:13.336620
# Unit test for function insert_at

# Generated at 2022-06-21 18:47:19.743198
# Unit test for function find
def test_find():
    def check_find(value, module):
        assert [n.id for n in find(module, ast.Import)] == [value]

    check_find('import_1', ast.parse('import import_1'))
    check_find('import_2', ast.parse('import import_1, import_2'))
    check_find('import_3', ast.parse('import import_1 as import_3'))

# Generated at 2022-06-21 18:47:23.130037
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    a = get_closest_parent_of(tree, tree.body[0].value, ast.Assign)
    assert a == tree.body[0] and a.__class__ == ast.Assign



# Generated at 2022-06-21 18:47:34.740524
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a = [1, 2, 3]
    if len(a) > 2:
        a[0] = a[0] + a[1]
    assert ('Module', ('If', 'Assign', 'Load', 'Load', 'BinOp', 'Store')) == get_non_exp_parent_and_index(a, a[0])
    assert ('Module', ('If', 'Load', 'Load', 'BinOp')) == get_non_exp_parent_and_index(a, a[1])
    assert ('Module', ('If', 'Load', 'Load', 'BinOp')) == get_non_exp_parent_and_index(a, a[2])

# Generated at 2022-06-21 18:47:38.996236
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .fixtures import module_with_function
    from .fixtures import function_with_n_statements

    node = ast.Name(id='n', ctx=ast.Load())
    mod = module_with_function(function_with_n_statements(node))
    parent = get_non_exp_parent_and_index(mod, node)[0]
    assert isinstance(parent, ast.FunctionDef)
    assert parent.body[0] == node

# Generated at 2022-06-21 18:47:44.883635
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """
    def func():
        pass

    class Foo:
        pass
    """

    tree = ast.parse(code)
    body = tree.body[0]

    assert isinstance(get_closest_parent_of(tree, body, ast.Module), ast.Module)

# Generated at 2022-06-21 18:47:54.369798
# Unit test for function replace_at
def test_replace_at():
    import typed_astunparse
    class a(ast.AST):
        pass
    class b(ast.AST):
        pass
    class c(ast.AST):
        pass
    class d(ast.AST):
        pass
    class e(ast.AST):
        pass
    class f(ast.AST):
        pass
    class g(ast.AST):
        pass
    class h(ast.AST):
        pass
    class i(ast.AST):
        pass
    class j(ast.AST):
        pass
    a_node = a()
    b_node1 = b()
    c_node = c()
    d_node = d()
    e_node = e()
    f_node = f()
    g_node = g()
    h_node = h()
    i_node = i

# Generated at 2022-06-21 18:48:06.536210
# Unit test for function replace_at
def test_replace_at():
    import typed_ast.ast3 as ast
    from autotranslate import replace_at, add_to_names_list

    lineno = 1
    col_offset = 2
    body = ast.FunctionDef(
        name="f",
        args=ast.arguments(args=[]),
        body=[ast.Expr(value=ast.Num(n=7)),
              ast.Expr(value=ast.Num(n=8)),
              ast.Expr(value=ast.Num(n=9))],
        decorator_list=[],
        returns=None)
    print(ast.dump(body))
    func = ast.Module(body=[body])
    replace_at(0, body, add_to_names_list(body, func))
    print(ast.dump(body))

# Generated at 2022-06-21 18:48:41.965732
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-21 18:48:45.113820
# Unit test for function find
def test_find():
    test_tree = ast.parse("import json", '<ast>', 'exec')
    assert find(test_tree, ast.Import) == test_tree.body

# Generated at 2022-06-21 18:48:46.069554
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-21 18:48:54.857744
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from lark import Lark
    from lark.indenter import Indenter


# Generated at 2022-06-21 18:49:05.602310
# Unit test for function replace_at
def test_replace_at():
    import ast
    import astunparse
    result = ast.parse(
        '''def foo(a, b, c):
        for i in range(c):
            a = a + b
        return a
    ''')
    node1 = result.body[0]
    node2 = result.body[0].body[0]
    node3 = result.body[0].body[0].body[0]
    node4 = result.body[0].body[1].value
    node5 = result.body[0].body[2].value
    assert(astunparse.unparse(node1)) == 'def foo(a, b, c):'
    assert(astunparse.unparse(node2)) == 'for i in range(c):'

# Generated at 2022-06-21 18:49:12.291675
# Unit test for function insert_at
def test_insert_at():
    a = ast.parse('def test():\n\tpass')
    b = ast.parse('def test2():\n\tprint("test")')
    insert_at(1, a.body[0], b.body[0])

    assert len(a.body) == 2
    assert a.body[0].name == 'test'
    assert a.body[1].name == 'test2'

# Generated at 2022-06-21 18:49:22.609262
# Unit test for function get_parent
def test_get_parent():
    import numpy as np
    from .visitor import to_source

    test_code = """
    for i in a:
        import datetime
        print(i)
    """

    tree = ast.parse(test_code)
    parent = get_parent(tree, tree.body[0].body[0].targets[0])
    parent_src = to_source(parent)
    np.testing.assert_equal(parent_src, 'print(i)')

    tree = ast.parse(test_code)
    parent = get_parent(tree, tree.body[0].body[1].targets[0])
    parent_src = to_source(parent)
    np.testing.assert_equal(parent_src, 'print(i)')

    tree = ast.parse(test_code)
    parent

# Generated at 2022-06-21 18:49:30.889701
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Check function get_non_exp_parent_and_index."""
    tree = ast.parse(dedent(r'''
    if 1:
        pass
    elif 2:
        pass
    else:
        pass
    ''')) # pylint: disable=C0330
    if_node = tree.body[0]  # type: ast.If
    elif_node = if_node.orelse[0]  # type: ast.If
    else_node = elif_node.orelse[0]  # type: ast.If

    class Node():
        """Fake node for testing."""
        pass

    fake_node = Node()

    if_node.body.append(fake_node) # pylint: disable=E1136
    assert get_non_exp_parent_and_

# Generated at 2022-06-21 18:49:32.164316
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_astunparse


# Generated at 2022-06-21 18:49:41.792668
# Unit test for function replace_at
def test_replace_at():
    import astor
    node = ast.parse("""def foo():
    print('bar')
    print('baz')
""")

    parent, index = get_non_exp_parent_and_index(node, find(node, ast.Expr).__next__())

    replace_at(index, parent, ast.parse("""
    if 1:
        break
    if 2:
        break
    if 3:
        break
    if 4:
        break
    if 5:
        break
    if 6:
        break
    if 7:
        break
"""))
