

# Generated at 2022-06-21 18:41:52.329588
# Unit test for function replace_at
def test_replace_at():
    import astor
    mod = ast.parse('x=1;x=2')
    mod.body[-1] = mod.body[-1].value
    mod.body[1] = ast.AugAssign(mod.body[1].targets[0], ast.Add(), mod.body[1].value)
    astor.to_source(mod)
    # print(astor.to_source(mod))
    mod.body[-1] = mod.body[-1].value
    assert astor.to_source(mod) == 'x = 1\nx += 2\n'  # replace_at not implemented

test_replace_at()

# Generated at 2022-06-21 18:41:57.535441
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def foo():
        def bar():
            if True:
                return 1
        return bar

    tree = ast.parse(inspect.getsource(foo))
    return_node = tree.body[0].body[1].body[1]
    assert isinstance(get_closest_parent_of(tree, return_node, ast.FunctionDef),
                      ast.FunctionDef)


# Generated at 2022-06-21 18:42:06.529151
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..ast import parse, dump

    src = """
      def whatever():
        def fuck():
          if True:
            whatever()
    """

    tree = parse(src)
    node = ast.Call(func=ast.Name('whatever', ast.Load()), args=[], keywords=[])
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)

    assert dump(parent) == "def fuck(): ..."
    assert dump(node) == "whatever()"

    node = ast.Call(func=ast.Name('whatever', ast.Load()), args=[], keywords=[])
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)

    assert dump(parent) == "def fuck(): ..."
    assert dump(node) == "whatever()"


# Generated at 2022-06-21 18:42:15.240386
# Unit test for function insert_at
def test_insert_at():
    m = ast.Module(body=[])
    class_ = ast.ClassDef(name='test')
    f = ast.FunctionDef(name='test')
    m.body.append(class_)
    m.body.append(f)

    insert_at(1, m, ast.FunctionDef(name='new_f'))

    assert m.body[0] == class_
    assert m.body[1] == ast.FunctionDef(name='new_f')
    assert m.body[2] == f
    assert len(m.body) == 3


# Generated at 2022-06-21 18:42:23.687065
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import definitions
    from . import statements
    from . import expressions

    tree = ast.Module(
        body=[
            statements.Return(
                value=expressions.Call(
                    func=expressions.Call(
                        func=expressions.Name(id='foo'),
                        args=[
                            expressions.Str(s='bar'),
                            expressions.Num(n=1)
                        ],
                        keywords=[])
                )
            )
        ]
    )

    assert get_non_exp_parent_and_index(tree, tree.body[0].value) == (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].value.func) == \
        (tree.body[0].value.func.args, 0)
    assert get_non_exp_parent

# Generated at 2022-06-21 18:42:31.486330
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('a = 5\nb = 6')
    test_node = ast.parse('c = 7')
    # replace a = 5
    insert_at(0, tree, test_node)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="c", ' \
                             'ctx=Store())], value=Num(n=7)), Assign(' \
                             'targets=[Name(id="b", ctx=Store())], value=Num' \
                             '(n=6))])'

# Generated at 2022-06-21 18:42:37.417762
# Unit test for function get_parent
def test_get_parent():
    """Unit test for get_parent()."""
    import unittest
    import astunparse

    module = ast.parse("""
        x = 1
        y = 2
    """)

    assert get_parent(module, module.body[0]) == module
    assert get_parent(module, module.body[1]) == module
    assert get_parent(module, module.body[0].value) == module.body[0]
    assert get_parent(module, module.body[1].value) == module.body[1]
    assert get_parent(module, module.body[0].value.n) == module.body[0].value
    assert get_parent(module, module.body[1].value.n) == module.body[1].value


# Generated at 2022-06-21 18:42:46.157377
# Unit test for function get_parent
def test_get_parent():
    import astor

    test_ast = ast.parse('''
        a = [0, 1,
             2, 3]
    ''')
    test_ast = ast.fix_missing_locations(test_ast)

    # get_parent(test_ast, test_ast)
    # assert False
    node = get_closest_parent_of(test_ast, test_ast.body[0].value.elts[0],
                                 ast.FunctionDef)
    node = get_parent(test_ast, node)
    node = get_parent(test_ast, node.body[0].value.elts[0])
    print(astor.to_source(node))



# Generated at 2022-06-21 18:42:54.582366
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        """
        def f(x):
            if True:
                asdf = x
                print(asdf)
            else:
                pass
        """
    )

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[1])
    assert isinstance(parent, ast.If)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1].body[0])
    assert isinstance(parent, ast.If)

# Generated at 2022-06-21 18:43:01.970718
# Unit test for function get_parent
def test_get_parent():
    tree_str = """
    class A(object):
        def __init__(self):
            self.b = []
            self.c = []
    """

    tree = ast.parse(tree_str)
    node_1 = list(find(tree, ast.FunctionDef))[0]
    node_2 = list(find(tree, ast.ClassDef))[0]
    node_3 = list(find(tree, ast.Attribute))[0]

    assert get_parent(tree, node_1) == tree
    assert get_parent(tree, node_2) == tree
    assert get_parent(tree, node_3) == node_1



# Generated at 2022-06-21 18:43:14.552996
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    sum = ast.BinOp(left=x, op=ast.Add(), right=y)
    z = ast.Name(id='z', ctx=ast.Load())
    unit_test = ast.Expression(body=ast.Compare(left=sum, ops=[ast.Gt()], comparators=[z]))

    exp = get_non_exp_parent_and_index(unit_test, sum)[0]
    assert isinstance(exp, ast.Expression)

# Generated at 2022-06-21 18:43:24.833826
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class X(ast.AST):
        _fields = ('x',)

    class Y(ast.AST):
        _fields = ('y',)

    class Z(ast.AST):
        _fields = ('z',)

    class Root(ast.AST):
        _fields = ('root',)

    # <root>
    #   <x>
    #     <y>
    #       <z>
    root = Root()
    x = X()
    y = Y()
    z = Z()

    root.root = x
    x.x = y
    y.y = z

    _build_parents(root)

    assert get_closest_parent_of(root, z, Root) == root
    assert get_closest_parent_of(root, z, Y) == y

    # Test for

# Generated at 2022-06-21 18:43:33.149595
# Unit test for function insert_at
def test_insert_at():
    class Source:
        parent = ast.Module(body=[ast.FunctionDef(name='f', body=[
            ast.Return(value=ast.Num(n=1))
        ])])

        insert_target = parent.body[0]

    result = ast.Module(body=[ast.FunctionDef(name='f', body=[
        ast.Return(value=ast.Num(n=1))
    ]), ast.FunctionDef(name='f2', body=[
        ast.Return(value=ast.Num(n=1))
    ])])

    insert_at(0, Source.insert_target, ast.FunctionDef(
        name='f2', body=[ast.Return(value=ast.Num(n=1))]))

    assert ast.dump(Source.parent) == ast.dump(result)



# Generated at 2022-06-21 18:43:34.270858
# Unit test for function insert_at
def test_insert_at():
    assert True

# Generated at 2022-06-21 18:43:39.610419
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .test_import.test_automation import parse_ast
    ast_tree = parse_ast("if True:\n    print('hello world')")
    result_tree = get_non_exp_parent_and_index(ast_tree, ast_tree.body[0])
    assert result_tree == (ast_tree, 0)

# Generated at 2022-06-21 18:43:50.871960
# Unit test for function insert_at
def test_insert_at():
    from . import make_arg
    from . import make_assignment
    from . import make_expr
    from . import make_funcdef
    from . import make_module
    from . import make_return
    from . import make_stmt


# Generated at 2022-06-21 18:43:58.766340
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse("""x = "1" + "2" """)
    assert isinstance(get_parent(node, node.body[0].value.left), ast.BinOp)
    assert isinstance(get_parent(node, node.body[0].value.left.left), ast.Str)
    assert isinstance(get_parent(node, node.body[0].value.right), ast.BinOp)
    assert isinstance(get_parent(node, node.body[0].value.right.right), ast.Str)
    assert isinstance(get_parent(node, node.body[0].targets[0]),
                      ast.Assign)
    assert isinstance(get_parent(node, node.body[0]), ast.Module)



# Generated at 2022-06-21 18:44:04.784641
# Unit test for function get_parent
def test_get_parent():
    def f():
        return 1

    tree = ast.parse(f.__code__)
    assert 'return' in ast.dump(get_parent(tree, tree.body[0].value))
    assert 'FunctionDef' in ast.dump(get_parent(tree, tree.body[0].value))

# Generated at 2022-06-21 18:44:10.412486
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Expr(ast.Str('ok'))
    parent = ast.While(ast.Name('True', ast.Load()),
                       [ast.Expr(ast.UnaryOp(ast.Not(), ast.Name('True', ast.Load()))), node], [])

    real_parent, real_index = get_non_exp_parent_and_index(parent, node)

    assert real_parent is parent
    assert real_index == 1


# Generated at 2022-06-21 18:44:16.007444
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .nodes import Module
    from .nodes import FunctionDef
    from .parser import parse

    tree = parse(
        """
        def fun():
            print('some text')
        """
    )
    assert isinstance(tree, Module)
    assert isinstance(get_closest_parent_of(tree, tree.body[0], FunctionDef),
                      FunctionDef)



# Generated at 2022-06-21 18:44:25.636531
# Unit test for function replace_at
def test_replace_at():
    # test replace at
    node = ast.parse(
        """
    def test_function():
        print('test')
    """
    )
    parent = ast.parse(
        """
    def test_function():
        print('test')
        print('asd')
    """
    )
    replace_at(1, parent, node)

    expected = ast.parse(
        """
    def test_function():
        print('test')
        def test_function():
            print('test')
    """
    )

    assert ast.dump(expected) == ast.dump(parent)



# Generated at 2022-06-21 18:44:26.273894
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:44:30.502634
# Unit test for function find
def test_find():
    example_node = ast.parse('foo(a=True)')
    nodes = find(example_node, ast.Call)
    assert len(list(nodes)) == 1
    node = next(nodes)
    assert isinstance(node, ast.Call)


# Generated at 2022-06-21 18:44:32.987491
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 2')
    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]



# Generated at 2022-06-21 18:44:37.275970
# Unit test for function replace_at
def test_replace_at():
    def f1(x):
        return x
    def f2(x):
        a = f1(x)
        return a

    tree = ast.parse(f2)
    f2 = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, f1)
    replace_at(index, parent, f2)
    import astor
    print(astor.to_source(ast.parse(f1)))
    print(astor.to_source(tree))

# Generated at 2022-06-21 18:44:48.222018
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import os
    import sys
    dir_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, dir_path + '/../')
    from textx import get_model
    from textx.model import children_of_type

    my_model = get_model('examples/simple_example.simple')
    my_f1 = my_model.f1s[0]
    my_f2 = my_f1.f2s[0]
    my_f3 = my_f2.f3s[0]
    my_f4 = my_f3.f4s[0]

    # Test get_closest_parent_of function

# Generated at 2022-06-21 18:44:55.124251
# Unit test for function replace_at
def test_replace_at():

    # Replace statements of two If statements
    tree = ast.parse("""
    if a:
        if c:
            a = 5
        else:
            a = 7
    """)

    replace_at(2, tree.body[0],
               ast.parse("""if a and b:
                    a = 5
                    else:
                        a = 7
                    """).body[0])

    assert ast.dump(tree) == ast.dump(ast.parse("""
        if a:
            if a and b:
                a = 5
            else:
                a = 7
            """))

# Generated at 2022-06-21 18:45:03.241332
# Unit test for function get_parent
def test_get_parent():
    # build abstract syntax tree
    node = ast.Name("foo")
    node = ast.Assign(targets=[node],
                      value=ast.Num(n=1))
    node = ast.FunctionDef(name="bar",
                           body=[node],
                           args=ast.arguments())
    node = ast.Module(body=[node])

    # check if parent was built correctly
    _build_parents(node)

    parent, index = get_non_exp_parent_and_index(node, node.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    # check if rebuilding works and makes a new parent
    module_backup = node
    node.body[0].body[0] = ast.Name("foo", ctx=ast.Load())


# Generated at 2022-06-21 18:45:14.763006
# Unit test for function insert_at
def test_insert_at():

    test_ast = ast.parse("""
    import re
    from sklearn.model_selection import train_test_split
    
    def f(x, y, z):
        a = s + t
        if a:
            b = c + d
        else:
            e = e + f
            g = h + i
    """)

    insert_at(0, test_ast.body[3], ast.parse("x = 1").body[0])

# Generated at 2022-06-21 18:45:26.179690
# Unit test for function insert_at
def test_insert_at():
    def f():
        def g():
            pass

    tree = ast.parse('def g():\n    pass\ndef f():\n    pass')
    insert_at(1, tree.body[1], ast.parse('def h():\n    pass'))


# Generated at 2022-06-21 18:45:37.655962
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import ast_helper

    parent, index = get_non_exp_parent_and_index(ast_helper.tree, \
        ast_helper.target_node)

    assert parent == ast_helper.target_func
    assert index == 1



# Generated at 2022-06-21 18:45:42.073798
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('a = 1\npass'), ast.Name))) == 1
    assert len(list(find(ast.parse('a = 1\npass'), ast.Module))) == 1
    assert len(list(find(ast.parse('a = 1\nA = 1\npass'), ast.Name))) == 2

# Generated at 2022-06-21 18:45:48.961919
# Unit test for function get_parent
def test_get_parent():
    """Function tests get_parent function."""
    def function(
            args1: int,
            args2: int = 0,
            args3="kwargs1"):
        def inner_function():
            """Inner function doc string."""
            return 'hello'

        return inner_function()

    TREE = ast.parse(function.__code__.co_code)
    # print(ast.dump(TREE))

    # Get parent of FunctionDef and compare it with Module
    parent_function_def = get_parent(TREE, TREE.body[0])
    assert isinstance(parent_function_def, ast.Module)

    # Get parent of Return and compare it with FunctionDef
    parent_return = get_parent(TREE, TREE.body[0].body[1])

# Generated at 2022-06-21 18:45:55.982499
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Set up
    cls = ast.ClassDef(name='Test', body=[], decorator_list=[])
    mth = ast.FunctionDef(name='test', body=[], decorator_list=[])
    func = ast.With(body=[], items=[])
    func.body.append(mth)
    cls.body.append(func)

    # Tests
    assert get_closest_parent_of(cls, mth, ast.With) == func

# Generated at 2022-06-21 18:46:03.582318
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""
    def f():
        for i in range(4):
            print(i)
            continue
    """)
    print(ast.dump(tree))
    tree = ast.fix_missing_locations(tree)
    print(ast.dump(tree))
    insert_at(2, tree.body[0].body[0], ast.parse("""
    print(100)
    """).body[0])
    print(ast.dump(tree))


test_insert_at()

# Generated at 2022-06-21 18:46:06.401525
# Unit test for function find
def test_find():
   pass

# Generated at 2022-06-21 18:46:07.490822
# Unit test for function replace_at

# Generated at 2022-06-21 18:46:15.962589
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test simple case
    tree = ast.parse(
        """
        def foo():
            if bar():
                baz()
        """
    )
    foo_def = tree.body[0]
    foo_call = foo_def.body[0].body[0]

    assert isinstance(get_closest_parent_of(tree, foo_call, ast.FunctionDef),
                      ast.FunctionDef)

    # Test case with wrong type
    tree = ast.parse(
        """
        class Foo:
            def bar(self):
                self.baz()
                self.qux()
        """
    )
    baz_call = tree.body[0].body[0].body[0].value
    qux_call = tree.body[0].body[0].body[1].value


# Generated at 2022-06-21 18:46:27.325976
# Unit test for function find
def test_find():
    import unittest

    class TestFind(unittest.TestCase):
        def test_find_fstring(self):
            import astor

            class_node = ast.parse("""
            class Test():
                value = {var}
            """)

            fstrings = list(find(class_node, ast.JoinedStr))

            self.assertEqual(len(fstrings), 1)
            self.assertIsInstance(fstrings[0], ast.JoinedStr)
            self.assertIn("{var}", astor.to_source(fstrings[0]))

        def test_find_assignment(self):
            import astor

            class_node = ast.parse("""
            class Test():
                value = 42
            """)

            assingments = list(find(class_node, ast.Assign))



# Generated at 2022-06-21 18:46:39.407383
# Unit test for function get_parent
def test_get_parent():
    import astunparse
    import astpretty

    def function():
        a = 1
        b = 2
        c = 3

    tree = ast.parse(function.__code__)
    _build_parents(tree)
    a = tree.body[0].body[0].value.args[0]
    b = tree.body[0].body[1].value.args[0]
    c = tree.body[0].body[2].value.args[0]

    assert get_parent(tree, tree) is None
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]