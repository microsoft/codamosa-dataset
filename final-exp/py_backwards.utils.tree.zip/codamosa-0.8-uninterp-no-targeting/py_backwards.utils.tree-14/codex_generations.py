

# Generated at 2022-06-21 18:41:34.734142
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse('''
    import json
    import os
    def f():
        def g():
            pass
    
    x = 1
    
    
    ''')

    grand_parent = get_parent(node, node.body[0].body[0])
    assert isinstance(grand_parent, ast.FunctionDef)
    assert grand_parent.name == 'f'

# Generated at 2022-06-21 18:41:41.480441
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    
    tree = ast.parse(dedent("""
        def func():
            for x in range(10):
                pass
        
        class C:
            def __init__(self):
                pass
    
        if 1:
            pass
        
        """), 'test.py')
    assert list(find(tree, ast.FunctionDef)) == [tree.body[0]]
    assert list(find(tree, ast.ClassDef)) == [tree.body[1]]
    assert list(find(tree, ast.If)) == [tree.body[3]]

# Generated at 2022-06-21 18:41:53.421095
# Unit test for function insert_at
def test_insert_at():
    import unittest
    import sys

    class TestInsertAt(unittest.TestCase):
        def setUp(self):
            self.tree = ast.parse('x = 1')

        def test_inserts_at_not_last(self):
            insert_at(0, self.tree.body[0], ast.parse('y = 2').body[0])
            self.assertEqual(len(self.tree.body), 2)
            self.assertEqual(self.tree.body[0].lineno, 1)
            self.assertEqual(self.tree.body[1].lineno, 2)

        def test_inserts_at_last(self):
            insert_at(1, self.tree.body[0], ast.parse('y = 2').body[0])

# Generated at 2022-06-21 18:42:01.512683
# Unit test for function insert_at
def test_insert_at():
    import os
    import tempfile

    from typed_ast import ast3

    # create a temporary file
    fd, fname = tempfile.mkstemp()

    # now open the file with 'with' statement
    with os.fdopen(fd, 'w') as file:
        file.write('import foo')
    with open(fname) as file:
        code = file.read()

    tree = ast3.parse(code)
    module: ast3.Module = tree
    assert module.body[0].name == 'foo'
    insert_at(0, module, ast3.Import(names=[ast3.alias(name='bar')]))
    assert module.body[0].name == 'bar'

# Generated at 2022-06-21 18:42:04.144211
# Unit test for function get_parent
def test_get_parent():
    class TestClass(ast.AST):
        _fields = ['test_field']

    class TestParentClass(ast.AST):
        _fields = ['test_parent_field']

    this_test_class = TestClass()
    this_test_parent_class = TestParentClass()
    this_test_parent_class.test_parent_field = this_test_class
    _build_parents(this_test_parent_class)

    assert id(get_parent(this_test_parent_class, this_test_class)) == \
        id(this_test_parent_class)

# Generated at 2022-06-21 18:42:16.150124
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('\n'.join([
        'def testFunc(param: int, *args, **kwargs):',
        '    """Docstring"""',
        '    if param + 1 == 10:',
        '        return param + 1',
        '    else:',
        '        return param'
    ]), filename='file.txt')

    # Modifying FunctionDef node
    func_def = find(tree, ast.FunctionDef).__next__()
    replace_at(0, func_def, [ast.Pass()])

    # Modifying If node
    if_node = find(tree, ast.If).__next__()
    replace_at(2, if_node, [ast.Return(value=ast.NameConstant(value='None'))])

    # Modifying Else node
    else_node

# Generated at 2022-06-21 18:42:24.026278
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse(
        "print('Hello, world!')\n"
        "print(2*2)\n")
    parent = tree.body
    insert_at(0, parent, ast.parse("print(3*3)\n"))
    assert ast.dump(tree) == \
        "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load())"

# Generated at 2022-06-21 18:42:31.125941
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = "for i in range(10):\n print('hello')"
    tree = ast.parse(code)

    # Find the Print node and look for closest parent of For
    for node in find(tree, ast.Print):
        parent_of_print = get_closest_parent_of(tree, node, ast.For)

    assert isinstance(parent_of_print, ast.For)

# Generated at 2022-06-21 18:42:34.051721
# Unit test for function find
def test_find():
    import astunparse
    import ast
    example_tree = ast.parse('x = "123"; y = [1, 2, 3]; x')
    result = list(find(example_tree, ast.Str))
    assert astunparse.unparse(result[0]) == '"123"'


# Generated at 2022-06-21 18:42:45.071473
# Unit test for function get_parent
def test_get_parent():
    import astunparse

    node = ast.parse(
        'def fn(x, y):\n'
        '    return b if x == 0 else y\n'
        '\n'
        'fn(1, 0)'
    )

    _build_parents(node)

    # Check if parents are right
    assert get_parent(node, node.body[0].body[0].value.body) == node.body[0].body[0]  # noqa
    assert get_parent(node, node.body[0].body[0].value.orelse) == node.body[0].body[0]  # noqa
    assert get_parent(node, node.body[0].body[0]) == node.body[0]
    assert get_parent(node, node.body[0]) == node

# Generated at 2022-06-21 18:46:02.998409
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass



# Generated at 2022-06-21 18:46:07.191012
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # TODO
    pass

# Generated at 2022-06-21 18:46:13.210282
# Unit test for function insert_at
def test_insert_at():
    s = ast.parse("""if 0:
    print("Hello")
print("World")""")
    print("Original AST:")
    print(ast.dump(s))

    parent = s.body[1]
    insert_at(0, parent, ast.Expr(value=ast.Str("Hello")))

    print("Transformed AST:")
    print(ast.dump(s))


# Generated at 2022-06-21 18:46:27.370438
# Unit test for function replace_at
def test_replace_at():
    body = ast.parse("def foo():\n    pass\n    pass", mode='exec').body

    def save_position():
        pos = body[0].body[0].lineno
        body[0].body[0] = ast.parse("pass", mode='exec').body[0]
        body[0].body[0].lineno = pos

    replace_at(0, body[0], ast.parse("pass\npass", mode='exec').body)
    save_position()
    assert body[0].body[0].lineno == 2

    replace_at(0, body[0], ast.parse("pass\npass\npass", mode='exec').body)
    save_position()
    assert body[0].body[0].lineno == 3


# Generated at 2022-06-21 18:46:30.155234
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:46:37.730787
# Unit test for function find
def test_find():
    code = '''
    def baz(a: int) -> int:
        a += 1
        do_something_with(a)
        return a
    '''
    tree = ast.parse(code)
    first_name = list(find(tree, ast.Name))[0]
    assert first_name.id == 'do_something_with'



# Generated at 2022-06-21 18:46:41.228826
# Unit test for function get_parent
def test_get_parent():
    root = ast.parse('def main(): a = 1')
    get_parent(root, root)


if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-21 18:46:53.754869
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse(
        """
        if True:
            if False:
                print(True)
                if True:
                    print(True)
        """)
    _build_parents(tree)

    if_node = tree.body[0].body[1]
    assert isinstance(if_node, ast.If)

    if_parent = get_parent(tree, if_node)
    assert isinstance(if_parent, ast.If)

    new_if_node = ast.If(test=ast.Name(id='True', ctx=ast.Load()),
                         body=[ast.Pass()],
                         orelse=[])
    assert get_parent(tree, new_if_node) is None

    assert get_non_exp_parent_and_index(tree, if_node)[0] == if_

# Generated at 2022-06-21 18:46:58.661794
# Unit test for function get_parent
def test_get_parent():
    my_code = """
        if True:
            print('True')
    """

    tree = ast.parse(my_code)
    assert get_parent(tree, tree.body[0].body[0].value) == \
            tree.body[0].body[0]

# Generated at 2022-06-21 18:47:01.944381
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    a = [1, 2, 3]
    """)
    assert get_parent(tree, tree) == tree

# Generated at 2022-06-21 18:51:19.367317
# Unit test for function insert_at
def test_insert_at():
    body = [ast.Expr(value=ast.Name(id='hello', ctx=ast.Load()))]
    node = ast.Module(body=body)
    insert_at(0, node, ast.Expr(value=ast.Name(id='world', ctx=ast.Load())))
    assert node.body[0].value.id == 'world'
    assert node.body[1].value.id == 'hello'

# Generated at 2022-06-21 18:51:25.423291
# Unit test for function insert_at
def test_insert_at():
    n = ast.parse('a = 3')
    i = n.body.index(n.body[0])
    insert_at(i, n, ast.parse('b = 5'))

    assert ast.dump(n) == "b = 5\na = 3"


# Generated at 2022-06-21 18:51:29.051181
# Unit test for function replace_at
def test_replace_at():
    import astor
    t = ast.parse('import astor\nif x > 1: print(x)')
    replace_at(1, t, ast.parse('if x < 1:\n print(x)'))
    assert astor.to_source(t) == 'import astor\nif x < 1:\n print(x)'