

# Generated at 2022-06-21 18:41:53.276250
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..examples import test_exp
    from . import test_exp_body

    assert get_closest_parent_of(test_exp, test_exp_body[0],
                                 ast.FunctionDef) == test_exp.body[0]

# Generated at 2022-06-21 18:42:01.441284
# Unit test for function insert_at

# Generated at 2022-06-21 18:42:02.434889
# Unit test for function find

# Generated at 2022-06-21 18:42:06.635168
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
    def f():
        if True:
            a = 0
    ''')  # type: ignore

    assert get_non_exp_parent_and_index(tree,
                                        tree.body[0].body[0].body[0].value) == \
        (tree.body[0].body[0], 1)



# Generated at 2022-06-21 18:42:18.584669
# Unit test for function replace_at
def test_replace_at():
    import typed_ast.ast3 as ast
    class A:
        def __init__(self, body):
            self.body = body
        def __repr__(self):
            return "A(%s)" % self.body
    class B:
        def __repr__(self):
            return "B"
    class C:
        def __repr__(self):
            return "C"
    class D:
        def __repr__(self):
            return "D"
    a = A([B(), C(), D()])
    print(a)
    replace_at(1, a, [])
    print(a)
    replace_at(1, a, [B()])
    print(a)
    replace_at(2, a, [B(), C(), D(), B()])
    print

# Generated at 2022-06-21 18:42:26.381514
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("'''\nfun(a,b)\n'''\nx = 'example'")
    node1 = ast.Str('example')
    node2 = ast.Str("fun(a,b)")
    assert get_non_exp_parent_and_index(tree, node1) == (tree.body[1].value, 0)
    assert get_non_exp_parent_and_index(tree, node2) == (tree.body[0], 0)


# Generated at 2022-06-21 18:42:32.367854
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # noqa

    with open('ast_examples/complex.py') as f:
        tree = ast.parse(f.read())

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert isinstance(parent, ast.Module)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, parent.body[1])
    assert isinstance(parent, ast.Module)
    assert index == 1

# Generated at 2022-06-21 18:42:37.974046
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from astutils import parse
    from astutils.exceptions import NodeNotFound

    tree = parse("""
    import ast
    from typed_ast import ast3
    from astutils import ast3utils

    def convert(func: ast.FunctionDef, typed_func: ast3.FunctionDef) -> None:
        for node in ast.walk(func):
            if isinstance(node, ast.Yield):
                non_exp_parent, index = ast3utils.get_non_exp_parent_and_index(
                    func, node)
                replace_at(index, split_yield(node))
    """)

    non_exp_parent, index = get_non_exp_parent_and_index(tree,
                                                         tree.body[2].body[0].body[2])


# Generated at 2022-06-21 18:42:44.197842
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    mod = ast.parse('''
    def g(x):
        return 1
    def f():
        pass
    for i in range(10):
        pass
    ''')  # type:ignore
    stmts = mod.body
    call = stmts[0].body[0].value
    assert get_non_exp_parent_and_index(mod, call) == (stmts[0], 0)

# Generated at 2022-06-21 18:42:50.054054
# Unit test for function get_parent
def test_get_parent():
    main = ast.Module([ast.FunctionDef('main', ast.arguments([], None, None, []),
                                       [ast.Return(ast.Num(0))],
                                       [], None, None)])

    statement = main.body[0].body[0]

    assert statement is get_parent(main, statement)
    assert main.body[0] is get_parent(main, statement)


# Generated at 2022-06-21 18:43:02.224952
# Unit test for function replace_at
def test_replace_at():
    """Test if replacement of nodes actually works."""
    class A(ast.AST):
        _fields = ['a', 'b']  # type: List[str]

    class B(ast.AST):
        _fields = ['c', 'd']  # type: List[str]

    class C(ast.AST):
        _fields = ['e', 'f']  # type: List[str]

    class D(ast.AST):
        _fields = ['g', 'h']  # type: List[str]

    a = A()
    b = B()
    c = C()
    b.c = a
    b.d = c
    d = D()
    d.g = b
    d.h = b
    # b should be of class B, not of class D

# Generated at 2022-06-21 18:43:09.525949
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def func():
        def inner_func():
            return True
        return inner_func()
    tree = ast.parse('func()')
    func_def = get_closest_parent_of(tree, tree.body[0].value.func, ast.FunctionDef)
    inner_func_def = func_def.body[0]
    assert get_non_exp_parent_and_index(tree, inner_func_def) == (func_def, 0)

# Generated at 2022-06-21 18:43:10.770434
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:43:21.953390
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import jsonschema
    from ..ast import parse

    class JsonSchema(type(jsonschema)):
        def __init__(cls, *args, **kwargs):
            super().__init__(*args, **kwargs)
            cls.schema = {
                'type': 'object',
                'oneOf': [{
                    'type': 'object',
                    'properties': {
                        'type': {
                            'type': 'string'
                        }
                    },
                }]
            }

    JsonSchema.__module__ = 'jsonschema'


# Generated at 2022-06-21 18:43:25.287886
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse('''
    def func():
        pass

    func()
    ''')
    f = node.body[0]
    c = f.body[0]
    assert get_parent(node, c) == f
    assert get_parent(node, f) == node



# Generated at 2022-06-21 18:43:26.551562
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')  # type: ast.AST
    assert isinstance(find(tree, ast.Assign).__next__(), ast.Assign)

# Generated at 2022-06-21 18:43:30.431838
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    example = ast.parse('''
        def f():
            a = 42
            b = a
    ''')
    test_node = example.body[0].body[1].value
    parent, index = get_non_exp_parent_and_index(example, test_node)
    assert parent is example.body[0]
    assert index == 1

# Generated at 2022-06-21 18:43:31.868057
# Unit test for function insert_at
def test_insert_at():
    assert ast.parse("b = 1\nc = 2") == ast.parse("b = 1\nc = 2")



# Generated at 2022-06-21 18:43:43.511817
# Unit test for function replace_at
def test_replace_at():
    # Given
    node0 = ast.Pass()
    node1 = ast.Pass()
    node2 = ast.Pass()
    node3 = ast.Pass()
    node4 = ast.Pass()
    node5 = ast.Pass()

# Generated at 2022-06-21 18:43:44.520904
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

# Generated at 2022-06-21 18:43:57.029748
# Unit test for function insert_at
def test_insert_at():
    # Test for insert_at for single node in main module
    main_module = ast.parse("if True: return")
    insert_node = ast.parse("a = 5").body[0]
    insert_at(1, main_module, insert_node)
    assert ast.dump(main_module) == "Module(body=[If(test=NameConstant(value=True), body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=5)), Return(value=None)], orelse=[])])"

    # Test for insert_at for multiple nodes in the main module
    main_module = ast.parse("if True: return")
    insert_nodes = ast.parse("a = 5 \nb = 10").body

# Generated at 2022-06-21 18:44:09.386309
# Unit test for function replace_at
def test_replace_at():
    a = ast.parse(
        'def f():\n'
        '    a = 5\n'
        '    b = 7\n'
        '    print(a)\n'
        '    print(b)\n'
    )
    replace_at(1, a.body[0], ast.parse('c = 3').body[0])

# Generated at 2022-06-21 18:44:16.353297
# Unit test for function replace_at
def test_replace_at():
    """Unit test for function replace_at."""
    class DummyClass(object):
        pass
    dummy_class = DummyClass()
    dummy_class.body = ["HELLO1", "HELLO2", "HELLO3", "HELLO4"]
    replace_at(2, dummy_class, "WORLD")
    assert dummy_class.body == ["HELLO1", "HELLO2", "WORLD", "HELLO4"]



# Generated at 2022-06-21 18:44:17.228789
# Unit test for function find

# Generated at 2022-06-21 18:44:19.092360
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\n')
    num = find(tree, ast.Num).__next__()
    assert num.n == 1

# Generated at 2022-06-21 18:44:24.815369
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""def function():
    a = ""
    """)

    defs = find(tree, ast.FunctionDef)

    for def_ in defs:
        i = 0
        last_node = None

        for i, node in enumerate(def_.body):
            if node.__class__.__name__ == "Assign":
                insert_at(i+1, def_, node)
                break

        assert def_.body[i+1].__class__.__name__ == "Assign"



# Generated at 2022-06-21 18:44:30.403691
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
        def my_function():
            def my_inner_function():
                print('hello')
    """)
    node = tree.body[0].body[0].body[0]
    assert get_non_exp_parent_and_index(tree, node) == (
        tree.body[0].body[0],
        0
    )

# Generated at 2022-06-21 18:44:33.269311
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..exceptions import CodeGenError
    import pytest
    from typed_ast.ast3 import ClassDef, FunctionDef, Module

# Generated at 2022-06-21 18:44:36.009570
# Unit test for function find
def test_find():
    v = ast.Name(id='v')
    tree = ast.Module([ast.Assign([v], ast.Name(id='x'))])  # type: ast.Module
    assert list(find(tree, ast.Name)) == [v, ast.Name(id='x')]

# Generated at 2022-06-21 18:44:46.545646
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('1 + 2')
    assert isinstance(get_parent(tree, tree), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].value), ast.Expr)
    assert isinstance(get_parent(tree, tree.body[0].value.left), ast.BinOp)
    assert isinstance(get_parent(tree, tree.body[0].value.left.left), ast.Num)
    assert isinstance(get_parent(tree, tree.body[0].value.left.op), ast.Add)
    assert isinstance(get_parent(tree, tree.body[0].value.left.right), ast.Num)

# Generated at 2022-06-21 18:48:04.606451
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse(
        '''
        def main():
            if True:
                try:
                    if False:
                        pass
                except ValueError as err:
                    1
        '''
    )
    assert get_closest_parent_of(tree, tree.body[0], ast.FunctionDef) == tree.body[0]
    assert get_closest_parent_of(tree, tree.body[0], ast.Module) == tree

# Generated at 2022-06-21 18:48:16.887269
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as ast
    from pyannotate_runtime import collect_types
    collect_types.init_types_collection()
    my_tree = ast.parse('def f():  \n'
                        '    a = 1  \n'
                        '    b = 2  \n'
                        '    return a * b + 9')
    a = my_tree.body[0].body[0].value
    assert get_closest_parent_of(my_tree, a, ast.FunctionDef) == my_tree.body[0]
    assert get_closest_parent_of(my_tree, a, ast.Expr) == my_tree.body[0].body[0]
    assert get_closest_parent_of(my_tree, a, ast.If) is None

# Generated at 2022-06-21 18:48:27.764594
# Unit test for function replace_at
def test_replace_at():
    """Unit test for function replace_at."""
    import unittest
    import astunparse as astu
    import astor as ast_or

    class TestReplaceAt(unittest.TestCase):
        """Test class for replace_at."""

        def test_replace_at(self):
            """Test replace_at with simple insert."""
            test_ast = ast.parse('a = 1; b = 2; c = 3')
            new_ast = ast.parse('a = 1; b = 2; c = 3; d = 4')
            parent = test_ast.body[0]
            index = 2
            new_node = ast.parse('d = 4').body[0]

            replace_at(index, parent, new_node)


# Generated at 2022-06-21 18:48:39.040653
# Unit test for function replace_at
def test_replace_at():
    """Test for replace_at function."""
    import astor
    top = ast.Module(body=[])

    ast.fix_missing_locations(top)
    replace_at(0, top, ast.Expr(value=ast.Name(id='1', ctx=ast.Load())))
    ast.fix_missing_locations(top)
    print(astor.to_source(top))

    ast.fix_missing_locations(top)
    replace_at(0, top, ast.Expr(value=ast.Name(id='2', ctx=ast.Load())))
    ast.fix_missing_locations(top)
    print(astor.to_source(top))

    ast.fix_missing_locations(top)

# Generated at 2022-06-21 18:48:50.542139
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_ = ast.parse('def foo(): pass')
    func_def_node = ast_.body[0]
    parent_node = get_closest_parent_of(ast_, func_def_node, ast.Module)
    assert isinstance(parent_node, ast.Module)

    ast_ = ast.parse('a = 1')
    name_node = ast_.body[0].targets[0]
    parent_node = get_closest_parent_of(ast_, name_node, ast.Module)
    assert isinstance(parent_node, ast.Module)
    parent_node = get_closest_parent_of(ast_, name_node, ast.Assign)
    assert isinstance(parent_node, ast.Assign)

# Generated at 2022-06-21 18:48:53.065217
# Unit test for function replace_at
def test_replace_at():
    pass

# Generated at 2022-06-21 18:48:54.772294
# Unit test for function get_parent

# Generated at 2022-06-21 18:49:00.335270
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("_a = b + 1 + 3")
    if_stmt = get_non_exp_parent_and_index(tree, tree.body[0].value.right)
    assert if_stmt[1] == 0
    assert isinstance(if_stmt[0], ast.Module)

# Generated at 2022-06-21 18:49:07.334755
# Unit test for function insert_at
def test_insert_at():
    import astunparse
    tree = ast.parse('a = 5\ntree.insert_at(1, a)')
    parent = None

    for node in ast.walk(tree):
        if isinstance(node, ast.Module):
            parent = node

    tree.body.insert(1, ast.parse('b = 2'))
    replace_at(1, parent, ast.parse('b = 2'))
    print(astunparse.unparse(tree))
    assert str(tree) == '<_ast.Module object at 0x7f8ec8126b70>'

# Generated at 2022-06-21 18:49:12.708754
# Unit test for function replace_at
def test_replace_at():
    class A():
        pass
    a1 = A()
    a2 = A()
    a3 = A()
    a4 = A()
    a5 = A()
    a6 = A()

    B = type('B', (), {'body': [a1, a2, a3, a4, a5, a6]})
    index = 3

    replace_at(index, B, a3)

    # Check the result
    assert index == 3
    assert a3 not in B.body
    assert a4 in B.body
    assert a5 in B.body
    assert a6 in B.body