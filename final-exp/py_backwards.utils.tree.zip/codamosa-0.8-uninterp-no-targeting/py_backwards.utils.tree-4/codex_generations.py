

# Generated at 2022-06-21 18:41:43.305383
# Unit test for function insert_at
def test_insert_at():
    module = ast.parse('if x: pass')
    insert_at(1, module, ast.Expr(value=ast.Name(id='x')))
    assert ast.dump(module) == Module(body=[If(test=Name(id='x', ctx=Load()),
                                               body=[Pass()],
                                               orelse=[])])


# Generated at 2022-06-21 18:41:46.362508
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nif b < 3:\n    a = 2')
    nodes = find(tree, ast.Name)


# Generated at 2022-06-21 18:41:48.554441
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:41:53.720289
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
        def foo():
            if True:
                pass
            else:
                pass
    """)  # type: ast.AST
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent is tree
    assert index == 0

# Generated at 2022-06-21 18:42:00.565274
# Unit test for function insert_at
def test_insert_at():
    from pytest import raises

    node = ast.parse('[1, 2, 3]')  # type: ast.List
    insert_at(1, node, '4')

    assert node.elts[0].n == 1
    assert node.elts[1].s == '4'
    assert node.elts[2].n == 2
    assert node.elts[3].n == 3

    with raises(AttributeError):
        ast.Expression(node)


# Generated at 2022-06-21 18:42:08.794450
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from . import ast_helpers
    simple_sum = "a + b"
    tree = ast_helpers.parse(simple_sum, mode="eval")
    sum_node = tree.body.right
    assert(isinstance(sum_node, ast.BinOp))
    assert(isinstance(get_closest_parent_of(tree, sum_node, ast.Expression),
                      ast.Expression))
    assert(isinstance(get_closest_parent_of(tree, sum_node, ast.Module),
                      ast.Module))
    assert(isinstance(get_closest_parent_of(tree, sum_node, ast.Name),
                      ast.Name))

# Generated at 2022-06-21 18:42:20.481479
# Unit test for function replace_at
def test_replace_at():  # pragma: no cover
    from .faketree import fake_tree
    tree = fake_tree()
    result = ast.dump(tree)

# Generated at 2022-06-21 18:42:23.767216
# Unit test for function find
def test_find():

    src = """x = [1, 2, 3]"""
    tree = ast.parse(src, '<string>', 'exec')
    find(tree, ast.List)


# Generated at 2022-06-21 18:42:31.536979
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('if a: pass\nelif b: pass\nelse: pass')
    if_node = tree.body[0]
    replace_at(0, if_node, [ast.Pass(), ast.Pass()])
    assert (
        tree._repr()
        == 'Module(body=[If(test=Name(id="a", ctx=Load()), body=[Pass(), Pass()], '
        'orelse=[Elif(test=Name(id="b", ctx=Load()), body=[Pass()], orelse=[Pass()])])])'
    )

# Generated at 2022-06-21 18:42:38.053025
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a + b').body[0].value
    a = tree.left
    b = tree.right

    parent = get_parent(tree, a)

    
    replace_at(0, parent, b)

    assert(ast.dump(get_parent(tree, b)) == ast.dump(parent))
    assert(ast.dump(get_parent(tree, tree.left)) == ast.dump(b))

# Generated at 2022-06-21 18:42:47.606532
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    class TestClass(object):
        def TestFunc(self):
            print('test')
    def main():
        TestClass().TestFunc()
    """)

    # Test matching class
    test_parent = get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                        ast.ClassDef)
    assert(test_parent.name == 'TestClass')

    # Test matching func
    test_parent = get_closest_parent_of(tree,
                                        tree.body[0].body[0].body[0].body[0],
                                        ast.FunctionDef)
    assert(test_parent.name == 'TestFunc')

# Generated at 2022-06-21 18:42:49.078800
# Unit test for function insert_at

# Generated at 2022-06-21 18:42:59.168888
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class TestTree(ast.AST):
        def __init__(self, x, y, z):
            self.x = x
            self.y = y
            self.z = z

    test_tree = TestTree(
        TestTree(ast.Expr(ast.Str('x')), ast.Expr(ast.Str('y')), ast.Str('z')),
        ast.Expr(ast.Str('x')), ast.Str('y'))
    assert get_non_exp_parent_and_index(test_tree, test_tree.x) == \
        (test_tree, 0)
    assert get_non_exp_parent_and_index(test_tree, test_tree.x.x) == \
        (test_tree.x, 0)

# Generated at 2022-06-21 18:43:02.750971
# Unit test for function find
def test_find():
    tree = ast.parse('a = 3\nx = 1')
    assert len(list(find(tree, ast.NameConstant))) == 2
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Assign))) == 2

# Generated at 2022-06-21 18:43:08.791248
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast
    tree = ast.parse('a = 1\nprint(a)')
    node = tree.body[1].value
    node_parent, node_index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(node_parent, ast.Module)
    assert isinstance(node_index, int)
    assert node_index == 1

# Generated at 2022-06-21 18:43:19.411562
# Unit test for function replace_at
def test_replace_at():
    test_tree = ast.parse('''
        def test():
            print('1')
            print('2')
            print('3')

        def test2():
            print('a')
            print('b')
            print('c')
    ''')
    parent, index = get_non_exp_parent_and_index(
        test_tree, test_tree.body[0].body[0])
    replace_at(index, parent, ast.parse('print("0")').body[0])  # type: ignore
    assert test_tree.body[0].body[0].value.s == '0'


if __name__ == '__main__':
    test_replace_at()

# Generated at 2022-06-21 18:43:31.371569
# Unit test for function insert_at
def test_insert_at():
    """
    Unit test for function insert_at
    :return:
    """
    mod = ast.Module((),
                     [], [])

    body = mod.body

    assert len(body) == 0
    insert_at(0, mod, ast.Expr(value=ast.Name(id='1', ctx=ast.Load())))
    assert len(body) == 1
    insert_at(1, mod, ast.Expr(value=ast.Name(id='2', ctx=ast.Load())))
    assert len(body) == 2
    insert_at(1, mod, ast.Expr(value=ast.Name(id='3', ctx=ast.Load())))
    assert len(body) == 3
    assert body[0].value.id == '1'

# Generated at 2022-06-21 18:43:32.853835
# Unit test for function find

# Generated at 2022-06-21 18:43:42.065588
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('''
    def foo():
        pass
        pass
        pass
        pass
    ''')
    replace_at(1, tree.body[0], ast.parse('pass').body[0])
    assert ast.dump(tree) == '''
    Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None,
    kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass(), Pass
    (), Pass(), Pass(), Pass()], decorator_list=[], returns=None)])
    '''

# Generated at 2022-06-21 18:43:47.722083
# Unit test for function get_parent
def test_get_parent():
    source = """
        def foo():
            for i in range(1):
                print(i)
            return 1
    """
    tree = ast.parse(source)
    parent = get_parent(tree, tree.body[0].body[0].body[0])

    # Check if we found the right node
    assert isinstance(parent, ast.For)



# Generated at 2022-06-21 18:43:53.575848
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .fixtures import parent_tree
    from .fixtures import parent_tree_typecheck

    assert get_closest_parent_of(parent_tree, parent_tree_typecheck, ast.Module) is parent_tree_typecheck

# Generated at 2022-06-21 18:44:00.431614
# Unit test for function replace_at
def test_replace_at():
    import astor as _astor
    tree = ast.parse('''
    x = 1
    ''')

    # Replace x with x+1
    node = tree.body[0]  # type: ast.Assign
    parent = get_parent(tree, node)
    assert parent is tree

    new_node = ast.Assign(
        targets=[node.targets[0]],
        value=ast.BinOp(node.value, op=ast.Add(), values=ast.Num(2))
    )
    replace_at(index=0, parent=parent, nodes=new_node)

    assert _astor.to_source(tree) == '''
    x = (1 + 2)
    '''

    # Replace binop with binop and assign
    node = tree.body[0].value

# Generated at 2022-06-21 18:44:10.851657
# Unit test for function insert_at
def test_insert_at():
    x = ast.parse('x + y')
    assert hasattr(x, 'body')
    x.body = [ast.Expr(value=ast.BinOp(left=ast.Name(id='x', ctx=ast.Load()),
                                       op=ast.Add(),
                                       right=ast.Name(id='y', ctx=ast.Load())))]

    body = get_closest_parent_of(x, x.body[0], ast.Module)

    insert_at(0, body, ast.parse('z'))

# Generated at 2022-06-21 18:44:18.090366
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_ast = filter(lambda x: x is not None,
                      ast.parse("""
                        function(x):
                            return x
                    """))
    test_return_stmt = get_closest_parent_of(test_ast, test_ast.body[0].body[0], ast.Return)
    parent, index = get_non_exp_parent_and_index(test_ast, test_return_stmt)
    assert isinstance(parent, ast.FunctionDef) \
        and parent == test_ast.body[0] and index == 0

# Generated at 2022-06-21 18:44:18.846392
# Unit test for function get_parent

# Generated at 2022-06-21 18:44:28.322240
# Unit test for function insert_at
def test_insert_at():
    fdef = ast.parse('def f():\n    1\n    2\n    3\n\n    pass', mode='exec')
    parent, index = get_non_exp_parent_and_index(fdef, fdef.body[0].body[0])
    assert parent.body[index].n == 1
    insert_at(index, parent, ast.Num(5))
    assert parent.body[index].n == 5
    insert_at(index, parent, [ast.Num(6), ast.Num(7)])
    assert parent.body[index].n == 6
    assert parent.body[index+1].n == 7



# Generated at 2022-06-21 18:44:36.814056
# Unit test for function replace_at
def test_replace_at():
    import inspect
    import os
    import astor

    # Load target file
    target_path = os.path.join(
        os.path.dirname(__file__), os.pardir, 'examples', 'swift')
    with open(os.path.join(target_path, 'input.py'), 'r') as f:
        file_content = f.read()

    # Parse file
    target_tree = ast.parse(file_content)

    # Find the "return" to be replaced
    node = next(find(target_tree, ast.Return))

    # Find the parent to be replaced
    parent = get_parent(target_tree, node)

    # Find the index
    index = parent.body.index(node)

    # First create the replacement node

# Generated at 2022-06-21 18:44:37.890591
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:44:48.923468
# Unit test for function insert_at
def test_insert_at():
    t = ast.parse("import sys")
    insert_at(0, t.body[0], [ast.Import([ast.alias("os", None)])])
    assert ast.dump(t) == "import sys\nimport os\n"

    t = ast.parse("import sys")
    insert_at(1, t.body[0], [ast.Import([ast.alias("os", None)])])
    assert ast.dump(t) == "import sys\nimport os\n"

    t = ast.parse("import os\nimport sys")
    insert_at(1, t.body[0], [ast.Import([ast.alias("os", None)])])
    assert ast.dump(t) == "import os\nimport sys\nimport os\n"


# Generated at 2022-06-21 18:44:53.860735
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    tree = astor.parse('def foo(x):\n  if x > 2:\n    x += 1\n  return x')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-21 18:45:00.753536
# Unit test for function find
def test_find():
    tree = ast.parse("test = 1\nif test == 1:\n    print(test)")
    parent = get_closest_parent_of(tree, tree.body[1], ast.Module)
    print(parent)


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-21 18:45:08.361979
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    print(5)')
    node = find(tree, ast.Name).__next__()

    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.FunctionDef)
    assert isinstance(parent.body[index], ast.Expr)  # type: ignore
    assert isinstance(parent.body[index].value, ast.Name)  # type: ignore

# Generated at 2022-06-21 18:45:09.695074
# Unit test for function replace_at
def test_replace_at():
    def foo(a):
        return a


# Generated at 2022-06-21 18:45:14.715505
# Unit test for function replace_at
def test_replace_at():
    node = ast.parse("def foo():\n    bar()\n    baz()\n").body[0]
    parent, index = get_non_exp_parent_and_index(node, node.body[0])
    replace_at(index, parent, node.body[1])

    assert parent.body[1] == node.body[1]  # type: ignore

# Generated at 2022-06-21 18:45:20.634407
# Unit test for function insert_at
def test_insert_at():
    def empty_function():
        pass

    tree = ast.parse('def f():\n    pass')
    empty_function_ast = tree.body[0]
    body = empty_function_ast.body
    print(body)
    insert_at(0, body, ast.parse('print("test")'))
    assert body[0].value.values[0].s == 'test'

# Generated at 2022-06-21 18:45:22.039939
# Unit test for function find

# Generated at 2022-06-21 18:45:28.134891
# Unit test for function find
def test_find():
    find_f = lambda x: 2*x
    find_f_ast = ast.parse(find_f.__code__)
    print(find(find_f_ast, ast.For))
    print(find(find_f_ast, ast.FunctionDef))
    print(find(find_f_ast, ast.Expr))
    print(find(find_f_ast, ast.Lambda))
    print(find(find_f_ast, ast.BinOp))



# Generated at 2022-06-21 18:45:39.540718
# Unit test for function find
def test_find():
    t1 = ast.parse('a = 1\nfor x in range(10):\n    b = 1\nc = 1')
    assert len([n for n in find(t1, ast.Assign)]) == 2
    assert len([n for n in find(t1, ast.Call)]) == 0
    assert len([n for n in find(t1, ast.For)]) == 1
    assert len([n for n in find(t1, ast.Name)]) == 3
    assert len([n for n in find(t1, ast.Load)]) == 3
    t2 = ast.parse('a = 1\nfor x in range(10):\n    pass\nc = 1')
    assert len([n for n in find(t2, ast.Assign)]) == 2

# Generated at 2022-06-21 18:45:45.732419
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Tree:
        pass

    class Parent:
        pass

    class Node(Parent):
        pass

    tree = Tree()
    parent = Parent()
    node = Node()
    node2 = Node()
    node3 = Node()
    node4 = Node()
    _build_parents(tree)
    _parents[node2] = node
    _parents[node3] = node2
    _parents[node4] = node3
    result = get_closest_parent_of(tree, node4, Parent)
    assert result == node2

# Generated at 2022-06-21 18:45:51.842274
# Unit test for function replace_at
def test_replace_at():
    for tree in [ast.parse("x = 1\n2*y\ny = 5/6\n")]:
        for node in ast.walk(tree):
            if isinstance(node, ast.Name):
                parent = get_parent(tree, node)
                index = parent.body.index(node)
                replace_at(index, parent, ast.Name(id='z'))
                assert index == 0
                break

# Generated at 2022-06-21 18:46:04.316084
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for get_non_exp_parent_and_index."""
    statement = ast.parse('x = 1 + 2').body[0]
    assignment = get_non_exp_parent_and_index(statement, statement.value.left)
    assert assignment == (statement, 0)

    statement = ast.parse('x = y = z').body[0]
    assignment = get_non_exp_parent_and_index(statement, statement.value.left)
    assert assignment == (statement, 0)

    statement = ast.parse('print(1 + 2)').body[0]
    call = get_non_exp_parent_and_index(statement, statement.value.args[0])
    assert call == (statement.value, 0)

# Generated at 2022-06-21 18:46:10.581717
# Unit test for function find
def test_find():
    tree = ast.parse('if a:\n\tb\nmodule: a+b')
    ifnode = list(find(tree, ast.If))[0]
    modulename= list(find(tree, ast.Name))[1]
    assert isinstance(ifnode, ast.If)
    assert isinstance(modulename, ast.Name)


# Generated at 2022-06-21 18:46:14.858018
# Unit test for function get_parent
def test_get_parent():
    code = '''
if True:
    if False:
        pass
else:
    pass
    '''
    tree = ast.parse(code)
    _build_parents(tree)
    parent = get_parent(tree, tree.body[0].body[0], rebuild=False)
    assert isinstance(parent, ast.If)




# Generated at 2022-06-21 18:46:19.063478
# Unit test for function find
def test_find():
    tree = ast.parse('y = 1 + 2 + 3')
    nums = list(find(tree, ast.Num))
    assert len(nums) == 3, 'Find didn\'t find 3 numbers in the tree'



# Generated at 2022-06-21 18:46:26.738964
# Unit test for function insert_at
def test_insert_at():
    def f():
        for a in range(7):
            print(a)

    t = ast.parse(inspect.getsource(f))  # type: ast.Module
    for_node = t.body[0]

    # Insert statement.
    insert_at(0, for_node, ast.parse('print(1)'))

    t = ast.parse(inspect.getsource(f))  # type: ast.Module
    assert(len(t.body[0].body) == 2)

# Generated at 2022-06-21 18:46:37.536210
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('x = 1\nprint(x)')
    assign = ast.Assign(targets=[ast.Name('x', ast.Store())],
                        value=ast.Num(1))
    print_ = ast.Print(ast.Name('x', ast.Load()))

    replace_at(0, tree, assign)
    replace_at(1, tree, print_)

    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store(), annotation=None)], value=Num(n=1)), Print(dest=None, values=[Name(id=\'x\', ctx=Load(), annotation=None)], nl=True)])'

# Generated at 2022-06-21 18:46:46.159782
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

    class TestAst(ast.AST):
        _fields = ('value',)

    def test(value=1):
        x = TestAst(value=value)
        while x.value > 0:
            y = x
            x = TestAst(value=x.value - 1)
        return x.value + y.value

    tree1 = ast.parse(test.__doc__)
    tree2 = ast.parse(test.__doc__)
    ast.fix_missing_locations(tree2)


# Generated at 2022-06-21 18:46:57.933243
# Unit test for function replace_at
def test_replace_at():
    func_def = ast.parse('def foo(x): return x * 2')
    func_def_parent = ast.parse('def foo(x): return x * 2').body[0]
    if_stmt = ast.parse('def foo(x): return if x: return x * 2').body[0].body[0]
    func_def_return = ast.parse('def foo(x): return x * 2').body[0].body[0]
    func_def_return_parent = ast.parse(
        'def foo(x): return x * 2').body[0].body[0].value

    replace_at(1, func_def_parent, if_stmt)
    assert isinstance(func_def_parent.body[1], ast.If)


# Generated at 2022-06-21 18:47:07.584894
# Unit test for function insert_at
def test_insert_at():
    import astor
    from ast import FunctionDef, Call, Name

    def foo(a: FunctionDef):
        a.body.extend([ast.parse('f1()').body[0]])
        insert_at(0, a, Call(Name('f2', Load()), [], [], None, None))
        insert_at(2, a, Call(Name('f3', Load()), [], [], None, None))

    res = foo(ast.parse('def foo():\n pass').body[0])
    assert astor.to_source(res) == (
        'def foo():\n    f2()\n    pass\n    f3()\n')

# Generated at 2022-06-21 18:47:15.528784
# Unit test for function get_parent
def test_get_parent():
    import unittest
    from . import builder

    class TestGetParent(unittest.TestCase):
        def setUp(self):
            self.tree = builder.build(
                '''\
                    def foo():
                        bar()
                        if True:
                            bar()
                            bar()
                        elif False:
                            bar()
                        else:
                            bar()
                    def baz():
                        pass
                    class Foo:
                        def __init__(self):
                            pass
                '''
            )

        def test_parent_search_in_function(self):
            call = find(self.tree, ast.Call).__next__()

            parent = get_parent(self.tree, call)
            self.assertIsInstance(parent, ast.If)


# Generated at 2022-06-21 18:47:26.506209
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from pytest import raises
    from .fixtures import get_test_tree
    from .fixtures import get_test_tree_correct

    with raises(NodeNotFound):
        get_closest_parent_of(get_test_tree(),
                              1,
                              ast3.With)

    with raises(NodeNotFound):
        get_closest_parent_of(get_test_tree_correct(),
                              1,
                              ast3.With)

    assert isinstance(get_closest_parent_of(get_test_tree(),
                                            get_test_tree(),
                                            ast3.Module),
                      ast3.Module)


# Generated at 2022-06-21 18:47:37.132773
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # pylint: disable=unused-variable
    from . import sample
    from ..exceptions import NodeNotFound
    from ..utils import to_type_ast

    ast_ = to_type_ast(sample.sample1)

    func_def = ast.FunctionDef(
        name='foo',
        body=[
            ast.Expr(value=ast.BinOp(
                left=ast.Num(n=1),
                op=ast.Add(),
                right=ast.Num(n=2)
            ))
        ],
        decorator_list=[],
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        )
    )

    expr = ast

# Generated at 2022-06-21 18:47:43.792284
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # noqa: D301
    import astor
    tree = ast.parse('if True: a = b')
    if_node = tree.body[0]
    ass_node = if_node.body[0]
    assert(astor.to_source(get_non_exp_parent_and_index(tree, ass_node)[0])
           == 'if True:')

# Generated at 2022-06-21 18:47:47.572779
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module = ast.parse('def f():\n\tdef a():\n\t\t1 + 1\n\t1 + 2\n\n')
    function_def = next(find(module, ast.FunctionDef))
    sum_node = next(find(module, ast.BinOp))

    assert get_closest_parent_of(module, sum_node, ast.FunctionDef) == \
        function_def
    # Test raise
    assert_raises(NodeNotFound, get_closest_parent_of,
                  module, sum_node, ast.arguments)

# Generated at 2022-06-21 18:47:48.357670
# Unit test for function replace_at
def test_replace_at():
    assert 1 == 2

# Generated at 2022-06-21 18:47:50.145029
# Unit test for function find
def test_find():
    import ast
    import astor

# Generated at 2022-06-21 18:47:52.816218
# Unit test for function get_parent
def test_get_parent():
    parent = ast.Module(body=[])
    child = ast.Name(id='test', ctx=ast.Load())

    parent.body.append(child)

    assert get_parent(parent, child) == parent

# Generated at 2022-06-21 18:47:54.011512
# Unit test for function get_closest_parent_of

# Generated at 2022-06-21 18:48:06.591610
# Unit test for function insert_at
def test_insert_at():
    # Build ast
    import astor
    source = """
        def function(arg1, arg2):
            x = arg1 + arg2

            return x
    """
    code = astor.parse_file(io.StringIO(source))
    code = ast.fix_missing_locations(code)

    # Get parent and index for the first assignment
    parent, index = get_non_exp_parent_and_index(code, code.body[0].body[0])

    # Insert new node at the index
    node = ast.Assign(targets=[ast.Name(id='y',
                                        ctx=ast.Store())],
                      value=ast.Num(n=4))

# Generated at 2022-06-21 18:48:14.571404
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import parse
    from pprint import pprint

    tree = parse("""
    if 0:
        a = 0

        if 1:
            b = 1
        else:
            c = 2
        d = 3
    else:
        e = 4

    """)

    a_node = get_closest_parent_of(tree, tree.body[0].body[1].body[0],
                                   ast.Assign)
    p, i = get_non_exp_parent_and_index(tree, a_node)

    print(ast.dump(p))
    print(i)

    pprint(_parents)

# Generated at 2022-06-21 18:48:21.499273
# Unit test for function get_parent

# Generated at 2022-06-21 18:48:27.291221
# Unit test for function replace_at
def test_replace_at():
    import astor
    module = astor.parse_file('test/fixtures/test.py')
    parent = module.body[7]
    import_node = ast.Import(names=[ast.alias('sys', None)])
    replace_at(2, parent, import_node)
    print(astor.to_source(module))


__all__ = ('get_parent', 'get_non_exp_parent_and_index', 'find', 'insert_at',
           'replace_at', 'get_closest_parent_of',)

# Generated at 2022-06-21 18:48:38.486826
# Unit test for function get_parent
def test_get_parent():
    code = inspect.cleandoc("""
    def function_name(arg1, arg2):
        return arg1 + arg2
    """)

    module = ast.parse(code)

    # Find FunctionDef
    for node in ast.walk(module):
        if isinstance(node, ast.FunctionDef):
            assert get_parent(module, node) == module

    # Find Assign
    for node in ast.walk(module):
        if isinstance(node, ast.Assign):
            assert get_parent(module, node) == module

    # Find arguments
    for node in ast.walk(module):
        if isinstance(node, ast.arguments):
            assert get_parent(module, node) is not None

    # Find Name

# Generated at 2022-06-21 18:48:39.399808
# Unit test for function insert_at

# Generated at 2022-06-21 18:48:44.546040
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("for i in range(10): i += 1")
    parent = get_closest_parent_of(tree, tree.body[0].body[0],
                                   ast.For)
    insert_at(parent.body.index(tree.body[0].body[0]), parent,
              ast.parse('i += 2').body[0])
    assert len(parent.body) == 2
    assert parent.body[0].value.left.id == 'i'
    assert isinstance(parent.body[1], ast.AugAssign)
    assert parent.body[1].value.left.id == 'i'



# Generated at 2022-06-21 18:48:53.227608
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    name_node = tree.body[0].targets[0]
    # retrieve the parent node of "a"
    a_parent = get_parent(tree, name_node)
    assert(isinstance(a_parent, ast.Assign))
    try:
        # now remove the node from the tree
        del name_node
        # re-add the parent to the tree
        tree.body.append(a_parent)
        # and retrieve it again. this should now fail
        get_parent(tree, name_node)
        assert(False)
    except:
        assert(True)
        return
    assert(False)



# Generated at 2022-06-21 18:48:57.296135
# Unit test for function get_parent
def test_get_parent():
    import astor
    test_ast = astor.parse_file("testfile")
    test_node = test_ast.body[0].body[0]
    assert get_parent(test_ast, test_node) == test_ast.body[0]


# Generated at 2022-06-21 18:49:01.329842
# Unit test for function find
def test_find():
    with open('test.py', 'r') as file:
        tree = ast.parse(file.read())

    for s in find(tree, ast.Assign):
        print(s)



# Generated at 2022-06-21 18:49:02.319949
# Unit test for function get_parent

# Generated at 2022-06-21 18:49:06.276503
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = """def foo(a, b):
    def bar():
        pass
    return bar"""
    tree = ast.parse(source)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert index == 0
    assert parent is tree.body  # type: ignore

# Generated at 2022-06-21 18:49:15.381233
# Unit test for function insert_at
def test_insert_at():
    import astor

# Generated at 2022-06-21 18:49:18.197682
# Unit test for function get_parent
def test_get_parent():
    assert isinstance(
        get_parent(
            ast.parse("""
print('hello')
"""
                     ),
            ast.parse("print('hello')").body[0]
        ),
        ast.Module
    )


# Generated at 2022-06-21 18:49:19.850407
# Unit test for function get_closest_parent_of

# Generated at 2022-06-21 18:49:29.328180
# Unit test for function insert_at
def test_insert_at():
    import typed_ast.ast3 as ast
    f = ast.FunctionDef(name='test', body=[
        ast.Expr(value=ast.Name(id='a')),
        ast.Expr(value=ast.Name(id='b')),
        ast.Expr(value=ast.Name(id='c'))],
        args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[])
    )
    insert_at(1, f, ast.Expr(value=ast.Name(id='d')))
    assert f.body[1].value.id == 'd'
    assert f.body[3].value.id == 'b'

# Generated at 2022-06-21 18:49:34.683456
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1 + 2')
    replace_at(1, tree, ast.Num(3))
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=a, ctx=Store())], value=BinOp(left=Num(n=1), op=Add(), right=Num(n=3)))])'

# Generated at 2022-06-21 18:49:39.806758
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Name(id = "a") # type: ignore
    exp = ast.Expression(node)
    suite = ast.Suite()
    suite.body.append(exp)

    parent, idx = get_non_exp_parent_and_index(suite, node)

    assert idx == 0
    assert isinstance(parent, ast.Suite)



# Generated at 2022-06-21 18:49:45.312103
# Unit test for function replace_at
def test_replace_at():
    from .. import TransformVisitor

    class ReplaceAtTransformer(TransformVisitor):

        def visit_Call(self, node: ast.Call) -> None:
            parent, index = get_non_exp_parent_and_index(self.tree, node)

            replace_at(index, parent, ast.parse(
                'a = 1; b = a + 1; print(a + b)'))


# Generated at 2022-06-21 18:49:52.378840
# Unit test for function insert_at
def test_insert_at():
    node = ast.parse("a = 1\na = 3")
    insert_at(1, node, ast.Assign(lineno=0, col_offset=0, targets=[ast.Name(id="b", ctx=ast.Store())], value=ast.Num(n=2)))
    assert str(node) == "a = 1\na = 3\nb = 2\n"


# Generated at 2022-06-21 18:49:54.565345
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():  # pragma: no cover
    from typed_ast import ast3 as ast

# Generated at 2022-06-21 18:50:05.425398
# Unit test for function find
def test_find():
    node1 = ast.Expr(value=ast.Num(n=1))
    node2 = ast.Expr(value=ast.Num(n=2))
    node3 = ast.Expr(value=ast.Num(n=3))
    node4 = ast.Expr(value=ast.Num(n=4))
    node5 = ast.Expr(value=ast.Num(n=5))
    node6 = ast.Expr(value=ast.Num(n=6))

    tree = ast.Module(body=[node1, node2, node3, node4, node5, node6,
                            ast.Expr(value=ast.Num(n=7))])

    assert node2 in list(find(tree, ast.Expr))

# Generated at 2022-06-21 18:50:28.982827
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_tree = ast.parse('function = lambda x, y: x + y')
    node = ast_tree.body[0].value.args.args[1]
    parent_func_def = get_closest_parent_of(ast_tree, node, ast.FunctionDef)

    assert isinstance(parent_func_def, ast.FunctionDef)
    assert parent_func_def.name == 'function'

# Generated at 2022-06-21 18:50:37.276458
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # The actual AST node
    node = ast.AST()

    # The tree to be searched
    tree = ast.Module(
        body=[
            ast.Expr(
                value=ast.BinOp(
                    left=ast.Name(id='a', ctx=ast.Load()),
                    op=ast.Add(),
                    right=ast.Name(id='b', ctx=ast.Load())
                )
            )
        ]
    )

    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, node, ast.Expr), ast.Expr)

# Generated at 2022-06-21 18:50:39.122709
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():  # pylint: disable=unused-argument
    import astor

# Generated at 2022-06-21 18:50:44.678149
# Unit test for function find
def test_find():
    import astor
    code = "my_list1 = [0, 1, 2, 3]"
    node = ast.parse(code)
    _build_parents(node)
    print (astor.to_source(node))
    print ("There is {} list in the code".format(len(list(find(node,ast.List)))))
    
if __name__ == '__main__':
    test_find()

# Generated at 2022-06-21 18:50:50.882885
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astunparse
    import sys
    test_case = ast.parse('''def fun(x): return x + 5 if x == 0 else x''')
    node = test_case.body[0].body[0].body[1]
    parent, index = get_non_exp_parent_and_index(test_case, node)
    expected = 'return x + 5 if x == 0 else x'
    assert astunparse.unparse(node) == expected
    assert astunparse.unparse(parent) == expected
    assert index == 1



# Generated at 2022-06-21 18:51:01.583598
# Unit test for function get_parent
def test_get_parent():
    import astor
    a = astor.parse_file('/home/kamilw/workspace/pystan/stan/tests/test_end_to_end.py')

    # string = astor.dump_tree(a)
    # print(string)
    #
    # node = a.body[0].body[0].body[0].body[0].body[3].body[0].body[0]
    #
    # print(astor.to_source(node))
    #
    # get(a, node)
    def _test_node(node):
        parent = get_parent(a, node)
        assert isinstance(parent, ast.ClassDef)

        if isinstance(node, ast.FunctionDef):
            assert node.name == 'test_fit_class'

# Generated at 2022-06-21 18:51:06.482642
# Unit test for function find
def test_find():
    tree = ast.parse("""
        def fun(a, b=1):
            x = 0
            for i in range(10):
                print(i)
    """)
    assert [y.id for y in find(tree, ast.Name)] == ['fun', 'a', 'b', 'x', 'i', 'print']  # type: ignore

if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-21 18:51:17.601399
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse(
        "def f():\n" +
        "    if True:\n" +
        "        print(42)\n")

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].test, ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].test, ast.If), ast.If)

test_get_closest_

# Generated at 2022-06-21 18:51:21.786908
# Unit test for function find
def test_find():
    tree = ast.parse('a = b == c')  # type: ignore
    assert list(find(tree, ast.Expr)) == [ast.Expr(value=ast.Compare(
        left=ast.Name(id='a', ctx=ast.Store()),
        ops=[ast.Eq()],
        comparators=[ast.Name(id='c', ctx=ast.Load())]))]



# Generated at 2022-06-21 18:51:26.723545
# Unit test for function replace_at
def test_replace_at():
    import unittest
    import astor

    class Func(unittest.TestCase):
        def test(self):
            params = ast.arguments(
                args=[
                    ast.arg(arg='a', annotation=None),
                    ast.arg(arg='b', annotation=None),
                ],
                vararg=None,
                kwonlyargs=[
                    ast.arg(arg='kwarg1', annotation=None),
                ],
                kw_defaults=[
                    ast.NameConstant(value=True),
                ],
                kwarg=None,
                defaults=[
                    ast.NameConstant(value=False),
                    ast.NameConstant(value=True),
                ]
            )
