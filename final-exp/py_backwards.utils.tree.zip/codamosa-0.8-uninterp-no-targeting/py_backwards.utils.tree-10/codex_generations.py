

# Generated at 2022-06-21 18:41:51.020848
# Unit test for function insert_at
def test_insert_at():
    file_input = """
    def test(a, b):
        a = 3
        b = 4
        return a + b
    """
    tree = ast.parse(file_input)
    _build_parents(tree)
    element_to_insert = ast.parse("return 2").body[0]
    insert_at(3, tree.body[0].body, element_to_insert)
    assert tree == ast.parse("""
    def test(a, b):
        a = 3
        return 2
        b = 4
        return a + b
    """)

# Generated at 2022-06-21 18:41:59.367789
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('''
        def test():
            print('test')

            if True:
                print('test')
    ''')

    parent, _ = get_non_exp_parent_and_index(node, node.body[0].body[0])
    assert isinstance(parent, ast.FunctionDef)

    parent, _ = get_non_exp_parent_and_index(node, node.body[0].body[1])
    assert isinstance(parent, ast.FunctionDef)

    parent, _ = get_non_exp_parent_and_index(node, node.body[0].body[1].body[0])
    assert isinstance(parent, ast.If)

# Generated at 2022-06-21 18:42:06.357316
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as ast
    with open('tests/code/hello.py') as f:
        src = f.read()

    root = ast.parse(src)
    body = root.body
    mod = body[0]
    imp = mod.body[0]
    func = mod.body[1]
    assert func.name == 'main'

    for f in func.body:
        assert get_non_exp_parent_and_index(root, f) == (func, func.body.index(f))

    print(ast.dump(root))


# Generated at 2022-06-21 18:42:18.340780
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('''
if 1:
    print('1')
print('2')
    ''')

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    replace_at(index, parent, ast.parse('''
print('inside')
print('inside 2')
    '''))

# Generated at 2022-06-21 18:42:22.015921
# Unit test for function find
def test_find():
    def compare_two():
        if a < b:
            return a

    module = ast.parse(inspect.getsource(compare_two))
    print(list(find(module, ast.Compare)))



# Generated at 2022-06-21 18:42:29.567995
# Unit test for function find
def test_find():
    tree = ast.parse('a=1')
    tree.body[0].value.n = 2
    assert ast.dump(tree) == u'(Module(\n    Assign(targets=[Name(id=a, ctx=Store())], value=Num(n=2))))'

    for node in find(tree, ast.Name):
        print(node.id)
    # a

    for node in find(tree, ast.Num):
        print(node.n)
    # 2


# Generated at 2022-06-21 18:42:32.650877
# Unit test for function replace_at
def test_replace_at():
    n = ast.parse("a = a + 2")
    n.body[0].value.right = ast.parse("a + 2")
    replace_at(1, n.body[0].value, ast.parse("a + 3"))
    print(ast.dump(n))

# Generated at 2022-06-21 18:42:33.605750
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-21 18:42:44.415231
# Unit test for function replace_at
def test_replace_at():
    test_code = """
                 for i in range(10):
                    x = i
                 """
    test_tree = ast.parse(test_code)
    test_list = ast.List(elts=[ast.Num(n=0)], ctx=ast.Load())
    test_node = test_tree.body[0].body[0]

    replace_at(0, test_tree.body[0], test_list)
    assert test_tree.body[0].body[0].value == test_node.value
    assert test_tree.body[0].body[1].elts[0].n == 0
    assert len(test_tree.body[0].body[1].elts) == 1
    assert len(test_tree.body[0].body) == 2

# Generated at 2022-06-21 18:42:47.974084
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''class foo():
    def bar():
        pass
''', mode='exec')
    _build_parents(tree)
    assert(get_parent(tree, tree.body[0]) == tree)



# Generated at 2022-06-21 18:42:52.463518
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-21 18:42:53.267349
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass

# Generated at 2022-06-21 18:42:54.972621
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

# Generated at 2022-06-21 18:43:00.091406
# Unit test for function insert_at
def test_insert_at():
    code = '''
    def f(x):
        if x > 0:
            return x
    '''
    tree = ast.parse(code)
    ifstmt = find(tree, ast.If).__next__()
    insert_at(0, ifstmt, ast.Pass())
    new_code = compile(tree, filename="", mode='exec')
    assert new_code.co_filename == '<ast>'


# Generated at 2022-06-21 18:43:06.435791
# Unit test for function insert_at
def test_insert_at():
    # given
    x = 0
    y = 0

    while x < 3:
        y = y + 1
        x = x + 1

    tree = ast.parse('x = 1\nwhile x < 3:\n    y = y + 1\n    x = x + 1\n')
    tree2 = ast.parse('x = 1\nwhile x < 3:\n    y = y + 1\n    x = x + 1\n')
    _build_parents(tree)
    # precondition
    assert 2 == tree2.body[1].body[1].body[1].value.right.n  # type: ignore

    # when
    insert_at(1, get_parent(tree, tree.body[1]),
              ast.parse('if y == 3:\n    break\n'))

    # then


# Generated at 2022-06-21 18:43:07.579568
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:43:19.010818
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from . import ast_impl as util_ast
    a = util_ast.Node('a')
    b = util_ast.Node('b')
    c = util_ast.Node('c')
    d = util_ast.Node('d')
    a.body.append(b)
    b.body.append(c)
    c.body.append(d)
    assert get_closest_parent_of(a, d, util_ast.Node) == c
    assert get_closest_parent_of(a, c, util_ast.Node) == b
    assert get_closest_parent_of(a, b, util_ast.Node) == a
    assert get_closest_parent_of(a, a, util_ast.Node) == a

# Generated at 2022-06-21 18:43:24.119962
# Unit test for function insert_at
def test_insert_at():
    import ast
    ast_tree = ast.parse("def hi(x, y):\n    return x + y")
    func = ast_tree.body[0]
    func_body = func.body
    insert_at(0, func_body, ast.parse("x = 1"))
    assert "x = 1" in astor.to_source(ast_tree).split("\n")[:-1]

# Generated at 2022-06-21 18:43:32.967838
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Tests function get_closest_parent_of."""
    tree = ast.parse('''
        a = 2
    ''')

    tree_b = ast.parse('''
        1+2
    ''')

    assignment = ast.parse('''
        a = 2
    ''')

    compare = ast.parse('''
        a == b
    ''')

    expected = tree.body[0]

    assert get_closest_parent_of(tree, tree_b.body[0], ast.Module) == tree
    assert get_closest_parent_of(tree, tree_b.body[0], ast.FunctionDef) is None

# Generated at 2022-06-21 18:43:39.420646
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('foo(1) + bar(2)')
    node = tree.body[0].value.args[0]
    parent = get_closest_parent_of(tree, node, ast.Expression)
    assert isinstance(parent, ast.Expression)
    assert parent == tree.body[0]
    assert isinstance(parent, ast.Expression)

# Generated at 2022-06-21 18:43:52.159455
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_parent_assign = ast.parse('x = 1')
    test_child_assign = test_parent_assign.body[0]
    assert get_non_exp_parent_and_index(test_parent_assign, test_child_assign) == ( test_parent_assign, 0)

    test_parent_for = ast.parse('for i in range(10): print(i)')
    test_child_for = ast.parse('print(i)')
    assert get_non_exp_parent_and_index(test_parent_for, test_child_for) == (test_parent_for, 0)

# Generated at 2022-06-21 18:43:53.152474
# Unit test for function find

# Generated at 2022-06-21 18:43:54.416838
# Unit test for function insert_at
def test_insert_at():
    import astunparse


# Generated at 2022-06-21 18:44:03.731005
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('x = lambda x, y : x + y')
    for idx, node in enumerate(tree.body):
        if idx == 0:
            assert(isinstance(node, ast.Assign))
            assert(get_parent(tree, node) == tree)
        elif idx == 1:
            assert(isinstance(node, ast.Expr))
            assert(get_parent(tree, node) == tree)
    assert (isinstance(tree.body[1].value, ast.Lambda))


# Generated at 2022-06-21 18:44:08.581930
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    parent = ast.FunctionDef('', ast.arguments([], None, [], [], None, []),
                             [ast.Pass(), ast.Pass(), ast.Pass()], [])
    children = list(ast.iter_child_nodes(parent))
    p1, i1 = get_non_exp_parent_and_index(parent, children[0])
    p2, i2 = get_non_exp_parent_and_index(parent, children[1])
    p3, i3 = get_non_exp_parent_and_index(parent, children[2])
    assert p1 is p2 is p3 is parent
    assert i1 == 0
    assert i2 == 1
    assert i3 == 2

# Generated at 2022-06-21 18:44:16.939754
# Unit test for function replace_at
def test_replace_at():
    import ast
    tree = ast.parse("""
    def test():
        for i in range(9):
            a = i
            print(a)
    """)

    parent = get_closest_parent_of(
        tree, tree.body[0].body[0].body[0].body[0], ast.For)

    assert isinstance(parent, ast.For)

    replace_at(0, parent, ast.parse("b = i"))

    assert parent.body[0].targets[0].id == 'b'

# Generated at 2022-06-21 18:44:25.300712
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
    if True:
        def f(x):
            pass
    elif False:
        def g(x):
            pass
    else:
        def h(x):
            pass
    ''')

    # Get non exp parent and index of node `f`
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.If)
    assert isinstance(index, int)
    assert index == 0

    # Get non exp parent and index of node `g`
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].orelse[0])
    assert isinstance(parent, ast.If)
    assert isinstance(index, int)

# Generated at 2022-06-21 18:44:34.128280
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = "def foo(x, y):\n  x += y"
    tree = ast.parse(code)
    node = tree.body[0]

    assert(node.name == 'foo')
    assert(node.args.args[0].arg == 'x')
    assert(node.body[0].targets[0].id == 'x')
    assert(node.body[0].value.op == '+')

    parent, index = get_non_exp_parent_and_index(tree, node)
    assert(isinstance(parent, ast.Module))
    assert(parent.body[0] is node)
    assert(index == 0)

# Generated at 2022-06-21 18:44:42.219040
# Unit test for function insert_at
def test_insert_at():
    # Given
    tree = ast.parse("""x = 5\n""")
    parent = tree.body[0]
    nodes = ast.Expr(ast.Name('a', ast.Load()))

    # When
    insert_at(1, parent, nodes)

    # Then
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=5)), Expr(value=Name(id='a', ctx=Load()))])"

# Generated at 2022-06-21 18:44:52.949645
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 11 + 12')
    n1, i1 = get_non_exp_parent_and_index(tree, tree.body[0].value)
    assert i1 == 0
    assert isinstance(n1, ast.Assign)

    n2, i2 = get_non_exp_parent_and_index(tree, tree.body[0].value.left)
    assert i2 == 1
    assert isinstance(n2, ast.BinOp)

    n3, i3 = get_non_exp_parent_and_index(tree.body[0].value.left,
                                          tree.body[0].value.left.id)
    assert i3 == 0
    assert isinstance(n3, ast.Name)

# Generated at 2022-06-21 18:45:01.056226
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Arrange
    from ..utils import FakeModule
    tree = FakeModule('a=1\nb=2\na=3')

    # Act
    body_index, node_index = get_non_exp_parent_and_index(tree, tree.body[0].value)

    # Assert
    assert body_index.body[1] == tree.body[1]
    assert node_index == 1

# Generated at 2022-06-21 18:45:02.026359
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:45:13.602166
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Test(ast.AST):
        _fields = ('parent1', 'parent2')

    class OtherTest(ast.AST):
        _fields = ('other_parent',)

    class Parent(ast.AST):
        _fields = ('parent',)

    class Some:
        pass

    class Other:
        pass

    other = OtherTest()
    test1 = Test(
        parent1=Some(),
        parent2=Parent(parent=Test(
            parent1=Parent(parent=Test(parent1=Test(parent1=other))),
            parent2=Test(parent2=Test(parent2=Parent(parent=Test(
                parent2=Test(parent2=Parent(parent=Some())))))
            )
        ))
    )


# Generated at 2022-06-21 18:45:14.239222
# Unit test for function get_parent

# Generated at 2022-06-21 18:45:19.212886
# Unit test for function replace_at
def test_replace_at():  # pylint: disable=no-self-use
    """Test if replace_at function works."""
    node = ast.parse(textwrap.dedent('''\
        def some_func():
            foo = 1
            x = 2
        '''))
    parent, index = get_non_exp_parent_and_index(node, node.body[0].body[-1])
    assert index == 2
    assert isinstance(parent, ast.Module)
    actual = ast.dump(node.body[0].body[2])
    expected = ast.dump(ast.parse(textwrap.dedent('''\
        x = 2
        ''')).body[0])
    assert actual == expected

# Generated at 2022-06-21 18:45:25.610905
# Unit test for function replace_at
def test_replace_at():
    ast1 = ast.parse('''def f():
        print('foo')
    ''')

    defnode = ast.parse('''def f(a, b):
        pass
    ''')

    replace_at(0, get_closest_parent_of(ast1, ast1.body[0], ast.FunctionDef),
               defnode.body[0])
    assert ast.dump(ast1) == ast.dump(defnode)

# Generated at 2022-06-21 18:45:26.456224
# Unit test for function replace_at

# Generated at 2022-06-21 18:45:32.419180
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('if x: pass')
    top_parent = tree.body[0]
    body = get_closest_parent_of(tree, top_parent.test, ast.stmt)
    replace_at(0, body, ast.parse('y').body[0])  # replace if with y

    assert tree.body[0].test.id == 'y'

# Generated at 2022-06-21 18:45:43.125288
# Unit test for function insert_at
def test_insert_at():
    class Dummy:
        parent = None
        child = None

    import ast
    import astor
    class DummyAST(object):
        def __init__(self, body = None):
            self.body = body
            type(self).parent = Dummy()
            type(self).child = Dummy()

        def __deepcopy__(self, memo):
            return DummyAST(self.body)

    body = [ast.FunctionDef(name="func1", args=ast.arguments(args=[]), body=[], returns=None),
            ast.FunctionDef(name="func2", args=ast.arguments(args=[]), body=[], returns=None),
            ast.FunctionDef(name="func3", args=ast.arguments(args=[]), body=[], returns=None)]

# Generated at 2022-06-21 18:45:47.134052
# Unit test for function insert_at
def test_insert_at():
    import astor
    def f1(x):
        if x:
            print("if")
        else:
            return x

        print("first")
        print("second")

    tree = ast.parse(f1)
    insert_at(2, tree.body[0].body, [ast.parse("print('third')").body[0]])
    print(astor.to_source(tree))

# Generated at 2022-06-21 18:45:59.867322
# Unit test for function find
def test_find():
    test_tree = ast.parse('a = 5\nb = 3\n')

    for node in find(test_tree, ast.Name):
        assert node.id == 'a' or node.id == 'b'


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-21 18:46:07.525295
# Unit test for function insert_at
def test_insert_at():
    test_tree = ast.parse("""
    def foo():
        a = 1
        b = 2
        c = 3
    """)

    parent = get_closest_parent_of(test_tree, find(test_tree, ast.Name).__next__(), ast.FunctionDef)

    insert_at(2, parent, [ast.parse("x = 'foo'").body[0]])


# Generated at 2022-06-21 18:46:11.605124
# Unit test for function replace_at
def test_replace_at():
    import astor

    ast_test = ast.parse("def test():\n    pass\n    pass")
    replace_at(0, ast_test, ast.parse("def test():\n    pass"))
    assert astor.to_source(ast_test).strip() == "def test():\n    pass"


# Generated at 2022-06-21 18:46:18.568448
# Unit test for function get_parent
def test_get_parent():
    """Test for function get_parent."""
    import astor
    from ..exceptions import NodeNotFound

    # create tree
    # test_node is name of node we are looking for
    main_node = ast.Module(body=[ast.Expr(value=ast.Name(
        id='test_node', ctx=ast.Load()))])

    # test if we found correct parent
    assert get_parent(main_node, ast.Name(id='test_node', ctx=ast.Load())) == ast.Expr(
        value=ast.Name(id='test_node', ctx=ast.Load()))

    # test if exception is raised if node is not found

# Generated at 2022-06-21 18:46:20.617289
# Unit test for function find
def test_find():
    import io
    import astor
    from ..typing import vars_in_ast as vi


# Generated at 2022-06-21 18:46:29.722897
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("a = 0 + 1\nb = 0 + 2\nc = 0 + 3")
    tree1 = ast.parse("x = 0 + 9")

    for i in range(3):
        tree = ast.parse("a = 0 + 1\nb = 0 + 2\nc = 0 + 3")
        tree1 = ast.parse("x = 0 + 9")
        node = tree.body[i]
        parent, index = get_non_exp_parent_and_index(tree, node)
        replace_at(index, parent, tree1.body)
        # print(ast.dump(tree))
        assert ast.dump(tree) == "Module([Assign([Name('a', Store())], Add(Num(0), Num(1))), x = 0 + 9, x = 0 + 9])"

# Generated at 2022-06-21 18:46:37.434203
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():  # pylint: disable=unused-argument
    tree = ast.parse("""if test == foo:
               pass;
           if test == bar:
               pass;""")

    node = tree.body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.If)

    assert isinstance(parent, ast.If)
    assert parent.body[0] == node



# Generated at 2022-06-21 18:46:41.663400
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo():\n    import a\n    a.bar()')
    assert(get_closest_parent_of(tree, tree.body[0].body[1].value.func,
                                 ast.FunctionDef) == tree.body[0])

# Generated at 2022-06-21 18:46:45.299046
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('(x for x in range(10) for x in range(10))')
    node = tree.body[0].body[1].iter
    assert get_non_exp_parent_and_index(tree, node) == (tree.body[0].body[0], 1)



# Generated at 2022-06-21 18:46:55.573348
# Unit test for function insert_at
def test_insert_at():
    """
    Test case for insert_at
    Creates the following AST
    import math
    import sys
    import math
    import sys
    """
    tree = ast.parse("""
    import math
    import sys
    """)
    tree.body.insert(0, ast.Import(names=[ast.alias(name="os", asname=None)]))

    target = tree.body[2]
    body = get_parent(tree, target)

    insert_at(2, body, ast.Import(names=[ast.alias(name="os", asname=None)]))

    assert len(body.body) is 5
    assert tree


# Generated at 2022-06-21 18:47:16.444793
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = b + 1')
    module = tree.body[0]
    assert isinstance(get_parent(tree, module), ast.Module)

    num = get_parent(tree, module).body[0].value
    assert isinstance(get_parent(tree, num), ast.Expr)

    parent = get_parent(tree, num)
    assert isinstance(get_parent(tree, parent), ast.Module)

# Generated at 2022-06-21 18:47:22.012706
# Unit test for function replace_at
def test_replace_at():
    """Unit test for function replace_at."""
    node = ast.parse("a = 1")
    replace_at(0, node, ast.parse("b = 2"))
    code = compile(node, '<string>', mode='exec')
    assert "a = 1" not in code.co_code
    assert "b = 2" in code.co_code



# Generated at 2022-06-21 18:47:31.095695
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .tests import get_nodes
    from ..tools.singleton import parse_file
    from ..utils.ast_functions import is_exp_node

    nodes = get_nodes()
    tree = parse_file(nodes.file_name)

    for node in ast.walk(tree):
        if not is_exp_node(node):
            non_exp_parent, index = get_non_exp_parent_and_index(tree, node)
            assert index == getattr(nodes, node).index, 'Wrong index'

    print('test_get_non_exp_parent_and_index() passed')

# Generated at 2022-06-21 18:47:38.845195
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    _parent = ast.parse('''
        def test(param1, param2):
            print(param1 + param2)
            print(param1)
            print(param2)
    ''').body[0]

    _func_call_node = _parent.body[0].value
    assert isinstance(_func_call_node, ast.Expr)
    assert isinstance(_func_call_node.value, ast.Call)

    # we need to get the closest For parent node.
    # But we are going to pass Call node
    assert isinstance(get_closest_parent_of(_parent, _func_call_node, ast.For),
                      ast.FunctionDef)

# Unit tests for function get_parent

# Generated at 2022-06-21 18:47:46.182802
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('''
    def foo():
        pass

    pass
    ''')
    pass_statement = tree.body[1]
    func_def = tree.body[0]
    assert func_def.body == [ast.Pass()]
    replace_at(0, func_def, pass_statement)
    assert func_def.body == [ast.Pass()]

# Generated at 2022-06-21 18:47:50.654989
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test for get_non_exp_parent_and_index.

    Test case:
    class A(object):
        def __init__(self):
            self.a = x + 1
            def b(self):
                return self.a + 2

    """
    a = ast.Module(body=[])

# Generated at 2022-06-21 18:47:54.779757
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest

    from .. import transforms

    class TestSuite(unittest.TestCase):
        def test_get_closest_parent_of(self):
            tree = ast.parse('x = [y for y in range(5)]')

            module = get_closest_parent_of(tree, tree.body[0].value.elts[0],
                                           ast.Module)

            self.assertIsInstance(module, ast.Module)

# Generated at 2022-06-21 18:47:55.914187
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass


# Generated at 2022-06-21 18:48:07.911196
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("""
    def test(x, y):
        if x:
            print(2)
            if y:
                print(4)
        else:
            print(6)
    """)

    body = tree.body[0].body
    print_2 = body[1].body[0]
    print_4 = body[2].body[1]
    print_6 = tree.body[0].body[3].body[0]

    print(get_non_exp_parent_and_index(tree, print_2))
    print(get_non_exp_parent_and_index(tree, print_4))
    print(get_non_exp_parent_and_index(tree, print_6))

    (print_6_parent, print_6_index) = get_non_exp

# Generated at 2022-06-21 18:48:14.298793
# Unit test for function find
def test_find():
    from .generate import generate_module
    from .dump import dump_ast

    node = ast.Name(id='x', ctx=ast.Store())

    tree = generate_module(body=[
        ast.Assign(targets=[node], value=ast.Num(n=1)),
        ast.Name(id='x', ctx=ast.Load())
    ])

    print(dump_ast(tree))
    assert list(find(tree, node.__class__)) == [node]

# Generated at 2022-06-21 18:48:34.657170
# Unit test for function get_parent
def test_get_parent():
    t = ast.parse('''
    while True:
        if True:
            pass
    ''')

    tree = t.body[0]
    if_body = tree.body[0].body  # type: ignore

    assert get_parent(tree, if_body[0]).body == if_body  # type: ignore
    assert get_parent(tree, if_body).body is tree.body  # type: ignore
    assert get_parent(tree, tree).body == t.body  # type: ignore



# Generated at 2022-06-21 18:48:41.318867
# Unit test for function get_parent
def test_get_parent():
    # pylint: disable=unused-variable
    class A:
        pass
    o1 = A()
    o2 = A()
    o3 = A()
    # pylint: enable=unused-variable
    _parents[o1] = o3
    _parents[o2] = o3
    _parents[o3] = None
    assert get_parent(None, o1) == o3
    assert _parents[o1] == o3
    assert get_parent(None, o1, True) == o3
    assert _parents[o1] == o3

# Generated at 2022-06-21 18:48:41.922981
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:48:52.586330
# Unit test for function get_parent
def test_get_parent():
    test_tree = ast.parse("""
    if True:
        x = y + 1
        print(x)
    """)

    assert get_parent(test_tree, test_tree.body[0].body[0]) == \
        test_tree.body[0]
    assert get_parent(test_tree, test_tree.body[0].body[0]).body[0] == \
        test_tree.body[0].body[0]
    assert get_parent(test_tree, test_tree.body[0].body[0].value) == \
        test_tree.body[0].body[0]

    with pytest.raises(NodeNotFound):
        get_parent(test_tree, test_tree.body[0].body[0].value.left)


# Generated at 2022-06-21 18:49:03.851040
# Unit test for function find
def test_find():
    # test for function find
    root = ast.parse("def f(x, y):\n    return x + y")
    def_node=find(root, ast.FunctionDef)
    assert isinstance(def_node, Iterable)
    # test for function find
    root = ast.parse("def f(x, y):\n    return x + y")
    def_node=next(find(root, ast.FunctionDef))
    assert def_node.name=='f'
    # test for function find
    root = ast.parse("def f(x, y):\n    return x + y")
    ret = find(root, ast.Return)
    assert isinstance(ret,Iterable)
    ret = next(find(root, ast.Return))
    assert (ret.value.left.id =='x')


# Generated at 2022-06-21 18:49:10.455993
# Unit test for function get_parent
def test_get_parent():
    code = '''
    def f():
        def g():
            1
    '''

    tree = ast.parse(code)
    test_node = tree.body[0].body[0]
    parent_node = get_parent(tree, test_node)
    assert isinstance(parent_node, ast.FunctionDef)



# Generated at 2022-06-21 18:49:17.636382
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    parent = ast.FunctionDef('foo', ast.arguments(args=[], vararg=None,
                                                  kwonlyargs=[],
                                                  kwarg=None, defaults=[],
                                                  kw_defaults=[]),
                             [ast.Expr(ast.Num(1))], [], None)
    body = ast.Module(body=[parent])

    _build_parents(body)

    assert parent is get_closest_parent_of(body, parent.body[0], ast.FunctionDef)

# Generated at 2022-06-21 18:49:22.603053
# Unit test for function insert_at
def test_insert_at():
    node = ast.AST()
    parent = ast.AST()
    index = 1
    parent.body = [1, 2, 3]  # type: ignore
    insert_at(index, parent, node)
    assert parent.body[1] == node



# Generated at 2022-06-21 18:49:30.191694
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..ast import Call, FuncDef
    from . import func_def

    def test(nodes, expectedIndex):
        tree = func_def.build(body=nodes)

        assert (
            get_non_exp_parent_and_index(tree, nodes[0]) == (tree, expectedIndex)
        )

    test([Call('foo')], 0)
    test([Call('foo'), Call('bar')], 1)
    test([Call('foo'), Call('bar'), Call('baz')], 2)
    test([Call('foo'), Call('bar'), FuncDef('baz')], 1)
    test([Call('foo'), Call('bar'), FuncDef('baz'), Call('quux')], 3)

# Generated at 2022-06-21 18:49:40.096513
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import os
    import pathlib
    from rex import Rex
    import unittest

    TEST_DATA_DIR = os.path.join(str(pathlib.Path(__file__).parent.absolute()),
                                 'test_data')

    rex = Rex()

    class TestGetClosestParentOf(unittest.TestCase):
        def test_get_closest_parent_of(self):
            file_path = os.path.join(TEST_DATA_DIR, '0.py')
            tree = rex.analyze_file(file_path)
            function_def = get_closest_parent_of(
                tree, find(tree, ast.Name).__next__(), ast.FunctionDef)
            self.assertEqual(function_def.name, 'fun')

    unitt

# Generated at 2022-06-21 18:50:22.831558
# Unit test for function insert_at

# Generated at 2022-06-21 18:50:30.470821
# Unit test for function find
def test_find():
    import astunparse

    code = """
    def a(x):
        x = 1 + 1
        x = 1 - 1
        x = 1 * 1
        x = 1 / 1
        x = 1 ** 1
        x = 1 // 1
        return x + 1
    """
    tree = ast.parse(code)

    # Test find
    assert len(list(find(tree, ast.Name))) == 11
    assert len(list(find(tree, ast.BinOp))) == 7
    assert len(list(find(tree, ast.Str))) == 0
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Return))) == 1



# Generated at 2022-06-21 18:50:33.394243
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def add(a, b): return a + b')
    node = tree.body[0].body[0].value
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-21 18:50:40.085469
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    a = 1
    if a == 2:
        print(a)
        print(a)
    """)
    print(ast.dump(tree))
    ast.fix_missing_locations(tree)
    print(ast.dump(tree))
    if_ = tree.body[1]
    print(if_)
    print(type(if_))
    print(ast.dump(if_))
    print(get_non_exp_parent_and_index(tree, if_))

# Generated at 2022-06-21 18:50:49.155224
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1', '<test>', 'exec')
    vars_ = find(tree, ast.Name)
    assert list(vars_) == [tree.body[0].targets[0]]
    expr_ = find(tree, ast.Num)
    assert list(expr_) == [tree.body[0].value]


tree = ast.parse('a = 1', '<test>', 'exec')
a = tree.body[0].targets[0]
from ..types import TypeDescription
from typing import Dict
from ..transformations.typeinference import infer_type
from ..transformations.typeinference import infer_from_assignment
from ..transformations.typeinference import infer_from_binary_op
from ..transformations.typeinference import infer_from_unary_op

# Generated at 2022-06-21 18:50:59.411629
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nb = 2\nc = 3')
    node = next(find(tree, ast.Num))

    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.Module)
    assert index == 0

    tree = ast.parse('a = 1; b = 2; c = 3')
    node = next(find(tree, ast.Num))

    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.Module)
    assert index == 0

    tree = ast.parse('a = 1')
    parent = next(find(tree, ast.Name))

    nodes = [ast.Name(id='a')]
    insert_at(0, parent, nodes)

# Generated at 2022-06-21 18:51:09.481460
# Unit test for function replace_at
def test_replace_at():

    root = ast.parse('print(5 + 4)')

    # Test if it works with single node
    replace_at(0, root, ast.parse('print(4 + 4)'))
    assert ast.dump(root, include_attributes=False) == \
        'Module(body=[Print(values=[BinOp(left=Num(n=4), op=Add(), right=Num(n=4))], dest=None, nl=True)])'

    root = ast.parse('print(5 + 4)')

    # Test if it works with multiple nodes
    replace_at(0, root, ast.parse('print(5 + 4); print(4 + 4)'))

# Generated at 2022-06-21 18:51:14.077463
# Unit test for function find
def test_find():
    source = '''
    def f(x):
        print(x)
    '''

    def test(node_cls):
        tree = ast.parse(source)
        nodes = find(tree, node_cls)
        assert next(nodes) == tree

    test(ast.Module)
    test(ast.FunctionDef)



# Generated at 2022-06-21 18:51:19.658800
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    _ast = ast.parse('''
        def fn(arg):
            pass
    ''')
    assert isinstance(get_closest_parent_of(_ast, _ast.body[0].body[0],
                                            ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(_ast, _ast.body[0].body[0],
                                            ast.Module),
                      ast.Module)

# Generated at 2022-06-21 18:51:24.004950
# Unit test for function get_parent
def test_get_parent():
    import typed_ast.ast3 as ast

    # Define a simple AST
    tree = ast.parse('x = 1')

    # Get the assign node (a body node)
    node = tree.body[0]

    # Get the index of the assign node
    index = tree.body.index(node)

    # Get the parent of the assign node
    assert get_parent(tree, node) == tree

    # Get the parent of the assign node using the index
    assert get_parent(tree, node) == tree