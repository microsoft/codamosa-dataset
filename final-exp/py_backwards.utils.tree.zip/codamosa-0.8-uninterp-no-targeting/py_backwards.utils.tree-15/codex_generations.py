

# Generated at 2022-06-21 18:41:31.831134
# Unit test for function get_parent
def test_get_parent():
    a = ast.Load()
    b = ast.Load()
    _parents[a] = b

    tree = ast.Module(body=[ast.Expr(value=a)])

    assert get_parent(tree, a) == b

# Generated at 2022-06-21 18:41:38.564274
# Unit test for function find
def test_find():
    class Node(ast.AST):
        name = "Node"

    class NodeB(ast.AST):
        name = "NodeB"

    class NodeC(ast.AST):
        name = "NodeC"

    class NodeD(ast.AST):
        name = "NodeD"

    def _build_ast() -> ast.AST:
        node = Node()
        node_d = NodeD()
        node_c = NodeC()
        node_b = NodeB()
        node.body = [node_b, node_c, node_d]
        return node

    tree = _build_ast()
    nodes = list(find(tree, NodeC))

    assert len(nodes) == 1
    assert isinstance(nodes[0], NodeC)

# Generated at 2022-06-21 18:41:42.370255
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse(textwrap.dedent(
        """\
        def foo():
            pass

        def bar():
            pass

        """
    ))

    class_def = get_closest_parent_of(tree, tree.body[1], ast.ClassDef) \
        # type: ignore
    assert class_def is None

    def_def = get_closest_parent_of(tree, tree.body[1], ast.FunctionDef) \
        # type: ignore
    assert def_def == tree.body[1]


# Generated at 2022-06-21 18:41:50.421176
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    parent_node = ast.Module()
    test_node = ast.Expr(value=ast.Str(s="test"))
    parent_node.body.append(test_node)
    parent_node.body.append(ast.Expr(value=ast.Str(s="last")))

    parent, idx = get_non_exp_parent_and_index(parent_node, test_node)

    assert parent == parent_node
    assert idx == 0

# Generated at 2022-06-21 18:41:54.339030
# Unit test for function find
def test_find():
    h = ast.parse("""a = 1\n""")
    l = list(find(h, ast.Name))
    assert len(l) == 1
    assert l[0].id == 'a'
    assert l[0].ctx.value == 'Store'
    

# Generated at 2022-06-21 18:41:59.681023
# Unit test for function replace_at
def test_replace_at():
    class A():
        body = [1, 2, 3]

    replace_at(1, A(), A())

    assert A().body == [1, A(), 3]

    replace_at(1, A(), [4, 5, 6])

    assert A().body == [1, 4, 5, 6, 3]

    replace_at(0, A(), 4)

    assert A().body == [4, 1, 4, 5, 6, 3]

# Generated at 2022-06-21 18:42:04.565738
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import textwrap
    from .parser import PythonParser

    tree = PythonParser.parse(textwrap.dedent('''
    def a():
        if True:
            pass
    '''))
    ast_node = get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.If)
    assert ast_node.body[0].value.id == 'True'

# Generated at 2022-06-21 18:42:08.916442
# Unit test for function insert_at
def test_insert_at():
    class A:
        def __init__(self):
            self.body = [1, 2, 3]

    a = A()
    insert_at(1, a, 'a')
    assert a.body == [1, 'a', 2, 3]

    insert_at(2, a, [4, 5])
    assert a.body == [1, 'a', 4, 5, 2, 3]



# Generated at 2022-06-21 18:42:15.909742
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse(
        '''def f():
    while True:
        0
    '''
    )
    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    parent = get_closest_parent_of(tree, parent, ast.Module)
    assert isinstance(parent, ast.Module)

# Generated at 2022-06-21 18:42:22.539673
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index."""
    node = ast.parse("""
    def test_function(arg1, arg2):
        if True:
            return arg1 + arg2
    """)
    ast.fix_missing_locations(node)
    exp_node = node.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(node, exp_node)
    assert(index == 0)
    assert(isinstance(parent, ast.If))



# Generated at 2022-06-21 18:42:27.709728
# Unit test for function find
def test_find():
    assert list(find(ast.parse("""def foo():
        pass

    def bar():
        pass"""), ast.FunctionDef))


# Generated at 2022-06-21 18:42:35.330360
# Unit test for function find

# Generated at 2022-06-21 18:42:45.849675
# Unit test for function find
def test_find():
    class AST(ast.AST):
        pass

    class InnerNode(AST):
        def __init__(self, data: str):
            self.data = data

    class ParentNode(AST):
        pass

    class MyNode(ParentNode):
        pass

    class MyOtherNode(ParentNode):
        pass

    n1 = MyNode()
    n2 = MyNode()
    n3 = MyOtherNode()
    n4 = InnerNode('a')
    n5 = ParentNode()

    n1.body = [n2, n4]  # type: ignore
    n4.body = [n5, n3]  # type: ignore

    assert set(find(n1, InnerNode)) == {n4}
    assert set(find(n1, type(n1))) == {n1, n2}
   

# Generated at 2022-06-21 18:42:49.759002
# Unit test for function get_parent
def test_get_parent():
    code = "for i in range(1, 2):\n    print(i)"
    module = ast.parse(code)
    loop = module.body[0]
    _build_parents(module)
    assert get_parent(module, loop) == module


# Generated at 2022-06-21 18:42:50.380144
# Unit test for function find

# Generated at 2022-06-21 18:42:53.607395
# Unit test for function insert_at
def test_insert_at():
    node = ast.parse('x = 1')
    try:
        insert_at(0, node, node.body[0].value)
    except Exception:
        pass



# Generated at 2022-06-21 18:43:02.366707
# Unit test for function get_parent
def test_get_parent():
    import unittest
    import ast

    class TestClass(unittest.TestCase):
        def testGetParent(self):
            a = ast.parse("""def func(arg):
                a = arg
                a += 1
                return a""")
            self.assertEqual(get_parent(a, a.body[0].body[2]), a.body[0])
            self.assertEqual(get_parent(a, a.body[0].body[2]),\
                             a.body[0].body[2].value.args[0].ctx)
            self.assertEqual(get_parent(a, a.body[0].body[2]).body.index(a.body[0].body[2]), 2)

    unittest.main()

# Generated at 2022-06-21 18:43:14.297592
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('def foo(x, y=4):\n    x * y')
    parent = get_closest_parent_of(tree, tree.body[0].args.args[1],
                                   ast.FunctionDef)

    replace_at(0, parent,
               [ast.parse('x = 4').body[0],  # type: ignore
                ast.parse('y = 5').body[0]])  # type: ignore


# Generated at 2022-06-21 18:43:21.185080
# Unit test for function insert_at
def test_insert_at():
    import sys
    import astor
    from ..exceptions import NodeNotFound
    
    code = "print('Hello World')"
    tree = ast.parse(code)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    new_node = ast.parse('print("Python is fun")').body[0]
    insert_at(index, parent, [new_node])

# Generated at 2022-06-21 18:43:23.446394
# Unit test for function get_closest_parent_of

# Generated at 2022-06-21 18:43:29.336586
# Unit test for function find
def test_find():
    test_node = ast.parse('a = 1\nb = 2\nc = 3\n')
    assert len(list(find(test_node, ast.Name))) == 3



# Generated at 2022-06-21 18:43:29.884234
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:43:37.510196
# Unit test for function find
def test_find():
    assert list(find(parse('a.b(c).d'), ast.Attribute)) == \
        [parse('a.b(c)').body[0].value.func, parse('a.b(c).d').body[0].value.value]

    assert list(find(parse('a.b(c).d'), ast.Name)) == \
        [parse('a.b(c)').body[0].value.func.value, parse('a.b(c).d').body[0].value.id]



# Generated at 2022-06-21 18:43:46.379250
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse(
        '''def func1(a):
                def func2(b):
                    def func3(c):
                        return c
                    return func3(b)
                return func2(a)'''
    )

    def test(lineno: int, result: str) -> None:
        func = get_closest_parent_of(tree, tree.body[0].body[0].body[0],
                                     ast.FunctionDef)
        assert func.name == result

    test(1, 'func1')
    test(2, 'func2')
    test(3, 'func3')

# Generated at 2022-06-21 18:43:56.354529
# Unit test for function find
def test_find():
    import astor
    test_ast = ast.parse('a = 1')

    assert list(find(ast.parse('a = 1'), ast.Assign)) == [ast.parse('a = 1').body[0]]

    insert_at(0, test_ast, ast.Assign(targets=[ast.Name(id='b')], value=ast.Num(1)))
    assert len(list(find(test_ast, ast.Assign))) == 2
    assert astor.to_source(test_ast) == 'b = 1\na = 1'

    replace_at(1, test_ast, ast.Assign(targets=[ast.Name(id='c')], value=ast.Num(1)))
    assert len(list(find(test_ast, ast.Assign))) == 2
    assert astor.to

# Generated at 2022-06-21 18:44:06.194496
# Unit test for function get_parent
def test_get_parent():

    src = """
    class Animal(object):
        def __init__(self):
            self.tail = None

        def append_tail(self):
            return self.tail + 1
    """

    tree = ast.parse(src)
    node = tree.body[0].body[1].body[0]
    parent = get_parent(tree, node)

    assert isinstance(parent, ast.ClassDef)

    node = tree.body[0]
    parent = get_parent(tree, node)

    assert isinstance(parent, ast.Module)



# Generated at 2022-06-21 18:44:09.306569
# Unit test for function find
def test_find():
    n = ast.parse('x = 8 + 5').body[0]
    assert find(n, ast.Name).next().id == 'x' or True
    assert find(n, ast.Num).next().n == 8 or True

# Generated at 2022-06-21 18:44:14.182809
# Unit test for function replace_at
def test_replace_at():
    class Node:
        def __init__(self):
            self.body = [1, 2, 3]

    node = Node()

    # It should be possible to replace node at index 0
    replace_at(0, node, 10)
    assert node.body == [10, 2, 3]



# Generated at 2022-06-21 18:44:23.254965
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    t = ast.parse('''
    def convert(self, input_, result_type):
        if result_type == "int":
            return int(input_)
        elif result_type == "bool":
            return True if input_ == "True" else False
        elif result_type == "NoneType":
            return None
        elif result_type == "list":
            return list(input_)
    ''')
    _build_parents(t)
    assert isinstance(get_closest_parent_of(t, t.body[0].args.args[1], ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(t, t.body[0].body[0], ast.FunctionDef), ast.FunctionDef)

# Generated at 2022-06-21 18:44:30.502047
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor  # type: ignore
    node = astor.parse("assert a")
    tree = astor.parse("""if b:
        assert a
    else:
        assert b""")
    parent, index = get_non_exp_parent_and_index(tree, node.body[0])
    # The parent is expected to be node of type If
    assert isinstance(parent, ast.If)
    # The index is expected to be 0
    assert index == 0

# Generated at 2022-06-21 18:44:37.404990
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:44:48.313317
# Unit test for function get_parent

# Generated at 2022-06-21 18:44:49.420014
# Unit test for function find

# Generated at 2022-06-21 18:44:52.441492
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("""
    def func(x, y):
        print(x)
    """)

    def_ = tree.body[0]

    node = def_.body[0]

    parent, index = get_non_exp_parent_and_index(tree, node)

    assert parent.body[index].value.id == 'print'

    replace_at(index, parent, ast.Expr(id='print'))

    assert parent.body[index].value.id == 'print'



# Generated at 2022-06-21 18:45:02.192746
# Unit test for function replace_at
def test_replace_at():
    import unittest
    import astor

    module = ast.parse('x = [1, 2, 3, 4, 5]')
    import_node = ast.Import()
    module.body.insert(0, import_node)
    replace_at(0, module, [ast.Import(), ast.Import(),
                           ast.Import(), ast.Import(), ast.Import()])
    assert astor.to_source(module) == 'import\nimport\nimport\nimport\nimport\nx = [1, 2, 3, 4, 5]'

    # Test that insert_at works with a single node as well as a list
    module = ast.parse('x = [1, 2, 3, 4, 5]')
    module.body.insert(0, ast.Import())

# Generated at 2022-06-21 18:45:09.382443
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("""if False:
        a = 1
    else:
        b = 2""").body[0]
    branch_body = tree.body[0]
    branch_body.body.append(ast.parse("c = 3").body[0])
    replace_at(2, branch_body, ast.parse("d = 4").body[0])
    assert branch_body.body[2].value.id == '4'

# Generated at 2022-06-21 18:45:12.836864
# Unit test for function insert_at
def test_insert_at():
    parent = ast.Module(body=[])
    insert_at(0, parent, [ast.Expr(value=ast.Num(1))])
    assert isinstance(parent.body[0].value, ast.Num)


# Generated at 2022-06-21 18:45:13.839048
# Unit test for function find

# Generated at 2022-06-21 18:45:19.068494
# Unit test for function get_parent
def test_get_parent():
    test_string = """\
        def foo(bar, baz=1):
            if bar > baz:
                return a
            else:
                return b
        """

    tree = ast.parse(test_string)
    assert isinstance(get_parent(tree, tree.body[0], rebuild=True), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0], rebuild=True), ast.FunctionDef)  # noqa: E501
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0], rebuild=True), ast.FunctionDef)  # noqa: E501
    assert isinstance(get_parent(tree, tree.body[0].body[0].body[0].test, rebuild=True), ast.If)  # no

# Generated at 2022-06-21 18:45:26.139941
# Unit test for function insert_at
def test_insert_at():
    """Tests insert_at function."""
    from .. import transformer
    from tests.examples import func_with_args, func_def

    arg = ast.parse(func_with_args).body[0].args[0]  # type: ast.arg
    sim = ast.parse(func_def).body[0]  # type: ast.FunctionDef

    transformer.insert_at(1, sim.body, arg)
    assert sim.body[1].__class__ == arg.__class__

# Generated at 2022-06-21 18:45:38.580883
# Unit test for function get_closest_parent_of

# Generated at 2022-06-21 18:45:47.077029
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..grid import Grid
    from . import ast_factory as factory

    grid = Grid(size=(2, 2), default=None, factory=factory)
    tree = factory.create(grid)

    for n in range(4):
        index = n
        for node in find(tree, ast.Expr):
            parent, index = get_non_exp_parent_and_index(tree, node)

            assert(all(not isinstance(p, ast.Expr) for p in _parents.keys()))

            assert(all(isinstance(p, ast.Module) or isinstance(p, ast.For) or
                       isinstance(p, ast.FunctionDef) for p  in _parents.keys()))

            assert(isinstance(parent, ast.FunctionDef))
            assert(parent.body[index] == node)

# Generated at 2022-06-21 18:45:58.416318
# Unit test for function replace_at
def test_replace_at():
    # Create tree
    simple_ast = ast.parse('def foo(x):\n    if x: bar(x)\n')

    # Replace node
    node = simple_ast.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(simple_ast, node)
    new_node = ast.parse('pass').body[0]  # type: ignore
    replace_at(index, parent, new_node)

    # Check result

# Generated at 2022-06-21 18:46:06.782711
# Unit test for function insert_at
def test_insert_at():
    t = ast.parse("""
    import click
    @click.group()
    def main():
        pass

    @main.command(name='server')
    def foo():
        pass
    """)

    function_def2 = t.body[2]
    insert_at(0, function_def2, ast.parse("print('foo')").body[0])

# Generated at 2022-06-21 18:46:15.534490
# Unit test for function get_parent
def test_get_parent():
    """Get parent node test."""
    parent = ast.parse('a + b * c * d(e * f(g)) + h').body[0]
    child = parent.value
    # child node is BinOp
    assert isinstance(child, ast.BinOp)
    assert get_parent(parent, child) == parent
    # child node is BinOp.left
    child = child.left
    assert isinstance(child, ast.Name)
    assert get_parent(parent, child) == parent.value
    # child node is BinOp.left.id
    child = child.id
    assert isinstance(child, str)
    assert get_parent(parent, child) == parent.value.left
    # child node is BinOp.right
    child = parent.value.right

# Generated at 2022-06-21 18:46:22.684973
# Unit test for function insert_at
def test_insert_at():
    node = ast.parse("raise Exception('test')")
    insert_at(0, node, ast.parse("if True:\n\tprint('hi')"))
    assert ast.dump(node) == \
        'Module(body=[If(test=NameConstant(value=True), body=[Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Str(s=\'hi\')], keywords=[]))], orelse=[])])'

# Generated at 2022-06-21 18:46:23.761466
# Unit test for function insert_at
def test_insert_at():
    import astor

# Generated at 2022-06-21 18:46:25.141289
# Unit test for function insert_at
def test_insert_at():
    import astor


# Generated at 2022-06-21 18:46:31.443794
# Unit test for function get_parent
def test_get_parent():
    tree_str = """
    class TestClass:
        def test(self):
            print('test')
            if True:
                print(True)
        def test_two(self):
            return 1
    """

    tree = ast.parse(tree_str)

    # Test 1
    print_node = list(find(tree, ast.Print))[0]
    parent = get_parent(tree, print_node)
    assert isinstance(parent, ast.If)

    # Test 2
    name = list(find(tree, ast.Name))[-1]
    parent = get_parent(tree, name)
    assert isinstance(parent, ast.Print)

    # Test 3
    test_node = list(find(tree, ast.FunctionDef))[0]

# Generated at 2022-06-21 18:46:42.776528
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import unittest
    from ..exceptions import NodeNotFound
    from .fixtures import simple_func_ast

    class TestGetNonExpParentAndIndex(unittest.TestCase):

        def test_get_parent_in_simple_program(self):
            tree, func_ast = simple_func_ast()
            print(func_ast.body[1].name)
            parent, index = get_non_exp_parent_and_index(tree, func_ast.body[1])
            self.assertEqual(func_ast.body[1].name, 'b')
            self.assertEqual(parent.name, 'f')
            self.assertEqual(index, 1)

        def test_get_parent_in_simple_program_for_actual_node(self):
            tree, func_ast = simple_

# Generated at 2022-06-21 18:47:03.944238
# Unit test for function insert_at
def test_insert_at():
    from typed_ast import ast3 as ast
    class Scope(ast.AST):
        _fields = ('body',)
    class Expression(ast.AST):
        _fields = ('value',)
    root = Scope([
        Expression('a'),
        Expression('b')
    ])
    index = 1
    parent = root.body[0]
    insert_at(index, parent, Expression('x'))
    assert len(parent.body) == 2
    assert parent.body[0].value == 'a'
    assert parent.body[1].value == 'x'


# Generated at 2022-06-21 18:47:05.917521
# Unit test for function insert_at

# Generated at 2022-06-21 18:47:12.471351
# Unit test for function get_parent
def test_get_parent():
    code = ast.parse('''
        def func(a, b):
            return a + b
    ''')
    _build_parents(code)

    assert isinstance(get_parent(code, code.body[0].body[0].value), ast.Call)
    assert isinstance(get_parent(code, code.body[0].body[0].value).func, ast.Name)
    assert get_parent(code, code.body[0].body[0].value).func.id == 'a'

# Generated at 2022-06-21 18:47:13.537889
# Unit test for function get_closest_parent_of

# Generated at 2022-06-21 18:47:18.721517
# Unit test for function find
def test_find():
    test_tree = ast.parse("apple = 1, 2, 3\nbanana = 2")
    test_result_tree = list(find(test_tree, ast.Assign))
    for node in test_result_tree:
        print(node)
        print(dir(node))



# Generated at 2022-06-21 18:47:19.373826
# Unit test for function get_parent
def test_get_parent():
    import typed_ast.ast3 as ast

# Generated at 2022-06-21 18:47:23.171185
# Unit test for function insert_at
def test_insert_at():
    top = ast.parse('def f():\n    pass')
    insert_at(1, top.body[0], ast.parse('a = 1'))
    assert "def f():\n    a = 1\n    pass" == top.body[0].body[0].s


# Generated at 2022-06-21 18:47:24.003673
# Unit test for function find

# Generated at 2022-06-21 18:47:29.854924
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def test_func():
        var = 1

    tree = ast.parse(dedent(inspect.getsource(test_func)))
    node = find(tree, ast.Num).__next__()
    parent = get_closest_parent_of(tree, node, ast.Store)
    assert isinstance(parent, ast.Assign)

# Generated at 2022-06-21 18:47:31.881117
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..common import ast_utils
    from ..exceptions import NodeNotFound


# Generated at 2022-06-21 18:48:14.436725
# Unit test for function replace_at
def test_replace_at():
    # Tree we want to test
    tree = ast.parse(
        'def foo(x):\n    if x > 1:\n        print(x)\n    elif x < 1:\n        print(x)\n    else:\n        print(x)'
    )

    # We want to replace the first body node of the the first body node of
    # the first body node of the the last body node (phew!).
    # In this case this is an "if" statement, which represents an "if" branch
    branch_to_replace = tree.body[0].body[0].body[0]

    # Replace the branch with a single "print" statement
    print_statement = ast.Print(
        None, [ast.Str(s='I am a pirate!')], False
    )

# Generated at 2022-06-21 18:48:20.506848
# Unit test for function get_parent
def test_get_parent():
    # Test case #1
    tree = ast.parse("""
    for x in y:
        pass
    """)

    for_stmt = tree.body[0]
    name = for_stmt.target
    parent = get_parent(tree, name)
    assert parent is for_stmt

# Generated at 2022-06-21 18:48:21.218296
# Unit test for function find

# Generated at 2022-06-21 18:48:29.756990
# Unit test for function get_parent
def test_get_parent():
    """Test function get_parent"""
    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value

    assert node == get_parent(tree, node)

    tree = ast.parse('a = 1 + 2')
    node = tree.body[0]

    assert node == get_parent(tree, node)

    tree = ast.parse('a = 1 + 2')
    node = tree.body[0].value.left

    assert get_parent(tree, node) == tree.body[0].value

    tree = ast.parse('a = (1 + 2) * 3')
    node = tree.body[0].value.right

    assert get_parent(tree, node) == tree.body[0].value

    tree = ast.parse('a = 1 + 2')

# Generated at 2022-06-21 18:48:40.102523
# Unit test for function insert_at
def test_insert_at():
    """Unit test for function insert_at."""
    imp = ast.Import(names=[ast.alias(name='os', asname=None)])
    imp_from = ast.ImportFrom(module='os', names=[ast.alias(name='cpu_count',
                                                            asname=None)], level=0)
    func_def = ast.FunctionDef(name='test', args=ast.arguments(args=[],
                                                               vararg=None,
                                                               kwonlyargs=[],
                                                               kw_defaults=[],
                                                               kwarg=None,
                                                               defaults=[]),
                               body=[ast.Pass()], decorator_list=[])
    module = ast.Module(body=[imp, imp_from, func_def])


# Generated at 2022-06-21 18:48:43.711737
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''def func(a, b):
    return a+b''')
    assert get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef) == tree.body[0]



# Generated at 2022-06-21 18:48:45.114093
# Unit test for function insert_at

# Generated at 2022-06-21 18:48:45.914633
# Unit test for function get_parent

# Generated at 2022-06-21 18:48:54.507968
# Unit test for function get_parent
def test_get_parent():
    mod = ast.parse('''
        def func(arg):
            if True:
                print('Test')
                return 0
            else:
                print('Test')
                return 1
        ''')
    func = mod.body[0]
    if_ = func.body[0]
    if_then = if_.body[0]
    _parents.clear()
    assert _parents == {}
    print(get_parent(mod, if_))
    print(_parents)
    assert get_parent(mod, if_) == func
    print(get_parent(mod, if_then))
    assert get_parent(mod, if_then) == if_
    assert _parents[if_then] == if_
    assert _parents[if_] == func


# Generated at 2022-06-21 18:49:04.776950
# Unit test for function insert_at
def test_insert_at():
    body = [
        ast.Expr(value=ast.Name(id='a')),
        ast.Expr(value=ast.Name(id='b'))
    ]

    add_node = ast.Expr(value=ast.Name(id='c'))

    tree = ast.Module(body=body)
    add_after_node = body[0]

    parent, index = get_non_exp_parent_and_index(tree, add_after_node)
    insert_at(index, parent, add_node)

    assert get_parent(tree, add_node) is parent
    assert parent.body[index] is add_after_node
    assert parent.body[index + 1] is add_node

