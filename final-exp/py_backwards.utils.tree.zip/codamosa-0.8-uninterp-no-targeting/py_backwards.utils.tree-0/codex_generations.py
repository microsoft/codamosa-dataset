

# Generated at 2022-06-21 18:41:29.771260
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""def foo():\n"""
                     """    return 3 + True\n"""
                     """\n"""
                     """class bar(object):\n"""
                     """    def __init__(self):\n"""
                     """        self.baz = True\n"""
                     """    def bazbaz(self):\n"""
                     """        return self.baz\n""")

    call = find(tree, ast.Call).__next__()  # type: ignore
    parent = get_parent(tree, call)

    assert isinstance(parent, ast.Return)

    assert get_parent(tree, parent) == tree.body[0].body



# Generated at 2022-06-21 18:41:35.185173
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from pylint_plugin_utils.ast_helpers import find, get_closest_parent_of, get_parent
    from pylint_plugin_utils.transformers import FunctionTransformer
    from pylint_plugin_utils.messages import message_registry
    tree = astor.parse_file("examples/example_01.py")
    class_def = get_closest_parent_of(tree, list(find(tree, ast.FunctionDef))[0], ast.ClassDef)
    print("Closest parent is:", class_def.name)



# Generated at 2022-06-21 18:41:39.540051
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def foo(bar):
        pass

    tree = ast.parse(textwrap.dedent(inspect.getsource(foo)))

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.Module)
    assert index == 1

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-21 18:41:53.473682
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Sample expression:
    #   a = (1, 2, 3) + foo(4, 5, 6)
    a = ast.Name(id='a', ctx=ast.Store())
    o = ast.Name(id='o', ctx=ast.Load())
    integers = (ast.Num(n=i) for i in range(1, 4))
    tpl = ast.Tuple(elts=list(integers), ctx=ast.Load())
    args = (ast.Num(n=i) for i in range(4, 7))
    fn = ast.Name(id='foo', ctx=ast.Load())
    fn_call = ast.Call(func=fn, args=list(args), keywords=[])

# Generated at 2022-06-21 18:42:01.556397
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class MyClass(ast.AST):
        _fields = ()

        @property
        def body(self):
            return [self.node1, self.node2]

    class MyClass2(ast.AST):
        _fields = ()

        @property
        def body(self):
            return [self.node3]

    # tree: MyClass
    # |- node1
    # |- node2
    # |- MyClass2
    #    |- node3
    tree = MyClass()
    tree.node1 = ast.Name()
    tree.node2 = ast.Name()
    tree.node3 = MyClass2()
    tree.node3.node3 = ast.Name()
    _parents[tree.node1] = tree
    _parents[tree.node2] = tree

# Generated at 2022-06-21 18:42:09.437316
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from .type_analysis import is_type_hint
    from .type_replacer import create_type_replacement
    from ..types import TypeStr

    code = """
    def f(a: "int") -> "int":
        return a
    """

    tree = ast.parse(code)
    fdef = tree.body[0]
    assert isinstance(fdef, ast.FunctionDef)

    int_arg = fdef.args.args[0]
    assert isinstance(int_arg, ast.arg)
    assert is_type_hint(int_arg)

    type_place = get_closest_parent_of(tree, int_arg, ast.Name)
    assert type_place is int_arg

    # Replace type of argument

# Generated at 2022-06-21 18:42:16.107467
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass
#    tree = ast.parse('def f():\n    pass')
#    tree.body[0].body[0] = ast.parse('pass')  # type: ignore
#    f, i = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
#    assert f == tree.body[0]
#    assert i == 0
#
#    tree = ast.parse('if True:\n    pass')
#    f, i = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
#    assert f == tree.body[0]
#    assert i == 0
#
#    tree = ast.parse('pass')
#    f, i = get_non_exp_parent_and_index(tree, tree.body

# Generated at 2022-06-21 18:42:17.214907
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass


# Generated at 2022-06-21 18:42:22.098985
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("def foo():\n  b = a")
    assign = find(tree, ast.Assign).__next__()
    assert assign.value.id == 'a'
    name = ast.Name(id='c', ctx=ast.Load())
    replace_at(1, tree.body[0].body, name)
    assert assign.value.id == 'c'


# Generated at 2022-06-21 18:42:27.282236
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .mock import get_mock_tree
    from . import nodes

    tree = get_mock_tree()
    closest_parent = get_closest_parent_of(tree, nodes.ARGS, ast.Module)

    assert isinstance(closest_parent, ast.Module)

# Generated at 2022-06-21 18:42:41.190083
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_tree = ast.parse("""
        def issue_tracker(func_name):

            def wrapper(*args, **kwargs):
                return func_name(*args, **kwargs)

            return wrapper

        @issue_tracker
        def test_func(param1):
            print(param1)
        """)

    func_def = get_closest_parent_of(ast_tree, ast_tree.body[3], ast.FunctionDef)

    assert func_def.name == 'test_func'



# Generated at 2022-06-21 18:42:47.974542
# Unit test for function insert_at
def test_insert_at():
    import ast
    my_tree = ast.parse('if True:\n    print()')
    new_function = ast.FunctionDef(name="test", body=[], decorator_list=[],
                                   returns=None, args=ast.arguments(
        args=[], vararg=None, kwonlyargs=[], kw_defaults=[],
        kwarg=None, defaults=[]))

    new_tree = ast.parse('def test():\n    return 3')
    insert_at(1, get_closest_parent_of(my_tree, my_tree.body[0], ast.If),
              new_tree.body[0])

    assert(ast.dump(my_tree) == ast.dump(new_tree))

# Generated at 2022-06-21 18:42:49.449350
# Unit test for function insert_at
def test_insert_at():
    import astor

# Generated at 2022-06-21 18:42:58.131634
# Unit test for function insert_at
def test_insert_at():
    source = """
    def func():
        pass
    """
    tree = ast.parse(source)
    parent: ast.Assign = list(find(tree, ast.Assign))[0]  # type: ignore
    name: ast.Name = list(find(tree, ast.Name))[0]  # type: ignore

    assert name.id == 'func'
    insert_at(0, parent, name)
    assert name.id == 'func'

    value: ast.FunctionDef = list(find(tree, ast.FunctionDef))[0]  # type: ignore
    assert value.name == 'func'



# Generated at 2022-06-21 18:42:59.004639
# Unit test for function get_parent

# Generated at 2022-06-21 18:43:04.744558
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import unittest

    class Node(ast.AST):
        _fields = ('body',)

    class If(Node):
        _fields = ('test', 'body')

    tree = If(
        test=Node(body=[]),
        body=[Node(body=[]), Node(body=[]), Node(body=[])],
    )

    class Test(unittest.TestCase):
        def test(self):
            self.assertEqual(
                get_non_exp_parent_and_index(tree, tree.body[0]),
                (tree, 0),
            )

    unittest.main()


# Generated at 2022-06-21 18:43:10.044463
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = """
    def a():
        print(1)
        print(2)
        print(3)"""

    tree = ast.parse(source)
    print_node = find(tree, ast.Print).__next__()
    assert_true(get_closest_parent_of(tree, print_node, ast.Module) is tree)

# Generated at 2022-06-21 18:43:19.510830
# Unit test for function find
def test_find():
    tree = ast.parse('pass')
    assert list(find(tree, ast.Pass)) == [tree.body[0]]
    tree = ast.parse('pass; pass')
    assert list(find(tree, ast.Pass)) == [tree.body[0], tree.body[1]]
    tree = ast.parse('if True: pass; pass')
    assert list(find(tree, ast.Pass)) == [tree.body[0].body[0], tree.body[1]]
    tree = ast.parse('if True: pass; pass')
    assert list(find(tree, ast.If)) == [tree.body[0]]

# Generated at 2022-06-21 18:43:31.472317
# Unit test for function find
def test_find():
    tree = ast.parse('def f1(a):\n\tdef f2(b):\n\t\treturn a + b')

# Generated at 2022-06-21 18:43:32.340928
# Unit test for function insert_at

# Generated at 2022-06-21 18:43:44.721507
# Unit test for function insert_at
def test_insert_at():
    import astunparse

    src = '''def foo():
            pass'''
    tree = ast.parse(src)

    # Inserts two nodes before last node
    insert_at(1, tree.body[0], [ast.Expr(ast.Call(
        ast.Name('print', ast.Load()), [ast.Str('Hello')], [])),
        ast.Pass()])
    
    print(astunparse.unparse(tree))

    assert astunparse.unparse(tree) == '''def foo():
    print('Hello')
    pass
    pass''', 'Function insert_at failed'



# Generated at 2022-06-21 18:43:52.916262
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class A(ast.AST):
        pass

    class B(ast.AST):
        pass

    class C(ast.AST):
        pass

    class D(ast.AST):
        pass

    tree = B()
    b = C()
    tree.body = [b]
    b.body = [D()]
    c = A()
    b.body.append(c)

    parent = get_closest_parent_of(tree, c, C)
    assert isinstance(parent, C)
    assert parent is b

# Generated at 2022-06-21 18:44:06.880475
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""\
        def test(a, b):
            a = 1
            b = 2
            c = 3
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])
    insert_at(index, parent, ast.parse("""\
            a = 1
            b = 2
    """))

# Generated at 2022-06-21 18:44:13.369284
# Unit test for function replace_at
def test_replace_at():
    some_node = ast.Name()
    ast_node = ast.Module(body=[some_node])
    index = ast_node.body.index(some_node)  # type: ignore
    replace_at(index, ast_node, ast.Module(body=[ast.Name()]))
    assert len(ast_node.body) == 1


if __name__ == '__main__':
    test_replace_at()

# Generated at 2022-06-21 18:44:17.271134
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse(
        "def myfunction():\n"
        "    return 8\n"
    )
    fdef = node.body[0]
    actual = get_parent(node, fdef)
    assert actual == node



# Generated at 2022-06-21 18:44:21.223274
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Build AST
    tree = ast.parse("""
    def foo():
        def bar():
            pass""")

    # Get parent and index
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    # Check that info is correct
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-21 18:44:22.515787
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astunparse
    import io


# Generated at 2022-06-21 18:44:33.753965
# Unit test for function replace_at
def test_replace_at():
    import unittest
    import astor


    class TestParsedAST(unittest.TestCase):
        def test_replace_at(self):
            ast_template = ast.parse(
                'def foo():\n'
                '\tbar()\n'
                '\tbaz()\n'
                '\tfoo()')
            replace_at(1, ast_template.body[0], ['a', 'b', 'c'])
            self.assertEqual(astor.to_source(ast_template).strip(),
                             'def foo():\n'
                             '\tbar()\n'
                             '\ta\n'
                             '\tb\n'
                             '\tc\n'
                             '\tfoo()')

    unittest.main()

# Generated at 2022-06-21 18:44:37.230493
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1 + b')
    assert find(tree, ast.Name)  # type: ast.Name


# Generated at 2022-06-21 18:44:45.840903
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    tree = ast.parse("""\
        def f():
            return 4 * 5 * 3 * 2 * 1 * 0 * 6 * 7 * 8 * 9 * 3 * 5 * 9
    """)
    node = tree.body[0].body[0].value.left.left
    closest_parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert astor.to_source(closest_parent) == "def f():\n            return 4 * 5 * 3 * 2 * 1 * 0 * 6 * 7 * 8 * 9 * 3 * 5 * 9\n"



# Generated at 2022-06-21 18:44:56.925312
# Unit test for function insert_at
def test_insert_at():
    test_case = \
    """
    import random
    import random
    import random

    random.random()
    """

    root = ast.parse(test_case)
    import_node = root.body[2]

    insert_at(0, import_node, ast.Import(names=[ast.alias('math', None)]))

# Generated at 2022-06-21 18:44:57.983035
# Unit test for function insert_at

# Generated at 2022-06-21 18:45:04.387439
# Unit test for function replace_at
def test_replace_at():
    test_node = ast.parse("""def foo():
        pass
    """)

    for_loop = ast.For(
        target=ast.Name(id='x', ctx=ast.Store()),
        iter=ast.Call(
            func=ast.Name(id='range', ctx=ast.Load()),
            args=[
                ast.Num(n=10)
            ],
            keywords=[]
        ),
        body=[
            ast.Pass()
        ],
        orelse=[]
    )

    insert_at(1, test_node, for_loop)

    assert isinstance(test_node.body[1], ast.For)  # type: ignore

    replace_at(1, test_node, ast.Pass())
    assert isinstance(test_node.body[1], ast.Pass)

# Generated at 2022-06-21 18:45:10.132197
# Unit test for function insert_at
def test_insert_at():
    # type: () -> None
    class A(ast.AST):
        _fields = ('a',)

    class B(ast.AST):
        _fields = ('body',)

    a1 = A(1)
    b1 = B([1, 2, 3])

    insert_at(1, b1, a1)

    assert b1.body == [1, 1, 2, 3]


# Generated at 2022-06-21 18:45:12.456946
# Unit test for function get_parent
def test_get_parent():
    parent = ast.parse('1 + 2')
    child = ast.parse('2')
    assert get_parent(parent, child) == parent

# Generated at 2022-06-21 18:45:15.378171
# Unit test for function get_parent
def test_get_parent():
    node = ast.Name(id="foo", ctx=ast.Load)
    parent = ast.Expr(node)
    tree = ast.Module(body=[parent])
    assert get_parent(tree, node) == parent

# Generated at 2022-06-21 18:45:26.685488
# Unit test for function replace_at
def test_replace_at():
    stmt = ast.parse("print(1)").body[0]
    function = ast.parse("def f(): pass").body[0]
    function.body.append(stmt)
    assert len(function.body) == 1

    replace_at(0, function, ast.parse("print(2)"))
    assert len(function.body) == 1
    assert function.body[0].value.args[0].n == 2

    replace_at(0, function, [ast.parse("a = 0"), ast.parse("print(3)")])
    assert len(function.body) == 3
    assert function.body[0].value.n == 0
    assert function.body[1].value.args[0].n == 3


if __name__ == '__main__':
    test_replace_at()

# Generated at 2022-06-21 18:45:32.235202
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-21 18:45:41.120372
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class A:
        pass
    class B:
        pass
    class C:
        pass
    a = A()
    b1 = B()
    b2 = B()
    b3 = B()
    b4 = B()
    c = C()

    a.b1 = b1
    a.b2 = b2
    b1.b3 = b3
    b1.b4 = b4
    b3.c = c

    assert get_closest_parent_of(a, c, B) == b3
    assert get_closest_parent_of(a, b4, C) is None

# Generated at 2022-06-21 18:45:42.114578
# Unit test for function replace_at

# Generated at 2022-06-21 18:45:52.357817
# Unit test for function find
def test_find():
    class M:
        ass = ""
    m = M()
    v = ast.parse(m.ass)
    assert len(list(find(v, ast.Module))) == 1
    assert len(list(find(v, ast.Load))) == 1
    assert len(list(find(v, ast.Name))) == 2

# Generated at 2022-06-21 18:46:00.661104
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astunparse
    from .. import refactor
    from . import mocks
    code = mocks.MockCode.get_code_single_line_function()
    tree = ast.parse(code)
    refactor.refactor_imports(tree)
    module = tree
    parent: ast.FunctionDef = get_closest_parent_of(module, node=module.body[2],
                                                    type_=ast.FunctionDef)
    assert astunparse.unparse(parent) == '''def func():
    pass
'''

# Generated at 2022-06-21 18:46:01.234251
# Unit test for function get_parent
def test_get_parent():
    pass

# Generated at 2022-06-21 18:46:03.865677
# Unit test for function find
def test_find():
    tree = ast.parse('for i in range(10):\n\tprint(i)')  # type: ignore
    for node in find(tree, ast.For):
        assert isinstance(node, ast.For)

# Generated at 2022-06-21 18:46:12.911105
# Unit test for function insert_at
def test_insert_at():
    code = """
    def test():
        pass
    """
    tree = ast.parse(code)
    node = tree.body[0]
    insert_at(0, node, ast.Expr(ast.Num(0)))
    assert ast.dump(tree) == """
    Module(body=[FunctionDef(name='test', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Num(n=0)), Pass()], decorator_list=[], returns=None)])
    """



# Generated at 2022-06-21 18:46:18.169523
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('var = [1, 2,3]')
    number = find(tree, ast.Num)
    parent, index = get_non_exp_parent_and_index(tree, next(number))
    replace_at(index, parent, [ast.Num(2), ast.Num(4), ast.Num(6)])
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=var, ctx=Store())], value=List(elts=[Num(n=2), Num(n=4), Num(n=6)]))])'

# Generated at 2022-06-21 18:46:27.878144
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse("""def foo(): pass""")
    funcdef = tree.body[0]
    pass_node = funcdef.body[0]
    assert hasattr(funcdef, 'body')
    assert len(funcdef.body) == 1
    assert isinstance(pass_node, ast.Pass)
    assert funcdef.body[0] == pass_node

    replace_at(0, funcdef, ast.Expr(value=ast.Str("hello world")))
    assert len(funcdef.body) == 1
    assert isinstance(funcdef.body[0], ast.Expr)
    assert isinstance(funcdef.body[0].value, ast.Str)



# Generated at 2022-06-21 18:46:28.908464
# Unit test for function get_parent

# Generated at 2022-06-21 18:46:35.159001
# Unit test for function get_parent
def test_get_parent():
    from typed_ast import ast3 as ast
    _build_parents(ast.parse('x = 1'))
    node = list(ast.walk(ast.parse('x = 1')))[3]
    print(node)
    parent = _parents[node]
    print(parent)
    parent2 = _parents[parent]
    print(parent2)

# Generated at 2022-06-21 18:46:41.018253
# Unit test for function get_parent
def test_get_parent():
    import os
    import ast
    import copy
    import pprint
    tree = ast.parse(open(os.path.dirname(__file__) + "/../examples/example_1.py").read())
    _build_parents(tree)
    pprint.pprint(_parents)
    pprint.pprint(get_parent(tree, tree.body[0]))
    

# Generated at 2022-06-21 18:46:53.398699
# Unit test for function get_parent

# Generated at 2022-06-21 18:47:00.873849
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # noqa: D103
    from .test_synthetic_node_utils import gofunc
    from .test_synthetic_node_utils import call_nodes
    from .test_synthetic_node_utils import call_node

    gofunc = gofunc()
    call_nodes = call_nodes(gofunc)
    call_node = call_node(gofunc)

    assert get_non_exp_parent_and_index(gofunc, call_node) \
           == (call_nodes, 0)

# Generated at 2022-06-21 18:47:09.623832
# Unit test for function replace_at
def test_replace_at():
    test_parent = ast.FunctionDef(name='test', body=[ast.Expr(value=ast.Str('1'))])
    test_nodes = [ast.Expr(value=ast.Str('2')), ast.Expr(value=ast.Str('3'))]
    replace_at(0, test_parent, test_nodes)
    assert len(test_parent.body) == 2
    assert isinstance(test_parent.body[0], ast.Expr)
    assert test_parent.body[0].value.s == '2'

# Generated at 2022-06-21 18:47:10.543819
# Unit test for function find

# Generated at 2022-06-21 18:47:14.761381
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    example = ast.parse(
        """
        # some comment
        def test(a, b, c):
            print(1 + 2)
        while True:
            print('hello')
        """
    )
    node = example.body[1].body[0].value
    parent, index = get_non_exp_parent_and_index(example, node)
    assert isinstance(parent, ast.While)
    assert index == 0


# Generated at 2022-06-21 18:47:19.650899
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("if a: print(a)")
    if_node = tree.body[0]
    assert get_parent(tree, if_node.body[0]) == if_node
    assert get_parent(tree, if_node.body[0].value) == if_node.body[0]

# Generated at 2022-06-21 18:47:23.980595
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    mod = ast.parse("import sys; def foo(): print('hi'); sys.exit()")
    assert mod is not None
    assert mod.body[1].name == "foo"
    assert mod.body[1].body[0].value.s == "'hi'"
    print("test_get_non_exp_parent_and_index: passed")



# Generated at 2022-06-21 18:47:35.734723
# Unit test for function replace_at
def test_replace_at():
    node1 = ast.FunctionDef('node1')
    node2 = ast.FunctionDef('node2')
    node3 = ast.FunctionDef('node3')
    node4 = ast.FunctionDef('node4')
    node5 = ast.FunctionDef('node5')
    node6 = ast.FunctionDef('node6')
    node7 = ast.FunctionDef('node7')
    
    replace_at(2, node1, node2)

    assert node1.body[2].name == 'node2'
    assert node1.body[2] is node2
    
    node1.body = [node3, node4, node5]
    replace_at(2, node1, node2)

    assert node1.body[2].name == 'node2'
    assert node1.body[2] is node2
   

# Generated at 2022-06-21 18:47:48.216014
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def func(x, y):
        c = a + b
        d = 1 + 2
        return a + b + c + d

    ast_node = ast.parse("def func(x, y):\n\tc = a + b\n\td = 1 + 2\n\treturn a + b + c + d")
    func_node = ast_node.body[0]
    module = ast_node

    parent_node, index = get_non_exp_parent_and_index(module, func_node)
    assert(parent_node == module)
    assert(index == 0)

    return_node = func_node.body[2]
    parent_node, index = get_non_exp_parent_and_index(module, return_node)
    assert(parent_node == func_node)

# Generated at 2022-06-21 18:47:52.074326
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('while True: a = 1')
    node = find(tree, ast.Assign).__next__()
    assert get_non_exp_parent_and_index(tree, node) == (tree, 1)

