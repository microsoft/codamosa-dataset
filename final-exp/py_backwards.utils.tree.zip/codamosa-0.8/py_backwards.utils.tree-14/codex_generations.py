

# Generated at 2022-06-12 04:47:29.637250
# Unit test for function find
def test_find():  # type: ignore
    tree = ast.parse('a + b')
    nodes = find(tree, ast.BinOp)
    assert len(list(nodes)) == 1
    assert list(nodes)[0].left.id == 'a'



# Generated at 2022-06-12 04:47:34.984220
# Unit test for function insert_at
def test_insert_at():
    import ast
    class Test(ast.AST):
        def __init__(self):
            super().__init__()
            # We don't actually use this field but the generic visitor requires it
            self.body = []
    t = Test()
    insert_at(0,t,ast.parse("pass\n"))

# Generated at 2022-06-12 04:47:37.904516
# Unit test for function find
def test_find():
    import sys
    from _ast import parse
    from ast import Name

    tree = parse(sys.modules[__name__].__doc__)

    print(find(tree, Name))

# Generated at 2022-06-12 04:47:41.046489
# Unit test for function find
def test_find():
    tree = ast.parse('1 + 2\n3\n4')
    for n in find(tree, ast.BinOp):
        print(n)


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:47:46.712087
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = '''
x = 1
y = 2
z = 3

if x == y:
    print(z)
    '''
    tree = ast.parse(source)
    node = tree.body[3].body[0].value.args[0]
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert parent is tree.body[3].body[0]
    assert index == 0

# Generated at 2022-06-12 04:47:52.300676
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    dummy_function_body = ast.Module(
        body=[ast.FunctionDef(name='dummy_function',
                              args=ast.arguments(args=[]), body=[])])

    function_node, function_index = \
        get_non_exp_parent_and_index(dummy_function_body,
                                     dummy_function_body.body[0])
    assert isinstance(function_node, ast.Module) and function_index == 0



# Generated at 2022-06-12 04:47:54.904519
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    tree = astor.parse_file('example.py')  # type: ast.Module
    node = find(tree, ast.Name).__next__()
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)



# Generated at 2022-06-12 04:48:00.030227
# Unit test for function find
def test_find():
    from typed_ast.ast3 import parse
    ast_ = parse('a = 1\nb = a\nclass A:\n    pass')

    nodes = find(ast_, ast.Name)
    assert list(map(lambda x: x.id, nodes)) == ['a', 'a']

    nodes = find(ast_, ast.Name).__next__()
    assert isinstance(nodes, ast.Name)



# Generated at 2022-06-12 04:48:04.208780
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    parent = ast.AST()
    assert get_closest_parent_of(parent, parent, ast.AST) == parent

    parent = ast.AST()
    child = ast.AST()
    parent.body = [child]
    assert get_closest_parent_of(parent, child, ast.AST) == parent

    parent = ast.AST()
    child = ast.AST()
    grandchild = ast.AST()
    parent.body = [child]
    child.body = [grandchild]
    assert get_closest_parent_of(parent, grandchild, ast.AST) == child

    parent = ast.AST()
    child = ast.FunctionDef()
    grandchild = ast.AST()
    parent.body = [child]
    child.body = [grandchild]
    assert get_closest

# Generated at 2022-06-12 04:48:05.261288
# Unit test for function find

# Generated at 2022-06-12 04:48:12.861888
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''
if a == 1:
    b
    c
else:
    d
    e

f
        ''')
    _build_parents(tree)

    assert ast.dump(_parents[tree.body[0].body[0]]) == ast.dump(tree.body[0])
    assert ast.dump(_parents[tree.body[0].body[1]]) == ast.dump(tree.body[0])
    assert ast.dump(_parents[tree.body[0].body[0].targets[0]]) == \
        ast.dump(tree.body[0].body[0])
    assert ast.dump(_parents[tree.body[0].test.ops[0]]) == \
        ast.dump(tree.body[0].test)

# Generated at 2022-06-12 04:48:19.582606
# Unit test for function find
def test_find():
    example_node = ast.parse("""
    def test():
        return 1
    print(test())
    
    """)
    assert example_node.body[1].value.func.id == 'test'
    assert find(example_node, ast.Name).__next__().id == 'test'
    assert find(example_node, ast.Expr).__next__().value.id == 'test'
    assert find(example_node, ast.FunctionDef).__next__().name == 'test'

# Generated at 2022-06-12 04:48:22.574433
# Unit test for function insert_at
def test_insert_at():
    AST = ast.parse('a = 21')  # type: ignore
    ast_obj = AST.body.pop()  # type: ignore

    assert AST.body == []

    parent = get_parent(AST, ast_obj)
    insert_at(0, parent, ast_obj)

    assert AST.body == [ast_obj] # type: ignore



# Generated at 2022-06-12 04:48:29.704992
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Name('a', ast.Load())
    name = ast.Name('b', ast.Load())

    func = ast.FunctionDef('func', ast.arguments([], None, None, []),
                           [ast.Assign([name], node), ast.Return(node)])

    parent, index = get_non_exp_parent_and_index(func, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1


# Generated at 2022-06-12 04:48:37.687348
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    T = ast.alias(name='List', asname='T')
    a = ast.Name(id='a', ctx=ast.Store())
    b = ast.Name(id='b', ctx=ast.Store())
    lst = ast.List(elts=[a, b], ctx=ast.Store())
    pytest.assume(get_non_exp_parent_and_index(lst, a) == (lst, 0))
    pytest.assume(get_non_exp_parent_and_index(lst, b) == (lst, 1))

    t = ast.Subscript(value=lst, slice=ast.Index(value=lst), ctx=ast.Load())

# Generated at 2022-06-12 04:48:40.120115
# Unit test for function find
def test_find():
    from astunparse import unparse
    from ast import parse

# Generated at 2022-06-12 04:48:48.596053
# Unit test for function insert_at
def test_insert_at():
    import textwrap
    from astmonkey import transformers

    code = textwrap.dedent("""
        def function():
            pass
    """)

    # Build before
    ast_obj = ast.parse(code)
    before = transformers.ParentChildNodeTransformer().visit(ast_obj)

    # Build after
    def_ = find(ast_obj, ast.FunctionDef).__next__()
    new_node = ast.Print('hello', None, False)
    insert_at(0, def_, new_node)
    after = transformers.ParentChildNodeTransformer().visit(ast_obj)

    # Test
    assert before.body[0].body != after.body[0].body
    assert after.body[0].body[0] == new_node



# Generated at 2022-06-12 04:48:55.528089
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from ..utils import find
    def test():
        a = 1
        b = 2
        b = 2
        if a == 1:
            a = 2
        else:
            pass

    tree = ast.parse(inspect.getsource(test))
    nodes = find(tree, ast.Name)
    names = [node.id for node in nodes]
    assert names == ['a', 'b', 'b', 'a', 'else']



# Generated at 2022-06-12 04:48:59.554905
# Unit test for function find
def test_find():
    t = ast.parse(
        'def foo():\n'
        '    a = 1\n'
        '    b = 2\n'
    )

    assert len(list(find(t, ast.Assign))) == 2
    assert len(list(find(t, ast.Name))) == 2

# Generated at 2022-06-12 04:49:03.467139
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    n = ast.parse("for i in range(n):\n    print (i)").body[0]
    i = n.body[0]
    print(get_non_exp_parent_and_index(n, i))

# Generated at 2022-06-12 04:49:07.538705
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:49:17.637323
# Unit test for function find
def test_find():
    # given
    tree1 = """def f(x):
    return x * x"""
    tree2 = """def f(x, y):
    return x * x"""
    tree3 = """def f(x, y=7):
    return x * x"""
    tree4 = """def f(x, y=7, *a):
    return x * x"""
    tree5 = """def f(x, y=7, *a, **z):
    return x * x"""
    tree6 = """def f(x, y=7, *a, **z, &b):
    return x * x"""

    # Expect
    expected = 1

    # When
    count = 0
    found = find(ast.parse(tree1), ast.Return)
    for _ in found:
        count += 1

# Generated at 2022-06-12 04:49:20.492384
# Unit test for function find
def test_find():
  tree = ast.parse('x = 1')
  node = find(tree, ast.Name)
  assert node[0].id == 'x'
  assert len(list(node)) == 1
  print('test find success')

# Generated at 2022-06-12 04:49:26.911377
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast.ast3 import FunctionDef, Pass
    from ..visitor import ParentVisitor

    f = FunctionDef(name="f", body=[Pass(), Pass(), Pass(), Pass()],
                    args=[], decorator_list=[],
                    returns=None, type_comment=None)
    p = ParentVisitor()
    f.accept(p)
    parent, index = get_non_exp_parent_and_index(f, f.body[3])
    assert parent == f and index == 3

# Generated at 2022-06-12 04:49:29.222551
# Unit test for function find
def test_find():
    expr = ast.parse("print('foo')")
    assert expr.body[0] == next(find(expr, ast.Expr))  # type: ignore

# Generated at 2022-06-12 04:49:34.242803
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("a.b(c + d)")
    _build_parents(tree)
    assert(_parents[tree.body[0].value] == tree.body[0])
    assert(_parents[tree.body[0].value.func] == tree.body[0].value)



# Generated at 2022-06-12 04:49:39.477113
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = '''
    def foo(a):
        b = a
        b += 1
        c = b + 2
        return c
    '''

    tree = ast.parse(code)
    node = get_closest_parent_of(tree, tree.body[0].body[2].value, ast.FunctionDef)
    assert isinstance(node, ast.FunctionDef)

# Generated at 2022-06-12 04:49:43.608171
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('for i in range(10):\n pass')
    for_loop = tree.body[0]
    pass_node = for_loop.body[0]
    parent, index = get_non_exp_parent_and_index(tree, pass_node)
    assert parent == for_loop
    assert index == 0

# Generated at 2022-06-12 04:49:46.586935
# Unit test for function find
def test_find():
    with open('test_input/test1.py') as f:
        tree = ast.parse(f.read())

    result = find(tree, ast.Call)
    assert len(list(result)) == 3

# Generated at 2022-06-12 04:49:48.529036
# Unit test for function find
def test_find():
    import sys
    import os
    import astor

# Generated at 2022-06-12 04:49:57.411399
# Unit test for function find
def test_find():
    from .test_util import load_test_script

    script = load_test_script()
    for node in find(script, ast.Name):
        pass



# Generated at 2022-06-12 04:50:00.561993
# Unit test for function find
def test_find():
    ast_ = ast.parse('f()')
    funcs = list(find(ast_, ast.FunctionDef))
    assert len(funcs) == 1
    assert funcs[0].name == 'f'


# Generated at 2022-06-12 04:50:07.526034
# Unit test for function get_parent
def test_get_parent():
    class TestAST(ast.AST):
        _fields = ()

    class FirstClass(TestAST):
        class_ = TestAST()

    class SecondClass(TestAST):
        class_ = TestAST()

    first = FirstClass()
    second = SecondClass()

    first.class_ = second
    second.class_ = TestAST()

    res = get_parent(first, first.class_)

    assert res == first

    res = get_parent(first, first.class_.class_)

    assert res == first.class_

# Generated at 2022-06-12 04:50:09.127718
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:50:14.926477
# Unit test for function get_parent
def test_get_parent():
    def foo():
        pass

    tree = ast.fix_missing_locations(ast.parse(inspect.getsource(foo)))

    assert get_parent(tree, tree) is None
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)



# Generated at 2022-06-12 04:50:17.375796
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('x = 1')
    node = tree.body[0]

    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)

# Generated at 2022-06-12 04:50:25.365480
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""x = [[1, 2, 3], [4]]""")
    node = tree.body[0].value.elts[0]
    assert isinstance(node, ast.List)
    assert isinstance(node.elts[0], ast.Num)
    assert isinstance(get_closest_parent_of(tree, node.elts[0], ast.Call), ast.Call)
    assert isinstance(get_closest_parent_of(tree, node, ast.Call), ast.Assign)

# Generated at 2022-06-12 04:50:31.773476
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast

    class TestVisitor(ast.NodeVisitor):
        def visit_Name(self, node):
            print('name: {}'.format(node.id))

    with open('tests/source_files/find.py', 'r') as source_file:
        tree = ast.parse(source_file.read())

    first_name = next(find(tree, ast.Name))
    first_name.id = 'ast.Name'

    visitor = TestVisitor()
    visitor.visit(tree)

    print(ast.dump(tree))



# Generated at 2022-06-12 04:50:32.753518
# Unit test for function find

# Generated at 2022-06-12 04:50:39.520224
# Unit test for function find
def test_find():
    from . import pretty_print
    tree = ast.parse('a = 1 + b')
    a = find(tree, ast.Name)
    assert str(list(a)[0]) == "Name(id='a', ctx=Store())", \
        pretty_print(list(a)[0])
    b = find(tree, ast.Name).next()
    assert str(b) == "Name(id='b', ctx=Load())", pretty_print(b)
    b = find(tree, ast.Name).__next__()
    assert str(b) == "Name(id='b', ctx=Load())", pretty_print(b)

# Generated at 2022-06-12 04:50:48.888170
# Unit test for function replace_at
def test_replace_at():
    class FalseNode:
        def __init__(self, body):
            self.body = body

    parent = FalseNode([1, 1])
    replace_at(0, parent, [3])
    assert parent.body[0] == 3

# Generated at 2022-06-12 04:50:52.493322
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('list()[2]')
    index_node = tree.body[0].value.slice.value
    parent_node, index = get_non_exp_parent_and_index(tree, index_node)
    assert isinstance(parent_node, ast.Subscript)
    assert index == 0


# Generated at 2022-06-12 04:51:01.090753
# Unit test for function replace_at
def test_replace_at():
    """Lorem ipsum dolor sit amet."""
    tree = ast.parse('a = 1\n')
    node = tree.body[0]
    parent = tree

    replace_at(0, parent, [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                      value=ast.Constant(2))])

    assert isinstance(parent.body[0], ast.Assign)
    assert parent.body[0].value.value == 2  # pylint: disable=no-member
    assert parent.body[0].targets[0].id == 'a'  # pylint: disable=no-member

# Generated at 2022-06-12 04:51:03.724615
# Unit test for function find
def test_find():
    for i in range(1000):
        tree = ast.parse('a.b(c, d)')
        assert find(tree, ast.Call) == [tree.body[0].value]

# Generated at 2022-06-12 04:51:10.429894
# Unit test for function get_parent
def test_get_parent():
    _code = "a = b + c * d"
    tree = ast.parse(_code)
    _build_parents(tree)
    assert get_parent(tree, _parents[tree.body[0].value]) == tree.body[0]
    assert get_parent(tree, _parents[tree.body[0].value.left]) == tree.body[0].value
    assert get_parent(tree, _parents[tree.body[0].value.right]) == tree.body[0].value



# Generated at 2022-06-12 04:51:11.765950
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor

# Generated at 2022-06-12 04:51:16.059627
# Unit test for function find
def test_find():
    tree = ast.parse("def foo(): print('a')")
    assert len(list(find(tree, ast.Print))) == 1
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Str))) == 1


# Generated at 2022-06-12 04:51:20.283340
# Unit test for function find
def test_find():
    class Module(ast.AST):
        _fields = ()

    class Num(ast.AST):
        _fields = ('n',)

    m = Module(body=[Num(n=1), Num(n=1)])
    assert list(find(m, Num)) == [Num(n=1), Num(n=1)]



# Generated at 2022-06-12 04:51:23.726676
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('1 + 2'), ast.BinOp))) == 1

# Generated at 2022-06-12 04:51:29.856752
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = '''
    import math
    for i in range(5):
        print(i)
    '''
    tree = ast.parse(code)

    for node in ast.walk(tree):
        if isinstance(get_closest_parent_of(tree, node, ast.For), ast.For):
            assert isinstance(node, ast.Name) or isinstance(node, ast.Attribute)

# Generated at 2022-06-12 04:51:44.153526
# Unit test for function find
def test_find():
    node = ast.parse('x = 1')
    nodes = list(find(node, ast.Assign))
    assert len(nodes) == 1 and isinstance(nodes[0], ast.Assign)


# Generated at 2022-06-12 04:51:47.820279
# Unit test for function find
def test_find():  # pragma: no cover
    code = ast.parse('[0, 1, 2, 3, 4]')
    result = list(find(code, ast.List))
    assert len(result) == 1
    assert isinstance(result[0], ast.List)



# Generated at 2022-06-12 04:51:53.795378
# Unit test for function find
def test_find():
    # Can find all nodes of type FunctionDef
    # Can find all nodes of type Str
    test_string = """
    def test():
        a = "test"
        return a
    """
    tree = ast.parse(test_string)
    func_nodes = find(tree, ast.FunctionDef)
    str_nodes = find(tree, ast.Str)
    assert len(list(func_nodes)) == 1
    assert len(list(str_nodes)) == 1

# Generated at 2022-06-12 04:51:55.447125
# Unit test for function find

# Generated at 2022-06-12 04:51:57.327829
# Unit test for function get_parent
def test_get_parent():
    """Unittest for get_parent"""

# Generated at 2022-06-12 04:52:02.545227
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as typed_ast
    ast_tree = typed_ast.parse("def my_fun(a): b = a")
    assert isinstance(
        get_closest_parent_of(ast_tree, ast_tree.body[0].body[0], typed_ast.Module), typed_ast.Module)
    print("Test get_closest_parent_of passed.")

# Generated at 2022-06-12 04:52:09.134097
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_tree = ast.parse("""
        def test(x):
            y = x + 1
            return y
    """)

    test_tree2 = ast.parse("""
        def test(x):
            y = x + 1

        if x == y:
            y = x + 1
    """)

    assert parent == test_tree.body[0]
    assert index == 0

    assert parent == test_tree2.body[1]
    assert index == 0

# Generated at 2022-06-12 04:52:10.067139
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:52:10.998326
# Unit test for function find

# Generated at 2022-06-12 04:52:16.829014
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Arrange
    code = '''
    def test():
        foo()
    '''

    tree = ast.parse(code)
    node = tree.body[0].body[0]

    # Act
    result = get_closest_parent_of(tree, node, ast.FunctionDef)

    # Assert
    assert isinstance(result, ast.FunctionDef)

# Generated at 2022-06-12 04:52:43.506222
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.Name(id='x')
    parent = get_closest_parent_of(node, node, ast.Name)
    assert parent.id == 'x'

    expr = ast.BinOp(node, ast.Add(), ast.Num(n=1))
    parent = get_closest_parent_of(expr, node, ast.Num)
    assert parent.n == 1

# Generated at 2022-06-12 04:52:44.638671
# Unit test for function find

# Generated at 2022-06-12 04:52:54.524861
# Unit test for function replace_at
def test_replace_at():
    parent = ast.Module(body=[ast.FunctionDef(
        name="foo",
        args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[],
                           kwarg=None, defaults=[]),
        body=[], decorator_list=[], returns=None)])
    replace_at(0, parent, ast.FunctionDef(name="bar",
                                          args=ast.arguments(args=[],
                                                             vararg=None,
                                                             kwonlyargs=[],
                                                             kw_defaults=[],
                                                             kwarg=None,
                                                             defaults=[]),
                                          body=[], decorator_list=[],
                                          returns=None))
    assert len(parent.body) == 1
   

# Generated at 2022-06-12 04:52:59.459809
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class A:
        pass

    class B:
        pass

    class C:
        pass

    class D:
        pass

    class E:
        pass

    _parents[C()] = D()
    _parents[D()] = E()

    assert get_closest_parent_of(A(), C(), B) == D()

# Generated at 2022-06-12 04:53:05.542052
# Unit test for function find
def test_find():
    from astunparse import unparse

    tree = ast.parse('''
if True:
    def f(x):
        return x + 1

    print(f(4))
    print(f.__name__)
''')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])
    assert isinstance(parent, ast.Module)
    assert index == 1



# Generated at 2022-06-12 04:53:09.400673
# Unit test for function find
def test_find():
    code = ast.parse("def foo(): return;")
    assert isinstance(next(find(code, ast.FunctionDef)), ast.FunctionDef)
    assert isinstance(next(find(code, ast.Name)), ast.Name)
    assert isinstance(next(find(code, ast.Return)), ast.Return)



# Generated at 2022-06-12 04:53:11.561082
# Unit test for function find
def test_find():
    tree = ast.parse('import a\n'
                     'import b\n'
                     'import c\n'
                     'def foo():\n'
                     '    pass\n')

    assert list(find(tree, ast.Import)) == tree.body[0:3]



# Generated at 2022-06-12 04:53:15.250300
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('if x: a = 1')
    node = tree.body[0].body[0].targets[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert index == 0
    assert isinstance(parent, ast.If)

# Generated at 2022-06-12 04:53:16.288899
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..exceptions import NodeNotFound

# Generated at 2022-06-12 04:53:20.054995
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast

    source = "test(test2)\n"
    parsed = ast.parse(source)
    node_to_search = parsed.body[0].body[0].value
    parent, index = get_non_exp_parent_and_index(parsed, node_to_search)
    assert parent == parsed.body[0]
    assert index == 0


# Generated at 2022-06-12 04:53:57.737473
# Unit test for function get_parent
def test_get_parent():
    class Test(ast.AST):
        _fields = ()  # type: Tuple[str, ...]

        @property
        def body(self):
            return ()  # type: Tuple[ast.AST, ...]

    class Test2(ast.AST):
        _fields = ()  # type: Tuple[str, ...]

        @property
        def body(self):
            return ()  # type: Tuple[ast.AST, ...]

        test = Test()

    class Test3(ast.AST):
        _fields = ()  # type: Tuple[str, ...]

        @property
        def body(self):
            return ()  # type: Tuple[ast.AST, ...]

        test_2 = Test2()

    test_3 = Test3()


# Generated at 2022-06-12 04:54:03.167194
# Unit test for function find
def test_find():
    assert [node for node in find(ast.parse('x*x'), ast.BinOp)] \
        == ast.parse('x*x').body[0].value.args

    assert [node for node in find(ast.parse('x*x'), ast.Name)] \
        == ast.parse('x*x').body[0].value.args

# Generated at 2022-06-12 04:54:08.659024
# Unit test for function find
def test_find():
    source_code = "import sys\nprint('hello world')"
    tree = ast.parse(source_code)

    for imp in find(tree, ast.Import):
        print(
            'import {0} {1}'.format(imp.names[0].asname or imp.names[0].name,
                                    imp.names[0].name))

if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:54:09.514268
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:54:14.253385
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    tree = ast.parse("a = 4")
    expected = ast.parse("a = 4")
    result = get_closest_parent_of(tree, tree.body[0].value, ast.Module)
    assert astor.to_source(result) == astor.to_source(expected)

# Generated at 2022-06-12 04:54:22.917344
# Unit test for function get_parent
def test_get_parent():
    import typed_ast.ast3

    t = typed_ast.ast3.parse("def f(x):\n"
                             "    if x:\n"
                             "        return foo(x, 2)\n"
                             "    else:\n"
                             "        return bar(x)\n",
                             mode="exec")

    # get FunctionDef node
    assert isinstance(get_parent(t, get_parent(t, t.body[0].body[0].body[0])),
                      typed_ast.ast3.FunctionDef)

    # get If node
    assert isinstance(get_parent(t, t.body[0].body[0].body[0]),
                      typed_ast.ast3.If)

    # get If, If

# Generated at 2022-06-12 04:54:23.837161
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:54:30.663040
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = '''
        def f():
            if a:
                b = 1
    '''
    mod = ast.parse(code)
    node = get_closest_parent_of(mod, mod.body[0].body[0].body[0], ast.If)
    parent, index = get_non_exp_parent_and_index(mod, node)
    assert parent == mod.body[0]
    assert index == 0



# Generated at 2022-06-12 04:54:33.901699
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('a[b[c]].d')
    node = tree.body[0].value.value.slice.value

    slice_ = get_closest_parent_of(tree, node, ast.Slice)
    assert slice_.value is node


# Generated at 2022-06-12 04:54:37.937921
# Unit test for function find
def test_find():
    tree = ast.parse("if a: b = 1 + 2")
    b_eqn = find(tree, ast.Assign).__next__()
    assert b_eqn.value.left.value.id == "b"


# Generated at 2022-06-12 04:55:48.886305
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    example_1 = ast.parse("def bar():\n"
                          "\treturn 1\n")
    assert get_non_exp_parent_and_index(example_1, example_1.body[0].body[0]) == (example_1.body[0], 0)
    assert get_non_exp_parent_and_index(example_1, example_1.body[0].body[0].value) == (example_1.body[0].body[0], 0)

    example_2 = ast.parse("if True:\n"
                          "\tprint(1)")
    assert get_non_exp_parent_and_index(example_2, example_2.body[0].body[0]) == (example_2.body[0], 0)


# Generated at 2022-06-12 04:55:49.808216
# Unit test for function find

# Generated at 2022-06-12 04:55:54.052621
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse(
        '''def bar(a):
        if True:
            return a
        '''
    )
    node = tree.body[0].body[0].value
    type_ = ast.FunctionDef
    assert get_closest_parent_of(tree, node, type_) == tree.body[0]


# Generated at 2022-06-12 04:55:57.011853
# Unit test for function find
def test_find():
    tree = ast.parse('1+1')
    assert list(find(tree, ast.Add)) == [ast.parse('1+1', mode='eval').body]


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:56:01.363740
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse("x = 3")
    parent = get_parent(node, node.body[0])

    assert isinstance(parent, ast.Module)

    parent = get_parent(node, node.body[0].targets[0])
    assert isinstance(parent, ast.Assign)



# Generated at 2022-06-12 04:56:07.381451
# Unit test for function find
def test_find():
    from textwrap import dedent
    from importlib import import_module
    from .util import module_path
    from .transpile import transpile

    module = import_module(module_path())

    tree = transpile(dedent("""
    def add(a: int, b: int) -> int:
        return a + b

    def sub(a: int, b: int) -> int:
        return a - b

    add(10, 5)
    """))

    module.assertCountEqual(find(tree, ast.Call), tree.body[-1].value)

# Generated at 2022-06-12 04:56:16.002181
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast
    import inspect
    import unittest

    class TestGetClosestParentOf(unittest.TestCase):
        def test1(self):
            source = '''
            a = 1
            if a == 1:\n\tb = 2\n\t'''
            tree = ast.parse(source)
            node = tree.body[1]
            parent = get_closest_parent_of(tree, node, ast.Module)
            self.assertEqual(type(parent), ast.Module)

        def test2(self):
            source = '''
            a = 1
            if a == 1:\n\tb = 2\n\t'''
            tree = ast.parse(source)
            node = tree.body[1].body[0]
            parent = get_closest_

# Generated at 2022-06-12 04:56:18.388062
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    statement = ast.parse("while True: print('hello')")
    node = ast.parse("print('hello')")
    parent, index = get_non_exp_parent_and_index(statement, node.body[0])
    assert parent == statement
    assert index == 0

# Generated at 2022-06-12 04:56:23.921043
# Unit test for function get_parent
def test_get_parent():
    """Test for function get_parent."""
    pass
    #FIXME: Figure out how to test this
    #tree = ast.parse('a = 1')
    #node = tree.body[0].value

    #parent1 = get_parent(tree, node)
    #assert isinstance(parent1, ast.Assign), 'Parent1 is not Assign'
    #parent2 = get_parent(tree, node)
    #assert parent1 is parent2, 'Parent1 and Parent2 are not equal'

# Generated at 2022-06-12 04:56:28.768627
# Unit test for function find
def test_find():
    def foo() -> None:
        return [x for x in range(10)]

    tree = ast.parse(inspect.getsource(foo))
    lc = get_closest_parent_of(tree, find(tree, ast.ListComp).__next__(),
                               ast.FunctionDef)
    print(lc)

if __name__ == '__main__':
    test_find()