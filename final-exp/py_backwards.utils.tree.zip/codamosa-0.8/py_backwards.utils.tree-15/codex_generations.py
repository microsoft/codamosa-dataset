

# Generated at 2022-06-12 04:47:29.441581
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    expr = ast.parse("if s: pass")
    get_non_exp_parent_and_index(expr, expr.body[0].body[0])


if __name__ == '__main__':
    test_get_non_exp_parent_and_index()

# Generated at 2022-06-12 04:47:33.388972
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    func_def = ast.parse('def func(): pass').body[0]
    assert func_def == get_closest_parent_of(func_def, func_def, ast.FunctionDef)

# Generated at 2022-06-12 04:47:39.152712
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('x == y and b == c or d == e')
    test_node = tree.body[0].value.ops[0]
    assert test_node.__class__.__name__ == 'Eq'

    replace_at(0, tree.body[0].value, ast.Lt())
    assert tree.body[0].value.ops[0].__class__.__name__ == 'Lt'

# Generated at 2022-06-12 04:47:48.348399
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import re
    import astor

    def get_node_at_index(code: str, index: int) -> ast.AST:
        return ast.parse(code).body[0].body[index]

    def get_node_at_str_index(code: str, index: str) -> ast.AST:
        return get_node_at_index(code, int(index))

    code = '''
if True:
    pass
else:
    pass
    '''
    exp = get_node_at_index(code, 1)
    parent, index = get_non_exp_parent_and_index(ast.parse(code), exp)
    assert isinstance(parent, ast.If)
    assert index == 1
    assert Code.from_ast(parent) == Code.from_ast(ast.parse(code))

# Generated at 2022-06-12 04:47:52.052608
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""def f():\n    a = 1 + 2\n    b = 3 + 4""")
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])

    assert isinstance(parent, ast.Module)
    assert index == 1

# Generated at 2022-06-12 04:47:57.079232
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n  if bar():\n    return baz()')
    expected = (tree.body[0].body[0], 0)
    assert expected == get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])



# Generated at 2022-06-12 04:48:03.109632
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a = ast.parse('''
        def abc():
            for i in range(1):
                def defg():
                    pass
    ''')

    parent = get_closest_parent_of(a, a.body[0].body[0].body[0],
                                   ast.FunctionDef)
    assert parent.name == 'defg'

# Generated at 2022-06-12 04:48:07.865988
# Unit test for function get_parent
def test_get_parent():

    class Node:
        pass

    class Node1(Node):
        pass

    class Node2(Node):
        pass

    class Node3(Node):
        pass

    class Node4(Node):
        pass

    class Node5(Node):
        pass

    class Node6(Node):
        pass

    class Node7(Node):
        pass

    class Node8(Node):
        pass

    class Node9(Node):
        pass

    class Node10(Node):
        pass

    class Node11(Node):
        pass

    class Node12(Node):
        pass

    class Node13(Node):
        pass

    class Node14(Node):
        pass

    class Node15(Node):
        pass

    class Node16(Node):
        pass

    class Node17(Node):
        pass


# Generated at 2022-06-12 04:48:10.865290
# Unit test for function find
def test_find():
    source = '''
    def f():
        pass
    class C:
        pass
    '''
    tree = ast.parse(source)
    classes = list(find(tree, ast.ClassDef))
    assert len(classes) == 1

# Generated at 2022-06-12 04:48:17.937078
# Unit test for function insert_at
def test_insert_at():
    def f(a, b):
        return a + b
        return a + b

    # Replace the second Return node with a Name node with id "c"
    module = ast.parse(inspect.getsource(f))
    func = module.body[0]
    name = ast.Name(id="c", ctx=ast.Load())
    insert_at(1, func, name)
    assert ast.dump(module) == "def f(a, b):\n    return a + b\n    c"



# Generated at 2022-06-12 04:48:22.587735
# Unit test for function find
def test_find():
    from astpretty import pprint


# Generated at 2022-06-12 04:48:27.829817
# Unit test for function find
def test_find():
    import astor
    t = ast.parse('if True: x = 1').body[0]
    nodes = list(find(t, ast.Name))
    assert len(nodes) == 1
    assert astor.to_source(nodes[0]).strip() == 'True'


# Generated at 2022-06-12 04:48:30.362946
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('if True: a=5\nelse: a=6\n')
    node = tree.body[1].body[0].value
    assert get_non_exp_parent_and_index(tree, node) == (tree.body[1].body, 0)



# Generated at 2022-06-12 04:48:35.686458
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .test_data import ONE_FUNC_MODULE

    module = ast.parse(ONE_FUNC_MODULE)
    func = module.body[0]
    stmt = func.body[0]
    body = func.body
    assert get_closest_parent_of(module, stmt, ast.FunctionDef) == func
    assert get_closest_parent_of(module, func, ast.Module) == module
    assert get_closest_parent_of(module, body[0], ast.Module) == module

# Generated at 2022-06-12 04:48:46.260490
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:48:51.151761
# Unit test for function find
def test_find():
    # Type of tree can be function, class, module.
    # If none, tree is going to be treated as module.
    tree = ast.parse('import ast3\ndef func():\n\tpass')
    assert len(list(find(tree, ast.FunctionDef))) == 1



# Generated at 2022-06-12 04:49:01.347590
# Unit test for function find
def test_find():
    from ..examples import Example
    from ..examples import if_else
    from ..examples import for_loop

    tree = ast.parse(Example.simple_if_else)
    if_stmt = next(find(tree, ast.If))

    assert tree.body[0] == if_stmt

    tree = ast.parse(Example.simple_for_loop)
    for_stmt = next(find(tree, ast.For))

    assert tree.body[0] == for_stmt

    tree = ast.parse(if_else.__doc__[8:])
    if_stmt = next(find(tree, ast.If))
    else_stmt = next(find(tree, ast.If))

    assert get_parent(tree, else_stmt) == if_stmt
    assert get_parent

# Generated at 2022-06-12 04:49:02.771256
# Unit test for function find

# Generated at 2022-06-12 04:49:13.385449
# Unit test for function replace_at
def test_replace_at():
    import unittest

    class Node(ast.AST):
        """Serve as mock for testing."""
        body = []
        field = ''

    class A(Node):
        """Serve as mock for testing."""
        pass

    class B(Node):
        """Serve as mock for testing."""
        pass

    class C(Node):
        """Serve as mock for testing."""
        pass

    class ReplaceAtTest(unittest.TestCase):
        """Test case for replace_at."""

        def test_replace_at(self):
            a = A()
            b = B()
            c = C()
            a.body = [b, c]

            replace_at(0, a, c)

            self.assertEqual(a.body, [c, c])


# Generated at 2022-06-12 04:49:19.310884
# Unit test for function get_parent
def test_get_parent():
    code = """def f():
        return 1"""

    tree = ast.parse(code)
    first_leaf = ast.FunctionDef(name='f', body=[ast.Return(value=ast.Num(n=1))],
                                 args=ast.arguments(
                                     args=[], vararg=None, kwonlyargs=[],
                                     kw_defaults=[], kwarg=None,
                                     defaults=[]))
    parent = ast.Module(body=[first_leaf])
    assert get_parent(tree, first_leaf) == parent


test_get_parent()



# Generated at 2022-06-12 04:49:30.996298
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = """
        def test():
            return 'hello'
            if True:
                pass
    """

    module = ast.parse(source)

    funcdef = module.body[0]
    str = funcdef.body[0].value
    assert get_non_exp_parent_and_index(module, str) == (funcdef, 0)

    if_ = funcdef.body[1]
    assert get_non_exp_parent_and_index(module, if_) == (funcdef, 1)



# Generated at 2022-06-12 04:49:41.414807
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test that get_non_exp_parent_and_index"""

    class InnerNonExp(ast.AST):
        pass

    class InnerExp(ast.AST):
        body = []

    class NonExp(ast.AST):
        def body(self):
            return []

    class Exp(ast.AST):
        body = []

    class Body(ast.AST):
        body = []

    class Root(ast.AST):
        body = []

    inner_inner = InnerNonExp()
    inner = InnerNonExp()
    non_exp = NonExp()
    exp = Exp()
    body = Body()
    root = Root()

    non_exp.body.append(inner_inner)
    body.body.append(non_exp)
    root.body.append(body)

    exp.body.append(inner)

# Generated at 2022-06-12 04:49:50.784963
# Unit test for function replace_at
def test_replace_at():
    import unittest

    class TestAST(ast.AST):
        def __init__(self, val):
            super().__init__()
            self.val = val

    class TestAST2(ast.AST):
        def __init__(self, val, body=None):
            super().__init__()
            self.val = val
            self.body = body or []

    class TestCase(unittest.TestCase):
        def test_simple(self):
            test_node1 = TestAST2(1, [TestAST(2), TestAST(3)])
            test_node2 = TestAST(4)
            replace_at(0, test_node1, test_node2)
            self.assertEqual(test_node1.body[0].val, 4)

    unittest.main()



# Generated at 2022-06-12 04:49:57.445368
# Unit test for function get_parent
def test_get_parent():
    """Test for function get_parent."""
    class Node:
        def __init__(self, parent, node):
            self.parent = parent
            self.node = node
            self.name = node.__name__

    original = Node(None, Node)
    assert get_parent(original, original) is None

    # assert get_parent(original, original.node) is None

    c = Node(original, Node)
    assert get_parent(original, c) is original
    assert get_parent(c, original) is None

    c = Node(original, Node)
    assert get_parent(c, original.node) is original
    assert get_parent(original, c.node) is original

    c = Node(None, Node)
    assert get_parent(original, c) is None

# Generated at 2022-06-12 04:50:04.032427
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """ print("hi")
    if (1 > 2):
        print("bye")
    else:
        print("never")
    """

    class FileExpr(ast.AST):
        _fields = ('body',)

    # Create tree
    tree = ast.parse(code, mode='exec')
    # Create FileExpr node
    file_expr = FileExpr(body=tree.body)
    # Replace tree body with file_expr
    tree.body = [file_expr]
    _build_parents(tree)

    node = get_parent(tree, tree.body[0].body[1].body[1])
    assert isinstance(node, FileExpr)
    assert isinstance(get_closest_parent_of(tree, node, FileExpr), FileExpr)

# Generated at 2022-06-12 04:50:12.426687
# Unit test for function get_parent
def test_get_parent():
    import unittest

    class Test(unittest.TestCase):
        def get_parents(self, root):
            parents = {}
            for node in ast.walk(root):
                for child in ast.iter_child_nodes(node):
                    parents[child] = node
            return parents

        def test_get_parent(self):
            root = ast.parse('a = 1 + 2')
            expected = self.get_parents(root)
            actual = _parents  # type: ignore
            self.assertDictEqual(expected, actual)

    unittest.main(verbosity=2)

# Generated at 2022-06-12 04:50:19.418064
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("x = 'a' + 'b'")
    func = tree.body[0]
    assert get_parent(tree, tree) is None
    assert get_parent(tree, func) == tree
    assert get_parent(tree, func.value) == func
    assert get_parent(tree, func.value.left) == func.value
    assert get_parent(tree, func.value.right) == func.value
    assert (get_parent(tree, func.value.left, True) ==
            get_parent(tree, func.value.left))


# Generated at 2022-06-12 04:50:27.430730
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    sample_tree = ast.parse("""
    def f1():
        def f2():
            def f3():
                return 1
            return 2
        return 3
    """)
    assert get_closest_parent_of(sample_tree, sample_tree.body[0].body[0].body[0], ast.FunctionDef) == sample_tree.body[0].body[0]
    assert get_closest_parent_of(sample_tree, sample_tree.body[0].body[0].body[0], ast.Module) == sample_tree

# Generated at 2022-06-12 04:50:30.169657
# Unit test for function find
def test_find():
    program = ast.parse("if False: a=5")
    for node in find(program, ast.Name):
        print(node)


if __name__ == '__main__':
    import sys
    test_find()

# Generated at 2022-06-12 04:50:30.934473
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:50:40.962552
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test if get_non_exp_parent_and_index() works correctly."""
    import astor
    tree = ast.parse('f = g(a, *args, **kwds)')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert astor.to_source(parent) == 'f=g(a,*args,**kwds)' and index == 0

# Generated at 2022-06-12 04:50:41.896153
# Unit test for function find

# Generated at 2022-06-12 04:50:43.136777
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # todo: write tests
    assert True

# Generated at 2022-06-12 04:50:50.918230
# Unit test for function find
def test_find():
    class A(ast.AST):
        _fields = ()  # type: ignore

    class B(A):
        pass

    class C(B):
        pass

    ac = A()
    bc = B()
    cc = C()

    b = B(body=[ac, bc, cc])
    tree = A(body=[b])
    print(list(find(tree, A)))
    print(list(find(tree, B)))
    print(list(find(tree, C)))
    assert len(list(find(tree, A))) == 3
    assert len(list(find(tree, B))) == 1
    assert len(list(find(tree, C))) == 1

# Generated at 2022-06-12 04:50:53.626025
# Unit test for function find
def test_find():
    tree = ast.parse('1 + 1')
    expr = find(tree, ast.expr)

    for n in expr:
        assert isinstance(n, ast.expr)



# Generated at 2022-06-12 04:50:55.196697
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:51:02.033503
# Unit test for function get_parent
def test_get_parent():
    test_ast = ast.parse('''
    x = 5
    ''')

    _build_parents(test_ast)
    test_parent = _parents[test_ast.body[0].value]
    assert test_parent == test_ast.body[0]

    test_ast = ast.parse('''
    for i in range(5):
        print(i)
    ''')
    _build_parents(test_ast)
    test_parent = _parents[test_ast.body[0].body[0].value.args[0]]
    assert test_parent == test_ast.body[0].body[0]

# Generated at 2022-06-12 04:51:06.320911
# Unit test for function find
def test_find():
    test_code = "some = 5 + 2"

    result = list(find(ast.parse(test_code), ast.BinOp))
    result = [ast.dump(node) for node in result]

    assert result == ["BinOp(left=Num(n=5), op=Add(), right=Num(n=2))"]

# Generated at 2022-06-12 04:51:10.855084
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    '''
    def foo():
        pass
    '''

    tree = ast.parse(inspect.getsource(test_get_closest_parent_of))
    assert isinstance(get_closest_parent_of(tree, tree, ast.Module), ast.Module)

# Generated at 2022-06-12 04:51:16.242530
# Unit test for function find
def test_find():
    from ..ast_factory import AstFactory

    af = AstFactory()
    tree = af.function('test', af.int_arg('a'), af.body(
        af.assign('a', af.integer(1)),
        af.assign('b', af.integer(2))
    ))
    assert len(list(find(tree, ast.Assign))) == 2

# Generated at 2022-06-12 04:51:26.246005
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class A:
        def __init__(self, a):
            self.a = a

    a = A(1)
    print(a)

# Generated at 2022-06-12 04:51:34.853665
# Unit test for function find
def test_find():
    import unittest
    import ast as python_ast

    class FindTest(unittest.TestCase):
        def _get_target(self, node: ast.AST) -> ast.arguments:
            return get_closest_parent_of(node, node, ast.arguments)

        def test_find(self):
            with self.assertRaises(NodeNotFound):
                find(ast.Expr(value=ast.Num(0)), ast.FunctionDef)

            tree = ast.parse("""
            def foo(a, b):
                print(a + b)""")


# Generated at 2022-06-12 04:51:38.840100
# Unit test for function find
def test_find():
    tree = ast.parse(" list(map(lambda x: x*x, range(5)))\n")
    out = list(find(tree, ast.Call))
    assert out[0].func.id == 'list'
    out = list(find(tree, ast.Lambda))
    assert out[0].args.args[0].arg == 'x'

# Generated at 2022-06-12 04:51:40.163047
# Unit test for function find

# Generated at 2022-06-12 04:51:45.491829
# Unit test for function find
def test_find():
    code = """
    def func(a):
        b = 5
        b = 6

        return a + b
    """

    tree = ast.parse(code)
    num = list(find(tree, ast.Num))

    assert len(num) == 2
    assert num[0].n == 5
    assert num[1].n == 6

# Generated at 2022-06-12 04:51:51.791190
# Unit test for function get_parent
def test_get_parent():
    import ast as ast_
    code = '''def f():
                a = 1
                return a
            '''
    tree = ast_.parse(code)
    function_body = tree.body[0].body

    # Test valid values
    assert get_parent(tree, function_body[0].value) == function_body[0]
    assert get_parent(tree, function_body[0]) == function_body

    # Test rebuild
    get_parent(tree, tree, True)
    assert get_parent(tree, tree) is None

    # Test invalid node
    assert get_parent(tree, ast_) == None

# Generated at 2022-06-12 04:51:56.621549
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    root = ast.parse("""
        def foo(x):
            return x
        """)
    node = root.body[0]
    parent, index = get_non_exp_parent_and_index(root, node.body[0].value)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-12 04:51:57.762900
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:52:04.219969
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def function():
        pass

    tree = ast.parse('''def function():
    pass''')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent is tree.body[0]
    assert index == 0
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert parent is tree.body[0].body[0]
    assert index == 0

# Generated at 2022-06-12 04:52:06.572648
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index"""

# Generated at 2022-06-12 04:52:28.047763
# Unit test for function find
def test_find():
    t = ast.parse('import abc\nabc.def')
    r = find(t, ast.Import)
    next(r)
    assert next(r) is None
    assert find(t, ast.ImportFrom) is None

# Generated at 2022-06-12 04:52:33.770902
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import inspect
    import astor

    test_data = [
        ('def f(): pass', 'def', ast.FunctionDef),
        ('class C: pass', 'class', ast.ClassDef),
        ('def f(): pass', 'def', ast.FunctionDef),
    ]
    for data in test_data:
        src, cls, cls_ = data
        t = astor.parse_file(inspect.getsourcefile(type(src)))
        f = get_closest_parent_of(t, t.body[0], cls_)
        assert getattr(f, 'name', '') == cls

test_get_closest_parent_of()



# Generated at 2022-06-12 04:52:43.126853
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import __main__
    import inspect
    import sys
    import astor
    import astunparse

    test_body = """
    while True:
        print("Hello there")
    """
    tree = ast.parse(test_body)
    node = tree.body[0]
    parent = get_closest_parent_of(tree, node, ast.Module)
    assert isinstance(parent, ast.Module)

    test_body = """
    while True:
        if True:
            print("Hello there")
    """
    tree = ast.parse(test_body)
    node = tree.body[0].body[0].body[0]
    parent = get_closest_parent_of(tree, node, ast.If)
    assert isinstance(parent, ast.If)



# Generated at 2022-06-12 04:52:46.476916
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse('def func(a):\n\tb = a\n\tprint(b)', mode='exec')
    func = node.body[0]
    assign = func.body[0]
    name = func.body[0].value
    func_parent = get_parent(node, func, rebuild=True)

    assert func_parent == node



# Generated at 2022-06-12 04:52:47.583227
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:52:52.609036
# Unit test for function find
def test_find():
    import unittest
    import ast

    class FindTest(unittest.TestCase):
        def test_find(self):
            class_node = ast.parse('class A: pass')
            result = list(find(class_node, ast.ClassDef))
            self.assertEqual(class_node.body[0], result[0])

    unittest.main()

# Generated at 2022-06-12 04:52:55.509272
# Unit test for function find
def test_find():
    nodes = list(find(ast.parse("""
        def f():
            pass

        def g():
            pass
        """), ast.FunctionDef))
    assert len(nodes) == 2


# Generated at 2022-06-12 04:52:59.460149
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("a = 1 + 2")
    a = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, a)
    assert parent is tree.body[0]
    assert index == 0

# Generated at 2022-06-12 04:53:06.915523
# Unit test for function find
def test_find():
    # Example node
    node = ast.parse('if foo: "bar"')

    # Find all str
    types = []
    for node in find(node, ast.Str):
        types.append(type(node))
    types = set(types)
    assert types == {ast.Str}

    # Find all expr
    types = []
    for node in find(node, ast.Expr):
        types.append(type(node))
    types = set(types)
    assert types == {ast.Expr}



# Generated at 2022-06-12 04:53:14.014290
# Unit test for function replace_at
def test_replace_at():
    class_node = ast.ClassDef(name='TestClass', body=[],
                              decorator_list=[],
                              keywords=[])
    function_node = ast.FunctionDef(name='test_function', body=[],
                                    decorator_list=[],
                                    args=ast.arguments(args=[],
                                                       vararg=None,
                                                       kwonlyargs=[],
                                                       kw_defaults=[],
                                                       kwarg=None,
                                                       defaults=[]),
                                    returns=None)
    replace_at(0, class_node, function_node)
    assert(class_node.body[0] == function_node)

test_replace_at()

# Generated at 2022-06-12 04:54:11.242783
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    exp = ast.Expression(
        value=ast.BinOp(
            left=ast.Num(n=42, ctx=ast.Load()),
            op=ast.Add(),
            right=ast.Num(n=42, ctx=ast.Load())))

    # Expected body: [Name(id='foo', ctx=Store()), Name(id='bar', ctx=Load())]
    mod = ast.Module(body=[
        ast.Assign(targets=[ast.Name(id='foo', ctx=ast.Store())], value=exp),
        ast.Expr(value=ast.Name(id='bar', ctx=ast.Load()))
    ])

    parent, index = get_non_exp_parent_and_index(mod, exp)


# Generated at 2022-06-12 04:54:21.017662
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:54:28.319541
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import os
    parent_node, index = get_non_exp_parent_and_index(ast.parse('''
        def main(arr):
            isEven = lambda x: x % 2 == 0
            for i, x in enumerate(arr):
                if isEven(x):
                    continue
                return i
    '''), ast.parse('if isEven(x):').body[0].test)

    assert isinstance(parent_node, ast.FunctionDef)
    assert index == 2

# Generated at 2022-06-12 04:54:34.037564
# Unit test for function replace_at
def test_replace_at():
    module = ast.parse("""
if True:
    if True:
        pass
    if True:
        pass
if True:
    if True:
        pass
    if True:
        pass
""")
    if_parent = get_parent(module, get_parent(module, module.body[0]))
    assert if_parent.body[0].body[0].value.value
    ast.fix_missing_locations(ast.If(
        test=ast.Name(id='False'),
        body=[ast.Pass()],
        orelse=[],
        lineno=2,
        col_offset=4
    ))

# Generated at 2022-06-12 04:54:42.071393
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    parent = ast.FunctionDef(
        name='foo',
        args=ast.arguments(
            args=[ast.arg('bar', None)],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ),
        body=[ast.Expr(ast.Num(1))],
        decorator_list=[],
        returns=None,
    )
    expr_node = parent.body[0].value  # type: ignore

    assert get_non_exp_parent_and_index(parent, expr_node) == (parent, 0)

# Generated at 2022-06-12 04:54:47.477617
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    #setup
    def parse(source):
        return ast.parse(source, mode='exec')
    
    def get_non_exp_parent_and_index(tree, node):
        get_non_exp_parent_and_index(tree, node)

    with pytest.raises(NodeNotFound):
        get_non_exp_parent_and_index(parse('f()'), ast.Name)

    with pytest.raises(NodeNotFound):
        get_non_exp_parent_and_index(parse('f()'), ast.Num)

    with pytest.raises(NodeNotFound):
        get_non_exp_parent_and_index(parse('f()'), ast.Call)


# Generated at 2022-06-12 04:54:56.554837
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..utils import get_ast
    from .transforms.var_expand import VarExpand
    from .transforms.decorator import Decorator
    from .transforms.decorated_def import DecoratedDef
    from .transforms.print_expand import PrintExpand

    module = get_ast('test_data/test')
    print_expand = PrintExpand()
    print_expand.visit(module)
    decorator_expand = Decorator()
    decorator_expand.visit(module)

    def_ = find(module, DecoratedDef)[0]
    func = def_.node.body[0]
    var_expand = VarExpand()
    var_expand2 = VarExpand()
    var_expand.visit(func)
    var_exp

# Generated at 2022-06-12 04:55:04.630997
# Unit test for function replace_at
def test_replace_at():
    mod = ast.parse('class A: def f(self): pass')
    c1 = ast.ClassDef(name='Class1', body=[ast.Pass()])
    c2 = ast.ClassDef(name='Class2', body=[ast.Pass()])
    f1 = ast.FunctionDef(name='f', body=[ast.Pass()])
    f2 = ast.FunctionDef(name='f', body=[ast.Pass()])

    for parent in find(mod, ast.Module):
        replace_at(0, parent, [c1, c2])
        replace_at(0, parent, [c1, f1])
        replace_at(0, parent, [f2])

    expected = ast.parse('class Class1:\n    pass\nclass Class2:\n    pass')

# Generated at 2022-06-12 04:55:08.569854
# Unit test for function find
def test_find():
    assert list(find(ast.parse('a = 5'), ast.Assign)) == \
        [ast.parse('a = 5').body[0]]
    assert list(find(ast.parse('a = b'), ast.Name)) == \
        [ast.parse('a = b').body[0].targets[0].id,
         ast.parse('a = b').body[0].value]

# Generated at 2022-06-12 04:55:17.293392
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent"""
    one = ast.Num(1)
    two = ast.Num(2)
    add = ast.BinOp(one, ast.Add(), two)
    list_ = ast.List([one, two], ast.Load())
    call = ast.Call(list_, [add], [])

    assert get_parent(call, add) is call
    assert get_parent(call, one) is add
    assert get_parent(call, two) is add
    assert get_parent(call, list_) is call

    with pytest.raises(NodeNotFound):
        get_parent(call, ast.Num(3))

    with pytest.raises(NodeNotFound):
        get_parent(add, call)

