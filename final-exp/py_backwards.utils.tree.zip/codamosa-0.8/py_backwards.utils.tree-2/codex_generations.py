

# Generated at 2022-06-12 04:47:33.070941
# Unit test for function find
def test_find():
    # Simple Find
    # ------------
    c = ast.parse('a + b').body[0].value

    assert list(find(c, ast.BinOp)) == [c]

    # Referenced Expression Find
    # --------------------------
    c = ast.parse('a + b + c').body[0].value

    assert list(find(c, ast.BinOp)) == [c.left, c]

    # Nested Find
    # -----------
    c = ast.parse('a + (b+c)').body[0].value

    assert list(find(c, ast.BinOp)) == [c.left, c.right]

    # Nested Find with filter
    # -----------------------
    c = ast.parse('a + (b+c)').body[0].value


# Generated at 2022-06-12 04:47:34.543106
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor

# Generated at 2022-06-12 04:47:39.427237
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('a = [1, 2, 3]'), ast.List))) == 1
    assert len(list(find(ast.parse('a'), ast.List))) == 0
    assert len(list(find(ast.parse('a = [1, 2, 3]'), ast.Name))) == 1



# Generated at 2022-06-12 04:47:40.459419
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:47:49.165469
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import ast_to_source
    from .type_refs import name_node_refs
    from ..types import TypeVar as TypeVarType
    from ..types import Union as UnionType
    #import astor

    program = """
    def f(a: int, b: int) -> str:
        with open('file1', 'r') as f1:
            pass
    """
    tree = ast.parse(program)
    # print(astor.to_source(tree))
    name_node_refs(tree)
    type_var = get_closest_parent_of(tree, TypeVarType('a'),
                                     ast.FunctionDef)
    assert type_var.argnames[0] == 'a'

# Generated at 2022-06-12 04:47:52.771395
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    x = ast.Name('name', ast.Load())
    mod = ast.Module([
        ast.Assign([x], ast.Num(3)),
        ast.FunctionDef('func', ast.arguments([], None, None, []),
                        [ast.Pass()], [])
    ])
    assert get_closest_parent_of(mod, x, ast.Module) == mod



# Generated at 2022-06-12 04:47:55.444452
# Unit test for function find
def test_find():
    tree = ast.parse('def foo(): return 1')

    for node in find(tree, ast.arguments):
        assert isinstance(node, ast.arguments)



# Generated at 2022-06-12 04:47:59.436816
# Unit test for function find
def test_find():
    import astunparse

    tree = ast.parse('''
x = 1
y = 2
z = 3
''')
    found = find(tree, ast.Assign)

    assert len(found) == 3

    foobar = next(found)
    assert astunparse.unparse(foobar).strip() == 'x = 1'

    foobar = next(found)
    assert astunparse.unparse(foobar).strip() == 'y = 2'

    foobar = next(found)
    assert astunparse.unparse(foobar).strip() == 'z = 3'

# Generated at 2022-06-12 04:48:08.356286
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test for function get_non_exp_parent_and_index"""
    tree = ast.parse('1 + 2\n2 + 3')
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body, list)
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.BinOp)
    assert isinstance(tree.body[1], ast.BinOp)

    2 + 3
    assert isinstance(get_non_exp_parent_and_index(tree, tree.body[1][1]), tuple)

# Generated at 2022-06-12 04:48:14.541321
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('for y in [0, 2]:\n b = 1 + 2\n b = 1 + 3')
    b = ast.parse('b = 1 + 2').body[0]
    closest_parent = get_closest_parent_of(tree, b, ast.FunctionDef)
    assert closest_parent is None
    closest_parent = get_closest_parent_of(tree, b, ast.For)
    assert isinstance(closest_parent, ast.For)

# Generated at 2022-06-12 04:48:25.466837
# Unit test for function find
def test_find():
    from .function_parse import parse_function_ast
    from .module_parse import parse_module_ast

    # Function test
    fn = '''
    def foo():
        x = 1
        x = 2
    '''

    tree = parse_function_ast(fn)
    assign_nodes = list(find(tree, ast.Assign))
    assert len(assign_nodes) == 2

    # Module test
    module = '''
    x = 1
    x = 2
    '''

    tree = parse_module_ast(module)
    assign_nodes = list(find(tree, ast.Assign))
    assert len(assign_nodes) == 2



# Generated at 2022-06-12 04:48:28.423074
# Unit test for function replace_at
def test_replace_at():
    class Parent(ast.AST):
        _fields = ('body',)
        body = None

    class Child(ast.AST):
        _fields = ()

    class Child2(ast.AST):
        _fields = ()

    parent = Parent()
    parent.body = [Child()]

    replace_at(0, parent, Child2())

    assert isinstance(parent.body[0], Child2)

# Generated at 2022-06-12 04:48:29.289418
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as ast

# Generated at 2022-06-12 04:48:37.467927
# Unit test for function get_parent
def test_get_parent():
    # Define tree
    tree = ast.parse('a = [1, 2, 3]')
    tree.body[0].value.elts[0].n = 1
    tree.body[0].value.elts[1].n = 2
    tree.body[0].value.elts[2].n = 3
    # Check if function works
    assert get_parent(tree, tree.body[0].value.elts[2]).elts[2].n == 3
    assert get_parent(tree, tree.body[0].value.elts[2]).elts[1].n == 2
    assert get_parent(tree, tree.body[0].value.elts[2]).elts[0].n == 1
    assert get_parent(tree, tree.body[0].value.elts[2]).ctx.__

# Generated at 2022-06-12 04:48:39.318292
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:44.820005
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_str = """
[1, 2, 3, 4, 5]
    """
    test_ast = ast.parse(test_str)
    node = test_ast.body[0].value.elts[2]
    desired_parent = test_ast.body[0].value
    assert desired_parent is get_closest_parent_of(test_ast, node, ast.List)

# Generated at 2022-06-12 04:48:54.641242
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from iaastools.transform.transform_tree import transform
    from iaastools.transform.transform_rule import apply_rules
    from iaastools.common.visitor import Visitor
    from iaastools.common.visitor import VisitorType

    class TestVisitor(Visitor):
        def __init__(self):
            self.visitor_type = VisitorType.RECURSIVE_COMPATIBLE

        def visit_expr(self, node: ast.Expr):
            pass

        def visit_module(self, node: ast.Module):
            return []

    visitor = TestVisitor()


# Generated at 2022-06-12 04:48:57.374069
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = b + c')
    _build_parents(tree)
    assert get_parent(tree, tree) is None



# Generated at 2022-06-12 04:48:58.269745
# Unit test for function find

# Generated at 2022-06-12 04:49:09.212223
# Unit test for function find
def test_find():
    import astunparse
    import astor
    x = astor.dump_tree(ast.parse("""
try:
    x()
except:
    x = 42
    print(x)
    pass
    raise
    pass
    print(1)
except:
    pass
finally:
    print(2)

x = 1
""").body[1])
    print(x)
    # x = ast.parse("""
    #     try:
    #         x()
    #     except:
    #         x = 42
    #         print(x)
    #         pass
    #         raise
    #         pass
    #         print(1)
    #     except:
    #         pass
    #     finally:
    #         print(2)

    #     x = 1
    # """)

# Generated at 2022-06-12 04:49:18.252539
# Unit test for function get_parent
def test_get_parent():
    import compile
    import astor
    tree = compile('a = 1\nb = 2', '<string>', 'exec', ast.PyCF_ONLY_AST, True)
    _build_parents(tree)
    a = tree.body[0]
    assert _parents[a] == tree
    print(astor.dump(tree))


if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.DEBUG)
    test_get_parent()

# Generated at 2022-06-12 04:49:20.042914
# Unit test for function find
def test_find():
    assert len(list(find('%[Print]\n', '%[Print]'))) == 1

# Generated at 2022-06-12 04:49:28.320618
# Unit test for function replace_at
def test_replace_at():
    module = ast.parse('if False:\n if True:\n  pass')
    if_ = module.body[0]
    insert_at(0, if_.body[0], ast.parse('a = 1').body[0])  # type: ignore
    assert ast.dump(module) == 'Module(body=[If(test=NameConstant(value=False), ' + \
        'body=[Try(body=[If(test=NameConstant(value=True), body=[Assign(targets=[Name' + \
        '(id=\'a\', ctx=Store())], value=Num(n=1)), Pass()], orelse=[])], excepts=[], ' + \
        'finalbody=[], orelse=[])], orelse=[])])'

# Generated at 2022-06-12 04:49:39.479775
# Unit test for function find
def test_find():
    filename = os.path.join(os.path.dirname(__file__), "testdata",
                            "test_find_fixture.py")
    with open(filename) as f:
        tree = ast.parse(f.read())

    assert len(list(find(tree, ast.Module))) == 1
    assert len(list(find(tree, ast.Import))) == 1
    assert len(list(find(tree, ast.ImportFrom))) == 1
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.AsyncFunctionDef))) == 0
    assert len(list(find(tree, ast.ClassDef))) == 1
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.Assign)))

# Generated at 2022-06-12 04:49:41.388049
# Unit test for function find
def test_find():
    tree = ast.parse('1 + 2')
    assert set(find(tree, ast.Expr)) == set(tree.body)

# Generated at 2022-06-12 04:49:43.088772
# Unit test for function find
def test_find():
    tree = ast.parse('''
    def foo(a: int, b: str) -> int:
        return a
    ''')
    print(list(find(tree, ast.FunctionDef)))

# Generated at 2022-06-12 04:49:46.738326
# Unit test for function replace_at
def test_replace_at():
    import astor
    from toolz import curry
    from ...utils import replace_at, add_last_function_to_class, remove_decorators
    from ...converters import ast_to_str, str_to_ast


# Generated at 2022-06-12 04:49:47.257554
# Unit test for function get_parent
def test_get_parent():
    pass


# Generated at 2022-06-12 04:49:55.530438
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node1 = ast.arg(arg='a', annotation=None)
    node2 = ast.arg(arg='b', annotation=None)
    node3 = ast.arg(arg='c', annotation=None)
    parent = ast.FunctionDef(name='test',
                             args=ast.arguments(args=[],
                                                kwonlyargs=[node1, node2, node3],
                                                kw_defaults=[],
                                                defaults=[]),
                             body=[], decorator_list=[],
                             returns=None)

    assert get_non_exp_parent_and_index(parent, node1) == (parent, 0)
    assert get_non_exp_parent_and_index(parent, node2) == (parent, 1)

# Generated at 2022-06-12 04:50:00.078056
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n\treturn\n\tpass')
    node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert 0 == index


# Generated at 2022-06-12 04:50:10.826384
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert len(list(find(tree, int))) == 1
    assert list(find(tree, int))[0].n == 1
    assert len(list(find(tree, ast.Assign))) == 1



# Generated at 2022-06-12 04:50:11.787120
# Unit test for function get_parent

# Generated at 2022-06-12 04:50:12.528691
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:50:20.648726
# Unit test for function get_parent
def test_get_parent():
    """Test get parent function."""
    import unittest
    from test_ast_builder import build_ast

    class GetParentTestCase(unittest.TestCase):
        """Test get parent function."""

        def _run_test(self, file_name, excepted_class, excepted_lineno,
                      excepted_col_offset):
            """Run a test."""
            tree = build_ast(file_name)

            node = list(find(tree, ast.FunctionDef))[0]
# pylint: disable=no-member
            parent = get_parent(tree, node)
            self.assertEqual(parent.__class__, excepted_class)
            self.assertEqual(parent.lineno, excepted_lineno)

# Generated at 2022-06-12 04:50:21.620316
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:50:23.014901
# Unit test for function replace_at

# Generated at 2022-06-12 04:50:25.605621
# Unit test for function find
def test_find():
    a = [x for x in find(ast.parse('1+1'), ast.Num)]
    assert a == [ast.parse('1+1').body[0].value]

# Generated at 2022-06-12 04:50:30.526685
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def identity(x: int) -> int:
        return x

    def func(x: int) -> int:
        return identity(x)

    tree = ast.parse(textwrap.dedent(inspect.getsource(func)))
    index = tree.body[0].body[0].value.body[0].value.value
    parent = get_non_exp_parent_and_index(tree, index)[0]

    assert parent == tree

# Generated at 2022-06-12 04:50:31.312306
# Unit test for function get_parent

# Generated at 2022-06-12 04:50:34.910832
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor as ast

    def f1(x: int) -> int:
        if x < 0:
            return -x
        else:
            return x

    f1_ast = astor.code_to_ast(f1)
    if_node = get_closest_parent_of(f1_ast, f1_ast.body[0].body[0], ast.If)
    assert isinstance(if_node, ast.If), \
        "Failed to get parent of type If in function f1"



# Generated at 2022-06-12 04:50:51.307434
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('if a: b')
    node = find(tree, ast.Name).__next__()
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert parent.body[index] == node

# Generated at 2022-06-12 04:50:56.289133
# Unit test for function get_parent
def test_get_parent():
    code = """x = 3 + 2"""
    node = ast.parse(code)
    assert get_parent(node, node).body == [ast.Assign([ast.Name('x', ast.Store())],
                                           ast.BinOp(ast.Num(3), ast.Add(), ast.Num(2)))]



# Generated at 2022-06-12 04:50:59.984488
# Unit test for function find
def test_find(): # type: ignore
    def test_func():
        for i in range(1, 10):
            print(i)

    tree = ast.parse(inspect.getsource(test_func))
    print([node.s for node in find(tree, ast.Str)])

# Generated at 2022-06-12 04:51:00.788120
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:51:02.146472
# Unit test for function get_parent

# Generated at 2022-06-12 04:51:12.189503
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_tree = ast.parse('''def f():
        if True:
            print('')
    ''')

    if_node = ast_tree.body[0].body[0]
    func_node = ast_tree.body[0]

    assert(func_node == get_closest_parent_of(ast_tree, if_node, ast.FunctionDef))

    ast_tree = ast.parse('''if True:
        if False:
            print('')
    ''')

    if_node = ast_tree.body[0]
    another_if_node = ast_tree.body[0].body[0]
    assert(if_node == get_closest_parent_of(ast_tree, another_if_node, ast.If))



# Generated at 2022-06-12 04:51:17.589775
# Unit test for function find
def test_find():
    code = '''
    def test():
        print 1
        if 1:
            pass
        else:
            print 2
        pass
    '''
    comp = ast.parse(code)

    ifs = list(find(comp, ast.If))
    assert [t.test.n for t in ifs] == [1, 1]



# Generated at 2022-06-12 04:51:22.575137
# Unit test for function get_parent
def test_get_parent():
    example = ast.parse('''
    class Example:

        def hello_world(self):
            return 'Hello world!'
    ''')

    assert isinstance(get_parent(example, example.body[0], True), ast.Module)
    assert isinstance(get_parent(example, example.body[0].body[0], True),
                      ast.ClassDef)
    assert isinstance(get_parent(example, example.body[0].body[0].body[0]),
                      ast.ClassDef)

# Generated at 2022-06-12 04:51:33.298869
# Unit test for function find
def test_find():
    from ..instrumentation.dummy import dummy_function
    from ..instrumentation.ast_extension import PatchedFunctionDef

    func = dummy_function()

# Generated at 2022-06-12 04:51:37.402824
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

    module = astor.parse_file('./tests/resources/test_utils.py')
    node = list(find(module, ast.FunctionDef))[0]
    parent = get_closest_parent_of(module, node, ast.Module)

    assert parent.body[0] == node

# Generated at 2022-06-12 04:52:06.758942
# Unit test for function get_parent

# Generated at 2022-06-12 04:52:09.678833
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = ast.parse('for i in range(1):\n    pass')
    get_non_exp_parent_and_index(code, code.body[0].body[0])

# Generated at 2022-06-12 04:52:11.904231
# Unit test for function find
def test_find():
    string_val = ast.parse("""if True: pass""")
    lst = list(find(string_val, ast.If))
    assert len(lst) == 1



# Generated at 2022-06-12 04:52:13.100381
# Unit test for function find

# Generated at 2022-06-12 04:52:21.852685
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .test_node_examples import simple_function_calls
    tree = ast.parse(simple_function_calls)
    node = tree.body[0].body[0].value.args[0]
    new_node = ast.parse(simple_function_calls)
    new_node = new_node.body[0].body[0].value.args[0]
    assert id(get_closest_parent_of(tree, node, ast.Module)) == \
        id(get_closest_parent_of(tree, new_node, ast.Module))
    assert Tree(tree).is_equal(Tree(new_node))

# Generated at 2022-06-12 04:52:24.729486
# Unit test for function get_parent
def test_get_parent():
    def test_doc():
        """This is a test docstring."""
        print('Testing')

    parent = get_parent(test_doc, test_doc.__doc__)
    assert parent == test_doc


# Generated at 2022-06-12 04:52:28.153549
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = '''
    def f(a):
        if a == 100:
            print('100')
        else:
            print('not 100')
    '''
    tree = ast.parse(code)


if __name__ == '__main__':
    test_get_closest_parent_of()

# Generated at 2022-06-12 04:52:34.502253
# Unit test for function find
def test_find():
    a = ast.Name(id='a')
    b = ast.Name(id='b')
    c = ast.Name(id='c')
    aa = ast.Name(id='aa')
    a_name = ast.Name(id='a')

    # ast.dump(a)
    # Name(id='a')

    # ast.dump(b)
    # Name(id='b')

    # ast.dump(c)
    # Name(id='c')

    # ast.dump(aa)
    # Name(id='aa')

    # ast.dump(a_name)
    # Name(id='a')

    # ast.dump(ast.BinOp(left=a, op=ast.Add(), right=b))
    # BinOp(left=Name(id='a', ctx=Load

# Generated at 2022-06-12 04:52:43.643235
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_node = ast.parse('if x: x = 1; else: x = 2')
    ast_node.body[0].body[0].body[0].value.n = 6
    assert get_non_exp_parent_and_index(ast_node,
                                        ast_node.body[0].body[0].body[0]) == \
                                        (ast_node.body[0].body[0], 0)
    assert get_non_exp_parent_and_index(ast_node, ast_node.body[0]) == \
                                        (ast_node, 0)
    assert get_non_exp_parent_and_index(ast_node, ast_node.body[0].body[0]) == \
                                        (ast_node.body[0], 0)

# Generated at 2022-06-12 04:52:49.622222
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("def f():\n"
                     "    if True:\n"
                     "        return\n")
    node = tree.body[0].body[0]
    parent = get_parent(tree, node)
    grandparent = get_non_exp_parent_and_index(tree, parent)[0]
    assert grandparent is tree.body[0]
    assert get_non_exp_parent_and_index(tree, parent)[1] is 0

# Generated at 2022-06-12 04:54:06.997206
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    expr = ast.parse('a = 1 + 2', '', 'eval').body
    assert get_non_exp_parent_and_index(expr, expr.value) == (expr, 0)



# Generated at 2022-06-12 04:54:11.004028
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code_string = """
    def test():
        for i in range(10):
            print(i)
        class C:
            def __init__(self):
                self.name = 'Hello'
            def test(self):
                self.name = 'World'
    """
    ast_tree = ast.parse(code_string)
    print(ast_tree)
    print(get_closest_parent_of(ast_tree, ast_tree.body[0].body[0].body[0], ast.FunctionDef))

# Generated at 2022-06-12 04:54:19.182805
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Dict(keys=[], values=[])
    dict_comp = ast.DictComp(
        key=ast.Name(id="z", ctx=ast.Load()),
        value=ast.Name(id="z", ctx=ast.Load()),
        generators=[]
    )
    parent = ast.Expression(body=dict_comp)
    _parents[node] = parent
    _parents[dict_comp] = parent

    non_exp_parent, index = get_non_exp_parent_and_index(node, node)
    assert non_exp_parent == parent
    assert index == 0


# Generated at 2022-06-12 04:54:20.713492
# Unit test for function get_parent
def test_get_parent():
    code = '''
    def hello():
        pass
    '''

    tree = ast.parse(code)
    parent = tree.body[0].body[0]

    assert get_parent(tree, parent) == tree.body[0]



# Generated at 2022-06-12 04:54:23.163005
# Unit test for function find
def test_find():
    funcdef = \
        ast.parse("""
        def foo():
            pass
        """).body[0]

    print(list(find(funcdef, ast.Pass)))


# Generated at 2022-06-12 04:54:31.430200
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert (str(get_closest_parent_of(ast.parse("""def my_func(a, b):
    pass"""), ast.parse("""def my_func(a, b):
    pass""").body[0].args.args[0], ast.FunctionDef)) ==
            "FunctionDef(name='my_func', args=arguments(args=[Name(id='a', ctx=Param()), Name(id='b', ctx=Param())], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)")

# Generated at 2022-06-12 04:54:36.209405
# Unit test for function replace_at
def test_replace_at():
    def func():
        pass

    ast_dumper_before = ast.dump(func)

    def replacement():
        pass

    replace_at(0, func, replacement)
    ast_dumper_after = ast.dump(func)

    assert ast_dumper_before != ast_dumper_after

# Generated at 2022-06-12 04:54:44.197914
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Setup
    import ast
    import astor
    tree = ast.parse("""
    if True:
        pass
    """)
    new_tree = ast.parse("""
    if True:
        pass
    elif False:
        pass
    """)
    new_body = get_non_exp_parent_and_index(new_tree, new_tree.body[0])[0].body

    # Test
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert parent == tree
    assert index == 0

    # Test
    new_body.insert(index, node)
    new_tree = ast.parse(astor.to_source(new_tree))


# Generated at 2022-06-12 04:54:44.969852
# Unit test for function find

# Generated at 2022-06-12 04:54:53.083923
# Unit test for function find
def test_find():

    nodes = list(find(ast.parse('a = 1 + 2 ** 3 + 4 ** (1 + 2)'), ast.BinOp))
    # [<_ast.BinOp object at 0x000002BE5D5C4438>,
    # <_ast.BinOp object at 0x000002BE5D5C44E0>,
    # <_ast.BinOp object at 0x000002BE5D5C4588>]

    assert isinstance(nodes[0], ast.BinOp)
    assert isinstance(nodes[1], ast.BinOp)
    assert isinstance(nodes[2], ast.BinOp)

