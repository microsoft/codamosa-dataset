

# Generated at 2022-06-12 04:47:26.970560
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-12 04:47:30.990856
# Unit test for function find
def test_find():
    node = ast.parse("a + b + c")
    b_nodes = list(find(node, ast.BinOp))
    d_nodes = list(find(node, ast.Dict))

    assert len(b_nodes) == 2
    assert len(d_nodes) == 0



# Generated at 2022-06-12 04:47:37.607756
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = """
        function a(x) {
            return (x + 1) / 2;
        }
    """

    tree = ast.parse(source)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.Name), ast.Name)
    print('test_get_closest_parent_of: OK')



# Generated at 2022-06-12 04:47:45.374855
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse('if True: pass')
    parent, _ = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    insert_at(1, parent, ast.parse('x = 2'))

    assert ast.dump(tree) == 'Module(body=[If(test=NameConstant(value=True), '\
        + 'body=[Pass(), Expr(value=Assign(targets=[Name(id="x", ctx=Store())], '\
        + 'value=Constant(value=2)))], orelse=[])])'



# Generated at 2022-06-12 04:47:54.059662
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('''
a = 1
a = 2
a = 3
a = 4
''')

    # Replace a=2 with a=5
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1])
    replace_at(index, parent, ast.parse('a = 5'))


# Generated at 2022-06-12 04:47:55.356597
# Unit test for function find
def test_find():
    from ..utils.tests import assert_equals


# Generated at 2022-06-12 04:48:06.660299
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from astor import to_source
    from ..ast_utils import condense_condition

    # Assert that get_non_exp_parent_and_index works for a simple case
    fun_def = ast.parse('def fun():\n    if a: pass').body[0]
    elif_index = 1
    elif_ = fun_def.body[elif_index]
    condense_condition(fun_def, elif_index)

    assert to_source(get_non_exp_parent_and_index(fun_def, elif_)[0]) \
        == to_source(fun_def)
    assert get_non_exp_parent_and_index(fun_def, elif_)[1] == elif_index

# Generated at 2022-06-12 04:48:10.785986
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 2 + 3')
    node = tree.body[0].value.right
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert type(parent) == ast.Module and parent.body == tree.body



# Generated at 2022-06-12 04:48:15.618899
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
        import test
        if True:
            test.test(test)
    """)

    try:
        get_parent(tree, ast.parse("test.test()"))
    except NodeNotFound:
        pass

    get_parent(tree, ast.Name("test"))
    get_parent(tree, ast.Module)


# Generated at 2022-06-12 04:48:16.848421
# Unit test for function find

# Generated at 2022-06-12 04:48:23.024939
# Unit test for function find
def test_find():
    import astor
    a = astor.parse_file('../examples/no_extra_space.py')
    b = find(a, ast.FunctionDef)
    assert len(list(b)) > 0

# Generated at 2022-06-12 04:48:33.792771
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    dummy_node1 = ast.Call()
    dummy_node2 = ast.Call()
    dummy_node3 = ast.Call()
    dummy_node = ast.Expression(dummy_node1)
    dummy_node4 = ast.Expression(dummy_node2)
    dummy_node5 = ast.Expression(dummy_node3)
    dummy_node6 = ast.Module(dummy_node4)
    dummy_node7 = ast.Module(dummy_node5)

    dummy_node_test1 = ast.Module(dummy_node)
    dummy_node_test2 = ast.Module(dummy_node6)
    dummy_node_test3 = ast.Module(dummy_node7)

    _build_parents(dummy_node_test1)

# Generated at 2022-06-12 04:48:36.560552
# Unit test for function find
def test_find():
    """Test function find."""
    tree = ast.parse('''
      def foo(arg):
        pass
      def bar():
        pass
    ''')

    found = find(tree, ast.FunctionDef)
    assert len(list(found)) == 2

# Generated at 2022-06-12 04:48:39.093081
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astunparse

# Generated at 2022-06-12 04:48:47.316323
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    #   def a():
    #       with b():
    #           c()
    tree = ast.parse('''
        def a():
            with b():
                c()
    ''')

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.With), ast.With)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.Module), ast.Module)



# Generated at 2022-06-12 04:48:48.288803
# Unit test for function insert_at

# Generated at 2022-06-12 04:48:49.473746
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:59.439989
# Unit test for function find
def test_find():
    from ..pycst import *
    from .test_ast import ast_test_tree

    def finder(type_: Type[T]) -> Iterable[T]:
        return find(ast_test_tree, type_)

    def test_find_for_type(type_: Type[T], count: int):
        assert len(list(finder(type_))) == count

    # Test find of some statements
    test_find_for_type(IfStmt, 2)
    test_find_for_type(ForStmt, 1)
    test_find_for_type(AssignStmt, 3)
    test_find_for_type(BinaryOperation, 1)
    test_find_for_type(UnaryOperation, 1)


# Generated at 2022-06-12 04:49:09.817093
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo(x):
        if x > 0:
            if x > 1:
                if x > 2:
                    return x
        return 0
    """)

    non_exp_parent = get_non_exp_parent_and_index(tree, tree.body[0].body[2])
    assert isinstance(non_exp_parent[0], ast.If)
    assert non_exp_parent[1] == 2

    non_exp_parent = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(non_exp_parent[0], ast.FunctionDef)
    assert non_exp_parent[1] == 0


# Generated at 2022-06-12 04:49:13.477140
# Unit test for function get_parent
def test_get_parent():
    string = "a = 1"
    tree = ast.parse(string)
    temp = tree.body[1]
    assert id(get_parent(tree,temp)) == id(tree)
    assert id(get_parent(tree,temp).body[0]) == id(temp)

# Generated at 2022-06-12 04:49:28.161849
# Unit test for function find
def test_find():
    """Test find function."""
    import ast
    import astunparse
    import re
    import sys
    import types

    python3_ast = types.ModuleType('ast')
    python3_ast.__file__ = './ast/__init__.py'
    sys.modules['ast'] = python3_ast

    with open('./astunparse/unparser.py') as f:
        tree = ast.parse(f.read())

    # Search for all nodes with type 'FunctionDef'
    fdef_nodes = list(find(tree, ast.FunctionDef))
    # Make sure list is not empty
    assert fdef_nodes != []

    # Unparse every 'FunctionDef' node found
    for node in fdef_nodes:
        fdef_string = astunparse.unparse(node)



# Generated at 2022-06-12 04:49:29.263050
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:49:34.726040
# Unit test for function find
def test_find():
    """Unit test for function find."""
    code_str = 'def hello(a: int, b: str) -> int: return'
    root = ast.parse(code_str)
    funcs = find(root, ast.FunctionDef)
    assert len(funcs) == 1
    assert funcs[0].name == 'hello'


# Generated at 2022-06-12 04:49:38.260229
# Unit test for function find
def test_find():
    tree = ast.parse('a := 1; b := 2; c := 3; d := 4;')
    assert len(list(find(tree, ast.Assign))) == 4
    assert len(list(find(tree, ast.Name))) == 4

# Generated at 2022-06-12 04:49:40.476027
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    assert [n.id for n in find(tree, ast.Name)] == ['a']


# Generated at 2022-06-12 04:49:41.374083
# Unit test for function find

# Generated at 2022-06-12 04:49:50.754164
# Unit test for function get_parent
def test_get_parent():
    return
    # import ast as ast3
    # tree = ast3.parse("def func():\n    var = 3\n    var += 4")
    # var_node = tree.body[0].body[1].targets[0]
    # while var_node:
    #     p = get_parent(tree, var_node)
    #     if p:
    #         print(var_node, p)
    #         var_node = p
    #     else:
    #         break
    # tree = ast3.parse("def func():\n    var = 3\n    var += 4")
    # var_node = tree.body[0].body[1].targets[0]
    # assert get_parent(tree, var_node) == tree.body[0].body[1], \
   

# Generated at 2022-06-12 04:49:56.714561
# Unit test for function find
def test_find():
    import builtins
    import astor
    import os
    """test function"""

    file_name = os.path.join(os.path.dirname(__file__),
                             '../../test/examples/example1.py')
    with open(file_name, 'r') as file:
        source = file.read()
    module = astor.code_to_ast.parse_file(file_name)
    _build_parents(module)
    nodes = [node for node in find(module, ast.Name)]
    assert len(nodes) == 9
    for node in nodes:
        assert node.id == 'print'



# Generated at 2022-06-12 04:49:57.680045
# Unit test for function find

# Generated at 2022-06-12 04:50:01.273827
# Unit test for function get_parent
def test_get_parent():
    import unittest
    import sys

    class TestGetParent(unittest.TestCase):
        """
        test get_parent function.
        """

        def test_get_parent(self):
            """test get_parent function.
            """
            # run test

# Generated at 2022-06-12 04:50:09.639492
# Unit test for function find
def test_find():
    from typed_ast.ast3 import parse

# Generated at 2022-06-12 04:50:10.241636
# Unit test for function find

# Generated at 2022-06-12 04:50:19.655105
# Unit test for function find
def test_find():
    # Test for Expression
    expr = ast.parse('foo').body[0]
    assert find(expr, ast.Name) == [expr]

    # Test for FunctionDef
    func_def = ast.parse('def func(): pass').body[0]
    assert func_def.name == 'func'
    assert find(func_def, ast.Name) == [func_def.name]
    assert find(func_def, ast.FunctionDef) == [func_def]
    assert find(func_def, ast.Module) == []

    # Test for Module
    code = '''
    def func(): pass
    x = 1
    '''
    module = ast.parse(code)
    
    # Check for AST Nodes that are hidden in the AST

# Generated at 2022-06-12 04:50:26.499840
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def f():
        return 1
    """)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)
    assert isinstance(get_parent(tree, tree.body[0].body[0].value), ast.Return)
    assert isinstance(get_parent(tree, get_parent(tree, tree.body[0].body[0])),
                      ast.Module)



# Generated at 2022-06-12 04:50:30.271834
# Unit test for function find
def test_find():
    source_code = """
    class Test(object):
        def func(self):
            pass

    b = Test()
    b.func()
    """
    tree = ast.parse(source_code)
    found = list(find(tree, ast.Call))
    assert len(found) == 1
    assert found[0].func.id == 'func'


# Generated at 2022-06-12 04:50:38.237833
# Unit test for function get_parent
def test_get_parent():
    import astor                  # type: ignore
    module = astor.parse_file("tests/python_files/function/function_statement.py")
    fname_node = module.body[0]
    f_args_node = fname_node.args
    param_name_node = f_args_node.args[0]
    fbody_node = fname_node.body[0]
    return_node = fbody_node.value
    var_name_node = return_node.value

    assert get_parent(module, param_name_node) is fargs_node
    assert get_parent(module, return_node) is fbody_node
    assert get_parent(module, var_name_node) is return_node


# Generated at 2022-06-12 04:50:39.593165
# Unit test for function find
def test_find():
    from . import parse_str

# Generated at 2022-06-12 04:50:45.498327
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    exp1 = ast.Expression(ast.parse("a + b").body[0].value)
    exp2 = ast.Expression(ast.parse("c + d").body[0].value)
    exp3 = ast.Expression(ast.parse("e + f").body[0].value)
    body = [exp1, exp2, exp3]
    parent = ast.Module(body)
    node = ast.BinOp(ast.parse("a").body[0].value, ast.Add(),
                     ast.parse("b").body[0].value)
    exp1.body = node
    assert get_non_exp_parent_and_index(parent, node) == (parent, 0)


# Generated at 2022-06-12 04:50:46.865739
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:50:50.928058
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = '''print(1 + 2)'''
    tree = ast.parse(code)

    expression = tree.body[0].value
    assert isinstance(expression, ast.BinOp)
    parent, index = get_non_exp_parent_and_index(tree, expression)

    assert isinstance(parent, ast.Expr)
    assert index == 0

# Generated at 2022-06-12 04:51:10.855480
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    module = ast.parse("""
    def foo():
        if a:
            return a
        return b
        """)
    a = find(module, ast.Return).__next__()
    b = get_closest_parent_of(module, a, ast.FunctionDef)
    print(astor.to_source(b))
    assert astor.to_source(b) == """
    def foo():
        if a:
            return a
        return b"""


# Generated at 2022-06-12 04:51:11.813353
# Unit test for function find

# Generated at 2022-06-12 04:51:16.063352
# Unit test for function find
def test_find():
    tree = ast.parse('def func(arg1, arg2): return arg1 + arg2')
    f = find(tree, ast.FunctionDef)
    assert next(f).name == 'func'
    assert next(f, None) is None



# Generated at 2022-06-12 04:51:22.575070
# Unit test for function get_parent
def test_get_parent():
    code = dedent("""
    def add(x, y):
        return x + y
    """)
    tree = ast.parse(code)
    node = find(tree, ast.FunctionDef).__next__()
    assert get_parent(tree, node) is tree
    assert get_parent(tree, node, True) is tree
    assert node == find(tree, ast.FunctionDef).__next__()
    _parents.clear()
    assert len(_parents) == 0
    assert get_parent(tree, node) is tree
    assert node == find(tree, ast.FunctionDef).__next__()
    assert len(_parents) == 1



# Generated at 2022-06-12 04:51:24.240042
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:51:25.676435
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:51:29.760434
# Unit test for function find
def test_find():
    """Unit test for function find."""
    tree = ast.parse('a = 1 + 1')
    nodes = find(tree, ast.BinOp)
    assert next(nodes).left.id == '1'


# Generated at 2022-06-12 04:51:33.208058
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    def a():
        def b():
            pass

    tree = ast.parse(inspect.getsource(a))
    node = ast.parse(inspect.getsource(b))

    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-12 04:51:40.599535
# Unit test for function replace_at
def test_replace_at():
    print("Unit test for function replace_at")
    func_body = [ast.Print(dest=None, values=[ast.Name(id='a', ctx=ast.Load())], nl=True), ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1))]
    func_def = ast.FunctionDef(name='f', args=ast.arguments(posonlyargs=[], args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=func_body, decorator_list=[], returns=None, type_comment=None)

# Generated at 2022-06-12 04:51:41.608698
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert True



# Generated at 2022-06-12 04:52:04.862794
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent."""
    assert ast.parse("(a or b) and c").body[0].body[0] == get_parent(
        ast.parse("(a or b) and c"), ast.parse("(a or b) and c").body[0].body[0].value)
    assert get_parent(ast.parse("(a or b) and c"), ast.parse("(a or b) and c").body[0].body[0].value) == ast.parse("(a or b) and c").body[0]
    assert get_parent(ast.parse("(a or b) and c"),
     ast.parse("(a or b) and c").body[0].body[0].value.left) == ast.parse("(a or b) and c").body[0].body[0]

# Generated at 2022-06-12 04:52:10.752135
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import typed_ast.ast3 as ast
    tree = ast.parse('''
    if x:
        a = b
        c = d
        if y:
            e = f
            g = h
    ''')

    closest_if = get_closest_parent_of(tree, tree.body[0].body[0].body[1], ast.If)
    assert isinstance(closest_if, ast.If)



# Generated at 2022-06-12 04:52:21.577834
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    function_def = ast.Module(
        body=[ast.FunctionDef(
            name='',
            args=ast.arguments(
                args=[],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]),
            body=[ast.Return(value=ast.Num(n=1))],
            decorator_list=[],
            returns=None)]
    )
    _build_parents(function_def)  # Populate the tree


# Generated at 2022-06-12 04:52:25.292045
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""class Class:
                        def a(self):
                            1 + 2""")
    node = tree.body[0].body[0].body[0].value.right
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef) and index == 0

# Generated at 2022-06-12 04:52:32.692110
# Unit test for function replace_at
def test_replace_at():
    import astor
    
    tree = ast.parse("a = 1")
    replacement = ast.parse("b = 1; a = 2")

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])  # type: ignore
    replace_at(index, parent, replacement)

    print(astor.to_source(tree))
    expected = '\n'.join([
        'def foo():',
        '    a = 1',
        '    b = 1',
        '    a = 2',
        '    return a',
        ''
    ])
    assert expected == astor.to_source(tree)

# Generated at 2022-06-12 04:52:37.077725
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """
    def foo():
        print(3)
    """
    tree = ast.parse(code)
    print_node = find(tree, ast.Print).__next__()
    assert isinstance(get_closest_parent_of(tree, print_node, ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-12 04:52:40.276513
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
a = 3
a = 1
b = 2
a = 4
""")

    print(get_non_exp_parent_and_index(tree, get_parent(tree, tree.body[1])))


# Generated at 2022-06-12 04:52:45.862487
# Unit test for function replace_at
def test_replace_at():
    astree = ast.parse('a = 2; b = 1')
    replace_at(0, astree.body, ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                        value=ast.Num(n=1)))

# Generated at 2022-06-12 04:52:55.901756
# Unit test for function get_parent
def test_get_parent():
    import astor
    import sys
    import os
    import contextlib

    # suppress stdout
    @contextlib.contextmanager
    def suppress_stdout():
        with open(os.devnull, "w") as devnull:
            old_stdout = sys.stdout
            sys.stdout = devnull
            try:
                yield
            finally:
                sys.stdout = old_stdout

    # get list of directories of models
    path = os.path.join('..', 'models')
    dirs = []
    for (dirpath, dirnames, filenames) in os.walk(path):
        dirs.extend(dirnames)
        break
    # (dirpath, dirnames, filenames) = os.walk(path).__next__()

# Generated at 2022-06-12 04:52:57.521221
# Unit test for function get_parent
def test_get_parent():
    import sys
    import astor

# Generated at 2022-06-12 04:53:32.550831
# Unit test for function replace_at
def test_replace_at():
    pass


# Generated at 2022-06-12 04:53:39.819666
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test get_non_exp_parent_and_index function."""
    assert get_non_exp_parent_and_index(ast.parse(
        '''a = 1
           b = 2'''
    ).body, ast.parse('1').body[0]) == (ast.parse(
        '''a = 1
           b = 2'''
    ), 0)

    assert get_non_exp_parent_and_index(ast.parse(
        '''a = 1
           b = 2'''
    ).body, ast.parse('1').body[0]) == (ast.parse(
        '''a = 1
           b = 2'''
    ), 0)


# Generated at 2022-06-12 04:53:46.174317
# Unit test for function get_parent
def test_get_parent():
    import astor
    from ..utils.unit_test import TestCase

    class TestGetParent(TestCase):
        def test_get_parent(self):
            source = """
            foo(a, b)
            """
            tree = astor.parse_file(self.get_test_file(source))

            expected_parent = tree.body[0]
            actual_parent = get_parent(tree, tree.body[0].value)

            self.assertEqual(expected_parent, actual_parent)

    TestGetParent().run()


# Generated at 2022-06-12 04:53:53.679093
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class_ = ast.ClassDef(name='MyClass', bases=[], keywords=[],
                          starargs=None, kwargs=None, body=[], decorator_list=[])
    assign = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                        value=ast.Name(id='y', ctx=ast.Load()))
    class_.body.append(assign)

    parent, index = get_non_exp_parent_and_index(class_, assign)
    assert parent == class_
    assert index == 0

# Generated at 2022-06-12 04:54:00.186059
# Unit test for function get_parent
def test_get_parent():
    test_module = ast.parse("""
        import pdb
        import a.b as c.d
        from modulea.moduleb import modulec
        x = 1
        y = x + 2
        z = x + c
    """)
    _build_parents(test_module)
    assert repr(get_parent(test_module, test_module.body[0])) == 'Import(names=[alias(name=pdb, asname=None)])'
    assert repr(get_parent(test_module, test_module.body[1])) == 'Import(names=[alias(name=a.b, asname=c.d), alias(name=modulea.moduleb.modulec, asname=None)])'



# Generated at 2022-06-12 04:54:01.828110
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\n')
    assert len(list(find(tree, ast.Name))) == 1

# Generated at 2022-06-12 04:54:07.615268
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_tree = ast.parse("if True: pass")
    node = find(ast_tree, ast.If).__next__()
    result = get_non_exp_parent_and_index(ast_tree, node)
    assert(isinstance(result[0], ast.Module)) #type: ignore
    assert(result[1] == 0)


# Generated at 2022-06-12 04:54:14.652843
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = 'a = 1 + 1'
    tree = ast.parse(code)
    node = find(tree, ast.Add).__next__()
    module = get_closest_parent_of(tree, node, ast.Module)
    assert isinstance(module, ast.Module)
    # Test if returned parent node is not a part of the node, so it should
    # be a parent.
    assert module.body[0] is not node



# Generated at 2022-06-12 04:54:23.168973
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astunparse
    from h2xs.ast import TypeParser, TypeResolver
    from h2xs.ast import Cmp

    def test(stmt: str) -> None:
        tree = ast.parse(stmt)
        cmp_class = find(tree, ast.ClassDef).__next__()
        cmp_class.name = 'Cmp'
        cmp_class.bases = [ast.Name('object', ast.Load())]
        tree = ast.fix_missing_locations(tree)

        cmp_instance = ast.Call(
            func=ast.Name(id='Cmp', ctx=ast.Load()),
            args=[],
            keywords=[],
            starargs=None,
            kwargs=None)


# Generated at 2022-06-12 04:54:27.581274
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
    def foo():
        1+1
    """)
    print("get_parent test: ", get_parent(tree, tree.body[0]).name)


# Generated at 2022-06-12 04:55:47.186265
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:55:53.519292
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function ast_utils.get_parent"""
    test_1 = ast.parse("""
    if True:
        pass
    """, mode='exec')
    parent_1 = get_parent(test_1, test_1.body[0].body[0])
    assert isinstance(parent_1, ast.If)

    test_2 = ast.parse("""
    for i in range(1):
        pass
    """, mode='exec')
    parent_2 = get_parent(test_2, test_2.body[0].body[0])
    assert isinstance(parent_2, ast.For)



# Generated at 2022-06-12 04:56:02.595462
# Unit test for function find
def test_find():
    tree = ast.parse('a, b, c')
    elems = find(tree, ast.Tuple)
    assert len(list(elems)) == 1
    tree = ast.parse('(a, b, c)')
    elems = find(tree, ast.Tuple)
    assert len(list(elems)) == 2
    tree = ast.parse('a, b, c')
    elems = find(tree, ast.Name)
    assert len(list(elems)) == 3
    tree = ast.parse('a and b')
    elems = find(tree, ast.BoolOp)
    assert len(list(elems)) == 1
    tree = ast.parse('a < b')
    elems = find(tree, ast.Compare)
    assert len(list(elems)) == 1

#

# Generated at 2022-06-12 04:56:10.941121
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import os
    import sys

    sys.path.append('.')
    sys.path.append('..')

    from ..instrumentation import Instrumentor
    from ..instrumentation import instrument_file

    f = os.path.join(
        os.path.dirname(__file__),
        '..', 'instrumentation', 'instrumentation.py')

    ast = instrument_file(f, Instrumentor())

    func = ast.body[0]
    assert func.name == '__init__'
    body = get_closest_parent_of(ast, ast, ast.FunctionDef)
    assert body == func

    parent = get_closest_parent_of(ast, func, ast.Module)
    assert parent == ast


# Generated at 2022-06-12 04:56:16.287891
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        "def foo(x):\n    for c in x:\n        print(c**2)\n\n    assert 1\n",
        mode='exec'
    )
    nodes = list(find(tree, ast.Assert))
    assert nodes == [ast.Assert(test=ast.Num(n=1))]
    assert get_non_exp_parent_and_index(tree, nodes[0])[1] == 2

# Generated at 2022-06-12 04:56:20.322875
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('if a == b: pass')
    node = tree.body[0].test
    type_ = ast.Compare

    parent = get_closest_parent_of(tree, node, type_)
    assert isinstance(parent, type_)

# Generated at 2022-06-12 04:56:29.289163
# Unit test for function find
def test_find():
    """Test for function find."""
    # pylint: disable=R0904
    class TestNode(ast.AST):
        """Test node class."""
        _ast3_fields = ('value', )

        def __init__(self, value: int) -> None:
            self.value = value
            super(TestNode, self).__init__()

    class TestNode2(ast.AST):
        """Test node class."""
        _ast3_fields = ('value', )

        def __init__(self, value: int) -> None:
            self.value = value
            super(TestNode2, self).__init__()

    node = TestNode(1)
    node2 = TestNode2(2)
    parent = ast.Module([ast.Expr(value=node)])

# Generated at 2022-06-12 04:56:38.081531
# Unit test for function find
def test_find():
    trees = ast.parse('''
        import time
        import time
        from time import time

        thing = 1
        from time import time
        import time.foo as bar
        import time.bar
        import time.foo as bar

        thing = 2
        from time import time
        import time.foo as bar
        import time.bar
        import time.foo as bar

        thing = 3
    ''')

    assert len(list(find(trees, ast.Import))) == 7

    # bad ast
    with pytest.raises(NodeNotFound) as exc:
        find([], ast.Import)
        assert "ast is not a tree!" in str(exc.value)

    # bad node
    with pytest.raises(NodeNotFound) as exc:
        find(trees, ast.arg)

# Generated at 2022-06-12 04:56:42.109806
# Unit test for function find
def test_find():
    assert list(find(ast.parse('a = b = c = 1'), ast.Assign)) == \
        [ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store()),
                             ast.Name(id='c', ctx=ast.Store())],
                    value=ast.Num(n=1),
                    type_comment=None),
         ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                    value=ast.Name(id='b', ctx=ast.Load()),
                    type_comment=None)]


# Generated at 2022-06-12 04:56:49.982606
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    mod = ast.parse("""
        def a():
            b()
        def b():
            pass
    """)

    parent, index = get_non_exp_parent_and_index(mod, mod.body[0])
    assert index == 1
    assert isinstance(parent, ast.Module)

    parent, index = get_non_exp_parent_and_index(mod, mod.body[1])
    assert index == 0
    assert isinstance(parent, ast.Module)

    parent, index = get_non_exp_parent_and_index(mod, mod.body[1].body[0])
    assert index == 0
    assert isinstance(parent, ast.FunctionDef)

