

# Generated at 2022-06-12 04:47:32.261960
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    tree = ast.parse("""
    import astor
    import ast
    a = 1
    """)
    a = tree.body[2]
    parent, index = get_non_exp_parent_and_index(tree, a)
    print(index)
    print(parent)
    import_index = tree.index(get_closest_parent_of(tree, a, ast.Import))
    print(import_index)

# Unit test function insert_at

# Generated at 2022-06-12 04:47:42.793400
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import ast_utils
    from . import logger
    from . import code_generators
    from . import ast_data
    from . import ast_data_types
    from . import ast_accessors
    from . import ast_manipulators
    from . import ast_fetcher
    from . import ast_compare
    from . import ast_transformer
    from . import ast_for_loop_transformer
    from . import code_processing
    from . import code_algorithms
    from . import code_scope
    from . import code_scope_analyzer
    from . import code_visualization
    from . import code_visualization_svg
    from . import code_visualization_jupyter
    from . import code_tools
    from . import code_jupyter
    from .exceptions import Parse

# Generated at 2022-06-12 04:47:43.840698
# Unit test for function get_parent

# Generated at 2022-06-12 04:47:44.683782
# Unit test for function find

# Generated at 2022-06-12 04:47:47.986196
# Unit test for function find
def test_find():
    tree = ast.parse('[x for x in range(1, 10)]')
    comprehension = find(tree, ast.comprehension).__next__()

    assert isinstance(comprehension, ast.comprehension)

# Generated at 2022-06-12 04:47:51.409251
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast
    from astor import dump_tree
    from ..type_inference.type_system import TypeSystem
    from ..context import Context
    from ..type_inference.typed_ast_utils import parse_ast


# Generated at 2022-06-12 04:47:55.073952
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = '''
    if True:
        x = 1
    '''
    tree = ast.parse(code)
    node = next(find(tree, ast.Assign))
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert(parent.body[index] == node)
    assert(isinstance(parent, ast.If))

# Generated at 2022-06-12 04:48:01.789721
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a = ast.parse('a = 1 + 2')
    b = ast.parse('b = 2 + 3')
    c = ast.parse('a = 1 + 2')
    d = ast.parse('a')
    a = get_non_exp_parent_and_index(ast.Module(body=[a, b, c]), c)
    b = get_non_exp_parent_and_index(ast.Module(body=[a, b, c]), a)
    c = get_non_exp_parent_and_index(ast.Module(body=[a, b, c]), b)
    d = get_non_exp_parent_and_index(ast.Module(body=[a, b, c]), d)


# Generated at 2022-06-12 04:48:02.775729
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:05.453195
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def foo():
        def bar():
            pass
        pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 2

    tree = ast.parse("""
    foo()
    pass
    """)
    assert len(list(find(tree, ast.FunctionDef))) == 0



# Generated at 2022-06-12 04:48:10.006450
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor

# Generated at 2022-06-12 04:48:20.657960
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import sys
    import os
    import unittest
    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..')))
    from typed_ast import ast3
    from utils import get_non_exp_parent_and_index

    class TestGetNonExpParentAndIndex(unittest.TestCase):
        def test_get_non_exp_parent_and_index(self):
            """Test case for get_non_exp_parent_and_index function."""
            code = '''
                def abc():
                    print(0)
                    print(1)
                '''
            ast_tree = ast3.parse(code)
            node_to_find = ast_tree.body[0]
           

# Generated at 2022-06-12 04:48:24.480777
# Unit test for function find
def test_find():
    code = '''def f():
    x = 5
    y = True'''
    src = ast.parse(code)
    assert len(list(find(src, ast.Name))) == 2
    assert len(list(find(src, ast.Load))) == 2
    assert len(list(find(src, ast.Store))) == 2



# Generated at 2022-06-12 04:48:29.345257
# Unit test for function find
def test_find():
    from astunparse import unparse
    source_code = open("tests/datasets/1.py").read()
    tree = ast.parse(source_code)
    for node in find(tree, ast.If):
        print(unparse(node))



# Generated at 2022-06-12 04:48:30.014484
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:39.043740
# Unit test for function find
def test_find():
    from typed_ast import annotatedast as ast
    from typed_ast import ast27 as ast
    from ..common import get_env
    from ..transformer import Transformer
    from ..common import get_transformation_file_name

    _modules, _module, _func = get_env()
    file_name = get_transformation_file_name('find', 'test_find')

    transformer = Transformer(file_name)
    transformer.transform(_module)

    assert len(list(find(_module, ast.FunctionDef))) == 3
    assert len(list(find(_module, ast.For))) == 1
    assert len(list(find(_module, ast.While))) == 1
    assert len(list(find(_module, ast.Expr))) == 1
    assert len(list(find(_module, ast.Name))) == 3
   

# Generated at 2022-06-12 04:48:45.349378
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_tree = ast.parse("""
        a = 1
        if b:
            c = a
            d = 1
            if d:
                e = a
            e = 1
            if e:
                a = 1
        a == 1
        if a:
            a = 1
    """)

    assert isinstance(get_closest_parent_of(test_tree, test_tree.body[4].body[0],
                                            ast.If), ast.If)

# Generated at 2022-06-12 04:48:57.106716
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_tree = ast.parse('def decorator(func):\n\tdef wrapper():\n\t\t'
                         'return func()\n\treturn wrapper')

# Generated at 2022-06-12 04:48:58.037434
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:49:04.878151
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    class_ = ast.ClassDef(name='a', body=[], decorator_list=[])
    func = ast.FunctionDef(name='b', body=[], decorator_list=[],
                           args=ast.arguments(args=[], vararg=None,
                                              kwonlyargs=[], kw_defaults=[],
                                              kwarg=None, defaults=[]))
    class_.body = [func]
    module = ast.Module(body=[class_])

    assert astor.to_source(module) ==  ("class a:\n"
                                        "    def b() -> None:\n"
                                        "        pass")

    parent, index = get_non_exp_parent_and_index(module, func)
    assert parent is class_
    assert index == 0

# Generated at 2022-06-12 04:49:13.151785
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:49:15.848750
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('''
        def some_func():
            return True
    '''), ast.Return))) == 1

# Generated at 2022-06-12 04:49:22.158367
# Unit test for function find
def test_find():
    ast_tree = ast.parse('print(5 * 5 * 5 * 5, 5 * 5 * 5 * 4)')

    assert len(list(find(ast_tree, ast.Name))) == 2

    ast_tree = ast.parse('a = 5 * 5 * 5')

    assert list(find(ast_tree, ast.Name))[1].id == 'a'

    assert len(list(find(ast_tree.body[0].value, ast.Name))) == 0

# Generated at 2022-06-12 04:49:26.241413
# Unit test for function find
def test_find():  # pragma: no cover
    from ..lib import parse
    tree = parse('import a; def b(): print(a); b()')
    assert len(list(find(tree, ast.Import))) == 1
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-12 04:49:27.388083
# Unit test for function get_parent

# Generated at 2022-06-12 04:49:38.445003
# Unit test for function get_parent
def test_get_parent():
    """Unit test for get_parent function."""
    from .parser import parse


# Generated at 2022-06-12 04:49:48.325335
# Unit test for function find
def test_find():
    import unittest
    import random
    from .ast_helper import parse

    class TestFind(unittest.TestCase):
        def test_find(self):
            for _ in range(100):
                n = random.randint(1, 20)
                # n = random.randint(1, 3)
                source = []
                expected = set()

                for i in range(n):
                    source.append('def f{}: pass'.format(i))
                    expected.add('f{}'.format(i))

                source = '\n'.join(source)

                tree = parse(source)
                actual = set([node.name for node in find(tree, ast.FunctionDef)])
                self.assertEqual(actual, expected)

    unittest.main()

# Generated at 2022-06-12 04:49:51.544420
# Unit test for function find

# Generated at 2022-06-12 04:49:55.310083
# Unit test for function get_parent
def test_get_parent():
    input = '''def func(a, b):\n    c = a + b\n    print (c)'''
    tree = ast.parse(input)
    exp = tree.body[0].body[0]
    actual = get_parent(tree, exp)
    ast.dump(exp)
    assert actual == tree.body[0], 'Wrong parent'

# Generated at 2022-06-12 04:50:01.306023
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor

    code = '''
        def f():
           x = 1
           return x
        '''

    expected = '''
        def f():
           x = 1
           return x
        '''

    tree = ast.parse(code)
    x_node = tree.body[0].body[0].value
    parent_function_node = get_closest_parent_of(tree, x_node, ast.FunctionDef)
    assert astor.to_source(parent_function_node) == expected

# Generated at 2022-06-12 04:50:18.339812
# Unit test for function find
def test_find():
    tree = ast.parse(textwrap.dedent(
        """\
        def foo():
            pass
    """))
    for node in find(tree, ast.FunctionDef):
        assert node.name == 'foo'

# Generated at 2022-06-12 04:50:29.270670
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # check that the function works for a variable name that appears in
    # multiple locations
    code1 = ast.parse(
        "def f(x):\n"
        "    if x == 3:\n"
        "        y = x\n"
        "    else:\n"
        "        y = 5\n"
        "    return y"
    )
    tree = code1.body[0].body
    y = tree[1].body[0].targets[0]
    assert get_non_exp_parent_and_index(code1, y) == (tree[1], 1)

    # check that the function does not work for variables that have not
    # been found yet

# Generated at 2022-06-12 04:50:34.062600
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def add(a, b):
        return a + b
    def mul(a, b):
        return a * b
    """)
    node = tree.body[1].body[0]
    closest = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert closest.name == 'mul'
    closest = get_closest_parent_of(tree, node, ast.Module)
    assert closest is tree
    assert get_closest_parent_of(tree, tree, ast.Module) is tree
    print(closest)

# Generated at 2022-06-12 04:50:34.699427
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass

# Generated at 2022-06-12 04:50:42.418226
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    program = """
    if condition:
        print('inside if')
    """
    mod = ast.parse(program)
    expr_stmt = mod.body[0]
    if_stmt = expr_stmt.test
    print_stmt = if_stmt.body[0]
    print_expr = print_stmt.value
    parent, index = get_non_exp_parent_and_index(mod, print_expr)
    assert isinstance(parent, ast.If)
    assert index == 1
    assert parent.body[1].value == print_expr


# Generated at 2022-06-12 04:50:46.556496
# Unit test for function get_parent
def test_get_parent():
    code = '''
        def foo():
            a = 1
            return a
    '''
    tree = ast.parse(code)
    a = tree.body[0].body[1].value
    assert get_parent(tree, a) == tree.body[0].body[1]


# Generated at 2022-06-12 04:50:48.213967
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    # Given

# Generated at 2022-06-12 04:50:48.986768
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-12 04:50:53.932698
# Unit test for function find
def test_find():
    src = '''
    def foo():
        bar()
        try:
            baz()
        except Exception:
            pass
    '''
    t = ast.parse(src)
    actual = find(t, ast.Try)
    assert(len(list(actual)) == 1)

    actual = find(t, ast.ExceptHandler)
    assert(len(list(actual)) == 1)

    actual = find(t, ast.FunctionDef)
    assert(len(list(actual)) == 1)


# Generated at 2022-06-12 04:50:56.797315
# Unit test for function find
def test_find():

    def check_tree(tree, type_, nodes):
        assert set(find(tree, type_)) == set(nodes)

    tree = ast.parse('boo = 1 + 2')
    check_tree(tree, ast.Name, [ast.Name(id='boo', ctx=ast.Store()),
                                ast.Name(id='None', ctx=ast.Load())])



# Generated at 2022-06-12 04:51:25.679993
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-12 04:51:33.079673
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert_eq(
        get_non_exp_parent_and_index(ast.parse('if True:\n    pass'),
                                     ast.parse('if True:\n    pass').body[0]),
        (ast.parse('if True:\n    pass'), 0))
    assert_eq(get_non_exp_parent_and_index(
        ast.parse('if True:\n    pass'),
        ast.parse('if True:\n    pass').body[0].body[0]),
        (ast.parse('if True:\n    pass').body[0], 0),
        )

# Generated at 2022-06-12 04:51:34.693384
# Unit test for function find

# Generated at 2022-06-12 04:51:35.717740
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:51:38.869368
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a = ast.parse("b = lambda x: x - 5")
    b = a.body[0]
    c = b.value
    d = c.body
    e = get_non_exp_parent_and_index(a, d)
    assert e[0] == b and e[1] == 0

# Generated at 2022-06-12 04:51:48.758425
# Unit test for function get_parent
def test_get_parent():
    test_ast = ast.parse('def foo():\n    return 1', mode='exec')
    test_ast2 = ast.parse('def foo():\n    return 1', mode='eval')
    test_ast3 = ast.parse('def foo():\n    return 1', mode='single')
    test_ast4 = ast.parse('def foo():\n    return 1', mode='exec')
    assert get_parent(test_ast, test_ast.body[0]) is test_ast
    assert get_parent(test_ast2, test_ast2.body) is test_ast2
    assert get_parent(test_ast3, test_ast3.body[0].body[0]) is test_ast3.body[
        0].body

# Generated at 2022-06-12 04:51:58.294203
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """unit test for function get_closest_parent_of"""
    tree = ast.parse("""
    import numpy as np
    a = np.array([1, 2, 3])
    b = a.mean()
    """)

    assert isinstance(get_closest_parent_of(tree, find(tree, ast.Num).__next__(), ast.Module), ast.Module)
    assert get_closest_parent_of(tree, find(tree, ast.Num).__next__(), ast.Module).body[3].value.id == 'b'
    assert get_closest_parent_of(tree, find(tree, ast.Attribute).__next__(), ast.Module).body[3].value.id == 'b'

# Generated at 2022-06-12 04:52:03.432024
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = "if True: a = 5"
    tree = ast.parse(code)
    _build_parents(tree)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert parent is tree.body[0]  # type: ignore
    assert index == 0



# Generated at 2022-06-12 04:52:11.243479
# Unit test for function find
def test_find():
    import astor
    exp1 = ast.parse("for i in range(10): print(i)")
    exp2 = ast.parse("for i in range(10): pass")
    target = next(find(exp1, ast.Print))
    parent, index = get_non_exp_parent_and_index(exp1, target)
    replace_at(index, parent, exp2.body[0])
    print(astor.to_source(exp1))
    from astpp import dump
    dump(exp1)


if __name__ == "__main__":
    test_find()

# Generated at 2022-06-12 04:52:16.456574
# Unit test for function find
def test_find():
    ast_snippet = ast.parse('def add(a, b): return a + b')
    numbers = list(find(ast_snippet, ast.Num))
    assert len(numbers) == 2
    for number in numbers:
        assert number.n == 1



# Generated at 2022-06-12 04:53:24.750679
# Unit test for function find
def test_find():
    # type: () -> None
    tree = ast.parse('print(1)')
    found = find(tree, ast.Call)

    assert next(found).func.id == 'print'



# Generated at 2022-06-12 04:53:30.910538
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1\na = 2\na = 3')
    for node in find(tree, ast.Assign):
        if node.value.n == 2:
            parent, index = get_non_exp_parent_and_index(tree, node)
            rep = ast.parse('a = 666')
            rep = rep.body[0]
            replace_at(index, parent, rep)

# Generated at 2022-06-12 04:53:37.622137
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..util.util import get_source
    from ..parser.parser import parse
    from ..exceptions import NodeNotFound

    code = '''
        def func():
            return 1
    '''
    tree = parse(get_source(code))
    node = tree.body[0].body[0].value
    assert type(get_closest_parent_of(tree, node, ast.FunctionDef)) is ast.FunctionDef

    with pytest.raises(NodeNotFound):
        get_closest_parent_of(tree, node, ast.Import)

# Generated at 2022-06-12 04:53:42.824086
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # test for a If block
    if_code = "if 1 == 2: a = 1; a = 2"
    if_code_tree = ast.parse(if_code)
    a = find(if_code_tree, ast.Assign).__next__()
    parent, index = get_non_exp_parent_and_index(if_code_tree, a)
    assert index == 0
    assert isinstance(parent, ast.If)
    # test for a FunctionDef block
    function = ast.parse("def test(): a = 1; a = 2")
    a = find(function, ast.Assign).__next__()
    print(a)
    parent, index = get_non_exp_parent_and_index(function, a)
    assert index == 0

# Generated at 2022-06-12 04:53:51.957231
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse2('def x(arg):\n  list = [arg, 2, 4]\n  x = list[1]\n')
    tree.body[0].body[0].value = ast.Num(1)
    replace_at(0, tree.body[0], ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(2)))


# Generated at 2022-06-12 04:54:00.138527
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    import astor

    class TestGetClosestParentOf(unittest.TestCase):
        def test_get_closest_parent_of(self):
            code = "def foo():\n" \
                   "   x = 1\n" \
                   "   while True:\n" \
                   "       x = 2\n" \
                   "       y = 1\n" \
                   "   return True"

            tree = ast.parse(code)

            # get closest parent of 'x = 2'
            x_assign = tree.body[0].body[1].body[0].body[0]

# Generated at 2022-06-12 04:54:09.401335
# Unit test for function find
def test_find():
    import astor
    from .transform import transform_lambda
    src = '''\
    def foo(a):
        b = lambda x, y: (x + y, x - y)
        a(b)
        c = lambda z: 1
        c(3)
    '''
    tree = ast.parse(src)
    foo = find(tree, ast.FunctionDef).__next__()
    print('foo: {}'.format(astor.dump_tree(foo)))
    a = foo.body[0]
    print('a: {}'.format(astor.dump_tree(a)))
    transform_lambda(tree, a)
    print(astor.to_source(tree))
    #print('body: {}'.format(astor.dump_tree(tree)))

# Generated at 2022-06-12 04:54:15.748477
# Unit test for function find
def test_find():
    # type: () -> None
    """Unit test for function find."""
    tree = ast.parse('foo()')
    assert len(list(find(tree, ast.Call))) == 1
    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Name))) == 1
    assert len(list(find(tree, ast.Load))) == 1
    assert len(list(find(tree, ast.Module))) == 1

# Generated at 2022-06-12 04:54:20.567102
# Unit test for function get_parent
def test_get_parent():
    code = '''
    def some_function():
        for i in range(10):
            pass
    '''

    root = ast.parse(code)
    for_node = get_parent(root, find(root, ast.For).__next__())
    assert isinstance(for_node, ast.FunctionDef)



# Generated at 2022-06-12 04:54:25.535357
# Unit test for function find
def test_find():
    def test_fn(a: int, b: str):
        return a + b
    tree = ast.parse(test_fn)
    function_defs = list(find(tree, ast.FunctionDef))
    assert len(function_defs) == 1
    assert function_defs[0].name == 'test_fn'


test_find()

# Generated at 2022-06-12 04:55:52.730300
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:55:53.552355
# Unit test for function get_parent

# Generated at 2022-06-12 04:56:02.652295
# Unit test for function find
def test_find():

    import astunparse
    from astpretty import pprint
    from ..tests.utils import get_ast

    tree = get_ast('a = 1')
    pprint(tree)

    def finder(type_):
        for node in find(tree, type_):
            print(astunparse.unparse(node))

    finder(ast.Assign)
    finder(ast.Name)
    finder(ast.Num)
    print('=' * 80)

    tree = get_ast('a.b.c')
    pprint(tree)

    finder(ast.Attribute)
    finder(ast.Name)
    finder(ast.load)
    print('=' * 80)

    tree = get_ast('a.b.c.d')
    pprint(tree)


# Generated at 2022-06-12 04:56:10.358158
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        a = 1
        return a
    """)
    def_ = find(tree, ast.FunctionDef).__next__()
    assign = find(def_, ast.Assign).__next__()
    return_ = find(def_, ast.Return).__next__()

    parent, index = get_non_exp_parent_and_index(tree, assign)
    assert isinstance(parent, ast.FunctionDef)
    assert parent == def_
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, return_)
    assert isinstance(parent, ast.FunctionDef)
    assert parent == def_
    assert index == 1


# Generated at 2022-06-12 04:56:13.828595
# Unit test for function find
def test_find():
    module = ast.parse("""
    if True:
        pass
        if True:
            pass

        if True:
            pass
    """)
    assert len(list(find(module, ast.If))) == 3
    assert len(list(find(module, ast.Pass))) == 3



# Generated at 2022-06-12 04:56:20.130056
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..exceptions import NodeNotFound
    from ..ast_manipulation import get_closest_parent_of, get_parent
    import ast

    def fn(x: int, y: int):
        if x < y:
            if x > 0:
                c = 7
                return x 
            else:
                return 5

    tree = ast.parse(fn)

    c = get_closest_parent_of(tree, get_parent(tree, tree.body[0].body[0]),
                              ast.FunctionDef)
    assert c == tree.body[0]
    
    c = get_closest_parent_of(tree, get_parent(tree, tree.body[0].body[1]), 
                              ast.FunctionDef)
    assert c == tree.body[0]

    c

# Generated at 2022-06-12 04:56:22.909811
# Unit test for function get_parent
def test_get_parent():
    def foo():
        pass

    tree: ast.AST = ast.parse(foo.__code__.co_code)
    assert get_parent(tree, tree.body[0].body[0].value.value) == \
        tree.body[0].body[0]

# Generated at 2022-06-12 04:56:24.466578
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-12 04:56:26.874606
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('print(1)')
    print(get_parent(tree, tree.body[0]))
    print(get_parent(tree, tree.body[0]) == tree)


# Generated at 2022-06-12 04:56:32.735284
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = """
        a = Foo()

        def foo():
            return a.foo() + 3
    """

    tree = ast.parse(code)
    node = tree.body[1].body.body[0]

    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

