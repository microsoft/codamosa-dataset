

# Generated at 2022-06-12 04:47:30.677536
# Unit test for function replace_at
def test_replace_at():
    def setup():
        class A(ast.AST):
            _fields = ('body', 'fields')

        class B(ast.AST):
            _fields = ('body', 'fields')

        fake_parent = A(body=[])
        fake_child_node = B(body=[])

        return fake_parent, fake_child_node

    def test_insert():
        parent, _ = setup()

        replace_at(0, parent, '12345')

        assert parent.body == ['12345']

    def test_insert_twice():
        parent, _ = setup()

        replace_at(0, parent, '12345')
        replace_at(0, parent, '54321')

        assert parent.body == ['54321']

    def test_insert_in_the_middle():
        parent, _ = setup

# Generated at 2022-06-12 04:47:35.184280
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''
        def func(arg1, arg2):
            pass
    ''')

    parent = get_parent(tree, tree.body[0].body[0])

    assert parent is tree.body[0]



# Generated at 2022-06-12 04:47:45.503699
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """
    if x == 1:
        l = list()
        l.append(1)
        l.append(2)
        l.append(3)
        l.append(4)

        for a in l:
            b = a + 1
    """
    import astor

    node = ast.parse(code)
    node_2 = get_closest_parent_of(node, node.body[0].body[1], ast.For)
    assert astor.to_source(node_2) == "for a in l:\n            b = a + 1"

    node_3 = get_closest_parent_of(node, node.body[0].body[1], ast.While)
    assert node_3 == None


# Generated at 2022-06-12 04:47:52.299974
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = """
    def main(a, b):
        if a == b:
            return a
        else:
            if a + b:
                return 0
            else:
                return 1
    """
    tree = ast.parse(source)
    if_a_equals_b = tree.body[0].body[0]
    closest_class_node = get_closest_parent_of(tree, if_a_equals_b, ast.Module)
    print("{0}".format(closest_class_node))


# Generated at 2022-06-12 04:47:55.935807
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('for i in range(10):\n    print(i)')
    s = tree.body[0]
    for_ = get_parent(tree, s)
    assert for_ is tree.body[0]


# Generated at 2022-06-12 04:47:59.081423
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('a = 1\nb = 2', '<test>', 'exec')
    node = tree.body[0].value
    result = get_closest_parent_of(tree, node, ast.Module)
    assert result is tree

# Generated at 2022-06-12 04:48:06.860540
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    a = ast.Module(body=[
        ast.FunctionDef(name='foo', body=[
            ast.Expr(value=ast.Num(n=1)),
        ]),
    ])

    expr = find(a, ast.Expr).__next__()
    func = find(a, ast.FunctionDef).__next__()
    assert get_closest_parent_of(a, expr, ast.FunctionDef) == func
    assert get_closest_parent_of(a, func, ast.Module) == a

# Generated at 2022-06-12 04:48:08.649483
# Unit test for function find

# Generated at 2022-06-12 04:48:10.908268
# Unit test for function find
def test_find():
    tree = ast.parse("""
i = 1
j = 2
""")
    for node in find(tree, ast.Assign):
        assert isinstance(node, ast.Assign)

# Generated at 2022-06-12 04:48:14.707426
# Unit test for function find
def test_find():
    source = """
a = b
if 1:
    s = 2
print(2)
"""
    tree = ast.parse(source)
    for i in find(tree, ast.Assign):
        print (i.__class__)



# Generated at 2022-06-12 04:48:23.838768
# Unit test for function find
def test_find():
    def test_func(a):
        b = 1
        c = 2
        return a + b + c
    test_tree = ast.parse(inspect.getsource(test_func)).body[0]
    names = []
    for name in find(test_tree, ast.Name):
        names.append(name.id)
    assert names == ['test_func', 'a', 'b', 'c']



# Generated at 2022-06-12 04:48:34.446033
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # for line 10
    code1 = '''
    def foo(a):
        if a > 1:
            if a > 2:
                if a < 3:
                    a = 2
                else:
                    b = 1
    '''
    tree1 = ast.parse(code1)
    get_closest_parent_of(tree1, tree1.body[0].body[1].body[0].body[1].body[0], ast.FunctionDef)

    # for line 6
    code2 = '''
    def foo(a):
        if a > 1:
            if a > 2:
                if a < 3:
                    a = 2
                else:
                    b = 1
    '''
    tree2 = ast.parse(code2)

# Generated at 2022-06-12 04:48:35.522106
# Unit test for function find
def test_find():
    import astunparse

# Generated at 2022-06-12 04:48:46.122408
# Unit test for function replace_at
def test_replace_at():
    import astor

    class Opt:
        def __init__(self, tree):
            self.tree = tree

        def _inline_node(self, node):
            tree = self.tree
            parent, index = get_non_exp_parent_and_index(tree, node)

            if not bool(parent.body[index].value.body):
                return

            replace_at(index, parent, parent.body[index].value.body)
            new_node = parent.body[index]
            new_node.body.extend(parent.body[index + 1:])
            del parent.body[index + 1:]

    test_code = '''
    def foo():
        if False:
            return 'foo'

    print(foo())
    '''
    tree = ast.parse(test_code)
    opt

# Generated at 2022-06-12 04:48:53.403577
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo(bar):\n    return None')
    exp = tree.body[0].body[0].value
    parent = get_non_exp_parent_and_index(tree, exp)
    assert isinstance(parent[0], ast.FunctionDef)
    assert parent[1] == 0
    print('Test for get_non_exp_parent_and_index passed')

test_get_non_exp_parent_and_index()

# Generated at 2022-06-12 04:48:54.059705
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-12 04:48:59.555383
# Unit test for function find
def test_find():
    sample_code = '''
    a = 1 + 2
    b = 3 + 4
    '''

    module = ast.parse(sample_code)
    ast.fix_missing_locations(module)

    test = list(find(module, ast.Add))

    assert len(test) == 2

    assert isinstance(test[0], ast.Add)
    assert isinstance(test[1], ast.Add)


# Generated at 2022-06-12 04:49:10.783504
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    one = ast.parse('def f(): 1 + 2')
    three = ast.parse('def f(): 1 + 2')
    four = ast.parse('def f(): 1 + 2')
    five = ast.parse('def f(): 1 + 2')
    six = ast.parse('def f(): 1 + 2')

    assert get_closest_parent_of(one, one.body[0].body[0], ast.FunctionDef) == one.body[0]
    assert get_closest_parent_of(three, three.body[0].body[0], ast.Module) == three
    assert get_closest_parent_of(four, four.body[0].body[0], ast.Module).body == []

# Generated at 2022-06-12 04:49:19.176201
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # The tree is built using ast.parse('code')
    tree = ast.Module([ast.Expr(value=ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Str(s='hi')],
        keywords=[]))])
    # Expected result is using ast.dump(tree)[10:]
    expected_result = (ast.Module(body=[ast.Expr(value=ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Str(s='hi')],
        keywords=[]))]), 0)
    result = get_non_exp_parent_and_index(tree, tree.body[0])

# Generated at 2022-06-12 04:49:25.424429
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Unit test for get_closest_parent_of"""
    tree = ast.parse('''
    class A:
        pass
    ''')
    node = tree.body[0].body[0]
    class_ = get_closest_parent_of(tree, node, ast.ClassDef)
    assert isinstance(class_, ast.ClassDef)
    assert class_.name == 'A'



# Generated at 2022-06-12 04:49:39.129611
# Unit test for function find
def test_find():
    from ..ast_tools import parse

    tree = parse('''
    import ast
    def a():
        def b():
            pass
        def c():
            pass
    ''')
    l = list(find(tree, ast.FunctionDef))
    assert len(l) == 3
    assert l[0].name == 'a'
    assert l[1].name == 'b'
    assert l[2].name == 'c'

    tree = parse('''
    import ast
    def a():
        pass
    def b():
        pass
    def c():
        pass
    def d():
        pass
    ''')
    l = list(find(tree, ast.FunctionDef))
    assert len(l) == 4
    assert l[0].name == 'a'
    assert l[1].name

# Generated at 2022-06-12 04:49:41.486788
# Unit test for function get_parent
def test_get_parent():
    import unittest
    import test.test_util
    _build_parents(test.test_util.tree)
    assert _parents[test.test_util.DECORATOR] == test.test_util.FUNC_DEF

# Generated at 2022-06-12 04:49:44.274883
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import _ast
    a = ast.parse('def f():\n    def g():\n        pass')
    assert isinstance(get_closest_parent_of(a, a.body[0].body[0], _ast.FunctionDef),
                      _ast.FunctionDef)
    assert isinstance(get_closest_parent_of(a, a, _ast.FunctionDef), _ast.Module)

# Generated at 2022-06-12 04:49:50.618895
# Unit test for function replace_at
def test_replace_at():
    t = ast.parse('''
    def f():
        a = 1
        b = 2
        c = 3
        d = 4
    ''')

    f = t.body[0]
    b = f.body[1]

    replace_at(1, f, [b])

    assert ast.dump(t) == ast.dump(ast.parse('''
    def f():
        a = 1
        b = 2
        b = 2
        c = 3
        d = 4
    '''))



# Generated at 2022-06-12 04:49:53.241769
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def foo(): pass')
    assert get_parent(tree, tree.body[0]) == tree

    with pytest.raises(NodeNotFound):
        get_parent(tree, None)

# Generated at 2022-06-12 04:50:02.270013
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    from typed_ast import ast3 as ast

    class TestParentOfMethods(unittest.TestCase):
        def test_get_closest_parent_of(self):
            import astor, unittest
            from astmonkey import transformers

            root = astor.parse('''
            def add(a, b):
                return a + b
            ''')

            t = transformers.ParentOf()
            t.visit(root)

            ret = get_closest_parent_of(root, t._parents[root.body[0]].body[0],
                                        ast.FunctionDef)

            self.assertEqual(ret, root.body[0])

    unittest.main()
# End unit test



# Generated at 2022-06-12 04:50:12.823005
# Unit test for function find
def test_find():
    import tools.ast, tools.parser, tools.codegen
    tree = tools.parser.parse_str("""
    class A:
        if True:
            pass
    """)
    _build_parents(tree)
    i = next(find(tree, ast.If))
    assert get_parent(tree, i).body.index(i) == 1
    assert get_non_exp_parent_and_index(tree, i) == (get_parent(tree, i), 1)
    c = get_closest_parent_of(tree, i, ast.ClassDef)
    assert c == next(find(tree, ast.ClassDef))
    import astor
    print(astor.to_source(tree))

if __name__ == "__main__":
    test_find()

# Generated at 2022-06-12 04:50:14.050541
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:50:21.165298
# Unit test for function find
def test_find():
    code = \
    """
    def foo():
        if a:
            b = 1

        for i in l:
            pass
    """

    ast_tree = ast.parse(code)

    if_nodes = list(find(ast_tree, ast.If))
    assert len(if_nodes) == 1, "Two if-statements should be found."

    for_nodes = list(find(ast_tree, ast.For))
    assert len(for_nodes) == 1, "One for-statement should be found."

    assert for_nodes[0].body[0] == ast_tree.body[0].body[2]
    assert for_nodes[0].body[0].body[0] == ast_tree.body[0].body[2].body[0]
    assert for_nodes

# Generated at 2022-06-12 04:50:29.010452
# Unit test for function find
def test_find():
    import astor
    test_code = "def test():\n\tprint('test')"
    test_tree = ast.parse(test_code)
    #ast.fix_missing_locations(test_tree)
    func_list = list(find(test_tree, ast.FunctionDef))
    print("Length of list is " + str(len(func_list)))
    assert func_list[0].name == "test"
    print("Function name is " + func_list[0].name)
    #print("Function body is " + astor.to_source(func_list[0]))


# Generated at 2022-06-12 04:50:39.520209
# Unit test for function get_parent
def test_get_parent():
    src = '''
    x = 2 + 3
    y = x * 5
    '''
    tree = ast.parse(src)
    test1_tree = tree.body[0]
    test2_tree = tree.body[1]
    test3_tree = test2_tree.value.left
    test4_tree = test1_tree.value
    test5_tree = test4_tree.left
    test6_tree = test4_tree.right
    assert get_parent(tree, test6_tree) == test4_tree
    assert get_parent(tree, test5_tree) == test4_tree
    assert get_parent(tree, test4_tree) == test1_tree
    assert get_parent(tree, test3_tree) == test2_tree

# Generated at 2022-06-12 04:50:40.250197
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-12 04:50:41.265266
# Unit test for function replace_at

# Generated at 2022-06-12 04:50:42.370256
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # TODO
    pass

# Generated at 2022-06-12 04:50:46.513935
# Unit test for function find
def test_find():
    # Arrange
    tree = ast.parse('''
    def test():
        def foo():
            pass

        def bar():
            pass
    ''')
    # Act
    found = list(find(tree, ast.FunctionDef))

    # Assert
    assert len(found) == 2



# Generated at 2022-06-12 04:50:56.245691
# Unit test for function find
def test_find():
    class1 = ast.ClassDef(name="FooClass", body=[ast.Pass()])
    class2 = ast.ClassDef(name="FooClass2", body=[ast.Pass()])
    func1 = ast.FunctionDef(name="FooFunc", body=[ast.Pass()])
    func2 = ast.FunctionDef(name="FooFunc2", body=[ast.Pass()])
    ast_tree = ast.Module(body=[class1, func1, class2, func2])

    for n in find(ast_tree, ast.ClassDef):
        assert n.__class__.__name__ == "ClassDef"

    for n in find(ast_tree, ast.FunctionDef):
        assert n.__class__.__name__ == "FunctionDef"


# Unit tests for function get_non_exp_parent

# Generated at 2022-06-12 04:50:59.622414
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    root = ast.parse('def test(): pass')
    assert (
        get_non_exp_parent_and_index(root, root.body[0].body[0]) ==
        (root.body[0], 0)
    )

# Generated at 2022-06-12 04:51:08.593829
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(ast.parse("if True: pass"),
                                        ast.parse("if True: pass").body[0]) == (
        ast.parse("if True: pass"), 0)

    assert get_non_exp_parent_and_index(
        ast.parse("if True:\n pass"), ast.parse("if True:\n pass").body[1]) == (
        ast.parse("if True:\n pass"), 1)

    assert get_non_exp_parent_and_index(
        ast.parse("if True:\n pass"), ast.parse("if True:\n pass").body[0]) == (
        ast.parse("if True:\n pass").body[0], 0)

# Generated at 2022-06-12 04:51:18.283963
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    import astor

    class TestGetClosestParentOf(unittest.TestCase):

        sample = """
if True:
    if True:
        if True:
            if True:
                pass"""

        parsed = astor.parse_file('tests/fixtures/sample.py')

        def test_get_closest_parent(self):
            pass_node = get_closest_parent_of(self.parsed,
                                              self.parsed.body[0].body[0].body[0].body[0].body[0],
                                              ast.If)

            self.assertEqual(pass_node.test.value, True)

    unittest.main()



# Generated at 2022-06-12 04:51:20.283903
# Unit test for function find
def test_find():
    assert(len(list(find(parse("x=1").body[0], ast.Assign))) == 1)


# Generated at 2022-06-12 04:51:28.316665
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert isinstance(find(ast.parse("x + x"), ast.Name), type(None))



# Generated at 2022-06-12 04:51:35.260838
# Unit test for function find
def test_find():
    tree = ast.parse('a=str(b)')
    nodes = find(tree, str)
    test_1 = False
    test_2 = False
    for n in nodes:
        if n == 'str':
            test_1 = True
        elif n == 'b':
            test_2 = True
    assert test_1 and test_2

    test_1 = False
    test_2 = False
    nodes = find(tree, ast.Name)
    for n in nodes:
        if isinstance(n, ast.Name):
            test_1 = True
        elif isinstance(n, ast.Attribute):
            test_2 = True
    assert test_1 and test_2


# Generated at 2022-06-12 04:51:39.023098
# Unit test for function get_parent
def test_get_parent():
    snippet = """
        def func():
            pass
    """
    tree = ast.parse(snippet)
    _build_parents(tree)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.FunctionDef)



# Generated at 2022-06-12 04:51:43.832221
# Unit test for function replace_at
def test_replace_at():
    import astor  # type: ignore

    n = ast.parse('')
    f = n.body.pop()
    a = ast.parse('1')
    insert_at(0, n, f)
    replace_at(0, n, a)

    assert astor.to_source(n) == '1'

# Generated at 2022-06-12 04:51:44.529006
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:51:51.480202
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ast_tools.parse import parse_code
    from .nodes import If, Exp
    from .nodes.factory import create_eval
    from ..exceptions import NodeNotFound

    tree = parse_code('a = 1')
    assign = tree.body[0]

    if_node = If(Exp(create_eval('True')), [assign])
    parent, index = get_non_exp_parent_and_index(tree, assign)
    assert parent == if_node
    assert index == 0

    assign2 = ast.parse('a = 1').body[0]
    assign3 = ast.parse('a = 1').body[0]

    parent, index = get_non_exp_parent_and_index(if_node, assign3)
    assert parent == if_node.orelse

# Generated at 2022-06-12 04:51:53.374826
# Unit test for function find
def test_find():
    import astunparse


# Generated at 2022-06-12 04:52:03.249610
# Unit test for function find
def test_find():
    tree = ast.parse(
        'import os\n'
        'from datetime import date\n'
        'import abc.def as def2\n'
        'def f(x):\n'
        '    g = lambda x: x**2\n'
        '    return g(x)\n'
        'class C(object):\n'
        '    def __init__(self, x):\n'
        '        self.x = x\n'
        '    def f(self):\n'
        '        return self.x\n'
    )
    assert len(list(find(tree, ast.ImportFrom))) == 1
    assert len(list(find(tree, ast.Import))) == 2
    assert len(list(find(tree, ast.Lambda))) == 1

# Generated at 2022-06-12 04:52:09.768618
# Unit test for function find
def test_find():
    text = 'a = 1; print(a)'
    tree = ast.parse(text)
    for node in find(tree, ast.Assign):
        assert node.targets[0].id == 'a'
    for node in find(tree, ast.Expr):
        assert isinstance(node.value, ast.Call)
    for node in find(tree, ast.Print):
        for child in node.values:
            assert child.id == 'a'


# Generated at 2022-06-12 04:52:15.982249
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Name(id='var')
    expr = ast.Expr(node)
    assign = ast.Assign(targets=[ast.Name(id='var')], value=expr)
    module = ast.Module(body=[assign])
    _build_parents(module)
    assert get_non_exp_parent_and_index(module, node)[1] == 0



# Generated at 2022-06-12 04:52:39.369944
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3
    from ..utils import ast_to_source
    from ..exceptions import NodeNotFound
    import pytest

    tree = ast3.parse('1 + 2')
    node = tree.body[0]
    relative = node.value
    node2 = tree.body[0].value
    relative2 = node2.left
    node3 = tree.body[0].value.left
    relative3 = None

    assert get_closest_parent_of(tree, relative, ast3.Module) == tree
    assert get_closest_parent_of(tree, node, ast3.Module) == tree
    assert get_closest_parent_of(tree, relative2, ast3.Module) == tree

# Generated at 2022-06-12 04:52:43.867421
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo(): x = 3 + 2 + 1', mode='exec')
    node = tree.body[0].body[0].value.left
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert(isinstance(parent, ast.Module))
    assert(isinstance(index, int))
    assert(index == 0)

# Generated at 2022-06-12 04:52:52.325433
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    print ('Testing function get_closest_parent_of')

    import astunparse
    import inspect

    src_code = inspect.getsource(test_get_closest_parent_of)
    code = ast.parse(src_code)

    def_node = get_closest_parent_of(code, code.body[0], ast.FunctionDef)
    assert astunparse.unparse(def_node) == 'def test_get_closest_parent_of():'

    module_node = get_closest_parent_of(code, def_node, ast.Module)
    assert code == module_node



# Generated at 2022-06-12 04:52:53.530581
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert True, get_closest_parent_of(None, None, None)

# Generated at 2022-06-12 04:52:55.870936
# Unit test for function find
def test_find():
    tree = ast.parse('i = 1 + 2')
    print([node.id for node in find(tree, ast.Name)])

# Generated at 2022-06-12 04:53:02.181552
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('x = 1')
    node = tree.body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert(isinstance(parent, ast.Module))
    assert(index == 0)
    print("get_non_exp_parent_and_index test passed")


# Generated at 2022-06-12 04:53:05.205181
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Get a closest parent for the import node
    import_node = ast.parse("import ast").body[0]
    module_node = ast.parse("import ast")
    assert get_closest_parent_of(module_node, import_node, ast.AST) == module_node

# Generated at 2022-06-12 04:53:09.434689
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = '''\
    def x():
        if y:
            y += 1
    '''

    tree = ast.parse(code)
    _build_parents(tree)
    cls = get_closest_parent_of(tree, tree.body[0].body[0].body[0], ast.ClassDef)
    assert cls is None

# Generated at 2022-06-12 04:53:10.646877
# Unit test for function find
def test_find():
    tree = parse("(1 + 2) * 3")
    assert sum(1 for _ in find(tree, ast.BinOp)) == 1

# Generated at 2022-06-12 04:53:15.623088
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_tree = """
    import ast
    import typed_ast.ast3 as ast
    tree = ast.parse('def test(): pass')
    """

    tree = ast.parse(ast_tree)
    test_node = tree.body[-1].value.body[0]  # type: ignore
    module = get_closest_parent_of(tree, test_node, ast.Module)
    assert isinstance(module, ast.Module)

# Generated at 2022-06-12 04:53:56.698677
# Unit test for function get_parent
def test_get_parent():
    node_src = ast.parse("""
    def foo():
        baz(1, 2)

    def bar():
        foo()
    """)

    bar_src = node_src.body[1]
    assert bar_src.body[0].func.id == "foo"

    foo_src = node_src.body[0]
    assert foo_src.name == "foo"

    assert get_parent(bar_src, foo_src) == bar_src
    assert get_parent(foo_src, foo_src) == foo_src


# Generated at 2022-06-12 04:53:57.456266
# Unit test for function find

# Generated at 2022-06-12 04:53:58.174110
# Unit test for function replace_at

# Generated at 2022-06-12 04:54:06.598266
# Unit test for function replace_at
def test_replace_at():
    test_tree = ast.parse("class A: def f(self): a = 1 + 2\n")
    _build_parents(test_tree)
    test_body = find(test_tree, ast.ClassDef).__next__().body
    node_to_replace = test_body[0].body[0].body[0]
    replace_at(0, test_body[0].body[0], ast.parse("a = 5 + 6").body[0])
    assert node_to_replace.value.left.n == 5

# Generated at 2022-06-12 04:54:12.031605
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_tree1 = ast.parse('''
        def func():
            pass
    ''')
    test_node1 = test_tree1.body[0].body[0]
    assert isinstance(get_closest_parent_of(test_tree1, test_node1,
                      ast.FunctionDef), ast.FunctionDef)

    test_tree2 = ast.parse('''
        def func():
            if True:
                pass
    ''')
    test_node2 = test_tree2.body[0].body[0].body[0]
    assert isinstance(get_closest_parent_of(test_tree2, test_node2,
                      ast.If), ast.If)


# Generated at 2022-06-12 04:54:18.978184
# Unit test for function replace_at
def test_replace_at():
    statement = ast.parse(
        'def foo():'
        '    print("hello world")'
    ).body[0]

    module = ast.Module([statement])
    parent = get_parent(module, statement)
    index = 0

    _parents[statement] = module

    replace_at(index, parent, ast.Expr(ast.Str('hello world')))

    assert ast.dump(module) == \
        'Module(body=[Expr(value=Str(s=\'hello world\'))])'



# Generated at 2022-06-12 04:54:19.648005
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass

# Generated at 2022-06-12 04:54:28.573512
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ast_toolbox import get_closest_parent_of

    tree = astor.parse_file('<PARENT>')

    assert isinstance(get_closest_parent_of(tree, tree.body[0], ast.Module),
                      ast.Module)
    assert not isinstance(get_closest_parent_of(tree, tree.body[0], ast.Module),
                          ast.FunctionDef)

    # ToDo by Arjaan: beter unit test, this is not good enough
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0],
                                            ast.FunctionDef),
                      ast.FunctionDef)

# Generated at 2022-06-12 04:54:32.098856
# Unit test for function find
def test_find():
    test_tree = ast.parse('''
    x = 2 + 3
    l = [4, 5, 6]
    for n in l:
        print(n)
    ''')

    assert len(list(find(test_tree, ast.Name))) == 5
    assert len(list(find(test_tree, ast.Num))) == 5


# Generated at 2022-06-12 04:54:41.848414
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .test_ast import ast_
    from .test_ast import expected_ast_
    ast_.body[3].body[0].name = 'my_var'
    for exp, act in zip(expected_ast_.body, ast_.body):
        assert exp._fields == act._fields
        for value_exp, value_act in zip(exp.body, act.body):
            assert value_exp._fields == value_act._fields
            if type(value_exp) is ast.FunctionDef:
                assert value_exp.name == value_act.name
                assert value_exp.args.args == value_act.args.args
                assert value_exp.args.vararg == value_act.args.vararg
                assert value_exp.decorator_list == value_act.decorator_list
                assert value_exp

# Generated at 2022-06-12 04:56:09.385684
# Unit test for function get_parent
def test_get_parent():
    # Set up AST
    tree = ast.parse('def function(p1: int):\n    a = p1 + p1')
    # Test node assignment
    assignment = tree.body[0].body[0]
    
    assert get_parent(tree, assignment) == tree.body[0]
    assert get_parent(tree, assignment, True) == tree.body[0]

# Generated at 2022-06-12 04:56:17.528892
# Unit test for function find

# Generated at 2022-06-12 04:56:19.000097
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor


# Generated at 2022-06-12 04:56:22.911506
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Expr(value=ast.Name(id='foo', ctx=ast.Load()))
    tree = ast.Module(body=[ast.Expr(value=node)])
    par, idx = get_non_exp_parent_and_index(tree, node)
    assert isinstance(par, ast.Module)
    assert idx == 0

# Generated at 2022-06-12 04:56:29.508692
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astpretty
    tree = ast.parse("""
    def foo():
        if True:
            return 1
        else:
            return 2
    """)
    node = tree.body[0].body[1].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    ast.fix_missing_locations(parent)
    print(astpretty.pprint(parent))
    assert isinstance(parent, ast.If)
    assert index == 0



# Generated at 2022-06-12 04:56:34.629925
# Unit test for function find
def test_find():
    program = open("test.py").read()
    tree = ast.parse(program)
    list_of_function = list(find(tree, ast.FunctionDef))
    print("number of function: " + str(len(list_of_function)))
    for f in list_of_function:
        print("Function name: " + f.name)



# Generated at 2022-06-12 04:56:35.099203
# Unit test for function get_parent

# Generated at 2022-06-12 04:56:41.390542
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def f():\n  while True:  # comment1\n    pass')
    while_node = tree.body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, while_node.test)
    assert isinstance(parent, ast.While)
    assert parent.body[0] is while_node.test
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, while_node)
    assert isinstance(parent, ast.Body)
    assert parent.body[0] is while_node
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, while_node)
    assert isinstance(parent, ast.FunctionDef)

# Generated at 2022-06-12 04:56:44.818328
# Unit test for function find
def test_find():
    def test(find, _1, _2, _3):
        return test

    tree = ast.parse('test(find, _1, _2, _3)')
    assert list(find(tree, ast.Name)) == [ast.parse('test').body[0].value.args[0]]

# Generated at 2022-06-12 04:56:45.635545
# Unit test for function get_non_exp_parent_and_index