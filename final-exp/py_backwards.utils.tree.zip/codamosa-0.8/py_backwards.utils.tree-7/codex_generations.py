

# Generated at 2022-06-12 04:47:25.889101
# Unit test for function find
def test_find():
    with open('find.py', 'r') as f:
        tree = ast.parse(f.read())
        f.close()

    print('++++++++++++++++++++')
    print('Test for function find:')
    for node in find(tree, ast.Return):
        print(ast.dump(node))
    print('++++++++++++++++++++')



# Generated at 2022-06-12 04:47:26.531407
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:47:27.842900
# Unit test for function get_parent

# Generated at 2022-06-12 04:47:33.797884
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:47:44.721031
# Unit test for function find
def test_find():
    """Test for find."""
    tree = ast.parse('''\
    def factorial(n):
        if n == 1:
            return 1
        return n*factorial(n-1)
    ''')

    names = list(find(tree, ast.Name))

    a = False

    if names[0].id == 'factorial':
        a = True

    b = False

    if names[1].id == 'n':
        b = True

    c = False

    if names[2].id == 'factorial':
        c = True

    d = False

    if names[3].id == 'n':
        d = True

    e = False

    if names[4].id == 'factorial':
        e = True

    f = False


# Generated at 2022-06-12 04:47:47.708803
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('x = 1\ny = 2')
    node = tree.body[0].value
    assert get_non_exp_parent_and_index(tree, node)[1] == 0


# Generated at 2022-06-12 04:47:53.620312
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''\
    def f():
        if True:
            def f():
                return
            return
        return
        ''')

    # _build_parents(tree)
    # print(_parents)
    # parent = get_parent(tree, tree.body[0].body[0].body[0])
    # print(parent)
    # assert isinstance(parent, ast.If)

    # assert get_non_exp_parent_and_index(tree, parent) == (tree.body[0], 2)

# Generated at 2022-06-12 04:48:04.855240
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # body
    tree = ast.parse("""
    x = 10
    y = x + 20
    z = y + 30
    """)

    assert isinstance(get_non_exp_parent_and_index(tree, tree.body[1].value)[0],
                      ast.Module)
    assert get_non_exp_parent_and_index(tree, tree.body[1].value)[1] == 1

    # Module, body
    tree = ast.parse("""
    x = 10
    y = x + 20
    z = y + 30
    """)

    assert isinstance(get_parent(tree, tree.body[1].value), ast.Assign)
    assert isinstance(get_non_exp_parent_and_index(tree, tree.body[1].value)[0],
                      ast.Module)

# Generated at 2022-06-12 04:48:12.197146
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast
    my_ast = ast.parse(
        'a = 1\n'
        'b = 2\n'
        '\n'
        'var = 3')
    test = my_ast.body[1]
    parent = my_ast.body

    assert get_non_exp_parent_and_index(my_ast, test) == (parent, 1)

if __name__ == '__main__':
    test_get_non_exp_parent_and_index()

# Generated at 2022-06-12 04:48:16.223159
# Unit test for function get_parent
def test_get_parent():
    # arr = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    # print(type(arr))
    # print(get_parent(arr))
    # print(get_parent([1, 2, 1, 2]))
    # print(get_parent((1, 2, 1, 2)))
    # print(get_parent({"a": "c", "b": "d"}))
    a = (1, 2)
    print(get_parent(a, a))


test_get_parent()


# Generated at 2022-06-12 04:48:27.055286
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # creates AST for function def f():
    #     continue
    #     print("hello")
    ast1 = ast.parse("def f():\n    continue\n    print(\"hello\")").body[0]
    f = ast1
    b = ast.Call(func=ast.Name(id='print', ctx=ast.Load()), 
                 args=[ast.Str(s="hello")], keywords=[], starargs=None, 
                 kwargs=None)
    continue_ = ast.Continue()
    b1 = ast.Pass()
    b2 = ast.Pass()
    b3 = ast.Pass()
    b4 = ast.Pass()
    # create AST for FunctionDef f
    #     Print ("hello")
    #     Pass
    # should return f
    f.body[0] = b


# Generated at 2022-06-12 04:48:35.695183
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    arg = ast.parse("x = y + z").body[0]
    call = ast.parse("f(x, y)").body[0].value
    name = ast.parse("f()").body[0].value.func
    assert get_non_exp_parent_and_index(ast.parse("x = y + z"), arg) == (
        ast.parse("x = y + z"), 0)
    assert get_non_exp_parent_and_index(ast.parse("f(x, y)"), call) == (
        ast.parse("f(x, y)"), 0)
    assert get_non_exp_parent_and_index(ast.parse("f()"), name) == (
        ast.parse("f()"), 0)


# Generated at 2022-06-12 04:48:42.570085
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def foo():
        pass
    tree = ast.parse(foo.__code__)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])

    assert isinstance(parent, ast.Module)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-12 04:48:49.702187
# Unit test for function get_parent
def test_get_parent():
    import unittest
    from typed_ast.ast3 import Name, Import, ImportFrom, FunctionDef

    ast_tree = Import(names=[Name(id='one', ctx=ast.Load()),
                               Name(id='two', ctx=ast.Load())])
    import_from = ImportFrom(module='something',
                             names=[Name(id='three', ctx=ast.Load())],
                             level=0)
    function = FunctionDef(name='f', args=ast.arguments(args=[], vararg=None,
                                                        kwarg=None,
                                                        defaults=[],
                                                        kw_defaults=[]))

    ast_tree.body.append(import_from)
    ast_tree.body.append(function)


# Generated at 2022-06-12 04:48:50.739951
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:52.086242
# Unit test for function find

# Generated at 2022-06-12 04:48:53.816020
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:55.344449
# Unit test for function find
def test_find():
    tree = ast.parse("a + b")
    result_list = [r for r in find(tree, ast.BinOp)]
    assert len(result_list) == 1
    assert isinstance(result_list[0], ast.BinOp)



# Generated at 2022-06-12 04:49:03.744023
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''class C:
    a = 1
    b = 2
    c = 3''')
    variable1_node = tree.body[0].body[0]
    variable2_node = tree.body[0].body[1]
    variable3_node = tree.body[0].body[2]

    variable1_parent, variable1_index = get_non_exp_parent_and_index(tree, variable1_node)
    variable2_parent, variable2_index = get_non_exp_parent_and_index(tree, variable2_node)
    variable3_parent, variable3_index = get_non_exp_parent_and_index(tree, variable3_node)

    assert variable1_parent == variable2_parent == variable3_parent
    assert variable1_index == 0

# Generated at 2022-06-12 04:49:06.603066
# Unit test for function find
def test_find():
    code = "def f():\n    pass"
    tree = ast.parse(code)
    for node in find(tree, ast.FunctionDef):
        print(node)

# Generated at 2022-06-12 04:49:10.984380
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-12 04:49:15.925736
# Unit test for function get_parent
def test_get_parent():
    statement = ast.parse("if True:\n    x = 0\n").body[0]
    left_node = statement.body[0].value
    print(left_node)
    print(statement)
    assert get_parent(statement, left_node) == statement


if __name__ == "__main__":
    test_get_parent()

# Generated at 2022-06-12 04:49:23.393480
# Unit test for function replace_at
def test_replace_at():
    def hello():
        a = 1
        b = 2  # test
        c = 3
        return 42
    tree = ast.parse(hello.__code__)
    parent, index = get_non_exp_parent_and_index(tree,
                                                 tree.body[0].body[1])
    replace_at(index, parent, [ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Store())],
        value=ast.Num(n=42))])

# Generated at 2022-06-12 04:49:29.245062
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import os
    import sys
    # Here we add ".." to sys path so that we can import typed_ast.
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from ..parsing import parse_source, Source
    from ..transformations import transform_ast, RemoveDeadCodeTransformer
    from ..visitors import FunctionVisitor

    source_text = """
    def foo(a):
        a = 1
        b = a
        return b + a
    """
    source = Source(source_text)
    tree = parse_source(source)
    transform_ast(tree, [RemoveDeadCodeTransformer()])
    visitor = FunctionVisitor()


# Generated at 2022-06-12 04:49:32.685205
# Unit test for function find
def test_find():
    """Unit test for function find."""

# Generated at 2022-06-12 04:49:36.735739
# Unit test for function find
def test_find():
    root_node = ast.parse('a = 0')
    store_nodes = find(root_node, ast.Store)  # type: Iterable[ast.Store]

    assert(list(find(root_node, ast.Store)) == [root_node.body[0].targets[0]])

# Generated at 2022-06-12 04:49:40.005826
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(ast.parse('x'),
                                        ast.parse('x').body[0]) == (
                                            ast.parse('x'), 0
                                        )

# Generated at 2022-06-12 04:49:43.061203
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = """if foo():
        bar()
    elif baz():
        biz()
    else:
        buzz()"""
    parsed = ast.parse(code)
    tree = parsed.body[0]
    pass

# Generated at 2022-06-12 04:49:44.000083
# Unit test for function find

# Generated at 2022-06-12 04:49:48.987851
# Unit test for function replace_at
def test_replace_at():
    t = ast.parse('a = 1\nx = 3')

    with pytest.raises(Exception):
        replace_at(1, t, ast.Name(id='x', ctx=ast.Store()))

    replace_at(0, t, ast.Name(id='x', ctx=ast.Store()))
    assert ast.dump(t) == 'x = 3'

# Generated at 2022-06-12 04:49:52.939009
# Unit test for function get_parent

# Generated at 2022-06-12 04:50:02.057154
# Unit test for function get_parent
def test_get_parent():
    import unittest

    # class Test_get_parent(unittest.TestCase):
    tree = ast.parse('''
        def foo():
            {
                a
            }
        ''')
    try:
        get_parent(tree, tree)
    except NodeNotFound:
        pass
    else:
        assert False

    try:
        get_parent(tree, tree.body[0])
    except NodeNotFound:
        pass
    else:
        assert False

    assert get_parent(tree, tree.body[0].body[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0].body[0]) == tree.body[0].body[0]


test_get_parent()

# Generated at 2022-06-12 04:50:12.578458
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    parent = ast.Module(body=[
        ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Num(n=1),
                op=ast.Add(),
                right=ast.Num(n=2),
            )
        )
    ])

    parent_index = get_non_exp_parent_and_index(parent,
                                                parent.body[0].value.left)
    assert parent_index == (parent.body[0], 0)

    parent_index = get_non_exp_parent_and_index(parent,
                                                parent.body[0].value)
    assert parent_index == (parent, 1)


# Generated at 2022-06-12 04:50:15.018831
# Unit test for function find
def test_find():
    mod = ast.parse('class Test: pass')
    assert len(list(find(mod, ast.ClassDef))) == 1



# Generated at 2022-06-12 04:50:21.512462
# Unit test for function find
def test_find():
    import unittest
    from . import parse
    from . import get_parent
    from . import get_non_exp_parent_and_index
    from . import find
    from . import insert_at
    from . import replace_at
    from . import get_closest_parent_of
    from ..exceptions import NodeNotFound

    class TestUtils(unittest.TestCase):
        def setUp(self):
            self.code = '''
                        def foo(x):
                            print(x)
                        '''

        def test_find(self):
            tree = parse(self.code)
            parent = get_parent(tree, tree.body[0].body[0].value)
            self.assertTrue(isinstance(parent, ast.Call))


# Generated at 2022-06-12 04:50:23.248450
# Unit test for function find
def test_find():
    find(ast.parse(''), ast.Assign)
    pass



# Generated at 2022-06-12 04:50:31.936973
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    module = ast.parse('if a: a = b')
    module.body.insert(0, ast.Expr(value=ast.Name(id='c')))
    closest_parent_of_module = get_closest_parent_of(module, module, ast.Module)
    assert closest_parent_of_module == module
    closest_parent_of_expr = get_closest_parent_of(module, module, ast.Expr)
    assert isinstance(closest_parent_of_expr, ast.Expr)
    assert closest_parent_of_expr.value.id == 'c'
    closest_parent_of_expr = get_closest_parent_of(module, module.body[1], ast.Expr)
    assert closest_parent_of_expr == module.body[2]


# Generated at 2022-06-12 04:50:35.510292
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module = ast.parse("""
    a = 1
    b = 2
    """)

    a_node = module.body[0]
    parent, index = get_non_exp_parent_and_index(module, a_node)

    assert parent is module
    assert index == 0

# Generated at 2022-06-12 04:50:41.415582
# Unit test for function find
def test_find():
    def fn():
        a = 1 + 1
        b = 2 + 2
        c = 3 + 3

    tree = extract_ast_from_fn(fn, {'ast': ast})
    a = find(tree, ast.Expr).__next__()  # type: ignore
    assert a.value.__dict__ == ast.BinOp(
        left=ast.Num(1), op=ast.Add(), right=ast.Num(1)).__dict__

# Generated at 2022-06-12 04:50:50.919909
# Unit test for function get_parent
def test_get_parent():
    test_code = """
    import test as test_module
    
    test_module.test_function(test_module.test_class())
    """

    test_tree = ast.parse(text=test_code)
    test_import = test_tree.body[0]
    test_import_name = test_import.names[0]
    test_func = test_tree.body[1].value.func
    test_class = test_tree.body[1].value.args[0].func

    # Check that _parents dict is empty
    assert _parents == {}

    # Get parents
    module_parent = get_parent(test_tree, test_import_name)
    func_parent = get_parent(test_tree, test_func)
    class_parent = get_parent(test_tree, test_class)

# Generated at 2022-06-12 04:51:02.362400
# Unit test for function find

# Generated at 2022-06-12 04:51:03.315338
# Unit test for function find
def test_find():
    assert find("2+2") == 2

# Generated at 2022-06-12 04:51:12.281044
# Unit test for function replace_at
def test_replace_at():
    import astor
    #test_ast = ast.parse('print("Hello world!")')
    test_ast = ast.parse('print(a)')
    import astpp
    #astpp.dump(test_ast)
    print(astor.to_source(test_ast))
    get_parent(test_ast, test_ast.body[0], rebuild=True)
    #print(_parents)
    parent, index = get_non_exp_parent_and_index(test_ast, test_ast.body[0])
    #print(parent.lineno)
    replace_at(index, parent, ast.parse('print(b)'))
    print(astor.to_source(test_ast))

# Generated at 2022-06-12 04:51:13.388247
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:51:22.420769
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    from . import test_parser

    class TestParent(unittest.TestCase):
        def test_find_parent_of(self):
            tree = test_parser.parse('item.split()')

            parent = get_closest_parent_of(tree, tree.body[0].value.func,
                                           ast.Expr)
            self.assertIs(parent, tree.body[0].value)

            parent = get_closest_parent_of(tree, tree.body[0].value.func,
                                           ast.Module)
            self.assertIs(parent, tree)

            with self.assertRaises(NodeNotFound):
                get_closest_parent_of(tree, tree.body[1].value, ast.Expr)

    unittest.main()

# Generated at 2022-06-12 04:51:32.719760
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..exceptions import NodeNotFound

    tree = ast.parse('''
    def f():
        def t():
            return 1
        return t()
        ''')
    node = find(tree, ast.Call).__next__()

    closest_parent_of = lambda x: get_closest_parent_of(tree, node, x)

    assert isinstance(closest_parent_of(ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(closest_parent_of(ast.ClassDef),
                      ast.Module)

    try:
        assert isinstance(closest_parent_of(ast.Assign),
                          ast.ClassDef)
    except NodeNotFound:
        assert True



# Generated at 2022-06-12 04:51:38.624455
# Unit test for function find
def test_find():
    body = [
        ast.Expr(value=ast.Name(id='x')),
        ast.Expr(value=ast.Name(id='y')),
    ]
    node = ast.ClassDef(name='Foo', body=body)
    assert list(find(node, ast.Name)) == [body[0].value, body[1].value]
    assert list(find(node, ast.Expr)) == body
    assert list(find(node, ast.Expr)) == body

# Generated at 2022-06-12 04:51:47.297687
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def f():
        if True:
            a = 1
    """)  # type: ignore

    node = tree.body[0].body[0].body[0]
    assert get_closest_parent_of(tree, node, ast.FunctionDef) is tree.body[0]

    node = tree.body[0].body[0]
    assert get_closest_parent_of(tree, node, ast.FunctionDef) is tree.body[0]

    node = tree.body[0]
    assert get_closest_parent_of(tree, node, ast.Module) is tree

# Generated at 2022-06-12 04:51:49.582181
# Unit test for function find
def test_find():
    tree = ast.parse('def foo():\n  pass\n')
    test = find(tree, ast.FunctionDef)
    assert next(test).name == 'foo'

# Generated at 2022-06-12 04:51:50.524879
# Unit test for function get_parent

# Generated at 2022-06-12 04:52:07.879910
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:52:09.898427
# Unit test for function find
def test_find():
    node = ast.parse('1 + 1')
    assert len(list(find(node, ast.BinOp))) == 1

# Generated at 2022-06-12 04:52:12.083221
# Unit test for function find
def test_find():
    tree = ast.parse('a + 2.5')
    nodes = list(find(tree, ast.Num))
    assert nodes[0].n == 2.5



# Generated at 2022-06-12 04:52:14.354558
# Unit test for function find

# Generated at 2022-06-12 04:52:15.405145
# Unit test for function get_parent

# Generated at 2022-06-12 04:52:24.065045
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    # Test case 1
    test_ast = ast.parse(
        """def x():
            if True:
                print(2,end="")
            else:
                print(3,end="")"""
    )
    test_node = test_ast.body[0].body[0]
    test_parent, test_index = get_non_exp_parent_and_index(test_ast, test_node)

    assert isinstance(test_parent, ast.FunctionDef)
    assert test_index == 0

    # Test case 2
    test_ast = ast.parse(
        """def x():
            if True:
                print(2,end="")
        else:
            print(3,end="")"""
    )
    test_node = test_ast.body[0].body[0]
    test_parent

# Generated at 2022-06-12 04:52:30.794773
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def g(a):
        c = a
        while True:
            # comment
            b = c
            c = b

    i = g('aa')
    tree = ast.parse(inspect.getsource(g))
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0].body[0])
    assert parent.body[index] == tree.body[0].body[0].body[0].body[0]
    assert parent.body[index] == tree.body[0].body[0].body[0].body[0]

# Generated at 2022-06-12 04:52:34.116638
# Unit test for function get_parent
def test_get_parent():
    with open('tests/get_parent.py', 'r') as f:
        tree = ast.parse(f.read())
    print(tree)
    
    print(get_parent(tree, tree.body[1]))

# test_get_parent()

# Generated at 2022-06-12 04:52:34.891579
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:52:41.828805
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1\nb = 2')
    body = tree.body
    b = body[1]
    parent_body, index = get_non_exp_parent_and_index(tree, b)
    assert parent_body == tree
    assert index == 1
    c = ast.parse('c = 1').body[0]
    parent_body, index = get_non_exp_parent_and_index(tree, c)
    assert parent_body == b
    assert index == 0
    ast.fix_missing_locations(tree)


# Generated at 2022-06-12 04:53:27.434428
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("def foo():\n    pass")
    parent = get_non_exp_parent_and_index(tree, tree.body[0].body[0])[0]
    assert parent is tree.body[0]

    tree = ast.parse("def foo():\n    if x:\n        pass")
    parent = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])[0]
    assert parent is tree.body[0].body[0]

    tree = ast.parse("def foo():\n    x = (1, 2, 3)\n    pass")
    parent = get_non_exp_parent_and_index(tree, tree.body[0].body[1])[0]
    assert parent is tree.body[0]




# Generated at 2022-06-12 04:53:29.877660
# Unit test for function find
def test_find():
    body = ast.parse('a = None').body
    assert list(find(body, ast.Assign)) == body
    assert list(find(body, ast.Name)) == body[0].value.elts



# Generated at 2022-06-12 04:53:31.412567
# Unit test for function get_parent

# Generated at 2022-06-12 04:53:39.898940
# Unit test for function find
def test_find():
    tree = ast.parse('a = b + c\n')
    assert list(find(tree, ast.Module)) == [tree]
    assert list(find(tree, ast.Name)) == [tree.body[0].value.func,
                                          tree.body[0].value.args[0],
                                          tree.body[0].value.args[1]]
    assert list(find(tree, ast.Add)) == [tree.body[0].value]
    assert list(find(tree, ast.Assign)) == [tree.body[0]]
    assert list(find(tree, ast.BinOp)) == [tree.body[0].value]
    assert list(find(tree, ast.Expr)) == [tree.body[0]]
    assert list(find(tree, ast.FunctionDef)) == []
   

# Generated at 2022-06-12 04:53:45.979349
# Unit test for function replace_at
def test_replace_at():
    """Test function replace_at."""
    tree = ast.parse("if 1: if 2: pass")

    if_node = tree.body[0]
    assert isinstance(if_node, ast.If)
    if_stmt = if_node.body[0]
    assert isinstance(if_stmt, ast.If)

    replace_at(0, if_node, ast.Pass())
    assert len(if_node.body) == 1
    assert isinstance(if_node.body[0], ast.Pass)

# Generated at 2022-06-12 04:53:55.173870
# Unit test for function find
def test_find():
    code = """
        x = (1 + 2) * 3
    """
    result = list(find(ast.parse(code), ast.BinOp))
    expected = [
        ast.BinOp(
            left=ast.Num(n=1),
            op=ast.Add(),
            right=ast.Num(n=2),
        ),
        ast.BinOp(
            left=ast.BinOp(
                left=ast.Num(n=1),
                op=ast.Add(),
                right=ast.Num(n=2),
            ),
            op=ast.Mult(),
            right=ast.Num(n=3),
        ),
    ]
    assert result == expected



# Generated at 2022-06-12 04:53:57.702675
# Unit test for function find
def test_find():
    tree = ast.parse("""
    def a(b):
        a = 1
        b = 3
        c = a + b
        return c + a
    """)
    assert len(list(find(tree, ast.Name))) == 5

# Generated at 2022-06-12 04:54:02.690337
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a + b')
    a, b = tree.body[0].value.left, tree.body[0].value.right
    parent, index = get_non_exp_parent_and_index(tree, a)
    assert parent == tree.body[0]
    assert index == 0
    parent, index = get_non_exp_parent_and_index(tree, b)
    assert parent == tree.body[0]
    assert index == 0
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent == tree
    assert index == 0
    parent, index = get_non_exp_parent_and_index(tree, tree)
    assert parent is None
    assert index is None

# Generated at 2022-06-12 04:54:10.810726
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound

    src = '''
    x = [1, 2]
    y = {3, 4}
    z = (5, 6)
    '''

    tree = ast.parse(src)

    try:
        parent = get_parent(tree, tree.body[0])
        assert isinstance(parent, (ast.Module)) and parent == tree
    except NodeNotFound:
        assert False

    try:
        lhs = get_parent(tree, tree.body[0].target)
        assert isinstance(lhs, (ast.Assign)) and lhs == tree.body[0]
    except NodeNotFound:
        assert False


# Generated at 2022-06-12 04:54:13.489907
# Unit test for function get_parent
def test_get_parent():
    l = ast.Lambda(args=None, body=ast.Constant(value=True))
    assert get_parent(l, l) is None



# Generated at 2022-06-12 04:55:47.369228
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import sys
    from ..utils import get_ast

    x = get_closest_parent_of(get_ast(sys.modules[__name__]),
                              ast.Name('ast', ast.Load()), ast.Module)
    assert isinstance(x, ast.Module)

# Generated at 2022-06-12 04:55:53.410381
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Check that every node has an non-Exp parent and an index of the child node."""
    p = ast.parse('''
        if a:
            b = 1
            d = 2
            if c:
                e = 3
            f = 5
    ''')
    for node in ast.walk(p):
        parent, index = get_non_exp_parent_and_index(p, node)
        try:
            parent.body[index]
        except IndexError:
            raise AssertionError('get_non_exp_parent_and_index test failed.')



# Generated at 2022-06-12 04:55:59.074614
# Unit test for function get_parent
def test_get_parent():
    from textwrap import dedent
    from typed_ast.ast3 import parse, Call

    tree = parse(dedent("""
    def foo(a: int, b: int) -> str:
        return a.__getitem__(b)
    """))

    call = find(tree, Call).__next__()
    print(call)
    p = get_parent(tree, call)
    print(p)
    assert isinstance(p, ast.Return)


if __name__ == "__main__":
    test_get_parent()

# Generated at 2022-06-12 04:56:04.537816
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        foo_ = 1 + 1
    """)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    assert parent.body[0].value.left.n == 1
    assert parent.body[0].value.left.n == tree.body[0].body[0].value.left.n
    assert index == 0

# Generated at 2022-06-12 04:56:05.655184
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:56:07.083911
# Unit test for function replace_at

# Generated at 2022-06-12 04:56:09.314040
# Unit test for function get_parent
def test_get_parent():
    module = ast.parse('a = 1')
    parent = get_parent(module, module.body[0].value)
    assert isinstance(parent, ast.Assign)



# Generated at 2022-06-12 04:56:11.071482
# Unit test for function find
def test_find():
    tree = ast.parse('5 + 3')
    assert list(find(tree, ast.BinOp)) == [tree.body[0].value]

# Generated at 2022-06-12 04:56:18.754482
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # AST for:
    #
    #    a = 1
    #    if True:
    #        if False:
    #            a = 2
    #            c = 7
    #
    #    if True:
    #        b = 3
    #    elif False:
    #        b = 4
    #
    #    if True:
    #        c = 5
    #    else:
    #        c = 6
    tree = ast.parse(
        '''
a = 1
if True:
    if False:
        a = 2
        c = 7

if True:
    b = 3
elif False:
    b = 4

if True:
    c = 5
else:
    c = 6
''',
        mode='exec')

    class B(ast.AST):
        _

# Generated at 2022-06-12 04:56:27.568292
# Unit test for function replace_at
def test_replace_at():
    ast1 = ast.parse("def f(x):\n    a = 2\n    b = 3\n    return a + b")
    node = find(ast1, ast.Return).__next__()
    assert(isinstance(node, ast.Return))  # type: ignore
    parent, index = get_non_exp_parent_and_index(ast1, node)
    ast2 = ast.Expression(ast.BinOp(ast.Name(id='a', ctx=ast.Load()),
                                    ast.Add(),
                                    ast.Name(id='b', ctx=ast.Load())))
    replace_at(index, parent, ast2)
    assert(isinstance(parent.body[index], ast.Expr))  # type: ignore