

# Generated at 2022-06-12 04:47:31.915635
# Unit test for function find
def test_find():
    tree = ast.parse("""
    a = 1
    b = 2
    if a != b:
        b = a
    print(a + b)
    """)  # type: ast.Module

    for des in find(tree, ast.AnnAssign):
        print('Annotation assignment:', des)

    for des in find(tree, ast.Assign):
        print('Assignment:', des)

    for des in find(tree, ast.Assign):
        print('Assignment:', des)

# Generated at 2022-06-12 04:47:35.032276
# Unit test for function find
def test_find():
    tree = ast.parse('ss = 2')
    s = next(find(tree, ast.Assign))
    assert s.value.n == 2



# Generated at 2022-06-12 04:47:45.473317
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # test case 1
    tree = ast.parse('x=1').body[0]
    result = get_non_exp_parent_and_index(tree, tree.value)
    assert result == (tree, 0)

    # test case 2
    tree = ast.parse('x=x+1').body[0]
    result = get_non_exp_parent_and_index(tree, tree.value)
    assert result == (tree, 0)

    # test case 3
    tree = ast.parse('x=x+1').body[0]
    result = get_non_exp_parent_and_index(tree, tree.value.left)
    assert result == (tree, 0)

    # test case 4
    tree = ast.parse('x=x+1').body[0]
    result = get_non_

# Generated at 2022-06-12 04:47:54.143825
# Unit test for function find
def test_find():
    tree = ast.parse(' x = 1/2 + 1')
    result = list(find(tree, ast.BinOp))
    assert len(result) == 1
    assert isinstance(result[0], ast.BinOp)
    assert isinstance(result[0].left, ast.Num)
    assert result[0].left.n == 1
    assert isinstance(result[0].op, ast.Div)
    assert isinstance(result[0].right, ast.BinOp)
    assert isinstance(result[0].right.left, ast.Num)
    assert result[0].right.left.n == 2
    assert isinstance(result[0].right.op, ast.Add)
    assert isinstance(result[0].right.right, ast.Num)

# Generated at 2022-06-12 04:48:02.117190
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('a = 1', '<source>', 'eval'), ast.AST))) == 1
    assert len(list(find(ast.parse('a = 1', '<source>', 'eval'),
                          ast.Expression))) == 1
    assert len(list(find(ast.parse('a = 1', '<source>', 'eval'),
                          ast.Module))) == 1
    assert len(list(find(ast.parse('a = 1', '<source>', 'eval'),
                          ast.Name))) == 1

# Generated at 2022-06-12 04:48:12.196370
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    with open('examples/test_get_non_exp_parent_and_index.py') as f:
        tree = ast.parse(f.read())
    for i, item in enumerate([4, 6, 8]):
        parent, index = get_non_exp_parent_and_index(tree, tree.body[item])
        assert (parent, index) == (tree.body[0], i), 'Fail test: {}'.format(i)
    for i, item in enumerate([9, 11, 13]):
        parent, index = get_non_exp_parent_and_index(tree, tree.body[1].body[item])
        assert (parent, index) == (tree.body[1], i), 'Fail test: {}'.format(i)


# Generated at 2022-06-12 04:48:14.038640
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index"""
    assert True



# Generated at 2022-06-12 04:48:24.158985
# Unit test for function find

# Generated at 2022-06-12 04:48:27.880535
# Unit test for function find
def test_find():
    assert list(find(ast.parse("a = 1"), ast3.Name)) == \
        [ast3.Name(id='a', ctx=ast3.Store())]

# Generated at 2022-06-12 04:48:31.169234
# Unit test for function get_parent
def test_get_parent():
    import argparse

    parser = argparse.ArgumentParser(
        description='Get the parent of a node in your tree.')
    parser.add_argument('node', help='Input node.')
    parser.add_argument('tree', help='Input tree.')
    args = parser.parse_args()

    print(get_parent(args.node, args.tree))

# Generated at 2022-06-12 04:48:40.965756
# Unit test for function find
def test_find():
    node = ast.parse('from a import d')
    node1 = ast.copy_location(ast.parse('import ast'), node)
    node2 = ast.copy_location(ast.parse('from b import e'), node)
    insert_at(0, node, node1)
    insert_at(1, node, node2)
    find_results = list(find(node, ast.Import))
    assert node1 in find_results
    assert node2 in find_results

# Generated at 2022-06-12 04:48:41.953270
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:44.499257
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import typed_ast.ast3 as ast


# Generated at 2022-06-12 04:48:45.466036
# Unit test for function find

# Generated at 2022-06-12 04:48:55.155292
# Unit test for function get_parent
def test_get_parent():
    module = ast.parse("""
    def func():
        for i in range(10):
            print(i)
            if i == 5:
                print("I equals 5")
            else:
                continue
    """)
    body = module.body[0]
    assert get_parent(module, body) == module
    assert get_parent(module, body.body[0]) == body
    assert get_parent(module, body.body[0].body[0]) == body.body[0]
    assert get_parent(module, body.body[0].body[-1].body[0]) == body.body[0]



# Generated at 2022-06-12 04:49:00.153495
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("print(a)\n", mode="exec")
    tree.body.insert(0, ast.parse("a = 1", mode="exec").body[0])
    print(ast.unparse(tree))
    # tree = insert_at(0, tree, ast.parse("a = 1", mode="exec").body[0])
    # print(ast.unparse(tree))


# Generated at 2022-06-12 04:49:05.255203
# Unit test for function find
def test_find():
    func_find = find(ast.parse(('def f(x):\n'
                                '    for i in range(x):\n'
                                '        y=i **2')), ast.FunctionDef)
    assert next(func_find).name == 'f'


# Generated at 2022-06-12 04:49:15.925950
# Unit test for function find
def test_find():
    import astunparse
    import sys

    body = [ast.Expr(ast.Num(1)), ast.Expr(ast.Num(2)),
            ast.Expr(ast.Num(3)), ast.Expr(ast.Num(4))]
    tree = ast.FunctionDef(name='main', body=body, decorator_list=[],
                           args=ast.arguments(args=[], vararg=None,
                                              kwonlyargs=[], kw_defaults=[],
                                              kwarg=None, defaults=[]))

    def find_test() -> None:
        n = find(tree, ast.Num)
        assert isinstance(n, Iterable)
        assert len(list(n)) == 4
        print("Test passed")

    find_test()
    find_test()

# Generated at 2022-06-12 04:49:17.541437
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import test.unit_test
    assert test.unit_test.run_asserts_and_return_test_results()

# Generated at 2022-06-12 04:49:18.475847
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:49:24.733816
# Unit test for function find
def test_find():
    tree = ast.parse('''
    def foo(a, b, c):
        pass
    ''')
    foo_func = find(tree, ast.FunctionDef).__next__()
    assert foo_func.name == 'foo'



# Generated at 2022-06-12 04:49:27.001156
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert get_closest_parent_of(ast.parse("""
        def foo():
            if True:
                pass
    """), ast.Pass(), ast.FunctionDef)



# Generated at 2022-06-12 04:49:38.166966
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:49:39.084701
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:49:48.839748
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    class A(ast.AST):
        _fields = ('body',)

    class B(ast.AST):
        _fields = ('body',)

    class C(ast.AST):
        _fields = ('body',)

    tree = A(body=[
        B(body=[
            ast.Expr(ast.Call(None, None, [])),
            C(body=[
                ast.Expr(ast.Num(1)),
                ast.Expr(ast.Num(2))
            ])
        ])
    ])

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert isinstance(parent, A), "Coudn't get parent of the Expr body."
    assert index == 0, "Coudn't get the index of the Expr."

    parent,

# Generated at 2022-06-12 04:49:51.041414
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('').body[0]
    assert (get_non_exp_parent_and_index(ast.parse(''), node)
                   == (node, 0))

# Generated at 2022-06-12 04:49:52.372522
# Unit test for function find
def test_find():
    print('testing find')

# Generated at 2022-06-12 04:49:58.386129
# Unit test for function get_parent
def test_get_parent():
    def func():
        return True

    tree = ast.parse(func.__code__)
    return_node = get_parent(tree, tree.body[0].body[0])

    assert isinstance(return_node, ast.FunctionDef)

    try:
        get_parent(tree, ast.Name(id=0, ctx=None))
    except NodeNotFound:
        assert True
    else:
        assert False



# Generated at 2022-06-12 04:50:01.752222
# Unit test for function find
def test_find():
    node = ast.parse('for i in range(10):\n pass')

    assert len(list(find(node, ast.For))) == 1
    assert len(list(find(node, ast.FunctionDef))) == 0
    assert len(list(find(node, ast.Load))) == 6



# Generated at 2022-06-12 04:50:07.814840
# Unit test for function get_parent
def test_get_parent():
    import astor
    code = astor.to_source(ast.parse('''
if True == False:
    pass
    '''))
    root = ast.parse(code)
    assert(get_parent(root, root.body[0]).__class__.__name__ == 'Module')
    assert(get_parent(root, ast.parse(code).body[0].body[0]).__class__.__name__ == 'If')
    return


# Generated at 2022-06-12 04:50:17.835969
# Unit test for function find
def test_find():
    code = '''
a = 1 + 2 * 3
'''
    tree = ast.parse(code)
    nodes = find(tree, ast.BinOp)
    assert nodes.__length_hint__() == 1, 'only one BinOp node in example'
    assert next(nodes).op.__class__.__name__ == 'Mult'

# Generated at 2022-06-12 04:50:21.200869
# Unit test for function find
def test_find():
    tr = ast.parse('x=1\ny=2\nx=3\n')
    assert len(list(find(tr, ast.Assign))) == 3


# Generated at 2022-06-12 04:50:22.564505
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:50:31.470563
# Unit test for function replace_at
def test_replace_at():
    """
    foo(1, 'test', bar(test))
    """
    # Create AST
    funcdef = ast.FunctionDef(name='foo', args=ast.arguments(),
                              body=[ast.Expr(value=ast.Call(
                                  func=ast.Name(id='bar', ctx=ast.Load()),
                                  args=[ast.Name(id='test', ctx=ast.Load())],
                                  keywords=[])),
                                  ast.Return()])
    call = ast.Call(func=ast.Name(id='foo', ctx=ast.Load()),
                    args=[ast.Num(n=1), ast.Str(s='test')],
                    keywords=[])
    # Replace second argument
    replace_at(1, call, ast.Str(s='test2'))
    # Replace

# Generated at 2022-06-12 04:50:38.967521
# Unit test for function replace_at
def test_replace_at():
    # test is to ensure that replacement of the node works properly and
    # that the clone is working properly
    import copy 
    x = ast.parse("1 + 2")
    y = copy.deepcopy(x)
    parent3 = x.body[0]
    for i in range(len(parent3.body)):
        if isinstance(parent3.body[i],ast.Expr):
            child = parent3.body[i]
            #print(parent3.body[i].value)
            parent3.body[i].value = ast.Num(n=42) #type: ignore
            print(child.value)
            y_child = y.body[0].body[i]
            print(y_child.value)
    assert child.value.n == 42
    assert y_child.value.n == 2

# Generated at 2022-06-12 04:50:42.551594
# Unit test for function find
def test_find():
    import astor

    tree = ast.parse("[i for i in range(10)]")
    print(astor.to_source(tree))
    assert len(list(find(tree, ast.ListComp))) == 1
    assert len(list(find(tree, ast.Name))) == 3

# Generated at 2022-06-12 04:50:44.381662
# Unit test for function find
def test_find():
    tree = ast.parse('a + b')
    assert isinstance(find(tree, ast.Str), Iterable)

# Generated at 2022-06-12 04:50:51.901511
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = '''
if True:
    a = 1
    if True:
        a = 1
    a = 1
    if True:
        a = 1
'''

    tree = ast.parse(source)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[2], ast.If), ast.If)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[4], ast.If), ast.If)

# Generated at 2022-06-12 04:51:00.891496
# Unit test for function find
def test_find():
    tree = ast.parse('a = [1,2,3]; seq = (1,2,3); '
                     'set = {1,2,3,4}; dict = {"key1":"val1","key2":"val2"};')
    a = list(find(tree, ast.List))[0]
    b = list(find(tree, ast.Tuple))[0]
    c = list(find(tree, ast.Set))[0]
    d = list(find(tree, ast.Dict))[0]
    assert a is not b and a is not c and a is not d
    assert b is not c and b is not d
    assert c is not d


# Generated at 2022-06-12 04:51:02.262143
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest

    

# Generated at 2022-06-12 04:51:15.502861
# Unit test for function find
def test_find():
    tree = ast.parse('def foo(): x = 1')
    assert find(tree, ast.FunctionDef)

# Generated at 2022-06-12 04:51:18.377348
# Unit test for function find
def test_find():
    def test(a, b):
        pass

    tree = ast.parse(test.__code__)
    pass_ = next(find(tree, ast.Pass))
    assert pass_.lineno == 3

# Generated at 2022-06-12 04:51:21.512124
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    body = ast.parse('def func():\n    a = 1').body

    assert get_non_exp_parent_and_index(body, body[0].body[0].targets[0]) ==\
        (body[0], 0)

# Generated at 2022-06-12 04:51:26.366304
# Unit test for function find
def test_find():
    for node in find(ast.parse('1 + 1'), ast.BinOp):
        assert isinstance(node, ast.BinOp)

    for node in find(ast.parse('1 + 1'), ast.Num):
        assert isinstance(node, ast.Num)


# Generated at 2022-06-12 04:51:32.209215
# Unit test for function get_parent
def test_get_parent():
    test_source = '''
    test = 1
    # this is a comment
    '''
    tree = ast.parse(test_source)
    assert tree == get_parent(tree, tree)
    assert tree.body[0] == get_parent(tree, tree.body[0])
    assert tree.body[1] == get_parent(tree, tree.body[1])


# Generated at 2022-06-12 04:51:38.756905
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert (get_non_exp_parent_and_index(ast.parse(
        'def foo(a): return a'),
        ast.parse('return a').body[0].value)
        == (ast.parse('def foo(a): return a'), 0))

    assert (get_non_exp_parent_and_index(ast.parse(
        'if True:\n    return a'),
        ast.parse('return a').body[0].value)
        == (ast.parse('if True:\n    return a').body[0], 0))



# Generated at 2022-06-12 04:51:45.628568
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def f(a):
        a.append(a.append)  # noqa

    node = ast.parse(inspect.getsource(f)).body[0].body[0].value.args[0]
    tree = ast.parse(inspect.getsource(f))
    non_exp_parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(non_exp_parent, ast.FunctionDef)
    assert index == 0

# Generated at 2022-06-12 04:51:47.938786
# Unit test for function find
def test_find():
    a = ast.parse('def x():\n    return x')
    list_ = list(find(a, ast.Name))
    assert len(list_) == 1
    assert list_[0].id == 'x'

# Generated at 2022-06-12 04:51:49.324841
# Unit test for function find

# Generated at 2022-06-12 04:51:50.564351
# Unit test for function find
def test_find():
    find(tree=None, type_=None)


# Generated at 2022-06-12 04:52:22.566266
# Unit test for function find
def test_find():
    from ..module import from_source
    from typed_ast import ast3 as ast

    source = """
    def a(x: int) : int
        return x
        
    def b(y: str) -> str:
        with open(y) as f:
            return f.read()
    """

    tree = from_source(source)

    assert len(list(find(tree, ast.FunctionDef))) == 2
    assert len(list(find(tree, ast.Name))) == 6
    assert len(list(find(tree, ast.Load))) == 5
    assert len(list(find(tree, ast.Store))) == 0



# Generated at 2022-06-12 04:52:25.964752
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent."""
    root = ast.parse('def f(): pass')
    funcdef = root.body[0]
    suite = funcdef.body
    assert(get_parent(root, funcdef) is root)
    assert(get_parent(root, suite) is funcdef)



# Generated at 2022-06-12 04:52:31.313940
# Unit test for function find
def test_find():
    # test if lits of functions are found or not
    assert_equals(list(find(ast.parse('def f(x): return x'), ast.FunctionDef)),
                  [ast.parse('def f(x): return x').body[0]])
    # test if 2 functions are found or not
    assert_equals(list(find(ast.parse(
        'def a(x): return x\ndef b(x): return x'), ast.FunctionDef)),
        [ast.parse('def a(x): return x').body[0],
            ast.parse('def b(x): return x').body[0]])



# Generated at 2022-06-12 04:52:33.448231
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('x = 1 + 2')

    assert get_parent(tree, tree.body[0].value) == tree.body[0]



# Generated at 2022-06-12 04:52:40.924322
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = (1, 2, 3)', '', 'eval')
    tup = tree.body[0].value
    replace_at(1, tup, ast.Tuple([ast.Num(4)], ast.Load()))

    assert ast.dump(tree) == "Expression(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Tuple(elts=[Num(n=1), Tuple(elts=[Num(n=4)], ctx=Load()), Num(n=3)], ctx=Load()))])"  # noqa: E501

# Generated at 2022-06-12 04:52:41.517664
# Unit test for function find

# Generated at 2022-06-12 04:52:47.839691
# Unit test for function replace_at
def test_replace_at():
    def function_unit_test():
        ast_ = ast.parse('1 + 2 + 3')
        parent, index = get_non_exp_parent_and_index(ast_, ast_.body[0].value)
        replace_at(index, parent, ast.parse('4 + 5').body[0].value)
        assert ast.dump(ast_) == ast.dump(ast.parse('4 + 5 + 3'))

    def cls_body_test():
        ast_ = ast.parse('class A:\n  1 + 2 + 3')
        parent, index = get_non_exp_parent_and_index(ast_, ast_.body[0].body[0])
        replace_at(index, parent, ast.parse('4 + 5').body[0].value)
        assert ast.dump(ast_) == ast

# Generated at 2022-06-12 04:52:48.686034
# Unit test for function get_parent

# Generated at 2022-06-12 04:52:54.064975
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')
    replace_at(0, tree, ast.parse('a = 1 - 1').body)  # type: ignore

    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=BinOp(left=Num(n=1), op=Sub(), right=Num(n=1)))])'

# Generated at 2022-06-12 04:53:04.361619
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    """
    def foo(x):
        if x == 'a':
            return x
    """
    code = "def foo(x):\n\tif x == 'a':\n\t\treturn x"
    tree = ast.parse(code)
    node = tree.body[0].body[0]

    if not isinstance(node, ast.If):
        raise ValueError("node is not ast.If")

    func = get_closest_parent_of(tree, node.body[0], ast.FunctionDef)
    print("func: {}".format(astor.to_source(func)))


if __name__ == '__main__':
    test_get_closest_parent_of()

# Generated at 2022-06-12 04:54:07.512634
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Name()
    parent = ast.Module(body=[ast.Expr(value=node)])
    assert get_non_exp_parent_and_index(parent, node) == (parent, 0)

# Generated at 2022-06-12 04:54:13.663995
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module = ast.parse("x = 1 + 1; y = x + 1")
    plus_node = find(module, ast.BinOp).__next__()
    body_node, index = get_non_exp_parent_and_index(module, plus_node)
    assert body_node == module.body[0]
    assert index == 0


# Generated at 2022-06-12 04:54:14.531281
# Unit test for function find

# Generated at 2022-06-12 04:54:21.250872
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import parse_string

    tree = parse_string('''
        def fun(a: int, b: float) -> int:
            a + b
    ''')

    node = tree.body[0].body[0]
    funcdef = get_closest_parent_of(tree, node, ast.FunctionDef)

    assert funcdef.name == 'fun'
    assert funcdef.args.args[0].arg == 'a'
    assert funcdef.args.args[1].arg == 'b'



# Generated at 2022-06-12 04:54:30.544914
# Unit test for function replace_at
def test_replace_at():
    from ..utils import parse_function
    from unittest import TestCase, main

    class _Test(TestCase):
        def setUp(self) -> None:
            self.fn = parse_function('def f(x):\n    return x * 2')

        def test__replace_at(self):
            self.assertEqual(self.fn.body[0].body[0].value.args[0].id, 'x')
            replace_at(0, self.fn.body[0], ast.Name(id='z', ctx=ast.Load()))
            self.assertEqual(self.fn.body[0].body[0].value.args[0].id, 'z')

    main()

# Generated at 2022-06-12 04:54:32.062431
# Unit test for function find

# Generated at 2022-06-12 04:54:41.810475
# Unit test for function replace_at
def test_replace_at():
    import typed_astunparse
    import ast
    import sys

    def test_insert_at(index, nodes, parent, expected):
        import ast
        import sys
        parent = ast.parse(parent)
        if sys.version_info >= (3, 8):
            nodes, expected = ast.parse(nodes), ast.parse(expected)
        else:
            nodes, expected = ast.parse(nodes).body, ast.parse(expected).body
        replace_at(index, parent, nodes)
        assert typed_astunparse.dump(parent) == typed_astunparse.dump(expected)

    test_insert_at(0, "a = 1", "a, b = 1, 2", "a = 1, b = 2\n")

# Generated at 2022-06-12 04:54:44.628865
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse("""
        x = 1
        y = 2
        z = 3
    """)  # type: ignore
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    print("Successfully ran test_get_parent")



# Generated at 2022-06-12 04:54:45.113614
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    pass

# Generated at 2022-06-12 04:54:46.076908
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:57:18.588301
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # pass
    """
    test_code = ast.parse("""
nodes = []
for x in y:
    if m > 1:
        pass
    else:
        nodes.append(x)
    if m > 2:
        pass
    else:
        nodes.append(x)
    if m > 3:
        pass
    else:
        nodes.append(x)
    if m > 4:
        pass
    else:
        nodes.append(x)
    if m > 5:
        pass
    else:
        nodes.append(x)
    if m > 6:
        pass
    else:
        nodes.append(x)
    if m > 7:
        pass
    else:
        nodes.append(x)
    if m > 8:
        pass
    else:
        nodes