

# Generated at 2022-06-12 04:47:30.608138
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def function1(x):
        return 3*x
    f1 = ast.FunctionDef(name='function1',
                        args=ast.arguments(
                            args=[ast.arg(arg='x')],
                            vararg=None,
                            kwonlyargs=[],
                            kwarg=None,
                            defaults=[],
                            kw_defaults=[],
                        ),
                        body=[
                            ast.Return(
                                value=ast.BinOp(
                                    left=ast.Constant(value=3, kind=None),
                                    op=ast.Mult(),
                                    right=ast.Name(id='x', ctx=ast.Load()),
                                )
                            ),
                        ],
                        decorator_list=[],
                        returns=None)

    assert get_non_exp

# Generated at 2022-06-12 04:47:37.858543
# Unit test for function get_parent
def test_get_parent():
    # tree = ast.parse("""\n_init_model = nn.Module()\n""")
    # _build_parents(tree)
    # print(_parents[tree.body[0].value])
    # print(get_parent(tree, tree.body[0].value))
    # print(get_parent(tree, tree))
    # print(get_parent(tree, tree.body[0].value))
    pass


# Generated at 2022-06-12 04:47:45.534050
# Unit test for function replace_at
def test_replace_at():
    parent = ast.Module()
    parent.body.append(ast.FunctionDef('test', [], [], []))
    replace_at(0, parent, [ast.FunctionDef('test1', [], [], []),
                           ast.FunctionDef('test2', [], [], [])])
    assert len(parent.body) == 2
    assert type(parent.body[0]) == ast.FunctionDef
    assert type(parent.body[1]) == ast.FunctionDef
    assert parent.body[0].name == 'test1'
    assert parent.body[1].name == 'test2'

# Generated at 2022-06-12 04:47:46.588784
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:47:50.264508
# Unit test for function find
def test_find():
    def func():
        print('Hello')
        print('World')
        a = 1
        b = 2

    tree = ast.parse(func.__code__.co_consts[0])
    assert len(list(find(tree, ast.Print))) == 2


# Generated at 2022-06-12 04:48:03.565139
# Unit test for function get_parent
def test_get_parent():
    class DummyClass(ast.AST):
        _fields = ('body',)

    ast_tree = ast.parse("""\
    def foo():
        bar = 0
        bar += 2
    """)

    node = get_closest_parent_of(ast_tree, ast_tree.body[0].body[1].targets[0],
                                 ast.FunctionDef)
    parent = ast_tree.body[0]
    assert get_parent(ast_tree, node) == parent

    node = get_closest_parent_of(ast_tree, ast_tree.body[0].body[1].targets[0],
                                 ast.FunctionDef)
    parent = ast_tree.body[0]
    assert get_parent(ast_tree, node) == parent

    node = get_cl

# Generated at 2022-06-12 04:48:04.518367
# Unit test for function get_parent

# Generated at 2022-06-12 04:48:05.178902
# Unit test for function find
def test_find():
    assert 0

# Generated at 2022-06-12 04:48:10.251084
# Unit test for function find
def test_find():
    ast_str = "def hello(x): return x + 1"
    tree = ast.parse(ast_str)
    assert find(tree, ast.FunctionDef)
    ast_str = "x = hello(x)"
    tree = ast.parse(ast_str)
    assert not find(tree, ast.FunctionDef)


# Generated at 2022-06-12 04:48:12.589960
# Unit test for function find
def test_find():
    assert isinstance(next(find(ast.parse('a = 1'), ast.Assign)), ast.Assign)



# Generated at 2022-06-12 04:48:23.566615
# Unit test for function find
def test_find():
    global _parents
    _parents.clear()

    class TestClass(ast.AST):
        _fields = ('a')

    class Class(ast.AST):
        _fields = ('s', 'f', 'g')
        body = [TestClass()]

    class Module(ast.AST):
        _fields = ('body',)
        body = [Class()]

    tree = Module()
    assert list(find(tree, Class)) == [tree.body[0]]
    assert list(find(tree, TestClass)) == [tree.body[0].body[0], ]

# Generated at 2022-06-12 04:48:24.144216
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():

    pass

# Generated at 2022-06-12 04:48:34.705729
# Unit test for function replace_at
def test_replace_at():
    """Tests the behavior of replace_at."""
    some_parent = ast.FunctionDef(name='some_parent',
                                  body=[ast.Expr(value=ast.Name(id='foo',
                                                                ctx=ast.Load))],
                                  decorator_list=[],
                                  args=ast.arguments(
                                      args=[], vararg=None, kwonlyargs=[],
                                      kw_defaults=[], kwarg=None, defaults=[]))
    tree = ast.Module(body=[ast.Expr(value=ast.Num(n=0)),
                            some_parent,
                            ast.Expr(value=ast.Num(n=1))])


# Generated at 2022-06-12 04:48:36.870150
# Unit test for function find
def test_find():
    from .node_builder import create_module
    m = create_module(""" foo = "baz" """)
    assert len(list(find(m, ast.Name))) == 1

# Generated at 2022-06-12 04:48:42.700292
# Unit test for function find
def test_find():
    # type: () -> None
    source = 'def foo(a, b):\n    print(a + b)\n'
    tree = ast.parse(source)

    assert list(find(tree, ast.FunctionDef))[0].name == 'foo'
    assert list(find(tree, ast.Load))[0].value.id == 'print'



# Generated at 2022-06-12 04:48:46.531617
# Unit test for function insert_at
def test_insert_at():
    t = ast.parse("""x = y + 1""").body[0]  # type: ignore

    insert_at(1, t.right, ast.Name(id="z"))

    assert t.right.elts[1].id == "z"  # type: ignore


# Generated at 2022-06-12 04:48:50.694960
# Unit test for function get_parent
def test_get_parent():
    def f():
        pass

    tree = ast.parse('''def f():
        pass''')
    func_body = get_parent(tree, tree.body[0].body[0])
    assert func_body == tree.body[1]



# Generated at 2022-06-12 04:48:51.397408
# Unit test for function find

# Generated at 2022-06-12 04:48:53.816930
# Unit test for function find
def test_find():
    tree = ast.parse('a + 1')
    assert list(find(tree, ast.BinOp)) == [tree.body[0].value]

# Generated at 2022-06-12 04:49:01.621508
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    import astor

    def f(x):
        pass

    tree = ast.parse(inspect.getsource(f))

    found = set(i.id for i in find(tree, ast.Name))
    expected = {
        'x',
        'f',
        'FunctionDef',
        'ast',
        'set',
        'inspect',
        'getattr',
        'getsource',
        'Module',
        'parse',
        'Module',
        'set',
        'FunctionDef',
        'Name',
        'FunctionDef',
        'Name',
        'Pass'
    }

    print(expected - found)

    print(set(map(lambda x: type(x), _parents.values())))


# Generated at 2022-06-12 04:49:05.937151
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:49:12.209309
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('x = 1 + 2', mode='eval')
    tree = ast.parse('x = 1 + 2')
    tree.body[0].body.append(node.body[0])
    node_to_check = tree.body[0].body[0].value.left
    parent, index = get_non_exp_parent_and_index(tree, node_to_check)
    assert parent == node.body[0]
    assert index == 1



# Generated at 2022-06-12 04:49:17.147136
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = """\
    if True:
        var = 1
        var2 = 2

    if True:
        var3 = 3
    """
    tree = ast.parse(code)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[1].value) \
        == (tree.body[0], 1)

# Generated at 2022-06-12 04:49:26.876252
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
        funcdef = FunctionDef(arguments=[arguments],
                      body=[Expr(value=Call(func=Name(id='add',
                                                        ctx=Load()),
                                            args=[Name(id='a',
                                                       ctx=Load()),
                                                  Name(id='b',
                                                       ctx=Load())],
                                            keywords=[],
                                            starargs=None,
                                            kwargs=None)),
                            Return(value=Name(id='total',
                                              ctx=Load()))],
                      decorator_list=[],
                      name='func')''')

    funcdef = tree.body[0]
    return_ = funcdef.body[-1]

    parent, index = get_non_exp_parent_and

# Generated at 2022-06-12 04:49:32.305751
# Unit test for function find
def test_find():
    tree = ast.parse('if var:    var = True\nelse:    var = False')

    found_if = list(find(tree, ast.If))
    assert len(found_if) == 1

    found_assign = list(find(tree, ast.Assign))
    assert len(found_assign) == 2


# Generated at 2022-06-12 04:49:36.471016
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_body = ast.parse('if a:\n    pass\nif b:\n    pass').body  # type: ignore
    assert get_non_exp_parent_and_index(test_body[0], test_body[0].body[0]) == \
        (test_body[0], 0)

# Generated at 2022-06-12 04:49:42.547401
# Unit test for function find
def test_find():
    """
    def foo():
        print("foo")
        def bar():
            print("bar")
            def baz():
                pass
    """
    tree = ast.parse("""
    def foo():
        print("foo")
        def bar():
            print("bar")
            def baz():
                pass
    """)

    assert len(list(find(tree, ast.FunctionDef))) == 3
    assert len(list(find(tree, ast.Name))) == 2

# Generated at 2022-06-12 04:49:46.307861
# Unit test for function get_parent
def test_get_parent():
    node = ast.Module(body=[ast.Expr(value=ast.Str('test')),
                            ast.Expr(value=ast.Str('another'))])
    parent = get_parent(node, node.body[0])

    assert parent == node


# Generated at 2022-06-12 04:49:50.440568
# Unit test for function find
def test_find():
    print("Running unit test for find")
    test_tree = ast.parse("""
    def func():
        pass
        pass
    """)

    counter = 0
    for node in find(test_tree, ast.Pass):
        counter += 1
        print(node)
    assert counter == 2
    print("Passed unit test")


# Generated at 2022-06-12 04:49:52.106922
# Unit test for function find

# Generated at 2022-06-12 04:50:03.780553
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def test(): pass')
    node = next(find(tree, ast.Name))
    assert get_closest_parent_of(tree, node, ast.FunctionDef) is tree.body[0]

# Generated at 2022-06-12 04:50:06.670147
# Unit test for function find
def test_find():
    f = ast.parse('def f(g): pass')
    r = [type(n) for n in find(f, ast.FunctionDef)]
    assert r == [ast.FunctionDef]



# Generated at 2022-06-12 04:50:13.215873
# Unit test for function get_parent
def test_get_parent():
    code = 'def fun(a, b):\n    if a:\n        return b'
    tree = ast.parse(code)
    return_node = find(tree, ast.Return).__next__()
    if_node = find(tree, ast.If).__next__()
    assert get_parent(tree, return_node) ==\
        code.split('\n')[2] == if_node.body[0]



# Generated at 2022-06-12 04:50:20.952887
# Unit test for function get_parent
def test_get_parent():
    pass
#     class A:
#         class B:
#             class C:
#                 class D:
#                     print(get_parent(A, B))
#                     print(get_parent(A, C))
#                     print(get_parent(A, D))
#                     print(get_parent(B, C))
#                     print(get_parent(C, D))
#                 print(get_parent(A, C))
#                 print(get_parent(B, C))
#                 print(get_parent(C, D))
#             print(get_parent(A, B))
#             print(get_parent(B, C))
#             print(get_parent(C, D))
#         print(get_parent(A, B))
#         print(get_parent(B, C))
#         print

# Generated at 2022-06-12 04:50:30.563054
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typed_ast import ast3 as ast
    from tests.test_util import assert_ast_equal, dump_ast
    from typed_astunparse import unparse

    code = """\
        def test(arg1: int, arg2: str):
            if arg1 > 0:
                if arg2:
                    return arg1 + 1
                else:
                    return arg1 + 2
            else:
                return arg1 + 3
        """

    expected_code = """\
        def test(arg1: int, arg2: str):
            if arg1 > 0:
                if arg2:
                    return arg1 + 1
                else:
                    return arg1 + 2
            else:
                return arg1 + 3
        """

    tree = ast.parse(code)

# Generated at 2022-06-12 04:50:34.649113
# Unit test for function find
def test_find():
    from .. import parse
    from . import nodes

    tree = parse("def f():\n    pass")

    for node in find(tree, nodes.FunctionDef):
        assert isinstance(node, nodes.FunctionDef)

    for node in find(tree, nodes.Stmt):
        assert isinstance(node, nodes.Stmt)

# Generated at 2022-06-12 04:50:40.247106
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_tree = ast.parse(
        'def add(a):\n'
        '    b = 2\n'
        '    return a + b')
    test_node = ast.parse('b = 2').body[0]

    result = get_closest_parent_of(test_tree, test_node, ast.FunctionDef)
    assert result == test_tree.body[0]



# Generated at 2022-06-12 04:50:41.265020
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:50:47.093747
# Unit test for function find
def test_find():
    import astor
    tree = ast.parse('''
if True:
    print(10)
else:
    print(20)
''')
    assert len(list(find(tree, ast.If))) == 1
    assert len(list(find(tree, ast.Expr))) == 2
    assert len(list(find(tree, ast.Call))) == 2
    assert len(list(find(tree, ast.For))) == 0

# Generated at 2022-06-12 04:50:54.415775
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    exp = astor.parse_file('test/test_get_parent.py')
    _build_parents(exp)
    nodes = []
    for node in exp.body[0].body:
        if isinstance(node, ast.Assign):
            nodes.append(node)
        elif isinstance(node, ast.Expr):
            nodes.append(node)
        elif isinstance(node, ast.If):
            nodes.append(node.body[0])
        elif isinstance(node, ast.For):
            nodes.append(node.body[0])
        elif isinstance(node, ast.While):
            nodes.append(node.body[0])
        elif isinstance(node, ast.FunctionDef):
            nodes.append(node.body[0])
        el

# Generated at 2022-06-12 04:51:13.782800
# Unit test for function replace_at
def test_replace_at():

    def function_with_return():
        return 1
    
    tree = ast.parse(inspect.getsource(function_with_return))
    function_def = tree.body[0]
    return_ = function_def.body[0]

    replace_at(0, function_def, [ast.Expr(ast.Num(2))])
    assert function_def.body[0] == ast.Expr(ast.Num(2))


# Generated at 2022-06-12 04:51:17.915042
# Unit test for function find
def test_find():
    source = "a"
    tree = ast.parse(source)
    expr = find(tree, ast.Expr)
    assert list(expr) == [
        ast.Expr(
            value=ast.Str(s=''),
        ),
    ]



# Generated at 2022-06-12 04:51:24.404744
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class Empty:
        pass

    tree = ast.parse('[a for a in range(10) if a > 5]')
    for node in ast.walk(tree):
        if isinstance(node, ast.Expr):
            node.body = ast.parse('foo').body[0]
        if isinstance(node, ast.GeneratorExp):
            node.elt = ast.parse('a + b').body[0].value
        if isinstance(node, ast.Compare):
            node.ops[0] = ast.Gt()
        if isinstance(node, ast.Name):
            setattr(node, 'ctx', Empty())
            node.id = 'a'


# Generated at 2022-06-12 04:51:29.657623
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert (get_non_exp_parent_and_index(
        ast.parse('def x():\n pass\n pass\ndef y():\n pass'),
        ast.parse('pass').body[0]
    ) == (ast.parse('def x():\n pass\n pass\ndef y():\n pass'), 3))

# Generated at 2022-06-12 04:51:32.661353
# Unit test for function find
def test_find():
    tree = ast.parse("if a: b")
    assert isinstance(find(tree, ast.If).__next__(), ast.If)
    assert isinstance(find(tree, ast.Name).__next__(), ast.Name)



# Generated at 2022-06-12 04:51:33.789249
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-12 04:51:37.652318
# Unit test for function find
def test_find():
    import astor
    from ..ast_manipulation import find

    for node in find(ast.parse(
        """
        def foo():
            return 1
        """), ast.FunctionDef):
        print(astor.dump(node))

    # Output:
    # def foo():
    #     return 1

# Generated at 2022-06-12 04:51:42.241720
# Unit test for function find
def test_find():
    """Unit test for function find."""
    tree = ast.parse('def foo():\n    x = 1\n    if x < 1:\n        y = 3')

    assert len(list(find(tree, ast.Name))) == 4
    assert len(list(find(tree, ast.Num))) == 2


# Generated at 2022-06-12 04:51:49.499996
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
        def f():
            x = (1,
                2,
                3
            )
            y = 4
            z = 5
    """)

    parent = get_closest_parent_of(tree, tree.body[0].body[2].targets[0],
                                   ast.FunctionDef)

    assert(parent == tree.body[0])

    parent = get_closest_parent_of(tree, tree.body[0].body[2].targets[0],
                                   ast.Module)

    assert(parent == tree)


# Generated at 2022-06-12 04:51:55.487789
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1\nb = 2\nc = 3\nd = 4', '', 'exec')
    nodes = list(find(tree, ast.Num))
    assert len(nodes) == 4
    assert str(nodes[0]) == '1'
    assert str(nodes[1]) == '2'
    assert str(nodes[2]) == '3'
    assert str(nodes[3]) == '4'



# Generated at 2022-06-12 04:52:28.186560
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_ast = ast.parse("""if 1:
        if 2:
            if 3:
                4
            5""")
    node = test_ast.body[0].body[0].body[0].body[0]  # type: ignore
    parent, index = get_non_exp_parent_and_index(test_ast, node)
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-12 04:52:34.001231
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''
         def foo(a, b, c, *d):
             e = f.g.h(1, i=1)
             j.k(l, m)
         ''')

    _build_parents(tree)

    assert get_parent(tree, tree.body[0].body[0].values[0]) == \
        tree.body[0].body[0].targets[0]



# Generated at 2022-06-12 04:52:38.830577
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("def func():\n    x=1\n    y=2")
    assert get_non_exp_parent_and_index(tree, tree.body[0]) == (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == \
        (tree.body[0], 0)

# Generated at 2022-06-12 04:52:46.616801
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import sys
    import os
    sys.path.insert(0, os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
    from parser_lib.utils import parse
    from parser_lib.utils import get_closest_parent_of
    from parser_lib.utils import get_parent
    import astor
    statement = "locals()['obj'].funct()"
    tree = parse(statement)
    temp_ast = tree.body[0].value.func.value
    call_node = get_closest_parent_of(tree, temp_ast, ast.FunctionDef)
    assert astor.to_source(call_node) == "def funct():\n  pass"



# Generated at 2022-06-12 04:52:49.320844
# Unit test for function find
def test_find():
    '''
    find = _find(find)
    tree = ast.parse('find')
    module = find(tree, ast.Module)
    assert len(list(module)) == 1
    '''

# Generated at 2022-06-12 04:52:50.228881
# Unit test for function find
def test_find():
    pass



# Generated at 2022-06-12 04:52:51.886713
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor

# Generated at 2022-06-12 04:52:58.017203
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import inspect
    import astor
    source = """
        def add(a: int, b: int) -> str:
            c = a + b
            return c
    """
    module: ast.Module = ast.parse(source)
    node: ast.FunctionDef = module.body[0]
    parent = get_closest_parent_of(module, node.body[0], inspect.FunctionDef)
    assert parent == node, astor.dump(parent)

# Generated at 2022-06-12 04:53:02.549792
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo():\n pass')
    child = tree.body[0].body[0]
    assert get_closest_parent_of(tree, child, ast.FunctionDef) == tree.body[0]

# Generated at 2022-06-12 04:53:05.245419
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('1 + 1').body[0]
    tree = ast.parse('x = 1 + 1')
    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)



# Generated at 2022-06-12 04:54:13.490053
# Unit test for function find
def test_find():
    def test_func():
        pass


# Generated at 2022-06-12 04:54:21.488900
# Unit test for function replace_at
def test_replace_at():
    body = ast.parse('''
a = 1
b = 2
c = 3
    ''')
    parent = body.body[0]
    assert(body == ast.parse('''
a = b = 1
b = 2
c = 3
    '''))
    replace_at(0, body, ast.parse('''a = b = 1'''))
    assert(body == ast.parse('''
a = b = 1
b = 2
c = 3
    '''))
    replace_at(0, body, parent)
    assert(body == ast.parse('''
a = 1
b = 2
c = 3
    '''))

# Generated at 2022-06-12 04:54:27.618008
# Unit test for function find
def test_find():
    expr = ast.Expr(ast.Num(10))
    tree = ast.Module(body=[ast.Expr(ast.Name('a')), expr,
                            ast.Expr(ast.Name('b'))])
    result = list(find(tree, ast.Expr))
    assert len(result) == 3
    assert result[1] == expr

# Generated at 2022-06-12 04:54:31.596340
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    sample_node = ast.Assign(targets=[], value=ast.Num(n=0))
    sample_parent = ast.Expr(value=sample_node)
    sample_tree = ast.Module(body=[sample_parent])
    closest_parent = get_closest_parent_of(sample_tree, sample_node, ast.Module)
    assert closest_parent == sample_tree


# Generated at 2022-06-12 04:54:37.008225
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
    if True:
        print(42)
    ''')

    print_node = find(tree, ast.Print).next()
    parent, index = get_non_exp_parent_and_index(tree, print_node)

    assert parent.__class__ == ast.If
    assert index == 0



# Generated at 2022-06-12 04:54:39.803476
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = node = ast.parse('a = 47 + b').body[0]
    parent, index = get_non_exp_parent_and_index(tree, node.value)

    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-12 04:54:46.300682
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astunparse
    import os
    test_file = os.path.join(os.path.dirname(__file__), 'node_finder.py')
    with open(test_file) as f:
        ast_tree = ast.parse(f.read())

    ast_node = find(ast_tree, ast.FunctionDef).__next__()

    parent, index = get_non_exp_parent_and_index(ast_tree, ast_node)

    assert parent == ast_tree
    assert index == 0

    ast_node = find(ast.Module(body=parent.body[:index] + parent.body[index + 1:]),
                    ast.FunctionDef).__next__()

    parent, index = get_non_exp_parent_and_index(ast_tree, ast_node)


# Generated at 2022-06-12 04:54:47.211364
# Unit test for function replace_at

# Generated at 2022-06-12 04:54:56.303308
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('2 + 3 * 4 + 5 * 6').body[0].value
    res = get_non_exp_parent_and_index(node, node.left)

    assert isinstance(res[0], ast.Expr)
    assert res[1] == 0

    res = get_non_exp_parent_and_index(node, node.ops[0])
    assert isinstance(res[0], ast.Expr)
    assert res[1] == 0

    res = get_non_exp_parent_and_index(node, node.comparators[0])
    assert isinstance(res[0], ast.Expr)
    assert res[1] == 0

    res = get_non_exp_parent_and_index(node, node.right)

# Generated at 2022-06-12 04:54:57.342046
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent."""

# Generated at 2022-06-12 04:56:26.711115
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test for function get_non_exp_parent_and_index."""
    from ..visitors import ast3_visitor
    from ..exceptions import VisitorException

    code = '''
    def foo():
        a = 1
        if a == 1:
            b = 2
        else:
            b = 3
        c = a + b
    '''

    tree, _ = ast3_visitor.visit(code, visitor_cls=ast3_visitor.NameVisitor)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == \
        (tree.body[0], 0)

# Generated at 2022-06-12 04:56:30.892373
# Unit test for function find
def test_find():
    import astor
    code = 'x = 5\nif x < 0:\n    print("x is negative")\nelse:\n    print("x is positive")'
    tree = ast.parse(code)
    assert len(list(find(tree, ast.If))) == 1
    assert len(list(find(tree, ast.Name))) == 3


# Generated at 2022-06-12 04:56:39.456245
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astunparse
    import ast

    test_str = '''\
    def func(a):
        return a
    '''

    tree = ast.parse(test_str)
    func = tree.body[0]
    return_ = getattr(func, 'body')[0]
    return_ = ast.Expr(value=return_)
    return_ = ast.copy_location(return_, func)

    replace_at(0, func, return_)
    parent, index = get_non_exp_parent_and_index(tree, return_)

    assert parent.body[index].value == return_.value
    assert parent.body[index].value.value == return_.value.value

# Generated at 2022-06-12 04:56:42.876321
# Unit test for function find
def test_find():
    a = ast.parse('a = 1')
    assert len(list(find(a, ast.Assign))) == 1
    assert len(list(find(a, ast.Name))) == 1
    assert len(list(find(a, ast.Num))) == 1



# Generated at 2022-06-12 04:56:47.152685
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert get_closest_parent_of(
        ast.parse("def test():\n\tprint('test')\n\tprint('test')"),
        ast.parse("print('test')").body[0],
        ast.FunctionDef) == ast.parse("def test():\n\tprint('test')\n\tprint('test')").body[0]

# Generated at 2022-06-12 04:56:48.549730
# Unit test for function find
def test_find():
    import astor
    
    # Test for If in class body

# Generated at 2022-06-12 04:56:55.949448
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_ast = ast.parse(
        """
        class Test:
            def __init__(self):
                self.d = 0

            def f(self, x):
                return x + self.d

        def func():
            pass
        """
    )
    parent_f = get_closest_parent_of(test_ast, test_ast.body[0].body[2],
                                     ast.ClassDef)
    assert isinstance(parent_f, ast.ClassDef)
    parent_func = get_closest_parent_of(test_ast, test_ast.body[1],
                                        ast.FunctionDef)
    assert isinstance(parent_func, ast.FunctionDef)



# Generated at 2022-06-12 04:57:01.634011
# Unit test for function get_parent
def test_get_parent():
    def a():
        def b():
            def c():
                pass

        return c

    if get_parent(a, a) != a:
        print('test_get_parent failed')

    if get_parent(a, a()) != a:
        print('test_get_parent failed')

    if get_parent(a, a()()) != a():
        print('test_get_parent failed')

    if get_parent(a, a()()()) != a:
        print('test_get_parent failed')


# Generated at 2022-06-12 04:57:05.231106
# Unit test for function find
def test_find():
    node = ast.parse('a = 1\nreturn a')
    found_nodes = find(node, ast.Name)
    assert isinstance(found_nodes, Iterable)

    found_node = next(found_nodes)
    assert isinstance(found_node, ast.Name)
    assert found_node.id == 'a'

# Generated at 2022-06-12 04:57:08.162197
# Unit test for function find
def test_find():
    node = ast.Module(body=[ast.Expression(body=ast.Str(s='hi'))])
    result = list(find(node, ast.Str))
    assert len(result) == 1
