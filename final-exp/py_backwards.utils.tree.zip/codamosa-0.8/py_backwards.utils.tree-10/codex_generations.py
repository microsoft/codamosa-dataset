

# Generated at 2022-06-12 04:47:24.841077
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
    def foo():
        return 1 + 5
    ''')

    x = find(tree, ast.FunctionDef).__next__()
    name = x.name

    parent = get_closest_parent_of(tree, name, ast.FunctionDef)

    assert parent is x


# Generated at 2022-06-12 04:47:29.270662
# Unit test for function get_parent
def test_get_parent():
    a = ast.parse('a = 1')
    b = ast.parse('def b(): a = 1')

    assert get_parent(a, a.body[0]) == a
    assert get_parent(b, b.body[0]) == b


# Generated at 2022-06-12 04:47:30.018802
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:47:35.604477
# Unit test for function find
def test_find():
    i = 0
    for node in find(ast.parse('''
        def foo(x: int) -> int:
            return x
        ''', mode='exec'), ast.FunctionDef):
        i += 1
        assert node.name == 'foo'

    assert i == 1


# Generated at 2022-06-12 04:47:36.199750
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:47:39.740087
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent."""

    tree = ast.parse('x = 1')
    node = tree.body[0].targets[0]
    assert get_parent(tree, node) == tree.body[0]

# Generated at 2022-06-12 04:47:40.530436
# Unit test for function find

# Generated at 2022-06-12 04:47:43.432347
# Unit test for function get_parent
def test_get_parent():
    test_tree = ast.parse('foo')
    assert get_parent(test_tree, test_tree.body[0]) == test_tree


# Generated at 2022-06-12 04:47:52.616639
# Unit test for function get_parent
def test_get_parent():
    f = ast.parse('for i in x: print(i)')
    assert get_parent(f, f.body[0]).body[0] is f.body[0]
    assert get_parent(f, f.body[0].target).body[0] is f.body[0]

    f = ast.parse('def x(y=0): return y')
    assert get_parent(f, f.body[0]).body[0] is f.body[0]
    assert get_parent(f, f.body[0].body[0]).body[0] is f.body[0]
    assert get_parent(f, f.body[0].body[0].value).body[0] is f.body[0]

# Generated at 2022-06-12 04:47:54.753118
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    module = ast.parse('def f():\n  pass')
    assert get_non_exp_parent_and_index(module, module.body[0].body[0]) == (
        module.body[0], 0)



# Generated at 2022-06-12 04:48:08.009199
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    code = '''
some_function(some_param, 10)
    '''
    assert astor.to_source(
        get_non_exp_parent_and_index(ast.parse(code), ast.parse(code).body[0])[0]
    ) == 'Module(body=[Expr(value=Call(func=Name(id="some_function", ctx=Load()), args=[Name(id="some_param", ctx=Load()), Num(n=10)], keywords=[]))])'  # noqa

# Generated at 2022-06-12 04:48:15.618664
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''def foo():
    bar = 1
    print(bar)
''')

    node = tree.body[0].body[1].value

    f = lambda: get_closest_parent_of(tree, node, ast.Module)
    assert f() == tree

    f = lambda: get_closest_parent_of(tree, node, ast.FunctionDef)
    assert f() == tree.body[0]

    f = lambda: get_closest_parent_of(tree, node, ast.Assign)
    assert f() == tree.body[0].body[0]



# Generated at 2022-06-12 04:48:18.029509
# Unit test for function get_parent
def test_get_parent():
    mod = ast.parse("a = 1")
    assert get_parent(mod, mod).body[0].value.n == 1



# Generated at 2022-06-12 04:48:23.023734
# Unit test for function find
def test_find():
    """Test find function."""
    example_tree = ast.parse("""
    import sys
    import os

    def run():
        print("Hello world")

    run()
    """)

    # Should filter out the import sys import
    assert list(find(example_tree, ast.Import)) == [example_tree.body[1]]

# Generated at 2022-06-12 04:48:27.515023
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert ast.parse('a if a else b').body[0] == get_closest_parent_of(
        ast.parse('a if a else b'), ast.parse('a if a else b').body[0], ast.Module)

# Generated at 2022-06-12 04:48:30.801838
# Unit test for function find
def test_find():
    code = "a = 1 + 2"
    ast_obj = ast.parse(code)
    _build_parents(ast_obj)
    assert list(find(ast_obj, ast.Name))[0].id == "a"



# Generated at 2022-06-12 04:48:34.337353
# Unit test for function find
def test_find():
    import astor
    source = "def f90():\n    pass\n"
    pattern = ast.parse(source)
    tree = ast.parse(source)

    for node in find(pattern, ast.FunctionDef):
        node.name = 'f91'

    assert astor.to_source(tree) == astor.to_source(pattern)

# Generated at 2022-06-12 04:48:37.031271
# Unit test for function find
def test_find():
    import astor
    tree = astor.parse_file('tests/example.py')
    _build_parents(tree)
    for x in find(tree, ast.FunctionDef):
        print(astor.dump(x))



# Generated at 2022-06-12 04:48:38.518334
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:48:40.871289
# Unit test for function find
def test_find():
    a = ast.parse('for i in 0:0')
    assert len(list(find(a, ast.For))) == 1

# Generated at 2022-06-12 04:48:45.257212
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:56.970042
# Unit test for function find
def test_find():
    import ast as c_ast
    import sys
    import io
    import unittest

    class Test(unittest.TestCase):
        code = """\
    def a(x, y):
        return x + y
    """
        tree = c_ast.parse(code)
        _build_parents(tree)

        def test_find_return(self):
            returns = list(find(self.tree, ast.Return))
            self.assertEqual(len(returns), 1)

        def test_find_funcdef(self):
            defs = list(find(self.tree, ast.FunctionDef))
            self.assertEqual(len(defs), 1)

    # Replace the original stdout
    temp_out = io.StringIO()
    sys.stdout = temp_out

    # Run unit

# Generated at 2022-06-12 04:48:59.274995
# Unit test for function find
def test_find():
    tree = ast.parse('a = 1')
    nodes = list(find(tree, ast.Name))
    assert len(nodes) == 3



# Generated at 2022-06-12 04:48:59.882573
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert True

# Generated at 2022-06-12 04:49:03.467167
# Unit test for function find
def test_find():
    ast_tree = ast.parse('x: int = 5')
    assgin_nodes = list(find(ast_tree, ast.Assign))
    assert len(assgin_nodes) == 1


# Generated at 2022-06-12 04:49:14.001068
# Unit test for function get_parent
def test_get_parent():
    # Test 1
    parent1 = ast.Module(
        body=[
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=5),
            ),
            ast.If(
                test=ast.Compare(
                    left=ast.Num(n=3),
                    ops=[ast.Eq()],
                    comparators=[ast.Num(n=4)],
                ),
                body=[ast.Assign(
                    targets=[ast.Name(id='a', ctx=ast.Store())],
                    value=ast.Num(n=5),
                )],
                orelse=[],
            ),
        ],
    )

# Generated at 2022-06-12 04:49:15.610114
# Unit test for function find
def test_find():
    import astor

# Generated at 2022-06-12 04:49:25.613579
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast
    from . import text
    from .string_ import create_string_from_ast
    from ..exceptions import NodeNotFound

    node = text.statement_if
    module = ast.parse(node)
    if_node = ast.parse(node).body[0]

    parent, index = get_non_exp_parent_and_index(module, if_node)
    assert isinstance(parent, ast.Module)

    try:
        parent, index = get_non_exp_parent_and_index(module, ast.parse('x = 2'))
        assert False
    except NodeNotFound:
        pass

    node = text.function_arg
    module = ast.parse(node)
    function = ast.parse(node).body[0]

# Generated at 2022-06-12 04:49:36.649327
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    simple_code = '''
    def test():
        a = 1
        b = 2
        return a + b
    '''
    tree = ast.parse(simple_code)
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            parent1, i1 = get_non_exp_parent_and_index(tree, node)
        if isinstance(node, ast.Assign):
            parent2, i2 = get_non_exp_parent_and_index(tree, node)
        if isinstance(node, ast.Num):
            parent3, i3 = get_non_exp_parent_and_index(tree, node)

# Generated at 2022-06-12 04:49:41.946881
# Unit test for function find
def test_find():
    from .examples import console, add_console
    from typed_ast import ast3

    tree = add_console(console)
    _build_parents(tree)
    nodes = list(find(tree, ast3.Expr))
    assert len(nodes) == 1
    assert isinstance(nodes[0], ast3.Expr)

if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:49:46.398543
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:49:54.788538
# Unit test for function find
def test_find():
    # Test for function find
    import unittest
    import astor

    class Test_find(unittest.TestCase):
        def test_find(self):
            s = """
            def f(a, b):
                print(a)
                if a > b + 1:
                    return a - b
                else:
                    return a + b
                """
            tree = ast.parse(s)
            f = next(find(tree, ast.FunctionDef))
            self.assertEqual(astor.to_source(f), astor.to_source(tree))
            f = next(find(tree, ast.FunctionDef))
            self.assertEqual(astor.to_source(f), astor.to_source(tree))

    unittest.main()

# Generated at 2022-06-12 04:49:59.850562
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor  # type: ignore

    node = ast.parse(
        """def func():
        if (1 or 2) and 3 == 4:
            return 5
        if 1 == 2:
            if 3 == 4:
                return 5
            else:
                return 9
        """
    ).body[0]

# Generated at 2022-06-12 04:50:10.000397
# Unit test for function find
def test_find():
    expected: List[str] = [
        'func_def', 'suite', 'suite', 'name', 'arguments', 'args',
        'arg', 'store', 'func_def', 'suite', 'suite', 'name',
        'arguments', 'args', 'arg', 'store', 'class_def', 'suite',
        'suite', 'store', 'class_def', 'suite', 'suite', 'store'
    ]
    expected.sort()
    actual: List[str] = [str(type(i).__name__) for i in find(
        ast.parse('''
        def func(a):
            pass

        def func2(a):
            pass

        class A():
            pass

        class B():
            pass
        '''
        ), ast.Name)]
   

# Generated at 2022-06-12 04:50:12.427520
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('0')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]

# Generated at 2022-06-12 04:50:20.606673
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import parse

    code = """
    def foo():
        bar()
        print('hello')
        if True:
            print('hello')
    """

    tree = parse(code)
    body = tree.body[0].body
    func = tree.body[0]

    # 1st statement case
    "bar()"
    assert get_non_exp_parent_and_index(tree, body[0]) == (func, 0)

    "print('hello')"
    assert get_non_exp_parent_and_index(tree, body[1]) == (func, 1)

    "if"
    assert get_non_exp_parent_and_index(tree, body[2]) == (func, 2)

    # 2nd statement case

# Generated at 2022-06-12 04:50:25.506563
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    target_node = tree.body[0]

    assert get_parent(tree, target_node) == tree
    assert get_parent(tree, target_node.targets[0]) == target_node
    assert get_parent(tree, target_node.value) == target_node

# Generated at 2022-06-12 04:50:29.594787
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo() -> None:
        print('bar')
        pass
    """)  # type: ast.Module
    node = tree.body[0].body[0]  # type: ast.AST
    parent, i = get_non_exp_parent_and_index(tree, node)
    assert i == 0

# Generated at 2022-06-12 04:50:35.199811
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo():
        if 0 < 1:
            a = 1
        else:
            a = 2
    """)

    # this test check that the function and the else statement are found
    assert isinstance(get_non_exp_parent_and_index(tree, tree.body[0])[0], ast.Module)
    assert isinstance(get_non_exp_parent_and_index(tree.body[0], tree.body[0].body[0])[0], ast.FunctionDef)
    assert isinstance(get_non_exp_parent_and_index(tree.body[0], tree.body[0].body[0].body[0])[0], ast.If)

    # this test check that the index of the statement
    assert get_non_exp_parent_and_index

# Generated at 2022-06-12 04:50:38.017420
# Unit test for function find
def test_find():
    find_test = ast.parse("x = 1")
    for node in find(find_test, ast.Assign):
        assert isinstance(node, ast.Assign)



# Generated at 2022-06-12 04:50:46.164490
# Unit test for function get_parent

# Generated at 2022-06-12 04:50:52.449777
# Unit test for function find
def test_find():
    class A:
        pass

    class B:
        pass

    class C:
        pass
    l = []
    cnt = 0
    print(cnt)
    l.append(A())
    l.append(B())
    l.append(C())
    l.append(A())
    l.append(A())
    l.append(C())
    l.append(B())
    l.append(B())
    for a in find(A, l):
        print(a)
        cnt += 1
    print(cnt)
    assert cnt == 3

# Generated at 2022-06-12 04:51:01.941710
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    # Test for body is list (body has length bigger than 1)
    tree = ast.parse('[1, 2, 3]')
    actual = get_non_exp_parent_and_index(tree, tree.body[1])
    expected_parent = ast.parse('[1, 2, 3]')
    expected_index = 1
    assert astor.to_source(actual[0]) == astor.to_source(expected_parent)
    assert actual[1] == expected_index

    # Test for body is not list (body has length equal to 1)
    tree = ast.parse('a = 1')
    actual = get_non_exp_parent_and_index(tree, tree.body[0].value)
    expected_parent = ast.parse('a = 1')
    expected_index = 0


# Generated at 2022-06-12 04:51:07.086680
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import textwrap
    tree = ast.parse(textwrap.dedent("""
    def wrapper():
        def inner():
            pass
    """))

    inner = find(tree, ast.FunctionDef).__next__()
    wrapper = get_closest_parent_of(tree, inner, ast.FunctionDef)

    assert wrapper.name == 'wrapper'


# TODO: Tests


# Generated at 2022-06-12 04:51:17.779896
# Unit test for function find
def test_find():
    from ..tokenizer import tokenize
    from .parser import parse
    from .printer import print_tree, print_node
    from . import tree_utils as self

    """
    def foo():
        print('hi')
    """
    code = tokenize('def foo():\n\tprint(\'hi\')')
    tree = parse(code)

    # type: ignore
    functions = [func for func in find(tree, ast.FunctionDef)]
    assert functions[0].name.value == 'foo'

    exps = [exp for exp in find(tree, ast.Expr)]
    assert len(exps) == 1

    # type: ignore
    exp = exps[0]
    assert isinstance(exp.value, ast.Call)
    assert isinstance(exp.value.func, ast.Name)
   

# Generated at 2022-06-12 04:51:18.748348
# Unit test for function find
def test_find():  # type: () -> None
    pass

# Generated at 2022-06-12 04:51:24.719008
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class_node = ast.ClassDef(name='foo', body=[], decorator_list=[])
    function_node = ast.FunctionDef(name='__init__',
                                    args=ast.arguments(args=[ast.arg(arg='self')],
                                                       varargarg=None,
                                                       kwonlyargs=[],
                                                       kwargarg=None,
                                                       defaults=[],
                                                       kw_defaults=[]),
                                    body=[ast.Return(value=ast.Num(n=1))],
                                    decorator_list=[],
                                    returns=None)
    assign_node = ast.Assign(targets=[ast.Name(id='a')], value=ast.Num(n=1))
    tree = ast.Module(body=[class_node, assign_node])

# Generated at 2022-06-12 04:51:29.455405
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def a():\n    a = 1\n    b = 2')
    node = tree.body[0].body[0].targets[0]
    assert get_non_exp_parent_and_index(tree, node) \
        == (tree.body[0], 0)

# Generated at 2022-06-12 04:51:33.741591
# Unit test for function get_parent
def test_get_parent():
    """Unit test for function get_parent."""
    global _parents
    test_tree = ast.parse("1+1")
    _parents = WeakKeyDictionary()
    assert(get_parent(test_tree, test_tree) == None)
    assert(isinstance(get_parent(test_tree, test_tree.body[0]), ast.Module))

# Generated at 2022-06-12 04:51:40.060420
# Unit test for function get_parent
def test_get_parent():
    source_code = 'def my_func():\n    a = 1\n'
    module = ast.parse(source_code)

    assert get_parent(module, module) is None
    assert isinstance(get_parent(module, module.body[0]), ast.Module)
    assert module.body[0] == get_parent(module, module.body[0].body[0])
    assert module.body[0].body[0] == get_parent(module, module.body[0].body[0].value)

    with pytest.raises(NodeNotFound):
        assert get_parent(module, ast.parse('1').body[0])


# Generated at 2022-06-12 04:52:17.862951
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        '''
        for i in range(10):
            print(i)
        print(i)
        '''
    )
    all_nodes = list(ast.walk(tree.body[0]))

    node = ast.Call(func=ast.Name('print', ast.Load()),
                    args=[ast.Name('i', ast.Load())],
                    keywords=[])
    results = [get_non_exp_parent_and_index(tree, node)
               for node in all_nodes]
    assert results[-1] == (tree.body[0], 1)
    assert results[-2] == (tree.body[0].body[0], 0)
    assert results[-3] == (tree.body[0], 0)

# Generated at 2022-06-12 04:52:20.741334
# Unit test for function get_parent
def test_get_parent():
    root = ast.parse('1 + 1')
    parent = get_parent(root, root.body[0].value)
    assert parent is root.body[0]

# Generated at 2022-06-12 04:52:27.270512
# Unit test for function find
def test_find():
    from .util import to_ast
    from .types import Signature

    code = """\
    class Foo:
        def __init__(self):
            pass

    def bar(a: int, b: str = 'a') -> str:
        return b\
    """

    tree = to_ast(code)

    # Test ClassDef
    for node in find(tree, ast.ClassDef):
        assert node.name == 'Foo'

    # Test Assign
    for node in find(tree, ast.AnnAssign):
        assert isinstance(node.annotation, ast.Name)
        assert node.annotation.id == 'int'

    # Test FunctionDef
    for node in find(tree, ast.FunctionDef):
        assert node.name == 'bar'

    # Test Signature

# Generated at 2022-06-12 04:52:33.113708
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert (get_closest_parent_of(
        ast.parse('''
        def foo(bar):
            if bar > 10:
                return 1
            else:
                return 2
        '''), ast.parse('1').body[0], ast.If)
        == ast.parse('if bar > 10:\n                return 1').body[0])

    assert (get_closest_parent_of(
        ast.parse('''
        def foo(bar):
            if bar > 10:
                return 1
            else:
                return 2
        '''), ast.parse('1').body[0], ast.FunctionDef)
        == ast.parse('def foo(bar):').body[0])

# Generated at 2022-06-12 04:52:42.208105
# Unit test for function get_parent
def test_get_parent():
    import syntok.segmenter as segmenter
    import syntok.tokenizer as tokenizer
    from syntok.tokenizer._constants.regex import TOKEN_REGEX_CACHE

    text = "def foo():\n pass"

    TOKEN_REGEX_CACHE.clear()
    token_list = tokenizer.tokenize(text)
    segment_list = segmenter.segment(token_list)

    import syntok.parser as parser
    tree = parser.parse(segment_list)

    for node in find(tree, ast.FunctionDef):
        assert get_parent(tree, node) is tree  # type: ignore
        assert get_parent(tree, node) is get_parent(tree, tree)  # type: ignore

    for node in find(tree, ast.Expr):
        assert get

# Generated at 2022-06-12 04:52:49.156823
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Checks get_closest_parent_of."""
    def foo():
        if 1:
            pass

    foo_node = find(ast.parse(foo.__code__), ast.FunctionDef).__next__()
    if_node = foo_node.body[0]
    if_test = if_node.test
    call_node = if_test.left
    assert get_closest_parent_of(foo_node, call_node, ast.FunctionDef) == foo_node

# Generated at 2022-06-12 04:52:50.048159
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:52:54.012995
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = parser.parse('def a():\n b = 1')
    assert get_non_exp_parent_and_index(tree, find(tree, ast.Assign).__next__()) == (tree.body[0].body, 0)



# Generated at 2022-06-12 04:52:58.135465
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('while x: pass')
    node = tree.body[0].body[0].body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert index == 0
    assert isinstance(parent, ast.While)

# Generated at 2022-06-12 04:53:06.530645
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    with open("./test_assets/find_index_test.py", "r") as f:
        code = f.read()

    # Make the AST
    tree = ast.parse(code)
    assert tree is not None

    # Get the node of interest
    classdef = list(find(tree, ast.ClassDef))[0]
    assert classdef is not None

    # Get the parent of interest
    parent, index = get_non_exp_parent_and_index(tree, classdef)
    assert parent is not None
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-12 04:53:44.934082
# Unit test for function replace_at
def test_replace_at():
    import astor
    test_tree = ast.parse('a += 1')
    test_node = test_tree.body[0]
    test_parent = test_tree.body
    test_index = test_parent.index(test_node)
    replace_at(test_index, test_parent, ast.parse('a += 2'))
    assert astor.to_source(test_tree) == 'a += 2'


# Generated at 2022-06-12 04:53:50.427340
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    source = "True"

    def get_result():
        tree = ast.parse(source)
        node = tree
        for child in ast.iter_child_nodes(tree):
            node = child

        return get_closest_parent_of(tree=tree, node=node, type_=ast.Module)

    expected_result = ast.parse(source)
    assert get_result() == expected_result

if __name__ == "__main__":
    test_get_closest_parent_of()

# Generated at 2022-06-12 04:53:58.404452
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    case = ast.parse("""
        def foo(x):
            if x == 1:
                return 1
            elif x == 2:
                return 2
            else:
                return 3
    """)
    _build_parents(case)
    assert get_closest_parent_of(case, case.body[0].body[0].body[0].body[1],
                                 ast.If) == case.body[0].body[0].body[0]
    assert get_closest_parent_of(case, case.body[0].body[0].body[0].body[1],
                                 ast.FunctionDef) == case.body[0]

# Generated at 2022-06-12 04:54:07.810134
# Unit test for function find
def test_find():
    import ast2json
    import json

    tree = ast.parse("""
    def foo():
        from urllib.parse import urlparse

        def bar():
            pass
    """, mode='exec')

    urlparse = find(tree, ast.ImportFrom)
    bar = find(tree, ast.FunctionDef)

    for node in urlparse:
        print(json.dumps(ast2json.convert(node), indent=2))

    for node in bar:
        print(json.dumps(ast2json.convert(node), indent=2))


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:54:18.976674
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from . import parse_source
    from . import get_closest_parent_of
    from . import find
    from . import get_parent

    code = "def for_tests():\n    for i in range(10):\n        if i % 2 == 0:\n            print (i)\n            return i"

    tree = parse_source(code)

    for node in find(tree, ast.Name):
        if node.id == "if":
            break

    if_node = node

    while True:
        name_node = if_node
        if_node = get_parent(tree, if_node)
        if get_closest_parent_of(tree, name_node, ast.For).__class__ == ast.For:
            break

    assert if_node.__class__ == ast.For

# Generated at 2022-06-12 04:54:25.102753
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import pytest
    with pytest.raises(NodeNotFound):
        # No parents are built up
        get_non_exp_parent_and_index(None, None)
    from .types import types
    from .parser import parser
    from .transformer import transformer
    from .code_generator import code_generator

    two_adds = parser.parse(u'1 + 2 + 3')
    left_add = two_adds.body[0].value.left
    right_add = two_adds.body[0].value.right
    non_exp_parent_and_index = get_non_exp_parent_and_index(two_adds, left_add)
    assert(non_exp_parent_and_index[0] == two_adds)

# Generated at 2022-06-12 04:54:27.278790
# Unit test for function replace_at
def test_replace_at():
    import inspect
    import astor

# Generated at 2022-06-12 04:54:27.769651
# Unit test for function get_parent

# Generated at 2022-06-12 04:54:33.763255
# Unit test for function find
def test_find():
    test_tree = ast.parse("""
    def f(x):
        def a(y):
            import math
        b = math.cos(x) + 2 * x
        return (x - math.sin(x)) * b
    """)
    # for node in find(test_tree, ast.Name):
    #     assert node.id in ['math', 'cos', 'sin', 'x'] # pass
    # for node in find(test_tree, ast.Call):
    #     assert node.func.id in ['math.cos', 'math.sin'] # pass
    # for node in find(test_tree, ast.Import):
    #     assert node.names[0].name == 'math' # pass
    # for node in find(test_tree, ast.FunctionDef):
    #     assert node.name in ['

# Generated at 2022-06-12 04:54:40.157666
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from typed_ast import ast3 as ast

    def func():
        a = 1
        b = 2
        c = 3
        d = 4
        f = 5

    tree = ast.parse(func.__code__.co_consts[0])
    parent, index = get_non_exp_parent_and_index(tree, tree.body[2].body[3])
    assert parent == tree.body[2]
    assert index == 4


# Generated at 2022-06-12 04:56:07.806219
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""if True:
                            print(True)
                            print(False)
                        """)  # type: ast.AST
    index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])[1]
    assert index == 0



# Generated at 2022-06-12 04:56:16.438339
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from .transform import ast_transform
    from .test_util import transform_test

    code = """
    def f1(a):
        return a

    def f2(a):
        return f1(a)

    def f3(a):
        return f2(a)

    def f4(a):
        return f3(a)
    """
    tree = transform_test(code)
    _build_parents(tree)
    tu = tree.body[3].body[0].value.func.value.func  # type: ignore
    closest_parent = get_closest_parent_of(tree, tu, ast.FunctionDef)
    assert astor.to_source(closest_parent) == 'f1(a)\n'

# Generated at 2022-06-12 04:56:24.549240
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def test():\n'
                     '    if True:\n'
                     '        pass\n')
    test_function = tree.body[0]
    test_if_body = test_function.body[0]
    test_pass_line = test_if_body.body[0]
    non_exp_part_of_line_before_pass, index_of_pass = get_non_exp_parent_and_index(tree, test_pass_line)
    assert index_of_pass == 0
    assert non_exp_part_of_line_before_pass.body[0] is test_pass_line

# Generated at 2022-06-12 04:56:33.238783
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # Test function get_closest_parent_of
    test_node = ast.parse('''
    a = 'a'
    f = 1
    c = a + f
    ''')

    node = test_node.body[1].value

    parent = get_closest_parent_of(test_node, node, ast.Module)
    assert isinstance(parent, ast.Module)
    parent = get_closest_parent_of(test_node, node, ast.Expr)
    assert isinstance(parent, ast.Expr)
    parent = get_closest_parent_of(test_node, node, ast.Assign)
    assert isinstance(parent, ast.Assign)

# Generated at 2022-06-12 04:56:34.332466
# Unit test for function find
def test_find():
    assert find(ast.parse('x = 5'), ast.Name)



# Generated at 2022-06-12 04:56:36.769351
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('1 + 2 * 3')
    assert isinstance(get_closest_parent_of(tree, tree.body[0].value, ast.Expr),
                      ast.BinOp)



# Generated at 2022-06-12 04:56:39.890665
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Given
    tree = ast.parse('a = 0\n'
                     'b = 1')
    node = tree.body[1]

    # When
    parent, index = get_non_exp_parent_and_index(tree, node)

    # Then
    assert isinstance(parent, ast.Module)
    assert index == 1



# Generated at 2022-06-12 04:56:47.342747
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    exp = ast.Expression(ast.Name(id="foo"))
    parent = ast.Call(func=exp, args=[], keywords=[])

    # Index of Name -> 3
    assert get_non_exp_parent_and_index(parent, exp.body)[1] == 3
    # Name of Name -> Call
    assert isinstance(get_non_exp_parent_and_index(parent, exp.body)[0], ast.Call)
    # Index of Call -> 3
    assert get_non_exp_parent_and_index(parent, parent)[1] == 3
    # Name of Call -> Module
    assert isinstance(get_non_exp_parent_and_index(parent, parent)[0], ast.Module)

# Generated at 2022-06-12 04:56:49.174587
# Unit test for function get_parent
def test_get_parent():
    # type: () -> None
    """Test for function get_parents."""
    import subprocess
    import astor


# Generated at 2022-06-12 04:56:50.022691
# Unit test for function find
def test_find():
    pass