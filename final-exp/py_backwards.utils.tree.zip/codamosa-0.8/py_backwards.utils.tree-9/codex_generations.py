

# Generated at 2022-06-12 04:47:29.673760
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    exp = ast.parse('root(a, b, c)').body[0]
    a = get_non_exp_parent_and_index(exp, exp.args[0])[0]
    b = get_non_exp_parent_and_index(exp, exp.args[1])[0]
    c = get_non_exp_parent_and_index(exp, exp.args[2])[0]
    assert a == b
    assert a == c

# Generated at 2022-06-12 04:47:35.555455
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = """
    def foo():
        call(foo2())
    """
    tree = ast.parse(code)
    _build_parents(tree)
    func = tree.body[0]
    call = func.body[0].value
    index, parent = get_non_exp_parent_and_index(tree, call)

# Generated at 2022-06-12 04:47:39.101656
# Unit test for function find
def test_find():
    tree = ast.parse('''
    def f():
      if False:
        return 1

      return 2
    ''')
    return_node = find(tree, ast.Return).next()
    assert return_node.value.n == 1

# Generated at 2022-06-12 04:47:39.414670
# Unit test for function get_parent
def test_get_parent():
    pass

# Generated at 2022-06-12 04:47:45.307504
# Unit test for function find
def test_find():
    src = 'class A(object):\n    def f(self):\n        pass'
    tree = ast.parse(src)

    names = find(tree, ast.Name)
    assert len(names) == 1
    assert names[0].id == 'A'

    classes = find(tree, ast.ClassDef)
    assert len(classes) == 1
    assert classes[0].name == 'A'



# Generated at 2022-06-12 04:47:54.030604
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # type: () -> None
    import astor

    # test1
    src = '''
    def foo():
        class A:
            def bar(self, a, b=1, *args, **kwargs):
                if a and b:
                    pass
                else:
                    pass
    '''
    tree = ast.parse(src)
    node = find(tree, ast.If).__next__()
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    expected = astor.to_source(parent)
    actual = '''
    def bar(self, a, b=1, *args, **kwargs):
        if a and b:
            pass
        else:
            pass
    '''
    assert expected == actual

    # test2

# Generated at 2022-06-12 04:47:58.323033
# Unit test for function replace_at
def test_replace_at():
    import astor
    string = 'x = x + 1'
    tree = ast.parse(string)
    replace_at(1, tree, ast.parse('x = x + 2'))
    result = 'x = (x + 2)'
    assert astor.to_source(tree) == result


# Generated at 2022-06-12 04:47:59.357484
# Unit test for function find

# Generated at 2022-06-12 04:48:06.810728
# Unit test for function find
def test_find():
    x = """
try:
    print 'hello'
except Exception as e:
    pass
else:
    pass
finally:
    pass
    """
    x = ast.parse(x)
    q = list(find(x, ast.Try))
    assert len(q) == 1
    q = list(find(q[0], ast.ExceptHandler))
    assert len(q) == 1
    q = list(find(x, ast.FunctionDef))
    assert len(q) == 0

# Generated at 2022-06-12 04:48:10.251154
# Unit test for function find
def test_find():
    """Unit test for function find."""
    test_tree = ast.parse('import ast\nimport sys\n')

    assert len(list(find(test_tree, ast.Import))) == 2

# Generated at 2022-06-12 04:48:23.739406
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    print('Unit test for get_non_exp_parent_and_index: ', end='')
    class Test(ast.AST):
        _fields = ('test', )
    class Exp(ast.AST):
        _fields = ('test', )
    class Node(ast.AST):
        _fields = ('test', 'body')


# Generated at 2022-06-12 04:48:28.559718
# Unit test for function get_parent
def test_get_parent():  # pragma: no cover
    from astpretty import pprint as pp
    tree = ast.parse('class C: pass')
    _build_parents(tree)
    assert node in _parents

    node = get_parent(tree, _parents.get(node))
    pp(node)

# Generated at 2022-06-12 04:48:37.015311
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ..transformers.convert_to_fstring import ConvertToFstring

    code = '''
        def test(a, b):
            c = a + b
            print(f'test {a} {b} {c}')
    '''

    ast_ = ast.parse(code)
    nodes = [x for x in ast.walk(ast_) if isinstance(x, ast.Num)]
    #print(astor.to_source(ast_))
    #print(nodes)
    assert len(nodes) == 2

    closest_parent = get_closest_parent_of(ast_, nodes[0], ast.FunctionDef)
    assert 'test' == closest_parent.name


# Generated at 2022-06-12 04:48:43.252634
# Unit test for function get_parent
def test_get_parent():
    from typed_ast import ast3 as ast
    code = '''
    if True:
        '''
    
    tree = ast.parse(code)

    _build_parents(tree)

    if_node = tree.body[0]

    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, if_node.body[0]) == if_node



# Generated at 2022-06-12 04:48:49.160024
# Unit test for function find
def test_find():
    import _ast as ast

    parent = ast.Module(body=[])
    if_stmt = ast.If()
    parent.body.append(if_stmt)
    for_stmt = ast.For()
    parent.body.append(for_stmt)

    result = list(find(parent, ast.If))
    if len(result) is not 1:
        raise Exception

    if if_stmt not in result:
        raise Exception

    result = list(find(parent, ast.For))
    if len(result) is not 1:
        raise Exception

    if for_stmt not in result:
        raise Exception

# Generated at 2022-06-12 04:48:50.185102
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:50.792299
# Unit test for function insert_at
def test_insert_at():
    assert False

# Generated at 2022-06-12 04:48:56.969948
# Unit test for function find
def test_find():
    # type: () -> Iterable[Tuple[ast.AST, ast.arg]]
    arg = ast.arg('node', None)
    func = ast.FunctionDef('func', ast.arguments([arg], None, None, []),
                           [], [], None, [])
    tree = ast.Module([func])

    for node, func_arg in zip(find(tree, ast.FunctionDef), [func]):
        yield node, func_arg

# Generated at 2022-06-12 04:48:59.234499
# Unit test for function find
def test_find():
    t = ast.parse('a = 1')
    result = find(t, ast.Name)
    assert isinstance(result, Iterable)



# Generated at 2022-06-12 04:49:04.458436
# Unit test for function get_parent
def test_get_parent():
    import astor

    a = ast.parse("""
    import ast
    print(ast.parse("1").body[0].value)
    """)
    _build_parents(a)
    assert astor.to_source(get_parent(a, a.body[1].value.func)) == 'ast.parse'



# Generated at 2022-06-12 04:49:17.664486
# Unit test for function find
def test_find():
    class G(ast.AST):
        def __init__(self, name : str, value : int):
            self.name = name
            self.value = value
            self.body = []
            self.obj_type = 'G'

    class F(ast.AST):
        def __init__(self, name : str, value : int):
            self.name = name
            self.value = value
            self.body = []
            self.obj_type = 'F'

    class E(ast.AST):
        def __init__(self, name : str, value : int):
            self.name = name
            self.value = value
            self.obj_type = 'E'

    class D(ast.AST):
        def __init__(self, name : str, value : int):
            self.name = name

# Generated at 2022-06-12 04:49:23.395175
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    parent = ast.parse('a = 1')
    node = parent.body[0]

    assert get_closest_parent_of(parent, node, ast.Module) == parent
    assert get_closest_parent_of(parent, node, ast.FunctionDef) is None
    assert get_closest_parent_of(parent, node, ast.Assign) == node



# Generated at 2022-06-12 04:49:24.414127
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:49:29.347225
# Unit test for function find
def test_find():
    tree = ast.parse('''
            def foo(x : int, y : int) -> str:
                return x / y
        ''')
    _build_parents(tree)
    print(len(list(find(tree, ast.Name))))
    print(len(list(find(tree, ast.FunctionDef))))


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:49:33.304179
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("def name(): pass")
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (tree.body[0], 0)

# Generated at 2022-06-12 04:49:43.101358
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class T(ast.AST):
        def __init__(self, body):
            self.body = body

    class T1(ast.AST):
        def __init__(self, body):
            self.body = body

    class T2(ast.AST):
        def __init__(self, body):
            self.body = body

    n1 = ast.Name('n1')
    n2 = ast.Name('n2')
    n3 = ast.Name('n3')
    n4 = ast.Name('n4')
    n5 = ast.Name('n5')
    n6 = ast.Name('n6')
    n7 = ast.Name('n7')
    n8 = ast.Name('n8')

# Generated at 2022-06-12 04:49:50.104349
# Unit test for function get_parent
def test_get_parent():
    import unittest

    class TestGetParent(unittest.TestCase):
        def test_get_parent(self):
            node_a = ast.Name('a', ast.Store())
            node_b = ast.Name('b', ast.Store())
            body = [node_a, node_b]
            func = ast.FunctionDef('test', ast.arguments([]), body, [], None)
            module = ast.Module([func])

            self.assertEqual(get_parent(module, node_b), func)

    unittest.main()



# Generated at 2022-06-12 04:49:51.681714
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from .ast_builder import ast_from_code


# Generated at 2022-06-12 04:49:57.844353
# Unit test for function find
def test_find():
    f = ast.parse("def f():\n\treturn \"ab\"")
    f.body.append(ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                             value=ast.Num(n=1)))
    f.body[0].body.append(ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())],
                                     value=ast.Num(n=2)))
    f.body.append(ast.Assign(targets=[ast.Name(id='c', ctx=ast.Store())],
                             value=ast.Num(n=3)))

# Generated at 2022-06-12 04:50:02.084404
# Unit test for function find
def test_find():
    import astor
    tree = ast.parse('''
    def foo() -> None:
        a: int = 1
        b: float = 2.
        b = 3
        return b
    ''')
    print(astor.to_source(tree))
    for node in find(tree, ast.Assign):
        print(astor.to_source(node))



# Generated at 2022-06-12 04:50:06.988416
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:50:11.595608
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('foo = 1\nbar = 2')
    node = tree.body[1]
    parent, index = get_non_exp_parent_and_index(tree, node)

    assert isinstance(parent, ast.Module)
    assert index == 1


# Generated at 2022-06-12 04:50:16.201407
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index."""
    node = ast.parse("""
[x for x in range(1)]
""").body[0]
    assert get_non_exp_parent_and_index(node, node.generators[0]) == (node, 0)

# Generated at 2022-06-12 04:50:20.822207
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert isinstance(get_closest_parent_of(ast.parse(  # type: ignore
        """
        def func() -> None:
            while True:
                pass
        """
    ), ast.parse('pass', mode='eval').body, ast.FunctionDef), ast.FunctionDef)



# Generated at 2022-06-12 04:50:27.670865
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    t = ast.parse("""\
if a:
    x = 1

while b:
    x = 2
""")  # type: ast.Module

    body = t.body  # type: ast.Module
    while_stmt = body[1]  # type: ast.While
    x = while_stmt.body[0].value  # type: ast.Name

    assert(get_non_exp_parent_and_index(t, x)) == (while_stmt, 0)

# Generated at 2022-06-12 04:50:28.252053
# Unit test for function insert_at
def test_insert_at():
    pass

# Generated at 2022-06-12 04:50:32.875658
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""# test file
    import sys

    a = 1

    def func():
        print("hello")
    """)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[1])
    assert parent == tree and index == 1

    parent, index = get_non_exp_parent_and_index(tree, tree.body[1].body[0])
    assert parent == tree.body[1] and index == 0



# Generated at 2022-06-12 04:50:34.251569
# Unit test for function get_parent

# Generated at 2022-06-12 04:50:37.268579
# Unit test for function find
def test_find():
    code = """def foo():
        print(1)
        print(2)
        print(3)"""
    tree = ast.parse(code)
    for n in find(tree, ast.Print):
        assert isinstance(n, ast.Print)
        assert n.nl == False

# Generated at 2022-06-12 04:50:40.013389
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test for get_non_exp_parent_and_index"""

# Generated at 2022-06-12 04:50:45.539276
# Unit test for function get_parent
def test_get_parent():
    import astor

# Generated at 2022-06-12 04:50:50.564124
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse(('import sys',
                      'a = 0x00',
                      'while a > 0x00:',
                      '    print(sys.platform)',
                      '    a -= 0x01'))
    nodes = list(ast.walk(tree))
    parent = get_closest_parent_of(tree, nodes[7], ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)


# Generated at 2022-06-12 04:50:51.075533
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    pass

# Generated at 2022-06-12 04:50:59.247282
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from . import const
    from . import tree

    code = "if True:\n" \
           "    d = c.d\n" \
           "    print(d)\n"
    tree = tree.build_tree(const.PYTHON_PATH, code)
    parent = get_closest_parent_of(tree, tree.body[0].body[0].value.func, ast.If)
    assert astor.to_source(parent) == "if True:\n" \
                                      "    d = c.d\n" \
                                      "    print(d)\n"

# Generated at 2022-06-12 04:51:06.323554
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = '''
    def f():
        pass

    class A:
        pass
    '''
    tree = ast.parse(code)
    for node in find(tree, ast.FunctionDef):
        parent = get_closest_parent_of(tree, node, ast.Module)
        assert isinstance(parent, ast.Module)  # type: ignore

    for node in find(tree, ast.ClassDef):
        parent = get_closest_parent_of(tree, node, ast.Module)
        assert isinstance(parent, ast.Module)  # type: ignore

# Generated at 2022-06-12 04:51:16.433425
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import ast
    import typing
    import unittest

    tree = ast.parse(
        open('test/test_cases/test_get_closest_parent_of').read())
    node = list(ast.iter_child_nodes(tree.body[0]))[1].body[0]
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)

    class TestGetClosestParentOf(unittest.TestCase):
        def test_for_correct_type(self):
            self.assertIsInstance(parent, ast.FunctionDef)

        def test_correct_parent(self):
            self.assertEqual(parent.name, 'foo')

    unittest.main()

# Generated at 2022-06-12 04:51:22.365742
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('if 1:\n    pass')
    node = tree.body[0]

    assert(get_closest_parent_of(tree, node, ast.Module) is tree)
    assert(get_closest_parent_of(tree, node, ast.Dict) is None)
    assert(get_closest_parent_of(tree, node.body[0], ast.Module) is tree)
    assert(get_closest_parent_of(tree, node.body[0], ast.If) is node)



# Generated at 2022-06-12 04:51:32.398749
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
    import ast
    def sort_nodes(nodes):
        return nodes
    ''')

    module = tree.body[0]
    import_node = module.body[0]
    ast_node = import_node.names[0]

    assert isinstance(
        get_closest_parent_of(module, ast_node, ast.Module), ast.Module)
    assert isinstance(
        get_closest_parent_of(module, ast_node, ast.Import), ast.Import)
    assert isinstance(
        get_closest_parent_of(module, ast_node, ast.Name), ast.Name)



# Generated at 2022-06-12 04:51:37.143802
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = "for i in range(10): print(i)"

    tree = ast.parse(code)
    closest_parent_of = get_closest_parent_of(tree, tree.body[0].body[0],
                                              ast.For)
    assert closest_parent_of == tree.body[0]



# Generated at 2022-06-12 04:51:47.821463
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # pylint: disable=W0613
    module = ast.parse("""
    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass
    """)

    # pylint: disable=E1101
    class_defs = find(module, ast.ClassDef)
    def_a, def_b, def_c = class_defs

    assert(get_non_exp_parent_and_index(module, def_a) ==
           (module, 1))
    assert(get_non_exp_parent_and_index(module, def_b) ==
           (module, 2))
    assert(get_non_exp_parent_and_index(module, def_c) ==
           (module, 3))

# Generated at 2022-06-12 04:51:58.711153
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a = ast.Module()
    b = ast.Expr()
    c = ast.Name()
    b.value = c
    a.body = [b]

    assert get_non_exp_parent_and_index(a, c) == (a, 0)

# Generated at 2022-06-12 04:52:00.014148
# Unit test for function find

# Generated at 2022-06-12 04:52:08.190629
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = """
    def parser(x):
        if x > 0:
            if x > 5:
                return 'big'
            else:
                return 'small'
        else:
            return 'negative'
    """

    # Get module
    module = ast.parse(code)

    # Get "small" string
    string = module.body[0].body[0].orelse[0].value  # type: ignore

    # Get parent and index
    parent, index = get_non_exp_parent_and_index(module, string)

    # Assert
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-12 04:52:11.830629
# Unit test for function find
def test_find():
    src = '''
    def foo(a, b):
        a = 1
        b = 2
    '''
    x = ast.parse(src)
    trees = find(x, ast.FunctionDef)
    assert len(list(trees)) == 1


# Generated at 2022-06-12 04:52:15.283326
# Unit test for function get_parent
def test_get_parent():
    """Tests get_parent."""
    import astor
    from ..exceptions import NodeNotFound


# Generated at 2022-06-12 04:52:22.159864
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    tree = astor.parse_file("../test/test.py")
    node = tree.body[0]
    assert isinstance(node, ast.FunctionDef)
    assert get_closest_parent_of(tree, node, ast.Module) == tree
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node.body[0], ast.FunctionDef),
                      ast.FunctionDef)


# Generated at 2022-06-12 04:52:27.941208
# Unit test for function find
def test_find():
    class Node(ast.AST):
        pass

    class Node1(Node):
        pass

    class Node2(Node):
        pass

    root = Node()
    node1_1 = Node1()
    node2_1 = Node2()
    node2_2 = Node2()
    node1_1.node1_1 = node2_1
    node1_1.node1_2 = node2_2
    root.node1_1 = node1_1

    for node in find(root, Node1):
        print(node)

# Generated at 2022-06-12 04:52:34.640497
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    cmp_str = "a=10\nb=20\nc=42\nif c==42: a=5\nelif a==5: b=5\nelse: b=0"
    tree = ast.parse(cmp_str)
    node = tree.body[2]
    parent = get_closest_parent_of(tree, node, ast.If)
    assert(parent.test.value.n == 42)
    assert(type(parent.test) is ast.Compare)
    assert(str(parent.test.left) == 'c')


# Generated at 2022-06-12 04:52:39.229399
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def foo():
        1 + 2

    tree = ast.parse(inspect.getsource(foo))
    v1 = tree.body[0].body[0].value
    i1, i2 = get_non_exp_parent_and_index(tree, v1)

    assert type(i1) == ast.FunctionDef
    assert i2 == 0

# Generated at 2022-06-12 04:52:40.530601
# Unit test for function find
def test_find():
    """ Test function find."""

# Generated at 2022-06-12 04:53:05.916748
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class TestClass(ast.AST):
        def __init__(self):
            self.body = []

    class TestClass2(ast.AST):
        def __init__(self):
            self.body = []

    class TestClass3(ast.AST):
        def __init__(self):
            self.body = []

    class TestClass4(ast.AST):
        def __init__(self):
            self.body = []

    class TestClass5(ast.AST):
        def __init__(self):
            self.body = []

    class TestClass6(ast.AST):
        def __init__(self):
            self.body = []

    tree = TestClass()
    tree.body.append(TestClass2())
    tree.body.append(TestClass3())

# Generated at 2022-06-12 04:53:09.362950
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('for i in range(10): print(i)')
    node = tree.body[0].body[0]
    #print(node)
    parent, index = get_non_exp_parent_and_index(tree, node)
    #print(parent.body[index], index)

# Generated at 2022-06-12 04:53:14.802423
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    m = ast.parse("""
    def get_closest_parent_of(tree, node, type_):
        parent = node
        while True:
            parent = get_parent(tree, parent)
            if isinstance(parent, type_):
                return parent
    """)

    assert isinstance(get_closest_parent_of(m, m.body[0].body[1].targets[0],
                                            ast.FunctionDef),
                      ast.FunctionDef)


# Generated at 2022-06-12 04:53:19.815485
# Unit test for function get_parent
def test_get_parent():
    # create tree
    assert_val = ast.parse('''
        class MyClass():
            # comment
            def myFunc(self):
                var1 = 1
    ''')

    # find comment
    comment = list(find(assert_val, ast.Expr))[0]

    # get parent
    parent = get_parent(assert_val, comment)

    # test if parent is of class ast.FunctionDef
    assert isinstance(parent, ast.FunctionDef)


# Generated at 2022-06-12 04:53:28.491189
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Checking body of tree to check if the parent is correct
    tree = ast.parse("""if True:
    a = 2
    a = 1
    if False:
        a = 3
        a = 4
        a = 5
    a = 6""")
    node = ast.parse("a = 6").body[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert(isinstance(parent, ast.If))
    assert(index == 3)

    # Checking parent of body to check if the index is correct
    tree = ast.parse("""if True:
    a = 1
    a = 2
    a = 3
    if False:
        a = 4
        a = 5
        a = 6""")

# Generated at 2022-06-12 04:53:35.511415
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert get_non_exp_parent_and_index(
        ast.parse('x = "a" if False else "b"').body[0],
        ast.parse('x = "a" if False else "b"').body[0].value.comparators[0]
    ) == (ast.Module([ast.Assign([ast.Name('x', ast.Store())],
                                 ast.IfExp(ast.Name('False', ast.Load()),
                                           ast.Str('a'),
                                           ast.Str('b')))],
                     []), 0)

# Generated at 2022-06-12 04:53:41.847995
# Unit test for function replace_at
def test_replace_at():
    import logging
    import os
    import unittest

    here = os.path.dirname(os.path.abspath(__file__))
    logger = logging.getLogger('test_replace_at')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    class TestReplaceAt(unittest.TestCase):
        """Test replace_at."""

        def test_replace_at(self):
            import copy
            try:
                import typed_astunparse
            except ImportError:
                logger.info('no module typed_astunparse')
                return
            from . import utils
            from . import replace_at
            source = utils.get_sample_code()
            tree

# Generated at 2022-06-12 04:53:50.891630
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import sys
    import copy
    import astunparse
    import pdb
    from ..utilities.log_utils import debug
    from ..utilities.ast_utils import get_closest_parent_of
    from ..utilities.ast_utils import get_non_exp_parent_and_index
    from ..utilities.ast_utils import insert_at
    from .doctest_utils import check


# Generated at 2022-06-12 04:53:58.503307
# Unit test for function get_parent
def test_get_parent():
    import astor
    node = ast.FunctionDef(name = "f", args=ast.arguments(args = [], vararg = None, kwonlyargs = [],
    kw_defaults = [], kwarg = None, defaults = []), body = [ast.Return(value = ast.Num(n = 1))], decorator_list = [], returns = None)
    assert astor.to_source(get_parent(node, node.body[0])) == "f(args = [], vararg = None, kwonlyargs = [], kw_defaults = [], kwarg = None, defaults = [])"


# Generated at 2022-06-12 04:54:03.332712
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node0 = ast.parse('x + (y / (x + 5))')
    assert (get_non_exp_parent_and_index(node0, node0.body[0].value) ==
            (node0.body[0].value.right, 1))



# Generated at 2022-06-12 04:54:37.576785
# Unit test for function find
def test_find():
    # test

    print("Unit test for find")
    code = """
    def func1(a):
        return 1
    """
    tree = ast.parse(code)
    node = find(tree, ast.Module)
    n = next(node)
    assert(isinstance(n, ast.Module))



# Generated at 2022-06-12 04:54:45.072820
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test for FunctionDef
    func_body = ast.parse(
    '''
    def func():
        pass
    '''.strip()
    )
    func = func_body.body[0]
    expected = ast.Module(body = [func_body]), 0
    result = get_non_exp_parent_and_index(func_body, func)
    assert(result == expected)

    # Test for If condition
    if_body = ast.parse(
    '''
    def func():
        if 0:
            pass
    '''.strip()
    )
    if_cond = if_body.body[0].body[0].test
    expected = if_body.body[0], 0
    result = get_non_exp_parent_and_index(if_body, if_cond)

# Generated at 2022-06-12 04:54:52.890776
# Unit test for function replace_at
def test_replace_at():
    tree = ast.parse('a = 1')

    node = ast.parse('b = 2').body[0]
    replace_at(0, tree, node)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="b", ctx=Store())], value=Num(n=2))])'

    node = ast.parse('c = 3').body[0]
    replace_at(0, tree, node)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="c", ctx=Store())], value=Num(n=3))])'

# Generated at 2022-06-12 04:54:54.130397
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:55:01.001209
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """
    Get non-Exp parent and index of child
    """
    ast_tree = ast.parse(
        "def foo():\n"
        "    b = [x+k for x in range(10) if x % 2 == 0]\n"
    )
    assert ([get_parent(ast_tree, x) for x in ast_tree.body[0].body] ==
            [ast_tree.body[0] for x in range(2)])

    actual = get_non_exp_parent_and_index(ast_tree,
                                          ast_tree.body[0].body[0])
    assert actual == (ast_tree.body[0], 0)



# Generated at 2022-06-12 04:55:05.892655
# Unit test for function find
def test_find():

    code = "class A:\n  def __init__(self):\n    self.a = 1"
    tree = ast.parse(code)

    assert(len(list(find(tree, ast.ClassDef))) == 1)  # noqa
    assert(len(list(find(tree, ast.FunctionDef))) == 1)  # noqa
    assert(len(list(find(tree, ast.Name))) == 4)  # noqa


# Generated at 2022-06-12 04:55:09.989132
# Unit test for function find
def test_find():
    code = """
    class A:
        def __init__(self, a, b):
            pass
        def foo(self, a, b):
            pass
    """

    tree = ast.parse(code)
    nodes = find(tree, ast.ClassDef)
    assert len(list(nodes)) == 1
    nodes = find(tree, ast.FunctionDef)
    assert len(list(nodes)) == 2

# Generated at 2022-06-12 04:55:10.482981
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:55:18.699366
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    __ast = ast.parse(
        'for i in range(10):\n\tpass\nelse: pass',
        's',
        'exec'
    )
    __parents = _build_parents(__ast)
    __expected_parent = __ast.body[0]

    __result_parent, __result_index = get_non_exp_parent_and_index(__ast, __ast.body[0].body[0])

    print(__result_parent)
    print(__result_index)

    if __result_parent == __expected_parent and __result_index == 0:
        print("SUCCESS")
    else:
        print("FAILED")

# Generated at 2022-06-12 04:55:22.466570
# Unit test for function find
def test_find():
    import untokenize
    import untokenize.tests.fixtures as fixtures
    import io
    import sys

    fixture = fixtures.params_fixture('func')
    tree = ast.parse(fixture)
    _build_parents(tree)

    f = find(tree, ast.FunctionDef).__next__()
    out = io.StringIO()
    sys.stdout = out
    print(f.name)
    sys.stdout = sys.__stdout__
    assert out.getvalue().strip() == 'func'

# Generated at 2022-06-12 04:56:51.480998
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class CustomNode(ast.AST):
        _fields = ()

    #Test1: regular case
    tree = ast.parse('''
    def foo():
       pass
    ''')
    parent, idx = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert tree.body[0].body[0] == parent.body[idx]
    assert parent is tree.body[0]
    assert idx == 0

    # Test2: nested custom node
    tree = ast.parse('''
    def foo():
        bar = CustomNode()
        bar.do_something()
    ''')
    parent, idx = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

# Generated at 2022-06-12 04:56:54.419194
# Unit test for function find
def test_find():
    with open('tests/samples/python_sample.py') as f:
        tree = ast.parse(f.read())

    functions = [f for f in find(tree, ast.FunctionDef)]

    assert len(functions) == 1
    assert functions[0].name == 'func'

# Generated at 2022-06-12 04:57:02.394650
# Unit test for function get_parent
def test_get_parent():
    """A function to test Parser.get_parent().

    1. Tests whether the function returns the correct parent when
    the node is an argument in the node.body list.
    2. Tests whether the function returns the correct parent when
    the node is not in the node.body list.
    3. Tests whether the function returns the correct parent when
    the node is the first node in the node.body list.
    4. Tests whether the function raises NodeNotFound when the node
    does not have a parent.
    """
    class Node(ast.AST):
        """A dummy class to test get_parent."""
        _fields = ()

        def __init__(self, body):
            """Initialize Node."""
            self.body = body

    node_1 = Node(['a'])
    node_2 = Node(['b'])


# Generated at 2022-06-12 04:57:11.727965
# Unit test for function get_parent
def test_get_parent():
    class A(): pass
    class B(): pass
    class C(): pass

    a = A()
    b = B()
    c = C()

    assert _parents[a] == None
    assert _parents[b] == None
    assert _parents[c] == None

    _parents[b] = a

    assert _parents[a] == None
    assert _parents[b] == a
    assert _parents[c] == None

    assert get_parent(a, b, rebuild=True) == a
    assert get_parent(a, a, rebuild=True) == None

    assert get_parent(b, b, rebuild=True) == None
    assert get_parent(b, a, rebuild=True) == b
    assert get_parent(b, c, rebuild=True) == None

    _parents[c] = b



# Generated at 2022-06-12 04:57:15.968956
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    mod = ast.parse("""
for i in range(10):
    for j in range(10):
        if j < 5:
            print(j)
    """)
    for_stmt = mod.body[0]
    child = for_stmt.body[0].body[0]
    print(get_closest_parent_of(mod, child, ast.For))

# Generated at 2022-06-12 04:57:16.726601
# Unit test for function replace_at

# Generated at 2022-06-12 04:57:17.944908
# Unit test for function get_parent
def test_get_parent():
    print('Test function get_parent')

# Generated at 2022-06-12 04:57:20.508289
# Unit test for function find
def test_find():
    input_ = ast.parse('x = 1 + 1\n')
    inputs = {}
    for node in find(input_, ast.Assign):
        inputs = node.targets[0].id
    assert inputs == 'x'
