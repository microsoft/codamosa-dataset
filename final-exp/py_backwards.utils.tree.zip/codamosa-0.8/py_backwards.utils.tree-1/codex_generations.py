

# Generated at 2022-06-12 04:47:20.230135
# Unit test for function find

# Generated at 2022-06-12 04:47:22.733068
# Unit test for function find
def test_find():
    node = ast.parse('1 + 1 * 2')
    result = [node for node in find(node, ast.BinOp)]
    assert len(result) == 2


# Generated at 2022-06-12 04:47:27.891935
# Unit test for function find
def test_find():
    code = """
    def foo():
        if a:
            return
    """
    tree = ast.parse(code)
    for x in find(tree, ast.Return):
        assert isinstance(x.value, ast.Name)

    for x in find(tree, ast.If):
        assert isinstance(x.test, ast.Name)

# Generated at 2022-06-12 04:47:30.989779
# Unit test for function replace_at
def test_replace_at():
    test1 = ast.parse('a = b')
    test_parent = test1.body[0]
    replace_at(1, test_parent, ast.Num(4))
    assert test1.body[0].value.n == 4


# Generated at 2022-06-12 04:47:32.796363
# Unit test for function find

# Generated at 2022-06-12 04:47:38.199676
# Unit test for function insert_at
def test_insert_at():
    func = ast.parse('a = 1; b = 2; c = 3; d = 4;').body[0]
    insert_at(2, func, ast.parse('e = 5; f = 6;').body)
    assert str(func) == 'a = 1; b = 2; e = 5; f = 6; c = 3; d = 4;'



# Generated at 2022-06-12 04:47:39.547094
# Unit test for function find

# Generated at 2022-06-12 04:47:40.455275
# Unit test for function find
def test_find():
    find(ast.parse('foo'), ast.AST)

# Generated at 2022-06-12 04:47:45.308743
# Unit test for function find
def test_find():
    import astor

    # Finds all nodes with Assign
    # class Assign(expr* targets, expr value, string? type_comment)
    ast_mod = ast.parse('a = 1\nb = 2')
    for node in find(ast_mod, ast.Assign):
        print(astor.to_source(node))



# Generated at 2022-06-12 04:47:50.514695
# Unit test for function find
def test_find():
    import unittest
    from . import shared
    
    facts = shared.get_facts()
    
    class TestFind(unittest.TestCase):
    
        def test_find_first(self):
            result = next(find(facts, ast.FunctionDef))
            self.assertIsNotNone(result)
            # TODO: Can write better test cases
    
    unittest.main(exit=False)

# Generated at 2022-06-12 04:47:56.887953
# Unit test for function find

# Generated at 2022-06-12 04:48:02.539379
# Unit test for function find
def test_find():
    m = ast.parse("a = lambda x: x")
    assert list(find(m, ast.Name)) == [ast.Name(id='a', ctx=ast.Store()), ast.Name(id='x', ctx=ast.Param()), ast.Name(id='x', ctx=ast.Load())]

# Generated at 2022-06-12 04:48:03.154917
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert 1 == 2

# Generated at 2022-06-12 04:48:07.883473
# Unit test for function find
def test_find():
    from unittest import TestCase
    
    class NodeTestCase(TestCase):
        def assert_finds(self, code: str, expected: str) -> None:
            tree = ast.parse(code)
            self.assertEqual([node.name for node in find(tree, ast.Name)],
                             expected.split(' '))
    
    class Case1(NodeTestCase):
        def test_1(self):
            self.assert_finds("x", "x")
    
    class Case2(NodeTestCase):
        def test_1(self):
            self.assert_finds("x+x", "x x")
    
    class Case3(NodeTestCase):
        def test_1(self):
            self.assert_finds("def f(x):return x", "f x")


# Generated at 2022-06-12 04:48:14.159149
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class ClassDef(ast.AST):
        _fields = ['name', 'body']
        _attributes = ['name']

    def func(a, b):
        return a + b

    tree = ast.parse(inspect.getsource(func))
    node = tree.body[0].body[0].value
    closest = get_closest_parent_of(tree, node, type_=ClassDef)
    assert not hasattr(closest, 'body')
    assert hasattr(closest, 'name')

# Generated at 2022-06-12 04:48:17.470377
# Unit test for function find
def test_find():
    code = """
    def foo():
        pass

    def bar():
        pass
    """

    tree = ast.parse(code)
    function_definitions = find(tree, ast.FunctionDef)

    assert len(list(function_definitions)) == 2

# Generated at 2022-06-12 04:48:21.869614
# Unit test for function find
def test_find():
    import astor

    code = open('example.py', 'r').read()
    tree = ast.parse(code)
    names = [name.id for name in find(tree, ast.Name)]
    print(names)

    # ast.dump(tree)



# Generated at 2022-06-12 04:48:22.750230
# Unit test for function get_parent

# Generated at 2022-06-12 04:48:30.707611
# Unit test for function get_parent
def test_get_parent():
    tree_str = 'def a(): return False'
    tree = ast.parse(tree_str)
    _build_parents(tree)
    node = tree.body[0]
    assert get_parent(tree, node) == tree

    tree_str = 'def a(): return False'
    tree = ast.parse(tree_str)
    _build_parents(tree)
    node = tree.body[0].body[0]
    assert get_parent(tree, node) == tree.body[0]


# Generated at 2022-06-12 04:48:39.374059
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_ast = ast.parse("""
        def func():
            if True:
                x = 3
            else:
                x = 4""")
    test_ast_body = test_ast.body[0].body
    test_if = test_ast_body[0]
    test_else = test_if.orelse[0]
    test_assignment_1 = test_if.body[0]
    test_assignment_2 = test_else.body[0]
    assert get_non_exp_parent_and_index(test_ast, test_assignment_1) == (test_if, 0)
    assert get_non_exp_parent_and_index(test_ast, test_assignment_2) == (test_else, 0)

# Generated at 2022-06-12 04:48:49.621842
# Unit test for function replace_at
def test_replace_at():
    from . import Module
    from . import FunctionDef
    from . import Return

    tree = Module([FunctionDef('fn', ['a', 'b'], [Return(1)])])

    function_def_node = tree.body[0]
    return_node = function_def_node.body[0]

    replace_at(0, function_def_node, Return(2))

    assert function_def_node.body == [Return(2)]

    replace_at(0, function_def_node, Return(2), Return(3))

    assert function_def_node.body == [Return(2), Return(3)]

    replace_at(1, function_def_node, Return(4))

    assert function_def_node.body == [Return(2), Return(4)]


# Generated at 2022-06-12 04:48:57.153032
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import inspect
    import main

    f_code = """if x:\n    raise ValueError()\n"""
    tree = ast.parse(f_code)
    f_call = get_closest_parent_of(
        tree, tree.body[0].body[0].body[0], ast.FunctionDef)
    raise_stmt = f_call.body[0].body[0]
    assert get_non_exp_parent_and_index(tree, raise_stmt) == (f_call, 0)


# Generated at 2022-06-12 04:49:01.961638
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    src = """
    def f():
        for i in range(2):
            for j in range(2):
                pass
    """
    tree = ast.parse(src)
    target = next(find(tree, ast.For))
    cl_prt = get_closest_parent_of(tree, target, ast.FunctionDef)
    assert isinstance(cl_prt, ast.FunctionDef)

# Generated at 2022-06-12 04:49:10.737514
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''{
        # Comment inside dict
        'a': 1,
        'b': 2
    }''')

    assert get_parent(tree, tree.body[0].value.values[1]).__class__.__name__ == \
        'Dict'
    assert get_parent(tree, tree.body[0].value.values[1].n).__class__.__name__ == \
        'Num'
    assert get_parent(tree, tree.body[0].value.values[1]).__class__.__name__ == \
        'Dict'

# Generated at 2022-06-12 04:49:11.693055
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:49:17.571290
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Stmt isn't child of Exp
    tree = ast.parse('node()')
    assert get_non_exp_parent_and_index(tree, tree.body[0]) == (tree, 0)

    # Exp isn't direct child of Exp
    tree = ast.parse('(1, 2)')
    assert get_non_exp_parent_and_index(tree, tree.body[0].value.elts[0]) == \
           (tree, 0)



# Generated at 2022-06-12 04:49:27.160586
# Unit test for function find
def test_find():
    from sys import version_info
    from typed_ast import ast3

    if version_info.major == 2:
        from ast import fix_missing_locations


# Generated at 2022-06-12 04:49:28.631560
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """Unit test for function get_closest_parent_of."""
    pass

# Generated at 2022-06-12 04:49:32.371515
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('print(1)\nprint(2)').body[1]
    assert get_non_exp_parent_and_index(node, node.value) == (
        node, 0)



# Generated at 2022-06-12 04:49:36.520793
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1')
    node = tree.body[0].value
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.Module)
    assert parent.body[index] == node
    assert index == 0

# Generated at 2022-06-12 04:49:39.268460
# Unit test for function find
def test_find():
    pass


# Generated at 2022-06-12 04:49:48.884110
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test: simple
    source = source = """
    def foo():
        a = 1
        b = 2
    x = 3
    """
    tree = ast.parse(source)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert parent == tree
    assert index == 0
    # Test: embeded in a list
    source = """
    def foo():
        x = 1; foo(x)
    """
    tree = ast.parse(source)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1].value)
    assert isinstance(parent, ast.Call)
    assert index == 0
    # Test: embeded in a list

# Generated at 2022-06-12 04:49:56.399672
# Unit test for function find
def test_find():
    # Basic
    tree = ast.parse('''
    if x:
        print("If")
    else:
        print("Else")
    ''')
    assert len(tuple(find(tree, ast.If))) == 1
    assert len(tuple(find(tree, ast.Expr))) == 2
    assert len(tuple(find(tree, ast.Name))) == 3

    # Double nested
    tree = ast.parse('''
    if x:
        if y:
            print("If")
        else:
            print("Else")
    else:
        print("Else")
    ''')
    assert len(tuple(find(tree, ast.If))) == 2
    assert len(tuple(find(tree, ast.Expr))) == 4

# Generated at 2022-06-12 04:50:03.514491
# Unit test for function find
def test_find():
    import unittest
    t = ast.parse('def fun(x=0,y=True):\n pass', 'tmp.py')
    res = list(find(t, ast.Name))
    assert res == [ast.Name(id='fun', ctx=ast.Load(),lineno=1,col_offset=4),
                   ast.Name(id='x', ctx=ast.Param(),lineno=1,col_offset=9),
                   ast.Name(id='y', ctx=ast.Param(),lineno=1,col_offset=13),
                   ast.Name(id='pass', ctx=ast.Load(),lineno=2,col_offset=7)]
    res = list(find(t, ast.keyword))

# Generated at 2022-06-12 04:50:09.733619
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    generated_tree = ast.parse("""
        def foo(a):
            b = 0
            c = 3 + 4
            for i in range(1):
                a = 4
            return a
        """)
    expected_result = (generated_tree.body[0], 3)
    assert(get_non_exp_parent_and_index(generated_tree,
                                        generated_tree.body[0].body[3])
           == expected_result)

# Generated at 2022-06-12 04:50:11.497717
# Unit test for function find
def test_find():
    import typed_ast.ast3


# Generated at 2022-06-12 04:50:12.722705
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:50:13.315556
# Unit test for function get_parent
def test_get_parent():
    pass

# Generated at 2022-06-12 04:50:19.711398
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    def if_a_gt_b_return_one():
        a = 1
        b = 2
        if a > b:
            return 1
        else:
            return 2

    tree = ast.parse(astor.to_source(if_a_gt_b_return_one))
    nodes = list(find(tree, ast.Stmt))
    expected = (nodes[1], 0)
    result = get_non_exp_parent_and_index(tree, nodes[2])
    assert expected == result


# Generated at 2022-06-12 04:50:21.109047
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:50:26.501706
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:50:27.529804
# Unit test for function find

# Generated at 2022-06-12 04:50:32.451049
# Unit test for function find
def test_find():
    node1 = ast.Print(ast.Name('foo', ast.Load()), [])
    node2 = ast.Print(ast.Name('bar', ast.Load()), [])
    node3 = ast.Print(ast.Name('baz', ast.Load()), [])
    tree = ast.Module([node1, node2, node3])
    assert list(find(tree, ast.Print)) == [node1, node2, node3]



# Generated at 2022-06-12 04:50:36.532379
# Unit test for function get_parent
def test_get_parent():
    from . import parser
    from . import syntax
    import astunparse

    p = parser.Parser('helpers.test')
    t = p.parse()

    t = t.body[2]
    test = t.body[2]
    parent = get_parent(t, test)
    assert parent is t


# Generated at 2022-06-12 04:50:41.816882
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from .helpers import get_node

    _build_parents(get_node('def foo():\n    return 1\n'))
    assert _parents[get_node('1')] == get_node('return 1')
    assert _parents[get_node('return 1')] == get_node('def foo():')
    assert get_non_exp_parent_and_index(None, None) == (None, 0)

# Generated at 2022-06-12 04:50:48.991850
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('for i in range(3): pass')
    body = get_closest_parent_of(tree, tree.body[0].body[0], ast.For)
    test = get_non_exp_parent_and_index(tree, body)
    assert test == (tree.body[0], 0)

    insert_at(0, tree.body[0], ast.parse('def test(): pass'))
    test = get_non_exp_parent_and_index(tree, body)
    assert test == (tree.body[0], 1)

# Generated at 2022-06-12 04:50:54.100460
# Unit test for function find
def test_find():
    # ast3.parse("__all__ = ['foo', 'bar']")
    tree = ast.Module(
        body=[
            ast.Assign(
                targets=[
                    ast.Name(
                        id='__all__',
                        ctx=ast.Store())],
                value=ast.List(
                    elts=[
                        ast.Str(s='foo'),
                        ast.Str(s='bar')],
                    ctx=ast.Load()))])

    assert list(find(tree, ast.Str)) == [ast.Str(s='foo'), ast.Str(s='bar')]

# Generated at 2022-06-12 04:50:56.190365
# Unit test for function find
def test_find():
    def func():
        a = 1
        b = 1 + 2
        c = a + b
        func()

    tree = ast.parse(func.__code__.co_consts[-1])
    print(list(find(tree, ast.Num)))

# Generated at 2022-06-12 04:50:57.354697
# Unit test for function find

# Generated at 2022-06-12 04:51:03.712990
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class A():
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C, B):
        pass

    def f():
        pass

    s = f.__code__.co_consts[0]
    tree = ast.parse(s)

    # get_closest_parent_of(tree, node, type_)
    node = tree.body[0]
    assert get_closest_parent_of(tree, node, ast.FunctionDef) == node
    assert get_closest_parent_of(tree, node, D) == tree
    # assert get_closest_parent_of(tree, node, C) == tree
    # assert get_closest_parent_of(tree, node, B) == tree
    # assert get_

# Generated at 2022-06-12 04:51:14.066773
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:51:21.481024
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astwild
    m = astwild.parse('def a(b, c=d())')
    assert get_non_exp_parent_and_index(m, m.body[0].args.args[0]) == (m.body[0], 0)
    assert get_non_exp_parent_and_index(m, m.body[0].decorator_list[0]) == (m.body[0], 0)
    assert get_non_exp_parent_and_index(m, m.body[0].args.defaults[0]) == (m.body[0].args, 2)

# Generated at 2022-06-12 04:51:27.045081
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('x = 1')
    assert get_parent(tree, tree.body[0].value) == tree.body[0]

    for node in tree.body[0].body[0].body:
        assert get_parent(tree, node) == tree.body[0].body[0].body



# Generated at 2022-06-12 04:51:32.169240
# Unit test for function get_parent
def test_get_parent():
    func = ast.parse("""
            def foo():
                if True:
                    return ''
                return ''
            """).body[0]
    assert get_parent(func, func.body[0]) == func
    assert get_parent(func, func.body[0].body[0]) == func.body[0]



# Generated at 2022-06-12 04:51:33.689757
# Unit test for function get_parent

# Generated at 2022-06-12 04:51:37.857844
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
    foo = 1
    print(foo)
    ''')

    foo = find(tree, ast.Name).next()  # type: ignore
    non_exp_parent, index = get_non_exp_parent_and_index(tree, foo)

    assert non_exp_parent.body[index] == foo

# Generated at 2022-06-12 04:51:43.921023
# Unit test for function replace_at
def test_replace_at():
    func = ast.FunctionDef("a", ast.arguments(), [], None, None)
    call = ast.Call()
    insert_at(0, func, call)
    if len(func.body) == 0:
        raise AssertionError("insert_at does not work")
    replace_at(0, func, ast.Load())
    if len(func.body) != 1:
        raise AssertionError("replace_at does not work")

# Generated at 2022-06-12 04:51:49.088244
# Unit test for function find
def test_find():
    import astor
    source = "def f1 ():\n    print('hello')\n\ndef f2():\n    print('world')\n"
    tree = ast.parse(source)
    functions = list(find(tree, ast.FunctionDef))
    assert len(functions) == 2
    assert functions[0].name == 'f1'
    assert functions[1].name == 'f2'


# Generated at 2022-06-12 04:51:50.600403
# Unit test for function find

# Generated at 2022-06-12 04:51:55.569086
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    tree = astor.parse_file('/home/me/test1.py')
    call = find(tree, ast.Call).next()
    parent = get_non_exp_parent_and_index(tree, call)
    print(parent)


if __name__ == '__main__':
    test_get_non_exp_parent_and_index()

# Generated at 2022-06-12 04:52:21.102340
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1')
    # node is the '1' in 'a = 1'
    node = tree.body[0].value
    assert get_parent(tree, node) == tree.body[0]
    assert get_parent(tree, tree.body[0], rebuild=True) == tree

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-12 04:52:28.840554
# Unit test for function find

# Generated at 2022-06-12 04:52:30.861365
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..utils.ast_util import get_ast

# Generated at 2022-06-12 04:52:40.007742
# Unit test for function find
def test_find():
    """Test function 'find'
    
    Comparing result of get_closest_parent_of and find function
    """
    from . import test_utils
    import os
    import astor
    from astor.code_gen import to_source
    from typed_ast import ast3

    def test_one_example(file_path: str) -> None:
        """Test one example code."""
        source_code = test_utils.read_file(file_path)
        source_tree = ast3.parse(source_code, file_path)
        _build_parents(source_tree)

        # Replace all 'AstroidInvalidType' to 'ast.AST'
        def is_astroid_valid(node: ast3.AST) -> bool:
            return isinstance(node,
                              ast3.Name) and node

# Generated at 2022-06-12 04:52:41.627041
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse("def foo(): pass"), ast.FunctionDef))) == 1


# Generated at 2022-06-12 04:52:42.137753
# Unit test for function get_parent

# Generated at 2022-06-12 04:52:45.141225
# Unit test for function find
def test_find():  # pragma: no cover
    tree = ast.parse("""def func(): pass""")
    assert len(list(find(tree, ast.FunctionDef))) == 1
    assert len(list(find(tree, ast.Assign))) == 0

# Generated at 2022-06-12 04:52:52.646907
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = "def foo(x):\na = [6, 7, 8]"
    tree = ast.parse(code)
    non_exp_parent_and_index = get_non_exp_parent_and_index(tree, tree.body[0])
    parent = non_exp_parent_and_index[0]
    index = non_exp_parent_and_index[1]
    assert (isinstance(parent, ast.Module))
    assert (index == 0)
    assert (parent.body[0] == tree.body[0])


# Generated at 2022-06-12 04:52:53.803408
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:52:57.934551
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    exp = ast.parse("a=1\nc=2\nd=3")
    astor.dump(exp)
    c = exp.body[2].value
    assert get_non_exp_parent_and_index(exp, c) == (exp, 2)

# Generated at 2022-06-12 04:53:54.117553
# Unit test for function get_parent
def test_get_parent():
    import astor

    source = """
    def f():
        try:
            x = 1
        except:
            print(x)
    """
    tree = astor.parse_file(source)

    rename_vars(tree)

    with open('tree.py', 'w') as f:
        f.write(astor.to_source(tree))


if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-12 04:53:55.656860
# Unit test for function get_parent
def test_get_parent():
    fake_module = ast.parse("x = 9")
    x = get_parent(fake_module, fake_module.body[0].value)
    assert x == fake_module.body[0]



# Generated at 2022-06-12 04:53:58.910667
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_src = """
    def foo():
        print(1)
    """
    tree = ast.parse(ast_src)
    node = tree.body[0].body[0].value
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert parent.name == 'foo'



# Generated at 2022-06-12 04:54:03.492081
# Unit test for function find
def test_find():
    import astor
    tree = ast.parse('a=1; b=2;')
    for node in find(tree, ast.Assign):
        print('Found assign')
        print(astor.to_source(node).strip())



# Generated at 2022-06-12 04:54:05.812461
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('x += 1'), ast.Assign))) == 1

# Generated at 2022-06-12 04:54:06.816158
# Unit test for function find

# Generated at 2022-06-12 04:54:09.982114
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('[x for x in range(0, 5)]')
    comprehension = get_parent(tree, tree.body[0].value)  # type: ignore
    assert isinstance(comprehension, ast.comprehension)

    with pytest.raises(NodeNotFound):
        get_parent(tree, ast.Module(body=[]))

# Generated at 2022-06-12 04:54:15.047440
# Unit test for function find
def test_find():
    example = """def test():
    def a():
        if True:
            return a
    return a"""
    tree = ast.parse(example)

    # Find nodes of type 'Name'
    assert len(list(find(tree, type(ast.Name)))) == 2

    # Find nodes of type 'If'
    assert len(list(find(tree, type(ast.If)))) == 1

# Generated at 2022-06-12 04:54:17.049094
# Unit test for function get_parent

# Generated at 2022-06-12 04:54:21.050530
# Unit test for function find
def test_find():
    # Test for find function
    tree = ast.parse("a = 1; b = 2; c = 3;")
    assert [node.id for node in find(tree, ast.Assign)] == ['a', 'b', 'c']  # a,b,c


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:55:21.141588
# Unit test for function replace_at
def test_replace_at():
    class A(ast.AST):
        _fields = ('a', 'b')
    class B(ast.AST):
        _fields = ('b', 'a')
    class C(ast.AST):
        _fields = ('c',)

    node1 = C(c=A(a=A(a=B(b=None, a=A(a=C(c=None), b=None)), b=None),
                  b=C(c=A(a=None, b=None))))

    node2 = C(c=A(a=A(a=B(b=None, a=A(a=C(c=None), b=None)), b=None),
                  b=C(c=A(a=None, b=None))))


# Generated at 2022-06-12 04:55:28.022249
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_tree = ast.parse('''
        import test
        if True:
            test.do()
    ''')

    assert isinstance(get_closest_parent_of(test_tree, test_tree.body[1], ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(test_tree, test_tree.body[1], ast.If), ast.If)
    assert isinstance(get_closest_parent_of(test_tree, test_tree.body[1], ast.Import), None)

# def get_outer_function(tree: ast.AST, node: ast.AST) -> T:
#     """Get outer function containing node."""
#     parent = node

#     while True:
#         parent = get_parent(tree, parent)

# Generated at 2022-06-12 04:55:35.025164
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:55:38.482870
# Unit test for function find
def test_find():
    test = 'a = 2 + 3'
    tree = ast.parse(test)

    assert len(list(find(tree, ast.Expr))) == 1
    assert len(list(find(tree, ast.Num))) == 2
    assert len(list(find(tree, ast.Add))) == 1

# Generated at 2022-06-12 04:55:45.515180
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    print("Testing get_non_exp_parent_and_index ...")

    # Second value in body is a node
    node = ast.parse(
        "def foo():\n"
        "    x = 3\n"
        "    y = 4\n"
        "    z = 5\n"
        "    return x\n"
        "    return y\n"
        "    return z\n"
    )

    parent, index = get_non_exp_parent_and_index(node, node.body[1].value)

    assert parent.__class__.__name__ == 'FunctionDef'
    assert index == 1

    print("Test passed")
    print()



# Generated at 2022-06-12 04:55:48.495099
# Unit test for function find
def test_find():
    def test():
        print('hi')

    tree = ast.parse(test.__code__.co_code, mode='exec')

    for node in find(tree, ast.Name):
        assert node.id == 'print'



# Generated at 2022-06-12 04:55:52.973289
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a = 1', mode='eval')  # type: ignore
    node = tree.body.value                        # type: ignore
    expected_parent = tree.body                   # type: ignore
    expected_index = 0
    actual_parent, actual_index = get_non_exp_parent_and_index(tree, node)
    assert expected_parent == actual_parent
    assert expected_index == actual_index



# Generated at 2022-06-12 04:56:02.086089
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..parser import parse_code

    source = '''
    def foo(a, b, c):
        if a > 0:
            if b > 0:
                for i in range(0, 10):
                    if c > 0:
                        return 10
            return 20
        return 30
    '''
    tree = parse_code(source)

    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0],
                                            ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, tree.body[0].body[0], ast.If),
                      ast.If)

# Generated at 2022-06-12 04:56:05.710103
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('class C:\n    @deco\n    def m(self):\n        pass')

    assert (get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0]) ==
            (tree.body[0], 1))

# Generated at 2022-06-12 04:56:06.590441
# Unit test for function get_parent