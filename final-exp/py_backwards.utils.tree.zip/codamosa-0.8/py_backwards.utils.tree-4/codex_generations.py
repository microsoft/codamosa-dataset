

# Generated at 2022-06-12 04:47:25.977794
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test function get_non_exp_parent_and_index."""
    tree = ast.parse('a = 1 + 2')
    assignment = tree.body[0]
    binop = assignment.value
    one = binop.left

    non_exp_parent, index = get_non_exp_parent_and_index(tree, one)

    assert isinstance(non_exp_parent, ast.Module)
    assert index == 0

# Generated at 2022-06-12 04:47:31.733694
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():  # pylint: disable=no-self-use
    import inspect
    import astor

    source = inspect.getsource(test_get_non_exp_parent_and_index)
    tree = ast.parse(source)
    exp, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    exp_str = astor.to_source(exp, indent_with=' ' * 4)
    assert exp_str.strip() == source.strip()
    asser

# Generated at 2022-06-12 04:47:38.496977
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class_name = ast.Name(id='MyClass', ctx=ast.Store())
    class_def = ast.ClassDef(name='MyClass', body=[], decorator_list=[])
    module = ast.Module(body=[class_def])

    parent, index = get_non_exp_parent_and_index(module, class_name)

    assert parent == class_def
    assert index == 0



# Generated at 2022-06-12 04:47:44.933790
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_tree = ast.parse(
        """
            if (True):
                (a, b) = (c, d)
                x = 5 + a + b
            else:
                x = 5 + c
        """
    )
    parent, index = get_non_exp_parent_and_index(test_tree, test_tree.body[0].body[0])
    assert parent.__class__.__name__ == "If"
    assert index == 1

# Generated at 2022-06-12 04:47:45.448504
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-12 04:47:54.115319
# Unit test for function find
def test_find():
    class Node(ast.AST):
        pass

    class Node1(ast.AST):
        pass

    class Node2(ast.AST):
        pass

    c1 = Node1()
    c2 = Node2()

    c11 = Node1()
    c12 = Node1()

    c111 = Node1()
    c112 = Node1()

    c1111 = Node1()
    c1112 = Node1()

    c11111 = Node1()
    c11112 = Node1()

    c11112.children = [c11111]
    c111.children = [c1111, c1112]
    c11.children = [c111, c112]
    c1.children = [c11]

    c21 = Node1()
    c22 = Node2()
    c23 = Node1()

   

# Generated at 2022-06-12 04:48:02.445522
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    root = ast.parse('''
    def sum(a, b):
        return a + b
    sum(1, 2)
    ''')
    assert isinstance(get_closest_parent_of(root, root.body[0].body[0].value, ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(root, root.body[0].body[0].value, ast.Module), ast.Module)

if __name__ == '__main__':
    test_get_closest_parent_of()

# Generated at 2022-06-12 04:48:04.509779
# Unit test for function find
def test_find():
    node = ast.parse("x = 1")
    assert list(find(node, ast.Assign)) == [node.body[0]]


# Generated at 2022-06-12 04:48:08.983596
# Unit test for function find
def test_find():
    tree = ast.parse("""
    if a == 42:
        b = 23
        c = 42
        if b > c:
            b = 0
    b = 42
    """)

    for node in find(tree, ast.If):
        print(node)



# Generated at 2022-06-12 04:48:16.972059
# Unit test for function find
def test_find():
    import astor
    tree = ast.parse("(1+1)\n2+2")
    assert len(list(find(tree, ast.Add))) == 2

    tree = ast.parse("a=1\n(1+1)\n2+2")
    assert len(list(find(tree, ast.Add))) == 2
    assert len(list(find(tree, ast.Assign))) == 1

    tree = ast.parse("a=1\n(1+1)\n2+2")
    node = ast.Num(100)
    get_non_exp_parent_and_index(tree, node)



# Generated at 2022-06-12 04:48:27.280659
# Unit test for function insert_at
def test_insert_at():
    function_def = ast.parse('def f(): pass').body[0]
    class_def = ast.parse('class f(): pass').body[0]

    assert function_def.body == []
    assert class_def.body == []

    insert_at(0, function_def, ast.Pass())
    insert_at(1, function_def, ast.Pass())
    assert isinstance(function_def.body[0], ast.Pass)
    assert isinstance(function_def.body[1], ast.Pass)

    insert_at(0, class_def, ast.Pass())
    insert_at(1, class_def, ast.Pass())
    assert isinstance(class_def.body[0], ast.Pass)
    assert isinstance(class_def.body[1], ast.Pass)



# Generated at 2022-06-12 04:48:35.833272
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Func(ast.AST):
        body = []

    class Class(ast.AST):
        body = []

    class Module(ast.AST):
        body = []

    def get_code(parent, child):
        return (
            ast.parse(dedent('''
                import ast
                import enum
                class A(enum.Enum):
                    B = 1
                {parent}.body = [{child}]
            '''.format(parent=parent, child=child)))
        )

    assert isinstance(get_closest_parent_of(get_code('Class', 'Func'),
                                            Func()), Class)
    assert isinstance(get_closest_parent_of(get_code('Module', 'Class'),
                                            Class()), Module)

# Generated at 2022-06-12 04:48:39.846432
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    exp = ast.parse('string = "hello world"')
    parent, index = get_non_exp_parent_and_index(exp, exp.body[0])
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-12 04:48:45.387509
# Unit test for function replace_at
def test_replace_at():
    # Given
    class TestBody(ast.AST):
        _fields = ('body',)

    test_body = TestBody()
    test_body.body = [ast.parse('a = 1')]

    # When
    replace_at(0, test_body, ast.parse('b = 1'))

    # Then
    assert test_body.body[0] == ast.parse('b = 1').body[0]

# Generated at 2022-06-12 04:48:57.153567
# Unit test for function get_parent
def test_get_parent():
    node = ast.parse("if 1: x=2")
    test_tree = ast.parse("if 1: x=2"
                          "\n    print(x)"
                          "\n    if 2: y=1"
                          "\n        print(y)")
    parent = get_parent(test_tree, node)
    assert isinstance(parent, ast.Module)

    node = ast.parse("print(x)")
    parent = get_parent(test_tree, node)
    assert isinstance(parent, ast.If)

    node = ast.parse("print(y)")
    parent = get_parent(test_tree, node)
    assert isinstance(parent, ast.If)

    node = ast.parse("y=1")
    parent = get_parent(test_tree, node)

# Generated at 2022-06-12 04:49:01.692580
# Unit test for function find
def test_find():
    code = textwrap.dedent("""\
    def a():
        pass
    """)
    tree = ast.parse(code)
    assert list(find(tree, ast.FunctionDef)) == tree.body  # type: ignore
    assert list(find(tree, ast.Module)) == [tree]
    assert list(find(tree, ast.Return)) == []



# Generated at 2022-06-12 04:49:11.219593
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('a = 1 / 2')
    print(tree)
    body = tree.body
    print('body = {}'.format(body))

    # Get parent of `1`
    bin_exp = body[0].value
    print('bin_exp = {}'.format(bin_exp))
    one = bin_exp.left
    print('1 = {}'.format(one))
    parent = get_parent(tree, one)
    print('Parent of 1 is {}'.format(parent.__class__.__name__))

    test_bin_exp = type(parent) == ast.BinOp
    assert test_bin_exp

# Generated at 2022-06-12 04:49:19.361962
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = (
        ast.Module(
            body=[
                ast.FunctionDef(
                    name='foo',
                    args=ast.arguments(
                        args=[],
                        kwonlyargs=[],
                        vararg=None,
                        kwarg=None,
                        defaults=[],
                        kw_defaults=[]
                    ),
                    body=[],
                    decorator_list=[],
                    returns=None
                )
            ]
        )
    )

    assert(get_closest_parent_of(tree, tree.body[0].body, ast.Module)
           == tree)
    assert(get_closest_parent_of(tree, tree.body[0].body, ast.FunctionDef)
           == tree.body[0])

# Generated at 2022-06-12 04:49:26.979055
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('''
        if True:
            pass
        if False:
            pass
        if True:

    ''')
    if_node = tree.body[2]
    assert get_parent(tree, if_node) == tree
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[1]) == tree
    assert get_parent(tree, ast.Name(id='True')) == if_node
    assert get_parent(tree, ast.Name(id='False')) == tree.body[1]

# Generated at 2022-06-12 04:49:28.070658
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:49:41.291440
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = '''
    def func():
        a = 1
        b = 2
        try:
            a = 3
            b = 4
        except Exception:
            pass
        finally:
            print(b)

    func()
    '''
    tree = ast.parse(code)
    node = list(find(tree, ast.Name))[-1]
    print(get_closest_parent_of(tree, node, ast.Try).finalbody[0].value)

# Generated at 2022-06-12 04:49:45.640943
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    node = ast.parse('func(1, x=2)').body[0].args[1]
    tree = ast.parse('def func(a, x=1):\n\tfunc(1, x=2)')
    assert node == get_closest_parent_of(tree, node=node, type_=ast.Call)



# Generated at 2022-06-12 04:49:48.404863
# Unit test for function find
def test_find():
    node = ast.parse('for i in range(10): print(i)')
    assert len(list(find(node, ast.For))) == 1



# Generated at 2022-06-12 04:49:56.105553
# Unit test for function find
def test_find():
    from .fixtures import test_find_node, test_find_node_with_type
    from .fixtures import test_find_multiple_nodes, \
        test_find_multiple_nodes_with_type

    # Test node with type
    assert test_find_node_with_type in list(find(test_find_node,
                                                 ast.Name))

    # Test node without type
    assert test_find_node in list(find(test_find_node, ast.AST))

    # Test multiple nodes with type
    test_find_nodes = find(test_find_multiple_nodes, ast.Name)
    assert test_find_node_with_type in test_find_nodes
    assert test_find_multiple_nodes_with_type in test_find_nodes

    # Test multiple nodes

# Generated at 2022-06-12 04:49:57.248909
# Unit test for function find

# Generated at 2022-06-12 04:50:01.239197
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def func(a, b):
        a = ([1, 2, 3], 3)
    """)
    result, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].value)
    assert result == tree.body[0]
    assert index == 0

# Generated at 2022-06-12 04:50:03.317961
# Unit test for function find
def test_find():
    tree = ast.parse('a + b')
    nodes = list(find(tree, ast.BinOp))
    assert nodes[0].op == ast.Add()

# Generated at 2022-06-12 04:50:04.367494
# Unit test for function replace_at

# Generated at 2022-06-12 04:50:13.742948
# Unit test for function get_parent
def test_get_parent():
    source = "def func(a, b, c): a + b + c"
    module = ast.parse(source, '<input>', 'exec')

    func = find(module, ast.FunctionDef).next()
    assert get_parent(module, func) == module

    b_arg = find(func, ast.arg).next()
    assert get_parent(module, b_arg) == func

    b_name = find(func, ast.Name).next()
    assert get_parent(module, b_name) == b_arg

    # test rebuild
    del _parents[func]
    assert get_parent(module, func, rebuild=True) == module



# Generated at 2022-06-12 04:50:19.355188
# Unit test for function find
def test_find():
    tree = ast.parse(
        """
        x = 10
        y = x * 5
        print x
        if x == 10:
            pass
        else:
            print x
        """
    )

    # Creating list of ast nodes which are Name
    names = [getattr(name, 'id')  # type: ignore
             for name in find(tree, ast.Name)]

    assert names == ['__builtins__', 'False', 'None', 'True', 'x', 'x', 'x']

# Generated at 2022-06-12 04:50:30.705562
# Unit test for function get_parent
def test_get_parent():
    if __name__ == "__main__":
        code = """
        def add(a):
            if 'a':
                a = a + 1
                return a
        """
        tree = ast.parse(code)
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                parent = get_parent(tree, node)
                assert parent.__class__.__name__ == ast._If.__name__



# Generated at 2022-06-12 04:50:38.537431
# Unit test for function find
def test_find():
    test_node1 = ast.Name(id="test_name")
    test_node2 = ast.Name(id="test_name")
    test_node3 = ast.Name(id="test_name1")
    test_node4 = ast.Name(id="test_name2")
    test_ast = ast.Module(body=[ast.Assign(targets=[test_node1], value=test_node2), ast.Assign(targets=[test_node3], value=test_node4)])

    list_of_names_found = find(test_ast, ast.Name)
    list_of_names_found = [str(name) for name in list_of_names_found]
    assert "test_name" in list_of_names_found, "test_find function failed"

# Generated at 2022-06-12 04:50:43.034040
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""if True:
        print("1")
        if True:
            print("2")
    """)
    parent, index = get_non_exp_parent_and_index(tree,
        tree.body[0].body[0])  # type: ignore

    assert parent is tree.body[0]  # type: ignore
    assert index == 0

# Generated at 2022-06-12 04:50:45.358311
# Unit test for function find
def test_find():
    assert len(list(
        find(ast.parse("a = 1\na = 2"), ast.Assign)
    )) == 2


# Generated at 2022-06-12 04:50:52.058535
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    tree = ast.parse("""
                    # test1
                      def func():
                          var = []
                          var_1 = 2
                          for item in var:
                              pass

                      def func1():
                          var = 2
                          pass
    """)
    for_node = list(find(tree, ast.For))[0]
    parent = get_non_exp_parent_and_index(tree, for_node)
    print(astor.to_source(tree))
    assert isinstance(parent[0], ast.FunctionDef)
    assert parent[1] == 1

# Generated at 2022-06-12 04:50:53.736485
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from . import ast_parser as ast_parser


# Generated at 2022-06-12 04:50:58.305387
# Unit test for function find
def test_find():
    tree = ast.parse(
        """def f(a):
            print(a)
            return a
        """
    )
    assert list(find(tree, ast.FunctionDef)) == tree.body


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:50:59.086818
# Unit test for function find

# Generated at 2022-06-12 04:51:05.943913
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    tree = ast.parse("for x in range(10): print(x)")
    n = ast.Load()
    n.col_offset = 0
    n.lineno = 1
    n.ctx = ast.Load()
    replace_at(1, tree.body[0].body[0], n)
    print(astor.to_source(tree))
    tree = ast.parse(astor.to_source(tree))
    print(get_non_exp_parent_and_index(tree, tree))

# Generated at 2022-06-12 04:51:07.419693
# Unit test for function replace_at
def test_replace_at():
    from astmonkey import transformers

# Generated at 2022-06-12 04:51:18.008214
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def hello():\n    print(\'Hello world!\')')
    node = tree.body[0].body[0].value.func
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)

# Generated at 2022-06-12 04:51:24.418485
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    source = '''
    for a in range(100):
        for b in range(100):
            pass
    '''
    tree = ast.parse(source)
    # print(ast.dump(tree))

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert isinstance(parent, ast.Module)

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert isinstance(parent, ast.For)
    assert parent == tree.body[0]

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])
    assert isinstance(parent, ast.For)

# Generated at 2022-06-12 04:51:31.196790
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # pylint: disable=import-outside-toplevel
    import astunparse
    import attr
    # pylint: enable=import-outside-toplevel

    @attr.s
    class Parent(ast.AST):
        child = attr.ib(type=ast.Expr)

    @attr.s
    class Child(ast.AST):
        pass

    class NonChild(ast.AST):
        pass


# Generated at 2022-06-12 04:51:34.082022
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # TODO: Find a better way for testing
    s = ast.parse('if True:\n   print("Hello")', '<test>', 'exec')
    par, index = get_non_exp_parent_and_index(s, s.body[0])
    assert par == s
    assert index == 0

# Generated at 2022-06-12 04:51:36.655610
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assert(get_closest_parent_of(ast.parse("a + b"), ast.parse("a").body[0].value, ast.Module) == ast.parse("a + b"))

# Generated at 2022-06-12 04:51:47.487046
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:51:54.915598
# Unit test for function get_parent
def test_get_parent():
    from .test_ast import ast_test
    import asttokens
    atok = asttokens.ASTTokens(ast_test, parse=True)
    tree = atok.tree
    def_names = ['f', 'g']
    for def_name in def_names:
        def_node = find(tree, ast.FunctionDef).next()
        assert(get_parent(tree, def_node) is tree)

    pass_node = find(tree, ast.Pass).next()
    assert(get_parent(tree, pass_node) is find(tree, ast.FunctionDef).next())



# Generated at 2022-06-12 04:51:59.849011
# Unit test for function find
def test_find():
    ast_string = """
    def add(x, y):
        return x + y
    """

    tree = ast.parse(ast_string)

    funcs = find(tree, ast.FunctionDef)
    assert len(list(funcs)) == 1

    i = find(tree, ast.Add)
    assert len(list(i)) == 1

# Generated at 2022-06-12 04:52:00.939144
# Unit test for function find
def test_find():
    tree = ast.parse("""
import re
    """)
    assert len(list(find(tree, ast.Import))) == 1



# Generated at 2022-06-12 04:52:03.841261
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('"toto" + 1')
    print(tree)
    #node = tree.body[0].value
    #print(get_non_exp_parent_and_index(tree, node))

# Generated at 2022-06-12 04:52:23.896098
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast.node as node

    example = """def foo():
    bar()
    baz()
    """

    ast_tree = node.Module([
        node.FunctionDef(
            'foo',
            [],
            [
                node.FunctionCall('bar', []),
                node.FunctionCall('baz', [])
            ],
            [])
    ])

    parent, index = get_non_exp_parent_and_index(ast_tree,
                                                 ast_tree.body[0].body[1])
    assert isinstance(parent, ast.FunctionDef)
    assert index == 0



# Generated at 2022-06-12 04:52:26.385431
# Unit test for function get_parent
def test_get_parent():
    a = ast.parse("""
    a = b + c
    """)
    _build_parents(a)
    b = a.body[0]
    assert b == get_parent(a, b.value)


# Generated at 2022-06-12 04:52:35.496937
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    ast_to_test_get_closest_parent_of = ast.parse('''if 1:
                                        if 2:
                                            if 3:
                                                pass
                                            else:
                                                pass
                                            pass
                                        else:
                                            pass
                                        pass''')
    assert get_closest_parent_of(ast_to_test_get_closest_parent_of,
                           ast_to_test_get_closest_parent_of.body[0].body[0],
                           ast.If).test.n == 2

# Generated at 2022-06-12 04:52:44.130941
# Unit test for function find
def test_find():
    tree = ast.parse('''
if True:
    a = 1
    if False:
        a = 2
''')
    if_nodes = list(find(tree, ast.If))

    assert len(if_nodes) == 2

    assert isinstance(if_nodes[0], ast.If)
    assert isinstance(if_nodes[0].test, ast.NameConstant)
    assert if_nodes[0].test.value is True

    assert isinstance(if_nodes[1], ast.If)
    assert isinstance(if_nodes[1].test, ast.NameConstant)
    assert if_nodes[1].test.value is False



# Generated at 2022-06-12 04:52:51.253709
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class TestParent(object):
        def __init__(self):
            self.field = 1
            self.body = []

    class TestChild(object):
        pass

    node = TestChild()
    tree = TestParent()
    tree.body = [1, TestChild(), TestParent(), 1]
    _build_parents(tree)

    assert get_closest_parent_of(tree, node, type(tree)) == tree
    assert get_closest_parent_of(tree, node, type(node)) == node

# Generated at 2022-06-12 04:52:55.767966
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def foo():\n    var = 1 if True else 2\n')
    node = tree.body[0].body[0].value.test  # type node is IfExp
    parent = get_closest_parent_of(tree, node, ast.FunctionDef)
    assert not hasattr(parent, 'body')

# Generated at 2022-06-12 04:52:56.991555
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:52:59.225076
# Unit test for function find
def test_find():
    tree = ast.parse('n * 0')
    assert list(find(tree, ast.BinOp)) == [tree.body[0].value]

# Generated at 2022-06-12 04:53:04.065838
# Unit test for function find
def test_find():
    from ..parser import parse_file

    tree = parse_file('test.py')

    assert len(list(find(tree, ast.Tuple))) == 1
    assert len(list(find(tree, ast.List))) == 1
    assert len(list(find(tree, ast.Name))) == 6



# Generated at 2022-06-12 04:53:12.144447
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ..src import parse_code
    from ..exceptions import NodeNotFound

    code = 'def foo():\n    for i in range(4):\n        print(i)'
    tree = parse_code(code)

    def _check(code_, expected_parent, expected_index):
        line, col = code_
        node = tree.body[0].body[line].body[0]
        parent, index = get_non_exp_parent_and_index(tree, node)
        assert isinstance(parent, expected_parent)
        assert index == expected_index

    _check((2, 4), ast.For, 0)
    _check((1, 5), ast.FunctionDef, 0)
    _check((0, 8), ast.Module, 0)


# Generated at 2022-06-12 04:53:51.369120
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    t = ast.parse('def a():\n  def b():\n    pass')
    p = get_closest_parent_of(t, t.body[0].body[0], ast.FunctionDef)
    assert p.name == 'b'

# Generated at 2022-06-12 04:53:57.318926
# Unit test for function find
def test_find():
    assert list(find(ast.parse('a = 1\n'), ast.Assign)) == [
        create_node('''
            a = 1
        ''', 'Assign')
    ]

    assert list(find(ast.parse('a = 1\n'), ast.Name)) == [
        create_node('''
            a = 1
        ''', 'Name'),
        create_node('''
            a = 1
        ''', 'Name')
    ]



# Generated at 2022-06-12 04:54:01.644542
# Unit test for function get_parent
def test_get_parent():
    code = '''
    if True:
        pass
    '''
    tree = ast.parse(code)
    _build_parents(tree)
    assert isinstance(get_parent(tree, tree), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)

# Generated at 2022-06-12 04:54:08.993281
# Unit test for function find
def test_find():
    test = ast.FunctionDef(
        'test',
        args=ast.arguments(args=[ast.arg(arg='a')]),
        body=[ast.Pass()],
        decorator_list=[ast.Name(id='staticmethod', ctx=ast.Load())],
        returns=None,
        type_comment=None)  # type: ast.AST
    assert len(list(find(test, ast.FunctionDef))) == 1
    assert len(list(find(test, ast.Name))) == 1
    assert len(list(find(test, ast.Pass))) == 1

# Generated at 2022-06-12 04:54:15.304945
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a = ast.If(ast.Constant(value=True), [ast.Assign(ast.Name(id=ast.Constant(value='hi'), ctx=ast.Store()), ast.Constant(value=12))], [])
    _build_parents(a)
    parent, index = get_non_exp_parent_and_index(a, a.body[0])
    assert isinstance(parent, ast.If)
    assert index == 0



# Generated at 2022-06-12 04:54:22.571382
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from compiler.ast import Module, CallFunc, Name
    from ast import parse, dump

    print()
    tree = parse('''
    def foo(a, b, c, d):
        pass

    foo(1, 2, 3, 4)
    ''')

    _build_parents(tree)
    print(dump(tree))

    node = tree.node.nodes[1].args[2]
    print(dump(node))
    parent, index = get_non_exp_parent_and_index(tree, node)
    print(dump(parent))
    assert isinstance(parent, CallFunc)
    assert index == 2

# Generated at 2022-06-12 04:54:32.099011
# Unit test for function replace_at
def test_replace_at():
    root = ast.parse('def foo(x):\n    if x > 1:\n        print("x > 1")\n'
                     '    else:\n        print("x <= 1")\n    print("this is'
                     ' the end")')
    repl_1 = ast.parse('def foo(x):\n    if x > 1:\n        print("x > 1")\n'
                       '    else:\n        print("x <= 1")\n    print("x is'
                       ' equal to x")\n    print("this is the end")')

# Generated at 2022-06-12 04:54:32.847442
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:54:42.603333
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class A(ast.AST):
        pass

    class B(ast.AST):
        body = ["b1", "b2", "b3"]

    class C(ast.AST):
        body = ["c1", "c2", "c3"]

    class D(ast.AST):
        body = ["d1", "d2", "d3"]

    a = A()
    b = B()
    c1 = C()
    c2 = C()
    d1 = D()
    d2 = D()
    d3 = D()

    b.body[2] = d1
    c2.body[2] = a
    d2.body[0] = c2

    assert get_non_exp_parent_and_index(b, a) == (d1, 0)


# Generated at 2022-06-12 04:54:47.717252
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # get_non_exp_parent_and_index(MockTree, MockNode)

    # def get_non_exp_parent_and_index(tree: ast.AST, node: ast.AST) \
    #         -> Tuple[ast.AST, int]:
    # """Get non-Exp parent and index of child."""
    # parent = get_parent(tree, node)
    #
    # while not hasattr(parent, 'body'):
    #     node = parent
    #     parent = get_parent(tree, parent)
    #
    # return parent, parent.body.index(node)  # type: ignore
    from typing import List

    from typed_ast import ast3 as ast

    from .mock_ast import MockTree


# Generated at 2022-06-12 04:56:30.277689
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """get_non_exp_parent_and_index test."""
    tree = ast.parse("""
    def my_func():
        new_var = 1 + 1
        new_var1 = 1 + 1
        new_var2 = 1 + 1
    """)
    func_def = tree.body[0]
    func_body = func_def.body
    assign = func_body[0]
    assert func_body == get_parent(tree, assign)
    assert func_def == get_parent(tree, func_body)
    assert func_def == get_parent(tree, func_def)
    assert tree == get_parent(tree, func_def, rebuild=True)
    assert assign == get_parent(tree, assign, rebuild=True)

# Generated at 2022-06-12 04:56:35.838355
# Unit test for function get_parent
def test_get_parent():
    """Function get_parent"""
    import astor
    from ..ans import Transformer
    class Transfromer(Transformer):
        '''A Transformer for testing
        '''
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            parent = get_parent(self.tree, node)
            assert isinstance(parent, ast.Module)
            return node


# Generated at 2022-06-12 04:56:40.487327
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from . import parse

    parsed = parse('''
    a = 1
    b = 2
    ''')
    cls_parent = get_closest_parent_of(parsed, parsed.body[0].targets[0],
                                       ast.Assign)
    assert cls_parent == parsed.body[0]

    cls_parent = get_closest_parent_of(parsed, parsed.body[0].targets[0],
                                       ast.Module)
    assert cls_parent == parsed

# Generated at 2022-06-12 04:56:45.077920
# Unit test for function find
def test_find():
    mod = ast.parse('''
    def my_func(a, b):
        return a + b
    ''')

    func_def = list(find(mod, ast.FunctionDef))[0]
    assert isinstance(func_def, ast.FunctionDef)

    bin_op = list(find(func_def, ast.BinOp))[0]
    assert isinstance(bin_op, ast.BinOp)

# Generated at 2022-06-12 04:56:53.710754
# Unit test for function get_parent
def test_get_parent():
    code = "file.write('test')"
    module = ast.parse(code)
    file = ast.Name(id='file', ctx=ast.Load(), lineno=1, col_offset=0)
    write = ast.Attribute(value=file, attr='write', ctx=ast.Load(), lineno=1,
                          col_offset=0)
    call = ast.Call(func=write, args=[ast.Str(s='test')], keywords=[],
                    lineno=1, col_offset=0)
    expr = ast.Expr(value=call, lineno=1, col_offset=0)
    module.body = [expr]

    assert get_parent(module, file) is expr
    assert get_parent(module, write) is call

# Generated at 2022-06-12 04:56:55.803874
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast

    tree = ast.parse('x = 1 + 2')
    assert len(list(find(tree, ast.Name))) == 1



# Generated at 2022-06-12 04:56:58.902186
# Unit test for function find
def test_find():
    source = """
    def foo():
        1 + 2
        bar()
    """
    tree = ast.parse(source)

    assert len(list(find(tree, ast.Call))) == 1
    assert len(list(find(tree, ast.Name))) == 3



# Generated at 2022-06-12 04:57:02.427630
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def f():\n    print(x)\n    print(y)\n    print(z)')
    node = next(find(tree, ast.Print))
    f, index = get_non_exp_parent_and_index(tree, node)
    assert index == 1
    assert isinstance(f, ast.FunctionDef)

# Generated at 2022-06-12 04:57:09.169807
# Unit test for function find
def test_find():
    import pathlib
    import sys
    from ..context import context
    from ..ast import astutil

    pathlib.Path(__file__).parent.resolve()

    # Clean global context 
    context.clear()

    # Prepare context
    context.extend(sys.modules[__name__])

    tree = ast.parse(test_find.__doc__)
    astutil.clean_asts(tree)

    retrieved = [str(n) for n in find(tree, ast.Assign)]

    assert 'nodes = [nodes]' in retrieved
    assert 'nodes = [node]' not in retrieved

# Generated at 2022-06-12 04:57:13.873472
# Unit test for function find
def test_find():
    test_src = '''
    def f(h):
        for x in y:
            for z in x:
                pass
    '''
    tree = ast.parse(test_src)

    assert list(find(tree, ast.For)) == [tree.body[0].body[0],
                                         tree.body[0].body[0].body[0]]