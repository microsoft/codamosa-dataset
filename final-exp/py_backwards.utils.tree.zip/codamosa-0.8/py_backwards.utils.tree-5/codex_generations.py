

# Generated at 2022-06-12 04:47:28.882443
# Unit test for function find
def test_find():
    import unittest

    class TestFind(unittest.TestCase):

        def test_find_simple(self):
            tree = ast.parse('fun()')
            # print(ast.dump(tree))

            fun_nodes = [node for node in find(tree, ast.FunctionDef)]
            self.assertEqual(len(fun_nodes), 1)

    unittest.main()

# if __name__ == '__main__':
#     test_find()

# Generated at 2022-06-12 04:47:34.252184
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from typing import Optional

    body = ast.parse('a + b', mode='eval').body
    assert get_closest_parent_of(body, body.right, ast.BinOp) == body
    assert get_closest_parent_of(body, body.left, ast.BinOp) == body

# Generated at 2022-06-12 04:47:38.775478
# Unit test for function replace_at
def test_replace_at():
    import astor
    tree = ast.parse("i = 1")
    i_parent = get_parent(tree, tree.body[0])
    replace_at(0, i_parent, "j = 2")
    assert astor.to_source(tree) == "j = 2\n"


# Generated at 2022-06-12 04:47:48.071975
# Unit test for function find
def test_find():
    # TODO current test set is ad-hoc and need to be fixed
    tree = ast.parse("if 1: pass")
    res = list(find(tree, ast.Pass))
    assert len(res) == 1
    assert isinstance(res[0], ast.Pass)

    tree = ast.parse("if 1: pass")
    res = list(find(tree, ast.If))
    assert len(res) == 1
    assert isinstance(res[0], ast.If)

    tree = ast.parse("if 1: pass")
    res = list(find(tree, ast.IfExp))
    assert len(res) == 0

    tree = ast.parse("if 1: pass")
    res = list(find(tree, ast.Try))
    assert len(res) == 0


# Generated at 2022-06-12 04:47:55.408870
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    one = ast.Num(n=1)
    two = ast.Num(n=2)
    three = ast.Num(n=3)
    four = ast.Num(n=4)
    five = ast.Num(n=5)
    six = ast.Num(n=6)
    seven = ast.Num(n=7)
    eight = ast.Num(n=8)
    nine = ast.Num(n=9)
    ten = ast.Num(n=10)

    sixteen = ast.Num(n=16)

    #     "add"
    #   /      \
    # "mul"    "sub"
    #   |     /     \
    # "mul" "add"   six
    # / | \  / | \
    # one two three five
    # +  

# Generated at 2022-06-12 04:47:59.433891
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('a = 1')
    node = list(find(tree, ast.Assign))[0]

    assert get_closest_parent_of(tree, node, ast.Module) == tree
    assert get_closest_parent_of(tree, node, ast.Assign) == node

# Generated at 2022-06-12 04:48:03.291008
# Unit test for function find
def test_find():
    code = "def foo(): pass"
    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 1
    print('test_find passed')

test_find()

# Generated at 2022-06-12 04:48:10.620241
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def foo(a, b):
        if (True):
            return a + b
    """)
    node = tree.body[0].body[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef), ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Module), ast.Module)
    assert get_closest_parent_of(tree, node, ast.For) is None

# Generated at 2022-06-12 04:48:18.029474
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from . import parse

    tree = parse("""
func() {
    while True:
        if True:
            break
}
    """)

    if_node = find(tree, ast.If).__next__()
    closest_parent = get_parent(tree, if_node)

    assert isinstance(closest_parent, ast.While)

    closest_parent = get_closest_parent_of(tree, if_node, ast.FunctionDef)

    assert isinstance(closest_parent, ast.FunctionDef)
    assert closest_parent.name == 'func'

# Generated at 2022-06-12 04:48:21.637421
# Unit test for function find

# Generated at 2022-06-12 04:48:31.169240
# Unit test for function find
def test_find():
    from . import ast_utils
    tree = ast_utils.ast_from_file('tests/test_data/test_find.py')

    ifs = list(find(tree, ast.If))
    assert len(ifs) == 3, 'Wrong number of If.'

    assert ifs[0].body[0].value.s == '0', \
        'Wrong body.'


# Generated at 2022-06-12 04:48:35.513639
# Unit test for function find
def test_find():
    from .test_code import code
    tree = ast.parse(code)
    assert len(list(find(tree, ast.FunctionDef))) == 2
    assert len(list(find(tree, ast.Call))) == 3
    assert len(list(find(tree, ast.Name))) == 3
    assert len(list(find(tree, ast.Str))) == 2
    assert len(list(find(tree, ast.Load))) == 2

# Generated at 2022-06-12 04:48:45.543244
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse(
        '''
        class Foo:
            def bar(self, a: int, b: int) -> int:
                return a + b
        '''
    )

    parent, child_index = get_non_exp_parent_and_index(
        tree,
        get_closest_parent_of(tree, tree.body[0].body[0].body[-1], ast.Expr)
    )

    assert parent is tree.body[0].body[0]
    assert child_index == 0
    assert parent.body[0] is get_closest_parent_of(
        tree, tree.body[0].body[0].body[-1], ast.Expr
    )

# Generated at 2022-06-12 04:48:57.330986
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast1 = ast.parse("""
for i in range(1):
    if True:
        a = 1
        b = 2
        c = 3
        print(a)
    else:
        a = 1
        b = 2
        c = 3
        print(b)""")
    _build_parents(ast1)
    print(ast.dump(ast1))
    ast_node = ast1.body[0].body[0]
    assert isinstance(ast_node, ast.If)

    result = get_non_exp_parent_and_index(ast1, ast_node)
    print(result)

# Generated at 2022-06-12 04:49:03.002973
# Unit test for function find
def test_find():
    from .case import Case
    from .stmt import While, Break
    from .expr import Const

    case = Case(Case.EXPR, Const(5))
    case_true = Case(Case.EXPR, Const(4))
    case_true.body = [While(Const(True), [Break()])]
    tree = While(Const(True), [case, case_true])
    _build_parents(tree)


# Generated at 2022-06-12 04:49:04.509608
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor


# Generated at 2022-06-12 04:49:15.570741
# Unit test for function get_parent
def test_get_parent():
    t1 = ast.parse('''
    def foo():
        pass
    ''')
    t2 = ast.parse('''
    def foo():
        def bar():
            pass
    ''')
    t3 = ast.parse('''
    def foo():
        def bar():
            pass
        def baz():
            pass
    ''')
    t4 = ast.parse('''
    def foo():
        def bar():
            pass
        for x in []:
            pass
    ''')


# Generated at 2022-06-12 04:49:25.575053
# Unit test for function insert_at
def test_insert_at():
    tree = ast.parse("""
    class TestClass(object):
        def test_insert(self):
            a = 5

            b = 6

            c = 8
    """)

    class_def = tree.body[0]
    function_def = class_def.body[0]

    assert function_def.name == 'test_insert'

    first_assign = function_def.body[0]
    second_assign = function_def.body[1]
    third_assign = function_def.body[2]

    assert isinstance(first_assign, ast.Assign)
    assert isinstance(second_assign, ast.Assign)
    assert isinstance(third_assign, ast.Assign)


# Generated at 2022-06-12 04:49:27.479527
# Unit test for function find
def test_find():
    import astor
    from .patchers import FuncDefPatch


# Generated at 2022-06-12 04:49:34.402225
# Unit test for function find
def test_find():
    """Test function find."""
    from typing import List
    from typed_ast import ast3 as ast

    nodes: List[ast.AST] = [
        ast.parse('1 + 2').body[0],
        ast.parse('2 + 3').body[0],
        ast.parse('1 + 4').body[0]
    ]

    assert list(find(nodes, ast.BinOp)) == [nodes[0], nodes[1], nodes[2]]


# Generated at 2022-06-12 04:49:47.218306
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():

    from ..refactor.parser import parse

    tree_ = ast.parse("""
    if True:
        pass
    elif True:
        pass
    elif True:
        pass
    elif True:
        pass
    else:
        pass
    """)
    parent_ = tree_.body[0]
    index_ = parent_.body[-1].body[0].body[0].body[0].body[0].body[0].lineno - \
        parent_.lineno
    assert get_non_exp_parent_and_index(tree_, tree_.body[0].body[-1].body[0]
                                        .body[0].body[0].body[0].body[0]) == (parent_, index_)


# Generated at 2022-06-12 04:49:50.997852
# Unit test for function find
def test_find():
    import astor
    import ast2json

    tree = astor.parse_file('../tests/test.py')
    nodes = find(tree, ast.FunctionDef)
    print(ast2json.ast2json(tree))
    assert len(list(nodes)) == 5



# Generated at 2022-06-12 04:49:54.708524
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = 'def function(): pass'
    tree = ast.parse(code)
    fun = find(tree, ast.FunctionDef).__next__()
    parent, index = get_non_exp_parent_and_index(tree, fun)
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-12 04:50:00.769969
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('x = 1\nprint(1)\nprint(2)')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[1].value)
    assert isinstance(parent, ast.Module)
    assert index == 1

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0])
    assert isinstance(parent, ast.Module)
    assert index == 0

# Generated at 2022-06-12 04:50:01.759268
# Unit test for function find

# Generated at 2022-06-12 04:50:12.182564
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from astunparse import unparse
    from .fixtures import get_fixture_tree
    from .fixtures import simple_if_else_if_else_fixture as if_fixture_data

    tree = get_fixture_tree(if_fixture_data['path'])  # type: ast.Module
    _build_parents(tree)
    nodes = [tree.body[0],
             tree.body[0].body[0]]

    expect_parents = [tree.body[0],
                      tree.body[0].body[0]]

    results = []
    for index, node in enumerate(nodes):
        try:
            parent = get_non_exp_parent_and_index(tree, node)[0]
            results.append(parent)
        except NodeNotFound:
            results.append(None)

# Generated at 2022-06-12 04:50:18.749680
# Unit test for function find
def test_find():
    from ..parser import parse_node

    test_tree = ast.parse(
        """
        def f():
            return 1
        """
    )

    _build_parents(test_tree)

    f_body = test_tree.body[0].body
    assert len(f_body) == 1

    ret = f_body[0]
    assert isinstance(ret, ast.Return)

    found_return = find(test_tree, ast.Return).__next__()
    assert ret == found_return



# Generated at 2022-06-12 04:50:19.487973
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert None == None

# Generated at 2022-06-12 04:50:23.155529
# Unit test for function get_parent
def test_get_parent():
    """ Check if parent is found correctly. """
    tree = ast.parse('a = 1 + 2')
    assert tree == get_parent(tree, tree.body[0].value)



# Generated at 2022-06-12 04:50:29.085910
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = "if a == b:\n\tprint('Hello World!')"

    try:
        node_ast = ast.parse(code)
        node = list(find(node_ast, type_=ast.Name))[0]
        assert get_non_exp_parent_and_index(node_ast, node) == (node_ast, 0)
    except AssertionError:
        raise AssertionError("Bug in function get_non_exp_parent_and_index")

# Generated at 2022-06-12 04:50:39.466031
# Unit test for function replace_at
def test_replace_at():
    import astor

    code = """def function(arg):
        var = arg
        return arg
    """
    tree = astor.parse_file(code)
    change_arg = ast.Assign(targets=[ast.Name(id='var')], value=ast.Num(n=1))

    # Find function
    function = tree.body[0]
    function_body = function.body

    # Find 'var = arg'
    var = function_body[0]
    # Find 'return arg'
    return_node = function_body[1]
    # Find 'arg' in 'return arg'
    arg = return_node.value
    # Find index of 'var = arg'
    index = function_body.index(var)

    # Replace 'var = arg' with 'var = 1'
    replace_

# Generated at 2022-06-12 04:50:45.927862
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    import textwrap
    from typed_ast import ast3 as ast
    import pprint

    class Test(unittest.TestCase):
        def test(self):
            code = textwrap.dedent('''
                def func():
                    pass

                def func2():
                    func()
            ''')

            tree = ast.parse(code)
            node = find(tree, ast.Name).__next__()

            parent = get_closest_parent_of(tree, node, ast.FunctionDef)
            self.assertEqual(parent.name, 'func')

            parent = get_closest_parent_of(tree, parent, ast.FunctionDef)
            self.assertEqual(parent.name, 'func2')

    unittest.main()


# Generated at 2022-06-12 04:50:49.416542
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = "def foo(x):"
    module = ast.parse(code)
    node = module.body[0].body
    parent, index = get_non_exp_parent_and_index(module, node)
    assert index == 0
    assert parent == module.body[0]


# Generated at 2022-06-12 04:50:59.703630
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    code = "def foo():\n  return a"
    parent, index = get_non_exp_parent_and_index(ast.parse(code),
                                                 ast.parse(code).body[0].body[0])
    assert parent == ast.parse(code)
    assert index == 0

    code = "def foo():\n  return a\ndef bar():\n  return b"
    parent, index = get_non_exp_parent_and_index(ast.parse(code),
                                                 ast.parse(code).body[0].body[0])
    assert parent == ast.parse(code)
    assert index == 0

    code = "def foo():\n  return a\nbar()"

# Generated at 2022-06-12 04:51:02.406252
# Unit test for function find
def test_find():
    from ..tests import get_example_ast

    ast_ = get_example_ast()
    print(list(find(ast_, ast.Name)))



# Generated at 2022-06-12 04:51:09.440511
# Unit test for function replace_at
def test_replace_at():
    import astor
    test_tree = ast.parse("""
*args, x = args
""")
    test_stmt = test_tree.body[0]
    print(astor.to_source(test_stmt))
    new_stmts = [ast.parse("""
a = args
""").body[0], ast.parse("""
y = x
""").body[0]]
    replace_at(0, test_stmt, new_stmts)
    print(astor.to_source(test_stmt))

# Generated at 2022-06-12 04:51:12.279951
# Unit test for function find
def test_find():
    tree = ast.parse('x = 1')
    res = [node for node in find(tree, ast.Name)]
    assert res == [ast.Name(id='x', ctx=ast.Store())]

# Generated at 2022-06-12 04:51:19.166573
# Unit test for function find
def test_find():
    filename = "tests/fixtures/test_find.py"
    tree = ast.parse(open(filename, "rb").read())

    test_node = list(find(tree, ast.Name))[-1]
    assert isinstance(test_node, ast.Name)
    assert test_node.id == "d"

    test_node = get_closest_parent_of(tree, test_node, ast.ClassDef)
    assert isinstance(test_node, ast.ClassDef)


# Generated at 2022-06-12 04:51:27.606190
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    from ..ast_utils import get_root
    import ast
    import inspect

    test_node = inspect.getsource(get_root)
    code = compile(test_node, '<string>', 'exec', optimize=2,
                   flags=ast.PyCF_ONLY_AST)
    tree = ast.parse(test_node)
    assert isinstance(get_closest_parent_of(tree, code, ast.Module), ast.Module)
    assert isinstance(get_closest_parent_of(tree, code, ast.AST), ast.Module)
    assert isinstance(get_closest_parent_of(tree, code, ast.Expression), ast.Module)

# Generated at 2022-06-12 04:51:28.224443
# Unit test for function find

# Generated at 2022-06-12 04:51:35.431106
# Unit test for function find
def test_find():
    node = ast.parse('def foo():\n pass')

    assert(list(find(node, ast.FunctionDef)) == [node.body[0]])

# Generated at 2022-06-12 04:51:38.697881
# Unit test for function find
def test_find():
    # assert len(list(find(ast.parse('a = ["forever", \'and a day\']'),
    #                     ast.Str))) == 2
    # assert len(list(find(ast.parse('a = ["forever", \'and a day\']'),
    #                     ast.List))) == 1
    pass

# Generated at 2022-06-12 04:51:48.725410
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import types
    import unittest

    class Test(unittest.TestCase):
        def test_get_closest_parent_of_object(self):
            tree = ast.parse('a = b')
            node = tree.body[0].value
            parent = get_closest_parent_of(tree, node, ast.Module)
            self.assertIsInstance(parent, ast.Module)

        def test_get_closest_parent_of_method(self):
            tree = ast.parse('a = 1')
            node = tree.body[0]
            parent = get_closest_parent_of(tree, node, ast.Assign)
            self.assertIsInstance(parent, ast.Assign)


# Generated at 2022-06-12 04:51:51.753773
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class X:
        pass
    class Y:
        pass

    root = Y()
    child = X()
    child.y = root
    child.parent = get_closest_parent_of(root, child, Y)
    assert(child.y == child.parent)

# Generated at 2022-06-12 04:51:56.997536
# Unit test for function get_parent
def test_get_parent():
    my_module = ast.parse("x = 1 + 1")
    my_node = ast.parse("1 + 1")
    _build_parents(my_module)
    parent = get_parent(my_module, my_node)
    assert(isinstance(parent, ast.Assign))

if __name__ == '__main__':
    test_get_parent()

# Generated at 2022-06-12 04:51:57.993456
# Unit test for function find

# Generated at 2022-06-12 04:52:00.659107
# Unit test for function find
def test_find():
    x = ast.parse('import cv2; cv2.imread()')
    found = find(x, ast.Import)
    assert len(list(found)) == 1



# Generated at 2022-06-12 04:52:03.203312
# Unit test for function find
def test_find():
    assert list(find(ast.parse('print(1)'), ast.Name)) == [ast.Name(
        id='print', ctx=ast.Load())]



# Generated at 2022-06-12 04:52:07.058458
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    expr = ast.parse('1+1', 'file')
    body_node = get_non_exp_parent_and_index(expr, expr.body[0])
    assert isinstance(body_node[0], ast.Module)
    assert body_node[1] == 0

# Generated at 2022-06-12 04:52:18.011730
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast
    from ..refactor import add_imports, get_non_exp_parent_and_index

    syntax1 = """
    import turtle
    a = 3
    a.forward(7)
    """

    syntax2 = """
    import turtle
    a = 3
    a.forward(7)
    """

    syntax3 = """
    import turtle
    a = 3
    """
    syntax4 = """
    import turtle
    a = 3
    b = a
    """

    syntax5 = """
    import turtle
    a = 3
    b = a
    forward(7)
    """

    syntax6 = """
    import turtle
    a = 3
    if a > 4 :
        forward(7)
    """


# Generated at 2022-06-12 04:52:25.905461
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor
    s = """x = a.b if x else f"""
    tree = ast.parse(s)
    ifx = find(tree, ast.If).__next__()
    parent, index = get_non_exp_parent_and_index(tree, ifx)
    assert parent == tree
    assert index == 1


# Generated at 2022-06-12 04:52:26.844887
# Unit test for function find
def test_find():
    import unittest as ut

# Generated at 2022-06-12 04:52:29.911738
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse('[0, 0]').body

    non_exp_parent, index = get_non_exp_parent_and_index(
        tree=ast.parse('[0, 0]'), node=node
    )

    assert non_exp_parent == ast.parse('[0, 0]')
    assert index == 0

# Generated at 2022-06-12 04:52:32.131341
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    exp = ast.parse('a.b.c', '<none>', 'eval').body.value
    assert get_non_exp_parent_and_index(exp, exp.value) == (exp, 0)



# Generated at 2022-06-12 04:52:36.562393
# Unit test for function find
def test_find():
    tree = ast.parse('(a + b) in x and not c')
    expected = ['x', '+', 'a', 'b', 'not', 'c']

    def test_node(_, node):
        if isinstance(node, ast.Name):
            return node.id

        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            return 'not'

        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            return '+'

    assert [test_node(None, node) for node in find(tree, ast.AST)] == expected



# Generated at 2022-06-12 04:52:37.491697
# Unit test for function find

# Generated at 2022-06-12 04:52:42.513766
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.parse(
        """
        foo()
        foo()
        foo()
        """)
    func = ast.FunctionDef('bar', ast.arguments(), [node.body[0], node.body[1], node.body[2]], [])
    parent, index = get_non_exp_parent_and_index(func, node.body[0])
    assert parent == func
    assert index == 0



# Generated at 2022-06-12 04:52:43.129899
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:52:46.156708
# Unit test for function find
def test_find():
    def function_name(x):
        return x

    assert list(find(ast.parse(function_name.__doc__), ast.FunctionDef))[0].name == 'function_name'

# Generated at 2022-06-12 04:52:50.002408
# Unit test for function get_parent
def test_get_parent():
    st = ast.parse("def foo():\n"
                   "    x = 2")
    _build_parents(st)

    node = st.body[0].body[0].value

    assert get_parent(st, node) == st.body[0].body[0]


# Generated at 2022-06-12 04:53:03.817906
# Unit test for function get_parent
def test_get_parent():
    """Unit test for get_parent."""
    exp = ast.parse("""
        def test():
            def test_function():
                variable = 0
            variable = 0
        variable = 0""").body[0]
    assert get_parent(exp, exp.body[0].body[0].body[0]) == \
        exp.body[0].body[0]
    assert get_parent(exp, exp.body[0].body[0]) == exp.body[0]
    assert get_parent(exp, exp.body[0]) == exp
    assert get_parent(exp, exp.body[1]) == exp
    assert get_parent(exp, exp.body[1]) == exp


# Generated at 2022-06-12 04:53:07.918825
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    with open('tests/examples/test.py') as f:
        tree = ast.parse(f.read())

    # test1: non-exp node
    parent, index = get_non_exp_parent_and_index(tree, list(
        find(tree, ast.Expr))[0].value)
    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'test1'
    assert index == 1

    # test2: exp node
    parent, index = get_non_exp_parent_and_index(tree, list(
        find(tree, ast.FunctionDef))[0].body[2])
    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'test2'
    assert index == 3

# Generated at 2022-06-12 04:53:12.170772
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    a = ast.parse('if 1: a = 2')
    if_block = a.body[0].body[0]

    if_body, index = get_non_exp_parent_and_index(a, if_block)
    assert index == 0
    assert isinstance(if_body, ast.If)
    assert id(if_body) == id(a.body[0].body)  # type: ignore



# Generated at 2022-06-12 04:53:19.588380
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class A:
        def __init__(self, body=[]):
            self.body = body

        def __repr__(self):
            return 'A()'

    class B:
        def __init__(self, body=[]):
            self.body = body

        def __repr__(self):
            return 'B()'

    a = A()
    b = B()
    c = B()
    a.body = [b]
    b.body = [c]

    assert(_parents[b] == a)
    assert(_parents[c] == b)
    assert(get_non_exp_parent_and_index(a, c) == (b, 0))

# Generated at 2022-06-12 04:53:21.662684
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    from ast_tool_box.transformations import replace_import

# Generated at 2022-06-12 04:53:27.133382
# Unit test for function replace_at
def test_replace_at():
    """Unit test for function replace_at."""
    class Dummy(ast.AST):
        pass
    tree = Dummy()
    tree.body = [Dummy(), Dummy(), Dummy()]

    def count_nodes(root):
        return len(list(ast.walk(root)))

    assert count_nodes(tree) == 4

    replace_at(1, tree, [Dummy(), Dummy()])
    assert count_nodes(tree) == 5

# Generated at 2022-06-12 04:53:36.086956
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # To run the unit test, type pytest in the root directory.
    from typed_ast.ast3 import parse
    tree = parse('def foo():\n foo()')

    # Find the closest parent of node with type 'FunctionDef'
    function_def = get_closest_parent_of(tree, tree.body[0].body[0],
                                         ast.FunctionDef)

    # Find the closest parent of node with type 'Module'
    module = get_closest_parent_of(tree, tree.body[0].body[0], ast.Module)

    # Find the closest parent of node with type 'Name'
    assert get_closest_parent_of(tree, tree.body[0].body[0],
                                 ast.Name) == tree.body[0].body[0].func

    # Assert

# Generated at 2022-06-12 04:53:38.458101
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:53:40.494383
# Unit test for function find
def test_find():
    ast_root = ast.parse("def foo(a, b, c): pass", mode='eval')
    result = list(find(ast_root, ast.FunctionDef))
    assert result[0].name == "foo"


# Generated at 2022-06-12 04:53:44.376393
# Unit test for function find
def test_find():
    class A:
        def __eq__(self, other):
            return isinstance(other, A)

    tree = ast.parse("""
    from a import B
    C = A()
    """)
    result = list(find(tree, A))
    assert len(result) == 2


# Generated at 2022-06-12 04:53:59.986386
# Unit test for function find
def test_find():
    test_ast = ast.parse('''def foo()\n    pass''')

    def_foo = get_closest_parent_of(test_ast, test_ast.body[0], ast.FunctionDef)

    other_func = ast.FunctionDef('bar', ast.arguments(args=[], vararg=None,
                                                      stararg=None, kwonlyargs=[],
                                                      kw_defaults=[],
                                                      kwarg=None, defaults=[]),
                                 [ast.Pass()], [])

    def_foo.body.append(other_func)
    functions = list(find(test_ast, ast.FunctionDef))

    assert len(functions) == 2



# Generated at 2022-06-12 04:54:09.184379
# Unit test for function find
def test_find():
    import unittest.mock as mock
    comp = ast.parse("x = 1; y = 2", mode="exec")
    with mock.patch("builtins.print") as mock_print:
        for n in find(comp, ast.Name):
            mock_print(n.id)
        mock_print.assert_has_calls([mock.call("x"), mock.call("y")])
    # should throw an exception if node is not found
    try:
        get_parent(comp, ast.arg(arg='arg1', annotation=None))
    except NodeNotFound as e:
        assert "Parent for arg(arg='arg1', annotation=None) not found" == \
            str(e)



# Generated at 2022-06-12 04:54:19.604731
# Unit test for function replace_at
def test_replace_at():
    x = ast.parse(
        """import a\nimport b
        def test():
            return True
        """)
    func_def = get_closest_parent_of(x, find(x, ast.Return).__next__(), ast.FunctionDef)
    body = func_def.body
    assert isinstance(body[0], ast.Return)
    replace_at(0, func_def, ast.Print(values=[ast.Constant(value=1)], dest=None,
                                      nl=True))
    print(ast.dump(body[0]))
    assert isinstance(body[0], ast.Print)
    print(body[0].values[0])
    assert body[0].values[0].value == 1


# Generated at 2022-06-12 04:54:25.354061
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse(
        "def func(x, y):\n"
        "    if x > 0:\n"
        "        x = x + 1\n"
        "    else:\n"
        "        x = x - 1\n")

    assert get_parent(tree, tree).__class__ == ast.Module
    assert get_parent(tree, tree.body[0]).__class__ == ast.Module
    assert get_parent(tree, tree.body[0].body[0]).__class__ == ast.FunctionDef
    assert get_parent(tree, tree.body[0].body[0].body[0]).__class__ == ast.FunctionDef
    assert get_parent(tree, tree.body[0].body[0].body[0].body[0]).__class__ == ast.If

# Unit

# Generated at 2022-06-12 04:54:28.174232
# Unit test for function find
def test_find():
    test_tree = ast.parse('x = 5 + 3')
    result = 5 in [node.value.n for node in find(test_tree, ast.Num)]
    assert result

# Generated at 2022-06-12 04:54:33.957563
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # type: () -> None
    global _parents
    _parents = WeakKeyDictionary()

    cl = ast.ClassDef(name='Test', body=[],
                      decorator_list=[],
                      lineno=0,
                      col_offset=0)

    func = ast.FunctionDef(name='test', body=[],
                           decorator_list=[],
                           args=ast.arguments(
                               args=[],
                               vararg=None,
                               kwonlyargs=[],
                               kw_defaults=[],
                               kwarg=None,
                               defaults=[]),
                           lineno=0,
                           col_offset=0)

    cl.body.append(func)  # type: ignore

    assert get_closest_parent_of(cl, func, ast.ClassDef)

# Generated at 2022-06-12 04:54:43.475098
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Testing for a function call in an expression
    def get_code_for_function_call_in_a_expression():
        return "a = b(c, d)"

    code = ast.parse(get_code_for_function_call_in_a_expression())
    function_call = code.body[0].value
    parent, idx = get_non_exp_parent_and_index(code, function_call)
    assert(parent == code.body[0])
    assert(idx == 0)

    # Testing for a function call in a if condition
    def get_code_for_function_call_in_a_if_condition():
        return "if b(c, d):\n    pass"

    code = ast.parse(get_code_for_function_call_in_a_if_condition())

# Generated at 2022-06-12 04:54:49.956766
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    ast_ = ast.parse(
        'from typing import List\n\n'
        + '# type: (int, List[str], bool) -> None\n'
        + 'def func(x, y, z):\n'
        + '    pass\n'
    )

    node_ = ast_.body[1].value.args[1]

    parent_, _ = get_non_exp_parent_and_index(ast_, node_)

    assert parent_ == ast_.body[1]

# Generated at 2022-06-12 04:54:57.932994
# Unit test for function find
def test_find():
    import inspect
    import astor

    ast_tree = ast.parse(inspect.getsource(test_find))
    import_list = find(ast_tree, ast.ImportFrom)
    
    assert str(import_list[0]) == "ImportFrom(module='astor', names=[alias(name='dump_tree', asname=None)], level=0)"

    function_list = find(ast_tree, ast.FunctionDef)

# Generated at 2022-06-12 04:55:02.206218
# Unit test for function find
def test_find():
    from .test_ast import min_ast_simple, simple_function_ast
    ast_rep = min_ast_simple
    ast_rep_sample = simple_function_ast
    assert len([for_loop for for_loop in find(ast_rep, ast.For)]) == 1
    assert len([for_loop for for_loop in find(ast_rep_sample, ast.For)]) == 1

# Generated at 2022-06-12 04:55:40.112104
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:55:48.461958
# Unit test for function find
def test_find():
    import _ast
    expr_children = [ast.parse(source).body[0].value for source in [
        '1', '2 + 3', '4 + 5 + 6', '7 * 8', '9 + 10 * 11', '12 * 13 + 14'
    ]]
    compound_expr_children = [ast.parse(source).body[0].value for source in [
        '1', '2 + 3', '1 + (2 + 3)', '(1 + 2) + 3', '1 + 2 * 3', '1 * 2 + 3'
    ]]
    expr_parents = [
        ast.Expr(child)
        for child in expr_children
    ]

# Generated at 2022-06-12 04:55:48.917878
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert True

# Generated at 2022-06-12 04:55:49.596938
# Unit test for function get_parent

# Generated at 2022-06-12 04:55:53.074853
# Unit test for function find
def test_find():
    tree = ast.parse('import abc; class A: def __init__(self, x)'
                     ':self.x = x; print(A())')
    for x in find(tree, ast.ImportFrom):
        print(x)


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:55:57.082363
# Unit test for function replace_at
def test_replace_at():
    """Unit test for function replace_at"""
    node = ast.parse('a = 0')
    parent = ast.With()
    parent.body = [node]
    new_node = ast.parse('a = 1')
    replace_at(0, parent, new_node)
    assert parent.body[0].body[0].value.n == 1

# Generated at 2022-06-12 04:55:57.868303
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:56:03.731833
# Unit test for function replace_at
def test_replace_at():
    class DummyNode(ast.AST):
        pass
    statement = DummyNode()
    statement.body = [DummyNode(), DummyNode(), DummyNode(), DummyNode(), DummyNode()]
    replace_at(1, statement, [DummyNode(), DummyNode(), DummyNode()])
    assert len(statement.body) == 6
    assert statement.body[1] == DummyNode()
    assert statement.body[2] == DummyNode()
    assert statement.body[3] == DummyNode()

# Generated at 2022-06-12 04:56:12.041616
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import ast
    import astor
    from .modifiers import Modifier
    from .modifiers import AttributeModifier

    from . import utils

    # Note: ast.dump(ast.parse(astor.to_source(node))) resembles node
    node = ast.Module(body=[
        ast.FunctionDef(name='greet', body=[
            ast.Return(value=ast.BinOp(left=ast.Str(s='Hello'),
                                       op=ast.Add(),
                                       right=ast.Name(id='name')))
        ], args=ast.arguments(args=[
            ast.arg(arg='name', annotation=None)
        ]))
    ])
    utils.get_non_exp_parent_and_index(node, node.body[0])



# Generated at 2022-06-12 04:56:16.643457
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    mod = ast.parse('if x: pass', mode='exec')
    if_ = mod.body[0]
    pass_ = if_.body[0]
    assert get_non_exp_parent_and_index(mod, if_) == (mod, 0)
    assert get_non_exp_parent_and_index(mod, pass_) == (if_, 0)

# Generated at 2022-06-12 04:56:52.790019
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:57:00.930857
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    """get_closest_parent_of() should work as expected"""
    code = "if True: for i in (1,2,3): print(i)"

    # Check for 'if'
    node = ast.parse(code)
    node = get_closest_parent_of(node, get_parent(node, node.body[0]), ast.If)
    assert isinstance(node, ast.If)

    # Check for 'for'
    node = ast.parse(code)
    node = get_closest_parent_of(node, get_parent(node, node.body[0]), ast.For)
    assert isinstance(node, ast.For)

    # Check for 'TryExcept'

# Generated at 2022-06-12 04:57:02.495364
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import astor
    import typed_astunparse

# Generated at 2022-06-12 04:57:08.345545
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse(
        "import os\n"
        "if a or b:\n"
        "    c()\n"
    )

    assert get_parent(tree, tree.body[0].targets[0]) == tree.body[0]
    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[1].body[0]) == tree.body[1]
    assert get_parent(tree, tree) is None

# Generated at 2022-06-12 04:57:13.686368
# Unit test for function find
def test_find():
    program = ast.parse('a=1\nb=2\nlen(b)')
    assert list(find(program, ast.Name)) == [ast.Name(id='a', ctx=ast.Store()), ast.Name(id='b', ctx=ast.Store()), ast.Name(id='len', ctx=ast.Load()), ast.Name(id='b', ctx=ast.Load())]

# Generated at 2022-06-12 04:57:15.743114
# Unit test for function find
def test_find():
    p = ast.parse('a = 1; b = 2;')
    print(list(find(p, ast.Name)))


# Generated at 2022-06-12 04:57:21.946327
# Unit test for function get_parent
def test_get_parent():
    code = """
        def foo(x, y):
            if x == y:
                return 0
            else:
                return 1
    """

    tree = ast.parse(code)

    if_node = tree.body[0].body[1]
    return_node = if_node.body[0]
    return_parent = get_parent(tree, return_node)

    assert if_node.lineno == return_parent.lineno == return_node.lineno == 4
    assert if_node.col_offset == return_parent.col_offset == \
        return_node.col_offset == 4

