

# Generated at 2022-06-12 04:47:35.082139
# Unit test for function find
def test_find():
    for i in range(4):
        for j in range(4):
            template = '''
if x == y:
    if z == 0:
        t = {} * {}


t = 0
t = 1
t = 2
t = 3
t = 4
t = 5
'''
            tree = ast.parse(template.format(i, j))
            print(list(map(lambda x: x.value, find(tree, ast.Name))))


# Generated at 2022-06-12 04:47:37.998948
# Unit test for function find
def test_find():
    tree = ast.parse('import sys, datetime')
    nodes = find(tree, ast.Import)
    assert nodes[0].names[1].name == 'datetime'

# Generated at 2022-06-12 04:47:45.620806
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class_node = ast.ClassDef(name='Test', body=[],
                              decorator_list=[],
                              starargs=None,
                              keywords=[],
                              kwargs=None)
    func_node = ast.FunctionDef(name='foo',
                                body=[],
                                decorator_list=[],
                                args=None,
                                returns=None)
    class_node.body.append(func_node)  # type: ignore

    assert get_non_exp_parent_and_index(class_node, func_node) == \
        (class_node, 0)

# Generated at 2022-06-12 04:47:51.100245
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def f():
        pass

    expected_parent = f.__code__.co_consts[0]
    expected_index = 0

    actual_parent, actual_index = get_non_exp_parent_and_index(
        f.__code__.co_code,
        f.__code__.co_consts[0].body[0]
    )

    assert actual_parent == expected_parent
    assert actual_index == expected_index

# Generated at 2022-06-12 04:47:58.323338
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('def a():\n    pass\n    #print expression\n    1 + 2')
    node = list(find(tree, ast.Name))[-1]
    assert isinstance(get_closest_parent_of(tree, node, ast.FunctionDef),
                      ast.FunctionDef)
    assert isinstance(get_closest_parent_of(tree, node, ast.Name),
                      ast.Name)

# Generated at 2022-06-12 04:48:09.839823
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import builtins
    test_ast = ast.parse('x = 1\nprint(x)\nx = 2\n')
    assert(get_non_exp_parent_and_index(test_ast, test_ast.body[0]).__repr__() ==
        "(<_ast.Module object at 0x107e88a90>, 0)")
    assert(get_non_exp_parent_and_index(test_ast, test_ast.body[2]).__repr__() ==
        "(<_ast.Module object at 0x107e88a90>, 2)")

# Generated at 2022-06-12 04:48:11.084653
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor


# Generated at 2022-06-12 04:48:16.148702
# Unit test for function find
def test_find():
    fn = ast.parse('def a():\n\treturn 1\n')
    a = find(fn, ast.FunctionDef)
    r = find(fn, ast.Return)
    assert isinstance(fn, ast.Module)
    assert isinstance(next(a), ast.FunctionDef)
    assert isinstance(next(r), ast.Return)



# Generated at 2022-06-12 04:48:22.830727
# Unit test for function find
def test_find():
    tree = ast.parse("""
    @add_to(a)
    def foo(b):
        x = a + b
        return x
        """)
    func_defs = list(find(tree, ast.FunctionDef))
    assert(len(func_defs) == 1)
    function_def = func_defs[0]
    assert(isinstance(function_def, ast.FunctionDef))
    assert(function_def.name == "foo")

# Generated at 2022-06-12 04:48:29.605633
# Unit test for function get_parent
def test_get_parent():
    """
    def test():
        a = 1
    get_parent(test, a)
    """
    module = ast.parse(test_get_parent.__doc__)
    func_def = module.body[0]

    for assign in func_def.body:
        if isinstance(assign, ast.Assign):
            assert get_parent(test_get_parent.__doc__, assign) == func_def


# Generated at 2022-06-12 04:48:34.219046
# Unit test for function find
def test_find():
     assert len(list(find(ast.parse('a = 1'), ast.Num))) == 1


# Generated at 2022-06-12 04:48:37.414774
# Unit test for function find
def test_find():
    tree = ast.parse('a = b + c\nprint(a)')
    names = find(tree, ast.Name)
    assert next(names).id == 'a'
    assert next(names).id == 'b'
    assert next(names).id == 'c'
    assert next(names).id == 'print'



# Generated at 2022-06-12 04:48:47.535012
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:55.001677
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    parent = ast.Module(body=[
        ast.Expr(value=ast.Name(id='print', ctx=ast.Load())),
        ast.Expr(value=ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()),
            args=[ast.Str(s='Hello, world!')], keywords=[]))
    ])

    node = parent.body[1].value
    assert get_non_exp_parent_and_index(parent, node) \
        == (parent, 1)

# Generated at 2022-06-12 04:49:03.530253
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:49:09.870512
# Unit test for function get_parent
def test_get_parent():
    src = '''
if True:
    None

x = 1
'''
    tree = ast.parse(src)

    assert isinstance(get_parent(tree, tree.body[0]), ast.Module)
    assert isinstance(get_parent(tree, tree.body[0].body[0]), ast.If)
    assert isinstance(get_parent(tree, tree.body[1]), ast.Module)



# Generated at 2022-06-12 04:49:10.499127
# Unit test for function find

# Generated at 2022-06-12 04:49:15.521318
# Unit test for function find
def test_find():
    import astor
    from . import example_code

    tree = ast.parse(example_code)

    for node in find(tree, ast.Name):
        assert isinstance(node, ast.Name)
        assert node.id == 'argv' or node.id == 'i' or node.id == 'a'



# Generated at 2022-06-12 04:49:19.526758
# Unit test for function get_parent
def test_get_parent():
    assert get_parent(ast.parse('a + b'), ast.parse('a').body[0].value) == ast.parse('a + b').body[0]
    assert get_parent(ast.parse('a + b'), ast.parse('a').body[0].value) != ast.parse('a * b').body[0]


# Generated at 2022-06-12 04:49:20.225086
# Unit test for function get_parent

# Generated at 2022-06-12 04:49:36.735345
# Unit test for function get_parent
def test_get_parent():
    import astor

    with open('tests/fixtures/simple.py') as f:
        tree = astor.parse_file(f)

    # Find first module level alias
    alias = find(tree, ast.alias).__next__()

    assert isinstance(get_parent(tree, alias), ast.Import)
    assert isinstance(get_parent(tree, alias, rebuild=True), ast.Import)

    try:
        get_parent(tree, alias, rebuild=True)
    except NodeNotFound:
        assert False

    # Orphaned node
    orphan = ast.Name()

    try:
        get_parent(tree, orphan)
    except NodeNotFound:
        assert True
    else:
        assert False

# Generated at 2022-06-12 04:49:42.453540
# Unit test for function replace_at
def test_replace_at():
    def f():
        x = 1
        return 1 + x
    tree = ast.parse(inspect.getsource(f))
    replace_at(1, tree.body[0], ast.Name(id='y', ctx=ast.Load()))
    assert ast.dump(tree) == textwrap.dedent("""
        def f():
            x = 1
            y = 1 + x
            return y
    """).strip()

# Generated at 2022-06-12 04:49:51.522310
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # the argument node is not the child of the parrent tree.
    tree = ast.parse("def foo(): pass")
    node = ast.parse("def bar(): pass").body[0]
    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)

    tree = ast.parse("def foo(): pass")
    node = ast.parse("def bar(): pass").body[0]
    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)

    tree = ast.parse("def foo(): pass")
    node = ast.parse("def bar(): pass").body[0]
    assert get_non_exp_parent_and_index(tree, node) == (tree, 0)

    tree = ast.parse("def foo(): pass")

# Generated at 2022-06-12 04:49:54.542218
# Unit test for function find
def test_find():
    code = """
    def foo():
        if True:
            pass

        if False:
            pass
    """
    module = ast.parse(code)
    module_if = find(module, ast.If)

    assert len(list(module_if)) == 2



# Generated at 2022-06-12 04:50:02.901382
# Unit test for function get_parent
def test_get_parent():
    tree1 = ast.parse("""x = [1,2,3,4]
    y = {}
    z = []
    while 1:
        x = 1
        y = 2
    """)
    tree2 = ast.parse("""x = [1,2,3,4]
    y = {}
    z = []
    while 1:
        x = 1
        y = 2
    """)
    x = tree1.body[0]
    parent = get_parent(tree1, x)
    assert parent.__eq__(tree1)

    while_stmt = tree1.body[3]
    parent = get_parent(tree1, while_stmt)
    assert parent.__eq__(tree1)

    assert get_parent(tree1, tree1) == None

# Generated at 2022-06-12 04:50:07.667860
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''\
    def foo():
        if a():
            return 0
    ''')

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[0])

    assert(parent == tree.body[0])
    assert(index == 0)

# Generated at 2022-06-12 04:50:10.433356
# Unit test for function find
def test_find():
    tree = ast.parse("if True: pass")

    for if_node in find(tree, ast.If):
        assert(isinstance(if_node, ast.If))

# Generated at 2022-06-12 04:50:11.401556
# Unit test for function get_parent

# Generated at 2022-06-12 04:50:16.013704
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    class Data(object):
        pass
    """)

    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            assert get_closest_parent_of(tree, node, ast.ClassDef) == tree.body[0]

# Generated at 2022-06-12 04:50:18.232865
# Unit test for function find
def test_find():
    example_ast = ast.parse('1 + 1')
    assert(1 + 1 == next(find(example_ast, ast.BinOp)).left.n)

# Generated at 2022-06-12 04:50:32.681343
# Unit test for function find
def test_find():
    tree = ast.parse('''class Bar:
    def foo():
        return 42
    print('python')''')
    for node in find(tree, ast.Expr):
        print(node)


# Generated at 2022-06-12 04:50:36.680424
# Unit test for function find
def test_find():
    code = """
    import json
    import re

    def main():
        print(json.dumps({"hello": "world"}))
    """
    tree = ast.parse(code)
    print([i.name for i in find(tree, ast.Attribute)])


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 04:50:40.012430
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    i = ast.parse('if a: b = c').body[0]
    a, b = get_non_exp_parent_and_index(i, i.body[0])
    assert isinstance(a, ast.If)
    assert b == 0

# Generated at 2022-06-12 04:50:41.463143
# Unit test for function find
def test_find():
    assert len(list(find(ast.parse('foo'), ast.Name))) == 1

# Generated at 2022-06-12 04:50:44.290665
# Unit test for function find
def test_find():
    x = ast.parse('x = 1')
    assert isinstance(find(x, ast.Assign).__next__(), ast.Assign)



# Generated at 2022-06-12 04:50:46.073826
# Unit test for function find
def test_find():
    assert all(isinstance(x, ast.Name) for x in find(ast.parse('a = 1'), ast.Name))

# Generated at 2022-06-12 04:50:52.369376
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('x = (1, 2, 3) + (4, 5, 6)')
    node = list(find(tree, ast.Tuple))[0]
    assert isinstance(get_closest_parent_of(tree, node, ast.Expr), ast.Expr)

    tree2 = ast.parse('[{}, {}]')
    node2 = list(find(tree2, ast.Dict))[0]
    assert isinstance(get_closest_parent_of(tree2, node2, ast.Module), ast.Module)

# Generated at 2022-06-12 04:51:01.895353
# Unit test for function get_parent
def test_get_parent():
    import pickle

    with open('test.pkl', 'rb') as f:
        tree = pickle.load(f)

    _build_parents(tree)
    parent = get_parent(tree, tree.body[0].body[0])

    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'set_statistics'

    parent = get_parent(tree, tree.body[0].body[0].body[2].values[-1])
    assert get_non_exp_parent_and_index(tree,
                                        tree.body[0].body[0].body[2].values[-1]) \
        == (tree.body[0].body[0].body[2], 2)


# Generated at 2022-06-12 04:51:04.740524
# Unit test for function find
def test_find():
    p = ast.parse('print(1)')
    assert len(list(find(p, ast.Print))) == 1
    assert isinstance(list(find(p, ast.Print))[0], ast.Print)

# Generated at 2022-06-12 04:51:10.711785
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def test_func(a):
        print(a)

    tree = ast.parse(test_func.__code__.co_code)
    parent, index = get_non_exp_parent_and_index(tree, tree.body.body[0])
    assert isinstance(parent, ast.Module)
    assert index == 0


if __name__ == '__main__':
    test_get_non_exp_parent_and_index()

# Generated at 2022-06-12 04:51:47.786433
# Unit test for function find
def test_find():
    import unittest
    import astor

    class TestFind(unittest.TestCase):
        def test_find_simple(self):
            ex = ast.parse('a = 1')
            self.assertEqual(astor.to_source(ex), 'a = 1')
            self.assertIsInstance(find(ex, ast.Assign).__next__(), ast.Assign)

        def test_find_no_match(self):
            ex = ast.parse('a = 1')
            self.assertEqual(astor.to_source(ex), 'a = 1')
            self.assertRaises(StopIteration, find(ex, ast.Raise).__next__)


# Generated at 2022-06-12 04:51:52.322214
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor  # type: ignore

    tree = ast.parse('if True:\n    print(1)\nelse:\n    print(0)')
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    assert index == 0
    assert astor.to_source(parent) == astor.to_source(tree.body[0])

# Generated at 2022-06-12 04:51:53.944716
# Unit test for function find

# Generated at 2022-06-12 04:52:03.885636
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    bin_op_a = ast.BinOp(ast.Name('a', ast.Load()), ast.Add(), ast.Name('b', ast.Load()))
    bin_op_c = ast.BinOp(ast.Name('c', ast.Load()), ast.Add(), ast.Name('d', ast.Load()))
    sub_expr_node = ast.Subscript(bin_op_a, ast.Index(bin_op_c), ast.Load())

    # Subscript has no body, so binop a is the best choice
    node, index = get_non_exp_parent_and_index(sub_expr_node, bin_op_a)

    assert isinstance(node, ast.Subscript) and index == 0

    # Index has no body, so binop c is the best choice
    node, index = get

# Generated at 2022-06-12 04:52:05.789417
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:52:13.508613
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('def foo():\n    pass\n')
    assert get_non_exp_parent_and_index(tree, tree.body[0]) == (tree, 0)
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == \
        (tree.body[0], 0)

    tree = ast.parse('if foo:\n    pass\n')
    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0]) == (
        tree.body[0], 0)

# Generated at 2022-06-12 04:52:23.313080
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def foo():
        print('foo')
        return 'bar'

    tree = ast.parse(dedent('''
    import sys
    import time

    class Foo(object):

        def bar(self):
            self.baz()

        def baz(self):
            print('test')
    '''))  # type: ast.Module

    for node in find(tree, ast.FunctionDef):
        if node.name == 'foo':
            parent, index = get_non_exp_parent_and_index(tree, node)
            assert parent is tree
            assert index == 4
            break

    for node in find(tree, ast.ClassDef):
        if node.name == 'Foo':
            parent, index = get_non_exp_parent_and_index(tree, node)
            assert parent is tree


# Generated at 2022-06-12 04:52:26.540307
# Unit test for function find
def test_find():
    node = ast.parse('a.b.c;')
    import pdb;pdb.set_trace()
    nodes = list(find(node, ast.Attribute))
    print(nodes)

if __name__ == '__main__':
    test_find()
    #unit_test()

# Generated at 2022-06-12 04:52:29.619277
# Unit test for function find
def test_find():
    assert list(find(ast.parse('if True:\n    if False:\n        pass'), ast.If)) == [ast.If(test=ast.NameConstant(value=True), body=[ast.If(test=ast.NameConstant(value=False), body=[ast.Pass()], orelse=[])], orelse=[])]



# Generated at 2022-06-12 04:52:38.830228
# Unit test for function replace_at
def test_replace_at():
    import astor
    testtree = astor.code_to_ast("""
    def f(a):
        if a == 1:
            return 1
    """)
    testnode = testtree.body[0].body[0]
    testparent = testtree.body[0]
    testreplace = ast.Return(value=ast.Num(1))
    testreplace2 = ast.Return(value=ast.Num(2))
    assert testparent.body[1].value.n == 1
    # Now do replacement
    replace_at(1, testparent, testreplace2)
    assert testparent.body[1].value.n == 2

if __name__ == "__main__":
    test_replace_at()

# Generated at 2022-06-12 04:53:44.213342
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:53:45.419370
# Unit test for function find
def test_find():
    find(ast.parse('a = 1'), ast.Assign)

# Generated at 2022-06-12 04:53:47.109254
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import sys

    from . import print_ast
    from . import parse_ast_from_str


# Generated at 2022-06-12 04:53:55.971211
# Unit test for function replace_at
def test_replace_at():
    # Example of code
    tree = ast.parse('def f():\n    a = 1\n    b = 2\n    c = 3\n    return c')

    # Find return node
    return_node = next(find(tree, ast.Return))

    # Get parent and index
    parent, index = get_non_exp_parent_and_index(tree, return_node)

    # Replace return node with new node
    a_asn_node = next(find(tree, ast.Assign))
    replace_at(index, parent, a_asn_node)

    # Check if return is replaced with assign node
    ast.fix_missing_locations(tree)
    print(ast.dump(tree))

# Generated at 2022-06-12 04:53:59.770961
# Unit test for function get_parent
def test_get_parent():
    def test_func(x, y):
        return x + y

    tree = ast.parse(inspect.getsource(test_func))
    assert get_parent(tree, tree.body[0].value.args[0]).__class__.__name__ == 'Name'
    assert get_parent(tree, tree.body[0].value.args[1]).__class__.__name__ == 'Name'



# Generated at 2022-06-12 04:54:08.183252
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Typical setup for unit tests
    from .. import transforms
    from ..testing.utils import parse_source_as_module

    # FIXME: bad copypast from compiled_visitor
    def _get_non_exp_parent_and_index(tree: ast.AST, node: ast.AST
                                      ) -> Tuple[ast.AST, int]:
        parent = get_parent(tree, node)

        while not hasattr(parent, 'body'):
            node = parent
            parent = get_parent(tree, parent)

        return parent, parent.body.index(node)


# Generated at 2022-06-12 04:54:09.388990
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # FIXME
    pass


# Generated at 2022-06-12 04:54:12.330226
# Unit test for function find
def test_find():
    assert isinstance(list(find(ast.parse('a = 2'), ast.Name))[0], ast.Name)



# Generated at 2022-06-12 04:54:21.716229
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""
    def foo(x):
        a = x + 1
        if x == 1:
            return a
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])

    assert isinstance(parent, ast.FunctionDef)
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[1])

    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

    tree = ast.parse("""
    def foo(x):
        if x == 1:
            return x
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].body[0])


# Generated at 2022-06-12 04:54:29.705447
# Unit test for function get_parent
def test_get_parent():
    _build_parents(ast.parse(
        """if a:
           if b:
               pass
        """
    ))
    assert _parents[ast.parse("b")] == ast.parse("if b: pass")
    assert _parents[ast.parse("if b: pass")] == ast.parse("if a: if b: pass")
    assert _parents[ast.parse("if a: if b: pass")] == ast.parse("if a: if b: pass")
    assert _parents[ast.parse("pass")] == ast.parse("if b: pass")



# Generated at 2022-06-12 04:57:10.063301
# Unit test for function find
def test_find():
    from typed_ast import ast3 as ast
    import inspect
    import os
    import unittest

    module_name = os.path.basename(__file__).rstrip('c')
    module_path = os.path.abspath(inspect.getsourcefile(test_find))
    module_dir = os.path.dirname(module_path)
    module_file = os.path.join(module_dir, module_name)

    with open(module_file, 'rb') as test_file:
        tree = ast.parse(test_file.read())

    class TestFind(unittest.TestCase):

        def test_find(self):
            for if_ in find(tree, ast.If):
                self.assertIsInstance(if_, ast.If)


# Generated at 2022-06-12 04:57:11.919843
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    import astor

# Generated at 2022-06-12 04:57:20.214002
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    node = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                      value=ast.Num(n=1))

    func_body = ast.Expr(value=node)
    func_def = ast.FunctionDef(name='test_func', args=ast.arguments(args=[],
                                                                    vararg=None,
                                                                    kwonlyargs=[],
                                                                    kw_defaults=[],
                                                                    kwarg=None,
                                                                    defaults=[]),
                               body=[func_body],
                               decorator_list=[],
                               returns=None)

    module_def = ast.Module(body=[func_def])
