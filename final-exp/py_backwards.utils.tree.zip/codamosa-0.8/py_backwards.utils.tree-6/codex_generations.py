

# Generated at 2022-06-12 04:47:30.313598
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    t = ast.parse("def foo():\n    print(1)\n    print(2)")  # type: ast.Module
    p = get_non_exp_parent_and_index(t, t.body[0].body[0])
    assert p == (t.body[0], 0)

# Generated at 2022-06-12 04:47:38.245630
# Unit test for function get_parent
def test_get_parent():
    source = """
    def function():
        def foo():
            pass
    """
    tree = ast.parse(source)
    _build_parents(tree)
    node_foo = tree.body[0].body[0]
    assert get_parent(tree, node_foo, rebuild=True) == tree.body[0]
    assert get_parent(tree, tree.body[0].body[0], rebuild=False) == tree.body[0]



# Generated at 2022-06-12 04:47:42.672097
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_tree = ast.parse('class A(object):\n    def b():pass')
    node = test_tree.body[0]
    test_parent, test_index = get_non_exp_parent_and_index(test_tree, node)
    assert test_parent == test_tree
    assert test_index == 0

# Generated at 2022-06-12 04:47:48.845653
# Unit test for function get_parent
def test_get_parent():
    import astor

    source_code = '''
        for i in range(1):
            def func(x):
                return x.method(2)
    '''

    tree = ast.parse(source_code)
    _build_parents(tree)

    test_node = list(find(tree, ast.Name))[0]
    parent_node = get_parent(tree, test_node)

    assert astor.to_source(parent_node) == 'func(x)'



# Generated at 2022-06-12 04:47:53.784865
# Unit test for function get_parent
def test_get_parent():
    code = """if True:
            if True:
                x = [1, 2]
            else:
                pass
        """
    tree = ast.parse(code.expandtabs(4))
    if_stmt = tree.body[0]
    if_body = if_stmt.body[0]
    pass_stmt = if_body.orelse[0]
    assert get_parent(tree, pass_stmt) == if_body


# Generated at 2022-06-12 04:48:01.285537
# Unit test for function get_parent
def test_get_parent():
    import astor
    tree = ast.parse('''class Test(object):
        def __init__(self):
            pass

        def run(self):
            pass
    ''')
    _build_parents(tree)

    assert astor.to_source(get_parent(tree, tree.body[0].body[0])) \
        == 'self'
    assert astor.to_source(get_parent(tree, tree.body[0].body[1].body[0])) \
        == 'self'

# Generated at 2022-06-12 04:48:04.227802
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    class Test:
        a = 1
        b = 2

    assert Test == get_closest_parent_of(Test, Test.b, Test)



# Generated at 2022-06-12 04:48:14.746224
# Unit test for function replace_at
def test_replace_at():
    import astor
    code = '''
    if a:
    b = 1
    c = 1
    '''
    tree = ast.parse(code)
    ast.fix_missing_locations(tree)
    print(astor.to_source(tree))
    assign_c = tree.body[0].body[1]
    print(astor.to_source(assign_c))
    print(astor.to_source(tree.body[0]))
    parent, index = get_non_exp_parent_and_index(tree, assign_c)
    print(astor.to_source(parent))
    replace_at(index, parent, ast.Assign(
        [ast.Name('new_name', ast.Store())],
        ast.Num(1)
    ))

# Generated at 2022-06-12 04:48:18.643040
# Unit test for function find
def test_find():
    from typed_ast.ast3 import Module, FunctionDef, Assign
    testTree = Module([FunctionDef("testFunction", [], [], [], Assign([], None), None, [])])
    assert len(list(find(testTree, FunctionDef))) == 1


# Generated at 2022-06-12 04:48:23.211767
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('a=1', mode='exec')
    v1 = tree.body[0].value
    result_expected = (tree.body[0], 0)
    result = get_non_exp_parent_and_index(tree, v1)
    assert result == result_expected

# Generated at 2022-06-12 04:48:28.645001
# Unit test for function find
def test_find():
    from .ast import from_string
    f = from_string('def foo(): pass')
    assert list(find(f, ast.FunctionDef)) == [f.body[0]]
    assert len(list(find(f, ast.arguments))) == 1
    assert len(list(find(f, ast.Name))) == 1

# Generated at 2022-06-12 04:48:33.006079
# Unit test for function find
def test_find():
    node = ast.parse('for i in range(10): print(i)')
    for_ = list(find(node, ast.For))
    assert len(for_) == 1, 'for statement not found'
    for_ = for_[0]
    assert type(for_.iter) == ast.Call, 'Wrong iterator found'

# Generated at 2022-06-12 04:48:34.445351
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:48:41.804261
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree=ast.parse('''
    def f():
        def function():
            def function_2():
                pass
        return function_2
    
    def function_3():
        pass''')
    node=get_closest_parent_of(tree,tree.body[0].body[0].body[0],ast.FunctionDef)
    parent,index=get_non_exp_parent_and_index(tree,node)
    assert(repr(parent)=='<_ast.Module object at 0x000000000000>')
    assert(index==0)

# Generated at 2022-06-12 04:48:43.692934
# Unit test for function find
def test_find():
    node = ast.parse('print(foo())')
    print(list(find(node, ast.FunctionDef)))

# Generated at 2022-06-12 04:48:50.082991
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    from ast_utils import parse
    tree = parse("""
    def foo(a, b):
        c = a + b
        d = a * b
    """)
    (ast_node, index) = get_non_exp_parent_and_index(tree, tree.body[0].body[1])

# Generated at 2022-06-12 04:48:51.198321
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:49:01.097532
# Unit test for function get_parent
def test_get_parent():
    import unittest

    from ..ast_utils import parse_code
    from . import compute_offsets

    class TestGetParent(unittest.TestCase):

        def test_get_parent(self):
            code = '''
            class X:
                def foo(self):
                    pass
            '''
            tree = parse_code(code)
            tree = compute_offsets(tree)
            node = next(find(tree, ast.FunctionDef))
            parent = get_parent(tree, node)
            self.assertEqual(parent.name, 'X')

            node = next(find(tree, ast.ClassDef))
            parent = get_parent(tree, node)
            self.assertIsInstance(parent, ast.Module)

    unittest.main()

# Generated at 2022-06-12 04:49:08.600182
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    test_ast = ast.parse("""
        def func():
            a = 2 + 3
            if a > 2:
                return 10 + 5
        class A:
            def func1(self, a):
                pass
    """)
    return_node = test_ast.body[0].body[1].body[0]
    func_node = get_closest_parent_of(test_ast, return_node, ast.FunctionDef)
    assert func_node.name == 'func'

# Generated at 2022-06-12 04:49:15.611104
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse('''
if expression:
    print('expression is true')
    print('expression is true')
    print('expression is true')
    print('expression is true')
''')
    print_node = tree.body[0].body[0]

    non_exp_parent, index = get_non_exp_parent_and_index(tree, print_node)
    assert index == 0
    assert isinstance(non_exp_parent, ast.If)



# Generated at 2022-06-12 04:49:25.614495
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('for i in range(20): print(i)')
    print(_parents)

    assert get_parent(tree, tree.body[0]) == tree
    assert get_parent(tree, tree.body[0].body[0].values[0]) == tree.body[0].body[0]

    assert get_parent(tree.body[0].body[0], tree.body[0].body[0].values[0]) == tree.body[0].body[0]



# Generated at 2022-06-12 04:49:29.815952
# Unit test for function find
def test_find():
    from ..util import parse_ast
    
    tree = parse_ast('def foo(a: int, b: int) -> int:\n\tpass\n')
    funcs = list(find(tree, ast.FunctionDef))

    assert len(funcs) == 1
    assert funcs[0].name == 'foo'

# Generated at 2022-06-12 04:49:34.154387
# Unit test for function find
def test_find():
    tree = ast.parse('def f():\n  return 2')
    assert len(list(find(tree, ast.Return))) == 1
    assert len(list(find(tree, ast.arg))) == 0


# Generated at 2022-06-12 04:49:38.446686
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    input_node = ast.parse("""\
x = 1
y = 2
""")

    expected_result = (input_node, 1)
    actual_result = get_non_exp_parent_and_index(input_node, input_node.body[1])

    assert expected_result == actual_result

# Generated at 2022-06-12 04:49:39.563519
# Unit test for function find

# Generated at 2022-06-12 04:49:45.985455
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    x = ast.parse('if foo:\n    print("bar")')
    func_def = x.body[0]
    func_def_2 = x.body[0].body[0]
    func_def_3 = x.body[0].body[0].body[0]
    func_def_4 = x.body[0].body[0].body[0].value
    func_def_3.test = func_def_4
    assert get_non_exp_parent_and_index(x, func_def_3)[0] == func_def_2
    assert get_non_exp_parent_and_index(x, func_def_3)[1] == 0
    assert get_non_exp_parent_and_index(x, func_def_2)[0] == func_def
    assert get_

# Generated at 2022-06-12 04:49:50.440465
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    code = """x = [z for z in range(3) if z < 3]
for y in x:
    pass"""
    tree = ast.parse(code)
    for_node = get_closest_parent_of(tree, tree.body[1].body[0], ast.For)
    assert for_node.body[0].value.args[0].id == "y"

# Generated at 2022-06-12 04:49:56.129808
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """
    Test get_non_exp_parent_and_index method.
    """
    test_source = '''
    class Test(object):
        def test_get_non_exp_parent_and_index(self):
            return 1
    '''
    test_tree = ast.parse(test_source)
    test_node = find(test_tree, ast.Return).__next__()
    non_exp_parent, index = get_non_exp_parent_and_index(test_tree, test_node)
    assert isinstance(non_exp_parent, ast.FunctionDef)
    assert index == 3

# Generated at 2022-06-12 04:50:03.190762
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    class A(ast.AST):
        name = 'A'
        _fields = ()
    class B(ast.AST):
        name = 'B'
        _fields = ('body',)

    t1 = ast.AST()
    t2 = ast.AST()
    t3 = ast.AST()
    a1 = A()
    a2 = A()
    b1 = B(body=[t1, a1, t2])
    b2 = B(body=[b1, t3, a2])

    assert get_non_exp_parent_and_index(b2, a1) == (b1, 1)
    assert get_non_exp_parent_and_index(b2, a2) == (b2, 2)

# Generated at 2022-06-12 04:50:06.850643
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    def f():
        return 1

    parent, index = get_non_exp_parent_and_index(f.__code__,
                                                 f.__code__.co_consts[0])
    assert parent is f.__code__
    assert index == 2

# Generated at 2022-06-12 04:50:19.511610
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # create AST for code "a + b + c"
    add1 = ast.BinOp(
        left=ast.Name(id='a', ctx=ast.Load()),
        op=ast.Add(),
        right=ast.Name(id='b', ctx=ast.Load())
    )

    add2 = ast.BinOp(
        left=add1,
        op=ast.Add(),
        right=ast.Name(id='c', ctx=ast.Load())
    )

    module = ast.Module(body=[add2])

    # get parent for "b"
    parent = get_closest_parent_of(module, add1, ast.Module)
    assert isinstance(parent, ast.Module)

    # get parent for "a"
    parent = get_closest_parent

# Generated at 2022-06-12 04:50:25.120299
# Unit test for function get_parent
def test_get_parent():
    source_code = """
    import os
    import pytest

    def test_index():
        pass
    """
    ast_tree = ast.parse(source_code)
    test_function_node = ast_tree.body[-1]
    assert get_parent(ast_tree, test_function_node).body == ast_tree.body


# Generated at 2022-06-12 04:50:27.157914
# Unit test for function find
def test_find():
    code = "def hi(): pass"
    tree = ast.parse(code)
    res = find(tree, ast.FunctionDef)
    assert type(res) == type(iter([]))
    assert list(res)[0].name == 'hi'

# Generated at 2022-06-12 04:50:33.520324
# Unit test for function find
def test_find():
    test = """def foo():
        print('Hello, world!')"""
    assert len(list(find(ast.parse(test), ast.Expr))) == 1
    assert len(list(find(ast.parse(test), ast.Call))) == 1
    assert len(list(find(ast.parse(test), ast.Print))) == 0
    assert len(list(find(ast.parse(test), ast.Str))) == 1
    assert len(list(find(ast.parse(test), ast.FunctionDef))) == 1
    assert len(list(find(ast.parse(test), ast.Load))) == 1
    assert len(list(find(ast.parse(test), ast.Store))) == 0


# Generated at 2022-06-12 04:50:34.155375
# Unit test for function find
def test_find():
    pass

# Generated at 2022-06-12 04:50:37.690778
# Unit test for function find
def test_find():
    tree = ast.parse('def a():\n pass\n')
    for func in find(tree, ast.FunctionDef):
        assert func.name == 'a'

    tree = ast.parse('pass\n')
    for _ in find(tree, ast.FunctionDef):
        assert False, 'Should not yield function'


# Generated at 2022-06-12 04:50:45.206943
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    # case 1
    module = ast.parse('def function(arg):\n\treturn arg')
    assert isinstance(get_closest_parent_of(module, module.body[0].body[0],
                                            ast.FunctionDef),
                      ast.FunctionDef)

    # case 2
    module = ast.parse('def function(arg):\n\treturn function(arg)')
    assert isinstance(get_closest_parent_of(module, module.body[0].body[0],
                                            ast.FunctionDef),
                      ast.FunctionDef)

    # case 3
    module = ast.parse('def function(arg):\n\treturn arg\n\nfunction(arg)')

# Generated at 2022-06-12 04:50:46.472412
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:50:49.300136
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("1 + 2 + 3")
    assert(get_closest_parent_of(tree, tree.body[0].value, ast.Module).body
           == [tree.body[0]])



# Generated at 2022-06-12 04:50:52.598090
# Unit test for function find
def test_find():
    """Unit test for function find."""
    from ast import parse

    statement = 'def func(): if True: pass\n'
    func_def_node = list(find(parse(statement), ast.FunctionDef))[0]

    assert func_def_node.name == 'func'

# Generated at 2022-06-12 04:51:03.261420
# Unit test for function get_parent
def test_get_parent():
    test_str = "a = 1; b = 2; c = 3"
    test_tree = ast.parse(test_str)

    _build_parents(test_tree)

    a_stmt = test_tree.body[0]
    a_expr = a_stmt.value
    b_stmt = test_tree.body[1]
    b_expr = b_stmt.value
    c_stmt = test_tree.body[2]
    c_expr = c_stmt.value

    assert get_parent(test_tree, a_expr) == a_stmt
    assert get_parent(test_tree, b_expr) == b_stmt
    assert get_parent(test_tree, c_expr) == c_stmt


# Generated at 2022-06-12 04:51:13.485173
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    parent = ast.Module(body=[ast.If(test=ast.Num(n=1),
                                     body=[ast.If(test=ast.Num(n=2),
                                                  body=[ast.Num(n=3)],
                                                  orelse=[ast.Num(n=4)])],
                                     orelse=[ast.If(test=ast.Num(n=5),
                                                    body=[ast.Num(n=6)],
                                                    orelse=[ast.Num(n=7)])])])


# Generated at 2022-06-12 04:51:21.606308
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse('''
        def foo(a, b, c):
            if True:
                if True:
                    print('hi')
            else:
                print('bye')
    ''')

    parent = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    assert isinstance(parent, ast.FunctionDef)
    assert parent == tree.body[0]

    parent = get_closest_parent_of(tree, tree.body[0].body[0], ast.If)
    assert isinstance(parent, ast.If)
    assert parent == tree.body[0].body[0]



# Generated at 2022-06-12 04:51:22.492801
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    assert False

# Generated at 2022-06-12 04:51:23.724478
# Unit test for function get_closest_parent_of

# Generated at 2022-06-12 04:51:30.295199
# Unit test for function find
def test_find():
    """Test for function find."""
    source = \
        """
        def foo(x):
            pass

        def bar(y):
            pass
        """

    tree = ast.parse(source)
    function_list = list(find(tree, ast.FunctionDef))

    assert len(function_list) == 2
    assert function_list[0].name == 'foo'
    assert function_list[1].name == 'bar'



# Generated at 2022-06-12 04:51:32.208302
# Unit test for function find
def test_find():
    assert list(find(ast.parse('a = 42'), ast.Assign)) == [ast.parse('a = 42').body[0]]



# Generated at 2022-06-12 04:51:40.317393
# Unit test for function get_parent
def test_get_parent():
    tree = ast.parse('def function(): pass')
    node_for_parents = tree.body[0]
    node_for_parents.body = [ast.Pass()]
    node_for_parents.args.args = [ast.arg(arg='arg', annotation=None)]

    node_for_parents.decorator_list = [ast.Name(id='decorator', ctx=None)]

    parent, index = get_non_exp_parent_and_index(tree, node_for_parents.body[0])
    assert parent is node_for_parents
    assert index == 0

    parent, index = get_non_exp_parent_and_index(tree, node_for_parents.args.args[0])
    assert parent is node_for_parents.args
    assert index == 0


# Generated at 2022-06-12 04:51:41.747084
# Unit test for function find
def test_find():
    """Test AST node find."""

# Generated at 2022-06-12 04:51:46.870894
# Unit test for function get_parent
def test_get_parent():
    import astor

    test_node = ast.Expr()
    test_parent = ast.Module(body=[test_node])

    test_parent_real = get_parent(test_parent, test_node)

    assert astor.to_source(test_parent_real) == '<Module> (line: 1)'



# Generated at 2022-06-12 04:52:00.380504
# Unit test for function get_parent
def test_get_parent():
    import astor
    tree = astor.parse_file("./tests/parent.py")
    _build_parents(tree)
    test = tree.body[0].body[0]
    assert isinstance(_parents[test], ast.FunctionDef)
    assert _parents[test].name == 'parent'
    assert isinstance(_parents[test].body[0], ast.FunctionDef)
    assert _parents[test].body[0].name == 'child'
    assert isinstance(_parents[test].body[1], ast.If)



# Generated at 2022-06-12 04:52:03.756227
# Unit test for function find
def test_find():
    tree = ast.parse('1')
    number = find(tree, ast.Num)
    for node in number:
        assert isinstance(node, ast.Num)
        assert node.n == 1
    assert len(list(number)) == 1

# Generated at 2022-06-12 04:52:09.499868
# Unit test for function find
def test_find():
    import unittest as ut

    class FindTest(ut.TestCase):
        def setUp(self):
            self.tree = ast.parse('a = "test"')
            self.expected = 3

        def test_find(self):
            result = len(list(find(self.tree, ast.Str)))

            self.assertEqual(result, self.expected)

    ut.main()

# Generated at 2022-06-12 04:52:20.132379
# Unit test for function get_parent
def test_get_parent():
    import sys
    if sys.hexversion >= 0x30600F0:
        import unittest
        import astunparse

    else:
        import unittest2 as unittest
        import astunparse2 as astunparse

    class Tests(unittest.TestCase):
        def test_get_parent(self):
            test_code = '''
            def foo():
                args = 1
            '''
            tree = ast.parse(test_code)
            node_to_search = list(tree.body)[0].body[0].value.args[0]
            parent = get_parent(tree, node_to_search)
            self.assertEqual(astunparse.unparse(parent), 'args = 1')

    return unittest.main()

# Generated at 2022-06-12 04:52:26.017041
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test1
    tree = ast.parse('def f():\n    a = 0\n    return True')
    node = list(find(tree, ast.Name))[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 1

    # Test2
    tree = ast.parse('def f():\n    a = 0\n    return True')
    node = list(find(tree, ast.Return))[0]
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert isinstance(parent, ast.FunctionDef)
    assert index == 2

# Generated at 2022-06-12 04:52:32.632507
# Unit test for function find
def test_find():
    assert list(find(ast.parse('a = 1 + 2'), ast.FunctionDef)) == []
    assert list(find(ast.parse('def f(): pass'), ast.FunctionDef)) == [
        ast.FunctionDef(name='f', args=ast.arguments(args=[], vararg=None,
                        kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                        body=[ast.Pass()], decorator_list=[], returns=None)]

# Generated at 2022-06-12 04:52:37.412868
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    tree = ast.parse("""
    def f():
        a = lambda x: {} + 1
        return a(0)
    print(f())""")

    lambda_ = find(tree, ast.Lambda).__next__()
    assert get_closest_parent_of(tree, lambda_, ast.FunctionDef) is tree  # type: ignore

# Generated at 2022-06-12 04:52:38.404262
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:52:42.751872
# Unit test for function find
def test_find():
    tree = ast.parse('''
if True:
    print('a')
    print('b')
    print('c')

if True:
    print('d')
    print('e')
    print('f')
''')

    assert len(list(find(tree, ast.Str))) == 6
    assert len(list(find(tree, ast.Print))) == 6

# Generated at 2022-06-12 04:52:47.195752
# Unit test for function find
def test_find():
    """Test for function find."""
    _source = """
    def foo(a, b, c):
      return a + b + c
    """
    tree = ast.parse(_source)
    from anast.ast_nodes.function_def_nodes import FunctionDef
    assert isinstance(find(tree, FunctionDef).__next__(), FunctionDef)
    from anast.ast_nodes.name import Name
    assert isinstance(find(tree, Name).__next__(), Name)


# Unit tests for function get_parent

# Generated at 2022-06-12 04:53:04.093534
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    parent = ast.Module(body=[ast.Expr(value=ast.Name(id='x')), ast.Expr(value=ast.Name(id='y')), ast.Expr(value=ast.Name(id='z'))])
    node = ast.Name(id='y')
    non_exp_parent, index = get_non_exp_parent_and_index(parent, node)
    assert non_exp_parent == parent
    assert index == 1


# Generated at 2022-06-12 04:53:09.845620
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    test_file = open(
        'examples/pytest/test_example.py', 'r'
    )
    tree = ast.parse(test_file.read())

    import_node = find(tree, ast.Import).__next__()
    function_node = find(tree, ast.FunctionDef).__next__()
    body = get_non_exp_parent_and_index(tree, import_node)
    assert body[0] == function_node.body
    assert body[1] == 0

    test_file.close()

# Generated at 2022-06-12 04:53:17.129255
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    import unittest
    import src.ast.parser as parser
    class GetClosestParentOfTestCase(unittest.TestCase):
        def test_get_closest_parent_of(self):
            source = "def f():\n  return 1 + 2;"
            tree = parser.parse(source)
            f = find(tree, ast.FunctionDef).__next__()
            return_ = find(tree, ast.Return).__next__()
            func_body = get_closest_parent_of(tree, return_, ast.FunctionDef)
            self.assertEqual(f, func_body)
    unittest.main()

# Generated at 2022-06-12 04:53:22.114175
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    src = '''
    def f():
        return 1+1
    '''

    tree = ast.parse(src)

    if_node = ast.If(test=ast.Name('test', ast.Load()),
                     body=[get_parent(tree, tree.body[0].body[0])],
                     orelse=[get_parent(tree, tree.body[0].body[0])])
    replace_at(0, tree.body[0], if_node)

    assert get_non_exp_parent_and_index(tree, tree.body[0].body[0].body[
        0].body[0]) == (if_node, 0)

# Generated at 2022-06-12 04:53:27.780346
# Unit test for function find
def test_find():
    tree = ast.parse("import itertools\nfrom typing import List\n"
                     "l = [] # type: List[int]\nprint(l)\n")
    list_ = find(tree, ast.List).next()
    module_ = find(tree, ast.Module).next()
    assert module_ == tree
    assert type(module_) == ast.Module
    assert list_ == module_.body[1].targets[0]
    assert type(list_) == ast.Name



# Generated at 2022-06-12 04:53:30.910129
# Unit test for function get_parent
def test_get_parent():
    # Arrange
    node = ast.parse("a = 10")

    # Act
    parent = get_parent(node, node.body[0].targets[0])

    # Assert
    assert isinstance(parent, ast.Assign)



# Generated at 2022-06-12 04:53:39.873407
# Unit test for function get_parent
def test_get_parent():
    code = """class KSL(object):
    def __init__(self):
        self.mean = np.zeros(self.D, dtype='float64')
        self.covariance = np.eye(self.D)
        self.covariance_cholesky = np.linalg.cholesky(self.covariance)
        self.covariance_inverse = np.linalg.inv(self.covariance)
        self.covariance_determinant = np.linalg.det(self.covariance)"""
    code_ast = ast.parse(code)
    parent = get_parent(code_ast, code_ast.body[0].body[0], rebuild=True)
    assert (isinstance(parent, ast.ClassDef))

# Generated at 2022-06-12 04:53:47.968350
# Unit test for function get_closest_parent_of
def test_get_closest_parent_of():
    assertEqual(get_closest_parent_of(ast.parse('a = 1 if True else 2'), ast.Name(id='a'),
            ast.Assign), ast.Assign(targets=[ast.Name(id='a')], value=ast.IfExp(test=ast.NameConstant(value=True), body=ast.Num(n=1), orelse=ast.Num(n=2))))
    assertEqual(get_closest_parent_of(ast.parse('a = b = c = 1'), ast.Name(id='b'),
            ast.Assign), ast.Assign(targets=[ast.Name(id='b')], value=ast.Name(id='c')))


# Generated at 2022-06-12 04:53:56.004080
# Unit test for function find
def test_find():  # pragma: no cover
    from typing import Generator, List

    test_node = ast.parse('def foo():\n    a = 1\n    b = 2')
    foo = test_node.body[0]
    a = foo.body[0].value
    b = foo.body[1].value

    assert(list(find(a, ast.AST)) == [a])
    assert(list(find(foo, ast.AST)) == [foo, a, b])
    assert(list(find(foo, ast.Num)) == [a])
    assert(list(find(a, ast.AST)) == [a])



# Generated at 2022-06-12 04:54:07.290111
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    BOOLOP_AND = 1
    BOOLOP_OR = 2

    def _create_boolop(boolop_type: int,
                       left: ast.AST, right: ast.AST
                       ) -> ast.BoolOp:
        return ast.BoolOp(boolop_type, [left, right])

    # Create AST tree
    ast_node = _create_boolop(BOOLOP_AND, ast.Name('a', ast.Load()),
                              _create_boolop(BOOLOP_OR, ast.Name('b', ast.Load()),
                                             ast.Name('c', ast.Load())))

    # Get parent of `b` and index of `b` with respect to parent.

# Generated at 2022-06-12 04:54:43.920388
# Unit test for function find
def test_find():
    x = ast.parse('x = 1', '<test>', 'exec')
    y = ast.parse('y = 1', '<test>', 'exec')
    t1 = ast.Suite([x, y])
    t2 = ast.Suite([t1])
    assert list(find(t2, ast.Name)) == [ast.Name(id='x', ctx=ast.Store()),
                                        ast.Name(id='y', ctx=ast.Store())]
    x.id = 'z'
    assert list(find(t2, ast.Name)) == [ast.Name(id='z', ctx=ast.Store()),
                                        ast.Name(id='y', ctx=ast.Store())]
    assert list(find(t2, ast.FunctionDef)) == []

# Generated at 2022-06-12 04:54:46.357428
# Unit test for function get_parent
def test_get_parent():
    parent = ast.parse('a = 1').body[0]  # type: ast.AST
    node = parent.value

    result = get_parent(parent, node)

    assert result is parent

# Generated at 2022-06-12 04:54:51.209185
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    # Test
    tree = ast.parse("""
    a = 1
    if a:
        a
    """)
    parent, index = get_non_exp_parent_and_index(tree, tree.body[0].targets[0])

    # Assert
    assert isinstance(parent, ast.If)
    assert index == 0

# Generated at 2022-06-12 04:54:52.065432
# Unit test for function get_non_exp_parent_and_index

# Generated at 2022-06-12 04:54:57.112042
# Unit test for function get_parent
def test_get_parent():
    # Simple example
    def f1(a):
        b = a + 2
        return b

    _, node = get_non_exp_parent_and_index(ast.parse('').body[0],
                                           ast.parse(f1.__code__.co_code))
    parent = get_parent(ast.parse('').body[0], node)
    assert isinstance(parent, ast.FunctionDef)
    assert parent.name == 'f1'



# Generated at 2022-06-12 04:54:57.818918
# Unit test for function replace_at
def test_replace_at():
    import astor

# Generated at 2022-06-12 04:55:02.062931
# Unit test for function find
def test_find():
    # Arrange
    src = '''
    a = 1
    a = 2
    a = 3
    '''
    tree = ast.parse(src)
    fake_node = ast.Name(id='a', ctx=ast.Store())

    # Act
    nodes = list(find(tree, ast.Name))

    # Assert
    assert nodes[0] == fake_node



# Generated at 2022-06-12 04:55:07.645197
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    three = ast.Num(n=3)
    add = ast.Add()
    two = ast.Num(n=2)
    two.n = 2
    expr = ast.BinOp(left=three, op=add, right=two)
    one = ast.Num(n=1)
    one.n = 1
    a = ast.Module(body=[ast.Expr(value=expr), one])
    (expr2, one2) = a.body
    assert get_non_exp_parent_and_index(a, one) == (a, 1)

# Generated at 2022-06-12 04:55:12.177050
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Unit test for function get_non_exp_parent_and_index"""
    tree = ast.parse('a = 1')
    node = tree.body[0].value
    result = get_non_exp_parent_and_index(tree, node)
    expected = (tree.body[0], 0)
    print('result: {}, expected: {}'.format(result, expected))
    assert(result == expected)


# Generated at 2022-06-12 04:55:18.217977
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    """Test node extraction from a tree."""
    from .parser import parse_tree

    tree = parse_tree(
        """
        i: int = 0
        i += 1
        """
    )
    node = find(tree, ast.Name).__next__()

    parent = get_non_exp_parent_and_index(tree, node)[0]

    assert(isinstance(parent, ast.AugAssign))

# Generated at 2022-06-12 04:56:40.840746
# Unit test for function replace_at
def test_replace_at():
    # given
    tree = ast.parse('def hello(a, b):\n  return a + b')
    print(ast.dump(tree))

    # when
    parent = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    print(ast.dump(parent))

    # then
    #assert(parent.body[0].value.left.id == "t")



# Generated at 2022-06-12 04:56:44.856432
# Unit test for function find
def test_find():
    test_tree = ast.parse("""
        def f():
            pass
        def g():
            pass
        def h():
            pass
    """)
    results = list(find(test_tree, ast.FunctionDef))

    for result in results:
        assert isinstance(result, ast.FunctionDef)

    assert len(results) == 3


# Generated at 2022-06-12 04:56:48.788797
# Unit test for function find
def test_find():
    def print_hello_world():
        print("Hello world")
        pass
    tree = ast.parse(print_hello_world.__code__)
    assert len([node for node in find(tree, ast.Print)]) == 1
    assert len([node for node in find(tree, ast.Pass)]) == 1



# Generated at 2022-06-12 04:56:55.546983
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = ast.parse("""a = 1\na += 2""")
    a_node = tree.body[1].value
    a_plus_node = tree.body[1]
    parent_node, index = get_non_exp_parent_and_index(tree, a_node)
    assert parent_node.body[0] == tree.body[0]
    assert index == 1

    parent_node, index = get_non_exp_parent_and_index(tree, a_plus_node)
    assert parent_node.body[0] == tree.body[0]
    assert index == 1


# Generated at 2022-06-12 04:56:57.826047
# Unit test for function find
def test_find():
    import astpp

    def f():
        pass

    f_ast = ast.parse(f.__code__.co_consts[0])


# Generated at 2022-06-12 04:57:05.923020
# Unit test for function find
def test_find():
    import astor
    from .general import _get_code_from_ast

    tree = astor.parse_file('tests/files/example_files/signatures.py')
    for ast_node in find(tree, ast.Call):
        if ast_node.func.id == 'print':
            assert _get_code_from_ast(ast_node) == 'print("Hello World!")'
        elif ast_node.func.id == 'type':
            assert _get_code_from_ast(ast_node) == 'type(self.val)'
        elif ast_node.func.id == 'my_function':
            assert _get_code_from_ast(ast_node) == 'my_function(3)'
            assert _get_code_from_ast(ast_node.args[0]) == '3'

# Generated at 2022-06-12 04:57:15.519611
# Unit test for function get_non_exp_parent_and_index
def test_get_non_exp_parent_and_index():
    tree = parse_string(
        """
        import testing
        def foo():
            pass

        def bar():
            pass
        """, 'test.py')

    def_ = get_closest_parent_of(tree, tree.body[1].body[0], ast.FunctionDef)
    parrent1, index1 = get_non_exp_parent_and_index(tree, tree.body[1].body[0])
    assert def_ is parrent1
    assert index1 == 1

    def_ = get_closest_parent_of(tree, tree.body[0].body[0], ast.FunctionDef)
    parrent2, index2 = get_non_exp_parent_and_index(tree, tree.body[0].body[0])
    assert def_ is parrent2
    assert index2

# Generated at 2022-06-12 04:57:23.005438
# Unit test for function replace_at
def test_replace_at():
    my_ast = ast.parse('''
for i in range(10):
    for j in range(10):
        if i == j:
            a = i + j
        else:
            a = i * j
    print(a)
''')
    replace_at(0, get_closest_parent_of(my_ast, my_ast.body[0].body[0].body[0].body[0],
                                        ast.For), ast.parse('a = 5'))