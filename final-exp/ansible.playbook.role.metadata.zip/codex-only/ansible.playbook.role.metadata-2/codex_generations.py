

# Generated at 2022-06-23 06:55:32.562046
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({
        'allow_duplicates': False,
        'dependencies': []
    })
    asserts = (r.allow_duplicates, r.dependencies)
    assert asserts == (False, [])

# Generated at 2022-06-23 06:55:43.470720
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role

    # input data

# Generated at 2022-06-23 06:55:47.796243
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test for the class constructor
    print("# Constructor test for class RoleMetadata")
    # Create an instance of class RoleMetadata
    role_metadata = RoleMetadata()
    print(role_metadata)
    print("Instance of class RoleMetadata created")
    return role_metadata


# Generated at 2022-06-23 06:55:54.382687
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {'allow_duplicates': False, 'dependencies': []}
    rmd = RoleMetadata(None)
    rmd.deserialize(data)
    assert rmd.allow_duplicates is False
    assert rmd.dependencies == []

# Generated at 2022-06-23 06:55:57.218842
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_metadata = RoleMetadata()
    assert test_metadata._allow_duplicates == False
    assert test_metadata._dependencies == []
    assert isinstance(test_metadata._argument_specs, dict)
    assert test_metadata._owner == None

# Generated at 2022-06-23 06:56:01.956117
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    my_role = RoleMetadata(owner='test')
    my_role._owner = 'test'
    data = dict(
        allow_duplicates=True,
        dependencies=['test', 'test2']
    )

    my_role.deserialize(data)

    assert my_role.serialize() == data

# Generated at 2022-06-23 06:56:02.571044
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 06:56:08.907413
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    data = dict(
        allow_duplicates=False,
        dependencies=['role1','role2','role3','role4']
    )

    metadata = RoleMetadata()
    metadata.deserialize(data)
    serialized_data = metadata.serialize()

    assert data['allow_duplicates'] == serialized_data['allow_duplicates']
    assert data['dependencies'] == serialized_data['dependencies']

# Generated at 2022-06-23 06:56:20.369752
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # Prepare a sample data to be consumed by the method load
    # of RoleMetadata class.
    data = {'galaxy_info': {'author': 'foobar@ansible.com', 'min_ansible_version': '2.5', 'company': 'foo'},
            'dependencies': [{'role': 'galaxy.foo'}], 'allow_duplicates': False}

    # Instantiate RoleMetadata class.
    role_meta = RoleMetadata()

    # Load the sample data and check if the loaded object is not None
    role_meta = role_meta.load(data, None, None, None)
    assert role_meta is not None

    # Check if the galaxy_info object is not None
    assert role_meta._galaxy_info is not None
    assert role_meta._galaxy_info.company

# Generated at 2022-06-23 06:56:21.580766
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print(RoleMetadata)

# Generated at 2022-06-23 06:56:28.890902
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    metadata = RoleMetadata()
    metadata.allow_duplicates = True
    metadata.dependencies = ['role1', 'role2']

    data = metadata.serialize()

    assert data['allow_duplicates'] is True
    assert data['dependencies'] == ['role1', 'role2']


# Generated at 2022-06-23 06:56:40.411242
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.name_loader import RoleLoader

    def create_data_structure(role_names):
        name_list = [RoleDefinition(name) for name in role_names]
        name_dict = RoleLoader.generate_role_names_from_defs(name_list)
        module_path = './tests/units/module_utils/roles/r.meta.yml'
        return name_dict, module_path


# Generated at 2022-06-23 06:56:44.717617
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    with open('test/unit/galaxy/metadata.yml', 'rb') as f:
        data = f.read()
    #Test with no owner
    m = RoleMetadata().load(data=yaml.safe_load(data), owner=None)
    m.prepare(Loader())
    serialized = m.serialize()
    assert serialized['allow_duplicates'] is True
    assert serialized['dependencies'][0] == {'role': 'geerlingguy.mysql'}


# Generated at 2022-06-23 06:56:52.590368
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class FakeRole(object):
        def __init__(self, role_name):
            self.role_name = role_name
        def get_name(self):
            return self.role_name
    roledata = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    rm = RoleMetadata(owner=FakeRole('fake_owner'))
    rm.deserialize(roledata)
    assert rm._allow_duplicates == roledata['allow_duplicates']
    assert rm._dependencies == roledata['dependencies']


# Generated at 2022-06-23 06:56:53.805575
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass



# Generated at 2022-06-23 06:56:58.893534
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    variable_manager = object()
    loader = object()
    data = dict(
        allow_duplicates=True,
        dependencies=list()
    )

    result = RoleMetadata.load(data, None, variable_manager, loader)
    assert result.allow_duplicates is True
    assert result.dependencies == list()

# Generated at 2022-06-23 06:57:08.860783
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import os
    import tempfile

    # Create tempory directory
    tmpdir = tempfile.mkdtemp(prefix="ansible_test_")
    role_path = os.path.join(tmpdir, 'role_path')
    os.makedirs(role_path)

    # Create required files
    meta_path = os.path.join(role_path, "meta")
    os.makedirs(meta_path)
    with open(os.path.join(meta_path, "main.yml"), "w") as f:
        f.write("dependencies:\n - {role: other_role, other_var: other_val}")


    # Create Role
    from ansible.playbook.role import Role
    role = Role.load(role_path)

    # Create RoleMetadata

# Generated at 2022-06-23 06:57:10.597313
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-23 06:57:14.090006
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    pr = Role()
    m = RoleMetadata(owner=pr)
    assert m._allow_duplicates == False
    assert m._dependencies == []

# Generated at 2022-06-23 06:57:23.375857
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.data import AnsibleLegacyVars
    from ansible.playbook.role import Role
    my_playbook = AnsibleMapping()
    my_playbook['roles'] = AnsibleMapping()
    my_playbook['roles']['example'] = AnsibleLegacyVars()
    my_playbook['roles']['example']['hosts'] = ['host1']
    my_playbook['roles']['example']['name'] = 'example'
    my_playbook['roles']['example']['user'] = 'root'

    my_role = Role.load(my_playbook['roles']['example'], None, None, None)


# Generated at 2022-06-23 06:57:31.688855
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata()
    role_meta._allow_duplicates=False
    role_meta._dependencies=[1,2,3]
    expected_result = dict(
        allow_duplicates=False,
        dependencies=[1,2,3]
    )
    assert role_meta.serialize() == expected_result

# Generated at 2022-06-23 06:57:35.657951
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert(m.dependencies == [])
    assert(m.allow_duplicates == False)
    assert(m.galaxy_info == None)
    assert(m.argument_specs == {})

# Generated at 2022-06-23 06:57:42.220477
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_include import RoleInclude
    rd = RoleDefinition()
    ri = RoleInclude(rd)
    r = RoleMetadata(owner=ri)
    assert r._allow_duplicates is False
    assert r._dependencies == []


# Generated at 2022-06-23 06:57:53.472304
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for RoleMetadata.load() method
    '''
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.meta import RoleMetadata
    import ansible.playbook.role.requirement

    # Define role and role dependencies
    role = 'testRole'
    role_dir = os.path.dirname(os.path.realpath(__file__))
    role_dir = os.path.join(role_dir, os.pardir, 'test_roles', role)
    role_dependencies = ['testRole1', 'testRole2', 'testRole3']

    # Create task
    task

# Generated at 2022-06-23 06:58:02.109390
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'connection': 'local',
        'tasks': [
            {
                'name': 'test',
                'debug': {
                    'msg': '{{foo}}'
                }
            }
        ]
    }, variable_manager=play_context.vars_manager, loader=None)

# Generated at 2022-06-23 06:58:08.891454
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    AnsibleModule Utility
    """
    import ansible.playbook.role.metadata
    def test_deserialize():
        data = {
            'allow_duplicates': False,
            'dependencies': []
        }
        a = ansible.playbook.role.metadata.RoleMetadata().deserialize(data)
        keys = sorted(a.keys())
        assert keys == [ 'allow_duplicates', 'dependencies' ]
    


# Generated at 2022-06-23 06:58:20.965249
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from collections import namedtuple
    import random
    import string
    import json

    RoleDependency = namedtuple('RoleDependency', 'name version')

    role_name = "".join([random.choice(string.ascii_letters) for i in range(0, 8)])
    role_definition = RoleDefinition(role_name=role_name)
    role_metadata = RoleMetadata(owner=role_definition)

    allow_duplicates = random.choice([True, False])
    role_metadata.allow_duplicates = allow_duplicates

    dependency_count = random.randint(1, 5)
    dependencies = []

# Generated at 2022-06-23 06:58:23.185580
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata('roles/test_role')
    assert a is not None

# Generated at 2022-06-23 06:58:28.422748
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Unit test for method serialize of class RoleMetadata.
    """
    #Create instance of class RoleMetadata
    role_metadata = RoleMetadata()

    #Set value for attribute 'allow_duplicates'.
    role_metadata._allow_duplicates = True
    #Set value for attribute 'dependencies'.
    role_metadata._dependencies = [({"role": "role1"}), ({"role": "role2"})]

    #Call method 'serialize' of class RoleMetadata.
    res = role_metadata.serialize()

    #Verify that the result equals to the expected result.
    assert res == {'allow_duplicates': True, 'dependencies': [({"role": "role1"}), ({"role": "role2"})]}

# Generated at 2022-06-23 06:58:33.638360
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.dependencies = [1, 2, 3]
    role_metadata.allow_duplicates = False
    data = role_metadata.serialize()
    assert data == {'allow_duplicates': False, 'dependencies': [1, 2, 3]}


# Generated at 2022-06-23 06:58:40.520155
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': ['a', 'b', 'c'],
    }
    m.deserialize(data)
    assert m.allow_duplicates
    assert m.dependencies == ['a', 'b', 'c']
# --

# Generated at 2022-06-23 06:58:49.594986
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.top import Top


# Generated at 2022-06-23 06:58:54.466212
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata= RoleMetadata()
    role_metadata.allow_duplicates=True
    #TODO: fix test!
    #assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': None}

# Generated at 2022-06-23 06:59:05.266333
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Load example role metadata
    role_test_meta_content = {
        "dependencies": [
            "geerlingguy.apache",
            "geerlingguy.php",
            {
                "role": "geerlingguy.mysql"
            },
            {
                "name": "some_collection.some_role",
                "collection": "some_collection"  # <-- in Ansible 2.10+ collections can be declared
            },
            {
                "src": "some_collection.some_role"  # <-- in Ansible 2.9+ collections can be declared
            },
            "geerlingguy.mysql@v1.0",
            "geerlingguy.mysql@v2.0"
        ]
    }
    test_class_RoleMetadata = RoleMetadata()
    test

# Generated at 2022-06-23 06:59:11.376179
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    obj.deserialize(dict(
        allow_duplicates=True,
        dependencies=[dict(role="test")]
    ))
    assert obj._allow_duplicates == True
    assert obj._dependencies == [dict(role="test")]


# Generated at 2022-06-23 06:59:20.912362
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-23 06:59:30.057288
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {}
    test_role = RoleMetadata(data)
    assert test_role._dependencies == [], "test_RoleMetadata: Failed to initialize _dependencies in constructor"
    assert test_role._allow_duplicates == False, "test_RoleMetadata: Failed to initialize _allow_duplicates in constructor"
    assert test_role._galaxy_info == None, "test_RoleMetadata: Failed to initialize _galaxy_info in constructor"
    assert test_role._argument_specs == {}, "test_RoleMetadata: Failed to initialize _argument_specs in constructor"


# Generated at 2022-06-23 06:59:41.986819
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.collectionsearch import GalaxyInfo
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display

    display = Display()
    collection_loader = AnsibleCollectionLoader(display)
    collection_loader.set_collection_paths(['/foo/bar'])

    role_definitions = [
        {'role': 'baz'},
        {'role': 'qux', 'vars': {'baz': 'xyzzy'}}
    ]

    meta = RoleMetadata(owner=None)

# Generated at 2022-06-23 06:59:45.450947
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r.deserialize({"allow_duplicates":True,"dependencies":[]})
    expected = {"allow_duplicates":True,"dependencies":[]}
    assert r.serialize() == expected


# Generated at 2022-06-23 06:59:48.002901
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_data = dict(
        allow_duplicates=False,
        dependencies=[
            dict(role='geerlingguy.nginx', some_var='some_value', other_var='other_value'),
            dict(role='geerlingguy.postgresql', other_var='other_value'),
        ]
    )
    print(RoleMetadata.load(role_data))

# Generated at 2022-06-23 07:00:00.406029
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    data_loader = DataLoader()
    variable_manager = None
    loader = data_loader
    play = Play().load(dict(name='play1'),variable_manager=variable_manager, loader=loader)
    play_context = PlayContext()

    # Test simple case: test loading of dependencies list to be a list of
    # RoleRequirement objects
    data = dict(
        dependencies=dict(role1=dict()),
        galaxy_info=dict(
            author='author',
            description='description',
            company='company',
            license='license'
        )
    )
   

# Generated at 2022-06-23 07:00:07.719477
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = {'dependencies': []}
    from ansible.playbook.role import Role
    r = Role()
    x = RoleMetadata.load(metadata, r)
    assert x._allow_duplicates == False
    assert x._dependencies == []
    assert x._galaxy_info == None
    assert x._argument_specs == {}
    assert repr(x).startswith('<ansible.playbook.role.metadata.RoleMetadata object at')

# Generated at 2022-06-23 07:00:13.002891
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []
    r = RoleMetadata()
    result = r.deserialize(data)
    expected = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    assert result == expected
    assert r.serialize() == expected

# Generated at 2022-06-23 07:00:23.461728
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()

    task = TaskInclude()
    task._role_name = 'test_role_metadata'
    task._role_path = os.path.join(os.path.dirname(__file__), 'data', 'test_role_metadata')
    task._task = 'main.yml'
    task._role_params = {}
    task._shared_loader_obj = loader
    task._variable_manager = variable_manager
    task._loader = loader
    task._

# Generated at 2022-06-23 07:00:34.131177
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from collections import namedtuple
    from ansible.playbook.role.include import RoleInclude
    
    fake_collection_search = namedtuple('fake_collection_search', ['find_file'])
    fake_collection_search.find_file = lambda x, y: "fake"
    role_include = RoleInclude()
    role_include.name = "test_role"
    role_include._collection_search = fake_collection_search
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = [role_include]
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.serialize() == data

# Generated at 2022-06-23 07:00:37.712029
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2', 'role3']
    )
    obj = RoleMetadata()
    obj.deserialize(data)
    assert obj.allow_duplicates is True
    assert len(obj.dependencies) == 3

# Generated at 2022-06-23 07:00:40.548539
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role

    role = Role()
    role_metadata = RoleMetadata(owner=role)

# Generated at 2022-06-23 07:00:48.574275
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    role = RoleRequirement()
    role.role = 'test'
    role.collections = ['test']
    role._role = 'test'
    role._role_path = '/tmp/test'
    role._role_collection = role
    role._variable_manager = 'test'
    role._loader = 'test'

    metadata = RoleMetadata()
    metadata._owner = role
    assert metadata.serialize() == dict(
            allow_duplicates=False,
            dependencies=[]
        )


# Generated at 2022-06-23 07:01:00.917238
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role_metadata = RoleMetadata()

    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._owner == None
    assert role_metadata._argument_specs == {}
    assert role_metadata._valid_attrs == {'allow_duplicates', 'dependencies', 'galaxy_info', 'owner', 'argument_specs'}
    assert role_metadata._data == {}

    role_metadata = RoleMetadata(owner=RoleDefinition())

    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._owner != None


# Generated at 2022-06-23 07:01:10.112164
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import role, task
    from ansible.module_utils.six import StringIO
    from ansible.errors import AnsibleParserError

    r = role.Role()
    r._role_path = "test_role_path"

    m = RoleMetadata.load({'dependencies': [{"role": "concentratord", "version": "1.0"}, "patientzero"]},
                          owner=r)
    assert(len(m._dependencies) == 2)
    assert(isinstance(m._dependencies[0], role.RoleRequirement))
    assert(isinstance(m._dependencies[1], role.RoleRequirement))

    # galaxy info mapping should be copied to main metadata
    g = role.GalaxyInfo()
    g._loose_variables = {'foo': 'bar'}


# Generated at 2022-06-23 07:01:13.306914
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata()
    data = dict(allow_duplicates=True)
    m.load_data(data)
    assert m._allow_duplicates == data['allow_duplicates']

# Generated at 2022-06-23 07:01:22.800921
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # without a dict
    try:
        RoleMetadata.load([], None)
    except AnsibleParserError:
        pass
    else:
        assert False

    # Now with a proper dict
    owner = mock.Mock()
    ds = dict(
        allow_duplicates=False,
        dependencies=['common']
    )
    r = RoleMetadata.load(ds, owner)
    assert r._allow_duplicates == False
    assert r._dependencies == ['common']
    assert r._owner == owner

# Generated at 2022-06-23 07:01:26.347181
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    obj = RoleMetadata()
    assert isinstance(obj._allow_duplicates, bool)
    assert isinstance(obj._dependencies, list)
    assert isinstance(obj._galaxy_info, dict)
    assert isinstance(obj._argument_specs, dict)
    assert obj._owner is None

# Generated at 2022-06-23 07:01:29.621280
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    owner = Base()
    r = RoleMetadata()
    r.deserialize(dict(allow_duplicates=True, dependencies=['test.role']))
    assert r._allow_duplicates == True
    assert r._dependencies == ['test.role']


# Generated at 2022-06-23 07:01:34.231225
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = dict(allow_duplicates=True, dependencies=[])
    role_metadata = RoleMetadata()
    role_metadata.deserialize(meta)
    assert role_metadata.allow_duplicates is True and role_metadata.dependencies == []

# Generated at 2022-06-23 07:01:44.379222
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """ RoleMetadata: serialize function test """
    from ansible.playbook.role import Role
    from ansible.module_utils.six import PY3

    rol = Role()
    rol.name = "test"
    rol.collections = ["collection.test"]
    rol.allow_duplicates = False

    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = list()
    role_metadata._owner = rol

    if not PY3:
        role_metadata._owner.name = u'foo'

    serialized = role_metadata.serialize()
    assert serialized['allow_duplicates'] == False
    assert serialized['dependencies'] == []

# Generated at 2022-06-23 07:01:48.612769
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    role.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert role.allow_duplicates == True
    assert role.dependencies == []

# Generated at 2022-06-23 07:01:52.287529
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    m.deserialize(data)
    assert m.serialize() == data

    data = {'allow_duplicates': True, 'dependencies': ['example.org']}
    m.deserialize(data)
    assert m.serialize() == data

# Generated at 2022-06-23 07:02:01.138357
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plays import RoleTask
    play = Play.load(dict(
        name="test play",
        hosts=['testhost'],
        roles=[dict(
            name='testrole',
            tasks=[dict(action=dict(module="shell", args="echo hi"))],
            meta=dict(dependencies=[dict(role="testrole2")])
        ), dict(
            name='testrole2',
            tasks=[dict(action=dict(module="shell", args="echo hi"))],
            meta=dict(dependencies=[dict(role="testrole")])
        )],
    ), loader=None, variable_manager=None)


# Generated at 2022-06-23 07:02:10.826263
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Case: meta/main.yml is not a dictionary
    # Expected result: raise AnsibleParserError
    data = []
    try:
        RoleMetadata.load(data, None)
        raise AssertionError("AnsibleParserError is not raised")
    except AnsibleParserError:
        pass

    # Case: meta/main.yml is a dictionary
    # Expected result: new RoleMetadata object
    data = {"allow_duplicates": True,
            "dependencies": ["role1", "test.test_username.test_role_name"]}
    m = RoleMetadata.load(data, None)
    assert m

    # Case: meta/main.yml is a dictionary with dependencies is not a list
    # Expected result: raise AnsibleParserError

# Generated at 2022-06-23 07:02:15.943780
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata = RoleMetadata()
    roleMetadata.allow_duplicates = True
    roleMetadata.dependencies = "role_name"
    r = roleMetadata.serialize()
    assert isinstance(r, dict)
    assert r["allow_duplicates"] == True
    assert r["dependencies"] == "role_name"
# Unit test end


# Generated at 2022-06-23 07:02:28.678226
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role_include as role_include
    import ansible.playbook.play_context as play_context

    # Build a context with a loader
    loader = 'ansible.parsing.dataloader.DataLoader'
    context = play_context.PlayContext()
    context.loader = loader
    context.SET_FACT_VARS={}

    # Build a role_metadata, as if it was loaded from a meta/main.yml of a role
    data = {}

# Generated at 2022-06-23 07:02:33.184230
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():  # pylint: disable=missing-function-docstring
    from ansible.playbook.role import RoleInclude

    # Test GalaxyInfo
    m = RoleMetadata(owner=None)
    try:
        data = m.load(dict(), owner=None)
    except Exception as e:  # pylint: disable=broad-except
        msg = "Exception is raised while trying to load an empty dictionary data."
        assert False, msg

    data = m.load(dict(dependencies=[{'role': 'some-role', 'name': 'some-other-role'}]), owner=None)
    assert type(data.dependencies[0]) == RoleInclude


# Generated at 2022-06-23 07:02:47.025060
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import copy
    import collections

    # A simple execution of load with a source
    sample_dict = {
        'dependencies': [
            {'role': 'another_role'},
            {'role': 'yet_another_role'},
            {'role': 'some_new_role', 'some_var': 'some_value'}],
        'allow_duplicates': True}
    class Play:
        pass
    class Role:
        def __init__(self, galaxy_info=None):
            self.galaxy_info = galaxy_info
            self._role_collection = None
            self._role_path = None


# Generated at 2022-06-23 07:02:53.521461
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    '''
    Unit test for method serialize of class RoleMetadata.
    '''

    role_metadata = RoleMetadata()

    role_metadata._allow_duplicates = "True"
    role_metadata._dependencies = ["foo.tar.gz"]

    output = role_metadata.serialize()

    assert output['allow_duplicates'] == "True"
    assert output['dependencies'] == ["foo.tar.gz"]


if __name__ == "__main__":
    test_RoleMetadata_serialize()

# Generated at 2022-06-23 07:03:02.661367
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({})
    assert m.allow_duplicates == False
    assert m.dependencies == []
    m.deserialize({'allow_duplicates': True, 'dependencies': ['A', 'B']})
    assert m.allow_duplicates == True
    assert m.dependencies == ['A', 'B']

# Generated at 2022-06-23 07:03:12.446690
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rm = RoleMetadata()
    rm.deserialize({'allow_duplicates': True, 'dependencies': ['apache', 'tomcat-7']})
    assert hasattr(rm, 'allow_duplicates')
    assert hasattr(rm, 'dependencies')
    assert rm.allow_duplicates == True
    assert rm.dependencies == ['apache', 'tomcat-7']


# Generated at 2022-06-23 07:03:16.916624
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {"foo": "bar", "spam": "eggs"}
    m = RoleMetadata().load_data(data)
    assert m.serialize() == data


# Generated at 2022-06-23 07:03:19.983449
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Test for the serialize method
    '''
    # imports for test
    from ansible.playbook.role.meta import RoleMetadata
    # creation test object
    dep_data = dict()
    dep_data['dependencies'] = [{'role': 'myrole'}]

    obj = RoleMetadata(dep_data)

    assert obj.serialize() == {'allow_duplicates': False, 'dependencies': [{'role': 'myrole'}]}



# Generated at 2022-06-23 07:03:23.049788
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role.allow_duplicates is False
    assert role.dependencies == []


# Generated at 2022-06-23 07:03:25.555849
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Load role
    role = RoleMetadata()
    role._load({}, owner=None)

# Generated at 2022-06-23 07:03:33.539887
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata_yaml_string = """\
dependencies:
  - name: test
    src: https://github.com/user/repo
"""
    metadata = RoleMetadata.load(data=metadata_yaml_string, owner=None)
    assert isinstance(metadata.dependencies, list)
    assert len(metadata.dependencies) == 1
    assert metadata.dependencies[0].name == 'test'
    assert metadata.dependencies[0].src == 'https://github.com/user/repo'

# Generated at 2022-06-23 07:03:41.641499
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    Role = type('Role', (object,), {'get_name':lambda: 'role_name', 'get_path':lambda: '/path/to/role', 'get_dep_chain':lambda: []})
    role = Role()
    from ansible.playbook.role.definition import RoleDefinition
    role._role_path = '/path/to/role'
    role._role_name = 'role_name'
    r = RoleMetadata(owner=role)
    assert(r.name == 'role_name')
    assert(r.path == '/path/to/role')

# Generated at 2022-06-23 07:03:42.764067
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:03:48.897952
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    try:
        role_metadata = RoleMetadata(owner=None)
        loaded_role_metadata = role_metadata.deserialize(dict(allow_duplicates=False, dependencies=[]))
        assert loaded_role_metadata
        assert loaded_role_metadata.allow_duplicates == False 
        assert loaded_role_metadata.dependencies == []
    except Exception as e:
        raise Exception("test_RoleMetadata_deserialize: %s" % (e))


# Generated at 2022-06-23 07:03:57.368753
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test constructor, with invalid argument (not None)
    try:
        _ = RoleMetadata(owner="")
    except:
        pass

    # Test constructor, with valid argument (None)
    try:
        _ = RoleMetadata()
    except:
        raise Exception("RoleMetadata() raised ExceptionType unexpectedly!")

if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-23 07:04:01.022470
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    role.dependencies = ['depend1', 'depend2']
    assert role.serialize() == dict(allow_duplicates=True, dependencies=['depend1', 'depend2'])

# Generated at 2022-06-23 07:04:09.625937
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    This test checks if it is possible to recreate an RoleMetadata instance
    from the serialized data.
    """
    role_metadata_instance = RoleMetadata()
    role_metadata_instance.deserialize({'allow_duplicates': True, 'dependencies': [{'src': 'test'}]})
    serialized_role_metadata = role_metadata_instance.serialize()
    assert serialized_role_metadata['allow_duplicates'] == True
    assert serialized_role_metadata['dependencies'] == [{'src': 'test'}]

# Generated at 2022-06-23 07:04:21.789590
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test creating a RoleMetadata object and attempting to call deserialize with a valid set of data
    # Confirm that the object attributes are set appropriately
    r = RoleMetadata()
    setattr(r, 'allow_duplicates', False)
    setattr(r, 'dependencies', [{'name': 'apache', 'role': '/home/username/ansible/roles/roleA'}])
    data = {'allow_duplicates': True, 'dependencies': [{'name': 'apache', 'role': '/home/username/ansible/roles/roleB'}]}
    try:
        r.deserialize(data)
    except AnsibleParserError:
            raise
    assert r._allow_duplicates == True

# Generated at 2022-06-23 07:04:23.019354
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-23 07:04:28.062075
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_name = 'test_role'
    role_metadata = RoleMetadata()
    role_metadata_serialize = role_metadata.serialize()
    #assert_equals(type(role_metadata_serialize), dict)

# Generated at 2022-06-23 07:04:32.675402
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # test invalid dict info
    try:
        RoleMetadata.load("invalid string", owner='')
    except AnsibleParserError as ae:
        pass
    # test valid dict info
    try:
        RoleMetadata.load({}, owner='')
    except AnsibleParserError as ae:
        pass

# Generated at 2022-06-23 07:04:38.152947
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class Data(object):
        def __init__(self):
            self.data = {'allow_duplicates': False, 'dependencies': [{'src': '/etc/ansible/roles/test'}]}
        def get(self, name, default = None):
            return self.data[name]

    role = Role()
    rm = RoleMetadata()
    rm.deserialize(Data())
    assert rm.serialize() == {'allow_duplicates': False, 'dependencies': [{'src': '/etc/ansible/roles/test'}]}

# Generated at 2022-06-23 07:04:44.862306
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    meta.deserialize({'allow_duplicates': True, 'dependencies':[{'role': 'Ansible-examples.test'}]})
    assert meta.allow_duplicates == True
    assert meta.dependencies == [{'role': 'Ansible-examples.test'}]
    assert meta.dependencies[0]['role'] == 'Ansible-examples.test'

# Generated at 2022-06-23 07:04:57.274812
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role

    # Setup
    role_name = 'ansible-role-test'
    role_path = '../lib/ansible/modules/remote_management/network/asa'
    role = Role().load({'role': role_name, 'role_path': role_path})


# Generated at 2022-06-23 07:05:01.151428
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata(owner='test')._owner == 'test'
    assert RoleMetadata(owner=None)._owner is None


# Generated at 2022-06-23 07:05:11.361819
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    my_play = Play().load({
        'name': 'test_play',
        'hosts': 'test_hosts'
    },
        variable_manager='test_variable_manager',
        loader='test_loader')

    my_task = Task().load({
        'name': 'test_task',
        'action': 'test_action'
    },
        play=my_play)


# Generated at 2022-06-23 07:05:16.641710
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role_dependency import RoleDependency

    role_include_a = RoleInclude()
    role_include_a._name = "foo"
    role_include_a._role_path = "../foo"
    role_include_b = RoleInclude()
    role_include_b._name = "bar"
    role_include_b._role_path = "../bar"

    play_a = Play()
    play_a._ds = {
        "name": "test play",
        "hosts": ["localhost"],
        "roles": ["foo", "bar"]
    }
    role_include_

# Generated at 2022-06-23 07:05:26.728817
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import load_extra_vars
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    extra_vars = load_extra_vars(loader=loader, options=None)
    variable_manager.extra_vars = extra_vars

    # Create a RoleDefinition object
    play_context = PlayContext()