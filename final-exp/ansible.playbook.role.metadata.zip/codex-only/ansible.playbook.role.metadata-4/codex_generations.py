

# Generated at 2022-06-23 06:55:30.744918
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-23 06:55:34.704202
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata(owner="owner")
    meta.deserialize(
        dict(allow_duplicates=True)
    )
    assert meta.allow_duplicates is True  # pylint: disable=no-member


# Generated at 2022-06-23 06:55:40.713234
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            {'some': 'dependency'}
        ]
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == [{'some': 'dependency'}]


# Generated at 2022-06-23 06:55:50.024760
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.collectionsearch import CollectionSearch
    data = {'dependencies': [{'role': 'foo', 'name': 'foo'}]}
    role = RoleMetadata(owner=collection_loader._loader)
    role.load_data(data, variable_manager=play._variable_manager, loader=play._loader)
    collection_search_list = ['ansible.legacy', 'ansible_namespace.collection1']
    collection_search_paths = list(CollectionSearch._get_collection_paths(collection_search_list))

# Generated at 2022-06-23 06:55:55.105289
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Test case to test the function deserialize in Role_Metadata class
    :return:
    '''
    a = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['admin']}
    b = a.deserialize(data)

# Generated at 2022-06-23 06:56:01.428612
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.executor.task_queue_manager import TaskQueueManager

    hosts = ["foo"]
    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_path = os.path.join(current_dir, '../../playbooks/test_data')
    print("Current directory: " + current_dir)
    print("Test data path: " + test_data_path)
    #print("Current directory: " + os

# Generated at 2022-06-23 06:56:13.152828
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

    assert RoleMetadata.deserialize({'allow_duplicates': False, 'dependencies': []}) == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 06:56:17.875014
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta._allow_duplicates = True
    meta._dependencies = ['one', 'two']
    assert meta.serialize() == {'allow_duplicates': True, 'dependencies': ['one', 'two']}

# Generated at 2022-06-23 06:56:21.091335
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Unit test for method serialize of class RoleMetadata
    """
    # TODO
    pass


# Generated at 2022-06-23 06:56:24.704290
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    md = RoleMetadata()
    md.allow_duplicates = True
    md.dependencies = ['test_role', 'test_role2']
    assert md.deserialize(md.serialize()) == md.serialize()

# Generated at 2022-06-23 06:56:33.231098
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import os

    current_dir = os.path.dirname(os.path.realpath(__file__))
    templar = Templar(loader=None, variables=VariableManager())
    parent_play = Play.load({'name': 'test_play', 'hosts': ['all']}, variable_manager=VariableManager(), loader=None)

# Generated at 2022-06-23 06:56:33.654944
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-23 06:56:43.196412
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a Play, Task and a Role Metadata.
    # We need to do this so that we can create a valid Role Metadata object.
    play_context = PlayContext()

# Generated at 2022-06-23 06:56:48.441786
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata(owner=None)

    role_metadata.deserialize(dict(
        allow_duplicates=True,
        dependencies=list()
    ))

    assert role_metadata.allow_duplicates == True
    assert isinstance(role_metadata.dependencies, list)
    assert not role_metadata.dependencies

# Generated at 2022-06-23 06:56:49.673740
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    assert metadata.deserialize(data)
    assert metadata.serialize() == data


# Generated at 2022-06-23 06:56:54.733852
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies=[])
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates is True
    assert role_metadata._dependencies == []

# Generated at 2022-06-23 06:57:06.105395
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # this method works only if the following scenario is true:
    # 1) the user's home directory is /home/<something>
    # 2) the user has a directory called 'ansible/test/roles'
    # 3) the user has a directory called 'ansible/test/playbooks'
    # 4) the directory 'ansible/test/roles' contains a role called 'testrole'
    # 5) the directory 'ansible/test/playbook' contains a file called 'testplay.yml'

    # set up the function's variables
    home_dir = os.path.expanduser('~')
    role_dir = os.path.join(home_dir, 'ansible/test/roles')
    playbook_dir = os.path.join(home_dir, 'ansible/test/playbooks')
    role

# Generated at 2022-06-23 06:57:19.498722
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition

    def_loader = RoleDefinition.load({
        'name': 'foo',
        'description': 'bar',
        'min_ansible_version': '1.0',
        'metadata_version': '1.0',
        'implementation_choices': ['pypy'],
        'license': 'MIT',
        'author': 'Michael DeHaan'
    })

    meta_loader = RoleMetadata.load(dict(
        allow_duplicates=False,
        dependencies=['role1', 'role2']
    ),
        owner=def_loader,
    )

    assert meta_loader._dependencies[0].get_name() == 'role1'


# Generated at 2022-06-23 06:57:33.923712
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_allow_duplicates = True
    test_dependencies = [
        {'role': 'test-role1', 'name': 'foobar'},
        {'role': 'test-role2'},
        'test-role3'
    ]
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = test_allow_duplicates
    role_metadata.dependencies = test_dependencies
    role_metadata = role_metadata.serialize()
    assert role_metadata['allow_duplicates'] == test_allow_duplicates
    assert isinstance(role_metadata['dependencies'], list)
    for dependency in role_metadata['dependencies']:
        assert isinstance(dependency, dict)
        if 'name' in dependency:
            assert dependency['name'] == 'foobar'

# Generated at 2022-06-23 06:57:44.911980
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-23 06:57:55.173894
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Creating a RoleMetadata object for testing
    owner = type('Owner', (), {'get_name': (lambda: 'role-name')})()
    role_metadata_object = RoleMetadata(owner)
    role_metadata_object._allow_duplicates = False
    role_metadata_object._dependencies = []

    # RoleMetadata object serialization
    serialized_role_metadata = role_metadata_object.serialize()

    # Expected result for RoleMetadata serialization
    expected_serialized_role_metadata = {
        'allow_duplicates': False,
        'dependencies': []
    }

    assert serialized_role_metadata == expected_serialized_role_metadata

# Generated at 2022-06-23 06:58:01.995960
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[
            dict(
                role=dict(
                    name='my-role-name',
                ),
                name='toto',
                tasks_from=None,
                tags=['titi', 'tata'],
            ),
            dict(
                role=dict(
                    name='my-role-name2',
                ),
                name='toto',
                tasks_from=None,
                tags=['titi', 'tata'],
            ),
        ]
    )
    assert RoleMetadata(owner=object()).deserialize(data).serialize() == data

# Generated at 2022-06-23 06:58:06.792150
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    import os
    import sys
    import json

    module_path = os.path.join(os.path.dirname(__file__), '..')
    sys.path.insert(0, module_path)

    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-23 06:58:13.190601
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play

    # Load a very simple one
    data = {
        'dependencies': ['foo', 'bar'],
    }
    with open('/tmp/playbook.yml', 'w') as f:
        f.write('''
        - hosts:
            roles: [foo, bar, baz]
            ''')

    class Role(object):
        def __init__(self):
            self._role_name = 'foo'
            self._role_path = '/tmp'
            self._role_collection = None
            self.collections = ['ansible.posix']

# Generated at 2022-06-23 06:58:18.518034
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m is not None
    assert m._allow_duplicates is False
    assert m._dependencies == []
    assert m._galaxy_info is None
    assert m._argument_specs == {}
    assert m._owner is None

# Generated at 2022-06-23 06:58:26.744753
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.six import PY3
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from collections import namedtuple

# Generated at 2022-06-23 06:58:28.250471
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    target_obj = RoleMetadata()
    target_dict = target_obj.serialize()
    assert dict == type(target_dict)
    assert False == target_dict['allow_duplicates']
    assert [] == target_dict['dependencies']


# Generated at 2022-06-23 06:58:33.374827
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner=None)
    assert m._allow_duplicates == False
    assert m._dependencies == list()
    assert isinstance(m._galaxy_info, dict)
    assert m._argument_specs == dict()

# Generated at 2022-06-23 06:58:43.807194
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    metadata = '{"dependencies": []}'

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='127.0.0.1,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    data = loader.load_from_file(metadata)
    role = RoleMetadata.load(data, owner=None, variable_manager=variable_manager, loader=loader)
    assert role.allow_duplicates is False
    assert role.dependencies == []

# Generated at 2022-06-23 06:58:46.716776
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create an object with all values set to None
    metadata = RoleMetadata()

    # Set some values
    metadata._allow_duplicates = True

    metadata_json = metadata.serialize()
    assert metadata_json["allow_duplicates"] == True



# Generated at 2022-06-23 06:58:50.579731
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_name = 'role_name'
    role_metadata = RoleMetadata(owner = role_name)

    assert (role_metadata._allow_duplicates == False)
    assert (role_metadata._dependencies == [])
    assert (role_metadata._owner == role_name)

# Generated at 2022-06-23 06:58:57.775352
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #
    # Create test RoleMetadata object with some string attribute
    # for testing load_data.
    #
    obj = RoleMetadata()
    obj.name = "TestRoleMetadata"

    #
    # Create test data structure
    #
    test_data = dict(
        name="TestRoleMetadata"
    )

    #
    # Load fake data into object
    #
    obj.load_data(test_data, variable_manager=None, loader=None)

    #
    # Get the initialized attribute
    #
    assert obj.name == "TestRoleMetadata"

# Generated at 2022-06-23 06:59:02.917399
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    obj = RoleMetadata()
    assert hasattr(obj, '_allow_duplicates')
    assert hasattr(obj, '_dependencies')
    assert hasattr(obj, '_galaxy_info')
    assert hasattr(obj, '_allow_duplicates')
    assert obj._allow_duplicates == False
    assert obj._dependencies == []
    assert obj._galaxy_info is None
    assert obj._argument_specs == {}


# Generated at 2022-06-23 06:59:11.849620
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    file_name = '/etc/ansible/roles/foo/meta/main.yml'

    data = {'allow_duplicates': True, 'dependencies': ['remote_role']}

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'play_hosts': 'all'}


# Generated at 2022-06-23 06:59:17.861365
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    # Test data for test_RoleMetadata
    data = {
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'common', 'role2': 'web'}
        ]
    }

    # Testing RoleMetadata constructor
    result = RoleMetadata.load(data, {})

    # Verify result
    assert result._allow_duplicates == True
    assert result._dependencies == [{'role': 'common', 'role2': 'web'}]

# Generated at 2022-06-23 06:59:22.937701
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(dependencies=[dict(role="role1")], allow_duplicates=False)
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._dependencies[0].role == "role1"
    assert role_metadata._allow_duplicates == False

# Generated at 2022-06-23 06:59:32.614219
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Test with valid data
    data_valid = {
        'allow_duplicates': False,
        'dependencies': []
    }
    role_metadata_valid = RoleMetadata()
    role_metadata_valid.deserialize(data_valid)
    assert role_metadata_valid._allow_duplicates == data_valid['allow_duplicates']
    assert role_metadata_valid._dependencies == data_valid['dependencies']

    # Test with invalid data
    data_invalid = {
        'allow_duplicates': False,
        'dependencies': True
    }
    role_metadata_invalid = RoleMetadata()
    try:
        role_metadata_invalid.deserialize(data_invalid)
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-23 06:59:38.897682
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Arrange
    data = {
        'allow_duplicates': True,
        'dependencies': [{}, {}]}
    
    # Act
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    result = role_metadata.serialize()

    # assert
    assert result['allow_duplicates']
    assert len(result['dependencies']) == 2

# Generated at 2022-06-23 06:59:44.761665
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    result = RoleMetadata.load(dict(), object())
    assert result is not None
    assert result.allow_duplicates == False
    assert result.dependencies == []

    result = RoleMetadata.load(dict(allow_duplicates=True), object())
    assert result is not None
    assert result.allow_duplicates == True
    assert result.dependencies == []

    result = RoleMetadata.load(dict(dependencies=['test']), object())
    assert result is not None
    assert result.allow_duplicates == False
    assert result.dependencies == ['test']

    result = RoleMetadata.load(dict(allow_duplicates=True, dependencies=['test']), object())
    assert result is not None
    assert result.allow_duplicates == True

# Generated at 2022-06-23 06:59:53.416946
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.common.collections import ImmutableDict

    rd = RoleDefinition()
    rd._role_path = 'my_role_path'

    rdm = RoleMetadata()
    rdm.load({'dependencies': [{'role': 'my_role'}]}, rd)

    assert rdm.dependencies[0].role_name == 'my_role'
    assert rdm.dependencies[0].role_path is None
    assert rdm.dependencies[0].collections is None

    rd = RoleDefinition()
    rd._role_path = 'my_role_path'

    rdm = RoleMetadata()

# Generated at 2022-06-23 07:00:03.245461
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import pytest
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.utils.unittest import TestAnsibleModule as T
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-23 07:00:15.146816
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    block1 = Block()
    block2 = Block()
    task1 = Task()
    task2 = Task()
    play1 = Play()

    block1._parent = play1
    block2._parent = play1
    task1._parent = block1
    task2._parent = block2

    block1._load_role_tasks(role_definition=RoleDefinition(), role_tasks_meta={})

    assert block1.tasks == []
    assert block1.role
    assert block1.role.get_name() == 'test'

    # block._load_role_tasks must return the role

# Generated at 2022-06-23 07:00:20.694326
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    Unit test for method deserialize of class RoleMetadata
    """
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-23 07:00:22.568937
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata()
    assert a._allow_duplicates== False
    assert a._dependencies== []


# Generated at 2022-06-23 07:00:30.355399
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    This is used to verify if RoleMetadata load is working
    """
    import json
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['tests/test_data/hosts'])
    variable_manager.set_inventory(inventory)

    host = inventory.get_host("test_host")

    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-23 07:00:33.517132
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ["test1", "test2"]
    expected = {"allow_duplicates": True,
                "dependencies": ["test1", "test2"]}
    assert expected == role_metadata.serialize()

# Generated at 2022-06-23 07:00:45.581223
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook import Play

    role_path = os.path.join(os.path.dirname(__file__), 'test_role')
    role = RoleDefinition('role', role_path)

    play = Play().load({
        'name': 'fakeplay',
        'hosts': 'localhost',
        'roles': ['role']
    }, loader=None, variable_manager=None)

    assert isinstance(play, Play)
    assert isinstance(play.get_roles(), list)
    assert isinstance(play.get_roles()[0], RoleDefinition)
   

# Generated at 2022-06-23 07:00:50.167663
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # define a dict to use as the data source
    ds = dict(
        allow_duplicates=False,
        dependencies=[
            dict(role="some_role_name")
        ]
    )

    # initialize the role metadata based on the data
    r = RoleMetadata(owner=None).load_data(ds)

    # verify that the data was processed correctly
    assert r.allow_duplicates == False
    assert r.dependencies is not None
    assert len(r.dependencies) == 1

    #serialize the role metadata into a dict for further testing
    ds = r.serialize()

    # deserialize the metadata from a dict
    r = RoleMetadata(owner=None).deserialize(ds)

    # verify that the data was processed correctly
    assert r.allow_duplicates == False


# Generated at 2022-06-23 07:00:56.168499
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    assert r._allow_duplicates is False
    assert r._dependencies == []

    r.deserialize({
        "allow_duplicates": True,
        "dependencies": ["myrole", "myrole2"]
    })
    assert r._allow_duplicates
    assert r._dependencies == ["myrole", "myrole2"]

# Generated at 2022-06-23 07:00:58.717545
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # run test with something that is found in a role
    pass

# Generated at 2022-06-23 07:01:02.645823
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r1 = RoleMetadata(owner="my name")
    r1.load_data(data=dict(), variable_manager=None, loader=None)
    assert r1._owner == "my name"
    assert r1._allow_duplicates is False
    assert r1._dependencies == []
    assert r1._galaxy_info is None
    assert r1._argument_specs == dict()


# Generated at 2022-06-23 07:01:04.634932
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata(owner=None)
    m.deserialize({'dependencies': None})
    assert m._dependencies == []

# Generated at 2022-06-23 07:01:07.431447
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    data = dict(allow_duplicates=False, dependencies=[])
    meta.deserialize(data)
    assert data.get('allow_duplicates') == meta._allow_duplicates

# Generated at 2022-06-23 07:01:14.709262
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    ds = RoleMetadata.load({}, None, None)
    ds.deserialize({
        'allow_duplicates': True,
        'dependencies': [
            {
                'src': 'path/to/role',
            },
        ],
    })
    assert ds.serialize() == {
        'allow_duplicates': True,
        'dependencies': [
            {
                'src': 'path/to/role',
            },
        ],
    }

# Generated at 2022-06-23 07:01:15.396099
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-23 07:01:18.372556
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata=RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-23 07:01:27.025252
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test 1: no attributes
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict())
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    # Test 2: with attributes
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(
                                allow_duplicates=True,
                                dependencies=['role1', 'role2']
                                ))
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']


# Generated at 2022-06-23 07:01:30.932538
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm = RoleMetadata()
    rm.allow_duplicates = True
    rm.dependencies = ['foobar']
    serialized = rm.serialize()
    assert serialized['allow_duplicates']
    assert serialized['dependencies'] == ['foobar']

# Generated at 2022-06-23 07:01:32.162937
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata() is not None


# Generated at 2022-06-23 07:01:35.051995
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test call of deserialize method with wrong type of argument
    role_metadata = RoleMetadata()
    data = ['a', 'b']
    with pytest.raises(AnsibleParserError) as excinfo:
        role_metadata.deserialize(data)
    assert 'Value should be a dictionary' in str(excinfo.value)


# Generated at 2022-06-23 07:01:40.103394
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize(None)
    assert m.allow_duplicates == False
    assert m.dependencies == []
    m.deserialize({'allow_duplicates': True, 'dependencies': ['foo']})
    assert m.allow_duplicates == True
    assert m.dependencies == ['foo']

# Generated at 2022-06-23 07:01:49.565446
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.utils.path import unfrackpath
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    base_vars = {
        'inventory_hostname': "localhost",
        'inventory_hostname_short': "localhost",
    }


# Generated at 2022-06-23 07:01:51.944189
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata._allow_duplicates)
    print(role_metadata._dependencies)

# Generated at 2022-06-23 07:02:00.959443
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.play.role import ROLE_CACHE
    from ansible.play.role_include import IncludeRole
    from ansible.play.role_path import RolePath
    from ansible.play.role_source import RoleSource
    ROLE_CACHE.pop('/foo/bar/roles/baz', None)
    r = RoleMetadata()
    assert r.load(data={'dependencies': []}, owner=RolePath(name='baz', path='/foo/bar/roles/baz'))
    assert len(r._dependencies) == 0
    assert r.load(data={'dependencies': [{'role': 'bar'}]}, owner=RolePath(name='baz', path='/foo/bar/roles/baz'))

# Generated at 2022-06-23 07:02:04.563953
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    collection_search_list = ['ansible.legacy', 'my.test.ns']
    rm = RoleMetadata()
    assert rm._collection_search_list == collection_search_list
    assert rm._owner is None

# Generated at 2022-06-23 07:02:05.907314
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    r = RoleMetadata()
    assert r.load(data={},owner={}) == None

# Generated at 2022-06-23 07:02:09.273945
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass
    # TODO: implement unit test for method load of class RoleMetadata


# Generated at 2022-06-23 07:02:13.338828
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata.__dict__)
    assert set(role_metadata.__dict__) == set(['_data_source', '_dependencies', '_allow_duplicates', '_argument_specs', '_galaxy_info'])


# Generated at 2022-06-23 07:02:15.438750
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role123 = RoleMetadata('role123')
    assert role123.allow_duplicates == False

# Generated at 2022-06-23 07:02:28.158382
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import collections_loader
    from ansible.plugins.loader import module_utils_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import cliconf

# Generated at 2022-06-23 07:02:38.982546
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.taggable import Taggable
    class TestPlay(Play):
        name = FieldAttribute(isa='string')
        hosts = FieldAttribute(isa='list')
        roles = FieldAttribute(isa='list', default=[])
        def __init__(self, *args, **kwargs):
            super(TestPlay, self).__init__(*args, **kwargs)
    class TestRole(Role):
        name = FieldAttribute(isa='string')
        def __init__(self, *args, **kwargs):
            super(TestRole, self).__init__(*args, **kwargs)

# Generated at 2022-06-23 07:02:48.752346
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    play_ds = dict(
        name="Test play for RoleMetadata",
        hosts='all'
    )
    play = Play().load(play_ds, variable_manager={}, loader=None)

    # Create a Task to pass to the RoleMetadata object
    task_ds = dict(
        name='test task',
        action=dict(module='shell', args='ls')
    )
    task = Task().load(task_ds, play=play, variable_manager={})

    # Create a Block to pass to the RoleMetadata object

# Generated at 2022-06-23 07:02:57.618204
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # These tests require an actual object to be of any use, so create a stub
    class stub(object):
        def __init__(self):
            self.allow_duplicates = None
            self.dependencies = None
    y = stub()

    # a dict with allow_duplicates=True and dependencies=[]
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    RoleMetadata.deserialize(y, data)
    assert y.allow_duplicates == True
    assert y.dependencies == []

    # a dict with allow_duplicates=False and dependencies=['common']
    data = dict(
        allow_duplicates=False,
        dependencies=['common']
    )
    RoleMetadata.deserialize(y, data)

# Generated at 2022-06-23 07:03:10.181457
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Case: minimal data
    data = dict(
        allow_duplicates = False,
        dependencies = dict(
            # not a valid syntax
            dep_valid_key = dict(
                name = "dep_valid_name",
            ),
        ),
    )
    role_metadata = RoleMetadata(owner=dict())
    role_metadata.deserialize(data)
    assert role_metadata.serialize() == dict(
        allow_duplicates = data.get('allow_duplicates'),
        dependencies = data.get('dependencies'),
        )

    # Case: complex data

# Generated at 2022-06-23 07:03:15.219718
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(src="geerlingguy.apache"),
            dict(src="geerlingguy.mysql", version="1.0.0", name="test_role"),
        ]
    )
    rd = RoleDefinition.load(dict(name="test_role"), "/foo/bar/roles", variable_manager=None, loader=None)
    rd._role_path = "/foo/bar/roles/test_role"
    m = RoleMetadata.load(data, rd, variable_manager=None, loader=None)

    # AllowDuplicates
    assert m.allow_duplicates == True

    # Dependencies
    assert len(m.dependencies) == 2

# Generated at 2022-06-23 07:03:16.813194
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    example = RoleMetadata()

# Generated at 2022-06-23 07:03:19.273805
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=list()
    )
    assert data == RoleMetadata().serialize()

# Generated at 2022-06-23 07:03:29.187241
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test normal state
    data = dict()
    owner = "owner"
    metadat = RoleMetadata(owner=owner)
    metadat.deserialize(data)
    assert metadat._allow_duplicates == False
    assert metadat._dependencies == []
    # Test set values with data
    data['allow_duplicates'] = True
    data['dependencies'] = [dict]
    metadat.deserialize(data)
    assert metadat._allow_duplicates == True
    assert metadat._dependencies == [dict]
    # Test set values with data
    data['allow_duplicates'] = False
    data['dependencies'] = []
    metadat.deserialize(data)
    assert metadat._allow_duplicates == False
    assert metad

# Generated at 2022-06-23 07:03:29.885171
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:03:32.805793
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    r = RoleMetadata(None)
    instance = r.load({'key1': "value1"}, None)
    assert instance is not None
    assert instance.key1 == 'value1'

# Generated at 2022-06-23 07:03:34.114312
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['vim']
    )
    assert (m.deserialize(data) == True)


# Generated at 2022-06-23 07:03:34.539686
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-23 07:03:34.978439
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-23 07:03:40.957790
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role

    r = Role()
    r.name = 'test'
    rm = RoleMetadata(owner=r)
    assert rm.name == 'test'
    assert rm.dependencies == []
    assert rm.allow_duplicates == False

# Generated at 2022-06-23 07:03:46.513052
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    try:
        # init a RoleMetadata object
        rm = RoleMetadata(owner=None)

        data = dict(
            allow_duplicates=True,
            dependencies=['dependencies']
        )

        # test the deserialize method of class RoleMetadata
        rm.deserialize(data)

    except:
        raise

test_RoleMetadata_deserialize()

# Generated at 2022-06-23 07:03:52.730669
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': True})
    assert r.allow_duplicates is True
    r.deserialize({'allow_duplicates': False})
    assert r.allow_duplicates is False
    r.deserialize({'allow_duplicates': "wrong"})
    assert r.allow_duplicates is False
    r.deserialize({'dependencies': []})
    assert r.dependencies == []
    r.deserialize({'dependencies': 'something'})
    assert r.dependencies == []
    r.deserialize({'dependencies': ['something1', 'something2']})
    assert r.dependencies == ['something1', 'something2']

# Generated at 2022-06-23 07:03:55.186563
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m.allow_duplicates == False
    assert m.dependencies == []

# Generated at 2022-06-23 07:03:59.223163
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(allow_duplicates=True, dependencies=[])
    m = RoleMetadata()
    m.deserialize(data)
    assert m._allow_duplicates is True
    assert m._dependencies == []

# Generated at 2022-06-23 07:04:07.406062
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # mock a calling play
    calling_play = Base()
    calling_play.name = 'mock_play'

    # mock a calling role
    from ansible.playbook.role.definition import RoleDefinition
    calling_role = RoleDefinition()
    calling_role._play = calling_play
    calling_role._role_path = '/some/path'
    calling_role.name = 'mock_role'

    # mock a role to be included
    include_role = RoleDefinition()
    include_role.name = 'include_role'

    # mock a role to be included
    include_role2 = RoleDefinition()
    include_role2.name = 'include_role2'

    # mock a role to be included
    include_role3 = RoleDefinition()
    include_role3.name = 'include_role3'



# Generated at 2022-06-23 07:04:15.731827
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Testing with missing data
    data = None
    owner = None
    variable_manager = None
    loader = None

    m = RoleMetadata.load(data, owner, variable_manager, loader)
    assert m is None
    # Testing with empty data
    data = {}
    owner = None
    variable_manager = None
    loader = None

    m = RoleMetadata.load(data, owner, variable_manager, loader)
    assert m is None


# unit test for method _load_dependencies of class RoleMetadata

# Generated at 2022-06-23 07:04:23.120626
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # Setup test objects
    data = dict(
        allow_duplicates=False,
        dependencies=[],
    )

    # role_path is used to setup the Role object in load_list_of_roles
    # Must be an existing file that is traversable
    role_path = "test/units/module_utils/test_module_utils.py"

    # Setup Play

# Generated at 2022-06-23 07:04:30.187160
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    values = dict(
        allow_duplicates=True,
        dependencies=['foo.bar', 'bar.baz']
    )

    meta = RoleMetadata()
    meta.deserialize(values)
    assert meta._allow_duplicates == True
    assert meta._dependencies == ['foo.bar', 'bar.baz']


# Generated at 2022-06-23 07:04:33.911456
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-23 07:04:41.691728
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Instantiate a RoleMetadata object
    rm = RoleMetadata()

    # Deserialize data dict
    rm.deserialize({'allow_duplicates': True,
                    'dependencies': ['geerlingguy.ntp']})

    # Assert allow_duplicates
    assert rm._allow_duplicates == True
    # Assert dependencies
    assert rm._dependencies == ['geerlingguy.ntp']

# init test
test_RoleMetadata_deserialize()

# Generated at 2022-06-23 07:04:42.362892
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-23 07:04:50.912203
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    play_context = PlayContext()

    role_name = 'role_name'
    role_path = 'role_path'

    play = Play()
    block = Block.load(dict(
        tasks=[dict(action=dict(module='ping'))]),
        play=play,
        role=None,
        task_include=None,
        use_handlers=False,
        block=None)
    task = block.block[0]

    RoleMetadata.load(None, play)

    RoleMetadata.load(dict(), play)


# Generated at 2022-06-23 07:04:51.613805
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:05:02.033111
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import ansible.plugins.loader as plugin_loader
    from ansible.module_utils._text import to_bytes
    my_loader = plugin_loader.ActionModuleLoader()

    variable_manager = ansible.vars.manager.VariableManager()
    variable_manager.extra_vars = dict(
        bar="hello",
        bat="world",
        bel="break",
    )

    from ansible.vars import include_vars
    from ansible.parsing.dataloader import DataLoader
    dataloader = DataLoader()

    include_vars(loader=dataloader, variable_manager=variable_manager, include_files=['tests/vars_files/test_var_files/test_include_vars.yml'])


# Generated at 2022-06-23 07:05:09.492914
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Set up a mock role object
    class MockRole(object):
        def __init__(self):
            self.name = 'role_name'
            self.collections = []

    # Create a RoleMetadata object to be deserialized
    role_metadata = RoleMetadata(owner=MockRole())
    data = dict(
        allow_duplicates=False,
        dependencies=[
            dict(
                name='role1',
                src='name1'
            )
        ]
    )

    # Call deserialize
    role_metadata.deserialize(data)


# Generated at 2022-06-23 07:05:12.706635
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    rmd = RoleMetadata()
    result = rmd.load(dict(dependencies=[]),None)
    assert result._dependencies == []
    assert result._owner == None

# Generated at 2022-06-23 07:05:25.211592
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print('Test normal data')
    data = dict(
        allow_duplicates=True,
        dependencies=[{ 'role': 'role-name' }]
    )
    roleMetadata = RoleMetadata()
    roleMetadata.deserialize(data)
    assert roleMetadata.deserialize(data) == dict(
        allow_duplicates=True,
        dependencies=[{ 'role': 'role-name' }]
    )
    print('Test bad data')
    data = dict(
        allow_duplicates=False
    )
    roleMetadata = RoleMetadata()
    try:
        roleMetadata.deserialize(data)
    except Exception as err:
        print('Got error as expected- {}'.format(err))


# Generated at 2022-06-23 07:05:28.221603
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load([])
    assert role_metadata.dependencies == []


if __name__ == '__main__':
    test_RoleMetadata_load()