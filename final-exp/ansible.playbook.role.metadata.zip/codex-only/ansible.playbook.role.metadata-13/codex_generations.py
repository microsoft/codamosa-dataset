

# Generated at 2022-06-23 06:55:32.687286
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    role_name = 'httpd'
    data = {'allow_duplicates': False, 'dependencies': ['common.role']}
    role = Role.load({'name': role_name}, variable_manager=None, loader=None)

    role_metadata = RoleMetadata.load(data, role)

    assert role_metadata is not None
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies is not None

# Generated at 2022-06-23 06:55:38.045829
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    role = Role()

    rmd = RoleMetadata(role)
    assert rmd.dependencies == []
    assert rmd.allow_duplicates is False

    rmd.deserialize(dict(dependencies=["foo", "bar"], allow_duplicates=True))
    assert rmd.dependencies == ["foo", "bar"]
    assert rmd.allow_duplicates is True

# Generated at 2022-06-23 06:55:49.824509
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    This function performs unit test for method load of class RoleMetadata
    '''
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    my_play_context = PlayContext()
    my_play = Play.load(dict(name="Ansible Play", hosts=['localhost'], gather_facts='no'), variable_manager=None, loader=None)
    my_play._play_context = my_play_context
    my_play._variable_manager = my_play.get_variable_manager()

# Generated at 2022-06-23 06:55:55.267767
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict(
        allow_duplicates=True,
        dependencies=[dict(
            role="role1"
        )]
    )
    meta = RoleMetadata(owner=None).deserialize(data)
    assert type(meta.dependencies) == list
    assert hasattr(meta, 'allow_duplicates')

# Generated at 2022-06-23 06:56:01.209936
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True,
                               'dependencies': ['common']})
    assert role_metadata.allow_duplicates
    assert role_metadata.dependencies == ['common']

    # test deserialize with empty input
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 06:56:12.643105
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import pytest
    from ansible.playbook.role.include import RoleInclude

    role_metadata = RoleMetadata(owner='foo')
    setattr(role_metadata, '_allow_duplicates', False)
    setattr(role_metadata, '_dependencies', [])

    # Test empty values
    assert role_metadata.serialize() == {"allow_duplicates": False, "dependencies": []}

    # Test non-empty values
    setattr(role_metadata, '_allow_duplicates', True)
    setattr(role_metadata, '_dependencies', [RoleInclude('common', 'path/to/common')])


# Generated at 2022-06-23 06:56:22.513848
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()

    test_inventory = InventoryManager(loader=loader, sources=['localhost,'])

    variable_manager = VariableManager(loader=loader, inventory=test_inventory)

    test_obj = RoleMetadata(owner=None)

    test_data = {'allow_duplicates': False, 'dependencies': []}

    test_obj.deserialize(test_data)


# Generated at 2022-06-23 06:56:31.968410
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    data_1 = {'allow_duplicates':False,'dependencies':[]}
    data_2 = {'allow_duplicates':False,'dependencies':['common']}
    data_3 = {'allow_duplicates':True,'dependencies':['common','webservers']}
    metadata = RoleMetadata()
    metadata.deserialize(data_1)
    assert(metadata.allow_duplicates == False)
    assert(metadata.dependencies == [])
    metadata.deserialize(data_2)
    assert(metadata.allow_duplicates == False)
    assert(metadata.dependencies == ['common'])
    metadata.deserialize(data_3)
    assert(metadata.allow_duplicates == True)

# Generated at 2022-06-23 06:56:41.786768
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=''))
        ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=loader)

    RoleMetadata(owner=play)

# Generated at 2022-06-23 06:56:45.367434
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert not m.allow_duplicates
    assert not len(m.dependencies)
    assert not m.galaxy_info
    assert not len(m.argument_spec)

# Generated at 2022-06-23 06:56:49.727445
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rm= RoleMetadata()
    data = {'allow_duplicates':False, 'dependencies':[]}
    rm.deserialize(data)
    assert rm._allow_duplicates == False
    assert rm._dependencies == []



# Generated at 2022-06-23 06:56:55.642936
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    subject = RoleMetadata.load(
        dict(
            allow_duplicates=False,
            dependencies=['foo', 'bar']
        ),
        None
    )
    assert subject.serialize() == dict(
            allow_duplicates=False,
            dependencies=['foo', 'bar']
        )



# Generated at 2022-06-23 06:57:00.636829
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create an instance of class RoleMetadata
    roleMetadata = RoleMetadata()
    roleMetadata.deserialize({'allow_duplicates': False, 'dependencies': []})

    assert (getattr(roleMetadata, '_allow_duplicates') == False)
    assert (getattr(roleMetadata, '_dependencies') == [])

# Generated at 2022-06-23 06:57:05.047572
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta = RoleMetadata.load({}, None)
    assert meta.dependencies == []
    assert meta.allow_duplicates == False

    ds = {
        "dependencies": [
            { "role": "role1" },
            { "name": "role2" }
        ]
    }
    meta = RoleMetadata.load(ds, None)
    assert len(meta.dependencies) == 2
    assert isinstance(meta.dependencies, list)
    assert meta.allow_duplicates == False


# Generated at 2022-06-23 06:57:06.959827
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-23 06:57:20.001471
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # create new instance of class RoleMetadata
    try:
        m = RoleMetadata()
    except Exception as e:
        print("Exception creating new instance of class RoleMetadata")
    # set attribute allow_duplicates with value True
    try:
        m.allow_duplicates = True
    except Exception as e:
        print("Exception setting attribute allow_duplicates")

    # set attribute dependencies with value []
    try:
        m.dependencies = []
    except Exception as e:
        print("Exception setting attribute dependencies")
    # call method deserialize
    try:
        m.deserialize({'allow_duplicates': False, 'dependencies': ['name', 1]})
    except Exception as e:
        print("Exception calling method deserialize")
    # asserts
    assert m._allow_duplicates

# Generated at 2022-06-23 06:57:34.169975
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude
    ri = RoleInclude()
    ri.name = "role1"
    ri.src = 'git+https://github.com/geerlingguy/ansible-role-nginx.git'
    ri.version = '1.0.0'
    ri.allow_duplicates = False
    ri.ansible_version = '>=2.7'
    ri.collections = ['ansible.builtin,geerlingguy.java']
    ri.scm = 'git'
    ri.path = ''

    rm = RoleMetadata()

# Generated at 2022-06-23 06:57:38.778717
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert r.serialize() == dict(allow_duplicates=False, dependencies=[])
    r2 = RoleMetadata()
    r2.allow_duplicates = True
    r2.dependencies = ['foo', 'bar']
    assert r2.serialize() == dict(allow_duplicates=True, dependencies=['foo', 'bar'])

# Generated at 2022-06-23 06:57:41.364269
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata(owner="")
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []


# Generated at 2022-06-23 06:57:52.857076
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-23 06:57:56.858003
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r._allow_duplicates = True
    r._dependencies   = ["test1", "test2"]
    serialised_data = r.serialize()
    assert serialised_data == {'allow_duplicates': True, 'dependencies': ['test1', 'test2']}

# Generated at 2022-06-23 06:58:07.356845
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    import yaml

    data = yaml.safe_load("""
    allow_duplicates: false
    dependencies:
      - role: myrole
    """)

    role = Role()
    role._role_path = './'
    role._role_collection = None

    role_metadata = RoleMetadata(owner=role)
    role_metadata.deserialize(data)

    assert getattr(role_metadata, 'allow_duplicates') == False
    assert getattr(role_metadata, 'dependencies') == [{'role': 'myrole'}]

# Generated at 2022-06-23 06:58:08.484591
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata=RoleMetadata()



# Generated at 2022-06-23 06:58:19.593106
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_obj = dict(
        allow_duplicates=True,
        dependencies=[
            RoleRequirement()
        ]
    )
    # prepare expected result
    expected_result = {
        "dependencies": [{
            "role": None,
            "name": None,
            "scm": None,
            "version": None,
            "collections": [],
            "collections_paths": [],
            "src": None,
            "path": None,
            "allow_duplicates": False,
            "private": False
        }],
        "allow_duplicates": True
    }

    result = RoleMetadata().deserialize(role_obj)
    assert result == expected_result

# Generated at 2022-06-23 06:58:25.877060
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['apache', 'nginx']

    expected = dict(
        allow_duplicates=True,
        dependencies=role_metadata._dependencies
    )

    # Ensure we got the expected result
    assert role_metadata.serialize() == expected

    # Ensure we did not get any side effect
    assert role_metadata._allow_duplicates == expected['allow_duplicates']
    assert role_metadata._dependencies == expected['dependencies']

# Generated at 2022-06-23 06:58:33.170692
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Owner:
        def __init__(self):
            self._play = 'play'
            self._role_path = '/role_path'
            self.collections = ['collection']

    owner = Owner()
    data = {'allow_duplicates': True, 'dependencies': []}

    role_metadata = RoleMetadata.deserialize(data, owner)

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 06:58:44.801668
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    collections = [
        os.path.join(os.path.dirname(__file__), '..', '..', 'collection_examples', 'testns1', 'testcoll1')
    ]
    loader = DataLoader()
    collection_loader = CollectionLoader(loader, collections)
    variable_manager = VariableManager()
    play = Play().load({}, loader=loader, variable_manager=variable_manager, collection_loader=collection_loader)
    play._inherit_parent_roles = lambda *args: None

    yml = [{'role': 'foobar', 'name': 'foobar', 'collections': [{'name': 'testns1.testcoll1', 'version': '1.0.0'}], 'tasks': []}]

# Generated at 2022-06-23 06:58:54.552336
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    role_dependencies = [
        {
            'role': 'my_awesome_role',
            'somedata': 'you should not be here'
        },
        {
            'role': 'another_awesome_role',
        }
    ]

    data = dict(
        allow_duplicates=True,
        dependencies=role_dependencies
    )

    # create a RoleMetadata sut
    sut = RoleMetadata()

    # call deserialize
    sut.deserialize(data)

    # Check if the above attributes deserialize methods were called properly
    assert sut._allow_duplicates == True
    assert sut._dependencies == role_dependencies

# Generated at 2022-06-23 06:59:05.431271
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    import os
    import tempfile
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 06:59:09.721854
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()

    assert role
    assert role._dependencies == []
    assert role._allow_duplicates is False
    assert role._owner is None



# Generated at 2022-06-23 06:59:17.241750
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    arg_data = {
        'allow_duplicates': True,
        'dependencies': ('geerlingguy.jenkins',),
    }

    class Owner():
        def get_name(self):
            return 'BlaBlaBla'

    role_metadata = RoleMetadata(Owner())
    role_metadata.load_data(arg_data)

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['geerlingguy.jenkins']

# Generated at 2022-06-23 06:59:18.133653
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert False

# Generated at 2022-06-23 06:59:24.706405
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    #from ansible.playbook.play import Play

    rd = RoleDefinition.load({'name': 'test_role'})

    context = PlayContext()
    context.remote_addr = 'localhost'
    #play = Play.load(dict(name="test", hosts=["localhost"]), variable_manager=var_mgr, loader=my_loader)
    var_mgr = context.variable_manager

    md = RoleMetadata(rd)
    md.load({'dependencies': [('other_role', '1.0')]}, loader=var_mgr)

    #test dependencies
    assert len(md.dependencies) == 1

# Generated at 2022-06-23 06:59:33.734469
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_data = {
        "ansible_collections": {
            "test_collection": {
                "roles": {
                    "test_role": {
                        "meta": {
                            "main.yml": {
                                "allow_duplicates": True,
                                "dependencies": ["other.role"]
                            }
                        }
                    }
                }
            }
        }
    }
    collection_loader = CollectionLoader()
    collection_loader._load_collections(test_data)
    collection = collection_loader.get_collection("test_collection")
    role = collection.get_role("test_role")
    role_metadata = RoleMetadata.load(role._metadata._data, role)

# Generated at 2022-06-23 06:59:42.894248
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class FakeOwner(object):
        _play = None
        _role_path = '/home/'
        _role_collection = None

        def get_name(self):
            return 'fake'

    meta = RoleMetadata.load({
        'dependencies': [
            {'role': 'common'},
            'webservers',
            {'role': 'foobar'},
        ],
        'galaxy_info': {},
        'allow_duplicates': True,
    }, FakeOwner())
    assert meta.allow_duplicates is True
    assert len(meta.dependencies) == 3

# Generated at 2022-06-23 06:59:50.087805
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data_dict = {
        'dependencies': [
            {
                'role': 'Apache',
                'version': '1.0'
            }, {
                'role': 'PHP'
            }
        ]
    }
    data_object = RoleMetadata.load(data_dict)

    assert data_object._dependencies[0].role == 'Apache'
    assert data_object._dependencies[0].version == '1.0'
    assert data_object._dependencies[1].role == 'PHP'
    assert not data_object._dependencies[1].version

# Generated at 2022-06-23 06:59:56.438516
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    a = RoleMetadata()
    a._allow_duplicates = True
    a._dependencies = ['a', 'b', 'c']
    assert a.serialize() == {'allow_duplicates': True, 'dependencies': ['a', 'b', 'c']}

# Generated at 2022-06-23 07:00:01.020979
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta = {
        "allow_duplicates": True
    }
    role = {"name": "test-role", "path": "."}
    r = RoleMetadata.load(meta, role)
    assert r._allow_duplicates is True
    assert isinstance(r, RoleMetadata)

# Generated at 2022-06-23 07:00:05.870108
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': ['random.role', 'other.dependency']
    }
    m.deserialize(data)
    assert m.allow_duplicates is True

# Generated at 2022-06-23 07:00:10.353011
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_dict = {'allow_duplicates': False, 'dependencies': []}
    m = RoleMetadata()
    m.deserialize(test_dict)
    assert m._allow_duplicates is False
    assert m._dependencies == []


# Generated at 2022-06-23 07:00:16.744076
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert(r.serialize() == {'allow_duplicates': False, 'dependencies': []})
    r._dependencies = ['foo']
    assert(r.serialize() == {'allow_duplicates': False, 'dependencies': ['foo']})
    r._allow_duplicates = True
    assert(r.serialize() == {'allow_duplicates': True, 'dependencies': ['foo']})

# Generated at 2022-06-23 07:00:23.501573
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ds = dict(
        role1=dict(
            meta=dict(
                dependencies=["role_A", "role_B"]
            )
        )
    )

    r1 = RoleMetadata()

    r1.load(ds)
    assert r1.serialize() == dict(
        allow_duplicates=False,
        dependencies=['role_A', 'role_B']
    )
    assert r1.allow_duplicates == False
    assert r1.dependencies == ['role_A', 'role_B']



# Generated at 2022-06-23 07:00:35.178305
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    SET_ATTR = {
      "_dependencies": [{'role': '../toto'}],
      "_owner": "Toto"
    }

    GET_ATTR = {
        "allow_duplicates": False,
        "dependencies": [{'role': '../toto'}]
    }

    def getter(key):
        return GET_ATTR.get(key)

    def setter(key, val):
        SET_ATTR[key] = val

    class Toto(object):
        def __init__(self):
            self.setattr = setter
            self.getattr = getter

    toto = Toto()

    # create a RoleMetadata object
    obj = RoleMetadata(owner=toto)

    # check serialize result

# Generated at 2022-06-23 07:00:47.042876
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class FakeVariableManager:
        class FakeOptions:
            pass

        class FakeVariables:
            variables = {}

        options = FakeOptions
        variables = FakeVariables

    class FakePlay:
        def __init__(self):
            self.name = 'fake_play'
            self.hosts = 'fake_hosts'
            self.connection = 'fake_connection'
            self.port = 10
            self.vars = {}
            self.vars_prompt = {}
            self.vars_files = []
            self.playbook = 'fake_playbook'
            self.defaults = {}
            self.handlers

# Generated at 2022-06-23 07:00:54.619787
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = dict(
            allow_duplicates=True,
            dependencies=['test']
        )
    m.deserialize(data)
    assert m._allow_duplicates == True
    assert m._dependencies == ['test']

# Generated at 2022-06-23 07:00:56.403153
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata("owner")
    assert role_metadata is not None
    assert role_metadata._owner == "owner"

# Generated at 2022-06-23 07:01:01.079252
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_data = {'galaxy_info': {'author': 'daniel'}, 'dependencies': [{'role': 'apache'}, {'role': 'mysql'}], 'allow_duplicates': False}
    role_metadata = RoleMetadata(owner=None).load_data(test_data)
    assert role_metadata.allow_duplicates == test_data['allow_duplicates']
    assert role_metadata.dependencies == test_data['dependencies']

# Generated at 2022-06-23 07:01:02.441060
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-23 07:01:10.619073
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from collections import namedtuple
    from ansible.utils.context_objects import AnsibleContext
    import os

    # Create a mock ansible context
    context_manager = AnsibleContext(MockConfig(), os.path.join('test/'))
    context_manager.push_context(context_manager.get_default_context())

    MockRoleDefinition = namedtuple('MockRoleDefinition', ['role', '_attributes', '_role_path'])
    mock_role_definition = MockRoleDefinition('test_role', dict(name='test_role', role_path='test/test_role'))

    data = dict()
    data['dependencies'] = ['test_dependency']

# Generated at 2022-06-23 07:01:17.178934
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    class Role:

        _role_collection = None
        _role_path = None
        _play = None

    role = Role()

    # Testing with data type supported by allow_duplicates in the object
    metadata = RoleMetadata.load(
        { "allow_duplicates": True }, role)
    assert isinstance(metadata, object)

    # Testing with data type not supported by allow_duplicates in the object
    metadata = RoleMetadata.load(
        { "allow_duplicates": [] }, role)
    assert isinstance(metadata, object)

# Generated at 2022-06-23 07:01:28.364764
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import json

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import ROLE_CACHE

    # set up fake role
    fake_role_data = {
        'metadata': {
            'name': 'some_role',
            'allow_duplicates': True,
        },
        'tasks': []
    }

    ROLE_CACHE.push(fake_role_data)
    role_data = ROLE_CACHE[0]
    role_path = os.path.join(ROLE_CACHE.cache_dir, 'some_role')
    os.mkdir(role_path)

    # load fake role

# Generated at 2022-06-23 07:01:40.251157
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({"allow_duplicates": True, "dependencies": ['roles/webservers/', 'roles/common/'], })
    assert m.allow_duplicates, "The attribute _allow_duplicates is not set to True"
    assert m.dependencies, "The attribute _dependencies is not set to ['roles/webservers/', 'roles/common/']"
    m_empty = RoleMetadata()
    m_empty.deserialize({"allow_duplicates": False, "dependencies": [], })
    assert m_empty.allow_duplicates == False, "The attribute _allow_duplicates is not set to False"

# Generated at 2022-06-23 07:01:49.656582
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.test.test_runner_layer import TestTask

    role = RoleDefinition.load({'name': 'test', 'defaults': {'test_default': 'test_default'}}, [], [], [], 'ansible.builtin')
    rmeta_task = RoleMetadata(owner=role)
    assert isinstance(rmeta_task, RoleMetadata)
    assert isinstance(rmeta_task._owner, RoleDefinition)
    assert rmeta_task._owner == role

    rmeta_task.set_loader(TestTask.fake_loader())
    assert rmeta_task._loader == TestTask.fake_loader()

    rmeta_task.set_variable_manager(TestTask.fake_variable_manager())
    assert rmeta_task

# Generated at 2022-06-23 07:01:52.438686
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test constructor
    m = RoleMetadata()
    assert isinstance(m, Base)
    assert isinstance(m, RoleMetadata)
    assert isinstance(m, object)

# Generated at 2022-06-23 07:01:53.177189
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
	pass

# Generated at 2022-06-23 07:02:01.565001
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    def load(string, owner):
        from ansible.parsing.yaml import objects
        return RoleMetadata.load(objects.AnsibleBaseYAMLObject(string), owner)

    ds = load(dict(
        allow_duplicates=True,
        dependencies=[
            dict(name='role1', version='1.0'),
            dict(name='role2'),
            'role3',
            ],
        galaxy_info=dict(author='me', description="role", license='MIT'),
        ), owner=None)

    assert isinstance(ds, RoleMetadata)
    assert ds.allow_duplicates is True
    assert len(ds.dependencies) == 3
    assert isinstance(ds.dependencies[0], RoleRequirement)

# Generated at 2022-06-23 07:02:11.061623
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    RoleMetadata_object = RoleMetadata()

# Generated at 2022-06-23 07:02:15.760205
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'dependencies': ['role1', 'role2'], 'allow_duplicates': True}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._dependencies == ['role1', 'role2']
    assert role_metadata._allow_duplicates == True


# Generated at 2022-06-23 07:02:28.468944
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    current_path = os.path.dirname(os.path.abspath(__file__))

    data = load_data_from_file(os.path.join(current_path, '../fixtures/ansible/test.yaml'))
    loader = DataLoader()
    variable_manager = VariableManager()
    fake_vault_secret = AnsibleVaultEncrypted

# Generated at 2022-06-23 07:02:33.022055
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    Playbook = namedtuple('Playbook', ['loader', 'inventory', 'variable_manager'])
    playbook = Playbook(
        loader=DataLoader(),
        inventory=InventoryManager(loader=DataLoader(), sources=''),
        variable_manager=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader(), sources=''))
    )

# Generated at 2022-06-23 07:02:41.015746
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print('Testing RoleMetadata')
    print('***Constructor***')
    role_meta = RoleMetadata()
    role_meta = RoleMetadata(owner='owner')
    print('SUCCESS')

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-23 07:02:50.236407
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    def test_load(data, expected):
        m = RoleMetadata(owner=None)
        m.load_data(data, variable_manager=None, loader=None)
        assert dict(m) == expected

    test_load({}, {'allow_duplicates': False, 'dependencies': []})
    test_load({'allow_duplicates': True, 'dependencies': []}, {'allow_duplicates': True, 'dependencies': []})
    test_load({'allow_duplicates': True, 'dependencies': ['a']}, {'allow_duplicates': True, 'dependencies': ['a']})

# Generated at 2022-06-23 07:02:58.700404
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    filename = os.path.join(os.path.dirname(__file__), 'meta', 'main.yml')
    with open(filename, 'rb') as f:
        lm_data = f.read()
        rmd = RoleMetadata()
        rmd.load_data(yaml_safe_load(lm_data))
        assert type(rmd.serialize()) == dict
        assert rmd.serialize()['allow_duplicates'] == False
        assert type(rmd.dependencies[0]) == dict
        assert rmd.dependencies[0]['role'] == 'ANXS.mysql'
        assert rmd.dependencies[0]['name'] == 'dbserver'

# Generated at 2022-06-23 07:03:05.596562
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # setup
    data={'allow_duplicates': True, 'dependencies': []}
    obj = RoleMetadata().deserialize(data)

    # execute
    to_return = obj.serialize()

    # assert
    assert to_return == data


# Generated at 2022-06-23 07:03:12.683527
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import play
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    # Specify module global loader to use
    loader = AnsibleCollectionLoader()
    # Instantiate an instance of fake play class to use as owner
    play = play.Play()
    # Instantiate an instance of fake collection class to use as owner
    fake_collection = AnsibleBaseYAMLObject()
    # Specify fake collection path
    fake_collection._collection_path = 'bogus'
    # Instantiate an instance of fake role class to use as owner
    fake_role = AnsibleBaseYAMLObject()
    # Specify fake rolename to use
    fake_role._role_name = 'bogus'
    #

# Generated at 2022-06-23 07:03:23.781722
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.template import RoleTemplate
    from collections import namedtuple

    Dependency = namedtuple('Dependency', ['role', 'collections'])
    dependency = Dependency(
        role=RoleDefinition(
            name='test',
            play=None,
            variable_manager=None,
            loader=None,
            collection_search_list=None,
            paths=[],
            _role_collection=None,
            role_path=os.path.join(os.path.dirname(__file__), '../../../test/data/collections/invalid_roles.tar.gz'),
        ),
        collections=[],
    )
    include = RoleIn

# Generated at 2022-06-23 07:03:28.304461
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []


# Generated at 2022-06-23 07:03:32.115673
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rm = RoleMetadata()
    rm.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert rm.allow_duplicates is True
    assert rm.dependencies == []

# Generated at 2022-06-23 07:03:33.508921
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Constructor test
    obj = RoleMetadata(owner=None)
    assert obj is not None

# Generated at 2022-06-23 07:03:34.352603
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass


# Generated at 2022-06-23 07:03:42.458944
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # Test case with incorrect metadata
    metadata_1 = "meta/main.yml"
    try:
        data = RoleMetadata.load(metadata_1, loader=None, variable_manager=None)
    except AnsibleParserError:
        print("Exception: Expected an exception because of incorrect metadata")

    # Test case with correct metadata

# Generated at 2022-06-23 07:03:46.646121
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm = RoleMetadata()
    assert rm.serialize() == {'allow_duplicates': False, 'dependencies': []}
    rm = RoleMetadata()
    rm.allow_duplicates = True
    assert rm.serialize() == {'allow_duplicates': True, 'dependencies': []}

# Generated at 2022-06-23 07:03:59.897311
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    This is a unit test for method load of class RoleMetadata.
    """
    owner = load(dict(
        name='test_role',
        collections=['collections/test_collection'],
        src='/opt/test/roles/test_role',
        path='/opt/test/roles/test_role',
        attrs={
            '_role_path': '/opt/test/roles/test_role',
            'collections': ['collections/test_collection']
        }
    ))
    variable_manager = load(dict())

    assert isinstance(variable_manager, Object)

# Generated at 2022-06-23 07:04:11.546983
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import json
    import filecmp
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.common._collections_compat import Mapping

    ansible_tests_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../tests'))
    role_path = os.path.join(ansible_tests_dir, 'test_collections', 'collections', 'testns', 'testcoll1', 'roles', 'testcoll1_role1')
    if not os.path.exists(role_path):
        raise AssertionError('role path for test is invalid')


# Generated at 2022-06-23 07:04:23.991252
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test case when allow_duplicates is True and dependencies is not empty
    allow_duplicates = True
    dependencies = [{'name': 'foo'}]
    r = RoleMetadata()
    r.allow_duplicates = allow_duplicates
    r.dependencies = dependencies
    expected_result = dict(
        allow_duplicates=allow_duplicates,
        dependencies=dependencies
    )
    actual_result = r.serialize()
    assert expected_result == actual_result

    # Test case when allow_duplicates is False and dependencies is not empty
    allow_duplicates = False
    dependencies = [{'name': 'foo'}]
    r = RoleMetadata()
    r.allow_duplicates = allow_duplicates
    r.dependencies = dependencies
    expected_

# Generated at 2022-06-23 07:04:35.144644
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    role_path = os.path.join(os.path.dirname(__file__), 'meta_main')

    # Create a Role
    role_definition = RoleDefinition.load(role_path, 'roles', None, None, True)
    role = Role.load(role_definition)

    # Create a HostVars
    host_vars = HostVars(variable_manager=None, loader=None, hostname="test")

    # Create a VariableManager

# Generated at 2022-06-23 07:04:46.669213
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Input data for the unittest
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    role = RoleMetadata()

    # Run the deserialize method of the class RoleMetadata to
    # set the data structure to the object
    role.deserialize(data)

    # Check if the values after the deserialization are the same
    # as the input data and if the data types are correct
    assert role._allow_duplicates is False and type(role._allow_duplicates) is bool
    assert role._dependencies == [] and type(role._dependencies) is list

    # Check if the deserialize method of the class RoleMetadata raises
    # an TypeError exception when the input data structure is not a dictionary

# Generated at 2022-06-23 07:04:56.950931
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    play_context = {'converge': False}
    play = Play().load({}, variable_manager=VariableManager(), loader=DataLoader())
    tqm = TaskQueueManager(inventory=InventoryManager(loader=DataLoader(), sources=None), variable_manager=VariableManager(), loader=DataLoader())
    role = RoleMetadata.load({}, owner=play, variable_manager=VariableManager(), loader=DataLoader())
    assert r

# Generated at 2022-06-23 07:05:09.239963
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''role_metadata.py: Test of class RoleMetadata'''

    # Create a mock class for the Role
    class Role():
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name

    # Create a mock class for the Play
    class Play():
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    # Create two mock objects for the role and play.
    role = Role("test_role")
    play = Play("test_play")

    # Set the _role and _play attributes of the role
    role._role = role
    role._play = play

    # Verify the behavior with valid input
    mdata = RoleMetadata.load({}, role)
   

# Generated at 2022-06-23 07:05:22.005570
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create and return a fake Role object
    def fake_Role_class(*_, **__):
        return object()
    # Create and return a fake TaskInclude object
    def fake_RoleInclude(*_, **__):
        return object()

    # Create a fake RoleMetadata object for test
    rol_meta = RoleMetadata(owner=None)
    rol_meta._allow_duplicates = True
    rol_meta._dependencies = [
        fake_RoleInclude(),
        fake_RoleInclude()
    ]

    # Call serialize and check the result
    data = rol_meta.serialize()
    assert data['allow_duplicates'] is True
    # Check dependencies format
    assert all(isinstance(dependency, object) for dependency in data['dependencies'])

# Generated at 2022-06-23 07:05:23.862598
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO: test the load method of class RoleMetadata
    pass


# Generated at 2022-06-23 07:05:29.165456
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner=None).load_data(dict(
        dependencies=dict(role="foo", version="1.0")
    ), variable_manager=None, loader=None)
    assert len(m.dependencies) == 1
    assert m.dependencies[0].name == 'foo'
    assert m.dependencies[0].role == 'foo'