

# Generated at 2022-06-23 06:55:24.333301
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Create a RoleInclude object
    role_include_obj = RoleRequirement()

    # Load role_include object in role_metadata object
    role_metadata_obj = RoleMetadata(owner=None)
    role_metadata_obj._load_dependencies(role_include_obj, 'hello')

# Generated at 2022-06-23 06:55:29.526945
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = "could not find role in"
    role_metadata = RoleMetadata(owner=None)
    try:
        role_metadata.load(data=data, owner=None, variable_manager=None, loader=None)
    except Exception as exception:
        assert type(exception) is AnsibleParserError

# Generated at 2022-06-23 06:55:36.576753
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.cli.adhoc import AdHocCLI as cli
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars



# Generated at 2022-06-23 06:55:47.713277
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test 1: non-dict data
    string = "string"
    m = RoleMetadata()
    with pytest.raises(AnsibleParserError) as excinfo:
        m.load(string, "owner")
    assert 'the \'meta/main.yml\' for role owner is not a dictionary' in str(excinfo.value)

    # Test 2: valid data
    data = {'dependencies': ['test'], 'allow_duplicates': True}
    m = RoleMetadata()
    m.load(data, "owner")
    assert m._allow_duplicates == True
    assert ['test'] == m._dependencies

    # Test 3: data missing allow_duplicates
    data = {'dependencies': ['test']}
    m = RoleMetadata()

# Generated at 2022-06-23 06:55:56.603444
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role.definition import TaskInclude

    fake_loader = None
    myplay = Play.load(dict(
        name="myplay",
        hosts="all",
        gather_facts="yes",
        roles=["web", "database"],
    ), loader=fake_loader)
    myplay.set_loader(fake_loader)

    mytask = Conditional()
    mytask._attributes = dict(
        name="test",
        when="runme",
        loop="results",
    )

# Generated at 2022-06-23 06:56:07.106419
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    r = Role.load(dict(
        name='myrole',
        vars=dict(a=1),
        tasks=dict(main=dict(meta='dict')),
    ))

    assert isinstance(r, Role)
    assert r.get_name() == 'myrole'
    assert r._metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[],
    )
    assert r._tasks.serialize()['block'] == {'meta': 'dict'}

    fh = open(os.path.join(r._role_path, 'meta', 'main.yml'))

# Generated at 2022-06-23 06:56:12.821522
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Unit test for method serialize of class RoleMetadata
    '''
    current_instance = RoleMetadata()
    current_instance._allow_duplicates = True
    current_instance._dependencies = ['test1', 'test2']
    expected_result = {'allow_duplicates': True, 'dependencies': ['test1', 'test2']}
    assert current_instance.serialize() == expected_result

# Generated at 2022-06-23 06:56:19.309523
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    role_definition = RoleDefinition()
    role_include = RoleInclude()
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data=role_definition.serialize())
    role_metadata.deserialize(data=role_include.serialize())

# Generated at 2022-06-23 06:56:26.211205
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_data = {
            'allow_duplicates': True,
            'dependencies': ['ansible.legacy.role1', 'ansible.legacy.role2', 'new_format_role']
            }

    role_metadata = RoleMetadata()
    role_metadata.deserialize(test_data)
    assert role_metadata._allow_duplicates == True
    assert len(role_metadata._dependencies) == 3

# Generated at 2022-06-23 06:56:31.055595
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = [ 'first', 'second' ]
    result = role_metadata.serialize()

    assert(result['allow_duplicates'] == False)
    assert(result['dependencies'][0] == 'first')
    assert(result['dependencies'][1] == 'second')

# Generated at 2022-06-23 06:56:33.822943
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False,
            'dependencies': []}
    assert RoleMetadata().deserialize(data) == data

# Generated at 2022-06-23 06:56:43.296679
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import role_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    data = dict(
        allow_duplicates=True,
        dependencies=[dict(rolename=dict(name='example'))]
    )

    role_name = 'example'
    role_path = '/etc/ansible/roles/' + role_name
    Galaxy = AnsibleCollectionLoader()
    Galaxy.add_

# Generated at 2022-06-23 06:56:53.205735
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-23 06:57:04.898915
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    dataloader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=dataloader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 06:57:06.831450
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data=dict(
        allow_duplicates=False
    )
    m = RoleMetadata()
    m.deserialize(data)
    assert m._allow_duplicates == False
    assert m._dependencies == []

# Generated at 2022-06-23 06:57:16.436697
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    ds = dict(allow_duplicates='yes', dependencies=['maven', 'tomcat'])
    role_definition = RoleDefinition()
    role_metadata = RoleMetadata(owner=role_definition)
    role_metadata.load_data(ds)
    serialized_data = role_metadata.serialize()
    assert serialized_data['allow_duplicates'] is True
    assert serialized_data['dependencies'] == ds['dependencies']


# Generated at 2022-06-23 06:57:31.098170
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Init
    role_metadata = RoleMetadata()

    # set the attributes
    setattr(role_metadata, 'allow_duplicates', False)

# Generated at 2022-06-23 06:57:38.087229
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    class _Role(object):
        def __init__(self, name, path):
            self._role_path = path
            self.name = name
            self.collections = []

    data = {'allow_duplicates': False, 'dependencies': []}
    owner = _Role('foo', '/path/to/roles/foo')

    role = RoleMetadata(owner = owner)
    role.deserialize(data)

    assert True == role._allow_duplicates
    assert [] == role._dependencies

# Generated at 2022-06-23 06:57:44.410741
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    a = RoleMetadata()
    b = a.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert(not b._allow_duplicates)
    assert(b._dependencies == [])
    assert(b._galaxy_info == {})
    assert(b._argument_specs == {})
    assert(b._owner is None)

# Generated at 2022-06-23 06:57:51.861463
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata_serialize_test = RoleMetadata()
    roleMetadata_serialize_test.allow_duplicates = False
    roleMetadata_serialize_test.dependencies = []
    serialized_roleMetadata = roleMetadata_serialize_test.serialize()
    if not serialized_roleMetadata == {'allow_duplicates': False, 'dependencies': []}:
        raise AssertionError('Expected {\'allow_duplicates\': False, \'dependencies\': []}, actual %s' % repr(serialized_roleMetadata))


# Generated at 2022-06-23 06:58:01.592979
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                role="geerlingguy.varnish"
            ),
            dict(
                role="geerlingguy.redis",
                version="3.0.4",
                vars=dict(
                    redis_port=6379
                )
            ),
            dict(
                name="foo.bar",
                src="/path/to/foo.bar"
            )
        ]
    )
    role_metadata = RoleMetadata.load(data, None)
    assert role_metadata
    assert role_metadata._allow_duplicates
    assert len(role_metadata._dependencies) == 3
    assert role_metadata.serialize() == data
    assert role_metadata.deserialize(data) == None

# Generated at 2022-06-23 06:58:11.920174
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsV2
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.reserved import define_hostvar
    from ansible.template.vars import AnsibleJ2Vars
    import jinja2
    loader = DataLoader()
    jenv = jinja2.Environment()


# Generated at 2022-06-23 06:58:20.877134
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # verify when allow_duplicates is false then dependencies is not empty
    rmd = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    rmd.deserialize(data)
    assert (getattr(rmd, 'dependencies') == [])
    assert (getattr(rmd, 'allow_duplicates') == False)

    # verify when allow_duplicates is false then dependencies is not empty
    data = {'dependencies': []}
    rmd.deserialize(data)
    assert (getattr(rmd, 'dependencies') == [])
    assert (getattr(rmd, 'allow_duplicates') == False)



# Generated at 2022-06-23 06:58:23.185747
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata().deserialize({}) == None

# Generated at 2022-06-23 06:58:24.727816
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    x = RoleMetadata()
    assert isinstance(x, RoleMetadata)

# Generated at 2022-06-23 06:58:33.061690
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_dependencies = [{
        "role": "ansible-role-foo",
        "version": "v1"
    }, {
        "role": "ansible-role-bar"
    }]
    role_metadata = RoleMetadata()
    setattr(role_metadata, 'allow_duplicates', True)
    setattr(role_metadata, 'dependencies', role_dependencies)

    assert role_metadata._serialize() == {'dependencies': role_dependencies, 'allow_duplicates': True}

# Generated at 2022-06-23 06:58:34.652959
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert RoleMetadata.load("{}",None)


# Generated at 2022-06-23 06:58:45.616401
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.six import PY3
    from ansible.playbook.helpers import load_list_of_roles

    mock_play = Mock()
    mock_role = Mock()
    mock_loader = Mock()

    role_path = '/roles'
    role_name = 'test'
    role_name_prefix = 'test_'
    role_path_name = '/roles/test'
    main_yml_filename = 'meta/main.yml'
    main_yml_file_path = '/roles/test/meta/main.yml'

    if PY3:
        builtin_open = 'builtins.open'
    else:
        builtin_open = '__builtin__.open'

    # Test with allow_duplicates: True
    main_

# Generated at 2022-06-23 06:58:52.902248
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print("Test if deserialize method of RoleMetadata class works as expected.")
    main_dict = {"allow_duplicates": False, "dependencies": {"role": "foo", "name": "bar"}}
    owner = None
    deserialize_role_metadata = RoleMetadata().deserialize(main_dict)
    print("Pass" if deserialize_role_metadata == main_dict else "Fail")

if __name__ == '__main__':
    test_RoleMetadata_deserialize()

# Generated at 2022-06-23 06:59:01.970493
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    for test_name, test_data in [
        ('basic', dict(
            rmd=RoleMetadata(),
            data=dict(allow_duplicates=False, dependencies=['foo', 'bar']),
            expect=dict(allow_duplicates=False, dependencies=['foo', 'bar']),
        )),
        ('empty', dict(
            rmd=RoleMetadata(),
            data=dict(allow_duplicates=True, dependencies=[]),
            expect=dict(allow_duplicates=True, dependencies=[]),
        )),
    ]:
        # Setup
        rmd = test_data['rmd']
        data = test_data['data']
        expect = test_data['expect']
        if test_name in ['basic']:
            actual = rmd.deserialize(data)



# Generated at 2022-06-23 06:59:08.080441
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    md = RoleMetadata()
    md.deserialize(dict(
        allow_duplicates=False,
        dependencies=[]
    ))

    assert not hasattr(md, '_dependencies')
    assert not hasattr(md, '_galaxy_info')
    assert not hasattr(md, '_allow_duplicates')
    assert not hasattr(md, '_argument_specs')

    assert not md.allow_duplicates
    assert not md.dependencies

# Generated at 2022-06-23 06:59:12.651077
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load(
        data={
                'allow_duplicates': False,
                'dependencies': ['foo.bar']
        }
    )
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == ['foo.bar']

# Generated at 2022-06-23 06:59:21.664074
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.role.metadata import RoleMetadata

    # Test 1. Test load_list_of_roles, which returns a list of RoleInclude objects
    # Test 1.1. test simple load_list_of_roles with a list of str
    roles = ['foo', 'bar', 'baz']
    current_path = '/path/to/user/roles'
    collection_search_list = ['ansible.builtin', 'ansible.posix']
    role_include_list = RoleMetadata.load_list_of_roles(roles, current_path, None, collection_search_list)

# Generated at 2022-06-23 06:59:32.090352
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Testing the case when meta/main.yml is not a dictionary (expecting AnsibleParserError)
    import ansible.playbook.role_include
    import ansible.playbook.role
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.playbook.block import Block
    from io import StringIO

# Generated at 2022-06-23 06:59:34.458215
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    roleMetadata = RoleMetadata()
    assert roleMetadata.deserialize({}) == {}

# Generated at 2022-06-23 06:59:35.703802
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.vars.manager import VariableMana

# Generated at 2022-06-23 06:59:38.100571
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    Unit test for constructor of class RoleMetadata
    """
    role = RoleMetadata()
    assert role is not None

# Generated at 2022-06-23 06:59:41.264437
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': True, 'dependencies': ['test', 'toto']}
    r = RoleMetadata()
    r.deserialize(data)
    assert r._allow_duplicates == True
    assert r._dependencies == ['test', 'toto']

# Generated at 2022-06-23 06:59:45.297413
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''
    # import ansible.playbook.role
    # assert ansible.playbook.role.RoleMetadata.load(data=, owner=, variable_manager=, loader=)


# Generated at 2022-06-23 06:59:55.283070
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['localhost']))

    src = {'name': 'Adam', 'dependencies': [{'role': 'foo'}, {'role': 'bar', 'some_param': 'foo'}], 'allow_duplicates': True}
    role_metadata = RoleMetadata.load(src, RoleDefinition.load({}, variable_manager=variable_manager, loader=loader))
    assert role_

# Generated at 2022-06-23 07:00:03.606594
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_host = Host(name="test_host")
    test_play = Play.load(dict(
        name="test_play",
        hosts=['test_host'],
        roles=['test_role']
    ))
    test_role = Role.load(dict(name="test_role"), play=test_play, variable_manager=VariableManager())
    test_metadata = RoleMetadata.load(dict(
        allow_duplicates=False,
        dependencies=[
            {'role': 'test_role'},
            {'role': 'test_role'}
        ]
    ), owner=test_role)
    assert test_metadata._allow_duplicates == False
    assert len(test_metadata._dependencies) == 2

# Generated at 2022-06-23 07:00:05.525692
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata(owner = None)
    meta.deserialize({ 'allow_duplicates': True, 'dependencies': ["redis", "mysql"] })
    assert meta.allow_duplicates == True
    assert meta.dependencies == ["redis", "mysql"]

# Generated at 2022-06-23 07:00:08.453178
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test without owner
    roleMetadata = RoleMetadata()
    roleMetadata.__init__()

    # Test with owner
    roleMetadata.__init__(owner='role')

# Generated at 2022-06-23 07:00:19.841005
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from units.mock.loader import DictDataLoader

    data = dict(allow_duplicates=True,
                dependencies=[dict(role=AnsibleVaultEncryptedUnicode("vault"))])
    data_loader = DictDataLoader({"meta.yml": "!!python/object:__main__.test_RoleMetadata_deserialize"})
    m = RoleMetadata(owner=None)
    m.deserialize(data)
    assert  len(m._dependencies) == 1
    assert m._dependencies[0].get("role") == AnsibleVaultEncryptedUnicode("vault")
    assert m._allow_duplicates

# Generated at 2022-06-23 07:00:20.736580
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # no special tests needed at this time
    pass

# Generated at 2022-06-23 07:00:27.854019
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext
    data = {}
    data['allow_duplicates'] = 'test'
    data['dependencies'] = 'test'

    # Create RoleMetadata
    _owner = PlayContext()

    _owner._role_name = 'test'
    _owner._play = 'play'

    _owner._role_path = '/home/username/ansible/roles/test'
    _owner._variable_manager = '_variable_manager'
    _owner._loader = '_loader'

    _owner.collections = ['a','b','c']

    roleMetadata = RoleMetadata()

    roleMetadata._owner = _owner
    roleMetadata.deserialize(data)

    assert roleMetadata.allow_duplicates == 'test'

# Generated at 2022-06-23 07:00:34.815912
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {}
    r.deserialize(data)
    assert r._allow_duplicates == False
    assert r._dependencies == []

    data = {'allow_duplicates': True, 'dependencies': ['ansible.zoo']}
    r.deserialize(data)
    assert r._allow_duplicates == True
    assert r._dependencies == ['ansible.zoo']

    data = {'allow_duplicates': 'X', 'dependencies': ''}
    with pytest.raises(AssertionError):
        r.deserialize(data)

    # with pytest.raises(AnsibleParserError):
    #     r.deserialize(data)
    #     assert not r._allow_duplicates
    #     assert not r

# Generated at 2022-06-23 07:00:35.929471
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass

# Generated at 2022-06-23 07:00:42.751757
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # create an object of class RoleMetadata
    role_metadata_obj = RoleMetadata()
    # create a dictionary data
    data = {'allow_duplicates': False, 'dependencies': []}
    # deserialize the data
    role_metadata_obj.deserialize(data)
    # equality test
    assert role_metadata_obj.allow_duplicates == False
    assert role_metadata_obj.dependencies == []

# Generated at 2022-06-23 07:00:52.608892
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )

    m = RoleMetadata()
    m.deserialize(data)

    assert m.allow_duplicates == True
    assert m.dependencies == []

# Generated at 2022-06-23 07:01:00.431607
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()

    # test role_metadata without dependencies
    data = {
        'allow_duplicates': True,
    }
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates is True
    assert role_metadata.dependencies == []

    # test role_metadata with dependencies
    data = {
        'allow_duplicates': False,
        'dependencies': [
            'foo',
            'bar'
        ]
    }
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 07:01:09.858004
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    rdm = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': [u'Test'], 'name': u'Test', 'collections': [],
            'options': {u'role_path': u'/home/user/Test', u'role_name': u'Test'}, '_role_path': '/home/user/Test'}
    result = rdm.deserialize(data)
    assert result.__dict__['_allow_duplicates'] == False
    assert isinstance(result.__dict__['_dependencies'][0], RoleRequirement)

# Generated at 2022-06-23 07:01:12.196265
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    R = RoleMetadata()
    x =  {'allow_duplicates': False, 'dependencies': []}
    R.deserialize(x)
    assert R.allow_duplicates == False
    assert R.dependencies == []

# Generated at 2022-06-23 07:01:25.039870
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role

    data1 = {
      "dependencies": [
        "test_role1",
        {
          "role": "test_role2",
          "test_var1": "test_value1"
        },
        {
          "test_role3": {
            "test_var2": "test_value2"
          }
        }
      ],
      "allow_duplicates": False
    }

# Generated at 2022-06-23 07:01:28.024350
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    This is an unit test of RoleMetadata class constructor
    """
    try:
        metadata = RoleMetadata(owner=None)
    except Exception as err:
        print(err)

# Generated at 2022-06-23 07:01:28.523590
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:01:40.456563
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import action_loader, lookup_loader, cache_loader, callback_loader, connection_loader
    from ansible.plugins.discovery import find_plugins
    from ansible.playbook.play_context import PlayContext
    import yaml
    # test with empty yaml data
    test_yaml = {}
    test_yaml_data = yaml.safe_load(test_yaml)
    test_role = RoleMetadata()
    test_role.deserialize(test_yaml_data)
    assert test_role._allow_duplicates == False
    assert test_role._dependencies == []
    # test with non-empty yaml data

# Generated at 2022-06-23 07:01:45.843854
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    owner = object
    data = dict(allow_duplicates=True, dependencies=[])
    metadata = RoleMetadata(owner)
    metadata.deserialize(data)

    assert getattr(metadata, 'allow_duplicates') == data.get('allow_duplicates', False)
    assert getattr(metadata, 'dependencies') == data.get('dependencies', [])

# Generated at 2022-06-23 07:01:55.467842
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata

    owner = RoleDefinition()

    role_meta = RoleMetadata(owner)

    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    # Call deserialize
    role_meta.deserialize(data)

    # Check data stored in role meta
    assert role_meta._allow_duplicates == data['allow_duplicates']
    assert role_meta._dependencies == data['dependencies']

# Generated at 2022-06-23 07:02:06.999039
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.helpers import load_list_of_roles

    class AnsibleOptions(object):
        def __init__(self, **kwargs):
            for x in kwargs:
                setattr(self, x, kwargs[x])

    class RoleInclude(object):
        def __init__(self, role_name, role_path, args=None, task_include=None, role=None, collection_name=None,):
            self._role_name = role_name
            self._role_path = role_path
            self._args = args
            self._task_include = task_include
            self._role = role
            self._collection_name = collection_name


# Generated at 2022-06-23 07:02:18.471842
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    role_data = {
        'name' : 'test-role',
        'description' : 'description',
        'dependencies' : [
            {'role' : 'test-role-cache'},
            {'role' : 'test-role-1'},
            {'role' : 'test-role-2'},
            'test-role-3',
        ],
    }

    parent_role = Role.load(role_data, None)
    role_metadata = RoleMetadata(owner=parent_role)

    assert type(role_metadata.dependencies) is list
    assert type(role_metadata.dependencies[0]) is RoleInclude
    assert role_metadata.dependencies[0].role

# Generated at 2022-06-23 07:02:21.296525
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata
    res = r.deserialize({'allow_duplicates': False, 'dependencies': []})


# Generated at 2022-06-23 07:02:28.468815
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Test RoleMetadata serializes properly
    data = dict(
        allow_duplicates = True,
        dependencies = [ 'A', 'B', 'C' ]
        )

    # create instance of RoleMetadata
    role_meta = RoleMetadata()

    role_meta.deserialize(data)

    # serialize data and then compare the serialized data against the expected
    # serialized data
    assert role_meta.serialize() == data

# Generated at 2022-06-23 07:02:32.981284
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {
        'dependencies': [
            {'role': 'geerlingguy.java'},
            {'role': 'geerlingguy.tomcat'},
        ],
        'some_var': 'some_value'
    }
    rm = RoleMetadata.load(data, owner=None)
    print(rm.dependencies) # [role('geerlingguy.java'), role('geerlingguy.tomcat')]
    print(rm['some_var']) # some_value
    rm2 = RoleMetadata(owner=None)
    rm2.load(data, owner=None)
    print(rm2.dependencies) # [role('geerlingguy.java'), role('geerlingguy.tomcat')]
    print(rm2['some_var']) # some_value


# Generated at 2022-06-23 07:02:37.590964
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata()  # To satisfy PyCharm inspection, which is wrong.

# Generated at 2022-06-23 07:02:39.704138
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    return role_metadata

# Generated at 2022-06-23 07:02:42.474582
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role_metdata = RoleMetadata(owner=role)

# Generated at 2022-06-23 07:02:51.762002
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs

    class MockRole(Role):
        """MockRole

        A mock object that looks and acts enough like a real Role object
        that the RoleMetadata.load() method can operate on it.

        """
        def __init__(self, play, name, role_path):
            super(MockRole, self).__init__()
            self._play

# Generated at 2022-06-23 07:02:54.044520
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m._allow_duplicates == False
    assert m._dependencies == []
    assert m._galaxy_info == None

# Generated at 2022-06-23 07:02:57.480131
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    def test(data):
        metadata = RoleMetadata()
        metadata.load_data(data)
        return metadata
    assert test({'allow_duplicates': True,
                 'dependencies': ['role1', 'role2']})


# Unit testing
import pytest
from ansible.playbook.role.definition import RoleDefinition


# Generated at 2022-06-23 07:02:58.397242
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-23 07:03:06.895980
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    yaml_content = '''---
allow_duplicates: False
dependencies:
 - name: test_name
'''
    import yaml
    data = yaml.load(yaml_content)
    r = RoleMetadata()
    r.deserialize(data)

    assert r.allow_duplicates == False
    assert r.dependencies[0]['name'] == 'test_name'

# Generated at 2022-06-23 07:03:13.396281
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition

    # test 1
    class MockRole(RoleDefinition):
        _role_path = os.path.join(os.path.dirname(__file__), '../../test_data/library/')

        def __init__(self):
            self._role_name = 'role1'
            self._role_collection = 'my.collection'
            super(MockRole, self).__init__()

    data = dict(
        allow_duplicates = False,
        dependencies = ['role2']
    )

    role = MockRole()
    meta = RoleMetadata(owner=role)

    result = RoleMetadata.load(data, role)

    assert result._allow_duplicates == data['allow_duplicates']

# Generated at 2022-06-23 07:03:18.262000
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    deserialize_data = {'allow_duplicates': False, 'dependencies': []}
    r.deserialize(deserialize_data)
    assert getattr(r, 'allow_duplicates') == False
    assert getattr(r, 'dependencies') == []


# Generated at 2022-06-23 07:03:19.371264
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-23 07:03:23.012913
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    ''' two simple tests to run against the method load of class RoleMetadata '''

    test1 = RoleMetadata.load(None, None)
    assert test1 is not None

# Generated at 2022-06-23 07:03:32.295251
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_p = {
        "allow_duplicates": False,
        "dependencies": [
            {
                "role": "role1",
                "collections": [
                    "collection1"
                ]
            },
            {
                "role": "role1",
                "collections": [
                    "collection2"
                ]
            },
        ]
    }
    role_metadata = RoleMetadata.load(data=role_metadata_p, owner=None)
    role_metadata_serialized = role_metadata.serialize()
    assert(role_metadata_serialized)
    assert(role_metadata_serialized['allow_duplicates'] == False)
    dependencies = role_metadata_serialized['dependencies']
    role1_collection1 = dependencies[0]

# Generated at 2022-06-23 07:03:35.524515
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    variable_manager = DummyVariableManager()
    loader = DummyLoader()
    data = {'galaxy_info': {'author': 'author1', 'description': 'desc1'}}

    role_metadata = RoleMetadata.load(data, None, variable_manager, loader)
    assert role_metadata is not None



# Generated at 2022-06-23 07:03:45.178384
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Input data
    data = {
        'allow_duplicates': False,
        'dependencies': ['role:name']
    }

    # Expected output
    output = {
        'allow_duplicates': False,
        'dependencies': ['role:name']
    }

    # Actual output
    role_metadata = RoleMetadata()
    role_metadata.load(data)
    actual_output = role_metadata.serialize()

    # Test if the actual output matches the expected output
    assert actual_output == output

# Generated at 2022-06-23 07:03:48.064849
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata().deserialize({}) == {'allow_duplicates': False, 'dependencies': []}
    assert RoleMetadata().deserialize({'allow_duplicates': True}) == {'allow_duplicates': True, 'dependencies': []}
    assert RoleMetadata().deserialize({'dependencies': ['a', 'b']}) == {'allow_duplicates': False, 'dependencies': ['a', 'b']}

# Generated at 2022-06-23 07:03:53.545157
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 07:03:58.434591
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['common']
    )
    rolemetadata = RoleMetadata()
    rolemetadata.allow_duplicates
    rolemetadata.dependencies
    result = rolemetadata.deserialize(data)
    assert data == result

# Generated at 2022-06-23 07:04:07.060927
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

# Generated at 2022-06-23 07:04:09.534928
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 07:04:10.123216
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass

# Generated at 2022-06-23 07:04:16.578963
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader.action_plugin import ActionBase

    roledef = RoleDefinition()
    main = RoleMetadata()
    main.deserialize( {'allow_duplicates': True,
                       'dependencies': [
                           {'role': 'ansible-role-apache'},
                           {'role': 'ansible-role-php'},
                       ]} )
    assert main.allow_duplicates == True
    assert main.dependencies == [{'role': 'ansible-role-apache'},
                                 {'role': 'ansible-role-php'}]


#  Unit test for method serialize of class RoleMetadata

# Generated at 2022-06-23 07:04:18.095901
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert isinstance(RoleMetadata.load({}, owner=None), RoleMetadata)

# Generated at 2022-06-23 07:04:20.834869
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    testRoleMetadata = RoleMetadata();
    testRoleMetadata.allow_duplicates = True
    testRoleMetadata.dependencies = [ 'dependencies1', 'dependencies2' ]
    result = testRoleMetadata.serialize()
    assert result == { 'allow_duplicates': True, 'dependencies': [ 'dependencies1', 'dependencies2' ] }


# Generated at 2022-06-23 07:04:33.369447
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # setup test inputs
    mock_owner = None
    mock_variable_manager = None
    mock_loader = None
    # First test (invalid data type)
    data = []
    try:
        r = RoleMetadata.load(data, mock_owner,
                              mock_variable_manager,
                              mock_loader)
        assert False
    except AnsibleParserError as e:
        assert e.message == "the 'meta/main.yml' for role None is not a dictionary"
        assert e.obj == []

    # Second test (valid data type)
    data = dict()
    r = RoleMetadata.load(data, mock_owner,
                          mock_variable_manager,
                          mock_loader)
    assert r.dependencies == []
    assert r.allow_duplicates == False

    #

# Generated at 2022-06-23 07:04:38.110448
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {
        'dependencies': [
            {'role': 'dummy'},
        ],
    }
    role_metadata = RoleMetadata.load(data, None)

    result = role_metadata.serialize()
    assert(result['dependencies'][0]['role'] == 'dummy')

# Generated at 2022-06-23 07:04:40.873604
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 07:04:46.880927
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Unit test for method deserialize of class RoleMetadata
    '''
    testmeta = {'allow_duplicates': False, 'dependencies': []}
    m = RoleMetadata()
    m.deserialize(testmeta)
    assert (m.allow_duplicates == False)
    assert (m.dependencies == [])


# Generated at 2022-06-23 07:04:49.564003
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta = RoleMetadata()
    assert role_meta.allow_duplicates == False
    assert role_meta.dependencies == []



# Generated at 2022-06-23 07:05:00.133097
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """ Test case for serialize method of RoleMetadata class
    """

    obj = RoleMetadata()
    obj.dependencies = [
        {
                'role': 'foo',
                'name': 'bar',
                'src': 'foobar.tar.gz',
                'version': '1.0'
            }
        ]

    obj.allow_duplicates = True
    result = obj.serialize()
    assert isinstance(result, dict)
    assert result.get('allow_duplicates') is True
    assert result.get('dependencies') == [
        {
                'role': 'foo',
                'name': 'bar',
                'src': 'foobar.tar.gz',
                'version': '1.0'
            }
        ]

    obj = RoleMetadata()

# Generated at 2022-06-23 07:05:10.596193
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugin.loader import load_plugin_vars_from_file

    # load dataloader
    data_loader = DataLoader()

    # define test data structure
    base_dir = os.path.dirname(__file__)

# Generated at 2022-06-23 07:05:17.677242
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role

    ds = dict(
        allow_duplicates=True,
        dependencies=[dict(role="common", some_var='foo')]
    )

    r = Role.load(ds)
    assert ds == r.metadata.serialize()

# Generated at 2022-06-23 07:05:21.665359
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {
        'allow_duplicates': True,
        'dependencies': []
    }
    role_meta = RoleMetadata()
    role_meta.deserialize(data)
    assert role_meta._allow_duplicates == True
    assert role_meta._dependencies == []