

# Generated at 2022-06-23 06:55:21.094005
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from tests.unit.mock.loader import DictDataLoader


# Generated at 2022-06-23 06:55:27.240824
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import pytest
    from galaxylib.galaxy_role import GalaxyRoleInfo
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    def load(data):
        if PY3:
            data = to_bytes(data, errors='surrogate_or_strict')
        rmd = RoleMetadata().load_data(data, loader=None)
        return rmd

    def test_dependencies(data):
        rmd = load(data)
        assert len(rmd.dependencies) == 1
        assert len(rmd.dependencies[0]) == 2
        assert rmd.dependencies[0][0] == '*'
        assert isinstance(rmd.dependencies[0][1], GalaxyRoleInfo)

# Generated at 2022-06-23 06:55:30.356279
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = False
    role.dependencies = ['role1', 'role2']
    assert role.serialize() == {
        'allow_duplicates': False,
        'dependencies': ['role1', 'role2']
    }

# Generated at 2022-06-23 06:55:35.790245
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolemd = RoleMetadata()
    setattr(rolemd, 'allow_duplicates', True)
    deps = ["common", "webserver"]
    setattr(rolemd, 'dependencies', deps)
    serialized_data = rolemd.serialize()
    assert serialized_data == dict(allow_duplicates=True, dependencies=deps)

# Generated at 2022-06-23 06:55:46.574630
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    class TestData(object):
        ds = dict(
            allow_duplicates=True,
            dependencies=[
                dict(name='another-role', src='/path/to/another-role'),
                dict(name='my-role', src='/path/to/my-role')
            ],
            galaxy_info={},
            argument_specs={}
        )

    test_play = Play()
    test_play.name = "test"
    test_play.path = "test"

    test_role = Role()
    test_role._play = test_play
    test_role._role_path = "/path/to/test-role"
    test_role.name = "test-role"
    test

# Generated at 2022-06-23 06:55:49.912455
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata, RoleMetadata)
    assert isinstance(role_metadata.allow_duplicates, bool)
    assert isinstance(role_metadata.dependencies, list)

# Generated at 2022-06-23 06:55:54.687206
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    constructor test
    '''
    try:
        RoleMetadata()
    except NameError:
        print('test_RoleMetadata: constructor test FAILURE')
    else:
        print('test_RoleMetadata: constructor test SUCCESS')



# Generated at 2022-06-23 06:56:00.197609
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    path = "../test/test_collections/testns/testcoll_v0.1.0/roles/test"
    role = RoleInclude.load(path, loader=None)
    var = VariableManager()
    var.get_vars(loader=None, play=None)
    m = RoleMetadata(role).load_data(role.metadata, variable_manager=var)
    assert m._allow_duplicates is False
    assert len(m._dependencies) is 2
    assert m._dependencies[0].get_name() == 'test1'
    assert m._dependencies[1].get_name() == 'test2'



# Generated at 2022-06-23 06:56:02.511894
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # test no error
    try:
        RoleMetadata()
        assert 1 == 1
    except Exception as e:
        raise e

# Generated at 2022-06-23 06:56:15.049499
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    pb = PlayContext()
    inv_manager = InventoryManager(pb)
    var_manager = VariableManager(pb, inv_manager)
    from ansible.playbook.role.definition import RoleDefinition
    role_path = '../../tests/fixtures/roles/role_include'
    rd = RoleDefinition(name='iam_role', paths=role_path)
    meta = RoleMetadata(owner=rd)
    meta = meta.load(role_path + "/meta/main.yml", rd, var_manager)
    assert type(meta.dependencies) == list
    assert meta.dependencies[0].role.name == "common"
   

# Generated at 2022-06-23 06:56:15.844847
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert metadata is not None

# Generated at 2022-06-23 06:56:19.165244
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': True,
            'dependencies': ['other1', 'other2']}
    r = RoleMetadata()
    r.deserialize(data)
    assert(r.allow_duplicates)
    assert(r.dependencies == ['other1', 'other2'])

# Generated at 2022-06-23 06:56:28.357897
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    a = RoleMetadata()
    a.allow_duplicates = False
    a.dependencies = [ {'name': 'common'},
                       {'role': 'foo', 'tasks_from': 'main.yml'} ]
    a_dict = a.serialize()
    assert isinstance(a_dict, dict)
    assert a_dict['allow_duplicates'] == a.allow_duplicates
    assert a_dict['dependencies'] == [{'name': 'common'}, {'role': 'foo', 'tasks_from': 'main.yml'}]


# Generated at 2022-06-23 06:56:29.765346
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    raise NotImplementedError()

# Generated at 2022-06-23 06:56:38.585163
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    data = m.serialize()
    if data.get('allow_duplicates') != False:
        raise AssertionError("Unexpected value for allow_duplicates: %s" % data.get('allow_duplicates'))
    if data.get('dependencies') != None:
        raise AssertionError("Unexpected value for dependencies: %s" % data.get('dependencies'))
    if data.get('_dependencies') != None:
        raise AssertionError("Unexpected value for _dependencies: %s" % data.get('_dependencies'))

# Generated at 2022-06-23 06:56:45.464732
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Owner:
        _role_path = None

    owner = Owner()
    data = {'allow_duplicates': False, 'dependencies': ["role1", "role2"]}

    def load_list_of_roles_mock(role_data, play, current_role_path, variable_manager, loader, collection_search_list):
        return [role_data[0], role_data[1]]

    r = RoleMetadata(owner)
    r.load_list_of_roles = load_list_of_roles_mock
    r.deserialize(data)

    assert hasattr(r, 'allow_duplicates')
    assert hasattr(r, 'dependencies')
    assert r.allow_duplicates is False
    assert r.dependencies == ["role1", "role2"]

# Generated at 2022-06-23 06:56:50.699576
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata = RoleMetadata()
    roleMetadata.allow_duplicates = False
    roleMetadata._dependencies = ["foo", "bar"]
    serializedData = roleMetadata.serialize()
    assert serializedData["allow_duplicates"] == False
    assert serializedData["dependencies"] == ["foo", "bar"]


# Generated at 2022-06-23 06:57:00.012102
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.tasks import RoleTasks
    from ansible.playbook.role.handlers import RoleHandlers
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.play import Play

    play_info = dict(
        roles=[]
    )
    play = Play().load(play_info, variable_manager=None, loader=None)

    owner_role_name = 'role_1'
    owner_main_file

# Generated at 2022-06-23 06:57:00.603564
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-23 06:57:09.836893
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    loader = None
    variable_manager = None

    # item_1
    item_1 = {'role': 'certificates'}
    role_definition_item_1 = RoleDefinition.load(item_1, variable_manager=variable_manager, loader=loader)
    assert isinstance(role_definition_item_1, RoleDefinition)

    # debug("role_definition_item_1.serialize() = {}".format(role_definition_item_1.serialize()))

    # item_2
    item_2 = {
        'role': 'certificates',
        'vars': {'foo': 'bar'}
    }

# Generated at 2022-06-23 06:57:14.557408
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Unit test for class RoleMetadata.
    '''

    r = RoleMetadata()
    test_dict = {'allow_duplicates': True}
    r.deserialize(test_dict)
    assert r.allow_duplicates == True

# Generated at 2022-06-23 06:57:30.105853
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role

    rolename = "role_name"
    rolepath = "/tmp/RoleMetadata/" + rolename
    os.mkdir(rolepath)
    file = open(rolepath + "/meta/main.yml", "w")
    dependency = "dependency1"
    dependency2 = "dependency2"

# Generated at 2022-06-23 06:57:37.512343
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata_instance = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['common']}
    print(type(data))
    print(type(RoleMetadata_instance.deserialize(data)))
    print(type(RoleMetadata_instance.deserialize(data)['dependencies']))
    print(type(RoleMetadata_instance.deserialize(data)['dependencies'][0]))

if __name__ == '__main__':
    test_RoleMetadata_deserialize()

# Generated at 2022-06-23 06:57:41.924876
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm = RoleMetadata()
    setattr(rm, 'allow_duplicates', True)
    assert rm.serialize() == dict(
        allow_duplicates=True,
        dependencies=[]
    )


# Generated at 2022-06-23 06:57:47.071123
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata(owner='owner')
    setattr(role_meta, 'allow_duplicates', False)
    setattr(role_meta, 'dependencies', [])
    assert role_meta.serialize() ==  dict(
            allow_duplicates=False,
            dependencies=[]
        )


# Generated at 2022-06-23 06:57:49.483487
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata.load({}, owner=None)
    result = role_metadata.serialize()
    assert result == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 06:57:58.079290
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        "allow_duplicates": False,
        "dependencies": [
            {
                "collection": "ansible_namespace.collection_name",
                "name": "test_role"
            }
        ]
    }

    metaRole = RoleMetadata()
    metaRole.deserialize(data)

    assert(metaRole.allow_duplicates == False)
    assert(metaRole.dependencies[0].name == "test_role")
    assert(metaRole.dependencies[0].collection == "ansible_namespace.collection_name")


# Generated at 2022-06-23 06:58:00.220422
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """Unit test for method deserialize of class RoleMetadata"""
    pass

# Generated at 2022-06-23 06:58:11.030071
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    meta_main_yml_content = '''
galaxy_info:
  author: Jeffery Chang
  description: An Ansible role to install nginx.
  company: None
  license: MIT
  min_ansible_version: 1.2
  platforms:
    - name: EL
      versions:
        - 7
dependencies: []
'''

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    data = AnsibleLoader(meta_main_yml_content, 'nonfile', variable_manager=VariableManager()).get_single_

# Generated at 2022-06-23 06:58:16.992933
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    data = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar']
    )
    rd = RoleDefinition.load({'name': 'role1'})
    rm = RoleMetadata(rd)
    rm.deserialize(data)
    assert rm.serialize() == data


# Generated at 2022-06-23 06:58:25.847163
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import os
    import copy
    import sys
    import warnings
    import six
    import pytest
    from ansible.playbook import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleParserError, AnsibleUndefinedVariable
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.template import Templar

    if PY3:
        unicode = str

    class VariableManager(object):

        def __init__(self):

            self._extra_vars = {}
            self._host_vars = {}
            self._group_

# Generated at 2022-06-23 06:58:29.484318
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = {'allow_duplicates': 'True', 'dependencies': ['aiohttp']}
    role = RoleMetadata()
    role.deserialize(metadata)


# Generated at 2022-06-23 06:58:40.276596
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-23 06:58:42.855783
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates='True',
        dependencies='test'
    )
    RoleMetadata().deserialize(data)

# Generated at 2022-06-23 06:58:50.480623
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ds = dict(
        allow_duplicates=True,
        dependencies=['geerlingguy.foo', 'bar']
    )
    m = RoleMetadata()
    m.deserialize(ds)
    assert m.allow_duplicates == True
    assert len(m.dependencies) == 2
    assert m.dependencies[0] == 'geerlingguy.foo'
    assert m.dependencies[1] == 'bar'


# Generated at 2022-06-23 06:58:54.465430
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = False
    dependencies = []
    role_metadata._dependencies = dependencies
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': dependencies}



# Generated at 2022-06-23 06:58:58.453108
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    assert role_metadata.argument_spec == {}
    assert role_metadata.galaxy_info == None


# Generated at 2022-06-23 06:59:03.890314
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Setup test
    role = {'allow_duplicates': 'allowed', 'dependencies': [{'role': 'some.thing', 'name': 'some_name'}]}
    metadata = RoleMetadata()
    # Execute the code to be tested
    metadata.deserialize(role)
    # Verify the results
    assert(metadata._allow_duplicates == 'allowed')
    assert(metadata._dependencies[0] == {'role': 'some.thing', 'name': 'some_name'})

# Generated at 2022-06-23 06:59:13.196445
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.module_utils._text import to_bytes
    import ansible.constants as C

    C.DEFAULT_ROLES_PATH = to_bytes("roles")

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    dependencies_file = os.path.join(cur_dir, '../../../test/unit/playbook/block/meta/files/deps')
    role_dependencies = RoleInclude.load(dependencies_file)

    assert(len(role_dependencies) == 2)

    data = {
        "dependencies": ["test1", "test2"]
    }

    assert(data["dependencies"] == [str(i) for i in role_dependencies])

# Generated at 2022-06-23 06:59:25.605735
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    role = Role(name='testrole', role_definition=RoleDefinition(name='testrole', role_path=os.path.dirname(os.path.realpath(__file__)) + '/../../../../../test/sanity/roles/testrole')).load_data(dict(),variable_manager=dict(),loader=dict())
    role_meta = RoleMetadata(role)
    assert role_meta.allow_duplicates == False, "RoleMetadata allow_duplicates set to False by default"
    assert role_meta.dependencies == [], "RoleMetadata dependencies empty by default"
    #TODO: test _load_dependencies



# Generated at 2022-06-23 06:59:31.425580
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    mm = RoleMetadata()
    data = {}
    mm.deserialize(data)
    assert mm.allow_duplicates == False
    assert mm.dependencies == []

    data['allow_duplicates'] = True
    data['dependencies'] = ['foo', 'bar']
    mm.deserialize(data)
    assert mm.allow_duplicates == True
    assert mm.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 06:59:36.008509
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    role_meta.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert hasattr(role_meta, 'allow_duplicates')
    assert hasattr(role_meta, 'dependencies')

# Generated at 2022-06-23 06:59:44.804937
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.collection.collection import Collection

    rd = RoleDefinition.load({'name': 'foo'}, collection=Collection('ansible_namespace.test_collection'), collection_list=['ansible_namespace.test_collection'])
    r = RoleMetadata(owner=rd)
    assert rd == r._owner
    assert isinstance(r._dependencies, list)
    assert r._dependencies == []
    assert isinstance(r._allow_duplicates, bool)
    assert r._allow_duplicates is False

# Generated at 2022-06-23 06:59:47.457516
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata().get_allow_duplicates() == False
    assert RoleMetadata().get_dependencies() == []
    assert RoleMetadata().get_galaxy_info() == {}

# Generated at 2022-06-23 06:59:53.871153
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    role.dependencies = ["test_role_1", "test_role_2"]
    assert role.serialize() == {'allow_duplicates': True, 'dependencies': ['test_role_1', 'test_role_2']}


# Generated at 2022-06-23 07:00:03.480562
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.module_utils.six import string_types
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    role_metadata=RoleMetadata()
    role_metadata.deserialize({'allow_duplicates':False, 'dependencies':['user']})
    assert role_metadata.allow_duplicates==False
    assert type(role_metadata.dependencies[0])==RoleDefinition
    assert type(role_metadata.dependencies[0].name)==string_types
    assert role_metadata.dependencies[0].name=='user'
    return "Successfully tested RoleMetadata method deserialize"

if __name__ == "__main__":
    print(test_RoleMetadata_deserialize())

# Generated at 2022-06-23 07:00:08.863294
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata = RoleMetadata()
    roleMetadata._allow_duplicates = True
    roleMetadata._dependencies = ['role_one', 'role_two']

    assert roleMetadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role_one', 'role_two']}


# Generated at 2022-06-23 07:00:20.528775
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import tempfile
    import os
    import shutil
    import yaml
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.playbook.role_include import RoleInclude

    # create a role
    role_def = dict(
        name='somename',
        dependencies=['some.collection.role.dependency']
    )
    role_name = 'some.collection.some_name'
    collection_dir = None

# Generated at 2022-06-23 07:00:23.581426
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    role_metadata = RoleMetadata.load({'a': 1, 'b': 2}, owner={ '_role_path': '/a/b/c' }, variable_manager=None, loader=None)

# Generated at 2022-06-23 07:00:31.271568
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Constructor of class RoleMetadata
    '''
    data = dict(
        allow_duplicates=False,
        dependencies=[
            dict(
                name="apache",
                src="https://github.com/leucos/ansible-role-apache",
                scm="git",
                version="v1.0"),
            dict(
                name="webserver",
                src="https://github.com/geerlingguy/ansible-role-apache.git",
                scm="git")])


# Generated at 2022-06-23 07:00:38.000215
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    # create a role
    role = RoleDefinition.load(dict(name="test"), play=Play().load(dict(name="fake", hosts=['localhost'])))

    # populate some data into the metadata
    data = dict(dependencies=[ { 'role': 'common' } ])

    # create the metadata object
    meta = RoleMetadata(owner=role)

    # load the data into the metadata object
    meta.load(data)

    assert meta.dependencies[0].get_name() == "common"

# Generated at 2022-06-23 07:00:48.879411
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """ test the RoleMetadata.load method"""

    def mock_RoleInclude(role_def):
        return role_def

    RoleInclude = mock_RoleInclude
    try:
        FakeRole = namedtuple("FakeRole", ["_role_path"])
    except NameError:
        FakeRole = lambda *args: tuple(args)

    from ansible.playbook.collectionsearch import CollectionSearch
    CollectionSearch.search_in_collections = lambda _: None

    # fake role path (must end with role_name)
    fake_path = "/some/path/foo"

    # fake role
    fake_role = FakeRole(fake_path)

    # fake role dependencies
    fake_dependencies = [{"role1": "1.0"}, {"role2": "2.0"}, "role3"]

    # fake meta

# Generated at 2022-06-23 07:00:54.837143
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert r.serialize() == { 'allow_duplicates': False, 'dependencies': [] }

# Generated at 2022-06-23 07:00:57.348072
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert load_list_of_roles is not None
    assert RoleRequirement is not None
    assert RoleRequirement.role_yaml_parse is not None

# Generated at 2022-06-23 07:01:07.426516
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    _dependencies = [{'src': 'git+https://github.com/TheLocehiliosan/yadt.git'}, {'src': 'git+https://github.com/TheLocehiliosan/yadt.git'}]
    _meta = {'galaxy_info': {'author': 'ZhigangSun', 'description': 'A sample of ansible galaxy info for testing', 'license': 'BSD', 'min_ansible_version': '2.4', 'platforms': [{'name': 'Unix'}], 'role_name': 'yadt', 'version': '1.0'}, 'allow_duplicates': True, 'dependencies': _dependencies}
    # test serialize
    roleMetadata = RoleMetadata()
    roleMetadata.load_data(_meta)
    _

# Generated at 2022-06-23 07:01:08.105992
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-23 07:01:17.670622
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print("Running unit test for method deserialize of class RoleMetadata")
    # Create instance without calling __init__ - we don't need it.
    meta = RoleMetadata.__new__(RoleMetadata)
    assert meta.allow_duplicates == None, "allow_duplicates not initialized"
    assert meta.dependencies == None, "dependencies not initialized"
    data = {'allow_duplicates': True, 'dependencies': ['role1', 'role2', 'role3']}
    meta.deserialize(data)
    assert meta.allow_duplicates == True, "allow_duplicates not True"
    assert meta.dependencies == ['role1', 'role2', 'role3'], "dependencies are wrong"
    print("Unit test for method deserialize of class RoleMetadata: Success")



# Generated at 2022-06-23 07:01:19.448460
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner="dummy")
    assert m


# Generated at 2022-06-23 07:01:25.469126
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_obj = RoleMetadata()
    role_metadata_obj.allow_duplicates = True
    role_metadata_obj.dependencies = ['apache-webserver']
    data = role_metadata_obj.serialize()
    expected_data = {'allow_duplicates': True, 'dependencies': ['apache-webserver']}
    assert data == expected_data


# Generated at 2022-06-23 07:01:28.954804
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_obj = RoleMetadata()
    role_metadata_obj.deserialize(dict(allow_duplicates=True, dependencies=[]))
    assert role_metadata_obj.serialize() == dict(allow_duplicates=True, dependencies=[])

# Generated at 2022-06-23 07:01:32.237844
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_data = dict(
        allow_duplicates=True,
        dependencies=['a', 'b']
    )
    role_metadata = RoleMetadata()

    role_metadata.deserialize(test_data)

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['a', 'b']

# Generated at 2022-06-23 07:01:32.827428
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize()


# Generated at 2022-06-23 07:01:41.220464
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            "galaxy.role1,version,name",
            "galaxy.role2,version,name",
        ]
    )
    role = RoleMetadata()
    role.deserialize(data)
    assert role.allow_duplicates == data['allow_duplicates']
    assert len(role.dependencies) == len(data['dependencies'])
    for i in range(len(role.dependencies)):
        assert role.dependencies[i] == data['dependencies'][i]

# Generated at 2022-06-23 07:01:44.784274
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    Test if the class constructor can accept a play and create the
    RoleMetadata object.
    """
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 07:01:45.385778
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:01:52.887100
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()

# Generated at 2022-06-23 07:02:01.446321
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from collections import namedtuple
    class Role(object):
        def __init__(self, name, path):
            self.name = name
            self.path = path
            self.implicit = False
    RoleInclude = namedtuple('RoleInclude', ['role', 'implicit'])
    class Playbook(object):
        pass
    class Collection(object):
        def __init__(self, name):
            self.name = name
    class CollectionSearch(object):
        def __init__(self):
            self.collections = ["fake_collection.fake_collection_role"]
    class VariableManager(object):
        def __init__(self):
            self.host_vars = {}
            self.groups = {}
            self.extra_vars = {}

# Generated at 2022-06-23 07:02:10.996734
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # test deserialization of a role with no metadata
    role = RoleMetadata()
    role.deserialize(None)
    assert role.allow_duplicates is False
    assert isinstance(role.dependencies, list)
    assert len(role.dependencies) == 0
    assert isinstance(role.galaxy_info, dict)
    assert len(role.galaxy_info) == 0

    # test deserialization with a role with metadata
    role_metadata = {'allow_duplicates': True, 'dependencies': [{'src': 'test_role_1'}, {'src': 'test_role_2'}]}
    role.deserialize(role_metadata)
    assert role.allow_duplicates is True
    assert isinstance(role.dependencies, list)

# Generated at 2022-06-23 07:02:15.341784
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar']
    )
    m = RoleMetadata()
    m.deserialize(data)
    assert m.allow_duplicates == True
    assert m.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 07:02:28.066040
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    role = RoleInclude()
    role.name = 'common'
    role.collections = ['namespace.collection']

    role_req = RoleRequirement()
    role_req.name = 'common'
    role_req.collections = ['namespace.collection']



# Generated at 2022-06-23 07:02:38.899379
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.loader import DataLoader
    from ansible.vars.manager import VariableManager

    test_data = dict(
        allow_duplicates=False,
        dependencies=['foo.bar', 'foo.baz']
    )

    loader = DataLoader()
    variable_manager = VariableManager()
    path = os.path.join("test", "data", "role_meta_data")
    role = RoleDefinition('foo', path, "test", None, loader, variable_manager)
    role_metadata = RoleMetadata(role)
    role_metadata.deserialize(test_data)

    assert role_metadata.allow_duplicates == False
    assert len(role_metadata.dependencies) == 2

# Generated at 2022-06-23 07:02:43.551334
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(allow_duplicates=False, dependencies=[])
    result = RoleMetadata().deserialize(data)
    assert result.allow_duplicates == data['allow_duplicates']
    assert result.dependencies == data['dependencies']

# Generated at 2022-06-23 07:02:52.547470
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    s = r.serialize()
    assert s == dict(
        allow_duplicates=False,
        dependencies=[]
    )

    # Allow duplicates
    r.allow_duplicates = True
    s = r.serialize()
    assert s == dict(
        allow_duplicates=True,
        dependencies=[]
    )

    # Dependencies
    r.dependencies = [{"role": "common"}]
    s = r.serialize()
    assert s == dict(
        allow_duplicates=True,
        dependencies=[{"role": "common"}]
    )

# Generated at 2022-06-23 07:02:56.229047
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.role import Role
    r = Role()
    m = RoleMetadata(r)
    assert m._owner == r
    assert m._allow_duplicates == False
    assert m._dependencies == list
    assert m._galaxy_info == None
    assert m._argument_specs == dict


# Generated at 2022-06-23 07:03:04.034116
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies']     = []
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._dependencies == []


# Generated at 2022-06-23 07:03:14.389495
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = 'allow_duplicates'
    role_metadata._dependencies = 'dependencies'
    role_metadata._galaxy_info = 'galaxy_info'
    role_metadata._argument_specs = 'argument_specs'

    data = role_metadata.serialize()
    assert data.get('allow_duplicates') == 'allow_duplicates'
    assert data.get('dependencies') == 'dependencies'



# Generated at 2022-06-23 07:03:19.045389
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['1', '2'],
        galaxy_info=None,
        argument_specs=None,
    )
    r.deserialize(data)
    assert r.serialize() == data

# Generated at 2022-06-23 07:03:23.639323
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    obj.deserialize({'allow_duplicates': False})
    obj.deserialize({'dependencies': []})
    assert hasattr(obj, 'allow_duplicates')
    assert hasattr(obj, 'dependencies')


# Generated at 2022-06-23 07:03:32.827964
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-23 07:03:34.998348
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata.deserialize(dict(allow_duplicates=True, dependencies=['foo'])) == dict(allow_duplicates=True, dependencies=['foo'])

# Generated at 2022-06-23 07:03:40.215307
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolem = RoleMetadata(owner=None)
    # MetaData(allow_duplicates=False, dependencies=[])
    assert rolem.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-23 07:03:49.904853
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    import json
    import os

    """
    Test serialize of class RoleMetadata
    """
    # Test serialize of class RoleMetadata
    role_path = "./test/units/playbook/roles/test_role_meta"
    role = Role.load(role_path)
    role_meta = role.metadata
    role_meta_dict = role_meta.serialize()
    assert isinstance(role_meta_dict, dict)
    assert 'allow_duplicates' in role_meta_dict
    assert 'dependencies' in role_meta_dict
    assert role_meta_dict['allow_duplicates'] == False
    assert role_meta_dict['dependencies'] == []

# Generated at 2022-06-23 07:04:02.877811
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data_dict = {'allow_duplicates': True, 'dependencies': [{'role': 'example_role', 'version': '2.0'}, {'role': 'other_role', 'version': '1.0'}]}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data_dict)
    assert role_metadata.allow_duplicates == True
    assert len(role_metadata.dependencies) == 2
    assert type(role_metadata.dependencies) == list
    assert role_metadata.dependencies[0]['role'] == 'example_role'
    assert role_metadata.dependencies[0]['version'] == '2.0'
    assert role_metadata.dependencies[1]['role'] == 'other_role'

# Generated at 2022-06-23 07:04:13.040818
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader._collection_finder import get_collection_paths
    from ansible.utils.collection_loader._collections_finder import get_collections_loader

    sample_role_name = 'nginx'
    sample_role_path = '../../../../../lib/galaxy/collection_mock/ansible_collections/' + sample_role_name + '/' + sample_role_name
    sample_role_def = RoleDefinition(role_name=sample_role_name, role_path=sample_role_path)
    role_metadata = RoleMetadata(owner=sample_role_def)
    role_metadata_serialize_ref = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_

# Generated at 2022-06-23 07:04:24.999946
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role
    import ansible.playbook.role.include

    role = ansible.playbook.role.Role()
    role._role_path = '/path/role'

    class Loader(object):
        def get_real_file(self, filename):
            return filename

    vars = {}
    loader = Loader()

    # best case: dependencies exist
    ds = {'dependencies': [
        'nameA',
        {'role': 'nameB', 'foo': 'bar'},
        {'role': 'nameC'},
        {'role': 'nameD', 'when': 'True'},
    ]}
    try:
        role_metadata = RoleMetadata.load(ds, role, vars, loader)
    except AnsibleParserError as e:
        assert False

# Generated at 2022-06-23 07:04:29.505147
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block

    m = RoleMetadata()
    m._dependencies = [ RoleInclude.load(dict(name="test", tasks=[]), Block()) ]
    m._allow_duplicates = True

    data = m.serialize()
    assert data['allow_duplicates'] == True
    assert len(data['dependencies']) == 1


# Generated at 2022-06-23 07:04:33.678117
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_RoleMetadata = RoleMetadata()
    assert test_RoleMetadata._allow_duplicates is False
    assert test_RoleMetadata._dependencies == []
    assert test_RoleMetadata._galaxy_info is None
    assert test_RoleMetadata._argument_specs == {}

# Generated at 2022-06-23 07:04:45.278797
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata.
    '''

    data = dict(
        dependencies=dict(
            Galaxy=dict(
              src="git+https://github.com/Leapp-to/galaxy-role-server.git"
            )
        )
    )

    from ansible.playbook.role import Role

    role = Role()
    role.name = 'test'
    role.validate_attributes()

    created_object = RoleMetadata.load(data, role, loader=None, variable_manager=None)
    assert isinstance(created_object, RoleMetadata)
    assert isinstance(created_object._dependencies, list)
    assert isinstance(created_object._dependencies[0], RoleRequirement)

# Generated at 2022-06-23 07:04:57.323037
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    from ansible.config.manager import ConfigManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-23 07:05:05.362020
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # serialize test
    m = RoleMetadata(owner='owner')
    m._allow_duplicates=False
    m._dependencies=['dependencies']
    m._galaxy_info=None
    m._argument_specs=None
    m.serialize()
    assert m._allow_duplicates == False
    assert m._dependencies == ['dependencies']
    assert m._galaxy_info == None
    assert m._argument_specs == None
    

# Generated at 2022-06-23 07:05:14.370610
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader.role_source.directory import RoleDirectory
    from ansible.plugins.loader.role_source.galaxy import GalaxyRole
    from ansible.plugins.loader.role_source.file import RoleFile
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()

    role_name = 'test_role'
    role_path = './tests/test_data/roles/' + role_name + '/'

# Generated at 2022-06-23 07:05:20.861874
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Make a default empty play
    play = PlayContext()

    # Make a default empty variable manager
    variable_manager = VariableManager()

    # Load a sample piece of data
    # That is a valid 'meta/main.yml' for a role whose name is 'sample_role'
    data = {
        'dependencies': [
            'role1',
            {
                'role': 'role2',
                'src': 'https://github.com/username/role2.git',
                'scm': 'git',
                'version': '1.0'
            }
        ]
    }

    # Load the data