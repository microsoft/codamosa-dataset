

# Generated at 2022-06-23 06:55:26.946135
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-23 06:55:38.538740
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    current_role_path = './test/utils/test_role_1'
    r = RoleDefinition.load({'name': 'johndoe.test_role_1'}, current_role_path)
    rmeta = RoleMetadata.load({
        'dependencies': [
            {'name': 'johndoe.test_role_2', 'meta': 'meta/main.yml'},
            {'name': 'johndoe.test_role_3'}
        ]
    }, r)
    ri = RoleInclude.load({'role': 'johndoe.test_role_4'})
    rmeta.dependencies.append(ri)

    # Convert

# Generated at 2022-06-23 06:55:45.925191
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    metadata_json = {
        'allow_duplicates': 'True',
        'dependencies': ['role1', 'role2']
    }
    metadata.deserialize(metadata_json)
    assert hasattr(metadata, 'allow_duplicates')
    assert hasattr(metadata, 'dependencies')
    assert metadata.allow_duplicates is True
    assert metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-23 06:55:55.400775
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play = Play().load({
        'name': 'myplay',
        'hosts': 'myhosts',
        'roles': [
            {
                'role': 'some.role',
            },
            'some.other-role',
            {
                'role': 'some.third-role',
                'tasks_from': 'some.tasks-file',
            },
        ]
    }, variable_manager=None, loader=None)

    m = play.get_roles()[0].metadata

    assert m is not None

    assert m._allow_duplicates is False
    assert len(m._dependencies) == 0



# Generated at 2022-06-23 06:55:58.475031
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    obj = RoleMetadata()
    obj.allow_duplicates = False
    obj.dependencies = []
    data = obj.serialize()
    assert data['allow_duplicates'] == False
    assert data['dependencies'] == []

# Generated at 2022-06-23 06:56:10.169272
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Create mock owner
    from ansible.playbook.role import Role
    mock_owner = Role()
    mock_owner.vars = {}
    mock_owner.name = 'foo'
    mock_owner.path = '/dev/null/foo'
    mock_owner._role_path = '/dev/null/foo'
    mock_owner._role_collection = 'ansible.builtin'
    mock_owner._play = 'blah'
    mock_owner.collections = ['ansible.builtin']
    # Create test data
    data = {'dependencies': [{'role': 'baz'}],
            'allow_duplicates': False}
    # Create test object
    obj = RoleMetadata(mock_owner)
    # Call load
    obj.load_data(data)
    # Load attributes

# Generated at 2022-06-23 06:56:12.513719
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rm = RoleMetadata()
    assert rm._allow_duplicates is False
    assert len(rm._dependencies) == 0

# Generated at 2022-06-23 06:56:19.229930
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test for constructor of class RoleMetadata
    '''
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    role_name = 'fake_role'
    Role_metadata = RoleMetadata()
    assert Role_metadata._allow_duplicates is None

# Generated at 2022-06-23 06:56:23.761039
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata_serialized = role_metadata.serialize()
    assert role_metadata_serialized.get('dependencies') == []
    assert role_metadata_serialized.get('allow_duplicates') == False

# Generated at 2022-06-23 06:56:27.728315
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r_metadata = RoleMetadata()
    assert r_metadata._allow_duplicates == False
    assert r_metadata._dependencies == []
    assert r_metadata._galaxy_info == {}
    assert r_metadata._argument_specs == {}

# Generated at 2022-06-23 06:56:34.064953
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext

    Play = namedtuple('Play', ['play_context', 'variable_manager'])
    Inventory = namedtuple('Inventory', ['basedir'])
    FileLoader = namedtuple('FileLoader', ['get_basedir'])
    RoleInclude = namedtuple('RoleInclude', ['name'])
    Role = namedtuple('Role', ['_role_collection'])


# Generated at 2022-06-23 06:56:40.760524
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create the test object
    obj = RoleMetadata()

    # Serialize it
    data = obj.serialize()

    # Test
    assert data == {"allow_duplicates": False, "dependencies": []}
    assert data["dependencies"] == []
    assert data["allow_duplicates"] == False



# Generated at 2022-06-23 06:56:52.519665
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    RoleMetadata: Test load()
    """
    import os
    import sys
    import tempfile
    import shutil

    try:
        from ansible.parsing.dataloader import DataLoader
    except ImportError:
        print('skipped: ansible.parsing.dataloader does not exist')
        sys.exit(0)

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes

    from ansible.playbook.play import Play

# Generated at 2022-06-23 06:57:02.989672
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Tests that serialize returns the expected dict.
    """
    from ansible.playbook.role.definition import RoleDefinition

    owner = RoleDefinition.load("test_role")
    data_dict = dict()

    role_meta = RoleMetadata(owner)
    assert role_meta.serialize() == dict(allow_duplicates=False,
                                         dependencies=[])

    data_dict['allow_duplicates'] = True
    data_dict['dependencies'] = 'test'
    role_meta._load_data(data_dict, variable_manager=None, loader=None)
    assert role_meta.serialize() == dict(allow_duplicates=True,
                                         dependencies='test')

# Generated at 2022-06-23 06:57:04.740258
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta = RoleMetadata()
    if not isinstance(role_meta, RoleMetadata):
        raise AssertionError("RoleMetadata test failed!")

# Generated at 2022-06-23 06:57:12.326644
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_name = 'test_role'
    role_path = './test/roles/ansible-role-' + role_name
    meta_file = os.path.join(role_path, 'meta/main.yml')
    role_meta = RoleMetadata.load(loader=None, variable_manager=None, owner='test_owner')


if __name__ == "__main__":
    test_RoleMetadata_load()

# Generated at 2022-06-23 06:57:15.921359
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role._allow_duplicates = True
    role._dependencies = []
    expected = dict(allow_duplicates=True, dependencies=[])
    assert role.serialize() == expected


# Generated at 2022-06-23 06:57:18.949826
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    res = RoleMetadata().deserialize({})
    assert res.get('allow_duplicates') is False
    assert res.get('dependencies') is None


# Generated at 2022-06-23 06:57:24.665885
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ds = {
        'allow_duplicates': True
    }

    try:
        m = RoleMetadata(owner=None).load_data(ds)
    except Exception as e:
        print(e)
        raise

    assert m._allow_duplicates == True

# Generated at 2022-06-23 06:57:31.768784
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm = RoleMetadata()
    setattr(rm, 'allow_duplicates', False)
    setattr(rm, 'dependencies', [])
    assert rm.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-23 06:57:37.927533
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    obj.deserialize(data={'allow_duplicates': False, 'dependencies': []})
    assert obj.allow_duplicates == False and obj.dependencies == []
    obj.deserialize(data={'allow_duplicates': True, 'dependencies': [{'name':'test-role', 'src': 'test-role'}]})
    assert obj.allow_duplicates == True

# Generated at 2022-06-23 06:57:48.300796
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data_to_test = {
        'allow_duplicates': False,
        'dependencies': [],
        'galaxy_info': GalaxyInfo(),
    }

    test_role_metadata = RoleMetadata()
    test_role_metadata.deserialize(data_to_test)

    attr_allow_duplicates = getattr(test_role_metadata, '_allow_duplicates')
    attr_dependencies = getattr(test_role_metadata, '_dependencies')
    attr_galaxy_info = getattr(test_role_metadata, '_galaxy_info')

    assert data_to_test['allow_duplicates'] == attr_allow_duplicates
    assert data_to_test['dependencies'] == attr_dependencies

# Generated at 2022-06-23 06:57:59.769301
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager


# Generated at 2022-06-23 06:58:02.538505
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        RoleMetadata()
    except Exception as e:
        assert False, "Failed to instantiate object: " + str(e)

# Generated at 2022-06-23 06:58:07.938061
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    assert m.serialize() == dict(allow_duplicates=False, dependencies=[])
    m = RoleMetadata(owner=None)
    assert m.serialize() == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-23 06:58:12.571226
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    my_metadata = RoleMetadata()
    my_metadata.allow_duplicates = 1
    my_metadata.dependencies = [{"src": "git+https://github.com/example/test"}, {"src": "https://github.com/example/test.tar.gz"}]

    res = my_metadata.serialize()
    assert res.get("allow_duplicates") == 1
    assert res.get("dependencies") == my_metadata.dependencies

# Generated at 2022-06-23 06:58:22.241265
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.errors import AnsibleParserError
    from ansible.playbook.role import Role
    import os
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.path import unfrackpath

    role = Role()

    yaml_data = '''---
    allow_duplicates: False
    dependencies:
    - { role: apache, when: ansible_os_family == 'RedHat' }
    - { role: apache2, when: ansible_os_family == 'Debian' }
    '''

    basedir = os.path.join(unfrackpath(os.path.dirname(__file__)), 'fixtures', 'metadata', 'role1')

# Generated at 2022-06-23 06:58:26.403989
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_obj = RoleMetadata()
    actual_result = role_metadata_obj.serialize()
    expected_result = {'allow_duplicates': False, 'dependencies': []}
    assert actual_result == expected_result

# Generated at 2022-06-23 06:58:30.649205
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    loader = AnsibleLoader(None)

# Generated at 2022-06-23 06:58:35.950848
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = ['one']
    result = role_metadata.serialize()
    assert result == {
        'allow_duplicates': False,
        'dependencies': ['one']
    }


# Generated at 2022-06-23 06:58:41.716147
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test loading of galaxy meta/main.yml file
    data = {'galaxy_info': {'author': 'Example Author'}}
    owner = Mock()
    owner.get_name.return_value = 'TestRole'
    assert RoleMetadata.load(data, owner).galaxy_info.author == 'Example Author'


# Generated at 2022-06-23 06:58:42.725579
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass


# Generated at 2022-06-23 06:58:54.552910
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import copy
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    ds = {
        'allow_duplicates': False,
        'dependencies': [
            'role1',
            'role2',
            {'role': 'role3', 'vars': {'a': 'b'}},
            {'role': 'role4'},
            {'role': '/path/to/role5'}
        ]
    }

    obj = RoleMetadata(owner=None).load_data(ds, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:58:56.700984
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rl = RoleMetadata()
    assert isinstance(rl, RoleMetadata)
    assert isinstance(rl._dependencies, list)
    assert isinstance(rl._argument_specs, dict)

# Generated at 2022-06-23 06:58:59.205593
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    obj = RoleMetadata(owner=None)
    serialized = obj.serialize()
    assert isinstance(serialized, dict)
    assert isinstance(serialized, object)



# Generated at 2022-06-23 06:59:03.119460
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': True,
            'dependencies': ['common', 'webservers']}
    role_meta = RoleMetadata().deserialize(data)
    assert role_meta
    assert role_meta.allow_duplicates is True
    assert role_meta.dependencies == ['common', 'webservers']

# Generated at 2022-06-23 06:59:09.588932
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata().load(dict(
        allow_duplicates=True,
        dependencies=[{'role': 'common', 'name': 'geerlingguy.java'}, {'role': 'web', 'name': 'geerlingguy.apache'}],
        galaxy_info={'namespace': 'bob', 'name': 'foo'},
    ), None)
    assert m.allow_duplicates
    assert len(m.dependencies) == 2
    assert isinstance(m.galaxy_info, dict)


# Generated at 2022-06-23 06:59:11.296928
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """Unit test for constructor of class RoleMetadata"""
    metadata = RoleMetadata()
    assert(metadata)

# Generated at 2022-06-23 06:59:20.850189
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    import ansible.constants as C

    # arbitrary values for testing
    hosts = ['localhost', '127.0.0.1']
    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_context.network_os = 'Linux'
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'

# Generated at 2022-06-23 06:59:31.876749
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.collectionsearch import CollectionSearch
    from ansible.playbook.collections import CollectionsLoader

    data = '''
        allow_duplicates: True
        dependencies:
          - src: "ansible.posix"
            name: "geerlingguy.repo-epel"
        argument_specs:
          foo:
            description: for foo
          bar:
            description: for bar
            default: baz
    '''

    loader = CollectionsLoader()

# Generated at 2022-06-23 06:59:39.438207
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class _Role(object):
        def __init__(self):
            self._role_path = "path"
            self._role_collection = None
            self._play = None
            self.name = "test"
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    role = _Role()
    role_meta = RoleMetadata.load(data, role)
    assert role_meta.allow_duplicates == False
    assert not role_meta.dependencies

# Generated at 2022-06-23 06:59:45.011773
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_exclude import RoleExclude

    m = RoleMetadata()

# Generated at 2022-06-23 06:59:53.553829
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role

    ds_role_meta = dict(
        allow_duplicates=False,
        dependencies=dict(
            name=dict(
                src='path/to/role',
                version=1.2
            ),
            name2=dict(
                name='path/to/role',
                version='1.3'
            ),
        )
    )

# Generated at 2022-06-23 07:00:00.655219
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role

    data = dict(
        allow_duplicates=False,
        dependencies=list()
    )
    role_metadata_object = RoleMetadata.load(data=data, owner=ansible.playbook.role.Role())
    assert role_metadata_object.allow_duplicates == False
    assert role_metadata_object.dependencies == list()
    assert role_metadata_object._owner == ansible.playbook.role.Role()
    assert isinstance(role_metadata_object, RoleMetadata)

# Generated at 2022-06-23 07:00:01.174650
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:00:03.177356
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta = {}
    assert RoleMetadata.load(meta, None)

# Generated at 2022-06-23 07:00:08.181571
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    result = '''allow_duplicates is type of <class 'bool'> with value "False"
dependencies is type of <class 'list'> with value "[]"'''
    metadata = RoleMetadata()
    res = metadata.serialize()
    assert result == str(res)


# Generated at 2022-06-23 07:00:11.090928
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['A.role', 'B.role']
    )
    role_meta.deserialize(data)
    assert role_meta._allow_duplicates == True
    assert role_meta._dependencies[0] == 'A.role'
    assert role_meta._dependencies[1] == 'B.role'

# Generated at 2022-06-23 07:00:11.862180
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-23 07:00:16.141139
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    mocked_ds = {'allow_duplicates': False, 'dependencies': []}
    obj = RoleMetadata()
    obj.deserialize(mocked_ds)
    assert obj._allow_duplicates == False
    assert obj._dependencies == []

# Generated at 2022-06-23 07:00:25.339183
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import pytest
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from io import BytesIO

    # the role we're going to use to exercise loading
    role_name = 'test-role-has-deps'
    role_path = '/tmp/' + role_name

    # the test playbook

# Generated at 2022-06-23 07:00:26.922051
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    assert meta.serialize


# Generated at 2022-06-23 07:00:28.462788
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-23 07:00:31.923773
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    owner = 'test'
    data = dict(
        dependencies=[{'role': 'geerlingguy.nfs'}],
        allow_duplicates=True,
    )
    serialized_data = RoleMetadata.load(data, owner).serialize()
    assert serialized_data == data

# Generated at 2022-06-23 07:00:36.532579
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata
    r.deserialize(r, data={"allow_duplicates": True, "dependencies": ["foo", "bar"]})
    assert r.allow_duplicates is True
    assert r.dependencies == ["foo", "bar"]



# Generated at 2022-06-23 07:00:45.489941
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class DummyRole(object):
        def __init__(self, name, role_path):
            self.name = name
            self._role_path = role_path

    role = DummyRole('testrole', '/test/testrole')

    metadata = RoleMetadata(owner=role)

    metadata.allow_duplicates = True
    metadata.dependencies = [{"role": "test", "name": "test"}, "test"]

    assert metadata.serialize() == {"allow_duplicates": True, "dependencies": [{"role": "test", "name": "test"}, "test"]}

# Generated at 2022-06-23 07:00:55.701755
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    d = dict(
        allow_duplicates='FALSE',
        dependencies=dict(
            role=['my.dependency']
        )
    )
    m = RoleMetadata.load(d)
    assert m.allow_duplicates == False
    assert m.dependencies is not None
    assert len(m.dependencies) == 1
    assert m.dependencies[0].get_name() == 'my.dependency'

# Generated at 2022-06-23 07:01:02.450802
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    RoleMetadata.serialize unit test
    '''
    from ansible.playbook.role import Role
    from ansible.playbook.role.metadata import RoleMetadata
    role = Role.load({}, None)
    role_meta = RoleMetadata(role)
    # Case 1: Check normal serialize
    serialize_result = role_meta.serialize()
    assert role_meta._allow_duplicates == serialize_result['allow_duplicates']
    assert role_meta._dependencies == serialize_result['dependencies']
    # Case 2: Check json serialize
    json_serialize_result = role_meta.serialize(to_json=True)
    assert json_serialize_result is not None
    # Case 3: Check safe_eval serialize
    safe_eval_result = role

# Generated at 2022-06-23 07:01:14.318657
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.collectionsearch import CollectionSearch

    # test with argument data as not a dict
    data = []
    owner = []
    try:
        RoleMetadata.load(data, owner)
        assert False
    except AnsibleParserError:
        assert True

    # test when arg owner is None
    data = {}
    owner = None
    m = RoleMetadata.load(data, owner)
    assert m is not None
    assert isinstance(m, RoleMetadata)
    assert isinstance(m, CollectionSearch)

    # test it when arguments are all valid
    data = {"a": "b"}
    owner = []
    m = RoleMetadata.load(data, owner)
    assert m is not None
    assert isinstance(m, RoleMetadata)
    assert isinstance(m, CollectionSearch)


# Generated at 2022-06-23 07:01:26.496020
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    playbook = dict(
        name="test_playbook.yml",
        hosts=["localhost"],
        user="bob",
        gather_facts="no",
        roles=[
            dict(role="name_of_role")
        ]
    )
    role = dict(
        name="name_of_role",
        foo="bar"
    )
    role_metadata = RoleMetadata(role)
    assert role_metadata._name == "name_of_role"
    assert role_metadata._data == {}
    assert role_metadata._dependencies == []
    assert role_metadata._owner == role
    assert role_metadata._galaxy_info == {}
    assert role_metadata._allow_duplicates == False
    assert role_metadata._argument_specs == {}



# Generated at 2022-06-23 07:01:26.936445
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:01:32.550828
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """Test RoleMetadata.serialize().

    This testcase tests the serialize method of the RoleMetadata class.
    """
    metadata = RoleMetadata()
    setattr(metadata, 'allow_duplicates', False)
    setattr(metadata, 'dependencies', [])

    assert metadata.serialize() == {'allow_duplicates': False,
                                    'dependencies': []}

# Generated at 2022-06-23 07:01:35.298883
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    assert role.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 07:01:43.594121
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_dict = {'tasks': {'task': 'test_task'}, 'vars': {'var': 'test_var'}, 'handlers': {'handlers': 'test_handler'}}
    test_role = RoleMetadata()
    test_role.load(test_dict, owner=None)
    test_role.get_dependencies()
    test_role.get_vars()
    test_role.get_tasks()
    test_role.get_handlers()
    test_role.serialize()
    test_role.deserialize(test_dict)

# Generated at 2022-06-23 07:01:49.426256
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role

    my_play = Play().load({'name': 'test play', 'hosts': ['all'], 'roles': []})
    my_play_context = PlayContext()
    role_metadata = RoleMetadata(owner=Role(play=my_play, play_context=my_play_context)).deserialize({})
    assert role_metadata.allow_duplicates == False

# Generated at 2022-06-23 07:01:58.038922
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    role = Role()
    role._role_path = "/tmp/role"

    metadata = RoleMetadata()
    metadata.load({'dependencies': [{'role': 'geerlingguy.nodejs'}]}, owner=role)

    assert isinstance(metadata, RoleMetadata) == True
    assert isinstance(metadata.dependencies[0], TaskInclude) == True

# Generated at 2022-06-23 07:02:03.257696
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    role = RoleMetadata(owner=r)
    assert role.dependencies == []
    assert role.allow_duplicates == False
    assert role._owner == r

# Generated at 2022-06-23 07:02:11.803553
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    # Test with valid data.
    data = dict()
    data['verion'] = 1
    data['allow_duplicates'] = True
    data['dependencies'] = list()
    data['dependencies'].append(RoleDefinition(
        'foo',
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        '/path/to/foo'
    ))
    meta = RoleMetadata(None)
    result = meta.load(data, None)

    assert(result._allow_duplicates == True)

# Generated at 2022-06-23 07:02:16.661093
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    import ansible.constants as C

    ansible.constants.HOST_KEY_CHECKING = False

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=['myhost'])
    variable

# Generated at 2022-06-23 07:02:24.143739
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    rd = RoleDefinition()
    rd.name = "testrole"
    rd.role_path = "/tmp/ansible-test/roles"

    rolemeta = RoleMetadata()
    rolemeta.allow_duplicates = False
    rolemeta.dependencies = [{"name": "testrole1"}, {"name": "testrole2", "version": "1.0.0"}]
    rolemeta.owner = rd

    serialize_data = rolemeta.serialize()

    assert serialize_data['allow_duplicates'] == False
    assert serialize_data['dependencies'] == [{"name": "testrole1"}, {"name": "testrole2", "version": "1.0.0"}]


# Generated at 2022-06-23 07:02:25.267849
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert metadata is not None

# Generated at 2022-06-23 07:02:29.597574
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    meta.deserialize({'allow_duplicates': False, 'dependencies': ['test', 'test2']} )
    assert meta._allow_duplicates == False
    assert meta._dependencies == ['test', 'test2']

# Generated at 2022-06-23 07:02:40.912403
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Make some fake module_utils so collection loads don't go network.
    os.makedirs(os.path.join('test/fixtures/collections', 'fake_col'))
    os.makedirs(os.path.join('test/fixtures/collections', 'fake_col', 'fake_ns'))
    os.makedirs(os.path.join('test/fixtures/collections', 'fake_col', 'fake_ns', 'test'))
    os.makedirs(os.path.join('test/fixtures/collections', 'fake_col2'))
    os.makedirs(os.path.join('test/fixtures/collections', 'fake_col2', 'fake_ns'))

# Generated at 2022-06-23 07:02:46.483915
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolemeta = RoleMetadata()
    rolemeta.allow_duplicates = True
    rolemeta.dependencies = ['common', 'webservers']
    res = rolemeta.serialize()

    assert 'allow_duplicates' in res and res['allow_duplicates'] == True
    assert 'dependencies' in res
    assert 'common' in res['dependencies']
    assert 'webservers' in res['dependencies']

# Generated at 2022-06-23 07:02:51.406908
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': []}
    deserialized_data = metadata.deserialize(data)

    assert deserialized_data is not None
    assert deserialized_data.get('allow_duplicates') == True
    assert deserialized_data.get('dependencies') == []

# Generated at 2022-06-23 07:02:59.371838
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.collection import RoleCollection

    # load normal role meta
    obj = RoleMetadata(owner=Role.load({'role': 'test', 'name': 'test'},
                                       variable_manager=None, loader=None))
    obj.load({
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'test1', 'name': 'test1'},
            {'role': 'test2', 'name': 'test2'},
        ],
    }, variable_manager=None, loader=None)

    assert obj._allow_duplicates
    assert len(obj._dependencies) == 2 and isinstance(obj._dependencies[0], Role)

    # load collection role meta

# Generated at 2022-06-23 07:03:13.107786
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.warnings import RoleWarning
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.meta import RoleMetadata
    class MyClass():
        pass

    my_dict = dict(
        allow_duplicates=True,
        dependencies=[]
    )


    def_1 = {}
    def_1['role'] = 'geerlingguy.java'
    def_1['tasks_from'] = 'main.yml'

    def_2 = {}
   

# Generated at 2022-06-23 07:03:24.283234
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.block import Block
    from ansible.playbook.helpers import load_list_of_roles

    m = RoleMetadata()
    m.deserialize(data={'allow_duplicates': True,
                        'dependencies': []})

    assert m._allow_duplicates is True
    assert m._dependencies == []

    m.deserialize(data={'allow_duplicates': False,
                        'dependencies': []})

    assert m._allow_duplicates is False
    assert m._dependencies == []

    m.deserialize(data={'allow_duplicates': False,
                        'dependencies': ['foo', 'bar']})

    assert m._allow_duplicates is False
    assert m._dependencies == ['foo', 'bar']


# Generated at 2022-06-23 07:03:33.012403
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rolemetadata = RoleMetadata(owner=None)
    assert rolemetadata._allow_duplicates == False, 'rolemetadata._allow_duplicates should be False'
    assert rolemetadata._dependencies == [], 'rolemetadata._dependencies should be []'

# Generated at 2022-06-23 07:03:35.626800
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class_RoleMetadata = RoleMetadata()
    class_RoleMetadata.allow_duplicates =  None
    class_RoleMetadata.dependencies =  None
    serialize_role_metadata = class_RoleMetadata.serialize()
    assert serialize_role_metadata == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 07:03:39.708853
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    assert m.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-23 07:03:45.370787
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test for method deserialize( data)
    # Ensures that the deserialize method of RoleMetadata works correctly
    des = RoleMetadata()
    deserialize_data = {'allow_duplicates': True}
    des.deserialize(deserialize_data)
    if des.allow_duplicates != True:
        raise AssertionError()



# Generated at 2022-06-23 07:03:47.395273
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ri = RoleMetadata(None)
    assert ri._allow_duplicates == False
    assert ri._dependencies == []

# Generated at 2022-06-23 07:03:52.020606
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    role_meta.deserialize({"allow_duplicates": False, "dependencies": []})
    assert role_meta.allow_duplicates == False
    assert role_meta.dependencies == []

# Generated at 2022-06-23 07:03:52.780191
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-23 07:03:59.066287
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m._dependencies = [{'role': 'foo'}, {'role': 'bar'}, {'role': 'baz'}]

    assert m.serialize() == dict(dependencies=[{'role': 'foo'}, {'role': 'bar'}, {'role': 'baz'}],
                                 allow_duplicates=False)

# Generated at 2022-06-23 07:04:06.600337
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role

    role = Role()
    role.name = 'test-role'
    metadata = RoleMetadata(owner=role)

    metadata.allow_duplicates = True
    metadata.dependencies = [
        {'role': 'foo'},
        {'role': 'bar', 'series': 'trusty'},
        RoleInclude.load(data='baz', owner=role)
    ]
    assert metadata.allow_duplicates is True
    assert isinstance(metadata.dependencies, list)
    assert len(metadata.dependencies) == 3

# Generated at 2022-06-23 07:04:08.106575
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Not implemented
    pass



# Generated at 2022-06-23 07:04:15.932206
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    class _Role:
        pass

    _role = _Role()

    _metadata = RoleMetadata(owner = _role)
    _metadata.deserialize({'allow_duplicates': True, 'dependencies': [u'role1', u'role2']})

    assert _metadata.allow_duplicates

    assert len(_metadata.dependencies) == 2
    assert _metadata.dependencies[0] == u'role1'
    assert _metadata.dependencies[1] == u'role2'

# Generated at 2022-06-23 07:04:23.073045
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.name import RoleName

    current_role = RoleName()

    data = { 'allow_duplicates': False, 'dependencies': [] }

    role_metadata = RoleMetadata(owner=current_role)
    role_metadata.deserialize(data)
    assert(role_metadata.allow_duplicates == False)
    assert(role_metadata.dependencies == [])
    assert(role_metadata.owner == current_role)

# Generated at 2022-06-23 07:04:34.789892
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata

    role = RoleDefinition.load({'name': 'geerlingguy.docker'})

    metadata = RoleMetadata.load(
        {
            'dependencies': [
                {'role': 'geerlingguy.docker'},
                {'role': 'geerlingguy.java'},
                {'role': 'geerlingguy.repo-remi'},
                {'role': 'geerlingguy.nginx'},
                {'role': 'geerlingguy.php'},
                {'role': 'geerlingguy.composer'}
            ]
        },
        role
    )

    assert metadata is not None

    assert metadata._dependencies[0].get_

# Generated at 2022-06-23 07:04:43.033185
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ds = dict(
        dependencies = [
            {'role': 'geerlingguy.apache'},
            {'role': 'username.rolename', 'version': '1.8.1'},
            "username.rolename,1.8.1",
            "username.rolename"
        ]
    )
    role_metadata = RoleMetadata(owner=None)
    role_metadata._load_dependencies(None, ds=ds['dependencies'])

    print (role_metadata.__dict__)



# Generated at 2022-06-23 07:04:47.382310
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    data = role_metadata.serialize()
    assert data == dict(allow_duplicates=False, dependencies=[])
    role_metadata = RoleMetadata(owner=object())
    data = role_metadata.serialize()
    assert data == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-23 07:04:54.226072
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    ri = RoleInclude()
    assert ri._role_name == None
    assert ri._role_collection == None
    assert ri._role_path == None
    assert ri._role_params == {}
    assert ri._role_collections == None


# Generated at 2022-06-23 07:05:03.447231
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class fake_class(object):
        def __init__(self, name):
            self.name = name
    setattr(fake_class, 'get_name', lambda x: x.name)


# Generated at 2022-06-23 07:05:09.332654
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta_path = "/home/ivan/Desktop/Ansible-Playbooks/sample/roles/docker/meta/main.yml"
    with open(meta_path, "r") as meta_file:
        document = yaml.safe_load(meta_file)

# Generated at 2022-06-23 07:05:16.214721
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    dependencies = "my_dependencies"
    data = {'dependencies':dependencies}
    m = RoleMetadata()
    m.deserialize(data)
    assert isinstance(m, RoleMetadata)
    assert m.dependencies == dependencies
    assert m.allow_duplicates== False

# Generated at 2022-06-23 07:05:20.645372
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata = RoleMetadata.load(data, None)
    assert role_metadata.allow_duplicates == data['allow_duplicates']
    assert role_metadata.dependencies == data['dependencies']

# Generated at 2022-06-23 07:05:31.467156
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
