

# Generated at 2022-06-23 06:55:36.991635
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    dependencies = [
        {
            'role': 'geerlingguy.apache',
            'collection': 'geerlingguy.collection',
            'name': 'apache'
        },
        {
            'role': 'geerlingguy.apache2',
            'collection': 'geerlingguy.collection',
            'name': 'apache2'
        }
    ]

    test_data = dict(
        allow_duplicates=False,
        dependencies=dependencies
    )

    role_metadata = RoleMetadata()
    role_metadata.deserialize(test_data)

    assert role_metadata.serialize() == test_data

# Generated at 2022-06-23 06:55:40.266602
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({'allow_duplicates': 'True'})
    assert m.allow_duplicates == True

# Generated at 2022-06-23 06:55:44.414955
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    r.name = "test"
    m = RoleMetadata(owner=r)
    assert r.name == m._owner.name


# Generated at 2022-06-23 06:55:48.083491
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role()
    role.name = 'test'
    role._role_path = './tests/units/playbook/role_include/roles/test'
    assert isinstance(RoleMetadata(role), RoleMetadata)

# Generated at 2022-06-23 06:55:53.641588
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize(dict(allow_duplicates=True, dependencies=[]))
    assert m.allow_duplicates
    assert not len(m.dependencies)

# Generated at 2022-06-23 06:55:58.232958
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Setup
    data = {'dependencies': [{'role': 'role1'},{'role': 'role2'}]}

    role_metadata=RoleMetadata()
    role_metadata.deserialize(data)

    # Verify
    assert role_metadata.dependencies == [{'role': 'role1'},{'role': 'role2'}]

# Generated at 2022-06-23 06:55:58.773747
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 06:56:02.992509
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Testing method load of class RoleMetadata
    m = RoleMetadata()
    o = open("../../../../../test/ansible_collections/ansible/builtin/meta/main.yml")
    assert m.load(yaml.safe_load(o),m)

# Generated at 2022-06-23 06:56:12.150141
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    ds = dict(
        meta = dict(
            dependencies=dict(
                galaxy=dict(
                    some_key='some_val',
                )
            )
        )
    )
    role_metadata.deserialize(ds)
    result = role_metadata.serialize()
    assert result == dict(
        allow_duplicates = False,
        dependencies = dict(
            galaxy = dict(
                some_key = 'some_val',
            ),
        ),
    )

# Generated at 2022-06-23 06:56:19.718687
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    my_play = Play()
    my_play.hosts = "all"
    my_play.become = True
    my_play.become_method = "sudo"
    my_play.become_user = "root"

# Generated at 2022-06-23 06:56:28.936993
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Success case
    rmd1 = RoleMetadata()
    rmd1_data = {'allow_duplicates': False, 'dependencies': ['role1', 'role2']}
    rmd1.load(rmd1_data)
    assert rmd1_data == rmd1.serialize()

    # Failure case
    rmd2 = RoleMetadata()
    rmd2_data = 'meta/main.yml of role role_name is not a dictionary'
    try:
        rmd2.load(rmd2_data)
    except Exception:
        assert True
    else:
        assert False



# Generated at 2022-06-23 06:56:33.728396
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    data = role_metadata.serialize()
    # expected results
    expected_data = {
        "allow_duplicates": False,
        "dependencies": []
    }
    assert data == expected_data



# Generated at 2022-06-23 06:56:39.512699
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata(owner=None)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    assert role_metadata.galaxy_info == None
    assert role_metadata.argument_specs == {}
    assert role_metadata._owner == None
    assert role_metadata._variable_manager == None
    assert role_metadata._loader == None

# Generated at 2022-06-23 06:56:45.551739
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role

    role = Role()
    rmd = RoleMetadata(owner=role)

    ret = rmd.deserialize({})
    assert ret == dict(allow_duplicates=False, dependencies=[])

    ret = rmd.deserialize({'allow_duplicates': True, 'dependencies': ['role1']})
    assert ret == dict(allow_duplicates=True, dependencies=['role1'])

# Generated at 2022-06-23 06:56:48.409650
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.module_utils._text import to_text

    options_dict = {"allow_duplicates":False, "dependencies":[]}
    r = RoleMetadata(owner=None)
    r.deserialize(options_dict)
    result = r.serialize()
    assert type(result) == type(options_dict)
    assert result == options_dict
    assert to_text(result, errors='surrogate_then_replace') == to_text(options_dict, errors='surrogate_then_replace')

# Generated at 2022-06-23 06:56:49.964114
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Just test that the method is implemented
     assert RoleMetadata(owner='ansible.legacy').serialize()

# Generated at 2022-06-23 06:56:54.785869
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    x = RoleMetadata(owner=None)
    assert x is not None
    assert x._allow_duplicates == False
    assert x._dependencies == []

    x.allow_duplicates = True
    assert x.allow_duplicates == True


# Generated at 2022-06-23 06:57:00.686869
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()

    setattr(role_metadata, 'allow_duplicates', True)
    setattr(role_metadata, 'dependencies', ['a', 'b', 'c'])

    result = role_metadata.serialize()

    assert result == dict(
        allow_duplicates=True,
        dependencies=['a', 'b', 'c']
    )



# Generated at 2022-06-23 06:57:06.653903
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class Play:
        def __init__(self):
            self.name="Some Play"

    class Role:
        def __init__(self, name):
            self.play = Play()
            self.name = name

    # test no dependency
    role_meta = RoleMetadata(owner=Role("my role"))
    print(role_meta)
    print(role_meta.serialize())

# Generated at 2022-06-23 06:57:18.676475
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Unit test for RoleMetadata.serialize.
    """
    f = RoleMetadata()

    # Test when allow_duplicates is not specified (default is False)
    f._dependencies.append(dict(src='test', name='test'))
    assert dict(allow_duplicates=False, dependencies=[dict(src='test', name='test')]) == f.serialize()

    # Test when allow_duplicates is specified
    f.allow_duplicates = True
    assert dict(allow_duplicates=True, dependencies=[dict(src='test', name='test')]) == f.serialize()

if __name__ == "__main__":
    test_RoleMetadata_serialize()

# Generated at 2022-06-23 06:57:19.786223
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta = RoleMetadata()
    assert role_meta is not None

# Generated at 2022-06-23 06:57:30.162093
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    r = RoleMetadata(owner=None)
    r = RoleMetadata.load(dict(allow_duplicates=False, dependencies=list()), owner=None)
    r = RoleMetadata()
    r.dependencies = [RoleInclude()]
    r.allow_duplicates = True

# Generated at 2022-06-23 06:57:35.299357
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    testdata = dict(
        allow_duplicates=True,
        dependencies=['geerlingguy.apache'],
    )
    metadata.deserialize(testdata)
    assert metadata.allow_duplicates
    assert metadata.dependencies == ['geerlingguy.apache']


# Generated at 2022-06-23 06:57:42.804653
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert r.serialize() == {'allow_duplicates': False, 'dependencies': []}

    setattr(r, 'allow_duplicates', True)
    setattr(r, 'dependencies', ['a.b.c', 'd.e.f'])
    assert r.serialize() == {'allow_duplicates': True, 'dependencies': ['a.b.c', 'd.e.f']}

# Generated at 2022-06-23 06:57:46.947586
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(allow_duplicates=False, dependencies=[])
    m = RoleMetadata(owner='owner')
    m.deserialize(data)
    assert m.allow_duplicates == False
    assert m.dependencies == []

# Generated at 2022-06-23 06:57:57.121782
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    import yaml

    host = Host('host1')
    play = Play().load(dict(
        name = "Ansible Play for Redis",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            dict(
                role = 'test1',
                tasks = [
                    dict(
                        action=dict(
                            module='shell',
                            args='/bin/echo "Hello World"'
                        ),
                    ),
                ]
            )
        ],
    ), variable_manager=VariableManager(), loader=None)

    variable

# Generated at 2022-06-23 06:58:07.018103
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    path = os.path.dirname(os.path.realpath(__file__))
    yaml_path = path + '/../../../../test/sanity/integration/inventory_overrides/'
    fname = yaml_path + 'junk/meta/main.yml'
    with open(fname, 'r') as yaml_file:
        import yaml
        data = yaml.load(yaml_file)

        # create object
        r = RoleMetadata()
        r.load(data)

        assert r.allow_duplicates is True

# Generated at 2022-06-23 06:58:08.832534
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(
        data=dict(
            allow_duplicates=False,
            dependencies=[],
        )
    )

# Generated at 2022-06-23 06:58:14.845233
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_obj = RoleMetadata()
    data = dict(allow_duplicates=False, dependencies=[])
    ansible_dict = test_obj.deserialize(data)
    assert ansible_dict == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-23 06:58:24.358830
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role

    # initialize play
    ROLE_NAME = 'test_role'
    PLAY_NAME = 'test_play'
    ROLE_PATH = '/path/to/test_role'
    play_context = PlayContext(play=PLAY_NAME)
    play_context.vars = {'some_var': 'foo'}
    play_context.prompt = 'bar'
    # play_context.vault_password = 'baz'

    # initialize role
    role_definition = {}
    role_definition[ROLE_NAME] = {'hosts': 'all'}
    role_metadata = RoleMetadata(owner=Role(ROLE_PATH, ROLE_NAME, play_context, role_definition))

   

# Generated at 2022-06-23 06:58:36.845833
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    class MockRole(Role):
        # only a subset of the class, we are not testing Role itself here
        class _methods(object):
            def parse_file(self, *args, **kwargs):
                return {'hello': 'world'}

            def __getattr__(self, name):
                def _mock_parse_file(self, *args, **kwargs):
                    return {name: True}
                return _mock_parse_file

        def __init__(self, *args, **kwargs):
            self._

# Generated at 2022-06-23 06:58:46.617355
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    class FakeRole(object):
        def __init__(self):
            pass

    class FakePlay(object):
        def __init__(self):
            pass

    class FakeVariableManager(object):
        def __init__(self, hostvars=None):
            self.hostvars = hostvars

    data = dict(
        name="test-role",
        dependencies=["role1", "role2"],
        some_other_key="something else"
    )

    role = FakeRole()
    play = FakePlay()
    role.name = "test-role"
    role._play = play
    role._role_path = "/some/path/to/role/test-role"
    owner = FakeRole()
    owner._play = play

# Generated at 2022-06-23 06:58:54.328262
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'dependencies': [
            {'role': 'content', 'name': 'apache'}
        ]
    }
    m = RoleMetadata()
    m.deserialize(data)
    assert m._dependencies == [
        {'role': 'content', 'name': 'apache'}
    ]
    assert m.allow_duplicates == False
    assert m._dependencies == [
        {'role': 'content', 'name': 'apache'}
    ]
    assert m._dependencies[0].allow_duplicates == False

# Generated at 2022-06-23 06:58:58.329786
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    role_obj = RoleDefinition()
    role_metadata_obj = RoleMetadata(role_obj)
    data = {}
    role_metadata_obj.deserialize(data)
    assert data

# Generated at 2022-06-23 06:59:08.946882
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # constructor of class RoleMetadata
    role_metadata=RoleMetadata()
    # parameter 'owner' is not None and is not instance of playbook.base.Base
    assert not role_metadata._load_galaxy_info('galaxy_info', {'role_name':'apache'})
    # parameter 'dependencies' is not list
    assert not role_metadata._load_dependencies('dependencies', False)
    # parameter 'data' is not instance of dict
    assert not role_metadata.load(False, 'owner')
    # parameter 'data' is instance of dict
    assert isinstance(role_metadata.load({'role_name':'apache'}, {'role_name':'apache'}), RoleMetadata)
    # parameter 'variable_manager' is not None and 'loader' is not None

# Generated at 2022-06-23 06:59:19.572490
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create object
    r = RoleMetadata()

    # Check defaults
    assert r.allow_duplicates is False
    assert r.dependencies == []
    assert r.galaxy_info is None
    assert r.argument_specs == {}

    # Set values
    r.allow_duplicates = True
    r.dependencies = ['some_dependency']
    r.galaxy_info = {'some': 'galaxy', 'info': 'here'}
    r.argument_specs = {'some': 'argument', 'specs': 'here'}

    # Verify values
    assert r.allow_duplicates is True
    assert r.dependencies == ['some_dependency']
    assert r.galaxy_info == {'some': 'galaxy', 'info': 'here'}
    assert r.argument

# Generated at 2022-06-23 06:59:30.885381
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import ROLE_CACHE
    from ansible.playbook.role.definition import RoleDefinition

    ROLE_CACHE.clear()
    role_path = 'path-to-role'
    role_name = 'test-role'

    role_dep_src = 'src-to-role'

    role_dep_name = 'test-role-dep'
    role_dep_path = 'path-to-role-dep'

    role_meta_data = {
        'allow_duplicates': False,
        'dependencies': [role_dep_src]
    }

    role_dep_data = {
        'allow_duplicates': False,
        'dependencies': []
    }


# Generated at 2022-06-23 06:59:42.801658
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement

    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                name='test',
                src='test',
                version='1.0.0'
            ),
            dict(
                name='test2',
                src='test2',
                version='2.0.0'
            )
        ]
    )

    my_role_meta = RoleMetadata()
    my_role_meta.deserialize(data)

    assert my_role_meta.allow_duplicates == True
    assert my_role_meta.dependencies == data['dependencies']
    assert isinstance(my_role_meta.dependencies[0], RoleRequirement)


# Generated at 2022-06-23 06:59:50.000278
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    data2 = dict(
        allow_duplicates=False,
        dependencies=["role1", "role2"]
    )
    r = RoleMetadata()
    r.deserialize(data)
    assert (r.allow_duplicates == True)
    assert (r.dependencies == [])
    r.deserialize(data2)
    assert (r.allow_duplicates == False)
    assert (r.dependencies == ["role1", "role2"])

# Generated at 2022-06-23 06:59:59.731242
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    #Test to check serialize method when data is set to none
    assert RoleMetadata(owner=None).serialize() == {"allow_duplicates": False, "dependencies": []}
    #Test to check serialize method setattr works
    role_metadata = RoleMetadata(owner=None)
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'name': 'test-role'}]
    assert role_metadata.serialize() == {"allow_duplicates": True, "dependencies": [{'name': 'test-role'}]}

# Generated at 2022-06-23 07:00:05.033917
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert r.serialize() == dict(allow_duplicates=False, dependencies=[])

    r._allow_duplicates = True
    r._dependencies = [1, 2, 3]
    assert r.serialize() == dict(allow_duplicates=True, dependencies=[1,2,3])


# Generated at 2022-06-23 07:00:16.679078
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    m = RoleMetadata()
    m.deserialize({'foo': 'bar'})
    assert m._allow_duplicates == False
    assert m._dependencies == []

    m = RoleMetadata()
    m.deserialize({'allow_duplicates': True})
    assert m._allow_duplicates == True
    assert m._dependencies == []

    m = RoleMetadata()
    m.deserialize({'dependencies': ['a.b.c']})
    assert m._allow_duplicates == False
    assert m._dependencies == ['a.b.c']

    m = RoleMetadata()
    p = Play()
    p._load_included_file = lambda: True

# Generated at 2022-06-23 07:00:24.085285
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    rd = RoleDefinition()
    rd._role_name = 'test_role'
    rm = RoleMetadata(owner=rd)
    rm.dependencies = [{'role': 'common'}, {'role': 'webservers', 'name': 'nginx'}]
    rm.allow_duplicates = True

    assert rm.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'common'}, {'role': 'webservers', 'name': 'nginx'}]}


# Generated at 2022-06-23 07:00:26.212943
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()


# Generated at 2022-06-23 07:00:29.694888
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # This is a test for constructor of class RoleMetadata
    test_data = {}
    owner = None
    r = RoleMetadata(owner)
    assert r._allow_duplicates is False
    assert r._dependencies == []

# Generated at 2022-06-23 07:00:40.898419
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # create mock object
    class MockObj:
        data = {
            'allow_duplicates': False,
            'dependencies': [
                {
                    'role': 'common',
                    'collection': 'my_collection'
                }
            ]
        }

    # create mock functions
    class MockClass:
        def __init__(self):
            pass

        def __setattr__(self, name, value):
            if name == '_loader':
                self.loader = value
                return
            if name == '_variable_manager':
                self.variable_manager = value
                return
            if name == '_owner':
                self.owner = value
                return
            self.__dict__[name] = value


# Generated at 2022-06-23 07:00:50.536116
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.playbook import Playbook

    # Set the arguments
    myplaybook = Playbook()
    myplaybook.vars = dict(foo='bar')
    myplaybook._basedir = '/usr/local/ansible'

    myplay = Play()
    myplay._file_name = '/usr/local/ansible/playbooks/foo.yml'

# Generated at 2022-06-23 07:00:56.481945
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    role = RoleDefinition('name')
    role.role_path = '/path/to/role'

    metadata = RoleMetadata.load(
        dict(dependencies=['role1', 'role2']),
        owner = role
    )
    assert metadata._dependencies == ['role1', 'role2']
    assert metadata._owner == role


# Generated at 2022-06-23 07:01:01.225291
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import json
    from ansible.playbook.role.definition import RoleDefinition
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    metadata = RoleMetadata()
    metadata.deserialize(data)
    assert metadata.serialize() == data
    print(json.dumps(metadata.serialize(), indent=4))

# unit test
if __name__ == "__main__":
    test_RoleMetadata_deserialize()

# Generated at 2022-06-23 07:01:09.434415
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # create a mock object
    mock_ds_obj = dict(allow_duplicates=True, dependencies=['role1', 'role2'])
    mock_owner = object()
    mock_variable_manager = object()
    mock_loader = object()

    # create an instance of LoaderModule using the mock class
    role_metadata = RoleMetadata(owner=mock_owner).load(mock_ds_obj, variable_manager=mock_variable_manager, loader=mock_loader)

    # test serialize method of RoleMetadata
    assert role_metadata.serialize() == dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )

# Generated at 2022-06-23 07:01:14.365699
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    rmd._allow_duplicates = True
    rmd._dependencies = [1,2,3,4,5]
    rmd._owner = None

    assert rmd.serialize() == dict(allow_duplicates=True, dependencies=[1,2,3,4,5])


# Generated at 2022-06-23 07:01:26.496258
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    from unit.mock.loader import DictDataLoader
    from unit.mock.path import mock_unfrackpath_noop
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play


# Generated at 2022-06-23 07:01:28.631598
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role_metadata = RoleMetadata(owner=RoleDefinition())
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 07:01:30.404944
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    return role_metadata

# Generated at 2022-06-23 07:01:34.781924
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta = {
        'allow_duplicates': True,
        'dependencies': []
    }

    # Test with optional owner parameter
    RoleMetadata(role_meta)

    # Test without owner parameter
    RoleMetadata(role_meta)

# Generated at 2022-06-23 07:01:39.491162
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role_serialize_actual = role.serialize()
    role_serialize_expected = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    assert role_serialize_actual == role_serialize_expected


# Generated at 2022-06-23 07:01:49.115691
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # set up a fake role to play with
    role_1 = dict(
        name='test_role_1',
        dependencies=['test_role_2']
    )
    role_2 = dict(
        name='test_role_2',
        dependencies=['test_role_3']
    )
    role_3 = dict(
        name='test_role_3',
        dependencies=['test_role_1']
    )

    data = dict(
        allow_duplicates=True,
        dependencies=[role_1, role_2, role_3]
    )

    test_role = RoleMetadata(owner=None).load(data, variable_manager=None, loader=None)
    assert test_role._allow_duplicates == True
    assert len(test_role._dependencies) == 3

# Generated at 2022-06-23 07:01:56.860249
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    my_meta = RoleMetadata()
    my_meta.allow_duplicates = True
    my_meta.dependencies = [
        {'role': 'A'},
        {'role': 'B'}
    ]
    serialized = my_meta.serialize()
    assert serialized['allow_duplicates'] == True
    assert len(serialized['dependencies']) == 2
    assert serialized['dependencies'][0]['role'] == 'A'
    assert serialized['dependencies'][1]['role'] == 'B'


# Generated at 2022-06-23 07:02:01.965865
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("test_RoleMetadata")
    meta = RoleMetadata()
    assert meta.dump() == {u'dependencies': [], u'allow_duplicates': False}

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-23 07:02:04.392736
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta_obj = RoleMetadata()
    assert role_meta_obj._allow_duplicates == False
    assert role_meta_obj._dependencies == []


# Generated at 2022-06-23 07:02:07.932982
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    role = Role()
    metadata = RoleMetadata(owner=role)

# Generated at 2022-06-23 07:02:10.579034
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.task import Task
    test_x = RoleMetadata(owner=Task())
    return test_x

# Generated at 2022-06-23 07:02:22.551928
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Load the sample role metadata
    role_meta_data = RoleMetadata.load(data='meta/main.yml', owner='com.me.test', variable_manager='ansible.utils.vars', loader='ansible.parsing.dataloader')
    # Test basic evaluation
    assert isinstance(role_meta_data, RoleMetadata) is True
    assert isinstance(role_meta_data.allow_duplicates, bool) is True
    assert isinstance(role_meta_data.dependencies, list) is True
    assert isinstance(role_meta_data.galaxy_info, str) is False
    assert role_meta_data.allow_duplicates is True
    assert role_meta_data.dependencies[0] == 'test_role'
    assert role_meta_data.galaxy_info

# Generated at 2022-06-23 07:02:26.910412
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_owner = RoleMetadata()
    test_owner_info = RoleMetadata(additional_base_paths=None, allow_duplicates=False, dependencies=[])
    assert test_owner.serialize() == test_owner_info.serialize()


# Generated at 2022-06-23 07:02:34.453088
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Ensure that deserialize will correctly set defaults for missing data
    meta1 = RoleMetadata()
    meta1.deserialize({})
    assert meta1.allow_duplicates is False
    assert meta1.dependencies == []
    
    # Ensure that deserialize will correctly set values from data
    meta2 = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'Role1'},
            {'role': 'Role2'},
            {'role': 'Role3'},
        ]
    }
    meta2.deserialize(data)
    assert meta2.allow_duplicates is True
    assert len(meta2.dependencies) == 3

# Generated at 2022-06-23 07:02:47.063622
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata.load({'allow_duplicates': True})
    assert m._allow_duplicates
    assert not m._dependencies

    m = RoleMetadata.load({'dependencies': [{"src": "git://github.com/geerlingguy/ansible-role-drupal.git",
                                             "name": "geerlingguy.drupal"}]})
    assert m._dependencies[0].get_name() == 'geerlingguy.drupal'
    assert not m._allow_duplicates

    m = RoleMetadata.load({'allow_duplicates': True,
                           'dependencies': [{"src": "git://github.com/geerlingguy/ansible-role-drupal.git",
                                             "name": "geerlingguy.drupal"}]})

# Generated at 2022-06-23 07:02:54.551582
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ''' Test constructor to create RoleMetadata object'''
    data = {
    "name": "test",
    "description": "this is a test role",
    "dependencies": [
    {
      "role": "test",
      "src": "test"
    },
    ],
    "license": "test"
  }
    play_obj = None
    variable_manager = None
    loader = None
    # create RoleMetadata object
    role = RoleMetadata(owner=play_obj).load_data(data, variable_manager=variable_manager, loader=loader)
    assert role
    # print(type(role))

# Generated at 2022-06-23 07:02:56.647367
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    role_meta = RoleMetadata()
    assert role_meta.load("a", "aa", "aaa", "aaaa") is None

# Generated at 2022-06-23 07:03:08.869962
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    c = PlayContext()
    p = Play()
    p._play_context = c

    from ansible.playbook.task_include import TaskInclude
    r = TaskInclude()
    # r._role_name = 'test_role_name'
    r._role_path = 'test_role_path'
    r._role_collection = 'test_role_collection'
    r._play = p

    m = RoleMetadata()
    m._owner = r
    print(m.serialize())

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-23 07:03:14.626365
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # inittialize the object to test
    a = RoleMetadata()
    a._allow_duplicates = True
    a._dependencies = [{'a': 'b'}]

    # returned value from serialize() should be same as the value from _serialize
    res = a.serialize()
    expected_res = dict(
        allow_duplicates=True,
        dependencies=[{'a': 'b'}]
    )
    assert res == expected_res


# Generated at 2022-06-23 07:03:25.562838
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = AnsibleCollectionLoader()
    role_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test_collections', 'test_namespace', 'test_collection1', 'roles', 'role2')
    tmp_path = "file://" + role_path
    role_def = RoleDefinition.load(tmp_path, loader)

# Generated at 2022-06-23 07:03:30.096461
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_md = RoleMetadata()
    dependencies = [{'role': 'an.ansible.role'}]
    data = {'allow_duplicates': False,
            'dependencies': dependencies}
    role_md.deserialize(data)
    assert role_md._allow_duplicates == data['allow_duplicates']
    assert role_md._dependencies == data['dependencies']

# Generated at 2022-06-23 07:03:33.851160
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(
        allow_duplicates=False,
        dependencies=['example.ntnu.no']
    ))
    serialized = role_metadata.serialize()
    assert serialized['allow_duplicates'] is False
    assert serialized['dependencies'] == ['example.ntnu.no']

# Generated at 2022-06-23 07:03:36.549893
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # init test object
    obj_RoleMetadata = RoleMetadata()
    obj_RoleMetadata.deserialize({'allow_duplicates': False, 'dependencies': []})

    # assert tests
    assert obj_RoleMetadata._allow_duplicates == False
    assert obj_RoleMetadata._dependencies == []

# Generated at 2022-06-23 07:03:41.155618
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == {}
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-23 07:03:47.049273
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    d = dict(
        allow_duplicates=True,
        dependencies=[
            {
                "role": "geerlingguy.apache",
                "name": "geerlingguy.apache"
            },
            {
                "role": "geerlingguy.php",
                "name": "geerlingguy.apache"
            },
        ],
    )
    owner = Role.load(dict(
        name="role_name",
        playbooks=["site.yml"]
    ), variable_manager=None, loader=None)
    role_meta = RoleMetadata(owner).load_data(d, variable_manager=None, loader=None)
    print(repr(role_meta.dependencies))
    assert len(role_meta.dependencies) == 2

# Generated at 2022-06-23 07:04:00.000113
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition

    data = """
    ---
    dependencies:
      - galaxy.role1
      - { role: galaxy.role2, when: 'somevar is defined' }
      - { name: galaxy.role3, other_vars: {'a': 1, 'b': 2} }
    """
    parent_role_definition = RoleDefinition.load("name", "path", data, 1)
    role_metadata = RoleMetadata.load(data, parent_role_definition)
    assert role_metadata is not None
    assert role_metadata.dependencies is not None
    assert len(role_metadata.dependencies) == 3
    assert {'role': 'galaxy.role1', 'name': 'galaxy.role1'} in role_metadata.dependencies

# Generated at 2022-06-23 07:04:01.921450
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m.allow_duplicates == False
    assert m.dependencies == []

# Generated at 2022-06-23 07:04:12.281156
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Here is a very primitive unit test to make sure that the constructor of the class RoleMetadata works.
    '''
    role = RoleMetadata()
    assert role != None

# Load test role to run the unit test

# Generated at 2022-06-23 07:04:13.600440
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata() is not None

# Generated at 2022-06-23 07:04:17.211365
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata._allow_duplicates)
    print(role_metadata._dependencies)
    print(role_metadata._galaxy_info)
    print(role_metadata._argument_specs)

# Generated at 2022-06-23 07:04:21.075210
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = True
    m.dependencies = [1, 2, 3]
    assert m.serialize() == {'allow_duplicates': True, 'dependencies': [1, 2, 3]}

# Generated at 2022-06-23 07:04:32.596126
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data1 = dict(
        allow_duplicates=metadata._allow_duplicates,
        dependencies=metadata._dependencies
    )
    data2 = dict(
        allow_duplicates=metadata._allow_duplicates,
        dependencies=metadata._dependencies
    )
    data2['dependencies'] = [1,2,3]
    # test default values
    metadata.deserialize(data1)
    assert metadata.allow_duplicates == False
    assert metadata.dependencies == []
    # test real values
    metadata.deserialize(data2)
    assert metadata.allow_duplicates == False
    assert metadata.dependencies == [1,2,3]

# Generated at 2022-06-23 07:04:44.039028
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.galaxy import GalaxyInfo

    # Test for class RoleMetadata serialize
    rmd = RoleMetadata(Role({"name": "test_role"}, "/path/to/ansible/roles/test_role"))
    rmd.allow_duplicates = True
    rmd.dependencies = RoleInclude({
        "role": "test_dep1",
        "name": "test_dep1"
    })

# Generated at 2022-06-23 07:04:49.938108
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    role_meta.deserialize("""{
            'allow_duplicates': False,
            'dependencies': []
            }""")
    assert role_meta
    print("Test for method deserialize of class RoleMetadata is passed")


# Generated at 2022-06-23 07:04:51.699944
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ro = RoleMetadata()
    assert ro.dependencies == []

# Generated at 2022-06-23 07:04:57.420204
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    os.environ["ANSIBLE_COLLECTIONS_PATHS"] = '/home/nitesh/Roles'
    role_metadata = RoleMetadata(owner='/home/nitesh/Roles/Jdoodle.jdoodle/meta/main.yml')
    print(role_metadata)


if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-23 07:05:04.202704
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create a RoleMetadata object
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['dependency1', 'dependency2']

    data = role_metadata.serialize()

    assert data == {'allow_duplicates': True, 'dependencies': ['dependency1', 'dependency2']}

# Generated at 2022-06-23 07:05:07.712819
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    print(r)
    print(r.allow_duplicates)
    print(r.dependencies)
    assert r.allow_duplicates is False
    assert r.dependencies == []


# Generated at 2022-06-23 07:05:10.995077
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create a new instance of RoleMetadata
    metadata = RoleMetadata()
    # Serialize the data
    data = metadata.serialize()
    # Assert that the data returned is a dictionary
    assert isinstance(data, dict)


# Generated at 2022-06-23 07:05:18.116538
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['hello.role']
    )

    result = RoleMetadata(owner=None).deserialize(data).serialize()

    assert result == data

if __name__ == '__main__':
    test_RoleMetadata_serialize()

# Generated at 2022-06-23 07:05:20.391529
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role

    owner = Role()
    role_metadata = RoleMetadata(owner)
    role_metadata.serialize()

# Generated at 2022-06-23 07:05:31.434009
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Prepare some test data
    data = dict(allow_duplicates=True, dependencies=["nginx", "tomcat"])

    # Construct a RoleMetadata object and call the method serialize
    role_metadata_obj = RoleMetadata.load(data, owner=None)
    serialize_actual_result = role_metadata_obj.serialize()

    # Serialize the test data to a string, then deserialize the string to a new object and call
    # the method serialize, comparate the result of this process with the actual result of the
    # method serialize
    data_serialized = ansible_serialize(data)
    data_deserialized = ansible_deserialize(data_serialized)
    role_metadata_obj2 = RoleMetadata.load(data_deserialized, owner=None)
    serialize