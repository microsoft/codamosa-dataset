

# Generated at 2022-06-23 06:55:29.172120
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-23 06:55:38.122853
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    #
    #   Read yaml file and check the variables can be loaded
    #
    meta_path = '../../../test/integration/targets/test-role-metadata/meta/main.yml'
    metadata = RoleMetadata.load(
        loader=None,
        variable_manager=None,
        data=dict(),
        owner=Role(path='../../../test/integration/targets/test-role-metadata')
    )
    assert isinstance(metadata, RoleMetadata)

# Make sure the test runs
if __name__ == '__main__':
    test_RoleMetadata_load()

# Generated at 2022-06-23 06:55:48.752078
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    data = {
        'allow_duplicates': 'false',
        'dependencies': [
            {'role': 'common', 'name': 'vnc'},
            {'role': 'webserver', 'name': 'apache2'}
        ]
    }

    r = RoleMetadata()
    r.load_data(data)
    serialized_data = r.serialize()

    assert data == serialized_data


# Unit Test for method load of class RoleMetadata

# Generated at 2022-06-23 06:55:57.252436
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block
    import ansible.constants as C

    # Test parsing of dependency with old style
    data = {}
    data['dependencies'] = [
        {'role': 'geerlingguy.example'},
        {'name': 'geerlingguy.another-example'},
        'geerlingguy.yet-another-example'
    ]
    play_context = dict(
        default_vars = dict(
            foo = 1
        ),
        passwords = dict()
    )

# Generated at 2022-06-23 06:56:08.424925
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import sys
    import unittest

    from ansible.module_utils.six import PY3, binary_type, text_type
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import cPickle as pickle

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.errors import AnsibleParserError
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-23 06:56:12.434483
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role.get_name() is None
    assert role._dependencies is not None
    assert role._allow_duplicates is not None
    assert role._galaxy_info is None
    assert role._argument_specs is not None



# Generated at 2022-06-23 06:56:19.897158
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import tempfile
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import module_loader
    from ansible.plugins.loader import role_loader
    from collections import namedtuple

    context = PlayContext()

# Generated at 2022-06-23 06:56:29.458156
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # NOTE: This function is intended for internal use only, and isn't part
    #       of the public API.
    from ansible.playbook.play import Play

    role_metadata = RoleMetadata()
    role_metadata.load(data={'dependencies': [{'role': 'name', 'version': 'v1.0'}, 'someotherrole']}, owner=Play().load({'name': 'test'}))
    assert role_metadata._dependencies[0].get_name() == 'name'
    assert role_metadata._dependencies[0].get_version() == 'v1.0'
    assert role_metadata._dependencies[1].get_name() == 'someotherrole'

# Generated at 2022-06-23 06:56:33.875989
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    rmd = RoleMetadata(Role())
    assert rmd is not None
    assert rmd.allow_duplicates is False
    assert rmd.dependencies == []

# Generated at 2022-06-23 06:56:43.321063
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    collections_loader = MockCollectionsLoader()

    with open('test/unit/utils/fixtures/meta/role_meta.yml', 'r') as f:
        data = yaml.safe_load(f)

    role_meta = RoleMetadata(collections_loader=collections_loader)
    role_meta._load_data(data)

    assert role_meta.allow_duplicates
    assert len(role_meta.dependencies) == 3
    assert role_meta.dependencies[0]._role_name == 'role1'
    assert role_meta.dependencies[0].role._role_path == 'role1'

    assert role_meta.dependencies[1]._role_name == 'role2'
    assert role_meta.dependencies[1].role._role_path == 'role2'


# Generated at 2022-06-23 06:56:44.646751
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    result = RoleMetadata().serialize()
    assert result.get('allow_duplicates') == False
    assert result.get('dependencies') == []


# Generated at 2022-06-23 06:56:49.369009
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test for successful instantiation
    my_obj = RoleMetadata(owner=None)
    assert isinstance(my_obj, RoleMetadata)

    # Test for creation with supplied args
    my_obj2 = RoleMetadata(owner=None)
    assert isinstance(my_obj2, RoleMetadata)

# Generated at 2022-06-23 06:56:52.370026
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    obj = RoleMetadata()
    assert obj.allow_duplicates is False
    assert obj.dependencies == []

# Generated at 2022-06-23 06:57:04.121841
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    a = Role(name='a')
    b = Role(name='b')
    c = Role(name='c')
    d = Role(name='d')

    assert a._metadata._owner == a
    assert not a._metadata._allow_duplicates
    assert not a._metadata._dependencies

    assert b._metadata._owner == b
    assert not b._metadata._allow_duplicates
    assert not b._metadata._dependencies

    a._metadata.allow_duplicates = True
    a._metadata.dependencies = [b, c]
    b._metadata.allow_duplicates = False
    b._metadata.dependencies = [d]

    assert a._metadata._owner == a
    assert a

# Generated at 2022-06-23 06:57:06.317083
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_dep = [{'src': 'geerlingguy.jenkins'}]
    test_dict = dict(allow_duplicates=True, dependencies=test_dep)
    test_obj = RoleMetadata().load(test_dict, owner=None)
    assert test_obj.serialize() == test_dict


# Generated at 2022-06-23 06:57:19.499038
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    assert m.serialize() == { 'allow_duplicates': False, 'dependencies': [] }
    m = RoleMetadata()
    m.dependencies = [ { 'role': 'another role' }, { 'role': 'my role' } ]
    assert m.serialize() == { 'allow_duplicates': False, 'dependencies': [ { 'role': 'another role' }, { 'role': 'my role' } ] }
    m = RoleMetadata()
    m.dependencies = [ { 'role': 'another role' }, { 'role': 'my role' } ]
    m.allow_duplicates = True

# Generated at 2022-06-23 06:57:33.225530
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.module_utils._text import to_native
    import os

    role_path = os.path.dirname(__file__)

    r = Role.load(role_path, False)
    m = RoleMetadata.load(dict(), r)

    m.deserialize({
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'name1'},
            {'role': 'name2'},
        ],
    })

    assert m.allow_duplicates == True
    assert len(m.dependencies) == 2


# Generated at 2022-06-23 06:57:43.810606
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role

    # noinspection PyTypeChecker
    RoleMetadata.load('some string', {}, DataLoader(), VariableManager())
    RoleMetadata.load({'dependencies': 'some string'}, {}, DataLoader(), VariableManager())

    role_metadata = RoleMetadata.load({'dependencies': []}, {}, DataLoader(), VariableManager())
    assert isinstance(role_metadata, RoleMetadata)
    assert role_metadata.get_dependencies() == []


# Generated at 2022-06-23 06:57:54.148329
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    mock_play = PlayContext()
    mock_play.connection = "local"
    mock_play._loader = None
    mock_play._variable_manager = None

    role = RoleInclude()
    role._play = mock_play
    role._role_name = "mock_role"
    role._role_path = '/etc/ansible'
    role._terms = []
    role.task_uuids = []
    role.tags = []
    role.collections = []

    meta = RoleMetadata()
    meta._owner = role
    meta._loader = None
    meta._variable_manager = None


# Generated at 2022-06-23 06:58:02.470607
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_path = os.path.join('test', 'roles', 'meta', 'main.yml')
    if not os.path.exists(role_path):
        # pycharm incorrectly recognizes this as an error
        role_path = os.path.join('..', 'test', 'roles', 'meta', 'main.yml')

    with open(role_path, 'r') as f:
        data = yaml.safe_load(f)
    # create a fake owner object
    class Foo:
        def __init__(self):
            self.name = 'meta'
            self.collections = []
            self._role_path = 'some path'
            self._play = None
            self._role_collection = None
            self.variables = {}
            self.default_vars = {}

    owner

# Generated at 2022-06-23 06:58:08.816235
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role_include import RoleInclude

    owner = FakeRole()

    galaxy_info = None

    dependencies = [
        RoleInclude(),
        RoleInclude()
    ]

    role_metadata = RoleMetadata(owner=owner,
                                 allow_duplicates=True,
                                 galaxy_info=galaxy_info,
                                 dependencies=dependencies)

    role_metadata.serialize()

# Generated at 2022-06-23 06:58:20.923526
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_folder = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test_data', 'roles', 'test_galaxy')
    variable_manager = VariableManager()
    loader = DataLoader()
    instance = RoleMetadata()
    instance.deserialize({'allow_duplicates': True, 'dependencies': ['role-test-galaxy']})
    assert instance.allow_duplicates is True
    assert instance.dependencies == ['role-test-galaxy']
    instance._owner = Role()
    instance._owner._role_path = os.path.join(role_folder, 'meta', 'main.yml')
    instance._owner._variable_manager = variable_manager
    instance._owner._loader = loader

# Generated at 2022-06-23 06:58:27.612411
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=list("dep")
    )
    mp = RoleMetadata()
    mp.deserialize(data)
    serialized_data = mp.serialize()
    assert serialized_data['allow_duplicates'] == False
    assert serialized_data['dependencies'] == ["dep"]

# Generated at 2022-06-23 06:58:33.278614
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Initialize the metadata dictionary
    md = dict()

    # Load the metadata dictionary into a RoleMetadata object
    role = RoleMetadata.load(md)
    assert role

    # Test serialize method
    role = role.serialize()
    assert role

    # Test deserialize method
    role = RoleMetadata.deserialize(role)
    assert role

# Generated at 2022-06-23 06:58:44.364932
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rm = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )
    rm.deserialize(data)
    assert rm.serialize() == data
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    rm.deserialize(data)
    assert rm.serialize() == data
    data['dependencies'] = 'foobar'
    assert rm.serialize() == {}
    data = dict(
        allow_duplicates=False,
        dependencies=['role1', 'role2']
    )
    rm.deserialize(data)
    assert rm.serialize() == data

# Generated at 2022-06-23 06:58:44.987681
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-23 06:58:49.783758
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.meta import RoleMetadata
    metadata = dict(
        allow_duplicates=False,
        dependencies=[
            'foo',
            'bar',
        ]
    )
    assert RoleMetadata.load(metadata, owner=None).serialize() == metadata

# Generated at 2022-06-23 06:59:00.918021
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext

    rmd = RoleMetadata()
    rmd.load_data({'allow_duplicates': False, 'dependencies': []}, variable_manager=PlayContext())
    assert not rmd.allow_duplicates
    assert not rmd.dependencies

    rmd = RoleMetadata()
    rmd.load_data({'allow_duplicates': True, 'dependencies': []}, variable_manager=PlayContext())
    assert rmd.allow_duplicates
    assert not rmd.dependencies

    rmd = RoleMetadata()

# Generated at 2022-06-23 06:59:07.006029
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class MockData(object):
        pass

    test_vars = dict()
    test_vars['allow_duplicates'] = False
    test_vars['dependencies'] = []
    test_data = MockData()

    for i in test_vars.keys():
        setattr(test_data, i, test_vars[i])

    out = RoleMetadata.serialize(test_data)

    assert out == test_vars


# Generated at 2022-06-23 06:59:17.625805
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test 0 expected OK with empty data
    # owner is not needed for this test
    owner = Role()
    rm = RoleMetadata(owner)
    rm.deserialize({})
    assert rm.allow_duplicates == False
    assert rm.dependencies == []
    #owner.deserialize()

    # Test 1 expected OK
    # owner is not needed for this test
    owner = Role()
    rm = RoleMetadata(owner)
    rm.deserialize({'allow_duplicates': 'any-bool-value', 'dependencies': 'any-dependencies-value'})
    assert rm.allow_duplicates == 'any-bool-value'
    assert rm.dependencies == 'any-dependencies-value'

    # Test 2 expected OK with empty data
    # owner is not needed for this test
    owner

# Generated at 2022-06-23 06:59:19.095778
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata)

# Generated at 2022-06-23 06:59:30.178886
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    ds = dict(
        dependencies = [
            # New style: { src: 'galaxy.role,version,name', other_vars: "here" }
            dict(src='galaxy.role,version,name', other_vars="here"),
            # Old style: 'galaxy.role,version,name'
            'galaxy.role,version,name',
            # Old style:
            dict(role='galaxy.role', name='name', version='version'),
        ]
    )

    m = RoleMetadata()
    m.load_data(ds, loader=None, variable_manager=None)
    result = m.serialize()
    jj = result
    # No assert.  Unit test passes if no exception is raised.
    return True

# Generated at 2022-06-23 06:59:42.096020
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.collections.ansible.builtin import load_collection_vars
    load_collection_vars()
    variable_manager = Role().variable_manager

# Generated at 2022-06-23 06:59:51.659234
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    # Test for deserialize a valid RoleMetadata
    data = dict(allow_duplicates=True, dependencies=[{'role': "git", 'collections': ['geerlingguy.git']}, "geerlingguy.apache"])
    role_meta.deserialize(data)
    assert role_meta.allow_duplicates is True
    assert role_meta.dependencies[0].role == "git"
    assert role_meta.dependencies[1].role == "geerlingguy.apache"
    # Test for deserialize a valid RoleMetadata with partial data
    data = dict(allow_duplicates=True)
    role_meta.deserialize(data)
    assert role_meta.allow_duplicates is True
    assert role_meta.dependencies == []

# Generated at 2022-06-23 06:59:57.438482
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None)
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = list()
    role_metadata_dict = role_metadata.serialize()
    assert role_metadata_dict == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 07:00:00.164747
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata()
    assert (isinstance(a, RoleMetadata))
    assert (a.dependencies == [])
    return True



# Generated at 2022-06-23 07:00:00.762322
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:00:05.869520
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {'dependencies': [{'role': 'common'}]}
    role_meta = RoleMetadata.load(data, owner=None, variable_manager=None, loader=None)
    assert isinstance(role_meta, RoleMetadata)
    assert role_meta._dependencies[0] == 'common'

# Generated at 2022-06-23 07:00:10.307928
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block

    # test the constructor
    import os
    role_path = os.path.join(os.getcwd(), '../', 'test/units/library/role_metadata/')
    role_def = RoleDefinition.load(role_path, name='test_role_metadata', action=None, play=None)
    assert role_def._role_name == 'test_role_metadata'
    assert role_def.name == 'test_role_metadata'
    assert isinstance(role_def.default_vars, dict)
    assert isinstance(role_def.dependencies, list)
    assert isinstance(role_def.tasks, list)


# Generated at 2022-06-23 07:00:15.816636
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    allow_duplicates = True
    dependencies = ['foo', 'bar']
    test_data = {'allow_duplicates': allow_duplicates, 'dependencies': dependencies}
    ret = RoleMetadata()
    ret.deserialize(test_data)
    assert ret._allow_duplicates == allow_duplicates
    assert ret._dependencies == dependencies


# Generated at 2022-06-23 07:00:25.364184
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    role_definition = RoleDefinition('/path/to/roles/my_role/meta/main.yml')
    role_definition.name = 'my_role'
    data = {
        "dependencies": [{
                "role": "p_nginx",
                "version": "1.9.9"
            }, {
                "role": "p_mariadb",
                "version": "1.0.2"
            }]
    }
    role_metadata = RoleMetadata.load(data, role_definition)
    assert role_metadata.dependencies[0].role == 'p_nginx'
    assert role_metadata.dependencies[0].version == '1.9.9'

# Generated at 2022-06-23 07:00:30.282401
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role._allow_duplicates = False
    role._dependencies = [{'role':'name1','version': 'version1'}, {'role':'name2','version': 'version2'},]
    data = role.serialize()
    assert data['allow_duplicates'] == False
    assert data['dependencies'] == [{'role':'name1','version': 'version1'}, {'role':'name2','version': 'version2'},]


# Generated at 2022-06-23 07:00:36.637320
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play

    # The class RoleMetadata call the class RoleInclude which call the class RoleDefinition
    block = Block()
    role = RoleDefinition.load({'role': 'test'}, play=Play().load({'name': 'test', 'hosts': 'localhost', 'gather_facts': 'no'}, variable_manager=None, loader=None), block=block)
    metadata = RoleMetadata({'role': 'test'}, play=Play().load({'name': 'test', 'hosts': 'localhost', 'gather_facts': 'no'}, variable_manager=None, loader=None), block=block)

# Generated at 2022-06-23 07:00:47.943137
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper

    playbook = Playbook.load('test/unit/output/dependency_serialize.yml')


# Generated at 2022-06-23 07:00:55.349895
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test1 = RoleMetadata()
    assert isinstance(test1, RoleMetadata)
    assert test1._allow_duplicates == False
    assert test1._dependencies == []
    assert test1._galaxy_info == None
    assert test1._argument_specs == {}

# Generated at 2022-06-23 07:01:02.320859
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Imports required for unit testing of constructor. load_data() tested separately.
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    role_definition = RoleDefinition("foo")
    role_metadata = RoleMetadata(role_definition)
    assert role_metadata._owner == role_definition
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

    role_metadata._dependencies = [RoleInclude("test_role")]
    role_metadata._galaxy_info = [{"test_galaxy_info": "test_galaxy_info_value"}]

# Generated at 2022-06-23 07:01:14.117829
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible_collections.community.general.plugins.module_utils.rbenv as rbenv
    import ansible_collections.community.general.plugins.module_utils.rhel as rhel
    import ansible_collections.community.general.plugins.module_utils.rvm as rvm
    import ansible_collections.community.general.plugins.module_utils.win_dsc as win_dsc
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.java_cert as java_cert
    import ansible_collections.network.general.plugins.module_utils.netbox as netbox
    import ansible_collections.network.general.plugins.module_utils.netconf as netconf

# Generated at 2022-06-23 07:01:19.921233
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ds = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    r = RoleMetadata(owner=None)
    r.deserialize(ds=ds)
    assert r.allow_duplicates == False
    assert r.dependencies == []

# Generated at 2022-06-23 07:01:20.542008
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:01:30.478824
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    ds = dict(
        allow_duplicates = False,
        dependencies = [
                           "role1",
                           { "name": "role2", "src": "role2" },
                           { "role": "role3", "private": "yes", "with_items": "yes" }
                       ]
        )

    p = PlayContext()
    r = Role()
    r._role_path = "/some/path"
    m = RoleMetadata(owner=r).load_data(ds, variable_manager=None, loader=None)
    assert m.serialize() == ds

# Generated at 2022-06-23 07:01:36.944256
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import ansible.playbook.role.metadata
    from ansible.playbook.role.metadata import RoleMetadata

    role_meta = RoleMetadata()

    role_meta.allow_duplicates = False
    role_meta.dependencies = []

    # serializes object to a dictionary
    role_meta_dict = role_meta.serialize()

    assert role_meta_dict == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 07:01:47.402478
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()

    # Test all arguments
    metadata.allow_duplicates = True
    metadata.dependencies = [
        dict(role='geerlingguy.jenkins', name='jenkins', version='1.9.1'),
        dict(role='geerlingguy.java', name='java', version='1.9.1')
    ]
    assert metadata.serialize() == dict(
        allow_duplicates=True,
        dependencies=[
            dict(role='geerlingguy.jenkins', name='jenkins', version='1.9.1'),
            dict(role='geerlingguy.java', name='java', version='1.9.1')
        ]
    )


# Generated at 2022-06-23 07:01:52.241400
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = 'true'
    m.dependencies = ['common', 'common']

    test = m.serialize()

    assert test == {'allow_duplicates': 'true',
        'dependencies': ['common', 'common']
    }

# Generated at 2022-06-23 07:02:01.136162
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.includes import RoleInclude

    the_play = Play().load({'name': 'foobar', 'hosts': 'all'}, variable_manager=None, loader=None)
    role = RoleInclude()

    # invalid metadata
    assert RoleMetadata.load(dict(), owner=role) is None

    # valid metadata
    assert RoleMetadata.load(dict(dependencies=dict()), owner=role)
    assert RoleMetadata.load(dict(dependencies=[dict()]), owner=role)

# Generated at 2022-06-23 07:02:05.081085
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    role_data = meta.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert role_data.allow_duplicates == True
    assert role_data.dependencies == []

# Generated at 2022-06-23 07:02:09.421440
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner={})
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = [{'name': 'new-role-dependency'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'name': 'new-role-dependency'}]}

# Generated at 2022-06-23 07:02:16.137424
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class RoleDummy(object):
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return "%s(%s)" % (self.__class__.__name__ , self.name)
        def _load_list_of_roles(self, role_defs):
            return role_defs
        def get_name(self):
            return self.name

    assert RoleMetadata.load(data=dict(), owner=RoleDummy(name="test"))

# Generated at 2022-06-23 07:02:24.186185
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    roledef = dict(
        name='test_role',
        galaxy_info=dict(),
        allow_duplicates=False,
        dependencies=['application_role', 'database_role']
    )
    role = RoleMetadata.load(roledef, dict(role_path='test_role'))
    assert not role.allow_duplicates
    assert len(role.dependencies) == 2
    assert isinstance(role.galaxy_info, dict)

# Generated at 2022-06-23 07:02:35.370965
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader

    class FakeRole(RoleDefinition):
        def __init__(self, owner, name, path, collection_name=None, collection_path=None, collection_version=None, collection_priority=None):
            super(FakeRole, self).__init__(owner, name, path)
            self.metadata_path = path

    play = FakeRole(None, name='test', path=os.path.join(role_loader.get_path(), 'test', 'meta'))

    assert RoleMetadata.load({}, play) == None

    class FakeLoader(object):
        def __init__(self, play):
            self._play = play


# Generated at 2022-06-23 07:02:36.781957
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert True

# Generated at 2022-06-23 07:02:37.701559
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-23 07:02:50.300182
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # initialize RoleMetadata
    r = RoleMetadata()
    r._owner = lambda: None
    setattr(r._owner, "_role_path", "/role/path")
    setattr(r._owner, "collections", [])
    setattr(r._owner, "_play", lambda: None)
    setattr(r._owner, "variable_manager", lambda: None)
    setattr(r._owner, "_loader", loader)
    setattr(r._owner, "_role_collection", None)
    r._variables = lambda: None

# Generated at 2022-06-23 07:02:58.735866
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Initialize a RoleMetadata object

    # Populate both instance attributes and meta_attributes
    # with their default values
    role_metadata = RoleMetadata()
    role_metadata.attributes.set_serialized_attributes()

    # Set attribute values

    # Set boolean attribute allow_duplicates
    allow_duplicates = True
    setattr(role_metadata, 'allow_duplicates', allow_duplicates)

    # Set list attribute dependencies
    dependencies = [
        {'role': 'peterjcaulfield.staging-environment'},
        {'role': 'peterjcaulfield.dev-environment'}
    ]
    setattr(role_metadata, 'dependencies', dependencies)

    # Serialize the RoleMetadata object
    role_metadata_serialized = role_metadata.serialize()

   

# Generated at 2022-06-23 07:03:02.942241
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[dict(name='bob.rolename', src='/foo/bar/roles/bob.rolename', scm="git", version="1.0")]
    )
    rmi = RoleMetadata(owner=None).deserialize(data)
    assert rmi.serialize() == data

# Generated at 2022-06-23 07:03:10.011581
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_name = ''
    base_path = ''
    args = dict()
    role = RoleMetadata(owner=role_name, base_path=base_path, args=args)
    assert role.name == base_path + "/" + role_name
    assert role._role_name == role_name
    assert role._role_path == base_path
    assert role._role_args == args
    assert role._role_collection is None
    assert role._allow_duplicates == False
    assert role._dependencies == []
    assert role._galaxy_info == {}
    assert role._argument_specs == {}

# Generated at 2022-06-23 07:03:12.752149
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    m.deserialize(data)
    assert m.allow_duplicates == False
    assert m.dependencies == []

# Generated at 2022-06-23 07:03:23.834117
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Playbook, PlaybookInclude
    from ansible.playbook.role.definition import RoleDefinition
    play = Playbook()

    # non-dict data
    data = 'string'
    try:
        RoleMetadata.load(data, 'test')
        assert False
    except AnsibleParserError:
        pass

    # bad argument_spec
    data = dict(
        galaxy_info=dict(
            min_ansible_version='2.2',
            min_ansible_engine_version='1.0.0'
        ),
        argument_spec=dict(
            nonexistent='dict'
        )
    )
    try:
        RoleMetadata.load(data, 'test')
        assert False
    except AnsibleError:
        pass

    # bad dependencies

# Generated at 2022-06-23 07:03:32.675145
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    #Deserialize without any data
    role_metadata = RoleMetadata()
    role_metadata.deserialize(None)
    assert role_metadata._dependencies == []
    assert role_metadata._allow_duplicates == False

    #Deserialize with empty data
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})
    assert role_metadata._dependencies == []
    assert role_metadata._allow_duplicates == False

    #Deserialize with valid data
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['one', 'two']})
    assert role_metadata._dependencies == ['one', 'two']
    assert role_metadata._allow_duplicates == True

# Generated at 2022-06-23 07:03:35.484175
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    # RoleMetadata constructor
    roleMetadata = RoleMetadata()
    assert not roleMetadata

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-23 07:03:42.622941
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    b = RoleMetadata()
    b._load_data({'allow_duplicates':True, 'dependencies':['a','b','c']})
    assert b == {'allow_duplicates':True, 'dependencies':['a','b','c']}

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-23 07:03:50.885452
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.requirement import RoleRequirement

    class Mock(object):

        def __init__(self, attr1, attr2):
            self.attr1 = attr1
            self.attr2 = attr2

    m = Mock('attr1', 'attr2')

    data = dict(
        allow_duplicates='enable',
        dependencies=[
            dict(
                name='role1',
                src='role1_path',
                version='v1',
                scm='git'
            ),
            dict(
                name='role2',
                src='role2_path',
                scm='git'
            )
        ]
    )

    r = RoleMetadata(owner=m)
    r.deserialize(data)

# Generated at 2022-06-23 07:03:55.974954
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-23 07:04:01.509016
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    m = RoleMetadata(owner=RoleDefinition())
    setattr(m, 'allow_duplicates', False)
    setattr(m, 'dependencies', [])
    reference = dict(allow_duplicates=False, dependencies=[])
    result = m.serialize()
    assert reference == result


# Generated at 2022-06-23 07:04:12.128051
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-23 07:04:14.813985
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    d = RoleMetadata()
    assert(d is not None)
    assert(d._dependencies == [])


# Generated at 2022-06-23 07:04:23.127916
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta1 = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar']
    )
    meta2 = dict(
        dependencies=['foo', 'bar']
    )

    r = RoleMetadata(owner=None)
    r.deserialize(meta1)
    assert r.allow_duplicates == True
    assert r.dependencies == ['foo', 'bar']

    r.deserialize(meta2)
    assert r.allow_duplicates == False
    assert r.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 07:04:30.188523
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    def test_func():
        class Role(object):
            def __init__(self, name=None):
                self.name = name
                self._role_path = name

        role = Role(name='role')
        role_metadata = RoleMetadata(owner=role)
        role.metadata = role_metadata
        return role_metadata
    assert test_func()

# Generated at 2022-06-23 07:04:34.318859
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    owner = RoleMetadata()

    assert owner.allow_duplicates == False, "RoleMetadata test failed: constructor, allow_duplicates"
    assert owner.dependencies == [], "RoleMetadata test failed: constructor, dependencies"


# Generated at 2022-06-23 07:04:45.863918
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    # create test RoleMetadata
    role_meta = RoleMetadata()

    # create test Play
    play_context = PlayContext()
    test_play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'shell', 'args': 'ls'}},
            {'action': {'module': 'debug', 'args': 'msg={{service1}}'}}
        ]},
        variable_manager=None, loader=None, play_context=play_context)

# Generated at 2022-06-23 07:04:46.748208
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:04:50.209709
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook import Play
    from ansible.playbook.block import Block

    ds = dict(
        allow_duplicates=True,
        dependencies=['test_role']
    )

    m = RoleMetadata()
    m.deserialize(ds)
    res = m.serialize()

    assert res == ds

# Generated at 2022-06-23 07:05:00.778255
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # create RoleMetadata instance
    my_role = RoleMetadata()
    my_role._allow_duplicates = True
    my_role._dependencies = [
        {'role': 'common', 'vars': {'var1': 'value1'}},
        {'role': 'web', 'vars': {'var2': 'value2'}},
    ]

    # serialize RoleMetadata instance
    expected_dict = {
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'common', 'vars': {'var1': 'value1'}},
            {'role': 'web', 'vars': {'var2': 'value2'}},
        ]
    }
    assert expected_dict == my_role.serialize()



# Generated at 2022-06-23 07:05:11.110492
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Init class instance
    ext = RoleMetadata()

    # Init vars
    allow_duplicates = True
    dependencies = [
        {
            "role": "Zzet.git",
            "scm": "git",
            "version": "2ea9d49a56b8c65bca7d56fbcf1c62503214c3b3"
        }
    ]

    # Set vars
    ext._allow_duplicates = allow_duplicates
    ext._dependencies = dependencies

    # Serialize
    data = ext.serialize()

    # Compare values
    assert isinstance(data, dict)
    assert isinstance(data.get('allow_duplicates'), bool)
    assert data.get('allow_duplicates') == allow_duplicates

# Generated at 2022-06-23 07:05:23.817490
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import sys
    import unittest
    import ansible.playbook.role.meta
    import ansible.plugins
    import ansible.plugins.loader
    #from ansible.playbook.role.definition import RoleDefinition
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text

    ######################################################################
    # This block is to prepare the environment to run the tests
    #
    # Ansible is configured to look for modules in the 'test/units/modules'
    # directory
    ######################################################################
    test_dir = os.path.dirname(__file__) or '.'
    sys.path.insert(0, os.path.abspath(os.path.join(test_dir, 'units/modules')))
    sys.path.insert

# Generated at 2022-06-23 07:05:28.159718
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ds = {'allow_duplicates': False, 'dependencies': []}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(ds)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []