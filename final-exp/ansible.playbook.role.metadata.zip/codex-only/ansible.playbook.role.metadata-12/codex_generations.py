

# Generated at 2022-06-23 06:55:18.064906
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

    return role_metadata


# Generated at 2022-06-23 06:55:26.059681
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    host = Host(name="test")
    group = Group(name="test")
    group.add_host(host)
    var_manager = VariableManager(loader=DataLoader(), inventory=group)

    var_manager.set_inventory(group)
    var_manager.set_vars(combine_vars(var_manager.get_vars(host=host), var_manager.get_vars(play=None)))


# Generated at 2022-06-23 06:55:29.231449
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    try:
        RoleMetadata.load('abc', None)
    except AnsibleParserError as e:
        print(e)
    try:
        RoleMetadata.load({}, None)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_RoleMetadata_load()

# Generated at 2022-06-23 06:55:32.003947
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    owner = 100
    data = 'testdata'
    variable_manager = 200
    loader = 300

    role_metadata = RoleMetadata()

    role_metadata.load(data, owner, variable_manager, loader)

    print(role_metadata)

# Generated at 2022-06-23 06:55:42.149333
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=dict(
            foo=dict(
                role="foo-role",
                src="/path/to/foo-role",
                version="0.1",
                name="foo"
            ),
            bar=dict(
                role="bar-role",
                src="/path/to/bar-role",
                version="0.1",
                name="bar"
            )
        )
    )
    rm = RoleMetadata()
    rm.deserialize(data)
    assert rm._allow_duplicates == True
    assert isinstance(rm._dependencies, list)
    assert len(rm._dependencies) == 2
    assert rm._dependencies[0].get_name() == "foo"
    assert rm._dependencies[1].get_name

# Generated at 2022-06-23 06:55:45.275016
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == list


# Generated at 2022-06-23 06:55:54.945893
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    p = Play()
    r = Role()
    r._role_path = '/abc/roles/test'
    m = RoleMetadata(owner=r)
    try:
        m.deserialize({})
        assert False, "deserialize with data empty should raise exception"
    except Exception:
        pass
    try:
        m.deserialize({'allow_duplicates': True})
        assert False, "deserialize with data invalid should raise exception"
    except Exception:
        pass

# Generated at 2022-06-23 06:55:59.470200
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play

    role_metadata = RoleMetadata.load({
        "allow_duplicates": True,
        "dependencies": [
            {
                "role": "common",
                "role_path": "/etc/ansible/roles/common",
                "version": "v1"
            }
        ]
    }, Play())
    assert role_metadata._allow_duplicates is True
    assert role_metadata._dependencies[0].get("role") == "common"


# Generated at 2022-06-23 06:56:10.885983
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play


# Generated at 2022-06-23 06:56:21.319975
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    m = RoleMetadata()
    assert isinstance(m._dependencies, list)
    assert len(m._dependencies) == 0

    ds = dict(
        dependencies = [
            dict(role="FRED"),
        ],
    )
    r = RoleInclude()
    r._role_name = 'BARNEY'
    r._play = dict(
        basedir = '.',
    )
    p = PlayContext()
    p.collections = ['foo']
    r._play_context = p

    m = m.load(data=ds, owner=r)
    assert isinstance(m, RoleMetadata)
    assert len(m.dependencies) == 1

# Generated at 2022-06-23 06:56:22.475214
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    raise NotImplementedError

# Generated at 2022-06-23 06:56:31.940989
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'dependencies': [
            {'name': 'role_name_1', 'src': 'role_src_1'},
            {'name': 'role_name_2', 'src': 'role_src_2'}
        ],
        'allow_duplicates': True
    }
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == True
    print(role_metadata._dependencies)
    assert role_metadata._dependencies[0].get('name') == 'role_name_1'
    assert role_metadata._dependencies[0].get('src') == 'role_src_1'
    assert role_metadata._dependencies[1].get('name') == 'role_name_2'
    assert role_

# Generated at 2022-06-23 06:56:42.471780
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-23 06:56:53.424122
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.parsing.yaml.objects
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = {
        'allow_duplicates': 'yes',
        'dependencies': [
            {'role': 'ansible.legacy.windows'},
            {'role': 'ansible.legacy.general',
             'tags': ['tag1', 'tag2'],
             'when': "ansible_facts['os_family']|lower == 'redhat'"},
        ],
    }
    data = AnsibleLoader(data, file_name=None).get_single_data()
    role_metadata = RoleMetadata(owner=None)
    role_metadata.allow_duplicates = 'yes'

# Generated at 2022-06-23 06:57:05.104540
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Test for an invalid file loading
    metadata_filename = 'meta/main.yml'
    p = Play.load(dict(
        name="Ansible Play",
        hosts=['all'],
        gather_facts='no',
        roles=['test-role'],
        vars=dict(a=1),
        handlers=['test-handler'],
        tasks=["test-task"]
    ), variable_manager=None, loader=None)
    context = PlayContext()

# Generated at 2022-06-23 06:57:07.496297
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata()
    role_meta.allow_duplicates = True
    role_meta.dependencies = ['test']
    serialized_dict = role_meta.serialize()
    assert serialized_dict['allow_duplicates'] == True
    assert serialized_dict['dependencies'] == ['test']

# Generated at 2022-06-23 06:57:20.326442
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ## Test case 1: Set all attributes with some value
    # Input for test case 1
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(name='foo', src='/path/to/foo')
        ]
    )

    # Output for test case 1
    exp_allow_duplicates = True
    exp_dependencies = [
            dict(name='foo', src='/path/to/foo')
        ]

    role_metadata = RoleMetadata('owner')
    role_metadata.deserialize(data)

    assert role_metadata._allow_duplicates == exp_allow_duplicates, \
        "Fail: allow_duplicates is wrong"
    assert role_metadata._dependencies == exp_dependencies, \
        "Fail: dependencies is wrong"

    ## Test case

# Generated at 2022-06-23 06:57:27.129622
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement

    def mock_load_list_of_roles(roles, play=None, current_role_path=None, variable_manager=None, loader=None):
        ''' Make sure the list of roles is parsed and returned as a list of RoleRequirement objects'''
        assert(isinstance(roles, list))
        assert(play is not None)
        assert(current_role_path is not None)
        assert(variable_manager is not None)
        assert(loader is not None)
        return roles

    # load with a list
    current_role = Role()
    current_role._role_path = '/path/to/roles/test_role'
    current_role.name = 'test_role'

# Generated at 2022-06-23 06:57:31.397735
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    r = RoleMetadata().load(role_metadata)

    assert r.serialize() == role_metadata


# Generated at 2022-06-23 06:57:35.813802
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    module = RoleMetadata()
    assert module._allow_duplicates is False
    assert module._dependencies == []
    assert module._galaxy_info is None
    assert module._argument_specs == {}
    assert module._ds is None


# Generated at 2022-06-23 06:57:42.220378
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from collections import namedtuple

    # Given a role object
    Role_obj = Role()

    # When I create an object of class RoleMetadata
    RoleMetadata_obj = RoleMetadata(Role_obj)

    # Then the owner should be the role object
    assert RoleMetadata_obj._owner == Role_obj

# Generated at 2022-06-23 06:57:46.321202
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=[],
    )
    metadata.deserialize(data)
    assert metadata._allow_duplicates is True
    assert metadata._dependencies == []

# Generated at 2022-06-23 06:57:50.643369
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {}
    data['allow_duplicates'] = False
    data['dependencies'] = []
    result = RoleMetadata().serialize()
    assert result == data


# Generated at 2022-06-23 06:57:51.317572
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-23 06:58:01.327553
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    Unit test for method load of class RoleMetadata
    """
    import os
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook import Play, Role

    # Test when data is not a dictionary
    with pytest.raises(AnsibleParserError):
        RoleMetadata.load(False, owner=None)

    # Test when data is a dictionary of bad var type
    data = AnsibleBaseYAMLObject()
    with pytest.raises(AnsibleParserError):
        RoleMetadata.load(data, owner=None)

    # Test with real data
    # TODO
    os.environ['ANSIBLE_DISPLAY_SKIPPED_HOSTS'] = 'False'

# Generated at 2022-06-23 06:58:11.733333
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-23 06:58:21.796742
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.play import Play

    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    C.DEFAULT_HOST_LIST = '/etc/ansible/hosts'
    C.DEFAULT_MODULE_PATH = '/usr/share/ansible/plugins/modules:/usr/share/ansible/plugins/module_utils'
    C.DEFAULT_TIMEOUT = 10
    C.DEFAULT_SUDO = False
    C.DEFAULT_SUDO_USER = 'root'
    C.DEFAULT_ASK_SUDO_PASS = False
    C.DEFAULT_ASK_PASS = False
    C.DEFAULT_REMOTE_USER = 'root'
    C.DEFAULT_PRIVATE_

# Generated at 2022-06-23 06:58:34.035439
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from collections import namedtuple
    from ansible.playbook.role.metadata import GalaxyInfo
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping
    import types

    owner = RoleDefinition('i_am_owner')
    variable_manager = None

    loader = types.SimpleNamespace(get_basedir=lambda x: None)

    owner.loader = loader

    owner._role_path = 'fake_rolepath'

    assert not owner._metadata

    with pytest.raises(AnsibleParserError) as exception_info:
        RoleMetadata.load(AnsibleBaseYAMLObject(None), owner, variable_manager, loader)

# Generated at 2022-06-23 06:58:45.524694
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    playbook_path = '../examples/playbook.yml'
    loader_mocker = AnsibleCollectionLoader.mocker()
    loader_mocker.patch_collection_path()
    loader_mocker.patch_ansible_module_utils()
    import ansible.module_utils.basic
    import ansible.module_utils.urls

    p = Play.load(playbook_path, variable_manager=None, loader=loader_mocker.loader)
    assert p._entries[0]._tasks[0].action == 'debug'
    assert p._entries[0]._tasks[0]._role_metadata.allow_duplicates == True


# Generated at 2022-06-23 06:58:47.092806
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO: need unit test
    pass

# Generated at 2022-06-23 06:58:48.919408
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata()
    assert m.load({'allow_duplicates': True})

# Generated at 2022-06-23 06:58:56.167179
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.plugins.loader import role_loader

    # this test could break if the ordering of the variables is changed
    data = {'allow_duplicates': True, 'dependencies': ['geerlingguy.jenkins']}
    role_meta = RoleMetadata.deserialize(data)
    assert role_meta.allow_duplicates == data['allow_duplicates']
    assert role_meta.dependencies == data['dependencies']

# Generated at 2022-06-23 06:59:04.529480
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole

    role = Role()
    role.name = 'superman'
    role.path = '/tmp/my_roles_path'
    role_metadata = RoleMetadata(role)
    assert role_metadata._owner == role
    assert role_metadata._galaxy_info == {}

    dependency = IncludeRole()
    dependency.role = 'ants'
    dependency._parent = role
    dependency._play = {'collections': ['ansible.posix']}
    role_metadata._dependencies = [dependency]
    role_metadata.serialize()
    role_metadata_deserialized = RoleMetadata.load(role_metadata.serialize(), role)
    assert role_metadata_deserialized._owner == role

# Generated at 2022-06-23 06:59:06.338158
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    data = {
        'allow_duplicates' : True,
        'dependencies' : []
    }

    role_metadata = RoleMetadata().deserialize(data)

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 06:59:13.310963
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(None)
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = [ "geerlingguy.nginx", "geerlingguy.php" ]
    assert role_metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[ "geerlingguy.nginx", "geerlingguy.php" ] )

# Generated at 2022-06-23 06:59:26.064419
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class Role():
        def __init__(self, role_name):
            self.name = role_name

    class RoleRequirement():
        def __init__(self, role_name, role_collection=None):
            self.role_name = role_name
            self.role_collection = role_collection

    r1 = Role('test1')
    r2 = Role('test2')
    r3 = Role('test3')

    r4 = RoleRequirement('test4', role_collection='geerlingguy.java')
    r5 = RoleRequirement('test5', role_collection='geerlingguy.postgresql')
    r6 = RoleRequirement('test6', role_collection='geerlingguy.jenkins')

    r7 = RoleRequirement('test7')

# Generated at 2022-06-23 06:59:31.156545
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()

    role_metadata.dependencies = [{'role': 'common'}]
    role_metadata.allow_duplicates = True

    expected_role_metadata = dict(
        allow_duplicates=True,
        dependencies=[{'role': 'common'}]
    )
    assert role_metadata.serialize() == expected_role_metadata

# Generated at 2022-06-23 06:59:43.091691
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''
    import os
    import sys
    import unittest

    class TestRoleMetadata(unittest.TestCase):
        '''
        Test class for RoleMetadata
        '''
        def setUp(self):
            '''
            Setup for RoleMetadata
            '''

            self.project_dir = os.path.realpath(os.path.join(os.path.dirname(__file__), '../../..'))

            # Mock helpers/playbook_tests/test.yml
            self.test_playbook_path = os.path.realpath(os.path.join(
                self.project_dir,
                'test/units/module_utils/test_playbook.yml'
            ))


# Generated at 2022-06-23 06:59:47.733481
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata({})
    role._allow_duplicates = True
    role._dependencies = [1,2,3]
    result = role.serialize()
    assert(result['allow_duplicates'] == True)
    assert(result['dependencies'] == [1,2,3])


# Generated at 2022-06-23 06:59:53.435054
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role

    role = Role.load('/etc/ansible/roles/test_role')
    question = RoleMetadata(owner=role)
    assert(isinstance(question, RoleMetadata))
    assert(question.dependencies == [])

# Generated at 2022-06-23 07:00:01.456101
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    from ansible.playbook.role.definition import RoleDefinition

    rd = RoleDefinition()
    rd._role_name = "test_role"
    rd._role_path = './test/data/roles/test_role/meta/main.yml'
    rd._role_collection = None
    rd._play = None
    rd._loader = None
    rd._variable_manager = None
    rd._task_blocks = []

    os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..'))
    rds_list = RoleMetadata.load(rd._ds, rd)

    assert len(rds_list) == 8

# Generated at 2022-06-23 07:00:03.175155
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rm = RoleMetadata(owner=None)

# Generated at 2022-06-23 07:00:15.096659
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play
    import yaml
    ds = {
        'allow_duplicates': False,
        'dependencies': [
            { 'role': 'apache' },
            { 'role': 'mysql', 'some_param': 'foo' }
        ]
    }
    role = yaml.load(role_yaml)
    r = RoleMetadata(role)
    r.load_data(ds, variable_manager=None, loader=None)

# Generated at 2022-06-23 07:00:19.615988
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class DummyClass:
        pass

    obj = DummyClass()
    data = {}
    data['allow_duplicates'] = False
    data['dependencies'] = []
    m = RoleMetadata()
    assert m.deserialize(data) == None

# Generated at 2022-06-23 07:00:24.424157
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    dependencies = ['role1', 'role2', 'role3']
    setattr(role_metadata, 'allow_duplicates', False)
    setattr(role_metadata, 'dependencies', dependencies)
    ret = role_metadata.serialize()
    assert ret['allow_duplicates'] == False
    assert ret['dependencies'] == dependencies
    assert len(ret) == 2


# Generated at 2022-06-23 07:00:31.978309
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_include import RoleInclude

    data = dict(
        allow_duplicates=True,
        dependencies=['one', 'two', 'three']
    )
    result = RoleMetadata.load(data, 'role_name')
    assert result._allow_duplicates
    assert len(result._dependencies) == 3

    data = dict(
        dependencies={'galaxy_info': {'foo': 'bar'}}
    )
    try:
        result = RoleMetadata.load(data, 'role_name')
    except AnsibleParserError:
        pass


# Generated at 2022-06-23 07:00:32.630904
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert 1 == 1

# Generated at 2022-06-23 07:00:44.836918
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    # Creation of structure data to populate a RoleMetadata
    data_mock = {'allow_duplicates': False, 'dependencies': [{'role': 'apache'}, {'role': 'mysql'}, {'role': 'php'}]}

    # Creation of RoleInclude
    role = Role('apache')
    role._role_path = '/home/user/ansible/roles/apache'
    roleInclude_apache = RoleInclude(role=role)

    role2 = Role('mysql')
    role2._role_path = '/home/user/ansible/roles/mysql'
    roleInclude_mysql = Role

# Generated at 2022-06-23 07:00:53.681141
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': True, 'dependencies': ['test.dependency']}
    role = RoleMetadata()
    role.deserialize(data)
    assert role._allow_duplicates == True
    assert role._dependencies == ['test.dependency']

# Generated at 2022-06-23 07:00:57.324860
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': []}
    rm = RoleMetadata()
    rm.deserialize(data)
    assert type(rm._allow_duplicates) == bool
    assert type(rm._dependencies) == list

# Generated at 2022-06-23 07:01:06.477408
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import copy
    import json

    r = RoleMetadata()


# Generated at 2022-06-23 07:01:12.172377
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {'allow_duplicates': True,
            'dependencies': ['role1', 'role2']
    }

    meta = RoleMetadata(owner=['role1']).load(data, ['role1'], variable_manager=None, loader=None)

    assert meta._allow_duplicates == True
    assert meta._dependencies == ['role1', 'role2']

# Generated at 2022-06-23 07:01:15.334805
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"test_attr": "test_value"})
    assert getattr(role_metadata, "test_attr") == "test_value"



# Generated at 2022-06-23 07:01:23.898045
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    meta.load_data({'dependencies':[{'role': 'common'}]})

    assert meta.dependencies[0].role == 'common'

    meta.load_data({'dependencies':[{'src': 'galaxy.test.role', 'version': '2.0'}]})
    assert meta.dependencies[0].src == 'galaxy.test.role'

    meta.load_data({'dependencies':['common']})
    assert meta.dependencies[0].role == 'common'

# Generated at 2022-06-23 07:01:25.415963
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(None)
    assert m is not None

# Generated at 2022-06-23 07:01:33.243675
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Test if serialize method of RoleMetadata works.
    """
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    role = RoleDefinition.load({}, 'role1')

    # test with empty dependencies list
    metadata = RoleMetadata(role)
    result = metadata.serialize()
    assert isinstance(result, dict)
    assert result == {'allow_duplicates': False, 'dependencies': []}

    # test with simple list of roles
    results = [RoleRequirement.load(role, 'role1'),
               RoleRequirement.load(role, {'src': 'role2', 'name': 'role2'})]
    role.metadata._dependencies = results
    result = role.metadata.serialize()

# Generated at 2022-06-23 07:01:39.441705
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = [{'role':'test1'},{'role':'test2'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role':'test1'},{'role':'test2'}]}

# Generated at 2022-06-23 07:01:47.975705
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Create a RoleMetadata object
    m = RoleMetadata()
    setattr(m, 'allow_duplicates', True)
    setattr(m, 'dependencies', [{'role': 'x', 'name': 'a,b'}, {'role': 'y', 'name': 'c,d'}])

    # Serialize the RoleMetadata object to a dictionary
    data = m.serialize()

    # Check the result
    assert data['allow_duplicates'] == True
    assert data['dependencies'] == [{'role': 'x', 'name': 'a,b'}, {'role': 'y', 'name': 'c,d'}]


# Generated at 2022-06-23 07:01:49.796779
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    r = RoleMetadata()
    d = {'hello': 'world'}
    r = r.load(d, owner=None)

    assert isinstance(r, RoleMetadata)

# Generated at 2022-06-23 07:01:59.619465
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

    role_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_role_metadata', '')
    role = create_test_role(role_path)
    loader = DictDataLoader({})
    variable_manager = basic.VariableManager()
    variable_manager.extra_vars = ImmutableDict({'foo': 'bar'})


# Generated at 2022-06-23 07:02:00.828365
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:02:05.906639
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.deserialize({'dependencies': [{'role': 'a'}], 'allow_duplicates': True})
    assert m.serialize() == {'dependencies': [{'role': 'a'}], 'allow_duplicates': True}

test_RoleMetadata_serialize()

# Generated at 2022-06-23 07:02:10.869377
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_met = RoleMetadata()
    role_met.deserialize(dict(allow_duplicates=True, dependencies=[1, 2, 3]))
    assert role_met._dependencies == [1, 2, 3]


# Generated at 2022-06-23 07:02:14.533287
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies=[10, 20, 30])
    r.deserialize(data)
    assert r.allow_duplicates
    assert r.dependencies == [10, 20, 30]

# Generated at 2022-06-23 07:02:19.926170
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(dependencies=dict(role="role_name"), allow_duplicates=True))
    assert role_metadata._dependencies == [dict(role="role_name")]
    assert role_metadata._allow_duplicates is True

# Generated at 2022-06-23 07:02:25.167102
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta._allow_duplicates = True
    meta._dependencies = ['common', 'dev']
    assert meta.serialize() == {
        'allow_duplicates': True,
        'dependencies': ['common', 'dev']
    }


# Generated at 2022-06-23 07:02:31.630458
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    my_role_metadata = RoleMetadata()
    my_role_metadata.deserialize(dict())
    assert my_role_metadata._allow_duplicates == False
    assert my_role_metadata._dependencies == []

    my_role_metadata.deserialize(dict(allow_duplicates=True, dependencies=['otherrole', 'anotherrole']))
    assert my_role_metadata._allow_duplicates == True
    assert my_role_metadata._dependencies == ['otherrole', 'anotherrole']

# Generated at 2022-06-23 07:02:38.772554
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    md = RoleMetadata()
    md.allow_duplicates = True
    md.dependencies = [{'role': 'Common'}, {'role': 'Web'}, AnsibleUnsafeText('{{web_server_role}}')]
    data = md.serialize()

    assert data['allow_duplicates'] == True
    assert data['dependencies'] == [{'role': 'Common'}, {'role': 'Web'}, AnsibleUnsafeText('{{web_server_role}}')]

# Generated at 2022-06-23 07:02:44.407585
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    assert metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}
    metadata._allow_duplicates = True
    metadata._dependencies = [True, False]
    assert metadata.serialize() == {'allow_duplicates': True, 'dependencies': [True, False]}

# Generated at 2022-06-23 07:02:49.666696
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_success
    variable_manager = 'variable_manager'
    loader = DictDataLoader({})

    import os
    import sys
    sys.modules['galaxy_info_data'] = {}
    sys.modules['galaxy_info_data'].GalaxyInfo = GalaxyInfo

    current_dir = os.path.dirname(__file__)
    #this file is in the same directory as this test
    data_path = os.path.join(current_dir, 'role_meta_data/role_meta_data.yml')


# Generated at 2022-06-23 07:02:58.191497
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # define class owner
    class role:
        _play = None
        _role_path = None
        _role_collection = None

    # create owner object
    owner = role()

    # test with default values

    # create RoleMetadata object
    obj = RoleMetadata(owner=owner)

    # serialize data from RoleMetadata object
    data = obj.serialize()

    # deserialize data to RoleMetadata object
    obj.deserialize(data)

    # check that RoleMetadata object is not None
    assert obj is not None

    # check that attribute 'allow_duplicates' has correct value
    assert obj.allow_duplicates == False

    # check that attribute 'dependencies' has correct value
    assert obj.dependencies == []

    # test with another values

    # assign new values to attributes attributes of

# Generated at 2022-06-23 07:03:10.401535
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import yaml
    yaml_str = """
    ---
    allow_duplicates: False
    dependencies:
      - {role: geerlingguy.java}
      - {role: geerlingguy.redis, redhat: True}
      - {role: geerlingguy.memcached, redhat: True, tags: tags_for_memcached_role}
    """

    yaml_obj = yaml.safe_load(yaml_str)
    role_meta = RoleMetadata.load(yaml_obj, None)
    assert role_meta is not None
    assert role_meta.allow_duplicates == False

    dependencies = role_meta.dependencies
    assert dependencies is not None
    assert len(dependencies) == 3

    dependency_1 = dependencies[0]
    assert dependency_1

# Generated at 2022-06-23 07:03:15.428950
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    if m._allow_duplicates:
        print("allow_duplicates should be False")
        return False
    if m._dependencies:
        print("dependencies should be []")
        return False
    return True

# Generated at 2022-06-23 07:03:19.782139
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r.allow_duplicates = False
    r.dependencies = []

    serialized = r.serialize()
    assert serialized['allow_duplicates'] == False
    assert serialized['dependencies'] == []

# Generated at 2022-06-23 07:03:22.573722
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata(owner=None)

    m.deserialize({'test_dict': {'test_key': 'test_value'}})

    assert m.test_dict['test_key'] == 'test_value'

# Generated at 2022-06-23 07:03:31.887875
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    Test the load function of the RoleMetadata class
    """

    # Test a correct load of data
    data = {"dependencies": [], "galaxy_info": {}}
    owner = RoleMetadata()
    owner.load(data)
    assert owner._dependencies == []
    assert owner._galaxy_info == {}
    assert owner._allow_duplicates == False
    assert owner._argument_specs == {}

    # Test the loading of duplicate data
    data = {"dependencies": [], "galaxy_info": {}, "allow_duplicates": True}
    owner = RoleMetadata()
    owner.load(data)
    assert owner._allow_duplicates == True

    # Test the wrong data type
    data = ["dependencies", [], "galaxy_info", {}]
    owner = RoleMet

# Generated at 2022-06-23 07:03:37.836762
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook import Playbook
    from ansible.playbook.base import PlaybookBase
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    roster = 'localhost,'
    path = 'test_playbooks/default.yml'


# Generated at 2022-06-23 07:03:39.041190
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    raise NotImplementedError()

# Generated at 2022-06-23 07:03:46.608873
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata(owner=None)
    role_meta.allow_duplicates = True
    role_meta.dependencies = [ {"role" : "mod_dependency_role_1" }, {"role" : "mod_dependency_role_2" } ]
    assert role_meta.serialize() == {'allow_duplicates': True,
                                     'dependencies': [{'role': 'mod_dependency_role_1'},
                                                      {'role': 'mod_dependency_role_2'}]}

# Generated at 2022-06-23 07:03:49.763317
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pb = RoleMetadata()
    pb.deserialize({"dependencies": []})
    assert pb.dependencies == []
    assert pb.allow_duplicates == False

# Generated at 2022-06-23 07:04:01.461227
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.errors import AnsibleParserError

    data = dict(
        allow_duplicates=False,
        dependencies=[],
		argument_specs={}
	)

    try:
        role = RoleMetadata()
    except AnsibleParserError as e:
        assert False, "Failed to load RoleMetadata"

    result = role.deserialize(data)
    assert result, "Failed to deserialize RoleMetadata"
    assert result['dependencies'] == data['dependencies'], "Failed to deserialize RoleMetadata: dependencies"
    assert result['allow_duplicates'] == data['allow_duplicates'], "Failed to deserialize RoleMetadata: allow_duplicates"

# Generated at 2022-06-23 07:04:02.323016
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:04:12.651846
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-23 07:04:18.519448
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    setattr(role_metadata, '_allow_duplicates', True)
    setattr(role_metadata, '_dependencies', ['galaxy.role,version,name'])
    assert(role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['galaxy.role,version,name']})


# Generated at 2022-06-23 07:04:22.551262
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': True,
        'dependencies': [
            {
                'role': 'test.role'
            }
        ]
    }
    role = RoleMetadata()
    role.deserialize(data)
    expected = {'allow_duplicates': True, 'dependencies': [{'role': 'test.role'}]}
    assert role.serialize() == expected


# Generated at 2022-06-23 07:04:23.991158
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata(owner=None)

# Generated at 2022-06-23 07:04:35.144755
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    import sys

    try:
        reload(sys.modules['ansible.playbook.lazy_loader'])
    except KeyError:
        from ansible.playbook.lazy_loader import LazyLoader
    from ansible.playbook.role.definition import RoleDefinition

    # Setup
    base_definition = RoleDefinition(
        name="test_role",
        play=None,
        loader=LazyLoader(),
        path="test",
        args=None,
        private=True,
        force_handlers=True,
        role_collection=None
    )
    base_role = Role(base_definition)

    # Test
    result = RoleMetadata.load(None, base_role)
    assert not result

# Generated at 2022-06-23 07:04:39.996679
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test for constructor of class RoleMetadata
    '''
    assert RoleMetadata()
    #assert RoleMetadata(owner=None)
    #assert RoleMetadata(ds=None)
    #assert RoleMetadata(owner=None, ds=None)

# Generated at 2022-06-23 07:04:51.842330
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import role_loader

    rd = RoleDefinition()
    rd._role_name = 'foo'
    rd._role_path = 'bar'
    role_loader.add_directory(rd, '/tmp/')
    rd = RoleDefinition()
    rd._role_name = 'foo'
    rd._role_path = 'bar'
    role_loader.add_directory(rd, '/tmp/')
    rm = RoleMetadata()
    rm.deserialize(dict(
        allow_duplicates=False,
        dependencies=[{'role': 'foo', 'foo': 'bar'}]
    ))

# Generated at 2022-06-23 07:05:02.216176
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role

    tmp_role_path = os.path.join(os.path.dirname(__file__), "..", "data", "test_role_bad")
    rd = RoleDefinition.load(tmp_role_path)

    rm = RoleMetadata(Role(name=os.path.basename(tmp_role_path), role_path=tmp_role_path))
    rm.load(rd.metadata, owner=rd.role, variable_manager=rd.variable_manager, loader=rd.loader)

    assert rm.allow_duplicates == True
    assert rm.dependencies == []
    assert rm._galaxy_info == None
    assert rm._argument_specs == {}
    
    assert rm.get_

# Generated at 2022-06-23 07:05:09.743421
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    data = dict(
        allow_duplicates=False,
        dependencies=[],
    )

    print("role metadata no owner test ... ")
    temp_obj = RoleMetadata(owner=None).deserialize(data)

    assert(temp_obj.allow_duplicates == False)
    assert(temp_obj.dependencies == [])

    print("m = RoleMetadata(owner=None) is " + str(temp_obj))
    print("m = RoleMetadata(owner=None) is " + str(temp_obj.__dict__))


# Generated at 2022-06-23 07:05:18.908974
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    RoleMetadata: Test the constructor of class RoleMetadata
    """
    rolemetadata = RoleMetadata()
    assert rolemetadata.__class__.__name__ == 'RoleMetadata'

    # Check for class attributes:
    assert hasattr(rolemetadata, '_allow_duplicates')
    assert hasattr(rolemetadata, '_dependencies')
    assert hasattr(rolemetadata, '_galaxy_info')
    assert hasattr(rolemetadata, '_argument_specs')