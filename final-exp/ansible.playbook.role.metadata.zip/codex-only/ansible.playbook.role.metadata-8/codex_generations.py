

# Generated at 2022-06-23 06:55:29.231448
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    assert meta is not None
    assert meta.dependencies == list()
    assert meta.allow_duplicates == False

# Generated at 2022-06-23 06:55:33.972030
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    # for this test, we will just require that if a string is encountered
    # it is converted to a RoleInclude using the related class method.
    m = RoleMetadata()

    # the real load method will do translation so we don't want to validate
    # that here

    # we are just looking to make sure that when a dict is parsed, we get
    # a RoleInclude back. We don't do anything with the RoleInclude so we
    # can just stub it out
    o = RoleDefinition.load({
        'name' : 'foo',
        'foo' : 'bar'
    })

    m._load_dependencies('dependencies', ['foo'])
    m._load_dependencies('dependencies', ['foo', { 'role' : o }])
    m._

# Generated at 2022-06-23 06:55:34.311431
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-23 06:55:44.933983
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata.load({'allow_duplicates': True}, owner='owner')
    assert m.allow_duplicates == True
    assert m.dependencies == []
    assert m._owner == 'owner'
    assert m._loader == None
    assert m._variable_manager == None

    m = RoleMetadata.load({'dependencies': [{'role': 'test', 'other_vars': 'abc'}]}, owner='owner')
    assert m.allow_duplicates == False
    assert isinstance(m.dependencies[0], RoleRequirement)
    assert m._owner == 'owner'
    assert m._loader == None
    assert m._variable_manager == None


# Generated at 2022-06-23 06:55:47.855774
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata.dependencies)
    assert role_metadata.dependencies == []

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-23 06:56:00.560714
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.meta import RoleMetadata
    # based on role_loader_unittest.RoleLoaderUnittest.test_galaxy_info
    # test: pass just meta/main.yml
    galaxy_data_1 = {}
    role = Role.load({'role1': {}, 'meta': { 'main.yml': galaxy_data_1 }})
    assert RoleMetadata.load(galaxy_data_1, owner=role)
    # test: pass meta/main.yml and meta/other.yml
    galaxy_data_2 = { 'galaxy_info': {}, 'dependencies': [] }

# Generated at 2022-06-23 06:56:04.142014
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata().load()
    assert role.allow_duplicates == False
    assert role.dependencies == []
    assert role.argument_spec == {}
    assert role.galaxy_info is None
    assert role.collections is None

# Generated at 2022-06-23 06:56:08.907728
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    r = RoleDefinition()
    r._role_name = "test_role"
    rmeta = RoleMetadata(owner=r)
    assert rmeta.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-23 06:56:17.693585
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import datetime as dt
    import os.path
    import unittest

    from ansible import context
    from ansible.playbook import Play

    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars

    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.module_utils.six import string_types
    from ansible.playbook.role.definition import RoleDefinition

    from ansible.plugins.loader import vault_loader
    vault_loader

# Generated at 2022-06-23 06:56:29.669605
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.block import Block

    from ansible.playbook.role.definition import RoleDefinition

    from ansible.playbook.play import Play

    from ansible.playbook.task import Task

    from ansible.playbook.task_include import TaskInclude

    from ansible.playbook.aes import AES

    ROLE_NAME = 'ansible_test_role'
    path = '.'
    defs = [{'role': ROLE_NAME}]
    rb = RoleDefinition.load(defs, play=Play())
    rb._role_name = ROLE_NAME
    rb._role_path = path

    task1 = Task()
    task1.action = 'shell'
    task1.args = 'echo "1"'
    task1.block = Block()


# Generated at 2022-06-23 06:56:33.681265
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    foo = RoleMetadata(owner=None)

    assert foo._allow_duplicates is False
    assert foo._dependencies == []
    assert foo._galaxy_info is None
    assert foo._argument_specs == {}

# Generated at 2022-06-23 06:56:35.120017
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # TODO: Support unit tests
    pass

# Generated at 2022-06-23 06:56:44.544126
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    rd = RoleDefinition()
    rd._role_path = '/home/tester/test.tar.gz'
    rd.name = 'test'
    rd._parent_dir = '/test'

    rd._collections = ['col1', 'col2']

    test_data = [{'role': 'test1'}, {'role': 'test2'}]

    rm = RoleMetadata.load(test_data, rd)
    assert rm.dependencies == test_data
    assert rm._allow_duplicates == False

# Generated at 2022-06-23 06:56:45.129499
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-23 06:56:54.230474
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import ROLE_CACHE
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(current_dir, '..', '..', 'test_data', 'playbook', 'valid_roles_path')

    context = PlayContext()
    cache = ROLE_CACHE.from_playbook_path(playbook_path=test_dir, strategy='linear', context=context)

    test_role_definition = RoleDefinition()
    test_role_definition._role_path = os.path.realpath(test_dir)

# Generated at 2022-06-23 06:57:05.706941
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import __main__
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    data = dict(
        hosts=['host1','host2'],
        vars=dict(
            var1='value1',
            subvar1=dict(
                subvar2='value2'
            )
        ),
        meta=dict(
            allow_duplicates=True,
            dependencies=[ dict(role='role1'), dict(role='role2', var2='value2') ]
        )
    )

    # The metadata should contain the same information we put in
    play = Play.load(data, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:57:06.819399
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-23 06:57:12.266018
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata(owner=None)
    r.deserialize(dict(allow_duplicates=False, dependencies=[]))
    assert r.allow_duplicates == False
    assert r.dependencies == []

# Generated at 2022-06-23 06:57:18.080777
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    data = rmd.serialize()
    assert data is not None
    assert type(data) == dict
    assert 'allow_duplicates' in data
    assert data['allow_duplicates'] == False
    assert 'dependencies' in data
    assert type(data['dependencies']) is list
    assert data['dependencies'] == []


# Generated at 2022-06-23 06:57:22.372377
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['b.yaml']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['b.yaml']}

# Generated at 2022-06-23 06:57:34.879122
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-23 06:57:35.595976
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO
    pass

# Generated at 2022-06-23 06:57:38.940665
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    meta = RoleMetadata()
    meta._allow_duplicates = True
    meta._dependencies = 'foobar'
    
    assert meta.serialize() == { 'allow_duplicates': True, 'dependencies': 'foobar' }


# Generated at 2022-06-23 06:57:49.266531
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    # Load data from a valid meta/main.yml file
    r = RoleMetadata.load({
        'dependencies': [
            'imaginary.role',
            'my.role,v1',
            {'role': 'imaginary.role'},
            {'role': 'imaginary2.role', 'name': 'ir2', 'tasks_from': 'main.yml'},
            {'role': 'imaginary3.role', 'name': 'ir3', 'vars_from': 'main.yml'},
        ]
    }, None)
    assert len(r._dependencies) == 5
    for role in r._dependencies:
        assert isinstance(role, RoleInclude)
    # Check the first
    assert r._dependencies

# Generated at 2022-06-23 06:57:51.776806
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Needs a PR before testing
    pass


# Generated at 2022-06-23 06:57:58.483737
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({
        'allow_duplicates': True,
        'dependencies': [{'role': 'foo'}, {'role': 'bar'}],
    })
    assert m.allow_duplicates is True
    assert len(m.dependencies) == 2
    assert m.dependencies[0].role == 'foo'
    assert m.dependencies[1].role == 'bar'


# Generated at 2022-06-23 06:58:09.920646
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

    # unit test for the constructor of RoleMetadata
    # if the data passed in is dictionary, it should be correct.
    role_metadata = RoleMetadata.load({'foo': 'bar'}, owner=Role(), variable_manager=None, loader=None)
    assert role_metadata._attributes.keys() == ['foo']

    # if the data passed in is not dictionary, we should raise an error.

# Generated at 2022-06-23 06:58:21.355861
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    meta = """
    dependencies:
    - role: role1
      version: v1
    - role2
    """
    meta_data = """
    dependencies:
    - role1
    - role2
    """

    play = RoleDefinition()
    play._role_path = '/tmp/testing-data/'
    play._play_context = PlayContext()
    play._variable_manager = VariableManager()

    role_meta = RoleMetadata.load(meta, owner=play, variable_manager=play._variable_manager)

# Generated at 2022-06-23 06:58:33.591846
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition

    data = dict(
        allow_duplicates=False,
        dependencies=dict()
    )
    role = RoleDefinition(
        name='/foo/roles/test_role',
        play=None,
        host_patterns='*',
        collections='ansible.collection',
        tasks=[],
        handlers=[],
        default_vars=dict(),
        vault_files=[],
        tasks_from=None,
        handlers_from=None,
        has_tasks=True,
        has_handlers=True,
        metadata={},
        role_path='/foo/roles',
        role_collections=None,
        role_collection=None
    )
    role_

# Generated at 2022-06-23 06:58:44.622743
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=["johny.role1", "johny.role2"]
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == False, "role_metadata._allow_duplicates != {0}, != {1}".format(role_metadata._allow_duplicates, data.get('allow_duplicates', False))
    assert role_metadata._dependencies == data.get('dependencies', []), "role_metadata._dependencies != {0}, != {1}".format(role_metadata._dependencies, data.get('dependencies', []))




# Generated at 2022-06-23 06:58:55.338149
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata

    #create a new PlayContext object
    pc = PlayContext()
    #create a new Play object
    pl = Play()

    #create a new object RoleMetadata
    r = RoleMetadata(owner=pl)

    list_1 = ['role']
    dict_1 = {'allow_duplicates':False, 'dependencies':list_1}

    #initialize the RoleMetadata object
    r.deserialize(data=dict_1)
    #verify that the correct data was loaded into the object
    assert r.allow_duplicates==False
    assert r.dependencies==list_1

# Generated at 2022-06-23 06:59:04.360652
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = {'allow_duplicates': True, 'dependencies': [{'role': 'jdoe.common', 'name': 'common'}, {'role': 'jdoe.webservers', 'name': 'webservers'}, {'role': 'jdoe.databases', 'name': 'databases'}]}
    instance = RoleMetadata(None)
    instance.deserialize(meta)
    assert instance._allow_duplicates == True
    assert len(instance._dependencies) == 3
    assert instance._dependencies[0]['role'] == 'jdoe.common'

# Generated at 2022-06-23 06:59:04.822047
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-23 06:59:16.825828
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display

    import collections
    import random
    import string

    display = Display()

    Dummy = collections.namedtuple('Dummy', ['test', 'value'])


# Generated at 2022-06-23 06:59:28.894649
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # assume normal execution
    # assume normal execution
    # assume normal execution
    # assume normal execution
    # assume normal execution
    data = {'allow_duplicates': True, 'dependencies': [{'src': 'ansible.legacy.role', 'version': '1.0.0', 'name': 'mynetwork.myrole', 'scm': 'git', 'path': 'roles/mynetwork.myrole'}]}
    owner = None
    variable_manager = None
    loader = None
    actual = RoleMetadata.load(data, owner, variable_manager, loader)

# Generated at 2022-06-23 06:59:41.197470
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude

    test_task_1 = Task()
    test_task_1._role = RoleInclude()
    test_task_2 = Task()
    test_task_2._role = RoleInclude()

    test_block = Block()
    test_block.block = [test_task_1]
    test_block.rescue = [test_task_2]
    test_block.always = [test_task_2]


# Generated at 2022-06-23 06:59:51.189083
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # test with default allow_duplicates and default dependencies
    m = RoleMetadata()
    d = {'allow_duplicates': False, 'dependencies': []}
    assert m.serialize() == d
    # test with allow_duplicates = True
    m = RoleMetadata()
    m.allow_duplicates = True
    d = {'allow_duplicates': True, 'dependencies': []}
    assert m.serialize() == d
    # test with dependencies
    m = RoleMetadata()
    m.dependencies = [{'role': 'foo'}, {'role': 'bar'}]
    d = {'allow_duplicates': False,
         'dependencies': [{'role': 'foo'}, {'role': 'bar'}]}
    assert m.serialize() == d

# Generated at 2022-06-23 06:59:54.934594
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    instance = RoleMetadata()
    assert isinstance(instance.serialize(), dict)


# Generated at 2022-06-23 07:00:00.113288
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test serialize of class RoleMetadata
    # Setup
    r = RoleMetadata()

    # Test
    r.deserialize({'allow_duplicates':True, 'dependencies':['test1','test2','test3']})

    # Asserts
    assert r.serialize() == {'allow_duplicates':True, 'dependencies':['test1', 'test2', 'test3']}

# Generated at 2022-06-23 07:00:09.018926
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
  default_role_path = '/home/myuser/ansible/roles/'
  role = 'roleName'
  role_path = default_role_path + role + '/'
  galaxy = 'galaxy.roleName.roleVersion.name'
  datastructure = { "dependencies": [ 'role1', 'role2' ], "allow_duplicates": 'True' }
  try:
    rm_obj = RoleMetadata.load(datastructure, role_path)
    assert rm_obj.serialize() == datastructure
  except Exception as ex:
    print("Error: %s" % ex)

# Generated at 2022-06-23 07:00:20.653501
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta_main = '''
galaxy_info:
  author: username
  description: This is my description
  company: Red Hat
  license: GPLv2
  min_ansible_version: 1.6
  platforms:
    - name: EL
      versions:
        - 5
        - 6
    - name: Fedora
      versions:
        - 17
        - 18
dependencies:
  - galaxy_name.role1
  - galaxy_name.role2
  - { role: other_role, other_vars: "here" }
allow_duplicates: yes
'''
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    play = Play()
    role = Role()
    role._role_path = '/home/username/roles/rolename'


# Generated at 2022-06-23 07:00:29.140102
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    # Test RoleMetadata load with no errors
    role_meta_data_dict = {'allow_duplicates': False, 'dependencies': [{'role': 'user'}, 'user2']}
    role_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'test', 'internal', 'test-roles_meta',)

# Generated at 2022-06-23 07:00:35.856021
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultLib
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.context import CLIContext

    config_obj = object()
    vault_password = object()
    loader = object()
    variable_manager = object()
    loader = AnsibleCollection

# Generated at 2022-06-23 07:00:47.337925
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    with open('test_data/test_playbook/meta/main.yml', 'r') as f:
        data=yaml.safe_load(f)
    rm=RoleMetadata(owner='dummy')
    rm.load(data, owner='dummy')
    serialized = rm.serialize()
    assert 'dependencies' in serialized
    assert len(serialized['dependencies']) == 3
    assert serialized['dependencies'][0]['role'] == 'other'
    assert serialized['dependencies'][0]['role'] == 'other'
    assert serialized['dependencies'][1]['name'] == 'dependent'
    assert serialized['dependencies'][1]['role'] == 'dependent'

# Generated at 2022-06-23 07:00:49.200452
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    x = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['geerlingguy.apache']}
    x.deserialize(data)
    assert x._allow_duplicates == data.get('allow_duplicates', False)
    assert x._dependencies == data.get('dependencies', [])

# Generated at 2022-06-23 07:00:50.801977
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []

# Generated at 2022-06-23 07:00:52.230289
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test for constructor of class RoleMetadata
    :return:
    '''
    role_metadata = RoleMetadata()

# Generated at 2022-06-23 07:00:58.317355
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role._allow_duplicates = True
    role._dependencies = ['role1']
    assert role.serialize() == {'allow_duplicates': True, 'dependencies': ['role1']}
    role._allow_duplicates = False
    role._dependencies = []
    assert role.serialize() == {'allow_duplicates': False, 'dependencies': []}



# Generated at 2022-06-23 07:01:01.204767
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates": True, "dependencies": []})
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == []

# Generated at 2022-06-23 07:01:03.983062
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Mock RoleMetadata.
    role = RoleMetadata()
    expected = dict(
        allow_duplicates=role._allow_duplicates,
        dependencies=role._dependencies
    )
    assert role.serialize() == expected

# Generated at 2022-06-23 07:01:11.155581
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    Unit test for method deserialize of class RoleMetadata
    """
    role_metadata = RoleMetadata()
    setattr(role_metadata, '_dependencies', [{"role": "common"}, {"role": "webservers"}, {"role": "dbservers"}])
    assert role_metadata._dependencies == [{"role": "common"}, {"role": "webservers"}, {"role": "dbservers"}]

# Generated at 2022-06-23 07:01:15.734872
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import sys
    sys.path.append('../../lib')
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import StringIO
    # changing version numbers in __version__ breaks this test
    assert __version__ == '2.9.2'
    if PY3:
        assert __version__ == '2.9.2'
    else:
        assert __version__ == '2.9.2'

    assert RoleMetadata.__name__ == 'RoleMetadata'
    assert RoleMetadata.__doc__ is None

    # instance should not be created
    # role_metadata = RoleMetadata()
    # assert

# Generated at 2022-06-23 07:01:18.974998
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    assert False

    a = RoleMetadata()
    b = RoleMetadata()
    b.deserialize(a.serialize())

# Generated at 2022-06-23 07:01:20.073475
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert False, "TODO"

# Generated at 2022-06-23 07:01:26.450979
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import ast

    test_data = ast.literal_eval("""
{
     'allow_duplicates': False,
     'dependencies': []
}
""")
    dummy_owner = None
    m = RoleMetadata(owner=dummy_owner)
    m.deserialize(test_data)
    assert False == m._allow_duplicates
    assert 0 == len(m._dependencies)
    return True


# Generated at 2022-06-23 07:01:33.807483
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play

    # Force play to  be the parent role
    p = Play()

    # Create test role
    r = Role()

    # Run load method
    m = RoleMetadata.load({'allow_duplicates': False, "dependencies": []}, owner=r)

    # Check value of metadata
    assert m._allow_duplicates == False
    assert m._dependencies == []
    assert m._galaxy_info == None
    assert m._argument_specs == {}
    assert m._owner == r

    # Reinit RoleMetadata, force play to be the parrent role
    p = Play()
    r = Role()

    # Run load method
    m

# Generated at 2022-06-23 07:01:38.839364
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': True,
        'dependencies': ['foo', 'bar']
    }
    rolemetadata = RoleMetadata(owner=None)
    rolemetadata.deserialize(data)
    assert rolemetadata.allow_duplicates is True
    assert rolemetadata.dependencies == ['foo', 'bar']

# Generated at 2022-06-23 07:01:42.574357
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r.allow_duplicates = True
    r.dependencies = ['a', 'b']
    assert r.serialize() == {'allow_duplicates': True, 'dependencies': ['a', 'b']}

# Generated at 2022-06-23 07:01:44.092916
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rm = RoleMetadata()
    assert rm._allow_duplicates == False
    assert rm._dependencies == []


# Generated at 2022-06-23 07:01:52.500015
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    datastruct_deps = [
        {
            "role": "geerlingguy.java",
            "name": "geerlingguy.java",
            "src": "https://galaxy.ansible.com/geerlingguy/java",
            "scm": None,
            "path": "https://galaxy.ansible.com/api/v1/roles/geerlingguy.java"
        },
        "common"
    ]

# Generated at 2022-06-23 07:01:57.840630
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    x_data = {'allow_duplicates': True,
              'dependencies': ['role1', 'role2']}
    x = RoleMetadata().load(x_data, owner=None)

    assert x.allow_duplicates == True
    assert x.dependencies == ['role1', 'role2']

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-23 07:02:05.497407
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    v = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                role="jdoe.myrole1",
            ),
            dict(
                role="jdoe.myrole2",
                collection="namespace.mycollection1",
                version="2.2.0"
            ),
        ]
    )
    metadata = RoleMetadata()
    metadata.deserialize(v)
    assert metadata.serialize() == v

# Generated at 2022-06-23 07:02:10.711776
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print('Test Start')
    m = RoleMetadata()
    data = {'allow_duplicates':False, 'dependencies':['test1', 'test2']}
    m.deserialize(data)
    assert m._allow_duplicates == False
    assert m._dependencies == ['test1', 'test2']
    print('Test ENDS\n')

if __name__ == '__main__':
    test_RoleMetadata_deserialize()

# Generated at 2022-06-23 07:02:11.306969
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-23 07:02:23.483120
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import os
    class System:
        pass
    system = System()
    system.basedir = "test_RoleMetadata_basedir"

    class Play:
        def __init__(self, system=system):
            self._system = system
    play = Play()

    class Owner:
        pass
    owner = Owner()
    owner._play = play

    rm = RoleMetadata(owner=owner)
    assert(rm._allow_duplicates == False)
    assert(rm._dependencies == [])

    # set _owner to None to test that load() is not called
    rm._owner = None
    assert(rm.load(dict(), owner, None, None) == rm)
    assert(rm._allow_duplicates == False)
    assert(rm._dependencies == [])


# Generated at 2022-06-23 07:02:28.203244
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    role_metadata.deserialize(data)

    assert not role_metadata.allow_duplicates
    assert not role_metadata.dependencies

# Generated at 2022-06-23 07:02:30.266131
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-23 07:02:38.898475
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_name = 'test_RoleMetadata'
    test_dict_role_metadata = dict(
        allow_duplicates=True,
        dependencies=[dict(role='test_role_1'), dict(role='test_role_2')]
    )

    # pylint: disable=protected-access
    role_metadata = RoleMetadata().load_data(test_dict_role_metadata)
    assert role_metadata.name == test_name
    assert role_metadata.allow_duplicates == test_dict_role_metadata.get('allow_duplicates')
    assert len(role_metadata.dependencies) == len(test_dict_role_metadata.get('dependencies'))

# Generated at 2022-06-23 07:02:45.390427
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Empty cache
    RoleMetadata._cache = {}

    role = RoleMetadata(owner="owner")
    role.deserialize(data={
        'allow_duplicates': True,
        'dependencies': ['common-role']
    })

    assert role.allow_duplicates is True
    assert role.dependencies == ['common-role']

# Generated at 2022-06-23 07:02:54.359222
# Unit test for method serialize of class RoleMetadata

# Generated at 2022-06-23 07:03:07.864194
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # Test 'dependencies' section

    # Scalar string
    data = { 'dependencies': 'test' }
    role_metadata = RoleMetadata(owner='test').load_data(data)
    assert role_metadata._dependencies == ['test']

    # List of strings
    data = { 'dependencies': [ 'test' ] }
    role_metadata = RoleMetadata(owner='test').load_data(data)
    assert role_metadata._dependencies == ['test']

    # Scalar dict
    data = { 'dependencies': { 'role': 'test' } }
    role_metadata = RoleMetadata(owner='test').load_data(data)
    assert role_metadata._dependencies == [{ 'role': 'test' }]

    # Scalar dict with an extra k/v pair

# Generated at 2022-06-23 07:03:10.793839
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role

    mock_data = dict(
        allow_duplicates=True,
        dependencies=[dict(role='role_dependency'), dict(role='role_dependency2')]
    )

    role = Role()
    try:
        RoleMetadata.load(mock_data, role)
    except Exception as ex:
        raise ex

# Generated at 2022-06-23 07:03:18.187429
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata instance
    m = RoleMetadata()

    # invoke deserialize method
    m.deserialize({'allow_duplicates': True,
                   'dependencies': ['common']})

    # Verify that the attributes are correctly set
    assert m._allow_duplicates is True
    assert m._dependencies == ['common']

# Generated at 2022-06-23 07:03:20.227841
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata.deserialize('{"allow_duplicates": True, "dependencies": ["foo.bar:1.2.3"]}')

# Generated at 2022-06-23 07:03:27.018927
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )
    m.deserialize(data)
    assert m._allow_duplicates == True
    assert m._dependencies == ['role1', 'role2']
    data = dict(
        allow_duplicates=False,
        dependencies=['role1', 'role2']
    )
    m.deserialize(data)
    assert m._allow_duplicates == False
    assert m._dependencies == ['role1', 'role2']

# Generated at 2022-06-23 07:03:37.316723
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict())

    # RoleMetadata(allow_duplicates=None, dependencies=None).
    data = dict(
        allow_duplicates=True,
        dependencies=['role1'],
        )
    meta = RoleMetadata.load(data, owner=None, variable_manager=None, loader=None)
    assert meta.allow_duplicates is True
    assert meta.dependencies == ['role1']

    # RoleMetadata(allow_duplicates=None, dependencies=None).

# Generated at 2022-06-23 07:03:48.259915
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext

    metadata = RoleMetadata()
    collection_loader_mock = Mock(spec_set=CollectionLoader)
    collection_loader_mock.list_collections.return_value=['rajalokan.mongodb']
    collection_loader_mock.load.return_value='rajalokan.mongodb'
    options_mock = Mock(spec_set=Options)
    options_mock.roles_path = ['~/roles']
    options_mock.collections_paths=['~/collections/']
    collection_loader_mock.path_exists.return_value = True
    variables_mock = Mock(spec_set=VariableManager)

# Generated at 2022-06-23 07:03:51.286231
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert r.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-23 07:03:52.774799
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()


# Generated at 2022-06-23 07:04:01.606392
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata(owner=None)
    r.allow_duplicates = False
    r.dependencies = ['role1', 'role2']
    res = r.serialize()
    assert isinstance(res, dict)
    assert 'allow_duplicates' in res
    assert res['allow_duplicates'] == False
    assert 'dependencies' in res
    assert isinstance(res['dependencies'], list)
    assert 'role1' in res['dependencies']
    assert 'role2' in res['dependencies']


# Generated at 2022-06-23 07:04:07.096005
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {
        'allow_duplicates': True,
        'dependencies': [
            'foo',
            'bar',
            'baz'
        ]
    }

    meta = RoleMetadata()
    meta.load_data(data)

    assert meta.allow_duplicates == True
    assert len(meta.dependencies) == 3



# Generated at 2022-06-23 07:04:07.968124
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:04:11.504568
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    rmd.deserialize({'allow_duplicates': True, 'dependencies': ['test', 'test2']})
    assert rmd.allow_duplicates
    assert rmd.dependencies == ['test', 'test2']


# Generated at 2022-06-23 07:04:13.837952
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    Metadata = RoleMetadata()
    assert Metadata  is not None


# Generated at 2022-06-23 07:04:14.914816
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()

# Generated at 2022-06-23 07:04:17.262590
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert isinstance(RoleMetadata, object)
    assert isinstance(metadata, RoleMetadata)

# Generated at 2022-06-23 07:04:30.371517
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-23 07:04:42.582881
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.playbook.helpers import load_list_of_roles

    data = {
        "dependencies": [
            { "role": "geerlingguy.jenkins" },
            "geerlingguy.mysql",
            { "role": "geerlingguy.apache" },
            { "role": "geerlingguy.php", "x_var": "somevalue" },
            { "name": "geerlingguy.apache", "version": "3.9.0" }
        ]
    }

    r = Role(name='test.role')
    m = RoleMetadata.load(data, owner=r)
    assert isinstance(m, RoleMetadata)
    assert m

# Generated at 2022-06-23 07:04:44.309404
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    RoleMetadata.load(data, owner)


# Generated at 2022-06-23 07:04:48.946774
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    md = RoleMetadata()
    md.deserialize({
        "allow_duplicates": False,
        "dependencies": []
    })
    assert not md._allow_duplicates and not md._dependencies

# Generated at 2022-06-23 07:04:59.455380
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Get the test data.
    from ansible.playbook import role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    datastructure = dict(
        allow_duplicates=False,
        dependencies=[
            "../apache2-role",
            "../ftp-server-role",
            "../database-role",
        ],
    )

    r = role.Role()
    r._role_name = 'test-name'

    # Create the object.
    rm = RoleMetadata(owner=r)

    # Load the data.
    rm.load(datastructure, variable_manager=None, loader=None)

    # Check the results.
    assert rm.allow_duplicates is False

# Generated at 2022-06-23 07:05:03.644586
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    This function is used to test the constructor of class RoleMetadata
    '''

    # Test the input value of owner is not a class Role object
    role = None
    role_metadata = RoleMetadata(owner=role)

    assert role_metadata is not None, 'Test RoleMetadata create failed'
    return role_metadata



# Generated at 2022-06-23 07:05:05.025235
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-23 07:05:07.764500
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    x = dict()
    y = RoleMetadata.load(x, None)
    assert y.allow_duplicates == False
    assert y.dependencies == []

# Generated at 2022-06-23 07:05:16.191260
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.constants import DEFAULT_SUDO_USER, DEFAULT_SUDO_PASS

    _ = RoleRequirement()

    p = PlayContext()
    p.sudo_user = DEFAULT_SUDO_USER
    p.sudo_pass = DEFAULT_SUDO_PASS

    r = Role()
    r._role_name = 'test_role_name'
    r._role_path = 'test_role_path'

    rol = RoleMetadata(owner=r)
    print(rol.serialize())
    # {'galaxy_info': {},
    #  'dependencies': [],
    #

# Generated at 2022-06-23 07:05:20.304091
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_obj = RoleMetadata()
    role_metadata_obj.deserialize(data={'allow_duplicates': False, 'dependencies': list()})
    assert not role_metadata_obj._allow_duplicates
    assert not role_metadata_obj._dependencies

# Generated at 2022-06-23 07:05:25.432852
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert isinstance(m, RoleMetadata)
    assert m._owner is None
    assert not m.allow_duplicates
    assert m.dependencies == []

# Generated at 2022-06-23 07:05:28.446007
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ret = RoleMetadata()
    assert ret._allow_duplicates == False
    assert ret._dependencies == []
    assert ret._galaxy_info == None
    assert ret._argument_specs == {}