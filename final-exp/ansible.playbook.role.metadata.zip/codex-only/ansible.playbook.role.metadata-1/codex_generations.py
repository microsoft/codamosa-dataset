

# Generated at 2022-06-23 06:55:21.074791
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []


# Generated at 2022-06-23 06:55:22.051034
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role=RoleMetadata(owner=None)
    role.test()

# Generated at 2022-06-23 06:55:32.292113
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block

    r = RoleDefinition.load('tests/unit/modules/test_role/', 'test_role')
    assert r.get_dependencies() == []
    assert r.serialize()['metadata']['allow_duplicates'] == False
    assert r.serialize()['metadata']['dependencies'] == []

    b = Block.load(dict(name='task1', with_foo='bar'), r, [], [])
    assert b.serialize() == dict(block=dict(name='task1', with_foo='bar'))

# Generated at 2022-06-23 06:55:36.746877
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("test_RoleMetadata")
    assert RoleMetadata(owner=None)._allow_duplicates is False
    assert RoleMetadata(owner=None)._dependencies == list()
    assert RoleMetadata(owner=None)._galaxy_info is None
    assert RoleMetadata(owner=None)._argument_specs == dict()
    assert RoleMetadata(owner=None)._owner is None
    assert isinstance(RoleMetadata(owner=None)._valid_attrs, dict) is True

test_RoleMetadata()

# Generated at 2022-06-23 06:55:46.834472
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    list_of_roles = [{'role': 'tomcat'}, 'apache', RoleDefinition(role_name='mariadb')]
    role_meta = RoleMetadata(owner=Play())
    role_meta._dependencies = list_of_roles
    role_meta._load_dependencies('dependencies', list_of_roles)
    assert isinstance(role_meta.dependencies[0], RoleInclude)
    assert isinstance(role_meta.dependencies[1], RoleInclude)
    assert isinstance(role_meta.dependencies[2], RoleDefinition)

# Generated at 2022-06-23 06:55:47.855523
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    x = RoleMetadata()


# Generated at 2022-06-23 06:55:56.614691
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    owner = object()
    RoleMetadata._valid_attrs = {'allow_duplicates': FieldAttribute(isa='bool', default=False),
                                 'dependencies': FieldAttribute(isa='list', default=list)
                                }

    data = dict(allow_duplicates=True,
                dependencies=['role1', 'role2'],
                galaxy_info=None)
    rm = RoleMetadata(owner)
    rm.deserialize(data)

    assert rm.allow_duplicates

# Generated at 2022-06-23 06:56:01.136221
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
  """
  (RoleMetadata) -> Bool

  Tests if an error is raised if the data structure passed in is not a dictionary.
  """
  data = "A string"
  correct = False
  try:
    RoleMetadata.load(data, None)
  except AnsibleParserError:
    correct = True
  return(correct)



# Generated at 2022-06-23 06:56:06.695956
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_md_obj = RoleMetadata()
    data = {
        'allow_duplicates' : False,
        'dependencies' : [ { 'role' : 'foobar' } ]
    }
    role_md_obj.deserialize(data)
    assert role_md_obj._dependencies[0].role == 'foobar'

test_RoleMetadata_deserialize()

# Generated at 2022-06-23 06:56:07.318855
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-23 06:56:09.494474
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({'allow_duplicates': True})
    assert m.allow_duplicates

# Generated at 2022-06-23 06:56:17.836058
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    module = AnsibleModule(
        argument_spec=dict(
            test_data=dict(required=True, type='dict'),
            collection_paths=dict(required=True, type='list'),
        )
    )

    collection_search_list = module.params['collection_paths']
    data = module.params['test_data']

    RoleMetadata.load(data=data, owner=None, variable_manager=None, loader=None)
    module.exit_json(changed=False)


# import module snippets
from ansible.module_utils.basic import *

# import test snippets
from ansible.module_utils import basic
from ansible.module_utils.six import iteritems

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 06:56:27.114540
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.requirement import RoleRequirement
    x = RoleMetadata()

    setattr(x, 'allow_duplicates', False)
    setattr(x, 'dependencies', [RoleRequirement.role_yaml_parse('test-role,1.2.3')])

    serialized_data = {
        'allow_duplicates': False,
        'dependencies': [{'role': 'test-role', 'version': '1.2.3'}]
    }
    assert x.serialize() == serialized_data


# Generated at 2022-06-23 06:56:33.387314
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role().load('test', '', True, None, None)
    data = dict(
        allow_duplicates = False,
        dependencies = []
    )
    m = RoleMetadata(role).deserialize(data)
    m.serialize()
    assert m != None

# Generated at 2022-06-23 06:56:38.850979
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata_role_file = open("./tests/test_metadata_role.yml", "r")
    metadata_role_content = metadata_role_file.read()
    metadata_role_file.close()
    data = metadata_role_content

    d = RoleMetadata()
    d.deserialize(data)

    assert d.dependencies == ['role1', 'role2']


# Generated at 2022-06-23 06:56:45.114112
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    assert m.serialize() == {'allow_duplicates': False, 'dependencies': []}
    m.allow_duplicates = True
    assert m.serialize() == {'allow_duplicates': True, 'dependencies': []}
    m.dependencies = [1, 2, 3]
    assert m.serialize() == {'allow_duplicates': True, 'dependencies': [1, 2, 3]}

# Generated at 2022-06-23 06:56:53.828163
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata.load({"dependencies": [{"src": "git+git@github.com/enterprisemodules/emc_vnx_role.git", "version": "v0.0.1", "scm": "git", "name": "emc_vnx_role"}], "allow_duplicates": True})
    assert r.serialize() == {"allow_duplicates": True, "dependencies": [{"src": "git+git@github.com/enterprisemodules/emc_vnx_role.git", "version": "v0.0.1", "scm": "git", "name": "emc_vnx_role"}]}


# Generated at 2022-06-23 06:57:05.385406
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    data = """
---
dependencies:
  - { role: parent, scm: git, src: git@github.com/user/parent.git }
  - { role: parent, scm: git, src: git@github.com/user/parent.git, version: v1.2.3 }
  - parent
  - { role: parent, version: v1.2.3 }
  - parent,v1.2.3
  - { role: parent }
  - { name: geerlingguy.example }
"""
    # load data
    loader = AnsibleCollectionLoader()


# Generated at 2022-06-23 06:57:07.542596
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': ['role1', 'role2']
    }
    r.deserialize(data)
    assert r.allow_duplicates == True
    assert r.dependencies == ['role1', 'role2']

# Generated at 2022-06-23 06:57:20.367901
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-23 06:57:21.226107
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    assert meta is not None

# Generated at 2022-06-23 06:57:23.887217
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    assert r.deserialize(dict(
        allow_duplicates=True,
        dependencies=['bob']
    )) == None
    assert r._allow_duplicates == True
    assert r._dependencies == ['bob']

# Generated at 2022-06-23 06:57:24.714726
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 06:57:28.852333
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=list(),
    )

    m = RoleMetadata()
    m.deserialize(data)
    assert m.serialize() == data

# Generated at 2022-06-23 06:57:39.338959
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Unit test for method deserialize of class RoleMetadata
    '''
    import os
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

    # get current directory
    playbook_dir = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-23 06:57:48.379616
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Create a test data structure
    testdata = dict(
        allow_duplicates=True,
        dependencies=['test1', 'test2']
    )

    # Create a new RoleMetadata object
    myRoleMetadata = RoleMetadata()

    # Call the deserialize() method of class RoleMetadata
    myRoleMetadata.deserialize(testdata)

    # Check the allow_duplicates attribute to see if it contains the expected value
    assert myRoleMetadata.allow_duplicates == True

    # Check the dependencies attribute to see if it contains the expected value
    assert myRoleMetadata.dependencies == ['test1', 'test2']

    return True


# Generated at 2022-06-23 06:57:54.709224
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    filename = "/home/user1/ansible-repo/roles/role1/meta/main.yml"
    test_ds = {'allow_duplicates': True}
    result = RoleMetadata.load(data=test_ds, owner=None)
    assert result['allow_duplicates'] is True


# Generated at 2022-06-23 06:57:59.596354
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # create a class object
    metadata = RoleMetadata()
    assert metadata.serialize() == {}
    # create another class object
    metadata = RoleMetadata()
    metadata._allow_duplicates = True
    metadata._dependencies = [1, 2, 3]
    assert metadata.serialize() == {'allow_duplicates': True, 'dependencies': [1, 2, 3]}


# Generated at 2022-06-23 06:58:05.903896
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    The logic of this test is to test if a deserialize method of class RoleMetadata
    properly sets variables
    """
    metadata = RoleMetadata(owner = "")
    metadata.deserialize({"allow_duplicates": True, "dependencies": "dksfjdfkss"})
    assert metadata.allow_duplicates == True
    assert metadata.dependencies == "dksfjdfkss"

# Generated at 2022-06-23 06:58:11.305084
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(
        dependencies=[
            dict(dependency_name="name1", dependency_src='src1'),
            dict(dependency_name="name2", dependency_src='src2')
        ]
    ))

    assert len(role_metadata.dependencies) == 2
    for dependency in role_metadata.dependencies:
        assert isinstance(dependency, dict)
        assert dependency == dict(dependency_name="name1", dependency_src='src1') or dependency == dict(dependency_name="name2", dependency_src='src2')


# Generated at 2022-06-23 06:58:19.689055
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os, sys
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from ansible.playbook.role.definition import RoleDefinition
    import ansible.constants as C

    role_path = C.DEFAULT_ROLES_PATH[1]
    role = RoleDefinition.load(role_path)
    meta = RoleMetadata.load(role._metadata_path, role)
    assert meta._name == 'meta'
    assert isinstance(meta._dependencies, list)

if __name__ == '__main__':
    test_RoleMetadata_load()

# Generated at 2022-06-23 06:58:23.877197
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_data = dict(
        allow_duplicates=True,
        dependencies=['a', 'b', 'c']
    )
    r_meta = RoleMetadata()
    r_meta.deserialize(test_data)
    assert r_meta.serialize() == test_data

# Generated at 2022-06-23 06:58:35.782293
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_data = """
---

allow_duplicates: false
dependencies:
    - role: geerlingguy.apache
    - role: geerlingguy.apache

...
""".strip()
    data = AnsibleLoader(yaml_data, file_name=None).get_single_data()
    assert data == {
        u'allow_duplicates': False,
        u'dependencies': [
            {u'role': u'geerlingguy.apache'},
            {u'role': u'geerlingguy.apache'},
        ]
    }



# Generated at 2022-06-23 06:58:39.050503
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata(owner = "owner")
    assert role.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 06:58:39.719279
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 06:58:42.755297
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test for constructor of class RoleMetadata.
    '''

    metadata = RoleMetadata()
    assert metadata._allow_duplicates == False
    assert metadata._dependencies == []



# Generated at 2022-06-23 06:58:54.594580
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-23 06:58:55.812554
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rm = RoleMetadata()
    assert rm is not None

# Generated at 2022-06-23 06:59:04.669896
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.collection import find_collection_roles
    from ansible.collections.ansible.community.plugins.module_utils.helpers import path_dwim
    from ansible.parsing.dataloader import DataLoader

    # test role that doesn't exist in any collection or role_path
    r1 = Role('role_does_not_exist')
    with pytest.raises(AnsibleParserError):
        r1.metadata

    # test role that exists in a collection
    r2 = Role(path_dwim('./test/units/module_utils/legacy_place'))
    assert r2.metadata.dependencies == [{'role': 'community.general.legacy_integration'}]

    # test role that

# Generated at 2022-06-23 06:59:06.600629
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Create test objects
    m = RoleMetadata()
    d = {'allow_duplicates': True, 'dependencies': ['test']}

    # Test deserialize method
    m.deserialize(d)

    assert m.allow_duplicates == True
    assert m.dependencies == ['test']

# Generated at 2022-06-23 06:59:17.586401
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task.include_role import TaskIncludeRole

    test_play = dict(
        name='test',
        hosts='all',
        tasks=[dict(action=dict(module='debug', args=dict(msg='Hello World!')))]
    )

# Generated at 2022-06-23 06:59:29.271358
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    data = dict(
        allow_duplicates=False,
        dependencies=list(),
    )
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory('localhost'))

    play = Play().load(dict(
        name='test',
        hosts='localhost',
        connection='local',
        gather_facts='no',
        roles=list(),
    ), variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:59:37.467694
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Expected output is object of type RoleMetadata
    data = {'allow_duplicates': False, 'dependencies': []}
    owner = False
    variable_manager = False
    loader = False
    actual_output = RoleMetadata.load(data, owner, variable_manager, loader)
    expected_output = 'RoleMetadata'
    assert type(actual_output).__name__ == expected_output, "Expected {0}, but returned {1}".format(expected_output, type(actual_output).__name__)


# Generated at 2022-06-23 06:59:48.460283
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    class RoleInclude:
        def __init__(self, name):
            self._name = name

        @property
        def name(self):
            return self._name

        def serialize(self):
            return dict(
                name=self._name
            )

        def __str__(self):
            return self._name

    def test_serialize(r_m_obj, r_i_obj_list, d_list):
        data_dict = r_m_obj.serialize()
        assert data_dict['allow_duplicates'] == r_m_obj._allow_duplicates
        assert data_dict['dependencies'] == d_list


# Generated at 2022-06-23 06:59:55.527133
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=['foo'],
        )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    serialized_data = role_metadata.serialize()
    assert data == serialized_data

# Generated at 2022-06-23 07:00:04.199992
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader

    # Setup
    the_loader = AnsibleCollectionLoader()
    data_loader = DataLoader()
    role_name = "test_role_name"
    role_data = dict(galaxy_info=dict(author="test_author", description="test_role_description",
                                       company="test_company", license="test_license", min_ansible_version="2.0",
                                       platforms=dict(blah=[dict(blah=dict(supports_check_mode=True))])),
                     dependencies=dict(blah=dict(blah=dict(supports_check_mode=True))))
    role = Role()
    setattr

# Generated at 2022-06-23 07:00:15.620062
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    context = PlayContext()
    context._options = dict(
        connection = 'local',
        become = False,
        become_method = 'sudo',
        become_user = None,
        check = False,
        diff = False,
        forks = 100,
        remote_user = "test",
        module_path = '',
        private_key_file = '',
        role_path = [],
        vault_password_file = '',
        verbosity = 1,
        start_at_task='',
        step=False)
    context.become = False
    context.become_method = 'sudo'
    context.become_user = 'cjay'
    context.check_mode = False


# Generated at 2022-06-23 07:00:25.153129
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.play.play import Play
    from ansible.playbook.task import Task

    metadata = '''
dependencies:
  - { role: some_role, tags: "some_tag" }
'''

    role_mock = mock.Mock()

    role_mock.get_name.return_value = 'some_role'
    role_mock.get_path.return_value = '/home/test/some_role'

    play_mock = mock.Mock()

    play_mock.get_name.return_value = 'some_play'
    play_mock.get_roles.return_value = []

    task_mock = mock.Mock()

    task_mock.get_name.return_value = 'some_task'
    task_mock.get_

# Generated at 2022-06-23 07:00:31.241475
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_object = RoleMetadata()
    assert test_object.deserialize({'allow_duplicates': True, 'dependencies': ['test1', 'test2']}) == {'allow_duplicates': True, 'dependencies': ['test1', 'test2']}
    assert test_object.deserialize({'allow_duplicates': False, 'dependencies': ['test']}) == {'allow_duplicates': False, 'dependencies': ['test']}

# Generated at 2022-06-23 07:00:36.067979
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    r = RoleMetadata()
    r.deserialize(data)
    assert(r.allow_duplicates is False)
    assert(r.dependencies == [])
    assert(r._owner is None)

# Generated at 2022-06-23 07:00:47.468837
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Playbook:
    - hosts: localhost
      tasks:
      - include_role:
          name: test_RoleMetadata
    '''
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task

    # Create a Play with a Task
    task = Task()

    # Create a RoleDefinition with a RoleMetadata to test
    role_definition = RoleDefinition.load(dict(
        name='test_RoleMetadata',
        tasks=[task],
        meta=dict(
            allow_duplicates=True,
            dependencies=['test_RoleInclude'],
            argument_specs=dict(
                test_arg=dict(
                    default='test_value'
                ),
            )
        )
    ))

    # Load the RoleMetadata
   

# Generated at 2022-06-23 07:00:50.900161
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata.load(dict(allow_duplicates=True, dependencies=[dict(role="mj")]), owner="mj", variable_manager=None,
                          loader=None)
    assert r.serialize() == dict(allow_duplicates=True, dependencies=[dict(role="mj")])



# Generated at 2022-06-23 07:00:51.495752
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:01:00.496333
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello Ansible Playbook')))
        ]
    )

# Generated at 2022-06-23 07:01:05.911027
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )
    role_meta.deserialize(data)
    assert role_meta.allow_duplicates is True
    assert role_meta.dependencies == ['role1', 'role2']


# Generated at 2022-06-23 07:01:06.543317
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass

# Generated at 2022-06-23 07:01:08.338235
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None


# Generated at 2022-06-23 07:01:17.788965
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    bad_value_data = ('xxx', 1, True)
    for d in bad_value_data:
        try:
            RoleMetadata.load(data=d, owner="test")
            assert False, "Expected AnsibleParserError"
        except AnsibleParserError:
            pass

    bad_key_data = ({'name': 'test', 'not_dependencies': []}, {'name': 'test', 'dependencies': {}})
    for d in bad_key_data:
        try:
            RoleMetadata.load(data=d, owner="test")
            assert False, "Expected AnsibleParserError"
        except AnsibleParserError:
            pass

    good_data = ({'name': 'test', 'dependencies': []}, {'name': 'test', 'dependencies': [{}]})

# Generated at 2022-06-23 07:01:18.598435
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:01:22.330392
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    serialize_dict = m.serialize()
    assert serialize_dict['allow_duplicates'] == False
    assert isinstance(serialize_dict['dependencies'], list)


# Generated at 2022-06-23 07:01:31.602028
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude

    role_directory = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'lib', 'ansible', 'modules', 'extras')
    role_definition = RoleDefinition(name='test', path=role_directory)
    metadata = RoleMetadata(owner=role_definition)
    metadata.dependencies = [RoleRequirement.role_yaml_parse('foo'), RoleRequirement.role_yaml_parse('bar')]
    metadata.allow_duplicates = True
    serialized = metadata.serialize()

# Generated at 2022-06-23 07:01:36.652162
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    setattr(metadata, 'allow_duplicates', True)
    setattr(metadata, 'dependencies', ['role1', 'role2'])
    assert metadata.serialize() == dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )



# Generated at 2022-06-23 07:01:47.788935
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    import tempfile
    import json

    tmp_dir = tempfile.mkdtemp()
    role_path = tmp_dir + '/library/role1'
    if not os.path.exists(role_path):
        os.makedirs(role_path)

    data = """
    ---
    meta/main.yml
    """
    with open(role_path + "/meta/main.yml", "w+") as f:
        f.write(data)

    role = Role.load(name="role1", role_path=role_path)
    role_req = RoleRequirement()
    role_req.role = role
    role_req.role_path = role_path
    
   

# Generated at 2022-06-23 07:01:52.734869
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['ansible.legacy.windows']}
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == ['ansible.legacy.windows']

# Generated at 2022-06-23 07:02:01.370355
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """ Test load function of RoleMetadata """
    # pylint: disable=too-few-public-methods,no-member
    """ Test load function of RoleMetadata """
    # pylint: disable=too-few-public-methods,no-member
    """ Test load function of RoleMetadata """

    class FakeOwner(object):
        """ Fake class for owner of RoleMetadata """

        def __init__(self):
            self.name = 'role1'
            self._play = FakePlay()
            self._role_path = ''
            self._role_collection = FakeCollection()
            self.collections = [self._role_collection]

    class FakePlay(object):
        """ Fake class for play of FakeOwner """

        def __init__(self):
            self.hosts = dict()
            self.vars

# Generated at 2022-06-23 07:02:13.030922
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    role1_path = '/path/to/role/dir'
    role2_path = '/path/to/dependency/dir'

    role1_metadata = {
        'allow_duplicates': True,
        'dependencies': [
            {'role': '../role2'},
            'dependency2',
            {'role': '../../role3'},
            {'role': '/absolute/path/to/dependency/dir'}
        ]
    }

    role2 = Role()
    role2._role_path = role2_path
    role2.meta = RoleMetadata.load(
        role1_metadata,
        role1_path,
        owner=role1
    )

    assert role2.meta.allow_duplicates is True


# Generated at 2022-06-23 07:02:25.371548
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
        # construct some fake data for loading
        meta_data = '''
        allow_duplicates: True
        dependencies:
        - { role: name, scm: git+https://github.com/foo_org/foo_name }
        '''
        fake_loader = MockLoader()
        fake_loader.path_exists.side_effect = lambda path: True
        fake_loader.is_directory.side_effect = lambda path: True
        fake_loader._read_yaml_from_file.side_effect = lambda path: { 'allow_duplicates': True, 'dependencies': [{ 'role': 'name', 'scm': 'git+https://github.com/foo_org/foo_name' }] }

        from ansible.playbook.role.definition import RoleDefinition
        fake_owner = RoleDefinition.load

# Generated at 2022-06-23 07:02:33.256277
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    This test checks that all parameters of RoleMetadata().load
    have the expected type.
    '''

    class _Mock_Role(object):
        '''
        A mock class of Role.
        '''

        def __init__(self):
            '''
            Constructor.
            '''

            self.name = ''

        def get_name(self):
            '''
            Getter.
            '''

            return self.name

    data = {}
    owner = _Mock_Role()
    variable_manager = None
    loader = None

    m = RoleMetadata.load(data, owner, variable_manager, loader)

    assert type(m) is RoleMetadata

# Generated at 2022-06-23 07:02:44.250599
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    # Mock data.
    # 1) A meta/main.yml file content with dependency on galaxy role:
    #  ---
    #  dependencies:
    #  - role: galaxy.role
    #    version: 0.1.0
    # 2) A dependency.yml file with galaxy_role_info:
    #  ---
    #  dependency_links:
    #  - https://github.com/user/repo/raw/branch/archive.tar.gz

# Generated at 2022-06-23 07:02:50.759317
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = True
    m.dependencies = ["name: localhost", {"role": "common", "other_vars": "yes"}]
    serialized = m.serialize()
    assert serialized['allow_duplicates'] == True
    assert serialized['dependencies'] == ["name: localhost", {"role": "common", "other_vars": "yes"}]

# Generated at 2022-06-23 07:02:59.160379
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_dir = os.path.dirname(os.path.dirname(__file__))
    test_case = os.path.join(test_dir, 'test_cases/meta/main.yml')
    ds = {}
    with open(test_case) as f:
        ds = f.read()
    r = RoleMetadata.load(ds)
    assert r is not None
    assert len(r.dependencies) == 12
    assert r.dependencies[0].get('role') == 'daniellawrence.mongodb'
    assert r.dependencies[0].get('name') == 'daniellawrence.mongodb'
    assert r.dependencies[0].get('version') is None
    assert r.dependencies[0].get('scm') == 'git'

# Generated at 2022-06-23 07:03:01.051735
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner=None)
    m._allow_duplicates = True
    assert m._allow_duplicates == True

# Generated at 2022-06-23 07:03:14.706320
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test when dependencies is empty
    data1 = {'dependencies': []}

    # Test when there is a single dependency
    data2 = {'dependencies': [{'role': 'foo', 'a': 'b'}]}

    # Test when there is a single dependency
    data3 = {'dependencies': [{'role': 'foo'}, {'role': 'bar'}]}

    rm = RoleMetadata(owner=None)
    rm.deserialize(data1)
    assert rm.dependencies == []
    rm.deserialize(data2)
    assert rm.dependencies == [{'role': 'foo', 'a': 'b'}]
    rm.deserialize(data3)
    assert rm.dependencies == [{'role': 'foo'}, {'role': 'bar'}]

# Generated at 2022-06-23 07:03:21.576184
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # create empty objects to be loaded
    my_rolemetatada = RoleMetadata()
    my_data = dict()
    my_owner = None

    # test load with empty object and empty data
    loaded_rolemetatada = RoleMetadata.load(my_data, my_owner)
    assert loaded_rolemetatada._dependencies == []
    assert loaded_rolemetatada._allow_duplicates == False

# Generated at 2022-06-23 07:03:24.974204
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info is None
    assert role_metadata._argument_specs == {}
    assert role_metadata._owner is None

# Generated at 2022-06-23 07:03:25.961534
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata()

# Generated at 2022-06-23 07:03:30.088136
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }


# Generated at 2022-06-23 07:03:38.757799
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    owner = object()
    galaxy_info_str = '{"author": "ANXS", "description": "Installs PHP 5.4", "company": "", "license": "MIT", "issues_url": null, "platforms": [{"name": "Debian", "versions": ["7", "8"], "dependencies": []}, {"name": "Ubuntu", "versions": ["10.04", "12.04", "14.04"], "dependencies": []}], "galaxy_tags": [], "repository": "https://github.com/ANXS/php", "min_ansible_version": "1.2", "name": "ANXS.php", "dependencies": [], "src": "", "version": "0.1"}'

# Generated at 2022-06-23 07:03:49.007331
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # check RoleMetadata.load function with data type `dict`
    data = {'allow_duplicates': False, 'dependencies': []}
    try:
        m = RoleMetadata.load(data, owner={'get_name': lambda: 'test'})
    except AnsibleParserError as e:
        assert False, "RoleMetadata.load with data type `dict` raise a exception: %s" % e
    assert isinstance(m, RoleMetadata), "RoleMetadata.load with data type `dict` return type `RoleMetadata`"

    # check RoleMetadata.load function with data type `list`
    data = [{'src': 'galaxy.role', 'name': 'galaxy_role'}]

# Generated at 2022-06-23 07:03:55.491341
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': ['test_role']
    }
    r.deserialize(data)
    assert r._allow_duplicates == True
    assert r._dependencies == ['test_role']

# Generated at 2022-06-23 07:03:59.480891
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    Unit test for constructor of class RoleMetadata
    """

    result = RoleMetadata()
    assert result._allow_duplicates == False
    assert result._dependencies == []
    assert result._galaxy_info == {}

# Generated at 2022-06-23 07:04:07.484990
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    #case: tests that defaults are set
    if not m.allow_duplicates:
        raise Exception('Expected default value for allow_duplicates to be True')
    if m.dependencies:
        raise Exception('Expected default value for dependencies to be an empty list.')

    #case: tests the deserialization
    data = {'allow_duplicates': False, 'dependencies': [{'src': '../../foo/bar'}]}
    m.deserialize(data)
    m.init_attributes()
    if m.allow_duplicates:
        raise Exception('Deserialize was not successful')
    if not m.dependencies:
        raise Exception('Deserialize was not successful')

# Generated at 2022-06-23 07:04:19.075976
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    This method tests the load method of class RoleMetadata
    """
    import os
    import sys
    import tempfile
    import string
    import random
    import imp
    import shutil
    TEST_DIR = tempfile.mkdtemp()
    sys.path.insert(0, TEST_DIR)

    RoleMetadata_path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/playbook/role/meta.py')
    with open(RoleMetadata_path, mode='rt') as f:
        RoleMetadata_code = f.read()
    RoleMetadata_mod = imp.new_module('RoleMetadata')
    exec(RoleMetadata_code, RoleMetadata_mod.__dict__)

# Generated at 2022-06-23 07:04:32.228548
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import collections
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.compat.tests import unittest

    class TestRoleMetadata(unittest.TestCase):
        def setUp(self):
            self.variable_manager = VariableManager()
            self.loader = None
            #self.inventory = Inventory(loader=self.loader, variable_manager=self.variable_manager, host_list=[])
            self.inventory = None

# Generated at 2022-06-23 07:04:35.483380
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta_data = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    role_meta_data.deserialize(data)

    assert role_meta_data.allow_duplicates == False
    assert role_meta_data.dependencies == []

# Generated at 2022-06-23 07:04:39.445083
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner=None)
    assert m._allow_duplicates == False
    assert m._dependencies == []

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-23 07:04:49.287872
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test data
    role_metadata = RoleMetadata()
    setattr(role_metadata, 'allow_duplicates', True)
    setattr(role_metadata, 'dependencies', ['ansible.builtin', 'ansible.legacy'])
    serialize_result = role_metadata.serialize()
    assert serialize_result.get('allow_duplicates') == True, "Test failed: test_RoleMetadata_serialize: method serialize: return value of allow_duplicates is not correct"
    assert serialize_result.get('dependencies') == ['ansible.builtin', 'ansible.legacy'], "Test failed: test_RoleMetadata_serialize: method serialize: return value of dependencies is not correct"
    print("Test passed: test_RoleMetadata_serialize: method serialize")

#

# Generated at 2022-06-23 07:04:58.650094
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test default values
    def_class_obj = RoleMetadata()

    assert def_class_obj._allow_duplicates == False
    assert def_class_obj._dependencies == []
    assert def_class_obj._galaxy_info == None
    assert def_class_obj._argument_specs == {}

    # Test overloaded constructor
    class_obj = RoleMetadata("owner")

    assert class_obj._allow_duplicates == False
    assert class_obj._dependencies == []
    assert class_obj._galaxy_info == None
    assert class_obj._argument_specs == {}
    assert class_obj._owner == "owner"


# Generated at 2022-06-23 07:05:06.481043
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    role_path = os.path.join(os.getcwd(), 'test/unit/test_modules/test_meta_main')

    RoleMetadata.load(loader.load_from_file(os.path.join(role_path, 'meta', 'main.yml')), None,
                      variable_manager=VariableManager(), loader=loader)

# Generated at 2022-06-23 07:05:10.941441
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert isinstance(m, RoleMetadata)
    assert isinstance(m, Base)
    assert m._allow_duplicates == False
    assert m._dependencies == list()
    assert m._galaxy_info == None
    assert m._argument_specs == dict()
    assert m._owner == None

# Generated at 2022-06-23 07:05:18.480352
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role, RoleRequirement
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.yaml.objects import YAMLInclude, RoleInclude
