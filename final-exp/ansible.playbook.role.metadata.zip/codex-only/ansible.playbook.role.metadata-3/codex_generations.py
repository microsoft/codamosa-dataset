

# Generated at 2022-06-23 06:55:24.659920
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test method for RoleMetadata class.
    '''
    roleMetadata = RoleMetadata()
    assert roleMetadata._allow_duplicates == False, "Allow duplicates default value is wrong"
    assert roleMetadata._dependencies == [], "Dependencies default value is wrong"
    assert roleMetadata._galaxy_info == None, "Galaxy info default value is wrong"
    assert roleMetadata._argument_specs == {}, "Argument specs default value is wrong"

# Generated at 2022-06-23 06:55:32.539050
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.module_utils.six.moves.configparser import SafeConfigParser
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    data = '''
    ---
    - name: myplaybook
      hosts: all
      roles:
        - myrole1
        - role: myrole2
          tasks:
            - name: task 1
            - name: task 2
        - myrole3
      tasks:
        - name: task 3
    '''
    parser = Playbook.load(data, variable_manager=PlayContext().variable_manager, loader=Playbook.loader)
    assert len(parser.get_plays()) == 1
    play = parser.get_

# Generated at 2022-06-23 06:55:36.227766
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_case = dict(
        allow_duplicates=True,
        dependencies=["role:foo", "role:bar"]
    )
    role_metadata = RoleMetadata()
    assert role_metadata.deserialize(test_case)['allow_duplicates']
    assert role_metadata.serialize() == dict(
        allow_duplicates=True,
        dependencies=["role:foo", "role:bar"]
    )

# Generated at 2022-06-23 06:55:46.432096
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': [] }
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    data = {'allow_duplicates': True, 'dependencies': [{'name': 'apache', 'src': 'http://foo.com/apache.tar.gz'}] }
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies[0].name == 'apache'
    assert role_metadata.dependencies[0].src == 'http://foo.com/apache.tar.gz'

# Generated at 2022-06-23 06:55:55.782622
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement

    import os
    import tempfile
    from shutil import rmtree

    # Create a role
    role_directory = tempfile.mkdtemp()
    meta_path = os.path.join(role_directory, 'meta')
    os.mkdir(meta_path)

    # Create a meta/main.yml file
    meta_main_path = os.path.join(meta_path, 'main.yml')
    meta_main_file = open(meta_main_path, 'w')

# Generated at 2022-06-23 06:56:01.924630
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    role1 = RoleInclude()
    role1._role_name = 'test'
    role1._role_path = '/test/test/test'
    role1._role_collection = None
    role1._task = Task()
    role1._task.load(data={'include_role': {'name': 'test'}}, attr_name="include_role", loader=loader)

    role2 = RoleInclude()
    role2._role_name = 'test'
    role2._role_path = '/test/test/test'
    role2._role_collection = None

# Generated at 2022-06-23 06:56:04.920743
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._data == dict()


# Generated at 2022-06-23 06:56:15.089356
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.taggable import Taggable

    class DummyTaggable(Taggable):
        pass

    p = Play().load({}, variable_manager=None, loader=None)

    role_def = RoleDefinition().load({"name": "role1", "hosts": ["all"], "tasks": []}, play=p)
    r1 = role_def.get_role()
    r1.metadata._allow_duplicates = True
    r1.metadata._dependencies = [{"name": "role1", "role": "role1"}]
    r1.metadata

# Generated at 2022-06-23 06:56:16.021603
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print(RoleMetadata(owner='1'))

# Generated at 2022-06-23 06:56:23.887904
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.collection_include import RoleCollectionInclude

# Generated at 2022-06-23 06:56:30.034467
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()

    dependencies = []
    role_metadata._dependencies = dependencies
    allow_duplicates = True
    role_metadata._allow_duplicates = allow_duplicates

    role_metadata_dict = role_metadata.serialize()

    assert role_metadata_dict['dependencies'] == dependencies
    assert role_metadata_dict['allow_duplicates'] == allow_duplicates


# Generated at 2022-06-23 06:56:41.556919
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    for value in [1, 'str']:
        try:
            m.deserialize({'allow_duplicates': value})
        except TypeError:
            pass
        else:
            raise AssertionError('Expected TypeError')
    for value in [1, 'str']:
        try:
            m.deserialize({'dependencies': value})
        except TypeError:
            pass
        else:
            raise AssertionError('Expected TypeError')

# Generated at 2022-06-23 06:56:48.773662
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Role(object):
        def __init__(self):
            self.name = 'RoleTest'
    role = Role()
    role_metadata = RoleMetadata(role)
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 06:56:53.650727
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            {'role': 'foo'},
            {'role': 'bar', 'name': 'foo'},
        ]
    )
    de = RoleMetadata()
    de.deserialize(data)
    assert de.serialize() == data

# Generated at 2022-06-23 06:57:05.251132
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta_data = {
        "allow_duplicates": False
    }

    role_metadata = RoleMetadata(owner=None)
    role_metadata.load(meta_data, owner=None, variable_manager=None, loader=None)

    assert not role_metadata._allow_duplicates

    meta_data = {
        "allow_duplicates": True,
        "dependencies": [
            {"role": "common", "version": "v1"},
            {"role": "web", "version": "v1"},
            {"role": "database", "version": "v2"}
        ]
    }
    role_metadata = RoleMetadata(owner=None)
    role_metadata.load(meta_data, owner=None, variable_manager=None, loader=None)

    assert role_metadata._allow_dupl

# Generated at 2022-06-23 06:57:09.848828
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta_src = '''
        allow_duplicates: true
        dependencies:
          - src: galaxy.role
            version: master.1
            name: role1
            private: True
          - role: role2
            version: master.2
    '''

    from ansible import utils, inv
    from ansible.module_utils import basic
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import role_loader

    # The play below is not really necessary,
    # as the methods under test only use the inventory and variablemanager
    # But this demonstrates that RoleMetadata.

# Generated at 2022-06-23 06:57:14.964029
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.vars.manager import VariableManager
    from ansible.playbook import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    #RoleMetadata.load(data=None, owner=None, variable_manager=None, loader=None)
    # - this method doesn't have return value
    # - but, debug print the result of setattr()

    # data must be dict
    data = None
    instance = RoleMetadata()

    # owner must be RoleInclude
    owner = Play()
    #variable_manager = VariableManager(loader=DataLoader(), inventory=InventoryManager())

    instance.load(data, owner)

    # dump results
    print('test_RoleMetadata_load:')

# Generated at 2022-06-23 06:57:28.283998
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {
        'allow_duplicates': False,
        'dependencies': [
            {
                'role': 'geerlingguy.nginx',
                'version': '0.8.x'
            }
        ]
    }

    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition('geerlingguy.nginx')
    role._role_path = '/some/path'

    r = RoleMetadata.load(data, owner=role)
    assert r._allow_duplicates == False
    assert len(r._dependencies) == 1
    assert isinstance(r._dependencies[0], RoleRequirement)

# Generated at 2022-06-23 06:57:35.092702
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r1 = RoleMetadata()
    r1.allow_duplicates = "allow_duplicates"
    r1.dependencies = ["a","b"]
    r1_serialize = r1.serialize()
    r2 = RoleMetadata()
    r2.deserialize(r1_serialize)
    assert r2.allow_duplicates == "allow_duplicates"
    assert r2.dependencies == ["a","b"]

# Generated at 2022-06-23 06:57:45.728992
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    import yaml
    data = '''
        dependencies:
          - role: r2
            vars:
              var2: 2
          - role: r3
            vars:
              var3: 3
        '''
    data_dict = yaml.safe_load(data)
    role = Role()
    role._role_path = "r1"
    role._role_collection = "my_collection"
    role._role_collection_path = "/usr/share/ansible/collections/ansible_collections/my_org/my_collection"

# Generated at 2022-06-23 06:57:48.742640
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test simple instantiation of class RoleMetadata
    r = RoleMetadata(owner=None)
    r.load_data({}, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:57:59.923025
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    playbook = Play().load(dict(
        name ="Ansible Play",
        hosts='localhost',
        roles = [
        ],
    ), variable_manager={}, loader=None)
    task = Task().load(dict(
        name = "debug",
        action = dict(
            module = "debug",
            args = dict(msg = "Hello World"),
        )
    ))
    role = Role().load(dict(
        name = "test_role",
        tasks = [task],
    ), variable_manager={}, loader=None)


# Generated at 2022-06-23 06:58:05.116757
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role1 = RoleMetadata()
    role2 = RoleMetadata()
    role3 = RoleMetadata()
    assert role1._allow_duplicates == False
    assert role2._allow_duplicates == False
    assert role3._allow_duplicates == False
    assert role1._dependencies == []
    assert role2._dependencies == []

# Generated at 2022-06-23 06:58:12.104737
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    fake_loader, fake_variable_manager, fake_inventory = 'fake_loader', 'fake_variable_manager', 'fake_inventory'

    class FakeRole:
        def __init__(self, name):
            self._role_name = name

        def get_name(self):
            return self._role_name

    class FakeRoleCollection:
        def __init__(self, name):
            self._collection_name = name

        def get_name(self):
            return self._collection_name

    m = RoleMetadata()
    m.deserialize(dict(allow_duplicates=True, dependencies=['fake_name']))

# Generated at 2022-06-23 06:58:22.389760
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    dep1 = {'role': 'foo', 'tags': 'bar', 'when': 'baz'}
    dep2 = {'role': 'qux', 'tags': 'quux', 'when': 'quuz'}
    serialized = {
        'allow_duplicates': False,
        'dependencies': [dep1, dep2]
    }
    rmd = RoleMetadata()
    rmd.deserialize(serialized)
    assert 'allow_duplicates' in rmd.__dict__
    assert 'dependencies' in rmd.__dict__
    assert rmd.allow_duplicates is False
    assert rmd.dependencies == [dep1, dep2]

# Generated at 2022-06-23 06:58:34.172484
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from units.mock.loader import DictDataLoader

    role_ds = dict(
        galaxy_info=dict(
            author='Foo Bar <foo@bar.com>',
            company='None',
            description='This is a description',
            license='None',
            min_ansible_version='2.0',
            platforms=dict(
                FOO="1.2",
                BAR="2.3"
            ),
            galaxy_tags=['foo', 'bar'],
            galaxy_install_msg='installing frobble',
            issue_tracker_url='https://github.com/foo/bar/issues',
            github_branch='master',
            role_name='foobar',
            role_type='Ansible'
        )
    )

    role = RoleMetadata(owner=None)


# Generated at 2022-06-23 06:58:43.533071
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class Owner(object):
        def get_name(self):
            return 'some_name'

    data = {}
    m = RoleMetadata.load(data, owner=Owner())
    assert not m.dependencies
    assert not m.galaxy_info
    assert m.allow_duplicates

    data = {'dependencies': {'a': 'b'}}
    m = RoleMetadata.load(data, owner=Owner())
    assert m.allow_duplicates
    assert len(m.dependencies) == 1
    assert not m.galaxy_info

# Generated at 2022-06-23 06:58:54.910323
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import json
    import pytest

    data = {'allow_duplicates': False, 'dependencies': []}
    m = RoleMetadata()
    m.deserialize(data)
    assert json.dumps(data) == json.dumps(m.serialize())
    # test with allow_duplicates: True
    data['allow_duplicates'] = True
    m.deserialize(data)
    assert json.dumps(data) == json.dumps(m.serialize())
    # test with dependencies: [{'role': 'test', 'galaxy_info': {'author': 'foo', 'description': 'baz', 'company': 'bar', 'license': 'MIT', 'min_ansible_version': '0.6'}}]
    dep = {'role': 'test'}
    dep

# Generated at 2022-06-23 06:59:01.690682
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    host = MockRole()
    host.name = 'host'
    role_metadata = RoleMetadata().load(data=dict(dependencies=dict(role=host)), owner=host, loader=MockLoader(), variable_manager=MockVariableManager())
    result = role_metadata.serialize()
    assert result['allow_duplicates'] is False
    assert result['dependencies'] is role_metadata.dependencies


# Generated at 2022-06-23 06:59:10.432044
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role.definition
    import ansible.playbook.role_include

    data=dict(
        allow_duplicates=True,
        dependencies=list()
    )
    variable_manager = None
    loader = None

    m = RoleMetadata(owner=None)
    result = m.load(data=data, owner=ansible.playbook.role.definition.RoleDefinition(), variable_manager=variable_manager, loader=loader)

    assert result._allow_duplicates == True
    assert type(result._dependencies) == list
    assert result._galaxy_info == None
    assert type(result._argument_specs) == dict
    assert result._loader == None

# Generated at 2022-06-23 06:59:16.615012
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import ansible.playbook.role.include
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata, RoleMetadata)
    assert isinstance(role_metadata, ansible.playbook.role.include.RoleInclude)
    with pytest.raises(AnsibleParserError):
        role_metadata.load("this is not a dict", None, None, None)
    role = 'an_role'
    role_metadata.load("{'role': '%s'}" % role, role)

# Generated at 2022-06-23 06:59:28.178524
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    class MockRoleOwner(object):

        def __init__(self, foo=None, bar=None):
            self.foo = foo
            self.bar = bar

    role_owner = MockRoleOwner()

    r = RoleMetadata(owner=role_owner)

    r.allow_duplicates = False

    assert not r.allow_duplicates
    assert r.dependencies == []

    # Test deserialize
    r.deserialize({
        'allow_duplicates': True,
        'dependencies': ['foo', 'bar']
    })

    assert r.allow_duplicates
    assert r.dependencies == ['foo', 'bar']

if __name__ == '__main__':
    test_RoleMetadata_deserialize()

# Generated at 2022-06-23 06:59:35.875967
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-23 06:59:47.133082
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Load the role via the RoleMetadata.load(data, owner)

# Generated at 2022-06-23 06:59:59.195268
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import sys

    # Create an object for use by the test
    metadata = RoleMetadata()

    # Execute the code to be tested
    retval = metadata.serialize()
    if isinstance(retval, dict):
        sys.stderr.write('PASS: retval type is dict\n')
    else:
        sys.stderr.write('FAIL: retval type is not dict\n')

    # Execute the code to be tested
    retval = metadata.serialize()
    if len(retval) == 2:
        sys.stderr.write('PASS: retval length is 2\n')
    else:
        sys.stderr.write('FAIL: retval length is not 2\n')

    # Execute the code to be tested
    retval = metadata.serialize()

# Generated at 2022-06-23 07:00:10.663271
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role.definition
    import ansible.playbook.role.requirement
    ds = {'dependencies': []}
    m = RoleMetadata(owner=None).load_data(ds, variable_manager=None, loader=None)
    assert m is not None
    assert m._dependencies == []

    ds = {'dependencies': ['a', 'b']}
    m = RoleMetadata(owner=None).load_data(ds, variable_manager=None, loader=None)
    assert len(m._dependencies) == 2
    assert isinstance(m._dependencies[0], ansible.playbook.role.requirement.RoleRequirement)
    assert isinstance(m._dependencies[1], ansible.playbook.role.requirement.RoleRequirement)

    # test loading a

# Generated at 2022-06-23 07:00:20.311785
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    import ansible.playbook.role.definition as role_definition

    ds = {}
    r = Role()
    rm = RoleMetadata.load(ds, owner=r)

    assert rm
    assert rm._owner == r

    ds = {'dependencies': ['foo']}
    r = Role()
    rm = RoleMetadata.load(ds, owner=r)

    assert rm
    assert rm._owner == r
    assert len(rm._dependencies) == 1
    assert isinstance(rm._dependencies[0], role_definition.RoleDefinition)
    assert rm._dependencies[0].role == 'foo'


# Generated at 2022-06-23 07:00:23.817113
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
  data = { "allow_duplicates": False, "dependencies": [ "foo", "bar" ] }
  f = RoleMetadata()
  f.load(data)
  assert f.allow_duplicates == False
  assert len(f.dependencies) == 2


# Generated at 2022-06-23 07:00:31.486705
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role import Role

    play = Play()
    play_context = PlayContext()
    play_context.connection = 'local'
    block1 = Block()
    block1._parent = play
    block1._play = play
    block1.block = [IncludeRole.load({'name': 'test'})]
    block1.block[0]._role_context = RoleContext()
    block

# Generated at 2022-06-23 07:00:32.173749
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:00:44.416344
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition

    test_dp1 = RoleDefinition.load({"role1": {"role": "role1", "tags": ["a", "b"]}},
                                   play=None,
                                   current_role_path=None,
                                   variable_manager=None,
                                   loader=None)
    test_dp2 = RoleDefinition.load({"role2": {"role": "role2", "tags": ["b", "c"]}},
                                   play=None,
                                   current_role_path=None,
                                   variable_manager=None,
                                   loader=None)

    test_data = dict(
        allow_duplicates=True,
        dependencies=[test_dp1, test_dp2]
    )


# Generated at 2022-06-23 07:00:49.627916
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    data = {}
    role = RoleDefinition.load(data, "foo1", [(None, None)])

    role_metadata = RoleMetadata.load(data, role)
    assert role_metadata
    assert not role_metadata._allow_duplicates
    assert not role_metadata._dependencies

# Test for loading of metadata

# Generated at 2022-06-23 07:00:58.435554
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create instance of class RoleMetadata
    role_metadata = RoleMetadata()
    # Create intance of class Base
    base = Base()
    # Load data for variables self._allow_duplicates and self._dependencies of role_metadata
    role_metadata.deserialize(base.load_data({'allow_duplicates': True, 'dependencies': ['test.test']}))
    # Check that variable self._allow_duplicates of role_metadata = True
    assert role_metadata._allow_duplicates == True
    # Check that variable self._dependencies of role_metadata = ['test.test']
    assert role_metadata._dependencies == ['test.test']

# Generated at 2022-06-23 07:01:08.195107
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    # Setup
    up = MagicMock(PlayContext)
    r = MagicMock
    r.load_role.return_value = None
    r._load_role_data.return_value = None
    # Init
    rm = RoleMetadata(owner=r)
    # Serialize self to get input for test
    data = rm.serialize()
    # Test deserialize
    rm.deserialize(data)
    # Assert results
    assert rm._allow_duplicates == False
    assert rm._

# Generated at 2022-06-23 07:01:12.682602
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({
        'allow_duplicates': True,
        'dependencies': ['my_role']
    })
    assert m.allow_duplicates is True
    assert m.dependencies == ['my_role']

# Generated at 2022-06-23 07:01:13.741030
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert False, "Not implemented"

# Generated at 2022-06-23 07:01:26.259007
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    role_name = 'test_role'
    role_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'test_roles')
    role_path = os.path.join(role_path, role_name)


# Generated at 2022-06-23 07:01:28.353941
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []

# Generated at 2022-06-23 07:01:33.705816
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    instance = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['test', 'test']
    )
    instance.deserialize(data)

    assert instance.allow_duplicates == True
    assert instance.dependencies == ['test', 'test']



# Generated at 2022-06-23 07:01:44.351457
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # arrange
    class TestRole:
        def __init__(self):
            self.collections = ['test_collection']
            self.meta = None

    import ansible_collections.test_collection.test_module as test_module
    metadata_ds = dict(allow_duplicates=False, dependencies=[dict(role='test')])

    # act
    test_role = TestRole()
    test_meta = RoleMetadata(owner=test_role)
    test_meta.deserialize(metadata_ds)

    # assert
    test_dependencies = test_meta._dependencies
    test_dependency = test_dependencies[0]
    assert(isinstance(test_dependency, test_module.RoleInclude))
    assert(test_dependency.collections[0] == 'test_collection')

# Generated at 2022-06-23 07:01:48.188824
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r._allow_duplicates == False
    assert r._dependencies == []
    assert r._galaxy_info == None

# Generated at 2022-06-23 07:01:58.441694
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    _owner = type('_owner', (object,), dict())()
    _owner._role_path = 'test_role_path'
    _owner._play = type('_play', (object,), dict())()
    _owner._role_collection = type('_collection', (object,), dict())()

    _variable_manager = type('_variable_manager', (object,), dict())()
    _loader = type('_loader', (object,), dict())()

    ds = {
        'allow_duplicates': True,
        'dependencies': [
            {'src': 'galaxy.role,version,name'}
        ]
    }

    data = RoleMetadata.load(data=ds, owner=_owner, variable_manager=_variable_manager, loader=_loader)

# Generated at 2022-06-23 07:02:02.885530
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    m = RoleMetadata(r)
    assert(m._allow_duplicates == False)
    assert(m._dependencies == [])

# Generated at 2022-06-23 07:02:11.574622
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Test serialize function of RoleMetadata class
    '''

    def TestRoleMetadata(ansible_module):
        '''
        Test class that inherits from RoleMetadata
        '''
        if ansible_module in ('ansible.legacy', 'ansible.builtin'):
            ansible_module = 'ansible.builtin'

        def init(self, owner=None):
            super(TestRoleMetadata, self).__init__(owner=owner)

        metaclass = type(RoleMetadata)


# Generated at 2022-06-23 07:02:16.540974
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolemetadata=RoleMetadata()


# Generated at 2022-06-23 07:02:23.997862
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.collection import RoleFromCollection

    # Test RoleMetadata loaded from a role, with a path and name attribute.
    r = Role()
    r._role_path = '/path/to/role/'

    # No dependencies.
    m = RoleMetadata.load({'allow_duplicates': True}, r)
    assert m._allow_duplicates is True
    assert m._dependencies == []

    # Dependencies on roles.
    m = RoleMetadata.load({'allow_duplicates': True, 'dependencies': [{'role': 'common'}, {'role': 'web'}]}, r)
    assert m._allow_duplicates is True
    assert len(m._dependencies) == 2
    assert m._dependencies

# Generated at 2022-06-23 07:02:32.525594
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test setup
    r = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar'],
        galaxy_info=dict(
            galaxy_tags=['foo', 'bar'],
            company='acme',
            min_ansible_version='1.0',
            issues_url='https://github.com/acme/ansible-role-foo/issues',
            license='GPLv3',
            author='Jane Doe'
        )
    )

    # Test execution
    deserialized_data = r.deserialize(data)

    # Test assertions
    assert deserialized_data is not None  # assert code reached

# Generated at 2022-06-23 07:02:42.329050
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({})
    assert r.allow_duplicates == False
    assert r.dependencies == []
    r.deserialize({'allow_duplicates': True, 'dependencies': ['one','two','three']})
    assert r.allow_duplicates == True
    assert r.dependencies == ['one','two','three']

# Generated at 2022-06-23 07:02:48.066479
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata(owner=None)
    data = dict(
        allow_duplicates=True,
        dependencies=['test_dependencies']
    )
    setattr(r, 'allow_duplicates', data.get('allow_duplicates', False))
    setattr(r, 'dependencies', data.get('dependencies', []))
    assert r.allow_duplicates == data.get('allow_duplicates', False)
    assert r.dependencies == data.get('dependencies', [])

# Generated at 2022-06-23 07:02:49.697410
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert  RoleMetadata().deserialize({}) == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-23 07:02:50.328146
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert True

# Generated at 2022-06-23 07:02:58.772097
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['test/inventory'])

# Generated at 2022-06-23 07:03:12.333595
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    play = Play().load({'hosts': 'all',
                        'roles': [{ "role": "test_role", "some_var": "some_thing"}]})
    role = Role().load({}, play=play, role_name="test_role")
    role._role_path = os.path.join(os.path.dirname(__file__), "test_roles/test_galaxy_requirements_meta")
    m = RoleMetadata.load({'dependencies': []}, owner=role)

    assert m._dependencies == []

    # make sure we are ignoring the file
    assert not m.get_single_data()


# Generated at 2022-06-23 07:03:23.944069
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import json
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary ansible.cfg
    fd, tmp_ansible_cfg = tempfile.mkstemp()
    # Change ansible.cfg and make it point to the temporary directory
    with os.fdopen(fd, 'w') as f:
        f.write('[defaults]\n')
        f.write('roles_path = %s' % tmp_dir)

    # Create nested directories

# Generated at 2022-06-23 07:03:27.065162
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Creating instance of class RoleMetadata
    return RoleMetadata()

if __name__ == '__main__':
    # For test purposes
    obj = test_RoleMetadata()

# Generated at 2022-06-23 07:03:31.673887
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    action_metadata = RoleMetadata()
    assert isinstance(action_metadata, RoleMetadata)
    assert action_metadata.allow_duplicates is False
    assert action_metadata.dependencies == []


# Generated at 2022-06-23 07:03:34.555657
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 07:03:38.583459
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
  from ansible.playbook.role import Role
  role = Role()
  role_metadata = RoleMetadata(owner=role)
  assert role_metadata._owner == role

# Generated at 2022-06-23 07:03:44.703774
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    obj = RoleMetadata()
    obj.allow_duplicates=True
    obj.dependencies=['name', 'version', 'src']
    result = obj.serialize()

    assert 'allow_duplicates' in result
    assert 'dependencies' in result
    assert result['allow_duplicates'] == True
    assert result['dependencies'] == ['name', 'version', 'src']

# Generated at 2022-06-23 07:03:50.266264
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """Test the load method of class RoleMetadata."""
    import datetime
    class_dict = {'date': datetime.datetime.now().isoformat()}
    owner = type('Role', (object,), class_dict)()
    data = {"dependencies": []}
    result = RoleMetadata.load(data, owner)
    assert result._lineno == 1
    assert result._data == data
    assert result._owner == owner
    assert result._variable_manager is None
    assert result._loader is None


# Generated at 2022-06-23 07:03:52.097803
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass


# Generated at 2022-06-23 07:03:52.824006
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-23 07:04:01.205964
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    current_dir = os.getcwd()
    os.chdir(os.path.dirname(os.path.realpath(__file__)) + "/test_collections/")
    pb = Playbook.load('test_collections.yml')
    (host, _) = pb.get_host_and_task('foo', 'test_role_meta_file_play')
    rm = host.get_role_metadata('test_role_meta_file')
    os.chdir(current_dir)
    return rm

# Generated at 2022-06-23 07:04:12.049625
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    def_ = RoleDefinition('test')
    def_.roles = load_list_of_roles(['role_a'])
    ri = RoleInclude()
    ri.role = def_
    ri.roles = def_.roles
    metadata = RoleMetadata()
    metadata._allow_duplicates = True
    metadata._dependencies = [ri]
    metadata.dependencies[0]._role_name = 'role_a'
    assert metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'role_a'}]}


# Generated at 2022-06-23 07:04:17.792105
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import ansible.playbook.role
    import ansible.playbook.role_include
    import ansible.playbook.task

    role_meta = RoleMetadata()
    role_meta.deserialize({'allow_duplicates': False})
    assert role_meta._allow_duplicates == False

    role_meta.deserialize({'dependencies': [
        {'role': 'test_role', 'task': 'test_task'},
        'test_role',
        {'role': 'test_role2', 'when': 'test_when'},
        {'name': 'test_role3'},
        {'role': 'test.name', 'task': 'test_task'},
        'test1.test2',
        'test2.test3'
    ]})

    assert role_meta._

# Generated at 2022-06-23 07:04:23.987334
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    role_path = '/home/test/ansible'
    definition = RoleDefinition(
        name='test',
        playbooks=None,
        force_handlers=False,
        tasks_from=None,
        defaults_from=None,
        meta_from=None,
        vars_from=None,
        role_path=role_path,
        collections=None,
        ignore_errors=False,
        allow_duplicates=False,
        by=None,
        playbook_filename=None,
        implicit=None,
        galaxy_info=None,
        role_includer=None,
        role_vars=None,
        role_params=None
    )
    role = RoleMetadata(owner=definition)
    role.deserial

# Generated at 2022-06-23 07:04:25.122694
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

# Generated at 2022-06-23 07:04:30.413662
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    a = RoleMetadata()
    a.deserialize(data)
    assert a.allow_duplicates == False
    assert a.dependencies == []

# Generated at 2022-06-23 07:04:37.063440
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    variable_manager = None
    loader = None
    data = dict(
        dependencies=[{'role': 'example'},
                      {'role': 'example', 'version': '1.0'}],
        allow_duplicates=True
    )
    result = RoleMetadata.load(data, variable_manager=variable_manager, loader=loader)
    assert( result.serialize() == data )


# Generated at 2022-06-23 07:04:47.728778
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role.load(dict(
        name='test',
        default_vars=dict(x=1),
        vars_files=['vars1', 'vars2'],
        meta=dict(
            dependencies=['role2', dict(role='role3', some='thing')],
            allow_duplicates=True,
        ),
    ))
    assert role.metadata.allow_duplicates
    assert [d.get_name() for d in role.metadata.dependencies] == ['role2', 'role3']
    assert role.metadata.dependencies[0].parent == role
    assert role.metadata.dependencies[1].parent == role
    assert role.metadata.dependencies[1].some == 'thing'

# Generated at 2022-06-23 07:04:52.973761
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_name = 'role_name'
    role = RoleMetadata(owner=role_name)
    role.allow_duplicates = True
    role.dependencies = ['test_dep']
    actual = role.serialize()
    assert actual == dict(allow_duplicates=True, dependencies=['test_dep'])


# Generated at 2022-06-23 07:04:53.984790
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rolemetadata = RoleMetadata()
    assert rolemetadata is not None

# Generated at 2022-06-23 07:04:59.873861
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({'allow_duplicates': True, 'dependencies': ['example_1', 'example_2']})
    assert m._allow_duplicates
    m._allow_duplicates = False
    m.deserialize({'dependencies': ['example_1', 'example_2']})
    assert m._allow_duplicates is False

# Generated at 2022-06-23 07:05:03.655249
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = True
    m.dependencies = ['common']
    assert m.serialize() == {'allow_duplicates': True, 'dependencies': ['common']}

# Generated at 2022-06-23 07:05:07.966501
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None).deserialize({'allow_duplicates': False,
                                                          'dependencies': []})
    assert role_metadata.serialize() == {'allow_duplicates': False,
                                         'dependencies': []}



# Generated at 2022-06-23 07:05:11.273435
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    role.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert role.get_allow_duplicates() and not role.get_dependencies()


# Generated at 2022-06-23 07:05:20.645071
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    # Basic test case
    meta._dependencies = ['foo']
    meta._allow_duplicates = True
    expected = {
        'allow_duplicates': True,
        'dependencies': ['foo'],
    }
    assert meta.serialize() == expected
    # Empty case
    meta = RoleMetadata()
    expected = {
        'allow_duplicates': False,
        'dependencies': [],
    }
    assert meta.serialize() == expected