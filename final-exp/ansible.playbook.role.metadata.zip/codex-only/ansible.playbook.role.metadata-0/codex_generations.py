

# Generated at 2022-06-23 06:55:24.090806
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    meta_main_content = {
        "dependencies": [
            {"role": "common", "some_var": 1},
            {"role": "webserver", "some_other_var": 2}
        ],
        "galaxy_info": {"author": "John Doe", "description": "Test Role", "company": "Foo GmbH"},
        "allow_duplicates": False
    }

# Generated at 2022-06-23 06:55:32.054672
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''Unit test for method `serialize` of class `RoleMetadata`

    :return:
    '''
    role_metadata = RoleMetadata()

    setattr(role_metadata, '_allow_duplicates', True)
    setattr(role_metadata, '_dependencies', ['test1', 'test2'])

    expected = dict(
        allow_duplicates=True,
        dependencies=['test1', 'test2']
    )

    assert role_metadata.serialize() == expected

# Generated at 2022-06-23 06:55:40.669732
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    d = {
        'allow_duplicates': True,
        'dependencies': [RoleDefinition.load({'role': 'geerlingguy.nginx', 'name': 'geerlingguy.nginx'})]
    }

    # create a new RoleMetadata object and call serialize
    role_metadata = RoleMetadata()
    role_metadata.deserialize(d)
    ret = role_metadata.serialize()

    # compare the results
    assert ret['allow_duplicates'] == True
    assert ret['dependencies'][0].get_name() == 'geerlingguy.nginx'

# Generated at 2022-06-23 06:55:42.794945
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    #for now we just do a sanity test, maybe more later
    assert RoleMetadata()

# Generated at 2022-06-23 06:55:51.332045
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    import ansible.parsing.utils.yaml.objects
    import ansible.utils.unsafe_proxy
    import ansible.vars.unsafe_proxy

    # Create a fake RoleDefinition object in order to pass the owner
    # parameter without having to create a separate ansible/playbook/role
    # submodule
    rd = RoleDefinition()
    rd.role_name = 'sample_role'

    # Create a fake data structure to test the method load
    data = ansible.parsing.utils.yaml.objects.AnsibleMapping()
    data['allow_duplicates'] = True
    data['dependencies'] = ansible.parsing.utils.yaml.objects.AnsibleSequence()


# Generated at 2022-06-23 06:56:02.257908
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class RoleMetadataObj():
        '''
        This mock class of RoleMetadata is providing all the required class variables and functions
        needed by the RoleMetadata._load_callables.
        '''
        _allow_duplicates = True
        _dependencies = []
        _galaxy_info = None
        _argument_specs = {}

        def __init__(self):
            return

        @staticmethod
        def load_list_of_roles(roles, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None):
            return roles

        @staticmethod
        def primary_key(role_def):
            if isinstance(role_def, string_types):
                return role_def

# Generated at 2022-06-23 06:56:14.062970
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.network.common.utils import load_provider
    play_context = PlayContext()

    rd = RoleDefinition()
    rd.name = 'test'
    rd.role_path = 'test'
    rd.vars = {}
    rd.collections = ['ansible.builtin']
    rd._parent = Play()
    rd._real_parent = Play()
    rd.tags = ['all']
    rd.tasks = []
    rd.handlers = []
    rd.default_vars = {}
    rd.templar = None
    rd.default

# Generated at 2022-06-23 06:56:23.249570
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_json = '{"allow_duplicates": true, "dependencies": [ {"src": "Ansible-Collections/ansible.kubernetes", "version": "v10.0.0", "name": "kubernetes"}]}'
    dependencies = [{'src': 'Ansible-Collections/ansible.kubernetes', 'version': 'v10.0.0', 'name': 'kubernetes'}]
    role_metadata = RoleMetadata(owner=None)
    setattr(role_metadata, 'allow_duplicates', True)
    setattr(role_metadata, 'dependencies', dependencies)
    serialized_data = role_metadata.serialize()
    assert(serialized_data['allow_duplicates'] == True)

# Generated at 2022-06-23 06:56:29.833042
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    data = {'allow_duplicates': False, 'dependencies': [{'role': 'R1'}, {'role': 'R2'}, {'role': 'R3'}]}

    m = RoleMetadata()
    m.deserialize(data)

    assert m.allow_duplicates == False
    assert m.dependencies == [{'role': 'R1'}, {'role': 'R2'}, {'role': 'R3'}]

# Generated at 2022-06-23 06:56:34.160123
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    result = RoleMetadata().deserialize( {
        'allow_duplicates': False,
        'dependencies': [],
    })
    assert result.allow_duplicates == False
    assert result.dependencies == []

# Generated at 2022-06-23 06:56:41.116661
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata()
    role_meta.allow_duplicates = True
    role_meta.dependencies = ['test']
    serialized = role_meta.serialize()
    assert isinstance(serialized, dict)
    assert serialized == {
        'allow_duplicates': True,
        'dependencies': ['test']
    }


# Generated at 2022-06-23 06:56:50.654130
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meth = RoleMetadata.deserialize
    meth.apply([{"dependencies": [{"role": "role1", "tasks_from": "main"}],
                 "allow_duplicates": True}])
    meth.apply([{"allow_duplicates": True}])
    meth.apply([{"dependencies": [{"role": "role1", "tasks_from": "main"}]}])
    meth.apply([{"dependencies": []}])
    meth.apply([{"dependencies": [{"role": "role1", "tasks_from": "main"}]}])
    meth.apply([{}])



# Generated at 2022-06-23 06:56:54.376292
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    rmeta = RoleMetadata(owner=RoleDefinition())
    serialize = rmeta.serialize()
    assert serialize == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 06:56:55.540627
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    RoleMetadata.load('test')

# Generated at 2022-06-23 06:56:57.544929
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata(owner='owner')
    assert isinstance(r, RoleMetadata)

# Generated at 2022-06-23 06:57:07.986053
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # The data to be loaded into the object:
    data = {}
    data['allow_duplicates'] = True
    data['dependencies'] = []

    d = data.copy()
    r = RoleMetadata(owner = None).load_data(d)

    # As the RoleMetadata object is loaded, the deserialize method is called automatically
    # which sets the attributes of the object.  This call to serialize returns another dictionary
    # containing the attributes:
    assert r.serialize() == {u'allow_duplicates': True, u'dependencies': []}

    data['dependencies'] = ['role1', 'role2']
    d = data.copy()
    r = RoleMetadata(owner = None).load_data(d)


# Generated at 2022-06-23 06:57:13.380611
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-23 06:57:14.041877
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 06:57:18.996470
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata_dict = dict(
        allow_duplicates=True,
        dependencies=["my_dependency"],
    )
    role_metadata.deserialize(role_metadata_dict)
    assert role_metadata.allow_duplicates
    assert role_metadata.dependencies == ["my_dependency"]

# Generated at 2022-06-23 06:57:24.710172
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    m = RoleMetadata()
    m.deserialize(data)
    assert not m.allow_duplicates
    assert not m.dependencies


# Generated at 2022-06-23 06:57:32.926549
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Testing RoleMetadata constructor")

    rmd = RoleMetadata()

    print("Testing RoleMetadata load")

    rmd = RoleMetadata.load(None)
    assert rmd

    rmd = RoleMetadata.load([])
    assert rmd

    rmd = RoleMetadata.load(None, None)
    assert rmd

    rmd = RoleMetadata.load([], None)
    assert rmd

# Generated at 2022-06-23 06:57:34.225206
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #assert False, "no test"
    pass

# Generated at 2022-06-23 06:57:37.842591
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = {'allow_duplicates' : True, 'dependencies' : 'test dependency'}
    r=RoleMetadata.load(role, owner='test owner')
    assert r._allow_duplicates == True
    assert r._dependencies == 'test dependency'

# Generated at 2022-06-23 06:57:39.337706
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 06:57:46.274972
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from collections import namedtuple
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    owner = namedtuple("owner", ["_role_name"])
    owner._role_name = 'owner'
    data = {'dependencies': ['role1', 'role2']}
    m = RoleMetadata(owner=owner).load_data(data)
    assert isinstance(m, RoleMetadata)
    assert m._owner._role_name == 'owner'
    assert m._dependencies == ['role1', 'role2']



# Generated at 2022-06-23 06:57:47.486328
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rm = RoleMetadata()
    assert isinstance(rm, RoleMetadata)

# Generated at 2022-06-23 06:57:59.651115
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from .playbook_include import RoleInclude

    role_meta = RoleMetadata()
    role_meta._load_dependencies('dependencies', ['foo.bar'])
    assert isinstance(role_meta.dependencies, list)
    assert isinstance(role_meta.dependencies[0], RoleInclude)

    role_meta = RoleMetadata()
    role_meta._load_dependencies('dependencies', [{'role': 'foo.bar', 'somevar': 'someval'}])
    assert isinstance(role_meta.dependencies, list)
    assert isinstance(role_meta.dependencies[0], RoleInclude)


# Generated at 2022-06-23 06:58:08.580251
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task.include import TaskInclude
    role = RoleDefinition()
    rm = RoleMetadata(owner=role)
    assert isinstance(rm._dependencies[0], TaskInclude)

    rm = RoleMetadata(owner=role)
    assert isinstance(rm._dependencies[0], RoleInclude)
    assert isinstance(rm._dependencies[0]._role, RoleRequirement)

# Generated at 2022-06-23 06:58:20.921697
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # standard dict
    r = RoleMetadata.load({"dependencies": [{'role': 'some.role'}]})
    assert type(r) == RoleMetadata
    assert type(r._dependencies[0]) == RoleRequirement
    assert r._dependencies[0].role == 'some.role'

    # role_spec
    r = RoleMetadata.load({"dependencies": [{'role': 'some.role'}, 'other.role', dict(role='another.role')]})
    assert type(r) == RoleMetadata
    assert type(r._dependencies[0]) == RoleRequirement

# Generated at 2022-06-23 06:58:22.753066
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO: implement
    pass

# Generated at 2022-06-23 06:58:34.437512
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils import context_objects as co

    # Create dummy play
    play = dict(
            name = "Test Play",
            hosts = 'all',
            gather_facts = 'no',
            roles = [],
            tasks = [],
            vars = [],
            )

    context = PlayContext()
    context._play = play
    context._play_context = context
    context._task_stack = []
    co.push(context, play=context._play, play_context=context._play_context, new_stdin=None)

    vm = VariableManager()

# Generated at 2022-06-23 06:58:45.587361
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block

    role1 = RoleDefinition.load(dict(name="role1"), play=Play().load(dict(), variable_manager=None, loader=None))
    role2 = RoleDefinition.load(dict(name="role2"), play=Play().load(dict(), variable_manager=None, loader=None))
    include1 = TaskInclude.load(dict(name=role1.get_name()), play=Play().load(dict(), variable_manager=None, loader=None))

# Generated at 2022-06-23 06:58:53.614570
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            "collection://mycollection.namespace.roles",
            'role: myrole',
            {'name': 'anotherrole', 'version_requirement': '1.2'}
        ]
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates
    assert len(role_metadata._dependencies) == 3

# Generated at 2022-06-23 06:59:00.235722
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_obj1 = RoleMetadata(owner='XYZ')
    assert role_obj1 != None
    assert role_obj1.owner == 'XYZ'
    assert role_obj1.allow_duplicates == False
    assert len(role_obj1.dependencies) == 0
    assert role_obj1.galaxy_info == None
    assert type(role_obj1.argument_specs) == dict
    assert len(role_obj1.argument_specs) == 0



# Generated at 2022-06-23 06:59:01.497935
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    return


# Generated at 2022-06-23 06:59:07.806336
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {'allow_duplicates': False,
            'dependencies': [],
            'galaxy_info': {}
    }
    owner = 'owner'
    role_metadata = RoleMetadata(owner)
    role_metadata.load(data, owner)

    assert (role_metadata.allow_duplicates == False)
    assert (role_metadata.dependencies == [])

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-23 06:59:08.624816
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-23 06:59:18.242951
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    args = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                src=dict(
                    path=os.path.join(os.path.dirname(__file__), 'data/library'),
                    name='test_role',
                    scm='git',
                    version='master',
                    private=True,
                    async_timeout=5,
                    ignore_errors=True
                ),
                name='test_role',
                private=True,
                version='master',
                async_timeout=5,
                ignore_errors=True
            )
        ]
    )
    r = RoleMetadata(owner=None).load(args, owner=None, variable_manager=None, loader=None)
    assert r._allow_duplicates is True
    assert r._dependencies[0].src.name

# Generated at 2022-06-23 06:59:21.171427
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    roleMetadataObj = RoleMetadata()
    assert roleMetadataObj.deserialize({'allow_duplicates': False, 'dependencies': []}) == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 06:59:23.862520
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-23 06:59:33.229622
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext(loader=loader, variable_manager=variable_manager, options=None)
    play = Play().load({}, loader=loader, variable_manager=variable_manager, play_context=play_context)
    path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/utilities/log_plays')

# Generated at 2022-06-23 06:59:36.319386
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    res = role_metadata.serialize()
    assert res == dict(
            allow_duplicates=False,
            dependencies=[]
            )

# Generated at 2022-06-23 06:59:36.971364
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-23 06:59:40.091667
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    rmd.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert rmd._allow_duplicates == False



# Generated at 2022-06-23 06:59:50.723176
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.utils.vars import load_extra_vars, load_options_vars, combine_vars, get_vars
    from ansible.parsing.dataloader import DataLoader

    rolestring = u'name: FOO\n\n#bar/baz: biz'
    role = RoleDefinition.load(rolestring, None)
    context = PlayContext()

# Generated at 2022-06-23 07:00:02.588588
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    rm = RoleMetadata()
    assert rm is not None
    assert rm._owner is None
    assert rm._allow_duplicates == False
    assert rm._dependencies == []
    assert rm._galaxy_info == None
    assert rm._argument_specs == {}

    # test load()
    rm1 = RoleMetadata.load(data={}, owner='this_is_owner')
    assert rm1._owner == 'this_is_owner'
    assert rm1._allow_duplicates == False
    assert rm1._dependencies == []
    assert rm1._galaxy_info == None
    assert rm1._argument_specs == {}

    # test load_data()

# Generated at 2022-06-23 07:00:13.310488
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = RoleMetadata().serialize()
    assert data['allow_duplicates'] == False
    assert data['dependencies'] == []

    data = {
        'allow_duplicates': True,
        'dependencies': [
            {'src': 'foo', 'version': '1.0', 'name': 'foo'},
            {'src': 'bar', 'version': '2.0', 'name': 'bar'},
        ]
    }
    role_metadata = RoleMetadata().deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies[0].name == "foo"
    assert role_metadata.dependencies[1].name == "bar"

# Generated at 2022-06-23 07:00:17.616633
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    rmd._allow_duplicates = True
    rmd._dependencies = []
    serialize = rmd.serialize()
    assert serialize['allow_duplicates'] is True
    assert serialize['dependencies'] == []

# Generated at 2022-06-23 07:00:26.207229
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import pytest
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    role_metadata = RoleMetadata()

    # Test for default values
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None

    # Test for Instantiation with values
    role_metadata = RoleMetadata(owner=RoleDefinition())

    with pytest.raises(AnsibleParserError):
        role_metadata._load_dependencies(role_metadata._dependencies, 'hello')

    with pytest.raises(AnsibleParserError):
        role_metadata._load_dependencies(role_metadata._dependencies, ['hello'])


# Generated at 2022-06-23 07:00:34.415318
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {'dependencies': [{'role': 'common', 'version': '1.0'}]}
    r.deserialize(data)
    assert r.dependencies == data['dependencies']
    data = {'dependencies': [{'role': 'common', 'version': '2.0'}]}
    r.deserialize(data)
    assert r.dependencies == data['dependencies']
    data = {'dependencies': []}
    r.deserialize(data)
    assert r.dependencies == data['dependencies']
    data = {}
    r.deserialize(data)
    assert r.dependencies == []

# Generated at 2022-06-23 07:00:46.629080
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm1 = RoleMetadata()
    result1 = rm1.serialize()
    expected_result1 = {
        'allow_duplicates': rm1._allow_duplicates,
        'dependencies': rm1._dependencies,
    }
    assert result1 == expected_result1, "RoleMetadata.serialize failed"

    rm2 = RoleMetadata()
    rm2._allow_duplicates = True
    rm2._dependencies = ['foo', 'bar']
    result2 = rm2.serialize()
    expected_result2 = {
        'allow_duplicates': rm2._allow_duplicates,
        'dependencies': rm2._dependencies,
    }
    assert result2 == expected_result2, "RoleMetadata.serialize failed"

    rm3 = RoleMetadata()
    rm

# Generated at 2022-06-23 07:00:57.972841
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
   m = RoleMetadata.load({
       'galaxy_info': {},
       'dependencies': [
           {'src': 'ANXS.postgresql', 'version': '1.0'},
           {'src': 'geerlingguy.postgresql', 'version': '1.0'},
           {'src': 'geerlingguy.nginx', 'version': '1.0'},
           {'src': 'geerlingguy.redis', 'version': '1.0'}
       ],
       'allow_duplicates': True
   })
   print(m.__dict__)

# Generated at 2022-06-23 07:01:07.868471
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    loader = AnsibleCollectionLoader()
    collection_path = loader._get_role_path('ansible.posix', 'install')
    role_def = RoleDefinition.load(dict(name='ansible.posix.install'), collection_path=collection_path)
    assert role_def.name == 'ansible.posix.install'
    assert role_def.metadata.galaxy_info
    assert role_def.collection == 'ansible.posix'
    assert role_def.path == '.../ansible.posix/roles/install'
    assert os.path.isdir(role_def.path)


# Generated at 2022-06-23 07:01:17.537231
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task import RoleTask
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    role = RoleDefinition()

    m = RoleMetadata(owner=role)

    assert isinstance(m, RoleMetadata)
    assert isinstance(m, Base)
    assert hasattr(m, '_allow_duplicates')
    assert isinstance(m._allow_duplicates, bool)
    assert m._allow_duplicates is False
    assert hasattr(m, '_dependencies')
    assert isinstance(m._dependencies, list)
    assert len(m._dependencies) == 0
    assert hasattr(m, '_galaxy_info')
    assert m

# Generated at 2022-06-23 07:01:21.107872
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    result = role.serialize()

    assert isinstance(result, dict)
    assert all(key in result for key in ['allow_duplicates', 'dependencies'])



# Generated at 2022-06-23 07:01:25.890791
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta.allow_duplicates = True
    meta.dependencies = ['role1', 'role2', 'role3']
    assert meta.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2', 'role3']}



# Generated at 2022-06-23 07:01:33.503610
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.block import Block


    m = RoleMetadata()
    m.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert not m._allow_duplicates
    assert len(m._dependencies) == 0

    m = RoleMetadata()
    m.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'common'}, {'role': 'webtier'}]})
    assert m._allow_duplicates
    assert len(m._dependencies) == 2
    assert m._dependencies[0].name == 'common'
    assert m._dependencies[0].collections

# Generated at 2022-06-23 07:01:34.683181
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass


# Generated at 2022-06-23 07:01:35.255204
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:01:45.600388
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import json
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play


# Generated at 2022-06-23 07:01:55.793850
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {
        'dependencies': [
            {'role': 'foo'},
            {'role': 'bar'},
            {'role': 'baz', 'some_parameter': 42}
        ],
    }

    role = MockRole()
    variable_manager = MockVariableManager()
    loader = MockLoader()
    metadata = RoleMetadata.load(data, owner=role, variable_manager=variable_manager, loader=loader)

    assert metadata._dependencies == data['dependencies']
    assert metadata._owner == role
    assert metadata._variable_manager == variable_manager



# Generated at 2022-06-23 07:01:59.413313
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_info = RoleMetadata()
    assert role_info._allow_duplicates == False
    assert role_info._dependencies == []
    assert role_info._galaxy_info == None
    assert role_info._argument_specs == {}

# Generated at 2022-06-23 07:02:06.088262
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    ds = dict(
        allow_duplicates=True,
        dependencies=['geerlingguy.nfs', {'src': 'git+https://github.com/geerlingguy/ansible-role-composer.git'}],
    )

    serialize_res = RoleMetadata.load(ds, None).serialize()
    assert serialize_res == ds



# Generated at 2022-06-23 07:02:11.255779
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Test(RoleMetadata):
        pass
    t = Test()

    data = {"allow_duplicates": False, "dependencies": []}
    t.deserialize(data)

    assert t._allow_duplicates == False
    assert t._dependencies == []

# Generated at 2022-06-23 07:02:23.435560
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.utils.module_docs as module_docs
    from ansible.plugins.loader import module_loader
    from ansible.modules import command
    from ansible.plugins.loader import module_loader, add_all_plugin_dirs
    from ansible.playbook.play_context import PlayContext

    # unit test need to patch module_loader
    module_loader.add_directory(os.path.dirname(command.__file__))
    add_all_plugin_dirs()

    module_loader.add_directory(os.path.dirname(command.__file__))

    test_code = """
- role: test_role
  vars:
     test_var1: foo

- role: test_role
  tags: ['role1']
  vars:
     test_var2: bar
"""

# Generated at 2022-06-23 07:02:32.880714
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.base import load_list_of_blocks
    from ansible.playbook.play_context import PlayContext

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict()), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    roles_source = [
        dict(
            name = "test_role1",
            tasks = [
                dict(action=dict(module='command', args=dict(cmd='ls')))
            ]
        )
    ]


# Generated at 2022-06-23 07:02:39.423387
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Tested with UnitTest RoleMetadataTest.test_serialize_type
    # Tested with UnitTest RoleMetadataTest.test_serialize_dictionary
    pass


# Generated at 2022-06-23 07:02:46.796879
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['d1', 'd2']

    #Serialize
    data = role_metadata.serialize()
    assert data.get('allow_duplicates') == True
    assert data.get('dependencies') == ['d1', 'd2']

# Generated at 2022-06-23 07:02:52.642863
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata.load({}, None)
    serialized = role_metadata.serialize()
    assert serialized["allow_duplicates"] == False
    assert serialized["dependencies"] == []

    role_metadata = RoleMetadata.load({"dependencies": [], "allow_duplicates": True}, None)
    serialized = role_metadata.serialize()
    assert serialized["allow_duplicates"] == True
    assert serialized["dependencies"] == []

# Generated at 2022-06-23 07:02:55.415378
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict(
        allow_duplicates=False,
        dependencies=[],
    )
    meta = RoleMetadata().deserialize(data)
    assert meta._allow_duplicates == False
    assert meta._dependencies == []

# Generated at 2022-06-23 07:03:03.532302
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins.loader import role_loader

    metadata_filename = 'meta/main.yml'
    role_directory = role_loader._get_role_path('my_role')
    role_definition = {'name': 'my_role', 'path': role_directory}
    data = read_docstring(metadata_filename, role_definition, ignore_errors=True, verbose=False)[1]

    rm = RoleMetadata()
    rm.deserialize(data)

    assert isinstance(rm, RoleMetadata)
    assert rm.get_owner() is None
    assert isinstance(rm.get_dependencies(), list)
    assert len(rm.get_dependencies()) == 0
    assert rm.get_allow_duplicates()

# Generated at 2022-06-23 07:03:12.016970
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None)
    role_metadata.allow_duplicates=True
    role_metadata.dependencies=['role1']
    assert role_metadata.serialize() == {
        'allow_duplicates': True,
        'dependencies': ['role1']
    }

# Generated at 2022-06-23 07:03:16.916748
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_role = {
        'allow_duplicates': False,
        'dependencies': []
    }
    assert RoleMetadata().serialize() == test_role

# Generated at 2022-06-23 07:03:19.001779
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # this is just to make sure the method works
    RoleMetadata().serialize()


# Generated at 2022-06-23 07:03:22.492160
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    role.deserialize({
        'allow_duplicates': True,
        'dependencies': [
            'rolename1'
        ],
    })

    assert role.allow_duplicates == True
    assert role.dependencies[0] == 'rolename1'

# Generated at 2022-06-23 07:03:27.065595
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'common'}]})
    assert m.allow_duplicates
    assert len(m.dependencies) == 1
    assert m.dependencies[0].role == "common"

# Generated at 2022-06-23 07:03:37.316516
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play, PlayContext, Playbook, PlaybookExecutor, Task, Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    pb = Playbook.load("./test/units/module_utils/test_role_metadata.yml", variable_manager=VariableManager(), loader=DataLoader())
    p = pb.get_plays()[0]
    i = InventoryManager(loader=DataLoader(), sources=["localhost"])
    i.subset('all')
    pc = PlayContext(play=p, options=p._options, variable_manager=VariableManager(), loader=DataLoader())
    t = Task()
    r = Role()

# Generated at 2022-06-23 07:03:41.217467
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata.__name__ == 'RoleMetadata'
    assert RoleMetadata._allow_duplicates == False
    assert RoleMetadata._dependencies == []
    assert RoleMetadata._galaxy_info == None
    assert RoleMetadata._argument_specs == {}



# Generated at 2022-06-23 07:03:45.805546
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    role_metadata = RoleMetadata.load({
        "allow_duplicates": True,
        "dependencies": [
            { "role": "common" },
            { "role": "webserver" },
            {
                "role": "database",
                "db": "mysql",
                "galaxy_tags": {
                    "galaxy_tags": "foo,bar"
                }
            }
        ]
    }, RoleDefinition())
    expected_result = "{'allow_duplicates': True, 'dependencies': [{'role': 'common'}, {'role': 'webserver'}, {'role': 'database', 'db': 'mysql', 'galaxy_tags': {'galaxy_tags': 'foo,bar'}}]}"
   

# Generated at 2022-06-23 07:03:50.396365
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager(loader=None, inventory=None, version_info=None)
    play = Play.load({
        'name': 'test play',
        'hosts': ['foo', 'bar'],
        'roles': [
            {'role': 'test_role'},
        ],
    }, variable_manager=variable_manager, loader=None)

    # assert correct RoleInclude objects are created from the play
    # roles attribute and that variable manager is passed to Role

# Generated at 2022-06-23 07:03:54.842756
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    o = RoleMetadata()
    o.deserialize(data)
    assert o.serialize() == data

# Generated at 2022-06-23 07:04:05.712390
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import yaml
    meta = RoleMetadata()
    # We will use the following data structure for test
    # The goal is to test the serialization of the
    # following values to the given keys
    data = {
        '_allow_duplicates': True,
        '_dependencies': ['foo', 'bar', 'baz'],
        '_galaxy_info': {'name': 'myrole_info', 'description': 'myrole_desc'}
    }
    desired_result = {'allow_duplicates': True, 'dependencies': ['foo', 'bar', 'baz']}
    # Set data structure
    meta.load_data(data, variable_manager=None, loader=None)
    # Serialize
    serialized_data = meta.serialize()
    # Test that the data structure has the expected values

# Generated at 2022-06-23 07:04:14.810826
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.path import unfrackpath

    base_dir = unfrackpath(os.path.dirname(__file__)) + '/../../../lib/ansible/playbook/roles'

    role1 = Role.load(base_dir + "/somerole1")
    role2 = Role.load(base_dir + "/somerole2")
    meta = RoleMetadata(owner=role1)
    meta.dependencies = [role1, role2]
    serialized = meta.serialize()
    assert serialized['dependencies'][0]['role'].get_name() == 'somerole1'
    assert serial

# Generated at 2022-06-23 07:04:17.497977
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    assert r.deserialize({}) == {'allow_duplicates': False, 'dependencies': []}
    assert r.deserialize({'allow_duplicates': True}) == {'allow_duplicates': True, 'dependencies': []}
    assert r.deserialize({'allow_duplicates': True, 'dependencies': ['a']}) == {'allow_duplicates': True, 'dependencies': ['a']}

# Generated at 2022-06-23 07:04:18.161699
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:04:23.185088
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    mod = RoleMetadata()
    mod._dependencies = ['role1', 'role2']
    mod._allow_duplicates = False
    data = mod.serialize()
    assert data['allow_duplicates'] == False
    assert data['dependencies'] == ['role1', 'role2']

# Generated at 2022-06-23 07:04:30.920900
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class RoleMetadata2(RoleMetadata):
        def __init__(self, owner=None):
            self._owner = owner
            super(RoleMetadata2, self).__init__()
    var = {'role_dependencies': [], 'allow_duplicates': True}
    m = RoleMetadata2().deserialize(var)
    assert m.allow_duplicates == True
    assert m.dependencies == []

# Generated at 2022-06-23 07:04:43.291139
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    data = {
        'dependencies': [
            {
                'role': 'common',
                'version': 'v1'
            },
            'db',
            'web',
            {
                'role': 'other',
                'scm': 'git',
                'version': 'master',
                'src':'http://foo.bar/roles/other',
                'name':'other'
            }
        ],
        'allow_duplicates': True
    }
    role = RoleDefinition()
    role.name = 'role-definition'

# Generated at 2022-06-23 07:04:51.358341
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.module_utils.six import PY3
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import get_all_plugin_loaders, module_loader
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.display import Display
    if not PY3:
        try:
            from __builtin__ import unicode
        except ImportError:
            from builtins import unicode

    display = Display()
    display.verbosity = 3
    example_data1 = dict(
        allow_duplicates=False,
        dependencies=["example.com,apache,1.0"],
    )

# Generated at 2022-06-23 07:04:55.425553
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': True, 'dependencies': []}
    rm = RoleMetadata()
    rm.deserialize(data)
    assert rm.allow_duplicates == True
    assert rm.dependencies == []

# Generated at 2022-06-23 07:04:58.591033
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    assert r.deserialize({'allow_duplicates': True, 'dependencies': ['a1']}) is None
    assert r._allow_duplicates is True
    assert r._dependencies == ['a1']

# Generated at 2022-06-23 07:05:04.397021
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta_data = RoleMetadata()
    meta_data.load({
        'allow_duplicates': False,
        'dependencies': ['role1', 'role2']
    })
    assert meta_data._allow_duplicates is False
    assert meta_data._dependencies == ['role1', 'role2']


# Generated at 2022-06-23 07:05:05.781658
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

# Generated at 2022-06-23 07:05:12.723820
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Unit test for method deserialize of class RoleMetadata
    '''
    r = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    setattr(r, 'allow_duplicates', data.get('allow_duplicates', False))
    setattr(r, 'dependencies', data.get('dependencies', []))
    to_compare = {'allow_duplicates': False, 'dependencies': []}
    assert r.deserialize(data) == to_compare

    

# Generated at 2022-06-23 07:05:15.593039
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    assert RoleMetadata().deserialize(data)['allow_duplicates'] is True
    assert RoleMetadata().deserialize(data)['dependencies'] == []
