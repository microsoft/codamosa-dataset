

# Generated at 2022-06-23 06:55:38.610561
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    mock_owner = 'ansible.builtin'
    null_obj = RoleMetadata.load({}, mock_owner)
    assert null_obj.allow_duplicates == False
    assert null_obj.dependencies == []

    role_obj = RoleMetadata.load({'allow_duplicates': True, 'dependencies': ['role1']}, mock_owner)
    role_obj.deserialize(dict(allow_duplicates=False, dependencies=[]))
    assert role_obj.allow_duplicates == False
    assert role_obj.dependencies == []

    role_obj.deserialize(dict(allow_duplicates=True, dependencies=['role2']))
    assert role_obj.allow_duplicates == True
    assert role_obj.dependencies == ['role2']

# Generated at 2022-06-23 06:55:43.675333
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    r = RoleMetadata.load({ 'allow_duplicates': True, 'dependencies': ['foo', 'bar']}, owner=None)
    assert r.allow_duplicates == True
    assert r.dependencies == ['foo', 'bar']
    assert r._owner is None

# Generated at 2022-06-23 06:55:53.577519
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role_include import RoleInclude

    t1 = Task()
    t2 = TaskInclude()
    b1 = Block()
    p1 = Play()
    p1.hosts = ['test.org']
    p1.name = 'test play'

    p1.set_loader(MockLoader())

# Generated at 2022-06-23 06:56:03.752259
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    m = RoleMetadata(owner=None)

    data1 = {
        'allow_duplicates': False,
        'dependencies': []
    }

    data2 = {
        'allow_duplicates': True,
        'dependencies': [
            ('testrole1'),
            ('testrole2', ["testtag1", "testtag2"])
        ]
    }

    m.deserialize(data1)

    assert m.allow_duplicates == data1['allow_duplicates']
    assert len(m.dependencies) == 0

    m.deserialize(data2)

    assert m.allow_duplicates == data2['allow_duplicates']
   

# Generated at 2022-06-23 06:56:13.979456
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition

    # constructor
    role = RoleDefinition.load({}, {"name": "test_role"}, variable_manager=None, loader=None)
    role_metadata = RoleMetadata(owner=role)

    # Test all public properties of class RoleMetadata
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == {}
    assert role_metadata._argument_specs == {}
    assert role_metadata.role._name == "test_role"
    assert role_metadata.role._metadata._galaxy_info == {}
    assert role_metadata.role._metadata._argument_specs == {}

# Generated at 2022-06-23 06:56:18.516853
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata().deserialize(dict(
        allow_duplicates=True,
        dependencies=['name1', 'name2', 'name3']
    ))

    assert meta.allow_duplicates
    assert len(meta.dependencies) == 3



# Generated at 2022-06-23 06:56:30.195848
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.module_utils.six import StringIO

    yaml_text = '''
---
- hosts: all
  roles:
    - common
    - web
    - db
    - { role: nfs_server, become: yes, become_user: root }
    '''

    loader, inventory, variable_manager = ansible_playbook_test(yaml_text)
    play = Play.load(data=dict(
        name = "test",
        hosts = 'all',
        roles = [
            "common",
            "web",
            "db",
            RoleRequirement.role_yaml_parse("nfs_server"),
        ],
    ), variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:56:41.655993
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook import Play
    from ansible.inventory.host import Host

    play_obj = Play().load(dict(
        name = "Ansible Play",
        hosts = "all",
        gather_facts = "no",
        roles = ["common", "webtier"],
    ))
    group_obj = Host("all")
    group_obj.set_variable('hosts', ['host1.example.org', 'host2.example.org'])
    host1_obj = Host("host1.example.org")
    host2_obj = Host("host2.example.org")

    host1_obj.set_variable('ansible_ssh_user', 'root')

# Generated at 2022-06-23 06:56:52.707552
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    class TestObject(object):
        def get_name(self):
            return 'test_role'

    role = RoleDefinition.load(dict(
        name='test_role',
        import_playbook=None,
        file=None,
        scm=None,
        galaxy_info=None,
        dependencies=[],
        default_vars={},
        vars={},
        vars_prompt={},
    ))
    role.validate()
    role._role_path = 'role_path'
    role._role_collection = None
    test_obj = TestObject()
    role._owner = test_obj
    role._

# Generated at 2022-06-23 06:57:04.435361
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_dependency import RoleDependency
    include = RoleInclude()
    include.role = RoleDefinition()
    include.role.name = 'test-role'
    include_path = '/tmp/library'
    include.role.collections = ['collection1', 'collection2']
    include.role.path = include_path
    role_dep = RoleDependency(include=include)

# Generated at 2022-06-23 06:57:05.058739
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-23 06:57:06.566207
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_obj = RoleMetadata()
    assert test_obj._owner is None
    assert test_obj.allow_duplicates is False
    assert test_obj.dependencies == []

# Generated at 2022-06-23 06:57:14.193436
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    role_data = {
        'allow_duplicates': False,
        'dependencies': ['role1', 'role2']
    }
    obj.deserialize(role_data)
    assert (obj.allow_duplicates == False)
    assert (obj.dependencies == ['role1', 'role2'])


# Generated at 2022-06-23 06:57:18.902660
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    role.dependencies = 'test'
    serialized_role = role.serialize()
    assert serialized_role['allow_duplicates'] == True
    assert serialized_role['dependencies'] == 'test'

# Generated at 2022-06-23 06:57:33.467449
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

    host_list = [
        "test_all_hosts"
    ]
    inventory = Inventory(host_list)


# Generated at 2022-06-23 06:57:36.966740
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role = RoleMetadata()
    role.deserialize(data)
    assert role._allow_duplicates == False
    assert role._dependencies == []

# Generated at 2022-06-23 06:57:47.942895
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # Test for empty parameter 'data'
    m = RoleMetadata(owner=None).deserialize(data={})
    assert m._allow_duplicates == False
    assert m._dependencies == []

    # Test for 'data' with field 'allow_duplicates'
    m = RoleMetadata(owner=None).deserialize(data={'allow_duplicates': True})
    assert m._allow_duplicates == True
    assert m._dependencies == []

    # Test for 'data' with field 'dependencies'
    m = RoleMetadata(owner=None).deserialize(data={'dependencies': []})
    assert m._allow_duplicates == False

# Generated at 2022-06-23 06:57:51.352931
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner = None)
    assert m._allow_duplicates == False
    assert m._dependencies == []

# Generated at 2022-06-23 06:57:53.871788
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 06:58:01.876720
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Unit test for method serialize of class RoleMetadata
    """

    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    my_dependency_role_definition = RoleDefinition(name="my_dependency_role")
    my_dependency_role_include = RoleInclude(role=my_dependency_role_definition)

    my_metadata = RoleMetadata()
    my_metadata.allow_duplicates = True
    my_metadata.dependencies = [my_dependency_role_include]

    assert my_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [my_dependency_role_include]}

# Generated at 2022-06-23 06:58:12.093895
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import json
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.definition import RoleDefinition

    module_utilities = __import__('ansible.module_utils', globals(), locals(), ['basic'])
    import ansible.module_utils.basic

    variable_manager = ansible.module_utils.basic.AnsibleVariableManager()
    for key, val in module_utilities.__dict__.items():
        variable_manager._fact_cache[key] = val
    variable_manager._fact_cache['json'] = json


# Generated at 2022-06-23 06:58:16.770927
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    data_to_deserialize = {
        'allow_duplicates': False,
        'dependencies': []
    }
    role_metadata = RoleMetadata()

    role_metadata.deserialize(data_to_deserialize)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 06:58:18.084477
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta_data_obj = RoleMetadata()

# Generated at 2022-06-23 06:58:26.528116
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    yml = dict(
        allow_duplicates=True,
        dependencies=[
            dict(src='some_path_to_role'),
            dict(src='some_path_to_role_2,v1.0.3')
        ]
    )

    # Init class
    test_obj = RoleMetadata()
    # Call function serialize
    result = test_obj.deserialize(data=yml)
    # Check type
    assert isinstance(result, dict)
    assert 'allow_duplicates' in result.keys()
    assert 'dependencies' in result.keys()
    assert isinstance(result['allow_duplicates'], bool)
    assert isinstance(result['dependencies'], list)
    assert isinstance(result['dependencies'][0], dict)



# Generated at 2022-06-23 06:58:38.214664
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible import constants as C

    owner = 'ansible.builtin.include_role'
    variable_manager = 'ansible.vars.manager.VariableManager'
    loader = 'ansible.parsing.dataloader.DataLoader'
    role_m = RoleMetadata(owner)

    #Test case when data is not a dictionary
    data = []
    try:
        role_m._load_data(data, variable_manager=variable_manager, loader=loader)
    except AnsibleParserError as e:
        assert "the 'meta/main.yml' for role ansible.builtin.include_role is not a dictionary" in str(e)

    #Test case when ds is not a list
    data = {'dependencies': {}}

# Generated at 2022-06-23 06:58:47.260479
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import sys
    sys.path.append('../')
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    options = parse_options(dict())
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, options=options)
    inventory = InventoryManager(loader=loader, sources=options.inventory,
                                            variable_manager=variable_manager)
    role_name = 'dummy'
    path = '/path/to/dummy'
    role = Role().load({'name': role_name}, 'test', variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:58:50.889753
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    r = RoleMetadata()
    r.deserialize(data)
    assert r.serialize() == data

# Generated at 2022-06-23 06:58:53.367300
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert(RoleMetadata(owner='owner') != None)

# Generated at 2022-06-23 06:58:58.267373
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': ['role1', 'role2']
    }
    m.deserialize(data)
    assert m._allow_duplicates == data['allow_duplicates']
    assert m._dependencies == data['dependencies']

# Generated at 2022-06-23 06:59:02.108183
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Set up
    role_metadata = RoleMetadata(owner=None)
    data = {"allow_duplicates": False, "dependencies": []}

    # Run
    role_metadata.deserialize(data)

    # Assert
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []


# Generated at 2022-06-23 06:59:03.390961
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()

# Generated at 2022-06-23 06:59:12.132349
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class owner:
        def __init__(self):
            self._role_path = ''
            self._play = None
            self._role_collection = None

    def test_load(data, owner):
        return RoleMetadata.load(data, owner=owner)

    def load_data(self, data, **kwargs):
        setattr(self, '_variable_manager', kwargs.get('variable_manager'))
        setattr(self, '_loader', kwargs.get('loader'))
        return self._load_data(data)

    saved_RoleMetadata_load = RoleMetadata.load
    RoleMetadata.load = test_load
    saved_RoleMetadata_load_data = RoleMetadata.load_data
    RoleMetadata.load_data = load_data

    m = RoleMetadata

# Generated at 2022-06-23 06:59:21.359593
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    # For this test, we don't use the normal setattr, as it would cause
    # problems to the _get_fields() definition
    role_def = RoleDefinition()
    role_def.__dict__['_role_name'] = "test_RoleMetadata_serialize"
    role_def.__dict__['_role_path'] = "/some/path/name"

    meta = RoleMetadata()
    meta.__dict__['_allow_duplicates'] = True
    meta.__dict__['_owner'] = role_def

    data = meta.serialize()
    assert 'allow_duplicates' in data
    assert data['allow_duplicates'] is True
    assert 'dependencies' in data
    assert data['dependencies'] == []

   

# Generated at 2022-06-23 06:59:32.129036
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import collection_loader

    # load the data for this function
    collection_list = [os.path.join(os.path.dirname(__file__), '../fixtures/collections/ansible_collections/test_collection/roles/role1')]
    collection_loader.set_collection_paths(collections=collection_list)

    role_def = {'name': 'test_collection.role1', 'version': '1.0'}
    role_req = RoleRequirement.from_role_yaml(role_def, play=None)
    role = role_req.get_role()

    # initialize the object
    obj = RoleMetadata(owner=role)

    # deserialize the data

# Generated at 2022-06-23 06:59:44.106037
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    yaml_data = """
---
galaxy_info:
  description: A sample description
  author: Unknown
  company: Unknown
  license: Apache 2.0
  min_ansible_version: 1.0
  platforms:
    - name: Ubuntu
      versions:
        - "14.04"
        - "16.04"
        - "18.04"
    - name: Debian
      versions:
        - "8"
        - "9"
  galaxy_tags:
    - tag1
    - tag2
dependencies:
  - role: foo
  - role: bar
    version: v2.0
  - role: baz
    name: galaxy.baz
    version: v1.0
"""
    from ansible.playbook.role import Role

# Generated at 2022-06-23 06:59:47.000819
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # TODO
    # 1. create DataLoader object
    # 2. create VariableManager object
    # 3. create InventoryManager object
    # 4. create Role object
    # 5. create RoleMetadata object
    # 6. test for RoleMetadata.load
    pass


# Generated at 2022-06-23 06:59:48.892169
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': []}


# Generated at 2022-06-23 06:59:55.577550
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role

    # Create a play
    play_context = PlayContext()
    play = Play().load({
        'name': 'test play',
        'hosts': 'test_hosts',
        'connection': 'local',
        'gather_facts': 'no',
        'roles': []
    }, variable_manager=None, loader=None)
    play._tqm = None
    play_context._play = play

    # Create a role
    role = Role().load({
        'name': 'test_role'
    }, variable_manager=None, loader=None)

    # Create a role metadata
    role_metadata = RoleMetadata(owner=role)
   

# Generated at 2022-06-23 06:59:55.958712
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:00:00.430633
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_inst = RoleMetadata()
    assert role_metadata_inst._allow_duplicates == False
    assert role_metadata_inst._dependencies == []
    assert role_metadata_inst._galaxy_info == None
    assert role_metadata_inst._argument_specs == {}

# Generated at 2022-06-23 07:00:07.770792
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Test serialize method of class RoleMetadata
    '''

    allow_duplicates = True
    dependencies = ['docker', 'python', 'role']
    RoleMetadata._owner = 'test'
    RoleMetadata._allow_duplicates = allow_duplicates
    RoleMetadata._dependencies = dependencies

    result = RoleMetadata.serialize()
    assert allow_duplicates == result['allow_duplicates']
    assert dependencies == result['dependencies']

# Generated at 2022-06-23 07:00:13.704434
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from collections import namedtuple
    from ansible.playbook.role.definition import RoleDefinition

    test = namedtuple('test', 'name')

    value = RoleMetadata(owner=test(name='test'))
    assert isinstance(value, RoleMetadata)
    assert isinstance(value._ds, dict)
    assert isinstance(value._owner, test)
    assert value._dependencies is None
    assert value._galaxy_info is None
    assert value._argument_specs is None

# Generated at 2022-06-23 07:00:22.692517
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = dict()
    obj = RoleMetadata()
    obj.deserialize(meta)
    assert(obj.allow_duplicates == False)
    assert(len(obj.dependencies) == 0)
    meta = dict(allow_duplicates=True)
    obj.deserialize(meta)
    assert(obj.allow_duplicates == True)
    assert(len(obj.dependencies) == 0)
    meta = dict(dependencies=['foo', 'bar'])
    obj.deserialize(meta)
    assert(obj.allow_duplicates == True)
    assert(obj.dependencies == ['foo', 'bar'])

# Generated at 2022-06-23 07:00:31.842756
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display

    data = {}
    data['allow_duplicates'] = False
    data['dependencies'] = []

    owner = RoleInclude()
    owner._role_path = '/dev/null'
    owner._play = None

    collection_loader = AnsibleCollectionLoader()
    display = Display()
    role_metadata = RoleMetadata(owner=owner)

    role_metadata.deserialize(data)

# Generated at 2022-06-23 07:00:34.130706
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-23 07:00:46.392490
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    data = dict(
        name='test-role',
        tasks=[
            dict(
                name='test-task',
                action=dict(
                    module='test-module',
                    args=dict(test='test')
                )
            )
        ]
    )
    roles = [
        Role.load(data=data, play=None, variable_manager=None, loader=None)
    ]

    assert roles is not None
    assert len(roles) == 1
    role = roles[0]
    assert role.name == data['name']
    assert len(role._task_blocks) == 1
    task_block = role._task_blocks[0]
    assert len(task_block.block) == 1
   

# Generated at 2022-06-23 07:00:55.265570
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[],
    )
    m = RoleMetadata().load(data, owner=None)
    result = m.serialize()

    assert result == data
    assert result['allow_duplicates'] == data['allow_duplicates']
    assert result['dependencies'] == data['dependencies']


# Generated at 2022-06-23 07:00:59.840889
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata(owner="owner")
    # No result if dependencies is None
    assert r.serialize() == dict(dependencies=[])
    r.dependencies = [{"role": "xxx"}]
    # result is dict with allow_duplicates and dependencies set
    assert r.serialize() == dict(allow_duplicates=False, dependencies=[{"role": "xxx"}])



# Generated at 2022-06-23 07:01:07.301104
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # prepare fake data
    data = dict()
    owner = dict()
    # prepare fake variable_manager and loader
    variable_manager = dict()
    loader = dict()
    # test RoleMetadata class
    role_metadata = RoleMetadata.load(data, owner, variable_manager, loader)
    assert isinstance(role_metadata, RoleMetadata)
    assert isinstance(role_metadata._owner, dict)
    assert isinstance(role_metadata._dependencies, list)
    assert isinstance(role_metadata._galaxy_info, dict)
    assert isinstance(role_metadata._allow_duplicates, bool)

# Generated at 2022-06-23 07:01:11.751178
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_ds = dict(allow_duplicates=False, dependencies=[])
    role_metadata = RoleMetadata().load_data(role_ds)
    result = role_metadata.serialize()
    assert result['allow_duplicates'] is False
    assert result['dependencies'] == []

# Generated at 2022-06-23 07:01:13.655035
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    setattr(metadata, 'allow_duplicates', False)
    setattr(metadata, 'dependencies', [])
    expected_result = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    assert metadata.serialize() == expected_result

# Generated at 2022-06-23 07:01:26.259079
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()

    # setup a basic ansible.cfg and an empty inventory
    shutil.copyfile('test/functional/inventory', os.path.join(tmpdir, 'ansible.cfg'))
    shutil.copyfile('test/functional/inventory', os.path.join(tmpdir, 'inventory'))

    # create a minimal text file

# Generated at 2022-06-23 07:01:33.730007
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import unit_tests.support as support
    from ansible.playbook.role.definition import RoleDefinition

    loader = support.TestDataLoader()
    data = {
        'galaxy_info': {},
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'common'},
            {'role': 'webservers'},
            {'role': 'postgresql', 'some_var': 'foo'},
            {'role': 'rabbitmq'},
        ]
    }

    # Check that the class RoleMetadata is correctly loaded
    result = RoleMetadata.load(data, RoleDefinition("some_role", "/some/path"), loader=loader)
    assert result is not None
    assert result.allow_duplicates ==True
    assert result._dependencies is not None

# Generated at 2022-06-23 07:01:35.312513
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmet = RoleMetadata()
    res = rmet.serialize()
    assert res['allow_duplicates'] == rmet.allow_duplicates
    assert res['dependencies'] == rmet.dependencies


# Generated at 2022-06-23 07:01:46.117280
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class MyRole(object):
        def __init__(self):
            self.name = "MY_NAME"

    role = MyRole()
    r = RoleMetadata(owner=role)

    r.load_data(dict(
        dependencies=[],
        allow_duplicates=True,
        galaxy_info=dict(author="me", min_ansible_version="2.4", description="foobar"),
    ))

    assert r._dependencies == []
    assert r._galaxy_info["author"] == "me"
    assert r._galaxy_info["min_ansible_version"] == "2.4"
    assert r._galaxy_info["description"] == "foobar"

# Generated at 2022-06-23 07:01:52.963835
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Init a RoleMetadata object with dependencies
    role_metadata = RoleMetadata()
    role_metadata._dependencies = [{}, {}]
    role_metadata._allow_duplicates = False
    # Check if serialize method returns expected result
    assert role_metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[{}, {}])

# Generated at 2022-06-23 07:01:54.438842
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    assert data == RoleMetadata().serialize()

# Generated at 2022-06-23 07:01:56.331463
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    check = {'allow_duplicates': False, 'dependencies': []}
    assert role_metadata.serialize() == check


# Generated at 2022-06-23 07:02:04.015154
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    role.deserialize(dict(dependencies=[{'role': 'geerlingguy.java'}]))
    assert type(role.dependencies) == list
    assert role.dependencies[0]['role'] == 'geerlingguy.java'
    role.deserialize(dict(allow_duplicates=True))
    assert role.allow_duplicates == True


# Generated at 2022-06-23 07:02:13.254197
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager

    loader = AnsibleCollectionLoader()

    role = Role.load(dict(name='foo'), play=None, variable_manager=None, loader=loader)
    metadata = RoleMetadata.load({'dependencies': []}, owner=role, variable_manager=VariableManager())

    assert metadata._dependencies == []

    assert metadata._galaxy_info == None

# Generated at 2022-06-23 07:02:14.623075
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
        :param data:
        :return:
    '''

# Generated at 2022-06-23 07:02:17.375013
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta = RoleMetadata()
    assert role_meta._allow_duplicates == False
    assert len(role_meta._dependencies) == 0
    assert not role_meta._ds
    assert not role_meta._owner


if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-23 07:02:22.694830
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': False,
        'dependencies': []
    })
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 07:02:24.690947
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    md = RoleMetadata()
    assert md.allow_duplicates == False
    assert md.dependencies == []

# Generated at 2022-06-23 07:02:28.325788
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Returns a serialized copy of the data contained within the RoleMetadata object
    '''

    rm = RoleMetadata()
    rm.allow_duplicates = True
    assert rm.serialize() == dict(allow_duplicates=True, dependencies=[])

# Generated at 2022-06-23 07:02:38.855031
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    # test with empty data
    assert rmd.deserialize({}) == (False, [])
    # test with empty data
    assert rmd.deserialize({'allow_duplicates': 'not-bool'}) == (False, [])
    # test with empty data
    assert rmd.deserialize({'allow_duplicates': 1, 'dependencies': False}) == (True, [])
    # test with empty data
    assert rmd.deserialize({'allow_duplicates': True, 'dependencies': 'not-list'}) == (True, [])
    # test with empty data
    assert rmd.deserialize({'allow_duplicates': True, 'dependencies': []}) == (True, [])

# Generated at 2022-06-23 07:02:46.840393
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #Creating a dictionary to load the list of dependencies
    data = {'allow_duplicates': False, 'dependencies': [{'name': 'test-role'}, {'name': 'test-role2'}]}
    #Creating a new RoleMetadata object
    role_metadata = RoleMetadata(owner=None)
    #Creating a new RoleMetadata object
    role_metadata_loaded = role_metadata.load(data, owner=None)
    assert role_metadata_loaded._allow_duplicates == data['allow_duplicates']
    assert role_metadata_loaded._dependencies == data['dependencies']

# Generated at 2022-06-23 07:02:56.899705
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.plugins.loader import role_loader

    from units.mock.loader import DictDataLoader

    class t_RoleMetadata(RoleMetadata):
        def __init__(self, owner=None, data=None):
            super(t_RoleMetadata, self).__init__(owner)
            self._data = data

        def load(self, data, variable_manager=None, loader=None):
            return self._data

    class t_Role(Role):
        def __init__(self, role_name=None, role_path=None):
            super(t_Role, self).__init__(role_name=role_name, role_path=role_path)


# Generated at 2022-06-23 07:03:02.657402
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    assert meta.dependencies == []
    assert meta.allow_duplicates == False

# Generated at 2022-06-23 07:03:10.867250
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import collections

    assert isinstance(RoleMetadata()._allow_duplicates, bool)
    assert isinstance(RoleMetadata()._dependencies, collections.Sequence)
    assert isinstance(RoleMetadata()._galaxy_info, dict)

# Generated at 2022-06-23 07:03:11.726769
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:03:23.646084
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from io import StringIO
    test_role_path = 'tests/test_collections/ansible_collections/basic_with_metadata/roles'
    test_role = os.path.join(test_role_path, 'base')
    role = Role.load(test_role, loader=None)
    role_files = [filename for filename
                  in os.listdir(os.path.join(test_role, 'meta'))
                  if filename.endswith('main.yml')]
    if not role_files:
        raise Exception('No roles/meta/main.yml in test data')
    file_path = os.path.join('roles', 'meta', role_files[0])
    print(file_path)

# Generated at 2022-06-23 07:03:29.787464
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r.allow_duplicates = 'True'
    r.dependencies = ['Test', 'Dependencies']
    assert r.serialize() == {'allow_duplicates': 'True', 'dependencies': ['Test', 'Dependencies']}
    r.allow_duplicates = ''
    assert r.serialize() == {'allow_duplicates': '', 'dependencies': ['Test', 'Dependencies']}


# Generated at 2022-06-23 07:03:33.053214
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print('IN test_RoleMetadata')
    r = RoleMetadata()
    print(r.get_dependencies())
    return

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-23 07:03:35.094547
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    r.deserialize(data)
    assert r._allow_duplicates == False
    assert r._dependencies == []


# Generated at 2022-06-23 07:03:46.057283
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play

    my_play = Play.load({}, variable_manager=None, loader=None)
    role_definition = RoleDefinition.load({
        "role1": [
            'role1_name'
        ]
    }, my_play, variable_manager=None, loader=None)

    r = RoleMetadata(owner=role_definition)
    r.deserialize({"allow_duplicates": True, "dependencies": "role1_name"})

    assert r._allow_duplicates == True
    assert r._dependencies == ['role1_name']


# Generated at 2022-06-23 07:03:50.870021
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'dependencies': [{'role': 'common'}, {'role': 'geerlingguy.java'}, {'role': 'apache'}]}
    assert RoleMetadata.load(data, None) is not None

# Generated at 2022-06-23 07:04:00.896717
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # create a test RoleMetadata object
    class MockOwner():
        def get_name(self):
            return 'my_test_role'

    role_metadata = RoleMetadata(owner=MockOwner())

    # test data for deserialize method
    test_data = dict(allow_duplicates=False, dependencies=['role1', 'role2'])

    # call deserialize method of class RoleMetadata
    role_metadata.deserialize(test_data)

    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-23 07:04:12.050234
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.plugins.loader import find_plugin_files

    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager

    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader

    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play import Play

    # We create a dummy context to test the serialize method of RoleMetadata
    context = PlayContext()
    context.CLIARGS = dict(become_method='sudo', become_user='root')

    loader = DataLoader()
    templar = Templar(loader=loader)

    inv_manager = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Create

# Generated at 2022-06-23 07:04:18.095855
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print('Test deserialize of class RoleMetadata')
    testObject = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': 'test'}
    testObject.deserialize(data)
    dependencies = testObject.dependencies
    if dependencies is None:
        raise AnsibleError('testObject.dependencies is None')
    print('testObject.dependencies:', dependencies)

# Generated at 2022-06-23 07:04:31.005645
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block

    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        roles=['test_role'],
        tasks=[
            dict(action=dict(module='setup', args=dict())),
            dict(action=dict(module='command', args=dict(free_form='whoami'))),
        ]
    )


# Generated at 2022-06-23 07:04:32.499493
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-23 07:04:34.235046
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role

    a_role = Role()
    assert a_role.metadata is not None

# Generated at 2022-06-23 07:04:35.156020
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass


# Generated at 2022-06-23 07:04:41.413731
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_RoleMetadata = RoleMetadata()
    setattr(test_RoleMetadata, '_allow_duplicates', True)
    setattr(test_RoleMetadata, '_dependencies', ['test'])
    # test method serialize of RoleMetadata
    assert test_RoleMetadata.serialize() == {"allow_duplicates": True, "dependencies": ['test']}

# Generated at 2022-06-23 07:04:51.450629
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.task import Task

    t = Task()
    rm = RoleMetadata()

    # Test serialized data with allow_duplicates flag and no dependencies
    data = {'dependencies': [], 'allow_duplicates': True}
    rm.deserialize(data)
    assert rm._dependencies == []
    assert rm.allow_duplicates == True

    # Test serialized data with allow_duplicates flag and empty dependencies
    data = {'dependencies': [], 'allow_duplicates': False}
    rm.deserialize(data)
    assert rm._dependencies == []
    assert rm.allow_duplicates == False

# Generated at 2022-06-23 07:05:01.857927
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import ansible.playbook.role.definition as role_definition

    host_vars = dict(
        http_port=80,
        maxRequestsPerChild=808
    )
    m = RoleMetadata().load(
        dict(
            allow_duplicates=True,
            dependencies=[dict(role="geerlingguy.java", version="v1.0.0"), 'geerlingguy.tomcat']
        ),
        owner=role_definition.RoleDefinition(
            dict(
                name="geerlingguy.tomcat",
                tasks=list()
            ),
            host_vars
        )
    )

    serialized = m.serialize()

# Generated at 2022-06-23 07:05:06.582575
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict(
        allow_duplicates='true',
        dependencies='../roles'
    )

    data_processed = RoleMetadata.load(data)
    assert data_processed.allow_duplicates == 'true'
    assert data_processed.dependencies == '../roles'


# Generated at 2022-06-23 07:05:10.681646
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ds = {'dependencies': ['A'], 'allow_duplicates': True}
    m = RoleMetadata(owner=None).load_data(ds, variable_manager=None, loader=None)
    assert m.allow_duplicates == True
    assert m.dependencies == ['A']

# Generated at 2022-06-23 07:05:23.335376
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    print("TESTING RoleMetadata")

    import os
    import sys
    import ansible.executor.task_queue_manager
    import ansible.inventory.manager
    import ansible.playbook.play
    import ansible.parsing.dataloader
    import ansible.utils.vars
    import ansible.plugins.loader

    ansible.plugins.loader.add_directory(os.path.dirname(__file__) + '/../../plugins/')
    ansible.plugins.loader.add_directory(os.path.dirname(__file__) + '/../../../lib/ansible/plugins')

    def __create_task_queue_manager(inventory, variable_manager, loader, options, passwords, stdout_callback, run_additional_callbacks=True, run_tree=False):
        return

# Generated at 2022-06-23 07:05:29.957579
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role_def = RoleDefinition('example')
    roleMetadata = RoleMetadata(role_def)
    assert isinstance(roleMetadata._allow_duplicates, bool)
    assert roleMetadata._allow_duplicates == False
    assert isinstance(roleMetadata._dependencies, list)
    assert isinstance(roleMetadata._galaxy_info, dict)
    assert isinstance(roleMetadata._argument_specs, dict)