

# Generated at 2022-06-23 06:55:22.300011
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    obj = RoleMetadata()
    assert obj.serialize() == {
        'allow_duplicates': False,
        'dependencies': [],
    }

# Generated at 2022-06-23 06:55:32.333432
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Loads a role metadata from a dictionary
    r = RoleMetadata()
    ds = dict(
        dependencies = [
            dict(role="common", some_variable="foo", some_bool=True),
            dict(role="webserver", some_global_variable="bar", some_int_number=999),
        ],
        allow_duplicates = True,
    )
    r.load(ds, owner=None)

    assert r.dependencies
    assert r.allow_duplicates

    r = RoleMetadata()

# Generated at 2022-06-23 06:55:38.540103
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from .role import Role
    from .helpers import load_collection_roles
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    role_path = '%s/test_collections/collections/test_ns/test_collect/roles/test_role' % C.DEFAULT_COLLECTIONS_PATHS[0]
    loader = DataLoader()
    roles = load_collection_roles([role_path], loader=loader)

    # test RoleMetadata with galaxy_info
    assert roles[0].metadata._galaxy_info is not None
    assert roles[0].metadata._galaxy_info.get('author') is not None
    assert roles[0].metadata._galaxy_info.get('description') is not None
    assert roles[0].metadata._

# Generated at 2022-06-23 06:55:49.239928
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    rd = RoleDefinition()
    b = Block(rd)
    t = Task()
    t._parent = b
    rd._parent = t
    a = RoleMetadata(owner=rd)
    a._dependencies = ["scljojo.expect", "scljojo.java", "jdauphant.nginx", "scljojo.maven"]

# Generated at 2022-06-23 06:55:54.038436
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolemeta = RoleMetadata()
    rolemeta.allow_duplicates = True
    rolemeta.dependencies = ["r1","r2"]
    data = rolemeta.serialize()
    assert(data.get('allow_duplicates', False) == True)
    assert(data.get('dependencies', []) == ["r1","r2"])
    return

# Generated at 2022-06-23 06:55:57.313699
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['test1','test2']
    )

    m = RoleMetadata()
    m.deserialize(data)
    assert m._allow_duplicates == True
    assert m._dependencies == ['test1','test2']

# Generated at 2022-06-23 06:56:00.076128
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = {'allow_duplicates': True}
    assert RoleMetadata.load(role, None) is not None

# Generated at 2022-06-23 06:56:04.484005
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    role_path = './test/units/module_utils/data/test_role_metadata'
    role_name = 'test_role_metadata'
    role = Role.load(role_path, name=role_name)
    assert isinstance(role, Role)
    assert isinstance(role._role_path, string_types)
    assert isinstance(role._role_name, string_types)
    assert isinstance(role._metadata, RoleMetadata)
    assert role._metadata._owner == role
    assert role._metadata._variable_manager is None
    assert role._metadata._loader is None
    assert role._metadata.allow_duplicates is False


# Generated at 2022-06-23 06:56:06.116591
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert True

# Generated at 2022-06-23 06:56:18.880176
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    rmd.allow_duplicates = True
    assert len(rmd.dependencies) == 0

    assert rmd.serialize() == {
        'allow_duplicates': True,
        'dependencies': []
    }

    rmd.dependencies.append({'role': 'a.dependency1', 'version': '1.0.0'})
    rmd.dependencies.append({'role': 'a.dependency2', 'version': '1.1.0'})
    rmd.dependencies.append({'role': 'a.dependency3', 'version': '1.2.0'})


# Generated at 2022-06-23 06:56:29.373293
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Loads a role's metadata
    m = RoleMetadata()
    m.load(data=dict(),
           owner=None,
           variable_manager=None,
           loader=None)
    # Serializes a role's metadata and returns the structure
    m.serialize()
    # Deserializes a role's metadata structure and populates the instance
    m.deserialize(data=dict())
    # Allows for the parsing of role dependency strings from the command line to be parsed into the format required by the role dependencies.
    m._load_dependencies(attr=None, ds=dict())
    # Allows for the parsing of galaxy_info
    m._load_galaxy_info(attr=None, ds=dict())

# Generated at 2022-06-23 06:56:34.159461
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    role.dependencies = ["common"]
    assert role.serialize()['allow_duplicates'] == True
    assert role.serialize()['dependencies'] == ['common']

# Generated at 2022-06-23 06:56:43.314920
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_metadata = RoleMetadata()
    assert test_metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )

    test_metadata_2 = RoleMetadata()
    test_metadata_2.deserialize(dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    ))
    assert test_metadata_2.serialize() == dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )

# Generated at 2022-06-23 06:56:45.519595
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    result = RoleMetadata()
    assert isinstance(result, RoleMetadata)
    assert result._allow_duplicates is False
    assert result._dependencies == []

# Generated at 2022-06-23 06:56:47.041262
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Use constructor to create an object
    RoleMetadata()

# Generated at 2022-06-23 06:56:54.813492
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """Unit test for method load of class RoleMetadata."""

    # Generate data
    ds = dict(
        allow_duplicates=False,
        dependencies=dict()
    )
    data = dict(
        allow_duplicates=False,
        dependencies=dict()
    )

    # Create mock object
    class MockOwner:
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

        def _role_path(self):
            return ''

        def _play(self):
            return self

    role = RoleMetadata(owner=MockOwner('mock_name'))
    role.load_data(data, variable_manager=None, loader=None)
    result = role.serialize()
    assert result == ds



# Generated at 2022-06-23 06:56:59.835514
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': True, 'dependencies': ['test']})
    assert r._allow_duplicates == True, 'allow_duplicates should be True'
    assert r._dependencies == ['test'], 'dependencies should be [\'test\']'



# Generated at 2022-06-23 06:57:00.946850
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass # TODO: implement your test here

# Generated at 2022-06-23 06:57:06.851193
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    print ("Unit test for method serialize of class RoleMetadata")
    # Test 1
    print ('Test 1')
    data = {'allow_duplicates': False,'dependencies': []}
    role_metadata = RoleMetadata(data)
    d = role_metadata.serialize()
    print (d)
    assert(data == d)


# unit test: test_RoleMetadata_deserialize

# Generated at 2022-06-23 06:57:19.918562
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    role = Role()
    role._role_path = "./role"
    role._role_name = "name"
    role_collection = "ansible.legacy"
    role._role_collection = role_collection
    role._role_collections = [role_collection]
    role._play = Play()
    role._play._context = PlayContext()
    # assume the following meta/main.yml:
    # dependencies

# Generated at 2022-06-23 06:57:32.970060
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleMapping

    # if the data is not a dict, raise AnsibleParserError
    data = AnsibleMapping()
    data.name = 'name'
    owner = RoleDefinition()
    owner._role_path = '/dir/dir/dir'
    try:
        RoleMetadata.load(data, owner)
        assert False, 'this should throw a AnsibleParserError'
    except AnsibleParserError:
        pass
    except Exception as e:
        assert False, 'unexpected exception: {}'.format(e)

# Generated at 2022-06-23 06:57:39.815533
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rolemeta = RoleMetadata()
    serialized_rolemeta = {'allow_duplicates': 'True' , 'dependencies': ['name1', 'name2']}
    rolemeta.deserialize(serialized_rolemeta)
    assert getattr(rolemeta, 'allow_duplicates') == True
    assert getattr(rolemeta, 'dependencies') == ['name1', 'name2']
# TEST FOR METHOD deserialize of class RoleMetadata ENDS HERE

# Generated at 2022-06-23 06:57:50.779196
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    # Test serialize from default constructor
    metadata = RoleMetadata()
    serialized = metadata.serialize()
    assert serialized is not None
    assert isinstance(serialized, dict)
    assert 'allow_duplicates' in serialized
    assert 'dependencies' in serialized
    assert serialized['allow_duplicates'] == metadata._allow_duplicates
    assert serialized['dependencies'] == metadata._dependencies

    # Test serialize with custom values for attributes
    new_dependencies = [
        {'role': 'role1'},
        {'role': 'role2'}
    ]
    metadata = RoleMetadata(owner=RoleDefinition('role'))
    metadata.dependencies = new_dependencies
    metadata.allow_duplicates = True

# Generated at 2022-06-23 06:57:57.077078
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[{'name': 'foo'}]
    )

    rmd = RoleMetadata().deserialize(data)
    assert isinstance(rmd, RoleMetadata)
    assert rmd.allow_duplicates is True
    assert rmd.dependencies
    assert rmd.dependencies[0].name == 'foo'

# Generated at 2022-06-23 06:58:08.392456
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ds = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    class MockBase(Base):
        def __init__(self):
            super(MockBase, self).__init__()
        def serialize(self):
            pass
        def deserialize(self, data):
            pass
    class MockRoleMetadata(RoleMetadata, MockBase):
        def __init__(self):
            super(MockRoleMetadata, self).__init__()
    rm = MockRoleMetadata()
    rm.deserialize(ds)
    assert rm.allow_duplicates == False
    assert rm.dependencies == []

# Generated at 2022-06-23 06:58:20.485500
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata_runner = RoleMetadata()
    metadata_runner._owner = load_list_of_roles(ds=dict(name='runner'))
    # test class_attributes
    assert metadata_runner._allow_duplicates == False
    assert metadata_runner._dependencies == []
    assert 'problem' not in metadata_runner._galaxy_info
    assert metadata_runner._argument_specs == {}
    # test the values returned by serialize
    assert metadata_runner.serialize() == {'allow_duplicates': False,
                                           'dependencies': []}
    # test the values set by deserialize
    metadata_runner.deserialize({'allow_duplicates': True,
                                 'dependencies': [dict(name='execute')]})
    assert metadata_runner._allow_duplicates == True


# Generated at 2022-06-23 06:58:25.955555
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': []
    }
    metadata.deserialize(data)
    assert metadata.allow_duplicates == True
    assert metadata.dependencies == []

# Generated at 2022-06-23 06:58:33.590162
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_met_data = RoleMetadata()
    if role_met_data._allow_duplicates != False:
        raise AssertionError("Should be false")

    if role_met_data._dependencies != []:
        raise AssertionError("Should be empty list")

    if role_met_data._galaxy_info != None:
        raise AssertionError("Should be None")

    if role_met_data._argument_specs != []:
        raise AssertionError("Should be empty list")

# Generated at 2022-06-23 06:58:45.192539
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class MockLoad():
        def __init__(self, ds):
            self.ds = ds
            self._loader = None
            self._variable_manager = None
        def load(self):
            return RoleMetadata.load(self.ds, self,
                                     variable_manager=self._variable_manager,
                                     loader=self._loader)
    class MockRole2():
        def __init__(self, role_path, role_collection):
            self.role_path = role_path
            self.role_collection = role_collection
    class MockRole():
        def __init__(self, ds, role_path=None, role_collection=None):
            self.ds = ds
            self._loader = None
            self._variable_manager = None
            self._role_path = role_path
            self

# Generated at 2022-06-23 06:58:56.122242
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils import context_objects as co
    from ansible.vars.manager import VariableManager

    # Create a valid metadata.yml
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                name='role1',
                src='col1.role1'
            ),
            dict(
                name='role2',
                src='col1.role2',
                version=3
            )
        ]
    )
    # Create a valid role in the current directory,
    # with name 'col1.role.role1'
    owner = RoleDefinition()
    owner._role_name = 'col1.role1'

# Generated at 2022-06-23 06:59:00.677180
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()

    setattr(role_metadata, '_allow_duplicates', True)
    setattr(role_metadata, '_dependencies', ['role1', 'role2'])

    actual = role_metadata.serialize()
    expected = {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}
    assert actual == expected



# Generated at 2022-06-23 06:59:10.798977
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    data = {'allow_duplicates': 'test', 'dependencies': [{'src':'test_role', 'name':'test_role'}]}
    owner = TaskInclude(play=True, role=True, task_include=True)

    result = RoleMetadata.load(data, owner)
    assert result.get_allow_duplicates() == 'test'
    result.set_allow_duplicates(True)
    result_dep = result.get_dependencies()
    assert len(result_dep) == 1
    assert result_dep[0].name == 'test_role'

# Generated at 2022-06-23 06:59:17.117163
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test = RoleMetadata()
    assert test._allow_duplicates == False
    assert test._dependencies == []
    assert test._galaxy_info == None
    assert test._argument_specs == {}
    assert test._owner == None

    #assert test.
    #assert test.
    #assert test.
    #assert test.
    #assert test.
    #assert test.


# Generated at 2022-06-23 06:59:26.149205
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test serialize()
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_object
    from ansible.playbook.play_context import PlayContext
    p = Play().load({'name': 'test', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager=None, loader=None)
    play_context = PlayContext()
    play_context._play = Play_object()
    result = RoleMetadata(owner=play_context).serialize()
    assert result == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 06:59:32.164548
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = []

    # Check that serialize returns a dictionary
    assert isinstance(role_metadata.serialize(), dict)

    # Check that serialize return value contains
    # the expected values
    expected_dict = {
        'allow_duplicates': False,
        'dependencies': []
    }
    assert role_metadata.serialize() == expected_dict

# Generated at 2022-06-23 06:59:38.147342
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata_deserialize = role_metadata.deserialize({'dependencies': [],
                                                           'allow_duplicates': False})
    assert role_metadata.dependencies == role_metadata_deserialize.dependencies
    assert role_metadata.allow_duplicates == role_metadata_deserialize.allow_duplicates

# Generated at 2022-06-23 06:59:44.020463
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    role_deps = RoleDefinition.load(
                {'name': 'geerlingguy.docker'},
                play=None,
                variable_manager=None,
                loader=None,
            )

    role_meta = RoleMetadata(owner=None)
    role_meta.deserialize(
        {
            "dependencies": [
                {
                    "role": role_deps
                }
            ],
            "allow_duplicates": False
        }
    )

    assert role_meta._allow_duplicates == False
    assert role_meta._dependencies[0].get_name() == "geerlingguy.docker"

# Generated at 2022-06-23 06:59:48.947612
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    owner = None
    variable_manager = None
    loader = None
    
    data = RoleMetadata.load(data='meta/main.yml', owner=owner, variable_manager=variable_manager, loader=loader)
    data.deserialize(data)
    print(data.allow_duplicates)
    print(data.dependencies)


# Generated at 2022-06-23 06:59:57.390614
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test for RoleMetadata initialization with valid values
    r = RoleMetadata(owner='')
    assert r.allow_duplicates == False
    assert r.dependencies == []

    # Test for RoleMetadata initialization with invalid values
    try:
        r = RoleMetadata(owner=5)
    except AssertionError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 07:00:08.761851
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_name = 'role_name'
    role_path = 'role_path'
    the_role = Role.load(role_name, role_path, None, None, None)
    the_meta_main_yml = {'hidden': False, 'allow_duplicates': False, 'dependencies': []}
    role_meta = RoleMetadata(owner=the_role)
    role_meta.deserialize(data=the_meta_main_yml)
    assert role_meta.allow_duplicates == False
    assert role_meta.dependencies == []
    the_meta_main_yml = {'hidden': False, 'allow_duplicates': True, 'dependencies': []}
    role_meta.deserialize(data=the_meta_main_yml)

# Generated at 2022-06-23 07:00:18.515102
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': 'an_allow_duplicates',
            'dependencies': 'a_dependencies'}
    deserialized_data = {}
    RoleMetadata.deserialize(deserialized_data, data)
    assert deserialized_data['allow_duplicates'] == 'an_allow_duplicates'
    assert deserialized_data['dependencies'] == 'a_dependencies'
    RoleMetadata.deserialize(deserialized_data, None)
    assert deserialized_data['allow_duplicates'] == 'an_allow_duplicates'
    assert deserialized_data['dependencies'] == 'a_dependencies'

# Generated at 2022-06-23 07:00:23.256801
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    _has_collection = hasattr(RoleMetadata, '_role_collection')
    _has_relations_path = hasattr(RoleMetadata, '_role_relations_path')
    _has_collection_path = hasattr(RoleMetadata, '_role_collection_path')

    assert _has_collection == _has_relations_path == _has_collection_path

# Generated at 2022-06-23 07:00:35.176901
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


    mock_loader = DataLoader()

    # Set up a mock owner
    mock_owner = PlayContext()
    mock_owner._role_path = 'foo'
    mock_owner._role_collection = None
    mock_owner._play = None
    mock_owner.collections = 'foo'

    # Set up a mock variable_manager
    mock_variable_manager = VariableManager()
    mock_variable_manager._extra_vars = {}

    # build a mock dataset for the RoleMetadata object to load
    mock_dataset = {}

    # call the load function with our mocked data; assert for truthiness
    assert RoleMetadata.load

# Generated at 2022-06-23 07:00:47.042703
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook import Play, Playbook, PlaybookInclude, PlaybookIncludeRole
    from ansible.playbook.play_context import PlayContext

    loader = None
    variable_manager = None
    play = Play.load(dict(name="foobar"), variable_manager=variable_manager, loader=loader)
    play.post_validate(variable_manager=variable_manager, loader=loader)
    playbook = Playbook.load([play], variable_manager=variable_manager, loader=loader)
    playbook.post_validate(variable_manager=variable_manager, loader=loader)
    playbook_include = PlaybookInclude.load(dict(hosts='host1', tasks=[dict(name="task1")]), variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 07:00:50.296564
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    roledata = '''
    from ansible.playbook.role.meta import RoleMetadata
    roledata = RoleMetadata()
    print(roledata)
    '''
    exec(roledata)

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-23 07:00:52.686585
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    r = Role()
    rm = RoleMetadata(owner=r)
    assert rm is not None

# Generated at 2022-06-23 07:00:57.894949
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_data = dict(
        allow_duplicates=True,
        dependencies='hello world'
    )
    expected_result = dict(
        allow_duplicates=True,
        dependencies='hello world'
    )
    m = RoleMetadata()
    m.deserialize(test_data)
    assert expected_result == m.serialize()

# Generated at 2022-06-23 07:01:02.098918
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    data = {}
    m = RoleMetadata(owner=RoleDefinition()).load_data(data)
    print("\nRoleMetadata:", m.serialize(), "\ndefault:", m._dependencies)
    return m


if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-23 07:01:07.805050
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class FakeOwner(object):
        def __init__(self, owner_name, play_name):
            self._name = owner_name
            self._play = play_name

    rm = RoleMetadata(owner=FakeOwner('owner_name', 'play_name'))
    data = dict()
    data['_allow_duplicates'] = False
    data['_dependencies'] = []
    rm.deserialize(data)
    assert rm.allow_duplicates == False
    assert rm.dependencies == []

# Generated at 2022-06-23 07:01:13.957811
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook import Playbook

    fake_playbook = Playbook()
    role_metadata = RoleMetadata(owner=fake_playbook)
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._owner == fake_playbook
    assert role_metadata._argument_specs == {}
    assert role_metadata._galaxy_info == {}

# Generated at 2022-06-23 07:01:21.056157
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    meta = {
        'allow_duplicates': True,
        'dependencies': [],
        'galaxy_info': 'info'
    }

    role_metadata = RoleMetadata()
    role_metadata.load_data(meta)

    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == 'info'

# Generated at 2022-06-23 07:01:24.106866
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test class RoleMetadata.
    :return:
    '''
    role_metadata = RoleMetadata(owner=None)
    assert not role_metadata._owner

# Generated at 2022-06-23 07:01:32.503433
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    make sure we get an object of class RoleMetadata
    """
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data = dict(
        allow_duplicates = False,
        dependencies = [
            "role1",
            "role2",
            "role3",
            "role4",
        ]
    )
    
    assert data['allow_duplicates'] == False
    assert len(data['dependencies']) == 4

    assert isinstance(data, dict)
    r=RoleMetadata.load(data, None)
    assert isinstance(r, RoleMetadata)

# Generated at 2022-06-23 07:01:39.731018
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    fake_obj = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2'],
    )
    fake_class = RoleMetadata(owner=None)
    assert isinstance(fake_class, RoleMetadata)
    assert fake_class.deserialize(data=fake_obj) is None
    assert fake_class._allow_duplicates is True
    assert fake_class._dependencies == ['role1', 'role2']



# Generated at 2022-06-23 07:01:46.604535
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Initialize params
    allow_duplicates = {u'allow_duplicates': True}
    dependencies = {u'dependencies': []}
    merge_result = {u'allow_duplicates': allow_duplicates, u'dependencies': dependencies}
    # Initialize object
    obj1 = RoleMetadata()
    # Check serialize
    obj2 = obj1.serialize()
    if obj2 == merge_result:
        return True
    else:
        return False


# Generated at 2022-06-23 07:01:57.998057
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    def load_role_def(role_def):
        if isinstance(role_def, string_types) or 'role' in role_def or 'name' in role_def:
            return role_def
        else:
            # role_def is new style: { src: 'galaxy.role,version,name', other_vars: "here" }
            role_def = RoleRequirement.role_yaml_parse(role_def)
            if 'name' not in role_def:
                raise AnsibleError("Name must be specified in the role dependency")
            return role_def


# Generated at 2022-06-23 07:01:59.787791
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata.load({'allow_duplicates': True}, None)

# Generated at 2022-06-23 07:02:04.325802
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata(owner=None)
    r._allow_duplicates = True
    r._dependencies = []
    result = r.serialize()
    assert result['allow_duplicates'] is True
    assert result['dependencies'] == []

# Generated at 2022-06-23 07:02:15.898864
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play
    from ansible.playbook.role_include import RoleInclude
    data = dict(
        allow_duplicates=False,
        dependencies=[],
        galaxy_info=dict(
            author='your name here',
            description='your description here',
            company='your company here',
            license='your license here',
            min_ansible_version='1.8',
            platforms=[
                dict(
                    name='someplatform',
                    versions=[
                        dict(version='1.0', supported=True)
                    ],
                    dependencies=[]
                )
            ],
        )
    )
    role = RoleInclude()
    role._role_path = 'a/b/c'
    play = Play()
    play.hosts = 'all'
    role._play = play


# Generated at 2022-06-23 07:02:28.597617
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    r = Role()
    r.name = 'foobar'
    r._role_path = './foo_role'
    assert r.get_name() == 'foobar'
    assert r._role_path == './foo_role'
    assert not r.tasks

    ds = {'foo': 'bar'}
    variable_manager = 'this is variable manager'
    loader = 'this is loader'
    m = RoleMetadata.load(ds, r, loader=loader, variable_manager=variable_manager)
    assert m._owner == r
    assert m._loader == loader
    assert m._variable_manager == variable_manager

    assert isinstance(m, RoleMetadata)


# Generated at 2022-06-23 07:02:33.116748
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    role_definition = RoleDefinition()
    role_definition.set_name('test_role')
    role_metadata = RoleMetadata(owner=role_definition)
    result = role_metadata.load({}, owner=role_definition, variable_manager=variable_manager, loader=loader)
    assert isinstance(result, RoleMetadata), \
        'The result for the method load of class RoleMetadata should be of type %s, but is of type %s' % \
        ('RoleMetadata', type(result))

# Generated at 2022-06-23 07:02:42.030090
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role

    r = Role()
    ds = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    rm = RoleMetadata(owner=r)
    rm.deserialize(data=ds)
    assert rm.serialize() == ds

# Generated at 2022-06-23 07:02:46.011367
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = list()
    assert(role_metadata.serialize() == dict(
            allow_duplicates=True,
            dependencies=list()
        ))


# Generated at 2022-06-23 07:02:51.036411
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import pytest
    RoleMetadata = RoleMetadata.deserialize(
        {
            'allow_duplicates':'allow_duplicates',
            'dependencies':'dependencies'
        }
    )
    assert RoleMetadata.allow_duplicates == 'allow_duplicates'
    assert RoleMetadata.dependencies == 'dependencies'

# Generated at 2022-06-23 07:02:54.004363
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    rmd._allow_duplicates = 1
    rmd._dependencies = ['a', 'b']
    rmd.deserialize(rmd.serialize())

# Generated at 2022-06-23 07:03:01.912764
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    try:
        from collections import OrderedDict
    except ImportError:
        from ordereddict import OrderedDict

    pb = Playbook()
    ds = {}
    ds['allow_duplicates'] = False
    ds['dependencies'] = ['foo']
    role = Role()
    role._role_path = b'fake_path'
   

# Generated at 2022-06-23 07:03:07.019846
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_metadata = RoleMetadata()
    assert test_metadata.dependencies == []
    assert test_metadata.allow_duplicates == False
    test_metadata1 = RoleMetadata(owner=1)
    assert test_metadata1.allow_duplicates == False
    assert test_metadata1.dependencies == []
    assert test_metadata1._owner == 1

# Generated at 2022-06-23 07:03:07.547667
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 07:03:13.776442
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata

    inv = {
        'all': {
            'hosts': ['localhost'],
            'vars': {
                'ansible_connection': 'local'
            }
        }
    }
    run = {
        'hosts': 'all',
        'roles': [
            {
                'role': 'test1',
                'myvar': '{{ foo }}'
            },
            {
                'role': 'test2'
            },
            'test3'
        ]
    }
    role = RoleDefinition.load('test1', {}, [], run)

# Generated at 2022-06-23 07:03:23.493354
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class TmpRoleMetadata(RoleMetadata):
        def __init__(self, **kwargs):
            self.allow_duplicates = kwargs.get("allow_duplicates")
            self.dependencies = kwargs.get("dependencies")
    role_metadata = TmpRoleMetadata(allow_duplicates=True, dependencies=["git + https://github.com/cristifalcas/ansible-role-common.git"])
    assert role_metadata.serialize() == dict(allow_duplicates=True, dependencies=["git + https://github.com/cristifalcas/ansible-role-common.git"])


# Generated at 2022-06-23 07:03:25.645722
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # method load of class RoleMetadata
    pass


# Generated at 2022-06-23 07:03:29.548335
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #Test load method

    my_role_metadata=RoleMetadata()

    # Test if allow_duplicates is set to default value
    my_role_metadata.deserialize({})
    assert my_role_metadata.allow_duplicates == False

    # Test if dependencies is set to default value
    assert my_role_metadata.dependencies == []

# Generated at 2022-06-23 07:03:38.325139
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.collection import CollectionRequirement

    class FakeVariableManager:
        @staticmethod
        def get_vars(loader, path=None, entities=None, cache=True):
            return dict(foo="bar")

    class FakeLoader:
        @staticmethod
        def load_from_file(path):
            return dict(a=1, b=2)

    fake_req = dict(role=dict(name='xyz'))
    fake_req2 = dict(role='xyz')

    fake_role = Role()
    fake_role._role_name = 'foo'
    fake_role._role_path = 'bar'
    fake_role.collections = []


# Generated at 2022-06-23 07:03:43.879764
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.include import RoleInclude

    rd = {'role':'common', 'tasks': ['main.yml']}
    assert isinstance(RoleMetadata.load({'dependencies': rd}, None), RoleMetadata)
    assert isinstance(RoleMetadata.load({'dependencies': [rd]}, None), RoleMetadata)
    assert isinstance(RoleMetadata.load({'dependencies': [{'role':'common'}]}, None), RoleMetadata)


# Generated at 2022-06-23 07:03:46.374766
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )

# Generated at 2022-06-23 07:03:52.666852
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test for constructor of class RoleMetadata
    '''
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader import AnsibleCollectionRef

    role = RoleDefinition.load({'foo': 'bar'}, '', [])
    role_metadata = RoleMetadata('bar', role)
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == []

    # Load
    role.name = 'new_name'
    role.role_name = 'new_role_name'
    role.role_path = 'new_location'
    role_metadata = RoleMetadata.load('bar', role)
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == []
    assert role_metadata._

# Generated at 2022-06-23 07:04:04.265655
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Creates a gobal yaml that represents a dictionary
    '''
    yaml = '''
    dependencies:
    - name: common
      src: https://github.com/ansible/ansible-examples.git

    allow_duplicates: false
    '''
    parser = MockParser()
    role_metadata = RoleMetadata()
    role_metadata.deserialize(yaml)
    assert parser.get_attribute('allow_duplicates') == False
    assert parser.get_attribute('dependencies') == [{'name': 'common',
                                                     'src': 'https://github.com/ansible/ansible-examples.git'}]

'''
Create a mock parser that allows to get the values of the attributes
'''

# Generated at 2022-06-23 07:04:06.616552
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []
    data['name'] = 'foo'
    role_metadata = RoleMetadata(owner='foo_owner')
    role_metadata.deserialize(data)
    assert role_metadata.serialize() == data


# Generated at 2022-06-23 07:04:08.722043
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    assert isinstance(meta, RoleMetadata)


# Generated at 2022-06-23 07:04:19.688603
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    from collections import namedtuple
    from ansible.playbook.role.include import RoleInclude

    RoleDef = namedtuple('RoleDef', ['role', 'name', 'scm', 'src', 'version'])
    role_dep = RoleDef('role', 'name', 'scm', 'src', 'version')
    role_deps = [role_dep]
    role_include = RoleInclude(role_deps=role_deps)
    role_metadata = RoleMetadata(owner=role_include)
    role_metadata.dependencies = role_deps

    result = role_metadata.serialize()

    assert result == dict(
        allow_duplicates=False,
        dependencies=[role_dep]
    )

# Generated at 2022-06-23 07:04:32.643898
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    module = 'main'
    name = 'name'
    path = '/path/to/roles/name/%s.yml' % module
    args = dict(
        verbosity=dict(required=False, default=0, type='int'),
        hosts=dict(required=True),
        become=dict(required=False, default=False, type='boolean'),
        become_user=dict(required=False),
        become_method=dict(required=False),
        check=dict(required=False, default=False, type='boolean')
    )
    variable_manager = None
    loader = None

    # Create RoleMetadata object

# Generated at 2022-06-23 07:04:36.406936
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import RoleFactory

    role = RoleFactory()
    role._role_path = 'tests/test_data/roles/meta_main_unmapped_field_missing'

    role_metadata = RoleMetadata.load(data=role._metadata, owner=role)

    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 07:04:47.267478
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook
    import ansible.playbook.role
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import ansible.executor.task_queue_manager

    collection_loader = AnsibleCollectionLoader()
    block_manager = ansible.playbook.block.BlockManager(play_context=PlayContext())
    variable_manager = VariableManager(loader=collection_loader)
    loader = ansible.parsing.dataloader.DataLoader()
    stdout_callback = ansible.executor.task_queue_manager._TaskQueueManager__std

# Generated at 2022-06-23 07:04:51.504427
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[],
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert False == role_metadata.allow_duplicates


# Generated at 2022-06-23 07:05:01.954622
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs

    loader = DataLoader()
    inv_data = {}
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    context = PlayContext()
    context._options = dict(log_path='/dev/null')

    add_all_plugin_dirs(C.DEFAULT_SYSTEM_PLUGIN_PATHS)
    variable_manager = VariableManager(loader=loader, inventory=inv)

    role_name = 'test_role'
    role_path

# Generated at 2022-06-23 07:05:04.271152
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # create a RoleMetadata object
    m = RoleMetadata()

    # create the expected serialized result
    expected = {}

    # test the serialize method
    result = m.serialize()

    # assert the result
    assert result == expected

# Generated at 2022-06-23 07:05:05.296586
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata()

# Generated at 2022-06-23 07:05:10.429470
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    rmd.deserialize(data={
        'allow_duplicates': True,
        'dependencies': [{'role': 'test', 'name': 'test'}]
    })

    assert rmd.allow_duplicates is True
    assert rmd.dependencies[0].role == 'test'

# Generated at 2022-06-23 07:05:18.657337
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'role': 'foo'}, {'role': 'bar'}]
    expected_result = {'allow_duplicates': True, 'dependencies': [{'role': 'foo'}, {'role': 'bar'}]}
    assert expected_result == role_metadata.serialize()

# Generated at 2022-06-23 07:05:28.346672
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    role = Role.load({
        'tasks': {
            'main.yml': {
                'meta': {
                    'dependencies': [],
                    'galaxy_info': {
                        'author': 'TEST',
                        'description': 'TEST',
                        'company': 'TEST',
                        'license': 'TEST',
                        'min_ansible_version': '1.0',
                        'platforms': [{'name': 'TEST'}],
                        'galaxy_tags': []
                    }
                }
            }
        }
    }, variable_manager=None, loader=None)
    role_metadata = RoleMetadata(owner=role)