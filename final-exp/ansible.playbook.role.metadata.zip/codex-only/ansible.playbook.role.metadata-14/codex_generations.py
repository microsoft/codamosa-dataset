

# Generated at 2022-06-23 06:55:30.477325
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """ Tests if deserialize sets the right values"""
    assert RoleMetadata().deserialize(data={'allow_duplicates': True, 'dependencies': "my_deps"}).allow_duplicates == True
    assert RoleMetadata().deserialize(data=None).allow_duplicates == False
    assert RoleMetadata().deserialize(data={'allow_duplicates': True, 'dependencies': "my_deps"}).dependencies == "my_deps"
    assert RoleMetadata().deserialize(data=None).dependencies == []


# Generated at 2022-06-23 06:55:40.813356
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test instantiation of a RoleMetadata object
    hostvars = dict(testhost=dict(ansible_host='127.0.0.1', ansible_port=22, ansible_user='user'))
    from ansible.vars import VariableManager
    vars = VariableManager(loader=None, variables=hostvars)
    from ansible.playbook.play import Play
    p1 = Play.load(dict(name='testplay1', hosts=['testhost'], tasks=[dict(action=dict(module='shell', args='ls'))]),
                   variable_manager=vars, loader=None)
    from ansible.playbook.task import Task
    t1 = Task.load(dict(name='task1', action=dict(module='shell', args='ls')), p1, p1._tqm)

# Generated at 2022-06-23 06:55:45.244824
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize(dict(allow_duplicates=True, dependencies=['dependency1', 'dependency2']))
    assert r.allow_duplicates == True
    assert r.dependencies == ['dependency1', 'dependency2']

# Generated at 2022-06-23 06:55:54.909652
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.yaml.loader import AnsibleLoader

    current_role_path = None
    collection_search_list = None

    # Create a role

# Generated at 2022-06-23 06:55:57.957744
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {"dependencies": [{"name":"my-role", "src":"https://example.com/roles/my-role.git"}]}
    role = RoleMetadata()
    result = role.load(data, variable_manager=None, loader=None)
    assert result is not None
    assert result.dependencies is not None

# Generated at 2022-06-23 06:56:00.108703
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    metadata.deserialize({"dependencies": ["a", "b"]})

    assert(metadata.dependencies == ["a", "b"])
    assert(metadata.allow_duplicates == False)

# Generated at 2022-06-23 06:56:06.695426
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'Foo'},
            {'role': 'Bar'}
        ]
    }
    rmd.deserialize(data)
    assert rmd.allow_duplicates is True
    assert rmd.dependencies[0].get_name() == 'Foo'
    assert rmd.dependencies[1].get_name() == 'Bar'

# Generated at 2022-06-23 06:56:11.760126
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    c = RoleMetadata()
    c.allow_duplicates = True
    c.dependencies = []
    temp_var = c.serialize()
    assert temp_var["allow_duplicates"] == True
    assert temp_var["dependencies"] == []


# Generated at 2022-06-23 06:56:16.178329
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_data = dict()
    test_data["allow_duplicates"] = True
    test_data["dependencies"] = [{u'role': u'foo'}]
    role_metadata = RoleMetadata()
    role_metadata.deserialize(test_data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies[0][u'role'] == u'foo'

# Generated at 2022-06-23 06:56:19.946999
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Input data
    roleMetadata = {}
    roleMetadata['allow_duplicates'] = False
    roleMetadata['dependencies'] = []

    # Check result
    assert RoleMetadata._serialize(roleMetadata) == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-23 06:56:25.853301
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.task_include import TaskInclude

    r = RoleMetadata()
    r.allow_duplicates = True
    t = TaskInclude()
    r.dependencies = [t]

    expected = {
        'allow_duplicates': True,
        'dependencies': [t]
    }

    assert r.serialize() == expected



# Generated at 2022-06-23 06:56:33.400893
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-23 06:56:33.835588
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 06:56:39.522924
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {"allow_duplicates": False, "dependencies": []}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert(role_metadata.allow_duplicates == False)
    assert(role_metadata.dependencies == [])

# Generated at 2022-06-23 06:56:52.372533
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class Role:
        def __init__(self, _role_path, _role_collection):
            self._role_path = _role_path
            self._role_collection = _role_collection

    class RoleRequirement:
        def __init__(self, role_name, scm, src, version, src_path, role_params=None):
            self.role_name = role_name
            self.scm = scm
            self.src = src
            self.version = version
            self.src_path = src_path
            self.role_params = role_params


# Generated at 2022-06-23 06:57:04.121575
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # import module snippets. An example snippet:
    #   t = AnsibleTemplate(content=content, file_name=file_name, search_path=search_path)
    #   t = AnsibleTemplate(content=content, file_name=file_name, search_path=search_path,
    #                           delimiters=('[[', ']]'))
    #   t = AnsibleTemplate(content=content, file_name=file_name, search_path=search_path,
    #                           encoding='koi8-r')
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # create temp file
    (fd, fname) = tempfile.mkstemp(prefix='ansible-tmp', suffix='.yml')
    os.close(fd)

    # create Ans

# Generated at 2022-06-23 06:57:15.969073
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    items = {
        "dependencies" : [{"name": "geerlingguy.ntp", "version": "1.9.1", "scm": "git", "src": "https://github.com/geerlingguy/ansible-role-ntp.git"}],
        "allow_duplicates" : True
    }
    r = RoleMetadata(None)
    r.deserialize(items)
    assert r.serialize()['dependencies'] == [{"name": "geerlingguy.ntp", "version": "1.9.1", "scm": "git", "src": "https://github.com/geerlingguy/ansible-role-ntp.git"}]
    assert r.serialize()['allow_duplicates'] == True

# Generated at 2022-06-23 06:57:24.549700
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #(self, data, owner, variable_manager=None, loader=None):
    data = ["geerlingguy.mysql", "example_role",
           {"src": "git+https://github.com/geerlingguy/ansible-role-php.git", "version": "1.0.0"},
           {"src": "git+https://github.com/geerlingguy/ansible-role-apache.git"},
           {"name": "geerlingguy.ntp", "some_other_variable": "foo"}]
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager(loader=loader)
    from ansible.playbook.play import Play

# Generated at 2022-06-23 06:57:35.251929
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    role1 = RoleDefinition.load({'name': 'role'}, owner=None)
    role2 = RoleDefinition.load({'name': 'role2', 'scm' : 'git'}, owner=None)
    role3 = RoleDefinition.load({'name': 'role3', 'scm' : 'hg'}, owner=None)
    role4 = RoleDefinition.load({'name': 'role4', 'scm' : 'svn'}, owner=None)

    # test loading of simple role definition
    assert RoleMetadata.load({'dependencies': role1}, owner=None).dependencies == [role1]

    # test loading of role definition with scm

# Generated at 2022-06-23 06:57:45.856804
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    host_vars = {
        'hostvars_loaded': True
    }
    inventory = host_vars

    mock_loader = Mock(**{
        'get_basedir.return_value': 'the/basedir'
    })

    mock_variable_mgr = Mock(**{
        'vars_loader.return_value': mock_loader,
        '_fact_cache': host_vars,
        'set_inventory.return_value': None,
        'get_vars.return_value': inventory
    })

    mock_requirement_1 = Mock(**{
        'serialize.return_value': 'role_requirement_1_serialized'
    })


# Generated at 2022-06-23 06:57:48.059293
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create instance of RoleMetadata
    RoleMetadata_instance = RoleMetadata()

    # serialize return a dict
    assert isinstance(RoleMetadata_instance.serialize(), dict)

# Generated at 2022-06-23 06:57:55.999714
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_name = 'my_role'
    variable_manager = None
    loader = None
    ds = {'allow_duplicates': False, 'dependencies': []}
    role = RoleMetadata.load(data=ds, owner=role_name, variable_manager=variable_manager, loader=loader)
    assert role._owner == 'my_role'
    assert role.allow_duplicates == False
    assert role.dependencies == []

# Generated at 2022-06-23 06:57:59.428412
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-23 06:58:06.144577
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    md = RoleMetadata()
    md.deserialize({'allow_duplicates': True})
    assert md.allow_duplicates == True
    md.deserialize({'dependencies': ['foo']})
    assert md.dependencies == ['foo']
    md.deserialize({'allow_duplicates': False, 'dependencies': ['foo']})
    assert md.allow_duplicates == False
    assert md.dependencies == ['foo']



# Generated at 2022-06-23 06:58:10.117085
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # test that deserialize ignores unknown attributes
    # test that deserialized metadata is equivalent to original

    role_metadata = RoleMetadata(owner=None)

    data = dict(allow_duplicates=True, extra_var=False, dependencies=['role1'])

    role_metadata.deserialize(data)

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1']



# Generated at 2022-06-23 06:58:13.938850
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    obj = RoleMetadata()
    assert obj.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-23 06:58:23.696592
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
        Test RoleMetadata.serialize()
    """
    import ansible.playbook.role_include as role_include
    from ansible.playbook.role.definition import RoleDefinition

    # Create a RoleRequirement object
    owner = None
    role_name = "role_name"
    role_path = "/home/test/test1/roles/role_name"
    vars = base.AnsibleVars()
    task_vars = base.AnsibleVars()
    metadata = None
    definition = RoleDefinition(role_name, vars, task_vars, metadata, owner)

    # Create a RoleInclude object
    role_include_obj = role_include.RoleInclude(definition=definition)

    # Create a RoleMetadata object
    role_metadata = RoleMetadata(owner)


# Generated at 2022-06-23 06:58:35.272457
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    class MockOwner:
        def get_name(self):
            return 'fake-owner'

        def __init__(self, role_path, play, variable_manager, loader, collections):
            self._role_path = role_path
            self._play = play
            self._variable_manager = variable_manager
            self._loader = loader
            self.collections = collections

    data = {"dependencies": [
        {"name": "role1",
         "src": "galaxy.role1",
         "version": "1.0"},
        {"name": "role2",
         "src": "galaxy.role2",
         "version": "2.0"},
        {"name": "role3",
         "src": "galaxy.role3"},
        "role4"]}


# Generated at 2022-06-23 06:58:37.011697
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-23 06:58:41.670860
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata(owner=None)
    assert metadata.deserialize({}) is None
    assert metadata.serialize() == {'dependencies': [], 'allow_duplicates': False}
    assert metadata.allow_duplicates == False
    assert metadata.dependencies == []

# Generated at 2022-06-23 06:58:53.580254
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import ast
    import json

    roles = [
        {
            'role': 'postfix',
            'tags': 'postfix_install'
        },
        {
            'role': 'linux',
            'ansible_facts': {
                'distribution': 'debian'
            }
        }
    ]
    roleMetadata_object = RoleMetadata.load(
        data=roles,
        variable_manager=None,
        loader=None,
        owner=None
    )
    expected_result = {
        'allow_duplicates': False,
        'dependencies': roles
    }
    serialized_data = roleMetadata_object.serialize()
    serialized_data['dependencies'] = ast.literal_eval(json.dumps(serialized_data['dependencies']))
    assert serial

# Generated at 2022-06-23 06:58:54.198583
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-23 06:59:04.848509
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    my_task = Task()
    my_task._role = RoleDefinition()
    my_task._role.name = "myrole"
    my_task._role.collections = ["col1.testns.mytestcoll", "col2.testns.mytestcoll"]
    my_task._role._role_path = "/tmp/myrole"

    variable_

# Generated at 2022-06-23 06:59:12.451328
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role

    role = Role()
    role_metadata = RoleMetadata(owner=role)
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ["roles/common"]

    test_data = {"allow_duplicates": True, "dependencies": ["roles/common"]}
    assert test_data == role_metadata.serialize()

# Generated at 2022-06-23 06:59:21.527121
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    from units.mock.vault_prompt import mock_vault_prompt

    mock_vault_prompt(rekey=False, recover=False)

    role_definition = RoleDefinition.load(dict(
        name='some-role',
        play_context=PlayContext()
    ))

    variable_manager = VariableManager()

# Generated at 2022-06-23 06:59:32.200877
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()

    # path is dummy.

# Generated at 2022-06-23 06:59:42.557263
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import pytest
    a = RoleMetadata()
    assert a.serialize() == {'allow_duplicates': False, 'dependencies': []}
    a.allow_duplicates = True
    assert a.serialize() == {'allow_duplicates': True, 'dependencies': []}
    a.dependencies = [1, 2, 3]
    assert a.serialize() == {'allow_duplicates': True, 'dependencies': [1, 2, 3]}
    with pytest.raises(AssertionError) as excinfo:
        a.serialize('hello')
    assert str(excinfo.value) == 'arg for serialize must be role metadata object'

# Generated at 2022-06-23 06:59:47.270015
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.deserialize(dict(
        allow_duplicates=True,
        dependencies=['common', 'webserver']))
    data = m.serialize()
    assert data['allow_duplicates'] == True
    assert data['dependencies'] == ['common', 'webserver']

# Generated at 2022-06-23 06:59:54.628481
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['foo', 'bar']
    result = role_metadata.serialize()
    expected_result = dict()
    expected_result['allow_duplicates'] = True
    expected_result['dependencies'] = ['foo', 'bar']
    assert result == expected_result


# Generated at 2022-06-23 06:59:59.285221
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {
        'allow_duplicates': 'true',
        'dependencies': 'dependency definitions'
    }
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == 'dependency definitions'


# Generated at 2022-06-23 07:00:10.814542
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import ROLE_CACHE

    current_dir = os.path.dirname(__file__)
    role_dir = os.path.join(current_dir, '..', '..', 'test', 'playbooks', 'roles', 'test_role')

    # Initialize role_meta as a dictionary
    role_meta = RoleMetadata.load(dict(), RoleRequirement.load(role_dir))

    # Assert that role_meta is a RoleMetadata object
    assert isinstance(role_meta, RoleMetadata)
    # Assert that role_meta object has the attributes allow_duplicates and dependencies
    assert hasattr(role_meta, 'allow_duplicates')
    assert hasattr(role_meta, 'dependencies')

    # Assert that role_meta.allow_du

# Generated at 2022-06-23 07:00:14.068587
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rolemetadata = RoleMetadata()
    rolemetadata.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert rolemetadata.allow_duplicates



# Generated at 2022-06-23 07:00:20.271452
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    variable_manager = None
    loader = None
    data = {
             "dependencies": [{"role": "Common"}],
             "allow_duplicates": False
           }

    m = RoleMetadata.load(data, variable_manager, loader)
    assert m.serialize() == {"dependencies": [{"role": "Common"}], "allow_duplicates": False}


# Generated at 2022-06-23 07:00:28.789381
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Assumption:
    #   - filename for the role is "role_name",
    #   - the content of the file is,
    #
    #   --- 
    #   - hosts: all
    #     roles:
    #       - role: role_name
    #         allow_duplicates: y
    #         dependencies:
    #           - dependency1
    #           - dependency2
    #
    #   - hosts: localhost
    #
    #   - hosts: roles_without_role_definition
    #     roles:
    #         - dependency1
    #         - dependency2
    #

    # Set up a Dummy class
    class Dummy(object):

        def __init__(self, allow_duplicates, dependencies, role_path):
            self._allow_duplicates = allow_du

# Generated at 2022-06-23 07:00:30.316334
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    mock_data = "data"
    role = RoleMetadata()
    role.deserialize(mock_data)

# Generated at 2022-06-23 07:00:33.736823
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # All the attributes are initialized to empty(for example, dependencies=[] ).
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        "allow_duplicates": False,
        "dependencies": ["role1"]
    })
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == ["role1"]


# Generated at 2022-06-23 07:00:40.039146
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test Case 1
    print("Test Case 1: Test if the load method raise error when the type of meta datastructure isn't a dictionary")
    try:
        RoleMetadata.load('1', None)
        assert False
    except AnsibleParserError:
        pass

# Make the module executable.

if __name__ == "__main__":
    test_RoleMetadata_load()

# Generated at 2022-06-23 07:00:41.509047
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert isinstance(r, RoleMetadata)

# Generated at 2022-06-23 07:00:55.742973
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #from ansible.playbook.role import Role
    #r = Role()
    #r._role_path = 'test/role'
    #ds = {"allow_duplicates": False, "dependencies": []}
    #m = RoleMetadata.load(ds, r)
    #assert m._role_path == 'test/role'
    #assert m.allow_duplicates == False
    #assert m.dependencies == []
    pass


# Generated at 2022-06-23 07:01:00.076996
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': []}

    m = RoleMetadata(owner=None)
    m.deserialize(data)

    assert m.allow_duplicates == False
    assert m.dependencies == []

# Generated at 2022-06-23 07:01:03.976978
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role._allow_duplicates == False
    assert role._dependencies == list()
    assert role._galaxy_info is None
    assert role._argument_specs == dict()

# Generated at 2022-06-23 07:01:07.118335
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 07:01:12.786706
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """ Return a dictionary for serialize()"""

    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']
    assert role_metadata.serialize() == dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )


# Generated at 2022-06-23 07:01:17.211460
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    metadata = RoleMetadata()
    metadata.allow_duplicates = 'True'
    metadata.dependencies = ['test']

    assert 'allow_duplicates' in metadata.serialize()
    assert 'dependencies' in metadata.serialize()

    assert metadata.serialize()['allow_duplicates'] == 'True'
    assert metadata.serialize()['dependencies'] == ['test']


# Generated at 2022-06-23 07:01:28.405337
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()

    data = {'allow_duplicates': True, 'dependencies': ['foo']}
    rmd.deserialize(data)

    # Check if allow_duplicates and dependencies variables were correctly deserialized
    assert rmd.allow_duplicates == True
    assert rmd.dependencies == ['foo']

    # Check if allow_duplicates dependency has been correctly deserialized when not present
    data = {'dependencies': ['foo']}
    rmd.deserialize(data)
    assert rmd.allow_duplicates == False

    # Check if dependencies dependency has been correctly deserialized when not present
    data = {'allow_duplicates': True}
    rmd.deserialize(data)
    assert rmd.dependencies == []

    # Check if allow_

# Generated at 2022-06-23 07:01:35.069161
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    obj = RoleMetadata()
    assert obj._allow_duplicates == False
    assert obj._dependencies == []
    assert obj._dependent_roles is None
    assert obj._owner is None
    assert obj._galaxy_info == None
    assert obj._argument_specs == {}
    assert obj._option_specs == {}


# Unit test to test static method load of class RoleMetadata

# Generated at 2022-06-23 07:01:45.488316
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude

    data = {
        "dependencies": [
            {'role': 'my.other.role'},
            {'role': 'my.strange.name.role'}
        ],
        "allow_duplicates": True,
        'galaxy_info': {'author': 'Somebody', 'description': 'Some random role'}
    }

    meta = RoleMetadata.load(data, RoleDefinition())
    assert meta._allow_duplicates == True
    assert len(meta._dependencies) == 2
    assert isinstance(meta._dependencies[0], RoleRequirement)

# Generated at 2022-06-23 07:01:51.045778
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['a', 'b']
    )
    r.deserialize(data)
    assert r.serialize() == data

# Generated at 2022-06-23 07:01:56.138320
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    owner = object()

    # Test load_data of RoleMetadata
    dummy_galaxy_info = object()
    m = RoleMetadata(owner).load_data(dict(galaxy_info=dummy_galaxy_info), variable_manager=None, loader=None)
    assert m._owner == owner
    assert isinstance(m._galaxy_info, object)
    assert m._argument_specs == dict()

    # Test load of RoleMetadata
    m = RoleMetadata.load(dict(galaxy_info=dummy_galaxy_info), owner=owner, variable_manager=None, loader=None)
    assert isinstance(m, RoleMetadata)
    assert m._galaxy_info == dummy_galaxy_info
    assert m._argument_specs == dict()
    assert m._owner == owner

   

# Generated at 2022-06-23 07:02:01.199576
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
  role_meta = RoleMetadata()
  role_meta._allow_duplicates = True
  role_meta._dependencies = ['foo', 'bar']
  assert role_meta.serialize() == {'allow_duplicates': True, 'dependencies': ['foo', 'bar']}

# Generated at 2022-06-23 07:02:02.729448
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert str(m) == "<RoleMetadata::>", "RoleMetadata object creation failed"
    m = RoleMetadata(owner=None)
    assert str(m) == "<RoleMetadata::>", "RoleMetadata object creation failed"

# Generated at 2022-06-23 07:02:11.485315
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    ds1 = dict(
        allow_duplicates='True',
        dependencies=['foo', 'bar', dict(role='baz', other_vars="here")],
    )
    role_path = 'foo/roles/bar'
    role = Role.load(role_path)
    variable_manager = VariableManager()
    inventory = InventoryManager([])
    loader = DataLoader()
    # TODO: get rid of inventory

# Generated at 2022-06-23 07:02:15.806754
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=["toto"]
    )
    metadata.deserialize(data)
    if metadata.allow_duplicates != True or metadata.dependencies != ["toto"]:
        raise AssertionError()

# Generated at 2022-06-23 07:02:20.163374
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_class = RoleMetadata()
    assert test_class._allow_duplicates == False
    assert test_class._dependencies == []
    assert test_class._galaxy_info == None
    assert test_class._argument_specs == {}

# Generated at 2022-06-23 07:02:23.697662
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = dict()
    r.deserialize(data)
    assert r._allow_duplicates is False


# Generated at 2022-06-23 07:02:30.603819
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    setattr(m, 'allow_duplicates', True)
    setattr(m, 'dependencies', [{'role': 'jdauphant.nginx'}, {'role': 'geerlingguy.nodejs'}])
    assert_equal(m.serialize(), {'allow_duplicates': True, 'dependencies': [{'role': 'jdauphant.nginx'}, {'role': 'geerlingguy.nodejs'}]})


# Generated at 2022-06-23 07:02:39.146790
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[{u'name': u'bacongobbler.haproxy'}, {u'name': u'geerlingguy.nginx'}, {u'name': u'bacongobbler.nfs_client'}]
    )
    m = RoleMetadata().deserialize(data)
    assert m.allow_duplicates == False
    assert m.dependencies == [{u'name': u'bacongobbler.haproxy'}, {u'name': u'geerlingguy.nginx'},{u'name': u'bacongobbler.nfs_client'}]

# Generated at 2022-06-23 07:02:42.176540
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm = RoleMetadata(None)
    assert type(rm.serialize()) is dict


# Generated at 2022-06-23 07:02:45.558261
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = { "allow_duplicates":True, "dependencies":[] }
    assert RoleMetadata().deserialize(data) == None


# Generated at 2022-06-23 07:02:47.529519
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r != None



# Generated at 2022-06-23 07:02:48.033752
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert True

# Generated at 2022-06-23 07:02:55.490340
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'dependencies': [
        {
            'role': 'geerlingguy.java',
            'meta': 'role_dependencies/java.yaml'
        }, {
            'role': 'geerlingguy.jenkins',
            'meta': 'role_dependencies/jenkins.yaml'
        }
    ]})
    assert len(role_metadata.dependencies) == 2
    assert role_metadata.dependencies[0].role == 'geerlingguy.java'
    assert role_metadata.dependencies[1].role == 'geerlingguy.jenkins'

# Generated at 2022-06-23 07:02:59.943808
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # setup a role_metadata object with some dependencies
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ["some_role", "another_role"]

    # serialize
    serialized = role_metadata.serialize()

    # check result
    assert serialized["allow_duplicates"]
    assert "some_role" in serialized["dependencies"]



# Generated at 2022-06-23 07:03:13.561767
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.block import Block

# role_dep.load :
#     role_dep.role._role_collection = {'namespace': 'my_namespace', 'name': 'my_collection'}
#     role_dep.role._role_name = 'my_role'
    class my_role:
        _role_collection = {'namespace': 'my_namespace', 'name': 'my_collection'}
        _role_name = 'my_role'
# role_dep.dst = 'target_role'
    role_dep = RoleDependency('role_dep', RoleDefinition())
    role_dep

# Generated at 2022-06-23 07:03:21.694378
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    import json
    x = RoleMetadata(owner=Role().load({'name': 'test'}, play=None, variable_manager=None, loader=None)).load({
      'dependencies': [],
      'allow_duplicates': False
    }, play=None, variable_manager=None, loader=None)
    assert json.dumps({
        'allow_duplicates': False,
        'dependencies': []
    }) == json.dumps(x.serialize())

# Generated at 2022-06-23 07:03:26.333678
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    role_metadata = RoleMetadata(owner=RoleDefinition.load('ansible-test', False, None, None))
    setattr(role_metadata, 'dependencies', [])
    role_metadata.deserialize({'dependencies': [], 'allow_duplicates': False})
    assert isinstance(role_metadata.dependencies, list)
    assert role_metadata.dependencies == []

# Generated at 2022-06-23 07:03:33.437062
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    arg_data = {}
    arg_data['metadata'] = {'dependencies': [
        {'role': 'common'},
        {'name': 'foo', 'src': 'https://github.com/foo.git', 'version': 'v1.0'}]}

    m = RoleMetadata()
    m.load(arg_data, owner=None)
    assert m._dependencies[0].get_name() == 'common'
    assert m._dependencies[1].get_name() == 'foo'
    assert m._dependencies[1].src == 'https://github.com/foo.git'
    assert m._dependencies[1].version == 'v1.0'


# Generated at 2022-06-23 07:03:34.969216
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert {'allow_duplicates': False, 'dependencies': []} == r.serialize()

# Generated at 2022-06-23 07:03:47.395986
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition

    # Data structure representing meta/main.yml
    data = {'allow_duplicates': False, 'dependencies': []}

    # Initialize a new RoleMetadata obj
    metadata = RoleMetadata.load(data, RoleDefinition(play_context=PlayContext()))

    assert (metadata._allow_duplicates == False), "Allow duplicates should be false."
    assert (metadata._dependencies == []), "Dependencies list should be empty."
    assert (metadata._galaxy_info == None), "Galaxy info should be None."
    assert (metadata._argument_specs == {}), "Argument specs should be {}."


# Generated at 2022-06-23 07:03:52.097849
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert r.allow_duplicates == False
    assert r.dependencies == []



# Generated at 2022-06-23 07:04:04.219916
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    collection_loader = MockCollectionLoader()
    variable_manager = MockVariableManager()
    loader = MockLoader({'meta/main.yml': '''---
    dependencies:
      - role: test
    '''})
    play = Play().load(dict(
        name="A Test Play",
        hosts=['localhost'],
        roles=[dict(name='test')]
    ), variable_manager=variable_manager, loader=loader)
    role = play.get_role_by_name('test')
    role.metadata = RoleMetadata.load(loader.get_basedir(role._role_path) + '/meta/main.yml', owner=role, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 07:04:09.286895
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadatas = [RoleMetadata()]
    for role_metadata in role_metadatas:
        role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role_name']})
        assert role_metadata.allow_duplicates == True
        assert role_metadata.dependencies == ['role_name']

# Generated at 2022-06-23 07:04:12.418372
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert not r._allow_duplicates
    assert not r._dependencies

# Generated at 2022-06-23 07:04:17.015812
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata.deserialize(None) == dict(allow_duplicates=False, dependencies=[])
    assert RoleMetadata.deserialize(dict(allow_duplicates=True, dependencies=['one', 'two'])) == dict(allow_duplicates=True, dependencies=['one', 'two'])

# Generated at 2022-06-23 07:04:30.142420
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.role import Role

    # Constants
    test_dependencies = {
        'test1': {
            'role': 'this-is-test1',
            'name': 'test1'
        },
        'test2': {
            'role': 'this-is-test2',
            'name': 'test1'
        }
    }

    # Create a test role
    test_role = Role()
    # Create a new instance of RoleMetadata class
    test_role_metadata = RoleMetadata()

    # Add dependencies to test_role_metadata object
    test_role_metadata._dependencies = test_dependencies

    # Test serialization
    assert test_role_metadata.serialize() == {
        'dependencies': test_dependencies
    }

# Generated at 2022-06-23 07:04:38.589952
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    test_data = dict(
        galaxy_info="This is galaxy information".split(),
        dependencies=[
            dict(
                name="A Name",
                src="SRC",
                scm="SCM",
                path="path",
                version="version"
            )
        ]
    )
    role_meta = RoleMetadata(owner=RoleDefinition(name="test"))
    role_meta.load(test_data, variable_manager=None, loader=None)

# Generated at 2022-06-23 07:04:45.415825
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role.definition
    import ansible.playbook.role.reqs

    # todo: this test should run RoleRequirement tests first
    #       to ensure that the use of RoleDefinition here is valid

    rd = ansible.playbook.role.definition.RoleDefinition.load(dict(name='test'))
    rm = RoleMetadata(owner=rd)
    rm._load_dependencies('dependencies', dict(dep1='one'))

# Generated at 2022-06-23 07:04:57.371920
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """Check load method of RoleMetadata works as expected.
    """
    # load_list_of_roles *must* be mocked to make param _deps_from_collection=False
    # to avoid raise exception
    import mock
    test_data = dict(
        dependencies=[mock.Mock(name='role1', spec=dict),
                      mock.Mock(name='role2', spec=dict)],
    )

    metadata = dict(
       galaxy_info=test_data
    )

    owner = mock.Mock(name='owner', spec=['get_name'])
    owner.get_name.return_value = 'test_role_name'

    variable_manager = mock.Mock(name='variable_manager', spec=[])
    loader = mock.Mock(name='loader', spec=[])

    #

# Generated at 2022-06-23 07:05:05.349848
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    # load() should return a RoleMetadata instance
    play_context = PlayContext()
    role = Role.load("galaxy.test.bar", "bar", 'test/roles/bar', play_context)
    role_meta = RoleMetadata.load({"foo": "bar"}, role)
    assert isinstance(role_meta, RoleMetadata)

# Generated at 2022-06-23 07:05:13.286615
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

    role = Role.load(dict(name='test'))
    test_meta = RoleMetadata.load(dict(dependencies=['foo', 'bar']), role)
    assert isinstance(test_meta.dependencies[0], RoleInclude)
    assert test_meta.dependencies[0].role == 'foo'
    test_meta = RoleMetadata.load(dict(dependencies=[dict(name='foo')]), role)
    assert isinstance(test_meta.dependencies[0], RoleInclude)
    assert test_meta.dependencies[0].role == 'foo'

# Generated at 2022-06-23 07:05:23.691539
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    role = Role()
    role._role_path = "/home/foo/"
    role._role_collection = "ansible.posix"
    data = {
        "allow_duplicates": True,
        "dependencies": [
            {
                "name": "bar",
                "version": "1.0.0",
                "src": "/home/bar/"
            }
        ]
    }

    loaded_data = RoleMetadata.load(data, role)
    assert loaded_data._allow_duplicates is True
    assert loaded_data._owner is role
    assert len(loaded_data._dependencies) == 1

# Generated at 2022-06-23 07:05:28.037103
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {'allow_duplicates': 'i', 'dependencies': 'd'}
    m.deserialize(data)
    assert m.allow_duplicates == 'i'
    assert m.dependencies == 'd'