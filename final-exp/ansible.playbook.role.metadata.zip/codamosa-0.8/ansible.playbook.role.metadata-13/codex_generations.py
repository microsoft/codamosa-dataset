

# Generated at 2022-06-11 10:39:23.760025
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    class RoleOne(RoleDefinition):
        pass

    class RoleTwo(RoleDefinition):
        pass

    hosts = ['localhost']

# Generated at 2022-06-11 10:39:31.179130
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class Role:
        def __init__(self):
            self._role_path = "role_path"
            self.collections = []
            self._play = None
            self._role_collection = None
    m = RoleMetadata(owner=Role())
    assert dict(allow_duplicates=False, dependencies=[]) == m.serialize()
    m.allow_duplicates = True
    m.dependencies = ["Dependency"]
    assert dict(allow_duplicates=True, dependencies=["Dependency"]) == m.serialize()

# Generated at 2022-06-11 10:39:36.225938
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # set up variables to test the method
    value = 'ok'
    data = {'dependencies': []}
    owner = 'ok'
    variable_manager = 'ok'
    loader = 'ok'
    m = RoleMetadata.load(data=data,owner=owner,variable_manager=variable_manager,loader=loader)
    assert m.serialize()['allow_duplicates'] == False
    assert m.serialize()['dependencies'] == []

# Generated at 2022-06-11 10:39:41.304738
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {
        'metadata': {
            'dependencies': ['role1', 'role2']
        }
    }

    m = RoleMetadata.load(data, owner='name')
    assert m._dependencies == ['role1', 'role2']

    m2 = RoleMetadata.load(data, owner='name')
    assert m2._dependencies == ['role1', 'role2']

# Generated at 2022-06-11 10:39:45.172574
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta._allow_duplicates = True
    meta._dependencies = []

    assert meta.serialize() == {'allow_duplicates': True, 'dependencies': []}

# Generated at 2022-06-11 10:39:55.090413
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    attrs_list = ['allow_duplicates', 'dependencies']
    for attr in attrs_list:
        assert getattr(role_metadata, attr, None) is None
    data = dict(
            allow_duplicates=True,
            dependencies=['role1', 'role2'])
    role_metadata.deserialize(data)
    for attr in attrs_list:
        assert getattr(role_metadata, attr, None) is not None
    assert role_metadata.allow_duplicates == data.get('allow_duplicates')
    assert role_metadata.dependencies == data.get('dependencies')



# Generated at 2022-06-11 10:39:56.120021
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata() is not None

# Generated at 2022-06-11 10:40:00.366346
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r1 = RoleMetadata()
    r2 = RoleMetadata(owner=r1)
    r2.load(data={'meta/main.yml':{'dependencies': ['role1','role2','role3','role4','role5','role6','role7'], 'allow_duplicates':False }}, owner=r2)

# Generated at 2022-06-11 10:40:03.215251
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role.allow_duplicates == False

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-11 10:40:05.680126
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test constructor
    role = role = RoleMetadata()
    assert role._allow_duplicates is False
    assert role._dependencies == []
    assert role._galaxy_info == None

# Generated at 2022-06-11 10:40:17.285834
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize(dict(allow_duplicates=False, dependencies=[]))
    assert(m.allow_duplicates == False)
    assert(m.dependencies == [])


# Generated at 2022-06-11 10:40:18.036797
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    print("testing serialize")
    assert True

# Generated at 2022-06-11 10:40:25.954725
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[
            dict(role='test_RoleMetadata_deserialize1'),
            dict(role='test_RoleMetadata_deserialize2')
        ]
    )
    m = RoleMetadata()
    m.deserialize(data)
    assert m.allow_duplicates == False
    assert m.dependencies[0].role == 'test_RoleMetadata_deserialize1'
    assert m.dependencies[1].role == 'test_RoleMetadata_deserialize2'


# Generated at 2022-06-11 10:40:35.934561
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.plays import Play
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    class FakeRole():
        def __init__(self):
            self.name = 'fake_role'

    fake_role = FakeRole()
    fake_role._roles = []
    fake_role._metadata = None
    fake_role._role_path = './tests/fixtures/fake_role'

    fake_role._metadata = RoleMetadata(owner=fake_role)


# Generated at 2022-06-11 10:40:37.291337
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert 0, "test_RoleMetadata_serialize needs to be implemented"

# Generated at 2022-06-11 10:40:38.162337
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert(RoleMetadata() is not None)

# Generated at 2022-06-11 10:40:44.834241
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata(owner={
        '_role_path': '../../roles/apache',
        '_role_name': 'apache',
        '_role_collection': 'ansible.legacy',
        '_play': { 'name': 'apache_play' },
        'collections': ['ansible.builtin']
    })

    assert(role_metadata._allow_duplicates == False)
    assert(role_metadata._dependencies == [])
    assert(role_metadata._galaxy_info == None)
    assert(role_metadata._argument_specs == {})


# Generated at 2022-06-11 10:40:47.441168
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {'allow_duplicates': True}
    collector = RoleMetadata()
    collector.load(data)
    assert collector.allow_duplicates



# Generated at 2022-06-11 10:40:50.783569
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''
    # TODO: Add test cases for the load() method
    pass


# Generated at 2022-06-11 10:40:59.824770
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['1', '2']

    assert role_metadata.serialize() == {
        'allow_duplicates': True,
        'dependencies': ['1', '2']
    }

    role_metadata._allow_duplicates = False
    role_metadata._dependencies = ['3', '4']

    assert role_metadata.serialize() == {
        'allow_duplicates': False,
        'dependencies': ['3', '4']
    }



# Generated at 2022-06-11 10:41:17.503443
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {
        'allow_duplicates': 'yes',
        'dependencies': [
            'role1',
            {'role': 'role2'},
            {'role': 'role3', 'vars_file': 'file1', 'other_vars': {'key1': 'value1'}},
            {'name': 'role4', 'src': 'bitbucket.org/user/repo', 'scm': 'hg', 'version': '1.2.3', 'private_key': 'key1'},
            {'src': 'github.com/user/repo'},
            {'src': 'gitlab.com/user/repo', 'vars': {'key2': 'value2'}}
        ]}

# Generated at 2022-06-11 10:41:27.061908
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    class MyRole(RoleDefinition):
        pass

    class MyBlock(Block):
        pass

    class MyTask(Task):
        pass

    class MyPlayContext(PlayContext):
        def __init__(self, *args, **kwargs):
            pass

    class MyRoleMetadata(RoleMetadata):
        pass

    r = MyRole()
    b = MyBlock()
    t = MyTask()
    pc = MyPlayContext()
    rm = MyRoleMetadata()

    b._parent = r
    t._parent = b
    t._role = r
    t._play_context = pc

# Generated at 2022-06-11 10:41:37.529927
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    # test for allow_duplicates
    # create an item of action plugin
    module_name = 'copy'
    module_args = {}
    module_kwargs = dict(
        src='/etc/hosts',
        dest='/tmp/hosts',
    )
    module = action_loader.get(module_name, class_only=True)
    task_action = module(
        module_name,
        module_args,
        module_kwargs,
    )
    task_name = 'install_redis'
    task_loop = None
    task_ignore_errors = None
    task

# Generated at 2022-06-11 10:41:41.407228
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    test_data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    # Create an instance of class RoleMetadata
    my_role_metadata = RoleMetadata()

    # deserialize data
    my_role_metadata.deserialize(test_data)

    assert my_role_metadata.allow_duplicates == False
    assert my_role_metadata.dependencies == []

# Generated at 2022-06-11 10:41:52.535845
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role

    role_name = 'test_role'
    role_path = '/home/ansible/test_role'
    role_metadata_file = os.path.join(role_path, 'meta', 'main.yml')

    r = Role()
    r.name = role_name
    r._role_path = role_path

    assert not hasattr(r, 'metadata')
    assert not hasattr(r, 'allow_duplicates')
    assert not hasattr(r, 'dependencies')

    # First test, role metadata file not exist
    assert not os.path.exists(role_metadata_file)
    m = RoleMetadata.load({}, r)
    assert not m.allow_duplicates
    assert [] == m.dependencies
    m.deserial

# Generated at 2022-06-11 10:41:58.274466
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    roles_path = os.path.dirname(os.path.dirname(__file__)) + "/../../../test/units/ansible_collections/ansible/test/roles/"
    role = os.listdir(roles_path)[0]
    path = roles_path + role
    metadata = RoleMetadata.load({'dependencies': [{'role': 'other_role'}]}, path)
    assert(metadata.dependencies[0].role == 'other_role')

# Generated at 2022-06-11 10:42:02.324728
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    metadata._allow_duplicates = True
    metadata._dependencies = ['role1', 'role2']

    data = metadata.serialize()
    assert data['allow_duplicates'] == True
    assert data['dependencies'] == metadata._dependencies
# Done unit test for method serialize of class RoleMetadata


# Generated at 2022-06-11 10:42:06.702804
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata.load(data='{"somekey": "somevalue"}', owner=None)
    assert role_metadata._owner is None
    assert role_metadata.data == {'somekey': 'somevalue'}

# Generated at 2022-06-11 10:42:08.071254
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata().deserialize({}).dependencies == []

# Generated at 2022-06-11 10:42:12.709667
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': [{'meta': 'main'}]}
    m = RoleMetadata()
    m.deserialize(data)
    assert m._allow_duplicates == False
    assert m._dependencies == [{'meta': 'main'}]
test_RoleMetadata_deserialize()

# Generated at 2022-06-11 10:42:30.083703
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata('example')
    assert isinstance(m, RoleMetadata)

    assert m.allow_duplicates == False
    assert m.dependencies == []

    del m

# Generated at 2022-06-11 10:42:39.841376
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    role_def=dict(
        name='test.role',
        collection='test.collection',
        path='/tmp/test.role'
    )
    role_declaration=RoleDefinition.load(role_def)
    # test_RoleMetadata_load(self.role_declaration):
    data=dict(
        allow_duplicates=True,
        dependencies=dict(
            src='test.role',
            path='/tmp/test.role',
            name='test.role',
            version='1.0',
            scm='git',
            src_type='roles'
        )
    )

# Generated at 2022-06-11 10:42:42.940220
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    datadict = {'allow_duplicates': True,
                'dependencies': ['test1', 'test2']}
    m.deserialize(datadict)
    assert m.serialize() == datadict

# Generated at 2022-06-11 10:42:48.852502
# Unit test for method serialize of class RoleMetadata

# Generated at 2022-06-11 10:42:53.500770
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # testdata
    # default values
    test_name = "default"
    test_data = {}
    test_owner = "owner"

    # custom values

    # execution
    metadata = RoleMetadata.load(test_data, test_name, test_owner)

    # assert
    assert metadata is not None
    assert metadata.dependencies is None
    assert metadata.allow_duplicates is None

    # transformation
    test_data = {
        "dependencies": {
            "role": "name"
        },
        "allow_duplicates": True
    }

    # execution
    metadata = RoleMetadata.load(test_data, test_name, test_owner)

    # assert
    assert metadata is not None
    assert metadata.dependencies is not None
    assert metadata.allow_duplicates is True



# Generated at 2022-06-11 10:43:04.200364
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class Owner:
        def __init__(self):
            self._role_path = ''
            self._play = ''
            self.collections = []
        def get_name(self):
            return ''
    owner = Owner()
    variable_manager = None
    loader = None
    data = {'allow_duplicates':True, 'dependencies':{'name':'apache','src':'apache','version':'1.0','role':'apache','galaxy_info':'','scm':'','scm_url':'','scm_type':'','scm_username':'','scm_password':'','scm_verify_certs':''}}
    result = RoleMetadata.load(data,owner,variable_manager,loader)
    print(result)


# Generated at 2022-06-11 10:43:05.539970
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-11 10:43:14.335752
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.helpers import load_list_of_roles

    role1 = RoleDefinition.load({'role': 'foo'}, play=None, variable_manager=None, loader=None)
    role2 = RoleDefinition.load({'role': 'bar'}, play=None, variable_manager=None, loader=None)
    role3 = RoleDefinition.load({'role': 'baz'}, play=None, variable_manager=None, loader=None)

    roles1 = load_list_of_roles(['foo'], play=None, current_role_path=None, variable_manager=None, loader=None)
    assert len(roles1) == 1
    assert roles1[0] == role1

    roles2 = load_list_

# Generated at 2022-06-11 10:43:23.652884
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.set_inventory(object)
    args = [dict(name='Configure Drupal', src='nginx'), ['Configure WordPress']]
    roles = [RoleMetadata(owner=RoleDefinition(role_name='drupal', role_path='/tmp/drupal')).load_dependencies('roles', args)]
    assert len(roles) == 2
    assert roles[0].get_role_name() == 'nginx'
    assert roles[1].get_role_name() == 'wordpress'

# Generated at 2022-06-11 10:43:29.490431
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play = Playbook.load(play_context=play_context, loader=None, variable_manager=None)._entries[0]
    role = play._entries[0]
    metadata = RoleMetadata.load(data={},owner=role,variable_manager=None)

    assert metadata.dependencies == []

# Generated at 2022-06-11 10:44:08.230241
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement

    mock_role = Role()
    mock_role.name = 'role_name'

    # test the load function with a dictionary
    mock_ds = {}
    role_metadata = RoleMetadata.load(mock_ds, mock_role)

    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    assert role_metadata.galaxy_info == {}

    # test the load function with a dictionary and dependencies as string
    mock_ds = {'dependencies': "dependency"}
    role_metadata = RoleMetadata.load(mock_ds, mock_role)

    assert role_metadata.allow_duplicates == False

# Generated at 2022-06-11 10:44:15.363905
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    assert meta._allow_duplicates == False, '_allow_duplicates must be False by default'
    assert meta._dependencies == [], '_dependencies must be [] by default'
    assert meta._galaxy_info == None, '_galaxy_info must be None by default'
    assert meta._argument_specs == {}, '_argument_specs must be {} by default'

# Generated at 2022-06-11 10:44:23.113998
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    content = """
---

allow_duplicates: True
dependencies:
- src: galaxy.role,version,name
  other_vars: "here"
- galaxy.role,version,name
    """
    from ansible import constants as C
    ds = yaml.load(content, yaml.SafeLoader)
    r = RoleMetadata(owner=None)
    r.allow_duplicates = ds.get('allow_duplicates')
    r.dependencies = ds.get('dependencies')

    data = r.serialize()
    assert data.get('allow_duplicates') == True
    assert len(data.get('dependencies')) == 2

# Generated at 2022-06-11 10:44:24.464507
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    RoleMetadata initialization test
    '''
    pass

# Generated at 2022-06-11 10:44:33.148341
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates=True
    role_metadata.dependencies=[
        {
            'role': 'test',
            'src': 'test.test'
        }
    ]
    expected_serialized_data = {
        'allow_duplicates': True,
        'dependencies': [
            {
                'role': 'test',
                'src': 'test.test'
            }
        ]
    }

    # Assert
    assert role_metadata.serialize() == expected_serialized_data, 'Expected serialized data of RoleMetadata is incorrect'


# Generated at 2022-06-11 10:44:40.510526
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.helpers import load_list_of_roles
    metadata = {
        'allow_duplicates': True,
        'dependencies': [{
            'src': 'git:master',
            'name': 'another_role',
            'version': '1.0'
        }]
    }
    roleMetadata = RoleMetadata.load(metadata, None, None, None)
    assert roleMetadata.allow_duplicates == True
    assert roleMetadata.dependencies[0].src == 'git:master'

# Unit testing for method serialize of class RoleMetadata

# Generated at 2022-06-11 10:44:45.396000
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    ds = dict(
            allow_duplicates=True,
            dependencies={'role_name': 'https://github.com/role_name.git'}
    )
    role_metadata.deserialize(ds)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == [{'role_name': 'https://github.com/role_name.git'}]

# Generated at 2022-06-11 10:44:47.153894
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition

    role_definition = RoleDefinition()

    role_metadata = RoleMetadata(owner=role_definition)

    assert role_metadata

# Generated at 2022-06-11 10:44:56.865800
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    host = 'local'
    play_context = dict(
        port=22
    )
    connection = 'local'
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = host,
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args='')),
        ]
    ), variable_manager=None, loader=None)

    role = Role()
    role._role_name = 'rolename'

# Generated at 2022-06-11 10:45:01.579642
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {
        "allow_duplicates": True,
        "dependencies":
            [
                'foo',
                'bar'
            ]
    }
    test = RoleMetadata()
    test.deserialize(data)
    assert test.allow_duplicates == True
    assert test.dependencies == ['foo', 'bar']

# Generated at 2022-06-11 10:45:57.692053
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    metadata.deserialize(data)
    assert metadata.allow_duplicates == False
    assert metadata.dependencies == []

# Generated at 2022-06-11 10:46:06.285689
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load(dict(
        name="Ansible Play",
        hosts=['all'],
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hi!')))
        ]
    ), variable_manager=variable_manager, loader=loader)

    # Setup test directory structure
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import chmod
    from os.path import join
    from stat import S_IEXEC

# Generated at 2022-06-11 10:46:09.359919
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=dict(
            role1 = "role1",
            role2 = "role2"
        )
    )

    role = RoleMetadata()
    role.deserialize(data)

    print(role)

    assert role.allow_duplicates == True
    assert data["dependencies"] == role.dependencies

# Generated at 2022-06-11 10:46:14.165639
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from .data import mock_role_meta_data
    rm = RoleMetadata.load(mock_role_meta_data(), 'test_role')
    assert isinstance(rm, RoleMetadata)
    assert isinstance(rm._dependencies[0], RoleInclude)
    assert rm.allow_duplicates is False
    assert rm._dependencies[0].name == 'foo'
    assert rm._dependencies[0].role_path == ['bar', 'tasks', 'main.yml']
    assert rm._dependencies[0]._role.name == 'foo'
    assert rm._dependencies[0]._role.get_path() == 'bar'
    assert rm._dependencies[1].name == 'baz'

# Generated at 2022-06-11 10:46:18.262722
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    owner = None
    data = {
        'allow_duplicates': True,
        'dependencies': ['CommonServer', 'DatabaseServer'],
    }
    m = RoleMetadata.load(data, owner)
    assert m.dependencies[0] == 'CommonServer'
    assert m.dependencies[1] == 'DatabaseServer'
    assert m.allow_duplicates == True

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-11 10:46:20.381554
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    This test is to test the constructor of the class RoleMetadata.
    '''
    role_metadata = RoleMetadata()
#    print(type(role_metadata))
    assert type(role_metadata) == RoleMetadata

# Generated at 2022-06-11 10:46:22.786381
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    expected_dict = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == expected_dict

# Generated at 2022-06-11 10:46:29.774936
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import ansible.constants as C

    role_path = os.path.abspath(os.path.dirname(__file__) + '/../../..') + '/test/unit/lib_roles/role_defaults'

# Generated at 2022-06-11 10:46:37.442160
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test1: Successful case
    def test1():
        test_roles = [
            {
                'role': 'role1',
                'version': 'version1',
                'name': 'name1',
                'scm': 'scm1',
                'src': 'src1',
                'path': 'path1',
                'spec': 'spec1'
            },
            {
                'role': 'role2',
                'version': 'version2',
                'name': 'name2',
                'scm': 'scm2',
                'src': 'src2',
                'path': 'path2',
                'spec': 'spec2'
            },
        ]
        test_data = {'dependencies': test_roles}
        test_obj = RoleMetadata(owner=None)
       

# Generated at 2022-06-11 10:46:44.188124
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # Parsing role role_with_bad_meta from /data/ansible-lint/tests/meta/roles/role_with_bad_meta/meta/main.yml
    # BAD: meta/main.yml:1:1: [ANSIBLE0006] INI file

# Generated at 2022-06-11 10:48:35.813152
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 10:48:40.176445
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = {
        'name': 'test',
        'description': 'this is a test',
        'dependencies': [{
            'role': 'common',
            'version': 'v1'
        }]
    }

    rm = RoleMetadata.load(metadata, 'test')

    assert rm._dependencies[0].get_name() == 'common'
    assert rm._dependencies[0].get_version() == 'v1'

# Generated at 2022-06-11 10:48:43.355280
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'dependencies': [{'role': 'common', 'repo': 'user_repo'}]}
    owner = {'_role_collection': None, '_role_path': './tests/lib/ansible_test/_data/roles/foo'}
    RoleMetadata.load(data, owner)
    assert 'tag' not in owner['dependencies'][0].metadata

# Generated at 2022-06-11 10:48:50.351858
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play

    p = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [
            'role1',
            'role2',
            'role3',
            'role4',
        ]
    ), variable_manager=None, loader=None)

    got_r1 = ''
    got_r2 = ''
    got_r3 = ''
    got_r4 = ''
    for role in p.get_roles():
        if role.name == "role1":
            got_r1 = role._role_path
        elif role.name == "role2":
            got_r2 = role._role_path
        elif role.name == "role3":
            got_r3

# Generated at 2022-06-11 10:48:51.801198
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    assert m.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:48:55.713969
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    temp = RoleMetadata()
    temp.deserialize({'allow_duplicates': True, 'dependencies': ['Ansible.Apache', 'name']})
    assert temp._allow_duplicates == True
    assert temp._dependencies == ['Ansible.Apache', 'name']


# Generated at 2022-06-11 10:49:02.456936
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    cache = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=cache)
    loader = AnsibleCollectionLoader()

    role_def1 = dict(role='geerlingguy.ntp', src='geerlingguy.ntp,2.0.0')
    role_def2 = dict(role='geerlingguy.ntp', src='geerlingguy.ntp,2.1.0')
