

# Generated at 2022-06-11 10:39:19.109009
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    RoleMetadata(owner=None)

    # test with normal data
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []
    result = RoleMetadata.load(data, owner=None, variable_manager=None, loader=None)
    assert result._allow_duplicates == False
    assert result._dependencies == []

    # test with normal data and 'role' keyword
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = [{"role": "name"}]
    result = RoleMetadata.load(data, owner=None, variable_manager=None, loader=None)
    assert result._allow_duplicates == False
    assert result._dependencies == [{"role": "name"}]

    # test with normal data and '

# Generated at 2022-06-11 10:39:29.567917
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # pylint: disable=unused-variable
    # pylint: disable=no-member
    # pylint: disable=unused-argument
    def test_owner(self):
        return self._owner
    def test_collections(self):
        base_path = '/etc/ansible/collections/ansible_collections/test_collection'
        return [base_path]
    def test_variable_manager(self):
        return None
    def test_loader(self):
        return None
    def test_role_path(self):
        return None
    def test_role_collection(self):
        return None
    def test_play(self):
        return None
    ds = {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:39:33.552217
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata().deserialize({'allow_duplicates': True, 'dependencies':[{'name': 'name', 'src': 'src'}]}) == {'allow_duplicates': True, 'dependencies':[{'name': 'name', 'src': 'src'}]}

# Generated at 2022-06-11 10:39:41.776155
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    role = RoleDefinition.load(dict(
        name='foo',
        dependencies=[],
        defaults=dict(),
        tasks=dict(),
        vars=dict(),
        handlers=dict(),
        files=dict(),
        templates=dict(),
        meta=dict(),
        galaxy_info=dict(),
        library=dict(),
        filter_plugins=dict(),
        module_utils=dict(),
        lookup_plugins=dict(),
        roles=dict(),
    ), role_path='/dev/null')

    role.post_validate()

    assert role._metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[],
    )

# Generated at 2022-06-11 10:39:50.063600
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.definition import _load_list_of_roles
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager

    # Test with name and src
    # Test with collection_name.name
    # Test with collection_name.namespace.name
    # Test with collection_name.namespace.name.version
    pass

# Generated at 2022-06-11 10:40:00.368589
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    import os
    import unittest

    # create and get the path for a test role with a meta/main.yml file
    role_def = RoleDefinition.load({'name': 'test_role'}, owner=None)
    role_path = role_def.get_path()
    os.mkdir(os.path.join(role_path, 'meta'))
    with open(os.path.join(role_path, 'meta', 'main.yml'), 'w') as f:
        f.write('dependencies:\n')
        f.write('- role: foo\n')
        f.write('  when: bar\n')
        f.write('- role: baz\n')

# Generated at 2022-06-11 10:40:02.457336
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    assert isinstance(meta.deserialize(data={}), dict)

# Generated at 2022-06-11 10:40:06.041308
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Load a valid RoleMetadata
    owner = 'galaxy.role,version,name'
    ds = {
        "dependencies": [
            "galaxy.role,version,name"
        ]
    }
    RoleMetadata.load(ds, owner)

# Generated at 2022-06-11 10:40:11.449126
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    role_definition = RoleDefinition()
    role_definition._role_path = '/home/roles/test'
    role_metadata = RoleMetadata(owner=role_definition)
    role_metadata.deserialize({})
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-11 10:40:12.430891
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

# Generated at 2022-06-11 10:40:29.221560
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_source = dict(
        name = "Ansible Play 1",
        hosts = 'webservers',
        gather_facts = 'no',
        roles = [
            'test_role_1'
        ]
    )

    play = Play.load(play_source, play_context=PlayContext(), loader=None)

    task = Task()
    task._role = 'test_role_1'
    task._parent = play
    task._role_path = 'test_role/test_role_1'
    task.role_metadata.allow_duplicates = 'True'

    assert task.role_metadata.allow_duplicates
    assert task

# Generated at 2022-06-11 10:40:30.985411
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner=None)
    assert isinstance(m, RoleMetadata)


# Generated at 2022-06-11 10:40:35.570568
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test
    p = RoleMetadata()
    p.deserialize({'dependencies' : [ { 'name': 'nginx' } ]})
    assert p._dependencies[0].get_name() == "nginx"
    assert p.allow_duplicates == False
    assert (p._argument_specs == {})

# Generated at 2022-06-11 10:40:43.400258
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader

    # Test legacy role metadata definition
    role_name = 'test_role'
    role_path = 'roles/%s' % role_name
    role_def = RoleDefinition.load(role_name, searched_path=role_path)
    role = role_loader.get(role_def.get_name(), class_only=True)

    role = role.load(role_def, role._role_search_path)
    role._metadata = RoleMetadata.load(role._metadata, owner=role)

    assert len(role.get_dependencies()) == 0, "legacy role dependency definition is not supported!"

# Generated at 2022-06-11 10:40:55.491669
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars


# Generated at 2022-06-11 10:41:03.982665
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.collectionsearch import PluginLoader

    m_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'library', 'test_metadata')

    metadata = RoleMetadata.load(dict(
        x = 1,
        y = 2,
        galaxy_info = dict(
            author = 'me',
            description = 'test',
            company = 'red hat',
            license = 'asl'
        ),
        dependencies = [
            dict(name="common", src="../common")
        ]
    ), RoleDefinition.load(data=dict(name='test_metadata'), parent_role=None),
                          variable_manager=None,
                          loader=PluginLoader())



# Generated at 2022-06-11 10:41:06.878824
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {'version': '1.0', 'author': 'Ansible'}
    role = RoleMetadata(data)
    assert isinstance(role, RoleMetadata)
    assert role._data == data

# Generated at 2022-06-11 10:41:15.474262
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role_include import RoleInclude
    from ansible.galaxy.role import GalaxyRole
    from ansible.galaxy.collection import GalaxyCollectionRequirement
    from ansible.galaxy.collection import GalaxyCollection
    collection = GalaxyCollection(
        collection_info={'namespace': 'test_namespace', 'name': 'test_name', 'version': '1.0.0'},
        versions_path='test_versions_path'
    )
    include1 = RoleInclude(
        role_name='test_role1',
        role_path='test_role_path1',
        role_collection=collection,
        options=dict(foo='bar'),
    )

# Generated at 2022-06-11 10:41:16.659907
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
  rm = RoleMetadata()

# Generated at 2022-06-11 10:41:18.090911
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # For now we don't have unit test for this class
    assert True == True

# Generated at 2022-06-11 10:41:34.300458
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = ['foo']
    assert not role_metadata._allow_duplicates
    role_metadata.dependencies[0] == 'foo'

# Generated at 2022-06-11 10:41:42.419856
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.loader import task_loader
    from ansible.plugins.task import TaskBase

    # Create a task
    task = Task()
    # Create a task queue manager
    tqm = TaskQueueManager()
    # Create a list of hosts
    hosts = []
    # Create a task executor
    task_executor = TaskExecutor()

    # Get a task base
    task_base = task_loader.get(None, "include_role", TaskInclude)


# Generated at 2022-06-11 10:41:46.379021
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test for method deserialize of class RoleMetadata
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    metadata = RoleMetadata()
    metadata.deserialize(data)
    assert not metadata.allow_duplicates
    assert not metadata.dependencies

# Generated at 2022-06-11 10:41:57.602139
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {
        'allow_duplicates': True,
        'dependencies': [
            {
                'role': 'geerlingguy.repo-epel'
            }
        ]
    }

    yaml.add_constructor('!include', include_constructor)
    yaml.add_constructor('!include_role', include_role_constructor)
    yaml.add_constructor('!include_tasks', include_tasks_constructor)
    yaml.add_constructor('!import', import_constructor)
    yaml.add_constructor('!import_playbook', import_playbook_constructor)

    rm = RoleMetadata.load(data, None)
    serialize_data = rm.serialize()
    assert serialize_data['allow_duplicates'] is True

# Generated at 2022-06-11 10:41:59.003672
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print(RoleMetadata(owner='mock_role'))

# Generated at 2022-06-11 10:42:05.246900
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role import Role
    from ansible.playbook.role import RoleRequirement

    # test the case where data is not a dict
    data = []
    owner = Role()
    owner._role_path = '/path/to/roles/foo'
    owner._role_name = 'foo'
    try:
        RoleMetadata.load(data, owner)
        assert False
    except AnsibleParserError:
        pass

    # test the case where data has no dependencies
    data = dict(dependencies=[])
    owner = Role()
    owner._role_path = '/path/to/roles/foo'
    owner._role_name = 'foo'
    result = RoleMetadata.load(data, owner)
    assert result.dependencies == []

    # test the case where data has dependencies, but

# Generated at 2022-06-11 10:42:09.621823
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata object
    rm = RoleMetadata()

    # Deserialize
    rm.deserialize(dict(
        allow_duplicates=False,
        dependencies=[]
    ))
    assert rm._allow_duplicates == False
    assert rm._dependencies == []

# Generated at 2022-06-11 10:42:13.991403
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = dict(
        dependencies=[1,2,3],
        allow_duplicates=False
    )
    metadata.deserialize(data)
    assert metadata.dependencies == [1,2,3]
    assert metadata.allow_duplicates == False

# Generated at 2022-06-11 10:42:18.457706
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_meta = RoleMetadata()
    role_meta._dependencies = ['role1', 'role2']

    serialized_data = role_meta.serialize()
    expected_data = dict(
        allow_duplicates=False,
        dependencies=['role1', 'role2']
    )
    assert serialized_data == expected_data

# Generated at 2022-06-11 10:42:22.280511
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = True
    m.dependencies = ['foo', 'bar']
    ds = m.serialize()
    assert ds['allow_duplicates']
    assert len(ds['dependencies']) == 2


# Generated at 2022-06-11 10:42:51.732774
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-11 10:42:56.830464
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )
    roleMeta = RoleMetadata()
    roleMeta.deserialize(data)
    assert roleMeta.allow_duplicates == data.get('allow_duplicates')
    assert roleMeta.dependencies == data.get('dependencies')

# Generated at 2022-06-11 10:43:07.694342
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta_object = RoleMetadata.deserialize({'allow_duplicates': False, 'dependencies': [1, 2, 3]})
    assert meta_object._allow_duplicates is False

    meta_object = RoleMetadata.deserialize({'allow_duplicates': True, 'dependencies': [1, 2, 3]})
    assert meta_object._allow_duplicates is True

    meta_object = RoleMetadata.deserialize({'dependencies': [1, 2, 3]})
    assert meta_object._allow_duplicates is False

    try:
        meta_object = RoleMetadata.deserialize({'allow_duplicates': "string", 'dependencies': [1, 2, 3]})
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-11 10:43:09.072018
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test entry point RoleMetadata.load()
    pass


# Generated at 2022-06-11 10:43:15.351714
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    role = Role()
    roleMetadata = RoleMetadata()
    roleMetadata.owner = role
    roleMetadata.deserialize({"allow_duplicates": False,
                              "dependencies": []})
    assert roleMetadata._allow_duplicates == False
    assert roleMetadata._dependencies == []
    data = {"allow_duplicates": True,
            "dependencies": [{"role": "example"}]}
    roleMetadata.deserialize(data)
    assert roleMetadata._allow_duplicates == True
    assert roleMetadata._dependencies == [{"role": "example"}]

# Generated at 2022-06-11 10:43:25.671475
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task.include import TaskInclude
    from ansible.module_utils.facts.system.pkg_mgr import PackageManager
    package_manager = PackageManager('/bin/rpm', None, None)
    hostvars = {}
    hostvars['pkg_mgr'] = package_manager.executable
    variable_manager = {'hostvars': hostvars}
    variable_manager['hostvars'] = hostvars
    play = Play()
    block = Block()
    dependency = RoleDefinition('/home/michael/ansible/ansible/playbooks/roles/test', play, block, variable_manager=variable_manager)

# Generated at 2022-06-11 10:43:26.295444
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass
    # TBD

# Generated at 2022-06-11 10:43:27.409942
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata is RoleMetadata

# Generated at 2022-06-11 10:43:31.902921
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = ['foo', 'bar']
    expected_result = {
        'allow_duplicates': False,
        'dependencies': ['foo', 'bar']
    }
    assert role_metadata.serialize() == expected_result

# Generated at 2022-06-11 10:43:32.437677
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass



# Generated at 2022-06-11 10:44:21.498235
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    R = RoleMetadata()
    ds = dict(allow_duplicates=True, dependencies=list())
    R.deserialize(ds)
    assert R._allow_duplicates == True and R._dependencies == list()

# Generated at 2022-06-11 10:44:25.372421
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    attr = {
        'allow_duplicates': True,
        'dependencies': [{'src': 'test'}],
    }

    role_meta = RoleMetadata()
    role_meta._load_allow_duplicates(attr, attr['allow_duplicates'])
    role_meta._load_dependencies(attr, attr['dependencies'])
    assert role_meta.allow_duplicates is True
    assert len(role_meta.dependencies) == 1
    assert role_meta.dependencies[0] == {'src': 'test'}


# Generated at 2022-06-11 10:44:29.796365
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    rmd = RoleMetadata()
    rmd.deserialize(data)
    assert rmd.dependencies == data['dependencies']
    assert rmd.allow_duplicates == data['allow_duplicates']


# Generated at 2022-06-11 10:44:39.357821
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Data for initialize the object
    data1 = {
        'allow_duplicates': ['foo'],
        'dependencies': ['bar']
    }
    data2 = {
        'dependencies': ['bar']
    }

    # Run the deserialize method
    role_metadata1 = RoleMetadata()
    role_metadata1.deserialize(data1)
    assert role_metadata1.allow_duplicates == ['foo']
    assert role_metadata1.dependencies == ['bar']

    role_metadata2 = RoleMetadata()
    role_metadata2.deserialize(data2)
    assert role_metadata2.allow_duplicates == False
    assert role_metadata2.dependencies == ['bar']



# Generated at 2022-06-11 10:44:46.077798
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    args = dict(
        dependencies=dict(
            role='testNamespace.testCollection.testRole',
            name='testRoleName'
        )
    )

    # init RoleMetadata
    role_metadata = RoleMetadata()
    role_metadata.load_data(args)

    # test_dependencies
    assert role_metadata.dependencies[0].role == args['dependencies']['role']
    assert role_metadata.dependencies[0].name == args['dependencies']['name']



# Generated at 2022-06-11 10:44:46.753275
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:44:55.494938
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_meta = {
        "dependencies": [
            {
                "role": "test",
                "name": "test-role"
            }
        ]
    }

    role_meta = RoleMetadata()
    role_meta.deserialize(test_meta)

    assert role_meta.dependencies[0].role == "test"
    assert role_meta.dependencies[0].name == "test-role"
    assert role_meta.dependencies[0].collections == list()
    assert role_meta.dependencies[0].scm == None
    assert role_meta.dependencies[0].src == None
    assert role_meta.dependencies[0].version == None
    assert role_meta.dependencies[0].api_version == '2'

# Generated at 2022-06-11 10:45:05.458353
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.test_helpers import load_data_from_file
    from ansible.playbook.role.definition import RoleDefinition

    path = 'tests/test_data/test_role'

    # Ensure empty RoleMetadata can be constructed
    RoleMetadata()

    # Load a valid role
    role_def = RoleDefinition.load(path)

    # Ensure the RoleMetadata is loaded
    role_def._metadata = RoleMetadata.load(load_data_from_file('meta/main.yml'), owner=role_def)
    assert isinstance(role_def._metadata, RoleMetadata)

    # GalaxyInfo is empty for now.
    assert isinstance(role_def._metadata.galaxy_info, GalaxyInfo)

# Generated at 2022-06-11 10:45:10.107737
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert r.serialize() == {}
    r._allow_duplicates = True
    assert r.serialize() == {'allow_duplicates': True}
    r._dependencies = [{'role': 'mongodb'}]
    assert r.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'mongodb'}]}

# Generated at 2022-06-11 10:45:17.669364
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    role = play.get_roles()[0]
    role._role_path = '/path/to/role'

    m = RoleMetadata.load(
        {
            'dependencies': ['common']
        },
        owner=role,
        variable_manager=variable_manager,
        loader=loader
    )
    assert m._dependencies[0].get_name() == 'common'

# Generated at 2022-06-11 10:46:57.649492
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    assert rmd.allow_duplicates is False
    assert rmd.dependencies == []
    data = {'allow_duplicates': True, 'dependencies': ['foo', 'bar']}
    rmd.deserialize(data)
    assert rmd.allow_duplicates is True
    assert rmd.dependencies == ['foo', 'bar']

# Generated at 2022-06-11 10:47:04.394945
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import ansible.playbook.role_include as RI
    from ansible.plugins.loader import role_loader
    import io
    import collections
    role_path = '/targetdir/role_dir/'
    main_yml_path = role_path + '/meta/main.yml'
    args = collections.namedtuple('args', 'listtags, listtasks, listhosts, syntax, connection, module_path, forks, private_key_file, ssh_common_args, ssh_extra_args, sftp_extra_args, scp_extra_args, become, become_method, become_user, verbosity, check, diff')

# Generated at 2022-06-11 10:47:07.836302
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': True,
        'dependencies': ['nginx', 'tomcat']
    })
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['nginx', 'tomcat']

test_RoleMetadata_deserialize()

# Generated at 2022-06-11 10:47:09.868667
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }

    r.deserialize(data)
    assert not r._allow_duplicates
    assert not r._dependencies

# Generated at 2022-06-11 10:47:10.297328
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:47:19.255979
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from collections import namedtuple

    class StubRole(namedtuple('StubRole', ['name'])):
        def get_name(self):
            return self.name

    from ansible.playbook.play_context import PlayContext

    c = PlayContext()

    expected = {
        'allow_duplicates': False,
        'argument_spec': {},
        'dependencies': [],
        'galaxy_info': None
    }

    role = StubRole(name='overrides')
    r = RoleMetadata(owner=role)
    r.load_data({}, variable_manager=None, loader=None)

    assert expected == r.serialize()


# Generated at 2022-06-11 10:47:26.680283
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Whether an error will be raised when loading the role metadata
    result = True

    # Create a role metadata object
    role_metadata = RoleMetadata()

    # Check if the method load of class RoleMetadata will raise an error
    # when the metadata file is not a dictionary
    try:
        role_metadata.load(True, None, None, None)
    except AnsibleParserError:
        result = False
    finally:
        assert result

    # Check if the method load of class RoleMetadata will raise an error
    # when the role dependencies field is not a list
    try:
        role_metadata.load(
            {
                'dependencies': 123
            },
            None,
            None,
            None
        )
    except AnsibleParserError:
        result = False
    finally:
        assert result

    # Check if

# Generated at 2022-06-11 10:47:30.193752
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {'allow_duplicates': True}
    r.deserialize(data)
    assert r.allow_duplicates == True
    data = {'dependencies': ['all']}
    r.deserialize(data)
    assert r.dependencies == ['all']


# Generated at 2022-06-11 10:47:35.471263
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates": True, "dependencies": ["A", "B", "C"]})
    role_metadata_serialized = role_metadata.serialize()
    assert role_metadata_serialized["allow_duplicates"] == True
    assert role_metadata_serialized["dependencies"] == ["A", "B", "C"]


# Generated at 2022-06-11 10:47:40.437564
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    try:
        rolemeta = RoleMetadata()
        rolemeta.deserialize(data=dict(dependencies='test'))
    except Exception:
        import traceback
        assert False, "test_RoleMetadata_deserialize failed:\n{0}".format(
            traceback.format_exc())
    assert True