

# Generated at 2022-06-11 10:39:13.359198
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    builder = RoleMetadata()
    assert builder is not None

# Generated at 2022-06-11 10:39:15.996567
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Exceptions
    try:
        RoleMetadata.load('', '')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 10:39:26.710506
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    my_deps = [{u'role': u'ependency1'}, {u'role': u'ependency2'}, {u'role': u'ependency3'}]
    galaxy_info = {u'description': u'This is a test',
                   u'author': u'John Doe',
                   u'version': u'1.0.0',
                   u'license': u'MIT'}
    my_dict = {u'allow_duplicates': True,
               u'dependencies': my_deps,
               u'galaxy_info': galaxy_info}

# Generated at 2022-06-11 10:39:31.709518
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()

    test_dict = {
        'allow_duplicates': False,
        'dependencies': []
    }

    role_metadata.deserialize(test_dict)
    assert role_metadata.allow_duplicates == test_dict['allow_duplicates']
    assert role_metadata.dependencies == test_dict['dependencies']

# Generated at 2022-06-11 10:39:36.322586
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata_data = dict(
        allow_duplicates=True,
        dependencies=dict(
            name='some_rolename',
            src='some_file_path',
            scm='some_GIT',
            version='some_version'
        )
    )
    roleMetadata = RoleMetadata()
    roleMetadata.deserialize(RoleMetadata_data)
    assert(roleMetadata.allow_duplicates)

# Generated at 2022-06-11 10:39:38.309736
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert r.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:39:39.718067
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._dependencies is not None

# Generated at 2022-06-11 10:39:49.477649
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Unit test for method serialize of class RoleMetadata
    '''

    # Create an object of class RoleMetadata
    role_metadata = RoleMetadata()
    string_allow_duplicates = 'yes'
    string_dependencies = [{'role': 'common', 'foo': 'bar'}]
    role_metadata._allow_duplicates = string_allow_duplicates
    role_metadata._dependencies = string_dependencies

    # Serialize the object
    data = role_metadata.serialize()

    assert data['allow_duplicates'] == bool(string_allow_duplicates)
    assert data['dependencies'] == string_dependencies

# Generated at 2022-06-11 10:39:56.603976
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import pytest
    from ansible.playbook.collectionsearch import CollectionSearch

    c = CollectionSearch()
    m = RoleMetadata(owner=c)
    m.dependencies = [{'role': 'ansible.builtin'}, {'role': 'ansible.builtin', 'name': 'debops'}]
    assert m.serialize()['dependencies'] == [{'role': 'ansible.builtin'}, {'role': 'ansible.builtin', 'name': 'debops'}]

# Generated at 2022-06-11 10:39:58.778217
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role._allow_duplicates == False
    assert role._dependencies == []



# Generated at 2022-06-11 10:40:15.078325
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import pytest

    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.fixture.play import Play
    from ansible.playbook.fixture.task import Task

    def _data(omit=False):
        data = dict(
            dependencies=dict(
                role1=dict(src="role-1"),
                role2=dict(src="role-2"),
            )
        )

        if omit is True:
            data['dependencies']['role3'] = dict(src="ansible.windows:role-3")

        return data

    data = _data()
    p = Play()
    t = Task()
    t._play = p
    rm = RoleMetadata(owner=t)

    result = RoleMetadata.load(data, owner=t)

# Generated at 2022-06-11 10:40:16.853870
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata().deserialize({'allow_duplicates': True}) == {'allow_duplicates': True, 'dependencies': []}

# Generated at 2022-06-11 10:40:20.286390
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata.load(dict(dependencies=[dict(role="geerlingguy.java")]), None)
    for d in role_metadata.serialize()["dependencies"]:
        assert d["role"] == "geerlingguy.java"

# Generated at 2022-06-11 10:40:27.693470
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from collections import namedtuple
    fake_data = {'allow_duplicates': False, 'dependencies': []}
    RoleMetadata_data_tuple = namedtuple('RoleMetadata_data_tuple', ['data'])
    role_metadata = RoleMetadata()
    role_metadata.deserialize(RoleMetadata_data_tuple(data=fake_data))
    assert role_metadata.allow_duplicates == fake_data['allow_duplicates']
    assert role_metadata.dependencies == fake_data['dependencies']

# Generated at 2022-06-11 10:40:37.620607
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta_data = '''
name: test_role
description: some description
dependencies:
    - role: test_role
      src: git+https://github.com/geerlingguy/ansible-role-apache.git
      scm: git
      version: 42.0
'''

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.metadata import RoleMetadata

    data = yaml.load(meta_data)

    # Create a RoleDefinition object to pass it to RoleMetadata class constructor
    owner = RoleDefinition()

    role_meta = RoleMetadata.load(data, owner)

    assert role_meta._dependencies[0].role == 'test_role'
    assert role_meta._depend

# Generated at 2022-06-11 10:40:41.322538
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    The test_RoleMetadata_deserialize function tests the deserialize method of the class RoleMetadata
    """

    rm = RoleMetadata()

    assert rm.deserialize({'dependencies':[{'role': 'some-role'}]}) is None
    assert rm.dependencies == [{'role': 'some-role'}]

# Generated at 2022-06-11 10:40:41.838407
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:40:45.830560
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata()
    role_meta._allow_duplicates = False
    role_meta._dependencies = ['test']
    serialize = role_meta.serialize()
    assert serialize['allow_duplicates'] == False
    assert serialize['dependencies'] == ['test']



# Generated at 2022-06-11 10:40:58.176049
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import yaml

# Generated at 2022-06-11 10:41:05.105329
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    data = {
        'allow_duplicates': False,
        'dependencies': [{'role': 'foo', 'version': '1.2.3'}]
    }
    context = PlayContext()
    owner = TaskInclude('foo', owner=context)
    # owner.role will trigger RuntimeError
    owner.role = RoleDefinition.load({'name': 'bar'}, owner=context, variable_manager=None, loader=None)
    result = RoleMetadata.load(data, owner=owner, variable_manager=None, loader=None)
    assert result
    assert result._owner.name == 'bar'
    assert result

# Generated at 2022-06-11 10:41:21.031333
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager()


# Generated at 2022-06-11 10:41:30.181606
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Test RoleMetadata deserialize method
    '''
    # import
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    play_obj = Play.load({'name': 'test',
                          'hosts': 'localhost',
                          'connection': 'local',
                          'tasks': [
                              {'debug': {'msg': 'test'}},
                          ]},
                          variable_manager=None,
                          loader=None)
    # play_obj.post_validate is called in __init__, we

# Generated at 2022-06-11 10:41:31.556995
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass


# Generated at 2022-06-11 10:41:38.347671
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Tests the constructor of the RoleMetadata class.
    '''

    role_metadata = RoleMetadata()

    assert role_metadata._data == {}
    assert role_metadata._ds == {}
    assert role_metadata._variable_manager is None
    assert role_metadata._loader is None
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info is None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-11 10:41:44.600773
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    metadata.allow_duplicates = True
    metadata.dependencies = [
        {
            'role': 'jdauphant.nginx',
            'version': 'v2.22.1'
        }
    ]
    
    expected = {
        'allow_duplicates': True,
        'dependencies': [
            {
                'role': 'jdauphant.nginx',
                'version': 'v2.22.1'
            }
        ]
    }

    assert metadata.serialize() == expected

# Generated at 2022-06-11 10:41:45.171546
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-11 10:41:55.409267
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role_include import RoleInclude
    r = RoleMetadata()
    roles = [{'role': 'foo', 'name': 'foo'}, {'role': 'bar', 'name': 'bar'}, {'role': 'baz', 'name': 'baz'}]
    r.deserialize({'allow_duplicates': True, 'dependencies': roles})
    assert r._allow_duplicates
    assert len(r._dependencies) == 3
    assert isinstance(r._dependencies[0], RoleInclude)
    assert isinstance(r._dependencies[1], RoleInclude)
    assert isinstance(r._dependencies[2], RoleInclude)

# Generated at 2022-06-11 10:41:58.502505
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Unit test code for method serialize of class RoleMetadata
    '''
    r = RoleMetadata()
    assert('allow_duplicates' in r.serialize())
    assert('dependencies' in r.serialize())

# Generated at 2022-06-11 10:42:03.013251
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata()
    role_meta.deserialize({'allow_duplicates':False, 'dependencies':[]})
    serialized_value = role_meta.serialize()

    assert serialized_value == {
        'allow_duplicates': False,
        'dependencies': []
    }, 'RoleMetadata.serialize() failed: serialized value was {0}'.\
        format(serialized_value)

# Generated at 2022-06-11 10:42:11.222648
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    data = dict(
        allow_duplicates=True,
        dependencies=list(),
    )

    role = Role()
    role._role_path = 'test_role_path'
    rm = RoleMetadata(owner=role)

    serial_rm = rm.serialize()
    assert serial_rm['allow_duplicates']
    assert len(serial_rm['dependencies']) == 0

    #test deserialization
    rm.deserialize(data)
    assert rm._allow_duplicates
    assert len(rm._dependencies) == 0

# Generated at 2022-06-11 10:42:29.997021
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader import role_loader
    from ansible.vars.manager import VariableManager

    role_name = dict(
        role='foo',
        file='/path/to/roles/foo/meta/main.yml'
        )
    role_def = RoleDefinition.load_from_file(role_name, role_loader)

    rm = RoleMetadata(owner=role_def)
    rm.allow_duplicates = True
    rm.dependencies = [RoleRequirement(name='bar', scm='git', src='git@gitlab.com:foo/bar.git')]


# Generated at 2022-06-11 10:42:41.117653
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # load() method of class RoleMetadata
    # test if  data is empty, the test will pass
    assert RoleMetadata.load(None, None) == None

    # test data is !dict
    assert RoleMetadata.load("", None) != None

    # test  normal condition
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader))


# Generated at 2022-06-11 10:42:45.461724
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.include import RoleInclude

    data = {
        'metadata' : {
            'allow_duplicates': False,
            'dependencies': []
        }
    }
    r = RoleMetadata()
    r.deserialize(data)
    result = r.serialize()
    assert data['metadata'] == result

# Generated at 2022-06-11 10:42:50.948266
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # test None input
    try:
        RoleMetadata.load(None, None)
    except Exception as e:
        print(e)
        assert False
    # test empty data input
    try:
        RoleMetadata.load({}, None)
    except Exception as e:
        print(e)
        assert False
    # test valid data input
    try:
        role_meta = RoleMetadata.load({'dependencies': [], 'allow_duplicates': False}, None)
    except Exception as e:
        print(e)
        assert False
    assert role_meta.dependencies == []
    assert role_meta.allow_duplicates == False


# Generated at 2022-06-11 10:42:56.147386
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
            "allow_duplicates": False,
            "dependencies": [
                {
                    "name": "Common",
                    "role": "./common",
                }
            ]
        }
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._dependencies == data['dependencies']



# Generated at 2022-06-11 10:43:07.010309
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude


    # test for default value of attributes in class RoleMetadata
    test_role_metadata = RoleMetadata()
    result = test_role_metadata.serialize()
    assert result == {'allow_duplicates': False, 'dependencies': []}
    assert result['allow_duplicates'] == False
    assert result['dependencies'] == []

    # test for set attribute in class RoleMetadata
    test_role_metadata = RoleMetadata()
    test_allow_duplicates = 'allow_duplicates in test'

# Generated at 2022-06-11 10:43:11.382941
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_data = {
        'dependencies': ['foo', 'bar'],
        'allow_duplicates': True,
    }

    rm = RoleMetadata()
    rm.deserialize(test_data)

    assert rm._dependencies == ['foo', 'bar']
    assert rm._allow_duplicates == True

# Generated at 2022-06-11 10:43:13.561720
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    obj.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert obj.allow_duplicates == True
    assert obj.dependencies == []

# Generated at 2022-06-11 10:43:23.885715
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.test_helpers import Defaults
    from ansible.playbook.role.definition import RoleDefinition

    my_loader = 'my_loader'
    my_variable_manager = 'my_variable_manager'

    # Test without loader and variable_manager
    m = RoleMetadata.load({'dependencies': ['other_role']}, RoleDefinition(name='my_role'))
    assert isinstance(m, RoleMetadata)
    assert isinstance(m.dependencies[0], RoleRequirement)
    assert m.dependencies[0].name == 'other_role'

    # Test with loader and variable_manager

# Generated at 2022-06-11 10:43:33.674816
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    
    # create an empty role
    role = RoleMetadata()

    # test getter methods
    #assert role.get_name() == "TestRole"
    #assert role.get_path() == "./roles/TestRole"
    #assert role.get_vars() == {}
    #assert role.get_default_vars() == {}
    #assert role.get_tasks() == []
    #assert role.is_task() == False

    # test setter methods
    #role.set_name("NewRole")
    #role.set_path("/path/to/NewRole")
    #role.set_vars({"key":"value"})
    #role.set_default_vars({"key":"value"})
    #role.set_tasks(["tasks/main.yml"]

# Generated at 2022-06-11 10:43:59.596971
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass # TODO

# Generated at 2022-06-11 10:44:09.009723
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.definition import RoleDefinition
    from collections import namedtuple

    RoleRequirement = namedtuple('RoleRequirement', 'role_path')

    # RoleInclude test
    in_data = {
        'dependencies': [{'role': 'foo'}]
    }
    test_obj = RoleMetadata(Role(RoleDefinition(name="myrole"), play=Play(), role_path="myrole"))
    test_obj.load_data(in_data)

    assert len(test_obj.dependencies) == 1
    assert isinstance(test_obj.dependencies[0], RoleRequirement)

# Generated at 2022-06-11 10:44:11.527236
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )

# Generated at 2022-06-11 10:44:21.056433
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_path = os.path.join(os.path.dirname(__file__), 'changelogs')
    role_collection = os.path.join(os.path.dirname(__file__), 'changelogs')
    meta_path = os.path.join(os.path.dirname(__file__), 'changelogs', 'meta')
    meta_file = os.path.join(os.path.dirname(__file__), 'changelogs', 'meta', 'main.yml')
    r = RoleMetadata(owner=None)
    r._dependencies = [{'name': 'foobar1', 'src': 'src1', 'version': '1.0'}, {'name': 'foobar2', 'src': 'src2'}]

# Generated at 2022-06-11 10:44:22.335732
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

     try:
         role_metadata = RoleMetadata()
     except Exception as e:
         print(e)

# Generated at 2022-06-11 10:44:32.565535
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.six import string_types

    new_play = Play().load({
        'name': 'test'
    })

    # test construct with empty data structure
    test_metadata = RoleMetadata(owner=new_play)
    assert isinstance(test_metadata, RoleMetadata)

    # test construct with a valid data structure

# Generated at 2022-06-11 10:44:36.072948
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': False, 'dependencies': [], 'galaxy_info': 'galaxy_info'})
    assert r.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:44:45.327446
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement


# Generated at 2022-06-11 10:44:46.111455
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert RoleMetadata.load(data=None, owner=None) is not None

# Generated at 2022-06-11 10:44:55.294627
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook import Play

    RoleMetadata.__setattr__ = Base.__setattr__
    setattr(RoleMetadata, '_valid_attrs', RoleMetadata._get_valid_attrs())
    setattr(Role, '_valid_attrs', Role._get_valid_attrs())

    my_play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            dict(
                name = "myrole",
                tasks = [
                    dict(action=dict(module="debug", args=dict(msg="Hello World!")))
                ]
            )
        ]
    ), loader=None, variable_manager=None)

    role_name = my

# Generated at 2022-06-11 10:45:45.087838
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()

# Generated at 2022-06-11 10:45:49.764959
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import sys
    import uuid
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    role_name = str(uuid.uuid4())
    role_path = '/dev/null'
    role = Role.load(role_name, role_path, Play())
    RoleMetadata.load(dict(), role)

# Generated at 2022-06-11 10:45:51.749308
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.tests.test_utils import p, run_test_case
    run_test_case(p, 'RoleMetadata_load')


# Generated at 2022-06-11 10:46:01.702194
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'allow_duplicates': True, 'dependencies': ['meta'],
            'galaxy_info': {'author': 'lijunjie', 'description': 'i am a description',
                            'company': 'horncao', 'license': 'Apache', 'min_ansible_version': '2.0',
                            'platforms': [{'name': 'Centos', 'versions': ['7']}]}}

    m = RoleMetadata()
    m.load(data, 'owner')

    assert isinstance(m, RoleMetadata)
    assert isinstance(m.dependencies[0], RoleRequirement)
    assert isinstance(m.galaxy_info, dict)
    assert 'author' in m.galaxy_info
    assert 'description' in m.galaxy_info

# Generated at 2022-06-11 10:46:05.338274
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # create an object of class RoleMetadata
    obj = RoleMetadata()

    # Test deserialize of class RoleMetadata
    data = dict(
        allow_duplicates= True,
        dependencies= ['ansible.builtin', 'ansible.legacy']
    )
    obj.deserialize(data)


# Generated at 2022-06-11 10:46:09.788546
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    data = {
        'allow_duplicates': False,
        'dependencies': [{
            'role': 'my.role',
            'version': '1.0.0'
        }]
    }

    rmd.deserialize(data=data)

    assert rmd.allow_duplicates == False
    assert len(rmd.dependencies) == 1
    assert rmd.dependencies[0].role == 'my.role'
    assert rmd.dependencies[0].version == '1.0.0'

# Generated at 2022-06-11 10:46:13.404951
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Unit test for method deserialize for class RoleMetadata
    '''
    assert RoleMetadata().deserialize({}) == ({}, False)
    assert RoleMetadata().deserialize({'allow_duplicates': False}) == ({}, False)
    assert RoleMetadata().deserialize({'allow_duplicates': True}) == ({}, True)

# Generated at 2022-06-11 10:46:13.866097
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert True

# Generated at 2022-06-11 10:46:14.382858
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-11 10:46:20.900299
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    # test injector "allow_duplicates"
    test_data = dict(allow_duplicates=False)
    metadata.deserialize(test_data)
    assert getattr(metadata, 'allow_duplicates') == False
    test_data = dict(allow_duplicates=True)
    metadata.deserialize(test_data)
    assert getattr(metadata, 'allow_duplicates') == True
    # test injector "dependencies"
    test_data = dict(dependencies=list())
    metadata.deserialize(test_data)
    assert getattr(metadata, 'dependencies') == list()
    test_data = dict(dependencies=['role1'])
    metadata.deserialize(test_data)

# Generated at 2022-06-11 10:47:22.291142
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from collections import namedtuple
    from ansible.playbook.role import Role
    test_args = namedtuple('TestArgs', ['args'])
    test_args.args = namedtuple('TestArgs.args', ['role'])
    test_args.args.role = namedtuple('TestArgs.args.role', ['role'])
    test_args.args.role.role = namedtuple('TestArgs.args.role.role', ['role'])
    test_args.args.role.role.role = Role('ansible-test-role')
    role_meta = RoleMetadata(test_args.args.role.role)
    print("Test succeed")

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-11 10:47:27.709867
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Test if method serialize of class RoleMetadata is working properly
    '''
    from ansible.playbook.role.meta import RoleMetadata

    role_metadata = RoleMetadata()
    role_metadata._galaxy_info = {}
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['one', 'two']

    res = role_metadata.serialize()
    assert res['allow_duplicates'] is True
    assert res['dependencies'][0] == 'one'
    assert res['dependencies'][1] == 'two'

# Generated at 2022-06-11 10:47:34.818932
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import json
    from ansible.playbook.role.definition import RoleDefinition

    m = RoleMetadata()
    json_string='''{
        "dependencies": [
            {"role": "common", "version": "v1"},
            {"role": "webserver", "version": "v1"},
            {"role": "mysql", "version": "v1"}
        ]
    }'''
    m.load(json.loads(json_string))
    assert len(m.dependencies) == 3
    assert all(isinstance(rd, RoleDefinition) for rd in m.dependencies)



# Generated at 2022-06-11 10:47:37.736235
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    a = r.serialize()
    assert r.allow_duplicates  == False
    assert r.dependencies  == []



# Generated at 2022-06-11 10:47:40.843358
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    playbook_path = "/etc/playbook.yml"
    r = RoleMetadata(playbook_path)
    assert r._playbook_path == playbook_path
    assert r._ds is None

# Generated at 2022-06-11 10:47:47.424489
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Test if serialize method of `RoleMetadata` casts `allow_duplicates` and
    `dependencies` to appropriate type.
    '''
    # Given
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    # When
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    # Then
    serialized_data = role_metadata.serialize()
    assert isinstance(serialized_data['allow_duplicates'], bool)
    assert isinstance(serialized_data['dependencies'], list)

# Generated at 2022-06-11 10:47:53.908445
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata.load({'allow_duplicates': True, 'dependencies': [{'role': 'http://example.com/local.or.remote/role'}, {'role': 'local.or.remote.role2', 'other_vars': 'here'}], }).serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'http://example.com/local.or.remote/role'}, {'role': 'local.or.remote.role2', 'other_vars': 'here'}], }


# Generated at 2022-06-11 10:48:01.798962
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Unit test for method RoleMetadata.serialize()
    '''

    print('Unit testing method "serialize" of class RoleMetadata')

    meta = RoleMetadata()

    role_dependencies = []

    #TODO: We need an example that has these attributes defined
    #setattr(meta, '_allow_duplicates', True)
    #setattr(meta, '_dependencies', role_dependencies)

    try:
        meta.serialize()
    except Exception as e:
        print('Caught exception: ' + str(e))
        raise

    print('Unit test for method "serialize" of class RoleMetadata passed')


if __name__ == '__main__':
    test_RoleMetadata_serialize()

# Generated at 2022-06-11 10:48:11.413901
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    import yaml

    test_dict = {
        'name': 'test',
        'dependencies': [
            {'role': 'include_role'},
            {'role': 'role_3'}
        ],
        'allow_duplicates': False
    }

# Generated at 2022-06-11 10:48:19.574629
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Load RoleMetadata object as it would be by the parser
    # Running method load of class RoleMetadata
    import ansible.playbook
    rp = ansible.playbook.Role()
    rp.role_path = 'somewhere'
    rp.name = u'role'
    rm = RoleMetadata(owner=rp)
    rm.load_data(
        {
            u'allow_duplicates': True,
            u'dependencies': [],
            u'some_attribute': u''
        }
    )
    # Check
    assert rm.allow_duplicates == True
    assert rm.dependencies == []
    assert rm.name == u'role'
    assert rm.owner == rp
    assert rm.some_attribute == u''
