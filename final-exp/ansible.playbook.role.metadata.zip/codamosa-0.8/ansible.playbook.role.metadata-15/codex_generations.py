

# Generated at 2022-06-11 10:39:21.689934
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import yaml
    variable_manager = yaml.load(open('./test/data/role_metadata_variable_data.yml', 'r'))
    data = yaml.load(open('./test/data/role_metadata_data.yml', 'r'))
    data['allow_duplicates'] = False
    data['dependencies'] = []
    loader = None
    owner = None

    meta_data = RoleMetadata.load(data, owner, variable_manager, loader)
    assert meta_data  # TODO: add more test cases here



# Generated at 2022-06-11 10:39:27.851375
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': True,
        'dependencies': [{'role': 'common', 'name': 'common'}]
    }
    var = RoleMetadata()
    var.deserialize(data)
    assert var.allow_duplicates == True
    assert len(var.dependencies) == 1
    assert var.dependencies[0]['role'] == 'common'

# Generated at 2022-06-11 10:39:35.240090
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition

    rd = RoleDefinition.load(dict(
        name='testrole',
        tasks=dict(main=[])),
        play=None)

    rms = RoleMetadata.load(dict(
        allow_duplicates=False,
        dependencies=[]),
    owner=rd)

    ansible_data = rms.deserialize(dict(
        allow_duplicates=True,
        dependencies=[1, 2, 3]))

    assert ansible_data.get('allow_duplicates')
    assert [1, 2, 3] == ansible_data.get('dependencies')

# Generated at 2022-06-11 10:39:45.657163
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = dict(
        allow_duplicates=False,
        dependencies=[
            dict(
                name="common",
            ),
            dict(
                name="webservers",
            ),
        ]
    )

    role_metadata = RoleMetadata(owner="lib_role_metadata.py")
    role_metadata.deserialize(metadata)

    # test of the deserialized dependencies
    dependencies = role_metadata.dependencies
    assert len(dependencies) == 2
    assert dependencies[0].name == "common"
    assert dependencies[1].name == "webservers"

    # test of the serialized metadata
    serialized_metadata = role_metadata.serialize()
    assert len(serialized_metadata['dependencies']) == 2
    assert serialized_metadata['dependencies'][0]['name']

# Generated at 2022-06-11 10:39:56.744735
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # create a play, a role, and a role_metadata
    import ansible.playbook
    import ansible.playbook.role.definition
    play = ansible.playbook.Play()
    role = ansible.playbook.role.definition.RoleDefinition()
    role_metadata = RoleMetadata()

    assert role._metadata is None
    assert role_metadata.owner is None

    # set the owner of the role_metadata to the role
    role_metadata.set_owner(role)
    assert role_metadata.owner == role

    # set the metadata of the role to the role_metadata
    role.set_metadata(role_metadata)
    assert role._metadata == role_metadata

    # set the role of the play to the role
    play.set_roles([role])
    assert play.roles == [role]

   

# Generated at 2022-06-11 10:40:04.794005
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    role_dependency_data = [{'role': 'test1'}, 'test2']

    role = Role()
    role._role_path = './test1'

    role_metadata_instance = RoleMetadata(owner=role)
    role_metadata_instance._allow_duplicates = False
    role_metadata_instance._dependencies = role_dependency_data

    role_metadata_instance.deserialize(role_metadata_instance.serialize())
    assert role_metadata_instance._allow_duplicates is False
    assert role_metadata_instance._dependencies == role_dependency_data

# Generated at 2022-06-11 10:40:14.691954
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-11 10:40:21.203781
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    print("serialize")

# Generated at 2022-06-11 10:40:26.488809
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data_to_test = {
        'allow_duplicates': True,
        'dependencies': None
    }
    meta_obj = RoleMetadata()
    meta_obj.deserialize(data_to_test)
    assert meta_obj.serialize() == {
        'allow_duplicates': True,
        'dependencies': []
    }

# Generated at 2022-06-11 10:40:36.594419
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta_info = {'allow_duplicates': True, 'dependencies': ['role1', 'role2', 'role3']}
    meta = RoleMetadata(owner=None)
    meta.load_data(meta_info)
    meta_return = meta.serialize()
    # Test for serialize() function
    assert meta_return == meta_info

    # Test for deserialize() function
    meta2 = RoleMetadata(owner=None)
    meta2.deserialize(meta_info)
    meta2_return = meta2.serialize()
    assert meta2_return == meta_info

    # Test for constructor
    meta_dict = meta.serialize()
    meta_dict['dependencies'] = ['role0']
    meta3 = RoleMetadata(owner=None)

# Generated at 2022-06-11 10:40:58.335055
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role_include import RoleInclude
    imports = ['from ansible.playbook.role_include import RoleInclude']
    exec(imports)
    metadata = {}
    metadata['allow_duplicates'] = False
    metadata['dependencies'] = [{"role": "role1", "version": "1.0", "name": "my-role"},
                                {"role": "role2", "version": "1.0", "name": "my-role2"}]
    owner = RoleInclude()
    a = RoleMetadata()
    a.deserialize(metadata)
    a._owner = owner
    assert a.allow_duplicates == False

# Generated at 2022-06-11 10:41:03.025679
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata=RoleMetadata()
    role_metadata.allow_duplicates=False
    role_metadata.dependencies=[]

    result = role_metadata.serialize()
    test_result = dict(
        allow_duplicates=False,
        dependencies=list()
    )
    assert result == test_result
    test_RoleMetadata_serialize.__doc__ = role_metadata.serialize.__doc__



# Generated at 2022-06-11 10:41:11.989738
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from units.mock.loader import DictDataLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader

    mock_data_loader = DictDataLoader({
        "/file/path/roles/role_with_dependencies/meta/main.yml": """
        allow_duplicates: false
        dependencies:
          - { role: existing_role }
          - { role: existing_role, name: existing_role_vars }
          - { role: ansible.builtin, when: ansible_facts['distribution'] == 'RedHat' }
          - { role: awx.awx, version: 1.1.1 }
        """
    })


# Generated at 2022-06-11 10:41:14.924916
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    role = RoleMetadata()
    role.deserialize(data)
    assert role.serialize() == data


# Generated at 2022-06-11 10:41:20.548348
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    try:
        data = { 'allow_duplicates': True, 'dependencies': [ 'foo', 'bar' ] }
        m = RoleMetadata()
        m.deserialize(data)
        assert m._allow_duplicates == True
        assert m._dependencies == [ 'foo', 'bar']
    except Exception as e:
        print("Caught exception: {}".format(e))
        assert False

# Generated at 2022-06-11 10:41:22.132846
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    gm = RoleMetadata()
    gm.deserialize(dict())


# Generated at 2022-06-11 10:41:23.313516
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # TODO: write this test
    pass

# Generated at 2022-06-11 10:41:29.079198
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    t1 = m.deserialize({'allow_duplicates': False})
    assert t1.get('allow_duplicates', False) == False
    t2 = m.deserialize({'allow_duplicates': True})
    assert t2.get('allow_duplicates', False) == True
    t = m.deserialize({'dependencies': ['One', 'Two']})
    assert t.get('dependencies', []) == ['One', 'Two']

# Generated at 2022-06-11 10:41:34.204992
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    class test_role():
        def __init__(self, role_path):
            self._role_path = role_path

    dt = {}
    dt['allow_duplicates'] = False
    dt['dependencies'] = []

    rmeta = RoleMetadata()
    rmeta.deserialize(dt)

# Generated at 2022-06-11 10:41:40.080743
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    assert not hasattr(obj, 'allow_duplicates')
    assert not hasattr(obj, 'dependencies')
    data = dict(
        allow_duplicates=True,
        dependencies=[{
            "role": {
                "src": "user.role",
                "bar": "baz"
            },
        }]
    )
    obj.deserialize(data)
    assert obj.allow_duplicates is True
    assert obj.dependencies is not None

# Generated at 2022-06-11 10:41:59.637974
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import os
    import sys
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.plugins.loader import action_loader, lookup_loader, callback_loader

    sys.modules['ansible'] = type('mock_ansible_object', (object,), dict(__file__=os.path.abspath('')))

    #################################################
    # Initialize current working directory and file #
    #################################################
    cwd = os.path.abspath("")
    file_name = "test_play.yml"

# Generated at 2022-06-11 10:42:09.945012
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    r = Role()
    r._role_path = '/tmp/ansible'
    r._role_name = 'role1'
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = AnsibleMapping(dict(foo='bar', baz='whiz', quux=2345))
    load = RoleMetadata.load(data, r, loader=AnsibleLoader)
    assert load.foo == 'bar'
    assert load.baz == 'whiz'
    assert load.quux == 2345

if __name__ == '__main__':
    test_RoleMetadata_load()

# Generated at 2022-06-11 10:42:20.082979
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook import Play

    play = Play().load({
        'name': 'someplay',
        'hosts': ['all'],
        'roles': [{'role': 'somerole'}]
    }, variable_manager=None, loader=None)

    role = Role().load(dict({
        'name': 'somerole',
        'tasks': [{'name': 'some task', 'foo': 'bar'}]
    }), play=play, variable_manager=None, loader=None)

    m = RoleMetadata(owner=role)

    assert m.load(dict(), None, None, None) is not None


# Generated at 2022-06-11 10:42:24.042398
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None)
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = []
    assert role_metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )


# Generated at 2022-06-11 10:42:30.052403
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    yaml = """
- hosts: all
  roles:
  - test
"""
    loader = []
    variable_manager = []

    # Test load() with valid data
    data_valid = {
        'author': 'Your Name',
        'dependencies': [
            "role1",
            "role2"
        ]
    }

    role_definition = RoleDefinition('name', yaml, loader, variable_manager)
    role_metadata = RoleMetadata.load(data_valid, role_definition)

    assert role_metadata._owner == role_definition
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == [
        "role1",
        "role2"
    ]

    # Test load() with invalid data


# Generated at 2022-06-11 10:42:41.156070
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class FakeRole:
        def __init__(self, name, path=''):
            self._role_name = name
            self._role_path = path
            self._role_collection = None

        def get_name(self):
            return self._role_name

    context = PlayContext()

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:42:43.568036
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates": False, "dependencies": []})
    return role_metadata

# Generated at 2022-06-11 10:42:46.368395
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    ds = dict(
        allow_duplicates=True,
        dependencies=["foo", "bar"]
    )
    r = RoleMetadata().load_data(ds)
    assert r.serialize() == ds


# Generated at 2022-06-11 10:42:51.600676
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.play import Play
    from ansible.plugins.loader import role_loader

    play = Play.load("""
    - hosts: localhost
      roles:
        - example
      tasks:
      - name: Task1
      """
    )

    role_metadata = role_loader.load("example", play, None)

    # check that the role metadata is not None
    assert role_metadata is not None

    # check that the allow duplicates is False by default
    assert role_metadata.allow_duplicates == False

    # check that the dependencies are empty by default
    assert role_metadata.dependencies == []

# Generated at 2022-06-11 10:42:52.937868
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    yaml_cls = RoleMetadata()
    yaml_cls.load()

# Generated at 2022-06-11 10:43:13.792240
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    # Create a Role instance so that we can assign the '_owner' attribute
    r = Role()
    rd = RoleDefinition.load('test', '/tmp')
    r._owner = rd

    # Verify that the constructor of RoleMetadata works without error
    rm = RoleMetadata(r)


# Generated at 2022-06-11 10:43:15.811110
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert 'allow_duplicates' in r.serialize()
    assert 'dependencies' in r.serialize()

# Generated at 2022-06-11 10:43:17.669790
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    data = {}
    obj.deserialize(data)
    assert obj

# Generated at 2022-06-11 10:43:23.068840
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None)

    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ["apache", "mysql"]

    expected = {
        'allow_duplicates' : True,
        'dependencies' : role_metadata.dependencies
    }
    result = role_metadata.serialize()

    assert expected == result

# Generated at 2022-06-11 10:43:32.273167
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    data = dict(
        dependencies=[
            dict(role="common", some_variable="foo"),
            dict(role="webservers", other_variable="bar"),
            dict(role="foo"),
        ],
    )
    role = RoleDefinition.load(dict(name="foo", playbooks=[]), loader=None, variable_manager=None)
    role._role_path = '/a/b/foo'
    rm = RoleMetadata.load(data, owner=role)

    assert isinstance(rm, RoleMetadata)
    assert isinstance(rm._dependencies[0], RoleRequirement)

# Generated at 2022-06-11 10:43:39.863620
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            {'role': 'test', 'name': 'test2', 'version': 'v1.0'},
            'test3'
        ]
    )

    m = RoleMetadata()
    m.deserialize(data)

    assert m._allow_duplicates == True
    assert len(m._dependencies) == 2
    assert m._dependencies[0].role == 'test'
    assert m._dependencies[0].name == 'test2'
    assert m._dependencies[0].version == 'v1.0'
    assert m._dependencies[1].role == 'test3'



# Generated at 2022-06-11 10:43:43.814236
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    item = RoleMetadata()

    data = {
        'allow_duplicates': True,
        'dependencies': ['role1', 'role2']
    }

    item.deserialize(data)
    assert item.allow_duplicates == True
    assert item.dependencies == ['role1', 'role2']

# Generated at 2022-06-11 10:43:44.325795
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-11 10:43:46.441804
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    assert RoleMetadata().serialize() == data


# Generated at 2022-06-11 10:43:55.980457
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    class TestPlay(object):
        def __init__(self, base_vars=None):
            self._base_vars = base_vars

        def get_vars(self):
            return combine_vars(self._base_vars, dict())

    class TestRoleDefinition(RoleDefinition):
        def __init__(self, base_vars=None):
            super(TestRoleDefinition, self).__init__()
            self._play = TestPlay(base_vars=base_vars)


# Generated at 2022-06-11 10:44:26.124423
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_role = RoleMetadata()

# Generated at 2022-06-11 10:44:30.348288
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_name = 'my_role'
    role_path = '/some/path/to/'+role_name
    owner = MockRole(role_name, role_path)
    meta_to_load = {}
    meta = RoleMetadata(owner=owner)
    meta = meta.load(meta_to_load, owner=owner)



# Generated at 2022-06-11 10:44:34.947663
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    meta.deserialize(data)
    assert 'allow_duplicates' in dir(meta)
    assert 'dependencies' in dir(meta)


# Generated at 2022-06-11 10:44:44.340911
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    class Role(object):

        def __init__(self, path, name):
            self._role_path = path
            self.name = name
            self.collections = []

        def __repr__(self):
            return "%s(%r)" % (self.__class__, self.__dict__)

    path = 'MY_PATH'
    name = 'MY_NAME'

    mock_variable_manager = Mock(autospec=True)
    mock_loader = Mock(autospec=True)

    data = dict(
        allow_duplicates=True,
        dependencies=[],
        galaxy_info=None,
        argument_specs={}
    )

    role = Role(path, name)

# Generated at 2022-06-11 10:44:49.365443
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    m = RoleMetadata()
    data = dict(allow_duplicates=False, dependencies=[
        {
            'role': 'test',
            'name': 'test',
            '_role_path': '/root/ansible-role-test'
        }
    ])
    result = m.deserialize(data)
    assert result == None


# Generated at 2022-06-11 10:44:59.010127
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    data = {
        'allow_duplicates': True,
        'dependencies': [['name', 'role_path']]
    }
    role_metadata = RoleMetadata.load(data, owner=None)
    my_serialized_role_metadata = role_metadata.serialize()
    for key in my_serialized_role_metadata:
        assert key in data



# Generated at 2022-06-11 10:45:05.992985
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize(dict(
        allow_duplicates=True,
        dependencies=[dict(
            name="some-dep",
            src="some-dep",
            version="0.1"
        )]
    ))
    assert m._allow_duplicates
    assert m._dependencies[0].name == "some-dep"
    assert m._dependencies[0].src == "some-dep"
    assert m._dependencies[0].version == "0.1"


# Generated at 2022-06-11 10:45:14.455638
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    dep1 = dict(role = "some_role")
    dependencies = [dep1]

# Generated at 2022-06-11 10:45:24.642024
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class MockRole():
        def __init__(self):
            self._role_collection = None
            self._play = {}
            self._role_path = ""
            self._role_name = ""

    class MockDependency():
        def __init__(self, name):
            self.name = name

    test_data = {'allow_duplicates': False,
                 'dependencies': [MockDependency('mock_role_name'),
                                  {'name': 'mock_role_name_2', 'version': 'v2.3.2'}]}

    test_role = MockRole()
    test_obj = RoleMetadata(owner=test_role)
    test_obj.deserialize(test_data)
    assert getattr(test_obj, 'allow_duplicates') == False


# Generated at 2022-06-11 10:45:25.647450
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass


# Generated at 2022-06-11 10:46:23.570467
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta = {'dependencies': [{'role': 'my.role'}]}
    m = RoleMetadata.load(meta, None)
    assert isinstance(m, RoleMetadata)
    assert len(m.dependencies) == 1
    assert m.dependencies[0].role == 'my.role'

    with pytest.raises(AnsibleParserError):
        meta = {'dependencies': 'foobar'}
        m = RoleMetadata.load(meta, None)

# Generated at 2022-06-11 10:46:24.527624
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test if load method of metadata class works
    RoleMetadata.load({})

# Generated at 2022-06-11 10:46:26.691289
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    serialized_data = metadata.serialize()
    assert 'allow_duplicates' in serialized_data
    assert 'dependencies' in serialized_data


# Generated at 2022-06-11 10:46:29.180283
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    a = RoleMetadata()
    a._allow_duplicates = True
    a._dependencies = ['foo', 'bar']
    assert a.serialize() == {'allow_duplicates': True, 'dependencies': ['foo', 'bar']}

# Generated at 2022-06-11 10:46:32.757569
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['d1', 'd2', 'd3']
    )
    rm = RoleMetadata()
    rm.deserialize(data)

    assert rm._allow_duplicates == True
    assert rm._dependencies == ['d1', 'd2', 'd3']

# Generated at 2022-06-11 10:46:36.674849
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Create instance of RoleMetadata
    metadata = RoleMetadata()

    # Try to deserialize data
    try:
        metadata.deserialize(dict())
    except AnsibleParserError as e:
        # Check exception message
        assert str(e) == "Expected role dependencies to be a list."
    else:
        assert False, "AnsibleParserError not raised"



# Generated at 2022-06-11 10:46:37.380145
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass

# Generated at 2022-06-11 10:46:44.130842
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager.extra_vars = dict()
    variable_manager.options_vars = dict()
    role_definition = RoleDefinition()
    role_definition.name = 'testRole'
    role_definition._role_path = 'test/path'
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                src= 'some.galaxy.role,version,name',
                other_vars= "here"
            )
        ]
    )

# Generated at 2022-06-11 10:46:48.229703
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    r = RoleMetadata.load({"allow_duplicates": True, "dependencies": [{"role": "role1", "other_attr": "other1"}, {"role": "role2"}]}, None)
    assert r.allow_duplicates is True
    assert isinstance(r.dependencies, list)
    assert isinstance(r.dependencies[0], RoleInclude)

# Generated at 2022-06-11 10:46:48.665338
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-11 10:48:56.730749
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    d = dict(
        allow_duplicates = True,
        dependencies = [
            'role1',
            {
                'role': 'role2',
                'use_kernel': False,
                'some_var': 'some_value'
            },
            {
                'role': 'role3',
                'use_kernel': False,
                'some_var': 'some_value'
            },
            'name=role4'
        ]
    )
    m = RoleMetadata.load(d, None)
    assert m.dependencies[0].get_name() == 'role1'
    assert m.dependencies[1].get_name() == 'role2'
    assert m.dependencies[2].get_name() == 'role3'

# Generated at 2022-06-11 10:48:59.615316
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == {}
    assert role_metadata._argument_specs == {}
    assert role_metadata._owner == None
    # TODO: Add unit test for owner


# Generated at 2022-06-11 10:49:07.050477
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    play_source = dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        roles = [
          'common',
          'webservers',
          'monitoring',
        ]
    )

    play = Play().load(play_source, variable_manager=None, loader=None)
    play._variable_manager = None
    play._loader = None
    play_context = PlayContext()
    play_context._play = play
    host = play_context.hostvars = {}
