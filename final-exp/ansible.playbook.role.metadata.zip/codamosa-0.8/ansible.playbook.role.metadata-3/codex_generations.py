

# Generated at 2022-06-11 10:39:18.190355
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role = RoleMetadata()
    role.deserialize(data)
    assert role._allow_duplicates == data['allow_duplicates']
    assert role._dependencies == data['dependencies']

# Generated at 2022-06-11 10:39:28.670700
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata().deserialize(dict(allow_duplicates='yes', dependencies=[])) == \
            {'allow_duplicates': True, 'dependencies': []}
    assert RoleMetadata().deserialize(dict(allow_duplicates='True', dependencies=[])) == \
            {'allow_duplicates': True, 'dependencies': []}
    assert RoleMetadata().deserialize(dict(allow_duplicates='no', dependencies=[])) == \
            {'allow_duplicates': False, 'dependencies': []}
    assert RoleMetadata().deserialize(dict(allow_duplicates='False', dependencies=[])) == \
            {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:39:29.660826
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass


# Generated at 2022-06-11 10:39:37.573347
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    data = {
        "galaxy_info": {
            "author": "John Doe",
            "description": "foo role",
            "company": "ACME Corporation",
            "license": "GPLv2",
            "min_ansible_version": "2.2",
            "platforms": [],
            "categories": [],
        },
        "dependencies": ["test.role","test.role"],
        "allow_duplicates": True
    }
    role = Role(name="test.role")
    r = RoleMetadata(role)
    r.load(data)
    result = r.serialize()
    assert result['dependencies'] == ["test.role","test.role"]
    assert result['allow_duplicates']

# Generated at 2022-06-11 10:39:48.722732
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # test load_list_of_roles
    from ansible.playbook.play_context import PlayContext

    class LoaderMock():
        def load_from_file(self, f):
            if f == 'dummy_role_src':
                return dict(
                    name='dummy_role_name',
                    dependencies=[
                        dict(
                            src='dummy_role_src'
                        )
                    ]
                )
            else:
                return dict(
                    name=f,
                    dependencies=[]
                )

    def test_load_list_of_roles(roles, loader=LoaderMock()):
        # construct fake role
        class FakeRole:
            def __init__(self, role_data):
                self._role_data = role_data


# Generated at 2022-06-11 10:39:53.510293
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r_meta = RoleMetadata()
    r_meta.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert r_meta._allow_duplicates == True
    assert r_meta._dependencies == ['role1', 'role2']



# Generated at 2022-06-11 10:40:02.014825
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta_obj = RoleMetadata()
    allow_duplicates = True
    dependencies = [{'name': 'nginx'}, {'name':'redis'}]

    data = dict(
        allow_duplicates=allow_duplicates,
        dependencies=dependencies
    )

    role_meta_obj.deserialize(data)
    assert role_meta_obj.allow_duplicates == allow_duplicates
    assert role_meta_obj.dependencies == dependencies
    assert role_meta_obj.dependencies[0].get('name') == 'nginx'
    assert role_meta_obj.dependencies[1].get('name') == 'redis'

# Generated at 2022-06-11 10:40:07.101289
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[dict(src='test')]
    )
    role = RoleMetadata().load(data, owner=None)
    actual = role.serialize()
    expected = dict(
        allow_duplicates=True,
        dependencies=[dict(src='test')]
    )
    assert actual == expected


# Generated at 2022-06-11 10:40:15.400881
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Test constructor of class RoleMetadata and common ones
    '''
    # Test only constructor
    meta = RoleMetadata()
    assert isinstance(meta, RoleMetadata)
    

    # Test common methods
    meta = RoleMetadata(owner="a")
    assert meta.serialize() == dict(
            allow_duplicates=meta._allow_duplicates,
            dependencies=meta._dependencies
        )
    meta.deserialize(dict(
            allow_duplicates=True,
            dependencies=[1, 3]
        ))
    assert meta._allow_duplicates == True
    assert meta._dependencies == [1, 3]



# Generated at 2022-06-11 10:40:23.667149
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = [{'name':'name','role':'role','src':'src','scm':'scm','version':'version','path':'path','private':False}]
    serialize = role_metadata.serialize()
    assert ('dependencies' in serialize)
    assert ('allow_duplicates' in serialize)
    assert (serialize['dependencies'] == [{'name':'name','role':'role','src':'src','scm':'scm','version':'version','path':'path','private':False}])
    assert (serialize['allow_duplicates'] == False)


# Generated at 2022-06-11 10:40:35.672128
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    obj = RoleMetadata()
    obj._allow_duplicates = True
    obj._dependencies = [
        {'role': 'test1'},
        {'role': 'test2'}
    ]
    expected = {
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'test1'},
            {'role': 'test2'}
        ]
    }
    actual = obj.serialize()
    assert expected == actual

# Generated at 2022-06-11 10:40:42.932743
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # initialize a GalaxyInfo object for test
    from ansible.playbook.galaxy_data import GalaxyInfo
    g = GalaxyInfo()

    # current role
    from ansible.playbook.role import Role
    role = Role()
    role._role_path = "/current/role/path"

    from ansible.playbook.play import Play
    play = Play()
    play._file_name = "/play/file/name"

    # galaxy info dict

# Generated at 2022-06-11 10:40:54.704617
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import ansible.playbook.role.definition

    # This test needs to have data created in the obj_role_metadata variable
    # and it should not be empty in order to be successful
    class DS(object):
        def __init__(self, data=None):
            self._data = data

        def get(self, key, default=None):
            return self._data.get(key, default)

    obj_role_metadata = DS({'dependencies': [{'src': 'git+https://github.com/collections/dependency-role'}]})

    # Create a RoleMetadata object with owner set
    class Owner(object):
        def __init__(self):
            self._role_path = None
            self.collections = [None]
            self._play = None
            self._role_collection = None


# Generated at 2022-06-11 10:40:56.731879
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Given a RoleMetadata
    data = {
        'allow_duplicates': False,
        'dependencies': [{
            'role': 'x111',
        }]
    }
    role = RoleMetadata()

    # When deserialize is called
    role.deserialize(data)

    # Then the method should return normally
    pass

# Generated at 2022-06-11 10:41:03.639174
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from collections import namedtuple
    from ansible.inventory.host import Host
    from ansible.parsing import vault
    from ansible.vars import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    RoleMetadata=RoleMetadata()
    fake_loader=namedtuple("fake_loader", "sorted_dir")
    fake_namespace=namedtuple("fake_namespace", "namespace")
    fake_group=Group()
    fake_inventory=InventoryManager(loader=fake_loader, sources=[""])
    fake_inventory.get_group = lambda x,y: fake_group
    fake_variable_manager=VariableManager(host_list=[], inventory=fake_inventory)

# Generated at 2022-06-11 10:41:10.097817
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Class RoleMetadata:
    # def deserialize(self, data):
    # setattr(self, 'allow_duplicates', data.get('allow_duplicates', False))
    # setattr(self, 'dependencies', data.get('dependencies', []))
    r = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['a', 'b', 'c']}
    r.deserialize(data)
    assert r.allow_duplicates == True
    assert r.dependencies == ['a', 'b', 'c']

# Generated at 2022-06-11 10:41:13.008552
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    m.deserialize(data)
    assert m.allow_duplicates == False
    assert m.dependencies == []

# Generated at 2022-06-11 10:41:16.142923
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta.allow_duplicates = True
    meta.dependencies = ['one', 'two']
    assert meta.serialize() == dict(allow_duplicates=True, dependencies=['one', 'two'])

# Generated at 2022-06-11 10:41:23.519701
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Role():
        def get_name():
            return "My name"
    role_metadata = RoleMetadata(Role())
    assert role_metadata.serialize()["allow_duplicates"] == False
    assert role_metadata.serialize()["dependencies"] == []

    serialized = {"dependencies" : [], "allow_duplicates" : True}
    role_metadata.deserialize(serialized)
    assert role_metadata.serialize()["allow_duplicates"] == True
    assert role_metadata.serialize()["dependencies"] == []


# Generated at 2022-06-11 10:41:24.400986
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata.load(data={}, owner=None)

# Generated at 2022-06-11 10:41:36.608226
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata(owner=None)
    assert role._allow_duplicates == False
    assert role._dependencies == []

# Generated at 2022-06-11 10:41:39.885771
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    loader=None
    variable_manager=None
    yaml_data = {'my_var': {'value': 1}}
    owner = RoleMetadata(owner='whatever')
    result = RoleMetadata.load(yaml_data, owner, variable_manager, loader)
    expected_result = RoleMetadata(owner='whatever')
    expected_result._load_data(yaml_data, variable_manager, loader)
    assert result == expected_result

# Generated at 2022-06-11 10:41:50.290851
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.errors import AnsibleParserError
    from collections import namedtuple
    from ansible.runner.return_data import ReturnData

    Role = namedtuple('Role', ['name', '_role_path'])
    role = Role('test', '/home/user/roles/test')

    r = RoleMetadata()
    r._owner = role

    #test with dependencies and allow_duplicates
    r.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert getattr(r, 'allow_duplicates') == True
    dependencies = getattr(r, 'dependencies')
    assert len(dependencies) == 2
    assert isinstance(dependencies[0], ReturnData)
    assert isinstance(dependencies[1], ReturnData)

# Generated at 2022-06-11 10:42:00.361344
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role

    role_spec = dict(
        name='test_role'
    )
    role = Role.load(role_spec)

# Generated at 2022-06-11 10:42:02.802728
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    metadata = RoleMetadata.load({"dependencies": []}, None)
    assert metadata.dependencies == []
    assert metadata.allow_duplicates == False

# Generated at 2022-06-11 10:42:13.783902
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    role_definition = RoleDefinition()
    role_definition._role_path = '/path/to/role'
    role_definition._role_collection = None

    ri = RoleInclude()
    ri._role_path = '/path/to/role'
    ri._role_collection = None
    ri._role_name = 'role'

    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = [role_definition, ri]
    role_metadata._owner = role_definition


# Generated at 2022-06-11 10:42:18.222794
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    role.dependencies = ['some_role']

    expected_serialized = dict(
        allow_duplicates=True,
        dependencies=['some_role']
    )

    assert role.serialize() == expected_serialized



# Generated at 2022-06-11 10:42:26.873642
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    role.dependencies = [
        {'role': 'some_role', 'path': '/some/path/some_role'},
        {'role': 'some_role2', 'path': '/some/path/some_role2'}
    ]
    data = role.serialize()
    assert data['allow_duplicates'] == True
    assert len(data['dependencies']) == 2
    assert 'some_role' in data['dependencies'][0]['role']
    assert '/some/path/some_role' in data['dependencies'][0]['path']
    assert 'some_role2' in data['dependencies'][1]['role']

# Generated at 2022-06-11 10:42:27.358181
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:42:34.793632
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    role.dependencies = [
        dict(
            name='common',
            src='http://github.com/user/common.git'
        )
    ]
    serialized = role.serialize()
    assert serialized['dependencies'] == [
        dict(
            name='common',
            src='http://github.com/user/common.git'
        )
    ]


# Generated at 2022-06-11 10:43:05.623337
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {"allow_duplicates": True, "dependencies": []}
    role_metadata_obj = RoleMetadata().deserialize(data)
    serialized_data = role_metadata_obj.serialize()
    assert serialized_data == data

# Generated at 2022-06-11 10:43:12.847833
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}

    # Verify that the deserialization from data works.
    # If it does, then the allow_duplicates and dependencies
    # attributes of the role_metadata object will have been
    # set, and we'll get the correct assertion when we test
    # for equality
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == data['allow_duplicates']
    assert role_metadata.dependencies == data['dependencies']


# Generated at 2022-06-11 10:43:23.170574
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook import PlayBook
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionRequirement

    config = AnsibleCollectionConfig(paths=[])
    loader = config.get_loader()
    collection = AnsibleCollectionRequirement.from_string('ansible.builtin')

    loader.resolve(collection)
    role = loader.get(collection, 'copy')
    play = PlayBook(loader=loader, variable_manager={})

    m = RoleMetadata(owner=role).load(role.metadata, owner=role, variable_manager=play._variable_manager, loader=play._loader)
    assert m.dependencies == []
    assert m.allow_duplicates == False

if __name__ == "__main__":
    test_

# Generated at 2022-06-11 10:43:26.701948
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    rmd.allow_duplicates = True
    rmd.dependencies = ["foo", "bar"]
    assert rmd.serialize() == {"allow_duplicates": True, "dependencies": ["foo", "bar"]}

# Generated at 2022-06-11 10:43:30.558503
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    t = RoleMetadata()
    t.deserialize(dict(allow_duplicates=True, dependencies=[]))
    assert(t._allow_duplicates == True)
    assert(t._dependencies == [])
    assert(t._owner is None)


# Generated at 2022-06-11 10:43:39.530118
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.loader import find_plugin

    file_name = "/root/ansible/lib/ansible/plugins/loader.py"
    file_name1 = os.path.realpath(file_name)

    print(os.path.dirname(file_name1))

    path_base = os.path.dirname(file_name1)
    print(path_base)


# Generated at 2022-06-11 10:43:48.371172
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    mock_owner = MockOwnerClass()
    mock_loader = MockLoaderClass()

    from ansible.parsing.yaml.dumper import AnsibleDumper
    test_data = dict(
        allow_duplicates=False,
        dependencies=[
            dict(role='foo', name='bar', path='/path/to/foo-role',
                 src='mycompany.mynamespace.mycollection.foo-bar', version='1.0',
                 collection='mycompany.mynamespace.mycollection'),
            dict(role='baz', path='/path/to/baz-role',
                 src='mycompany.mynamespace.mycollection.baz', version='1.0',
                 collection='mycompany.mynamespace.mycollection')
        ]
    )

# Generated at 2022-06-11 10:43:51.569375
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = dict(
        allow_duplicates=False,
        dependencies=[],
    )
    m = RoleMetadata().deserialize(data)
    assert m.allow_duplicates == data['allow_duplicates']
    assert m.dependencies == data['dependencies']

# Generated at 2022-06-11 10:44:01.186966
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # If a default value is specified, left blank (or set null) in yaml, serialize should return a dict with the default value.
    assert RoleMetadata(None).serialize() == dict(allow_duplicates=False, dependencies=[])
    assert RoleMetadata(None, allow_duplicates=True).serialize() == dict(allow_duplicates=True, dependencies=[])
    assert RoleMetadata(None, dependencies=['test']).serialize() == dict(allow_duplicates=False, dependencies=['test'])
    assert RoleMetadata(None, allow_duplicates='test').serialize() == dict(allow_duplicates=True, dependencies=[])
    assert RoleMetadata(None, dependencies='').serialize() == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-11 10:44:11.928245
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    definition = RoleDefinition.load({'role': 'foo',
                                      'collection': 'examples'},
                                     role_name='foo',
                                     collection_name='examples',
                                     role_path='/tmp/roles/examples/foo',
                                     parent_role=None)
    definition.collections = ['examples']
    assert definition is not None

    loader = None
    variable_manager = None

# Generated at 2022-06-11 10:44:47.303018
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.definition import RoleDefinition

    # Define mock objects for testing
    fake_loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.options_vars = {}
    inventory = Inventory(loader=fake_loader, variable_manager=variable_manager, host_list=[])
    play_context = PlayContext(defaults=dict(), remote_addr=None)
    tqm = None
    block = None
    play

# Generated at 2022-06-11 10:44:51.324542
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    testMetadata = RoleMetadata()
    testMetadata.deserialize(dict(allow_duplicates=True, dependencies=['dependencies1', 'dependencies2', 'dependencies3']))
    assert testMetadata._allow_duplicates == True
    assert len(testMetadata._dependencies) == 3

# Generated at 2022-06-11 10:44:56.540841
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    data = {
        'collections': [],
        'name': 'test-role',
    }
    rd = RoleDefinition.load(data)
    rd.get_role_path = lambda: '/test-role'
    rd.set_metadata(RoleMetadata(owner=rd))

    assert rd.serialize() == data

# Generated at 2022-06-11 10:45:05.732187
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test case using a mode with all arguments specified
    role_metadata = RoleMetadata(owner=None)
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = ['foo', 'bar']
    assert role_metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=['foo', 'bar']
    )
    # Test case using a mode with not all arguments specified
    role_metadata = RoleMetadata(owner=None)
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = []
    assert role_metadata.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )

# Generated at 2022-06-11 10:45:11.605784
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Unit test for method serialize of class RoleMetadata
    '''
    test_object_temp = RoleMetadata(owner=None)

    setattr(test_object_temp, 'allow_duplicates', False)
    setattr(test_object_temp, 'dependencies', [])

    test_object_expect = {'allow_duplicates': False, 'dependencies': []}

    result = test_object_temp.serialize()

    assert result == test_object_expect

    # clean up
    del test_object_temp

# Generated at 2022-06-11 10:45:12.407318
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert 0



# Generated at 2022-06-11 10:45:15.189348
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook import Play

    play = Play()
    role = RoleMetadata(owner=play)
    assert role._allow_duplicates == False
    assert role._dependencies == []

# Generated at 2022-06-11 10:45:25.602242
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    role_definition = RoleDefinition("#my/role/path", {"name": "my-role"}, ['localhost'], vm)
    role_metadata = RoleMetadata(owner=role_definition)

    role_metadata.deserialize({"allow_duplicates":True, "dependencies":[]})
    assert(role_metadata.allow_duplicates is True)
    assert(role_metadata.dependencies == [])
    assert(role_metadata.galaxy_info is None)

    role_metadata.deserialize({"allow_duplicates":False, "dependencies":[]})
    assert(role_metadata.allow_duplicates is False)

# Generated at 2022-06-11 10:45:35.357762
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.base import Base
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    try:
        RoleMetadata(owner=None)
    except TypeError as e:
        assert(e.args[0] == "__init__() takes exactly 2 arguments (1 given)")

    try:
        Base(owner=None)
    except TypeError as e:
        assert(e.args[0] == '__init__() takes exactly 3 arguments (1 given)')


# Generated at 2022-06-11 10:45:36.666082
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    TODO: Add unit tests
    """
    return True

# Generated at 2022-06-11 10:46:42.315202
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """ test RoleMetadata.deserialize() """
    m = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(role='common', src='git+https://github.com/example/ansible-role-common.git')
        ]
    )
    m.deserialize(data)
    assert m._allow_duplicates == True
    assert type(m._dependencies) == list
    assert m._dependencies == [
            dict(role='common', src='git+https://github.com/example/ansible-role-common.git')
        ]



# Generated at 2022-06-11 10:46:43.531197
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role.allow_duplicates is False
    assert role.dependencies == []

# Generated at 2022-06-11 10:46:44.187779
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata(owner="Owner")


# Generated at 2022-06-11 10:46:46.878392
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # If RoleMetadata.serialize was not implemented, the below code would raise an error
    dict_with_desired_fields = {'allow_duplicates': False, 'dependencies': []}
    assert RoleMetadata().serialize() == dict_with_desired_fields

# Generated at 2022-06-11 10:46:48.465839
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    fields = m.serialize()
    assert fields['allow_duplicates'] is False
    assert fields['dependencies'] == []

# Generated at 2022-06-11 10:46:55.756995
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.six import PY3

    class Play():
        pass

    class Playbook():
        pass

    class Role():
        pass

    class RoleInclude():
        pass

    class VariableManager():
        pass

    class DataLoader():
        pass

    class RoleMetadata():
        _owner = Role()
        _play = Play()
        _play._playbook = Playbook()
        _variable_manager = VariableManager()
        _loader = DataLoader()
        _dep_results = RoleInclude()

    role = Role()

    role_definition = RoleDefinition.load([{'role': 'test_role'}], role._role_collection, variable_manager=VariableManager(), loader=DataLoader(), play=Play(), play_ds=dict())

# Generated at 2022-06-11 10:47:01.538210
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from collections import namedtuple
    from ansible.playbook.role import Role
    fake_loader_class = namedtuple("FakeLoaderClass", ["path_dwim_relative"])
    fake_loader = fake_loader_class("path_dwim_relative")
    fake_role = Role("test_RoleMetadata_load", mock.Mock())
    fake_role._role_path = os.path.abspath("test_file")
    fake_role._role_collection = None
    data = {"galaxy_info":{}}
    RoleMetadata.load(data, fake_role, loader=fake_loader)

# Generated at 2022-06-11 10:47:06.073698
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Unit test for deserialize method of class RoleMetadata
    '''
    m = RoleMetadata()
    m.deserialize({'dependencies': [], 'allow_duplicates': False})
    m.deserialize({'dependencies': 'dependencies', 'allow_duplicates': True})
    m.deserialize({'dependencies': False, 'allow_duplicates': False})
    m.deserialize({'dependencies': 'dependencies', 'allow_duplicates': 'allow_duplicates'})

# Generated at 2022-06-11 10:47:06.838690
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-11 10:47:12.379362
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test without option 'allow_duplicates'
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'dependencies': [ 'test' ]})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == [ 'test' ]

    # Test with option 'allow_duplicates'
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'dependencies': [ 'test' ], 'allow_duplicates': True})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == [ 'test' ]