

# Generated at 2022-06-11 10:39:16.057080
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.include import RoleInclude

    role_meta = RoleMetadata()
    role_meta.deserialize(dict(allow_duplicates=True,
                               dependencies=[RoleInclude()]))
    assert role_meta._allow_duplicates
    assert isinstance(role_meta._dependencies[0], RoleInclude)


# Generated at 2022-06-11 10:39:26.759738
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {
        'dependencies': [
            {'role': 'common', 'some_parameter': 'some_value'},
            'geerlingguy.jenkins'
        ],
        'allow_duplicates': True
    }
    from ansible.playbook.role import Role
    rolename = "rolename"
    rolepath = "/path/to/roles/rolename"
    role = Role.load(data=data, role_name=rolename, role_path=rolepath)
    m = RoleMetadata.load(data=data, owner=role)
    assert m.allow_duplicates
    assert len(m.dependencies) == 2
    assert len(m.dependencies[0]._role_name) == 1
    assert len(m.dependencies[1]._role_name)

# Generated at 2022-06-11 10:39:35.917547
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    my_role = Role(name='test_role', play=Play().load({'name': 'test_play', 'hosts': 'all'}))
    my_role._role_path = '/tmp/test_role'
    my_role._role_collection = None
    my_role._role_defs = {'test_role': RoleDefinition.load({'name': 'test_role'}, play=my_role._play, role_path='/tmp/test_role')}

# Generated at 2022-06-11 10:39:37.533508
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test with no arguments
    RoleMetadata()

    # Test with arguments
    RoleMetadata(owner=object)

# Generated at 2022-06-11 10:39:43.726712
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata(owner=None)
    data = dict(
        allow_duplicates=True,
        dependencies=['ansible.builtin', 'ansible.legacy']
    )
    result = m.deserialize(data)
    assert m.allow_duplicates == True
    assert 'ansible.builtin' in m.dependencies
    assert 'ansible.legacy' in m.dependencies


# Generated at 2022-06-11 10:39:48.538477
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': False,
        'dependencies': ['foo', 'bar']
    })
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == ['foo', 'bar']

# Generated at 2022-06-11 10:39:49.160880
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass

# Generated at 2022-06-11 10:39:59.721599
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.plugins.loader import role_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple
    from ansible.template import Templar
    import ansible.constants as C
    import ansible.playbook.play
    import ansible.playbook.helpers
    import ansible_collections.community.general.tests.unit.compat.mock as mock
    from ansible.errors import AnsibleParserError

# Generated at 2022-06-11 10:40:00.655464
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role

# Generated at 2022-06-11 10:40:03.859192
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    owner = {}
    variable_manager = {}
    loader = {}
    data = {}
    rm = RoleMetadata.load(data, owner, variable_manager, loader)
    assert isinstance(rm, RoleMetadata)

# Generated at 2022-06-11 10:40:15.116712
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[1,2,3]
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

    assert role_metadata.allow_duplicates == data.get('allow_duplicates')
    assert role_metadata.dependencies == data.get('dependencies')

# Generated at 2022-06-11 10:40:23.712953
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [],
        pre_tasks = [],
        tasks = [],
        post_tasks = [],
        handlers = [],
    ), variable_manager=None, loader=None)

    assert RoleMetadata.load(dict(
        allow_duplicates = True
    ), owner=play, variable_manager=None, loader=None).allow_duplicates is True

# Generated at 2022-06-11 10:40:25.135979
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert isinstance(metadata, RoleMetadata)

# Generated at 2022-06-11 10:40:35.013482
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role

    import yaml

    test_data = """
---
allow_duplicates: false
dependencies:
- {role: davide, name: alessandra}
- {name: giulio}
- role: marcello
"""

    # The following is required for RoleMetadata.load to work
    parent_role = Role()
    parent_role._role_path = 'test_role'

    # Testing that the method load of class RoleMetadata returns a new RoleMetadata object
    role_metadata = RoleMetadata.load(yaml.safe_load(test_data), owner=parent_role)
    assert isinstance(role_metadata, RoleMetadata)

    # Testing that the method load of class Role

# Generated at 2022-06-11 10:40:39.625507
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import json
    data = json.loads("""{
        "allow_duplicates": false,
        "dependencies": []
    }""")
    r = RoleMetadata().deserialize(data)
    assert r['allow_duplicates'] == False
    assert r['dependencies'] == []
    assert r == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:40:41.653391
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = { 'dependencies' : [{'role': 'common', 'some_variable': 42}, 'foobar'] }
    assert RoleMetadata.load(data, None)

# Generated at 2022-06-11 10:40:44.835141
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    obj.deserialize(data)
    assert obj.allow_duplicates is False
    assert obj.dependencies == []

# Generated at 2022-06-11 10:40:49.337258
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    roleMetadata = RoleMetadata()
    roleMetadata.deserialize(dict(
        allow_duplicates=True,
        dependencies=["role1", "role2"]
    ))

    assert roleMetadata.allow_duplicates == True
    assert roleMetadata.dependencies == ["role1", "role2"]

# Generated at 2022-06-11 10:40:56.693186
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class Role():
        def __init__(self, role_path):
            self._role_path = role_path
    role_metadata = RoleMetadata.load({}, Role('/test'))
    serialized_data = role_metadata.serialize()
    assert serialized_data
    assert 'allow_duplicates' in serialized_data
    assert 'dependencies' in serialized_data

# Generated at 2022-06-11 10:41:02.929940
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata(owner=None)

    data = dict(
        allow_duplicates=True,
        dependencies=[1, 2],
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates is True
    assert role_metadata.dependencies == [1, 2]

    data = dict(
        allow_duplicates=False,
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == []

# Generated at 2022-06-11 10:41:25.876897
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play, Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleMapping
    yaml_data = dict(
        allow_duplicates=False,
        dependencies=[
            dict(
                name="common",
                src="ansible.posix"
            )
        ]
    )
    yaml_data = AnsibleMapping(yaml_data)

    # create a RoleDefinition object
    role_definition = RoleDefinition()
    role_definition._role_path = "tests/unit/data_files/roles/test-role"
    role_definition._role_name = "test-role"

    # create a RoleMetadata object

# Generated at 2022-06-11 10:41:27.187802
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    print("Test loading data for RoleMetadata class")
    print("FIXME")

# Generated at 2022-06-11 10:41:34.014255
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    class Owner(object):

        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    mock_data = {
        'allow_duplicates': False,
        'dependencies': [
            'test1',
            'test2',
        ],
    }

    owner = Owner('test')
    role = RoleMetadata.load(mock_data, owner)
    print(role.serialize())



# Generated at 2022-06-11 10:41:37.528276
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    result = role_metadata.serialize()
    assert isinstance(result, dict)
    assert result['allow_duplicates'] == False
    assert result['dependencies'] == []


# Generated at 2022-06-11 10:41:39.961645
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = { 'allow_duplicates': False, 'dependencies': [] }
    m.deserialize(data)
    assert m._allow_duplicates == data['allow_duplicates']
    assert m._dependencies == data['dependencies']

# Generated at 2022-06-11 10:41:40.738096
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:41:41.269465
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-11 10:41:46.197184
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    setattr(RoleMetadata, '_allow_duplicates', False)
    setattr(RoleMetadata, '_dependencies', [])
    data = dict()
    data['allow_duplicates'] = True
    data['dependencies'] = "some_role"
    res = RoleMetadata.deserialize(data)
    assert res == (True, "some_role")


# Generated at 2022-06-11 10:41:57.094450
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # test a simple example
    metadata = RoleMetadata.load(dict(
        dependencies = [dict(name='first'), dict(name='second')],
        allow_duplicates = False
    ), None)
    assert metadata.allow_duplicates == False
    assert len(metadata.dependencies) == 2

    # test no dependencies
    metadata = RoleMetadata.load(dict(allow_duplicates = False), None)
    assert metadata.allow_duplicates == False
    assert len(metadata.dependencies) == 0

    # test empty dependencies field
    metadata = RoleMetadata.load(dict(allow_duplicates = False, dependencies=[]), None)
    assert metadata.allow_duplicates == False
    assert len(metadata.dependencies) == 0

# Generated at 2022-06-11 10:42:04.497373
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    owner = 'test'
    files_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'files')
    meta_path = os.path.join(files_dir, 'meta_good.yml')
    meta_dict = {'allow_duplicates': False,
                 'dependencies': [{'role': 'role1'}, {'role': 'role2'}]}
    with open(meta_path, 'r') as f:
        data = yaml.safe_load(f)
    rolemetadatatest = RoleMetadata(owner=owner)
    test1 = rolemetadatatest.load(data=data, owner=owner)
    test2 = test1.serialize()

# Generated at 2022-06-11 10:42:41.353257
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    class stub_owner():

        def __init__(self):
            # Create a stub
            self._ext_vars = {'x': '1', 'y': '2'}

    stub_role_path = './roles/'
    stub_owner_instance = stub_owner()
    stub_data1 = {'allow_duplicates': 'False', 'dependencies': ['name1', 'name2'], 'x': '{{ x }}'}
    stub_data4 = {'allow_duplicates': 'True', 'dependencies': ['name3', 'name4'], 'y': '{{ y }}'}

    # For the case that 'data' is empty
    assert RoleMetadata().deserialize(dict()) == None

    # For the case that 'data' is a valid object

# Generated at 2022-06-11 10:42:49.525323
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates":True,"dependencies":[{"role": "test", "tasks_from": "other"}]})
    assert role_metadata.deserialize({"allow_duplicates":True,"dependencies":[{"role": "test", "tasks_from": "other"}]})._dependencies[0].role == "test"
    assert role_metadata.deserialize({"allow_duplicates":True,"dependencies":[{"role": "test", "tasks_from": "other"}]})._dependencies[0].tasks_from == "other"
    assert role_metadata.deserialize({"allow_duplicates":True,"dependencies":[{"role": "test", "tasks_from": "other"}]})._allow_duplicates == True

# Generated at 2022-06-11 10:42:59.419883
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader
    from ansible.utils.display import Display
    import ansible.constants as C
    from ansible.errors import AnsibleError

    d = Display()
    c = C.DEFAULT_COLLECTIONS_PATHS
    C.DEFAULT_COLLECTIONS_PATHS = []
    role_names = ['newrole', 'not.a.collection']


# Generated at 2022-06-11 10:43:00.067985
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-11 10:43:03.584040
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role._allow_duplicates == False
    assert role._dependencies == []
    assert role._galaxy_info == None
    assert role._argument_specs == {}

# Generated at 2022-06-11 10:43:07.579608
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Setup
    m = RoleMetadata(owner=None)

    # Exercise
    result = m.serialize()

    # Assert
    assert m._allow_duplicates == result['allow_duplicates']
    assert m._dependencies == result['dependencies']

# Generated at 2022-06-11 10:43:15.357123
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    metadata = {"dependencies": [{"role": "foo"}], "allow_duplicates": False}
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    role = Role()
    role._role_path = "./"
    role._role_collection = "ansible_collections.mycollection"
    play = Play()
    play.collections = ["ansible_collections.mycollection"]
    m = RoleMetadata.load(metadata, owner=role, variable_manager=VariableManager, loader=DataLoader())
    assert m._allow_duplicates is False
    assert m._dependencies[0].get_name() == 'foo'

# Generated at 2022-06-11 10:43:25.671699
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_RoleMetadata = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': [
            {
                'name': 'role1',
                'version': '1.0'
            },
            {
                'name': 'role2',
                'version': '1.0',
                'collection': 'ansible.collections.ns.test'
            },
            {
                'name': 'role3',
                'version': '1.0',
                'src': 'sample.role'
            }
        ]
    }
    test_RoleMetadata.deserialize(data)
    assert test_RoleMetadata.allow_duplicates == True

# Generated at 2022-06-11 10:43:35.191060
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.role.definition import RoleDefinition

    mock_atom = type('MockAtom', (object,), {
        '_load_list_of_roles': lambda self, roles: [RoleDefinition(name, 'maybe', 'anonymous') for name in roles]
    })

    atom_mock = mock_atom()

    r1 = RoleMetadata.load(dict(dependencies=['a', 'b', 'c']), atom_mock)
    assert r1.dependencies == [RoleDefinition(name, 'maybe', 'anonymous') for name in ['a', 'b', 'c']]


# Generated at 2022-06-11 10:43:44.245346
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import Task
    from ansible.playbook.play import Play
    from ansible.playbook.group import Group

    # create a mock role for the subdir
    play = Play()
    play._ds = dict(
        name="dummy",
        play_hosts=[],
        vars=[],
        groups=[],
        handlers=[],
        tasks=[])
    play._basedir = '/tmp'

    role = Role()
    role._role_name = 'dummy'
    role._role_path = '/tmp/dummy'
    role._play = play
    role._play_context = play._play_context

# Generated at 2022-06-11 10:44:38.360706
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    if __name__ == '__main__':
        role_metadate = RoleMetadata()
        print("Test Constructor is passed")

# Begin unit test for constructor of class RoleMetadata
test_RoleMetadata()

# Generated at 2022-06-11 10:44:40.631374
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner='owner')
    assert m is not None
    assert m._owner == 'owner'
    assert m.dependencies == []

# Generated at 2022-06-11 10:44:43.186499
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {
        'allow_duplicates': False,
        'dependencies': ['role1', 'role2']
    }
    result = RoleMetadata().serialize()
    assert result == data


# Generated at 2022-06-11 10:44:49.373564
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role  # TODO: Fix circular import
    role = Role()
    role.name = 'test name'
    role.role_path = 'test path'

# Generated at 2022-06-11 10:44:53.482642
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Unit test for method serialize of class RoleMetadata
    """
    instance = RoleMetadata()
    instance.allow_duplicates = False
    instance.dependencies = []

    result = instance.serialize()
    assert result['allow_duplicates'] == False
    assert result['dependencies'] == []


# Generated at 2022-06-11 10:45:04.418015
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 10:45:11.251135
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    meta_yml_data = {
        'allow_duplicates': True,
        'dependencies': [
            'role1',
            'role2',
            'role3'
        ]
    }

    attr = RoleMetadata()
    attr.deserialize(meta_yml_data)
    assert attr.allow_duplicates == True
    assert isinstance(attr.dependencies, list)
    assert len(attr.dependencies) == 3
    assert attr.dependencies[0] == 'role1'
    assert attr.dependencies[1] == 'role2'
    assert attr.dependencies[2] == 'role3'

# Generated at 2022-06-11 10:45:15.072979
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': False,
        'dependencies': []
    })

    assert(role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []})


# Generated at 2022-06-11 10:45:21.645341
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import json
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Setup test data
    md_data = dict(
        allow_duplicates=False,
        dependencies=list(dict(role=AnsibleUnsafeText('nginx')),)
    )
    md_data_json = json.dumps(md_data)

    a = RoleMetadata()
    a.deserialize(md_data)

    assert json.dumps(a.serialize()) == md_data_json

# Generated at 2022-06-11 10:45:31.118984
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    result = RoleMetadata.deserialize(dict(dependencies=[1, 2, 3]))
    assert(result.get('dependencies') == [1,2,3])
    assert(result.get('allow_duplicates') == False)

    result = RoleMetadata.deserialize(dict(dependencies=None, allow_duplicates=True))
    assert(result.get('dependencies') == [])
    assert(result.get('allow_duplicates') == True)

    try:
        result = RoleMetadata.deserialize(dict(dependencies='not a list'))
    except Exception as err:
        assert(type(err) == AnsibleParserError)



# Generated at 2022-06-11 10:47:29.195242
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-11 10:47:39.093084
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    import pytest
    from collections import namedtuple

    class Mock_Role(Base):
        '''
        A class that mocks the old class Role that has been removed
        '''

        _role_collection = FieldAttribute(isa='RoleCollection')
        _role_path = FieldAttribute(isa='string')
        _role_path = FieldAttribute(isa='string')
        _role_name = FieldAttribute(isa='string')

        def __init__(self, **kwargs):
            self._role_collection = kwargs.get('role_collection', '')
            self._role_path = kwargs.get('role_path', '')
            self._role_name = kwargs.get('role_name', '')


# Generated at 2022-06-11 10:47:43.135342
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata(owner = None)
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['roleOne', 'roleTwo']})

    assert(role_metadata.allow_duplicates == True)
    assert(role_metadata.dependencies == ['roleOne', 'roleTwo'])

# Generated at 2022-06-11 10:47:51.948738
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.network_os = 'ios'
    play_context.remote_addr = 'localhost'
    play_context.remote_user = None
    play_context.become = None
    play_context.become_method = None
    play_context.become_user

# Generated at 2022-06-11 10:47:54.439638
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role.get_dependencies() == []

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-11 10:47:58.118678
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    role_meta.deserialize({'allow_duplicates': False,
                           'dependencies': []})

    assert role_meta._allow_duplicates == False
    assert len(role_meta._dependencies) == 0

# Generated at 2022-06-11 10:48:00.378146
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = False
    m.dependencies = []
    assert m.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:48:06.986186
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    my_attributes = {'dependencies': ['roles/require_role']}
    my_role = FakeRoleInclude(attributes=my_attributes)
    my_role_metadata = RoleMetadata(owner=my_role)
    my_role_metadata._dependencies = [my_role]
    ansible_result = my_role_metadata.serialize()
    assert ansible_result['dependencies'] == my_role_metadata._dependencies



# Generated at 2022-06-11 10:48:11.161909
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Testing RoleMetadata constructor")
    role_metadata = RoleMetadata()
    dir(role_metadata)
    assert(role_metadata._allow_duplicates == False)
    assert(role_metadata._dependencies == [])
    assert(role_metadata._galaxy_info == {})
    assert(role_metadata._argument_specs == {})
    print("Testing RoleMetadata constructor succeesfully\n")

# Generated at 2022-06-11 10:48:14.358474
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    rm=RoleMetadata(owner=None)
    assert rm._allow_duplicates == False
    assert rm._dependencies == []
    rm.deserialize({'dependencies': [1,2]})
    assert rm._allow_duplicates == False
    assert rm._dependencies == [1,2]