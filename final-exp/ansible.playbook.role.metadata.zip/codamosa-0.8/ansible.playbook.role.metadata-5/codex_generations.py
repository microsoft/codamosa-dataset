

# Generated at 2022-06-11 10:39:16.056644
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create an instance of RoleMetadata
    role = RoleMetadata()
    # Test deserialize method
    role.deserialize({})
    assert role.allow_duplicates == False
    assert role.dependencies == []

# Generated at 2022-06-11 10:39:18.524750
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m._allow_duplicates == False
    assert m._dependencies == []



# Generated at 2022-06-11 10:39:19.113017
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-11 10:39:22.920126
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.filters import Filters
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.objects import AnsibleMapping
    import inspect

    host = HostV

# Generated at 2022-06-11 10:39:29.846762
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {
        'allow_duplicates' : True,
        'dependencies'     : ['example', 'example2']
    }
    rm = RoleMetadata(owner=None)
    assert not rm._owner
    assert rm.allow_duplicates == False
    assert rm._dependencies == []
    rm.deserialize(data)
    assert rm.allow_duplicates == True
    assert rm._dependencies == ['example', 'example2']
    assert rm.serialize() == data

# Generated at 2022-06-11 10:39:33.796630
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=True, dependencies=['test1', 'test2']))
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['test1', 'test2']


# Generated at 2022-06-11 10:39:35.519668
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata.__name__ == 'RoleMetadata'

# ===== RUNNING TESTS =====
test_RoleMetadata()

# Generated at 2022-06-11 10:39:37.744772
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    meta.deserialize(dict(allow_duplicates=True, dependencies=[]))
    assert meta.allow_duplicates is True

# Generated at 2022-06-11 10:39:43.957505
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Test: test_RoleMetadata")
    r = RoleMetadata()
    assert not r._owner
    assert r._allow_duplicates == False
    assert r._dependencies == []
    assert r._galaxy_info == None
    assert r.passwords == {}
    assert r.connection_info == {}
    assert r.defaults == {}
    assert r.vars == {}
    assert r.templates == {}

# Generated at 2022-06-11 10:39:46.703875
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r._allow_duplicates == False
    assert r._dependencies == list()



# Generated at 2022-06-11 10:39:57.780191
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata(owner=None)
    data = {
       'allow_duplicates': True,
       'dependencies': ["foo", "bar"]
    }
    r.deserialize(data)
    assert r.allow_duplicates == True
    assert r.dependencies == ["foo", "bar"]


# Generated at 2022-06-11 10:40:01.441772
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_name = 'test_role'
    data = {'functions': {}}
    rm = RoleMetadata.load(data, role_name)
    assert rm.serialize()['allow_duplicates'] == False
    assert rm.serialize()['dependencies'] == []

# Generated at 2022-06-11 10:40:06.577189
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Unit test for method serialize of class RoleMetadata
    '''
    role_metadata = RoleMetadata()
    role_metadata.dependencies = [1, 2, 3, 4]
    role_metadata.allow_duplicates = True
    assert role_metadata.serialize() == dict(
        dependencies=[1, 2, 3, 4],
        allow_duplicates=True
    )

# Generated at 2022-06-11 10:40:12.218926
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    instance = RoleMetadata()
    data     = dict(
            allow_duplicates=True,
            dependencies=[1, 2]
        )
    instance.deserialize(data)
    assert hasattr(instance, 'allow_duplicates')
    assert hasattr(instance, 'dependencies')
    assert instance.allow_duplicates == True
    assert instance.dependencies == [1, 2]

# Generated at 2022-06-11 10:40:15.116863
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-11 10:40:16.785644
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({"dependencies":[{"name":"geerlingguy.apache"}]})
    assert r.dependencies[0].get_name() == "geerlingguy.apache"

# Generated at 2022-06-11 10:40:17.255418
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:40:18.879512
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata()
    assert a._dependencies == []
    assert a._allow_duplicates is False

# Generated at 2022-06-11 10:40:22.970833
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Data():
        pass

    data = Data()
    data.get = lambda x, y: y
    m = RoleMetadata()
    m.deserialize(data)
    assert(m.allow_duplicates == False)
    assert(m.dependencies == [])

# Generated at 2022-06-11 10:40:26.440909
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert not role_metadata.allow_duplicates
    assert role_metadata.dependencies == []

# Generated at 2022-06-11 10:40:44.789634
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # FIXME: This test is incomplete.
    r = RoleMetadata(owner=None)
    s = r.serialize()
    assert(s == {})

    r.load_data({'dependencies': [
        {'role': 'foo'},
        {'role': 'bar', 'version': '1.2'}
    ]})

    s = r.serialize()
    assert(s == {
        'dependencies': [
           {'role': 'foo'},
           {'role': 'bar', 'version': '1.2'}
        ]
    })

# Generated at 2022-06-11 10:40:47.778322
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
  roleMetadata = RoleMetadata()
  roleMetadata.deserialize({"dependencies":[]})
  assert roleMetadata.allow_duplicates == False
  assert roleMetadata.dependencies == []

# Generated at 2022-06-11 10:40:59.988640
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook import Playbook

    # Create a new RoleMetadata Object
    owner = RoleInclude.load({"role":"role_name"})

    data = {"allow_duplicates": True, "dependencies": [
            {"role": "a_role"},
            {"role": "b_role"},
            {"role": "c_role"}]}

    role_metadata = RoleMetadata.load(data, owner)
    assert role_metadata.allow_duplicates == True
    assert len(role_metadata.dependencies) == 3

# Generated at 2022-06-11 10:41:04.063276
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data1 = { "dependencies": [] }
    data2 = { "allow_duplicates": True, "dependencies": []}
    m = RoleMetadata().deserialize(data1)
    assert m.allow_duplicates == False
    assert m.dependencies == []
    m = RoleMetadata().deserialize(data2)
    assert m.allow_duplicates == True
    assert m.dependencies == []

# Generated at 2022-06-11 10:41:09.582242
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_data = dict()
    test_data['metadata'] = dict()
    test_data['metadata']['dependencies'] = None
    test_data['metadata']['allow_duplicates'] = None
    role_metadata = RoleMetadata(owner=None)
    role_metadata.deserialize(test_data['metadata'])
    result = role_metadata.serialize()
    assert result['allow_duplicates'] == False
    assert result['dependencies'] == []

# Generated at 2022-06-11 10:41:16.939349
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test with default values
    obj = RoleMetadata._serialize_class()
    data = obj.serialize()
    assert data['allow_duplicates'] == False
    assert data['dependencies'] == []

    # Test with provided values
    obj2 = RoleMetadata._serialize_class()
    obj2.allow_duplicates = True
    obj2.dependencies = [{'role': 'example.role'}]
    data2 = obj2.serialize()
    assert data2['allow_duplicates'] == True
    assert data2['dependencies'] == [{'role': 'example.role'}]


# Generated at 2022-06-11 10:41:24.443156
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    class TestDependencies(Base):
        def serialize(self):
            return 'This is a test'

    class TestGalaxyInfo(Base):
        def serialize(self):
            return 'This is a test'

    rm = RoleMetadata()

    # Testing serialize with data
    rm.allow_duplicates = True
    rm.dependencies = [TestDependencies()]
    rm.galaxy_info = TestGalaxyInfo()
    result = rm.serialize()
    assert result == {'allow_duplicates': True, 'dependencies': ['This is a test']}

# Generated at 2022-06-11 10:41:34.487858
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.six import PY3
    def test_data():
        return {
            'allow_duplicates': True,
            'dependencies': [
                {'name': 'common', 'src': 'git+https://git.example.org/repos/common.git', 'version': 'v1.0'},
                {'name': 'webservers', 'src': 'git+https://git.example.org/repos/webservers.git', 'version': 'master'}
            ],
            'redirects': [
                {'name': 'common', 'collection': 'namespaceA.common'}
            ]
        }

# Generated at 2022-06-11 10:41:39.208320
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test for constructor of class RoleMetadata
    '''
    # Initialize RoleMetadata class
    r = RoleMetadata()

    assert(r._allow_duplicates == False)
    assert(r._dependencies == [])
    assert(isinstance(r._galaxy_info, dict))
    assert(isinstance(r._argument_specs, dict))

# Generated at 2022-06-11 10:41:44.831616
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    This unittest checks if the deserialize method of RoleMetadata
    converts the role dependencies from old to new format
    '''
    from ansible.playbook.role import Role

    role_data = {
        'name': 'testrole',
        'allow_duplicates': False,
        'dependencies': [
            {
                'role': 'foo',
                'other_vars': "here"
            },
            {
                'role': 'bar',
                'other_vars': "here"
            },
        ]
    }
    role = Role.load(role_data, None)
    result = role.metadata.dependencies

# Generated at 2022-06-11 10:42:01.024062
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import collections

    RoleMetadata.load({'dependencies': ['src', 'version', 'name']}, None) == RoleMetadata.load({'dependencies': ['src', 'version', 'name']}, None)
    assert RoleMetadata.load({'dependencies': ['src', 'version', 'name']}, None) == \
        RoleMetadata(owner = None,
                     dependencies = [{'src': 'src', 'version': 'version', 'name': 'name'}],
                     allow_duplicates = False,
                     galaxy_info = None,
                     argument_specs = {})

    #This one fails because of the assert statement which compares a list to a tuple.
    #RoleMetadata.load({'dependencies': ()}, None) == RoleMetadata.load({'dependencies': {}}, None)
    #assert RoleMetadata.

# Generated at 2022-06-11 10:42:08.438450
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
  x = RoleMetadata()
  x.deserialize({'dependencies': [{'role': 'test1'}]})
  assert x.dependencies is not None
  assert x.dependencies[0] == {'role': 'test1'}
  x.deserialize({'allow_duplicates': True})
  assert x.allow_duplicates is True
  x.deserialize({'allow_duplicates': False})
  assert x.allow_duplicates is False

# Generated at 2022-06-11 10:42:13.352147
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata().deserialize({
        'dependencies': ['role1', 'role2'],
        'allow_duplicates': True,
    })

    serialized_data = role_metadata.serialize()
    assert serialized_data['allow_duplicates'] is True
    assert serialized_data['dependencies'] == ['role1', 'role2']

# Generated at 2022-06-11 10:42:23.213877
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader.collections import load_collections
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.playbook.collectionsearch import CollectionSearch

    search_paths = []
    loader = AnsibleCollectionLoader()
    search_paths.append(os.path.join(os.path.dirname(__file__), '../../../test/collections/ansible_collections/namespace1/collection1/roles'))
    loader.set_collection_paths(search_paths)
    search = CollectionSearch(loader)

    role_name = "role_name"

# Generated at 2022-06-11 10:42:29.654191
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from units.mock.loader import DictDataLoader

    # create a data loader

# Generated at 2022-06-11 10:42:40.762816
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.collections.ansible.legacy import IMPORT_ROOT

    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from units.mock.loader import DictDataLoader

    # Create a fake collection (ansible.foo) which in this case is located
    # under the fake root directory IMPORT_ROOT.
    collection_root = os.path.join(IMPORT_ROOT, "ansible", "foo")

    # Create a fake role (baz) within the fake collection
    role_root = os.path.join(collection_root, "roles", "baz")
    metadata_

# Generated at 2022-06-11 10:42:49.127422
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.play_context import PlayContext

    data = {
        'allow_duplicates': True,
        'dependencies': [
            {'name': 'tomcat', 'version': '2.0'}
        ]
    }

    r = Role()
    r._role_name = 'test'
    r._role_path = __file__
    r._role_collection = ''
    r._play = None
    r._blocks = []
    r._default_vars = dict()
    r

# Generated at 2022-06-11 10:42:56.524496
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude

    role_metadata = RoleMetadata.load({"dependencies": []}, None)

    assert isinstance(role_metadata, RoleMetadata)
    assert len(role_metadata._dependencies) == 0

    role_metadata = RoleMetadata.load({"dependencies": [{'role': 'myrole', 'someoption': 'somevalue'}]}, None)

    assert isinstance(role_metadata, RoleMetadata)
    assert len(role_metadata._dependencies) == 1
    assert isinstance(role_metadata._dependencies[0], RoleInclude)

# Generated at 2022-06-11 10:42:57.473961
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
  RoleMetadata.deserialize()

# Generated at 2022-06-11 10:43:08.383616
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    import os

# Generated at 2022-06-11 10:43:30.558977
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata()
    setattr(role_meta, 'allow_duplicates', True)
    setattr(role_meta, 'dependencies', [])
    data = role_meta.serialize()
    assert data['allow_duplicates'] == True
    assert data['dependencies'] == []

# Generated at 2022-06-11 10:43:39.529489
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    rdef = RoleDefinition()
    rdef._role_name = 'role1'
    t = Task()
    rdef._task_blocks = [Block([t])]
    play = Play()
    play._role_include = RoleInclude(play, role_name='role2')
    rdef._task_blocks = [Block([TaskInclude(play, 'role2')])]
    rmeta = RoleMetadata()
    serialized_object = rmeta.serialize()
    assert serialized_object

# Generated at 2022-06-11 10:43:46.257291
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Arrange
    class GalaxyInfo:
        pass
    GalaxyInfoObject = GalaxyInfo()
    # Act
    fld = RoleMetadata()
    fld._allow_duplicates = False
    fld._dependencies = [1, 2, 3]
    fld._galaxy_info = GalaxyInfoObject
    fld._argument_specs = { 'verbose': { 'required': True } }
    serialized = fld.serialize()
    # Assert
    assert serialized['allow_duplicates'] == False
    assert serialized['dependencies'] == [1, 2, 3]

# Generated at 2022-06-11 10:43:48.564875
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta_data = RoleMetadata()
    assert role_meta_data

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-11 10:43:51.790995
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    yaml_input = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata = RoleMetadata().deserialize(yaml_input)

    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-11 10:44:01.827558
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task
    from ansible.playbook.task.include import Include
    from ansible.module_utils.six import PY3

    # Prepare pretend source
    class TestRole(Role):
        pass

    class TestPlay(Play):
        pass

    r = TestRole()
    p = TestPlay()
    p._entries = [r]
    p._ds = dict()

    fake_loader = None
    fake_variable_manager = None

    # test RoleMetadata.load
    test_data = dict()

    # fail: role name is not a dict
    # should fail with a AnsibleParserError exception

# Generated at 2022-06-11 10:44:12.761466
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata object for testing.
    test_obj = RoleMetadata()
    # Deserialize empty data.
    test_obj.deserialize({})
    # Check if allow_duplicates is False.
    assert test_obj.allow_duplicates is False
    # Check if dependencies is an empty list.
    assert test_obj.dependencies == []
    # Deserialize data with some data.
    test_obj.deserialize({"allow_duplicates": True, "dependencies": ["my_dependency"]})
    # Check if allow_duplicates is True.
    assert test_obj.allow_duplicates is True
    # Check if dependencies is ['my_dependency']
    assert test_obj.dependencies == ['my_dependency']


# Generated at 2022-06-11 10:44:21.762028
# Unit test for method serialize of class RoleMetadata

# Generated at 2022-06-11 10:44:26.778001
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_data = '''---
dependencies:
  - {role: common, some_parameter: foo}
'''
    data = yaml.safe_load(test_data)
    rmd = RoleMetadata(owner=None).load_data(data, variable_manager=None, loader=None)
    rmd.__init__()
    assert 1==1

# Generated at 2022-06-11 10:44:36.656715
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata.load(
        {
            'allow_duplicates': True,
            'dependencies': [
                {
                    'role': 'rolename',
                    'variables': {
                        'var1': 'value1',
                        'var2': 'value2',
                    }
                },
                {
                    'role': 'rolename2',
                    'tags': ['tag1', 'tag2']
                }
            ]
        },
        owner=None
    )


# Generated at 2022-06-11 10:45:01.678709
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': True, 'dependencies': ['apache', 'java', 'mysql']}

    r_obj = RoleMetadata()
    r_obj.deserialize(data)

    assert r_obj.allow_duplicates is True
    assert r_obj.dependencies == ['apache', 'java', 'mysql']

# Generated at 2022-06-11 10:45:06.539540
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    test_data = dict(
        test_metadata=dict(
            allow_duplicates=True,
            dependencies=['base.role']
        )
    )

    metadata.deserialize(test_data.get('test_metadata'))
    assert metadata.allow_duplicates == True
    assert metadata.dependencies ==['base.role']

# Generated at 2022-06-11 10:45:14.996271
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    lDataLoader = DataLoader()
    vManager = VariableManager()
    mock_role = RoleDefinition.load({'name': 'mock'},
        loader=lDataLoader, variable_manager=vManager, use_role_defaults=False)
    rMetadata = RoleMetadata(owner=mock_role)

    # Initialisation
    assert len(rMetadata) == 0
    assert rMetadata._allow_duplicates == False
    assert rMetadata._dependencies == list()

    # deserialize

# Generated at 2022-06-11 10:45:22.982926
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            'example1',
            'example2'
        ]
    )
    # when
    obj = RoleMetadata(owner=None)
    obj.deserialize(data)
    obj.serialize()
    result = obj.serialize()
    # then
    assert 'allow_duplicates' in result
    assert result['allow_duplicates']
    assert 'dependencies' in result
    assert 'example1' in result['dependencies']
    assert 'example2' in result['dependencies']
# endtest

# Generated at 2022-06-11 10:45:25.977250
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    This is a test for constructor of class RoleMetadata.
    """
    rmd = RoleMetadata()
    assert rmd._allow_duplicates == False
    assert rmd._dependencies == []

# Generated at 2022-06-11 10:45:29.732543
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    Unit test to test the constructor of class RoleMetadata.
    """
    rolmeta = RoleMetadata()
    # test default constructor values
    assert rolmeta._allow_duplicates is False
    assert rolmeta._dependencies == []

# Generated at 2022-06-11 10:45:32.822706
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    Loading a RoleMetadata object will fill in default values
    """
    role_meta = RoleMetadata()
    assert role_meta._allow_duplicates == False
    assert role_meta._dependencies == []

# Generated at 2022-06-11 10:45:41.729548
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    # test serialize
    # create a test play context without passwords and without tasks as we don't need to run it
    pc = PlayContext()
    pc.network_os = 'junos'
    pc.remote_addr = '1.1.1.1'
    pc.port = 22
    pc.remote_user = 'test'

    # create a test play without tasks to create a role context
    p = Play().load({
        'name': 'test',
        'hosts': 'all',
        'connection': 'local',
        'gather_facts': 'no',
        'tasks': []
    }, variable_manager=None, loader=None)

   

# Generated at 2022-06-11 10:45:44.012759
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # basic test to verify RoleMetadata constructor
    roleMetadata1 = RoleMetadata()
    # another test that provides the additional parameters
    roleMetadata2 = RoleMetadata(owner="owner")


# Generated at 2022-06-11 10:45:51.749875
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()

    # no need to create a mock instance of AnsibleRole here,
    # as the owner of RoleMetadata is not used in the method serialize.
    # Usage of mock.ANY does not work here, because the other attributes
    # of the instance RoleMetadata are not set (they would result in
    # an exception in method load_data).
    role._allow_duplicates = True
    role._dependencies = [1, 2, 3]

    # method serialize returns a dictionary
    assert isinstance(role.serialize(), dict)

    # method serialize returns the expected dictionary
    expected_dict = {"allow_duplicates": True,
                     "dependencies": [1, 2, 3]}
    assert role.serialize() == expected_dict



# Generated at 2022-06-11 10:46:41.817228
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager

    loader = DictDataLoader({
        "role_name/meta/main.yml": """
allow_duplicates: yes
dependencies:
  - some_role_name
    """
    })

    variable_manager = VariableManager()

    m = RoleMetadata.load(
        data=loader.load_from_file("role_name/meta/main.yml"),
        owner=None,
        variable_manager=variable_manager,
        loader=loader
    )

    assert m._allow_duplicates
    assert len(m._dependencies) == 1

    # TODO: Load test is failing with the below commented
    # assert m._dependencies[0]._role_name == 'some_role_name'

# Generated at 2022-06-11 10:46:48.402722
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Test if the serialize method of the RoleMetadata class works as expected.
    '''

    # Create an instance of class RoleMetadata
    role_metadata = RoleMetadata()

    # Set the dependencies attribute of the object
    role_metadata.dependencies = 'test'

    # Set the allow_duplicates attribute of the object
    role_metadata.allow_duplicates = 'test'

    # Create a dictionary with the expected result of serialize
    expected_serialized_dict = dict(
        allow_duplicates='test',
        dependencies='test'
    )

    # Serialize the object
    actual_serialized_dict = role_metadata.serialize()

    # Assert that the actual result is equal to the expected result
    assert actual_serialized_dict == expected_serialized_dict

# Unit test

# Generated at 2022-06-11 10:46:52.593581
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    def test_helpers(allow_duplicates, dependency_list):
        result = RoleMetadata(allow_duplicates=allow_duplicates, dependencies=dependency_list).serialize()
        assert result == {'allow_duplicates': allow_duplicates, 'dependencies': dependency_list}

    yield test_helpers, True, []
    yield test_helpers, False, []
    yield test_helpers, True, ['foo']
    yield test_helpers, False, ['foo', 'bar']

# Generated at 2022-06-11 10:46:55.611200
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata(owner=None)

    data = dict(allow_duplicates=True, dependencies=[])
    obj.deserialize(data)
    assert obj.allow_duplicates == True
    assert obj.dependencies == []

# Generated at 2022-06-11 10:46:57.853153
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'dependencies': [{'name': 'common', 'src': 'common'}]})
    assert 'dependencies' in dir(role_metadata)

# Generated at 2022-06-11 10:47:02.778972
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    main_yaml = {
        'allow_duplicates': True,
        'dependencies': [
            'role1',
            'role2',
        ],
    }
    role_metadata = RoleMetadata()
    role_metadata.load({}, None)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    role_metadata.load(main_yaml, None)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-11 10:47:07.713289
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from units.mock.loader import DictDataLoader

    yaml_data = '''
---
dependencies:
  - foo
  - bar
'''

    loader = DictDataLoader({
        'meta/main.yml': yaml_data,
    })
    metadata = RoleMetadata.load(yaml_data, owner=None, loader=loader)

    assert metadata.get_dependencies() == ['foo', 'bar']
    assert metadata.get_allow_duplicates() == False
    assert metadata.get_galaxy_info() is None

# Generated at 2022-06-11 10:47:10.271698
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies=['role1', 'role2', 'role3'])
    meta.deserialize(data)
    assert meta.allow_duplicates == True
    assert meta.dependencies == ['role1', 'role2', 'role3']

# Generated at 2022-06-11 10:47:17.962513
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    p = Play().load({'name': 'test_play', 'hosts': 'all'}, variable_manager={}, loader=None)
    role_name = 'test_role'
    path = '.'
    role = RoleDefinition.load(role_name, path, p, loader=None, collection_list=[])
    r = RoleMetadata(owner=role)
    assert r._role == role_name
    assert r._role_path == path
    assert r._dependencies == []
    assert r._galaxy_info == {}



# Generated at 2022-06-11 10:47:18.808417
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata.load({})

# Generated at 2022-06-11 10:48:53.253715
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
  from ansible.playbook.play import Play
  from ansible.playbook.role.definition import RoleDefinition
  from ansible.playbook.role.meta import RoleMetadata
  from ansible.playbook.role.include import RoleInclude

  pb = Play().load(dict(
    name = "Ansible Play",
    hosts = "all",
    gather_facts = "no",
    roles = [ RoleInclude(name='role1')  ]
  ))
  pb.post_validate()

  rm = RoleMetadata.load(dict(
    dependencies = [{ 'role': 'role2'}], 
  ), owner=pb.get_roles()[0])
  assert len(rm.dependencies) == 1
  assert isinstance(rm.dependencies[0], RoleDefinition)
  assert rm

# Generated at 2022-06-11 10:48:53.818593
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-11 10:49:00.578146
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # Test 1: Invalid role dependency format
    logger_disabled = []

    def deactivated_logger_function():
        logger_disabled.append(True)

    logger_disabled.append(False)
    RoleMetadata.load({
        'dependencies': [
            'should_not_be_a_string',
            { 'should_have_a_name_or_role_key': 1 }
        ]
    }, owner=None)
    assert logger_disabled[0]

    # Test 2: Valid role dependency format
    logger_disabled.append(False)
    RoleMetadata.load({
        'dependencies': [
            'should_be_a_string',
            { 'name': 'should_be_a_dict_with_a_name_or_role_key' }
        ]
    }, owner=None)


# Generated at 2022-06-11 10:49:06.185519
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

    data['allow_duplicates'] = True
    data['dependencies'] = set(['a', 'b', 'c'])
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == ['a', 'b', 'c']