

# Generated at 2022-06-11 10:39:17.703523
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['common', 'webservers']}
    role_meta._deserialize_roledeps = lambda role_deps: role_deps
    role_meta.deserialize(data)
    assert role_meta.allow_duplicates == True
    assert role_meta.dependencies == ['common', 'webservers']

# Generated at 2022-06-11 10:39:21.942531
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import os
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Instantiate RoleMetadata
    role_metadata = RoleMetadata()

    # Attempt to set owner to invalid type
    try:
        role_metadata._owner = 'mock_owner'
    except AssertionError as error:
        assert error.args[0] == 'role_metadata._owner should be RoleDefinition not mock_owner'

    # Set owner to valid type
    role_metadata._owner = RoleDefinition()
    assert isinstance(role_metadata._owner, RoleDefinition)

    # Test 'load' method where data is not a dictionary

# Generated at 2022-06-11 10:39:29.240769
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.meta import RoleMetadata

    role_metadata = RoleMetadata(owner=None)
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['role1', 'role2']

    serialized_role = role_metadata.serialize()

    assert serialized_role is not None
    assert serialized_role.get('allow_duplicates') is True
    assert serialized_role.get('dependencies') == ['role1', 'role2']


# Generated at 2022-06-11 10:39:34.535777
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True,
                               'dependencies': [{'role': 'database'},
                                                {'role': 'webserver'}]})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == [{'role': 'database'},
                                          {'role': 'webserver'}]

# Generated at 2022-06-11 10:39:37.620961
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    expected = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    result = RoleMetadata().serialize()
    assert result == expected, 'test_RoleMetadata_serialize() failed!'
    print('RoleMetadata().serialize() returned expected value')

# Generated at 2022-06-11 10:39:42.793984
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm = RoleMetadata()
    rm.deserialize(dict(allow_duplicates=False, dependencies=[dict(name="role.name")]))
    serialized_data = rm.serialize()
    assert serialized_data['allow_duplicates'] is False
    assert serialized_data['dependencies'] == [dict(name="role.name")]

# Generated at 2022-06-11 10:39:45.497677
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    constructor test of class RoleMetadata
    '''
    f = RoleMetadata()
    assert f is not None

# Generated at 2022-06-11 10:39:51.072547
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Owner object is required as first argument of RoleMetadata constructor. 
    # In this test it is not needed but we must provide something or test will fail.
    r = RoleMetadata(owner="Owner")
    d = dict(
        allow_duplicates=False,
        dependencies=["role1", "role2"]
    )
    assert r.serialize() == d


# Generated at 2022-06-11 10:39:56.840929
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    data = dict(dependencies=[{'role': 'some_role', 'version': 'some_ver'}],
                allow_duplicates=True)
    role_meta.deserialize(data)
    assert data == dict(allow_duplicates=True,
                        dependencies=[{'role': 'some_role', 'version': 'some_ver'}])

# Generated at 2022-06-11 10:40:06.668908
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_path_exists

    from ansible.playbook.role.definition import RoleDefinition

    loader = DictDataLoader({
        "/etc/ansible/roles/role_foo/tasks/main.yml": """\
        - debug:
            var: "role_var"
        """,
        "/etc/ansible/roles/role_foo/meta/main.yml": """\
        dependencies:
        - {role: role_bar, tags: ['bar_tag']}
        """
    })

    # path provided by RoleDefinition
    setattr(loader, "_basedir", "/etc/ansible/roles/role_foo")

    # mock role path

# Generated at 2022-06-11 10:40:22.803892
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()

    data = {'allow_duplicates': True, 'dependencies': ['foo', 'bar']}
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['foo', 'bar']

# Generated at 2022-06-11 10:40:30.195584
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_dep = RoleRequirement.load({'name': 'role_dep_name', 'src': 'role_dep_src', 'sha256sum': 'role_dep_sha256sum',
                                     'version': 'role_dep_version'})
    role_metadata = RoleMetadata()
    setattr(role_metadata, 'allow_duplicates', True)
    setattr(role_metadata, 'dependencies', [role_dep])
    assert role_metadata.serialize() == dict(allow_duplicates=True, dependencies=[role_dep])


# Generated at 2022-06-11 10:40:30.812233
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-11 10:40:35.285589
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import ansible.galaxy.collection
    import ansible.playbook.role
    galaxy_info = ansible.galaxy.collection.GalaxyInfo()
    role = ansible.playbook.role.Role()
    galaxy_info.serialize()
    role.serialize()
    role.deserialize({'name': 'test'})

# Generated at 2022-06-11 10:40:43.257485
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    yaml_text = '''---
      galaxy_info:
        author: example
        description: example
        company: example
        license: MIT
        min_ansible_version: 1.2
        platforms:
          - name: example
            versions:
              - example
        galaxy_tags:
          - example
        dependencies: []
        issue_tracker_url: example
        source_url: example
        role_name: example
      allow_duplicates: false
    '''
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    data = AnsibleLoader(yaml_text, 'test_RoleMetadata_serialize',
                         variable_manager=VariableManager()).get_single_data()

# Generated at 2022-06-11 10:40:46.575085
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    meta = RoleMetadata()
    meta.deserialize(data)
    assert meta.allow_duplicates == False
    assert meta.dependencies == []

# Generated at 2022-06-11 10:40:52.375737
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rm = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['one', 'two', 'three']}
    rm.deserialize(data)
    assert rm.allow_duplicates == True
    assert rm.dependencies == ['one', 'two', 'three']


# Generated at 2022-06-11 10:40:53.195724
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass



# Generated at 2022-06-11 10:41:02.897472
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    r = Role()
    m = RoleMetadata(r)
    task = Task()
    r._tasks = [task]
    assert m.serialize() == {'dependencies': [], 'allow_duplicates': False}
    m = RoleMetadata()
    m._allow_duplicates = True
    task = TaskInclude(name='foo')
    task.from_file = 'bar'
    r._tasks = [task]
    m._dependencies = r._tasks

# Generated at 2022-06-11 10:41:09.900050
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    yaml_data =  \
'''
---
dependencies: []
'''

    galaxy_data = {
        'allow_duplicates': False,
        'dependencies': []
    }

    data = yaml.load(yaml_data)
    role_metadata = RoleMetadata.load(data, None)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

    assert role_metadata.serialize() == galaxy_data
    role_metadata.deserialize(galaxy_data)
    assert role_metadata.serialize() == galaxy_data

# Generated at 2022-06-11 10:41:29.037259
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    #Here We are going to test RoleMetadata class, serialize method
    context = {
        'allow_duplicates': False,
        'dependencies': []
    }
    #create a rolemetada obj
    r = RoleMetadata()
    #the results of method serialize should be a dictionary 
    ansible_return = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    #call the method serialize
    result_serialize = r.serialize()
    #the result of serialize method should be equal context
    assert result_serialize == ansible_return


# Generated at 2022-06-11 10:41:39.367380
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # Windows returns C:\Windows\system32 on PATH lookup
    # PATH lookup on unix returns empty string
    import platform
    if platform.system() == 'Windows':
        import sys
        sys.path.append('C:\\Windows\\system32')

    from ansible.playbook.role_include import RoleInclude
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    import ansible.constants as C


# Generated at 2022-06-11 10:41:41.975007
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    sample = {
        'allow_duplicates': False,
        'dependencies': [],
    }
    r = RoleMetadata().serialize()
    assert sample == r



# Generated at 2022-06-11 10:41:53.092241
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.module_utils.common._collections_compat import Mapping

    def _test(ds, role_name=None, role_path=None, allow_duplicates=False,
              dependencies=list()):
        owner = Role()
        owner._role_name = role_name
        owner._role_path = role_path
        r = RoleMetadata.load(ds, owner)
        assert isinstance(r, RoleMetadata), r
        assert r._owner == owner, r._owner
        assert r._allow_duplicates == allow_duplicates, r._allow_duplicates
        assert len(r._dependencies) == len(dependencies), r._dependencies

# Generated at 2022-06-11 10:41:57.138800
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {'meta': {'foo': 'bar'}}
    role = RoleMetadata(owner=None)
    role.load_from_file('.', 'meta', data)

    assert role.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-11 10:42:00.206487
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates": False, "dependencies": []})
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-11 10:42:06.342859
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    load_data = dict(allow_duplicates=True, dependencies=[])
    obj = RoleMetadata()
    obj.deserialize(data=load_data)
    assert getattr(obj, 'allow_duplicates') == True
    assert getattr(obj, 'dependencies') == []

#     assert getattr(obj, '_dependencies') == []

# Generated at 2022-06-11 10:42:16.322343
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.collection_loader import AnsibleCollectionRef

    test_data = {
        'allow_duplicates': False,
        'dependencies': []
    }

    # No exception should be raised.
    RoleMetadata().deserialize(test_data)

    test_data['dependencies'] = [
        'tomcat',
        {'role': 'common', 'version': 'foo'}
    ]

    # No exception should be raised.
    role_metadata = RoleMetadata().deserialize(test_data)
    assert len(role_metadata.dependencies) == 2
    assert type(role_metadata.dependencies[0]) == RoleInclude

# Generated at 2022-06-11 10:42:18.593675
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    result = RoleMetadata()
    assert result.allow_duplicates == False
    assert result.dependencies == []


# Generated at 2022-06-11 10:42:21.728459
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=False, dependencies=[]))
    assert role_metadata.allow_duplicates == False
    assert len(role_metadata.dependencies) == 0

# Generated at 2022-06-11 10:42:50.232514
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert(r._allow_duplicates == False)
    assert(r._dependencies == [])
    assert(r._galaxy_info == None)
    assert(r._argument_specs == None)

    r = RoleMetadata(owner=None)
    assert(r._allow_duplicates == False)
    assert(r._dependencies == [])
    assert(r._galaxy_info == None)
    assert(r._argument_specs == None)



# Generated at 2022-06-11 10:42:58.279635
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    d = dict(
        allow_duplicates=True,
        dependencies=list(),
    )

    dso = AnsibleBaseYAMLObject(d)
    r = RoleMetadata(owner=None)
    r.deserialize(dso)

    assert r._allow_duplicates == True
    assert type(r._dependencies) == ImmutableList
    assert r._dependencies == list()

# Generated at 2022-06-11 10:43:09.149995
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.roles import Role, IncludeRole
    from ansible.playbook.block import Block
    from ansible.template import Templar

    # RoleMetadata

    # Owner is a Role, but not a IncludeRole
    role = Role()
    role.name = "myrole"
    role._role_path = "/home/roles/myrole"
    role._role_collection = "mycollection"
    role._play = Play()
    role._play._variable_manager = None
    role._play._loader = None
    role._play.contex = PlayContext()

# Generated at 2022-06-11 10:43:16.086585
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta_data = {
        'allow_duplicates': False,
        'dependencies': [
            {
                'src': "geerlingguy.java",
                'version': "2.2.0"
            },
            {
                'role': "src",
                'name': "repo",
                'version': "1.0.0"
            },
            {
                'role': "src",
                'name': "webapp"
            },
            {
                'src': "src",
                'name': "webapp"
            }
        ]
    }

    rm = RoleMetadata()
    rm.deserialize(meta_data)
    assert len(rm.dependencies) == 4
    assert rm.allow_duplicates == False

# Generated at 2022-06-11 10:43:20.874082
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

    assert role_metadata is not None
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info is None
    assert role_metadata._argument_specs == {}


# Generated at 2022-06-11 10:43:30.694601
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_name = RoleMetadata()

# Generated at 2022-06-11 10:43:31.779780
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

# Generated at 2022-06-11 10:43:40.523345
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar

    playbook_path = ''
    loader, inventory, variable_manager = None, None, None

    my_play = Play().load({
        'name': 'my play',
        'hosts': 'localhost',
        'vars': {'var_a': 'foo', 'var_b': 'bar'}
    }, variable_manager=variable_manager, loader=loader)

    play_context = PlayContext(play=my_play)


# Generated at 2022-06-11 10:43:44.009734
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm = RoleMetadata().load({'allow_duplicates': False, 'dependencies': ['a', 'b']})
    assert rm.serialize() == {
        'allow_duplicates': False,
        'dependencies': ['a', 'b']
    }

# Generated at 2022-06-11 10:43:49.463347
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(key1="value1", key2="value2")
    role = RoleMetadata(owner = None)
    role.load_data(data, variable_manager = None, loader = None)
    result = role.serialize()
    assert result == dict(
            allow_duplicates=False,
            dependencies=[],
        ), "Serialisierung der RoleMetadata-Klasse fehlgeschlagen"

test_RoleMetadata_serialize()


# Generated at 2022-06-11 10:44:39.751306
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    # Test calling RoleMetadata() with no parameters.
    r = RoleMetadata()
    assert r.allow_duplicates is False
    assert r.dependencies == []
    assert r.argument_spec == {}

# Generated at 2022-06-11 10:44:47.589809
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    collection_loader = Mock()
    collection_loader.load.return_value = 'collections_path'
    role_loader = Mock()
    role_loader.get_collection_paths.return_value = ['collections_path']
    role_loader.get_role_path.return_value = '/path/to/roles'
    loader = Mock()
    loader.collection_loader = collection_loader
    loader.role_loader = role_loader

    fake_variable_manager = Mock()
   

# Generated at 2022-06-11 10:44:57.331382
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    playbook = Playbook()
    play = Play().load(dict(
        name="play1",
        hosts=["localhost"],
        roles=[
        ],
    ), variable_manager=playbook.get_variable_manager(), loader=playbook._loader)

    role = RoleCollection().load(dict(
        name="myrole",
        default_vars={},
        dependencies={}
    ), variable_manager=playbook._variable_manager, loader=playbook._loader)
    play._included_roles = [role]
    meta = RoleMetadata()

# Generated at 2022-06-11 10:45:07.370578
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata object
    roleMetadata = RoleMetadata()
    # Check the value of the allow_duplicates attribute
    assert roleMetadata.allow_duplicates == False
    # Check the value of the dependencies attribute
    assert roleMetadata.dependencies == []
    # Create a RoleMetadata object
    roleMetadata2 = RoleMetadata()
    # Create some mock data
    data = {'allow_duplicates':  True, 'dependencies':  ['role1', 'role2']}
    # Check the deserialize method
    roleMetadata2.deserialize(data)
    # Check the value of the allow_duplicates attribute
    assert roleMetadata2.allow_duplicates == True
    # Check the value of the dependencies attribute

# Generated at 2022-06-11 10:45:13.500575
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.utils.display import Display
    rolemetadata = RoleMetadata()
    rolemetadata.display = Display()
    rolemetadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert rolemetadata.allow_duplicates == False
    assert len(rolemetadata.dependencies) == 0
    rolemetadata.deserialize({'allow_duplicates': True, 'dependencies': ['otherrole']})
    assert rolemetadata.allow_duplicates == True
    assert len(rolemetadata.dependencies) == 1
    assert rolemetadata.dependencies == ['otherrole']


# Generated at 2022-06-11 10:45:23.872433
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class Play:
        def __init__(self, role_path=None):
            self.hosts = []
            self.roles = []
            self.role_path = role_path

    # We cannot use setUp and tearDown because it will throw error
    # during load_list_of_roles function, so have to create variables
    # and destroy them manually.
    # pylint: disable=unused-variable
    def setUp():
        pass

    def tearDown():
        pass


# Generated at 2022-06-11 10:45:27.899623
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = {'allow_duplicates': True, 'dependencies': ['dep1', 'dep2']}
    role_metadata = RoleMetadata(owner=None).load_data(metadata)
    assert role_metadata.serialize() == metadata


# Generated at 2022-06-11 10:45:37.304594
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    testdata_dict = dict()
    testdata_dict["allow_duplicates"] = False
    testdata_dict["dependencies"] = list()
    testdata_dict["dependencies"].append({"role": "my_role"})
    testdata_dict["dependencies"].append({"role": "my_role2"})

    testdata = dict()
    testdata["allow_duplicates"] = False
    testdata["dependencies"] = list()
    testdata["dependencies"].append( "my_role" )
    testdata["dependencies"].append( "my_role2" )

    rmd = RoleMetadata()
    rmd.deserialize(testdata)

    assert testdata_dict["allow_duplicates"] == rmd.serialize()["allow_duplicates"]

# Generated at 2022-06-11 10:45:40.903972
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    example = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    r = RoleMetadata()
    r.deserialize(example)
    assert r._allow_duplicates == example['allow_duplicates']
    assert r._dependencies == example['dependencies']

# Generated at 2022-06-11 10:45:48.887987
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    # Setup test environent
    variable_manager = None
    loader = None
    play = Play.load({'name': 'test_play', 'connection': 'local'}, variable_manager=variable_manager, loader=loader)
    play.set_loader(loader)
    play.set_variable_manager(variable_manager)
    block = Block()
    block._role_name = 'test_role'
    #
    # Test 1: Test deserialize on an empty object
    #
    data = {}
    rmd

# Generated at 2022-06-11 10:46:23.228429
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies={})
    r.deserialize(data)
    assert (r.allow_duplicates == True)
    assert (r.dependencies == {})

# Generated at 2022-06-11 10:46:26.691367
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    """
    Unit test for constructor of class RoleMetadata
    """

    meta = RoleMetadata()
    assert isinstance(meta, RoleMetadata) is True, 'Instantiation of class RoleMetadata failed'
    assert meta.allow_duplicates is False, 'Instantiation of class RoleMetadata failed'
    assert meta.dependencies is None, 'Instantiation of class RoleMetadata failed'

# Generated at 2022-06-11 10:46:29.178813
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    ds = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    metadata.deserialize(ds)
    assert metadata.allow_duplicates
    assert [] == metadata.dependencies

# Generated at 2022-06-11 10:46:33.593946
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    rd = RoleDefinition()
    ri = RoleInclude()
    rm = RoleMetadata()
    ri.name = "toto"
    rm._dependencies.append(ri)
    assert rm.serialize() == dict(allow_duplicates=None, dependencies=[{"toto": {}}])

# Generated at 2022-06-11 10:46:35.907885
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    metadata._allow_duplicates = False
    metadata._dependencies = []
    assert metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:46:40.769746
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    json_data = {
        'allow_duplicates': False,
        'dependencies': [
            {'src': 'test', 'version': 'test'}
        ]
    }

    role_metadata = RoleMetadata()
    assert role_metadata.deserialize(json_data) is None
    assert role_metadata._allow_duplicates is False
    assert len(role_metadata._dependencies) == 1
    assert role_metadata._dependencies == [{'src': 'test', 'version': 'test'}]

# Generated at 2022-06-11 10:46:47.547859
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class MockGalaxyInfo():
        def __init__(self, p):
            self.path = p

    class MockRole():
        def __init__(self, p, n='name'):
            self.path = p
            self.name = n
            self.play = None
            self.collections = []

    class MockVariableManager():
        def __init__(self, v=None):
            self.vars = v

    class MockLoader():
        def __init__(self, c, d=None):
            self.basedir = c
            self.get_basedir = lambda: self.basedir
            self.data = d

    ###############
    # First, test with an invalid datastructure
    ###############

    # This class is a mock of a class which has a method load

# Generated at 2022-06-11 10:46:51.522565
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    serialized_data = dict(
        allow_duplicates=True,
        dependencies=list()
    )
    role_definition = RoleDefinition.load(serialized_data)
    role_metadata = RoleMetadata(owner=role_definition)
    assert role_metadata.serialize() == serialized_data, "RoleMetadata object serialization deserialization failure"



# Generated at 2022-06-11 10:46:52.101565
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-11 10:46:56.901983
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == []
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['test_dependencies']})
    assert role_metadata.allow_duplicates is True
    assert role_metadata.dependencies == ['test_dependencies']



# Generated at 2022-06-11 10:47:49.880572
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = True
    m.dependencies = [1, 2]
    assert m.serialize() == dict(
        allow_duplicates=True,
        dependencies=[1, 2]
    )

# Generated at 2022-06-11 10:47:59.182040
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import json
    import textwrap
    from unittest import TestCase
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import _get_collection_roles_data

    from ansible.module_utils.six import PY3

    def task(name, action, args=None):
        args = args or []
        return

# Generated at 2022-06-11 10:48:08.738224
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    m = RoleMetadata()
    meta_file = dict(
        allow_duplicates=False,
        dependencies=[dict(role='foo')],
        galaxy_info=dict(
            author='me',
            company='none',
            description='no desc',
            license='anything',
            min_ansible_version='1.2',
            platforms=[( 'any', dict( platform_version='1.2' ) )],
            project_url='http://a.b.c',
            repository='https://',
            tags=[ 'a', 'b' ],
            version='1.2'
        )
    )
    meta = m.load(meta_file, RoleDefinition())
    assert meta.allow_duplicates == False

# Generated at 2022-06-11 10:48:10.772169
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()

    assert m.allow_duplicates is False
    assert len(m.dependencies) == 0
    assert m.galaxy_info is None

# Generated at 2022-06-11 10:48:11.469461
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Constructor of class RoleMetadata is not implemented")

# Generated at 2022-06-11 10:48:19.036568
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': [{'role': 'test_name', 'some_connection_var': 'value'}]}
    meta.deserialize(data)
    assert meta._allow_duplicates == True
    assert isinstance(meta._dependencies, list)
    assert isinstance(meta._dependencies[0], RoleRequirement)

    data = {'dependencies': [{'role': 'test_name', 'some_connection_var': 'value'}]}
    meta.deserialize(data)
    assert meta._allow_duplicates == False
    assert isinstance(meta._dependencies, list)
    assert isinstance(meta._dependencies[0], RoleRequirement)

# Generated at 2022-06-11 10:48:22.587890
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata(owner=None)
    assert m.serialize() == dict(allow_duplicates=False, dependencies=[])

    m = RoleMetadata(owner=object())
    m._allow_duplicates = True
    m._dependencies = [1, 2, 3]
    assert m.serialize() == dict(allow_duplicates=True, dependencies=[1, 2, 3])


# Generated at 2022-06-11 10:48:26.339207
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role

    r = Role()
    m = r.metadata
    assert isinstance(m, RoleMetadata)

    assert m.allow_duplicates is False
    assert len(m.dependencies) == 0

    # test direct constructor
    m2 = RoleMetadata()
    assert m2.allow_duplicates is False
    assert len(m2.dependencies) == 0

# Generated at 2022-06-11 10:48:33.267775
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class MyRole(object):
        def __init__(self):
            self._role_path = 'path/to/role'
            self._play = 'play'
            self._role_collection = None
            self.collections = []

    role = MyRole()
    metadata = RoleMetadata(owner=role)
    assert(metadata._owner == role)
    assert(metadata.owner == role)
    assert(metadata.allow_duplicates == False)
    assert(metadata.dependencies == [])
    assert(metadata.galaxy_info == [])
    assert(metadata.argument_specs == {})
    assert(metadata._ds == {})

# Generated at 2022-06-11 10:48:33.847358
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()