

# Generated at 2022-06-11 10:39:23.429557
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Create a new Play object to be used in all tests
    import os
    import tempfile
    from ansible.playbook.play import Play
    plugin_loader = None
    variable_manager = None
    loader = None
    play = Play.load(dict(
        name="test",
        hosts=['localhost'],
        gather_facts=False,
        tasks=[dict(action=dict(module="ping"))]
    ), loader=loader, variable_manager=variable_manager, loader_plugin_loader=plugin_loader)

    # Test that no error is raised if RoleMetadata is initialized with a string as argument
    tmpfd, tmpfile = tempfile.mkstemp()
    roletest = RoleMetadata(owner=play)
    roletest.load(tmpfile, owner=play)

    os.close(tmpfd)


# Generated at 2022-06-11 10:39:29.996160
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = "./myplay/roles/myrole/meta/main.yml"
    with open(data, 'rb') as f:
        yaml_data = yaml.safe_load(f)

    role_metadata = RoleMetadata()
    role_metadata.deserialize(yaml_data)
    assert role_metadata.dependencies == [{'role': 'anotherrole'}]
    assert role_metadata.allow_duplicates == True


# Generated at 2022-06-11 10:39:37.721242
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data_block = '''
    allow_duplicates: yes
    dependencies:
    - other
    '''

    from ansible.playbook.role import Role
    import yaml
    # New RoleMetadata object with owner as fake Role object
    test_role = Role()
    test_role._role_name = 'fake role'
    test_meta = RoleMetadata(owner=test_role)
    yaml_data = yaml.safe_load(data_block)

    test_meta.load_data(yaml_data)
    assert test_meta._dependencies == ['other']
    assert test_meta._allow_duplicates == True
    assert test_meta._owner == test_role
    # Caller is not a Role object
    test_meta = RoleMetadata()

# Generated at 2022-06-11 10:39:43.518246
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role_path = "../../../examples/ansible-galaxy/roles/foo_galaxy"
    r = RoleDefinition.load(role_path)

    assert isinstance(r.metadata, RoleMetadata)
    assert r.metadata.minimum_ansible_version == "2.0"
    assert len(r.metadata.dependencies) == 4

# Generated at 2022-06-11 10:39:54.904033
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    import json

    data = '''{
        "dependencies": [
            {
                "role": "geerlingguy.nodejs",
                "version": "2.2.3"
            },
            {
                "role": "geerlingguy.php",
                "version": "2.2.0"
            },
            {
                "role": "geerlingguy.drush",
                "version": "2.0.0"
            }
        ],
        "allow_duplicates": false
    }'''

    data = json.loads(data, strict=False)
    role_metadata = RoleMetadata()

    # Run the deserialize method
    role_metadata.deserialize(data)

    # Test the attributes
    assert role_metadata._allow_duplicates == False
    assert len

# Generated at 2022-06-11 10:39:55.901234
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata(owner=None)

# Generated at 2022-06-11 10:40:05.768284
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude

    from ansible.utils.collection_loader import AnsibleCollectionLoader

    from ansible.galaxy.collection import GalaxyCollection

    collection_search_path = AnsibleCollectionLoader._get_collections_search_paths()
    galaxy_collection = GalaxyCollection('TEST.namespace', collection_search_path[0])

    # init a role for testing

# Generated at 2022-06-11 10:40:06.370519
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-11 10:40:08.104379
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata(owner='me')
    assert True


# Generated at 2022-06-11 10:40:17.181946
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import os
    import shutil
    import tempfile

    #  creation of a temporary directory to store the roles
    tmp_dir = tempfile.mkdtemp()

    # creation of a role
    os.makedirs(os.path.join(tmp_dir, "foo"))
    f = open(os.path.join(tmp_dir, "foo", "meta", "main.yml"), "w")
    f.write("""
    allow_duplicates: True
    dependencies:
      - role: bar
      - role: baz
      - role: foobar
    """)
    f.close()

    # creation of other roles to resolve dependencies
    os.makedirs(os.path.join(tmp_dir, "bar"))

# Generated at 2022-06-11 10:40:27.859490
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta._allow_duplicates = False
    meta._dependencies = []
    serialized_meta = meta.serialize()
    assert serialized_meta['allow_duplicates'] == False
    assert serialized_meta['dependencies'] == []
    return


# Generated at 2022-06-11 10:40:37.781611
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    fake_play = Play().load({
        'name': 'fake_play',
        'hosts': 'fake_hosts',
        'roles': [
            'fake_role_1',
            'fake_role_2'
        ]
    }, variable_manager=None, loader=None)
    fake_role = Role()
    fake_role._role_path = '/home/user/custom_role'
    fake_role._role_name = 'test'
    fake_role._role_collection = None
    fake_role._play = fake_play


# Generated at 2022-06-11 10:40:44.172263
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    def mocked_load_data():
        return {'name': 'test', 'dependencies': [{'role': 'test1'}]}

    RoleMetadata.load_data = mocked_load_data
    m = RoleMetadata().load_data({'name': 'test', 'dependencies': [{'role': 'test1'}]})
    assert m is not None

    m = RoleMetadata()
    m.load_data({'name': 'test', 'dependencies': [{'role': 'test1'}]})
    assert m is not None

    m = RoleMetadata()
    m._load_dependencies('dependencies', [{'name' : 'test1'}, 'test2'])
    assert m is not None

# Generated at 2022-06-11 10:40:56.500461
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

    owner = RoleDefinition('role')
    owner._role_path = 'ansible/playbooks/roles/role'
    owner._play = Play()

    meta = RoleMetadata().deserialize(dict(
        allow_duplicates=True,
        dependencies=[
            '../../../../roles/common',
            { 'role': '../../../../roles/common', 'tasks_from': 'main.yml' }
        ]
    ))

    assert meta._allow_duplicates == True

# Generated at 2022-06-11 10:40:59.341390
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    p = RoleMetadata
    # unit test RoleMetadata's __init__ method
    try:
        owner=None
        p(owner)
    except Exception as e:
        print(e)


# Generated at 2022-06-11 10:41:02.495287
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class Owner:
        def __init__(self):
            self._role_path = '/path/to/role'

    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )

    rm = RoleMetadata.load(data, Owner())
    assert rm.serialize() == data



# Generated at 2022-06-11 10:41:11.433343
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
     from ansible.playbook.role.definition import RoleDefinition
     from ansible.playbook.role_include import RoleInclude

     # case 1: valid meta data
     r = RoleMetadata.load({'allow_duplicates':True, 'dependencies':['common']}, RoleDefinition("foo"))
     assert isinstance(r, RoleMetadata)
     assert isinstance(r.dependencies, list)
     assert isinstance(r.dependencies[0], RoleInclude)
     assert r.dependencies[0].role == 'common'
     assert r.dependencies[0].name == 'common'
     assert r.dependencies[0].collections == []
     assert r.dependencies[0].vars == {}
     assert r.dependencies[0].default_vars == {}
     assert r.dependencies[0].tasks

# Generated at 2022-06-11 10:41:16.258146
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    new_data = dict(allow_duplicates=True)
    role_metadata.deserialize(new_data)
    assert role_metadata._allow_duplicates == True
    new_data = dict(dependencies=[1, 2, 3])
    role_metadata.deserialize(new_data)
    assert role_metadata._dependencies == [1, 2, 3]

# Generated at 2022-06-11 10:41:23.604943
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    # test case 1
    result = RoleMetadata.load({'dependencies': ['example.foo', 'example.bar']}, owner="owner")
    assert result._dependencies == ['example.foo', 'example.bar']
    assert result._owner == "owner"
    assert result._allow_duplicates == False

    # test case 2
    result = RoleMetadata.load({'dependencies': ['example.foo', 'example.bar'], 'allow_duplicates': True}, owner="owner")
    assert result._allow_duplicates == True

test_RoleMetadata()

# Generated at 2022-06-11 10:41:27.987415
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition

    rd = RoleDefinition.load(
        dict(
            name='test',
            playbook_path='/tmp/foo',
        )
    )
    rm = RoleMetadata.load(dict(), rd)
    assert rm is not None
    assert rm._allow_duplicates is False


# Generated at 2022-06-11 10:41:42.046339
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager

    collection_paths = ['../../test/functional/targets/galaxy_collection/']
    play_source = dict(
        name="role_metadata_test",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(
                action=dict(
                    module='debug',
                    args=dict(
                        msg='test message'
                    )
                )
            )
        ]
    )
    loader, inventory, variable_manager = Playbook.load_playbook_inventory(play_source, variable_manager=VariableManager())
    play = Playbook.load(play_source, loader=loader, variable_manager=variable_manager)


# Generated at 2022-06-11 10:41:51.885487
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': True,
        'dependencies': [{
            'name': 'geerlingguy.java',
            'role': 'geerlingguy.java',
            'version': '1.8.1'
        }]
    }
    m = RoleMetadata()
    m.deserialize(data)
    assert m.allow_duplicates == True
    assert m.dependencies[0]['name'] == 'geerlingguy.java'
    assert m.dependencies[0]['role'] == 'geerlingguy.java'
    assert m.dependencies[0]['version'] == '1.8.1'


# Generated at 2022-06-11 10:42:01.281520
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    class FakeLoader():
        class FakeVarsManager():
            def __init__(self):
                self.extra_vars = []

            def get_vars(self, loader=None, play=None, include_hostvars=True, include_delegate_to=False):
                return {}

        def __init__(self):
            self.extra_vars = []
            self.inventory = []
            self.variable_manager = FakeLoader.FakeVarsManager()

    class FakePlay():
        def __init__(self):
            self.collections = ["role_collections_dir"]


# Generated at 2022-06-11 10:42:12.400842
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import json
    # create a RoleMetadata object
    main_yml_content = '''
    allow_duplicates: no
    dependencies:
      - { name: apache, src: git+https://github.com/ansible/role-apache.git, scm: git, version: master }
    '''

    data = yaml.safe_load(main_yml_content)

    # create a RoleMetadata object
    rmd = RoleMetadata.load(data)
    # call deserialize
    results = rmd.deserialize(data)
    # ensure that the original object and the result object are the same
    # not implemented yet
    if False:
        assert results.allow_duplicates == rmd.allow_duplicates
        assert results.dependencies == rmd.dependencies
    assert 0

# Generated at 2022-06-11 10:42:20.636117
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    collection = {
        "namespace": "test_namespace",
        "name": "test_name",
        "version": "1.0",
        "roles_path": "test_roles_path",
        "path": "test_path",
        "role_name": "test_role_name"
    }
    owner = MagicMock()
    owner.get_name.return_value = "test_name"
    ds = {
        "dependencies": [
            {
                "role": "test_role"
            }
        ]
    }

    result = RoleMetadata.load(ds, owner)
    assert result is not None

# Generated at 2022-06-11 10:42:26.511660
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta1 = RoleMetadata()
    role_meta1.deserialize({
        'allow_duplicates': True,
        'dependencies': [{'name': 'role1'}, {'name': 'role2'}],
    })
    assert role_meta1.allow_duplicates == True
    assert len(role_meta1.dependencies) == 2
    assert role_meta1.dependencies[0].name == 'role1'
    assert role_meta1.dependencies[1].name == 'role2'

# Generated at 2022-06-11 10:42:28.133738
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata().deserialize({'allow_duplicates': False, 'dependencies': []}) == \
        {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:42:34.666062
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    rl = RoleMetadata()
    rl.allow_duplicates = True
    rl.dependencies = [{"role": 'test_name', "name": "test"}]

    rl.serialize()

# Generated at 2022-06-11 10:42:41.199115
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(role='foo'),
            dict(role='bar')
        ]
    )
    context = dict(name='galaxy.zoo.role')
    r = Role(loader=None, variable_manager=None, use_role_defaults=False,
             playbook=None, defs=context)
    m = RoleMetadata.load(data, owner=r)
    assert isinstance(m, RoleMetadata)

# Generated at 2022-06-11 10:42:43.607674
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata(owner=None)
    assert metadata.deserialize(data=dict(allow_duplicates=False, dependencies=[])) == None


# Generated at 2022-06-11 10:42:48.601933
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    t = RoleMetadata(owner=None).deserialize(data)

    assert t.serialize() == data

# Generated at 2022-06-11 10:42:49.844262
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata()
    ret = m.load({})
    assert ret.allow_duplicates == False

# Generated at 2022-06-11 10:42:53.029543
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {"allow_duplicates": False, "dependencies": []}
    obj = RoleMetadata()
    obj.deserialize(data)
    assert obj.allow_duplicates == False
    assert obj.dependencies == []


# Generated at 2022-06-11 10:43:03.836014
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_source import RoleSource
    from ansible.playbook.role import Role
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.galaxy import Galaxy
    import yaml

    var_manager = PlayContext()
    var_manager._options = ImmutableDict(connection='local', forks=100, become=False, become_method='sudo', become_user='root', check=False, diff=False, listhosts=False, listtasks=False, listtags=False, syntax=False)

    play_context = PlayContext()

# Generated at 2022-06-11 10:43:06.598274
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Tests return a dictionary
    my_meta = RoleMetadata()
    assert my_meta.serialize() == dict(allow_duplicates=False, dependencies=list())

# Generated at 2022-06-11 10:43:11.935195
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader, look_for_roles

    loader, _, _ = look_for_roles()
    role_def = RoleDefinition.load('defaults/main.yml', loader=loader)
    role_meta = role_def.metadata

    assert role_meta.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:43:21.571400
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.play_context import PlayContext

    class MockPlaybook:

        def __init__(self):
            self.hosts = 'all'
            self.remote_user = 'remote_user'
            self.connection = 'local'
            self.sudo = True
            self.sudo_user = 'root'
            self.become = True
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.verbosity = 0
            self._initialized = False
            self._finalized = False
            self._play_context = PlayContext()

    class MockRole:

        def __init__(self):
            self._role_path = '/path/to/roles/foo'
            self._role_name = 'foo'
            self._role_collection = None

# Generated at 2022-06-11 10:43:24.769673
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    mock_data = {'allow_duplicates': False,
                 'dependencies': []}
    rm = RoleMetadata()
    assert mock_data == rm.serialize()

# Generated at 2022-06-11 10:43:28.165938
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    rm = RoleMetadata.load(dict(galaxy_info=dict(author='Michael DeHaan')), None)
    assert rm._galaxy_info is not None
    assert rm._galaxy_info.author == 'Michael DeHaan'

# Generated at 2022-06-11 10:43:33.251047
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()

    # GalaxyInfo not present because it is not properly implemented
    data = {'allow_duplicates': True, 'dependencies': [1, 2, 3]}
    meta.deserialize(data)
    assert meta.allow_duplicates is True
    assert meta.dependencies == [1, 2, 3]

# Tests for serialize() method of RoleMetadata

# Generated at 2022-06-11 10:43:40.922846
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create a new RoleMetadata object with an owner created in memory.
    # The RoleMetadata constructor will create a new role requirement
    # whose owner is the role created here.
    role_metadata = RoleMetadata(owner={'name': 'test_role'})
    assert role_metadata is not None
    assert role_metadata._dependencies == []

# Generated at 2022-06-11 10:43:45.926466
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test that the constructor errors out if not passed an owner
    try:
        m = RoleMetadata()
        raise Exception('The constructor of class RoleMetadata failed to error out when not passed an owner')
    except:
        pass
    # Test that the constructor works if passed an owner
    m = RoleMetadata(owner=RoleMetadata)
    if not m:
        raise Exception('The constructor of class RoleMetadata failed to work when passed an owner')
    return True

# Generated at 2022-06-11 10:43:48.562223
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    assert meta.allow_duplicates == False
    assert meta.dependencies == []

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-11 10:43:49.066203
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert True

# Generated at 2022-06-11 10:43:59.189800
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    # Make sure that constructor of class RoleMetadata raises Exception when data parameter is None
    try:
        RoleMetadata(owner=None)
        assert False, "An exception should have been thrown"
    except Exception as e:
        assert str(e) == "__init__() missing 1 required positional argument: 'owner'", "An exception should have been thrown"

    try:
        RoleMetadata(owner=True)
        assert False, "An exception should have been thrown"
    except Exception as e:
        assert str(e) == "__init__() missing 1 required positional argument: 'owner'", "An exception should have been thrown"


# Generated at 2022-06-11 10:44:02.265045
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Test if the serialize method works correctly
    """
    class test_RoleMetadata(RoleMetadata):
        _dependencies = FieldAttribute(isa='list')

    test_metadata = test_RoleMetadata()
    test_metadata._dependencies = [1, 2, 3]
    test_expected_result = {'allow_duplicates': False, 'dependencies': [1, 2, 3]}

    assert test_metadata.serialize() == test_expected_result

# Generated at 2022-06-11 10:44:13.257255
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import RoleInclude
    play_context = PlayContext()
    play = Play().load(dict(
        name = "test_play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
                  dict(action=dict(module='setup', args=dict())),
                  dict(action=dict(module='debug', args=dict(msg='{{ansible_date_time.iso8601}} {{ansible_hostname}}')))
                ]
      ), variable_manager=play_context.variable_manager, loader=play_context.loader)


# Generated at 2022-06-11 10:44:22.126061
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.definition import RoleDefinition

    # test load with invalid data type for meta data
    invalid_data = 'invalid data'
    try:
        RoleMetadata().load(invalid_data, None)
        assert False
    except AnsibleParserError:
        assert True

    # test load with valid data
    role_name = 'role1'
    role_def1 = RoleDefinition()
    role_def1._role_name = role_name
    role_def1._role_path = '/ansible/roles/role1'
    role_def1.metadata = {}
    meta = RoleMetadata().load(role_def1.metadata, role_def1)
    assert meta._owner == role_def1
    assert meta._

# Generated at 2022-06-11 10:44:26.777823
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    collector = RoleMetadata(owner=None)
    setattr(collector, 'allow_duplicates', True)
    setattr(collector, 'dependencies', [])
    expected_result = {'allow_duplicates': True, 'dependencies': []}
    result = collector.serialize()
    assert result == expected_result

# Generated at 2022-06-11 10:44:31.155724
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata(owner=None)
    m.deserialize(dict(allow_duplicates=True, dependencies=['role1', 'role2']))

    serialized = m.serialize()
    assert serialized['allow_duplicates'] is True
    assert serialized['dependencies'] == ['role1', 'role2']



# Generated at 2022-06-11 10:44:44.933091
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-11 10:44:45.526287
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert False, "Test not implemented"

# Generated at 2022-06-11 10:44:54.299578
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-11 10:44:58.848348
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = dict(allow_duplicates=False,dependencies=[])
    r.deserialize(data)
    assert r.allow_duplicates == data['allow_duplicates']
    assert r.dependencies == data['dependencies']


# Generated at 2022-06-11 10:45:02.671455
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role.deserialize(data)
    assert (role.allow_duplicates, role.dependencies) == (False, [])

# Generated at 2022-06-11 10:45:05.955838
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m.allow_duplicates == False
    assert m.dependencies == []
    assert isinstance(m, RoleMetadata)
    assert issubclass(RoleMetadata, Base)



# Generated at 2022-06-11 10:45:14.455133
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.collection import RoleRequirement, GalaxyInfo
    from ansible.playbook.play_context import PlayContext

    role_type = 'role'
    name = 'name'
    role_path = 'role'
    play_context = PlayContext()
    collection_type = 'collection'
    collection_name = 'collection_name'
    collection_namespace = 'collection_namespace'
    collection_search_path = 'collections'
    collection_version = 'collection_version'
    collection_parent_dirs = '../'
    collection_reqs = RoleRequirement.from_string('namespace.name,version')


# Generated at 2022-06-11 10:45:21.645756
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    role_definition = RoleDefinition()
    role_definition.deserialize({'name': 'test'})

    metadata = RoleMetadata(role_definition)
    metadata.deserialize({
        'allow_duplicates': True,
        'dependencies': [
            'cgeorge',
            'ncarlier'
        ]
    })
    data = metadata.serialize()
    assert data['allow_duplicates']
    assert data['dependencies'] == [ 'cgeorge', 'ncarlier' ]

# Generated at 2022-06-11 10:45:22.935540
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
   assert(RoleMetadata)

# Generated at 2022-06-11 10:45:32.963624
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.helpers import load_list_of_roles
    r = RoleMetadata()
    # Testing for empty dependencies
    data = {'dependencies': []}
    r.deserialize(data)
    assert r.dependencies == []

    # Testing for valid dependencies

# Generated at 2022-06-11 10:45:59.206405
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Unit test for method serialize of class RoleMetadata
    '''

    m = RoleMetadata()
    assert m.serialize() == {'allow_duplicates': False, 'dependencies': []}
    m._allow_duplicates = True
    m._dependencies = [1, 2, 3]
    assert m.serialize() == {'allow_duplicates': True, 'dependencies': [1, 2, 3]}

# Generated at 2022-06-11 10:46:00.921882
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-11 10:46:01.737100
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert False, "Test not implemented"

# Generated at 2022-06-11 10:46:03.727803
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    try:
        RoleMetadata.load('/path/to/ansbile/role')
        assert False
    except Exception as e:
        assert True

# Generated at 2022-06-11 10:46:06.635607
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    d = {}
    m = RoleMetadata(owner=d)
    m2 = RoleMetadata(owner=d)
    d2 = dict(
        allow_duplicates=m._allow_duplicates,
        dependencies=m._dependencies
    )
    assert m.serialize() == d2


# Generated at 2022-06-11 10:46:10.184285
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Unit test for serialize method of class RoleMetadata
    """
    test_object = RoleMetadata()
    test_object._allow_duplicates = True
    test_object._dependencies = ['test_dependency1', 'test_dependency2']
    assert test_object.serialize() == {'allow_duplicates': True, 'dependencies': ['test_dependency1', 'test_dependency2']}

# Generated at 2022-06-11 10:46:10.869909
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print ("Constructor of class RoleMetadata")

# Generated at 2022-06-11 10:46:14.765065
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = dict(
        allow_duplicates=False, dependencies=['apache', 'foo'])
    owner = MockOwner()
    try:
        m = RoleMetadata.load(data, owner)
        assert m._allow_duplicates == False
        assert m._dependencies == ['apache', 'foo']
    except AnsibleParserError:
        raise AssertionError("Should not raise.")


# Generated at 2022-06-11 10:46:19.021425
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ''' RoleMetadata class deserialize method test '''

    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'myRole', 'version': '1.0'}]})

    assert role_metadata._dependencies[0]._role_name == 'myRole'
    assert role_metadata._dependencies[0]._role_version == '1.0'
    assert role_metadata._allow_duplicates

# Generated at 2022-06-11 10:46:26.080116
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    class RoleMock:
        def __init__(self, name, path, collection=None):
            self.name = name
            self.collection = collection
            self.path = path

        def get_name(self):
            return self.name


# Generated at 2022-06-11 10:47:12.939071
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    import ansible.playbook.role.metadata
    rd_data = dict(
        role='test',
        galaxy_info=dict(
            author='test',
            company='test',
            description='test',
            license='test',
            platforms=dict(
                name='test',
                versions='test'
            ),
            galaxy_tags='test',
            min_ansible_version='test',
            dependencies=dict(
                role='test',
                collections=['test', 'test']
            )
        )
    )
    rd = RoleDefinition.load(rd_data, 'test', 'test', [])
    assert isinstance(rd, RoleDefinition)
    rd_md = ansible.playbook.role.metadata.RoleMetadata.load

# Generated at 2022-06-11 10:47:21.680595
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    # Create a MockRole for testing RoleMetadata
    class MockRole(object):
        def __init__(self, role_name):
            self._role_name = role_name
            self._role_path = '/some/path/to/role'
            self._role_collections = []

        def get_name(self):
            return self._role_name

        def get_collections(self):
            return self._role_collections

        def get_dependency_errors(self):
            return []

        def set_paths(self):
            return None

        def _get_role_path(self):
            return self._role_path


# Generated at 2022-06-11 10:47:24.986915
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()

    role_metadata._dependencies = [{'src': 'foo', 'version': '1.0'}]
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': [{'src': 'foo', 'version': '1.0'}]}

# Generated at 2022-06-11 10:47:29.497408
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role import Role

    # load from a string, not a dictionary
    data = 'stringdata'
    loader_mock = mock.MagicMock()
    owner = Role()

    try:
        RoleMetadata.load(data, owner, loader=loader_mock)
    except AnsibleParserError as e:
        assert 'not a dictionary' in e.message
    else:
        assert False, 'AnsibleParserError has not been raised'



# Generated at 2022-06-11 10:47:31.799907
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert (RoleMetadata().serialize() == {'allow_duplicates': False, 'dependencies': []}), "serialize method of RoleMetadata class returns the expected dict"

# Generated at 2022-06-11 10:47:32.967205
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert(False)

# Generated at 2022-06-11 10:47:42.711277
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    r = Role()
    r._role_name = 'role_name'
    r._role_path = 'role_path'
    assert r._role_path == 'role_path'

    t = Task()
    t._role = r
    assert t._role is r

    p = Play()
    p._basedir = '.'
    assert p._basedir == '.'

    rd = RoleDefinition()
    rd._role_name = 'role_name'
    rd._role_path = 'role_path'
    assert rd._role_path == 'role_path'


# Generated at 2022-06-11 10:47:43.991454
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role._allow_duplicates == False
    assert role._dependencies == []

# Generated at 2022-06-11 10:47:53.065172
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    data = dict(
        allow_duplicates = False,
        dependencies = [
            dict(
                role = dict(
                    name = 'common',
                )
            ),
            dict(
                role = dict(
                    collection = dict(
                        name = 'test-roles',
                        namespace = 'test',
                    ),
                    name = 'common',
                ),
            ),
        ],
    )
    role = RoleDefinition(name='x', path='x', parent_role=None)
    m = RoleMetadata.load(data, owner=role)
    assert len(m.dependencies) == 2
    assert isinstance(m.dependencies[0], RoleRequirement)

# Generated at 2022-06-11 10:48:01.799967
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class fake_owner:
        def __init__(self):
            self._role_collection = None

    import os
    x = os.path.dirname('/tmp/meta/main.yml')
    assert x == '/tmp/meta'
    import sys
    sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/../../../'))
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    fake_owner_instance = fake_owner()
    fake_owner_instance._role_path = '/tmp/meta/main.yml'