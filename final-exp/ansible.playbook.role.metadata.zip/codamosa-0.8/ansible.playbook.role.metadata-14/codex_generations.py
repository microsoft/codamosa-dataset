

# Generated at 2022-06-11 10:39:22.436004
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import os
    from ansible.utils.display import Display
    display = Display()

    # test on a real role
    # test_role_path = os.path.join(os.path.dirname(__file__), '..', 'test_roles', 'test_role')
    test_role_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test_roles', 'test_role')
    collection_search_list = None
    require_role_paths = None
    init_collection_plugin_loader = False
    from ansible.playbook.role import Role
    display.debug("loading role from %s" % test_role_path)

# Generated at 2022-06-11 10:39:27.008097
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=[], dependencies=[]))
    assert role_metadata.allow_duplicates == [], "deserialize method failed"
    assert role_metadata.dependencies == [], "deserialize method failed"

# Generated at 2022-06-11 10:39:36.054200
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

    options = dict(
        connection='local',
        remote_user='yan',
        become=False,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        start_at_task=None,
    )

    from ansible.playbook.block import Block
    from ansible.playbook.play import Play


# Generated at 2022-06-11 10:39:37.033694
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role is not None

# Generated at 2022-06-11 10:39:40.645023
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata(owner=None)
    data = dict(allow_duplicates=False, dependencies=[])
    obj.deserialize(data)
    assert obj.allow_duplicates == False
    assert obj.dependencies == []



# Generated at 2022-06-11 10:39:47.900267
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
   test_object = RoleMetadata()
   test_object.deserialize( {'allow_duplicates': True, 'dependencies': []})

   # test role_metadata.py with python3
   # pylint: disable=no-member
   if hasattr(RoleMetadata, "_allow_duplicates"):
      assert test_object._allow_duplicates == True
   if hasattr(RoleMetadata, "_dependencies"):
      assert test_object._dependencies == []

# Generated at 2022-06-11 10:39:48.546169
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-11 10:39:55.761208
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False, "The assert has failed because the allow_duplicates variable has wrong value."
    assert role_metadata.dependencies == [], "The assert has failed because the dependencies variable has wrong value."
    assert role_metadata.galaxy_info == None, "The assert has failed because the galaxy_info variable has wrong value."
    assert role_metadata.argument_specs == {}, "The assert has failed because the argument_specs variable has wrong value."

# Generated at 2022-06-11 10:39:58.726659
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    def serialize():
        rm = RoleMetadata()
        return rm.serialize()
    assert serialize() == {'dependencies': [], 'allow_duplicates': False}


# Generated at 2022-06-11 10:40:08.933361
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    data = {u'allow_duplicates': True, u'dependencies': [u'role1']}
    owner = RoleDefinition(name='role_name', role_path='role_path', collection_name='collection_name')
    variable_manager = 'variable_manager'
    loader = 'loader'
    role_metadata = RoleMetadata(owner=owner)
    result = RoleMetadata.load(data, owner, variable_manager=variable_manager, loader=loader)
    assert role_metadata == result
    data = 'meta_data'

# Generated at 2022-06-11 10:40:22.335277
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class Test(RoleMetadata):
        _allow_duplicates = FieldAttribute(isa='bool', default=False)
        _dependencies = FieldAttribute(isa='list', default=list)
        _galaxy_info = FieldAttribute(isa='GalaxyInfo')

    role_metadata = Test()
    assert isinstance(role_metadata._allow_duplicates, bool)
    assert isinstance(role_metadata._dependencies, list)
    # assert isinstance(role_metadata._galaxy_info, GalaxyInfo)



# Generated at 2022-06-11 10:40:30.195086
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play

    p = Play()
    d1 = {'name': 'one', 'role': 'one'}
    d2 = {'name': 'two', 'role': 'two'}
    m1 = {'dependencies': [d1, d2]}

    r = RoleMetadata.load(m1, owner=RoleDefinition())
    assert len(r.dependencies) == 2
    assert r.dependencies[0].role == 'one'
    assert r.dependencies[1].role == 'two'

# Generated at 2022-06-11 10:40:37.121260
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{
        'role' : 'test',
        'name' : 'test-name'
    }]
    serialized_data = role_metadata.serialize()
    assert serialized_data['allow_duplicates'] == True
    assert serialized_data['dependencies'][0]['role'] == 'test'
    assert serialized_data['dependencies'][0]['name'] == 'test-name'

# Generated at 2022-06-11 10:40:40.209092
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    b = RoleMetadata()
    b.deserialize({'allow_duplicates': True, 'dependencies': ['test1', 'test2', 'test3']})
    assert b.allow_duplicates
    assert b.dependencies == ['test1', 'test2', 'test3']

# Generated at 2022-06-11 10:40:41.207007
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r

# Generated at 2022-06-11 10:40:48.580187
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    loader = AnsibleCollectionLoader()
    collection = loader.load("myns.mycoll1")
    role = RoleDefinition.load({'name': 'myrole', 'collection': 'myns.mycoll1'}, parent_role=None, collection_list=None, loader=loader)
    role.post_validate(collection=collection)
    assert role.metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:40:54.640724
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata(owner="rolename")
    meta.allow_duplicates = True
    meta.dependencies = ["dep1", "dep2"]
    serialized = meta.serialize()
    assert serialized == {'allow_duplicates': True, 'dependencies': ['dep1', 'dep2']}


# Generated at 2022-06-11 10:41:03.611203
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # initialize a RoleMetadata object
    obj = RoleMetadata()

    # initialize a data dictionary
    data = {}

    # deserialize data into obj
    obj.deserialize(data)

    # verify the no. of elements in object
    assert len(obj.__dict__.keys()) == 4
    assert obj.__dict__.has_key('_owner')
    assert obj.__dict__.has_key('_dependencies')
    assert obj.__dict__.has_key('_allow_duplicates')
    assert obj.__dict__.has_key('_argument_specs')

    # set the _owner attribute
    obj._owner = 'some string'

    # deserialize data into obj
    obj.deserialize(data)

    # verify the no. of elements in object

# Generated at 2022-06-11 10:41:12.437460
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-11 10:41:16.316112
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {
        "allow_duplicates": False,
        "dependencies": []
    }
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []



# Generated at 2022-06-11 10:41:36.381713
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    from ansible.playbook.role.definition import RoleDefinition

    role_def = RoleDefinition._load_from_file(
        os.path.join(os.path.dirname(__file__), '../../../test/units/modules/test_role/meta/main.yml')
    )

    assert role_def.metadata.deserialize({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-11 10:41:36.946848
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:41:43.651363
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    fake_role_definition = RoleDefinition()
    fake_role_metadata = RoleMetadata(owner=fake_role_definition)
    assert fake_role_metadata.allow_duplicates == False
    fake_data = dict()
    fake_data['allow_duplicates'] = True
    fake_role_metadata.deserialize(fake_data)
    assert fake_role_metadata.allow_duplicates == True
    #
    assert fake_role_metadata.dependencies == []
    fake_data['dependencies'] = [{'role': 'A'}]
    assert fake_role_metadata.dependencies == [{'role': 'A'}]


# Generated at 2022-06-11 10:41:48.244668
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rm = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[])
    rm.deserialize(data)
    assert rm.allow_duplicates == data['allow_duplicates']
    assert rm.dependencies == data['dependencies']

# Generated at 2022-06-11 10:41:58.544348
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    from ansible.playbook.play_context import PlayContext

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory


# Generated at 2022-06-11 10:42:08.402374
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.role.definition
    import ansible.utils
    import os


# Generated at 2022-06-11 10:42:12.029285
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    from ansible.playbook.role.definition import RoleDefinition

    rd = RoleDefinition()
    rm = RoleMetadata(owner=rd)
    assert rm.allow_duplicates == False
    assert rm.dependencies == []
    assert rm._owner == rd

# Generated at 2022-06-11 10:42:16.954794
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    myRoleMetadata = RoleMetadata()
    myRoleMetadata.allow_duplicates = True
    myRoleMetadata.dependencies = [1, 2, 3]
    serializedRoleMetadata = myRoleMetadata.serialize()

    assert serializedRoleMetadata['allow_duplicates'] == True
    assert serializedRoleMetadata['dependencies'] == [1, 2, 3]

# Generated at 2022-06-11 10:42:23.650405
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {}
    data['path'] = "./test_meta/main.yml"
    data['name'] = 'test'

    role = RoleMetadata(data)
    assert role.allow_duplicates == False

    data = {}
    data['allow_duplicates'] = True
    data['dependencies'] = []
    data['path'] = "./test_meta/main.yml"
    data['name'] = 'test'

    role = RoleMetadata(data)
    assert role.allow_duplicates == True

# Generated at 2022-06-11 10:42:24.162423
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:42:56.401301
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Create a mock RoleMetadata instance
    m = RoleMetadata()

    # Create a mock data that is used by deserialize()
    data = {'allow_duplicates': False, 'dependencies':[]}

    # Test the deserialize() of the RoleMetadata instance
    m.deserialize(data)

    # Assert that we can get the attributes of RoleMetadata instance
    assert m.allow_duplicates == False
    assert m.dependencies == []

# Generated at 2022-06-11 10:43:07.310391
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # set up a fake owner object
    class owner:
        name = None
        play = None
        _role_path = None
        _role_collection = None

    # set up a fake play object
    class play:
        collections = ['ansible.builtin', 'ansible.posix']

    # set up a fake GalaxyInfo object
    class GalaxyInfo:
        def __init__(self):
            pass

    # set up a fake loader object
    class loader:
        def path_dwim(self, include_role):
            return "/path/to/roles/" + include_role

    # set up a fake variable_manager object
    class variable_manager:
        pass

    # define galaxy info dict
    galaxy_info = GalaxyInfo()
    galaxy_info.author = 'geerlingguy'
    galaxy_info

# Generated at 2022-06-11 10:43:08.186747
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata()

# Generated at 2022-06-11 10:43:12.631690
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    setattr(RoleMetadata, '_validate_dependencies', _validate_dependencies_stub)
    setattr(RoleMetadata, '_validate_allow_duplicates', _validate_allow_duplicates_stub)

    assert RoleMetadata().deserialize({}).__dict__ == {'_allow_duplicates': False, '_dependencies': []}

# Generated at 2022-06-11 10:43:14.515902
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    f = RoleMetadata()
    assert f.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-11 10:43:24.960155
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    yaml_data = dict(
        name="geerlingguy.apache",
        description="Install and configure Apache HTTP Server on multiple platforms.",
        dependencies=[]
    )

    role = RoleDefinition.load(yaml_data, loader=None)
    assert role is not None

    play = Play.load(dict(
        name = "all",
        hosts = 'localhost',
        roles = [ dict(role="geerlingguy.apache") ]
    ), loader = None)
    assert play is not None

    # Fake parent play
    role_meta = RoleMetadata.load(yaml_data, owner=play, loader=None)
    assert role_meta is not None

    result = role_meta.serialize()

# Generated at 2022-06-11 10:43:27.668461
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_test = RoleMetadata()
    assert role_metadata_test.dependencies == []
    assert role_metadata_test.allow_duplicates == False

# Generated at 2022-06-11 10:43:34.111883
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    setattr(meta, '_allow_duplicates', True)
    setattr(meta, '_dependencies', ["foo"])
    assert meta.serialize()["allow_duplicates"] == True
    assert meta.serialize()["dependencies"] == ["foo"]
    # Serialize does not modify the object
    assert hasattr(meta, '_allow_duplicates')
    assert hasattr(meta, '_dependencies')
    # TODO: add test for __init__() and _get_attr_value()

# Generated at 2022-06-11 10:43:39.826722
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=False, dependencies=['test-role1', 'test-role2']))

    assert isinstance(role_metadata._allow_duplicates, bool)
    assert getattr(role_metadata, 'allow_duplicates') == False
    assert isinstance(role_metadata._dependencies, list)
    assert len(getattr(role_metadata, 'dependencies')) == 2


# Generated at 2022-06-11 10:43:42.090358
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata(owner=None).serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-11 10:44:44.413832
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    # Test without owner passed to constructor
    try:
        RoleMetadata()
    except Exception as e:
        assert(isinstance(e, AnsibleError))
        assert(str(e) == "The RoleMetadata object must have an owner.")

    # Test with owner set at creation time, but "owner" is not a RoleDefinition
    try:
        RoleMetadata(owner='not a RoleDefinition')
    except Exception as e:
        assert(isinstance(e, AnsibleError))
        assert(str(e) == "The RoleMetadata object passed an owner that is not a RoleDefinition.")

    # Test with valid owner passed in constructor
    role_definition_obj = RoleDefinition()
    role_metadata_obj = RoleMetadata(owner=role_definition_obj)

# Generated at 2022-06-11 10:44:52.374698
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.base import Base
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    test_data = {'allow_duplicates': False, 'dependencies': [{'name': 'test1'}, {'name': 'test2'}]}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(test_data)

    assert isinstance(role_metadata.dependencies, list)
    assert isinstance(role_metadata.allow_duplicates, bool)

    assert isinstance(role_metadata.dependencies[0], RoleRequirement)
    assert role_metadata.dependencies[0].role == 'test1'
    assert role_metadata.dependencies[0].play == None

# Generated at 2022-06-11 10:45:02.779224
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.helpers import load_list_of_roles

    role_data = {
        'name': 'geerlingguy.apache',
        'collection': 'geerlingguy.apache',
        'scm': None,
        'src': None,
        'version': '1.1.0',
        'path': '/etc/ansible/roles/geerlingguy.apache',
        'dependencies': [],
        'allow_duplicates': False
    }

    role = RoleDefinition.load(role_data)

    # We need to fork the method to avoid the assertion error due to the different types of dependencies
    dependencies = 'test_role'

# Generated at 2022-06-11 10:45:04.092206
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #TODO
    assert False

# Generated at 2022-06-11 10:45:12.176261
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import copy
    import collections

    data_types = [collections.OrderedDict, dict]
    for data_type in data_types:
        data = data_type({u'allow_duplicates': False,
                          u'__ansible_module__': u'setup',
                          u'__ansible_arguments__': [u'filter=ansible_distribution', u'filter=ansible_distribution_release'],
                          u'dependencies': [u'foo',
                                            data_type({u'src': u'https://github.com/ansible/ansible-examples.git',
                                                       u'name': u'ansible-examples'}),
                                            u'bar']})
        role_metadata = RoleMetadata()
        role_metadata.deserialize(data)

# Generated at 2022-06-11 10:45:15.301943
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert role.allow_duplicates == False
    assert role.dependencies == []
    assert role.attribute_map == {'allow_duplicates': 'allow_duplicates', 'dependencies': 'dependencies'}

# Generated at 2022-06-11 10:45:25.730566
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.include import RoleInclude

# Generated at 2022-06-11 10:45:35.451483
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    yaml_text = """
    dependencies:
    - role: test
      version: v2
    - role: httpd
      version: v1
    - role: foo
    - role: bar
    """
    fake_loader = DictDataLoader({'meta/main.yml': yaml_text})
    fake_variable_manager = DictDataManager()

    fake_role = RoleDefinition.load(dict(name='test', path='/foo/bar', play={}), fake_variable_manager, fake_loader)

    role_metadata = RoleMetadata.load(yaml_text, fake_role, fake_variable_manager, fake_loader)

    # TODO: Do more tests here

# Generated at 2022-06-11 10:45:41.249887
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': [
            'B',
            'C==1.0,<=2.0',
            {'role': 'D'},
            {'name': 'E', 'a': 'A'}
        ],
        'a': 'A',
        'b': 'B'
    }
    metadata.deserialize(data)
    assert metadata.allow_duplicates == True

# Generated at 2022-06-11 10:45:49.261645
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    print("Unit test for constructor of class RoleMetadata")
    list_of_tasks = [{"include": "tasks/main.yml"}]
    main = ["task1", "task2"]
    hand = ["task3", "task4"]
    block = Block(
        tasks=list_of_tasks,
        handlers=hand,
        rescue=None,
        always=None,
    )
    data = [block]
    depen = [{"role": "common", "tasks_from": "main"}]
    metadata = {"dependencies": depen}
    owner = RoleInclude([{"role": "common", "tasks_from": "main"}])

# Generated at 2022-06-11 10:47:45.252530
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._dependencies = [
        {'role': 'ansible/testrole', 'name': 'testrole', 'src': 'ansible.testrole'},
        {'role': 'ansible/testrole0', 'name': 'testrole0', 'src': 'ansible.testrole0'},
        {'role': 'ansible/testrole1', 'name': 'testrole1', 'src': 'ansible.testrole1'},
    ]
    role_metadata._allow_duplicates = True
    result = role_metadata.serialize()
    assert result['dependencies'] == role_metadata._dependencies, \
        'The method \'serialize\' of class \'RoleMetadata\' does not work correctly'
    assert result['allow_duplicates'] == role_metadata._

# Generated at 2022-06-11 10:47:48.497575
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner=None)
    assert m._allow_duplicates == False
    assert len(m._dependencies) == 0
    assert m._galaxy_info == None
    assert m._argument_specs == {}


# Generated at 2022-06-11 10:47:50.267815
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # TODO
    # this test is not yet implemented
    # Method and class do not exist in 2.9
    pass


# Generated at 2022-06-11 10:47:51.583241
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_instance = RoleMetadata()
    test_instance.load()

# Generated at 2022-06-11 10:48:00.468165
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Create the role
    role = Role()

    # Create the task
    task = Task()

    # Create a task include and load data
    task_include = TaskInclude()
    task_include.load(dict(tasks='main.yml'))
    role._task_includes.append(task_include)
    task._role = role

    # Create a role include and load data
    role_include = RoleInclude()
    role_include.load(dict(role='webservers'))
    role._role_includes.append(role_include)
    task._role = role



# Generated at 2022-06-11 10:48:08.768226
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Init
    role_meta = RoleMetadata()
    role_meta.deserialize({})
    # Asserts
    assert role_meta.allow_duplicates == False
    assert role_meta.dependencies == []
    # Init
    role_meta = RoleMetadata()
    role_meta.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2', 'role3']})
    # Asserts
    assert role_meta.allow_duplicates == True
    assert role_meta.dependencies == ['role1', 'role2', 'role3']


# Generated at 2022-06-11 10:48:16.683785
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    ri = RoleInclude()
    ri.name = 'database'
    ri.role = '/home/xyz/ansible/roles/database'
    ri._role = ri.role
    ri.role_path = '/home/xyz/ansible/roles/database'
    ri.role_name = 'database'
    ri._role_name = ri.role_name
    ri.task_includes = []
    ri.role_params = {}
    ri._dependencies = []
    ri.vars = {}
    m = RoleMetadata()
    m._owner = ri
    m._variable_manager = []
    m._loader = []
    m._ds = [ri]

# Generated at 2022-06-11 10:48:20.314484
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    metadata = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2'],
    )
    result_metadata = RoleMetadata()
    result_metadata.deserialize(metadata)

    assert result_metadata._allow_duplicates == metadata['allow_duplicates']
    assert result_metadata._dependencies == metadata['dependencies']



# Generated at 2022-06-11 10:48:20.864785
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-11 10:48:24.712126
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    result = RoleMetadata({
        'allow_duplicates': False,
        'dependencies': [{'name': 'role_A'}, {'name': 'role_B'}],
    })
    assert result.serialize() == {
        'allow_duplicates': False,
        'dependencies': [{'name': 'role_A'}, {'name': 'role_B'}],
    }