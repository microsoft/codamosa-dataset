

# Generated at 2022-06-11 10:39:22.954073
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from  ansible.playbook.block import Block
    from ansible.playbook.task.include import TaskInclude
    playbook = Playbook().load('test_playbook.yml')
    play_block = Block(play=playbook._entries[0])
    task_include = TaskInclude(play_block=play_block)
    role_definition = RoleDefinition(name=None, role_path=None)
    task_include._role = role_definition
    role_metadata = RoleMetadata(owner=task_include)
    assert role_metadata._variable_manager == None
    assert role_metadata._loader == None

# Generated at 2022-06-11 10:39:25.945587
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None
    assert not role_metadata._allow_duplicates
    assert len(role_metadata._dependencies) == 0

# Generated at 2022-06-11 10:39:29.332566
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    meta_data = RoleMetadata('name')
    meta_data.owner = RoleDefinition.load('test')
    assert meta_data.owner.get_name() == 'test'

# Generated at 2022-06-11 10:39:35.776432
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    Test the deserialize method of class RoleMetadata
    """
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []
    data['galaxy_info'] = {}
    data['argument_specs'] = {}
    m = RoleMetadata()
    m.deserialize(data)
    assert(m.allow_duplicates == False)
    assert(m.galaxy_info == {})
    assert(m.argument_specs == {})
    assert(len(m.dependencies) == 0)

# Generated at 2022-06-11 10:39:39.617293
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata = RoleMetadata()
    roleMetadata.deserialize({'allow_duplicates': True, 'dependencies': ['test.test']})
    
    assert roleMetadata.serialize() == {'allow_duplicates':True, 'dependencies':['test.test']}

# Generated at 2022-06-11 10:39:44.979907
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=[1, 2, 3]
    )

    role_metadata.deserialize(data)

    assert role_metadata._dependencies == [1,2,3]
    assert role_metadata._allow_duplicates == True



# Generated at 2022-06-11 10:39:52.696434
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude

    data = """
    ---
    allow_duplicates: True
    dependencies:
    - 1
    - 2
    - 3
    """
    data_object = RoleMetadata()
    data_object.load_data(data)
    assert isinstance(data_object._dependencies[0], RoleInclude)
    assert isinstance(data_object._dependencies[1], RoleInclude)
    assert isinstance(data_object._dependencies[2], RoleInclude)

    return True

# Generated at 2022-06-11 10:39:57.402203
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata.load(dict(dependencies=[]), owner=None)
    serialize = role_metadata.serialize()
    assert serialize
    assert type(serialize) == dict
    assert serialize['allow_duplicates'] == False
    assert serialize['dependencies'] == []


# Generated at 2022-06-11 10:39:58.011466
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-11 10:39:58.956753
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata().__init__()

# Generated at 2022-06-11 10:40:11.968207
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    constructor test
    '''

    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-11 10:40:12.982610
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert type(RoleMetadata()) == RoleMetadata

# Generated at 2022-06-11 10:40:14.941862
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'allow_duplicates': True, 'dependencies': ['roles/role1',
            'roles/role2', {'role': 'Role1'}]}
    r = RoleMetadata.load(data, owner=None)
    assert r.allow_duplicates == True
    assert r.dependencies == ['roles/role1', 'roles/role2', 'Role1']

# Generated at 2022-06-11 10:40:17.683345
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test data
    dependencies = [{'role': 'example', 'version': 0}, {'role': 'example2', 'version': 1}]
    roleMetadata = RoleMetadata()
    roleMetadata._dependencies = dependencies

    # Testing serialize method
    assert(roleMetadata.serialize() == {'allow_duplicates': False, 'dependencies': dependencies})

# Generated at 2022-06-11 10:40:26.680616
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    d = {
        "allow_duplicates": False,
        "dependencies": []
    }
    r.deserialize(d)
    if r._allow_duplicates != False or r._dependencies != []:
        fail("RoleMetadata deserialize failed!")
    else:
        pass
    d = {
        "allow_duplicates": True,
        "dependencies": ['common']
    }
    r.deserialize(d)
    if r._allow_duplicates != True or r._dependencies != ['common']:
        fail("RoleMetadata deserialize failed!")
    else:
        pass

# Generated at 2022-06-11 10:40:30.383512
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates=True
    role_metadata._dependencies=[]
    assert role_metadata.serialize() == {'dependencies': [], 'allow_duplicates': True}


# Generated at 2022-06-11 10:40:32.681851
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """ test serialize """
    temp = RoleMetadata()
    assert temp.serialize() == dict(allow_duplicates=False, dependencies=[])



# Generated at 2022-06-11 10:40:41.810848
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

    # test static method load

# Generated at 2022-06-11 10:40:44.284600
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata().allow_duplicates == False
    assert RoleMetadata().dependencies == []
    assert RoleMetadata(owner=RoleMetadata())._owner == RoleMetadata()

# Generated at 2022-06-11 10:40:47.634074
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    roleMetadata = RoleMetadata()
    assert roleMetadata._allow_duplicates == False
    assert roleMetadata._dependencies == []
    assert roleMetadata._galaxy_info == {}
    assert roleMetadata._argument_specs == {}

# Generated at 2022-06-11 10:41:06.505269
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    This function will test the constructor of the class RoleMetadata
    '''

    # Test 1: no parameters
    result = RoleMetadata()
    assert result._allow_duplicates == False and result._dependencies == [],\
        "_allow_duplicates and _dependencies are not initialized with default value"
    assert result._ds == {},\
        "_ds is not initialized with default value"
    assert result._vars == [],\
        "_vars is not initialized with default value"
    assert result._variable_manager == None,\
        "_variable_manager is not initialized with default value"
    assert result._loader == None,\
        "_loader is not initialized with default value"



# Generated at 2022-06-11 10:41:15.064272
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task

    # test constructor
    m = RoleMetadata()

    if m is None or m.allow_duplicates or len(m.dependencies) > 0:
        raise AssertionError("test_constructor_1 failed")

    # test load_data(data)
    m = RoleMetadata().load_data(dict(allow_duplicates=True, dependencies=['common', 'webservers'], galaxy_info=dict(author="Michael DeHaan", description="Install and configure the nginx web server", company="Ansible", license="GPLv3", min_ansible_version="1.2", platforms=["Debian", "RedHat"])))


# Generated at 2022-06-11 10:41:18.493933
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    # test that deserializing an empty dictionary results in empty lists
    r.deserialize({})
    assert r._dependencies == []


# TODO: remove with drop support for Ansible-2.8 and below

# Generated at 2022-06-11 10:41:25.561942
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    m = RoleMetadata(RoleDefinition.load({'name': 'test'}, None, DataLoader(), None))
    m.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'test123', 'name': 'test'}]})
    assert m.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'test123', 'name': 'test'}]}

# Generated at 2022-06-11 10:41:29.244757
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = True
    m.dependencies = ['a', 'b', 'c']
    data = m.serialize()
    assert data == dict(allow_duplicates=True, dependencies=['a', 'b', 'c'])



# Generated at 2022-06-11 10:41:39.529333
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # FIXME: this is a hack to be able to test private method
    RoleMetadata._load_dependencies = RoleMetadata._load_dependencies

    # Testcase 1
    # Create a RoleMetadata object
    r = RoleMetadata()
    # Test if arguments are valid using assertRaises
    with pytest.raises(AnsibleParserError):
        r.load("not a dict", "foo", "bar", "baz")
    # Test if the return value is expected
    result = r.load({}, "foo", "bar", "baz")
    assert isinstance(result, RoleMetadata)
    assert result.dependencies == []
    assert result.allow_duplicates is False
    assert result._owner == "foo"
    # Test if the return value is expected with allow_duplicates

# Generated at 2022-06-11 10:41:45.869282
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata(owner=None).deserialize(dict(
        allow_duplicates=False,
        dependencies=[{'src': 'git@git.example.com/example-repo.git'}]
    ))
    assert not m._allow_duplicates
    assert len(m._dependencies) == 1
    assert isinstance(m._dependencies[0], dict)
    assert m._dependencies[0]['src'] == 'git@git.example.com/example-repo.git'



# Generated at 2022-06-11 10:41:57.139259
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    ds = dict(dependencies=['A', dict(role='B'), dict(src='C'), dict(src='D', version='1.0')])
    m = RoleMetadata(owner=None).load_data(ds)

    deps = m.get_dependencies()
    assert len(deps) == 4
    assert isinstance(deps[0], RoleDefinition)
    assert isinstance(deps[1], RoleDefinition)
    assert isinstance(deps[2], RoleRequirement)
    assert isinstance(deps[3], RoleRequirement)

    # We should fail gracefully if we don't have an owner

# Generated at 2022-06-11 10:42:00.206339
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': 'true', 'dependencies': 'test'})
    assert r._allow_duplicates is True
    assert r._dependencies == 'test'


# Generated at 2022-06-11 10:42:02.427584
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    d = RoleMetadata()
    d.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert d.allow_duplicates == False
    assert d.dependencies == []

# Generated at 2022-06-11 10:42:27.286276
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("\n=========== test_RoleMetadata: ===========")
    role_metadata = RoleMetadata()

# Generated at 2022-06-11 10:42:31.436391
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies=[{'role': 'role1'}, {'role': 'role2', 'name': 'name2'}])
    m.deserialize(data)
    assert data == m.serialize()

# Generated at 2022-06-11 10:42:35.973276
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = False
    m.dependencies = []

    assert m.serialize() == {"allow_duplicates": False, "dependencies": []}, "serialize() returns a wrong result"

# Generated at 2022-06-11 10:42:38.349771
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner = {'_role_path': 'test/path'})
    assert m._owner == {'_role_path': 'test/path'}

# Generated at 2022-06-11 10:42:41.721967
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_data = role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_data['allow_duplicates'] == [], 'The test for deserialize of class RoleMetadata has failed!'

# Generated at 2022-06-11 10:42:43.332244
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    c = RoleMetadata()
    assert c
    c = RoleMetadata(owner=True)
    assert c

# Generated at 2022-06-11 10:42:47.463491
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict()
    data['allow_duplicates'] = True
    data['dependencies'] = [{"foo": "bar"}]
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == [{"foo": "bar"}]

# Generated at 2022-06-11 10:42:49.435658
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    m.deserialize(data)
    assert data == m.serialize()

# Generated at 2022-06-11 10:42:50.530511
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata

# Generated at 2022-06-11 10:42:52.353893
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    unit test for RoleMetadata class method load
    """
    pass



# Generated at 2022-06-11 10:43:44.507939
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {
        'allow_duplicates': False,
        'dependencies': [
            'role1',
            'role2',
            {'src': 'role3', 'version': '3.4.5'},
            {'name': 'role4', 'somevar': 'someval'}
        ]
    }
    m = RoleMetadata.load(data, None, None)
    assert m.allow_duplicates is False
    assert len(m.dependencies) == 4
    assert m.dependencies == data.get('dependencies')

# Generated at 2022-06-11 10:43:53.225132
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import json
    import copy
    import sys

    class module_utils_psutil_memory_virtual:

        def __init__(self):
            self.vms = 0

        def serialize(self):
            return self.vms

    class module_utils_psutil_memory_swap:

        def __init__(self):
            self.vms = 0

        def serialize(self):
            return self.vms

    class module_utils_psutil_virtual_memory:

        def __init__(self):
            self.vms = 0

        def serialize(self):
            return self.vms

    class module_utils_psutil_swap_memory:

        def __init__(self):
            self.vms = 0

        def serialize(self):
            return self.vms

   

# Generated at 2022-06-11 10:43:55.328862
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    obj = RoleMetadata()
    assert obj.__class__.__name__ == 'RoleMetadata'


# Generated at 2022-06-11 10:43:59.801428
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert issubclass(RoleMetadata,Base)
    assert RoleMetadata.__mro__ == Base.__mro__
    assert Base.__mro__ == (Base, object)
    assert RoleMetadata.load()


if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-11 10:44:02.857332
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-11 10:44:13.886628
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # data
    m = {
        'allow_duplicates': True,
        'dependencies': [
            {
                "role": "ansible-role-foo",
                "vars": {
                    "foo_var": 1
                }
            }
        ]
    }

    # create object and serialize
    expected = dict(
        allow_duplicates=True,
        dependencies=[
            {
                'role': 'ansible-role-foo',
                'vars': {
                    'foo_var': 1
                }
            }
        ]
    )
    obj = RoleMetadata.load(m, owner=None)
    actual = obj.serialize()

    # make sure that serialized object equals expected value

# Generated at 2022-06-11 10:44:21.189651
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    r_data = {
        "allow_duplicates": True,
        "dependencies": ["another_collection.role", { "name": "another_collection.role", "src": "another_collection.role", "vars": {"a": "b" }}]
    }
    test_role = Role()
    test_role.name = 'my_role'
    test_role.metadata = RoleMetadata.load(r_data, test_role)
    assert test_role.metadata.serialize() == r_data

# Generated at 2022-06-11 10:44:23.348598
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert isinstance(role, RoleMetadata)
    assert role.dependencies == []
    assert not role.galaxy_info
    assert not role.allow_duplicates
    assert role.argument_specs == {}

# Generated at 2022-06-11 10:44:25.977029
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates is False
    assert not role_metadata.dependencies

# Generated at 2022-06-11 10:44:35.306298
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-11 10:46:13.779671
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition

    roleDef = RoleDefinition()
    roleDef._collection_name = "test.role"
    roleDef._role_name = "test.role"

    roleMetadata = RoleMetadata(roleDef)

    # Test if allow_duplicates is set to False if not given
    assert roleMetadata.get_allow_duplicates() == False 

    # Test if dependencies is set to [] if not given
    assert roleMetadata.get_dependencies() == []

# Generated at 2022-06-11 10:46:16.288358
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {'allow_duplicates': False, 'dependencies': []}
    obj = RoleMetadata()
    obj.deserialize(data)
    res = obj.serialize()

    assert res == data
# END Unit test for method serialize of class RoleMetadata

# Generated at 2022-06-11 10:46:17.791115
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    assert r.serialize() == {'dependencies': [], 'allow_duplicates': False}


# Generated at 2022-06-11 10:46:21.968906
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    dependencies = "dependencies"
    allow_duplicates = "allow_duplicates"
    dict_ = dict(
        allow_duplicates=allow_duplicates,
        dependencies=dependencies
    )
    collection = RoleMetadata()
    collection.deserialize(dict_)
    dict_serialize = dict(
        allow_duplicates=allow_duplicates,
        dependencies=dependencies
    )
    assert collection.serialize() == dict_serialize

# Generated at 2022-06-11 10:46:29.033852
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.collection import AnsibleCollectionConfig
    from ansible.vars.manager import VariableManager

    role = Role.load(dict(
        meta=dict(
            main=dict(
                dependencies=dict(
                    foo=dict(role='foo')
                )
            )
        )
    ))
    assert(role.get_dependencies()[0].get_name() == "foo")

    role = Role.load(dict(
        meta=dict(
            main=dict(
                dependencies=dict(
                    foo=dict(role='foo', version='1.0.0')
                )
            )
        )
    ))
    assert(role.get_dependencies()[0].get_name() == "foo")

# Generated at 2022-06-11 10:46:31.651680
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    expected = dict(
        allow_duplicates=True,
        dependencies=[{'name': 'foo', 'role': 'bar'}]
    )
    rm = RoleMetadata()
    rm.deserialize(expected)
    actual = rm.serialize()
    assert actual == expected

# Generated at 2022-06-11 10:46:37.566829
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role.allow_duplicates = True
    role.dependencies = [{'role': 'common', 'tags': 'common'}, {'role': 'webserver', 'tags': 'webserver'}]
    serialized_role = role.serialize()
    assert serialized_role['allow_duplicates'] == True
    assert serialized_role['dependencies'] == [{'role': 'common', 'tags': 'common'}, {'role': 'webserver', 'tags': 'webserver'}]

# Generated at 2022-06-11 10:46:42.576136
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class MockRole(object):
        def __init__(self, name):
            self._name = name
        def get_name(self):
            return self._name

    def walk(name):
        return [(name, [], [])]
    data = [
        'foo',
        'bar',
    ]
    mockOs = MockOsModule(walk)
    mockRole = MockRole('name')

    roleMetadata = RoleMetadata.load(data, mockRole, loader=mockOs)
    roleMetadata.get_dependencies()



# Generated at 2022-06-11 10:46:48.604137
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    role_def = RoleDefinition()
    role_metadata = RoleMetadata(role_def)

    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [1, 2]

    serialized_data = role_metadata.serialize()
    #print(serialized_data)
    #assert serialized_data == {'allow_duplicates': True, 'dependencies': [1, 2]}

    serialized_data_copy = serialized_data.copy()
    role_metadata.deserialize(serialized_data_copy)
    #print(serialized_data_copy)
    assert serialized_data == serialized_data_copy

# Generated at 2022-06-11 10:46:49.074837
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()