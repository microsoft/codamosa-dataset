

# Generated at 2022-06-11 10:39:25.023761
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_RoleMetadata1 = RoleMetadata()
    test_RoleMetadata1.deserialize({'dependencies': [{'role': 'test'}, {'role': 'test2'}]})
    assert test_RoleMetadata1._dependencies[1]['role'] == 'test2'

    test_RoleMetadata2 = RoleMetadata()
    with pytest.raises(AnsibleParserError) as excinfo:
        test_RoleMetadata2.deserialize({'dependencies': 'test'})
    assert 'Expected role dependencies to be a list' in str(excinfo.value)

    test_RoleMetadata3 = RoleMetadata()

# Generated at 2022-06-11 10:39:29.001207
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    data = rmd.serialize()
    rmd.deserialize(data)
    assert rmd._allow_duplicates == data['allow_duplicates']
    assert rmd._dependencies == data['dependencies']

# Generated at 2022-06-11 10:39:32.343446
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': []}
    role = RoleMetadata(owner=None)
    role.deserialize(data)
    assert role.allow_duplicates == False
    assert role.dependencies == []

# Generated at 2022-06-11 10:39:41.164276
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.vars import combine_vars

    pb = Play()
    # Create a role
    my_role = RoleDefinition()
    # Role name
    my_role._role_name = 'myrole'
    # Role path
    my_role._role_path = '/home/ansible/roles/myrole'
    # Role dependencies
    my_role.dependencies = []

    # Create a RoleMetadata instance
    meta = RoleMetadata(owner=my_role)
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []

    meta.load(data=data, owner=my_role, variable_manager=None, loader=None)


# Generated at 2022-06-11 10:39:45.409810
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    r = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies=[])
    r.deserialize(data)
    assert r.allow_duplicates == True
    assert r.dependencies == []


# Generated at 2022-06-11 10:39:54.949711
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    role_namerole = Role()
    role_namerole.name = 'role'
    role_includerole = RoleInclude()
    role_includerole.role = role_namerole

    test_role_metadata = RoleMetadata()
    test_role_metadata.deserialize({'allow_duplicates':False, 'dependencies':[role_includerole]})
    assert test_role_metadata.allow_duplicates == False
    assert test_role_metadata.dependencies == [role_includerole]


# Generated at 2022-06-11 10:39:59.050334
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata(owner=None)
    m._dependencies = ['role1', 'role2']
    m._allow_duplicates = True
    assert m.serialize() == dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    )

# Generated at 2022-06-11 10:40:03.262632
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    serialized_data={
        "allow_duplicates": False,
        "dependencies": []
    }
    RoleMetadata_obj=RoleMetadata()
    serialized_data_obj=RoleMetadata_obj.serialize()
    assert serialized_data==serialized_data_obj


# Generated at 2022-06-11 10:40:08.351859
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import ansible.playbook.role.definition
    rd = ansible.playbook.role.definition.RoleDefinition()
    rm = RoleMetadata(rd)
    assert rm._allow_duplicates == False
    assert rm._dependencies == []
    assert rm._owner == rd
    assert rm._argument_specs == {}
    assert rm._galaxy_info == None

# Generated at 2022-06-11 10:40:12.665040
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Verify constructor without parameters:
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}


# Generated at 2022-06-11 10:40:26.634842
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    r = RoleDefinition()
    assert r.deserialize({}) is None

test_RoleMetadata_deserialize()

# Generated at 2022-06-11 10:40:29.554194
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['name1', 'name2']
    )
    result = RoleMetadata.serialize(data)
    assert result == data

# Generated at 2022-06-11 10:40:30.575704
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    obj = RoleMetadata()
    assert obj is not None

# Generated at 2022-06-11 10:40:40.098365
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Load fixture
    moduleManager = MockModuleManager()
    moduleManager.all()['role'] = ['k8s', 'docker']
    moduleManager.all()['collections'] = ['k8s', 'docker']

    moduleManager.all()['k8s'] = {'name': 'k8s', 'path': '~/projects/ansible-role-k8s', 'child': {'defaults': {'host': '192.168.1.1'}}}
    moduleManager.all()['docker'] = {'name': 'docker', 'path': '~/projects/ansible-role-docker', 'child': {'defaults': {'host': '192.168.1.1'}}}

# Generated at 2022-06-11 10:40:41.219633
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # TODO: Test this
    return True


# Generated at 2022-06-11 10:40:44.379160
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()

    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})

    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-11 10:40:56.740350
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    # RoleMetadata.load relies on the data contained in Play
    # For this mocking out Play includes and excludes
    play = Play()
    role0 = RoleDefinition()
    role1 = RoleDefinition()

    role0._role_name = 'role0'
    role0._role_path = 'role0_path'
    role1._role_name = 'role1'
    role1._role_path = 'role1_path'
    play.roles = [role0, role1]
    role_include0 = RoleInclude()
    role_include0._role_name = 'role0'

# Generated at 2022-06-11 10:40:57.350531
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-11 10:41:04.766401
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-locals
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.collections.ansible import AnsibleCollectionRef
    from ansible.collections.ansible.plugins.module_utils.common.collections_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader

    mock_loader = DataLoader()
    mock_collection = AnsibleCollectionRef.from_string('ansible.foo')
    mock_loader.set_basedir(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'unit', 'data', 'collection_loader'))
    mock_loader.set_collection_playbook_paths

# Generated at 2022-06-11 10:41:13.451564
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import configparser

    _config = configparser.ConfigParser()
    _config.readfp(BytesIO("""[defaults]
force_handlers=True
"""))
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole

    p = PlayContext(play=dict(
        name='play 1'
    ))

    r = IncludeRole(name='fake', play=p, play_context=p, role_path="./tests/test_data/test_roles/dependency_role")

    m = RoleMetadata(owner=r)
    m.load(dict(
        dependencies=[]
    ), owner=r)


# Generated at 2022-06-11 10:41:34.348362
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {"allow_duplicates": True,
            "dependencies": [
                {"role": "geerlingguy.apache",
                 "version": "v2.1.0"},
                {"role": "geerlingguy.mysql",
                 "version": "v2.1.0"},
                {"role": "geerlingguy.php",
                 "version": "v2.1.0"},
                {"role": "geerlingguy.composer",
                 "version": "v2.1.0"},
                {"role": "geerlingguy.drush",
                 "version": "v2.1.0"}
            ]}
    r.deserialize(data)
    assert r.allow_duplicates is True
    assert len(r.dependencies) == 5

# Generated at 2022-06-11 10:41:42.460919
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play

    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [
            dict(
                role = 'test1',
                meta = dict(
                    allow_duplicates=True,
                    dependencies=[
                        dict(name='role1', src='/path/to/role1'),
                        dict(role='test2'),
                    ]
                )
            )
        ]
    ), variable_manager=None, loader=None)

    assert play.get_roles()[0]._role_name == 'test1'
    assert play.get_roles()[0].meta.allow_duplicates

# Generated at 2022-06-11 10:41:44.917244
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    data = role.serialize()
    assert data['allow_duplicates'] is False
    assert data['dependencies'] == []



# Generated at 2022-06-11 10:41:51.408983
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Tests that deserialize works as expected
    data = {}
    data['allow_duplicates'] = True
    data['dependencies'] = ['example1', 'example2']
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == ['example1', 'example2']



# Generated at 2022-06-11 10:42:00.947496
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # default values
    r1 = RoleMetadata()
    assert r1._allow_duplicates == False
    assert r1._dependencies == []

    # allow_duplicates
    r2 = RoleMetadata(allow_duplicates=True)
    assert r2._allow_duplicates == True
    assert r2._dependencies == []

    # dependencies
    r3 = RoleMetadata(dependencies=['A'])
    assert r3._allow_duplicates == False
    assert r3._dependencies == ['A']

    # all values
    r4 = RoleMetadata(allow_duplicates=True, dependencies=['A', 'B'])
    assert r4._allow_duplicates == True
    assert r4._dependencies == ['A', 'B']


# Generated at 2022-06-11 10:42:11.000527
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.collectionsearch import CollectionSearch
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                src='galaxy.role,version,name',
            ),
        ]
    )
    m = RoleMetadata().deserialize(data)
    # allow_duplicates
    assert m._allow_duplicates == True
    # dependencies
    dependencies = []
    dependencies.append(RoleRequirement.role_yaml_parse({
        'src': 'galaxy.role,version,name',
    }))
    assert m._dependencies == dependencies

# Generated at 2022-06-11 10:42:20.918687
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class TestRoleMetadata(RoleMetadata):
        def __init__(self, data):
            self.data = data
            super(TestRoleMetadata, self).__init__()

        def serialize(self):
            return dict(
                allow_duplicates=self.data.get('allow_duplicates', False),
                dependencies=self.data.get('dependencies', [])
            )
    
    for data in [{}, {'allow_duplicates': True}, {'dependencies': [{'role': 'dummy'}]}, {'allow_duplicates': True, 'dependencies': [{'role': 'dummy'}]}]:
        metadata = TestRoleMetadata(data)
        metadata.deserialize(data)


# Generated at 2022-06-11 10:42:28.567203
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play import PlaySerializer
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.role_dependency import RoleDependency

    # Load a play
    ps = PlaySerializer()

# Generated at 2022-06-11 10:42:38.723421
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.requirement import RoleRequirement

    class Role(RoleMetadata):
        def __init__(self, allow_duplicates, dependencies):
            self.allow_duplicates = allow_duplicates
            self.dependencies = dependencies

    required_dict = {}
    required_dict['allow_duplicates'] = False
    required_dict['dependencies'] = [{'name': 'foo', 'role': 'foo'}]

    role = Role(**required_dict)

    serialized = role.serialize()

    assert required_dict['allow_duplicates'] == serialized['allow_duplicates']
    assert type(serialized['dependencies'][0]) is RoleRequirement



# Generated at 2022-06-11 10:42:47.426617
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """ test_RoleMetadata_load: test loading RoleMetadata and its subclasses """
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    role = Role.load('/nonexistent/roles/somerole', playbook=Playbook())

    m = RoleMetadata.load({}, owner=role)
    assert isinstance(m._dependencies, list)
    assert not m._dependencies

    m = RoleMetadata.load({'dependencies': []}, owner=role)
    assert isinstance(m._dependencies, list)
    assert not m._dependencies

    m = RoleMetadata.load({'dependencies': {}}, owner=role)
    assert isinstance(m._dependencies, list)
    assert not m._

# Generated at 2022-06-11 10:43:13.090934
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_dependency_list = ['role1', 'role2']
    role_metadata = RoleMetadata(owner = None)
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == {}
    assert role_metadata._argument_specs == {}
    assert role_metadata._owner == None
    

# Generated at 2022-06-11 10:43:23.412970
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    def mock_import_module(name):
        obj = None
        if name == 'ansible':
            obj = ansible_mock

        return obj

    ansible_mock = type("obj", (object,), { "__version__": "2.1.0.0" })

    m = MockModule()
    m.params = {
        "name": "test",
        "hosts": "localhost",
        "tasks": [
            { "action": { "module": "win_ping" } },
        ]
    }
    m.ds = {
        "dependencies": [
            {
                "name": "test_role",
                "version": "1.2.3"
            }
        ]
    }

# Generated at 2022-06-11 10:43:25.077250
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata.deserialize({'allow_duplicates': False, 'dependencies': []})

# Generated at 2022-06-11 10:43:34.629922
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task.include import TaskInclude

    rd = RoleDefinition.load(dict(
        name='test',
        tasks=dict(
            main=dict(
                include=dict(
                    name="foobar"
                )
            )
        )
    ))

    assert rd.get_tasks()[0].serialize() == dict(
        include=dict(
            name='foobar'
        )
    )

    t = TaskInclude.load(dict(
        name="foobar"
    ))

    assert t.serialize() == dict(
        name='foobar'
    )


# Generated at 2022-06-11 10:43:38.499285
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata.load({'dependencies': [{'name': 'foo'}]}, None)
    role_meta_serialized = role_meta.serialize()
    assert role_meta_serialized == {'allow_duplicates': False, 'dependencies': [{'name': 'foo'}]}


# Generated at 2022-06-11 10:43:42.543792
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # create a RoleMetadata object
    role_metadata = RoleMetadata()

    # verify allow_duplicates attribute value is original
    assert role_metadata._allow_duplicates == False

    # verify dependencies attribute value is original
    assert role_metadata._dependencies == []

    # create dictionary data with new values
    data = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2'],
    )

    # deserialize data
    role_metadata.deserialize(data)

    # verify allow_duplicates attribute value has been updated
    assert role_metadata._allow_duplicates == True

    # verify dependencies attribute value has been updated
    assert role_metadata._dependencies == ['role1', 'role2']

# Generated at 2022-06-11 10:43:51.145378
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMeta

    def_1 = RoleDefinition.load(dict(role='role_1', tasks=[dict(name='task 1')])).serialize()
    def_2 = RoleDefinition.load(dict(role='role_2', tasks=[dict(name='task 2')])).serialize()
    include_1 = RoleInclude.load(dict(role='role_1')).serialize()
    include_2 = RoleInclude.load(dict(role='role_2')).serialize()
    dep_1 = dict(include_1).serialize()
    dep_2 = dict(include_2).serialize()


# Generated at 2022-06-11 10:44:00.273632
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {"dependencies": [],
            "allow_duplicates": False}
    owner = None
    role_metadata = RoleMetadata(owner)
    role_metadata.deserialize(data)
    assert role_metadata.deserialize(data) == None
    serialized_data = role_metadata.serialize()
    expected_serialized_data = dict(
        dependencies=role_metadata._dependencies,
        allow_duplicates=role_metadata._allow_duplicates
    )
    assert serialized_data == expected_serialized_data
    data = {"dependencies": [],
            "allow_duplicates": False}
    assert RoleMetadata.load(data, owner) != None

# Generated at 2022-06-11 10:44:02.125101
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    test_instance = RoleMetadata()

    assert isinstance(test_instance, RoleMetadata), "Type of RoleMetadata invalid"

# Generated at 2022-06-11 10:44:05.555627
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class Role():
        def __init__(self):
            self._role_path = '.'

    r = Role()
    rm = RoleMetadata(owner=r)
    assert rm._allow_duplicates is False
    assert rm._dependencies == []

# Generated at 2022-06-11 10:45:28.284570
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os

    current_dir = os.path.dirname(os.path.abspath(__file__))
    role_dir_name = os.path.join(current_dir, 'samples', 'role_skels_by_version', 'role_skel_2.0')
    assert os.path.exists(role_dir_name)

    role = RoleMetadata(role_dir_name)
    role.load()

    assert role.license == 'Apache 2.0'
    assert role.description == 'An apache role'
    assert role.dependencies == [{'role': 'dependency1'}, {'role': 'dependency2'}, {'role': 'dependency3'}]
    assert role.min_ansible_version == '2.0'

# Generated at 2022-06-11 10:45:31.078104
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []


# Generated at 2022-06-11 10:45:40.095878
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 10:45:43.176063
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': ['role_1', 'role_2']}
    role.deserialize(data)
    assert role.allow_duplicates == True
    assert role.dependencies == ['role_1', 'role_2']

# Generated at 2022-06-11 10:45:44.979334
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta.allow_duplicates = True
    assert meta.serialize()['allow_duplicates']

# Generated at 2022-06-11 10:45:49.451119
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata(owner=None).serialize() == {'allow_duplicates': False, 'dependencies': []}
    r = RoleMetadata(owner=None)
    r._dependencies = ['test']
    r._allow_duplicates = True
    assert r.serialize() == {'allow_duplicates': True, 'dependencies': ['test']}


# Generated at 2022-06-11 10:45:58.449706
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.manager import VariableManager

    def _create_role_metadata(r_name):
        r = Role()
        r._role_name = r_name
        r_metadata = RoleMetadata.load(dict(dependencies=[dict(role=r_name)]), r)
        return r_metadata

    # role_metadata = RoleMetadata.load(dict(dependencies=[dict(role='geerlingguy.jenkins')]), None)
    # assert role_metadata is not

# Generated at 2022-06-11 10:46:06.692470
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils._text import to_bytes

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


    class TestModule:
        def __init__(self, *args, **kwargs):
            self.play_basedir = self.path = '/path/to/fake/roles/my_role/tasks'
            self.role_name = 'my_role'

        def _load_role_collections(self, role_def):
            return role_def

        @staticmethod
        def get_default_vars(play=None):
            return []

    m = TestModule()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
   

# Generated at 2022-06-11 10:46:12.363958
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test the ability to use a string for the dependency
    role_meta = RoleMetadata()
    role_meta.dependencies = ['geerlingguy.java']
    role = role_meta

    # Test conversions to a string
    role.dependencies = ['geerlingguy.java']
    # import pdb; pdb.set_trace()
    assert(len(role_meta.dependencies) == 1)
    assert('geerlingguy.java' in role_meta.dependencies[0])

    # Test conversions to a dictionary
    role.dependencies = [{'role': 'geerlingguy.java'}]
    assert(len(role_meta.dependencies) == 1)
    assert('geerlingguy.java' in role_meta.dependencies[0])

    # Test conversion from one form to another
   

# Generated at 2022-06-11 10:46:17.217603
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.path import RolePath
    from ansible.playbook.role.role import Role
    # create role
    owner_role = Role()
    owner_role._role_path = RolePath(path='./empty')
    # create metadata object
    metadata = RoleMetadata(owner=owner_role).deserialize(dict(allow_duplicates=True, dependencies=['test1', 'test2']))
    assert metadata.allow_duplicates == True
    assert metadata.dependencies == ['test1', 'test2']

# Generated at 2022-06-11 10:47:23.473358
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-11 10:47:25.697688
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata(owner=None)
    assert m._allow_duplicates == False
    assert m._dependencies == []
    assert m._galaxy_info == None
    assert m._argument_specs == {}

# Generated at 2022-06-11 10:47:33.001922
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role_name = 'example_role'
    role_path = './'
    role_manager = RoleDefinition(role_name, role_path, role_path)
    metadata = RoleMetadata(owner=role_manager)
    assert metadata
    for x in ['allow_duplicates', 'dependencies', 'galaxy_info', 'argument_specs']:
        assert getattr(metadata, '_' + x) == []
    assert metadata._owner.get_name() == 'example_role'
    assert metadata._owner.get_role_path() == './'
    assert metadata._owner.get_collections() == ['./']


# Generated at 2022-06-11 10:47:42.710383
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {
        'dependencies': [
            "role1",
            {
                "role": "role2",
                "vars": {
                    "var1": "val1"
                }
            },
            {
                "role": "role3",
                "var1": "val1",
                "another_var": "{{var1}}"
            }
        ],
        'galaxy_info': {
            'author': 'me'
        }
    }
    metadata = RoleMetadata().load_data(data)

# Generated at 2022-06-11 10:47:48.497834
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_name = 'test_role'
    role_dir = '/a/dir/roles/test_role'
    owner_play = None
    owner = RoleRequirement(role_name, role_dir, owner_play)
    data = {'allow_duplicates': True}
    variable_manager = None
    loader = None
    meta = RoleMetadata(owner=owner).load_data(data, variable_manager=variable_manager, loader=loader)
    assert meta._owner == owner


# Generated at 2022-06-11 10:47:57.721462
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {
        'allow_duplicates': False,
        'dependencies': [
            {'role': 'somedeps', 'collection': 'somedepcol'},
            {'src': 'otherdeps', 'collection': 'otherdepcol'}],
        'galaxy_info': {'author': 'Someone', 'license': 'Something Open'},
        'argument_spec': {
            'arg1': {'default': True},
            'arg2': {'type': 'str', 'default': 'default2'},
            'arg3': {'type': 'list', 'default': ['a', 'b', 'c']},
            'arg4': {'type': 'dict', 'default': {'x': 'y'}}
        }
    }
    loader = None
    variable_manager = None
    owner

# Generated at 2022-06-11 10:48:07.278064
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    ansible.playbook.role.metadata.RoleMetadata serialize
    units tests for method serialize of class RoleMetadata
    '''

    m = RoleMetadata()
    dep_array = [{'role': 'test1', 'version': 'test2'}, {'role': 'test3', 'version': 'test4'}]
    m.dependencies = dep_array

    data = m.serialize()
    assert len(data.keys()) == 2, "Unexpected size of serialized output"
    assert 'allow_duplicates' in data.keys(), "Key 'allow_duplicates' missing from serialized output"
    assert 'dependencies' in data.keys(), "Key 'dependencies' missing from serialized output"

# Generated at 2022-06-11 10:48:10.840004
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    a = RoleMetadata()
    setattr(a, 'allow_duplicates', True)
    setattr(a, 'dependencies', "something")
    s = a.serialize()
    assert s == {
        'allow_duplicates': True,
        'dependencies': "something"
    }


# Generated at 2022-06-11 10:48:18.918587
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create object, passing an object of class Role.
    # Notice that constructor will call functions load_data and load
    # on the object using the arguments 'datastructure' and 'owner'.
    # Notice that load_data will initialize the object (self)
    # with datastructure: 'datastructure' and set its owner (self._owner)
    # to the object 'owner'
    # And then, load will call its methods to set attributes
    # as specified in the datastructure 'datastructure'

    # Create a datastructure for the object
    datastructure1 = {
        'galaxy_info': {
            'author': ['someone']
        }
    }

    # Empty datastructure should exist in this case
    datastructure2 = {}  

    from ansible.playbook.role import Role 

# Generated at 2022-06-11 10:48:19.691575
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata(None)