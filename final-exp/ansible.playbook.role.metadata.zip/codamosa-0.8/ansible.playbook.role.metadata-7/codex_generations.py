

# Generated at 2022-06-11 10:39:17.655421
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # @TODO replace this test with unittest
    from ansible.playbook.role.definition import RoleDefinition
    rdef = RoleDefinition.load('test', '/etc/ansible/roles')

    fake_data = ({
    'allow_duplicates': True,
    'dependencies': [
        {'role':'common', 'foo': 'bar'}
    ]
    })

    rmeta = RoleMetadata(rdef)
    rmeta.deserialize(fake_data)

    assert rmeta.allow_duplicates == True
    assert rmeta.dependencies[0].role == 'common'
    assert rmeta.dependencies[0].foo == 'bar'

# Generated at 2022-06-11 10:39:18.670709
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    RoleMetadata().serialize()

# Generated at 2022-06-11 10:39:29.096101
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test if it's possible to deserialize a object
    testobj=RoleMetadata()
    testobj.deserialize({'allow_duplicates':True,'dependencies':[{'role':'test'}]})
    assert testobj.allow_duplicates
    assert testobj.dependencies[0].role == 'test'

    # Test if wrong values raises exceptions
    testobj=RoleMetadata()
    try:
        testobj.deserialize({'allow_duplicates':1,'dependencies':[{'role':'test'}]})
        raise AssertionError("deserialize should raise exception when value type is wrong")
    except ValueError:
        pass

    testobj=RoleMetadata()

# Generated at 2022-06-11 10:39:37.263343
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.collectionsearch import CollectionsSearch
    import collections

    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    collections_path = ['./my_collection']
    role_collection = 'my_collection'
    r = RoleDefinition(None)
    r._role_collection = role_collection
    r._loader = None
    r._variable_manager = None
    r._collections_paths = collections_path
    r.deserialize(data)
    ds = [r]

    m = RoleMetadata()
    m.deserialize(data)
    # Allow duplicate roles
    m.allow_duplicates = True

# Generated at 2022-06-11 10:39:48.349189
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import variable_manager
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    data = dict(
        dependencies=['geerlingguy.java',
                      dict(role='geerlingguy.mysql'),
                      dict(name='geerlingguy.apache', other_vars='here')],
        allow_duplicates=False
    )


# Generated at 2022-06-11 10:39:50.308840
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta = RoleMetadata()
    meta.load({'dependencies': []})
    assert meta.dependencies == []

# Generated at 2022-06-11 10:39:54.241356
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2', 'role3'],
    )
    obj = RoleMetadata(metadata)
    assert obj.serialize() == metadata

# Generated at 2022-06-11 10:39:59.093447
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = False
    role_metadata.dependencies = []

    assert role_metadata.serialize() is not None
    assert role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []}) == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:40:09.363094
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader import AnsibleCollectionConfig

# Generated at 2022-06-11 10:40:09.978811
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:40:16.417203
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-11 10:40:17.756844
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata()
    assert isinstance(a, RoleMetadata)


# Generated at 2022-06-11 10:40:28.291544
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    # Create a RoleDefinition for testing. RoleDefinition is an abstract base class and cannot be instantiated.
    # Therefore, it is mocked here (metaclass=type)
    RoleDefinitionMock = type('RoleDefinitionMock', (RoleDefinition,), {})

    # Create a RoleInclude for testing
    data = {
        'name': 'role_name0',
        'tasks_from': './tasks/main.yml',
    }
    role_include0 = RoleInclude(data=data, role_definition_class=RoleDefinitionMock, loader=None)

    # Create a RoleInclude for testing

# Generated at 2022-06-11 10:40:35.621976
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    data = {'dependencies': [{'role': 'rajeshkumar.ansible-nginx', 'name': 'rajeshkumatic.ansible-nginx'}], 'allow_duplicates': False}
    obj.deserialize(data)
    assert obj.deserialize(data) == {'dependencies': [{'role': 'rajeshkumar.ansible-nginx', 'name': 'rajeshkumatic.ansible-nginx'}], 'allow_duplicates': False}


# Generated at 2022-06-11 10:40:39.754307
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['test_role1', 'test_role2']})
    assert role_metadata.allow_duplicates is True
    assert role_metadata.dependencies == ['test_role1', 'test_role2']

# Generated at 2022-06-11 10:40:45.271771
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.plugins.loader import find_plugin

    class FakeRole(Role):
        _role_path = './tests/lib/ansible/data/test_collections/ansible_namespace/other/roles/test_role'
        _role_collection = 'ansible_namespace.other'

        def __init__(self, *args, **kwargs):
            super(FakeRole, self).__init__(*args, **kwargs)
            self.metadata = None
            self.plugin_loaders = {'action': find_plugin}

    role = FakeRole()
    role_metadata = RoleMetadata.load(role_data, role)
    assert role_metadata is not None
    assert role_metadata.allow_duplicates is False


# Generated at 2022-06-11 10:40:57.685278
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    # Check if object is created
    my_role_metadata = RoleMetadata()
    assert isinstance(my_role_metadata, RoleMetadata)
    assert hasattr(my_role_metadata, '_allow_duplicates')
    assert hasattr(my_role_metadata, '_dependencies')
    assert hasattr(my_role_metadata, '_galaxy_info')
    assert hasattr(my_role_metadata, '_argument_specs')

    # Check if default values set correctly
    assert my_role_metadata.allow_duplicates == False
    assert my_role_metadata.dependencies == []
    assert my_role_metadata.galaxy_info == None
    assert my_role_metadata.argument_specs == {}

    # Check if values set correctly

# Generated at 2022-06-11 10:41:01.327930
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    owner = object
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    r = RoleMetadata(owner)
    r.deserialize(data)
    assert r.allow_duplicates == False and r.dependencies == []


# Generated at 2022-06-11 10:41:04.108584
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': []}
    metadata.deserialize(data)
    assert metadata.allow_duplicates
    assert metadata.dependencies == []


# Generated at 2022-06-11 10:41:05.575985
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO(akozumpl): implement
    pass


# Generated at 2022-06-11 10:41:26.172364
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import json
    import os
    import collections
    import ansible.constants
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task

    loader = DataLoader()
    play_context = PlayContext()

# Generated at 2022-06-11 10:41:36.735484
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role

    m1 = RoleMetadata()
    assert m1.dependencies == []
    assert m1.allow_duplicates == False
    assert m1._galaxy_info == None
    assert m1._argument_specs == None

    role1 = Role()
    role1._role_path = "test/test_role_meta_main.yml"

    m2 = RoleMetadata(owner=role1)
    assert m2.dependencies == []
    assert m2.allow_duplicates == False
    assert m2._galaxy_info == None
    assert m2._argument_specs == {}

    # Testing load(data, owner, variable_manager, loader)

# Generated at 2022-06-11 10:41:38.488447
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ''' test_RoleMetadata

    Unit test for constructor of class RoleMetadata
    '''

    data = {}
    metadata = RoleMetadata.load(data, owner=None)
    assert not metadata.allow_duplicates


# Generated at 2022-06-11 10:41:42.585624
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    a = RoleMetadata()
    a.allow_duplicates = True
    a.dependencies = [{'role': 'role1'}, {'role': 'role2'}]
    assert a.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'role1'}, {'role': 'role2'}]}


# Generated at 2022-06-11 10:41:53.835503
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # test whether invalid constructor of class RoleMetadata may raise an error
    fake_role_name = 'invalid_constructor'
    fake_owner = 'faker'
    try:
        RoleMetadata(owner=fake_owner)
        assert False
    except AnsibleParserError:
        pass
    try:
        # invalid metadata
        invalid_metadata = AnsibleMapping()
        RoleMetadata(owner=fake_owner).load(data=invalid_metadata, owner=fake_owner)
        assert False
    except AnsibleParserError:
        pass
    # test whether constructor of class RoleMetadata may return an instance
    role_include = RoleInclude()


# Generated at 2022-06-11 10:41:57.051015
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    data = dict(
        dependencies=[],
        allow_duplicates=None,
    )
    meta.deserialize(data)
    assert meta.allow_duplicates == False



# Generated at 2022-06-11 10:42:02.730433
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # test without arguments, should initialize the path and dependencies with default values
    roleMetadata = RoleMetadata.deserialize({})
    assert roleMetadata.allow_duplicates == False
    assert roleMetadata.dependencies == []

    # test with arguments
    roleMetadata = RoleMetadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert roleMetadata.allow_duplicates == True
    assert roleMetadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-11 10:42:13.743623
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create an object of class RoleMetadata
    a = RoleMetadata()
    # Add a value to the object
    a.allow_duplicates = True
    # Add a value to the object
    a.dependencies = [{
        "role": "rolename",
        "scm": "git",
        "version": "v1.0.0",
        "name": "rolename",
        "path": "git+git@git_server:/path/to/role.git@v1.0.0#rolename",
        "src": "git+git@git_server:/path/to/role.git@v1.0.0",
        "url": "git@git_server:/path/to/role.git",
        "scmversion": "v1.0.0"
    }]
    #

# Generated at 2022-06-11 10:42:18.962744
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create SUT
    r = RoleMetadata()
    # assert r._allow_duplicates == False
    # assert r._dependencies == []

    data = {'allow_duplicates': True, 'dependencies': ['name']}
    r.deserialize(data)
    assert r._allow_duplicates == True
    assert r._dependencies == ['name']


# Generated at 2022-06-11 10:42:23.690373
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Instantiation
    my_dict = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    my_RoleMetadata = RoleMetadata()
    my_RoleMetadata.deserialize(my_dict)
    # Test
    my_dict2 = my_RoleMetadata.serialize()
    assert my_dict == my_dict2

# Generated at 2022-06-11 10:42:53.123623
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = [{'role': 'test1.testRole1'}, {'role': 'test2.testRole2'}]
    from ansible.playbook.role import Role
    role = Role()
    role.name = 'testRole'
    r = RoleMetadata()
    assert r.__class__.__name__ == 'RoleMetadata'
    assert not hasattr(r, 'allow_duplicates')
    assert not hasattr(r, 'dependencies')
    r = RoleMetadata(owner=role)
    assert hasattr(r, 'allow_duplicates')
    assert hasattr(r, 'dependencies')
    assert r.allow_duplicates == False
    assert r.dependencies == []
    r.allow_duplicates = True
    r.dependencies = data
    assert r.allow

# Generated at 2022-06-11 10:43:00.114854
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class TestRole:
        role_path = "test_role"
        _role_name = "test_role"
        _role_path = role_path

    owner = TestRole()
    m = RoleMetadata(owner)

    setattr(m, 'allow_duplicates', True)
    setattr(m, 'dependencies', [{'src': 'some_dir'}])

    assert m.serialize() == {'allow_duplicates': True, 'dependencies': [{'src': 'some_dir'}]}

# Generated at 2022-06-11 10:43:01.189740
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass


# Generated at 2022-06-11 10:43:04.358206
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    meta_data = RoleMetadata()
    assert meta_data is not None

    assert meta_data.allow_duplicates == False
    assert meta_data.dependencies == []

# Generated at 2022-06-11 10:43:10.916993
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Construct data parameter
    data={}
    data['allow_duplicates']=False
    data['dependencies']=list()

    # Construct RoleMetadata object
    roleMetadata = RoleMetadata()

    # Call deserialize method to set its instance attributes
    roleMetadata.deserialize(data)

    # Assert that its instance attributes equal to data
    assert roleMetadata.allow_duplicates == data['allow_duplicates']
    assert roleMetadata.dependencies == data['dependencies']

# Generated at 2022-06-11 10:43:11.713573
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r is not None

# Generated at 2022-06-11 10:43:14.788570
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=['role1', 'role2', 'role3']
    )
    r = RoleMetadata()
    r.deserialize(data)
    assert r.allow_duplicates is False
    assert r.dependencies == ['role1', 'role2', 'role3']

# Generated at 2022-06-11 10:43:21.147587
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test that a RoleMetadata object is correctly serialized into dict
    role_m = {
        'allow_duplicates': False,
        'dependencies': ['foo', 'bar']
    }

    role_m_obj = RoleMetadata()
    role_m_obj.deserialize(role_m)

    assert isinstance(role_m_obj, RoleMetadata)
    assert role_m_obj.serialize() == role_m

# Generated at 2022-06-11 10:43:23.290092
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    assert meta.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-11 10:43:30.093850
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    TestDS = RoleMetadata.load({'dependencies': [{'role': 'some_role'}]}, owner='owner', variable_manager=None, loader=None)
    assert TestDS.allow_duplicates == False
    assert TestDS.dependencies[0].role == 'some_role'

    TestDS = RoleMetadata.load({}, owner='owner', variable_manager=None, loader=None)
    assert TestDS.allow_duplicates == False
    assert len(TestDS.dependencies) == 0


# Generated at 2022-06-11 10:44:14.308613
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role

    role = Role.load({'name': 'myrole'},
                     variable_manager=None,
                     loader=None)
    role._role_path = '/path/to/role'

    role_metadata = RoleMetadata.load({'dependencies': [{'role': 'otherrole', 'name': 'the_other_role'}]},
                                      owner=role)
    assert role_metadata.serialize() == {'allow_duplicates': False,
                                         'dependencies': [{'role': 'otherrole', 'name': 'the_other_role'}]}



# Generated at 2022-06-11 10:44:22.747146
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.definition import RoleDefinition
    metadata = RoleMetadata()
    data = { "dependencies": ['role1', RoleRequirement('role2', '1.0.0')] }
    metadata.deserialize(data)
    assert data == metadata.serialize()
    assert isinstance(metadata.dependencies[0], RoleInclude)
    assert isinstance(metadata.dependencies[1], RoleDefinition)
    assert metadata.dependencies[0].name == 'role1'
    assert metadata.dependencies[0]._role_name == 'role1'
    assert metadata.dependencies[1].name

# Generated at 2022-06-11 10:44:26.823534
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    dependencies = ['test']
    role = RoleDefinition.load(dict(name='test', dependencies=dependencies), play=None)
    role_metadata = role.metadata
    role_metadata.serialize()


# Generated at 2022-06-11 10:44:36.657270
# Unit test for method serialize of class RoleMetadata

# Generated at 2022-06-11 10:44:39.312988
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    with pytest.raises(AnsibleParserError, match="the 'meta/main.yml' for role foo is not a dictionary"):
        RoleMetadata.load([], None)

# Generated at 2022-06-11 10:44:44.590620
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.base import Base

    # initialize class
    role_metadata = RoleMetadata()

    # test good condition
    test_ds = {'foo': 'bar'}
    result = role_metadata.load(test_ds, None)
    # check result
    assert isinstance(result, RoleMetadata)

    # test bad condition
    test_ds = [1, 2, 3]
    try:
        result = role_metadata.load(test_ds, None)
    except AnsibleParserError as e:
        pass

    # test with normal role
    from ansible.playbook.role import Role
    test_ds = {'name': 'test_role'}
    role = Role.load(test_ds, None)
    test_ds = {'foo': 'bar'}
    result = role

# Generated at 2022-06-11 10:44:50.125901
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Task
    from ansible.playbook.role import Role

    ##########################
    # _load_dependencies #
    ##########################
    # new style
    role_metadata = RoleMetadata(0)
    role_metadata._load_dependencies({'name': 'dependencies'}, {'role1': {'src': 'role2', 'version': '2.0.0'}})
    assert role_metadata.dependencies[0].get_name() == 'role2'
    assert role_metadata.dependencies[0].get_scm_branch() is None
    assert role_metadata.dependencies[0].get_scm_ref() is None
    assert role_metadata.dependencies[0].get_scm_url

# Generated at 2022-06-11 10:44:50.729933
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-11 10:44:57.292208
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    m = RoleMetadata()

    # data = {
    #     "allow_duplicates": True,
    #     "dependencies": [{"role": "geerlingguy.java"},{"role": "geerlingguy.jenkins"}]
    # }
    data = {"allow_duplicates": True}

    m.deserialize(data)

    assert m.allow_duplicates == True
    assert m.dependencies == []

# Generated at 2022-06-11 10:45:03.645263
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    class MyRole(object):
        def __init__(self):
            pass

        def part(self):
            return "Part"

    m = RoleMetadata(owner=MyRole())
    data = dict(
        allow_duplicates=True,
        dependencies=["Alice"]
    )
    m.load(data=data)
    assert m.allow_duplicates and m.dependencies[0] == 'Alice'

# Generated at 2022-06-11 10:46:08.796350
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata(owner=None)
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-11 10:46:15.012971
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from . import unittest
    class test_owner:
        def get_name(self):
            return "name"

    owner = test_owner()
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    r = RoleMetadata(owner)
    r.load_data(data, variable_manager=None, loader=None)

    serialize_data = r.serialize()

    unittest.TestCase().assertIsInstance(serialize_data, dict)
    unittest.TestCase().assertEqual(serialize_data['allow_duplicates'], data['allow_duplicates'])
    unittest.TestCase().assertEqual(serialize_data['dependencies'], data['dependencies'])



# Generated at 2022-06-11 10:46:17.093457
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }


# Generated at 2022-06-11 10:46:20.964623
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Test method RoleMetadata.serialize()
    """
    p = mock_loader()
    obj = p.load_from_file('test/unit/lib/ansible/playbook/test_role_metadata.yml')
    res = obj.serialize()
    assert(isinstance(res, dict))
    assert(res['allow_duplicates'] == False)
    assert(len(res['dependencies']) == 2)


# Generated at 2022-06-11 10:46:28.224592
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    import os

    fake_loader = DictDataLoader({
        'test.yml': "{}",
        'meta/main.yml': 'dependencies:\n- role: b'
    })

    fake_loader.set_basedir(os.getcwd())

    role_def = RoleDefinition('role_path', name="a")
    role_def = RoleDefinition('role_path', name="a")
    play = Play().load(dict(name="a play", hosts=["all"],
                            roles=[dict(role="a")]),
                       variable_manager=None, loader=fake_loader)

# Generated at 2022-06-11 10:46:31.370833
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test with invalid ds
    data = {}
    try:
        RoleMetadata.load(data)
    except AnsibleParserError:
        pass

    # Test with valid ds
    data = dict(
        allow_duplicates=True,
        dependencies={}
    )
    RoleMetadata.load(data)

# Generated at 2022-06-11 10:46:39.098024
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.collections.ansible.builtin import BuiltInCollection

    class MyRoleDefinition(RoleDefinition):
        def __init__(self, name, collection):
            self.name = name
            self.collection = collection
            self.path = '%s.%s' % (name, collection.root_path)

    r1 = MyRoleDefinition('role1', BuiltInCollection())
    r2 = MyRoleDefinition('role2', BuiltInCollection())
    r3 = MyRoleDefinition('role3', BuiltInCollection())


# Generated at 2022-06-11 10:46:44.942424
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Test serialized dynamic RoleMetadata object in Python 2 and Python 3.
    """
    from ansible.playbook.role.definition import RoleDefinition

    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = [RoleDefinition()]
    role_metadata._galaxy_info = ''
    role_metadata._argument_specs = {}
    role_metadata._owner = ''
    serialized_role_metadata = role_metadata.serialize()
    # Assert that RoleMetadata data has been serialized properly
    assert serialized_role_metadata == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-11 10:46:51.160049
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    d1 = dict(
        name="test_role_1",
        allow_duplicates=True,
        dependencies=[
            dict(
                name="test_role_0",
                allow_duplicates=False,
                dependencies=[]
            )
        ]
    )
    r1 = RoleDefinition.load(d1)

    d2 = dict(
        name="test_role_2",
        allow_duplicates=False,
        dependencies=[
            dict(name='test_role_0')
        ]
    )
    r2 = RoleDefinition.load(d2)


# Generated at 2022-06-11 10:46:58.990008
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # This fails if data is not a dictionary
    data = {}
    class Role:
        def get_name(self):
            return "role_name"
    r = Role()
    assert (RoleMetadata.load(data, r))

    # This fails if not RoleInclude
    data = [
        {
            "role": "some_role"
        },
        {
            "role": "some_role"
        }
    ]
    role = RoleMetadata.load(data, r)
    assert (role.dependencies[0][0] == "role_name")
    assert (role.dependencies[0][1] == "some_role")

    # This fails if role_def doesn't have name or role

# Generated at 2022-06-11 10:49:00.076313
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    class MockCaller:
        def get_name(self):
            return "name"

    role_metadata = RoleMetadata()
    assert role_metadata.load({}, MockCaller()) == None

    role_metadata = RoleMetadata()
    assert role_metadata.dependencies == []

    p = Play()
    p.vars.ansible_version = 2.10
    r = Role.load(None, "name", p)
    assert r.repo == "name"

    role_metadata = RoleMetadata()
    assert role_metadata.load({'repo': "test"}, MockCaller()) == None

    role_metadata = RoleMetadata()

# Generated at 2022-06-11 10:49:01.084650
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert isinstance(r, RoleMetadata)