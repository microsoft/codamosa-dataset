

# Generated at 2022-06-11 10:39:23.289090
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.module_utils.search_paths import PathData, SearchPathFinder
    import ansible.playbook.role
    import ansible.playbook.play

    test_dir = os.path.dirname(ansible.playbook.role.__file__)
    test_role_dir = test_dir + "/test_role"
    test_role_file = test_role_dir + "/meta/main.yml"
    test_role_file_empty = test_role_dir + "/meta/bad.yml"
    test_playbook_dir = test_dir + "/test_playbook"
    test_playbook_file = test_playbook_dir + "/test_playbook.yml"


# Generated at 2022-06-11 10:39:33.593489
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role

    class MockRole:
        def __init__(self, name, ds):
            self._role_name = name
            self._role_path = 'path/to/role/' + name


# Generated at 2022-06-11 10:39:43.147463
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:39:47.502476
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata.load({'allow_duplicates':True,'dependencies':['foo','bar']},owner=True).serialize() == {
        'allow_duplicates': True,
        'dependencies': ['foo', 'bar']}



# Generated at 2022-06-11 10:39:51.156538
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role = RoleMetadata()
    role.deserialize(data)
    assert role.allow_duplicates == False
    assert role.dependencies == []

# Generated at 2022-06-11 10:39:51.884469
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:40:02.270536
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class TestRole:
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import iteritems

    # ImmutableDict is used here because it allows me to sort the dicts
    # before comparison with the RoleMetadata output.
    # Unfortunately itenritems() method is not inherited, so this requires
    # an extra step as well.
    #
    # The other option would be to use OrderedDict, but it is based on a
    # collections.MutableMapping, and we really don't need any of the
    # associated methods.


# Generated at 2022-06-11 10:40:06.212320
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("test RoleMetadata class constructor")

    owner = 'test'
    data = {
        'allow_duplicates': 'true',
        'dependencies': []
    }

    print("call RoleMetadata constructor:")
    rm = RoleMetadata(owner)
    print(rm)

# Generated at 2022-06-11 10:40:15.954726
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_data = {'allow_duplicates': True, 'dependencies': [
        {'role': 'a'},
        {'role': 'b'},
        {'role': 'c'}
    ]}
    metadata = RoleMetadata()
    metadata._load_allow_duplicates(role_data)
    metadata._load_dependencies(role_data)
    serialize_data = metadata.serialize()

    assert 'allow_duplicates' in serialize_data
    assert 'dependencies' in serialize_data

    assert isinstance(serialize_data['allow_duplicates'], bool)
    assert isinstance(serialize_data['dependencies'], list)

    assert serialize_data['allow_duplicates'] is True
    assert len(serialize_data['dependencies']) == 3

# Generated at 2022-06-11 10:40:20.479671
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []
    assert role_metadata.galaxy_info == None
    assert role_metadata.argument_specs == {}

    owner = Base()
    role_metadata = RoleMetadata(owner=owner)
    assert role_metadata._owner == owner


# Generated at 2022-06-11 10:40:37.332399
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    try:
        m = RoleMetadata()
        m.deserialize({
            'allow_duplicates': True,
            'dependencies': [
                'role1',
                'role2',
                {
                    'role': {
                        'name': 'role3',
                        'src': 'http://localhost:8000/role3',
                        'version': '0.1'
                    },
                    'other_vars': 'hello'
                }
            ]
        })
        assert m.allow_duplicates == True
        assert len(m.dependencies) == 3
    except Exception as e:
        print (e)
        raise e
        
    p = None
    m = None
    variable_manager = None

# Generated at 2022-06-11 10:40:46.007470
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Ensure that the RoleMetadata object can be deserialized. The deserialize
    method of a RoleMetadata object takes a data structure as an argument, then
    sets the values defined in the data structure in place of the variables
    defined as attributes of the RoleMetadata object.
    '''

    # Instantiate a new role metadata object.
    role_metadata = RoleMetadata()

    # Use the deserialize method to set the values of the
    # role_metadata object.
    role_metadata.deserialize({'dependencies': ['test_role', {'test_role2' : '2.0.0'}],
                               'allow_duplicates': True})

    # Ensure that the values were set.

# Generated at 2022-06-11 10:40:52.769461
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # GIVEN
    role_metadata = RoleMetadata()

    # WHEN
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['dependency_1', 'dependency_2']})

    # THEN
    assert role_metadata._allow_duplicates
    assert role_metadata._dependencies == ['dependency_1', 'dependency_2']



# Generated at 2022-06-11 10:41:00.347685
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    print('Testing method deserialize of class RoleMetadata')
    rd = RoleDefinition(name='test-role')

    rm = RoleMetadata(owner=rd)
    data = { 'allow_duplicates': 1, 'dependencies': ['test-role2', 'test-role3'] }
    rm.deserialize(data)
    assert rm.allow_duplicates is True
    assert rm.dependencies == ['test-role2', 'test-role3']

# Generated at 2022-06-11 10:41:08.787061
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.utils.display import Display
    loader = module_loader._find_plugin_by_path(
        os.path.join(os.path.dirname(os.path.realpath(__file__)),
                     '..', '..', '..', '..', 'lib', 'ansible', 'modules', 'system', 'ping.py'), disable_extensions=True)

    # Mock variable manager
    variable_manager=None

    # Mock loader


# Generated at 2022-06-11 10:41:13.005676
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': [1,2,3], 'dependencies': [1,2,3]}
    m = RoleMetadata().deserialize(data)
    assert getattr(m, 'allow_duplicates', None) == data['allow_duplicates']
    assert getattr(m, 'dependencies', None) == data['dependencies']

# Generated at 2022-06-11 10:41:18.174669
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata._serializable_attrs = ['allow_duplicates', 'dependencies']
    data = {'allow_duplicates': False, 'dependencies': []}

    rm = RoleMetadata()
    rm.deserialize(data)
    assert rm.allow_duplicates == data['allow_duplicates']
    assert rm.dependencies == data['dependencies']


# Generated at 2022-06-11 10:41:21.206508
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata_deserialize = RoleMetadata.deserialize({'dependencies': '', 'allow_duplicates': ''})
    assert RoleMetadata_deserialize is not None


# Generated at 2022-06-11 10:41:28.954999
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
   test_data = {'allow_duplicates': 'False',
                'dependencies': [{'role': 'b', 'name': 'c'}],
                'allow_duplicates': 'True',
                'dependencies': [{'role': 'a', 'name': 'b'}],
                'allow_duplicates': 'True',
                }
   r1 = RoleMetadata(owner=None)
   r1.load_data(test_data)
   assert r1 != None
   assert r1.allow_duplicates == True
   assert r1.dependencies == [{'role': 'a', 'name': 'b'}]


# Generated at 2022-06-11 10:41:29.493413
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-11 10:41:35.847069
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict()
    RoleMetadata.deserialize(data)


# Generated at 2022-06-11 10:41:43.075528
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import sys
    import tempfile
    import ansible.utils.plugin_docs as plugin_docs
    from ansible import errors
    from ansible.playbook.role import Role

    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    plugin_docs.write({}, os.path.dirname(fname), 'action_plugins')
    sys.path.append(os.path.dirname(fname))


# Generated at 2022-06-11 10:41:54.422434
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["/etc/ansible/hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load

# Generated at 2022-06-11 10:41:58.273997
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    data = {
        'allow_duplicates': True,
        'dependencies': ['role1', 'role2']
    }

    meta.deserialize(data)
    assert meta.allow_duplicates == True
    assert meta.dependencies == ['role1', 'role2']

# Generated at 2022-06-11 10:42:02.860065
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': []}
    m.deserialize(data)
    assert m.allow_duplicates == True

# Load test methods into the class
for methname in RoleMetadata.__dict__:
    if methname.startswith('_load_'):
        setattr(Base, methname, getattr(RoleMetadata, methname))

# Generated at 2022-06-11 10:42:06.977357
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict()
    data['allow_duplicates'] = True
    data['dependencies'] = []
    m = RoleMetadata().load_data(data)
    assert m.serialize()['allow_duplicates'] == True

# Generated at 2022-06-11 10:42:16.959259
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block

    from units.mock.loader import DictDataLoader


# Generated at 2022-06-11 10:42:19.870510
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class FakeData:
        def __init__(self):
            self.name = 'fake_name'
    a = RoleMetadata(owner=FakeData())
    assert a._owner.name == 'fake_name'

# Generated at 2022-06-11 10:42:20.427415
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-11 10:42:25.236412
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    f = open("/home/vagrant/ansible/lib/ansible/playbook/role/metadata.yml")
    data = f.read()
    import yaml
    data = yaml.load(data)
    ds = data.get("ansible.builtin")
    obj = RoleMetadata()
    obj.deserialize(ds)
    assert obj.serialize() == ds

# Generated at 2022-06-11 10:42:41.198976
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task import Task
    # Create a mock owner of class RoleDefinition
    owner = RoleDefinition()
    # Create a role requirement
    role_req = RoleRequirement()
    role_req.role = "other"
    role_req._role_name = "other"
    role_req.role_path = "/home/user/playbooks/roles/other"
    # Add the role requirement to the dictionary of the owner
    owner._roles = {'other': role_req}
    # Define a dependency for the RoleMetadata object
    dependency = {'role': 'other', 'tasks': 'tasks/main.yml'}
    # Define a data structure

# Generated at 2022-06-11 10:42:46.828353
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Set up test data
    data = dict(
        allow_duplicates=True,
        dependencies=['test_role_name']
    )

    # Set up instance of RoleMetadata
    r = RoleMetadata()

    # Run test against object
    r.deserialize(data)

    # Make assertions
    assert(r.allow_duplicates == True)
    assert(r.dependencies == ['test_role_name'])

    # CleanupInstance of RoleMetadata
    del r

# Generated at 2022-06-11 10:42:48.599176
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    ds = {'allow_duplicates': True}
    roleMeta = RoleMetadata.load(ds)
    assert roleMeta._allow_duplicates == True

# Generated at 2022-06-11 10:42:49.815906
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata().allow_duplicates == False
    assert RoleMetadata().dependencies == []



# Generated at 2022-06-11 10:42:59.796452
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import vcr
    from ansible.plugins.loader import role_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible_collections.ansible.builtin.plugins.loader import role_loader as collection_role_loader
    from ansible_collections.testns.testcoll.plugins.loader import role_loader as testcoll_role_loader

    # set up the standard play context
    variable_manager = None
    loader = None
    variable_manager, loader = None, None
    play_context = PlayContext()

    # set up the VCR to cache HTTP requests to Galaxy
    test_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'test_data')
    test_data = os.path

# Generated at 2022-06-11 10:43:05.418081
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_class = RoleMetadata()
    data = dict()
    data['allow_duplicates'] = 'true'
    data['dependencies'] = 'test'
    test_class.deserialize(data)
    assert test_class.allow_duplicates == True
    assert test_class.dependencies == 'test'
# done unit test


# Generated at 2022-06-11 10:43:09.994931
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    data = {}
    data['allow_duplicates'] = True
    data['dependencies'] = ["role1", "role2"]

    metadata.deserialize(data)
    assert metadata._allow_duplicates == True
    assert metadata._dependencies    == ["role1", "role2"]


# Generated at 2022-06-11 10:43:12.848130
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata(owner=None)
    r.allow_duplicates = False
    r.dependencies = []
    d = r.serialize()
    assert d == dict(allow_duplicates=False, dependencies=[]), d

# Generated at 2022-06-11 10:43:17.943503
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata object
    m = RoleMetadata()

    # Define test data
    data = {
        'allow_duplicates': True,
        'dependencies': [],
        }

    # Deserialize the data
    m.deserialize(data)

    # Test that the deserialized data is correct
    assert m.allow_duplicates is True
    assert m.dependencies == []

# Generated at 2022-06-11 10:43:18.450180
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:43:36.945592
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role_include import RoleInclude

    role = RoleMetadata(owner=None)
    role.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role.allow_duplicates == False
    assert role.dependencies == []

    role = RoleMetadata(owner=None)
    role.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'common', 'name': 'common'}]})
    assert role.allow_duplicates == True
    assert isinstance(role.dependencies[0], RoleInclude)
    assert role.dependencies[0].role == 'common'
    assert role.dependencies[0].name == 'common'

    #

# Generated at 2022-06-11 10:43:42.048894
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    ''' test serialization of RoleMetadata class '''
    # Create a data structure for RoleMetadata
    data = {
        'allow_duplicates': True,
        'dependencies': ['foo.bar', 'bar.baz']
    }

    # Create the RoleMetadata instance from data
    role_metadata = RoleMetadata.load(data, None)
    assert role_metadata.serialize() == data

# Generated at 2022-06-11 10:43:50.603192
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = None

    dc = dict(
        allow_duplicates = False,
        dependencies = dict()
    )
    data = dict(
        meta = dict(
            main = dc
        )
    )

    play_context = PlayContext()

    play_context.extra_vars = dict()
    play_context.setup_cache()

    templar = Templar(loader, variables=play_context.variables)
    play = Play().load(data, loader, play_context, templar)

# Generated at 2022-06-11 10:43:52.835379
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create an instance of RoleMetadata
    role_meta_data_instance = RoleMetadata()
    assert isinstance(role_meta_data_instance, RoleMetadata)


# Generated at 2022-06-11 10:43:55.870975
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
  metadata = RoleMetadata()
  serialized = metadata.serialize()
  assert serialized == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-11 10:43:59.445624
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    setattr(r, 'allow_duplicates', False)
    d = r.serialize()
    assert d == {'dependencies': [], 'allow_duplicates': False}
# END unit test

# Generated at 2022-06-11 10:44:02.509600
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_metadata_dict = {}
    test_metadata_dict['allow_duplicates'] = False
    test_metadata_dict['dependencies'] = [{'role': 'geerlingguy.nodejs', 'scm': 'git'}]
    test_metadata_dict['company'] = 'Ansible'

    try:
        assert RoleMetadata.load(test_metadata_dict, owner=None) is not None
    except AnsibleParserError:
        assert False

# Generated at 2022-06-11 10:44:05.334141
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    result = role_metadata.serialize()
    assert result == {'allow_duplicates': False, 'dependencies': []}, result

# Generated at 2022-06-11 10:44:16.670799
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-11 10:44:21.965259
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data1 = dict(
        allow_duplicates=True,
        dependencies=True
    )
    data2 = dict(
        allow_duplicates=False,
        dependencies=False
    )
    m1 = RoleMetadata()
    m2 = RoleMetadata()
    m1.deserialize(data1)
    m2.deserialize(data2)
    assert m1.allow_duplicates
    assert m1.dependencies
    assert not m2.allow_duplicates
    assert not m2.dependencies

# Generated at 2022-06-11 10:44:44.227381
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta.allow_duplicates = False
    meta.dependencies = []
    res = meta.serialize()
    assert res == {'allow_duplicates': False, 'dependencies': []}
    print("OK")


# Generated at 2022-06-11 10:44:46.033563
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata.dependencies, list)
    assert isinstance(role_metadata.allow_duplicates, bool)
    assert role_metadata.allow_duplicates == False

# Generated at 2022-06-11 10:44:46.522582
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-11 10:44:49.561576
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            '.'
        ]
    )

    obj = RoleMetadata()
    obj.deserialize(data)
    assert data == obj.serialize()

# Generated at 2022-06-11 10:44:59.558576
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    def check_role(owner, dep, exp_owner=None, exp_dep=None, exp_allow_duplicates=None):
        m = RoleMetadata(owner=owner)
        m.deserialize(dict(dependencies=dep, allow_duplicates=True))
        assert exp_owner == m._owner
        assert exp_dep == m._dependencies
        assert exp_allow_duplicates == m._allow_duplicates

    check_role(owner=None, dep=[], exp_owner=None, exp_dep=[], exp_allow_duplicates=None)
    check_role(owner='owner', dep=['a'], exp_owner='owner', exp_dep=['a'], exp_allow_duplicates=True)

# Generated at 2022-06-11 10:45:08.433463
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import pytest
    exec_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(exec_dir, '../../tests/collections/role_dependencies/roles/')
    ds = {"dependencies": [
        {"role": "role1"},
    ]}
    role_obj = RoleMetadata(owner='test')
    role_obj.load_data(ds, variable_manager='test', loader='test')
    ds_attr = role_obj.deserialize(role_obj.serialize())
    assert ds_attr['allow_duplicates'] is False
    assert role_obj.dependencies[0]._role_name == "role1"

# Generated at 2022-06-11 10:45:10.483789
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    args = dict(
        dependencies = ['common', 'webtier'],
    )
    r = RoleMetadata(args)
    assert r.dependencies == ['common', 'webtier']

# Generated at 2022-06-11 10:45:17.759473
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    role_definition = RoleDefinition.load({
        'name' : 'role_name',
        'options': {},
        'metadata': {
            'allow_duplicates': False,
            'dependencies': [
                {'role': 'foo'},
                {'role': 'bar'}
            ]
        },
        'collections': [],
    })
    role_metadata = RoleMetadata(owner=role_definition)
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': [{'role': 'foo'}, {'role': 'bar'}]}

# Generated at 2022-06-11 10:45:24.427519
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role.definition as role_definition
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'role_metadata.json')
    data = json.load(open(fixture_path))
    arg_data = data.pop('args')
    rmd = RoleMetadata.load(arg_data, None)
    assert rmd == RoleMetadata(**data)

# Generated at 2022-06-11 10:45:28.406113
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=['become', 'filesystem', 'meta', 'packages', 'service', 'web_server']
    )

    metadata = RoleMetadata().deserialize(data)

    assert metadata.serialize() == data

# Generated at 2022-06-11 10:46:09.113326
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert True

# Generated at 2022-06-11 10:46:15.746995
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata = RoleMetadata(owner=None)

    # test with valid data
    setattr(roleMetadata, 'allow_duplicates', True)
    setattr(roleMetadata, 'dependencies', ['dependency1', 'dependency2'])
    serialized = roleMetadata.serialize()
    assert serialized['allow_duplicates'] == True
    assert serialized['dependencies'] == ['dependency1', 'dependency2']

    # test with invalid data
    setattr(roleMetadata, 'allow_duplicates', False)
    setattr(roleMetadata, 'dependencies', ['dependency1'])
    serialized = roleMetadata.serialize()
    assert serialized['allow_duplicates'] == False
    assert serialized['dependencies'] == ['dependency1']


# Generated at 2022-06-11 10:46:19.697304
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ds = dict(
        allow_duplicates=True,
        dependencies=[
            'foo',
            dict(
                name='bar'
            )
        ]
    )

    m = RoleMetadata(owner=dict())
    m.deserialize(data=ds)

    assert m.allow_duplicates == True
    assert m.dependencies == [
        'foo',
        dict(
            name='bar'
        )
    ]


# Generated at 2022-06-11 10:46:20.719306
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None;

# Generated at 2022-06-11 10:46:23.509171
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # test valid instantiation
    r = RoleMetadata()
    # test invalid instantiation
    try:
        r = RoleMetadata(owner='')
        assert False
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)

# Generated at 2022-06-11 10:46:25.372709
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import ansible.playbook.role.definition

    # test RoleMetadata.load(data, owner, variable_manager=None, loader=None)

    pass


# Generated at 2022-06-11 10:46:29.355575
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    r=RoleMetadata(owner=RoleDefinition(name='test_RoleMetadata_serialize',
                                        role_path='/tmp',
                                        conf_file='/tmp/meta/main.yaml',
                                        collection=None))
    result=r.serialize()
    assert result['dependencies'] == []
    assert result['allow_duplicates'] == False

# Generated at 2022-06-11 10:46:36.093443
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role_include import RoleInclude
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    loader = AnsibleCollectionLoader()
    collection = loader.load_collection_from_directory('collection', 'collection')
    parent_role_meta_var = RoleMetadata()
    parent_role_meta_var._owner = collection
    ri = RoleInclude()
    ri._role_name = 'name'
    ri._role_path = '/path/to'
    ri._role_collection = collection
    parent_role_meta_var._dependencies = [ri]
    data = parent_role_meta_var.serialize()
    assert data
    assert data['dependencies']

# Generated at 2022-06-11 10:46:43.120227
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import collections
    import pprint
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    # Test: Calling RoleMetadata with invalid object (something other than 'RoleDefinition')
    invalid_owner = collections.namedtuple('InvalidOwner', ['name'])
    invalid_owner.name = 'invalid_owner'
    try:
        role_meta = RoleMetadata(owner=invalid_owner)
    except Exception as e:
        assert(isinstance(e, AssertionError))
        assert(str(e) == 'RoleMetadata() needs to be initialized with a RoleDefinition object')
    else:
        assert(False)  # Exception was not raised

    # Test:

# Generated at 2022-06-11 10:46:43.807878
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata

# Generated at 2022-06-11 10:48:12.268803
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook import Play
    from ansible.plugins.loader import collection_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    collections_paths = [collection_loader._collection_paths[0]]
    collection_loader.add_collection_paths(collections_paths)

    test_path = os.path.dirname(
        os.path.dirname(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    test_path = os.path.join(test_path, 'test', 'units', 'data', 'test_collections')
    collections_paths.append(test_path)

# Generated at 2022-06-11 10:48:19.751935
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    play_context = PlayContext()
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = "all",
        connection = "local",
        gather_facts = "no",
        tasks = [],
    ), variable_manager=None, loader=None)
    correct_rm_data = dict(
        dependencies = [],
        allow_duplicates = False,
        galaxy_info = None,
        argument_specs = dict(),
    )
    rm = RoleMetadata()
    rm_data = rm.serialize()
    assert correct_rm_data == rm_data


# Generated at 2022-06-11 10:48:23.115451
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    def _invoke(self, data):
        return RoleMetadata.deserialize(self, data)

    # Ensure that data['dependencies'] is converted to a list
    role_metadata = RoleMetadata()
    role_metadata.deserialize = _invoke
    role_metadata.deserialize(data={'dependencies': None})
    assert role_metadata._dependencies == []

# Generated at 2022-06-11 10:48:26.859108
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_dependencies = [{'role': 'geerlingguy.docker'}, {'role': 'geerlingguy.security'}]
    role_metadata = RoleMetadata(owner=None)
    role_metadata._dependencies = role_dependencies
    result_serialize = role_metadata.serialize()
    assert result_serialize['dependencies'] == role_dependencies, 'The serialize result is not correct'

# Generated at 2022-06-11 10:48:35.790818
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    test_col_loader = AnsibleCollectionLoader()
    test_col_loader.set_options(allow_collections=True)

    test_metadata = RoleMetadata()
    test_role_definition = RoleDefinition.load(
        dict(
            name="test.role",
            collection="test.namespace",
        ),
        play=None,
        variable_manager=None,
        loader=test_col_loader,
    )

    test_role_definition._role_collection = test_col_loader.collections["test.namespace"]


# Generated at 2022-06-11 10:48:40.440869
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    setattr(r, 'allow_duplicates', False)
    setattr(r, 'dependencies', [])
    assert r.deserialize(dict(allow_duplicates=True,dependencies=['foo','bar'])) == dict(allow_duplicates=True,dependencies=['foo','bar'])
    assert r.allow_duplicates == True
    assert r.dependencies == ['foo','bar']


# Generated at 2022-06-11 10:48:42.266928
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    roleMetadata = RoleMetadata()

    assert roleMetadata.allow_duplicates is False
    assert roleMetadata.dependencies == []


if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-11 10:48:44.066620
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r.dependencies == []
    assert r.galaxy_info is None
    assert r.allow_duplicates is False
    assert r.argument_spec == {}

# Generated at 2022-06-11 10:48:47.085303
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Prepare test variables
    role_metadata = RoleMetadata()
    expected_result = {
        "allow_duplicates": False,
        "dependencies": []
    }

    # Perform the test
    result = role_metadata.serialize()

    # Verify the results
    assert result == expected_result


# Generated at 2022-06-11 10:48:55.237063
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata_obj_1 = RoleMetadata()
    serialize_data_1 = {'allow_duplicates' : True, 'dependencies': []}
    
    # check duplicate key, catch exception
    serialize_data_2 = {'allow_duplicates' : True, 'dependencies': [], 'dependencies':[]}
    try:
        metadata_obj_1.deserialize(serialize_data_2)
    except Exception as e:
        print("[ERROR] exception occurs when deserializing a RoleMetadata object")
        raise

    # check non-list value
    serialize_data_3 = {'allow_duplicates' : True, 'dependencies': 'non-list'}