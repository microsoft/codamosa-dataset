

# Generated at 2022-06-11 10:39:15.457638
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()


# Generated at 2022-06-11 10:39:16.668127
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-11 10:39:18.621330
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    isinstance(role_metadata, RoleMetadata)


# Generated at 2022-06-11 10:39:29.047187
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play

    m = RoleMetadata()
    m.deserialize({'allow_duplicates': True, 'dependencies': ['foo', {'role': 'bar'}]})
    assert m.allow_duplicates
    assert len(m.dependencies) == 2
    assert type(m.dependencies[0]) == RoleDefinition
    assert m.dependencies[0].get_name() == 'foo'
    assert type(m.dependencies[1]) == RoleInclude
    assert type(m.dependencies[1]._role) == RoleRequirement

# Generated at 2022-06-11 10:39:32.744749
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta_data = RoleMetadata()
    print(meta_data.__dict__)

    meta_data1 = RoleMetadata(owner=None)
    print(meta_data1.__dict__)

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-11 10:39:34.382117
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata(owner=None)
    assert role.allow_duplicates == False
    assert role.dependencies == []

# Generated at 2022-06-11 10:39:36.738648
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create a RoleMetadata object using default constructor
    roleMetadata = RoleMetadata()


if __name__ == "__main__":
    test_RoleMetadata()
    print("Successfully passed all tests")

# Generated at 2022-06-11 10:39:37.450950
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-11 10:39:46.960122
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # no dependencies to deserialize
    rmd = RoleMetadata()
    data = dict(allow_duplicates=False, dependencies=[])
    rmd.deserialize(data)
    assert rmd._allow_duplicates is False
    assert rmd._dependencies == []

    # dependencies to deserialize
    rmd = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies=['common', 'apache', 'php'])
    rmd.deserialize(data)
    assert rmd._allow_duplicates is True
    assert rmd._dependencies == ['common', 'apache', 'php']

test_RoleMetadata_deserialize()

# Generated at 2022-06-11 10:39:51.440989
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Test(object):
        pass
    m = RoleMetadata(Test())
    m.deserialize({'dependencies': [{'role': 'test'}]})
    assert m._dependencies[0]._role == 'test'
    assert m._dependencies[0]._collections is None

# Generated at 2022-06-11 10:40:08.106725
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    role_metadata = RoleMetadata()
    setattr(role_metadata, 'allow_duplicates', False)
    task = Task()
    setattr(task, 'name', 'Test Serialize')
    task_include = TaskInclude()
    setattr(task_include, 'name', 'Test Include')
    setattr(task_include, '_role_name', 'test_role')
    setattr(task, '_task_includes', [task_include])
    role_metadata.dependencies = [task]

# Generated at 2022-06-11 10:40:17.182705
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    import sys

    setattr(sys, 'real_prefix', sys.prefix)

    definition = {'role': 'foo'}
    role_requirement = RoleRequirement.from_role_definition(definition)
    role_definition = RoleDefinition(role_requirement=role_requirement)


# Generated at 2022-06-11 10:40:19.595073
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    collection = {"allow_duplicates": False, "dependencies": []}
    metadata = RoleMetadata()
    metadata.deserialize(collection)
    assert collection == metadata.serialize()

# Generated at 2022-06-11 10:40:20.177207
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-11 10:40:21.391178
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass


# Generated at 2022-06-11 10:40:31.613183
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.collection import RoleCollection
    from ansible.playbook.role.include import RoleInclude

    data = {
        'allow_duplicates': True,
        'dependencies': [
            {
                'role': 'name',
            },
            'name',
        ]
    }
    role = RoleDefinition.load({'name': '../../test/roles/foo'}, '127.0.0.1', 'test/roles/foo')
    role._role_path = 'test/roles/foo/meta/main.yml'
    role._role_collection = RoleCollection.load('galaxy', '127.0.0.1', 'galaxy')
    res = RoleMetadata(owner=role).load_

# Generated at 2022-06-11 10:40:40.972643
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class MockOwner:
        def get_name(self):
            return "mockOwner"

    mock_owner = MockOwner()

    role_data = dict(
        allow_duplicates=True,
        dependencies=[
            {
                'role': 'mock_dependency_role'
            },
        ]
    )
    result = RoleMetadata.load(
        data=role_data, owner=mock_owner
    )

    result_serialized = result.serialize()

    assert 'allow_duplicates' in result_serialized
    assert result_serialized['allow_duplicates'] is True

    assert 'dependencies' in result_serialized
    assert isinstance(result_serialized['dependencies'], list)
    assert result_serialized['dependencies'] == role_data['dependencies']



# Generated at 2022-06-11 10:40:45.143105
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Given data with missing values
    data = {'dependencies': []}

    # When RoleMetadata.deserialize is called
    RoleMetadata(owner=None).deserialize(data)

    # Then RoleMetadata.allow_duplicates is False
    assert not RoleMetadata(owner=None).allow_duplicates

# Generated at 2022-06-11 10:40:48.474724
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    RoleMetadata = RoleMetadata()
    result = RoleMetadata.serialize()
    assert result ==  {
        'allow_duplicates':None,
        'dependencies':[]
    }


# Generated at 2022-06-11 10:40:59.218427
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Create a mock data structure
    data = {
        'allow_duplicates': True,
        'dependencies': [
            'foo',
            'bar'
        ]
    }

    # Load it into a new RoleMetadata object
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

    # Check if the properties of the object are correct
    assert role_metadata.allow_duplicates is True
    assert isinstance(role_metadata.dependencies, list)
    assert len(role_metadata.dependencies) == 2
    assert role_metadata.dependencies[0] == 'foo'
    assert role_metadata.dependencies[1] == 'bar'

# Generated at 2022-06-11 10:41:21.166196
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_data = {
        'dependencies': [
            {'role': 'x', 'version': '1'},
            {'name': 'y', 'version': '2'},
            {'src': 'z', 'scm': 'git'},
            'a.b',
        ],
    }

    from ansible.playbook.role.definition import RoleDefinition

    test_role_def = RoleDefinition('foo')
    test_role_def.vars = {'role_meta_test': 'bar'}

    try:
        m = RoleMetadata.load(test_data, test_role_def)
    except AnsibleError as e:
        print("Unit test for RoleMetadata failed: ", e)
        return False

    return True


# Generated at 2022-06-11 10:41:27.580592
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.name import RoleName
    
    role = RoleName()
    role.name = "test_role"
    role_meta = RoleMetadata(owner=role)
    role_meta.allow_duplicates = True
    role_meta.dependencies = ['role1', 'role2']

    serialize_meta = role_meta.serialize()
    assert serialize_meta == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}


# Generated at 2022-06-11 10:41:31.319795
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == {'allow_duplicates': False, 'dependencies': []}
    assert RoleMetadata(allow_duplicates=True).serialize() == {'allow_duplicates': True, 'dependencies': []}



# Generated at 2022-06-11 10:41:40.799684
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    ROLE_CACHE.clear()

    loader = AnsibleCollectionLoader()

# Generated at 2022-06-11 10:41:46.711484
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    This is a unit test for method serialize of class RoleMetadata.
    '''
    role_meta = RoleMetadata()
    role_meta._allow_duplicates = True
    role_meta._dependencies = ["apache"]
    serialized_data = role_meta.serialize()
    assert serialized_data["allow_duplicates"] == True
    assert serialized_data["dependencies"] == ["apache"]
    #TODO: Add more test cases


# Generated at 2022-06-11 10:41:57.768345
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader

    rd = RoleDefinition.load(dict(name='foo'), role_loader)
    rm = RoleMetadata(owner=rd)
    serialized_rm = rm.serialize()
    assert serialized_rm == { 'allow_duplicates': False, 'dependencies': [] }, serialized_rm
    rd.metadata.dependencies = dict(one=dict(name='bar'))
    serialized_rm = rd.metadata.serialize()
    assert serialized_rm == { 'allow_duplicates': False, 'dependencies': [{ 'name': 'bar' }] }, serialized_rm
    rd.metadata.allow_duplicates = True
    serialized_rm = rd.metadata.serial

# Generated at 2022-06-11 10:41:58.320923
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:41:58.868236
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata().load_data({})

# Generated at 2022-06-11 10:42:01.023400
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    meta = RoleMetadata(owner=None).load({}, None, None, None)

    assert meta is not None, "Failure: method load of class RoleMetadata is broken"

# Generated at 2022-06-11 10:42:10.694077
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': True,
        'dependencies': {
            'role1': {
                'role1_var': 'role1_var'
            },
            'role2': {
                'role2_var': 'role2_var'
            }
        }
    })
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == [{
        'role1': {
            'role1_var': 'role1_var'
        },
        'role2': {
            'role2_var': 'role2_var'
        }
    }]

# Generated at 2022-06-11 10:42:49.358928
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    assert role_meta._allow_duplicates is False, "Failed to deserialize allow_duplicates"
    assert role_meta._dependencies == [], "Failed to deserialize dependencies"
    peer_meta_data = {'allow_duplicates':True, 'dependencies':['common']}
    role_meta.deserialize(peer_meta_data)
    assert role_meta._allow_duplicates is True, "Failed to deserialize allow_duplicates"
    assert role_meta._dependencies == ['common'], "Failed to deserialize dependencies"


# Generated at 2022-06-11 10:42:58.978035
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    def test_role_metadata(metadata):
        class FakeRole():
            def __init__(self, metadata):
                self.metadata = metadata

        assert metadata.allow_duplicates is False
        assert len(metadata.dependencies) == 1

        dep_role = metadata.dependencies[0]

        assert(dep_role.get_name() == 'common')
        assert(dep_role.get_scm_branch() == '1.2')
        assert(dep_role.get_scm_repo() == 'https://github.com/user/common-role')
        assert(dep_role.get_scm_tag() == '')


# Generated at 2022-06-11 10:43:09.946896
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import yaml
    variable_manager = None
    loader = None

    # load metadata of a role.
    with open("../../lib/ansible/roles/testrole/meta/main.yml", 'r') as stream:
        try:
            data = yaml.load(stream)
        except yaml.YAMLError as exc:
            print(exc)
    m = RoleMetadata.load(data, owner='', variable_manager=variable_manager, loader=loader)

    print("Returned value:", m)
    if m is not None:
        print("dir(m):", dir(m))
        print("m.__dict__:", m.__dict__)  # m.__dict__ is a dict object

if __name__ == '__main__':
    test_RoleMetadata_load

# Generated at 2022-06-11 10:43:12.229755
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    owner = {
        "name": "myrole"
    }
    r = RoleMetadata(owner=owner)
    assert r.name == "myrole"

# Generated at 2022-06-11 10:43:14.950692
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_cls = RoleMetadata()
    assert role_metadata_cls._allow_duplicates == False
    assert role_metadata_cls._dependencies == []
    assert role_metadata_cls._galaxy_info == None
    assert role_metadata_cls._argument_specs == {}

# Generated at 2022-06-11 10:43:16.524457
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    #assert False, "Test not implemented"
    pass



# Generated at 2022-06-11 10:43:17.126062
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:43:17.981753
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata is not None

# Generated at 2022-06-11 10:43:23.729153
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ''' Unit test for method deserialize of class RoleMetadata '''

    serialized_data = {
        "allow_duplicates": False,
        "dependencies": []
    }

    rm = RoleMetadata()

    rm.deserialize(serialized_data)

    assert rm._dependencies ==  serialized_data['dependencies']
    assert rm._allow_duplicates == False

# Generated at 2022-06-11 10:43:27.572483
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    data = {"allow_duplicates": False, "dependencies": []}
    obj.deserialize(data)
    assert obj._allow_duplicates is False
    assert len(obj._dependencies) == 0


# Generated at 2022-06-11 10:44:04.366439
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # type: () -> None
    test_var = dict()
    test_var['name'] = 'test'
    test_var['allow_duplicates'] = True
    test_var['dependencies'] = [{'name': 'test_role_1'}]
    test_var['galaxy_info'] = None
    test_var['argument_spec'] = None

    role = RoleMetadata()
    role.deserialize(test_var)

    assert role._role_name == 'test'
    assert role._allow_duplicates
    assert role._dependencies[0].get_name() == 'test_role_1'

# Generated at 2022-06-11 10:44:04.988044
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:44:16.371812
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Unit test for method serialize of class RoleMetadata
    """

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    import os
    data_file_name = "test_playbook_role_meta_main_yml.yml"
    data_file_path = os.path.dirname(os.path.realpath(__file__))
    try:
        roleinfo = RoleDefinition.load(os.path.join(data_file_path, data_file_name))
    except Exception as exc:
        print("The role definition file loading is failed due to error - %s" % exc)
        print("The RoleDefinition object is not created")
        assert False


# Generated at 2022-06-11 10:44:23.635908
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # Just for load_list_of_roles, create a dummy Play class that has the attributes
    # needed for the load_list_of_roles method
    class Play(object):
        def __init__(self, collection_search_list=None, variable_manager=None, loader=None):
            self.collections = collection_search_list
            self.variable_manager = variable_manager
            self.loader = loader

    # Just for load_list_of_roles, create a dummy Role class that has the attributes
    # needed for the load_list_of_roles method
    class Role(object):
        def __init__(self, role_collection=None, role_path=None):
            self._role_collection = role_collection
            self._role_path = role_path

    role_meta_data = RoleMet

# Generated at 2022-06-11 10:44:27.739786
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_obj = RoleMetadata()
    assert isinstance(test_obj, RoleMetadata)
    assert test_obj._allow_duplicates == False
    assert test_obj._dependencies == []
    assert test_obj._galaxy_info == {}

# Generated at 2022-06-11 10:44:36.193630
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    Unit test for method deserialize of class RoleMetadata
    """

    # Works when 'allow_duplicates' is False
    meta = RoleMetadata()
    data = dict(allow_duplicates=False, dependencies=[])
    meta.deserialize(data)
    assert meta.allow_duplicates == False
    assert meta.dependencies == []

    # Works when 'allow_duplicates' is True
    meta = RoleMetadata()
    data = dict(allow_duplicates=True, dependencies=[])
    meta.deserialize(data)
    assert meta.allow_duplicates == True
    assert meta.dependencies == []

test_RoleMetadata_deserialize()

# Generated at 2022-06-11 10:44:44.558244
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # config
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

    # pass in an empty context, which should not be used by the role
    context = PlayContext()

    # create an empty role with a dict for its metadata
    owner = Role()
    owner._role_path = '/tmp'
    owner._role_name = 'myrole'
    data = dict()

    m = RoleMetadata.load(data, owner)
    assert m != None

# Generated at 2022-06-11 10:44:50.108680
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task

    role = Role()
    role._role_name = "role_name"
    role._role_path = "/role/path"
    role._role_collection = "role_collection"

    role_include = RoleInclude()
    role_include._role = role
    role_include._options = {'name':'role_include_name'}
    role_include._tasks = [Task()]

    role_metadata = RoleMetadata(owner=role)
    role_metadata._dependencies = [role_include]
    role_metadata._allow_duplicates = False

# Generated at 2022-06-11 10:45:00.247353
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role import Role

    role_data = {
        'name': 'some_role',
        '_role_path': 'some_path',
        'collections': ['some.collection'],
    }
    role = Role()
    role.deserialize(role_data)

    md_data = {
        'dependencies': [
            {'role': 'geerlingguy.apache', 'some_extra_var': 'some_value'},
            'geerlingguy.ntp',
            'name: geerlingguy.php',
            'src: https://github.com/geerlingguy/ansible-role-apache',
            'name: src: https://github.com/foo/bar',
        ]
    }

# Generated at 2022-06-11 10:45:09.551501
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude

    mock_owner = RoleDefinition()
    mock_owner._play = Play().load({'name': 'test', 'hosts': 'localhost'}, variable_manager=None, loader=None, context=PlayContext())
    dependencies = []
    role1 = RoleInclude()
    role1._role_name = 'role1'
    role2 = RoleInclude()
    role2._role_name = 'role2'
    dependencies.append(role1)
    dependencies.append(role2)
    mock_owner._dependencies = dependencies

# Generated at 2022-06-11 10:46:15.899214
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})


# Generated at 2022-06-11 10:46:18.931891
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = RoleMetadata()
    meta.deserialize({'allow_duplicates': True, 'dependencies': ['foo']})

    def test_assert(attr):
        return getattr(meta, attr)

    assert test_assert('allow_duplicates') == True
    assert test_assert('dependencies') == ['foo']

# Generated at 2022-06-11 10:46:21.485132
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.meta import RoleMetadata
    serialized_data = RoleMetadata(owner="test1").serialize()
    assert serialized_data.get('allow_duplicates') is False
    assert serialized_data.get('dependencies') == []


# Generated at 2022-06-11 10:46:22.062754
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-11 10:46:29.091488
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    #from ansible.playbook.role_include import RoleInclude

    r = Role.load(dict(
        name='role_name',
        default_tags=['role_default_tag'],
        tasks=[dict(action=dict(module='test_module', args=dict(test='test_arg')))]
    ), play=Play().load(dict(
        name='play_name'
    ), variable_manager=None, loader=None))


# Generated at 2022-06-11 10:46:36.616724
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import mock
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import collection_loader

    options = mock.MagicMock()
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, use_task_vars=False)
    inventory = InventoryManager(loader=loader, sources=options.inventory)


# Generated at 2022-06-11 10:46:39.158770
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta = RoleMetadata.load({}, None)
    assert meta._dependencies == []
    assert meta._galaxy_info is None
    assert meta._argument_specs == {}
    assert not meta._allow_duplicates


# Generated at 2022-06-11 10:46:42.348034
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role_include import RoleInclude
    dependency_list = ['test', 'test1']
    r = RoleMetadata().load({'dependencies': dependency_list})
    assert(r.dependencies[0] == 'test')
    assert(r.dependencies[1] == 'test1')



# Generated at 2022-06-11 10:46:43.308418
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert isinstance(r, RoleMetadata)

# Generated at 2022-06-11 10:46:44.214066
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # test with a directory name
    role = RoleMetadata()
    assert role

# Generated at 2022-06-11 10:48:50.674831
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata(owner=None)
    meta._allow_duplicates = False
    meta._dependencies = []
    serialized_meta = meta.serialize()
    assert serialized_meta['allow_duplicates'] == False
    assert serialized_meta['dependencies'] == []


# Generated at 2022-06-11 10:48:53.352964
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    roleMetadata = RoleMetadata()
    roleMetadata.deserialize({
        'allow_duplicates': True,
        'dependencies': []
    })
    assert roleMetadata._allow_duplicates

# Generated at 2022-06-11 10:48:55.406381
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    result = metadata.serialize()
    assert result == dict(
        allow_duplicates=False,
        dependencies=[])


# Generated at 2022-06-11 10:49:02.131962
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    #Loading with empty parameters
    with pytest.raises(AssertionError):
        RoleMetadata().load()

    #Loading with empty data structure
    with pytest.raises(AnsibleParserError):
        RoleMetadata.load(data={}, owner=None)

    #Loading with valid data structure and owner of class Role
    block = Block()
    task = Task()
    task.block = block
    play_context = PlayContext()
    role_definition = RoleDefinition()

# Generated at 2022-06-11 10:49:09.565812
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    class MyPlay(Playbook):
        pass

    loader = DataLoader()
    passwords = dict(vault_pass='secret')
    inventory = PlaybookInventory(loader=loader, vault_password='secret')

    pb = MyPlay()
    pb._loader        = loader
    pb._variable_manager = VariableManager(loader=loader, inventory=inventory)

    my_play_context = PlayContext()
    my_play_context._pb = pb
    my_play_context.password = passwords

    pb._tqm            = None
    pb._play_context   = my_play_context
    pb._inventory      = inventory