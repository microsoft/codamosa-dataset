

# Generated at 2022-06-11 10:39:20.790551
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # 1. test all default values
    r = RoleMetadata()
    assert(r._allow_duplicates is False)
    assert(r._dependencies == [])
    assert(r._galaxy_info is None)
    assert(r._argument_specs == {})

    # 2. test load from an empty dictionary
    r = RoleMetadata().load({})
    assert(r._allow_duplicates is False)
    assert(r._dependencies == [])
    assert(r._galaxy_info is None)
    assert(r._argument_specs == {})

    # 3. test load with all possible attributes

# Generated at 2022-06-11 10:39:31.323405
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Instantiates a RoleMetadata object and calls the deserialize method
    with the dict shown below. Then tests that the contents of the dict
    were stored in the object appropriately.
    '''
    from ansible.playbook.role.definition import RoleDefinition
    data = dict()
    data['allow_duplicates'] = True
    data['dependencies'] = []
    # create RoleDefinition instance without a role path
    role_definition = RoleDefinition('role_name')
    # create RoleMetadata instance
    role_metadata = RoleMetadata(role_definition)
    # call deserialize
    role_metadata.deserialize(data)
    # test that allow_duplicates was stored in object
    assert role_metadata.allow_duplicates
    # test that dependencies was stored in object

# Generated at 2022-06-11 10:39:33.134899
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    # Test 1, object of the class RoleMetadata should have the attribute allow_duplicates
    res = hasattr(role_meta, 'allow_duplicates')
    assert res is True
    # Test 2, object of the class RoleMetadata should have the attribute dependencies
    res = hasattr(role_meta, 'dependencies')
    assert res is True

# Generated at 2022-06-11 10:39:40.455923
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies.append(RoleInclude.load({}, play=None))
    role_metadata.dependencies.append(RoleDefinition.load({'role': 'my_role'}, play=None))

    data = {
        'allow_duplicates': True,
        'dependencies': [{'role': None}, {'role': 'my_role'}]
    }

    assert(role_metadata.serialize() == data)


# Generated at 2022-06-11 10:39:52.034437
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()
    context._role = Role()
    context._role._role_path = './tests/unit/test_data/roles/test_role1'
    context._role._role_collection = 'collection1'
    context._role._collections = ['collection1', 'ansible.legacy']
    context._role._

# Generated at 2022-06-11 10:39:54.572650
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    result = dict(
        allow_duplicates=False,
        dependencies=[],
    )
    assert RoleMetadata.deserialize(None) == result

# Generated at 2022-06-11 10:39:55.573684
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #TODO
    pass

# Generated at 2022-06-11 10:39:57.826250
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # 1. RoleMetadata test
    role_metadata = RoleMetadata(owner='owner')
    assert role_metadata



# Generated at 2022-06-11 10:40:00.150450
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    role_metadata = RoleMetadata(owner="owner-test")
    print(role_metadata.owner)


if __name__ == "__main__":

    test_RoleMetadata()

# Generated at 2022-06-11 10:40:06.324140
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test with empty dict
    rd = RoleMetadata()
    rd.deserialize({})
    assert rd.allow_duplicates == False
    assert rd.dependencies == []
    # Test with dict data
    rd.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert rd.allow_duplicates == True
    assert rd.dependencies == ['role1', 'role2']

# Generated at 2022-06-11 10:40:20.198475
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._base import _generate_role_names

    def _update_plugins(self, role_metadata, role_def):
        ''' helper function which is called by load_list_of_roles '''
        pass

    RoleMetadata.load_list_of_roles = load_list_of_roles
    RoleMetadata._update_plugins = _update_plugins

    # Test 1
    # Create a dummy RoleDefinition object that is required for the RoleMetadata object instant

# Generated at 2022-06-11 10:40:30.717283
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.collectionsearch import CollectionSearch
    from ansible.playbook.collectionsearch import CollectionSearchEntry
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.errors import AnsibleParserError

    # Create a role and RoleMetadata associated with it.
    path = os.path.join(os.path.dirname(__file__), '../../../test/support/test-collections/ansible_collections/my_namespace/my_role/')
    role = Role.load(path, play=None, variable_manager=None, loader=None)
    # Invoke the RoleMetadata constructor and set the allow_duplicates, dependencies attributes of role attribute


# Generated at 2022-06-11 10:40:39.901928
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Test with a play without role dependencies
    role_metadata = RoleMetadata()
    dependencies = {'allow_duplicates': False, 'dependencies': []}
    role_metadata.deserialize(dependencies)
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []

    # Test with a play with 4 role dependencies
    role_metadata = RoleMetadata()
    dependencies = {'allow_duplicates': True, 'dependencies': ['role1', 'role2', 'role3', 'role4']}
    role_metadata.deserialize(dependencies)
    assert role_metadata._allow_duplicates is True
    assert role_metadata._dependencies == ['role1', 'role2', 'role3', 'role4']


# Generated at 2022-06-11 10:40:49.814986
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    """ Unit test for method load of class RoleMetadata """
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=None)
    play_context = PlayContext()
    play_context.CLIARGS = ImmutableDict(connection='local', module_path=None, forks=10, become=False,
                                         become_method=None, become_user=None, check=False, diff=False)
    play_context.become = C.DEFAULT_BECOME
    play_context.become_method = C.DEFAULT_BECOME_METHOD
    play_context.become_user = C.DEFAULT_BECOME_USER


# Generated at 2022-06-11 10:40:58.877778
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    import ansible.playbook.role.definition
    import ansible.playbook.task.include
    
    data = dict(
        allow_duplicates=False,
        dependencies=['my-role', 'my.collection.role']
    )
    
    m = RoleMetadata()
    m.deserialize(data)
    
    assert m.dependencies[0].role == 'my-role'
    assert m.dependencies[1].role == 'my.collection.role'

# Generated at 2022-06-11 10:41:00.304509
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    Base.register_namespace('role', Role)
    RoleMetadata()

# Generated at 2022-06-11 10:41:06.369360
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # General test for method deserialize with data for an object
    # of class RoleMetadata
    d = dict()
    d['allow_duplicates'] = True
    d['dependencies'] = ['apache', 'database']
    m = RoleMetadata().deserialize(d)
    assert m.allow_duplicates == True
    assert m.dependencies == ['apache', 'database']

    # Test with missing keys in data
    m = RoleMetadata().deserialize(dict())
    assert m.allow_duplicates == False
    assert m.dependencies == []

# Generated at 2022-06-11 10:41:14.924929
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    # create a fake role definition, with a sequence of tasks
    block = Block()
    # add a task to the block
    block._load_task(dict(action=dict(module='debug', args=dict(msg='Hello World!'))))

    role_definition = RoleDefinition()
    role_definition._blocks = [block]

    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = False

    # add fake role definition to role metadata
    role_metadata._owner = role_definition

    # serialize
    data = role_metadata.serialize()



# Generated at 2022-06-11 10:41:16.879081
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert RoleMetadata().deserialize({'allow_duplicates': True, 'dependencies': []}) != None

# Generated at 2022-06-11 10:41:26.463965
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        roles=[dict(
            name='foobar',
            tasks=[dict(action=dict(module='shell', args='/bin/true')),
                  dict(action=dict(module='shell', args='/bin/false')
                       )]
        )]
    )


# Generated at 2022-06-11 10:41:42.417305
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    a = RoleMetadata()
    a.deserialize({'allow_duplicates': True, 'dependencies': ['a', 'b']})
    assert getattr(a, 'allow_duplicates') == True
    assert getattr(a, 'dependencies') == ['a', 'b']



# Generated at 2022-06-11 10:41:46.009449
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Unit test for method serialize of class RoleMetadata.
    '''
    obj = RoleMetadata()
    obj._dependencies = []
    assert obj.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )

# Generated at 2022-06-11 10:41:51.355091
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[{'role': 'common'}, {'role': 'webserver'}]
    )
    r = RoleMetadata()
    r.deserialize(data)
    assert r.serialize() == data


# Generated at 2022-06-11 10:41:57.768850
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # data is a list of dictionaries
    data = [
        {
            'allow_duplicates': True,
            'dependencies': [{
                'role': 'common',
                'name': 'common'
            }]
        }
    ]

    rolemetadata = RoleMetadata()
    rolemetadata.deserialize(data)
    dependencies = rolemetadata.dependencies

    assert dependencies[0].name == 'common'
    assert rolemetadata.allow_duplicates == True


# Generated at 2022-06-11 10:42:00.796710
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    This test tests the load method of class RoleMetadata
    '''
    # Put your test code here
    my_res = RoleMetadata.load(dict(), None)
    assert isinstance(my_res, RoleMetadata)

# Generated at 2022-06-11 10:42:03.613390
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {
        'allow_duplicates': False,
        'dependencies': []
    }
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []


# Generated at 2022-06-11 10:42:08.818286
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['R1', 'R2']
    data = role_metadata.serialize()
    assert (data == dict(allow_duplicates=True, dependencies=['R1', 'R2']))


# Generated at 2022-06-11 10:42:18.956075
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import os
    import json
    import shutil
    import tempfile
    from io import StringIO
    from ansible.module_utils._text import to_bytes

    # Put a default collection in this directoory
    my_dir = tempfile.mkdtemp()
    collection_dir = os.path.join(my_dir, 'my_collection')
    os.makedirs(collection_dir)
    collection_file = os.path.join(collection_dir, 'my_collection.tar.gz')
    contents = StringIO()
    contents.write('{"namespace": "my_namespace", "name": "test_collection", "version": "0.0.1"}')
    with open(collection_file, 'wb') as f:
        f.write(to_bytes(contents.getvalue()))

    #

# Generated at 2022-06-11 10:42:27.354215
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Test that RoleMetadata.deserialize() creates a GalaxyInfo object from the dict in
    the legacy "galaxy_info" key, in cases where a GalaxyInfo object is not already
    present in the "galaxy_info" key.
    '''
    rmd = RoleMetadata()

    # Test with a dict
    data = dict(galaxy_info=dict(author='foo'))
    safe_dump = dict(galaxy_info=dict(author='foo'))
    rmd.deserialize(data)
    assert isinstance(rmd._galaxy_info, dict)
    assert rmd.serialize() == safe_dump

    # Test with a GalaxyInfo
    data = dict(galaxy_info=dict(author='foo', GalaxyInfo=dict()))

# Generated at 2022-06-11 10:42:34.375822
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Test with a valid data dictionary
    test_dict = {
        'allow_duplicates' : True,
        'dependencies' : [ "test_role" ],
    }
    role_metadata = RoleMetadata()
    role_metadata.deserialize(test_dict)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == [ "test_role" ]



# Generated at 2022-06-11 10:42:57.605475
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata(owner=None)
    assert r._allow_duplicates == False
    assert r._dependencies == []
    assert r._galaxy_info is None
    assert r._argument_specs == {}



# Generated at 2022-06-11 10:43:08.525180
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import sys
    import os
    import yaml
    from ansible.module_utils._text import to_bytes
    meta_main = '''
    allow_duplicates: True
    dependencies:
      - role: galaxy.role1,1.0,name1
        other_vars: "here"
      - role: galaxy.role2
        scm: git
        scm_url: "http://example.com/repo"
        scm_version: master
      - galaxy.role3
      - name: galaxy.role4
        version: 1.0
    '''
    sys.path.insert(0, os.path.dirname(__file__))
    from ansible.playbook.role import Role


# Generated at 2022-06-11 10:43:13.125235
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()

# Generated at 2022-06-11 10:43:17.222814
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['test_dependencies']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['test_dependencies']}


# Generated at 2022-06-11 10:43:18.098588
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata()
    assert a is not None

# Generated at 2022-06-11 10:43:27.410362
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.metadata import RoleMetadata

    # create fake role definitions
    foo_role_def = RoleDefinition('foo')
    bar_role_def = RoleDefinition('bar')

    # create role metadata object
    role_metadata = RoleMetadata(owner=None)

    # set role dependencies
    role_metadata._dependencies.append(foo_role_def)
    role_metadata._dependencies.append(bar_role_def)

    expected = dict(
        dependencies=[
            'foo',
            'bar'
        ]
    )

    result = role_metadata.serialize()
    assert result == expected

# Generated at 2022-06-11 10:43:30.984962
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': False,
        'dependencies': []
    })
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []


# Generated at 2022-06-11 10:43:38.037283
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    # test allow_duplicates=True
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == []
    # test allow_duplicates=False
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-11 10:43:42.827129
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['geerlingguy.apache']
    )
    m = RoleMetadata()
    m._allow_duplicates = data.get('allow_duplicates', False)
    m._dependencies = data.get('dependencies', [])
    assert m.serialize() == data



# Generated at 2022-06-11 10:43:51.341053
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_yaml = """
    allow_duplicates: true
    dependencies:
        - role: test.role1
        - role: test.role2
        - role: test.role3
          version: 1.1
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role

    class RoleDef(RoleDefinition):
        _role_path = "/tmp/roles"
        _role_name = "test.role"
        _task_blocks = []
        _default_vars = {}

# Generated at 2022-06-11 10:44:36.918926
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    data = dict(
        allow_duplicates=False,
        dependencies=[RoleRequirement.role_yaml_parse({'src': 'nginx'})],
    )

# Generated at 2022-06-11 10:44:41.799810
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metapath = os.path.join(os.path.dirname(__file__), os.path.pardir, "test_role_meta")
    role = RoleMetadata.load(dict(foo=1), owner=role_metapath)
    assert role.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-11 10:44:48.851630
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class MyRoleMetadata(RoleMetadata):
        _allow_duplicates = FieldAttribute(isa='bool', default=False)
        _dependencies = FieldAttribute(isa='list', default=list)
        _galaxy_info = FieldAttribute(isa='GalaxyInfo')

    role_meta = MyRoleMetadata(owner=None)

    # Test __init__() is successful
    assert (role_meta.__class__.__name__ == 'MyRoleMetadata')

    # Test initialization of class attributes
    assert (role_meta._allow_duplicates is False)
    assert (role_meta._dependencies == [])
    assert (role_meta._galaxy_info is None)

    role_meta._allow_duplicates = True
    role_meta._dependencies.append('test')
    role_meta._galaxy_

# Generated at 2022-06-11 10:44:54.413073
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roleMetadata = RoleMetadata.load(
        {'allow_duplicates': True, 'dependencies': ['b','c']},
        owner=None
    )
    assert roleMetadata.__dict__ == {'_allow_duplicates': True, '_dependencies': [{}, {}], '_owner': None}
    assert roleMetadata.serialize() == {'allow_duplicates': True, 'dependencies': ['b', 'c']}


# Generated at 2022-06-11 10:44:57.368593
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert r.allow_duplicates == False
    assert r._dependencies == []
    assert r._galaxy_info == None


# Generated at 2022-06-11 10:45:07.474262
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task


# Generated at 2022-06-11 10:45:13.312911
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class my_play:
        def __init__(self):
            self.name = "test_play"

    class my_role:
        def __init__(self):
            self.name = "test_role"
            play = my_play()
            self.play = play

    role = my_role()
    role_metadata = RoleMetadata(owner=role)
    assert role_metadata is not None
    assert role_metadata._owner is not None
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []

# Generated at 2022-06-11 10:45:23.197756
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    role = RoleMetadata({})
    role.load({'dependencies': ['geerlingguy.docker', [{'role': 'geerlingguy.pip', 'vars': {'key': 'value'}}]]},
              owner=play, variable_manager=variable_manager, loader=loader)
    assert isinstance(role._dependencies[0], RoleMetadata)
    assert isinstance(role._dependencies[1], RoleMetadata)

# Generated at 2022-06-11 10:45:31.901466
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader
    m = RoleMetadata(owner=RoleDefinition.load({'name': 'test'}, role_loader))
    assert m.load({'dependencies': ['foo']})
    # with pytest.raises(AnsibleParserError):
    #     m.load({'dependencies': {}})

    loader = role_loader
    m = RoleMetadata(owner=RoleDefinition.load({'name': 'test'}, loader))
    assert m.load({'dependencies': [{'role': 'foo'}, {'role': 'bar'}]})

# Generated at 2022-06-11 10:45:37.820219
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import json

    json_data = '''
        {
            "allow_duplicates": true,
            "dependencies": [
                "foo"
            ]
        }
    '''

    data = json.loads(json_data.strip())
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

    assert role_metadata.allow_duplicates == data['allow_duplicates']
    assert role_metadata.dependencies == data['dependencies']

# Generated at 2022-06-11 10:46:50.282572
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-11 10:46:54.237010
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r.allow_duplicates = True
    r.dependencies = ['foo', 'bar']
    serialized = r.serialize()
    assert 'allow_duplicates' in serialized
    assert 'dependencies' in serialized
    assert serialized['allow_duplicates'] is True
    assert serialized['dependencies'] == ['foo', 'bar']


# Generated at 2022-06-11 10:46:57.006790
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test initialization of RoleMetadata() object with empty argument
    role_metadata = RoleMetadata()

    # Test initialization of RoleMetadata() object with single dictionary argument
    role_metadata = RoleMetadata(owner={"name": "Test"})

# Generated at 2022-06-11 10:46:59.585253
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    meta._allow_duplicates = True
    meta._dependencies = [1, 2, 3]
    assert meta.serialize() == {'allow_duplicates': True, 'dependencies': [1, 2, 3]}



# Generated at 2022-06-11 10:47:01.237875
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {}
    m = RoleMetadata(owner=None)

    m = RoleMetadata.load(data, owner=None)

# Generated at 2022-06-11 10:47:04.246605
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Test for constructor of class RoleMetadata
    :return:
    '''
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info is None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-11 10:47:05.126050
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO: implement this
    pass


# Generated at 2022-06-11 10:47:08.307283
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[dict(role='test.test1'), dict(role='test.test2')]
    )
    meta = RoleMetadata()
    meta.deserialize(data)
    assert meta.allow_duplicates is True
    assert len(meta.dependencies) == 2

# Generated at 2022-06-11 10:47:11.308344
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': True,
        'dependencies': [{'role': 'foo'}]
    })
    assert(role_metadata.allow_duplicates is True)
    assert(role_metadata.dependencies[0].role == 'foo')


# Generated at 2022-06-11 10:47:12.537384
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert isinstance(metadata, RoleMetadata)