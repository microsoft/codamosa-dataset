

# Generated at 2022-06-25 05:55:17.585544
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Build test object
    role_metadata_0 = RoleMetadata()
    s = role_metadata_0.serialize()
    assert s is not None

# Generated at 2022-06-25 05:55:21.281689
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Constructor exists?
    try:
        test_case_0()
    except NameError as e:
        print("RoleMetadata constructor does not exist")
        assert False
    print("RoleMetadata constructor exists")
    assert True


# Generated at 2022-06-25 05:55:24.861107
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test for constructor of class RoleMetadata
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-25 05:55:30.803308
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialized_0 = role_metadata_0.serialize()
    if serialized_0 != {'allow_duplicates': False, 'dependencies': []}:
        raise AssertionError()


# Generated at 2022-06-25 05:55:32.743659
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=True, dependencies=['delete']))


# Generated at 2022-06-25 05:55:34.138852
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:55:37.862583
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'allow_duplicates': False, 'dependencies': [], 'galaxy_info': None, 'argument_specs': {}})


# Generated at 2022-06-25 05:55:39.297668
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load({}, None)


# Generated at 2022-06-25 05:55:40.427267
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:55:41.905364
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata().__class__.__name__ == 'RoleMetadata'


# Generated at 2022-06-25 05:55:56.676838
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("constructor RoleMetadata")
    role_metadata = RoleMetadata()
    assert role_metadata != None
    print("assertion test passed")
    print("")



# Generated at 2022-06-25 05:55:58.233448
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize([])


# Generated at 2022-06-25 05:55:59.872866
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert(role_metadata_0 is not None)

# Generated at 2022-06-25 05:56:04.926215
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO: implement this test!
    # test_RoleMetadata_load(self):
    role_metadata_0 = RoleMetadata()
    data_0 = {}
    owner_0 = RoleRequirement()
    variable_manager_0 = RoleInclude()
    loader_0 = None
    result_0 = role_metadata_0.load(data_0, owner_0, variable_manager_0, loader_0)
    assert not result_0


# Generated at 2022-06-25 05:56:10.668530
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

    assert role_metadata._dependencies == [], "Default value for dependency is not correct"
    role_metadata.dependencies = "abc"
    assert role_metadata.dependencies == "abc", "Set dependency value is not correct"

# Generated at 2022-06-25 05:56:13.432418
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []
    role_metadata_0.deserialize(data)

# Generated at 2022-06-25 05:56:17.287614
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    actual = role_metadata.serialize()
    assert actual['allow_duplicates'] == False, "Failed to execute 'serialize' method of class RoleMetadata"
    assert actual['dependencies'] == [], "Failed to execute 'serialize' method of class RoleMetadata"


# Generated at 2022-06-25 05:56:22.275121
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    my_role_metadata = RoleMetadata()
    if not isinstance(my_role_metadata, RoleMetadata):
        raise AssertionError("Constructor of RoleMetadata class is not working as intended")


# Generated at 2022-06-25 05:56:24.513321
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    datastructure_0 = {'meta/main.yml': {'dependencies': [{'role': 'template'}]}}
    role_metadata_0 = RoleMetadata.load(datastructure_0)

# Generated at 2022-06-25 05:56:28.793860
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    metadata.deserialize(dict(
        allow_duplicates=False,
        dependencies=[]))


# Generated at 2022-06-25 05:56:48.551285
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    ansible_metadata_1 = dict(
        allow_duplicates=True,
        dependencies=['name==1.0.0']
    )
    role_metadata_1.deserialize(data=ansible_metadata_1)
    assert role_metadata_1.allow_duplicates == True
    assert role_metadata_1.dependencies == ['name==1.0.0']

# Generated at 2022-06-25 05:56:52.577266
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        test_case_0()
    except Exception as err:
        raise AssertionError("Cannot instantiate class RoleMetadata")
        assert True


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v", "-s"])

# Generated at 2022-06-25 05:56:58.792290
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test for metastructure of type dict
    role_metadata_1 = RoleMetadata()
    data = dict()
    owner = dict()
    variable_manager = dict()
    loader = dict()
    try:
        result = role_metadata_1.load(data, owner, variable_manager, loader)
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-25 05:57:02.483049
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 05:57:05.100856
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    try:
        test_case_0()
    except Exception as e:
        print('Exception caught: {}'.format(e))
    else:
        print('Test case 0 passed.')


# Generated at 2022-06-25 05:57:06.643565
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert len(RoleMetadata.base_attrs) == 5
    test_case_0()

# Generated at 2022-06-25 05:57:11.827950
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1

    role_metadata_2 = RoleMetadata()
    assert role_metadata_2

    role_metadata_3 = RoleMetadata()
    assert role_metadata_3

    role_metadata_4 = RoleMetadata()
    assert role_metadata_4

    role_metadata_5 = RoleMetadata()
    assert role_metadata_5


# Generated at 2022-06-25 05:57:12.881166
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Testing __init__
    test_case_0()

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 05:57:22.989694
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import text_type

    role_metadata_0 = RoleMetadata()
    res_serialize_0 = isinstance(role_metadata_0.serialize(), Mapping)

    role_metadata_1 = RoleMetadata()
    res_serialize_1 = isinstance(role_metadata_1.serialize(), Mapping)

    role_metadata_0.deserialize({'allow_duplicates': True, 'dependencies': []})
    res_serialize_2 = isinstance(role_metadata_0.serialize(), Mapping)

    print("Test 1 Passed: " + str(res_serialize_0))
    print("Test 2 Passed: " + str(res_serialize_1))

# Generated at 2022-06-25 05:57:24.860806
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-25 05:58:04.212883
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_case = dict(
        allow_duplicates=False,
        dependencies=[
            dict(name='geerlingguy.apache'),
            dict(name='geerlingguy.php')
        ]
    )
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(test_case)
    assert role_metadata_0._dependencies[0]._role_name == 'geerlingguy.apache'
    assert role_metadata_0._dependencies[1]._role_name == 'geerlingguy.php'


# Generated at 2022-06-25 05:58:08.107028
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata() != None
    assert RoleMetadata()._allow_duplicates == False
    assert RoleMetadata()._dependencies == []
    assert RoleMetadata()._galaxy_info == None
    assert RoleMetadata()._argument_specs == {}
    assert RoleMetadata()._loader == None
    assert RoleMetadata()._owner == None


# Generated at 2022-06-25 05:58:08.785769
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:58:10.251230
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    value = role_metadata_0.serialize()
    assert value == {"allow_duplicates": False, "dependencies": []}

# Generated at 2022-06-25 05:58:20.144351
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:58:22.117923
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata, RoleMetadata)

# Generated at 2022-06-25 05:58:26.423527
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Initialize test variables
    owner = Base()
    data = dict()

    # Execute test
    role_metadata = RoleMetadata.load(data, owner)
    assert isinstance(role_metadata, RoleMetadata)


# Generated at 2022-06-25 05:58:30.716975
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(role_metadata_0.serialize())

# Generated at 2022-06-25 05:58:35.659935
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader, variable_manager, loader)
    playbook = Play().load({}, variable_manager=variable_manager, loader=loader)
    test_obj = RoleMetadata(owner=playbook)

    # test deserialize of an empty dict returns empty
    data = dict()
    test_obj.deserialize(data)

    # test deserialize of an dict with fields
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    test_obj.deserial

# Generated at 2022-06-25 05:58:39.673558
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0, RoleMetadata)


# Generated at 2022-06-25 05:59:41.447484
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0 is not None, "Failed to instantiate test_RoleMetadata_0"
    return role_metadata_0


role_metadata_0 = test_RoleMetadata()

# Generated at 2022-06-25 05:59:50.125689
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta_path = './unit_data/role_meta_main.yml'
    jdata = {}
    with open(meta_path) as meta_fd:
        jdata = yaml.safe_load(meta_fd)

    r_metadata = RoleMetadata()
    r_metadata.load_data(jdata)
    result = r_metadata.serialize()

    assert result['allow_duplicates'] == False
    assert result['dependencies'][0]['role'] == 'SomeOrganization.some_role'
    assert result['dependencies'][1]['role'] == 'OtherOrganization.other_role'
    assert result['dependencies'][2]['role'] == 'OtherOrganization.third_role'
    assert result['dependencies'][3]['role'] == 'OtherOrganization.fourth_role'

# Generated at 2022-06-25 05:59:53.293472
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load({'galaxy_info': 345, 'dependencies': ['test1', 'test2', 'test3']})


# Generated at 2022-06-25 05:59:56.497468
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    expected_result = {
        'dependencies': [],
        'allow_duplicates': False
    }
    result = role_metadata_1.serialize()

    assert result == expected_result, 'Expected: %s, Actual: %s' % (expected_result, result)


# Generated at 2022-06-25 05:59:58.862881
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = list()
    assert role_metadata.serialize() == {
        'allow_duplicates': False,
        'dependencies': list(),
    }


# Generated at 2022-06-25 06:00:03.364191
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 06:00:05.443518
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert(role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []})

# Generated at 2022-06-25 06:00:10.293363
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    # Test actual class attribute
    assert isinstance(role_metadata_0._allow_duplicates, bool)
    # Test actual class attribute
    assert isinstance(role_metadata_0._dependencies, list)
    # Test actual class attribute
    assert isinstance(role_metadata_0._galaxy_info, RoleMetadata)
    # Test actual class attribute
    assert isinstance(role_metadata_0._argument_specs, dict)


# Generated at 2022-06-25 06:00:20.493979
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dataLoader = DataLoader()
    variableManager = VariableManager()
    testPlay = Play.load({
        'name': 'test_play',
        'connection': 'local',
        'hosts': 'all',
        'tasks': [],
    }, variableManager, dataLoader)
    testPlayContext = PlayContext()
    testBlock = Block.load({"name": "test_block", "block": "block"}, testPlayContext, variableManager, dataLoader, testPlay)
   

# Generated at 2022-06-25 06:00:21.456018
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()



# Generated at 2022-06-25 06:02:21.185983
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # FIXME: this test is failing
    role_metadata_1 = RoleMetadata()

    # test deserialization of role_metadata_1
    data = dict(
        allow_duplicates=True,
        dependencies=list(),
    )
    role_metadata_1.deserialize(data)
    assert role_metadata_1._allow_duplicates == True
    assert role_metadata_1._dependencies == list()

    # test serialization of role_metadata_1
    assert role_metadata_1.serialize() == data


# FIXME: this test is failing

# Generated at 2022-06-25 06:02:25.945065
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._owner is None
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies is None
    assert role_metadata._galaxy_info is None
    assert role_metadata._argument_specs is None


# Generated at 2022-06-25 06:02:27.333933
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = dict()
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 06:02:34.095120
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vault_loader
    from ansible.plugins.loader import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.utils import context_objects as co
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.inventory.host import Host, Group
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common._collections_compat import MutableMapping

# Generated at 2022-06-25 06:02:37.857342
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0_dict = role_metadata_0.serialize()
    role_metadata_des_0 = RoleMetadata.deserialize(role_metadata_0_dict)
    assert role_metadata_des_0.serialize() == role_metadata_0.serialize()


# Generated at 2022-06-25 06:02:42.551523
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Test case 1
    role_metadata_1 = RoleMetadata()
    ans = {'allow_duplicates': False, 'dependencies': []}

    assert(role_metadata_1.serialize() == ans), \
        "role_metadata_1.serialize() != ans"


# Generated at 2022-06-25 06:02:52.322998
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    test_1_role_data = {'allow_duplicates': True, 'dependencies': [{'role': 'a_role_1'}, {'role': 'a_role_2'}, {'role': 'a_role_3'}]}
    test_1_expected_result = {'allow_duplicates': True, 'dependencies': [{'role': 'a_role_1'}, {'role': 'a_role_2'}, {'role': 'a_role_3'}]}
    assert role_metadata_1.deserialize(test_1_role_data) == test_1_expected_result

# Generated at 2022-06-25 06:02:57.158622
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata(owner=None)

    # Change nothing
    result = role_metadata_0.load(data=None, owner=None, variable_manager=None, loader=None)

    assert result is None


# Generated at 2022-06-25 06:02:59.273854
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.vars.variable_manager import VariableManager
    var_manager = VariableManager()
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'allow_duplicates': False, 'dependencies': []})


# Generated at 2022-06-25 06:03:01.337319
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    
    role_metadata_0.deserialize(None)


# Generated at 2022-06-25 06:05:02.395806
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-25 06:05:02.831065
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-25 06:05:03.470002
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 06:05:09.159108
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }
