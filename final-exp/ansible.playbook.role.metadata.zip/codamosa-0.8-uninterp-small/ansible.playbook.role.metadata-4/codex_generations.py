

# Generated at 2022-06-25 05:55:25.620769
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = {"allow_duplicates": False, "dependencies": []}
    role_metadata_0.deserialize(data_0)


# Generated at 2022-06-25 05:55:26.929256
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test case 0
    int_0 = 493
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:55:28.304741
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    int_0 = 493
    role_metadata_2 = RoleMetadata()


# Generated at 2022-06-25 05:55:29.090978
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_case_0()


# Generated at 2022-06-25 05:55:35.770162
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    int_0 = 493
    role_metadata_0 = RoleMetadata()
    str_0 = '''Dependency spec: {0} is malformed'''
    int_1 = 801
    str_1 = '''Dependency spec: {0} is malformed'''
    int_2 = 305
    str_2 = '''Dependency spec: {0} is malformed'''
    int_3 = 20
    int_4 = 522
    int_5 = 566
    str_3 = '''Dependency spec: {0} is malformed'''
    int_6 = 207
    str_4 = '''Dependency spec: {0} is malformed'''
    str_5 = '''Dependency spec: {0} is malformed'''
    int_7 = 619


# Generated at 2022-06-25 05:55:37.721205
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()


# Generated at 2022-06-25 05:55:38.881691
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_case_0()

# Load test for RoleMetadata.load method

# Generated at 2022-06-25 05:55:43.558124
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    int_0 = 493
    role_metadata_0 = RoleMetadata()
    data_0 = "/home/jhannah/.cache/ansible/ansiballz/ansible_tower/setup.py"
    owner_0 = "*/home/jhannah/.cache/ansible/ansiballz/ansible_tower/setup.py"
    role_metadata_1 = role_metadata_0.load(data_0, owner_0)



# Generated at 2022-06-25 05:55:45.539092
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    int_0 = 493
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(int_0)



# Generated at 2022-06-25 05:55:48.691073
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = 'test_data'
    role_metadata_0 = RoleMetadata()
    setattr(role_metadata_0, 'allow_duplicates', True)
    role_metadata_0.deserialize(data)
    assert getattr(role_metadata_0, 'allow_duplicates') == True


# Generated at 2022-06-25 05:56:04.998023
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.dependencies = [
        RoleRequirement(name="myrole", scm="git", src="https://github.com/geerlingguy/ansible-role-apache.git", version="master"),
        RoleRequirement(name="myrole2", scm="git", src="https://github.com/geerlingguy/ansible-role-apache.git", version="")
    ]

# Generated at 2022-06-25 05:56:07.831350
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {"allow_duplicates": True, "dependencies": ['role2']}
    role_metadata_0.deserialize(data)
    assert role_metadata_0.allow_duplicates is True
    assert role_metadata_0._dependencies == ['role2']


# Generated at 2022-06-25 05:56:16.266999
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(allow_duplicates=True, dependencies=[RoleRequirement(name='test_role')])
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)
    if not role_metadata_0.allow_duplicates: #if not self._allow_duplicates:
        raise AssertionError('Property allow_duplicates did not get set')
    if not role_metadata_0.dependencies: #if not self._dependencies:
        raise AssertionError('Property dependencies did not get set')


# Generated at 2022-06-25 05:56:21.335155
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test if serialize raises TypeError when ds is not a dict
    with pytest.raises(TypeError, match="'serialize' requires 'ds' argument to be a dict"):
        role_metadata_0 = RoleMetadata()
        role_metadata_0.serialize(ds=None)


# Generated at 2022-06-25 05:56:24.686473
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(
                                    allow_duplicates=False,
                                    dependencies=list()
                                ))
    data = role_metadata.serialize()

    assert data['allow_duplicates'] == False
    assert data['dependencies'] == list()

# Generated at 2022-06-25 05:56:27.644466
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {}
    roleMetadata = RoleMetadata()
    roleMetadata.load(data, None)
    assert roleMetadata._dependencies == []
    assert roleMetadata._galaxy_info == {}
    assert roleMetadata._allow_duplicates == False
    assert roleMetadata._argument_specs == {}


# Generated at 2022-06-25 05:56:36.024320
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = dict()
    role_metadata_0.deserialize(data_0)
    data_1 = dict()
    role_metadata_0.deserialize(data_1)
    data_2 = dict()
    role_metadata_0.deserialize(data_2)
    data_3 = dict()
    role_metadata_0.deserialize(data_3)
    data_4 = dict()
    role_metadata_0.deserialize(data_4)


# Generated at 2022-06-25 05:56:41.131882
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = dict(allow_duplicates=False, dependencies=[])
    role_metadata_0.deserialize(data_0)


# Generated at 2022-06-25 05:56:43.785718
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    result_1 = role_metadata_1.serialize()
    assert result_1 == {'allow_duplicates': False, 'dependencies': []}, "serialize() result is wrong"

# Generated at 2022-06-25 05:56:45.386102
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 05:57:04.172498
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Create an instance of class RoleMetadata
    role_metadata = RoleMetadata()
    #role_metadata.load(data="data", owner="owner", variable_manager="variable_manager", loader="loader")
    #print(role_metadata)
    print("Test passed")


# Generated at 2022-06-25 05:57:13.023747
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.host_set is False
    assert role_metadata_0.pattern is ''
    assert role_metadata_0.ignore_errors is False
    assert role_metadata_0._filter_tags is None
    assert role_metadata_0._ungroup_tags == []
    assert role_metadata_0.run_once is False
    assert role_metadata_0.step is False
    assert role_metadata_0.serial is 0
    assert role_metadata_0.always_run is False
    assert role_metadata_0._when is None
    assert role_metadata_0.port is 0
    assert role_metadata_0.tags == []
    assert role_metadata_0.name is ''
    assert role_metadata_0._task_include is None
    assert role_

# Generated at 2022-06-25 05:57:18.585174
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata().deserialize(data={'dependencies': [], 'allow_duplicates': False})
    role_metadata_2 = RoleMetadata().deserialize(data={'dependencies': [], 'allow_duplicates': False})
    assert role_metadata_1.serialize() == role_metadata_2.serialize()



# Generated at 2022-06-25 05:57:21.407085
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(dict(
        allow_duplicates=False,
        dependencies=list()
    ))


# Generated at 2022-06-25 05:57:26.523576
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()
    role_metadata_0.load_data({'allow_duplicates': False, 'dependencies': []})
    role_metadata_0.finalize()
    role_metadata_1.load_data({'allow_duplicates': False, 'dependencies': []})
    role_metadata_1.finalize()
    assert role_metadata_0.serialize() == role_metadata_1.serialize()


# Generated at 2022-06-25 05:57:30.979468
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(dict())

    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize(dict(allow_duplicates=True))


# Generated at 2022-06-25 05:57:39.768577
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata(owner=None)
    # Load list of dependencies with RoleInclude
    assert isinstance(role_metadata._load_dependencies('dependencies', [{'role': 'apache', 'nested_role': {'role': 'foo'}}]), list)
    # Load str of dependencies with RoleInclude
    assert isinstance(role_metadata._load_dependencies('dependencies', 'test'), list)
    # Load dict of dependencies with role
    # TODO(goneri): fix this test once role inclusion is managed by role_include instead of role_metadata
    #assert isinstance(role_metadata._load_dependencies('dependencies', {'role': 'test'}), list)
    assert isinstance(role_metadata._load_dependencies('dependencies', {'name': 'test'}), list)


# Generated at 2022-06-25 05:57:51.682227
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    role_def = RoleDefinition()
    role_def._role_path = "./ansible/roles/gather_facts/meta/main.yml"

    from ansible.playbook.play import Play
    play = Play()

    from ansible.playbook.play_context import PlayContext
    pc = PlayContext()

    from ansible.vars.manager import VariableManager
    vm = VariableManager()

    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()

    metadata_file_path = "./ansible/roles/gather_facts/meta/main.yml"
    meta_ds = dl.load_from_file(metadata_file_path, play=play)

# Generated at 2022-06-25 05:57:59.113247
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    data = {
        'dependencies': [
            {
                'role': 'example.foo',
                'some_var': 'some_value'
            },
            {
                'role': 'example.bar',
                'some_var': 'some_other_value'
            }
        ]
    }
    role_metadata.load(data, owner=None)
    assert role_metadata._dependencies[0].role == 'example.foo'

# unit test for method serialize of class RoleMetadata

# Generated at 2022-06-25 05:58:03.709120
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    data_0 = dict()
    owner_0 = RoleMetadata()
    ansible_parse_error_0 = AnsibleParserError()
    try:
        assert role_metadata_0.load(data_0,owner_0)
    except AssertionError:
        raise AssertionError(ansible_parse_error_0.message)

# Generated at 2022-06-25 05:58:16.112672
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize == "{'dependencies': [], 'allow_duplicates': False}"


# Generated at 2022-06-25 05:58:21.476285
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    result = role_metadata_0.serialize()
    assert result == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:58:24.407755
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:58:27.115898
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()

    data_1 = {'data_0': 'data_0', 'data_1': 'data_1'}
    role_metadata_0.deserialize(data_1)


# Generated at 2022-06-25 05:58:28.733750
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # This test is solely to get a 100% code coverage for the file
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({})

# Generated at 2022-06-25 05:58:33.737736
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    output = role_metadata_0.serialize()
    assert output['allow_duplicates'] == 0
    assert output['dependencies'] == []


# Generated at 2022-06-25 05:58:35.574852
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    mdr = RoleMetadata()
    assert(mdr is not None)


# Generated at 2022-06-25 05:58:39.170391
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()
    obj.deserialize(data={'dependencies': [], 'allow_duplicates': False})
    obj.deserialize(data={})
    obj.deserialize(data={'dependencies': ['localhost.local'], 'allow_duplicates': True})


# Generated at 2022-06-25 05:58:44.350577
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    a="""
    - role: myapp_webserver
      role: apache2

    - role: mysql
    - role: myapp_database
      example_var: "{{ db_example_var }}"

    - name: myapp_database
      src: git+https://github.com/ansible-collections/my_namespace.my_collection.some_role
    """
    role_metadata_1 = RoleMetadata.load(a, current_role_path="", variable_manager='', loader='')
    assert role_metadata_1 is not None

if __name__ == "__main__":
    test_RoleMetadata_load()
    test_case_0()

# Generated at 2022-06-25 05:58:45.832712
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:59:07.600978
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print("Running test_RoleMetadata_deserialize")

    # Create instance of RoleMetadata
    role_metadata_0 = RoleMetadata()

    # Manual test
    role_metadata_0.deserialize(None)

    # Create a dict to pass to deserialize
    dict = {}
    dict['role_name'] = "common"
    dict['role_path'] = "./common"
    dict['collections'] = []
    dict['allow_duplicates'] = True
    dict['dependencies'] = []
    dict['metadata'] = {}

    # Call deserialize
    role_metadata_0.deserialize(dict)


# Generated at 2022-06-25 05:59:13.591126
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata.load(None, None)
    assert role_metadata.serialize() == {"allow_duplicates": False, "dependencies": []}
    role_metadata.deserialize({"allow_duplicates": True, "dependencies": ["role"]})
    assert role_metadata.serialize() == {"allow_duplicates": True, "dependencies": ["role"]}

# Generated at 2022-06-25 05:59:20.949917
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Fixme: RoleMetadata(owner=None) loads a file with a name 
    # in the form of a path relative to the current path
    # Rather than a string containing the YAML
    #
    # Fixme: This test would fail without preloading the correct structure
    # into the owner object
    #
    test_metadata_yml = """
    dependencies:
      - galaxy.role1,1.0,name1
    """
    role_metadata_1 = RoleMetadata.load(test_metadata_yml, owner=None)
    assert role_metadata_1


# Generated at 2022-06-25 05:59:27.884972
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_dict = dict(
        allow_duplicates=False,
        dependencies=[
            dict(
                name='common',
                src='https://github.com/geerlingguy/ansible-role-common',
                version='1.3.0'
            ),
            dict(
                name='geerlingguy.java',
                version='1.3.0'
            )
        ]
    )
    role_metadata_0 = RoleMetadata.load(test_dict, {})
    assert role_metadata_0._allow_duplicates == False

# Generated at 2022-06-25 05:59:29.472560
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()

# Generated at 2022-06-25 05:59:31.521653
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 05:59:36.662147
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data={})


# Generated at 2022-06-25 05:59:48.358947
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # Tests with a valid file
    # Initialize data to be passed to RoleMetadata.load
    data = {}
    owner = None
    variable_manager = None
    loader = None

    # Initialize the expected result
    result = None

    # Test RoleMetadata.load
    result = RoleMetadata.load(data, owner, variable_manager, loader)

    # Tests with an invalid file
    # Initialize data to be passed to RoleMetadata.load
    data = ""
    owner = None
    variable_manager = None
    loader = None

    # Initialize the expected result
    result = None

    # Test RoleMetadata.load
    try:
        result = RoleMetadata.load(data, owner, variable_manager, loader)
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 05:59:52.472923
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    owner = 'lalu'
    variable_manager = 'becker'
    loader = 'jessi'
    data = {'some_key': 'some_value'}
    #
    rm = RoleMetadata(owner=owner)
    rm.load(data, owner, variable_manager, loader)


# Generated at 2022-06-25 05:59:55.354733
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data={'allow_duplicates': False, 'dependencies': [{'src': 'test_str', 'name': 'test_str'}]})


# Generated at 2022-06-25 06:00:22.009619
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.load() == None

# Generated at 2022-06-25 06:00:23.848572
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 06:00:27.221163
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    test = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0.deserialize(test)


# Generated at 2022-06-25 06:00:30.820460
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    try:
        test_data_0 = RoleMetadata.load(data={"dependencies": []},
                                        owner={},
                                        variable_manager={},
                                        loader={})
    except AnsibleParserError as e:
        pass        # Expected error


# Generated at 2022-06-25 06:00:35.545029
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'dependencies' : []})
    role_metadata_0.deserialize({'allow_duplicates' : True})
    role_metadata_0.deserialize({'allow_duplicates' : True, 'dependencies' : []})

# Generated at 2022-06-25 06:00:41.870663
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.dependencies = ['test_case_0_dep_list', 'test_case_0_dep_list']
    role_metadata_0.allow_duplicates = True
    
    assert role_metadata_0.serialize()['dependencies'] == ['test_case_0_dep_list', 'test_case_0_dep_list']
    assert role_metadata_0.serialize()['allow_duplicates'] == True


# Generated at 2022-06-25 06:00:45.011205
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(a = 1, b = 2, c = 3)
    role = RoleMetadata()
    role.deserialize(data)
    assert role._allow_duplicates == False
    assert role._dependencies == []

# Generated at 2022-06-25 06:00:53.855729
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # RoleMetadata/GalaxyInfo
    gal = RoleMetadata._load_galaxy_info(None, None)
    assert gal is None

    # RoleMetadata/RoleInclude
    dep = RoleMetadata._load_dependencies(None, None)
    assert isinstance(dep, list)
    assert len(dep) == 0

    # RoleMetadata/RoleInclude
    dep = RoleMetadata._load_dependencies(None, ['test_role'])
    assert isinstance(dep, list)
    assert len(dep) == 1
    assert dep[0]['name'] == 'test_role'
    assert dep[0]['allow_duplicates'] is False

    # RoleMetadata/RoleInclude
    dep = RoleMetadata._load_dependencies(None, [{'test_role': None}])
   

# Generated at 2022-06-25 06:00:58.522032
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    print("")
    print("*"*10, " TEST: RoleMetadata load", '*'*10)
    role_metadata_1 = RoleMetadata()
    role_metadata_1.load({}, None)


if __name__ == "__main__":
    test_RoleMetadata_load()

# Generated at 2022-06-25 06:01:06.313162
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    ds = dict(
        dependencies=dict(
            roles=[
                dict(name='test1'),
                dict(role='test2'),
                dict(name='test3', src='../other', version='1.0.0')
            ]
        )
    )

    for role in RoleMetadata(owner=123).load(ds, variable_manager=None, loader=None).dependencies:
        assert isinstance(role, RoleInclude) or isinstance(role, RoleDefinition)

# Generated at 2022-06-25 06:01:56.681192
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test = """
    {
        "dependencies": [
            {
                "role": "dependency_role",
                "name": "dependency_role",
                "collection": "my_collection",
                "version_requirement": ">= 1.0.0"
            }
        ],
        "allow_duplicates": false
    }
    """
    test_json = json.loads(test)

    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(test_json)


# Generated at 2022-06-25 06:02:01.779535
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(
        allow_duplicates=True,
        dependencies=[]
    ))



# Generated at 2022-06-25 06:02:08.787850
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    my_ds = dict()
    my_ds['dependencies'] = list()
    # Populate one dependency
    my_ds['dependencies'].append(dict())
    my_ds['dependencies'][0]['role'] = 'my_dependency'
    my_ds['dependencies'][0]['version'] = '1.2'
    role_metadata.load(my_ds)

# Generated at 2022-06-25 06:02:13.597636
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)
    assert role_metadata_0._allow_duplicates == False
    assert role_metadata_0._dependencies == []


# Generated at 2022-06-25 06:02:18.647913
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
   role_metadata_load_0 = RoleMetadata()
   data_0 = dict(dependencies = [{"src": "geerlingguy.java", "name": "geerlingguy.java"}])
   role_metadata_load_0.load(data = data_0)


# Generated at 2022-06-25 06:02:25.999669
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test constructor with no input arguments (default values should be used)
    role_metadata_0 = RoleMetadata()

    assert role_metadata_0._attributes['allow_duplicates']['default'] == False
    assert role_metadata_0._attributes['dependencies']['default'] == []
    assert role_metadata_0._attributes['galaxy_info']['default'] == None
    assert role_metadata_0._attributes['argument_specs']['default'] == {}

# Generated at 2022-06-25 06:02:26.923054
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    assert type(role) == RoleMetadata

# Generated at 2022-06-25 06:02:30.161012
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    Test deserialize with a valid meta yaml
    """
    meta_data = "meta/main.yml"
    role_metadata = RoleMetadata()
    role_metadata.deserialize(meta_data)

    assert role_metadata == meta_data


# Generated at 2022-06-25 06:02:36.230487
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    dict_0 = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(dict_0)


# Generated at 2022-06-25 06:02:42.846109
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_data = dict(
        allow_duplicates=False,
        dependencies=[])
    ansible_data = dict(
        allow_duplicates=False,
        dependencies=[])
    role_metadata = RoleMetadata()
    role_metadata.deserialize(role_data)
    assert role_metadata
    assert role_metadata.serialize() == ansible_data

# Generated at 2022-06-25 06:04:08.927837
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize().get('allow_duplicates') is False
    assert role_metadata.serialize().get('dependencies') is []

# Generated at 2022-06-25 06:04:14.988098
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {"allow_duplicates": False, "dependencies": []}
    ret = role_metadata_0.deserialize(data)
    assert ret == False
    assert role_metadata_0._dependencies == []


# Generated at 2022-06-25 06:04:19.955163
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(role_metadata.serialize())
    assert role_metadata_0.serialize() == role_metadata.serialize()



# Generated at 2022-06-25 06:04:30.672443
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Unit test for the constructor of class RoleMetadata
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition

    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata(owner=RoleDefinition())
    role_metadata_2 = RoleMetadata(owner=Play())
    role_metadata_3 = RoleMetadata(owner=PlayContext())

    # test normal instantiation

# Generated at 2022-06-25 06:04:33.765561
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(
        allow_duplicates=False,
        dependencies=[],
    )



# Generated at 2022-06-25 06:04:38.663333
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    variables_dict = dict()
    loader_obj = ansible.parsing.dataloader.DataLoader()
    role_metadata_obj = RoleMetadata()
    role_metadata_result = role_metadata_obj.serialize()
    assert role_metadata_result == dict(
            allow_duplicates=False,
            dependencies=[]
        )


# Generated at 2022-06-25 06:04:40.634650
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected_dict = dict(allow_duplicates=False, dependencies=[])
    assert (role_metadata_0.serialize() == expected_dict)


# Generated at 2022-06-25 06:04:41.855774
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()

    data = {}

    role_metadata.load(data)

# Generated at 2022-06-25 06:04:42.449778
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-25 06:04:42.947493
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass