

# Generated at 2022-06-25 05:55:24.538602
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # test the constructor of class RoleMetadata by passing valid and invalid arguments
    
    # Case 0: invalid arguments. Should fail
        # No arguments
    role_metadata_0 = RoleMetadata()

    # Case 1: invalid arguments. Should fail
        # Invalid type for "owner" argument
    #role_metadata_1 = RoleMetadata(owner = 1)

    # Case 2: valid arguments. Should pass
        # No arguments
    role_metadata_2 = RoleMetadata()

    # Case 3: valid arguments. Should pass
        # Role as valid "owner" argument
    role_metadata_3 = RoleMetadata()


test_RoleMetadata()



# Generated at 2022-06-25 05:55:25.585043
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    print(role_metadata_0)

# Generated at 2022-06-25 05:55:29.771114
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []
    assert role_metadata_0.galaxy_info == None
    assert role_metadata_0.argument_specs == {}
    assert role_metadata_0.name == ""
    assert role_metadata_0.tags == []

test_case_0()
test_RoleMetadata()

# Generated at 2022-06-25 05:55:31.121255
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict())
    return


# Generated at 2022-06-25 05:55:34.071109
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata_0 = RoleMetadata()

    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:55:36.530603
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None


# Generated at 2022-06-25 05:55:38.035756
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load(dict(), None, None, None)



# Generated at 2022-06-25 05:55:45.665605
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    
    # Define a mock for the 'loader' class
    class loader_mock:
        def __init__(self):
            pass
        def get_basedir(self):
            return AnsibleUnicode('/path/to/role')
    
    # Define a mock for the 'Role' class
    class Role_mock:
        def __init__(self, filename, play, path, collection=None, task_include=None):
            self._role_name = AnsibleUnicode()
            self._role_path = AnsibleUnicode()
            self._role_collection = collection
            self._play = play
            self.collections = list()
    
    # Define a mock for the 'variable_manager' class


# Generated at 2022-06-25 05:55:48.566515
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    data = {
        'dependencies': [
            {
                'role': 'role.test',
                'collection': 'collection.test'
            }
        ]
    }
    role_metadata_0.load(data, owner=None)


# Generated at 2022-06-25 05:55:52.998998
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-25 05:56:03.859163
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Can we use the ansible.test.unit.test_loader.TestDataLoader here?
    data = dict(
        allow_duplicates=False,
        dependencies=[],
    )
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize(data)
    assert role_metadata_1.allow_duplicates == False
    assert role_metadata_1.dependencies == []


# Generated at 2022-06-25 05:56:14.934591
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # FIXME: how do I pass a loader or variable manager?
    data = {
        'dependencies': [
            {'role': 'common'},
            'postgresql',
            'example_vars',
            'mysql',
            {'role': 'foobar', 'x': 1, 'y': 2}
        ],
        'allow_duplicates': True
    }
    role_metadata_1 = RoleMetadata.load(data, None, None, None)
    assert role_metadata_1.dependencies[0]['role'] == 'common'
    assert role_metadata_1.dependencies[1] == 'postgresql'
    assert role_metadata_1.dependencies[2] == 'example_vars'
    assert role_metadata_1.dependencies[3] == 'mysql'
   

# Generated at 2022-06-25 05:56:17.979012
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_case_0()

# Generated at 2022-06-25 05:56:23.527507
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates": False, "dependencies": []})
    data = role_metadata.serialize()
    assert data == {"allow_duplicates": False, "dependencies": []}


# Generated at 2022-06-25 05:56:28.325300
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Return a new RoleMetadata object based on the datastructure passed in.
    test_RoleMetadata_load.flag = 1


# Generated at 2022-06-25 05:56:30.851874
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-25 05:56:33.887687
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load.
    '''

    '''
    TODO: Implement this test.
    '''
    pass


# Generated at 2022-06-25 05:56:37.178666
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = dict()
    setattr(role_metadata_0, 'allow_duplicates', data.get('allow_duplicates', False))
    setattr(role_metadata_0, 'dependencies', data.get('dependencies', []))


# Generated at 2022-06-25 05:56:40.435450
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.serialize()


# Generated at 2022-06-25 05:56:46.315765
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert isinstance(role_metadata._dependencies, list)
    assert role_metadata._allow_duplicates == False

# Generated at 2022-06-25 05:57:03.217727
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata0 = RoleMetadata()
    data = {'allow_duplicates':False, 'dependencies':[{'role':'ROLE'}]}
    role_metadata0 = role_metadata0.deserialize(data)
    assert role_metadata0.serialize() == data


# Generated at 2022-06-25 05:57:08.333094
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Load good role metadata
    role_metadata_0 = RoleMetadata.load(dict(galaxy_info=dict(author='me')), owner=None)
    assert role_metadata_0.galaxy_info == dict(author='me')

    # Load bad role metadata
    try:
        role_metadata_1 = RoleMetadata.load(dict(galaxy_info=dict()), owner=None)
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 05:57:11.273389
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    role.deserialize({'name': 'test', 'verion': '1.0.0'})
    assert role._name == 'test'
    assert role._version == '1.0.0'


# Generated at 2022-06-25 05:57:13.468322
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 05:57:16.151668
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    # AssertionError: unittest failure
    # assert role_metadata_0.deserialize() == None, "%s.deserialize() != None" % role_metadata_0


# Generated at 2022-06-25 05:57:21.633619
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test load when the 'meta/main.yml' for role is not a dictionary
    try:
        data_0 = 1
        role_metadata_0 = RoleMetadata()
        role_metadata_0.load(data_0)
        assert False
    except AnsibleParserError:
        pass
    else:
        assert False

# Generated at 2022-06-25 05:57:22.754154
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert (role_metadata_0 != None)


# Generated at 2022-06-25 05:57:24.153975
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-25 05:57:25.833569
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.__init__()

# Generated at 2022-06-25 05:57:30.613391
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    serialize_data = role_metadata_1.serialize()
    assert serialize_data['allow_duplicates'] == False
    assert serialize_data['dependencies'] == []


# Generated at 2022-06-25 05:57:57.176933
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load({"role_name" : "test_role_0"}, "test_role_0")



# Generated at 2022-06-25 05:57:58.865159
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(
        allow_duplicates=False,
        dependencies=[],
    )


# Generated at 2022-06-25 05:58:00.184185
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None


# Generated at 2022-06-25 05:58:06.371266
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {"allow_duplicates": False, "dependencies": []}
    role_metadata_0.deserialize(data)
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []


# Generated at 2022-06-25 05:58:08.276649
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata();
    result = r.deserialize({'allow_duplicates': False, 'dependencies': []});
    assert result == None


# Generated at 2022-06-25 05:58:09.584776
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []


# Generated at 2022-06-25 05:58:11.190746
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }

# Generated at 2022-06-25 05:58:16.311800
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata.load({'dependencies': ['common.role']})
    assert role_metadata_1._dependencies[0]._role_name == 'common.role'

# Generated at 2022-06-25 05:58:23.268662
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected = {
        "allow_duplicates": False,
        "dependencies": [],
    }
    result = role_metadata_0.serialize()
    assert result == expected
    # TODO: Improve the serialize unit test
    # Other potential tests for serialize
    #    * Expected does not match result


# Generated at 2022-06-25 05:58:25.677237
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    cls_RoleMetadata_obj = RoleMetadata()
    cls_RoleMetadata_obj.serialize()
    pass


# Generated at 2022-06-25 05:59:10.964264
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print ("test_RoleMetadata")
    test_case_0()

# Run tests
test_RoleMetadata()

# Generated at 2022-06-25 05:59:12.566606
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.serialize()

# Generated at 2022-06-25 05:59:16.980272
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    dict_0 = dict(name="Thierry", is_valid=True)

    role_metadata_0.deserialize(dict_0)


# Generated at 2022-06-25 05:59:22.860801
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates":True, "dependencies":[]})
    assert(role_metadata.allow_duplicates == True)
    assert (role_metadata.dependencies == [])


if __name__ == '__main__':
    test_case_0()
    test_RoleMetadata_deserialize()

# Generated at 2022-06-25 05:59:28.261785
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    galaxy_info = []
    for i in range(0,8):
        galaxy_info.append(i)
    role_metadata.load(galaxy_info,None)

# Generated at 2022-06-25 05:59:30.442304
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0, RoleMetadata)


# Generated at 2022-06-25 05:59:34.976517
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:59:36.713336
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata()

    #TODO: Require a testcase
    return obj.deserialize(data)


# Generated at 2022-06-25 05:59:40.872034
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data={'allow_duplicates': True, 'dependencies': []})

# Generated at 2022-06-25 05:59:49.785373
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-25 06:01:20.426195
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {"allow_duplicates":False,"dependencies":[]}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 06:01:23.707222
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    try:
        role_metadata_1 = RoleMetadata()
        role_metadata_1.load()
    except:
        pass
    else:
        raise AssertionError("The RoleMetadata load method has not been implemented.")

# Generated at 2022-06-25 06:01:27.498416
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_dict_0 = {}
    role_metadata_0.deserialize(data_dict_0)


# Generated at 2022-06-25 06:01:34.435770
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata.load(
        {
            "dependencies": [
                {
                    "role": "dependency-role-1",
                    "force_handlers": "yes"
                },
                {
                    "role": "dependency-role-2",
                    "when": "ansible_os_family == 'Debian'"
                },
                {
                    "role": "dependency-role-3",
                    "allow_duplicates": True
                }
            ],
            "allow_duplicates": False
        },
        owner=None
    )

# Generated at 2022-06-25 06:01:37.735324
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'dependencies': [], 'allow_duplicates': False})

# Generated at 2022-06-25 06:01:42.153331
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load("text")


# Generated at 2022-06-25 06:01:42.877647
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 06:01:48.964538
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()

    serialized_data = role_metadata.serialize()

    assert serialized_data == {'dependencies': [], 'allow_duplicates': False}



# Generated at 2022-06-25 06:01:54.706262
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    expected_result = dict(
        allow_duplicates=False,
        dependencies=[]  # TODO: dnaber: Investigate why this is empty
    )
    assert expected_result == role_metadata_1.serialize()

# Generated at 2022-06-25 06:01:59.834053
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0._allow_duplicates = True
    role_metadata_0._dependencies = [{'foo': 'role_metadata_0._dependencies[0]'}]
    role_metadata_0._galaxy_info = None
    role_metadata_0._argument_specs = {'foo': 'role_metadata_0._argument_specs'}
    expected = dict(allow_duplicates=True, dependencies=[{'foo': 'role_metadata_0._dependencies[0]'}])
    actual = role_metadata_0.serialize()
    assert expected == actual


# Generated at 2022-06-25 06:03:12.400956
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [RoleRequirement()]
    assert role_metadata.serialize() == {
        "allow_duplicates": True,
        "dependencies": [RoleRequirement().serialize()]
    }

# Generated at 2022-06-25 06:03:15.457504
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    #testing in serialize method, so no assert data is needed.
    role_metadata_0.serialize()


# Generated at 2022-06-25 06:03:17.348639
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False,
            'dependencies': []}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 06:03:20.894455
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert isinstance(role_metadata_1.serialize(), dict), \
        "Violation of: RoleMetadata.serialize returns a dict"


# Generated at 2022-06-25 06:03:23.000191
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(
        allow_duplicates=False,
        dependencies=[],
    ), role_metadata_0.serialize()


# Generated at 2022-06-25 06:03:24.774646
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert 'allow_duplicates' in role_metadata_0.serialize()
    assert 'dependencies' in role_metadata_0.serialize()


# Generated at 2022-06-25 06:03:29.431519
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Copy test/unit/files/test_role_meta/main.yml to /tmp/role_meta/main.yml
    local_path_to_main_yml = '/tmp/role_meta/main.yml'
    local_path_to_role_root = '/tmp/role_meta'
    from shutil import copyfile
    copyfile('test/unit/files/test_role_meta/main.yml', local_path_to_main_yml)

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.loader import RoleLoader
    rd = RoleDefinition(name='test_role_meta', playbook=local_path_to_role_root)
    role_loader = RoleLoader(basedir=local_path_to_role_root)
    role

# Generated at 2022-06-25 06:03:36.279089
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
  r_data = "./test/units/module_utils/ansible/test/units/module_utils/ansible_test_roles/meta/main.yml"
  r_path = "./test/units/module_utils/ansible_test_roles/meta"
  r_name = "ansible_test_roles"
  # We are loading a role names ansible_test_roles
  role_metadata_1 = RoleMetadata.load(r_data, r_path, r_name)
    

# Generated at 2022-06-25 06:03:43.127040
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.allow_duplicates is False
    assert role_metadata_1.dependencies == []

    role_metadata_2 = RoleMetadata()
    assert role_metadata_1 == role_metadata_2

    role_metadata_3 = RoleMetadata()
    assert hash(role_metadata_1) != hash(role_metadata_3)

# Generated at 2022-06-25 06:03:50.178228
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    metadata = dict(
        allow_duplicates=False,
        dependencies=[
            dict(role='role1'),
            dict(role='role2')
        ]
    )

    role_metadata = RoleMetadata()
    role_metadata.deserialize(metadata)

    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies[0].role == 'role1'
    assert role_metadata.dependencies[1].role == 'role2'

