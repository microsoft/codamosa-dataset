

# Generated at 2022-06-25 05:55:30.854954
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-25 05:55:34.481087
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    role_metadata_0 = RoleMetadata()

    exception = None
    try:
        role_metadata_0.deserialize({'allow_duplicates': True, 'dependencies': [{'role': 'redhat.yum-utils', 'name': 'redhat.yum-utils'}]})
    except Exception as e:
        exception = e

    assert not exception


# Generated at 2022-06-25 05:55:38.918330
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    yaml_str =  "\n" +\
    "dependencies:\n" +\
    "- name: foo\n" +\
    "- name: bar\n" +\
    "- src: baz\n"
    role_metadata_0.deserialize(yaml_str)

# Generated at 2022-06-25 05:55:39.774133
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:55:42.986413
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    loader,role_path,vam = mock_loader()
    data = None
    owner = mock_owner()
    with pytest.raises(AnsibleParserError):
        role_metadata = RoleMetadata.load(data,owner,variable_manager = vam, loader=loader)


# Generated at 2022-06-25 05:55:44.815002
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {}
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 05:55:46.754132
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []} 


# Generated at 2022-06-25 05:55:53.035321
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None)
    role_metadata._allow_duplicates = False
    role_metadata._dependencies = []

    role_metadata.serialize()

    # Test for method serialize of class RoleMetadata

    # Test for successors of method serialize of class RoleMetadata

# Generated at 2022-06-25 05:56:03.700610
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    try:
        # Test with a valid value, i.e. a dictionary
        valid_dict_0 = {'dependencies': [{"role": "foo", "foo2": "bar2", "tab": "baz"}], 'allow_duplicates': True}
        role_metadata_load_0 = RoleMetadata.load(valid_dict_0, None, None, None)

        # Test with an invalid value, i.e. a list
        invalid_list_0 = ['dependencies', [{"role": "foo", "foo2": "bar2", "tab": "baz"}], 'allow_duplicates', True]
        role_metadata_load_1 = RoleMetadata.load(invalid_list_0, None, None, None)
    except Exception as exc:
        raise AssertionError(exc)

# Generated at 2022-06-25 05:56:06.867693
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    ds = dict(
        allow_duplicates = True,
        dependencies = [],
    )
    role_metadata_0 = RoleMetadata.load(ds, None)


# Generated at 2022-06-25 05:56:15.658799
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # test_RoleMetadata_deserialize_0 ----------------------------------------
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0._deserialize({u'allow_duplicates': False, u'dependencies': []}) == None
    # test_RoleMetadata_deserialize_1 ----------------------------------------
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1._deserialize({u'allow_duplicates': False, u'dependencies': []}) == None


# Generated at 2022-06-25 05:56:16.717990
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {"allow_duplicates": False, "dependencies": []}


# Generated at 2022-06-25 05:56:24.408884
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0._dependencies = ['geerlingguy.apache', 'geerlingguy.ansible-role-repo']
    role_metadata_0._allow_duplicates = False
    result = role_metadata_0.serialize()
    assert result == {'allow_duplicates': False, 'dependencies': ['geerlingguy.apache', 'geerlingguy.ansible-role-repo']}


# Generated at 2022-06-25 05:56:26.203639
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    role_metadata = RoleMetadata()
    assert role_metadata
    assert role_metadata._owner is None

    #TODO: add more test cases here


# Generated at 2022-06-25 05:56:30.503354
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialize_data_0 = dict(
        allow_duplicates=False,
        dependencies=list()
    )
    assert role_metadata_0.serialize() == serialize_data_0


# Generated at 2022-06-25 05:56:34.211326
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_obj_1 = RoleMetadata()
    result_1 = role_metadata_obj_1.serialize()
    assert result_1 == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:56:40.662408
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    data = {"allow_duplicates": False,
            "dependencies": [{"role": "foo", "src": "bar", "scm": "git", "version": "1.2"}],
            "galaxy_info": {"author": "john", "author_email": "john@gmail.com", "company": "abc",
                            "description": "foo role", "license": "MIT"},
            "issue_tracker_url": "http://tracker.com",
            "min_ansible_version": "1.2",
            "repository_url": "https://github.com/ansible/ansible-examples.git",
            "supported_by": "comminity"}
    with pytest.raises(AnsibleParserError):
        role_metadata.load

# Generated at 2022-06-25 05:56:46.193937
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialize_output = role_metadata_0.serialize()
    assert serialize_output["allow_duplicates"] == False
    assert serialize_output["dependencies"] == []


# Generated at 2022-06-25 05:56:50.810388
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    roledata = RoleMetadata().serialize()
    assert roledata['allow_duplicates'] == False
    assert roledata['dependencies'] == []

# Generated at 2022-06-25 05:56:58.869209
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m_data = {}
    m_data['dependencies'] = ['rococoa.postgresql', 'foggycam.python']

    role_metadata = RoleMetadata(owner='owner')
    role_metadata.load(m_data, owner='owner')

    assert role_metadata.get_owner() == 'owner'
    assert role_metadata.get_dependencies() == ['rococoa.postgresql', 'foggycam.python']



# Generated at 2022-06-25 05:57:14.735063
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected_result_0 = dict(
        allow_duplicates=False,
        dependencies=list()
    )
    result_0 = role_metadata_0.serialize()
    assert result_0 == expected_result_0, "{} != {}".format(result_0, expected_result_0)


# Generated at 2022-06-25 05:57:24.350038
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # test_case_0: object created using default option
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0,RoleMetadata)

    # test_case_1: object created using a dictionary that is a common data structure for a role file

# Generated at 2022-06-25 05:57:26.038613
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    # test case 0
    test_case_0()

# call test function
test_RoleMetadata()

# Generated at 2022-06-25 05:57:30.356951
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # data = None
    # owner = None
    # variable_manager = None
    # loader = None
    # result = m.load(data, owner, variable_manager, loader)
    pass


# Generated at 2022-06-25 05:57:36.914634
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()

# Generated at 2022-06-25 05:57:40.758371
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    ret = role_metadata_0.serialize()
    assert isinstance(ret, dict)
    assert ret == {u'allow_duplicates': False, u'dependencies': []}


# Generated at 2022-06-25 05:57:44.226015
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    test_data = dict(allow_duplicates=False, dependencies=[])
    role_metadata.load(test_data, None)
    assert role_metadata.deserialize(test_data) == test_data

# Generated at 2022-06-25 05:57:46.936277
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r1 = RoleMetadata()
    d1 = {"dependencies": []}
    r1.deserialize(d1)

    assert r1.allow_duplicates is False
    assert not r1.dependencies


# Generated at 2022-06-25 05:57:51.312890
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(role_metadata.serialize())


# Generated at 2022-06-25 05:57:54.040874
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    # The data should come from the result of a serialize
    data = {
        'allow_duplicates': '', 
        'dependencies': '', 
    }
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 05:58:08.409178
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0._dependencies.append(RoleRequirement())
    role_metadata_0.deserialize({'allow_duplicates': True})
    assert role_metadata_0.serialize() == {'dependencies': [{'collections': [], 'allow_duplicates': False, 'role': None, 'name': None, 'src': None, 'path': None, 'scm': None, 'version': None}], 'allow_duplicates': True}

# Generated at 2022-06-25 05:58:11.113396
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    _data1 = dict(
                allow_duplicates=False,
                dependencies=[]
    )
    role_metadata_0.deserialize(_data1)
    assert role_metadata_0._dependencies == list()
    assert role_metadata_0._allow_duplicates == False

# Generated at 2022-06-25 05:58:16.045867
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 05:58:22.573345
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_serialize = role_metadata_0.serialize()
    assert role_metadata_serialize == {'allow_duplicates': False, 'dependencies': []}
    print("Test RoleMetadata serialize() has worked well.")


# Generated at 2022-06-25 05:58:26.457752
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1._dependencies is not None
    assert role_metadata_1._allow_duplicates is False
    assert role_metadata_1._owner is None


# Generated at 2022-06-25 05:58:30.884730
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print(RoleMetadata().load_data({"allow_duplicates": False, "dependencies": []}))
    print(RoleMetadata()._load_dependencies({"allow_duplicates": False, "dependencies": []}, []))
    print(RoleMetadata()._load_galaxy_info({"allow_duplicates": False, "dependencies": []}, []))
    print(RoleMetadata().serialize())
    print(RoleMetadata().deserialize({"allow_duplicates": False, "dependencies": []}))


# Generated at 2022-06-25 05:58:35.166682
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    result = role_metadata.serialize()
    assert result == {'allow_duplicates': False,
                      'dependencies': []}


# Generated at 2022-06-25 05:58:41.219848
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1_serialized = role_metadata_1.serialize()
    assert role_metadata_1_serialized['allow_duplicates'] == False
    assert role_metadata_1_serialized['dependencies'] == []


# Generated at 2022-06-25 05:58:43.620586
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        test_case_0()
    except:
        raise AssertionError("Testcase failed. Constructor didn't work")


# Generated at 2022-06-25 05:58:46.104933
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-25 05:58:59.766430
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.load() is None

# Generated at 2022-06-25 05:59:06.528005
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    data_1 = dict(dependencies=dict(), allow_duplicates=bool())
    owner_1 = ''
    variable_manager_1 = ''
    loader_1 = ''
    role_metadata_1.load(data=data_1, owner=owner_1, variable_manager=variable_manager_1, loader=loader_1)


# Generated at 2022-06-25 05:59:09.109871
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialized_result = role_metadata_0.serialize()
    # Test assertions here


# Generated at 2022-06-25 05:59:10.784688
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    result = role_metadata_0.serialize()
    assert result is None


# Generated at 2022-06-25 05:59:14.409567
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        print("\nSTART test_RoleMetadata")
        test_case_0()
        print("\nEND test_RoleMetadata")
    except Exception as e:
        print("\nERROR test_RoleMetadata: %s" % e)

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 05:59:23.430172
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    md = {}
    actual = RoleMetadata.load(data=md, owner=None)
    assert isinstance(actual, RoleMetadata)
    assert actual.galaxy_info is None

    md = {'galaxy_info': {'author': 'foo', 'description': 'not bar'}}
    actual = RoleMetadata.load(data=md, owner=None)
    assert isinstance(actual, RoleMetadata)
    assert actual.galaxy_info.author == 'foo'
    assert actual.galaxy_info.description == 'not bar'

    # Test that non-string values for 'description' are converted to string
    md = {'galaxy_info': {'description': ['Foo', 'Bar']}}
    actual = RoleMetadata.load(data=md, owner=None)

# Generated at 2022-06-25 05:59:25.409566
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert test_case_0() == None

# Generated at 2022-06-25 05:59:31.539177
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Constructing an instance of class RoleMetadata")
    try:
        test_case_0()
        print("Constructor call is successful")
    except Exception as e:
        print(e)
        print("Failed to instantiate class RoleMetadata")

# Invoking this module as a script will run the unit tests
if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 05:59:36.394822
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata_serialize = role_metadata.serialize()



# Generated at 2022-06-25 05:59:48.323129
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata1 = RoleMetadata()
    serialized_obj1 = metadata1.serialize()
    serialized_obj1 = sorted(serialized_obj1.items())
    print(serialized_obj1)
    role_metadata_0 = RoleMetadata()
    role_metadata_0._owner = 'role_name'
    role_metadata_0._allow_duplicates = 'False'
    role_metadata_0._dependencies = 'dependencies'
    serialized_obj2 = role_metadata_0.serialize()
    serialized_obj2 = sorted(serialized_obj2.items())
    print(serialized_obj2)
    if serialized_obj1 == serialized_obj2:
        return True
    else:
        return False

if __name__ == '__main__':
    test_case_

# Generated at 2022-06-25 06:00:15.007366
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    metadata = {'allow_duplicates': 'yes'}
    assert role_metadata_0.load(metadata)
    assert role_metadata_0.allow_duplicates

# Generated at 2022-06-25 06:00:20.897446
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = dict(
        allow_duplicates = False,
        dependencies = "os.linux",
    )
    role_metadata = RoleMetadata.load(role, variable_manager=None, loader=None)
    assert role_metadata == {}

# Generated at 2022-06-25 06:00:29.668365
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata.load({'dependencies': [{'role': 'geerlingguy.composer'}]}, owner=None)
    assert role_metadata_1._dependencies[0].role == 'geerlingguy.composer'
    #dependencies {u'role': u'geerlingguy.composer'}
    role_metadata_2 = RoleMetadata.load({'dependencies': ['geerlingguy.composer']}, owner=None)
    assert role_metadata_2._dependencies[0].role == 'geerlingguy.composer'
    #dependencies u'geerlingguy.composer'

# Generated at 2022-06-25 06:00:34.234354
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected_dict = dict(allow_duplicates=False, dependencies=[])
    actual_dict = role_metadata_0.serialize()
    assert expected_dict == actual_dict


# Generated at 2022-06-25 06:00:41.134104
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    data = '{"name": "ansible.builtin", "version": "1.0.0", "collections": ["ansible"], "namespace": "ansible", "dependencies": [{"src": "https://github.com/ansible/ansible-test", "name": "ansible-test", "version_requirement": ">=0.0.0"}]}'
    role_metadata_1 = role_metadata_0.load(data,'owner')
    assert role_metadata_1 is not None


# Generated at 2022-06-25 06:00:43.515333
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()



# Generated at 2022-06-25 06:00:45.020181
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# unit test for load function

# Generated at 2022-06-25 06:00:53.855496
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    data_1 = dict()
    owner_1 = RoleRequirement()
    owner_1._role_name = 'test_name'
    assert 'role_name' in dir(owner_1)
    assert 'role_name' in dir(owner_1)
    assert hasattr(owner_1, 'role_name')
    assert isinstance(owner_1.role_name, (str,))
    assert owner_1.role_name == 'test_name'
    assert 'role_path' not in dir(owner_1)
    assert not hasattr(owner_1, 'role_path')

    assert '_owner' not in dir(role_metadata_1)
    assert not hasattr(role_metadata_1, '_owner')
    role_metadata_1 = RoleMet

# Generated at 2022-06-25 06:00:58.221323
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialized = role_metadata_0.serialize()
    assert isinstance(serialized, dict)
    assert 'allow_duplicates' in serialized
    assert 'dependencies' in serialized


# Generated at 2022-06-25 06:01:02.510339
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_loaded = role_metadata_0.load({"dependencies": [{'role': 'my_role'}]}, owner=None)
    assert isinstance(role_metadata_loaded, RoleMetadata)

# Generated at 2022-06-25 06:02:05.688262
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Setup a test case that does not have the deps set
    r0 = RoleMetadata()

    s0 = r0.serialize()

    assert s0.get('dependencies', []) == []

    # Setup a test case that have the deps set
    r1 = RoleMetadata()
    r1._dependencies = ['abc', 'def']

    s1 = r1.serialize()
    assert set(s1.get('dependencies', [])) == set(['abc', 'def'])

    # Setup a test case that have the deps set
    r2 = RoleMetadata()
    r2._dependencies = []

    s2 = r2.serialize()
    assert s2.get('dependencies', []) == []

# Generated at 2022-06-25 06:02:15.484454
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = role_metadata_0.load({'galaxy_info': {'author': '', 'description': '', 'platforms': [{'name': '', 'versions': []}], 'issued': '', 'license': '', 'min_ansible_version': '', 'name': '', 'path': '', 'project_url': '', 'role_name': '', 'src': '', 'status': '', 'version': ''}, 'allow_duplicates': False, 'dependencies': []})
    assert role_metadata_1 is not None


# Generated at 2022-06-25 06:02:23.124551
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    fake_dependencies = 'fake dependencies'
    fake_allow_duplicates = 'fake allow duplicates'

    role_metadata = RoleMetadata()
    setattr(role_metadata, '_dependencies', fake_dependencies)
    setattr(role_metadata, '_allow_duplicates', fake_allow_duplicates)

    actual_serialize = role_metadata.serialize()
    expected_serialize = dict(
        allow_duplicates=fake_allow_duplicates,
        dependencies=fake_dependencies
    )

    if actual_serialize != expected_serialize:
        raise AssertionError('Expected serialize to return {}, but returned {}'.format(expected_serialize, actual_serialize))

# Generated at 2022-06-25 06:02:32.992019
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create root
    root = RoleMetadata()
    # Create RoleMetadata attributes
    root.allow_duplicates = True
    # Create RoleRequirement
    role_requirements = []
    role_requirement = RoleRequirement()
    role_requirement.name = "geerlingguy.jenkins"
    role_requirements.append(role_requirement)
    role_requirement = RoleRequirement()
    role_requirement.name = "geerlingguy.java"
    role_requirements.append(role_requirement)
    root.dependencies = role_requirements
    # Create serialized data
    result = root.serialize()
    assert(result['allow_duplicates'] == True)
    assert(len(result['dependencies']) == 2)

# Generated at 2022-06-25 06:02:36.086017
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1._allow_duplicates == False
    assert role_metadata_1._dependencies == []



# Generated at 2022-06-25 06:02:41.150648
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load({"dependencies": ["foo"], "allow_duplicates": False}, 'foo')

# Generated at 2022-06-25 06:02:46.499107
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )

# Test the class RoleMetadata

# Generated at 2022-06-25 06:02:50.554180
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data={'allow_duplicates': False, 'dependencies': []})
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []


# Generated at 2022-06-25 06:02:56.631328
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(dict(allow_duplicates=False, dependencies=[]))
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 06:02:58.690374
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.deserialize({'dependencies': [], 'allow_duplicates': False}) is None


# Generated at 2022-06-25 06:03:59.718443
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(dict(allow_duplicates=False,dependencies=[]))
    role_metadata_0.allow_duplicates = True
    role_metadata_0.dependencies = [ RoleRequirement.load(dict(role='test_role',scenario='test_scenario'), loader=None) ]
    assert role_metadata_0.serialize() == dict(allow_duplicates=True,dependencies=[RoleRequirement.load(dict(role='test_role',scenario='test_scenario'), loader=None)])


# Generated at 2022-06-25 06:04:01.014423
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()
    assert role_metadata_0 is not role_metadata_1

# Generated at 2022-06-25 06:04:03.291345
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert True

# Generated at 2022-06-25 06:04:06.966835
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    if not (isinstance(role_metadata_0, RoleMetadata)):
        raise AssertionError()


# Generated at 2022-06-25 06:04:10.570295
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    # The call to serialize() returns a dictionary
    serialized_dict = role_metadata.serialize()
    assert isinstance(serialized_dict, dict)
    assert serialized_dict['allow_duplicates'] is True


# Generated at 2022-06-25 06:04:16.882060
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    assert not role_metadata.load(data=None, owner=None, variable_manager=None, loader=None)
    assert not role_metadata.load(data='{}', owner=None, variable_manager=None, loader=None)

    assert not role_metadata.load(data=RoleMetadata(), owner=None, variable_manager=None, loader=None)
    assert not role_metadata.load(data=RoleMetadata, owner=None, variable_manager=None, loader=None)

# Generated at 2022-06-25 06:04:21.017013
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_data = {'dependencies': [{'role': 'geerlingguy.nodejs'}, {'role': 'geerlingguy.npm'}]}
    role_metadata_0.load(role_data, None)


# Generated at 2022-06-25 06:04:22.667511
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert(isinstance(role_metadata, RoleMetadata))


# Generated at 2022-06-25 06:04:31.745768
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_name = "test_RoleMetadata_load"
    print("**** In %s *****" % test_name)
    test_data = dict({
        'dependencies': [
            dict({
                'name': 'database',
                'src': 'git+https://github.com/geerlingguy/ansible-role-postgresql',
                'scm': 'git',
            }),
            dict({
                'name': 'foo',
                'scm': 'git',
            })
        ],
        'allow_duplicates': True,
    })
    role_metadata_1 = RoleMetadata()
    result = role_metadata_1.load(test_data, None)
    assert result is not None

# Generated at 2022-06-25 06:04:36.104969
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()