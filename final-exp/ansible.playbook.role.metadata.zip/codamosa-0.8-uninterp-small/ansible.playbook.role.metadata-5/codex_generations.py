

# Generated at 2022-06-25 05:55:19.407317
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0 is not None


# Generated at 2022-06-25 05:55:24.506851
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    data_0 = b'\xdb\xc9\x08'
    owner_0 = role_metadata_0._owner
    variable_manager_0 = role_metadata_0._variable_manager
    loader_0 = role_metadata_0._loader
    int_0 = RoleMetadata.load(data_0, owner_0, variable_manager_0, loader_0)
    assert int_0 == b'\xdb\xc9\x08'


# Generated at 2022-06-25 05:55:27.098569
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    dict_0 = dict()
    dict_0['allow_duplicates'] = False
    dict_0['dependencies'] = []
    serialized = role_metadata_0.serialize(dict_0)
    assert serialized == dict_0


# Generated at 2022-06-25 05:55:29.257652
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("test_RoleMetadata() Running...")

    test_case_0()
    print("test_RoleMetadata() Finished successfully")


# Test RoleMetadata class
if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 05:55:39.173937
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    #
    # First: test RoleMetadata initialization
    #
    role_metadata = RoleMetadata()
    isinstance(role_metadata, RoleMetadata)
    isinstance(role_metadata, CollectionSearch)
    isinstance(role_metadata, Base)

    #
    # Now: test RoleMetadata loading
    #
    role_metadata_0 = RoleMetadata()
    role_args_0 = {'allow_duplicates': False, 'dependencies': []}

    role_metadata_1 = RoleMetadata()
    role_args_1 = {'dependencies': []}

    data = {'allow_duplicates': False,
            'dependencies': []}

    role_metadata = RoleMetadata()
    role_metadata = RoleMetadata().load(data, owner=None)

    # Now: Test a role that

# Generated at 2022-06-25 05:55:42.743693
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize(dict(allow_duplicates=True, dependencies=list()))
    data = role_metadata_1.serialize()
    assert data.get('allow_duplicates') is True
    assert data.get('dependencies') == list()

# Generated at 2022-06-25 05:55:44.310386
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_case_0()

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-25 05:55:45.605471
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    print("Testing RoleMetadata.load")
    test_case_0()


# Generated at 2022-06-25 05:55:46.928125
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()
    print("Unit test for constructor of class RoleMetadata finished.")


# Generated at 2022-06-25 05:55:47.988765
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 05:55:55.994428
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    result = role_metadata_1.load(None, None, None, None)
    assert result is None


# Generated at 2022-06-25 05:55:59.049817
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()

    # Test exception handling
    try:
        role_metadata_0.deserialize()
    except Exception as err:
        print("Exception when calling deserialize of RoleMetadata: %s\n" % str(err))


# Generated at 2022-06-25 05:56:01.650925
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()

    result = role_metadata_0.serialize()
    assert result == {"dependencies": [], "allow_duplicates": False}



# Generated at 2022-06-25 05:56:03.859030
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    result = role_metadata_1.serialize()
    assert result == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-25 05:56:05.694359
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {}


# Generated at 2022-06-25 05:56:10.036923
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialize_0 = role_metadata_0.serialize()
    assert serialize_0 == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 05:56:10.979974
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # not implemented yet
    return True


# Generated at 2022-06-25 05:56:12.960645
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {}
    role_metadata.deserialize(data)


# Generated at 2022-06-25 05:56:13.913196
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:56:18.392668
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        if not hasattr(RoleMetadata, '_serializable_attributes'):
            setattr(RoleMetadata, '_serializable_attributes', tuple())
    except AttributeError:
        print("Failed to add _serializable_attributes to class RoleMetadata.")
    test_case_0()

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 05:56:26.187058
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(None)


# Generated at 2022-06-25 05:56:27.568243
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    role_metadata_1 = RoleMetadata()

    assert role_metadata_1.load({'author': 'Dummy'}) is not None

# Generated at 2022-06-25 05:56:30.070367
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass


# Generated at 2022-06-25 05:56:34.437848
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    data = {"dependencies": [{"role": "common", "name": None}]}
    owner = "Ansible"
    variable_manager = "Ansible"
    loader = "Ansible"
    role_metadata.load(data,owner,variable_manager,loader)

# Generated at 2022-06-25 05:56:35.793069
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False})

# Generated at 2022-06-25 05:56:46.467587
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    # Declare a valid data structure to test class RoleMetadata
    ds = dict(
        allow_duplicates=True,
        dependencies=['name: test0']
    )

    # Declare a not valid data structure to test class RoleMetadata
    ds_invalid = dict(
        allow_duplicates=True,
        dependencies='name: test0'
    )

    # Check if we can load RoleMetadata with a valid data structure
    role_metadata_valid = RoleMetadata.load(ds, 'owner', 'variable_manager', 'loader')

    # Check if the loader raises the correct error when it sees an invalid data structure

# Generated at 2022-06-25 05:56:53.268066
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1 is not None
    assert isinstance(role_metadata_1, RoleMetadata)
    assert role_metadata_1._allow_duplicates == False
    assert role_metadata_1._dependencies == []
    assert role_metadata_1._galaxy_info == {}
    assert role_metadata_1._argument_specs == []


# Generated at 2022-06-25 05:56:54.430085
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        role_metadata = RoleMetadata()
    except Exception as e:
        print('FAILURE: ' + str(e))

# Generated at 2022-06-25 05:56:57.485788
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}, "Test failed."


# Generated at 2022-06-25 05:57:06.952508
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_data = {
        'allow_duplicates': True,
        'dependencies': [
            'testRole1',
            'testRole2',
            {'role': 'testRole3', 'vars': {'var1': 'val1'}},
            {'role': 'testRole4'},
            {'name': 'testRole5', 'vars': {'var2': 'val2'}},
            {'name': 'testRole6'},
        ],
    }


    role_metadata_load = RoleMetadata(owner=None)
    role_metadata_load.load(data=role_data, owner=None)
    pass



# Generated at 2022-06-25 05:57:13.671240
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = { 'allow_duplicates': False, 'dependencies': [] }
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 05:57:17.943462
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates" : "True", "dependencies" : "depe_1, depe_2"})
    assert role_metadata.allow_duplicates == "True"
    assert role_metadata.dependencies == "depe_1, depe_2"


# Generated at 2022-06-25 05:57:24.744273
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {
        'allow_duplicates': False,
        'dependencies': [
            {
                'role': 'role-0',
                'name': 'role-0'
            }, {
                'role': 'role-1',
                'name': 'role-1'
            }
        ]
    }
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 05:57:30.214182
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Arrange
    # Create a dictionary to pass to the load function
    data = {}
    # Create a mock of class Role
    owner = type('', (object,), {'get_name': lambda x: 'my_role'})()

    try:
        # Act
        RoleMetadata.load(data, owner)
    except AnsibleParserError as ape:
        # Assert
        assert ape.message == 'the \'meta/main.yml\' for role my_role is not a dictionary'

if __name__ == '__main__':
    test_case_0()
    test_RoleMetadata_load()

# Generated at 2022-06-25 05:57:33.236194
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata() # instantiate a test object
    role_metadata_1._owner = None
    data_1 = dict(allow_duplicates=dict(), dependencies=dict())
    variable_manager_1 = dict()
    loader_1 = dict()
    result = role_metadata_1.load(data_1, role_metadata_1._owner, variable_manager_1, loader_1) # call method load
    assert result # mock success

# Generated at 2022-06-25 05:57:37.913139
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test with a simple valid entry
    role_metadata_0 = RoleMetadata.load(dict(
        dependencies=dict(
            role1=dict(
                role='role1',
                src='/path/to/role1',
                version=1.0
            )
        )
    ), owner='owner')

    assert len(role_metadata_0._dependencies) == 1

    # Test with a simple invalid entry
    role_metadata_1 = RoleMetadata.load(dict(
        dependencies=dict(
            role1=dict(
                role='role1'
            )
        )
    ), owner='owner')

    assert len(role_metadata_1._dependencies) == 0

# Generated at 2022-06-25 05:57:41.536071
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = dict()
    try:
        role_metadata_0.deserialize(data)
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 05:57:43.018926
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0 is not None

# Generated at 2022-06-25 05:57:45.380877
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load(data=dict(), owner=object(), variable_manager=object(), loader=object())

# Generated at 2022-06-25 05:57:46.892319
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata(owner=None)
    assert role_metadata_1 is not None

if __name__ == "__main__":
    test_case_0()
    test_RoleMetadata()

# Generated at 2022-06-25 05:57:55.799073
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({"allow_duplicates": True, "dependencies": [{"name": "test", "src": "test"}]})


# Generated at 2022-06-25 05:57:57.655361
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialize_func = role_metadata_0.serialize()
    print("Serialize func::", serialize_func)


# Generated at 2022-06-25 05:58:00.360313
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.serialize()
    data = dict(allow_duplicates = 'true', dependencies = [dict(name = 'ansible.posix', src = 'https://github.com/ansible-collections/ansible_collections_core,origin/master')])
    role_metadata.deserialize(data)
    role_metadata.serialize()


# Generated at 2022-06-25 05:58:06.400541
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    result = role_metadata.serialize()

    assert result == {'allow_duplicates':False, 'dependencies':[]}

# Generated at 2022-06-25 05:58:09.638801
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar']
    )
    role_metadata_1.deserialize(data)
    assert role_metadata_1.allow_duplicates
    assert role_metadata_1.dependencies == data.get('dependencies')


# Generated at 2022-06-25 05:58:12.181823
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    deps = ['common', {'role': 'nginx', 'tags': ['httpd']}]
    galaxy_info = 'author: redhat'
    data = {'dependencies': deps, 'galaxy_info': galaxy_info}
    serialized = data
    assert RoleMetadata.load(data, None).serialize() == serialized



# Generated at 2022-06-25 05:58:15.372741
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(None)


# Generated at 2022-06-25 05:58:18.565206
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata is not None
    assert RoleMetadata._load_dependencies is not None
    assert RoleMetadata._load_galaxy_info is not None
    assert RoleMetadata._allow_duplicates is not None
    assert RoleMetadata._dependencies is not None
    assert RoleMetadata._galaxy_info is not None
    assert RoleMetadata._argument_specs is not None

# Generated at 2022-06-25 05:58:27.894816
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    fake_data = {
        'dependencies': [
            {
                'role': 'common',
                'some_integers': [1, 2, 3, 4],
                'some_strings': ['one', 'two', 'three', 'four'],
            },
        ]
    }
    fake_owner = MockRole()
    fake_variable_manager = MockVariableManager()
    fake_loader = MockLoader()
    role_metadata = RoleMetadata.load(fake_data, fake_owner, variable_manager=fake_variable_manager, loader=fake_loader)
    assert isinstance(role_metadata, RoleMetadata)
    assert role_metadata._owner is fake_owner
    assert role_metadata._variable_manager is fake_variable_manager
    assert role_metadata._loader is fake_loader
    assert role_metadata._dependencies

# Generated at 2022-06-25 05:58:35.017936
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()

# Generated at 2022-06-25 05:58:42.924157
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-25 05:58:45.250135
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data={})
    assert role_metadata_0 is not None


# Generated at 2022-06-25 05:58:49.165991
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    owner = "test"
    variable_manager = None
    loader = None
    data = {"dependencies": 'roles'}

    with pytest.raises(AnsibleParserError) as excinfo:
        role_metadata.load(data, owner, variable_manager, loader)
    excinfo.match("'meta/main.yml' for role test is not a dictionary")


# Generated at 2022-06-25 05:58:58.564575
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    #
    # Set up test infrastructure.
    #
    role_metadata_0 = RoleMetadata()
    #
    # Set up test data.
    #
    data = {
        'allow_duplicates': False,
        'dependencies': [], 
    }
    #
    # Un-serialize the data.
    #
    role_metadata_0.deserialize(data)
    #
    # Serialize the data.
    #
    serialized_data = role_metadata_0.serialize()
    #
    # Verify the results.
    #
    assert serialized_data == data

# Generated at 2022-06-25 05:58:59.805272
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-25 05:59:03.653121
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(allow_duplicates=False, dependencies=[])
    role_metadata.deserialize(data)


# Generated at 2022-06-25 05:59:04.861636
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
	print(RoleMetadata())


# Generated at 2022-06-25 05:59:06.728849
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})


# Generated at 2022-06-25 05:59:12.741172
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    src = {
        "allow_duplicates": "true",
        "dependencies": [
            {"role": "rolename", "vars": "hello", "ignore_errors": "true"},
            {"role": "another", "vars": "goodbye"}
        ]
    }
    role_metadata = RoleMetadata()
    role_metadata.load_data(src)
    serialized = role_metadata.serialize()
    assert isinstance(serialized, dict)
    assert serialized.get('allow_duplicates') is not None
    assert serialized.get('dependencies') is not None


# Generated at 2022-06-25 05:59:14.663095
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    result = RoleMetadata()
    assert result is not None

# Generated at 2022-06-25 05:59:33.147181
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()

    test_data = {
        'allow_duplicates': False,
        'dependencies': [
            {'name': 'apache'},
            {'name': 'test1'},
            {'name': 'test2'}
        ]
    }
    role_metadata.load(test_data)



# Generated at 2022-06-25 05:59:34.480963
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # test load
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0, RoleMetadata)


# Generated at 2022-06-25 05:59:38.692123
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0._load_data(dict(allow_duplicates=False, dependencies=list()))

    serialized_metadata = role_metadata_0.serialize()
    assert serialized_metadata['allow_duplicates'] is False
    assert serialized_metadata['dependencies'] == list()



# Generated at 2022-06-25 05:59:43.132649
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    data_0 = {'dependencies': ['list', 'of', 'roles'], 'allow_duplicates': False, 'galaxy_info': {}}
    try:
        role_metadata_1 = RoleMetadata.load(data_0, owner=None)
    except AnsibleError as e:
        print("exception: " + to_native(e))

    try:
        role_metadata_2 = RoleMetadata.load(data_0, owner=role_metadata_1, variable_manager=None)
    except AnsibleError as e:
        print("exception: " + to_native(e))

# Generated at 2022-06-25 05:59:48.321706
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0._allow_duplicates == False
    assert role_metadata_0._dependencies == []
    assert isinstance(role_metadata_0._galaxy_info, type(None))
    assert role_metadata_0._argument_specs == {}
    assert role_metadata_0._owner == None


# Generated at 2022-06-25 05:59:54.283045
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_case = dict(
        allow_duplicates = True,
        dependencies = dict(
            src = '/roles'
        )
    )

    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = test_case['allow_duplicates']
    role_metadata.dependencies = [ test_case['dependencies'] ]

    assert role_metadata.serialize() == { 'allow_duplicates': True, 'dependencies': [{'src': '/roles'}] }


# Generated at 2022-06-25 05:59:59.367302
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1._allow_duplicates = True
    role_metadata_1._dependencies = ['dependency1','dependency2']

    assert role_metadata_1.serialize() == {'allow_duplicates': True, 'dependencies': ['dependency1','dependency2']}


# Generated at 2022-06-25 06:00:07.864719
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0._dependencies == [], "class RoleMetadata: constructor: test case #0 failed"
    assert role_metadata_0._galaxy_info == None, "class RoleMetadata: constructor: test case #1 failed"
    assert role_metadata_0._allow_duplicates == False, "class RoleMetadata: constructor: test case #2 failed"
    assert role_metadata_0._owner == None, "class RoleMetadata: constructor: test case #3 failed"


# Generated at 2022-06-25 06:00:16.168311
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import json
    from ansible.utils.path import unfrackpath
    from ansible.parsing.utils.yaml import from_yaml
    from ansible.parsing.vault import VaultLib
    from ansible.utils.display import Display
    from ansible.utils.vars import merge_hash

    # load data via Vault or from file
    # data_file = os.path.realpath(os.path.join(os.path.dirname(__file__), '../data/role_meta_0.json'))
    data_file = os.path.realpath(os.path.join(os.path.dirname(__file__), '../data/role_meta_0.json.vault'))

# Generated at 2022-06-25 06:00:19.404857
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()
    print('success')

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 06:00:46.117592
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Test execution
    # test_case_0
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(dict(
        allow_duplicates=True,
        dependencies=[]
    ))
    assert role_metadata_0.allow_duplicates is True
    assert role_metadata_0.dependencies == []



# Generated at 2022-06-25 06:00:47.694316
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))

# Generated at 2022-06-25 06:00:51.414275
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[],
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

# Generated at 2022-06-25 06:00:57.755814
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    data_1 = dict(dependencies=dict())
    owner_1 = None
    variable_manager_1 = None
    loader_1 = None
    try:
        role_metadata_1.load(data_1, owner_1, variable_manager_1, loader_1)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:01:01.831400
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == []


# Generated at 2022-06-25 06:01:07.206901
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    data = {
        'dependencies': [
            "role1",
            "role2",
        ],
    }
    role_metadata.load_data(data)
    assert role_metadata.dependencies == ['role1', 'role2']

# Generated at 2022-06-25 06:01:11.066390
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    actual = role_metadata_0.serialize()
    assert type(actual) is dict
    expected = {'allow_duplicates': False, 'dependencies': []}
    assert actual == expected


# Generated at 2022-06-25 06:01:13.407005
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    setattr(role_metadata, 'allow_duplicates', True)
    setattr(role_metadata, 'dependencies', [])
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': []}


# Generated at 2022-06-25 06:01:22.657441
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Arrange
    role_metadata_load = RoleMetadata()
    ds = dict(dependencies=dict(src="/home/vagrant/test_role", name="test_role"))
    # Act
    assert role_metadata_load._load_dependencies(role_metadata_load._dependencies, ds['dependencies'])
    # Assert
    assert isinstance(role_metadata_load._load_dependencies(role_metadata_load._dependencies, ds['dependencies']),
                      list)
    assert role_metadata_load._load_dependencies(role_metadata_load._dependencies, ds['dependencies'])[0]['src'] == "/home/vagrant/test_role"

# Generated at 2022-06-25 06:01:27.341240
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import ansible.playbook.role.metadata
    role_metadata_0 = ansible.playbook.role.metadata.RoleMetadata()
    assert isinstance(role_metadata_0, ansible.playbook.role.metadata.RoleMetadata)
    assert isinstance(role_metadata_0._allow_duplicates, bool)
    assert isinstance(role_metadata_0._dependencies, list)
    assert isinstance(role_metadata_0._argument_specs, dict)


# Generated at 2022-06-25 06:02:26.117784
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=None
    )
    role_metadata_0.deserialize(data)
    assert data == dict(
        allow_duplicates=False,
        dependencies=None
    )


# Generated at 2022-06-25 06:02:30.349333
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Base case, not provided with a variable manager
    meta_data = {
        'allow_duplicates': True,
        'dependencies': ['dependency1', 'dependency2']
    }
    obj = RoleMetadata.load(data=meta_data)
    assert obj.allow_duplicates == meta_data['allow_duplicates']
    assert obj.dependencies == meta_data['dependencies']

# Generated at 2022-06-25 06:02:36.810378
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata_data = dict(allow_duplicates=False, dependencies=[])
    role_metadata.deserialize(role_metadata_data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []


# Generated at 2022-06-25 06:02:42.409648
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({"allow_duplicates": False, "dependencies": []})
    assert role_metadata_0._allow_duplicates == False
    assert role_metadata_0._dependencies == []


# Generated at 2022-06-25 06:02:52.324308
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Test with data dictionary
    this_instance = RoleMetadata.load(dict(allow_duplicates=False), owner=None)
    result = this_instance.serialize()
    assert result == dict(allow_duplicates=False, dependencies=[])

    # Test with data list
    this_instance = RoleMetadata.load(list(), owner=None)
    assert this_instance.serialize() == dict(allow_duplicates=False, dependencies=[])

    # Test with data str
    this_instance = RoleMetadata.load('foo', owner=None)
    assert this_instance.serialize() == dict(allow_duplicates=False, dependencies=[])

    # Test with data int
    this_instance = RoleMetadata.load(1, owner=None)

# Generated at 2022-06-25 06:02:57.157833
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {}
    data['allow_duplicates'] = False
    data['dependencies'] = []
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 06:02:59.311570
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    try:
        a = RoleMetadata()
        a.deserialize({'foo': 'bar'})
        assert True
    except Exception as ex:
        assert False, ex



# Generated at 2022-06-25 06:03:09.543848
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    return role_metadata_0.load(ds_0, owner=play)



# Generated at 2022-06-25 06:03:13.187240
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    assert not hasattr(role_metadata_0, "allow_duplicates")
    assert not hasattr(role_metadata_0, "dependencies")
    data = dict(allow_duplicates=False, dependencies=[])
    role_metadata_0.deserialize(data)
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []


# Generated at 2022-06-25 06:03:16.242047
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata(ins_owner = "test_RoleMetadata")
#    assert role_metadata.ins_owner == "test_RoleMetadata"
#    assert role_metadata.allow_duplicates == False
#    assert role_metadata.dependencies == []