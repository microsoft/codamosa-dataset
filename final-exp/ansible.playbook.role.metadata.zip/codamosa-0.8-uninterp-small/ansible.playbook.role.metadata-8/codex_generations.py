

# Generated at 2022-06-25 05:55:18.580978
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    RoleMetadata.load(role_metadata_0)

# Generated at 2022-06-25 05:55:26.115750
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()

    # Create a role owner to pass as argument
    role_owner_0 = RoleInclude()
    role_owner_0._role_name = 'default'
    role_owner_0._role_collection = None
    role_owner_0._role_path = '/home/vagrant/.ansible/roles/default'
    role_owner_0._role_dependencies = None

    # Create a data structure which will be used when calling the load method
    # of RoleMetadata.
    dict_0 = dict()
    dict_0[u'dependencies'] = []

    # Load the role metadata
    role_metadata_0.load(dict_0, role_owner_0)
    assert isinstance(role_metadata_0, RoleMetadata)


# Generated at 2022-06-25 05:55:27.195310
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata.load({}, None)

# Generated at 2022-06-25 05:55:36.711637
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-25 05:55:41.335234
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Argument namespace set to a non-empty value
    role_metadata_1 = RoleMetadata()
    data = '''
dependencies:
'''
    owner = 'theowner'
    variable_manager = 'the variabl emanager'
    loader = 'the loader'

    result = role_metadata_1.load(data, owner, variable_manager, loader)
    assert isinstance(result, RoleMetadata)


# Generated at 2022-06-25 05:55:43.643796
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test the deprecation warning with a simple metadata
    role_metadata_1 = RoleMetadata.load({}, '')

# Generated at 2022-06-25 05:55:45.337936
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata.load(data=None, owner=None)

# Generated at 2022-06-25 05:55:47.012106
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata.load(dict(), None), RoleMetadata)


# Generated at 2022-06-25 05:55:54.857356
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    try:
        role_metadata_1.load(None, RoleMetadata)
    except AnsibleParserError:
        pass

    role_metadata_2 = RoleMetadata()
    try:
        role_metadata_2.load(10, RoleMetadata, variable_manager=None, loader=None)
    except AnsibleParserError:
        pass

    pass


# Generated at 2022-06-25 05:55:55.159502
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-25 05:56:04.924753
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test function
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)
    assert role_metadata_0.allow_duplicates == False


# Generated at 2022-06-25 05:56:12.452938
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()

    role_metadata_2 = RoleMetadata()

    assert role_metadata_1._dependencies == role_metadata_2._dependencies
    assert role_metadata_1._allow_duplicates == role_metadata_2._allow_duplicates
    assert role_metadata_1._galaxy_info == role_metadata_2._galaxy_info

# Unit test of loading data

# Generated at 2022-06-25 05:56:23.417649
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    # input arguments

# Generated at 2022-06-25 05:56:32.067908
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {'dependencies': []}
    data1 = None
    setattr(role_metadata_0, 'allow_duplicates', data.get('allow_duplicates', False))
    setattr(role_metadata_0, 'dependencies', data.get('dependencies', []))
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []


# Generated at 2022-06-25 05:56:35.283510
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 05:56:46.305050
# Unit test for method serialize of class RoleMetadata

# Generated at 2022-06-25 05:56:54.560624
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'dependencies': [{'role': 'role1', 'src': 'src1'}, {'role': 'role2', 'version': 'version2'}], 'allow_duplicates': True})
    assert role_metadata_1._dependencies == [{'role': 'role1', 'src': 'src1'}, {'role': 'role2', 'version': 'version2'}]
    assert role_metadata_1._allow_duplicates == True


# Generated at 2022-06-25 05:56:58.841092
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {"allow_duplicates": False, "dependencies": []}


# Generated at 2022-06-25 05:57:01.650148
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    input_data = {"allow_duplicates": True}
    # Testing method load of class RoleMetadata with arguments: input_data
    # Input data: {"allow_duplicates": True}
    # Expected result: None
    assert role_metadata_0._load_allow_duplicates(attr = "allow_duplicates", ds = input_data) == None # True or False


# Generated at 2022-06-25 05:57:02.646699
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

# Generated at 2022-06-25 05:57:20.523904
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Definition of dictionary ds
    ds = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_obj = RoleMetadata()
    role_metadata_obj.deserialize(ds)
    # Test whether serialize method will return correct value
    assert role_metadata_obj.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-25 05:57:22.264228
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # make sure no test case has been left behind from previous invocation
    assert False, "Unit test for method 'deserialize' not implemented"


# Generated at 2022-06-25 05:57:27.524287
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0._deserialize_metaparameter = _deserialize_metaparameter_0_default
    role_metadata_0.deserialize(role_metadata_0._deserialize_metaparameter(role_metadata_0))

_deserialize_metaparameter_0_default = {'allow_duplicates': False, 'dependencies': [], 'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-25 05:57:32.080349
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    f = open("../../../test/units/parsing/yaml/RoleMetadata_0", "r")
    ds_0 = yaml.safe_load(f)
    role_metadata_0 = RoleMetadata(ds_0)
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == ['foo', 'bar', 'baz']
    assert role_metadata_0.galaxy_info == {}
    assert role_metadata_0.argument_specs == {}
    f.close()



# Generated at 2022-06-25 05:57:36.083248
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_data = {
        "allow_duplicates": True,
        "dependencies": [{"role": "foo", "bar": "baz"}, "ansible.builtin"]
    }
    role_metadata = RoleMetadata()
    role_metadata.load(test_data, owner=None)
    assert role_metadata.allow_duplicates == True
    assert len(role_metadata.dependencies) == 2
    assert isinstance(role_metadata.dependencies[1], dict)

# Generated at 2022-06-25 05:57:42.601376
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = [{'role': 'JohnDoe.foo'}, {'role': 'JohnDoe.bar'}]
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': [{'role': 'JohnDoe.foo'}, {'role': 'JohnDoe.bar'}]}


# Generated at 2022-06-25 05:57:53.399159
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Test for case where all defaults are used.
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {"allow_duplicates": False, "dependencies": []}

    # Test for case where allow_duplicates and dependencies are set to False and [], respectively.
    role_metadata_1 = RoleMetadata()
    role_metadata_1._allow_duplicates = False
    role_metadata_1._dependencies = []
    assert role_metadata_1.serialize() == {"allow_duplicates": False, "dependencies": []}

    # Test for case where all parameters are set to non-default values.
    role_metadata_2 = RoleMetadata()
    role_metadata_2._allow_duplicates = True
    role_metadata_2._dependencies = []
   

# Generated at 2022-06-25 05:57:58.079980
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test with None data
    try:
        role_metadata_2 = RoleMetadata()
        role_metadata_2.deserialize(None)
    except (AnsibleParserError, TypeError):
        pass
    else:
        assert False, "Failed to raise expected exception"



# Generated at 2022-06-25 05:58:01.664118
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(allow_duplicates=False, dependencies=['']))
    assert role_metadata
    assert isinstance(role_metadata, RoleMetadata)


# Generated at 2022-06-25 05:58:02.158721
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-25 05:58:29.872138
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == {}


# Generated at 2022-06-25 05:58:34.100154
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.to_nice_yaml()


# Generated at 2022-06-25 05:58:42.069334
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_data_0 = {
        u'allow_duplicates': False,
        u'dependencies': []
    }
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(role_metadata_data_0)
    assert role_metadata_0._allow_duplicates is False
    assert role_metadata_0._dependencies == []


# Generated at 2022-06-25 05:58:47.268623
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata.load({'dependencies': [{'role': 'geerlingguy.java', 'name': 'geerlingguy.java'}]}, owner=None)
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': [{'role': 'geerlingguy.java', 'name': 'geerlingguy.java'}]}

# Generated at 2022-06-25 05:58:48.076900
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 05:58:56.190176
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    role_metadata_0 = RoleMetadata()

    assert isinstance(role_metadata_0, RoleMetadata)
    assert isinstance(role_metadata_0._allow_duplicates, bool)
    assert isinstance(role_metadata_0._dependencies, list)
    assert isinstance(role_metadata_0._galaxy_info, object)
    assert isinstance(role_metadata_0._argument_specs, dict)
    assert isinstance(role_metadata_0._loader, object)



# Generated at 2022-06-25 05:59:01.269587
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition

    # Create a test RoleMetadata instance
    role_metadata = RoleMetadata()

    # Create a test RoleDefinition instance
    role_definition = RoleDefinition()

    # Load an empty role_definition
    role_metadata.load(role_definition)

    # Load a non-empty role_definition
    # TODO:
    # need a proper way to retrieve or mock a non-empty role_definition

# Generated at 2022-06-25 05:59:02.605530
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_obj = RoleMetadata()
    role_metadata_obj.serialize()

# Generated at 2022-06-25 05:59:05.332388
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    meta_0 = RoleMetadata()

    serialized = meta_0.serialize()

    assert serialized == { 'allow_duplicates': False,
                           'dependencies': [] }

# Generated at 2022-06-25 05:59:06.489919
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 05:59:54.811867
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    role_metadata_2 = role_metadata_1.load({'galaxy_info': {'namespace': 'test', 'author': 'test'}, 'dependencies': ['test1', 'test2']})


# Generated at 2022-06-25 05:59:58.258501
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
        assert 0, "test_case_0 failed"



# Generated at 2022-06-25 06:00:02.517973
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.load({})

# Generated at 2022-06-25 06:00:04.098441
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1 != None


# Generated at 2022-06-25 06:00:07.544794
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_dict = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    obj = RoleMetadata()
    obj.deserialize(role_metadata_dict)
    assert obj._allow_duplicates == False
    assert obj._dependencies == []


# Generated at 2022-06-25 06:00:11.975921
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(allow_duplicates=False, dependencies=[])
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 06:00:13.099530
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    assert role_metadata.load(dict(), None) == dict()

# Generated at 2022-06-25 06:00:20.962259
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    dependency_role1 = RoleRequirement()
    dependency_role1._role_name = 'nginx'
    dependency_role1._role_path = '/ansible/roles/nginx'
    dependency_role1._role_collection = 'ansible.legacy'
    dependency_role1._playbook_path = '/ansible/roles/nginx/meta/main.yml'
    dependency_role2 = RoleRequirement()
    dependency_role2._role_name = 'debian'
    dependency_role2._role_path = '/ansible/roles/debian'
    dependency_role2._role_collection = 'ansible.legacy'
    dependency_role2._playbook_path = '/ansible/roles/debian/meta/main.yml'
    dependency_role3 = RoleRequirement()
    dependency_

# Generated at 2022-06-25 06:00:23.890319
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    dict = dict()
    dict['allow_duplicates'] = 'True'
    dict['dependencies'] = list()
    role_metadata.load(dict,None)

# Generated at 2022-06-25 06:00:27.302685
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    owner = Base()
    variable_manager = Base()
    loader = Base()
    role_metadata.load(dict(),owner,variable_manager,loader)

# Generated at 2022-06-25 06:02:24.048967
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0._data == dict()
    assert role_metadata_0.task_blocks == list()
    # tests for setters
    role_metadata_0.role_blocks = "test_str_0"
    assert role_metadata_0.role_blocks == "test_str_0"
    role_metadata_0.role_paths = "test_str_1"
    assert role_metadata_0.role_paths == "test_str_1"
    role_metadata_0.role_names = "test_str_2"
    assert role_metadata_0.role_names == "test_str_2"
    role_metadata_0.roles = "test_str_3"

# Generated at 2022-06-25 06:02:28.064631
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()


# Generated at 2022-06-25 06:02:30.950361
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    dummy_data_0 = {'dependencies': [], 'allow_duplicates': False}
    role_metadata_0.deserialize(dummy_data_0)


# Generated at 2022-06-25 06:02:35.152261
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1._allow_duplicates == False


# Generated at 2022-06-25 06:02:42.974291
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data={'dependencies': [], 'allow_duplicates': False})
    assert role_metadata_0._dependencies == [], "RoleMetadata.deserialize failed"
    assert role_metadata_0._allow_duplicates is False, "RoleMetadata.deserialize failed"


# Generated at 2022-06-25 06:02:48.080947
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1
    assert role_metadata_1._allow_duplicates == False
    assert role_metadata_1._dependencies == []
    assert role_metadata_1._galaxy_info == None
    assert role_metadata_1._argument_specs == {}


# Generated at 2022-06-25 06:02:55.086443
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # tests with passing cases:
    role_metadata_1 = RoleMetadata.load(data={'allow_duplicates': True, 'dependencies': ['role1', 'role2', 'role3']}, owner='owner')
    role_metadata_2 = RoleMetadata.load(data={'allow_duplicates': False, 'dependencies': ['role1', 'role2', 'role3']}, owner='owner')
    role_metadata_3 = RoleMetadata.load(data={'allow_duplicates': False, 'dependencies': ['role1', 'role2', 'role3', {'role': 'role4'}, {'role': 'role5', 'foo': 'bar'}]}, owner='owner')

    # tests with failing cases:
    # ...

if __name__ == '__main__':

    test_case

# Generated at 2022-06-25 06:02:58.834363
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata_1.serialize() == {"allow_duplicates": False, "dependencies": []}, "test_RoleMetadata_serialize() failed"


# Generated at 2022-06-25 06:03:07.993578
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load({'allow_duplicates': False}, owner=None)
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == None
    assert role_metadata_0.galaxy_info == None

# Generated at 2022-06-25 06:03:09.974315
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata_0 = RoleMetadata()
    serialized_data = role_metadata_0.serialize()

    assert serialized_data == dict(allow_duplicates=False, dependencies=[])
