

# Generated at 2022-06-25 05:55:18.941280
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:55:26.349156
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()

# Generated at 2022-06-25 05:55:34.727317
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    roles_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test_collections/test_roles/')

    role_metadata_1 = RoleMetadata.load(dict(), owner=None)
    assert isinstance(role_metadata_1, RoleMetadata)

    role_metadata_2 = RoleMetadata.load(dict(), owner=None)
    assert isinstance(role_metadata_2, RoleMetadata)
    assert role_metadata_1 is not role_metadata_2

    try:
        role_metadata_3 = RoleMetadata.load(1, owner=None)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("AnsibleParserError not raised")


# Generated at 2022-06-25 05:55:37.862799
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({
        "allow_duplicates": False,
        "dependencies": []
    })


# Generated at 2022-06-25 05:55:40.532071
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    ds_1 = dict()
    owner_1 = dict()
    variable_manager_1 = dict()
    loader_1 = dict()
    result_1 = role_metadata_1.load(ds_1, owner_1, variable_manager_1, loader_1)


# Generated at 2022-06-25 05:55:45.225415
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    # Test the isinstance() for the below data
    data_0 = "string"
    owner_0 = RoleMetadata()
    try:
        role_metadata_0.load(data_0, owner_0)
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 05:55:51.475153
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # 1st test - minimal data with only required info
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []

    # 2nd test - full data with all entries
    data = {'allow_duplicates': True, 'dependencies': []}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)
    assert role_metadata_0.allow_duplicates == True
    assert role_metadata_0.dependencies == []



# Generated at 2022-06-25 05:55:53.581309
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.load(str(''), None, None, None) == None, 'No exception'



# Generated at 2022-06-25 05:55:56.743962
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata

# Generated at 2022-06-25 05:55:58.965448
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    try:
        role_metadata_0.serialize()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 05:56:11.650286
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

# Generated at 2022-06-25 05:56:22.706795
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    setattr(RoleMetadata, '_allow_duplicates', FieldAttribute(isa='bool', default=False))
    setattr(RoleMetadata, '_dependencies', FieldAttribute(isa='list', default=list))
    role_metadata_0 = RoleMetadata()
    setattr(role_metadata_0, '_dependencies', 'Dfg:AheS?n">W8')
    setattr(role_metadata_0, '_allow_duplicates', 'Dfg:AheS?n">W8')
    role_metadata_1 = role_metadata_0.deserialize({'dependencies': 'Dfg:AheS?n">W8', 'allow_duplicates': 'Dfg:AheS?n">W8'})

# Generated at 2022-06-25 05:56:23.770299
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
	role_metadata_load = RoleMetadata()


# Generated at 2022-06-25 05:56:32.090566
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata(owner={'_role_path': '/home/you/myproject/myrole', '_role_name': 'myrole'})
    role_metadata_1.deserialize(data={'allow_duplicates': True, 'dependencies': [{'role': 'geerlingguy.apache'}]})
    assert role_metadata_1._dependencies[0].role == 'geerlingguy.apache'


# Generated at 2022-06-25 05:56:36.220261
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.load({'dependencies': [], 'allow_duplicates': False})

# Generated at 2022-06-25 05:56:46.729321
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    fixture = {u'allow_duplicates': False, u'dependencies': []}
    # Get  the test setup variables
    # Get the test setup variables
    role_include_0 = {"role": "example", "name": "example"}
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata.load(fixture, role_metadata_0)
    role_metadata_2 = RoleMetadata()
    role_metadata_3 = RoleMetadata.load(fixture, role_metadata_2)
    # Get  the test setup variables
    # Get the test setup variables
    role_metadata_4 = RoleMetadata()
    role_metadata_5 = RoleMetadata.load(fixture, role_metadata_4)
    # Verify the value of variables
    assert role_include_0 == role_

# Generated at 2022-06-25 05:56:49.593482
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.serialize()

# Generated at 2022-06-25 05:56:52.829318
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata_0 = RoleMetadata()
    serialized_data = role_metadata_0.serialize()
    assert serialized_data == {'dependencies': [], 'allow_duplicates': False}


# Generated at 2022-06-25 05:56:54.882463
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """Unit test for method `RoleMetadata.serialize`"""
    fail_msg = "Test case `test_RoleMetadata_serialize` failed"
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0.serialize(), dict), fail_msg


# Generated at 2022-06-25 05:57:02.922385
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    metadata = """
        allow_duplicates: true

        dependencies:
            - src: https://github.com/geerlingguy/ansible-role-apache
              scm: git
              version: master
              name: geerlingguy.apache
            - geerlingguy.mysql
    """
    yaml_s = yaml.safe_load(metadata)
    role_metadata = RoleMetadata.load(yaml_s, None)
    print (role_metadata)
    print (role_metadata.allow_duplicates)
    print (role_metadata.dependencies)

if __name__ == '__main__':
    test_case_0()
    test_RoleMetadata_load()

# Generated at 2022-06-25 05:57:25.756388
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-25 05:57:30.314208
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata= RoleMetadata()
    role_metadata.load(data={'some_key':'some_value','dependencies':['role1','role2']}, owner="the_owner")


# Generated at 2022-06-25 05:57:32.827636
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        role_metadata_0 = RoleMetadata()
        print("Unit test for constructor of class RoleMetadata: success.")
    except:
        print("Unit test for constructor of class RoleMetadata: failed.")


# Generated at 2022-06-25 05:57:36.064500
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    print (role_metadata_0.allow_duplicates)
    print (role_metadata_0.dependencies)
    print (role_metadata_0.galaxy_info)
    print (role_metadata_0.argument_specs)


# Generated at 2022-06-25 05:57:40.126140
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata = RoleMetadata()
    role_metadata.serialize()    # This should not raise an exception

    # This code path is not tested
    #if ds is None and role_path:
    #    ds = self.load_from_file(role_path)

    #if ds and not isinstance(ds, dict):
    #    raise AnsibleParserError("the 'meta/main.yml' for role %s is not a dictionary" % role_path)

# Generated at 2022-06-25 05:57:42.409628
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    output_0 = role_metadata_0.serialize()



# Generated at 2022-06-25 05:57:45.214425
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()
    assert role_metadata_0.serialize() == role_metadata_1.serialize()


# Generated at 2022-06-25 05:57:45.730083
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_case_0()


# Generated at 2022-06-25 05:57:46.717086
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    print(role_metadata_0.__dict__)


# Generated at 2022-06-25 05:57:47.900626
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'allow_duplicates': False, 'dependencies': []})

# Generated at 2022-06-25 05:58:36.338276
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # RoleMetadata.load() with an empty dict should populate no fields
    try:
        role_metadata_0 = RoleMetadata.load({})
        assert role_metadata_0.allow_duplicates == False
        assert role_metadata_0.dependencies == []
    except:
        assert False

    # RoleMetadata.load() with a dict containing valid fields should populate all fields
    # TODO: Replace with a proper dict

# Generated at 2022-06-25 05:58:42.652432
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0 is not None

    data = {'allow_duplicates': True, 'dependencies': [{'collection': 'foo.bar'}]}
    role_metadata_0.deserialize(data)
    assert role_metadata_0._allow_duplicates is True
    assert role_metadata_0._dependencies is not None


# Generated at 2022-06-25 05:58:50.734838
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    setattr(role_metadata_0, 'keywords', ['h', 'f', 'd', 'c', 'k', 'v', 'j', 'z'])
    setattr(role_metadata_0, '_dependencies', ['c', 'y', 'l', 'g', 'f', 'o', 's', 'm', 'u', 't'])
    role_metadata_0.deserialize(dict(allow_duplicates=False, dependencies=['c', 'y', 'l', 'g', 'f', 'o', 's', 'm', 'u', 't']))
    assert role_metadata_0.keywords == ['h', 'f', 'd', 'c', 'k', 'v', 'j', 'z']


# Generated at 2022-06-25 05:58:56.190201
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    path = './tests/data/roles/role1/meta/main.yml'
    file = open(path, 'rb')
    data = file.read()
    file.close()
    role_metadata = RoleMetadata()
    role_metadata.load(data)


# Generated at 2022-06-25 05:58:59.722450
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0_serialize_result = role_metadata_0.serialize()
    assert(role_metadata_0_serialize_result == {"allow_duplicates": False, "dependencies": []})


# Generated at 2022-06-25 05:59:02.685677
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1._dependencies == []

# Generated at 2022-06-25 05:59:12.010247
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_deserialize_0 = RoleMetadata()
    data_role_metadata_deserialize_0 = {'dependencies': []}
    role_metadata_deserialize_0.deserialize(data_role_metadata_deserialize_0)
    assert role_metadata_deserialize_0.allow_duplicates == False, "role_metadata_deserialize_0.allow_duplicates == False"
    data_role_metadata_deserialize_1 = {'allow_duplicates': False}
    role_metadata_deserialize_0.deserialize(data_role_metadata_deserialize_1)
    assert role_metadata_deserialize_0.dependencies == [], "role_metadata_deserialize_0.dependencies == []"


# Generated at 2022-06-25 05:59:21.083465
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_obj = RoleMetadata()
    role_metadata_obj.deserialize(dict(
        allow_duplicates=True,
        dependencies=[[dict(role="newrole1", src="newroleurl1", version="1.0"), dict(name="newrole2", src="newroleurl2")]]
    ))
    serialized_data = role_metadata_obj.serialize()
    assert serialized_data == dict(allow_duplicates=True, dependencies=[[dict(name='newrole1', src='newroleurl1', version='1.0'), dict(name='newrole2', src='newroleurl2')]])

# Generated at 2022-06-25 05:59:27.237705
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader

    local_loader = DataLoader()

    role_metadata_load_0 = RoleMetadata.load({"dependencies": [{'role': 'galaxy.role,version'}, {'role': 'galaxy.role,version', 'other_vars': 'go here'}], 'galaxy_info': {'author': 'John Smith', 'description': 'Foo bar', 'company': 'ABC', 'platforms': [{'os': 'Fedora'}], 'license': 'BSD'}, 'allow_duplicates': False}, None, variable_manager=None, loader=local_loader )

# Generated at 2022-06-25 05:59:31.771198
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data=dict(allow_duplicates=False, dependencies=[]))


# Generated at 2022-06-25 06:00:27.981362
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_RoleMetadata_load_0()
    test_RoleMetadata_load_1()
    test_RoleMetadata_load_2()
    test_RoleMetadata_load_3()
    test_RoleMetadata_load_4()
    test_RoleMetadata_load_5()
    test_RoleMetadata_load_6()
    test_RoleMetadata_load_7()
    test_RoleMetadata_load_8()
    test_RoleMetadata_load_9()
    test_RoleMetadata_load_10()
    test_RoleMetadata_load_11()
    test_RoleMetadata_load_12()
    test_RoleMetadata_load_13()
    test_RoleMetadata_load_14()
    test_RoleMetadata_load_15()
    test_RoleMetadata_

# Generated at 2022-06-25 06:00:30.201925
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()

    ##
    ## Invalid args
    ##

    ##
    ## Valid args
    ##


# Generated at 2022-06-25 06:00:35.658684
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0, RoleMetadata)
    data = {"allow_duplicates": False, "dependencies": []}
    role_metadata_0.deserialize(data)
    assert role_metadata_0._allow_duplicates is False
    assert role_metadata_0._dependencies == []



# Generated at 2022-06-25 06:00:41.949376
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    role_metadata_0._load_dependencies({'dependencies': 'test'}, 'test')
    role_metadata_0._load_galaxy_info({'galaxy_info': 'test'}, 'test')
    role_metadata_0.serialize()
    role_metadata_0.deserialize({'data': 'test'})

if __name__ == "__main__":
    test_case_0()
    test_RoleMetadata()

# Generated at 2022-06-25 06:00:44.305412
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata_0 = RoleMetadata.load(dict(), role_metadata)


# Generated at 2022-06-25 06:00:45.659184
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert type(role_metadata_1) is RoleMetadata



# Generated at 2022-06-25 06:00:46.833616
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata(owner=None)
    assert role_metadata_0 is not None

# Generated at 2022-06-25 06:00:48.635182
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {}



# Generated at 2022-06-25 06:00:55.690002
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    collection_0 = '/root/ansible-2.8.0-0.2.rc3.fc29.noarch/lib/ansible/collections/nsweb/cloud'
    playbook_0 = 'role_name'
    variable_manager_0 = '/root/ansible-2.8.0-0.2.rc3.fc29.noarch/lib/ansible/vars/manager.py'
    loader_0 = '/root/ansible-2.8.0-0.2.rc3.fc29.noarch/lib/ansible/parsing/dataloader.py'
    retval_0 = role_metadata_0.load(playbook_0, collection_0, variable_manager_0, loader_0)
    assert retval_0

# Generated at 2022-06-25 06:01:01.421201
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0.deserialize(data_0)
    assert(role_metadata_0._dependencies == [])
    assert(role_metadata_0._allow_duplicates == False)


# Generated at 2022-06-25 06:02:44.080178
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    # Input parameters:
    allow_duplicates = True
    dependencies = []
    setattr(role_metadata_1, 'allow_duplicates', allow_duplicates)
    setattr(role_metadata_1, 'dependencies', dependencies)
    expectedResult = dict()
    expectedResult['compat'] = False
    expectedResult['allow_duplicates'] = True
    expectedResult['dependencies'] = []
    actualResult = role_metadata_1.serialize()
    assert expectedResult == actualResult


# Generated at 2022-06-25 06:02:46.876828
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    Test Case 0
    """
    print("\nTest Case 0\n")
    r = RoleMetadata()


# Generated at 2022-06-25 06:02:49.954788
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # FIXME: check the serialization
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 06:02:56.807085
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1._allow_duplicates = True
    role_metadata_1._dependencies = "this is a string"
    res = role_metadata_1.serialize()
    assert res == {'allow_duplicates': True, 'dependencies': None}, res


# Generated at 2022-06-25 06:02:59.381101
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected = {
        "allow_duplicates": False,
        "dependencies": []
        }
    actual = role_metadata_0.serialize()
    assert expected == actual


# Generated at 2022-06-25 06:03:07.373976
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_ds = { "some": "val", "foo": "bar", }
    my_RoleMetadata = RoleMetadata()
    my_RoleMetadata.deserialize(test_ds)
    return_val = my_RoleMetadata.serialize()

    assert return_val is not None
    assert isinstance(return_val, dict)
    assert len(return_val.keys()) == 2
    for k in test_ds.keys():
        assert k in return_val.keys()
        assert return_val[k] == test_ds[k]

# Generated at 2022-06-25 06:03:14.250876
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()

    import __main__
    __main__.ROLE_PATH = 'test'

    RoleMetadata.load({"allow_duplicates": False, "dependencies": []}, role_metadata_0)

    role_metadata_0.load_data({"allow_duplicates": False, "dependencies": []}, None, None)

    RoleMetadata.load({"allow_duplicates": False}, role_metadata_0)


# Generated at 2022-06-25 06:03:15.058343
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 06:03:23.292710
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Assert that setattr of allow_duplicates is same as data.get('allow_duplicates', False)
    start = time.time()
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'allow_duplicates': False})
    # Assert that setattr of dependencies is same as data.get('dependencies', [])
    begin = time.time()
    role_metadata_0.deserialize({'dependencies': []})
    end = time.time()
    duration = end-begin

# Generated at 2022-06-25 06:03:26.341168
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata.load({"dependencies": [{"role": "foo", "tasks_from": "bar"}]})
    assert len(role_metadata.dependencies) == 1
    # Test assertion of RoleInclude
    assert role_metadata.dependencies[0].role == "foo"
    assert role_metadata.dependencies[0].tasks_from == "bar"



# Generated at 2022-06-25 06:04:18.999537
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.load(data=None, owner=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 06:04:22.537014
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Setup

    role_metadata = RoleMetadata()
    # Exercise
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': []})
    # Verify
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == []



# Generated at 2022-06-25 06:04:23.313986
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert RoleMetadata.load() == None

# Generated at 2022-06-25 06:04:29.289566
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1
    assert isinstance(role_metadata_1, Base)
    assert isinstance(role_metadata_1, CollectionSearch)
    assert not role_metadata_1.allow_duplicates
    assert role_metadata_1.dependencies == []


# Generated at 2022-06-25 06:04:33.217566
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata, Base)
    assert isinstance(role_metadata, CollectionSearch)
    # there is no test for _owner

# Generated at 2022-06-25 06:04:37.259383
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1._allow_duplicates = True
    role_metadata_1.serialize()


# Generated at 2022-06-25 06:04:46.206899
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Constructor test for class RoleMetadata
    '''

    role_metadata = RoleMetadata()
    assert not isinstance(role_metadata, dict)
    assert isinstance(role_metadata, RoleMetadata)
    assert hasattr(role_metadata, '_allow_duplicates')
    assert hasattr(role_metadata, '_dependencies')
    assert hasattr(role_metadata, '_galaxy_info')
    assert isinstance(role_metadata._dependencies, list)
    assert role_metadata._dependencies == []
    assert isinstance(role_metadata._galaxy_info, dict)
    assert role_metadata._galaxy_info == {}
    assert isinstance(role_metadata._allow_duplicates, bool)
    assert role_metadata._allow_duplicates == False

# Generated at 2022-06-25 06:04:48.773377
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialize = role_metadata_0.serialize()
    assert serialize['allow_duplicates'] == False
    assert serialize['dependencies'] == []

test_case_0()
test_RoleMetadata_serialize()

# Generated at 2022-06-25 06:04:56.533726
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata.load(dict(), None)
    assert role_metadata_1._class_name == "RoleMetadata"
    assert role_metadata_1._owner._class_name == "Role"
    assert role_metadata_1._owner.name == ""
    assert role_metadata_1._allow_duplicates == False
    assert role_metadata_1._dependencies == []
    assert role_metadata_1._galaxy_info == None
    assert role_metadata_1._argument_specs == {}

# Generated at 2022-06-25 06:04:58.520314
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    try:
        role_metadata_deserialize = RoleMetadata()
        role_metadata_deserialize.deserialize(None)
    except Exception as e:
        print('Function deserialize threw exception %s' % e)
        return 1
