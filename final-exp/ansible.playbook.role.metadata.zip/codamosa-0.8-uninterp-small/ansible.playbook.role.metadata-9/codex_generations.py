

# Generated at 2022-06-25 05:55:17.760440
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    result = role_metadata_0.serialize()
    assert not result


# Generated at 2022-06-25 05:55:22.252997
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.allow_duplicates = False
    role_metadata_1.dependencies = ['test_dependency_1']
    assert role_metadata_1.serialize() == {'allow_duplicates': False, 'dependencies': ['test_dependency_1']}


# Generated at 2022-06-25 05:55:23.741195
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data={})
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []


# Generated at 2022-06-25 05:55:25.585613
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize(): #TODO
    #TODO
    data = {}
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

# Generated at 2022-06-25 05:55:30.022564
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    data = dict()

    role_metadata_1 = role_metadata_0.load(data)


# Generated at 2022-06-25 05:55:33.068216
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {
        'allow_duplicates': 'False',
        'dependencies': [],
    }
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == []

# Generated at 2022-06-25 05:55:42.679996
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    role_metadata_1 = RoleMetadata()

# Generated at 2022-06-25 05:55:43.499715
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    raise Exception("No test for RoleMetadata")

# Generated at 2022-06-25 05:55:45.471485
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    result_0 = role_metadata_0.serialize()
    assert result_0 == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-25 05:55:48.314723
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    ser_data = role_metadata_0.serialize()
    assert ser_data == {'allow_duplicates': False, 'dependencies': []}

#Unit test for method deserialize of class RoleMetadata

# Generated at 2022-06-25 05:56:01.982379
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    obj_0 = dict()
    role_metadata_0.deserialize(obj_0)


# Generated at 2022-06-25 05:56:03.586609
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load()


# Generated at 2022-06-25 05:56:05.562605
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    result = role_metadata.serialize()
    assert 'allow_duplicates' in result
    assert 'dependencies' in result


# Generated at 2022-06-25 05:56:16.340931
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._dependencies = [{'name': 'bob', 'src': 'https://github.com/bob/my-role.git'},
                                   {'name': 'david', 'src': 'https://github.com/david/other-role.git'}]
    role_metadata._allow_duplicates = True
    assert role_metadata.serialize() == {'dependencies':
                                             [{'name': 'bob', 'src': 'https://github.com/bob/my-role.git'},
                                              {'name': 'david', 'src': 'https://github.com/david/other-role.git'}],
                                         'allow_duplicates': True}


# Generated at 2022-06-25 05:56:18.431898
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    r = RoleMetadata()
    assert r._load_dependencies("dependencies", [{'role': 'common'}]) == [{'role': 'common'}]


# Generated at 2022-06-25 05:56:25.646797
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Retrieve metadata from a role
    '''

    role_metadata = RoleMetadata(owner=None)

    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['common']

    role_metadata_serialize = role_metadata.serialize()
    assert role_metadata_serialize == dict(allow_duplicates=True, dependencies=['common']), \
        "RoleMetadata serialize method doesn't return the expected result"


# Generated at 2022-06-25 05:56:30.285253
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata(owner = None)
    role_metadata.deserialize({'allow_duplicates' : False, 'dependencies' : []})


# Generated at 2022-06-25 05:56:34.908715
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None
    role_metadata.load_ds(dict())
    role_metadata.load(dict())
    role_metadata.serialize()
    role_metadata.deserialize()
    assert role_metadata.dependencies is not None
    assert role_metadata.allow_duplicates is not None

# Generated at 2022-06-25 05:56:43.210916
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    '''
    Test serialize method of RoleMetadata class
    '''
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [{'role': 'common'}]
    # serialize the role metadata
    serialized_role_metadata = role_metadata.serialize()
    assert serialized_role_metadata == dict(allow_duplicates=True,
                                            dependencies=[{'role': 'common'}])


# Generated at 2022-06-25 05:56:44.600072
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_case_0()
    assert True, 'Test case 0 failed'


# Generated at 2022-06-25 05:57:30.241859
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    result = role_metadata_1.serialize()
    assert result == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:57:31.310794
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata)

# Generated at 2022-06-25 05:57:32.111567
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()


# Generated at 2022-06-25 05:57:35.910669
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    role_metadata_1 = RoleMetadata()
    data_1 = dict(
        dependencies=dict(role="Alice"),
        galaxy_info=dict(description="Test description")
    )

    role_metadata_1.load(data_1)
    assert role_metadata_1._dependencies['role'] == "Alice"
    assert role_metadata_1._galaxy_info['description'] == "Test description"



# Generated at 2022-06-25 05:57:45.765497
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    print("Test: serialize")
    metadata_for_role_0 = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                role="geerlingguy.java"
            ),
            dict(
                role="geerlingguy.jenkins",
                vars=dict(
                    jenkins_plugins=[
                        dict(
                            name="greenballs"
                        ),
                        dict(
                            name="envinject"
                        )
                    ]
                )
            )
        ]
    )
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load_data(metadata_for_role_0)
    assert role_metadata_0.serialize() == metadata_for_role_0


# Generated at 2022-06-25 05:57:48.157140
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # create a empty RoleMetadata class
    role_metadata=RoleMetadata()
    # print the variabls of the class instance
    print('%s\n' % role_metadata.__dict__)
    # print the attributes of the class instance
    print('%s\n' % RoleMetadata.__dict__)


# Generated at 2022-06-25 05:57:48.901685
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize()



# Generated at 2022-06-25 05:57:50.825978
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata,RoleMetadata)

# Generated at 2022-06-25 05:57:51.754899
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert metadata is not None


# Generated at 2022-06-25 05:57:56.132277
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata, RoleMetadata)

# Generated at 2022-06-25 05:58:19.772336
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:58:27.039390
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()

    data = {
        'allow_duplicates': True,
        'dependencies': {
            'role': 'geerlingguy.drupal',
            'version': '1.0.2',
        },
    }
    role_metadata_2 = RoleMetadata.load(data, None, None, None)
#
#    assert role_metadata_2.allow_duplicates == True
#    assert role_metadata_2.dependencies[0].role == 'geerlingguy.drupal'
#    assert role_metadata_2.dependencies[0].version == '1.0.2'

# Generated at 2022-06-25 05:58:30.026494
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None


# Generated at 2022-06-25 05:58:34.463470
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'dependencies': []})


# Generated at 2022-06-25 05:58:42.147387
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.role.definition import RoleDefinition

    role_metadata_0 = RoleMetadata()

    def test_1():
        ds = {}
        role_metadata_0.load(ds, None)

    def test_2():
        ds = dict(allow_duplicates=True)
        role_metadata_0.load(ds, None)

    def test_3():
        ds = dict(dependencies=dict(role=None))
        role_metadata_0.load(ds, None)

    def test_4():
        ds = dict(dependencies='')
        role_metadata_0.load(ds, None)


# Generated at 2022-06-25 05:58:45.521308
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()

    data_0 = {'dependencies': [], 'allow_duplicates': False}

    role_metadata_0.deserialize(data_0)

# Generated at 2022-06-25 05:58:50.659616
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

    data_0 = {'allow_duplicates': False}
    role_metadata_0 = RoleMetadata.load(data_0, owner='owner_0', variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 05:58:58.486559
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    try:
        role_metadata_0 = RoleMetadata.load(self=None, data=None, owner=None)
    except TypeError as e:
        assert(str(e) == TypeError('RoleMetadata.load() takes at least 3 arguments (2 given)'))
    except AssertionError as e:
        assert(str(e) == TypeError('RoleMetadata.load() takes at least 3 arguments (2 given)'))


# Generated at 2022-06-25 05:59:02.884683
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata2 = RoleMetadata()
    actual_result = role_metadata2.serialize()
    expected_result = dict(dependencies=list(), allow_duplicates=False)
    assert actual_result == expected_result


# Generated at 2022-06-25 05:59:03.901196
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert test_case_0() == None

# Generated at 2022-06-25 05:59:38.693166
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    # serialize(self):
    ret_val = role_metadata_0.serialize()

    # dict: dict(allow_duplicates=self._allow_duplicates, dependencies=self._dependencies)
    assert isinstance(ret_val, dict)
    assert ret_val["allow_duplicates"] == False
    assert ret_val["dependencies"] == []


# Generated at 2022-06-25 05:59:41.372206
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # expected = {'allow_duplicates': False, 'dependencies': []}
    # actual = RoleMetadata().serialize()
    # assert expected == actual
    pass


# Generated at 2022-06-25 05:59:43.486997
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        test_case_0()
    except Exception as e:
        raise AnsibleParserError(to_native(e))


# Generated at 2022-06-25 05:59:52.198060
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # define valid data to be used to test
    role_metadata = RoleMetadata()
    data = dict()
    data['dependencies'] = [{}, {}]
    data['allow_duplicates'] = True
    data['foo'] = 'bar'
    data['galaxy_info'] = {'author': 'Peter', 'description': 'xyz',
                           'company': 'ABC', 'license': 'Apache',
                           'min_ansible_version': '2.0', 'platforms': [{'name': 'Debian',
                                                                       'versions': [{'name': 'trusty'}]}],
                           'role_name': 'test',
                           'issues_url': 'http://example.com',
                           'source': 'http://example.com'}

    role_metadata.load_data

# Generated at 2022-06-25 05:59:53.371972
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_load = RoleMetadata()
    assert role_metadata_load

# Generated at 2022-06-25 05:59:55.320913
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'dependencies': [], 'allow_duplicates': False}

# Generated at 2022-06-25 05:59:57.094640
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)

# Generated at 2022-06-25 05:59:58.335400
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

if __name__ == '__main__':
    test_RoleMetadata()
#
#
#
#

# Generated at 2022-06-25 06:00:09.561386
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
        # Test non-dict datastructure
    try:
        RoleMetadata.load([])
    except AnsibleParserError as e:
        assert str(e) == "the 'meta/main.yml' for role None is not a dictionary"

    # Test a proper role
    role_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test_data', 'roles', 'jdoe.example_role')
    collection_search_list = [os.path.join(role_path, '..', '..', '..', 'ansible_collections', 'jdoe', 'example_role')]
    RoleMetadata.load({}, owner=role_path, collection_search_list=collection_search_list)

    # Test old-style metavars
    RoleMet

# Generated at 2022-06-25 06:00:14.376931
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})


# Generated at 2022-06-25 06:00:44.611111
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(
        dict(
            allow_duplicates=False,
            dependencies=[]
        )
    )
    assert role_metadata_0.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )



# Generated at 2022-06-25 06:00:48.553545
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = test_case_0()

    data = role_metadata_0.serialize()

    assert isinstance(data, dict)
    keys = data.keys()
    assert 'allow_duplicates' in keys
    assert 'dependencies' in keys
    assert 'id' in keys
    assert data.get('id') == None
    assert '_ansible_parsed' in keys
    assert data.get('_ansible_parsed') == True


# Generated at 2022-06-25 06:00:50.224371
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # call test_case_0
    test_case_0()
    return

# Generated at 2022-06-25 06:00:52.017930
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    # Start of test case
    assert role_metadata_0.serialize() == dict(allow_duplicates=False, dependencies=[])
    # End of test case


# Generated at 2022-06-25 06:00:54.884647
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': True, 'dependencies': {}}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 06:01:00.424298
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Create an instance of class RoleMetadata with default values
    role_metadata_3 = RoleMetadata()
    # The data to load
    data_4 = {'dependencies': []}
    # Create an instance of class RoleMetadata with the data from data_4
    role_metadata_5 = RoleMetadata.load(data_4)

# Generated at 2022-06-25 06:01:01.421875
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert True == True


# Generated at 2022-06-25 06:01:09.018472
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    temp_path = "/test_RoleMetadata_load/test_RoleMetadata_load_data/"
    yaml_file = "main.yml"
    role_metadata_1 = role_metadata_0.load(temp_path, yaml_file)
    assert(role_metadata_1.dependencies == [])
    assert(role_metadata_1.allow_duplicates == False)


# Generated at 2022-06-25 06:01:12.328565
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Constructor of class RoleMetadata")
    test_case_0()

# Generated at 2022-06-25 06:01:15.094587
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 06:02:19.209061
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None, 'Expected role_metadata to be not None'
    assert role_metadata.dependencies is not None, 'Expected role_metadata.dependencies to be not None'
    assert len(role_metadata.dependencies) == 0, 'Expected role_metadata.dependencies to be empty'

# Generated at 2022-06-25 06:02:21.903347
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected = Code.ok

    try:
        result = role_metadata_0.serialize()
    except Exception as e:
        result = Code.fail

    assert expected == result


# Generated at 2022-06-25 06:02:28.568925
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [
                                  {'role': 'tomcat'},
                                  {'role': 'apache'},
                                  {'role': 'mysql'}
                                 ]

    assert(role_metadata.serialize() == {'allow_duplicates': True,
                                         'dependencies': [
                                                          {'role': 'tomcat'},
                                                          {'role': 'apache'},
                                                          {'role': 'mysql'}
                                                         ]
                                         })


# Generated at 2022-06-25 06:02:30.387118
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    obj = RoleMetadata(owner='owner')
    obj.load('meta', 'owner')
    pass


# Generated at 2022-06-25 06:02:34.130975
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert (role_metadata)



# Generated at 2022-06-25 06:02:36.961506
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    result = role_metadata_0.serialize()

    assert result['allow_duplicates'] == False
    assert result['dependencies'] == []


# Generated at 2022-06-25 06:02:40.913279
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0 = RoleMetadata.load(data={}, owner=None)


# Generated at 2022-06-25 06:02:49.060963
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata.__class__.__name__)
    print(role_metadata.__class__.__bases__)
    # print(role_metadata.__class__.__mro__)
    print(type(role_metadata))
    print(isinstance(role_metadata, object))

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 06:02:50.519355
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1 != None


# Generated at 2022-06-25 06:02:56.067064
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(
        dependencies=[],
        allow_duplicates=False,
        allow_list=True
    )


# Generated at 2022-06-25 06:05:06.208615
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    """
    Test if the deserialize method works correctly.
    """
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({
        'allow_duplicates': False,
        'dependencies': [
            {'role': 'foo',
             'name': 'bar',
             'src': 'baz',
             'scm': 'git',
             'version': '4.2.0'},
            {'role': 'foo',
             'name': 'bar',
             'src': 'baz',
             'scm': 'git',
             'version': '4.2.0'}
        ],
        'collections': [
            'ansible_namespace.collection_name',
            '/path/to/collection'
        ]
    })
    assert role_metadata