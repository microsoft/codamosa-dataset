

# Generated at 2022-06-25 05:55:19.619145
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.load({})


# Generated at 2022-06-25 05:55:30.825023
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-25 05:55:34.071263
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    role_metadata_1 = role_metadata_1.load('', '', '')
    assert isinstance(role_metadata_1, RoleMetadata)


# Generated at 2022-06-25 05:55:38.152621
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({ "allow_duplicates": [ { "name": "allow_duplicates", "value": False, "type": "bool" } ],
                                  "dependencies": []})

# Generated at 2022-06-25 05:55:39.583007
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.load({}, owner = '')

# Generated at 2022-06-25 05:55:42.241678
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata_dict = role_metadata.serialize()
    assert role_metadata_dict['allow_duplicates'] == False
    assert role_metadata_dict['dependencies'] == []


# Generated at 2022-06-25 05:55:44.422013
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Testing constructor for class RoleMetadata")
    test_case_0()
    print("Finished testing constructor")
test_RoleMetadata()

# Generated at 2022-06-25 05:55:46.352391
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'dependencies': [], 'allow_duplicates': False}


# Generated at 2022-06-25 05:55:47.711707
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize()


# Generated at 2022-06-25 05:55:55.968886
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # simple role
    role_metadata_1 = RoleMetadata.load(
        data=dict(
            allow_duplicates=True,
            dependencies=[
                dict(role='bob'),
                dict(role='another.role')
            ]),
        owner=None,
        variable_manager='minimal',
        loader={})
    assert role_metadata_1.get_allow_duplicates() is True
    assert len(role_metadata_1.get_dependencies()) == 2


# Generated at 2022-06-25 05:56:12.411439
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata_1.deserialize(data)
    assert role_metadata_1.allow_duplicates == False
    assert role_metadata_1.dependencies == []


# Generated at 2022-06-25 05:56:23.418307
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # Create an instance of class Play to initialize AnsibleLoader.
    test_play = Play()
    test_play._loader = test_play.loader
    test_play._variable_manager = test_play.variable_manager
    test_play._context = PlayContext()
    test_play._basedir = '/home/ubuntu/Test_Ansible_Workflow_Engine/ansible_workflow_engine'
    test_play._host_pattern = 'all'

    test_play.load()

    test_role = Role()
    test_role._role_name = 'test_role'

# Generated at 2022-06-25 05:56:31.683230
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()

    # Set allow_duplicates to True and dependencies to []
    data = {
        'allow_duplicates': True,
        'dependencies': [],
    }

    role_metadata.deserialize(data)

    # Check if deserialize set attributes correctly
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == []

# Generated at 2022-06-25 05:56:37.616136
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0._serialized_attrs = {}
    role_metadata_0._serialized_attrs['galaxy_info'] = {}
    assert isinstance(role_metadata_0.serialize(), dict)

if __name__ == '__main__':
    test_case_0()
    test_RoleMetadata_serialize()

# Generated at 2022-06-25 05:56:41.354757
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test load in class RoleMetadata
    role_metadata = RoleMetadata()

    role_metadata = RoleMetadata()
    role_metadata = role_metadata.load(data=None, owner=None, variable_manager=None, loader=None)

# Generated at 2022-06-25 05:56:47.297608
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates" : True, "dependencies": [{"src" : "example.com", "version": "1.0.0"}, "https://example.com"]})
    assert(role_metadata.allow_duplicates == True)
    assert(role_metadata.dependencies == [{"src" : "example.com", "version": "1.0.0"}, "https://example.com"])


# Generated at 2022-06-25 05:56:59.114906
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    print("Constructor")
    print("===========")

    print("\nAnsibleRoleMetadata()")
    role_metadata_0 = RoleMetadata()

    role_metadata_0.deserialize({'allow_duplicates': True, 'dependencies': ['test.test_data.test_role_metadata.test_role_0']})

    print("\n")

    print("[allow_duplicates]")
    print(role_metadata_0._allow_duplicates)
    print("[dependencies]")
    print(role_metadata_0._dependencies)
    print("[galaxy_info]")
    print(role_metadata_0._galaxy_info)
    print("[argument_specs]")
    print(role_metadata_0._argument_specs)

# Generated at 2022-06-25 05:57:00.671881
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1
    assert role_metadata_1.allow_duplicates == False
    assert role_metadata_1.dependencies == []



# Generated at 2022-06-25 05:57:02.606746
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.serialize()


# Generated at 2022-06-25 05:57:11.542010
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.allow_duplicates = True
    role_metadata_0.dependencies = ['test_case_0']

# Generated at 2022-06-25 05:57:27.977900
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()

    role_metadata_1_allow_duplicates = False
    role_metadata_1_dependencies = []
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'allow_duplicates' : role_metadata_1_allow_duplicates,'dependencies' : role_metadata_1_dependencies} )


# Generated at 2022-06-25 05:57:37.772480
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.data = dict(
        allow_duplicates=False,
        dependencies=[],
        galaxy_info=None,
        argument_specs=None
    )
    assert role_metadata_0.data == dict(
        allow_duplicates=False,
        dependencies=[],
        galaxy_info=None,
        argument_specs=None
    )
    assert role_metadata_0._allow_duplicates is False
    assert role_metadata_0._dependencies == []
    assert role_metadata_0._galaxy_info is None
    assert role_metadata_0._argument_specs is None
    #
    role_metadata_1 = RoleMetadata()

# Generated at 2022-06-25 05:57:43.812935
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    data = {'dependencies': []}
    role_metadata_1.deserialize(data)
    assert role_metadata_1.dependencies == []

    data = {'allow_duplicates': True}
    role_metadata_1.deserialize(data)
    assert role_metadata_1.allow_duplicates == True



# Generated at 2022-06-25 05:57:46.900444
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test function RoleMetadata.deserialize from module 
    assert not __name__ == '__main__'
    
    role_metadata_0 = RoleMetadata()
    data = dict()
    role_metadata_0.deserialize(data)
    

# Generated at 2022-06-25 05:57:48.106980
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0.serialize(), dict)


# Generated at 2022-06-25 05:57:48.700972
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_case_0()

# Generated at 2022-06-25 05:57:49.285632
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    raise NotImplementedError()


# Generated at 2022-06-25 05:57:52.091252
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    if not role_metadata_0.serialize():
        raise Exception("Unit test has error")
    else:
        pass


# Generated at 2022-06-25 05:57:57.352253
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.deserialize(dict()) == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:57:58.611608
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0.serialize(), dict)


# Generated at 2022-06-25 05:58:18.144756
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'dependencies': ['role1', 'role2', 'role3'], 'allow_duplicates': True}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data)
    assert role_metadata_0.allow_duplicates == True
    assert role_metadata_0.dependencies == ['role1', 'role2', 'role3']
    assert role_metadata_0._owner == None


# Generated at 2022-06-25 05:58:20.589162
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_obj = RoleMetadata()
    role_metadata_obj.deserialize({'allow_duplicates':True, 'dependencies':[]})

# Generated at 2022-06-25 05:58:28.342429
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = Role("test_role_name")
    role_metadata.__dict__["_role_path"] = "/roles"
    role_metadata.__dict__["_play"] = "test_play"
    role_metadata.__dict__["collections"] = "test_collections"
    role_metadata.__dict__["_role_collection"] = "test_collection"
    role_metadata.__dict__["_variable_manager"] = {"hostvars": {}, "groups": {}, "_fact_cache": {}}
    role_metadata.__dict__["_loader"] = "test_loader"

    RoleMetadata.load(data = "null", owner = role_metadata, variable_manager = {"hostvars": {}, "groups": {}, "_fact_cache": {}}, loader = "test_loader")

#

# Generated at 2022-06-25 05:58:30.066663
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1 is not None


# Generated at 2022-06-25 05:58:32.346833
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print(test_case_0.__doc__)
    test_case_0()

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 05:58:40.761202
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.six import PY2
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_cases_dir = os.path.join(current_dir, 'test_cases')
    test_case_dir = os.path.join(test_cases_dir, '0')
    sys.path.append(test_case_dir)
    from test_case_0 import test_case_0

    test_case_0()
    test_case_dir = os.path.join(test_cases_dir, '1')

# Generated at 2022-06-25 05:58:43.464191
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert isinstance(role_metadata_1, Base)
    assert isinstance(role_metadata_1, CollectionSearch)

# Generated at 2022-06-25 05:58:45.913341
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 05:58:48.000501
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }


# Generated at 2022-06-25 05:58:49.561455
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    obj = RoleMetadata(owner=None) # It's really a class variable
    assert True



# Generated at 2022-06-25 05:59:04.586689
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:59:09.492487
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_obj = RoleMetadata()
    setattr(role_metadata_obj, 'allow_duplicates', 'False')
    setattr(role_metadata_obj, 'dependencies', [])
    assert role_metadata_obj.allow_duplicates == 'False'
    assert role_metadata_obj.dependencies == []


# Generated at 2022-06-25 05:59:13.157142
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """
    Test serialize method of RoleMetadata
    """
    role_metadata_0 = RoleMetadata()
    result = role_metadata_0.serialize()
    assert result is not None, 'The serialize method of RoleMetadata returned none'
    assert isinstance(result, dict), 'The serialize method of RoleMetadata did not return a dict'
    assert len(result) == 2, 'The serialize method of RoleMetadata did not return a dict of 2 elements'


# Generated at 2022-06-25 05:59:19.537652
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    ansible_ds = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata_1 = RoleMetadata()
    role_metadata_2 = RoleMetadata()
    role_metadata_2.load(ansible_ds, None, None, None)
    assert role_metadata_1 == role_metadata_2
    assert role_metadata_1.__dict__ == role_metadata_2.__dict__

# Generated at 2022-06-25 05:59:22.767585
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()

    expected = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    # test method serialize
    actual = role_metadata_0.serialize()
    assert actual == expected, "RoleMetadata.__init__() did not return the expected value"


# Generated at 2022-06-25 05:59:29.508662
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()

    assert role_metadata_1.allow_duplicates == False
    assert isinstance(role_metadata_1.dependencies, list)
    assert isinstance(role_metadata_1.galaxy_info, dict)
    assert isinstance(role_metadata_1.argument_specs, dict)


# Generated at 2022-06-25 05:59:30.409514
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()

# Generated at 2022-06-25 05:59:32.871584
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.dependencies == []
    assert role_metadata_1.allow_duplicates == False

# Generated at 2022-06-25 05:59:39.169249
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = None

    play_0 = Play().load(dict(
            name = 'test Play 0'
        ),
        variable_manager = variable_manager,
        loader = loader
    )
    play_0._included_filenames = ['file_0', 'file_1']
    play_0._play_hosts = dict()


# Generated at 2022-06-25 05:59:40.560442
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata.load(None, None)

# Generated at 2022-06-25 05:59:58.802787
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'allow_duplicates': False, 'dependencies': []})

if __name__ == "__main__":
    test_case_0()
    test_RoleMetadata_deserialize()

# Generated at 2022-06-25 06:00:04.586845
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_test = RoleMetadata()
    assert role_metadata_test is not None
# test if the constructor returns a object of RoleMetadata class
    assert isinstance(role_metadata_test, RoleMetadata)

# Generated at 2022-06-25 06:00:09.431879
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = 'test_val'
    role_metadata.dependencies = 'test_val'
    role_metadata.galaxy_info = 'test_val'
    role_metadata.argument_specs = 'test_val'
    assert role_metadata.serialize() == {'dependencies' : 'test_val', 'allow_duplicates' : 'test_val'}


# Generated at 2022-06-25 06:00:14.878598
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    # Load an empty yaml
    yaml = None
    role_metadata = RoleMetadata.load(yaml, None)
    assert role_metadata is not None

# Generated at 2022-06-25 06:00:19.094863
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._attributes == {
        'allow_duplicates': {'default': False, 'isa': 'bool'},
        'argument_specs': {'default': dict, 'isa': 'dict'},
        'dependencies': {'default': list, 'isa': 'list'},
        'galaxy_info': {'default': '', 'isa': 'GalaxyInfo'}
    }

# Generated at 2022-06-25 06:00:22.827697
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata_0 = RoleMetadata()
    role_metadata_dict_0 = role_metadata_0.serialize()
    assert role_metadata_dict_0 == {'dependencies': [], 'allow_duplicates': False}



# Generated at 2022-06-25 06:00:25.856542
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({"allow_duplicates": False, "dependencies": []})


# Generated at 2022-06-25 06:00:27.222260
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata.deserialize(role_metadata_0)

# Generated at 2022-06-25 06:00:28.659964
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata == None

# Generated at 2022-06-25 06:00:32.248046
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    d = dict(
        allow_duplicates=["false"],
        dependencies=["ansible: galaxy.role"],
        )
    r.deserialize(d)
    assert r._allow_duplicates == ['false']
    assert r._dependencies == ["ansible: galaxy.role"]



# Generated at 2022-06-25 06:00:58.096724
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'dependencies':'test_dependency_0','allow_duplicates':True})


# Generated at 2022-06-25 06:01:01.831425
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()

    # Load role metadata from role
    role_metadata_1 = RoleMetadata.load({}, role_metadata_0)
    assert role_metadata_1 == role_metadata_0

test_case_0()

# Generated at 2022-06-25 06:01:06.554116
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    data = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar', 'baz']
    )

    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

    assert(role_metadata.allow_duplicates == True)
    assert(role_metadata.dependencies == ['foo', 'bar', 'baz'])


# Generated at 2022-06-25 06:01:12.472731
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    metadata.deserialize(dict(allow_duplicates=True, dependencies=[{'role': 'foo', 'name': 'bar'}]))
    assert metadata._allow_duplicates == True
    assert metadata._dependencies == [{'role': 'foo', 'name': 'bar'}]


# Generated at 2022-06-25 06:01:16.459430
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    # Test type of return value
    assert isinstance(role_metadata_0.serialize(), dict)
    # Test return value
    assert role_metadata_0.serialize() == dict(
        allow_duplicates=False,
        dependencies=[],
    )


# Generated at 2022-06-25 06:01:19.431153
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    assert role_metadata.load(dict(), owner=None) == None

# Generated at 2022-06-25 06:01:21.793376
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_3 = RoleMetadata()
    assert role_metadata_3.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 06:01:25.175593
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        test_case_0()
        print ('Success: constructed test case 0')
    except Exception as e:
        print ('Failure: caught exception testing constructor')
        print (e)

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 06:01:29.127301
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    d = dict(
        allow_duplicates = True
    )
    rmd.deserialize(d)
    assert rmd.allow_duplicates == True



# Generated at 2022-06-25 06:01:37.655901
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''
    try:
        from ansible.playbook.base import Base
    except ImportError as e:
        print("Could not load ansible.playbook.base")
        raise e
    try:
        from ansible.playbook.collectionsearch import CollectionSearch
    except ImportError as e:
        print("Could not load ansible.playbook.collectionsearch")
        raise e
    try:
        from ansible.playbook.role.requirement import RoleRequirement
    except ImportError as e:
        print("Could not load ansible.playbook.role.requirement")
        raise e

# Generated at 2022-06-25 06:02:10.490116
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    role_metadata_1 = RoleMetadata()
    data = {
        "dependencies": [
            "geerlingguy.apt",
            "geerlingguy.apache",
            {
                "role": "geerlingguy.mysql",
                "version": "1.0.0"
            }
        ]
    }
    role_metadata_1.load(data, owner=None)
    assert role_metadata_1._dependencies == ["geerlingguy.apt", "geerlingguy.apache", {
        "role": "geerlingguy.mysql",
        "version": "1.0.0"
    }]


# Generated at 2022-06-25 06:02:22.877413
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0._load_data({
        'allow_duplicates': False,
        'dependencies': ['test', 'test', {'role': 'test', 'version': '1.2.3'}]
    })

    expected = {
        'allow_duplicates': False,
        'dependencies': ['test', 'test', {'role': 'test', 'version': '1.2.3'}]
    }

    role_metadata_0_serialized = role_metadata_0.serialize()
    assert role_metadata_0_serialized == expected, \
        'RoleMetadata._serialize() failed, returned %s, expected %s' % (
            role_metadata_0_serialized,
            expected
        )


# Generated at 2022-06-25 06:02:26.059975
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Setup and call test
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({})

    # Assert results
    assert role_metadata_0._allow_duplicates == False
    assert role_metadata_0._dependencies == []


# Generated at 2022-06-25 06:02:27.448929
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata.load({'foo': 1})
    assert role_metadata.foo == 1


# Generated at 2022-06-25 06:02:30.978759
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.allow_duplicates=False
    role_metadata_0.dependencies=[]
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 06:02:36.303244
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    expected_1 = {'allow_duplicates': False,
                  'dependencies': []}
    actual_1 = role_metadata_1.serialize()
    assert actual_1 == expected_1

# Generated at 2022-06-25 06:02:41.807028
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_load_0 = RoleMetadata()
    # Check if TypeError raised when data not dict
    with pytest.raises(AnsibleParserError):
        RoleMetadata.load([], role_metadata_load_0)


# Generated at 2022-06-25 06:02:48.834040
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_2 = RoleMetadata()
    role_metadata_2.allow_duplicates = True
    role_metadata_2.dependencies = []
    assert role_metadata_1.serialize() == {}
    assert role_metadata_2.serialize() == {'allow_duplicates': True, 'dependencies': []}


# Generated at 2022-06-25 06:02:50.032446
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    obj = RoleMetadata()
    assert obj


# Generated at 2022-06-25 06:02:58.372447
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    role_metadata_1 = RoleMetadata.load(data={}, owner=None)
    assert role_metadata_1.allow_duplicates is False
    assert len(role_metadata_1.dependencies) == 0 and isinstance(role_metadata_1.dependencies, list) and \
        isinstance(role_metadata_1.dependencies[0], RoleRequirement)

    role_metadata_2 = RoleMetadata.load(data=None, owner=None)
    assert role_metadata_2 is None


# Generated at 2022-06-25 06:03:51.412478
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass



# Generated at 2022-06-25 06:03:53.959846
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    expected_result = {'allow_duplicates': False, 'dependencies': []}
    result = role_metadata_1.serialize()
    assert result == expected_result



# Generated at 2022-06-25 06:03:55.353811
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1


# Generated at 2022-06-25 06:04:00.988953
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # test serialize of empty RoleMetadata object.
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'dependencies': [], 'allow_duplicates': False}
    # test same object with values
    role_metadata_0 = RoleMetadata()
    role_metadata_0.allow_duplicates = True
    role_metadata_0.dependencies = ['a','b','c']
    assert role_metadata_0.serialize() == {'dependencies': ['a', 'b', 'c'], 'allow_duplicates': True}


# Generated at 2022-06-25 06:04:09.355477
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {"allow_duplicates": False, "dependencies": []}
    role_metadata_0.deserialize(data)
# assert that the returned value of deserialize() called on "role_metadata_0" is equal to the value of the "role_metadata_0" object after deserialize() has been called on "role_metadata_0"
    assert role_metadata_0 == role_metadata_0


# Generated at 2022-06-25 06:04:19.617062
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()
    # Testing attributes of instance RoleMetadata.
    setattr(role_metadata_1, 'allow_duplicates', True)
    setattr(role_metadata_1, 'dependencies', ['galaxy.role,version,name'])
    serialized_role_metadata_1 = role_metadata_1.serialize()
    role_metadata_deserialized_1 = RoleMetadata()
    role_metadata_deserialized_1.deserialize(serialized_role_metadata_1)
    assert serialized_role_metadata_1 == role_metadata_deserialized_1.serialize()



# Generated at 2022-06-25 06:04:21.441296
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # call test_case_0
    test_case_0()



# Generated at 2022-06-25 06:04:31.093344
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = dict(
        allow_duplicates=True,
        dependencies=['common', 'webservers'],
        galaxy_info=dict(
            author='Will Thames',
            description='Install and configure the Nginx web server',
            company='My Company Ltd',
            license='MIT',
            min_ansible_version='2.7',
            platform='Linux',
            galaxy_tags=[
                'web',
            ],
            issues_url='https://github.com/willthames/ansible-role-nginx/issues',
            galaxy_tests=[],
            company_url='https://www.mycompany.com',
        ),
    )
    role_metadata = RoleMetadata(owner=None, data=metadata)
    data = role_metadata.serialize()

# Generated at 2022-06-25 06:04:34.876175
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize(dict(allow_duplicates=True, dependencies=[]))
    assert role_metadata_1.allow_duplicates is True
    assert role_metadata_1.dependencies == []


# Generated at 2022-06-25 06:04:36.570593
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()

    assert role_metadata_1._allow_duplicates == False
    assert role_metadata_1._dependencies == []