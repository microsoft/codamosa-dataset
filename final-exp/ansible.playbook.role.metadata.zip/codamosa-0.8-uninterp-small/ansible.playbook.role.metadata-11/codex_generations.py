

# Generated at 2022-06-25 05:55:17.883776
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_load = RoleMetadata()

# Generated at 2022-06-25 05:55:21.035883
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    try:
        if hasattr(role_metadata_0, 'serialize'):
            out = role_metadata_0.serialize()
            assert isinstance(out, dict)
        else:
            raise AttributeError("'RoleMetadata' object has no attribute 'serialize'")
    except (AssertionError, AttributeError) as e:
        print(e)
        pytest.fail("Unit test for method serialize of class RoleMetadata failed")


# Generated at 2022-06-25 05:55:26.761741
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()

    data= { 'allow_duplicates': False, 'dependencies': [] }
    role_metadata_1.deserialize(data)
    assert role_metadata_1._allow_duplicates == False
    assert len(role_metadata_1._dependencies) == 0


# Generated at 2022-06-25 05:55:28.126567
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()

    assert role_metadata_1


# Generated at 2022-06-25 05:55:29.491565
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert(role_metadata_1 is not None)


# Generated at 2022-06-25 05:55:31.406392
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 05:55:36.284003
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rm = RoleMetadata()
    assert rm.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 05:55:39.661864
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0._allow_duplicates == "False"
    assert role_metadata_0._argument_specs == dict()
    assert role_metadata_0._dependencies == list()
    assert role_metadata_0._galaxy_info == None

# Generated at 2022-06-25 05:55:42.603479
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_data_0 = {'allow_duplicates': False, 'dependencies': []}

    # Test for deserialize
    role_metadata_0.deserialize(role_data_0)



# Generated at 2022-06-25 05:55:43.428783
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    RoleMetadata.load()

# Generated at 2022-06-25 05:55:59.165779
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    m = RoleMetadata.load(data={'galaxy_info': {'author': 'sample_author'}, 'dependencies': ['dependency1', 'dependency2']}, owner=role_metadata)
    assert m is not None and m.dependencies[0] == 'dependency1' and m.dependencies[1] == 'dependency2' and m.galaxy_info.author == 'sample_author'

# Generated at 2022-06-25 05:56:01.775127
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': []}
    role_metadata_1.deserialize(data)


# Generated at 2022-06-25 05:56:03.326866
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})


# Generated at 2022-06-25 05:56:05.073941
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    result = role_metadata_0.deserialize(data={})
    assert not result


# Generated at 2022-06-25 05:56:05.835725
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert issubclass(RoleMetadata, Base)

# Generated at 2022-06-25 05:56:11.157941
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    if isinstance(role_metadata, RoleMetadata):
        print('Class RoleMetadata exist: pass')
    # assert isinstance(role_metadata, RoleMetadata)
    else:
        print('Class RoleMetadata does not exist: fail')


# Generated at 2022-06-25 05:56:12.117618
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # TODO: add meaningful tests
    pass

# Generated at 2022-06-25 05:56:13.748100
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        test_case_0()
    except:
        return False
    return True



# Generated at 2022-06-25 05:56:16.015552
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'allow_duplicates': False, 'dependencies': []})


# Generated at 2022-06-25 05:56:22.271441
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = {'dependencies': [], 'allow_duplicates': False}
    role_metadata_0.deserialize(data_0)
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []


# Generated at 2022-06-25 05:56:35.723089
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': 'local_action'})


# Generated at 2022-06-25 05:56:46.397407
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()
    try:
        role_metadata_1.load({'dependencies': [], 'allow_duplicates': False})
    except AssertionError as e:
        pass
    assert role_metadata_0 == role_metadata_1
    role_metadata_1.load({'dependencies': ['galaxy.example.com,0.1.0'], 'allow_duplicates': False})
    role_metadata_0.dependencies = ['galaxy.example.com,0.1.0']
    role_metadata_0.allow_duplicates = False
    assert role_metadata_0 == role_metadata_1
    b = False

# Generated at 2022-06-25 05:56:51.759665
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = {
        'allow_duplicates': False,
        'dependencies': [],
    }
    role_metadata = RoleMetadata()
    assert role_metadata.deserialize(metadata) == metadata


# Generated at 2022-06-25 05:56:56.938234
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    serialized_role_metadata = role_metadata.serialize()
    assert('allow_duplicates' in serialized_role_metadata)
    assert('dependencies' in serialized_role_metadata)



# Generated at 2022-06-25 05:57:03.678926
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1_dict = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_1.deserialize(role_metadata_1_dict)
    assert role_metadata_1.allow_duplicates == False
    assert role_metadata_1.dependencies == []



# Generated at 2022-06-25 05:57:05.844959
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-25 05:57:09.309190
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    print("RoleMetadata instance is created: ", role_metadata_0)

# Generated at 2022-06-25 05:57:11.573521
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:57:15.918404
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_ds = dict()
    try:
        role_metadata = role_metadata_0.load(role_metadata_ds, None)
    except AnsibleParserError as e:
        assert(e.message == "the 'meta/main.yml' for role %s is not a dictionary" % None.get_name())


# Generated at 2022-06-25 05:57:16.728781
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    return

# Generated at 2022-06-25 05:57:45.083736
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # input:
    #      (dict) data (e.g. {"dependencies": ["foo"]})
    #      (object) owner
    #      (object) variable_manager
    #      (object) loader
    # output:
    #      (object) RoleMetadata
    # test case:
    role_metadata_0 = RoleMetadata.load({"dependencies": ["foo"]}, object())


# Generated at 2022-06-25 05:57:46.158030
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata_0 = RoleMetadata()

    assert role_metadata_0.serialize() == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-25 05:57:47.349993
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print("test_RoleMetadata: " + "instance is created!")

test_RoleMetadata()

# Generated at 2022-06-25 05:57:52.786951
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(
        allow_duplicates=False,
        dependencies=[]
    ))

    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []


# Generated at 2022-06-25 05:57:55.037843
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata()
    print("\nSerialize RoleMetadata\n")
    print("serialized role is : ",metadata.serialize())

    assert metadata.serialize() == {'dependencies': [], 'allow_duplicates': False}


# Generated at 2022-06-25 05:57:57.087912
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
  role_metadata_0 = RoleMetadata()
  role_metadata_0.deserialize(dict(allow_duplicates=None, dependencies=None))

# Generated at 2022-06-25 05:58:00.686577
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata.deserialize(data)


# Generated at 2022-06-25 05:58:03.803978
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    data = {'dependencies': [], 'allow_duplicates': False}
    role_metadata_1.deserialize(data)
    assert role_metadata_1.serialize() == data
    assert role_metadata_1._allow_duplicates == data['allow_duplicates']
    assert role_metadata_1._dependencies == []

# Generated at 2022-06-25 05:58:06.421093
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''

    role_metadata_0 = RoleMetadata()
    role_metadata_0.load()

# Generated at 2022-06-25 05:58:08.815691
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata.load(arg1="asdf", arg2="asdf")
    assert isinstance(role_metadata_1, RoleMetadata) == True


# Generated at 2022-06-25 05:58:57.503733
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0, RoleMetadata)


# Generated at 2022-06-25 05:58:59.608970
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load(data=None, owner=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 05:59:02.931596
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata(owner=Base())
    serialized = meta.serialize()
    assert isinstance(serialized, dict)


# Generated at 2022-06-25 05:59:09.264466
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=True,
        dependencies=[RoleRequirement('nginx.com', 'nginx', '1.6.2', 'nginx')]
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

    assert role_metadata.allow_duplicates is True
    assert role_metadata.dependencies[0].get_name() == 'nginx'


# Generated at 2022-06-25 05:59:10.928810
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    result = RoleMetadata.load(data=None, owner=None)
    assert True == isinstance(result, RoleMetadata)


# Generated at 2022-06-25 05:59:14.294935
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    var_RoleMetadata_allow_duplicates = False
    obj = RoleMetadata(allow_duplicates=var_RoleMetadata_allow_duplicates)

    obj_serialize = obj.serialize()
    assert 'allow_duplicates' in obj_serialize



# Generated at 2022-06-25 05:59:17.853155
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

if __name__ == '__main__':
    print("Testing " + __file__)
    test_case_0()
    test_RoleMetadata()
    print("Test successful")

# Generated at 2022-06-25 05:59:20.038742
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_obj = RoleMetadata()
    role_metadata_obj.deserialize(role_metadata_1)
    assert role_metadata_obj._allow_duplicates == False
    assert role_metadata_obj._dependencies == []


# Generated at 2022-06-25 05:59:22.734820
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.allow_duplicates = False
    role_metadata_0.dependencies = dict()
    assert role_metadata_0.serialize() == dict(dependencies=dict(), allow_duplicates=False)

# Generated at 2022-06-25 05:59:28.420743
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    test_dict = {'allow_duplicates':True}
    role = RoleMetadata.load(test_dict, role_metadata_0._owner)
    assert (role.allow_duplicates == True)

# Generated at 2022-06-25 06:00:59.256957
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    try:
        RoleMetadata.load(data, 'owner')
    except Exception as e:
        raise e


# Generated at 2022-06-25 06:01:02.287478
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    result = role_metadata_0.deserialize({})
    assert result is None



# Generated at 2022-06-25 06:01:07.641878
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize(data)


# Generated at 2022-06-25 06:01:11.355389
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected = dict(
        allow_duplicates=role_metadata_0._allow_duplicates,
        dependencies=role_metadata_0._dependencies
    )
    assert (role_metadata_0.serialize() == expected)


# Generated at 2022-06-25 06:01:18.735995
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(
        allow_duplicates=False,
        dependencies=["test.test_case_valid_role_info_0", "test.test_case_valid_role_info_1", "test.test_case_valid_role_info_2", "test.test_case_valid_role_info_3"],
        ))

    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == ["test.test_case_valid_role_info_0", "test.test_case_valid_role_info_1", "test.test_case_valid_role_info_2", "test.test_case_valid_role_info_3"]


# Generated at 2022-06-25 06:01:20.949527
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0.serialize(), dict)


# Generated at 2022-06-25 06:01:28.154900
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    ds = {
        "dependencies": [
            {"role": "Common", "defaults_file": "config/defaults.yml"},
            {"role": "Application Server", "when": "ansible_distribution == 'Debian'"}
        ],
        "allow_duplicates": False
    }
    role_metadata_0 = RoleMetadata.load(ds=ds, owner=None)

    assert role_metadata_0 is not None
    # Test 'dependencies' attribute
    dependencies = role_metadata_0.dependencies()
    assert dependencies is not None
    assert len(dependencies) == 2

    # Test the first item of 'dependencies'
    # The first item of 'dependencies' should be a dictionary
    assert isinstance(dependencies[0], dict)
    first_dependency = dependencies[0]


# Generated at 2022-06-25 06:01:31.754956
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    result = RoleMetadata()
    result.deserialize(dict(
        allow_duplicates=False,
        dependencies=[],
    ))
    assert (result.allow_duplicates is False)
    assert (result.dependencies == [])



# Generated at 2022-06-25 06:01:34.667512
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    role_metadata_0 = RoleMetadata()
    r_0 = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0.deserialize(r_0)


# Generated at 2022-06-25 06:01:36.877906
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()



# Generated at 2022-06-25 06:04:07.670356
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("test_RoleMetadata testcase begin")
    test_case_0()
    print("test_RoleMetadata testcase end")

# Generated at 2022-06-25 06:04:15.656964
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()

    assert isinstance(r.allow_duplicates, bool)
    assert r.allow_duplicates == False
    assert isinstance(r.dependencies, list)
    assert r.dependencies == []
    assert isinstance(r._argument_specs, dict)
    assert r._argument_specs == {}



# Generated at 2022-06-25 06:04:19.449295
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates == False, "Fail, wrong value"
    assert role_metadata.dependencies == [], "Fail, wrong value"

# Generated at 2022-06-25 06:04:22.144704
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load('data', owner='owner', variable_manager=None, loader=None)


# Generated at 2022-06-25 06:04:31.642702
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_obj = RoleMetadata()

    _data = {}
    _owner = {'role': 'ansible.posix', 'role_path': '/home/stephen/project/ansible/lib/ansible/roles/ansible.posix'}
    _variable_manager = None
    _loader = None

    # role_metadata_1 = test_obj.load(_data, _owner)
    # assert role_metadata_1._owner == 'ansible.posix'
    # assert role_metadata_1.dependencies == []
    # assert role_metadata_1.allow_duplicates == False

    _data = {'allow_duplicates': True, 'dependencies': [{'role': 'ansible.posix'}]}
    role_metadata_2 = test_obj.load(_data, _owner)


# Generated at 2022-06-25 06:04:35.520796
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata_dict = {'allow_duplicates': False,
                     'dependencies': []}
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize(metadata_dict)
    assert not role_metadata_1.allow_duplicates
    assert role_metadata_1.dependencies == []


# Generated at 2022-06-25 06:04:45.396223
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ansible_playbook_path = os.getenv('TEST_ANSIBLE_PLAYBOOK_PATH')
    if not ansible_playbook_path:
        print('XXX: No TEST_ANSIBLE_PLAYBOOK_PATH specified. Skipping test_RoleMetadata_deserialize().')
        return
    data_dir = os.path.join(ansible_playbook_path, 'test', 'data')
    unit_test_yml = os.path.join(data_dir, 'unit', 'role_metadata', 'test_case_0.yml')
    with open(unit_test_yml, 'r') as fd:
        fd_data = fd.read()
    if fd_data:
        # Initialize an object to call the deserialize method on
        m = RoleMetadata()
        #

# Generated at 2022-06-25 06:04:46.656132
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0 == role_metadata_0


# Generated at 2022-06-25 06:04:48.436179
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == dict(allow_duplicates=False, dependencies=list())


# Generated at 2022-06-25 06:04:53.696617
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    ds_0 = dict(dependencies=[])
    serialized_0 = role_metadata_0.serialize()
    assert serialized_0 == ds_0
