

# Generated at 2022-06-25 05:55:19.211475
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({})


# Generated at 2022-06-25 05:55:21.580676
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 05:55:22.998721
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_data = RoleMetadata()
    assert isinstance(role_data, RoleMetadata)

# Generated at 2022-06-25 05:55:23.458374
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert(True)

# Generated at 2022-06-25 05:55:25.690704
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create a new RoleMetadata object
    role_metadata = RoleMetadata()
    # Check the type of role_metadata
    test_case_0()
    assert(type(role_metadata) == RoleMetadata)


# Generated at 2022-06-25 05:55:27.875425
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

    # We expect the constructor will not return an error
    if role_metadata == None:
        raise AssertionError("Error: RoleMetadata class constructor failed")


# Generated at 2022-06-25 05:55:29.805717
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    print('role_metadata_0 = %r' % (role_metadata_0,))
    assert role_metadata_0


# Generated at 2022-06-25 05:55:31.775117
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load(data='./tests/resources/role_metadata', owner='/etc/ansible/roles/test_case_metadata')

test_case_0()
test_RoleMetadata_load()

# Generated at 2022-06-25 05:55:33.639067
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata, RoleMetadata)


# Generated at 2022-06-25 05:55:34.913532
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load(data = {}, owner = {}, variable_manager = {}, loader = {})


# Generated at 2022-06-25 05:55:43.354418
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load({})

# Generated at 2022-06-25 05:55:45.464491
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load(data=None, owner=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 05:55:47.710875
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    role_metadata_1 = RoleMetadata()
    assert role_metadata_1 is not None


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 05:55:50.522127
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # define values used in test case
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata_0 = RoleMetadata()
    
    # test case
    assert role_metadata_0.deserialize(data) == None


# Generated at 2022-06-25 05:55:55.493078
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1_obj = role_metadata_1.serialize()
    assert role_metadata_1_obj == {'allow_duplicates': False, 'dependencies': []}, "RoleMetadata_serialize test case failed"


# Generated at 2022-06-25 05:55:57.005651
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        RoleMetadata()
    except Exception as e:
        assert False, 'Unable to construct RoleMetadata object'


# Generated at 2022-06-25 05:55:58.206116
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Very basic test
    assert(RoleMetadata.load(None, None))


# Generated at 2022-06-25 05:56:02.283490
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(dependencies=[dict(role='restart-service', default_task='main')], allow_duplicates=True)
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == [{'role': 'restart-service', 'default_task': 'main'}]


# Generated at 2022-06-25 05:56:03.818645
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create a new RoleMetadata object
    role_metadata = RoleMetadata()



# Generated at 2022-06-25 05:56:06.766438
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_data_0 = {u'allow_duplicates': False, u'dependencies': []}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(test_data_0)
    assert role_metadata_0.allow_duplicates == False


# Generated at 2022-06-25 05:56:27.450170
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    actual = role_metadata_0.serialize()
    assert actual == expected

    # test override
    role_metadata_1 = RoleMetadata()
    role_metadata_1.allow_duplicates = True
    role_metadata_1.dependencies = [{'role1':{'name':'role1'}}, 'role2']
    expected = dict(
        allow_duplicates=True,
        dependencies=[{'role1':{'name':'role1'}}, 'role2']
    )
    actual = role_metadata_1.serialize()
    assert actual == expected

# Generated at 2022-06-25 05:56:35.826802
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()

    data = {
        'dependencies': [
            {
                'role': 'geerlingguy.jenkins',
                'version': '2.0.0'
            }
        ]
    }

    owner = {}
    variable_manager = {
        'name': 'variable_manager'
    }
    loader = {
        'name': 'loader'
    }

    role_metadata_1 = role_metadata_0.load(data, owner, variable_manager, loader)
    assert role_metadata_1 is not None

# Generated at 2022-06-25 05:56:39.739426
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load(data={}, owner=None)


# Generated at 2022-06-25 05:56:47.877641
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # testing with a dict - invalid input
    data = dict()
    owner = RoleMetadata()
    try:
        RoleMetadata.load(data, owner)
    except Exception as e:
        assert(isinstance(e, AnsibleParserError))
        assert(e.message == "the 'meta/main.yml' for role <none> is not a dictionary")

    # testing with a list - valid input
    data = list()
    try:
        RoleMetadata.load(data, owner)
    except Exception as e:
        raise e


# Generated at 2022-06-25 05:56:51.032679
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-25 05:56:56.703041
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    assert 'allow_duplicates' in dir(RoleMetadata())
    assert 'dependencies' in dir(RoleMetadata())
myobj = RoleMetadata()
myobj.deserialize({"allow_duplicates": False, "dependencies": []})
assert myobj.allow_duplicates == False
assert myobj.dependencies == []


# Generated at 2022-06-25 05:57:03.626110
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    data = dict()
    owner = None
    result = role_metadata_1.load(data, owner)
    expected_result = None
    if not isinstance(result, type(expected_result)):
        print("expected: %s, got %s" % (expected_result, result))
        assert False


# Generated at 2022-06-25 05:57:06.182105
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []


# Generated at 2022-06-25 05:57:11.703322
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    g = RoleMetadata()


if __name__ == "__main__":
    import sys
    import os
    import pytest
    import ansible.constants as C
    C.HOST_KEY_CHECKING = False
    file_path = os.path.realpath(__file__)
    sys.path.insert(0, os.path.dirname(file_path) + "/../")

    pytest.main([file_path, '-v', '-s'])

# Generated at 2022-06-25 05:57:12.751319
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert isinstance(role_metadata_1.serialize(), dict)


# Generated at 2022-06-25 05:57:21.212433
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

test_RoleMetadata()

# Generated at 2022-06-25 05:57:23.833515
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load(ds='TEST_VALUE', owner='TEST_VALUE', variable_manager='TEST_VALUE', loader='TEST_VALUE')


# Generated at 2022-06-25 05:57:28.181698
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': True,
        'dependencies': ['defaults', 'vars', 'tasks', 'handlers']
    })

    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['defaults', 'vars', 'tasks', 'handlers']


# Generated at 2022-06-25 05:57:32.486600
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )


# Generated at 2022-06-25 05:57:35.169719
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'allow_duplicates': True, 'dependencies': [{'name': 'test'}]})
    role_metadata_1.serialize()


# Generated at 2022-06-25 05:57:42.459817
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'dependencies': [], 'allow_duplicates': False}

    role_metadata_0._dependencies = [{'name': 'openbsd-dev'}]
    assert role_metadata_0.serialize() == {'dependencies': [{'name': 'openbsd-dev'}], 'allow_duplicates': False}


# Generated at 2022-06-25 05:57:46.755167
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Tests assume the following:
    #   - filename contains metadata/main.yml
    #   - role_path contains the full path to the file
    #   - the role is named 'test'

    test_role_metadata_0 = dict()
    assert test_case_0().load(test_role_metadata_0, test_case_0()) is None


# Generated at 2022-06-25 05:57:52.259523
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata_0 = RoleMetadata()
    res_0 = role_metadata_0.serialize()

    assert res_0["allow_duplicates"] is False
    assert res_0["dependencies"] == []


# Generated at 2022-06-25 05:57:54.798737
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.load({"dependencies":[{"role": "common","name": "common"},{"role": "webserver","name": "webserver"},{"role": "database","name": "database"}]}, "owner", "variable_manager", "loader")


# Generated at 2022-06-25 05:57:57.154591
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    data = {'name': 'myrole'}
    loader = None
    result = role_metadata.load(data, owner=None, loader=loader)
    raise Exception(result)


if __name__ == '__main__':
    # test_case_0()
    test_RoleMetadata_load()

# Generated at 2022-06-25 05:58:28.399764
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    dict_0 = dict()
    dict_0['dependencies'] = list()
    dict_0['allow_duplicates'] = False
    owner_0 = RoleRequirement()
    variable_manager_0 = VariableManager()
    # Load the role and return the RoleMetadata object
    load_0 = role_metadata_0.load(dict_0, owner_0, variable_manager_0)
    assert(load_0 == role_metadata_0)


# Generated at 2022-06-25 05:58:33.737406
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    serialize = role_metadata_1.serialize()
    assert serialize == dict(
        allow_duplicates=False,
        dependencies=[]
    )


# Generated at 2022-06-25 05:58:37.747758
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    #set up object for serialize
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['1','2','3']

    #serialize it
    data = role_metadata.serialize()

    #verify the serialization
    assert data is not None
    assert data['allow_duplicates'] == True
    assert data['dependencies'] == ['1','2','3']


# Generated at 2022-06-25 05:58:40.644988
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    #TODO: Figure out how to test this method
    assert False

# Generated at 2022-06-25 05:58:44.261649
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Load a dictionary datastructure
    role_metadata_1 = RoleMetadata.load(data={"meta": {"main.yml": {}}})
    assert(role_metadata_1._ds == {"meta": {"main.yml": {}}})


# Generated at 2022-06-25 05:58:46.104787
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    with pytest.raises(AssertionError):
        role_metadata_1 = RoleMetadata()


# Generated at 2022-06-25 05:58:50.582970
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # For deserialize we need a RoleMetadata object.
    role_metadata_0 = RoleMetadata()
    # Now we can call the deserialize method.
    # But we need a data structure to pass to it, the function test_case_0
    # creates a yaml file which can be used to create a dictionary.
    # This dictionary can be passed to the method deserialize
    role_metadata_0.deserialize(test_case_0())


# Generated at 2022-06-25 05:59:01.220200
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})
    if role_metadata.allow_duplicates != False:
        raise AssertionError("""Failed to deserialize for allow_duplicates""")
    if role_metadata.dependencies != []:
        raise AssertionError("""Failed to deserialize for dependencies""")
    role_metadata.deserialize({'allow_duplicates':  True, 'dependencies': ['test_role']})
    if role_metadata.allow_duplicates != True:
        raise AssertionError("""Failed to deserialize for allow_duplicates""")

# Generated at 2022-06-25 05:59:03.799223
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': False, 'dependencies': []})


# Generated at 2022-06-25 05:59:09.903515
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    setattr(test_RoleMetadata_deserialize, 'allow_duplicates', True)
    setattr(test_RoleMetadata_deserialize, 'dependencies', ["dependency1", "dependency2"])
    assert test_RoleMetadata_deserialize.allow_duplicates == True
    assert test_RoleMetadata_deserialize.dependencies == ["dependency1", "dependency2"]


# Generated at 2022-06-25 05:59:41.783274
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    print(role_metadata_0.allow_duplicates)
    print(role_metadata_0.dependencies)
    print(role_metadata_0.galaxy_info)
    print(role_metadata_0._argument_specs)

# Generated at 2022-06-25 05:59:45.758335
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    role_metadata_2 = role_metadata_1.load(data=None, owner=None, variable_manager=None, loader=None)
    assert(role_metadata_2 is not None)


# Generated at 2022-06-25 05:59:54.548535
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    data = {"dependencies": []}
    try:
        role_metadata_1.load(data, None)
    except AnsibleParserError as e:
        print('Caught AnsibleParserError: {0}'.format(e))
    print(role_metadata_1._dependencies)
    data = {"dependencies": "something"}
    try:
        role_metadata_1.load(data, None)
    except AnsibleParserError as e:
        print('Caught AnsibleParserError: {0}'.format(e))
    data = {"dependencies": ["a", "b"]}

# Generated at 2022-06-25 05:59:59.591489
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0 is not None
    assert role_metadata_0._allow_duplicates == False
    assert role_metadata_0._dependencies == []
    assert role_metadata_0._galaxy_info == None
    assert role_metadata_0._argument_specs == {}
    assert role_metadata_0._owner == None



# Generated at 2022-06-25 06:00:10.036234
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0._dependencies == []
    role_metadata_0.dependencies = {'role_01': {'name': 'geerlingguy.apache'}, 'role_02': {'name': 'geerlingguy.firewall'}}
    role_metadata_0.allow_duplicates = False
    assert role_metadata_0._dependencies == [{'role': 'role_01', 'name': 'geerlingguy.apache'},
                                             {'role': 'role_02', 'name': 'geerlingguy.firewall'}]
    assert role_metadata_0._allow_duplicates == False
    dict_0 = role_metadata_0.serialize()

# Generated at 2022-06-25 06:00:19.307511
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Case: Simple case
    m = RoleMetadata.load("""
        galaxy_info:
            author: Joe Cisco
            description: Test role for unit testing RoleMetadata
            company: Cisco
            license: Apache 2.0
            min_ansible_version: 2.4
            galaxy_tags:
            - network
            - cisco
        dependencies:
        - role: ansible.posix
          tasks_from: network_ping
          vars:
            network_ping_count: 7
          meta:
            always_run: True
        - role: example_role
          tasks_from: webserver_security
        """, owner=None)



# Generated at 2022-06-25 06:00:20.803568
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-25 06:00:22.969097
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'allow_duplicates': False})


# Generated at 2022-06-25 06:00:27.149303
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Step 1
    # Setup
    from ansible.parsing.yaml.objects import AnsibleMapping
    role_metadata_0 = RoleMetadata()

    # Test
    role_metadata_0.deserialize(AnsibleMapping())


# Generated at 2022-06-25 06:00:31.500573
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print("\n# Unit test for method deserialize of class RoleMetadata")

    role_metadata_0 = RoleMetadata()
    data_dict = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0.deserialize(data_dict)
    print(role_metadata_0.serialize())


# Generated at 2022-06-25 06:01:25.406489
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Testing constructor")
    test_case_0()


# Generated at 2022-06-25 06:01:27.400619
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert None == role_metadata

# Generated at 2022-06-25 06:01:29.220933
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load(data={},owner=object())


# Generated at 2022-06-25 06:01:31.799052
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    # Call method load of class RoleMetadata
    role_metadata_0.load(data = None,owner = None,variable_manager = None,loader = None)

# Generated at 2022-06-25 06:01:33.896925
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.serialize()



# Generated at 2022-06-25 06:01:40.100340
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_5 = RoleMetadata()
    setattr(role_metadata_5, "allow_duplicates", True)
    setattr(role_metadata_5, "dependencies", ["role_1", "role_2"])

    assert role_metadata_5.serialize() == {
        'allow_duplicates': True,
        'dependencies': ["role_1", "role_2"]
    }


# Generated at 2022-06-25 06:01:41.808696
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 06:01:43.069265
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1


# Generated at 2022-06-25 06:01:51.779906
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = None
    role_metadata.dependencies = ["test_dependencies_0", "test_dependencies_1", "test_dependencies_2"]
    result = role_metadata.serialize()
    assert result == {'allow_duplicates': None, 'dependencies': ['test_dependencies_0', 'test_dependencies_1', 'test_dependencies_2']}


# Generated at 2022-06-25 06:01:57.968585
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'allow_duplicates': False, 'dependencies': []}

    owner = 'role'
    variable_manager = 'varmgr'
    loader = 'loader'
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = role_metadata_0.load(data, owner, variable_manager, loader)
    assert(role_metadata_1._allow_duplicates == False)
    assert(role_metadata_1._dependencies == [])
    assert(role_metadata_1._owner == 'role')
    assert(role_metadata_1._variable_manager == 'varmgr')
    assert(role_metadata_1._loader == 'loader')


# Generated at 2022-06-25 06:03:56.109796
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_obj = RoleMetadata()
    data = {'dependencies': ['B', 'C'], 'allow_duplicates': True}
    role_metadata_obj.load(data, owner=None)

# Generated at 2022-06-25 06:03:58.732610
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    test_data_0 = dict()
    role_metadata_0.deserialize(test_data_0)


# Generated at 2022-06-25 06:04:03.673889
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()
    role_metadata_0.load({'allow_duplicates': False,
                          'dependencies': []})
    role_metadata_1.load({'allow_duplicates': False,
                          'dependencies': []})
    assert (role_metadata_0.serialize() ==
            role_metadata_1.serialize())


# Generated at 2022-06-25 06:04:05.213367
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test case 0
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load(data=[], owner=None)

# Generated at 2022-06-25 06:04:06.533822
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 06:04:08.012761
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # This is really just a sanity check to ensure that the deserialize method is at least accepting data
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'dependencies': []})
    assert role_metadata._dependencies == []

# Generated at 2022-06-25 06:04:14.400378
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    real_obj = RoleMetadata()
    test_data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_deserialize(test_data)



# Generated at 2022-06-25 06:04:21.048698
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    # Attempt to load the role metadata
    data_1 = {}
    role_metadata_0.load(data=data_1, owner="owner", variable_manager="variable_manager", loader="loader")
    # Verify the contents of the RoleMetadata have been set to their defaults
    # assert role_metadata_0.__dict__ == dict()

# Generated at 2022-06-25 06:04:23.513299
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    expected_1 = dict(allow_duplicates=False, dependencies=[])
    assert role_metadata_1.serialize() == expected_1


# Generated at 2022-06-25 06:04:25.163780
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    if role_metadata._dependencies != [] or role_metadata._allow_duplicates != False:
        raise Exception("Error in constructor of RoleMetadata class")