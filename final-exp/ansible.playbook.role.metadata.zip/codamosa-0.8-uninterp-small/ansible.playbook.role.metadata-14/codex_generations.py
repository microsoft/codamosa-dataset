

# Generated at 2022-06-25 05:55:19.327268
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert bool(role_metadata_1.serialize)


# Generated at 2022-06-25 05:55:21.748058
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = {}
    role_metadata_0.deserialize(data_0)


# Generated at 2022-06-25 05:55:22.361640
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize()

# Generated at 2022-06-25 05:55:23.820756
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    result_0 = role_metadata_0.serialize()


if __name__ == '__main__':
    test_case_0()
    test_RoleMetadata_serialize()

# Generated at 2022-06-25 05:55:24.538733
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_case_0()

# Generated at 2022-06-25 05:55:26.261887
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata(owner=Owner())
    setattr(role_metadata_0, '_allow_duplicates', True)
    

# Generated at 2022-06-25 05:55:29.903422
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(allow_duplicates=True,
                dependencies=[{'role': 'geerlingguy.jenkins', 'name': 'geerlingguy.jenkins'}])
    role_metadata.deserialize(data)
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == [({'role': 'geerlingguy.jenkins', 'name': 'geerlingguy.jenkins'}, None)]


# Generated at 2022-06-25 05:55:34.421326
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_class = RoleMetadata
    test_instance = RoleMetadata()
    test_data_dict = {
        'key1': 'val1',
        'key2': 'val2'
    }
    test_owner = 'role'
    # a variable manager, used for variable substitution
    variable_manager = 'variable_manager'
    # a loader, used for finding and reading yaml files
    loader = 'loader'
    test_instance.load(test_data_dict, test_owner, variable_manager, loader)

# Generated at 2022-06-25 05:55:41.063247
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Unit test for method load of class RoleMetadata
    '''
    # Setup test data
    data = {
        'name': 'foobar',
        'description': 'Foo the bars',
        'authorized_key': 'Put the key in here'
    }

    owner = "foobar"

    # Execute the load method
    try:
        test_RoleMetadata = RoleMetadata.load(data, owner)
    except AnsibleParserError as e:
        print("Failed to create RoleMetadata object: {0}".format(e))


# Generated at 2022-06-25 05:55:43.355600
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:55:57.250841
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 05:55:58.666240
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates": "True"})

# Generated at 2022-06-25 05:56:00.308472
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 05:56:05.033323
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()
    role_metadata_2 = RoleMetadata()

    role_metadata_0.load({})
    role_metadata_1.load({'allow_duplicates': True})
    role_metadata_2.load({'dependencies': ['geerlingguy.docker', 'geerlingguy.java', 'geerlingguy.elasticsearch']})

# Generated at 2022-06-25 05:56:07.021082
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    RoleMetadata_instance = test_case_0()
    result = RoleMetadata_instance.serialize()
    assert {'allow_duplicates': False, 'dependencies': []} == result

# Generated at 2022-06-25 05:56:12.074780
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected_result_0 = {
        'dependencies': list,
        'allow_duplicates': bool
    }
    result_0 = role_metadata_0.serialize()
    assert type(result_0) == type(expected_result_0)


# Generated at 2022-06-25 05:56:23.081260
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data_0 = dict(
        dependencies=list(
            dict(
                role='galaxy.role',
                src='https://github.com/username/role',
                scm='git',
                version='master'
            )
        )
    )
    data_1 = dict(
        dependencies=list(
            dict(
                role='galaxy.role',
                src='https://github.com/username/role',
                scm='git',
                version='master'
            )
        )
    )
    data_2 = dict(
        dependencies=list(
            dict(
                role='galaxy.role',
                src='https://github.com/username/role',
                scm='git',
                version='master'
            )
        )
    )

# Generated at 2022-06-25 05:56:27.406947
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:56:34.066124
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None
    assert len(role_metadata.serialize()) == 2
    assert role_metadata.allow_duplicates is False
    assert len(role_metadata.dependencies) == 0
    assert role_metadata._galaxy_info == dict()
    assert role_metadata._argument_specs == dict()


# Generated at 2022-06-25 05:56:40.040644
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_a = RoleMetadata.load({}, 'test')
    assert not role_metadata_a._allow_duplicates
    assert role_metadata_a._dependencies == []
    assert role_metadata_a._owner == 'test'
    assert role_metadata_a._argument_specs == {}
    role_metadata_b = RoleMetadata.load({'allow_duplicates': False, 'dependencies': [], 'owner': 'test'}, 'test')
    assert not role_metadata_b._allow_duplicates
    assert role_metadata_b._dependencies == []
    assert role_metadata_b._owner == 'test'
    assert role_metadata_b._argument_specs == {}

# Generated at 2022-06-25 05:57:15.802940
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()


# Generated at 2022-06-25 05:57:19.727939
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize()['allow_duplicates'] == False
    assert role_metadata_0.serialize()['dependencies'] == []

# Generated at 2022-06-25 05:57:20.880421
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({})


# Generated at 2022-06-25 05:57:25.402497
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    data = {'not_allow_duplicates': False, 'dependencies': []}
    variable_manager = None
    loader = None
    owner = None
    result = role_metadata_1.load(data, owner, variable_manager, loader)

# Generated at 2022-06-25 05:57:29.110070
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0 != None

# Generated at 2022-06-25 05:57:30.114208
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role = RoleMetadata()
    print(role)

# Generated at 2022-06-25 05:57:36.757574
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Create new object of class RoleMetadata
    role_metadata = RoleMetadata(owner = 1)

    # Call method load
    result = role_metadata.load(data = {'dependencies': [{'role': 'otherrole', 'src': 'someserver.example.com'}],
                                        'galaxy_info': {'author': 'me', 'description': 'foo', 'company': 'bar',
                                                        'license': 'MIT', 'platforms': [{'name': 'Fedora', 'versions': ['All']}],
                                                        'galaxy_tags': ['foo', 'bar'],
                                                        'repo': 'https://github.com/someuser/somerepo', 'min_ansible_version': '1.5'}},
                                owner = 1)

    assert result == None

#

# Generated at 2022-06-25 05:57:44.439568
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Create an instance of Mock to replace the dependency for testing
    class Mock():

        def __init__(self):
            pass
        
        def get_name(self):
            return "mock_name"

    mock_0 = Mock()

    role_metadata_0 = RoleMetadata(owner=mock_0)
    role_metadata_0.deserialize({'dependencies': [], 'allow_duplicates': True})

    role_metadata_0.deserialize({'dependencies': ['mock_name'], 'allow_duplicates': True})

# Generated at 2022-06-25 05:57:51.019206
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {}
    expected_value = None
    setattr(role_metadata_0, 'allow_duplicates', role_metadata_0.deserialize(data).get('allow_duplicates', False))
    assert role_metadata_0._allow_duplicates == expected_value


# Generated at 2022-06-25 05:57:53.093103
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    global role_metadata_0
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 05:58:18.508562
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    # Test that serialize function does not throw an error
    serialized = role_metadata_1.serialize()
    # Test that serialized returns the correct data type
    assert type(serialized) == dict
    # Test that serialize returns the correct data
    assert serialized == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 05:58:27.831362
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata() # ansible/playbook/role/metadata.py ==> test_case_1
    role_metadata_2 = RoleMetadata() # ansible/playbook/role/metadata.py ==> test_case_2
    role_metadata_3 = RoleMetadata() # ansible/playbook/role/metadata.py ==> test_case_3
    role_metadata_4 = RoleMetadata() # ansible/playbook/role/metadata.py ==> test_case_4
    role_metadata_5 = RoleMetadata() # ansible/playbook/role/metadata.py ==> test_case_5
    role_metadata_6 = RoleMetadata() # ansible/playbook/role/metadata.py ==> test_case_6
    role_metadata_7 = RoleMetadata() # ans

# Generated at 2022-06-25 05:58:36.534427
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Define arguments
    role_metadata_load_data = {'allow_duplicates': False, 'dependencies': [], 'galaxy_info': None, 'argument_specs': {}}

    # Construct a model instance of RoleMetadata by calling from_dict on the json representation
    role_metadata_load_model_0 = RoleMetadata.load(role_metadata_load_data, None, None, None)
    assert role_metadata_load_model_0._allow_duplicates is False
    assert role_metadata_load_model_0._dependencies == []
    assert role_metadata_load_model_0._galaxy_info == None
    assert role_metadata_load_model_0._argument_specs == {}



# Generated at 2022-06-25 05:58:40.248069
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    test_data_0 = dict()

    role_metadata_0.deserialize(test_data_0)

# Generated at 2022-06-25 05:58:41.724263
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {}
    metadata = RoleMetadata()
    metadata.deserialize(data)



# Generated at 2022-06-25 05:58:50.082381
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.run_context import RunContext
    from ansible.playbook.task.include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders

    m = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['name=common', 'name=apache'],
        galaxy_info={
            'namespace': 'test_namespace',
            'test_value': 'test_value'
        }
    )

    m.load(data, None)

# Generated at 2022-06-25 05:58:52.690278
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 05:58:54.066274
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:59:01.580750
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_name = 'foo'
    role_data = dict(
        name='foo',
        dependencies={'bar':{}, 'baz':{}},
        allow_duplicates=True,
    )

    role_metadata = RoleMetadata(role_name)
    role_metadata.load(role_data)
    assert role_metadata._dependencies[0].name == 'bar'
    assert role_metadata._dependencies[1].name == 'baz'
    assert role_metadata._allow_duplicates
    assert role_metadata._dependencies[0]._parent == role_metadata
    assert role_metadata._dependencies[1]._parent == role_metadata


# Generated at 2022-06-25 05:59:05.460550
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._owner is None
    assert role_metadata._allow_duplicates is False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info is None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-25 05:59:36.430255
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0, RoleMetadata)

# Generated at 2022-06-25 05:59:39.678564
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # test case 0
    test_case_0()

# Generated at 2022-06-25 05:59:46.007917
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()

    # Load a role_metadata with not a dictionary data
    data = 0
    owner = 1
    variable_manager = 2
    loader = 3
    try:
        role_metadata.load(data, owner, variable_manager, loader)
        assert False
    except AnsibleParserError as e:
        pass

    data = {}
    try:
        role_metadata.load(data, owner, variable_manager, loader)
    except AnsibleParserError as e:
        assert False

# Generated at 2022-06-25 05:59:48.187128
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(dependencies=['foo', 'bar']))


# Generated at 2022-06-25 05:59:50.267927
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()
    #print(role_metadata_0.__dict__)

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 05:59:54.170692
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata_1.allow_duplicates == False
    assert role_metadata_1.dependencies == []


# Generated at 2022-06-25 05:59:57.065634
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}


if __name__ == '__main__':
    test_case_0()
    test_RoleMetadata_serialize()

# Generated at 2022-06-25 05:59:57.715840
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:59:58.797004
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    print(role_metadata_0.serialize())


# Generated at 2022-06-25 06:00:03.669039
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None, 'RoleMetadata constructor returned None'

# Generated at 2022-06-25 06:00:38.553216
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    print(role_metadata_1)


# Generated at 2022-06-25 06:00:44.484824
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()
    assert role_metadata_0._allow_duplicates == role_metadata_1._allow_duplicates
    assert role_metadata_0._dependencies == role_metadata_1._dependencies
    assert role_metadata_0._galaxy_info == role_metadata_1._galaxy_info
    assert role_metadata_0._argument_specs == role_metadata_1._argument_specs
    assert role_metadata_0._owner == role_metadata_1._owner


# Generated at 2022-06-25 06:00:49.979688
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    try:
        # Failing because the below mentioned dictionary ds is not a dictionary.
        role_metadata_0.load({}, {}, {}, {});
    except AnsibleParserError as e:
        print(e)
        pass
    except Exception as e:
        print(e)
        pass
    else:
        print("FAILED")
        pass

# Generated at 2022-06-25 06:00:52.059735
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()


if __name__ == "__main__":
    test_case_0()
    test_RoleMetadata()

# Generated at 2022-06-25 06:01:00.213779
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    # mock some values to return
    role_metadata_0.allow_duplicates = role_metadata_0.dependencies = 'role_metadata_0.dependencies'
    # set the expected return value of deserialize
    expected_res = dict(
        allow_duplicates='role_metadata_0.allow_duplicates',
        dependencies='role_metadata_0.dependencies'
    )
    res = role_metadata_0.deserialize()
    assert res == expected_res


# Generated at 2022-06-25 06:01:03.180093
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }


# Generated at 2022-06-25 06:01:09.016498
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata(owner=None)
    assert role_metadata.serialize() == dict(
        allow_duplicates=role_metadata.allow_duplicates,
        dependencies=role_metadata.dependencies
    )


# Generated at 2022-06-25 06:01:11.319384
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Testing constructor of class RoleMetadata")
    try:
        role_metadata_0 = RoleMetadata()
    except:
        assert False
    assert True


# Generated at 2022-06-25 06:01:15.197706
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    try:
        role_metadata_0.load(None, None)
    except AnsibleParserError as e:
        assert "the 'meta/main.yml' for role None is not a dictionary" in str(e)

# Generated at 2022-06-25 06:01:18.887766
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({
        'allow_duplicates': False,
        'dependencies': []
    })


# Generated at 2022-06-25 06:02:30.719229
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}



# Generated at 2022-06-25 06:02:34.174622
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # TODO: implement test for serialize
    assert False


# Generated at 2022-06-25 06:02:42.005033
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-25 06:02:52.295299
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    test_role = Role()
    test_play = Play()
    test_play._entries = []
    test_role._play = test_play
    test_role._role_name = 'test_role_name'
    test_role._role_path = 'test_role_path'

    # If a Play is not set, the RoleMetadata.deserialize() should fail.
    test_role_metadata = RoleMetadata()
    data = dict()

    try:
        test_role_metadata.deserialize(data)

        assert(False)
    except:
        assert(True)

    # If a Play is set, the RoleMetadata.deserialize() should pass.

# Generated at 2022-06-25 06:02:58.558930
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    mock_owner_0 = Mock()
    mock_owner_0.get_name.return_value = 'Ansible'
    data_0 = {}
    variable_manager_0 = Mock()
    loader_0 = Mock()
    result = role_metadata_0.load(data_0, mock_owner_0, variable_manager_0, loader_0)
    assert result is not None



# Generated at 2022-06-25 06:02:59.313025
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata() is not None

# Generated at 2022-06-25 06:03:02.590078
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(
        allow_duplicates=False,
        dependencies=['common', 'database']
    )
    RoleMetadata.deserialize(data)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:03:08.409411
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'dependencies': ['A', 'B'], 'allow_duplicates': False})
    serialized_data = role_metadata.serialize()
    assert serialized_data == {'dependencies': ['A', 'B'], 'allow_duplicates': False}

# Generated at 2022-06-25 06:03:09.974324
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # create 2 test objects
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = RoleMetadata()



# Generated at 2022-06-25 06:03:16.211285
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_2 = RoleMetadata()
    role_metadata_2.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert not role_metadata_1.allow_duplicates
    assert not role_metadata_2.allow_duplicates


# Generated at 2022-06-25 06:04:48.185655
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    current_dir = os.path.dirname(__file__)
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name="test play",
        hosts='localhost,',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='raw', args='echo "Hi, this is a test"'))
        ]
    )
   

# Generated at 2022-06-25 06:04:58.315020
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Read parameter for unit testing of method load
    test_file = os.path.join(os.path.realpath('../../test/units/module_utils/test_collection_loader/data/meta_main.yaml'), 'meta_main.yaml')
    with open(test_file, 'r') as data:
        params = [data.read(), None]
        role_metadata_0 = RoleMetadata.load(*params)
        # Check if the loaded RoleMetadata is correct
        assert role_metadata_0.dependencies[0] == "galaxy.role,version,name"
        assert role_metadata_0.dependencies[1] == "galaxy.role,version,name"
        assert role_metadata_0.dependencies[2] == "galaxy.role,version,name"
        assert role_metadata_0

# Generated at 2022-06-25 06:05:00.361584
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata(owner=None)

    assert(role_metadata_1 != None)



# Generated at 2022-06-25 06:05:02.999160
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load('role_metadata_main.yml')

# Generated at 2022-06-25 06:05:07.876308
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
   # Test case 0 is above
   role_metadata_1 = RoleMetadata()
   role_metadata_1._allow_duplicates = True
   role_metadata_1._dependencies = ['test/depend/one', 'test/depend/two']
   res_1 = role_metadata_1.serialize()
   assert res_1 == { 'allow_duplicates': True,
                     'dependencies': ['test/depend/one', 'test/depend/two'],
                     'galaxy_info': None }
   role_metadata_2 = RoleMetadata()
   role_metadata_2._allow_duplicates = False
   role_metadata_2._dependencies = ['test/depend/two']
   res_2 = role_metadata_2.serialize()