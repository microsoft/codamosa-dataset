

# Generated at 2022-06-25 05:55:22.188381
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = []
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': []}



# Generated at 2022-06-25 05:55:28.444515
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []
    fields = role_metadata_0._get_fields()
    assert fields['allow_duplicates'].name == 'allow_duplicates'
    assert fields['allow_duplicates'].default == False
    assert fields['allow_duplicates'].isa == 'bool'
    assert fields['dependencies'].name == 'dependencies'
    assert fields['dependencies'].default == []
    assert fields['dependencies'].isa == 'list'
    assert fields['galaxy_info'].name == 'galaxy_info'
    assert fields['galaxy_info'].default == None
    assert fields['galaxy_info'].isa == 'GalaxyInfo'

# Generated at 2022-06-25 05:55:30.697103
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    '''assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}'''


# Generated at 2022-06-25 05:55:42.461869
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-25 05:55:45.504431
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0 is not None
    assert role_metadata_0._data is not None

    role_metadata_1 = RoleMetadata()
    assert role_metadata_1 is not None
    assert role_metadata_1._data is not None

# Generated at 2022-06-25 05:55:47.094184
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = test_case_0()

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 05:55:48.333976
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_mdata = RoleMetadata()
    role_mdata.load({}, None)



# Generated at 2022-06-25 05:55:49.063838
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:55:55.165075
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == dict()


# Generated at 2022-06-25 05:55:56.549844
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    

# Generated at 2022-06-25 05:56:11.373645
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_data = ''
    test_RoleMetadata = RoleMetadata()
    result = test_RoleMetadata.load(test_data, owner='', variable_manager='', loader='')
    assert result == None


# Generated at 2022-06-25 05:56:22.470788
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # create a role_metadata object to run the test
    role_metadata_0 = RoleMetadata()

    # create role_definition dictionary to run the test
    role_definition_0 = dict()

    # initialize role_definition_0['metadata']['allow_duplicates'] with a value
    role_definition_0.setdefault('metadata', dict())['allow_duplicates'] = False

    # initialize role_definition_0['metadata']['dependencies'] with a value
    role_definition_0['metadata']['dependencies'] = []

    # initialize role_definition_0['metadata']['dependencies'][0] with a value
    role_definition_0['metadata']['dependencies'].append(dict())

    # initialize role_definition_0['metadata']['dependencies'][0]['name'] with a value

# Generated at 2022-06-25 05:56:24.158935
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()

    role_metadata_0.deserialize(dict(allow_duplicates=False, dependencies=[]))

# Generated at 2022-06-25 05:56:31.327210
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.__doc__ == '''This class wraps the parsing and validation of the optional metadata\n    within each Role (meta/main.yml).\n    '''
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []


# Generated at 2022-06-25 05:56:35.922223
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {}
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 05:56:41.629439
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_data = dict()
    test_data["allow_duplicates"] = False
    test_data["dependencies"] = []

    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(test_data)


# Generated at 2022-06-25 05:56:45.798490
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()
    #print("The constructor of class RoleMetadata is ok")

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 05:56:49.984331
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    a = RoleMetadata()
    assert a.load(data={"a":1, "b":2}, owner=None) == a


# Generated at 2022-06-25 05:56:51.686831
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-25 05:56:57.173775
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'dependencies': [{'role': 'common', 'some_variable': 42}],
            'allow_duplicates': True,
            }
    meta = RoleMetadata.load(data, 'Johnny')
    assert meta._dependencies[0].role == 'common'

# Generated at 2022-06-25 05:57:18.825567
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Check if object of class RoleMetadata is created or not
    assert  RoleMetadata()



# Generated at 2022-06-25 05:57:22.726205
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    # Setup
    role_metadata_deserialize = RoleMetadata()
    data = dict()
    setattr(role_metadata_deserialize, 'allow_duplicates', data.get('allow_duplicates', False))
    setattr(role_metadata_deserialize, 'dependencies', data.get('dependencies', []))

    # Test
    assert role_metadata_deserialize._allow_duplicates is False
    assert role_metadata_deserialize._dependencies == []


# Generated at 2022-06-25 05:57:24.389213
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    pass

# Generated at 2022-06-25 05:57:34.201424
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata_0 = RoleMetadata(owner=None)
    role_metadata_0._load_dependencies = RoleMetadata._load_dependencies(attr=None, ds=[{'role': 'common', 'tasks_from': 'install.yml'}])
    role_metadata_0._load_galaxy_info = RoleMetadata._load_galaxy_info(attr=None, ds={'description': 'Common tools'})
    role_metadata_0._galaxy_info._author = 'Alan Smith'
    role_metadata_0.allow_duplicates = False
    role_metadata_0._galaxy_info._download_url = 'https://galaxy.example.org/api/v1/roles/common/download/'
    role_metadata_0._galaxy_info._issue_tracker_url

# Generated at 2022-06-25 05:57:37.703060
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert 'allow_duplicates' in role_metadata_0.serialize()
    assert 'dependencies' in role_metadata_0.serialize()


# Generated at 2022-06-25 05:57:40.969588
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    data = dict(
        allow_duplicates='yes',
        dependencies='core.database',
        dependencies='core.webserver'
        #galaxy_info=GalaxyInfo()
    )
    owner=None
    variable_manager=None
    loader=None
    role_metadata_1.load(data, owner, variable_manager, loader)


# Generated at 2022-06-25 05:57:45.083669
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == None
    assert role_metadata_0.galaxy_info == None
    assert role_metadata_0.argument_specs == None

# Generated at 2022-06-25 05:57:51.530957
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({
        'allow_duplicates': False,
        'dependencies': [],
    })
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []



# Generated at 2022-06-25 05:58:00.443387
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({
        'allow_duplicates': True,
        'dependencies': [
            {
                'path': 'collection://my.collection/roles/test_role',
                'src': 'ansible.builtin',
                'scm': 'git',
                'requirements': None,
                'name': 'test_role',
                'version': '1.0',
                'metadata': None,
                'collection': 'my.collection'
            }
        ]
    })
    serialized = role_metadata_0.serialize()

# Generated at 2022-06-25 05:58:01.462254
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_load = RoleMetadata()


# Generated at 2022-06-25 05:58:43.422746
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:58:46.181278
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {
        'dependencies': [],
        'allow_duplicates': False}


# Generated at 2022-06-25 05:58:47.268219
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 05:58:49.784837
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = {"allow_duplicates": False, "dependencies": []}
    role_metadata_0.deserialize(data_0)
    return role_metadata_0


# Generated at 2022-06-25 05:58:54.976167
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(dict(allow_duplicates=True, dependencies=[('127.0.0.1', '127.0.0.1.1')]))


# Generated at 2022-06-25 05:58:57.721901
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0.deserialize(data)

# Generated at 2022-06-25 05:58:59.262113
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 05:59:06.960511
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {
        'allow_duplicates': False,
        'dependencies': [
            {'role': 'geerlingguy.git'}
        ]
    }
    expected = {
        'allow_duplicates': False,
        'dependencies': [
            {'role': 'geerlingguy.git'}
        ]
    }
    result = role_metadata_0.deserialize(data)
    assert result == expected


# Generated at 2022-06-25 05:59:07.788318
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    pass

# Generated at 2022-06-25 05:59:16.336826
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_2 = RoleMetadata()
    #class Owner:
    #    def __init__(self):
    #        pass

    #owner_5 = Owner()
    #class VariableManager:
    #    def __init__(self):
    #        pass

    #variable_manager_6 = VariableManager()
    #class DataLoader:
    #    def __init__(self):
    #        pass

    #loader_7 = DataLoader()
    #data_8 = {
    #    "galaxy_info": "galaxy_info_8",
    #    "dependencies": [
    #        "hubot.xmpp"
    #    ],
    #    "allow_duplicates": False
    #}
    #role_metadata_2.load(data_8, owner_5, variable_

# Generated at 2022-06-25 06:00:40.360219
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    assert meta.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )


# Generated at 2022-06-25 06:00:44.920090
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # data is a string
    # owner is a Role
    # variable_manager is a VariableManager
    # loader is a DataLoader
    # expected_result is a RoleMetadata
    assert True # TODO: implement your test here


# Generated at 2022-06-25 06:00:53.825013
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    try:
        assert role_metadata_0._allow_duplicates == False and isinstance(role_metadata_0._allow_duplicates, bool)
    except AssertionError as e:
        print(e)
    try:
        assert role_metadata_0._dependencies == [] and isinstance(role_metadata_0._dependencies, list)
    except AssertionError as e:
        print(e)
    try:
        assert role_metadata_0._galaxy_info == None
    except AssertionError as e:
        print(e)
    data = {"allow_duplicates": False, "dependencies": []}
    role_metadata_0.deserialize(data)

# Generated at 2022-06-25 06:00:58.789480
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data={}
    test_value={
        'allow_duplicates': False,
        'dependencies': []
    }
    role_metadata_0.deserialize(data=data)
    assert(role_metadata_0.serialize() == test_value)


# Generated at 2022-06-25 06:01:02.114153
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-25 06:01:08.787177
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.yaml.objects import AnsibleMapping
    role_metadata = RoleMetadata()
    role_metadata_load = role_metadata.load(AnsibleMapping(),
                                            None,
                                            None,
                                            None)
    assert isinstance(role_metadata_load, RoleMetadata)

# Generated at 2022-06-25 06:01:18.613412
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-25 06:01:23.107627
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    # Test if parameters can be deserialized properly
    deserialize_data_0_expected = {'dependencies': [], 'allow_duplicates': False}
    assert role_metadata_0.deserialize(deserialize_data_0_expected) == None


# Generated at 2022-06-25 06:01:29.350921
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a new instance of RoleMetadata
    role_metadata = RoleMetadata()
    # Test if an empty dictionary is returned
    assert role_metadata.deserialize({}) is None
    # Test if the dictionary is returned
    assert role_metadata.deserialize(dict(a=1, b=2)) is None
    assert role_metadata.a == 1 and role_metadata.b == 2
    # Test if the dictionary is returned
    assert role_metadata.deserialize(dict(a=1, b=2, c=3)) is None
    assert role_metadata.a == 1 and role_metadata.b == 2 and role_metadata.c == 3
    # Test if an exception is raised

# Generated at 2022-06-25 06:01:30.984022
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )

# Generated at 2022-06-25 06:03:01.258269
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()



# Generated at 2022-06-25 06:03:04.083009
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_object = RoleMetadata()
    role_metadata_dict = role_metadata_object.serialize()
    assert isinstance(role_metadata_dict, dict)

# Generated at 2022-06-25 06:03:09.673194
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()

    # Run method load on argument data.
    # Note: The default arguments of load are not used.
    #delete role_metadata_0.load  # comment out this line to test load
    try:
        result = role_metadata_0.load()
    except Exception as e:
        print('Exception: {}'.format(e))
    else:
        print('No exception')


# Generated at 2022-06-25 06:03:15.059286
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    print('In test_RoleMetadata_load')
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load(ds=None, owner=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 06:03:19.476829
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    # test with a valid RoleMetadata
    try:
        role_metadata_1 = RoleMetadata()
    except:
        raise AssertionError("Test 1: expected successful construction of class RoleMetadata.")

    # test with invalid arguments
    try:
        role_metadata_2 = RoleMetadata('bad arg')
        raise AssertionError("Test 2: expected failed construction of class RoleMetadata.")
    except:
        pass

# Test to ensure that the code handles the correct input for constructor of class RoleMetadata
# This test should succeed and print nothing.

# Generated at 2022-06-25 06:03:25.282863
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0._allow_duplicates == False
    assert role_metadata_0._dependencies == []
    assert role_metadata_0._galaxy_info == None
    assert role_metadata_0._argumen

# Generated at 2022-06-25 06:03:28.695038
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = ['a', 'b']
    role_metadata = role_metadata.load(data, None)

# Generated at 2022-06-25 06:03:30.621144
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = {}
    role_metadata_0.deserialize(data_0)


# Generated at 2022-06-25 06:03:32.775362
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {"allow_duplicates": False, "dependencies": []}
    metadata = RoleMetadata()
    assert metadata.deserialize(data) == None


# Generated at 2022-06-25 06:03:34.695816
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialize_0 = role_metadata_0.serialize()
    assert serialize_0['allow_duplicates'] == False
    assert serialize_0['dependencies'] == []
