

# Generated at 2022-06-25 05:55:30.884279
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()

    # test failure on non-dictionary
    try:
        role_metadata._load_dependencies('dependencies', None)
        assert False
    except AnsibleParserError:
        pass

    # test failure on value not string
    try:
        role_metadata._load_dependencies('dependencies', [1])
        assert False
    except AnsibleParserError:
        pass

    # test failure on value not string
    try:
        role_metadata._load_dependencies('dependencies', [{'name': 1}])
        assert False
    except AnsibleParserError:
        pass

    # test failure on value not string
    try:
        role_metadata._load_dependencies('dependencies', [{'role': 1}])
        assert False
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 05:55:33.581785
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    expected_0 = {'allow_duplicates': False, 'dependencies': []}
    actual_0 = role_metadata_0.serialize()
    assert actual_0 == expected_0


# Generated at 2022-06-25 05:55:37.456174
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    result = role_metadata_0.serialize()
    expected = {u'dependencies': [], u'allow_duplicates': False}
    assert result == expected


# Generated at 2022-06-25 05:55:45.201648
# Unit test for constructor of class RoleMetadata

# Generated at 2022-06-25 05:55:51.265837
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data_0 = dict()
    data_0['allow_duplicates'] = False
    data_0['dependencies'] = []
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data=data_0)
    # Verify that the Data Structure has a valid size
    assert(len(data_0) == 2)
    # Verify that the method deserialize works as expected
    assert(role_metadata_0._allow_duplicates == False)
    assert(role_metadata_0._dependencies == [])
    assert(role_metadata_0._galaxy_info is None)
    assert(role_metadata_0._argument_specs == {})


# Generated at 2022-06-25 05:55:59.010321
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': 'true',
        'dependencies': [
                            {
                                'name': 'rolename',
                                'role': 'rolename'
                            }
                        ]
    }
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize(data)
    assert role_metadata_1._dependencies[0] == {'name': 'rolename', 'role': 'rolename'}
    assert role_metadata_1._allow_duplicates == True


# Generated at 2022-06-25 05:56:03.618849
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    # Should load dict data
    data = dict()
    assert(type(role_metadata_0.load(data, None)) == RoleMetadata)
    # Should raise AnsibleParserError exception
    data = 0
    try:
        role_metadata_0.load(data, None)
        assert(False)
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 05:56:05.872134
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    obj_0 = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata_0.deserialize(obj_0)

# Generated at 2022-06-25 05:56:06.480447
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-25 05:56:12.783700
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()

    # caller is responsible for serializing dependencies
    if role_metadata_0.dependencies:
        role_metadata_0.dependencies = role_metadata_0.dependencies.serialize()

    returned_0 = role_metadata_0.serialize()
    assert returned_0 == {'dependencies': [], 'allow_duplicates': False}


# Generated at 2022-06-25 05:56:21.926429
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Instaniate a RoleMetadata Object
    role_metadata = RoleMetadata()
    # Loads a RoleMetadata object from data, returns None
    role_metadata.load(data, owner, variable_manager, loader)


# Generated at 2022-06-25 05:56:25.000386
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta_data = dict()
    meta_data['dependencies'] = dict()
    meta_data['allow_duplicates'] = True
    role_data = dict()
    role_data['test_role'] = dict()
    test_object = RoleMetadata(role_data)

# Generated at 2022-06-25 05:56:27.704090
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_case_0()

# Generated at 2022-06-25 05:56:33.455377
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    result = role_metadata.serialize()

    assert 'allow_duplicates' in result
    assert result['allow_duplicates'] == False
    assert 'dependencies' in result
    assert result['dependencies'] == []


# Generated at 2022-06-25 05:56:34.547306
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test = load([], None)
    assert test._ds == []


# Generated at 2022-06-25 05:56:40.834476
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({})
    assert role_metadata_1._allow_duplicates == False
    assert role_metadata_1._dependencies == []
    role_metadata_2 = RoleMetadata()
    role_metadata_2.deserialize({'allow_duplicates': False, 'dependencies': []})
    assert role_metadata_2._allow_duplicates == False
    assert role_metadata_2._dependencies == []
    role_metadata_3 = RoleMetadata()
    role_metadata_3.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert role_metadata_3._allow_duplicates == True
    assert role_metadata_3._dependencies == []
    role_metadata_4 = RoleMet

# Generated at 2022-06-25 05:56:49.877481
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-25 05:56:53.907473
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = []

    serialized_role_metadata = role_metadata.serialize()
    assert serialized_role_metadata['allow_duplicates'] == True
    assert serialized_role_metadata['dependencies'] == []

# Generated at 2022-06-25 05:56:57.544141
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialized_0 = role_metadata_0.serialize()
    test_0 = serialized_0 == {'allow_duplicates': False, 'dependencies': []}
    assert test_0


# Generated at 2022-06-25 05:57:01.771472
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data={'allow_duplicates': False, 'dependencies': []})

# Generated at 2022-06-25 05:57:14.089897
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert test_case_0() == None

# Generated at 2022-06-25 05:57:16.457815
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    result = role_metadata.serialize()
    expected = {'allow_duplicates': False,
                'dependencies': []}
    assert result == expected


# Generated at 2022-06-25 05:57:22.333832
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    data = {
        'allow_duplicates': True,
        'dependencies': [],
        'galaxy_info': {},
        'argument_specs': {}
    }
    owner = ''
    variable_manager = ''
    loader = ''
    r = RoleMetadata.load(data, owner, variable_manager, loader)
    assert r is not None


# Generated at 2022-06-25 05:57:29.907566
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load(data={"name": "gocd", "description": "gocd server/agent", "dependencies": []}, owner=None, variable_manager=None, loader=None)
    role_metadata_0.load_data(data={"name": "gocd", "description": "gocd server/agent", "dependencies": []}, variable_manager=None, loader=None)


# Testing for the RoleMetadata class
# Creating an object
role_metadata_0 = RoleMetadata()

# Testing for the load class method
role_metadata_0.load(data={"name": "gocd", "description": "gocd server/agent", "dependencies": []}, owner=None, variable_manager=None, loader=None)
# Testing

# Generated at 2022-06-25 05:57:30.286843
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-25 05:57:33.041821
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        role_metadata_0 = RoleMetadata()
    except Exception as err:
        print(err)
        traceback.print_exc()
        assert(False)
    assert(isinstance(role_metadata_0, RoleMetadata))


# Generated at 2022-06-25 05:57:34.044768
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:57:36.298886
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(dict(dependencies=None, allow_duplicates=False))



# Generated at 2022-06-25 05:57:41.789614
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata.load({'init_msgs': ['welcome'],
        'allow_duplicates': False, 'dependencies': ['hello']})
    assert role_metadata_1._allow_duplicates == False
    assert role_metadata_1._dependencies == ['hello']
    assert role_metadata_1.init_msgs == ['welcome']



# Generated at 2022-06-25 05:57:46.004560
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create test object
    role_metadata = RoleMetadata()
    # RoleMetadata.serialize()
    x = role_metadata.serialize()
    assert x == {'allow_duplicates': False, 'dependencies': []}, \
        f"Failed to serialize object: expected {x}, got {x}"


# Generated at 2022-06-25 05:58:10.144328
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_data_0 = {}
    role_metadata_0.deserialize(role_metadata_data_0)


# Generated at 2022-06-25 05:58:19.096284
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.allow_duplicates is False
    assert role_metadata.dependencies == []
    assert role_metadata.galaxy_info == {}
    assert role_metadata.argument_specs == {}
    assert role_metadata.collection == None
    assert role_metadata.collection_list is None
    assert len(role_metadata.attribute_list) == 7
    assert role_metadata.collection_list is None
    assert role_metadata.collection_list is None
    assert role_metadata.collection_list is None
    assert role_metadata.collection_list is None
    assert role_metadata.collection_list is None

# Generated at 2022-06-25 05:58:20.666114
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert (role_metadata_0 != None)



# Generated at 2022-06-25 05:58:26.342975
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create a instance of the class RoleMetadata
    r = RoleMetadata()
    # Create a temp attribute so that the test can run without error
    r.dependencies = [
        {
            "role": "collection.dependency-role"
        }
    ]
    # Verify that the serialization of RoleMetadata is correct
    assert r.serialize() == {'dependencies': [{'role': 'collection.dependency-role'}], 'allow_duplicates': False}


# Generated at 2022-06-25 05:58:31.233485
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == dict(
            allow_duplicates=False,
            dependencies=[]
        )


# Generated at 2022-06-25 05:58:33.301262
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 05:58:34.790415
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:58:40.210852
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    retval = role_metadata_0.load(data=None, owner=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 05:58:43.847477
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = {'src': 'galaxy.role', 'other_vars': 'here'}
    role_metadata.serialize()


# Generated at 2022-06-25 05:58:44.896866
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-25 05:59:36.689179
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

if __name__ == '__main__':
    import os
    import sys
    import unittest

    def test_suite():
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(TestRoleMetadata))
        return suite


    base_dir = os.path.dirname(__file__)
    sys.path.append(os.path.join(base_dir, "../lib"))
    try:
        from ansible.utils.display import Display
        display = Display()
    except ImportError:
        pass

    verbosity = 2

    unittest.main(verbosity=verbosity, failfast=True, buffer=False)

# Generated at 2022-06-25 05:59:37.782245
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 05:59:42.486811
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    try:
        role_metadata_1 = RoleMetadata.load("something", {}, {})
        assert False, "Should not reach here"
    except AnsibleParserError:
        role_metadata_1 = None

    role_metadata_2 = RoleMetadata.load({}, {}, {})
    assert role_metadata_2 is not None


# Generated at 2022-06-25 05:59:45.548129
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:59:54.319176
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.base import Base
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.vars.manager import VariableManager

    try:
        # TEST CASE: RoleMetadata deserialize raises TypeError given 'data' parameter of wrong type
        # DESCRIPTION: The method deserialize of the class RoleMetadata raises TypeError when the 'data' parameter is not of type dict
        # EXPECTED RESULT: The method deserialize raises TypeError
        role_metadata_0 = RoleMetadata()
        role_metadata_0.deserialize(data = [])
        assert False
    except TypeError:
        assert True
    except Exception:
        assert False

    # TEST CASE: RoleMetadata deserialize given only 'data' parameter

# Generated at 2022-06-25 05:59:57.687530
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    str(role_metadata_0.serialize())


# Generated at 2022-06-25 05:59:59.524957
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    print(role_metadata_0.serialize())

if __name__ == '__main__':
    test_case_0()
    test_RoleMetadata_serialize()

# Generated at 2022-06-25 06:00:04.991385
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    result_0_0 = role_metadata_0.serialize()
    assert result_0_0 == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 06:00:09.465710
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = {}
    role_metadata_0.deserialize(data_0)
    data_1 = {'dependencies': []}
    role_metadata_0.deserialize(data_1)
    data_2 = {'dependencies': [], 'allow_duplicates': False}
    role_metadata_0.deserialize(data_2)


# Generated at 2022-06-25 06:00:14.925464
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({
        "allow_duplicates": False,
        "dependencies": []
    })


# Generated at 2022-06-25 06:01:49.675789
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0._allow_duplicates == False
    assert role_metadata_0._dependencies == []
    assert role_metadata_0._galaxy_info == None
    assert role_metadata_0._argument_specs == {}

# Generated at 2022-06-25 06:01:54.209680
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # deserialize code
    test_RoleMetadata = RoleMetadata()

# Generated at 2022-06-25 06:01:55.219234
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata.load({}, None)



# Generated at 2022-06-25 06:01:57.404574
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'allow_duplicates': False, 'dependencies': [{'role': 'dependency_role_1'}, {'role': 'dependency_role_2'}]})


# Generated at 2022-06-25 06:01:58.772711
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0, RoleMetadata)



# Generated at 2022-06-25 06:02:04.623086
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    data = {'dependencies': 'dependencies', 'allow_duplicates': 'allow_duplicates'}
    owner = 'owner'
    variable_manager = 'variable_manager'
    loader = 'loader'
    try:
        RoleMetadata.load(data, owner, variable_manager, loader)
    except Exception as exception:
        print ('Exception: ' + str(exception))
    else:
        print ('Excepted exception')
        raise Exception('Exception not raised')


# Generated at 2022-06-25 06:02:11.619266
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.galaxy_info = None
    role_metadata_1.dependencies = [{'role': 'test_name_2'}]
    role_metadata_1.allow_duplicates = False

    assert role_metadata_1.serialize() == {'dependencies': [{'role': 'test_name_2'}], 'allow_duplicates': False}

    role_metadata_1.galaxy_info = None
    role_metadata_1.dependencies = [{'role': 'test_name_2'}]
    role_metadata_1.allow_duplicates = True


# Generated at 2022-06-25 06:02:19.368042
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_init = RoleMetadata()
    try:
        role_metadata_init.load(
            {'dependencies': ['role1', 'role2'],
             'allow_duplicates': False
             }
        )
    except Exception as e:
        # TODO: what exception should be catched here?
        assert False, "Raised an exception: " + str(e)



# Generated at 2022-06-25 06:02:20.515738
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.serialize()

# Generated at 2022-06-25 06:02:27.157952
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()