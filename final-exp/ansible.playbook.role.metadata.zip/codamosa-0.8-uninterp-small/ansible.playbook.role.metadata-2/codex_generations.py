

# Generated at 2022-06-25 05:55:19.127946
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata


# Generated at 2022-06-25 05:55:26.460246
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    owner = {}

    # Pass in data, owner, and variable_manager
    actual_result = RoleMetadata.load(data, owner)
    actual_result_0 = actual_result.serialize()
    assert actual_result_0 == data, 'Expected: {} Got: {}'.format(data, actual_result_0)

    # Pass in data, owner, variable_manager, and loader
    actual_result = RoleMetadata.load(data, owner, variable_manager={})
    actual_result_0 = actual_result.serialize()
    assert actual_result_0 == data, 'Expected: {} Got: {}'.format(data, actual_result_0)


# Generated at 2022-06-25 05:55:28.415777
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    result = role_metadata.deserialize(dict(allow_duplicates=False, dependencies=[]))
    assert result == None


# Generated at 2022-06-25 05:55:31.334202
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # setup data
    role_metadata_0 = RoleMetadata()
    # Unit test for method serialize of class RoleMetadata
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:55:33.897514
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    result = role_metadata.serialize()
    assert len(result) == 2


# Generated at 2022-06-25 05:55:37.996284
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_case_0()
    role_metadata = RoleMetadata()
    role_metadata.deserialize({ 'allow_duplicates' : True, 'dependencies' : False})
    serialize_ret = role_metadata.serialize()
    assert(serialize_ret == {})

# Generated at 2022-06-25 05:55:39.736084
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_0_0 = role_metadata_0.serialize()
    print(test_0_0)


# Generated at 2022-06-25 05:55:42.093437
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_obj_1 = RoleMetadata()

# Generated at 2022-06-25 05:55:45.429357
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    data = dict(
        dependencies = [dict(
                            name='geerlingguy.java',
                            version='1.8'
                            )
                       ],
    )

    role_metadata.load(data, None, None)

# Generated at 2022-06-25 05:55:47.378909
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_2 = RoleMetadata()
    role_metadata_2.deserialize(role_metadata_1.serialize())

# Generated at 2022-06-25 05:55:56.011624
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata.load(ds, owner=owner)

# Generated at 2022-06-25 05:55:58.426303
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
  # Load RoleMetadata
  obj = RoleMetadata()
  data = {'dependencies': [], 'allow_duplicates': False}
  obj.load(data, None)


# Generated at 2022-06-25 05:56:06.534216
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    data = dict(
        galaxy_info = dict(
            author = "aaron",
            description = "aaron's role",
            company = "ACME"
        ),
        dependencies = dict(
            soft = dict(
                role = dict(
                    name = "common",
                    version = "1"
                )
            ),
            hard = dict(
                role = dict(
                    name = "special_user",
                    src = "roles/special_user",
                    version = "2",
                    scm = dict(
                        repo = "http://scm.example.com/roles/special_user.git",
                        branch = "dev",
                        version = "1.1.0"
                    )
                )
            )
        )
    )
    # There

# Generated at 2022-06-25 05:56:11.416116
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd = RoleMetadata()
    rmd.deserialize(dict(
        dependencies=[dict(rolename='test1')]
    ))
    assert rmd.serialize() == dict(
        dependencies=[dict(rolename='test1')]
    )



# Generated at 2022-06-25 05:56:14.466655
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in test case for constructor for class RoleMetadata", e)


if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 05:56:18.761567
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    res = role_metadata_1.load({})
    assert res == role_metadata_1

# Generated at 2022-06-25 05:56:23.450757
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {
        'dependencies': [{'role': 'some_role'}],
        'allow_duplicates': True,
    }
    role_metadata.deserialize(data)
    assert role_metadata._dependencies == data['dependencies']
    assert role_metadata.allow_duplicates == data['allow_duplicates']


# Generated at 2022-06-25 05:56:31.682720
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()
    role_metadata.load(dict(galaxy_info=dict(author="Tester", min_ansible_versio=2.4)), "TestPlay.yml")
    assert role_metadata.serialize() == dict(galaxy_info=dict(author="Tester", min_ansible_versio=2.4), allow_duplicates=False, dependencies=[])

# Generated at 2022-06-25 05:56:36.181784
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0._loader is not None
    assert role_metadata_0._variable_manager is not None

# Generated at 2022-06-25 05:56:41.626404
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_data_0 = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(role_metadata_data_0)


# Generated at 2022-06-25 05:56:49.593876
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert isinstance(role_metadata_0, RoleMetadata)


# Generated at 2022-06-25 05:56:53.973650
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print('Testing method deserialize of class RoleMetadata...')
    print()

    role_metadata_0 = RoleMetadata()
    data_0 = {"allow_duplicates": False, "dependencies": []}
    result_0 = role_metadata_0.deserialize(data_0)
    print("Deserialized role metadata successfully!")
    print()


# Generated at 2022-06-25 05:57:00.658877
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    from ansible.playbook.role.definition import RoleDefinition
    owner = RoleDefinition()
    owner._role_name = 'name'
    owner._role_path = 'path'
    role_metadata_0._owner = owner
    role_metadata_0.allow_duplicates = False
    role_metadata_0.dependencies = ['name']
    role_metadata_serialize_0 = role_metadata_0.serialize()
    assert role_metadata_serialize_0 == {'dependencies': ['name'], 'allow_duplicates': False}, "Test Failed! Actual output is as follows:\n" + str(role_metadata_serialize_0)


# Generated at 2022-06-25 05:57:03.586235
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    metadata_0 = {'dependencies': [], 'allow_duplicates': False}
    role_metadata_0.deserialize(metadata_0)


# Generated at 2022-06-25 05:57:06.142744
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata(owner=_Role())
    role_metadata_0.deserialize(data={"dependencies": [], "allow_duplicates": False})


# Generated at 2022-06-25 05:57:13.949657
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    role_metadata_2 = role_metadata_1.load({'dependencies':[{'role':'tomcat','version':'1.0.0'},
                                     {'role':'ntp', 'version':'1.0.0'} ]})
    assert role_metadata_2.dependencies[0].role_name == 'tomcat'
    assert role_metadata_2.dependencies[0].role_version == '1.0.0'
    assert role_metadata_2.dependencies[1].role_name == 'ntp'
    assert role_metadata_2.dependencies[1].role_version == '1.0.0'


# Generated at 2022-06-25 05:57:15.379853
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({})


# Generated at 2022-06-25 05:57:20.564675
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata(owner=None)
    role_metadata_0._load_data = Mock(return_value = None)
    role_metadata_0._load_dependencies = Mock(return_value = None)
    role_metadata_0._load_galaxy_info = Mock(return_value = None)
    role_metadata_0.deserialize(data=None)
    assert str(role_metadata_0.deserialize.__doc__) == 'Loads role metadata from a dictionary.'



# Generated at 2022-06-25 05:57:23.213015
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialized_str_0 = str(role_metadata_0.serialize())
    assert serialized_str_0 == "{'dependencies': [], 'allow_duplicates': False}"


# Generated at 2022-06-25 05:57:24.773603
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.loader is None


# Generated at 2022-06-25 05:57:36.098014
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta_data = dict(include_tasks='main.yml')
    role_metadata = RoleMetadata.load(meta_data, None)


# Generated at 2022-06-25 05:57:39.712781
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    role_metadata_1 = RoleMetadata()

    data_1 =  {
        "dependencies": ["common", "webservers", {"role": "foobar", "some_var": "blah"} ],
        "allow_duplicates": True
    }
    # testing load of role_metadata with data_1
    role_metadata_1.load(data_1, role_metadata_1)


# Generated at 2022-06-25 05:57:45.995819
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create and initialize an object of class RoleMetadata
    role_metadata_1 = RoleMetadata()
    role_metadata_1._dependencies = [ "apache", "postgres", "tomcat" ]
    role_metadata_1._allow_duplicates = True
    # Serialize object
    result = role_metadata_1.serialize()
    assert result == { 'allow_duplicates': True, 'dependencies': [ 'apache', 'postgres', 'tomcat' ] }


# Generated at 2022-06-25 05:57:52.362289
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({
        'allow_duplicates': True,
        'dependencies': []
    })
    assert role_metadata.allow_duplicates == True, "Accepts allow_duplicates"
    assert role_metadata.dependencies == [], "Accepts dependencies"


# Generated at 2022-06-25 05:57:59.697179
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    count = 0
    for x in [RoleMetadata().deserialize(dict(allow_duplicates=False,
                                              dependencies=[])),
              RoleMetadata().deserialize(dict(allow_duplicates=False,
                                              dependencies=[dict(role="role_name")])),
              RoleMetadata().deserialize(dict(allow_duplicates=True,
                                              dependencies=[dict(role="role_name"),
                                                            dict(role="role_name2")]))
              ]:
        count += 1
    assert(count == 3)



# Generated at 2022-06-25 05:58:07.639660
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    # test case 0
    data_0 = dict(allow_duplicates=False, dependencies=[])
    # test case 1
    owner_1 = dict(name='galaxy', path='/home/cts2/.ansible/collections/ansible_collections/dummy/roles')
    variable_manager_1 = dict(vars_cache={}, host_vars={}, group_vars={})
    data_1 = dict(allow_duplicates=False, dependencies=[])
    role_metadata_2 = role_metadata_1.load(data_1, owner_1, variable_manager_1)
    # test case 2

# Generated at 2022-06-25 05:58:08.787204
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.allow_duplicates == False

# Generated at 2022-06-25 05:58:10.752687
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({'allow_duplicates': False, 'dependencies': []})



# Generated at 2022-06-25 05:58:15.240843
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize( {} )

# Generated at 2022-06-25 05:58:16.898378
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize('allow_duplicates')


# Generated at 2022-06-25 05:58:26.775124
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({'allow_duplicates': True, 'dependencies': []})
    assert role_metadata_0.serialize() == dict(allow_duplicates=True, dependencies=[])

# Generated at 2022-06-25 05:58:29.673813
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r0 = RoleMetadata()
    print(r0)


# Generated at 2022-06-25 05:58:35.417814
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    # This is the data to be tested
    test_dict = {}
    with pytest.raises(AnsibleParserError):
        role_metadata_0.load(test_dict, role_metadata_0)


# Generated at 2022-06-25 05:58:42.890917
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0 is not None
    assert role_metadata_0._owner == None
    assert role_metadata_0._allow_duplicates == False
    assert role_metadata_0._dependencies == []
    assert role_metadata_0._galaxy_info == None
    assert role_metadata_0._argument_specs == {}
    # Create a role_include_0 object and set name and role_name
    role_include_0 = RoleRequirement()
    role_include_0.name = 'suricata'
    role_include_0.role_name = 'suricata'
    role_include_0.role_collection = None
    # Create a play_0 object and append role_include_0 to play_

# Generated at 2022-06-25 05:58:46.631829
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': True, 'dependencies': None}
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == None


# Generated at 2022-06-25 05:58:47.449220
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 05:58:48.260374
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()

# Generated at 2022-06-25 05:58:59.761482
# Unit test for method deserialize of class RoleMetadata

# Generated at 2022-06-25 05:59:11.001291
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data0 = dict()
    ansible_parser_error_expected = False
    try:
        role_metadata_0 = RoleMetadata.load(data0, None, None, None)
    except AnsibleParserError as e:
        ansible_parser_error_expected = True
        assert ansible_parser_error_expected
    assert ansible_parser_error_expected

# Generated at 2022-06-25 05:59:14.578392
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    RoleMetadata: load
    '''

    role_metadata_obj = RoleMetadata()

    test_data_0 = dict()
    current_play_0 = dict()

    role_metadata_obj.load(test_data_0, current_play_0)

    assert role_metadata_obj is not None



# Generated at 2022-06-25 05:59:29.356456
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.deserialize({"allow_duplicates": True, "dependencies": ["Err"]})


# Generated at 2022-06-25 05:59:31.265446
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()


# Generated at 2022-06-25 05:59:37.694923
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = 10
    role_metadata._dependencies = [10, 20]
    assert role_metadata.serialize() == {"allow_duplicates":10, "dependencies":[10, 20]}


# Generated at 2022-06-25 05:59:41.296012
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = dict()
    try:
        role_metadata_0.deserialize(data)
    except TypeError:
        assert False


# Generated at 2022-06-25 05:59:50.056244
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    
    # Verify that the instance of class RoleMetadata is the same
    assert role_metadata_0.__class__ == RoleMetadata # Verify that the instance of class RoleMetadata is the same
    assert isinstance(role_metadata_0, RoleMetadata) # Verify that the instance of class RoleMetadata is the same
    assert issubclass(RoleMetadata, object) # Verify that the instance of class RoleMetadata is the same
    assert role_metadata_0 != object # Verify that the instance of class RoleMetadata is the same
    assert role_metadata_0.__doc__ == '''\n    This class wraps the parsing and validation of the optional metadata\n    within each Role (meta/main.yml).\n    '''
    assert role_metadata_0.__init__.__defaults

# Generated at 2022-06-25 05:59:51.680741
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata=RoleMetadata(owner=Role)


# Generated at 2022-06-25 05:59:57.937037
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # load empty role
    role_metadata_0 = RoleMetadata.load(None, None)
    assert role_metadata_0.allow_duplicates == False
    assert role_metadata_0.dependencies == []
    assert role_metadata_0.galaxy_info == None
    assert role_metadata_0.argument_specs == {}

    # load role with metadata
    # use real data, so the test can catch any changes
    # only check the meta main.yml file.
    # The test should pass even if the shape of the role changes.

# Generated at 2022-06-25 06:00:09.068796
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 06:00:14.517246
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = { 'dependencies': [], 'allow_duplicates': False }
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 06:00:15.997548
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata != None


# Generated at 2022-06-25 06:00:34.772420
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._dependencies = [
        {
            "name": "common",
            "src": "example.com",
            "scm": "git",
            "ver": "v1.0",
            "path": "/etc/ansible/roles"
        }
    ]
    role_metadata._allow_duplicates = True
    assert role_metadata.serialize() == {
        'dependencies': [
            {
                "name": "common",
                "src": "example.com",
                "scm": "git",
                "ver": "v1.0",
                "path": "/etc/ansible/roles"
            }
        ],
        'allow_duplicates': True
    }


# Generated at 2022-06-25 06:00:35.996481
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert isinstance(RoleMetadata(), RoleMetadata)


# Generated at 2022-06-25 06:00:37.699591
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.serialize()


# Generated at 2022-06-25 06:00:46.390062
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class Role:
        def __init__(self, role_path, role_name):
            self._role_path = role_path
            self.name = role_name

    role_metadata_0 = RoleMetadata()
    role_metadata_0._owner = Role(role_path='test/test_data/test_playbooks/play_0/roles/role_0', role_name='role_0')
    with open('test/test_data/test_meta/meta_main_0.yml', 'r') as stream:
        data = yaml.load(stream)
    print(type(data))
    for k,v in data.items():
        print(k, type(k))

# Generated at 2022-06-25 06:00:54.689067
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # set up metadata
    metadata = {
        'allow_duplicates': False,
        'dependencies': [
            {
                'role': 'apache',
                'another_var': 'somevalue'
            },
            'nginx'
        ]
    }

    # create RoleMetadata object
    role_metadata = RoleMetadata()
    role_metadata.deserialize(metadata)

    # create play
    play = FakePlay()

    # create loader
    loader = FakeLoader()

    # create variable manager
    variable_manager = FakeVariableManager()

    # create RoleMetadata object from data structure
    role_metadata = RoleMetadata.load(metadata,
                                      owner=play,
                                      variable_manager=variable_manager,
                                      loader=loader)

    # check allow_duplicates

# Generated at 2022-06-25 06:01:02.664401
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_instance = RoleMetadata()

    assert role_metadata_instance is not None, 'Unable to create an instance of RoleMetadata'
    assert isinstance(role_metadata_instance, RoleMetadata), 'Expected an instance of RoleMetadata'

    results = role_metadata_instance.serialize()
    assert results is not None, 'Expected a valid serialization of an instance of RoleMetadata'
    assert results == dict(
        allow_duplicates=False,
        dependencies=[]
    )



# Generated at 2022-06-25 06:01:08.492818
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = dict(
        allow_duplicates=True,
        dependencies=list()
    )
    role_metadata_0.deserialize(data=data_0)


# Generated at 2022-06-25 06:01:18.614266
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # In this test we load a RoleMetadata structure from a file. The
    # file is in the tests directory in the ansible repo and
    # is called "meta_main.yml"

    # Import the fixtures directory to find the file we are using
    # for the test
    import tests.fixtures
    # Load the file as a data structure
    test_meta = tests.fixtures.load_fixture_file("meta_main.yml")
    # Make sure that it is a dictionary
    assert isinstance(test_meta, dict) == True
    # Check that certain keys are in the dictionary
    assert isinstance(test_meta['dependencies'], list) == True
    assert isinstance(test_meta['galaxy_info'].get('platforms', ''), list) == True
    # The platforms list should contain a dictionary with a

# Generated at 2022-06-25 06:01:21.780793
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    serialized_0 = role_metadata_0.serialize()
    assert serialized_0['allow_duplicates'] == False
    assert serialized_0['dependencies'] == []


# Generated at 2022-06-25 06:01:22.372644
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-25 06:01:53.769341
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 06:01:56.717392
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {'allow_duplicates': False, 'dependencies': []}
    role_metadata_0.deserialize(data)
    assert(False == role_metadata_0._allow_duplicates)
    assert([]) == role_metadata_0._dependencies


# Generated at 2022-06-25 06:02:01.163858
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.serialize()


# Generated at 2022-06-25 06:02:09.008678
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test data
    data = dict(
        dependencies=[dict(
            collection='collection'
        )],
        allow_duplicates=True
    )

    # Test
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(data=data)

    # Assertions
    assert role_metadata_0.get_name() is None
    assert role_metadata_0.dependencies[0].get_name() == 'collection'


# Generated at 2022-06-25 06:02:17.074093
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create the object instance
    role_metadata_0 = RoleMetadata()

    # An empty dict
    data = dict()
    role_metadata_0.deserialize(data)

    # result:
    #     allow_duplicates: False
    #     dependencies: []

    # Create the object instance
    role_metadata_1 = RoleMetadata()

    # A dict with one attribute
    data = dict(
        allow_duplicates=True)
    role_metadata_1.deserialize(data)

    # result:
    #     allow_duplicates: True
    #     dependencies: []

    # Create the object instance
    role_metadata_2 = RoleMetadata()

    # A dict with one attribute
    data = dict(
        dependencies=list())

# Generated at 2022-06-25 06:02:19.566065
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.load(data=dict(), owner=object(), variable_manager=object(), loader=object()) == role_metadata_0


# Generated at 2022-06-25 06:02:22.335097
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert (isinstance(RoleMetadata(), RoleMetadata))

# Generated at 2022-06-25 06:02:25.505664
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata('ansible.michael.dehaan')
    data = role_metadata.serialize()
    assert data['allow_duplicates'] == False
    assert data['dependencies'] == []


# Generated at 2022-06-25 06:02:31.611733
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    RoleMetadata load()
    """

    # First Pass Case where the metadata should be parsed successfully
    role_metadata_0 = RoleMetadata()
    role_metadata_0.load(dict(
        allow_duplicates = True,
        dependencies = [
            dict(
                name = 'test_role',
                src = 'https://github.com/example/test_role',
                scm = 'git',
                version = 'master',
            )
        ]
    ), None, None)
    assert role_metadata_0.allow_duplicates is True
    assert len(role_metadata_0.dependencies) == 1


# Generated at 2022-06-25 06:02:34.643492
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test = RoleMetadata()
    test.deserialize({'dependencies': 'test_value'})



# Generated at 2022-06-25 06:02:59.243046
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 06:03:03.191046
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    data_0 = dict(allow_duplicates=True, dependencies=['dependency_0'])
    variable_manager = 'variable_manager'
    owner = 'owner'
    loader = 'loader'
    RoleMetadata.load(data_0, owner, variable_manager, loader)


# Generated at 2022-06-25 06:03:05.287993
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_case_0()

# Generated at 2022-06-25 06:03:05.796090
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-25 06:03:11.362463
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta = [{'allow_duplicates': False, 'dependencies': []}]
    for index in range(len(meta)):
        assert RoleMetadata().deserialize(meta[index]) == meta[index]
        assert RoleMetadata().deserialize(meta[index]) == meta[index]


# Generated at 2022-06-25 06:03:17.382801
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test case for name is not a string
    # This should raise an exception for TypeError
    with pytest.raises(TypeError) as testcase_1:
        RoleMetadata.load(2, 3)

    with pytest.raises(AnsibleParserError) as testcase_2:
        RoleMetadata.load(dict, "fake_owner")

    with pytest.raises(AnsibleParserError) as testcase_3:
        RoleMetadata.load(dict(dependencies = [dict(name = "fake_role_name", vars = "fake_vars")]), "fake_owner")


# Generated at 2022-06-25 06:03:18.249030
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-25 06:03:19.825544
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    result = role_metadata.serialize()
    assert result == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 06:03:27.265659
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1._allow_duplicates = False
    role_metadata_1._dependencies.append({'role': 'role0'})
    role_metadata_1._dependencies.append({'role': 'role1'})
    serialized_data = role_metadata_1.serialize()

    assert serialized_data['allow_duplicates'] == False
    assert serialized_data['dependencies'] == role_metadata_1._dependencies


# Generated at 2022-06-25 06:03:31.694629
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = {}
    setattr(role_metadata_0, 'allow_duplicates', data.get('allow_duplicates', False))
    setattr(role_metadata_0, 'dependencies', data.get('dependencies', []))
    return True


# Generated at 2022-06-25 06:04:06.279899
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_deserialize_0 = RoleMetadata()
    role_metadata_deserialize_0.deserialize({})


# Generated at 2022-06-25 06:04:13.638115
# Unit test for method deserialize of class RoleMetadata

# Generated at 2022-06-25 06:04:20.322924
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['foo', 'bar']
    expected = {'allow_duplicates': True, 'dependencies': ['foo', 'bar']}
    
    assert role_metadata.serialize() == expected


# Generated at 2022-06-25 06:04:22.241860
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()
    assert isinsta

# Generated at 2022-06-25 06:04:30.134356
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    print('test_RoleMetadata_load')
    role_metadata_1 = RoleMetadata()
    role_metadata_1.load({"galaxy_info":{"author":"Thomas.Krahn","description":"Verify OS version","company":"Kraxel.org","license":"GPLv3","min_ansible_version":"2.0","platforms":[{"name":"EL","versions":["7.1","7.2","7.3"]}]},"dependencies":[{"role":"thomas.krahn","version":"1.0"}]},None,None,None)


# Generated at 2022-06-25 06:04:38.127061
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0._variable_manager = VariableManager()
    role_metadata_0._loader = DataLoader()
    role_metadata_0._task_vars = dict()
    role_metadata_0._allow_duplicates = False
    role_metadata_0._dependencies = []
    role_metadata_0._loaded_from = "null"
    role_metadata_0._galaxy_info = None
    role_metadata_0._argument_specs = dict()
    print(role_metadata_0.serialize())
    print(role_metadata_0.serialize())
    print(role_metadata_0.serialize())
    print(role_metadata_0.serialize())
    print(role_metadata_0.serialize())

# Generated at 2022-06-25 06:04:39.855669
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1._allow_duplicates == False
    assert role_metadata_1._dependencies == []


# Generated at 2022-06-25 06:04:41.079991
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert len(role_metadata.serialize()) == 2

# Generated at 2022-06-25 06:04:42.692451
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata.__class__.__name__ == 'RoleMetadata'


# Generated at 2022-06-25 06:04:47.382850
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata._variable_manager)
    assert role_metadata != None
