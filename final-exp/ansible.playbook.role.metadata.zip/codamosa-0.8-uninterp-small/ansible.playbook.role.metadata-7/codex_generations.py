

# Generated at 2022-06-25 05:55:21.751370
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metdata_0 = RoleMetadata()
    assert role_metdata_0.__class__.__name__ == 'RoleMetadata'

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-25 05:55:23.960224
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1._allow_duplicates = True
    role_metadata_1._dependencies = ['dependency1', 'dependency2']
    s = role_metadata_1.serialize()
    assert(s and isinstance(s, dict))
    assert(s['allow_duplicates'])
    assert(s['dependencies'])



# Generated at 2022-06-25 05:55:32.169741
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rmd_obj1 = RoleMetadata()
    rmd_obj1.allow_duplicates = True
    rmd_obj1.dependencies = [{'name': 'galaxy.role,version,name', 'src': 'galaxy.role,version,name'}]
    rmd_obj1.galaxy_info = {}
    rmd_obj1.argument_specs = {}
    if rmd_obj1.serialize()['allow_duplicates'] != True:
        raise AssertionError("expected allow_duplicates to be True")
    if rmd_obj1.serialize()['dependencies'] != [{'name': 'galaxy.role,version,name', 'src': 'galaxy.role,version,name'}]:
        raise AssertionError("incorrect dependency list")


# Unit

# Generated at 2022-06-25 05:55:33.361338
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:55:35.086111
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    returned_value = role_metadata_0.serialize()
    # print(str(returned_value))


# Generated at 2022-06-25 05:55:39.443900
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1 is not None

    try:
        RoleMetadata(owner="A")
    except Exception as e:
        print(e)
        assert isinstance(e, Exception)


# Generated at 2022-06-25 05:55:43.260987
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    a = RoleMetadata()
    a.deserialize({"allow_duplicates": False})
    assert a.allow_duplicates is False
    assert a.dependencies == []
    a.deserialize({"dependencies": ["foo"]})
    assert a.allow_duplicates is False
    assert a.dependencies == ["foo"]


# Generated at 2022-06-25 05:55:44.815703
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:55:46.698389
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    # TODO: add error handling
    #role_metadata_1.load()
    assert role_metadata_1



# Generated at 2022-06-25 05:55:48.632071
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = {}
    assert role_metadata_0.deserialize(data_0) == None


# Generated at 2022-06-25 05:56:03.030113
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata.load(
        data={},
        owner=None,
        variable_manager=None,
        loader=None
        )


# Generated at 2022-06-25 05:56:05.940534
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    testcase0 = {
        'galaxy_info': None,
        'allow_duplicates': False,
        'dependencies': [],
        'argument_specs': {}
    }
    rm = RoleMetadata()
    assert rm.serialize() == testcase0

# Generated at 2022-06-25 05:56:12.286881
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=[
            "role1",
            "role2",
            "role3"
        ]
    )
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)
    # serialized = role_metadata.serialize()
    serialized = role_metadata.serialize()
    assert serialized == data



# Generated at 2022-06-25 05:56:15.974937
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata()
    result1 = role_metadata_1.load('data', 'owner', 'variable_manager', 'loader')
    assert isinstance(result1, RoleMetadata)
    assert result1.__repr__() == '<RoleMetadata>'


# Generated at 2022-06-25 05:56:21.036038
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    role_metadata = RoleMetadata()
    assert role_metadata != None
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    assert role_metadata._galaxy_info == None
    assert role_metadata._argument_specs == {}

# Generated at 2022-06-25 05:56:23.527432
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:56:30.606795
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = role_metadata_0.load()
    # Dict of type 'dict'
    assert isinstance(role_metadata_1,dict)


# Generated at 2022-06-25 05:56:32.834004
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata(owner=None)

# Generated at 2022-06-25 05:56:37.494237
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # create a dummy RoleMetadata() object for the test
    role_metadata_0 = RoleMetadata()
    # declare sample data
    role_metadata_0_data = dict(
        meta_main_yml = dict()
    )

    # call the method with sample data
    role_metadata_0._load(role_metadata_0_data)


# Generated at 2022-06-25 05:56:40.468515
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize()



# Generated at 2022-06-25 05:57:06.559728
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()

    try:
        r.deserialize(None)
    except SystemExit:
        pass


# Generated at 2022-06-25 05:57:07.497420
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:57:10.521789
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 05:57:14.084304
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # create an instance of a class that inherits from RoleMetadata
    role_metadata_1 = RoleMetadata()

    # call method serialize on role_metadata_1 object
    assert role_metadata_1.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 05:57:15.129268
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_case_0()

# Generated at 2022-06-25 05:57:20.385441
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata_1 = RoleMetadata(owner=None)

    # Testing: Load metadata from file
    with open('./tests/unit/test_fixtures/ansible-role-requirements.yml', 'r') as f:
        role_metadata_1.load(yaml.load(f, Loader=yaml.FullLoader), None, None, None)

    assert len(role_metadata_1._dependencies) == 1
    assert role_metadata_1._dependencies[0].role == 'Wim Ten Have'

# Generated at 2022-06-25 05:57:26.467819
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    # Test _allow_duplicates field
    assert role_metadata._allow_duplicates is False
    # Test _dependencies field
    assert role_metadata._dependencies == list()
    # Test _galaxy_info field
    assert role_metadata._galaxy_info is None
    # Test _argument_specs field
    assert role_metadata._argument_specs == dict()

if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-25 05:57:32.450808
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata.serialize())
    assert set(['allow_duplicates', 'dependencies']) == set(role_metadata.serialize().keys())
    assert False == role_metadata.serialize()['allow_duplicates']
    assert [] == role_metadata.serialize()['dependencies']

# Unit test
# 1. RoleMetadata has the ability to load data structure

# Generated at 2022-06-25 05:57:35.141955
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict( role="role_name_1" ),
            dict( role="role_name_2" ),
        ]
    )
    role_metadata_0 = RoleMetadata().load( data, None )

# Generated at 2022-06-25 05:57:36.432307
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    raise NotImplementedError("test_RoleMetadata_load() not implemented.")

# Generated at 2022-06-25 05:58:00.551234
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({"allow_duplicates": False, "dependencies": []})


# Generated at 2022-06-25 05:58:03.174500
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = None  # TODO: implement test_RoleMetadata_deserialize
    assert role_metadata_0.deserialize(data) == None


# Generated at 2022-06-25 05:58:04.593063
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == {}

# Generated at 2022-06-25 05:58:10.503842
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
  role_metadata_0 = RoleMetadata()
  data = dict(
        dependencies=[],
        allow_duplicates=False
    )
  role_metadata_0.deserialize(data)


# Generated at 2022-06-25 05:58:14.690507
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_0 = RoleMetadata()

# Generated at 2022-06-25 05:58:16.421353
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-25 05:58:23.567094
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    print("")
    print("TEST CASE 0: object initialisation")
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ["webapp-backend", "webapp-frontend"]

    print("TEST CASE 1: serialize")
    print("serialized value: %s" % role_metadata.serialize())



# Generated at 2022-06-25 05:58:25.167757
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata)

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-25 05:58:29.553518
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1.serialize()

# Generated at 2022-06-25 05:58:34.381105
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create the RoleMetadata instance
    rm = RoleMetadata()
    # Call the deserialize method
    rm.deserialize({})


# Generated at 2022-06-25 05:59:00.420193
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print("Constructor arguments:")
    print("self:")
    test_case_0()
    print("\n")

# Generated at 2022-06-25 05:59:06.687707
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = dict(allow_duplicates=False,
                dependencies=['src: foo', {'role': 'test'}, {'role': 'test', 'name': 'test'}])
    role_metadata.deserialize(data)
    print(role_metadata._allow_duplicates)
    print(role_metadata._dependencies)



# Generated at 2022-06-25 05:59:13.713604
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_1 = RoleMetadata()
    test_value_for_allow_duplicates = False
    test_value_for_dependencies = [{u'role': u'role_name', u'name': u'role_name'}, {'role': 'role_name', 'name': 'role_name'}, {u'role': u'role_name', u'name': u'role_name'}, {'role': 'role_name', 'name': 'role_name'}]
    test_value_for_datadict = {'allow_duplicates':test_value_for_allow_duplicates, 'dependencies':test_value_for_dependencies}
    role_metadata_1.deserialize(data=test_value_for_datadict)
    assert role_metadata_1.allow_

# Generated at 2022-06-25 05:59:17.500179
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata1 = RoleMetadata()
    assert role_metadata1.load({}, None, None, None)

if __name__=="__main__":
    test_case_0()
    test_RoleMetadata_load()

# Generated at 2022-06-25 05:59:21.722683
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create the object
    role_metadata = RoleMetadata()

    # Create the variables
    from ansible.collections.ansible.builtin import load as ansible_builtin_load
    from ansible.collections.ansible.builtin.plugins.modules.command import Command
    from ansible.collections.ansible.builtin.plugins.modules.setup import Setup
    from ansible.collections.ansible.builtin.plugins.modules.copy import Copy
    from ansible.collections.ansible.builtin.plugins.modules.file import File
    from ansible.collections.ansible.builtin.plugins.modules.file import File
    from ansible.collections.ansible.builtin.plugins.modules.service import Service
    from ansible.collections.ansible.builtin.plugins.modules.service import Service

# Generated at 2022-06-25 05:59:25.002011
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert isinstance(role_metadata_0, RoleMetadata)


# Generated at 2022-06-25 05:59:28.739525
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize(dict(
        allow_duplicates=False,
        dependencies=[]
    ))


# Generated at 2022-06-25 05:59:35.400707
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    block_0 = {
        'allow_duplicates': False,
        'dependencies': [
            {'role': 'geerlingguy.apache', 'version': '1.2.3'},
            {'role': 'geerlingguy.mysql', 'version': '1.1.2'},
            'geerlingguy.postgresql'
        ]
    }
    role_metadata_0 = RoleMetadata()
    role_metadata_1 = role_metadata_0.load(block_0, None)
    assert role_metadata_0 != role_metadata_1
    assert role_metadata_1._allow_duplicates == False


# Generated at 2022-06-25 05:59:42.255918
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_test_1 = RoleMetadata()
    serialized_data = role_metadata_test_1.serialize()
    print(serialized_data)
    assert isinstance(serialized_data, dict)
    assert 'allow_duplicates' in serialized_data
    assert 'dependencies' in serialized_data


# Generated at 2022-06-25 05:59:50.545350
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_dict_1 = {'dependencies': ['tests/test_roles/test_role_2'], 'allow_duplicates': True}
    role_metadata_obj_1 = RoleMetadata()
    role_metadata_obj_1.deserialize(role_metadata_dict_1)
#    print("\n" + "Expected result:\n" + "-----------")
#    print("\n" + "Result:\n" + "-----------")
#    print("RoleMetadata object")
#    print("dependencies: " + str(role_metadata_obj_1._dependencies))
#    print("allow_duplicates: " + str(role_metadata_obj_1._allow_duplicates))


# Generated at 2022-06-25 06:00:41.368459
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 06:00:47.186308
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Create instance of class RoleMetadata
    role_metadata = RoleMetadata()
    assert isinstance(role_metadata, RoleMetadata)
    # Compare above serialized value of instance with value in dictionary
    assert role_metadata.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-25 06:00:49.417308
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'dependencies': ['foo', 'bar'], 'allow_duplicates': True})
    assert role_metadata.dependencies == ['foo', 'bar']
    assert role_metadata.allow_duplicates == True

# Generated at 2022-06-25 06:00:52.367676
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {'allow_duplicates': True, 'dependencies': [{'role': 'galaxy.role', 'other_vars': 'here'}]}
    role_metadata = RoleMetadata()
    role_metadata.load(data=data, owner=None)
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies[0].name == 'galaxy.role'

# Generated at 2022-06-25 06:01:03.282890
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    role_metadata_0 = RoleMetadata()

    from ansible import inventory
    from ansible.parsing.dataloader import DataLoader

    # Ansible inventory
    inv_obj = inventory.Inventory(loader=DataLoader())

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # Initializing play_context
    play_context_0 = PlayContext()

    # Play
    play_0 = Play().load(dict(
        name='Test play 0',
        hosts='localhost',
        gather_facts=False,
    ), variable_manager=None, loader=None)

    # Initializing test_role_0

    from ansible.playbook.role import Role


# Generated at 2022-06-25 06:01:08.034699
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata_1 = RoleMetadata()
    print("RoleMetadata object:")
    print(role_metadata_1)


# Generated at 2022-06-25 06:01:14.120093
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata_0.deserialize(data)


# Generated at 2022-06-25 06:01:15.293989
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    role_metadata_0.deserialize({})


# Generated at 2022-06-25 06:01:19.149468
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    assert role_metadata_1.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )


# Generated at 2022-06-25 06:01:27.216180
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    ROLE_NAME = 'role_name'
    ROLE_COLLECTION = 'role_collection'
    ROLE_PATHS = 'role_paths'
    INCLUDES = 'include'
    ROLE_METADATA = 'role_metadata'
    DEPENDENCIES = 'dependencies'

    role_metadata_0 = RoleMetadata()
    data_0 = {
            ROLE_NAME: 'name_1',
            ROLE_COLLECTION: 'collection_1',
            ROLE_PATHS: 'paths_1',
            INCLUDES: 'include_1'
            }
    variable_manager_0 = data_0
    loader_0 = data_0
    assert role_metadata_0.load(data_0, variable_manager_0, loader_0)

    role_metadata_0

# Generated at 2022-06-25 06:03:11.923697
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_obj = RoleMetadata()
    data = {'dependencies': [], 'allow_duplicates': False}
    role_metadata_obj.deserialize(data)
    assert role_metadata_obj._dependencies == []
    assert role_metadata_obj._allow_duplicates == False

# Generated at 2022-06-25 06:03:18.486885
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = {
        "allow_duplicates": False,
        "dependencies": [
            "common",
            "webservers"
        ]
    }
    role_metadata_load = RoleMetadata()
    role_metadata_load_result = role_metadata_load.load(data)
    assert role_metadata_load_result.__class__.__name__ == "RoleMetadata"
    assert role_metadata_load_result.serialize() == {
        "allow_duplicates": False,
        "dependencies": [
            "common",
            "webservers"
        ]
    }


# Generated at 2022-06-25 06:03:24.270506
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_1 = RoleMetadata()
    role_metadata_1._loader = 'loader'
    role_metadata_1._variable_manager = 'variable_manager'
    ansible_galaxy_info_1 = {}
    setattr(role_metadata_1, 'galaxy_info', ansible_galaxy_info_1)
    role_metadata_1._dependencies = ['dependencies']
    role_metadata_1._allow_duplicates = 'allow_duplicates'
    serialized_1 = role_metadata_1.serialize()
    role_metadata_2 = RoleMetadata()
    role_metadata_2._loader = 'loader'
    role_metadata_2._variable_manager = 'variable_manager'
    ansible_galaxy_info_2 = {}

# Generated at 2022-06-25 06:03:27.769479
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert not hasattr(role_metadata_0, 'allow_duplicates')
    assert not hasattr(role_metadata_0, 'dependencies')

    role_metadata_0.allow_duplicates = True
    role_metadata_0.dependencies = []

    assert role_metadata_0.serialize() == {
        'allow_duplicates': True,
        'dependencies': [],
    }


# Generated at 2022-06-25 06:03:30.686641
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata_0 = RoleMetadata()
    data_0 = {
        'allow_duplicates': True,
        'dependencies': [
            'foo'
        ]
    }
    role_metadata_0.deserialize(data_0)


# Generated at 2022-06-25 06:03:37.749869
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import ROLE_BOILERPLATE_SUBDIRS
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader, module_loader

    # create a fake path/name for the role to deserialize
    temp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir, "tasks"))
    os.makedirs(os.path.join(temp_dir, "meta"))
    os.makedirs(os.path.join(temp_dir, "vars"))
    os.makedirs(os.path.join(temp_dir, "defaults"))
    os.makedirs(os.path.join(temp_dir, "files"))
    os.makedirs

# Generated at 2022-06-25 06:03:44.370191
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    role_metadata = RoleMetadata()

# Generated at 2022-06-25 06:03:48.131064
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': '', 'dependencies': ['dependency1', 'dependency2']})
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == ['dependency1', 'dependency2']


# Generated at 2022-06-25 06:03:51.273778
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata_0 = RoleMetadata()
    assert role_metadata_0.serialize() == dict(
        allow_duplicates=False,
        dependencies=[]
    )



# Generated at 2022-06-25 06:03:52.229088
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata(owner=None)

