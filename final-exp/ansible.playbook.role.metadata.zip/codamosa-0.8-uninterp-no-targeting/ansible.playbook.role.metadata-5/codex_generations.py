

# Generated at 2022-06-21 01:14:19.540236
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class TestRoleMetadata(RoleMetadata):
        def __init__(self, loader=None):
            super(TestRoleMetadata, self).__init__()
            self._loader = loader

    r = TestRoleMetadata()
    r.deserialize({'allow_duplicates':True, 'dependencies':[{'role': 'test'}]})

    assert r.allow_duplicates == True
    assert isinstance(r.dependencies, list)
    assert r.dependencies == [{'role': 'test'}]

# Generated at 2022-06-21 01:14:29.026128
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role.definition
    import ansible.playbook.role.include

    class MockPlaybook:
        def __init__(self):
            self.roles = dict()

        def get_role_definition(self, name):
            return self.roles[name]

        def add_role(self, role):
            self.roles[role.get_name()] = role

    class MockRole:
        def __init__(self, name):
            self.name = name
            self.tags = set()

        def get_name(self):
            return self.name

        def get_tags(self):
            return self.tags

    class MockRoleInclude:
        def __init__(self, name, tags):
            self.name = name
            self.tags = tags


# Generated at 2022-06-21 01:14:31.684171
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    role.deserialize({"allow_duplicates": True, "dependencies": []})
    assert role.allow_duplicates == True
    assert role.dependencies == []

# Generated at 2022-06-21 01:14:38.474889
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class Role:
        def __init__(self):
            self.name = 'testrole'
            self.path = 'testrole.role'
            self._role_path = os.path.join(self.path, 'meta/main.yml')
            self.collections = None
            self._play = self
    role = Role()
    data = dict(
        allow_duplicates = False,
        dependencies = [{'role': 'testrole1', 'name': 'testrole1'}, {'role': 'testrole2', 'name': 'testrole2'}]
    )
    RoleMetadata.load(data, owner=role)

# Generated at 2022-06-21 01:14:43.399677
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    json_data = {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}
    r.deserialize(json_data)
    assert r.allow_duplicates
    assert r.dependencies == ['role1', 'role2']

# Generated at 2022-06-21 01:14:43.975908
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-21 01:14:48.323346
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r._allow_duplicates = True
    r._dependencies = [RoleRequirement({'role': 'foo'})]
    assert r.serialize() == {'allow_duplicates': True, 'dependencies': r._dependencies}

# Generated at 2022-06-21 01:14:55.321910
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Tests that allowing duplicate roles
    '''
    data = dict(
        allow_duplicates=True,
        dependencies=[dict(role='ansible.builtin.debug')],
    )

    m = RoleMetadata()
    m.deserialize(data)
    assert (m.allow_duplicates == True)
    assert (len(m.dependencies) == 1)

# Generated at 2022-06-21 01:15:05.846570
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # compile list of metadata files
    meta_list = list()
    list_of_roles = ['../../../../lib/ansible/roles']
    for roles_path in list_of_roles:
        for role_path in os.listdir(roles_path):
            if os.path.exists(os.path.join(roles_path, role_path, "meta", "main.yml")):
                meta_list.append(os.path.join(roles_path, role_path, "meta", "main.yml"))

    # verify that all files in meta_list can be loaded and parsed
    for meta_file in meta_list:
        role = dict()
        role['name'] = meta_file

# Generated at 2022-06-21 01:15:15.484817
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook import role_include
    from ansible.playbook.helpers import load_list_of_roles
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    # prepare data structure
    role_def1 = dict(
        role="my_role",
        version="v3.0.0",
        src="https://github.com/user/repo.git",
    )
    role_def2 = dict(
        role="my_role",
        version="v3.0.0",
        src="https://github.com/user/repo.git",
    )

# Generated at 2022-06-21 01:15:32.142522
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task


# Generated at 2022-06-21 01:15:39.805249
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print("unit test: deserialize")
    # Test case - when data is empty
    roleMetadata = RoleMetadata()
    roleMetadata.deserialize({})
    assert roleMetadata.allow_duplicates == False
    assert roleMetadata.dependencies == []
    # Test case - when data is not empty
    roleMetadata.deserialize({'allow_duplicates':True, 'dependencies':['test']})
    assert roleMetadata.allow_duplicates == True
    assert roleMetadata.dependencies == ['test']


# Generated at 2022-06-21 01:15:47.435212
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    metadata = RoleMetadata(owner='test_owner')
    
    # No data, so the expected result is empty dictionary
    assert {} == metadata.serialize()

    # Set data.
    metadata._allow_duplicates = True
    metadata._dependencies = ['test_dependencies']

    serialized_data = metadata.serialize()
    assert True == serialized_data['allow_duplicates']
    assert 'test_dependencies' == serialized_data['dependencies'][0]


# Generated at 2022-06-21 01:15:56.257827
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # create a mock entry for RoleMetadata
    class MockRoleMetadata(object):
        def __init__(self):
            self.allow_duplicates = True
            self.dependencies = ['role1', 'role2', 'role3']

    role_metadata = RoleMetadata()
    role_metadata_mock = MockRoleMetadata()

    # call the method serialize of RoleMetadata
    result = role_metadata.serialize()

    # check the value stored in serialized dict
    assert result == dict(
        allow_duplicates=role_metadata_mock.allow_duplicates,
        dependencies=role_metadata_mock.dependencies
    )



# Generated at 2022-06-21 01:16:08.428430
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a_file_path = '/ansible/library/role/meta/main.yml'
    a_file_type = 'role'
    a_file_name = 'role'
    a_file_parent_path = '/ansible/library/role/'
    role_metadata = RoleMetadata()
    role_metadata.set_loader(loader)
    role_metadata.set_variable_manager(variable_manager)
    play_context = PlayContext(loader=loader, variable_manager=variable_manager)
    metadata_file = RoleMetadataFile(play=play, file_path=a_file_path, file_type=a_file_type,
                                     file_name=a_file_name, parent_path=a_file_parent_path)
    role_metadata.set_owner(metadata_file)

# Generated at 2022-06-21 01:16:09.589042
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert False, "No test defined"

# Generated at 2022-06-21 01:16:14.239295
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(role='bob')]
    )
    m = RoleMetadata().load(data)
    assert m.allow_duplicates == True
    assert m.dependencies[0].role == 'bob'


# Generated at 2022-06-21 01:16:23.439331
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class DummyPlay:
        def __init__(self):
            self.roles = list()

    class DummyRole:
        def __init__(self, name):
            self.name = name
            self.metadata = RoleMetadata(self)
            self.path = '/tmp/does/not/matter'

    # Basic empty constructor test
    rm = RoleMetadata()
    assert rm

    # Test the load function
    p = DummyPlay()
    r = DummyRole('role-unit-test')

    rm = RoleMetadata(r)
    assert rm

    data = rm.load(dict({'dependencies': [
        'role1',
        'role2',
    ]}), r)
    assert data


# Generated at 2022-06-21 01:16:27.737172
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    meta = RoleMetadata()

# Generated at 2022-06-21 01:16:30.869500
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import json
    assert json.loads(RoleMetadata().deserialize({}).decode()) == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-21 01:16:44.338866
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import ROLE_CACHE
    from ansible.playbook.role.definition import RoleDefinition

    ROLE_CACHE.clear()

    RoleDefinition.load_role_definition('jdauphant.nginx', '/home/vagrant/nginx_role')
    rolemeta = RoleMetadata.load({}, ROLE_CACHE['jdauphant.nginx'])
    serialized = rolemeta.serialize()

    assert serialized['allow_duplicates'] == False
    assert serialized['dependencies'] == []

# Generated at 2022-06-21 01:16:55.333270
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import json
    import os
    import sys

    # given/when
    # Get the file path of this script
    file_path = os.path.realpath(os.path.dirname(__file__))

    # Get the role metadata file
    role_metadata_file_path = os.path.join(file_path, "..", "..", "data", "galaxy", "ansible-test_role_deps_main.yml")

    # Load the role metadata content
    with open(role_metadata_file_path) as role_metadata_file:
        role_metadata_data = json.load(role_metadata_file)

    # Execute the load function and print the deps with name and version
    role_metadata = RoleMetadata.load(role_metadata_data, None)

    # then
    # Ass

# Generated at 2022-06-21 01:16:59.127754
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        foo=dict(
            allow_duplicates=True,
            dependencies=["role1", "role2"]
        )
    )
    return RoleMetadata.load(data.get('foo'), 'foo').serialize()

if __name__ == '__main__':
    result = test_RoleMetadata_serialize()
    print(result)

# Generated at 2022-06-21 01:17:02.086302
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class MyPlay(object):
        pass

    class MyRole(object):
        pass

    play = MyPlay()
    role = MyRole()
    me = RoleMetadata(owner=role)

# Generated at 2022-06-21 01:17:13.599189
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.plugins.loader import loaders
    from ansible.template import Templar
    import json

    module_loader.add_directory('./test/utils/plugins/modules')
    loaders.push(module_loader)

    play_context = PlayContext()

    play = Play.load(dict(
        name="test play",
        hosts='localhost',
        gather_facts='no',
        roles=[],
    ), variable_manager=None, loader=None)

    templar = Templar(loader=None, variables={})
    role_metadata = RoleMetadata(owner=play)

# Generated at 2022-06-21 01:17:18.126044
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({"allow_duplicates": False, "dependencies": []})
    assert role_metadata._allow_duplicates == False
    assert role_metadata._dependencies == []
    role_metadata.deserialize({"allow_duplicates": True, "dependencies": ["something"]})
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == ["something"]

# Generated at 2022-06-21 01:17:22.217795
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pb = RoleMetadata()
    assert pb._allow_duplicates is False
    assert pb._dependencies == []
    assert pb._galaxy_info is None
    assert pb._argument_specs == {}

# Generated at 2022-06-21 01:17:29.755798
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata(owner = None)
    m._owner = None
    m._dependencies = None
    m._allow_duplicates = None
    m._galaxy_info = None
    m._argument_specs = None
    m.serialize()
    m._owner = 1
    m._dependencies = 2
    m._allow_duplicates = 4
    m._galaxy_info = 4
    m._argument_specs = {}
    m.serialize()


# Generated at 2022-06-21 01:17:37.452417
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role import Role
    import pytest

    try:
        # Using the constructor with owner=None should cause an exception
        r = RoleMetadata().load({}, owner=None, variable_manager=None, loader=None)
        pytest.fail("Expected exception, due to use of the constructor with owner=None")
    except:
        pass

    # Using the constructor with owner as Role object should succeed
    r = RoleMetadata().load({}, owner=Role(), variable_manager=None, loader=None)

# Generated at 2022-06-21 01:17:39.227744
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    serial_data = meta.serialize()
    assert serial_data == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-21 01:18:00.729228
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-21 01:18:03.440902
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    serialized = role.serialize()
    assert(len(serialized) == 2)
    assert(serialized['allow_duplicates'] == False)

# Generated at 2022-06-21 01:18:13.060722
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    role_name = 'test'
    role_path = 'test/data/test_role_repo/' + role_name
    from ansible.playbook.role import Role
    r = Role.load(role_name, role_path)
    p = Play.load(dict(
        name = 'Ansible Play',
        hosts = 'all',
        gather_facts = 'no',
        roles = [
            dict(name=role_name, role_path=role_path)
        ]
    ), variable_manager=None, loader=None)
    MockPlayContext = PlayContext()
    p._set_play_context(MockPlayContext)
    r._set_play(p)

    # Test

# Generated at 2022-06-21 01:18:25.031502
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    variable_manager = None
    loader = None

    playbook_path = os.path.join("tests", "test_data", "test_playbook.yml")
    play = Play.load(playbook_path, variable_manager=variable_manager, loader=loader)
    play._post_validate()

    # The following test has been commented out due to the test_playbook.yml being modified
    # to load a role in a different way.  The role loading section has been commented out until
    # the test data can be fixed.
    # play._load_roles()

    # Get the role we want to test the load method on

# Generated at 2022-06-21 01:18:30.950066
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # test "deprecate_import" attribute of class RoleMetadata
    test_deprecate_import = RoleMetadata(owner=None)
    setattr(test_deprecate_import, 'dependencies', [])
    test_data = test_deprecate_import.serialize()
    assert test_data['allow_duplicates'] == False
    assert test_data['dependencies'] == []


# Generated at 2022-06-21 01:18:38.176364
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    data = {}
    owner = RoleDefinition(dict(name='dummy',
                                play=None,
                                _role_collection=None,
                                role_path='/tmp/role',
                                collections=[]),
                           variable_manager=None,
                           loader=None)
    meta = RoleMetadata(owner=owner).load(data, owner=owner)
    assert meta.allow_duplicates == False
    assert meta.dependencies == []

# Generated at 2022-06-21 01:18:42.908377
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Setup a RoleMetadata object instance
    role_metadata = RoleMetadata()
    
    # Get the serialize result from the RoleMetadata object instance
    result = role_metadata.serialize()
    assert result == dict(
        allow_duplicates=False,
        dependencies=[]
    )


# Generated at 2022-06-21 01:18:47.086570
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {'allow_duplicates': True, 'dependencies': []}
    roleMetadata = RoleMetadata().deserialize(data)
    assert roleMetadata.allow_duplicates == True
    assert roleMetadata.dependencies == []

# Generated at 2022-06-21 01:18:51.607686
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata().load({ "dependencies": [ { "role": "name" } ], "allow_duplicates": True })
    m.deserialize(m.serialize())
    assert len(m.serialize()) == 2

# Generated at 2022-06-21 01:18:59.851941
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition.load({}, None)
    role._role_path = '/path/to/role/without/meta'
    # None meta
    metadata = RoleMetadata(owner=role).load(dict(), owner=role)
    assert metadata.allow_duplicates == False
    assert isinstance(metadata.dependencies, list)
    assert isinstance(metadata.argument_spec, dict)
    assert metadata.dependencies == []
    # 'allow_duplicates' is bool
    metadata = RoleMetadata(owner=role).load(dict(allow_duplicates=True), owner=role)
    assert metadata.allow_duplicates == True
    # 'allow_duplicates' is string

# Generated at 2022-06-21 01:19:40.492151
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-21 01:19:43.137637
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_RoleMetadata = RoleMetadata()
    test_RoleMetadata.deserialize({"allow_duplicates": True})
    assert test_RoleMetadata['allow_duplicates']

# Generated at 2022-06-21 01:19:48.654528
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    role_meta.deserialize({'allow_duplicates': True, 'dependencies': [{'name': 'foo', 'src': 'bar', 'path': 'baz'}]})
    assert role_meta._allow_duplicates

# Generated at 2022-06-21 01:19:59.246482
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    p = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'roles': [
            {'role': 'test1'},
            {'role': 'test2'},
        ]
    })

    r1 = Role().load({
        'name': 'test1',
        'hosts': 'testhost',
        'tasks': [
            {'name': 'debug',
             'debug': 'msg="This is a debug task"'
            }
        ]
    }, parent_play=p)


# Generated at 2022-06-21 01:20:08.612053
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import data.role_metadata_data as test_data
    # first test: valid input data
    m = RoleMetadata.load(test_data.VALID_ROLE_META, None)

    assert m.allow_duplicates == False
    assert m.dependencies[0].get_name() == 'some_other_role'
    assert m.dependencies[0].get_role_path() == os.path.join(os.path.expanduser('~'), 'some_other_role/')
    assert m.dependencies[1].get_name() == 'another_role'
    assert m.dependencies[1].get_role_path() == '/foo/another_role/'

    # second test: test the case that there is no meta/main.yml file present

# Generated at 2022-06-21 01:20:12.906796
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.task_include import TaskInclude
    role_met = RoleMetadata()
    assert isinstance(role_met, RoleMetadata)
    assert isinstance(role_met, Base)
    assert isinstance(role_met, TaskInclude)

# Generated at 2022-06-21 01:20:24.835887
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-21 01:20:28.496367
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata instance
    role = RoleMetadata()
    # Populate the example data
    data = dict()
    data['allow_duplicates'] = False
    data['dependencies'] = []
    
    # Call the deserialize method
    role.deserialize(data)
    
    # Assert that the RoleMetadata instance has the fields populated with the data
    assert role._allow_duplicates is False
    assert role._dependencies == []

# Generated at 2022-06-21 01:20:34.950363
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''Unit test for constructor of class RoleMetadata'''

    r1 = RoleMetadata()
    r1.deserialize({"allow_duplicates": True, "dependencies": ["1234"]})
    print(r1)
    assert(True)


if __name__ == "__main__":
    test_RoleMetadata()

# Generated at 2022-06-21 01:20:42.781355
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    class TestOwnerObject():
        def __init__(self):
            self._play = 'fake_play'
            self._role_path = 'fake_role_path'
            self._role_collection = 'fake_collection'
            self.collections = []
            self.get_name = 'fake_get_name'

    class TestObj():
        def __init__(self):
            pass

    class TestVariableManager():
        def __init__(self):
            pass

    data1 = dict(allow_duplicates=False, dependencies=[{'role': 'test1'}, {'role': 'test2'}])
    meta = RoleMetadata()
    meta.deserialize(data1)
    assert meta._allow_duplicates is False
    assert len(meta._dependencies) == 2

    data2 = dict

# Generated at 2022-06-21 01:21:24.939847
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m.allow_duplicates = True
    m.dependencies = [dict(role=dict(name='r1')), dict(role=dict(name='r2'))]
    data = m.serialize()
    assert data.get('allow_duplicates') == True
    assert len(data.get('dependencies')) == 2
    assert data['dependencies'][0]['role']['name'] == 'r1'
    assert data['dependencies'][1]['role']['name'] == 'r2'

# Generated at 2022-06-21 01:21:35.991774
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import role

    test_owner = role.Role()
    test_owner._role_path = 'test/roles/role_to_include'
    test_owner.name = 'test.rolename'
    test_owner._role_collection = None
    test_owner._metadata = RoleMetadata(owner=test_owner)

    test_role_metadata = RoleMetadata(owner=test_owner)
    test_role_metadata.name = 'test.rolename'
    test_role_metadata._role_path = 'test/roles/role_to_include'
    test_role_metadata._role_collection = None
    test_role_metadata._play = None


# Generated at 2022-06-21 01:21:37.897502
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert isinstance(m, RoleMetadata)
    assert isinstance(m, Base)

# Generated at 2022-06-21 01:21:46.781999
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.collection_search import RoleCollectionSearch
    from ansible.galaxy.collection import CollectionRequirement

# Generated at 2022-06-21 01:21:57.591383
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager,  host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-21 01:22:01.074850
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    a = RoleMetadata()
    data = {
        'allow_duplicates': True
    }
    a.deserialize(data)
    assert a._allow_duplicates is True


# Generated at 2022-06-21 01:22:08.805891
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'dependencies': [
                {'role': 'name', 'version': 'version'},
                'somethingelse',
                {'src': 'filename'}
            ],
        'allow_duplicates': True
    }
    m = RoleMetadata()
    m.deserialize(data)
    assert m.allow_duplicates == True
    assert m.dependencies == [
        {'role': 'name', 'version': 'version'},
        'somethingelse',
        {'src': 'filename'}
    ]

# Generated at 2022-06-21 01:22:11.952322
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize({'allow_duplicates': True})
    assert r._allow_duplicates
    assert r.allow_duplicates

# Generated at 2022-06-21 01:22:16.925326
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    print("Test serialize of class RoleMetadata")
    role_meta = RoleMetadata()
    role_meta.allow_duplicates = True
    role_meta.dependencies = ['mockrole', 'mockrole2']
    role_meta.galaxy_info = "GalaxyInfo"
    role_meta.argument_specs = {"argument_specs": "argument_specs"}
    print("Test completed")
    return role_meta.serialize()


# Generated at 2022-06-21 01:22:28.568346
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    This is a unit test for method RoleMetadata.deserialize()

    The unit test checks that the method properly deserializes the passed-in
    data blob.

    Returns true on success and false otherwise.
    '''
    role_metadata = RoleMetadata()

    # test that the passed-in data is updated properly
    orig_data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    role_metadata.deserialize(orig_data)
    if not (role_metadata.allow_duplicates == orig_data['allow_duplicates'] and
            role_metadata.dependencies == orig_data['dependencies']):
        return False

    # test that missing fields are set to defaults
    orig_data = dict(
        dependencies=[]
    )

# Generated at 2022-06-21 01:23:42.938026
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # create RoleMetadata
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict())

    # test the property allow_duplicates
    assert isinstance(role_metadata.allow_duplicates, bool)
    assert role_metadata.allow_duplicates == False

    # test the property dependencies
    assert isinstance(role_metadata.dependencies, list)
    assert role_metadata.dependencies == []

# Generated at 2022-06-21 01:23:49.891595
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    role_def = RoleDefinition.load({"role": "name"}, dataloader, "/path/to/role")
    dependency = RoleMetadata.load({"dependencies": [role_def]}, Role('name', "/path/to/role", "/path/to/playbook"))
    assert dependency._dependencies is not None
    assert isinstance(dependency._dependencies[0], Role)

    role_def = RoleDefinition.load({"src": "name"}, dataloader, "/path/to/role")

# Generated at 2022-06-21 01:23:53.714718
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    a = RoleMetadata()
    a.deserialize( { 'allow_duplicates': True, 'dependencies': [ 'b' ] } )
    assert a.serialize() == { 'allow_duplicates': True, 'dependencies': [ 'b' ] }



# Generated at 2022-06-21 01:23:54.681399
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass

# Generated at 2022-06-21 01:24:01.767065
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    allow_duplicates = True
    role_requirement = RoleRequirement()
    role_dependency = dict(name='test_role', src='role_url', scm='git', version='v1.0')
    dependencies = [role_requirement, role_dependency]

    metadata = RoleMetadata()
    setattr(metadata, 'allow_duplicates', allow_duplicates)
    setattr(metadata, 'dependencies', dependencies)

    data = metadata.serialize()
    assert data['allow_duplicates'] == allow_duplicates
    assert len(data['dependencies']) == 2
    assert data['dependencies'][0] == role_requirement
    assert data['dependencies'][1] == role_dependency
    assert data['dependencies'][1]['name'] == 'test_role'