

# Generated at 2022-06-21 01:14:13.472529
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata(owner=None)

    meta.allow_duplicates = False
    meta.dependencies = []

    data = meta.serialize()

    assert len(data) == 2
    assert data['allow_duplicates'] is False
    assert data['dependencies'] == []


# Generated at 2022-06-21 01:14:25.012207
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition

    def_list = [{'role': {'name': 'test_role'}, 'tasks': [{'debug': 'msg="Hi"', 'notify': ['This is a notify']}]},
                {'role': {'name': 'test_role1'}, 'tasks': [{'debug': 'msg="Hi"', 'notify': ['This is a notify']}]}]

    owner = RoleDefinition()
    owner._play = None
    setattr(owner, '_role_collection', None)
    setattr(owner, '_role_path', None)
    setattr(owner, 'collections', None)
    owner._load_data(def_list)
    role_list = owner.get_direct_dependencies()

# Generated at 2022-06-21 01:14:29.514847
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata_dict = {
        'allow_duplicates': True,
        'dependencies': ['dependency_1', 'dependency_2', 'dependency_3']
    }
    metadata = RoleMetadata()
    metadata.deserialize(metadata_dict)
    assert metadata.allow_duplicates == True
    assert metadata.dependencies == ['dependency_1', 'dependency_2', 'dependency_3']

# Generated at 2022-06-21 01:14:35.767146
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role import Role
    import os
    import sys

    # This is a test for deserialize method to convert data to object
    # The test data is the data saved by method serialize of class RoleMetadata

    # create a RoleMetadata
    role = Role.load(dict(name='test-role', path=os.path.join(sys.prefix, 'lib', 'ansible', 'roles', 'test-role')))
    role_metadata = role.metadata
    role_metadata.dependencies.append({'role': 'fooo.test-role'})
    role_metadata.dependencies.append({'name': 'test-collection.test-role'})
    serialized_data = role_metadata.serialize()
    #print(serialized_data)

    # deserialize the data
    role

# Generated at 2022-06-21 01:14:47.423733
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    ansible_module = AnsibleModule(
        argument_spec=dict()
    )

    # Create a role to use as owner of RoleMetadata object
    role_name = 'role_name'
    role_path = 'foo/bar/role_name'
    role_path_expanded = 'foo/bar/role_name'
    role = Role(name=role_name, play=None, role_path=role_path, collection_search_paths=None)
    role._role_path = role_path

    # Create a RoleMetadata object using the role created above as owner
    role_metadata = RoleMetadata(owner=role)

    # data passed to the method role_metadata.load()

# Generated at 2022-06-21 01:14:59.913877
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    m = RoleMetadata()
    name = 'test'
    file_name = 'r1.yml'
    play = Play.load({}, variable_manager=VariableManager(), loader=DataLoader())
    m._owner = RoleDefinition.load(name, file_name, play, DataLoader()).get_role_path()

    dependencies = []
    dependencies.append({'role': "my_role0", 'name': 'role_name0'})

# Generated at 2022-06-21 01:15:09.347324
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role

    def get_galaxy_info(data):
        role_metadata = RoleMetadata.load(data, Role)
        return role_metadata._galaxy_info

    # test with both legacy (galaxy_info) and new style (galaxy) syntax
    galaxy_info_data = {'galaxy_info': {'author': 'Testy', 'description': 'good tester'}}
    galaxy_data = {'galaxy': {'author': 'Testy', 'description': 'good tester'}}
    assert get_galaxy_info(galaxy_info_data).description == 'good tester'
    assert get_galaxy_info(galaxy_data).description == 'good tester'
    # test that an empty dict is returned if galaxy_info is not provided
    assert get_

# Generated at 2022-06-21 01:15:17.978728
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = [ 
        "samlolo.laravel", 
        "samlolo.nginx", 
        "samlolo.php-fpm", 
        "samlolo.supervisor", 
        "samlolo.composer", 
        "samlolo.mysql", 
        "samlolo.php-ext-install", 
        {
            "src": "git+https://github.com/samlolo/ansible-role-mysql.git@v1.0", 
            "name": "samlolo.mysql"
        }
    ]

    serialized = role_metadata.serialize()

    assert isinstance(serialized, dict)

# Generated at 2022-06-21 01:15:24.919268
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create a fake role
    from ansible.playbook.role import Role

    r = Role()
    r._role_path = '/tmp/my_role'

    # Create a fake metadata
    md = dict()

    # Test the constructor
    rm = RoleMetadata(owner=r).load_data(md)

    # Assert default values
    assert rm._dependencies == []
    assert rm._allow_duplicates == False

# Generated at 2022-06-21 01:15:29.743674
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a RoleMetadata object
    r = RoleMetadata()
    # deserialize data to the object
    r.deserialize(dict(
        allow_duplicates=False,
        dependencies=[]
    ))
    # Check if the values are the same
    assert r.allow_duplicates == False
    assert r.dependencies == []

# Generated at 2022-06-21 01:15:37.749013
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
      This is a unit test for the constructor of the class RoleMetadata
    '''
    role_metadata = RoleMetadata()
    assert role_metadata is not None

# Generated at 2022-06-21 01:15:49.871870
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    # Setting up for the test
    data = {
        "dependencies": [
            {
                "role": "example_role2",
                "other_vars": {
                    "role2": True
                }
            }
        ],
        "allow_duplicates": "True"
    }

    # Testing the method serialize of class RoleMetadata
    test_role_metadata = RoleMetadata()
    test_role_metadata.deserialize(data)
    data = test_role_metadata.serialize()
    # Verifying the result
    assert data == {
        "dependencies": [
            {
                "role": "example_role2",
                "other_vars": {
                    "role2": True
                }
            }
        ],
        "allow_duplicates": "True"
    }

# Generated at 2022-06-21 01:15:58.879765
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    # init test object
    obj = RoleMetadata()
    # init test variable
    data = {}
    # test deserializing
    obj.deserialize(data)
    # assert attributes
    assert obj.allow_duplicates == False
    assert obj.dependencies == []
    assert obj.icons == []
    assert obj.tags == []
    assert obj.defaults == {}
    assert obj.handlers == {}
    assert obj.meta == {}
    assert obj.vars == {}
    assert obj.files == []
    assert obj.module_defaults == {}
    assert obj.tests == []
    assert obj.main_file == {}



# Generated at 2022-06-21 01:16:05.970605
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {}
    data['dependencies'] = [{'role1': '0.1.0'}, {'role2': '0.2.0'}]
    data['allow_duplicates'] = True
    # Owner is not used in constructor
    m = RoleMetadata(None).load_data(data)
    assert m._owner is None
    assert m._allow_duplicates == True
    assert len(m._dependencies) == 2

# Generated at 2022-06-21 01:16:09.190234
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition

    r = RoleMetadata.load(dict(dependencies=[]), RoleDefinition())
    assert(isinstance(r, RoleMetadata))

# Generated at 2022-06-21 01:16:19.666128
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import sys
    from ansible.module_utils.six import PY3

    if PY3:
        def execfile(filename, globals):
            with open(filename) as f:
                exec(f.read(), globals)
    else:
        import imp

    main_file = os.path.join(os.path.dirname(__file__), "test_data", "role_meta", "main.yml")
    gi_file = os.path.join(os.path.dirname(__file__), "test_data", "role_meta", "gi.yml")
    dep_file = os.path.join(os.path.dirname(__file__), "test_data", "role_meta", "deps.yml")

# Generated at 2022-06-21 01:16:24.213339
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata._allow_duplicates == False, "RoleMetadata does not default _allow_duplicates to False"
    assert role_metadata._dependencies == [], "RoleMetadata does not default _dependencies to []"

# Generated at 2022-06-21 01:16:31.020037
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta1 = RoleMetadata(owner=None)
    meta2 = RoleMetadata(owner=None).load_data(data={'dependencies': [{'src': '/home/user/roles'}]},
                                               variable_manager=None, loader=None)
    return

# test_RoleMetadata()

# Generated at 2022-06-21 01:16:37.677935
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    sample = dict(
        allow_duplicates=False,
        dependencies=[{'role': 'Ansible-commons.rhv'}],
        some_garbage=True
    )

    expected = dict(
        allow_duplicates=False,
        dependencies=[{'role': 'Ansible-commons.rhv'}]
    )

    rolemetadata_obj = RoleMetadata().load(sample, None)

    assert rolemetadata_obj.serialize() == expected

# Generated at 2022-06-21 01:16:42.827386
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_role_metadata = RoleMetadata(owner={'name': 'test_role', 'role_path':'/home/ansible/roles/test_role'})
    result_isinstance_dict = isinstance(test_role_metadata.data, dict)
    assert isinstance(test_role_metadata, RoleMetadata)
    assert result_isinstance_dict

# Generated at 2022-06-21 01:16:54.748599
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import json
    import textwrap
    data = json.loads(textwrap.dedent("""
    {
        "_metadata": {}
    }
    """))
    role = RoleMetadata().deserialize(data)
    data = role.serialize()
    assert data == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-21 01:17:05.596292
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.include import RoleInclude

    my_play = Play.load({
        'name': 'test_play',
        'hosts': 'all',
        'roles': [
            'role1',
            {
                'role': 'role2',
                'some_param': 'foo'
            }
        ]
    }, variable_manager=None, loader=None)

    role1 = Role.load({
        'name': 'role1',
    }, play=my_play, variable_manager=None, loader=None)


# Generated at 2022-06-21 01:17:10.704210
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata(owner=None)
    r.allow_duplicates=True
    r.dependencies=[1, 2, "string", {"name":"value"}]
    assert r.serialize() == {"allow_duplicates": True, "dependencies": [1, 2, "string", {"name":"value"}]}

# Generated at 2022-06-21 01:17:12.380390
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert (RoleMetadata().serialize() == {'allow_duplicates': False, 'dependencies': []})

# Generated at 2022-06-21 01:17:17.248241
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    path = '../ansible/playbook/role_include.py'
    with open(path, 'r') as f:
        data = f.read()
    tree = compile(data, path, 'exec', ast.PyCF_ONLY_AST)
    tree = ast.fix_missing_locations(tree)
    tree = ast.copy_location(tree, path)
    RoleMetadata.load(data)

if __name__ == "__main__":
    import ast

# Generated at 2022-06-21 01:17:20.385889
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_meta = RoleMetadata()
    assert role_meta._allow_duplicates == False
    assert role_meta._dependencies == []
    assert isinstance(role_meta._argument_specs, dict)

# Generated at 2022-06-21 01:17:23.641452
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m._allow_duplicates == False
    assert m._dependencies == []

# Generated at 2022-06-21 01:17:28.033313
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    r = RoleMetadata()
    assert r.deserialize(data) == None

    assert r._allow_duplicates == False
    assert r._dependencies == []

# Generated at 2022-06-21 01:17:28.517211
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-21 01:17:35.178610
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata(owner=None)
    r.allow_duplicates = True
    r.dependencies = ["test"]
    r.galaxy_info = "test"
    r.argument_specs = {}
    r.vars = {}

    assert(r.serialize() == {'allow_duplicates': True, 'dependencies': ['test']})


# Generated at 2022-06-21 01:17:50.866798
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_context = PlayContext()

    loader = DataLoader()
    host = Host(name="127.0.0.1", port=80)
    group = Group(name="ungrouped")

# Generated at 2022-06-21 01:17:53.063816
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    result = meta.serialize()
    assert 'allow_duplicates' in result
    assert 'dependencies' in result

# Generated at 2022-06-21 01:18:04.310858
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test loading of a role with no dependencies
    role0_data = {}
    role0 = RoleMetadata.load(role0_data, owner=None)
    assert len(role0._dependencies) == 0

    # Test loading of a role with dependencies
    role1_data = {'dependencies': ['role0', 'role1', 'role2']}
    role1 = RoleMetadata.load(role1_data, owner=None)
    assert len(role1._dependencies) == 3
    assert isinstance(role1._dependencies[0], RoleRequirement)
    assert isinstance(role1._dependencies[1], RoleRequirement)
    assert isinstance(role1._dependencies[2], RoleRequirement)
    assert role1._dependencies[0]._role_name == 'role0'
    assert role1._

# Generated at 2022-06-21 01:18:13.339625
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    def _get_fake_play():
        """
        Simple object simulating a play.
        """
        return type('Play', (object,), dict(
            hosts=['host1']
            ))

    def _get_fake_role(name, play):
        """
        Simple object simulating a role.
        """
        return type('Role', (object,), dict(
            _role_name=name,
            _role_path='fake_role_dir',
            _play=play,
            ))

    role_obj = _get_fake_role('testrole', _get_fake_play())
    rm = RoleMetadata(owner=role_obj)
    assert rm.serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-21 01:18:20.073746
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role import Role

    context = PlayContext()
    role_context = RoleContext(play=context)
    role = Role(name='test', role_context=role_context)

    def find_role(name, play=None, variable_manager=None, loader=None, collection_search_list=None):
        return name

    # tests default values
    role_metadata = RoleMetadata(owner=role)
    role_metadata.find_role = find_role
    role_metadata.load(dict(), variable_manager=None, loader=None)
    assert role_metadata.allow_duplicates == False
    assert len(role_metadata.dependencies) == 0

    # tests

# Generated at 2022-06-21 01:18:31.358961
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #There are lots of ways to load the class RoleMetadata,
    #but the load function can only load meta/main.yml
    #through loading the class Role
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from collections import namedtuple
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import var_loader

    # Load the class RoleMetadata through Role
    data = {'name': 'get_started', 'description': 'Ansible get started tutorial.',
            'dependencies': [
                {'src': 'st2x.common', 'path': 'tasks/common/main.yml', 'name': 'st2x.common'}
            ]}



# Generated at 2022-06-21 01:18:37.941292
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing import vault

    role_def = RoleDefinition()
    role_def.name = 'test_role'
    role_def._role_path = '/home/user/ansible_git/ansible/roles/test_role'
    meta = RoleMetadata()
    meta._owner = role_def
    meta.allow_duplicates = True
    meta.dependencies = [1,2,3]
    serialize_result = meta.serialize()
    assert serialize_result == dict(allow_duplicates=True, dependencies=[1,2,3])

# Generated at 2022-06-21 01:18:41.210593
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    a = RoleMetadata()
    a.deserialize({'allow_duplicates': True, 'dependencies': [{'name': 'test1', 'src': 'test1'}, {'name': 'test2', 'src': 'test2'}]})
    assert a._allow_duplicates == True
    assert a._dependencies == [{'name': 'test1', 'src': 'test1'}, {'name': 'test2', 'src': 'test2'}]

# Generated at 2022-06-21 01:18:44.376362
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    data = {}
    metadata.load_data(data)
    assert metadata.dependencies == []
    assert metadata.allow_duplicates == False
    assert metadata.serialize() == data

# Generated at 2022-06-21 01:18:47.533817
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    setattr(self, 'allow_duplicates', data.get('allow_duplicates', False))
    setattr(self, 'dependencies', data.get('dependencies', []))

# Generated at 2022-06-21 01:19:04.355155
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    m.deserialize(data = {'allow_duplicates': True, 'dependencies': ['common']})
    assert m._allow_duplicates == True
    assert m._dependencies == ['common']

# Generated at 2022-06-21 01:19:10.488676
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():  # type: () -> None
    """Unit test for method serialize of class RoleMetadata."""
    md = RoleMetadata()
    md.allow_duplicates = True
    md.dependencies = ["role1", "role2"]

    data = md.serialize()

    assert data['allow_duplicates'] == True
    assert data['dependencies'] == md.dependencies

# Generated at 2022-06-21 01:19:15.727660
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = ['dependencies_1', 'dependencies_2']
    assert(role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['dependencies_1', 'dependencies_2']})


# Generated at 2022-06-21 01:19:16.381423
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    assert True

# Generated at 2022-06-21 01:19:23.197046
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    play_data = dict(
        name='test play',
        hosts=["all"],
        roles=["role1"],
    )

    play = Play().load(play_data, variable_manager=None, loader=None)

    role1_data = dict(
        name='role1',
        meta=dict(
            allow_duplicates=True,
            dependencies=["role2", "role3"],
        )
    )

    role1 = Role().load(role1_data, play=play, variable_manager=None, loader=None)

    assert role1.get_name() == "role1"
    assert role1.metadata.allow_duplicates is True

# Generated at 2022-06-21 01:19:35.328817
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.role import Role
    # Test1
    data = {'meta/main.yml': '''
dependencies:
  - { src: "http://github.com/michaeljoseph/ansible-role-foo.git", scm: git, version: "1.0" }
  - { role: bar }
'''}
    role_metadata = RoleMetadata(owner=Role())
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager._extra_vars = {}
    variable_manager._options_vars = {}
    variable

# Generated at 2022-06-21 01:19:39.454970
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata('test')
    r.load_data()
    assert r._allow_duplicates == False
    assert r._dependencies == []
    assert r._galaxy_info == None
    assert r._argument_specs == {}


# Generated at 2022-06-21 01:19:47.625148
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()

# Generated at 2022-06-21 01:19:51.415206
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rol = RoleMetadata()
    rol._allow_duplicates = False
    rol._dependencies = []
    result = rol.serialize()
    assert result == dict(allow_duplicates=False, dependencies=[])


# Generated at 2022-06-21 01:19:59.546333
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    serialized = dict(
        allow_duplicates='{allow_duplicates}',
        dependencies='{dependencies}'
    )
    metadata.deserialize(serialized)
    print("Test for deserialize method of class RoleMetadata: ")
    print("Type of attribute allow_duplicates: " + str(type(metadata.allow_duplicates)))
    print("Type of attribute dependencies: " + str(type(metadata.dependencies)))
    print("New RoleMetadata: " + str(metadata.serialize()))

test_RoleMetadata_deserialize()

# Generated at 2022-06-21 01:20:29.902921
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import sys

    if sys.version_info[0] == 2:
        class Play:
            def __init__(self):
                self._variable_manager = ''
                self._loader = ''
                self._tqm = ''

        class Role:
            def __init__(self):
                self._play = Play()

        role = Role()
        role._role_name = 'role'
        role._role_path = 'role_path'
        metadata = RoleMetadata(owner=role)
        assert metadata.serialize() == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-21 01:20:38.073283
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    sut = RoleMetadata()
    sut.deserialize(dict(
        allow_duplicates=True,
        dependencies=['role1', 'role2']
    ))
    assert sut.allow_duplicates == True
    assert len(sut.dependencies) == 2
    assert sut.dependencies[0].role == 'role1'
    assert sut.dependencies[1].role == 'role2'

# Generated at 2022-06-21 01:20:49.119827
# Unit test for method load of class RoleMetadata

# Generated at 2022-06-21 01:21:00.368896
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test role dependencies

# Generated at 2022-06-21 01:21:03.116170
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    a = RoleMetadata()
    assert a._allow_duplicates is False
    assert a._dependencies == []
    assert a._galaxy_info == {}
    assert a._argument_specs == {}

# Generated at 2022-06-21 01:21:06.166760
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Test setup
    good_role_metadata = dict(
        allow_duplicates=False
    )

    # Test execution
    rm = RoleMetadata.load(good_role_metadata, owner=None)

    # Test assertion
    assert isinstance(rm, RoleMetadata)

# Generated at 2022-06-21 01:21:17.371212
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    assert RoleMetadata.load({}, None) is not None, 'RoleMetadata load method should return a valid role metadata'
    assert RoleMetadata.load({}, None)._allow_duplicates is False, 'RoleMetadata load method should return a role metadata with allow_duplicates unset'
    assert RoleMetadata.load({'allow_duplicates': True}, None)._allow_duplicates is True, 'RoleMetadata load method should return a role metadata with allow_duplicates set to True'

# Generated at 2022-06-21 01:21:20.071513
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata()
    assert role_meta.serialize() == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-21 01:21:24.211279
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.include import RoleInclude
    role_metadata = RoleMetadata()
    role_metadata.load({}, None)

    assert isinstance(role_metadata.dependencies, list)
    assert isinstance(role_metadata.dependencies[0], RoleInclude)

# Generated at 2022-06-21 01:21:27.469971
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta = RoleMetadata(owner=None)
    setattr(role_meta, "_allow_duplicates", True)
    setattr(role_meta, "_dependencies", "test")
    assert role_meta.serialize() == {"allow_duplicates": True, "dependencies": "test"}


# Generated at 2022-06-21 01:22:27.310832
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMetadata

    dependency1 = RoleInclude()
    dependency1._role_name = "ansible.builtin"

    dependency2 = RoleInclude()
    dependency2._role_name = "common"

    dependency3 = RoleInclude()
    dependency3._role_name = "webserver"

    definition = RoleDefinition()
    definition._role_name = "my_role"
    definition._role_path = "/path/to/my_role"
    definition._parent_dir = "/path/to/"
    definition.dependencies = [ dependency1, dependency2 ]

    role_meta = RoleMetadata()
    role_meta._allow_dupl

# Generated at 2022-06-21 01:22:31.680624
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolemeta = RoleMetadata()
    rolemeta.dependencies = ['foo', 'bar']
    rolemeta.allow_duplicates = False
    check = {'dependencies': ['foo', 'bar'], 'allow_duplicates': False}
    assert rolemeta.serialize() == check


# Generated at 2022-06-21 01:22:38.327156
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Unit test for method deserialize of class RoleMetadata
    '''
    rmd = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=dict(role1=dict(), role2=dict()))
    rmd.deserialize(data)
    assert rmd.allow_duplicates == data.get('allow_duplicates', False)
    assert rmd.dependencies == data.get('dependencies', [])

# Generated at 2022-06-21 01:22:40.136885
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    testRoleMetadata = RoleMetadata()
    assert isinstance(testRoleMetadata, RoleMetadata)

# Generated at 2022-06-21 01:22:47.013012
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = {
        '_ansible_parsed': True,
        'allow_duplicates': True,
        'dependencies': [
            {'src': 'https://github.com/bgruening/galaxy-ngs-testing.git', 'scm':'git', 'name':'bgruening.ngs-test-collection'},
            {'role': 'dummy-role'},
        ],
    }
    m.deserialize(data)
    assert m._allow_duplicates == True
    assert len(m._dependencies) == 2

# Generated at 2022-06-21 01:22:51.624492
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert isinstance(r, RoleMetadata)
    assert r._variable_manager == None
    assert r._loader == None
    assert r._allow_duplicates == False
    assert r._dependencies == []


# Generated at 2022-06-21 01:22:56.241935
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition

    rd = RoleDefinition.load(dict(name='test'), play=None)
    meta = RoleMetadata(owner=rd)
    serialized = {'allow_duplicates': False, 'dependencies': []}
    assert serialized == meta.serialize()
    meta.allow_duplicates = True
    meta.dependencies = [{'role': 'test'}, {'role': 'test1'}]
    assert meta.allow_duplicates == True
    assert meta.dependencies == [{'role': 'test'}, {'role': 'test1'}]

# Generated at 2022-06-21 01:23:03.442306
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    meta_data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                src='git@github.com:test1.git',
                scm='git',
                version='testVersion',
                name='test1',
                path='tests/test1',
            )
        ]
    )

    role_metadata = RoleMetadata()
    role_metadata.deserialize(meta_data)

    assert role_metadata.allow_duplicates == True
    assert role_metadata._dependencies[0]._role_name == 'test1'

# Generated at 2022-06-21 01:23:03.941123
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    pass

# Generated at 2022-06-21 01:23:15.192463
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.unicode import to_string
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    # mock up the calling role
    calling_role = RoleDefinition()
    calling_role._role_path = '/calling/path'
    calling_role.name = 'some_name'
    calling_role._collections = ['col1', 'col2']
