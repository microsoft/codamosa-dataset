

# Generated at 2022-06-21 01:14:20.645578
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # test role metadata with empty meta/main.yml
    loader = DataLoader()

    role_path = os.path.join(os.path.dirname(__file__), '../../../test/support/test-roles/fake_role/tasks')
    pb = Play().load(dict(name="empty_role_meta",
                          type='fake_role',
                          host_pattern="all",
                          roles=[dict(name='fake_role')]),
                     variable_manager=VariableManager(), loader=loader, use_deprecated_implicit_roles=True)

# Generated at 2022-06-21 01:14:29.739397
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # All metadata is optional, so empty metadata is a valid input
    ds = {}
    m = RoleMetadata.load(ds, None, None, None)
    assert m._allow_duplicates == False
    assert not m._dependencies
    assert m._galaxy_info is None
    assert not m._argument_specs
    assert m._owner is None

    # Invalid types should throw an exception
    ds = {'dependencies': 'foo'}
    try:
        m = RoleMetadata.load(ds, None, None, None)
        assert False
    except AnsibleParserError:
        pass

    # The dependencies list must have role objects
    ds = {'dependencies': [{'role': 'an.example.role'}, 'foo']}

# Generated at 2022-06-21 01:14:33.075554
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata.dependencies = ['foo', 'bar']
    role_metadata.allow_duplicates = True
    result = dict(allow_duplicates=role_metadata.allow_duplicates, dependencies=role_metadata.dependencies)
    assert role_metadata.serialize() == result

# Generated at 2022-06-21 01:14:34.952887
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    m = RoleMetadata.load({}, RoleDefinition())

# Generated at 2022-06-21 01:14:47.282686
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    print('RoleMetadata Test')

    '''
    Test constructor
    '''
    test = RoleMetadata()
    assert isinstance(test, RoleMetadata)

    '''
    Test _load_dependencies() with an empty list
    '''
    data = test._load_dependencies(None, [])
    assert isinstance(data, list)
    assert len(data) == 0

    '''
    Test _load_dependencies() with a list of strings
    '''
    data = test._load_dependencies(None, [
        'ansible.builtin.copy',
        'ansible.builtin.template'
    ])
    assert isinstance(data, list)
    assert len(data) == 2

    '''
    Test _load_dependencies() with a list of dictionaries
    '''


# Generated at 2022-06-21 01:14:55.052508
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    data = {'dependencies': []}
    role_metadata = RoleMetadata(owner=None)
    role_metadata.load_data(data, variable_manager=None, loader=None)
    assert isinstance(role_metadata, object)
    assert isinstance(role_metadata, Base)
    assert isinstance(role_metadata, CollectionSearch)

if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-21 01:15:00.019419
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class Role(object):
        def __init__(self):
            self.name = 'test'

    role = Role()

    role_meta = RoleMetadata(owner=role)
    data = role_meta.serialize()
    assert data['allow_duplicates'] is False
    assert data['dependencies'] == []


# Generated at 2022-06-21 01:15:03.690751
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert metadata._allow_duplicates == False
    assert metadata._dependencies == []
    assert metadata._galaxy_info == None
    assert metadata._argument_specs == {}

# Generated at 2022-06-21 01:15:14.032067
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role_include import RoleInclude
    from ansible.plugins import module_loader
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group

    class TestRole(object):
        role_path = '/test_roles/test_role'

        def __init__(self):
            pass

        def get_name(self):
            return 'test_role'

        def get_path(self):
            return self.role_path

        def get_variable_manager(self):
            return self.variable_manager


# Generated at 2022-06-21 01:15:20.939953
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.tests.unit.fixture_data import FixtureData
    from ansible.playbook.role.meta import RoleMetadata

    data = FixtureData.ROLE_META_DATA1
    obj = RoleMetadata.load(data, None)
    serialized = obj.serialize()

    assert serialized == {
        'allow_duplicates': False,
        'dependencies': []
    }

# Generated at 2022-06-21 01:15:36.625144
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition

    current_role_path = '/home/ansible/ansible-modules-core/lib/ansible/modules/core'

    role = RoleDefinition.load({'name': 'core_modules_core'}, loader=None, variable_manager=None, path_list=[current_role_path])


# Generated at 2022-06-21 01:15:39.809181
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    #TODO fix this
    field_attr = FieldAttribute(isa="bool", default=False)
    test_obj = RoleMetadata()
    print(test_obj.serialize())


# Generated at 2022-06-21 01:15:45.090164
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.meta import RoleMetadata
    data = dict(dependencies=[{'role':1},{'role':2}])
    roledata = RoleMetadata()
    roledata.deserialize(data)
    assert roledata._dependencies == [{'role':1},{'role':2}]

# Generated at 2022-06-21 01:15:48.902958
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()

    m.allow_duplicates=True
    m.dependencies=['a','b']

    assert m.serialize() == {'allow_duplicates': True, 'dependencies': ['a', 'b']}

# Generated at 2022-06-21 01:15:52.039126
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    roleMetadata = RoleMetadata()

    roleMetadata.deserialize(dict(allow_duplicates=True, dependencies=[]))

    assert roleMetadata.allow_duplicates == True



# Generated at 2022-06-21 01:15:54.842425
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    output = m.serialize()
    assert output['allow_duplicates'] == False
    assert output['dependencies'] == []

# Generated at 2022-06-21 01:15:59.416191
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    fh = open('tests/units/data/role_meta_main.yml', 'rb')
    data = fh.read()
    fh.close()

    print(data)
    obj = RoleMetadata.load(data, owner=None)
    print(obj)
    attr = obj._attributes_to_serialize
    print(attr)

if __name__ == '__main__':
    test_RoleMetadata_load()

# Generated at 2022-06-21 01:16:03.625489
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    my_role = Role()
    my_role.name = "test_role"
    my_role._role_path = "/tmp/my_role"
    my_metadata = RoleMetadata()
    my_metadata.load( { 'dependencies': [ { 'role': 'test_role', 'version_requirement': '*' } ] }, my_role)
    # to_native(my_metadata)
    print(my_metadata)

if __name__ == "__main__":
    test_RoleMetadata_load()

# Generated at 2022-06-21 01:16:08.353864
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    rd = RoleDefinition.load({
        'name': 'apache',
        'collection': 'my.collection',
    })
    rd._role_path = 'some/path/to/role'

    rd._role_collection = None
    rm = RoleMetadata.load({}, rd)

    # this should set collection to ansible.legacy and name to apache
    rm = RoleMetadata.load({}, rd)

# Generated at 2022-06-21 01:16:08.945853
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    pass

# Generated at 2022-06-21 01:16:23.438917
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = [{'role': 'common'}, {'role': 'webservers'}]
    role_metadata._galaxy_info = None
    role_metadata._argument_specs = {}

    serialized = role_metadata.serialize()
    assert serialized['allow_duplicates'] == True, 'allow_duplicates() should be True but is %s' % serialized
    assert serialized['dependencies'][0]['role'] == 'common', 'dependencies()[0][\'role\'] should be \'common\' but is %s' % serialized['dependencies'][0]['role']

# Generated at 2022-06-21 01:16:32.090213
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # the input data structure 
    data = dict(
        allow_duplicates = False,
        dependencies = [
            dict(
                role = 'my_role',
            ),
            dict(
                name = 'my_role2',
            )
        ]
    )

    # instantiate a object of class RoleMetadata
    r = RoleMetadata(owner = None)
    
    # load the data
    r.load(data, owner = None)

    # test the code block 3 of method RoleMetadata.load
    assert r._allow_duplicates == data['allow_duplicates']
    assert r._dependencies[0]['role'] == data['dependencies'][0]['role']
    assert r._dependencies[1]['name'] == data['dependencies'][1]['name']

# Generated at 2022-06-21 01:16:37.984949
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    role_meta.deserialize(
        {'allow_duplicates': True,
        'dependencies': ['dependency1', 'dependency2']})
    assert role_meta.allow_duplicates == True
    assert role_meta.dependencies == ['dependency1', 'dependency2']


# Generated at 2022-06-21 01:16:49.441484
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.requirement import RoleRequirement
    # deserialize sets _allow_duplicates and _dependencies
    # _allow_duplicates = FieldAttribute(isa='bool', default=False)
    # _dependencies = FieldAttribute(isa='list', default=list)
    #
    # Without parent self._owner does not exist
    rm=RoleMetadata()
    #
    # Testing the setting of _allow_duplicates
    #
    # If data.get('allow_duplicates', False) is not specified, it should be set to False
    assert rm._allow_duplicates == False
    #
    # Test setting _allow_duplicates to True
    rm.deserialize(dict(allow_duplicates=True))
    assert rm._allow_duplicates == True
   

# Generated at 2022-06-21 01:16:57.449920
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata=RoleMetadata()
    role_metadata.deserialize({"allow_duplicates":True})
    assert role_metadata._allow_duplicates==True
    assert role_metadata._dependencies==[]
    role_metadata.deserialize({"dependencies":[{"foo":"bar"}]})
    assert role_metadata._dependencies==[{'foo':'bar'}]
    role_metadata.deserialize({"allow_duplicates":True,"dependencies":[{"foo":"bar"}]})
    assert role_metadata._allow_duplicates==True
    assert role_metadata._dependencies==[{'foo':'bar'}]


# Generated at 2022-06-21 01:16:58.688810
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata != None

# Generated at 2022-06-21 01:17:03.026111
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role = RoleMetadata()
    # Test deserialize
    assert role.deserialize({'allow_duplicates': False, 'dependencies': []}) == None
    assert role.deserialize({'allow_duplicates': True, 'dependencies': []}) == None



# Generated at 2022-06-21 01:17:14.153253
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    vars = [
        {'role': 'web', 'dest': '/etc/nginx'},
        {'role': 'monitoring', 'server': 'monitoring.example.com'},
        {'name': 'galaxy.ns.role,version', 'server': 'monitoring.example.com'},
    ]

    role_metadata = RoleMetadata.load(vars, None)

    assert role_metadata.dependencies[0]['name'] == 'web'
    assert role_metadata.dependencies[0]['dest'] == '/etc/nginx'
    assert role_metadata.dependencies[1]['name'] == 'monitoring'
    assert role_metadata.dependencies[1]['server'] == 'monitoring.example.com'

# Generated at 2022-06-21 01:17:17.030663
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolemetadata = RoleMetadata()
    rolemetadata.allow_duplicates = 'false'
    rolemetadata.dependencies = list()
    expected = {'allow_duplicates': 'false', 'dependencies': list()}
    assert rolemetadata.serialize() == expected


# Generated at 2022-06-21 01:17:19.562855
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    try:
        role_metadatas = RoleMetadata(owner=None)
        print("Success")
    except Exception as e:
        print("Failed to construct RoleMetadata", e)

# Unit test
if __name__ == '__main__':
    test_RoleMetadata()

# Generated at 2022-06-21 01:17:32.100990
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = dict(allow_duplicates=False, dependencies=list())
    result = RoleMetadata().deserialize(data)
    assert result.allow_duplicates == data['allow_duplicates']
    assert result.dependencies == data['dependencies']



# Generated at 2022-06-21 01:17:41.461714
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    testcases = [
        dict(
            allow_duplicates=True,
            dependencies=[],
            serialized_data=dict(
                allow_duplicates=True,
                dependencies=[]
            )
        ),
        dict(
            allow_duplicates=False,
            dependencies=[],
            serialized_data=dict(
                allow_duplicates=False,
                dependencies=[]
            )
        ),
        dict(
            allow_duplicates=False,
            dependencies=[1, 2],
            serialized_data=dict(
                allow_duplicates=False,
                dependencies=[1, 2]
            )
        ),
    ]

    for testcase in testcases:
        assert RoleMetadata._serialize(testcase['allow_duplicates'], testcase['dependencies']) == test

# Generated at 2022-06-21 01:17:50.803595
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook import Play, Playbook
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Make a dummy Playbook
    pb = Playbook().load([
        dict(
            name = "test playbook",
            hosts = 'localhost',
            tasks = [],
        ),
    ])
    pb._basedir = "/"

    # Make a dummy Inventory
    inv = Inventory(loader=DataLoader())

    # Make a dummy VariableManager
    variable_manager = VariableManager()

    # Create a dummy Task
    class Task(object):
        def __init__(self, name, play):
            self.name = name
            self.play = play
            self.role = None


# Generated at 2022-06-21 01:17:52.333148
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert len(role_metadata.dependencies) == 0

# Generated at 2022-06-21 01:17:53.591306
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # FIXME
    raise NotImplementedError

# Generated at 2022-06-21 01:17:57.303071
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = {'allow_duplicates':True,
            'dependencies':['common', 'webserver']
           }

    print(RoleMetadata(owner=None).serialize())


# Generated at 2022-06-21 01:18:08.099726
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class MyRole(object):
        role_path = '/tmp'
        name = 'myrole'

    role = MyRole()
    data = dict(
        allow_duplicates=False,
        dependencies=[
            dict(src='git.example.org/foo/bar.git')
        ]
    )

    metadata = RoleMetadata.load(data, role)
    assert isinstance(metadata, RoleMetadata)
    assert isinstance(metadata.dependencies[0], RoleRequirement)
    assert metadata.dependencies[0].role == 'bar'
    assert metadata.dependencies[0].src == 'git.example.org/foo/bar.git'
    assert isinstance(metadata.dependencies[0]._role_name, basestring)
    assert metadata.dependencies[0]._role_name == 'bar'


# Generated at 2022-06-21 01:18:16.090389
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # initialize a RoleMetadata object
    role_metadata = RoleMetadata()

    # set up a fake role
    role_path = '/tmp/role_path'
    fake_role = type('role', (object,), {'_role_path': role_path})()

    # test with valid parameters
    data = {
        'allow_duplicates': True,
        'dependencies': [],
    }
    role_metadata = role_metadata.load(data, fake_role)
    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == []

    # test with invalid allow_duplicates
    data = {
        'allow_duplicates': 'yes',
        'dependencies': [],
    }

# Generated at 2022-06-21 01:18:22.731516
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition.load({'name': 'test-role'})
    assert RoleMetadata.load({}, role).serialize() == {'allow_duplicates': False, 'dependencies': []}
    assert RoleMetadata.load({'dependencies': []}, role).serialize() == {'allow_duplicates': False, 'dependencies': []}

# Generated at 2022-06-21 01:18:25.502368
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata().__dict__ == {'_allow_duplicates': False, '_dependencies': [], '_galaxy_info': None, '_argument_specs': {}, '_owner': None}

# Generated at 2022-06-21 01:18:38.705302
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    current = RoleMetadata(owner = RoleDefinition.load('michael', dict(), loader = None))
    assert current is not None

# Generated at 2022-06-21 01:18:47.295822
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    owner = RoleDefinition()
    role_metadata = RoleMetadata.load({}, owner)
    assert isinstance(role_metadata, RoleMetadata)
    assert role_metadata._dependencies == []

    owner = RoleDefinition()
    role_metadata = RoleMetadata.load({
        'dependencies': [
            'common'
        ]
    }, owner)
    assert isinstance(role_metadata, RoleMetadata)
    assert isinstance(role_metadata._dependencies[0], RoleRequirement)

# Generated at 2022-06-21 01:18:57.841659
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import os
    from ansible.playbook.role.definition import RoleDefinition

    owner = RoleDefinition(
        role_path = '/Users/shimon/test',
        role_name = 'test',
        play_context = None,
        _variable_manager = None,
        loader = None,
    )

    def comp(name, value, data):
        if name in data and data[name] == value:
            del data[name]
        else:
            raise Exception(name + ' not found')

    data = { 
        'dependencies': ['a', 'b', 'c'],
        'allow_duplicates': False
    }

    RoleMetadata.load(data, owner)


# Generated at 2022-06-21 01:19:00.879760
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    ds = dict(
        allow_duplicates=False,
        dependencies=[]
    )

    m = RoleMetadata().deserialize(data=ds, tmp=False)
    m.serialize()

# Generated at 2022-06-21 01:19:12.871051
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test 1: create a RoleMetadata object without any parameters.
    role_metadata1 = RoleMetadata()
    assert role_metadata1.allow_duplicates == False
    assert role_metadata1.dependencies == []
    assert role_metadata1.galaxy_info == None
    assert role_metadata1.argument_specs == {}
    assert role_metadata1.metadata_files == []

    # Test 2: create a RoleMetadata object with a Role object as parameter.
    role_metadata2 = RoleMetadata(owner=Role())
    assert role_metadata2.allow_duplicates == False
    assert role_metadata2.dependencies == []
    assert role_metadata2.galaxy_info == None
    assert role_metadata2.argument_specs == {}
    assert role_metadata2.metadata_files == []

# Generated at 2022-06-21 01:19:13.701382
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:19:21.888149
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.six import text_type, PY3
    from ansible.vars import VariableManager
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    import sys

    if PY3:
        unicode = str
        basestring = str


# Generated at 2022-06-21 01:19:27.194713
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role import Role
    r = Role()
    m = RoleMetadata(owner=r)
    m.dependencies = ['foo', 'bar']
    m.allow_duplicates = True
    assert m.serialize() == dict(
            allow_duplicates=True,
            dependencies=['foo', 'bar']
    )

# Generated at 2022-06-21 01:19:32.955171
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    data = {'allow_duplicates': False}
    role_metadata.deserialize(data)
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == []

if __name__ == "__main__":
    test_RoleMetadata_deserialize()

# Generated at 2022-06-21 01:19:43.080112
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition.load(dict(
        name='foo',
        tasks=[{'debug': 'msg=foo'}],
    ))
    datastructure = dict(
        allow_duplicates=True,
        dependencies=[{'role':'bar'},{'name':'myrole'}]
    )
    role_meta = RoleMetadata(role)
    role_meta.deserialize(datastructure)
    assert role_meta._allow_duplicates == True, 'RoleMetadata can not deserialize metadata'
    assert role_meta._dependencies[0].get_name() == 'bar', 'RoleMetadata can not deserialize metadata'

# Generated at 2022-06-21 01:20:03.892377
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata()
    data = dict(
        galaxy_info=dict(
            author="Joe",
            description="My sweet little role"))
    m.load(data)
    assert 'Joe' == m.galaxy_info.author

# Generated at 2022-06-21 01:20:06.122490
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
  data = {'allow_duplicates': False, 'dependencies': []}
  assert (RoleMetadata().deserialize(data) == data)


# Generated at 2022-06-21 01:20:09.710008
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    setattr(role_metadata, 'allow_duplicates', True)
    setattr(role_metadata, 'dependencies', ['role1', 'role2'])
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}

# Generated at 2022-06-21 01:20:21.294833
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Testing case when there is data in the return value of method
    # serialize of class RoleMetadata.

    # Create a data structure to simulate the return value of method serialize
    # of class RoleMetadata.
    data = {'allow_duplicates':True, 'dependencies':['no-such-role', 'should-be-a-list']}

    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

    assert role_metadata.allow_duplicates == data['allow_duplicates']
    assert role_metadata.dependencies == data['dependencies']

    # Testing case when there is no data in the return value of method
    # serialize of class RoleMetadata.
    data = {}

    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

   

# Generated at 2022-06-21 01:20:29.817816
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-21 01:20:33.013575
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    own = None
    myRoleMetadata = RoleMetadata(owner=own)
    assert myRoleMetadata.allow_duplicates is False
    assert myRoleMetadata.dependencies == []

# Generated at 2022-06-21 01:20:35.068495
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    print(role_metadata)

# Generated at 2022-06-21 01:20:36.209350
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    #TODO
    pass

# Generated at 2022-06-21 01:20:41.451275
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    m = RoleMetadata()
    m.load({"dependencies": [{'role': "role1"}, "role2"], "allow_duplicates": True}, None)
    assert m.allow_duplicates
    assert len(m.dependencies) == 2

    # load an empty role file
    m = RoleMetadata()
    m.load({}, None)
    assert m.allow_duplicates == False
    assert len(m.dependencies) == 0

# Generated at 2022-06-21 01:20:53.181512
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Create a fake owner
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    class FakeRole(Base):
        pass
    class FakePlay(Base):
        pass
    fake_play = FakePlay()
    setattr(fake_play, 'tags', [])
    setattr(fake_play, '_ds', {})
    setattr(fake_play, '_task_blocks', [])

# Generated at 2022-06-21 01:21:15.717341
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    test_data = {"dependencies": [{"role": "foo", "vars": {"foo": "bar"}},
                                  {"role": "bar", "vars": {"bar": "foo"}}],
                 "galaxy_info": {"author": "foo", "description": "bar"}}

    meta = RoleMetadata.load(test_data, None)
    assert meta.dependencies[0].role == "foo"

# Generated at 2022-06-21 01:21:20.568775
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    class Owner():
        pass

    owner = Owner()
    owner._role_path = 'roles/test/meta/main.yml'
    result = RoleMetadata.load([{'role': 'test'}, 'test1'], owner)
    print(result)

# test_RoleMetadata_load()

# Generated at 2022-06-21 01:21:25.648360
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=['foo.bar', 'foo2.bar2']
    )
    role_metadata = RoleMetadata().deserialize(data)

    assert(role_metadata.allow_duplicates == data.get('allow_duplicates'))
    assert(role_metadata.dependencies == data.get('dependencies'))

# Generated at 2022-06-21 01:21:38.026826
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # test instantiation
    r = RoleMetadata()

    # test deserialize
    data = {
        'allow_duplicates': False,
        'dependencies': ['role1'],
    }
    r.deserialize(data)
    assert r._allow_duplicates == data['allow_duplicates']
    assert r._dependencies[0] == data['dependencies'][0]


# Generated at 2022-06-21 01:21:46.884526
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    class MockRole:
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    # create an instance of the RoleMetadata class:
    role_metadata = RoleMetadata(owner=MockRole("test-role"))

    # check that non-dictionary data raises an error:
    try:
        role_metadata.load("bad_data", MockRole("test-role"))
    except AnsibleParserError as e:
        assert "the 'meta/main.yml' for role test-role is not a dictionary" in to_native(e)

    # check that dependencies are parsed and a list is returned:

# Generated at 2022-06-21 01:21:50.424867
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize(dict(dependencies=['role1']))
    assert r._allow_duplicates is False
    assert r._dependencies == ['role1']


# Generated at 2022-06-21 01:22:01.197954
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    '''
    Test boolean values for duplicates
    '''
    import pytest
    for value in (True, False):
        data = {'allow_duplicates': value}
        role_meta = RoleMetadata()
        role_meta.deserialize(data)
        assert role_meta.allow_duplicates == value

    '''
    Test string values for dependencies
    '''
    data = {'dependencies': ['role1', 'role2']}
    role_meta = RoleMetadata()
    role_meta.deserialize(data)
    assert role_meta.dependencies == ['role1', 'role2']

    '''
    Test Malformed values for dependencies
    '''
    data = {'dependencies': ['role1', True]}
    role_meta = RoleMetadata()

# Generated at 2022-06-21 01:22:06.209938
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Create new object of class RoleMetadata
    role_metadata = RoleMetadata()

    # Get params of object
    result = role_metadata.serialize()

    # Check the result
    assert result == {
        'allow_duplicates': False,
        'dependencies': []
    }

# Generated at 2022-06-21 01:22:12.082268
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    m._allow_duplicates = False
    m._dependencies = [{'name': 'test-role'}]
    s = m.serialize()
    assert type(s) == dict
    assert type(s['allow_duplicates']) == bool
    assert type(s['dependencies']) == list
    assert type(s['dependencies'][0]) == dict

# Generated at 2022-06-21 01:22:16.202862
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_meta = RoleMetadata()
    data = dict(allow_duplicates = False, dependencies = ['test:role'])
    role_meta.deserialize(data)
    assert role_meta.allow_duplicates == False
    assert role_meta.dependencies == ['test:role']
    assert role_meta.serialize() == data


# Generated at 2022-06-21 01:22:59.337748
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.six import PY3
    import sys
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO


    def load_role_def(data):
        return DataLoader().load_from_file(path)


    class FakePlay(object):

        def __init__(self):
            self._basedir = os.path.realpath(os.path.dirname(__file__))

    class DataLoader(object):

        def load_from_file(self, path):
            stream = open(path, 'r')

# Generated at 2022-06-21 01:23:08.788469
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_include import RoleInclude
    from ansible.utils.collection_loader import AnsibleCollectionRef

    octarole = AnsibleCollectionRef.from_str('octa.tests')
    data = {
        'dependencies': [
            {'src': octarole},
            {'src': octarole, 'name': 'nested', 'scenario': 'inner'},
            {'src': 'nested-same-src'},
            {'src': 'nested-same-src', 'name': 'nested'}
        ]
    }

# Generated at 2022-06-21 01:23:20.274854
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context.CLIARGS = {}
    metadata = RoleMetadata(owner=object)
    metadata._variable_manager = VariableManager()
    metadata._loader = DataLoader()

# Generated at 2022-06-21 01:23:27.152911
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_dir = 'library/net_ping'
    role_module = __import__('test.units.playbook.role.test_role',
                             globals(),
                             locals(),
                             [role_dir])
    role_cls = getattr(role_module, 'TestRoleMeta')
    role = role_cls()

    test_case = dict(
        allow_duplicates=True,
        dependencies=[
            {'role': 'foobar'}
        ]
    )
    role_metadata = RoleMetadata(role)
    role_metadata.deserialize(test_case)

    assert role_metadata.allow_duplicates == test_case['allow_duplicates']
    assert len(role_metadata.dependencies) == 1

# Generated at 2022-06-21 01:23:32.691211
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    mapping = {
        "allow_duplicates": False,
        "dependencies": [
            {
                "role": "test_role",
                "collections": [],
                "scm": None,
                "version": "",
                "name": "test_role"
            }
        ],
        "galaxy_info": {}
    }
    assert RoleMetadata().load(mapping)

# Generated at 2022-06-21 01:23:42.984771
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    role = RoleDefinition()
    role._role_name = "test"
    role._role_path = "/path/to/my_role"
    role._role_collection = "test_collection"

    deps = [
        RoleRequirement.role_yaml_parse({'role': 'test1', 'foo': 'bar'}),
        RoleRequirement.role_yaml_parse({'role': 'test2'})
    ]

    role._metadata = RoleMetadata(owner=role)
    role._metadata._dependencies = deps

    loader = DataLoader()

# Generated at 2022-06-21 01:23:44.742501
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    instance = RoleMetadata()
    assert not hasattr(instance, 'allow_duplicates')
    assert not hasattr(instance, 'dependencies')

# Generated at 2022-06-21 01:23:46.709105
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    test_class = RoleMetadata()
    assert isinstance(test_class, RoleMetadata) == True, 'Error loading RoleMetadata from ansible.parsing.dataloader'

# Generated at 2022-06-21 01:23:57.775959
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # test to deserialize an empty data
    rm = RoleMetadata(None)
    data = {}
    rm.deserialize(data)
    assert rm.allow_duplicates == False
    assert rm.dependencies == []

    # test to deserialize an data with an empty dependencies
    data = {'allow_duplicates': False, 'dependencies': [] }
    rm.deserialize(data)
    assert rm.allow_duplicates == False
    assert rm.dependencies == []

    # test to deserialize an data with an empty allow_duplicates
    data = {'allow_duplicates': '', 'dependencies': [] }
    rm.deserialize(data)
    assert rm.allow_duplicates == False
    assert rm.dependencies == []

    # test to deserialize an