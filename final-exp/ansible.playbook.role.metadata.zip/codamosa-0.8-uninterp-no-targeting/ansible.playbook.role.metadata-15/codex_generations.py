

# Generated at 2022-06-21 01:14:24.968896
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    # Load data to be tested
    data = dict(
        allow_duplicates=True,
        dependencies=[
            dict(
                name='myrole',
                src='/usr/share/ansible/roles/myrole',
                scm='git',
                version_requirement='master'
            ),
            dict(
                name='myrole2',
                src='/usr/share/ansible/roles/myrole2',
                scm='git',
                version_requirement='master'
            )
        ]
    )

    # Object of class RoleMetadata
    obj = RoleMetadata()

    # Set data loaded
    setattr(obj, 'allow_duplicates', data.get('allow_duplicates', False))

# Generated at 2022-06-21 01:14:25.532105
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:14:28.390234
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_data = dict(
        allow_duplicates=True,
        dependencies=list()
    )
    instance = RoleMetadata()
    instance.deserialize(test_data)
    instance.serialize()


# Generated at 2022-06-21 01:14:30.113173
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    assert m.serialize() == {'allow_duplicates': False, 'dependencies': []}


# Generated at 2022-06-21 01:14:32.588132
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ds = dict(
        allow_duplicates = False,
        dependencies = []
    )
    RoleMetadata.deserialize(ds)
    assert ds == dict(
        allow_duplicates = False,
        dependencies = []
    )

# Generated at 2022-06-21 01:14:38.837437
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    """Create an instance of RoleMetadata and serialize it to validate that it will
    serialize for example for use in a role cache

    Args:
      None
    
    Returns:
      None

    """
    from ansible.playbook.role import Role
    rm = RoleMetadata()
    rm.load({
        "allow_duplicates": True,
        "dependencies": [
            "role1",
            "role2"
        ]
    }, owner=Role())
    s = rm.serialize()
    assert s.get('dependencies')
    assert s.get('allow_duplicates')

# Generated at 2022-06-21 01:14:45.334549
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata().serialize() == dict(allow_duplicates=False, dependencies=[])
    assert RoleMetadata(a=1).serialize() == dict(allow_duplicates=False, dependencies=[])
    assert RoleMetadata(a=2, allow_duplicates=True, dependencies=[1,2,3]).serialize() == dict(allow_duplicates=True, dependencies=[1, 2, 3])


# Generated at 2022-06-21 01:14:47.714452
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=True,
        dependencies=['foo', 'bar']
    )
    m = RoleMetadata().deserialize(data)
    assert m.serialize() == data

# Generated at 2022-06-21 01:15:00.182320
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.role_include import RoleInclude

    dl = DataLoader()
    vm = VariableManager()

    # Test loading a valid metadata

# Generated at 2022-06-21 01:15:01.060856
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:15:11.140092
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    meta={'Allow_duplicates': "func", 'Dependencies': 'func',
          'argument_specs': 'func', 'galaxy_info':'func'}
    data=RoleMetadata.load(meta, None)
    print(vars(data))

# Generated at 2022-06-21 01:15:14.404574
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    rolemeta = RoleMetadata()
    rolemeta.allow_duplicates = True
    rolemeta.dependencies = list()
    result = rolemeta.serialize()
    assert result['allow_duplicates'] == True
    assert result['dependencies'] == list()

# Generated at 2022-06-21 01:15:23.150516
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Create a new RoleMetadata object
    my_role_metadata = RoleMetadata()
    # Initialize a valid data structure for argument data
    data = dict(
        allow_duplicates=False,
        dependencies=[],
    )
    # Call class method deserialize with argument data
    my_role_metadata.deserialize(data)
    # Check that the deserialization was correctly done
    assert my_role_metadata.allow_duplicates == data['allow_duplicates']
    assert my_role_metadata.dependencies == data['dependencies']

# Generated at 2022-06-21 01:15:30.341819
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    '''
    Create a new RoleMetadata object:
      name: 'test'
      owner: 'owner'
      allow_duplicates: False
      dependencies: [1, 2, 3]
      galaxy_info: None
      argument_specs: {}
    '''
    roleMetadata = RoleMetadata()


if __name__ == "__main__":
    import sys
    import doctest
    failed, tested = doctest.testmod(report=True)
    sys.exit(failed - tested)

# Generated at 2022-06-21 01:15:34.976428
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition.load({}, play=None)

    meta = RoleMetadata(owner=role)
    meta.dependencies = ['foo']
    meta.allow_duplicates = True

    assert meta.serialize() == {'allow_duplicates': True, 'dependencies': ['foo']}

# Generated at 2022-06-21 01:15:35.738329
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    metadata = RoleMetadata()
    assert metadata._allow_duplicates == False
    assert metadata._dependencies == []

# Generated at 2022-06-21 01:15:37.573622
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():

    tst = RoleMetadata()

    assert tst._allow_duplicates == False
    assert tst._dependencies == []
    assert tst._galaxy_info == None
    assert tst._argument_specs == {}

# Generated at 2022-06-21 01:15:38.702573
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()

# Generated at 2022-06-21 01:15:47.688412
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    rd = RoleDefinition()
    rd._role_path = 'roles'
    rd._name = 'ansible'
    rm = RoleMetadata(rd)
    setattr(rm, 'allow_duplicates', True)
    setattr(rm, 'dependencies', ['dependecy1', 'dependecy2'])
    result = rm.serialize()
    assert isinstance(result, dict)
    assert result == {'allow_duplicates': True, 'dependencies': ['dependecy1', 'dependecy2']}

# Generated at 2022-06-21 01:15:51.244058
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata(owner=None)
    r.deserialize({'allow_duplicates': True,'dependencies': []})
    assert r._allow_duplicates == True
    assert r._dependencies == []


# Generated at 2022-06-21 01:16:10.293365
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    playbook = Playbook()

    play1 = Play()
    play1._load_name = 'play1'
    play1._role_name = 'test_role'
    play1._entries = []
    block1 = Block()
    block1._load_name = 'block1'
    block1._role_name = 'test_role'
    task1 = Task()
    task1._role_name = 'test_role'
    task1._load_name = 'task1'
    task2 = Task()
    task2._role_name = 'test_role'

# Generated at 2022-06-21 01:16:21.091415
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    data = dict(
        dependencies=['one', 'two', {'role': 'three', 'x': 'y'}],
        allow_duplicates=True,
    )

    owner = RoleDefinition()
    metadata = RoleMetadata.load(data, owner)
    assert metadata.allow_duplicates == True
    assert isinstance(metadata.dependencies[0], RoleInclude)
    assert isinstance(metadata.dependencies[1], RoleInclude)
    assert isinstance(metadata.dependencies[2], RoleRequirement)
    assert metadata.dependencies[0].name == 'one'

# Generated at 2022-06-21 01:16:24.839331
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    data = {'dependencies': ['role1', 'role2']}
    r.deserialize(data)
    assert r.dependencies == ['role1', 'role2']

# Generated at 2022-06-21 01:16:30.511566
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class Test_RoleMetadata(RoleMetadata):
        pass

    result = Test_RoleMetadata().serialize()
    expected = dict(
        allow_duplicates=False,
        dependencies=[],
    )

    assert result == expected

# Generated at 2022-06-21 01:16:40.249957
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    playbook_path = './test/playbooks/metadata/playbook.yml'
    data = RoleMetadata._load_playbook(playbook_path)
    assert 'metadata' in data
    assert 'hosts' in data
    assert 'roles' in data
    assert not data.get('hosts')
    assert not data.get('roles')

    variables = {}
    metadata = RoleMetadata.load(data['metadata'], owner='', variable_manager=variables)
    assert metadata is not None
    assert metadata._allow_duplicates == True
    assert len(metadata._dependencies) == 2

    # test dependencies
    for dep in metadata._dependencies:
        assert isinstance(dep, RoleRequirement)
        print(dep.role)
        print(dep.get_role_params())

# Generated at 2022-06-21 01:16:51.789329
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    def make_fake_role(name):
        '''
        Make a fake role definition.
        '''
        rd = RoleDefinition()
        setattr(rd, '_role_name', name)
        setattr(rd, '_role_path', 'meta/main.yml')
        return rd

    role = make_fake_role('foo')
    data = dict(
        allow_duplicates=True,
        dependencies=['bar', dict(role='baz', when='roles/baz/meta/main.yml is present')]
    )

    rm = RoleMetadata.load(data, owner=role)
    assert rm._allow_duplicates is True
    assert 2 == len(rm._dependencies)
    assert 'bar'

# Generated at 2022-06-21 01:16:57.606021
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    RoleMetadata_inst = RoleMetadata()
    allow_duplicates = True
    dependencies =['/aci/ansible_collections/cisco/aci/roles/aci_interface_policy']
    data = dict(allow_duplicates=allow_duplicates, dependencies=dependencies)
    RoleMetadata_inst.deserialize(data)
    assert allow_duplicates == RoleMetadata_inst.allow_duplicates
    assert dependencies == RoleMetadata_inst.dependencies



# Generated at 2022-06-21 01:17:07.797881
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    "Unit test for test_RoleMetadata_serialize of class RoleMetadata"

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    #  initializing default arguments of class RoleDefinition
    role_definition = RoleDefinition()
    # initializing default arguments of class RoleMetadata
    role_metadata = RoleMetadata()
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['name', 'someotherrole']
    result = role_metadata.serialize()
    assert "allow_duplicates" in result
    assert result["allow_duplicates"] == True
    assert "dependencies" in result
    assert result["dependencies"] == ['name', 'someotherrole']

# Generated at 2022-06-21 01:17:14.739890
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    a = RoleMetadata()
    v = {'allow_duplicates': False, 'dependencies': []}
    a.deserialize(v)
    # assert not setattr(a, 'allow_duplicates', data.get('allow_duplicates', False))
    assert setattr(a, 'allow_duplicates', data.get('allow_duplicates', False))
    assert setattr(a, 'dependencies', data.get('dependencies', []))


# Generated at 2022-06-21 01:17:24.373576
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    from ansible.utils.display import Display
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    display = Display()
    fixture = RoleMetadata()

    data = dict(
        allow_duplicates=False,
        dependencies=[]
    )
    fixture.deserialize(data)
    assert fixture.allow_duplicates == False
    assert fixture.dependencies == []

    data = dict(
        allow_duplicates=True,
        dependencies=[{
            'role': 'common'
        }]
    )
    fixture.deserialize(data)
    assert fixture.allow_duplicates == True
    assert fixture.dependencies == [{
            'role': 'common'
        }]

   

# Generated at 2022-06-21 01:17:48.592092
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    ds = {'dependencies': [{'name': 'foo', 'scm': 'git', 'src': 'x', 'version': '1.0'}]}
    rm = RoleMetadata()
    rm.deserialize(ds)

    assert rm.dependencies[0].role_name == 'foo'
    assert rm.dependencies[0].role_scm == 'git'
    assert rm.dependencies[0].role_src == 'x'
    assert rm.dependencies[0].role_version == '1.0'

# Generated at 2022-06-21 01:17:57.818069
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    variable_manager = VariableManager()
    loader = DataLoader()
    role = Role()

    galaxy_role = RoleMetadata()
    galaxy_role.load({'dependencies':
                        [{'role': 'bennojoy.nginx', 'scm': 'git', 'src': 'https://github.com/bennojoy/nginx.git'}]},
                      role,
                      variable_manager=variable_manager, loader=loader)

    assert galaxy_role.dependencies[0].role == 'bennojoy.nginx'
    assert galaxy_role.dependencies[0].scm == 'git'
    assert galaxy_role.dependencies[0].src == 'https://github.com/bennojoy/nginx.git'

# Generated at 2022-06-21 01:18:04.361583
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    import json

    # Deserialize data into a RoleMetadata object
    data = '{"allow_duplicates":false, "dependencies":["one", "two", "three"]}'
    data = json.loads(data)
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data)

    # Check attributes
    assert role_metadata.allow_duplicates == False
    assert role_metadata.dependencies == ["one", "two", "three"]

# Generated at 2022-06-21 01:18:11.722450
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    import ansible.collections
    collection_loader = ansible.collections.collection_loader

    import ansible.vars
    import ansible.parsing.dataloader
    from ansible.utils.display import Display

    display = Display()
    var_manager = ansible.vars.VariableManager()
    var_manager.extra_vars = {'inventory_hostname': 'localhost'}

    data_loader = ansible.parsing.dataloader.DataLoader()

    # Basic loading
    data = dict(
        allow_duplicates=False,
        dependencies=[{'name': 'example.role'}]
    )

    m = RoleMetadata.load(data, collection_loader, var_manager=var_manager, loader=data_loader)
    assert m.owner is None

# Generated at 2022-06-21 01:18:19.092839
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    testData = dict(
        name="ansible-test-role",
        allow_duplicates=False,
        dependencies=['dependency1', 'dependency2']
    )
    testObj = RoleMetadata()
    testObj.deserialize(data=testData)
    assert not testObj._allow_duplicates
    assert testObj._dependencies == ['dependency1', 'dependency2']
    assert testObj.serialize() == testData

# Generated at 2022-06-21 01:18:30.518380
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # check TypeError on no argument
    try:
        meta = RoleMetadata()
    except TypeError as e:
        pass

    # check no TypeError on proper argument
    data = {
        'dependencies' : [
            { 'role' : 'ansible-role-postgresql' },
            'ansible-role-redis',
            'ansible-role-webserver',
        ],
    }
    meta = RoleMetadata().load(data, None)
    dependencies = meta.dependencies
    assert isinstance(dependencies, list)
    assert len(dependencies) == 3
    assert isinstance(dependencies[0], RoleRequirement)
    assert isinstance(dependencies[1], RoleRequirement)
    assert dependencies[2] == 'ansible-role-webserver'

# Generated at 2022-06-21 01:18:32.726406
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import ansible.playbook.role.meta
    assert issubclass(ansible.playbook.role.meta.RoleMetadata, ansible.playbook.base.Base)

# Generated at 2022-06-21 01:18:44.017722
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    p = Play()
    pb = Playbook()
    p._playbook = pb
    p._play_basedir = "/a/b/c"
    p._loader = pb._loader
    p._variable_manager = pb._variable_manager


# Generated at 2022-06-21 01:18:55.458773
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_metadata = RoleMetadata()
    role_metadata._allow_duplicates = True
    role_metadata._dependencies = [
        {'role': 'common', 'name': 'webservers', 'private': True},
        {'role': 'loadbalancer', 'private': True},
        'test_roles/geerlingguy.nginx',
        'test_roles/nicholasdille.docker',
        'test_roles/nicholasdille.inspec',
    ]

# Generated at 2022-06-21 01:18:58.632266
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    d = {'allow_duplicates': True,
         'dependencies': ['woot']}
    task_meta = RoleMetadata()
    task_meta.deserialize(d)

    assert task_meta.allow_duplicates == True
    assert task_meta.dependencies == ['woot']

# Generated at 2022-06-21 01:19:20.056036
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data = {
        'allow_duplicates': True,
        'dependencies': [
            {'role': 'common'},
            {'role': 'webtier', 'some_parameter': 43},
            dict(role='database', foo='baz', bar='baz')
        ],
    }

    role_metadata = RoleMetadata().deserialize(data)

    assert role_metadata._allow_duplicates == True
    assert role_metadata._dependencies == [
        RoleRequirement.role_yaml_parse({'role': 'common'}),
        RoleRequirement.role_yaml_parse({'role': 'webtier', 'some_parameter': 43}),
        RoleRequirement.role_yaml_parse(dict(role='database', foo='baz', bar='baz'))
    ]

# Generated at 2022-06-21 01:19:30.392154
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    Playbook = Play().load({
        'name': 'foobar',
        'hosts': 'all',
        'roles': [{
            'role': 'geerlingguy.test-role'
        }, 'test', 'test_role'],
        'tasks': [
            {'name': 'test task 1', 'include_role': 'test-role'}
        ]
    }, PlayContext(), variable_manager=None, loader=None)
    Playbook._post_validate()

    task = Task()

# Generated at 2022-06-21 01:19:39.702323
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from collections import namedtuple
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.role.requirement import RoleRequirement
    Role = namedtuple('Role', ['allow_duplicates', 'dependencies'])
    role = Role(allow_duplicates=True, dependencies=[RoleRequirement(role='test')])
    ret = RoleMetadata.serialize(role)
    expected_ret = ImmutableDict(allow_duplicates=True, dependencies=[{'role': 'test'}])
    assert type(ret) == type(expected_ret)
    assert ret == expected_ret


# Generated at 2022-06-21 01:19:50.644243
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_include import RoleInclude
    owner = RoleDefinition.load('galaxy.example.role')
    data = dict(
        allow_duplicates='yes',
        dependencies=[
            dict(
                role='galaxy.example.role@2.0',
                scm='https://github.com/example/role.git',
                version='v2.0'
            ),
            dict(
                role='galaxy.example.role2',
                scm='https://github.com/example/role2.git',
                version='master'
            )
        ],
        galaxy_info=dict(
            author='John Doe',
            company='John Doe Inc.',
        )
    )
    role_meta = RoleMetadata

# Generated at 2022-06-21 01:19:54.636547
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    d = {'allow_duplicates': True, 'dependencies': ['myrole']}
    m.deserialize(d)
    assert m.allow_duplicates == True
    assert m.dependencies == ['myrole']

# Generated at 2022-06-21 01:19:58.257043
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    base_serialized = Base.serialize(r)
    assert r.serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }


# Generated at 2022-06-21 01:19:58.920994
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert True

# Generated at 2022-06-21 01:19:59.568403
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-21 01:20:03.216365
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Test parameters
    data = {}
    owner = None

    # Test constructor
    result_metadata = RoleMetadata.load(data, owner)
    assert (result_metadata._allow_duplicates == False)

test_RoleMetadata()

# Generated at 2022-06-21 01:20:08.138597
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta = RoleMetadata()
    setattr(meta, 'allow_duplicates', True)
    setattr(meta, 'dependencies', ['test-role1','test-role2'])
    expected_data = dict(
        allow_duplicates=True,
        dependencies=['test-role1','test-role2']
    )
    result = meta.serialize()
    assert result == expected_data


# Generated at 2022-06-21 01:20:51.126757
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    task = RoleMetadata()
print(test_RoleMetadata())

# Generated at 2022-06-21 01:20:52.881348
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metad = RoleMetadata()
    assert role_metad != None


# Generated at 2022-06-21 01:21:01.183695
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    r = RoleMetadata()
    r._allow_duplicates = True
    r._dependencies = ['/etc/ansible/roles/a/molecule/default',
                       '/etc/ansible/roles/a/molecule/webservers']
    ser = r.serialize()
    assert (ser['allow_duplicates'] == True)
    assert (ser['dependencies'] == ['/etc/ansible/roles/a/molecule/default',
                                    '/etc/ansible/roles/a/molecule/webservers'])

# Generated at 2022-06-21 01:21:06.783158
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    data = dict(
        allow_duplicates=False,
        dependencies=['foo', dict(role='foo', other='val'), dict(name='foo')])
    res = RoleMetadata.load(data, None, None, None)
    assert res._allow_duplicates == False
    assert res._dependencies[0].get_info() == 'foo'
    assert res._dependencies[1].get_info() == 'foo, other=val'
    assert res._dependencies[2].get_info() == 'foo'

# Generated at 2022-06-21 01:21:13.113118
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data1 = {'allow_duplicates': False, 'dependencies': []}
    data2 = {'allow_duplicates': True, 'dependencies': ['foo.role']}
    m1 = RoleMetadata()
    m2 = RoleMetadata()
    m2._allow_duplicates = True
    m2._dependencies = ['foo.role']
    assert data1 == m1.serialize()
    assert data2 == m2.serialize()



# Generated at 2022-06-21 01:21:24.947150
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    manager = VariableManager()

    galaxy_role = 'test_role'
    role_path = loader.path_dwim(galaxy_role)
    metadata = os.path.join(role_path, 'meta')
    if not os.path.exists(metadata):
        os.makedirs(metadata)
    meta_file = os.path.join(metadata, 'main.yml')

# Generated at 2022-06-21 01:21:35.991956
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    import os
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    play = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'roles': [
            {
                'role': 'example',
            }
        ]
    }, variable_manager=None, loader=None)

    role = play.get_roles()[0]

    assert type(role.metadata) == RoleMetadata
    assert type(role.metadata.get_dependencies()) == list
    assert len(role.metadata.get_dependencies()) == 0


# Generated at 2022-06-21 01:21:45.495262
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play_context import PlayContext  
    from ansible.playbook.play import Play 
    from ansible.playbook.task import Task 
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block 

    p = Play() 
    t = Task()
    block = Block()
    block.block  = [t]

# Generated at 2022-06-21 01:21:52.877061
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Role:
        def __init__(self, name, path):
            self.name = name
            self._role_path = path
            self.collections = []

    testRole = Role("test", "path")
    data = dict(
        allow_duplicates=False,
        dependencies=['test']
    )
    testMeta = RoleMetadata(testRole)
    testMeta.deserialize(data)
    assert testMeta._allow_duplicates == False
    assert isinstance(testMeta._dependencies, (list))

# Generated at 2022-06-21 01:22:03.020446
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()
    role_include1 = {'role': 'role2', 'other_vars': 'var1'}
    role_include2 = {'role': 'role3', 'other_vars': 'var2'}
    dependency_roles = ['role1', role_include1, role_include2]
    m.dependencies = dependency_roles

    dependency_roles_serialized = [
        'role1',
        {
            'role': 'role2',
        },
        {
            'role': 'role2',
            'other_vars': 'var1',
        },
        {
            'role': 'role3',
        },
        {
            'role': 'role3',
            'other_vars': 'var2',
        },
    ]

    serialized

# Generated at 2022-06-21 01:23:00.085735
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import os
    import shutil
    import tempfile
    from ansible.module_utils.six import u
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.six.moves import configparser

    script_dir = os.path.dirname(unfrackpath(__file__))

    galaxy_roles_dir = '/usr/share/ansible/galaxy/roles/'

# Generated at 2022-06-21 01:23:03.549885
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
  from collections import namedtuple
  data = namedtuple('data', ['allow_duplicates', 'dependencies'])
  data.allow_duplicates = False
  data.dependencies = []
  test = RoleMetadata().serialize()
  assert test == data._asdict()

# Generated at 2022-06-21 01:23:07.978208
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    yaml_str = """
    allow_duplicates: True
    dependencies:
      - {role: webservers, some_parameter: foo}
    """

    role_metadata = RoleMetadata.load(yaml_str, None)
    serialized = role_metadata.serialize()

    assert serialized.get('allow_duplicates') == True
    assert len(serialized.get('dependencies')) == 1
    assert list(serialized.get('dependencies')[0].keys())[0] == 'role'

# Generated at 2022-06-21 01:23:19.559021
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Loader for role A
    loader_a = AnsibleLoader(dict(
        defaults = dict(),
        vars     = dict(),
        meta     = dict(
            allow_duplicates = True,
            dependencies     = [],
            galaxy_info      = 'test'
        )
    ), variable_manager=None)

    # Loader for role B

# Generated at 2022-06-21 01:23:24.847467
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(dict(dependencies=['foo', 'bar']))
    assert role_metadata.dependencies == ['foo', 'bar']
    role_metadata.deserialize(dict(allow_duplicates=True))
    assert role_metadata.allow_duplicates
    role_metadata.deserialize(dict(allow_duplicates=False))
    assert not role_metadata.allow_duplicates

# Generated at 2022-06-21 01:23:29.948533
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():

    role_metadata = RoleMetadata(owner={})
    role_metadata.allow_duplicates = True
    role_metadata.dependencies = ['geerlingguy.ntp']
    data = role_metadata.serialize()
    assert data == {'allow_duplicates': True, 'dependencies': ['geerlingguy.ntp']}

# Generated at 2022-06-21 01:23:31.431816
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    """
    Unit test for method load of class RoleMetadata
    """
    pass

# Generated at 2022-06-21 01:23:34.971692
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role_meta=RoleMetadata()
    role_meta.deserialize()
    assert dict(
        allow_duplicates=role_meta._allow_duplicates,
        dependencies=role_meta._dependencies
    )

# Generated at 2022-06-21 01:23:44.513360
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_data = {
        'allow_duplicates': True,
        'dependencies': [
            'role1',
            {
                'role': 'role2',
                'vars': {
                    'var1': 'val1',
                }
            }
        ]
    }
    r = RoleMetadata()
    r.deserialize(test_data)
    assert r._allow_duplicates == test_data['allow_duplicates']
    assert r._dependencies == test_data['dependencies']
    assert r._galaxy_info is None
    assert r._argument_specs == {}
    assert r._valid_attrs == {
        'allow_duplicates',
        'dependencies',
        'galaxy_info',
        'argument_specs'
    }
    assert r._

# Generated at 2022-06-21 01:23:50.800074
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.mapping import RoleMapping
    from ansible.playbook.role_include import RoleInclude

    meta_data = {
        'depends': ['test_role']
    }
    my_owner = RoleDefinition.load(meta_data, "test", variable_manager=None, loader=None)
    result = RoleMetadata.load(meta_data, my_owner, variable_manager=None, loader=None)
    assert result._owner == my_owner
    assert isinstance(result._dependencies[0], RoleInclude)
    assert result._dependencies[0]._role_name == 'test_role'
    assert isinstance(result._dependencies[0]._role, RoleMapping)