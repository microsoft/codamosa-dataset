

# Generated at 2022-06-21 01:14:25.073494
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.definition import RoleDefinition

    name = 'test'
    path = '/tmp'
    parent_role = RoleDefinition(
        name='test.parent',
        collection_name='test',
        collection_version='1.0.1',
        path=path
    )

    galaxy_info = dict(
        author='test@example.com',
        description='description',
        company='CompanyName',
        license='LicenseName',
        min_ansible_version='2.8',
        platforms=dict(
            platform1=dict(
                platform='platform1',
                version='1.x'
            ),
            platform2=dict(
                platform='platform2',
                version='2.x'
            )
        )
    )

    tags = ['tag1', 'tag2']


# Generated at 2022-06-21 01:14:25.426596
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:14:28.633767
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    test_meta = {'allow_duplicates': False, 'dependencies': []}
    test_obj = RoleMetadata()
    test_obj.deserialize(test_meta)

    assert test_obj.allow_duplicates == False
    assert test_obj.dependencies == []

# Generated at 2022-06-21 01:14:35.265053
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.collection import AnsibleCollectionRef

# Generated at 2022-06-21 01:14:41.862716
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata.load({
        'dependencies': [
            { 'role': 'SomeOtherRole', 'otherKey': 'otherKeyValue' },
            'OtherRole'
        ]
    })
    assert r.allow_duplicates == False
    assert len(r.dependencies) == 2

# Generated at 2022-06-21 01:14:49.817188
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.parsing.dataloader import DataLoader

    c = DataLoader()

    blob = dict(
        dependencies=[
            {'role': 'common', 'tags': 'always'},
            {'role': 'nginx', 'some_parameter': 33},
            {'role': 'apache', 'x': 1},
            dict(role='mysql', when='inventory_hostname == "foo"')
        ]
    )
    m = RoleMetadata().load(blob, DataLoader())
    assert len(m._dependencies) == 4

# Generated at 2022-06-21 01:14:52.279232
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    m = RoleMetadata()

    assert m.serialize() == {
        "allow_duplicates": False,
        "dependencies": []
    }

# Generated at 2022-06-21 01:14:57.854843
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    class Test(RoleMetadata):
        def __init__(self):
            self._dependencies = [1, 2, 3]
        def allow_duplicates(self):
            return False
    test = Test()
    assert test.serialize() == {'allow_duplicates': False, 'dependencies': [1, 2, 3]}

# Generated at 2022-06-21 01:15:08.009169
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    shared = {
        '_ansible_no_log': False, 
        '_ansible_verbosity': 0, 
        '_ansible_syslog_facility': 'LOG_USER',
        '_ansible_version': '2.9.0', 
        '_ansible_version_original': '2.9.0',
        '_ansible_callback_whitelist': [], 
        'ansible_check_mode': False, 
        'ansible_diff': True, 
        'ansible_fail_on_missing': True
    }

    rm = RoleMetadata()

# Generated at 2022-06-21 01:15:09.346981
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    result = RoleMetadata()
    assert result is not None

# Generated at 2022-06-21 01:15:20.070112
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    a = RoleMetadata()
    a.allow_duplicates = True
    a.dependencies = [1, 2, 3]

    assert a.serialize() == {'dependencies': [1, 2, 3]}

# Generated at 2022-06-21 01:15:22.071796
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert isinstance(RoleMetadata(owner=None), RoleMetadata)

# Generated at 2022-06-21 01:15:29.745385
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    '''
    Test the load method of RoleMetadata
        1. call RoleMetadata.load with valid data
    '''

    # 1. call RoleMetadata.load with valid data
    #    should return a RoleMetadata object
    #    should fail, "the 'meta/main.yml' for role ansible.posix is not a dictionary"
    #    should fail, "Expected role dependencies to be a list."
    #    should fail, "A malformed list of role dependencies was encountered."
    pass



# Generated at 2022-06-21 01:15:36.168472
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    r = RoleMetadata()
    r.deserialize(dict(allow_duplicates=False, dependencies=[]))
    assert getattr(r, 'allow_duplicates') == False
    assert getattr(r, 'dependencies') == []
    r.deserialize(dict(allow_duplicates=True, dependencies=[{'role': 'test'}]))
    assert getattr(r, 'allow_duplicates') == True
    assert getattr(r, 'dependencies') == [{'role': 'test'}]

# Generated at 2022-06-21 01:15:38.492468
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    # Test data
    data = dict(
        allow_duplicates=True,
        dependencies=[]
    )

    # Deserialize data
    m = RoleMetadata()
    m.deserialize(data)

# Generated at 2022-06-21 01:15:39.646656
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    r = RoleMetadata()
    assert True

# Generated at 2022-06-21 01:15:49.919401
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.role import Role
    import ansible.constants as C
    import ansible.utils.plugin_docs as plugin_docs

    C.DEFAULT_ROLES_PATH = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'test_data', 'roles')

    role = Role().load(os.path.join(C.DEFAULT_ROLES_PATH, 'role_with_duplicate_tags'))
    metadata = RoleMetadata.load(role._metadata, role, loader=plugin_docs.find_plugin)

    assert(metadata.allow_duplicates is True)

# Generated at 2022-06-21 01:15:58.341763
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.definition import RoleDefinition
    loader = DictDataLoader({
        "meta/main.yml": """
        allow_duplicates: true
        dependencies:
          - name: galaxy.role,version,name
        """,
    })
    role = RoleDefinition.load('/fake_role_path', loader=loader, variable_manager=VariableManager())
    role_meta = RoleMetadata.load(loader.get_basedir('meta/main.yml'), owner=role, loader=loader)
    assert role_meta.serialize() == dict(allow_duplicates=True, dependencies=[{'name': 'galaxy.role,version,name'}])



# Generated at 2022-06-21 01:16:07.978814
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    data = dict(
        allow_duplicates=True,
        dependencies=['name.test.role', 'name.test2.role']
    )
    m.deserialize(data=data)
    assert m._allow_duplicates is True
    assert m._dependencies == ['name.test.role', 'name.test2.role']
    m.deserialize(data='')
    assert m._allow_duplicates is False
    assert m._dependencies == []


# Generated at 2022-06-21 01:16:12.418601
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    # Initiailize test variables
    data = {'dependencies': ['foo', 'bar']}
    def mock_owner():
        # Mock methods
        def get_name():
            return 'test'

        owner = Mock()
        owner.get_name = Mock(side_effect=get_name)
        return owner

    # Call method
    RoleMetadata.load(data, mock_owner)

# Generated at 2022-06-21 01:16:37.984563
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_include import RoleInclude
    from ansible import constants as C

    data = """
        allow_duplicates: True
        dependencies:
            - { role: webservers, vars: {'http_port': 80 } }
            - common
    """

    role_name = 'webservers'
    role_path = '/etc/ansible/roles/%s' % role_name
    role = RoleDefinition.load(data=data, name=role_name, path=role_path)
    assert isinstance(role, RoleDefinition)

    m = RoleMetadata(owner=role)


# Generated at 2022-06-21 01:16:45.721913
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # load_data
    role = RoleMetadata()
    role.load_data({})
    assert role.allow_duplicates == False
    assert role.dependencies == []
    # deserialize
    data = {
        'allow_duplicates': True,
        'dependencies': ['test'],
    }
    role.deserialize(data)
    assert role.allow_duplicates == True
    assert role.dependencies == ['test']
    # serialize
    assert role.serialize() == data

# Generated at 2022-06-21 01:16:49.642895
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    test_dict = {"allow_duplicates": False, "dependencies": []}
    roleMetadata = RoleMetadata()
    roleMetadata.deserialize(test_dict)
    assert roleMetadata.allow_duplicates == False
    assert roleMetadata.dependencies == []

# Generated at 2022-06-21 01:16:50.194002
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m is not None

# Generated at 2022-06-21 01:16:50.824721
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    RoleMetadata()

# Generated at 2022-06-21 01:16:55.194673
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize(data={'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.dependencies == ['role1', 'role2']
    assert role_metadata.allow_duplicates is True


# Generated at 2022-06-21 01:16:55.646272
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:16:58.778476
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    assert RoleMetadata(owner=None).serialize() == {
        'allow_duplicates': False,
        'dependencies': []
    }


# Generated at 2022-06-21 01:17:09.364393
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    import pytest
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    t = RoleMetadata("test/path")
    t._allow_duplicates = False
    t._dependencies = [RoleInclude("role1/path"), RoleDefinition("role2"), RoleInclude("role3/path")]

    assert t.serialize() == dict(
        allow_duplicates=False,
        dependencies=[dict(name='role1', scm=None, src=None, version='HEAD'),
                      dict(name='role2', scm=None, src=None, version='HEAD'),
                      dict(name='role3', scm=None, src=None, version='HEAD')]
    )


# Generated at 2022-06-21 01:17:18.194504
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    meta_path = os.path.join(os.path.dirname(__file__), 'data', 'role_meta.yml')
    with open(meta_path, 'r') as f:
        metadata = f.read()
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_unsafe_proxy(UnsafeProxy(dict()))
    variable_manager.extra_vars = dict()

# Generated at 2022-06-21 01:17:44.396983
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    pass

# Generated at 2022-06-21 01:17:46.863725
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    m = RoleMetadata()
    assert m.allow_duplicates == False
    assert m.dependencies == []


# Generated at 2022-06-21 01:17:48.495195
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates' : True})
    assert role_metadata.allow_duplicates == True

# Generated at 2022-06-21 01:17:50.964957
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    test_obj = RoleMetadata()
    test_obj._allow_duplicates = False
    test_obj._dependencies = []

    assert test_obj.serialize() == dict(allow_duplicates=False, dependencies=[])

# Generated at 2022-06-21 01:17:51.768926
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    raise NotImplementedError()


# Generated at 2022-06-21 01:18:03.187136
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
  attr = '_load_galaxy_info'
  try:
    ds = {}
    ret = RoleMetadata(owner=1)._load_galaxy_info(attr, ds)
    assert(ret)
  except AssertionError as e:
    print("AssertionError")

  try:
    ds = None
    ret = RoleMetadata(owner=1)._load_galaxy_info(attr, ds)
    assert(ret)
  except AssertionError as e:
    print("AssertionError")

  try:
    ds = []
    ret = RoleMetadata(owner=1)._load_galaxy_info(attr, ds)
    assert(ret)
  except AssertionError as e:
    print("AssertionError")

# Generated at 2022-06-21 01:18:12.872405
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    loader = None
    variable_manager = None

    role0 = RoleDefinition.load({'role0': 'meta/main.yml'}, loader, variable_manager)
    role1 = RoleDefinition.load({'role1': 'meta/main.yml'}, loader, variable_manager)

    role0._role_path = '/path/to/role0'
    role1._role_path = '/path/to/role1'

    role0._role_collection = None
    role1._role_collection = None

    include0 = RoleInclude()
    include0._role_path = '/path/to/role0'
    include0._role_name = 'role0'

    include1 = Role

# Generated at 2022-06-21 01:18:15.849750
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    owners = 'own'
    data = {'allow_duplicates': 'True', 'dependencies': 'dep'}
    res = RoleMetadata().deserialize(data, owners)
    assert res.get('allow_duplicates') == 'True'
    assert res.get('dependencies') == 'dep'

# Generated at 2022-06-21 01:18:23.459708
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    t_role_meta = RoleMetadata()
    role_meta_data = {'allow_duplicates': 'False', 'dependencies': []}
    t_role_meta.deserialize(role_meta_data)
    assert t_role_meta.allow_duplicates == False
    assert t_role_meta.dependencies == []


# Generated at 2022-06-21 01:18:30.907091
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    class Owner(object):
        def __init__(self):
            self._role_path = ''
            self._role_collection = None
        def get_name(self):
            return ''
    class Play(object):
        def __init__(self):
            self._variable_manager = None
    data = {'dependencies':[]}
    owner = Owner()
    role_metadata = RoleMetadata(owner=owner)
    role_metadata.deserialize(data=data)
    assert role_metadata._dependencies == []

# Generated at 2022-06-21 01:19:25.147517
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    print("========test_RoleMetadata_deserialize=========")
    data = dict(
        dependencies=[],
        allow_duplicates=False
    )
    rm = RoleMetadata().deserialize(data)
    print(rm.__dict__)

# Generated at 2022-06-21 01:19:29.653213
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    data_in=dict(
        allow_duplicates=False,
        dependencies=[]
    )
    data_out=RoleMetadata().deserialize(data_in)
    assert data_out.allow_duplicates == False
    assert data_out.dependencies == []

# Generated at 2022-06-21 01:19:31.902914
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata()._allow_duplicates is False
    assert RoleMetadata()._dependencies == []

# Generated at 2022-06-21 01:19:36.116421
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    d = dict(
        allow_duplicates=False,
        dependencies=[
            dict(role='common', src='../../common_role')
        ]
    )
    m = RoleMetadata().load_data(d)
    assert m.serialize() == d

# Generated at 2022-06-21 01:19:39.373325
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Constructor with a None
    roleMetadata = RoleMetadata(None)
    assert roleMetadata is not None


# Generated at 2022-06-21 01:19:42.692833
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    meta_data = RoleMetadata()
    meta_data._allow_duplicates = True
    meta_data._dependencies = ['test']

    assert meta_data.serialize() == {'allow_duplicates': True, 'dependencies': ['test']}


# Generated at 2022-06-21 01:19:44.944294
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    # Check RoleMetadata can be instantiated
    r = RoleMetadata()
    assert r != None

# Generated at 2022-06-21 01:19:46.335525
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    assert RoleMetadata(owner=None)

# Generated at 2022-06-21 01:19:53.453638
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    role_metadata = RoleMetadata()
    role_metadata.deserialize({'allow_duplicates': True, 'dependencies': ['role1', 'role2']})
    assert role_metadata.allow_duplicates == True
    assert role_metadata.dependencies == ['role1', 'role2']
    assert role_metadata.serialize() == {'allow_duplicates': True, 'dependencies': ['role1', 'role2']}


# Generated at 2022-06-21 01:20:02.879699
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    current_path = os.path.abspath(os.getcwd())
    test_path = os.path.join(current_path, 'test')
    role_name = 'role_1'
    role_path = os.path.join(test_path, role_name)
    test_meta_main = 'test/meta/main.yml'
    role_meta = '{0}/meta/main.yml'.format(role_name)
    # Load metadate from file: meta/main.yml
    rm = RoleMetadata.load(role_meta, loader=None)
    # Test RoleMetadata constructor with a path
    rm.load(test_meta_main, loader=None)

# Generated at 2022-06-21 01:20:37.811987
# Unit test for constructor of class RoleMetadata
def test_RoleMetadata():
    role_metadata = RoleMetadata()
    assert role_metadata != None

# Generated at 2022-06-21 01:20:43.443559
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    rmd = RoleMetadata()
    setattr(rmd, 'allow_duplicates', True)
    setattr(rmd, 'dependencies', 'alice')
    data = {'allow_duplicates': False, 'dependencies': 'bob'}
    rmd.deserialize(data)
    assert rmd._allow_duplicates is False
    assert rmd._dependencies == ['bob']


# Generated at 2022-06-21 01:20:54.653996
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode

    from ansible.playbook.role import ROLE_CACHE
    from ansible.module_utils.six import PY3
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import get_all_plugin_loaders, PluginLoader
    from ansible.errors import AnsibleParserError
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.playbook.role.metadata import RoleMetadata

# Generated at 2022-06-21 01:21:05.076129
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    deserialized_data = dict(
        allow_duplicates=True,
        dependencies=[{'role': 'role1'}, {'role': 'role2', 'tags': 'tags1'}],
    )
    data = {}
    RoleMetadata.deserialize(data, deserialized_data)
    assert(data['allow_duplicates'] is True)
    assert(len(data['dependencies']) == 2)
    for i in range(0, len(deserialized_data['dependencies'])):
        role = deserialized_data['dependencies'][i]
        role_data = data['dependencies'][i]
        assert(role_data.get('role') == role['role'])
        assert(role_data.get('tags') == (role.get('tags')))

# Generated at 2022-06-21 01:21:16.103159
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    # Testing scenario with full example of metadata.yml
    metadata = dict(
            allow_duplicates=True,
            dependencies=[
                dict(role="foo"),
                dict(role="bar"),
                dict(role="baz", some_option="some_value"),
                dict(),
                "foo"
                ]
            )

    owner = dict(
            _play=dict(get_name=lambda: 'play'),
            _role_path='/path/to/role',
            )

    role_defs = RoleMetadata.load(metadata, owner, variable_manager=None, loader=None)._dependencies

    for x in range(0,3):
        assert isinstance(role_defs[x], dict)
    assert role_defs[0]['role'] == 'foo'
    assert role_defs

# Generated at 2022-06-21 01:21:26.615591
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.utils.password import get_secret

    # create dummy class
    class Dummy:
        name = "dummy"
        _role_path = "/dummy/path"

    context = PlayContext()
    templar = Templar(loader=None, variables=VariableManager())
    password_prompt = get_secret(prompt="Password:")
    # initialize RoleMetadata object
    obj = RoleMetadata.load({"dependencies": password_prompt}, owner=Dummy(), variable_manager=templar, loader=None)
    # check if object is of type RoleMetadata
    assert isinstance(obj, RoleMetadata)

# Generated at 2022-06-21 01:21:34.324771
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    role = RoleMetadata()
    role._allow_duplicates = False
    role._dependencies = ['test']
    assert role.serialize() == {'allow_duplicates': False, 'dependencies': ['test']}
    role._allow_duplicates = True
    role._dependencies = ['test', 'test2']
    assert role.serialize() == {'allow_duplicates': True, 'dependencies': ['test', 'test2']}

# Generated at 2022-06-21 01:21:44.278789
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():

    from ansible.playbook.role import Role

    r = Role()
    m = RoleMetadata.load({}, owner=r)

    assert m._allow_duplicates is False
    assert m._dependencies == []
    assert m._galaxy_info is None
    assert m._argument_specs == {}
    assert m._owner == r

    m = RoleMetadata.load({'allow_duplicates': True}, owner=r)

    assert m._allow_duplicates is True
    assert m._dependencies == []
    assert m._galaxy_info is None
    assert m._argument_specs == {}
    assert m._owner == r

    assert m.serialize() == dict(allow_duplicates=True, dependencies=[])
    m.deserialize({'allow_duplicates': True})

# Generated at 2022-06-21 01:21:48.444607
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    result = metadata.deserialize(dict(allow_duplicates=True,
                                       dependencies=['test1', 'test2']))
    assert result == True
    assert metadata.allow_duplicates == True
    assert metadata.dependencies == ['test1', 'test2']


# Generated at 2022-06-21 01:21:53.782941
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    metadata = RoleMetadata()
    test_data = {"dependencies": [{'role': 'some.role', 'name': 'some.role'}], 'allow_duplicates': False}
    assert metadata.deserialize(test_data) == None
    assert metadata.dependencies == test_data['dependencies']
    assert metadata.allow_duplicates == False

# Generated at 2022-06-21 01:22:39.355800
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass

# Generated at 2022-06-21 01:22:42.673273
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    first_value = False
    second_value = []

    test = RoleMetadata()
    test.deserialize({"allow_duplicates": first_value, "dependencies": second_value})
    assert test.allow_duplicates == first_value
    assert test.dependencies == second_value


# Generated at 2022-06-21 01:22:52.600933
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    test_data = dict(
        allow_duplicates=True,
        dependencies=dict(role=RoleInclude('role', RoleDefinition('name', 'path')))
    )

    role_info = RoleMetadata()
    role_info.deserialize(data=test_data)

    assert role_info._allow_duplicates == True

    assert isinstance(role_info._dependencies[0], RoleRequirement)

# Generated at 2022-06-21 01:22:56.900079
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    data = dict(
        allow_duplicates=False,
        dependencies=['some']
    )
    m = RoleMetadata()
    m.deserialize(data=data)
    result = m.serialize()
    assert result == data


# Generated at 2022-06-21 01:23:02.983994
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    owner = RoleRequirement()
    owner.name = "testrole"
    m = RoleMetadata(owner=owner)
    m.allow_duplicates = True
    m.dependencies = ['testdependency']

    data = m.serialize()
    # check that the serialized object contains "allow_duplicates"
    assert data["allow_duplicates"]
    # check that the serialized object contains "dependencies"
    assert data["dependencies"] == ['testdependency']

# Generated at 2022-06-21 01:23:07.333261
# Unit test for method serialize of class RoleMetadata
def test_RoleMetadata_serialize():
    u = RoleMetadata()
    u.deserialize({'dependencies': [], 'allow_duplicates': False})
    u_serialized = u.serialize()
    assert u_serialized['dependencies'] == []
    assert u_serialized['allow_duplicates'] == False

# Generated at 2022-06-21 01:23:08.234060
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    pass


# Generated at 2022-06-21 01:23:19.826620
# Unit test for method load of class RoleMetadata
def test_RoleMetadata_load():
    import unittest
    import sys
    from ansible.playbook.role.metadata import RoleMetadata

    class TestRoleMetadata_load(unittest.TestCase):
        def test_load_throws_for_empty_data(self):
            with self.assertRaises(AnsibleParserError):
                RoleMetadata.load(data=None, owner=None)

        # Unit test for method load of class RoleMetadata, throws with unexpected data type
        def test_load_throws_for_unexpected_data_type(self):
            with self.assertRaises(AnsibleParserError):
                RoleMetadata.load(data=1234, owner=None)

        # Unit test for method load of class RoleMetadata, throws for unexpected list data

# Generated at 2022-06-21 01:23:26.240404
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
    m = RoleMetadata()
    d = dict(
        allow_duplicates = False,
        dependencies = [
            {'foo': 'bar'},
            {'src': 'michael.dehaan.test1'},
            'michael.dehaan.test2'
        ]
    )
    m.deserialize(d)
    assert m.allow_duplicates == False
    assert m.dependencies[0]['foo'] == 'bar'
    assert m.dependencies[1]['src'] == 'michael.dehaan.test1'
    assert m.dependencies[2] == 'michael.dehaan.test2'

# Generated at 2022-06-21 01:23:32.511198
# Unit test for method deserialize of class RoleMetadata
def test_RoleMetadata_deserialize():
   data = dict(
       allow_duplicates=True,
       dependencies=[dict(role='test', src='test.com/test.git', version='v1.0.0')]
   )
   m = RoleMetadata()
   m.deserialize(data)
   assert getattr(m, 'allow_duplicates') == True
   assert getattr(m, 'dependencies')[0].role == 'test'